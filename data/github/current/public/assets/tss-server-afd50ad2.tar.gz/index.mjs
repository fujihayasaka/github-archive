globalThis.__nitro_main__ = import.meta.url;
import { n as node_server_default } from "./server-nitro-KCCim8M2.js";
export { node_server_default as default };
