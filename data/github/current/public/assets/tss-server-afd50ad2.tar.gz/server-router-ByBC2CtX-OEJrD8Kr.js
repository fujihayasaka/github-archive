performance.mark("js-parse-end:server-router-ByBC2CtX-OEJrD8Kr.js");
import { i as ssrSafeLocation, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { n as getEnv } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { f as sendStats, t as SOFT_NAV_STATE } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { s as inSoftNav } from "./server-utils-4Tqzfq5z-FwA7hod1.js";
import { a as failSoftNav, d as succeedSoftNav, g as useLocation$1, l as renderedSoftNav, u as startSoftNav, y as useNavigation } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as registerRouteWithUIService } from "./server-register-route-with-ui-service-CMrESzAc-B6TtUNGU.js";
import { n as getQueryClient, r as resetQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { n as codeViewLayoutRoute$1 } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { a as updateFileTree, t as codeViewFileTreeLayoutRoute$1 } from "./server-file-tree-query-BoZ7HlYc-BElKzBR6.js";
import { t as BaseProviders } from "./server-BaseProviders-DU7Q3PBg-4trXOd5G.js";
import { n as getStartContext } from "./server-getRouterInstance-CbN1klIM-Cx3RyjAK.js";
import { c as createServerFn, d as json, i as TSS_SERVER_FUNCTION } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as serverConfig } from "./server-config-fAGtGEuQ-g7WI1iQy.js";
import { t as codeViewTreeRoute$1 } from "./server-code-view-tree-route-DaWFX48b-q_Z2gZhH.js";
import { t as codeViewBlobLayoutRoute$1 } from "./server-code-view-blob-layout-route-dhoYwhPV-CcMKI0YH.js";
import { t as codeViewBlameRoute$1 } from "./server-code-view-blame-route-CBnG62NQ-C6WKn_o_.js";
import { r as getOrCreateRequestFetchNonce } from "./server-request-C9AEnFH8-C42vJH27.js";
import { l as increment, s as getAuthContext, u as isStaff } from "./server-auth-CdSUgQ-0-DHDnXnPo.js";
import { n as getUIVersion, t as getEntrySrc } from "./server-ui-manifest-bErCbRQw-CIMAfPrX.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as codeViewBlobRoute$1 } from "./server-code-view-blob-route-BXbxJsMG-BeLOpqoP.js";
import { t as codeViewDeleteRoute$1 } from "./server-code-view-delete-route-DHSuVl8s-8Ntctk0M.js";
import { t as codeViewEditRoute$1 } from "./server-code-view-edit-route-CUHyRXnW-CWvnzfL0.js";
import { t as codeViewRepoRoute } from "./server-code-view-repo-route-BsNI4mmi-Czvdqq85.js";
import { t as codeViewNewRoute$1 } from "./server-code-view-new-route-CPa0iN_Q-Rsso1z4C.js";
import { t as codeViewTreeDeleteRoute$1 } from "./server-code-view-tree-delete-route-BKfSJUYK-C-1_W8Qg.js";
import { r as pullsDashboardSurfaceContentRoute } from "./server-pulls-dashboard-surface-content-route-CY12u0dp-B-R1iWh6.js";
import { t as pullsDashboardSurfaceLayoutRoute } from "./server-pulls-dashboard-surface-layout-route-BUkOm7Nm-BgXjnlHv.js";
import { c as reposFinderPageRoute, i as ReposListLoadingSkeleton, s as reposFinderLayoutRoute } from "./server-repos-finder-page-route-CLW2IkJh-kX9Pej9X.js";
import { n as throwDotcomPassThrough } from "./server-dotcom-pass-through-LDRpZga1-DQ9ZcIX-.js";
import { t as PullsListLoadingSkeleton } from "./server-PullsListLoadingSkeleton-DhYMWKWJ-5yMD5jGg.js";
import { t as getServerFnById } from "./server-__tanstack-start-server-fn-resolver-BwTr-KXy-X5SCb9xi.js";
import { i as shortCircuitTurboFrame, r as serverOnlyFeatureFlags } from "./server-turbo-Cr1W-fWB-D8daiiIn.js";
import { createHash, createHmac } from "node:crypto";
import { memo, useEffect, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { HeadContent, Outlet, Scripts, createFileRoute, createRootRouteWithContext, createRouter, isNotFound, lazyRouteComponent, retainSearchParams, useLoaderData, useRouter } from "@tanstack/react-router";
import { c } from "react/compiler-runtime";
import { setupRouterSsrQueryIntegration } from "@tanstack/react-router-ssr-query";
performance.mark("js-parse-end:router-ByBC2CtX.js");
function updateVisitorPayload(pathname) {
	const visitorMeta = ssrSafeDocument?.querySelector("meta[name=visitor-payload]");
	if (!visitorMeta) return;
	const payload = JSON.parse(atob(visitorMeta.content));
	payload.referrer = new URL(pathname, ssrSafeLocation.origin).href;
	visitorMeta.content = btoa(JSON.stringify(payload));
}
var useSoftNavLifecycle = (location, isLoading, error) => {
	const $ = c(6);
	const lastRecordedKeyRef = useRef(void 0);
	let t0;
	let t1;
	if ($[0] !== error || $[1] !== isLoading || $[2] !== location.key || $[3] !== location.pathname) {
		t0 = () => {
			if (!isLoading && (lastRecordedKeyRef.current === void 0 || lastRecordedKeyRef.current !== location.key)) {
				if (inSoftNav()) {
					finishSoftNav(error);
					updateVisitorPayload(location.pathname);
				} else finishHardNav(error);
				document.dispatchEvent(new CustomEvent(SOFT_NAV_STATE.REACT_DONE, { detail: { error } }));
				lastRecordedKeyRef.current = location.key;
			}
		};
		t1 = [
			location.key,
			location.pathname,
			isLoading,
			error
		];
		$[0] = error;
		$[1] = isLoading;
		$[2] = location.key;
		$[3] = location.pathname;
		$[4] = t0;
		$[5] = t1;
	} else {
		t0 = $[4];
		t1 = $[5];
	}
	useEffect(t0, t1);
};
var finishSoftNav = (error) => {
	if (error) failSoftNav();
	else {
		renderedSoftNav();
		succeedSoftNav();
	}
};
var finishHardNav = (error) => {
	if (error) return;
	const navDuration = getReactNavDuration();
	if (!navDuration) return;
	sendStats({
		requestUrl: window.location.href,
		distributionKey: "REACT_NAV_DURATION",
		distributionValue: Math.round(navDuration),
		distributionTags: ["REACT_NAV_HARD"]
	});
};
var reactNavDurationStat = "react_nav_duration";
function getReactNavDuration() {
	window.performance.measure(reactNavDurationStat, {
		start: 0,
		detail: { devtools: {
			dataType: "track-entry",
			track: "Navigation",
			trackGroup: "Performance Timeline",
			color: "secondary-light",
			tooltipText: "React nav duration"
		} }
	});
	const measure = window.performance.getEntriesByName(reactNavDurationStat).pop();
	return measure ? measure.duration : null;
}
/**
* We start the soft nav in the loader and finish it in the router.
* The soft nav events start via startSoftNav when the loader is called
* with the request in QueryRoute.
*
* SoftNavLifecycleListener is a component that listens to the soft nav
* lifecycle and finishes the operation when complete.
*/
var SoftNavLifecycleListener = memo(function SoftNavLifecycleListener() {
	const location = useLocation$1();
	const navigation = useNavigation();
	useSoftNavLifecycle(location, Boolean(navigation.location), null);
	return null;
});
SoftNavLifecycleListener.displayName = "SoftNavLifecycleListener";
var SoftNavLifecycleListenerLegacy = memo(function SoftNavLifecycleListenerLegacy() {
	useSoftNavLifecycle(useLocation$1(), false, null);
	return null;
});
SoftNavLifecycleListenerLegacy.displayName = "SoftNavLifecycleListenerLegacy";
/**
* Subscribes to TanStack Router's history events and starts
* the soft nav lifecycle for PUSH/REPLACE navigations.
*
* This bridges TanStack Router with the existing soft-nav infrastructure
* so that HPC and other web vitals are measured during client-side navigations.
*
* History-driven navigations (back/forward) are intentionally excluded
* to match existing soft-nav behavior (see use-navigator.ts).
*/
function SoftNavRouterIntegration() {
	const $ = c(4);
	const router = useRouter();
	let t0;
	if ($[0] !== router.history) {
		t0 = () => {
			return router.history.subscribe(_temp);
		};
		$[0] = router.history;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== router) {
		t1 = [router];
		$[2] = router;
		$[3] = t1;
	} else t1 = $[3];
	useEffect(t0, t1);
	return null;
}
SoftNavRouterIntegration.displayName = "SoftNavRouterIntegration";
function _temp(t0) {
	const { action, location } = t0;
	if (action.type !== "PUSH" && action.type !== "REPLACE") return;
	if (!(location.pathname === window.location.pathname && location.search === window.location.search && location.hash !== window.location.hash)) startSoftNav("ui");
}
function RootComponent() {
	return /* @__PURE__ */ jsx(RootDocument, { children: /* @__PURE__ */ jsxs(BaseProviders, {
		appName: "tss-app",
		dataRouterEnabled: true,
		children: [
			/* @__PURE__ */ jsx(SoftNavRouterIntegration, {}),
			/* @__PURE__ */ jsx(SoftNavLifecycleListener, {}),
			/* @__PURE__ */ jsx(Outlet, {})
		]
	}) });
}
RootComponent.displayName = "RootComponent";
function RootDocument(t0) {
	const $ = c(11);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { from: "__root__" };
		$[0] = t1;
	} else t1 = $[0];
	const { colorModes, analyticsUrls, aliveDetails, releaseVersion, fetchNonce, clientEnv } = useLoaderData(t1);
	const t2 = colorModes?.colorMode ?? "auto";
	const t3 = colorModes?.lightTheme ?? "light";
	const t4 = colorModes?.darkTheme ?? "dark";
	let t5;
	if ($[1] !== aliveDetails || $[2] !== analyticsUrls || $[3] !== children || $[4] !== clientEnv || $[5] !== fetchNonce || $[6] !== releaseVersion || $[7] !== t2 || $[8] !== t3 || $[9] !== t4) {
		t5 = jsxs("html", {
			lang: "en",
			"data-color-mode": t2,
			"data-light-theme": t3,
			"data-dark-theme": t4,
			suppressHydrationWarning: true,
			children: [jsxs("head", { children: [
				jsx("script", {
					id: "client-env",
					type: "application/json",
					dangerouslySetInnerHTML: { __html: JSON.stringify(clientEnv) }
				}),
				jsx("meta", {
					name: "release",
					content: releaseVersion
				}),
				jsx("meta", {
					name: "fetch-nonce",
					content: fetchNonce
				}),
				analyticsUrls?.browserErrorsUrl && jsx("meta", {
					name: "browser-errors-url",
					content: analyticsUrls.browserErrorsUrl
				}),
				analyticsUrls?.browserStatsUrl && jsx("meta", {
					name: "browser-stats-url",
					content: analyticsUrls.browserStatsUrl
				}),
				analyticsUrls?.hydroCollectorUrl && jsx("meta", {
					name: "octolytics-url",
					content: analyticsUrls.hydroCollectorUrl
				}),
				aliveDetails?.url && jsx("link", {
					rel: "shared-web-socket",
					href: aliveDetails.url,
					"data-refresh-url": aliveDetails.refreshUrl,
					"data-session-id": aliveDetails.sessionId
				}),
				aliveDetails?.socketSrc && jsx("link", {
					rel: "shared-web-socket-src",
					href: aliveDetails.socketSrc
				}),
				jsx(HeadContent, {})
			] }), jsxs("body", { children: [
				children,
				jsx("div", {
					id: "__primerPortalRoot__",
					role: "region",
					style: {
						zIndex: 1e3,
						position: "absolute",
						width: "100%"
					}
				}),
				jsx(Scripts, {})
			] })]
		});
		$[1] = aliveDetails;
		$[2] = analyticsUrls;
		$[3] = children;
		$[4] = clientEnv;
		$[5] = fetchNonce;
		$[6] = releaseVersion;
		$[7] = t2;
		$[8] = t3;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
}
RootDocument.displayName = "RootDocument";
function ErrorLayout({ title, details, stack }) {
	return /* @__PURE__ */ jsxs("main", {
		className: "tmp-p-4 container mx-auto pt-16",
		children: [
			/* @__PURE__ */ jsx("h1", { children: title }),
			/* @__PURE__ */ jsx("p", { children: details }),
			stack && /* @__PURE__ */ jsx("pre", {
				className: "tmp-p-4 w-full overflow-x-auto",
				children: /* @__PURE__ */ jsx("code", { children: stack })
			})
		]
	});
}
ErrorLayout.displayName = "ErrorLayout";
function RootErrorComponent({ error }) {
	let title = "Oops!";
	let details = "An unexpected error occurred.";
	let stack;
	if (isNotFound(error)) {
		title = "404";
		details = "The requested page could not be found.";
	} else if (error instanceof Error) {
		title = "Error";
		details = error.message || details;
	}
	return /* @__PURE__ */ jsx(ErrorLayout, {
		title,
		details,
		stack
	});
}
RootErrorComponent.displayName = "RootErrorComponent";
function NotFoundComponent() {
	return /* @__PURE__ */ jsx(ErrorLayout, {
		title: "404",
		details: "The requested page could not be found."
	});
}
NotFoundComponent.displayName = "NotFoundComponent";
var createSsrRpc = (functionId, importer) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (importer ? await importer() : await getServerFnById(functionId))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getColorModes = createServerFn().handler(createSsrRpc("ef4114798e0b83bf658371727c8c96649edc020f02b6ff83ac0124a900a0ded0", () => import("./server-color-modes-BNonmdiP-NFEBswin.js").then((m) => m["getColorModes_createServerFn_handler"])));
var getAnalyticsUrls = createServerFn().handler(createSsrRpc("86c3f6715a2dcfc16d0d89f8f78e0fc935ce178e210cd08d3372ad8b8073efa1", () => import("./server-analytics-urls-r5iI1mtO-VQgg5ZK0.js").then((m) => m["getAnalyticsUrls_createServerFn_handler"])));
/**
* Theme stylesheet mapping for dynamic loading.
*
* Instead of loading all theme stylesheets upfront, we only load the themes
* that the user has selected (light and dark themes). This reduces the initial
* CSS bundle size significantly since users typically only need 1-2 themes.
*
* The stylesheets are imported with Vite's ?url suffix to get their final URLs
* without including the CSS in the bundle. These URLs are then added as <link>
* elements in the document head.
*/
/**
* Map of theme names to their stylesheet URLs.
* These are the processed URLs from Vite that point to the final CSS files.
*/
var themeStylesheetUrls = {
	light: "https://github.githubassets.com/assets/light-BM8ncMU4.css",
	light_colorblind: "https://github.githubassets.com/assets/light_colorblind-Bp_pJGSX.css",
	light_high_contrast: "https://github.githubassets.com/assets/light_high_contrast-CLWlkIZS.css",
	light_tritanopia: "https://github.githubassets.com/assets/light_tritanopia-MovKIhyG.css",
	dark: "https://github.githubassets.com/assets/dark-DPYOeDqu.css",
	dark_colorblind: "https://github.githubassets.com/assets/dark_colorblind-_MlEXnIZ.css",
	dark_dimmed: "https://github.githubassets.com/assets/dark_dimmed-DwjFKnsb.css",
	dark_high_contrast: "https://github.githubassets.com/assets/dark_high_contrast-C5ITQEbq.css",
	dark_tritanopia: "https://github.githubassets.com/assets/dark_tritanopia-DetGqnVw.css"
};
/**
* Default themes to use when no user preference is set.
*/
var defaultLightTheme = "light";
var defaultDarkTheme = "dark";
/**
* Core logic for determining which theme stylesheets to load.
* This function is separated for testability.
*
* @param preferences - The user's color mode preferences
* @param urlMap - Map of theme names to stylesheet URLs
* @returns An array of stylesheet link objects for the head
*/
function getThemeStylesheetLinksFromMap(preferences, urlMap) {
	const links = [];
	const lightTheme = preferences?.lightTheme ?? "light";
	const darkTheme = preferences?.darkTheme ?? "dark";
	const colorMode = preferences?.colorMode ?? "auto";
	if (colorMode === "auto" || colorMode === "light") {
		const validLightTheme = urlMap[lightTheme] ? lightTheme : defaultLightTheme;
		const lightStylesheetUrl = urlMap[validLightTheme];
		if (lightStylesheetUrl) links.push({
			rel: "stylesheet",
			href: lightStylesheetUrl,
			"data-theme": validLightTheme
		});
	}
	if (colorMode === "auto" || colorMode === "dark") {
		const validDarkTheme = urlMap[darkTheme] ? darkTheme : defaultDarkTheme;
		const darkStylesheetUrl = urlMap[validDarkTheme];
		if (darkStylesheetUrl) links.push({
			rel: "stylesheet",
			href: darkStylesheetUrl,
			"data-theme": validDarkTheme
		});
	}
	return links;
}
/**
* Get the stylesheet URLs for the user's selected themes.
*
* @param preferences - The user's color mode preferences
* @returns An array of stylesheet link objects for the head
*/
function getThemeStylesheetLinks(preferences) {
	return getThemeStylesheetLinksFromMap(preferences, themeStylesheetUrls);
}
var LUAU_SOCKET_ID_VERSION = "V3";
var CHANNEL_ID_MAX = 2 ** 32;
/**
* Generates a GitHub Alive WebSocket URL for live updates
* Matches Rails implementation: lib/github/web_socket.rb#luau_url
*
* @param sessionId - The user session ID (string)
* @param actorId - The user ID (integer)
* @param aliveWsUrl - The Alive WebSocket base URL (e.g., "wss://alive.github.com")
* @returns WebSocket URL with signed session parameter
*/
function getSignedAliveUrl(sessionId, actorId, aliveWsUrl) {
	if (!actorId || !sessionId) throw new Error("Failed to get signed Alive URL: user needs to be logged in and have a valid session");
	if (!process.env.ALIVE_SECRET) throw new Error("Failed to get signed Alive URL: missing ALIVE_SECRET");
	const socketId = {
		v: LUAU_SOCKET_ID_VERSION,
		u: actorId,
		s: sessionId,
		c: Math.floor(Math.random() * CHANNEL_ID_MAX),
		t: Math.floor(Date.now() / 1e3)
	};
	const payload = JSON.stringify(socketId);
	const payloadBase64 = Buffer.from(payload).toString("base64");
	const hmac = createHmac("sha256", process.env.ALIVE_SECRET);
	hmac.update(payloadBase64);
	const signedId = `${payloadBase64}--${hmac.digest("hex")}`;
	return `${aliveWsUrl}/_sockets/u/${actorId}/ws?session=${encodeURIComponent(signedId)}`;
}
function getHashedSessionId(auth) {
	if (auth.actorId == null || auth.sessionId == null) return null;
	const hash = createHash("sha256");
	hash.update(`luau-session-id-${auth.actorId}-${auth.sessionId}`);
	return hash.digest("hex");
}
function getAliveDetailsForCurrentRequest(aliveHost) {
	const auth = getAuthContext();
	if (!auth || auth.actorId == null || auth.sessionId == null) return null;
	return {
		url: getSignedAliveUrl(auth.sessionId, auth.actorId, aliveHost),
		sessionId: getHashedSessionId(auth),
		refreshUrl: "/_alive"
	};
}
/**
* Retrieves "alive" metadata for the current request and the URL for the socket worker script.
*
* This is a server-only function that composes the result of
* {@link getAliveDetailsForCurrentRequest} with an optional `socketSrc` value
* derived from the UI manifest entry for `socket-worker.js`.
*
* @returns A promise that resolves to an object containing all properties returned
* by {@link getAliveDetailsForCurrentRequest} along with a `socketSrc` field.
* The `socketSrc` will be `null` if no manifest entry can be found for
* `socket-worker.js`. Depending on the implementation of
* {@link getAliveDetailsForCurrentRequest}, the spread `aliveDetails` may also be
* `null` or `undefined` when there are no alive details available for the current request.
*/
var getAliveDetails = async () => {
	const aliveDetails = getAliveDetailsForCurrentRequest(serverConfig.aliveHost);
	if (!aliveDetails) return null;
	const socketEntry = await getEntrySrc("socket-worker.js");
	const socketSrc = socketEntry ? `/assets-cdn/worker/${socketEntry.split("/").pop()}` : null;
	return {
		...aliveDetails,
		socketSrc
	};
};
var FONT_LINKS = [];
var serverOnlyFlags = new Set(serverOnlyFeatureFlags);
var STICKY_PARAMS = [
	"_ui",
	"_features",
	"_tracing"
];
function getSearchMiddlewares() {
	return [retainSearchParams([...STICKY_PARAMS])];
}
var Route$22 = createRootRouteWithContext()({
	head: ({ loaderData }) => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			...loaderData?.isStaff ? [{
				name: "user-staff",
				content: "1"
			}] : []
		],
		links: [...FONT_LINKS, ...getThemeStylesheetLinks(loaderData?.colorModes ?? null)]
	}),
	loader: async () => {
		const clientEnv = getEnv();
		return {
			colorModes: await getColorModes(),
			analyticsUrls: await getAnalyticsUrls(),
			aliveDetails: await getAliveDetails(),
			releaseVersion: getUIVersion(),
			fetchNonce: getOrCreateRequestFetchNonce(),
			isStaff: isStaff(),
			clientEnv: {
				...clientEnv,
				featureFlags: clientEnv.featureFlags.filter((flag) => !serverOnlyFlags.has(flag))
			}
		};
	},
	component: RootComponent,
	errorComponent: RootErrorComponent,
	notFoundComponent: NotFoundComponent,
	shouldReload: false,
	search: { middlewares: getSearchMiddlewares() }
});
var Route$21 = createFileRoute("/healthcheck")({ server: { handlers: { GET: async () => {
	return json({
		status: "healthy",
		timestamp: (/* @__PURE__ */ new Date()).toISOString()
	});
} } } });
var $$splitComponentImporter$18 = () => import("./server-global-nav-layout-9vZuvr2y-B8plujg9.js");
var globalNavLayoutLoader = createServerFn().handler(createSsrRpc("97b2c57eea454ae235ed19f793122279887e262457fa282a73f7366119742801"));
var Route$20 = createFileRoute("/_nav")({
	component: lazyRouteComponent($$splitComponentImporter$18, "component"),
	loader: () => globalNavLayoutLoader(),
	shouldReload: false
});
var Route$19 = createFileRoute("/ui/version")({ server: { handlers: { GET: async () => {
	return json({
		version: getUIVersion(),
		timestamp: (/* @__PURE__ */ new Date()).toISOString()
	});
} } } });
function routeIdFromFlag(flag) {
	return flag.replace("ui_route_", "");
}
/**
* Route-level flag guard intended for `beforeLoad`.
*
* - Server: throws a sentinel Response that stops nested loader execution.
*   Middleware reads the route header and proxies to Dotcom.
* - Client: throws a TanStack full-document redirect so routing falls back to
*   standard server handling for the current URL.
*/
var requireFlagForRoute = (flag) => {
	const route = routeIdFromFlag(flag);
	if (!isFeatureEnabled(flag)) {
		increment("ui_routes.server_decision", 1, {
			route,
			backend: "dotcom"
		});
		throwDotcomPassThrough(route);
	} else increment("ui_routes.server_decision", 1, {
		route,
		backend: "ui"
	});
};
var $$splitComponentImporter$17 = () => import("./server-layout-DmMdwMT3-BIsN_aJZ.js");
var uiServiceRouteConfig$14 = registerRouteWithUIService(reposFinderLayoutRoute, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("4049c22acbc78625404fbadcb7664ccb9e28a38a67961cbf52184858fa8188b8")),
	mode: "blocking"
} }, {
	beforeLoad: () => {
		requireFlagForRoute("ui_route_repos");
		return { navigation: { crumbs: [{
			label: "Repositories",
			href: "/repos"
		}] } };
	},
	staticData: {
		showSsoPrompt: true,
		sso: ["mainQuery", "sso"]
	}
});
var Route$18 = createFileRoute("/_nav/_repos_layout")({
	component: lazyRouteComponent($$splitComponentImporter$17, "component"),
	...uiServiceRouteConfig$14,
	shouldReload: false
});
var $$splitComponentImporter$16 = () => import("./server-react-sandbox-future-layout-CRlr6E95-BiaRO73G.js");
var layoutLoader = createServerFn().handler(createSsrRpc("76837b393b559363a9cd378daa2414bc95808736e1245f9fb3a38db41a020fb5"));
var Route$17 = createFileRoute("/_nav/_react_sandbox_future")({
	component: lazyRouteComponent($$splitComponentImporter$16, "component"),
	loader: {
		handler: () => layoutLoader(),
		staleReloadMode: "background"
	},
	shouldReload: false,
	beforeLoad: () => {
		return { navigation: {
			crumbs: [{
				label: "React Sandbox Future",
				href: "/react_sandbox_future"
			}],
			localNavigation: [
				{
					label: "Index",
					href: "/react_sandbox_future",
					id: "sandbox-index"
				},
				{
					label: "Page 1",
					href: "/react_sandbox_future/1",
					id: "sandbox-1"
				},
				{
					label: "Page 2",
					href: "/react_sandbox_future/2",
					id: "sandbox-2"
				}
			],
			selectedLink: "/react_sandbox_future"
		} };
	}
});
var $$splitComponentImporter$15 = () => import("./server-layout-BeF00bA9-B9RJu31S.js");
var uiServiceRouteConfig$13 = registerRouteWithUIService(pullsDashboardSurfaceLayoutRoute, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("3e67a847c1db09f01c56541acdb4c043f45b7b244cc33e6b6fb6f26b114156df")),
	mode: "blocking"
} }, {
	beforeLoad: () => {
		requireFlagForRoute("ui_route_pulls");
		return { navigation: { crumbs: [{
			label: "Pull Requests",
			href: "/pulls"
		}] } };
	},
	staticData: {
		showSsoPrompt: true,
		sso: ["mainQuery", "sso"]
	}
});
var Route$16 = createFileRoute("/_nav/_pulls_layout")({
	component: lazyRouteComponent($$splitComponentImporter$15, "component"),
	...uiServiceRouteConfig$13,
	shouldReload: false
});
var $$splitComponentImporter$14 = () => import("./server-repos-Cgy5hbHk-DidGyWIt.js");
var uiServiceRouteConfig$12 = registerRouteWithUIService(reposFinderPageRoute, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.withSearchParams).handler(createSsrRpc("311f5ad21c11f471b5aa30726222748ccf67f7812e97330a0371cfccb7db5b1d")),
	mode: "streaming"
} });
var Route$15 = createFileRoute("/_nav/_repos_layout/repos")({
	ssr: "data-only",
	head: () => ({ meta: [{ title: "User repositories" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component"),
	pendingComponent: ReposListLoadingSkeleton,
	pendingMinMs: 0,
	...uiServiceRouteConfig$12
});
var $$splitComponentImporter$13 = () => import("./server-pulls-Nn2C5fjp-DxFbEpBf.js");
var pullsIndexServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(createSsrRpc("180951b37fb889ea2e493ea1bafe7f5ab5f986463ee4bb5efb952295c78c841d"));
var pullsIndexDeferredServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(createSsrRpc("794b44b5a606c614b0fdffa923edd1b2e81d253620199a4f9c920ed8b2abf094"));
var uiServiceRouteConfig$11 = registerRouteWithUIService(pullsDashboardSurfaceContentRoute, {
	mainQuery: {
		queryFn: pullsIndexServerFn,
		mode: "streaming"
	},
	deferred: {
		queryFn: pullsIndexDeferredServerFn,
		mode: "streaming"
	}
});
var Route$14 = createFileRoute("/_nav/_pulls_layout/pulls")({
	component: lazyRouteComponent($$splitComponentImporter$13, "component"),
	pendingComponent: PullsListLoadingSkeleton,
	pendingMinMs: 0,
	...uiServiceRouteConfig$11
});
var $$splitComponentImporter$12 = () => import("./server-react-sandbox-future-id-Df8RLSTO-BX810FnM.js");
var idLoader = createServerFn().inputValidator((data) => data).handler(createSsrRpc("a64794e92b23f483ccd07044c4f01cab0f6dfdc92540bdffa335bb2ae630e5a0"));
var Route$13 = createFileRoute("/_nav/_react_sandbox_future/react_sandbox_future/$id")({
	head: () => ({ meta: [{ title: "React Sandbox Future Id" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component"),
	loader: {
		handler: ({ params }) => idLoader({ data: { id: params.id } }),
		staleReloadMode: "background"
	},
	beforeLoad: ({ context, params, location }) => {
		return { navigation: {
			...context.navigation,
			crumbs: [...context.navigation?.crumbs ?? [], {
				label: `Page #${params.id}`,
				href: `/react_sandbox_future/${params.id}`
			}],
			selectedLink: location.pathname
		} };
	}
});
var Route$12 = createFileRoute("/_nav/$owner/$repo/_repo_layout")({ beforeLoad({ params }) {
	const { owner, repo } = params;
	const encodedOwner = encodeURIComponent(owner);
	const encodedRepo = encodeURIComponent(repo);
	return { navigation: {
		crumbs: [{
			label: owner,
			href: `/${encodedOwner}`
		}, {
			label: repo,
			href: `/${encodedOwner}/${encodedRepo}`,
			crumb_type: "repository"
		}],
		localNavigation: [
			{
				id: "code",
				icon: "code",
				label: "Code",
				href: `/${encodedOwner}/${encodedRepo}`,
				selectedLinks: [
					"repo_source",
					"repo_downloads",
					"repo_commits",
					"repo_releases",
					"repo_tags",
					"repo_branches",
					"repo_packages",
					"repo_deployments",
					"repo_attestations"
				],
				commandId: "repositories:go-to-code",
				reactNav: {
					appTarget: "code-view",
					anchor: "code-view-repo-link"
				}
			},
			{
				id: "issues",
				icon: "issue-opened",
				label: "Issues",
				href: `/${encodedOwner}/${encodedRepo}/issues`,
				selectedLinks: [
					"repo_issues",
					"repo_labels",
					"repo_milestones"
				],
				commandId: "repositories:go-to-issues",
				hotkey: "g i",
				reactNav: {
					appTarget: "issues-react",
					anchor: void 0
				}
			},
			{
				id: "pull-requests",
				icon: "git-pull-request",
				label: "Pull requests",
				href: `/${encodedOwner}/${encodedRepo}/pulls`,
				selectedLinks: ["repo_pulls", "checks"],
				commandId: "repositories:go-to-pull-requests",
				hotkey: "g p",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "agents",
				icon: "agent",
				label: "Agents",
				href: `/${encodedOwner}/${encodedRepo}/agents`,
				selectedLinks: ["repo_agents", "repo_agents_task"],
				commandId: "repositories:go-to-agents",
				hotkey: "g e",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "discussions",
				icon: "comment-discussion",
				label: "Discussions",
				href: `/${encodedOwner}/${encodedRepo}/discussions`,
				selectedLinks: ["repo_discussions"],
				commandId: "repositories:go-to-discussions",
				hotkey: "g g",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "actions",
				icon: "play",
				label: "Actions",
				href: `/${encodedOwner}/${encodedRepo}/actions`,
				selectedLinks: ["repo_actions"],
				hotkey: "g a",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "projects",
				icon: "table",
				label: "Projects",
				href: `/${encodedOwner}/${encodedRepo}/projects`,
				selectedLinks: [
					"repo_projects",
					"new_repo_project",
					"repo_project"
				],
				commandId: "repositories:go-to-projects",
				hotkey: "g b",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "security",
				icon: "shield",
				label: "Security",
				href: `/${encodedOwner}/${encodedRepo}/security`,
				selectedLinks: [
					"security",
					"overview",
					"alerts",
					"policy",
					"token_scanning",
					"code_scanning"
				],
				commandId: "repositories:go-to-security",
				hotkey: "g s",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "insights",
				icon: "graph",
				label: "Insights",
				href: `/${encodedOwner}/${encodedRepo}/pulse`,
				selectedLinks: [
					"repo_graphs",
					"repo_contributors",
					"dependency_graph",
					"dependabot_updates",
					"pulse",
					"people",
					"community"
				],
				commandId: "repositories:go-to-insights",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			},
			{
				id: "settings",
				icon: "gear",
				label: "Settings",
				href: `/${encodedOwner}/${encodedRepo}/settings`,
				selectedLinks: [
					"code_review_limits",
					"code_quality",
					"codespaces_repository_settings",
					"collaborators",
					"custom_tabs",
					"github_models_repo_settings",
					"hooks",
					"integration_installations",
					"interaction_limits",
					"issue_template_editor",
					"key_links_settings",
					"license_policy",
					"notifications",
					"repo_announcements",
					"repo_branch_settings",
					"repo_custom_properties",
					"repo_keys_settings",
					"repo_pages_settings",
					"repo_protected_tags_settings",
					"repo_rule_insights",
					"repo_rules_bypass_requests",
					"repo_rulesets",
					"repo_settings_copilot_coding_guidelines",
					"repo_settings_copilot_content_exclusion",
					"repo_settings_copilot_swe_agent",
					"repo_settings",
					"reported_content",
					"repository_actions_settings_add_new_runner",
					"repository_actions_settings_general",
					"repository_actions_settings_runner_details",
					"repository_actions_settings_runners",
					"repository_actions_settings",
					"repository_actions_settings_policies",
					"repository_environments",
					"role_details",
					"secrets_settings_actions",
					"secrets_settings_codespaces",
					"secrets_settings_dependabot",
					"secrets",
					"security_analysis",
					"security_products"
				],
				commandId: "repositories:go-to-settings",
				reactNav: {
					appTarget: void 0,
					anchor: void 0
				}
			}
		]
	} };
} });
var $$splitComponentImporter$11 = () => import("./server-react-sandbox-future-index-XKDIa563-BPT2UQ-W.js");
var indexLoader = createServerFn().handler(createSsrRpc("a07e5a1811e99c52a112dcf349e8057d914dd5e979710806dce91e8db540ec44"));
var Route$11 = createFileRoute("/_nav/_react_sandbox_future/react_sandbox_future/")({
	head: () => ({ meta: [{ title: "React Sandbox Future Index" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component"),
	loader: {
		handler: () => indexLoader(),
		staleReloadMode: "background"
	}
});
var code_default = "https://github.githubassets.com/assets/index-Bt7-r3wP.css";
var global_default = "https://github.githubassets.com/assets/index-x7JzkEm7.css";
var $$splitComponentImporter$10 = () => import("./server-layout-D-H3AnqV-CIB-ruut.js");
var uiServiceRouteConfig$10 = registerRouteWithUIService(codeViewLayoutRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("b675b2614abc8b6e4bf1724b1e67a55a35682e23fb9ce0522bd2075187e4566a")),
	mode: "blocking"
} }, { beforeLoad: () => {
	requireFlagForRoute("ui_route_code_view");
	shortCircuitTurboFrame();
	return {};
} });
var Route$10 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout")({
	component: lazyRouteComponent($$splitComponentImporter$10, "component"),
	...uiServiceRouteConfig$10,
	head: () => ({ links: [{
		rel: "stylesheet",
		href: global_default
	}, {
		rel: "stylesheet",
		href: code_default
	}] }),
	shouldReload: false
});
var $$splitComponentImporter$9 = () => import("./server-file-tree-layout-DHZrbsSr-DIGDC4pH.js");
var uiServiceRouteConfig$9 = registerRouteWithUIService(codeViewFileTreeLayoutRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("694f3736e0b5f75f6cc2581eab05ece8a1ffe21b38dcd1f6a5e06fb6915e3cfe")),
	mode: "blocking"
} });
var Route$9 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout")({
	component: lazyRouteComponent($$splitComponentImporter$9, "component"),
	...uiServiceRouteConfig$9,
	shouldReload: false
});
/**
* Shared query config for the latestCommit query.
*
* Fetches the latest commit information for the current path, including
* commit status checks. This query is used by both the tree route and
* repo overview route to display the most recent commit in the header.
*/
var latestCommitQuery = {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("c095f5f847e3e9e85a9cdbf02c3a0a9306f74ec8da2d4181dc43a5b337a1716b")),
	mode: "streaming"
};
/**
* Shared query config for the treeCommitInfo query.
*
* Fetches commit info for each entry in the file tree, keyed by path.
* This data is used to display per-file commit messages and dates in
* the tree view. Used by both the tree route and repo overview route.
*/
var treeCommitInfoQuery = {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("1900fd1372f2c4547c9dabe0cb6c502a5f5cba01a8e66c69a6397b1bad093695")),
	mode: "streaming"
};
var $$splitComponentImporter$8 = () => import("./server-repo-overview-BXHKxiPv-DavC0JXv.js");
var codeViewRepoOverviewServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("5570a6dfaea5b5a8291c280a1b6bf2d11d3943232fdcb95f6ef940f99f19a782"));
var headerPartialServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("11ecefba7033308c84e7125a569cd4e43612780a5a95ae1b856cf272e4dc792f"));
var sidebarPartialServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("7f955aae96327dca072e229ce256f7a4e6ffe65004b0cbf55e83efea5d9f703e"));
var recentlyTouchedBranchesServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("209ee1152b7c97b2cb4358ec3ed1101afbfb79eb8d7415a7869d6e9ccacb308f"));
var branchAndTagCountServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("02b53bedb79ffba7123f46f6683fd076943a6c59c1fbc50fb98f29e4762fdce5"));
var aboutQueryServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("ede11af01410f853c6f30f37d655e27965917c49dbbfa223a0a0f02152b2112c"));
var uiServiceRouteConfig$8 = registerRouteWithUIService(codeViewRepoRoute, {
	mainQuery: {
		queryFn: codeViewRepoOverviewServerFn,
		mode: "blocking"
	},
	"codeViewRepoRoute.Header": {
		queryFn: headerPartialServerFn,
		mode: "blocking",
		select: ({ payload }) => payload["codeViewRepoRoute.Header"]
	},
	"codeViewRepoRoute.Sidebar": {
		queryFn: sidebarPartialServerFn,
		mode: "blocking",
		select: ({ payload }) => payload["codeViewRepoRoute.Sidebar"]
	},
	latestCommit: latestCommitQuery,
	treeCommitInfo: treeCommitInfoQuery,
	recentlyTouchedBranches: {
		queryFn: recentlyTouchedBranchesServerFn,
		mode: "streaming"
	},
	branchAndTagCount: {
		queryFn: branchAndTagCountServerFn,
		mode: "streaming"
	},
	sidebarAbout: {
		queryFn: aboutQueryServerFn,
		mode: "blocking"
	}
});
var Route$8 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/")({
	component: lazyRouteComponent($$splitComponentImporter$8, "component"),
	...uiServiceRouteConfig$8
});
var $$splitComponentImporter$7 = () => import("./server-blob-layout-JR6Wj1q1-Dy_asZR3.js");
var codeViewBlobLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("c83dfe310299fc5ef2a93f49a7327eabe3cf9dedae2230f9a88bf953a13368cb"));
var codeViewBlobLayoutStyledBlobServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("8504c6d56c3efae37bf79d9b8c60c5a14489f3720fd612aa3cb53417d9f5a9da"));
var deferredMetadataServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("140174379d70ac1fb8fe0e39cc460887e8bbb07eb0ae1ce7e2488ed81b793b6f"));
var uiServiceRouteConfig$7 = registerRouteWithUIService(codeViewBlobLayoutRoute$1, {
	mainQuery: {
		queryFn: codeViewBlobLayoutServerFn,
		mode: "blocking"
	},
	"codeViewBlobLayoutRoute.StyledBlob": {
		queryFn: codeViewBlobLayoutStyledBlobServerFn,
		mode: "blocking",
		select: (data) => {
			const payload = data.payload?.["codeViewBlobLayoutRoute.StyledBlob"];
			if (payload === void 0 || payload === null) throw new Error("Missing payload for codeViewBlobLayoutRoute.StyledBlob");
			return payload;
		}
	},
	deferredMetadata: {
		queryFn: deferredMetadataServerFn,
		mode: "streaming"
	},
	latestCommit: latestCommitQuery
});
var Route$7 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout")({
	component: lazyRouteComponent($$splitComponentImporter$7, "component"),
	...uiServiceRouteConfig$7,
	shouldReload: true
});
/**
* Shared query config for the fileTree query.
*
* The fileTree query is a special cache updater that fetches missing directory data
* and updates the file tree cache. It must be registered with registerRouteWithUIService
* so that components can access it via useRouteQuery(route, 'fileTree').
*
* When called (either during initial load or via refetch()), it calls updateFileTree which:
* - Checks what paths are missing from the current file tree cache
* - Fetches the missing directory data from the server
* - Merges the new data into the file tree cache
*
* This query is used by both the tree route and blob route, which both need access to the
* file tree for navigation.
*/
var fileTreeQuery = {
	queryFn: async ({ data }) => {
		const { params } = data;
		await updateFileTree({
			owner: params.owner,
			repo: params.repo,
			params
		});
		return null;
	},
	mode: "streaming"
};
var $$splitComponentImporter$6 = () => import("./server-tree-1hplyQBp-Dmrrvker.js");
var uiServiceRouteConfig$6 = registerRouteWithUIService(codeViewTreeRoute$1, {
	mainQuery: {
		queryFn: createServerFn().inputValidator(queryValidator.withSearchParams).handler(createSsrRpc("ad0a48c2e16c9d6dc580cf6e1f28842ad0acd3d852e622e196513c14d28b6462")),
		mode: "blocking"
	},
	latestCommit: latestCommitQuery,
	treeCommitInfo: treeCommitInfoQuery,
	fileTree: fileTreeQuery
});
var Route$6 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	...uiServiceRouteConfig$6
});
var $$splitComponentImporter$5 = () => import("./server-new-F_Dt-DmG-DD759U0i.js");
var uiServiceRouteConfig$5 = registerRouteWithUIService(codeViewNewRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("485aab9949f91d6ded9cd342ed5bbfe78020f1699252653dea689a9897608303")),
	mode: "blocking"
} });
var Route$5 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	...uiServiceRouteConfig$5
});
var $$splitComponentImporter$4 = () => import("./server-edit-C6wzTPm3--kj5l_Vj.js");
var uiServiceRouteConfig$4 = registerRouteWithUIService(codeViewEditRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("0171e77204682a42c63d8f4aabb2374f77edfad4696d22265c4d82b119aeb6cf")),
	mode: "blocking"
} });
var Route$4 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	...uiServiceRouteConfig$4
});
var $$splitComponentImporter$3 = () => import("./server-delete-uOyiB6i4-BwxzkSiV.js");
var uiServiceRouteConfig$3 = registerRouteWithUIService(codeViewDeleteRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("8a17754e5d26e19e0c86f0f44a9d847ecc33a7285eb228ef9c1b69805a32feee")),
	mode: "blocking"
} });
var Route$3 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	...uiServiceRouteConfig$3
});
var $$splitComponentImporter$2 = () => import("./server-tree-delete-dMRTwi9U-CCdX3NUA.js");
var uiServiceRouteConfig$2 = registerRouteWithUIService(codeViewTreeDeleteRoute$1, { mainQuery: {
	queryFn: createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("49ebf714316715b57e796c434675bccb1d1f4fe6328a00e55a409ab6fe3d1933")),
	mode: "blocking"
} });
var Route$2 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	...uiServiceRouteConfig$2
});
var $$splitComponentImporter$1 = () => import("./server-blob-CZnmQb8j-Dzz3HFWO.js");
var uiServiceRouteConfig$1 = registerRouteWithUIService(codeViewBlobRoute$1, {
	mainQuery: {
		queryFn: createServerFn().inputValidator(queryValidator.withSearchParams).handler(createSsrRpc("93143f62fd7abef2b06e315700aa1d9d03a0b62a785fe928a82638f4879af70a")),
		mode: "blocking"
	},
	fileTree: fileTreeQuery
});
var Route$1 = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	...uiServiceRouteConfig$1
});
var $$splitComponentImporter = () => import("./server-blame-B2ImpwZD-DLDlVl7Y.js");
var codeViewBlameServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("114d5388eb2fca2a18c6c57a9d2b1ab96be2fc0e35d9bde5632d3e85f658dcf2"));
var contributorsServerFn = createServerFn().inputValidator(queryValidator.base).handler(createSsrRpc("54cf7fcad24fb13d72cc3a43b3d405c09019149320a1716f6dbbc03c570651e7"));
var uiServiceRouteConfig = registerRouteWithUIService(codeViewBlameRoute$1, {
	mainQuery: {
		queryFn: codeViewBlameServerFn,
		mode: "blocking"
	},
	contributors: {
		queryFn: contributorsServerFn,
		mode: "streaming"
	}
});
var Route = createFileRoute("/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	...uiServiceRouteConfig
});
var healthcheckRoute = Route$21.update({
	id: "/healthcheck",
	path: "/healthcheck",
	getParentRoute: () => Route$22
});
var rootGlobalNavLayoutRoute = Route$20.update({
	id: "/_nav",
	getParentRoute: () => Route$22
});
var uiVersionRoute = Route$19.update({
	id: "/ui/version",
	path: "/ui/version",
	getParentRoute: () => Route$22
});
var reposLayoutRoute = Route$18.update({
	id: "/_repos_layout",
	getParentRoute: () => rootGlobalNavLayoutRoute
});
var react_sandbox_futureReactSandboxFutureLayoutRoute = Route$17.update({
	id: "/_react_sandbox_future",
	getParentRoute: () => rootGlobalNavLayoutRoute
});
var pullsLayoutRoute = Route$16.update({
	id: "/_pulls_layout",
	getParentRoute: () => rootGlobalNavLayoutRoute
});
var reposIndexRoute = Route$15.update({
	id: "/repos",
	path: "/repos",
	getParentRoute: () => reposLayoutRoute
});
var pullsIndexRoute = Route$14.update({
	id: "/pulls",
	path: "/pulls",
	getParentRoute: () => pullsLayoutRoute
});
var react_sandbox_futureReactSandboxFutureIdRoute = Route$13.update({
	id: "/react_sandbox_future/$id",
	path: "/react_sandbox_future/$id",
	getParentRoute: () => react_sandbox_futureReactSandboxFutureLayoutRoute
});
var repoRepoLayoutRoute = Route$12.update({
	id: "/$owner/$repo/_repo_layout",
	path: "/$owner/$repo",
	getParentRoute: () => rootGlobalNavLayoutRoute
});
var react_sandbox_futureReactSandboxFutureIndexRoute = Route$11.update({
	id: "/react_sandbox_future/",
	path: "/react_sandbox_future/",
	getParentRoute: () => react_sandbox_futureReactSandboxFutureLayoutRoute
});
var codeViewLayoutRoute = Route$10.update({
	id: "/_codeview_layout",
	getParentRoute: () => repoRepoLayoutRoute
});
var codeViewFileTreeLayoutRoute = Route$9.update({
	id: "/_file_tree_layout",
	getParentRoute: () => codeViewLayoutRoute
});
var codeViewRepoOverviewRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => codeViewLayoutRoute
});
var codeViewBlobLayoutRoute = Route$7.update({
	id: "/_blob_layout",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewTreeRoute = Route$6.update({
	id: "/tree/$branch/$",
	path: "/tree/$branch/$",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewNewRoute = Route$5.update({
	id: "/new/$branch/$",
	path: "/new/$branch/$",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewEditRoute = Route$4.update({
	id: "/edit/$branch/$",
	path: "/edit/$branch/$",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewDeleteRoute = Route$3.update({
	id: "/delete/$branch/$",
	path: "/delete/$branch/$",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewTreeDeleteRoute = Route$2.update({
	id: "/tree/delete/$branch/$",
	path: "/tree/delete/$branch/$",
	getParentRoute: () => codeViewFileTreeLayoutRoute
});
var codeViewBlobRoute = Route$1.update({
	id: "/blob/$branch/$",
	path: "/blob/$branch/$",
	getParentRoute: () => codeViewBlobLayoutRoute
});
var codeViewBlameRoute = Route.update({
	id: "/blame/$branch/$",
	path: "/blame/$branch/$",
	getParentRoute: () => codeViewBlobLayoutRoute
});
var pullsLayoutRouteChildren = { pullsIndexRoute };
var pullsLayoutRouteWithChildren = pullsLayoutRoute._addFileChildren(pullsLayoutRouteChildren);
var react_sandbox_futureReactSandboxFutureLayoutRouteChildren = {
	react_sandbox_futureReactSandboxFutureIndexRoute,
	react_sandbox_futureReactSandboxFutureIdRoute
};
var react_sandbox_futureReactSandboxFutureLayoutRouteWithChildren = react_sandbox_futureReactSandboxFutureLayoutRoute._addFileChildren(react_sandbox_futureReactSandboxFutureLayoutRouteChildren);
var reposLayoutRouteChildren = { reposIndexRoute };
var reposLayoutRouteWithChildren = reposLayoutRoute._addFileChildren(reposLayoutRouteChildren);
var codeViewBlobLayoutRouteChildren = {
	codeViewBlameRoute,
	codeViewBlobRoute
};
var codeViewFileTreeLayoutRouteChildren = {
	codeViewBlobLayoutRoute: codeViewBlobLayoutRoute._addFileChildren(codeViewBlobLayoutRouteChildren),
	codeViewDeleteRoute,
	codeViewEditRoute,
	codeViewNewRoute,
	codeViewTreeRoute,
	codeViewTreeDeleteRoute
};
var codeViewLayoutRouteChildren = {
	codeViewRepoOverviewRoute,
	codeViewFileTreeLayoutRoute: codeViewFileTreeLayoutRoute._addFileChildren(codeViewFileTreeLayoutRouteChildren)
};
var repoRepoLayoutRouteChildren = { codeViewLayoutRoute: codeViewLayoutRoute._addFileChildren(codeViewLayoutRouteChildren) };
var rootGlobalNavLayoutRouteChildren = {
	pullsLayoutRoute: pullsLayoutRouteWithChildren,
	react_sandbox_futureReactSandboxFutureLayoutRoute: react_sandbox_futureReactSandboxFutureLayoutRouteWithChildren,
	reposLayoutRoute: reposLayoutRouteWithChildren,
	repoRepoLayoutRoute: repoRepoLayoutRoute._addFileChildren(repoRepoLayoutRouteChildren)
};
var rootRouteChildren = {
	rootGlobalNavLayoutRoute: rootGlobalNavLayoutRoute._addFileChildren(rootGlobalNavLayoutRouteChildren),
	healthcheckRoute,
	uiVersionRoute
};
var routeTree = Route$22._addFileChildren(rootRouteChildren)._addFileTypes();
var getNonceFromContext = () => {
	return getStartContext().contextAfterGlobalMiddlewares.nonce;
};
function getRouter() {
	const queryClient = getQueryClient();
	resetQueryClient();
	queryClient.setQueryDefaults([], {
		staleTime: 0,
		gcTime: 1e3 * 60 * 5,
		refetchOnMount: false
	});
	const router = createRouter({
		routeTree,
		scrollRestoration: true,
		trailingSlash: "preserve",
		ssr: { nonce: getNonceFromContext() },
		context: { queryClient },
		defaultStaleReloadMode: "blocking"
	});
	setupRouterSsrQueryIntegration({
		router,
		queryClient,
		wrapQueryClient: false
	});
	return router;
}
export { getRouter };
