import { Mi as XIcon, an as IconButton } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { _ as get, b as useTheme, g as Ye, y as sx } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import React, { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { parseToHsla, parseToRgba } from "color2k";
var xlargeSize = "32px";
var tokenSizes = {
	small: "16px",
	medium: "20px",
	large: "24px",
	extralarge: xlargeSize,
	xlarge: xlargeSize
};
var defaultTokenSize = "medium";
var isTokenInteractive = ({ as = "span", onClick, onFocus, tabIndex = -1, interactive }) => interactive ?? Boolean(onFocus || onClick || tabIndex > -1 || ["a", "button"].includes(as));
var xlargeVariantStyles = {
	fontSize: 1,
	height: tokenSizes.xlarge,
	lineHeight: tokenSizes.xlarge,
	px: 3,
	py: 0
};
var variants = {
	small: {
		fontSize: 0,
		height: tokenSizes.small,
		lineHeight: tokenSizes.small,
		px: 1,
		py: 0
	},
	medium: {
		fontSize: 0,
		height: tokenSizes.medium,
		lineHeight: tokenSizes.medium,
		px: 2,
		py: 0
	},
	large: {
		fontSize: 0,
		height: tokenSizes.large,
		lineHeight: tokenSizes.large,
		px: 2,
		py: 0
	},
	extralarge: xlargeVariantStyles,
	xlarge: xlargeVariantStyles
};
var StyledTokenBase = Ye.span.withConfig({
	displayName: "TokenBase__StyledTokenBase",
	componentId: "sc-wpoz-0"
})([
	"align-items:center;border-radius:999px;cursor:",
	";display:inline-flex;font-weight:",
	";font-family:inherit;text-decoration:none;max-width:100%;position:relative;white-space:nowrap;",
	""
], (props) => isTokenInteractive(props) ? "pointer" : "auto", get("fontWeights.bold"), sx);
function TokenBase({ ref: forwardedRef, text, onRemove, id, as = "span", sx: baseSx, size = defaultTokenSize, ...rest }) {
	return /* @__PURE__ */ jsx(StyledTokenBase, {
		"aria-label": onRemove ? `${text}, press backspace or delete to remove` : void 0,
		id: id?.toString(),
		as,
		sx: {
			...variants[size],
			...baseSx
		},
		...rest,
		ref: forwardedRef
	});
}
TokenBase.displayName = "TokenBase";
var TokenTextContainer = Ye("span").withConfig({
	displayName: "TokenTextContainer",
	componentId: "sc-n0u8jr-0"
})(["flex-grow:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:transparent;border:0;font:inherit;margin:0;padding:0;width:auto;-webkit-font-smoothing:inherit;-moz-osx-font-smoothing:inherit;color:currentColor;text-decoration:none;&:is(a,button,[tabIndex='0']){cursor:pointer;&::after{content:'';position:absolute;left:0;top:0;right:0;bottom:0;}}"]);
var LabelToken_module_default = {
	labelTokenBase: "LabelToken-module_F938Za_labelTokenBase",
	labelTokenDeleteButton: "LabelToken-module_F938Za_labelTokenDeleteButton"
};
var tokenBorderWidthPx = 1;
var LabelToken = ({ ref: forwardedRef, as, fontWeight, fillColor = "#999", onRemove, id, isSelected, text, size = defaultTokenSize, hideRemoveButton, href, onDelete, ...rest }) => {
	const { colorScheme } = useTheme();
	const isHighContrast = useMemo(() => colorScheme?.includes("high_contrast"), [colorScheme]);
	const lightModeStyles = useMemo(() => ({
		"--lightness-threshold": "0.453",
		"--border-threshold": "0.96",
		"--background-alpha": "0.20",
		"--border-alpha": "max(0, min(calc((var(--perceived-lightness) - var(--border-threshold)) * 100), 1))",
		background: "rgb(var(--label-r), var(--label-g), var(--label-b))",
		color: "hsl(0deg, 0%, calc(var(--lightness-switch) * 100%))",
		borderWidth: tokenBorderWidthPx,
		borderStyle: "solid",
		borderColor: "hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) - 25) * 1%), var(--border-alpha))"
	}), []);
	const darkModeStyles = useMemo(() => ({
		"--lightness-threshold": "0.6",
		"--background-alpha": "0.18",
		"--border-alpha": isHighContrast ? "0.9" : "0.3",
		"--lighten-by": "calc(((var(--lightness-threshold) - var(--perceived-lightness)) * 100) * var(--lightness-switch))",
		borderWidth: tokenBorderWidthPx,
		borderStyle: "solid",
		background: "rgba(var(--label-r), var(--label-g), var(--label-b), var(--background-alpha))",
		color: "hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%))",
		borderColor: "hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%), var(--border-alpha))"
	}), [isHighContrast]);
	const interactiveTokenProps = {
		as,
		href
	};
	const hasMultipleActionTargets = isTokenInteractive(rest) && Boolean(onRemove) && !hideRemoveButton;
	const labelStyles = useMemo(() => {
		const [r, g, b] = parseToRgba(fillColor);
		const [h, s, l] = parseToHsla(fillColor);
		return {
			"--label-r": String(r),
			"--label-g": String(g),
			"--label-b": String(b),
			"--label-h": String(Math.round(h)),
			"--label-s": String(Math.round(s * 100)),
			"--label-l": String(Math.round(l * 100)),
			"--perceived-lightness": "calc(((var(--label-r) * 0.2126) + (var(--label-g) * 0.7152) + (var(--label-b) * 0.0722)) / 255)",
			"--lightness-switch": "max(0, min(calc((1/(var(--lightness-threshold) - var(--perceived-lightness)))), 1))",
			"--border-color": "var(--borderColor-muted, var(--color-border-subtle))",
			paddingRight: hideRemoveButton || !onRemove ? void 0 : 0,
			position: "relative",
			minWidth: 0,
			overflow: "hidden",
			...colorScheme?.includes("light") ? lightModeStyles : darkModeStyles,
			...fontWeight ? { fontWeight } : {},
			...isSelected ? {
				background: colorScheme === "light" ? "hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) - 5) * 1%))" : darkModeStyles.background,
				":focus": { outline: "none" },
				":after": {
					content: "\"\"",
					position: "absolute",
					zIndex: 1,
					top: `-${tokenBorderWidthPx * 2}px`,
					right: `-${tokenBorderWidthPx * 2}px`,
					bottom: `-${tokenBorderWidthPx * 2}px`,
					left: `-${tokenBorderWidthPx * 2}px`,
					display: "block",
					pointerEvents: "none",
					boxShadow: `0 0 0 ${tokenBorderWidthPx * 2}px ${colorScheme === "light" ? "rgb(var(--label-r), var(--label-g), var(--label-b))" : "hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%))"}`,
					borderRadius: "999px"
				}
			} : {}
		};
	}, [
		fillColor,
		hideRemoveButton,
		onRemove,
		fontWeight,
		colorScheme,
		lightModeStyles,
		darkModeStyles,
		isSelected
	]);
	return /* @__PURE__ */ jsxs(TokenBase, {
		onRemove,
		id: id?.toString(),
		isSelected,
		text,
		size,
		sx: labelStyles,
		...!hasMultipleActionTargets ? interactiveTokenProps : {},
		...rest,
		ref: forwardedRef,
		className: onDelete ? LabelToken_module_default.labelTokenBase : void 0,
		children: [/* @__PURE__ */ jsx(TokenTextContainer, {
			...hasMultipleActionTargets ? interactiveTokenProps : {},
			children: text
		}), onDelete && /* @__PURE__ */ jsx(IconButton, {
			onClick: (e) => {
				e.stopPropagation();
				e.preventDefault();
				onDelete();
			},
			variant: "invisible",
			icon: XIcon,
			size: "small",
			"aria-label": "Remove label",
			className: LabelToken_module_default.labelTokenDeleteButton
		})]
	});
};
LabelToken.displayName = "IssueLabelToken";
export { LabelToken as t };
