performance.mark("js-parse-end:server-IssueCommentEditor-BbPKhk28-C8Ht7ODG.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { t as canBeOptimisticallyParsed } from "./server-md2html-TgcTyYQC-DzwxtslQ.js";
import { p as validateComment, t as CommentBox } from "./server-validators-DpH9Vi4K-BgoqazXb.js";
import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { a as TEST_IDS, i as LABELS, n as ERRORS } from "./server-quotes-Biwbbu-B-YKXYFdbk.js";
import { c as require_hooks } from "./server-use-issue-pr-state-Ca7HKQL5-BTNcVLo6.js";
import { c as IssueCommentHeader, g as commitUpdateIssueCommentBodyMutation } from "./server-update-issue-comment-body-mutation-Hq-PEIJI-CwHjzG_O.js";
import { t as BUTTON_LABELS } from "./server-button-labels-DIxotQxx-Dixtm-9B.js";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
performance.mark("js-parse-end:IssueCommentEditor-BbPKhk28.js");
var node$1 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueCommentEditor_repository",
	"selections": [{
		"alias": null,
		"args": null,
		"concreteType": "Repository",
		"kind": "LinkedField",
		"name": "repository",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "slashCommandsEnabled",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "nameWithOwner",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "databaseId",
				"storageKey": null
			}
		],
		"storageKey": null
	}],
	"type": "IssueComment",
	"abstractKey": null
};
node$1.hash = "ed1c5fd22a973ac313b7b49b9ffa3105";
var node = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IssueCommentEditorBodyFragment",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "body",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "bodyVersion",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "author",
				"plural": false,
				"selections": [v1, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "avatarUrl",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Issue",
				"kind": "LinkedField",
				"name": "issue",
				"plural": false,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "databaseId",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "author",
						"plural": false,
						"selections": [v1],
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "IssueCommentHeader"
			}
		],
		"type": "IssueComment",
		"abstractKey": null
	};
})();
node.hash = "ccd3b10437b5d35f704f99ca1d9a6735";
var import_hooks = require_hooks();
var import_react_relay = require_react_relay();
var IssueCommentEditor_module_default = {
	CommentBox: "IssueCommentEditor-module_vRxx5q_CommentBox",
	EditorMarginContainer: "IssueCommentEditor-module_vRxx5q_EditorMarginContainer"
};
var IssueCommentEditorFragment = node$1;
var IssueCommentEditorBodyFragment = node;
function IssueCommentEditor({ initialValue = "", comment, repo, cancelEdit, onSave, onChange, setIsEditing, setHasDisabledActions, isSubmitting, setIsSubmitting, initialValidationResult, setManualValidationResult }) {
	const ref = useRef(null);
	const data = (0, import_hooks.useFragment)(IssueCommentEditorBodyFragment, comment);
	const { body, bodyVersion } = data;
	const { repository } = (0, import_hooks.useFragment)(IssueCommentEditorFragment, repo);
	const repositoryDatabaseId = repository.databaseId;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	const [currentBody, setCurrentBody] = useState(initialValue || body);
	const [currentBodyVersion] = useState(bodyVersion);
	const computedValidationResult = useMemo(() => validateComment(currentBody), [currentBody]);
	const onMarkdownChange = (newMarkdown) => {
		setCurrentBody(newMarkdown);
		onChange(newMarkdown);
	};
	const save = useCallback((newId) => {
		const withOptimisticResponse = canBeOptimisticallyParsed(currentBody);
		if (withOptimisticResponse) {
			setIsEditing(false);
			setHasDisabledActions(true);
		} else setIsSubmitting(true);
		commitUpdateIssueCommentBodyMutation({
			environment,
			input: {
				id: newId,
				body: currentBody,
				bodyVersion: currentBodyVersion
			},
			onError: (error) => {
				setIsSubmitting(false);
				setHasDisabledActions(false);
				addToast({
					type: "error",
					message: error.message.startsWith(LABELS.staleCommentErrorPrefix) ? ERRORS.couldNotEditCommentStale : ERRORS.couldNotEditComment
				});
				if (!error.message.startsWith(LABELS.staleCommentErrorPrefix)) onSave();
				else setManualValidationResult?.({
					isValid: false,
					errorMessage: ERRORS.couldNotEditCommentStale
				});
			},
			onCompleted: (response) => {
				setIsSubmitting(false);
				setHasDisabledActions(false);
				if (!response?.updateIssueComment) addToast({
					type: "error",
					message: ERRORS.couldNotEditComment
				});
				else onSave();
			},
			withOptimisticResponse
		});
	}, [
		currentBody,
		environment,
		currentBodyVersion,
		setIsEditing,
		setHasDisabledActions,
		setIsSubmitting,
		addToast,
		onSave,
		setManualValidationResult
	]);
	const onCancel = () => {
		cancelEdit();
	};
	useEffect(() => {
		if (ref && ref.current) ref.current.focus();
	}, [ref]);
	const subject = useMemo(() => {
		return {
			type: "issue_comment",
			id: {
				id: data.issue.id,
				databaseId: data.issue.databaseId
			},
			repository: {
				databaseId: repositoryDatabaseId,
				nwo: repository.nameWithOwner,
				slashCommandsEnabled: repository.slashCommandsEnabled
			}
		};
	}, [
		data.issue.databaseId,
		data.issue.id,
		repository.nameWithOwner,
		repository.slashCommandsEnabled,
		repositoryDatabaseId
	]);
	const issuesReactLazyLoad = isFeatureEnabled("issues_lazy_load_comment_box_suggestions");
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IssueCommentHeader, {
		comment: data,
		commentAuthorLogin: data.author.login,
		avatarUrl: data.author.avatarUrl,
		commentSubjectAuthorLogin: data.issue.author?.login,
		editComment: noop,
		onReplySelect: noop,
		navigate: noop,
		hideActions: true
	}), /* @__PURE__ */ jsx("div", {
		className: IssueCommentEditor_module_default.EditorMarginContainer,
		children: /* @__PURE__ */ jsx(CommentBox, {
			disabled: isSubmitting,
			subject,
			ref,
			value: initialValue || currentBody,
			placeholder: "",
			onSave: () => save(data.id),
			onCancel,
			validationResult: initialValidationResult ? initialValidationResult : computedValidationResult,
			onChange: onMarkdownChange,
			saveButtonText: BUTTON_LABELS.updateComment,
			saveButtonTrailingIcon: !isSubmitting,
			buttonSize: "medium",
			teamHovercardsEnabled: true,
			markdownSuggestionsFetchMethod: issuesReactLazyLoad ? "lazy" : "eager",
			className: IssueCommentEditor_module_default.CommentBox,
			...testIdProps(TEST_IDS.commentBox("comment-editor"))
		})
	})] });
}
IssueCommentEditor.displayName = "IssueCommentEditor";
export { IssueCommentEditor };
