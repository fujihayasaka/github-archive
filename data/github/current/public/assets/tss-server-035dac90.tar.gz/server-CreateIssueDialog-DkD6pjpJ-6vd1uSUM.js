performance.mark("js-parse-end:server-CreateIssueDialog-DkD6pjpJ-6vd1uSUM.js");
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { r as relayEnvironmentWithMissingFieldHandlerForNode, t as RelayEnvironmentProvider } from "./server-relay-environment-37zIk8_--Ci7dtWT_.js";
import { n as CreateIssueDialogEntry } from "./server-CreateIssueDialogEntry-BjvQ1-iv-ze7WYvMN.js";
import { useEffect } from "react";
import { jsx } from "react/jsx-runtime";
performance.mark("js-parse-end:CreateIssueDialog-DkD6pjpJ.js");
var defaultEnvironment = relayEnvironmentWithMissingFieldHandlerForNode();
function CreateIssueDialog({ isVisible, setIsVisible, setIsLoaded, setIsParentMenuOpen, owner, repo, environment = defaultEnvironment, returnFocusRef }) {
	const navigate = useNavigate$1();
	useEffect(() => {
		setIsLoaded(true);
	}, []);
	useEffect(() => {
		if (isVisible) setIsParentMenuOpen(false);
	}, [isVisible, setIsParentMenuOpen]);
	return /* @__PURE__ */ jsx(RelayEnvironmentProvider, {
		environment,
		children: /* @__PURE__ */ jsx(CreateIssueDialogEntry, {
			returnFocusRef,
			navigate,
			isCreateDialogOpen: isVisible,
			setIsCreateDialogOpen: setIsVisible,
			optionConfig: owner && repo ? { issueCreateArguments: { repository: {
				owner,
				name: repo
			} } } : void 0
		})
	});
}
CreateIssueDialog.displayName = "CreateIssueDialog";
export { CreateIssueDialog as default };
