import { a as ssrSafeWindow, i as ssrSafeLocation, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled, n as IS_SERVER } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as VisuallyHidden, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Cr as ScreenFullIcon, Dt as FileIcon, F as ChevronDownIcon, Fr as SingleSelectIcon, Ht as GitBranchIcon, Mi as XIcon, Nn as MilestoneIcon, O as CheckIcon, Or as ShieldIcon, Qn as PeopleIcon, Qt as Heading$2, R as ChevronUpIcon, Sn as LinkIcon, T as CalendarIcon, Un as NumberIcon, Vt as GitBranchCheckIcon, Xn as PencilAiIcon, Zn as PencilIcon, _i as Truncate, a as AlertFillIcon, an as IconButton, ar as PlusIcon, bn as Link, cn as InfoIcon, d as ArrowRightIcon, et as CopilotIcon, fn as IssueOpenedIcon, gr as RepoIcon, hi as TriangleDownIcon, i as AgentIcon, ii as TagIcon, m as ArrowUpRightIcon, n as ActionList, o as AlertIcon, pi as Tooltip$1, ri as TableIcon, sr as ProjectTemplateIcon, tt as CopyIcon, u as ArrowLeftIcon, vi as TypographyIcon, wi as UploadIcon, xn as LinkExternalIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { o as isStaff, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, o as SkeletonBox, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { a as Token, i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { a as Heading, g as Ye, h as Tooltip, m as Token$1, r as Dialog$1, t as Box, y as sx } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { n as useConfirm, t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { i as queryOptions$1, l as useQuery, n as keepPreviousData, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { Kt as userHovercardPath, Y as issuePath, jt as repositoryDefaultBranchPath, k as copilotHovercardPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { a as CopilotLicenseType, b as copilotFeatureFlags, n as COPILOT_PATH, o as CopilotPlan } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { i as VerifiedHTMLText, n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as sanitize } from "./server-sanitize.server-b2h7HJ0t-CE6bPZBY.js";
import { n as useClickAnalytics, t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as RefSelector } from "./server-RefSelector-unHqlV3G-DIJhjGu-.js";
import { t as noop$1 } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { t as CheckboxGroup_default } from "./server-CheckboxGroup-D-9z19be-BHUG_g4C.js";
import { n as NO_MATCH, r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import { a as useEmojiSuggestions } from "./server-use-mention-suggestions-CJBNKUGO-wdkkDgZ6.js";
import { t as AriaAlert } from "./server-use-reference-suggestions-Ixpw3mar-CrD64Jy4.js";
import { i as useUnifiedFileSelect } from "./server-use-unified-file-select-CEU56QFm-CLNiWm9V.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as createPersister } from "./server-react-query-persister-D24LKcxB-BQe2u09x.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { i as useSessionStorage, t as clearSessionStorage } from "./server-use-session-storage-C2f28u9L-cHRWNGhU.js";
import { E as useEntitlement, r as EntitlementProvider } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { a as GlobalCommands, i as CommandKeybindingHint, n as CommandButton, o as ScopedCommands, r as CommandIconButton, t as CommandActionListItem } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { t as InlineAutocomplete } from "./server-InlineAutocomplete-ByKImo4X-BNUEsRr4.js";
import { t as FeatureFlags } from "./server-FeatureFlags-C1NipJFp-82e1Xac8.js";
import { a as SELECTORS, l as useItemPickersContext, n as IDS, o as getAdjustedOverlayProps, r as ItemPicker, t as ERRORS$2, u as useKeyPress } from "./server-ItemPicker-ILw4RsMA-BLDIejLk.js";
import { t as ReposSelector } from "./server-ReposSelector-DzGKvaFx-Dm7ShIoG.js";
import { r as useUploadFile, t as acceptedFileTypes } from "./server-file-upload-hzKYHhKF-aHtqJYP7.js";
import { S as useLastSelectedAgent, b as isCopilotOrCustomAgent, l as IconButtonSelector, o as DISMISSAL_KEY, r as AgentSelector, s as DecoupledModeBanner, x as queryForRepos } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { t as CopilotAnimation } from "./server-CopilotAnimation-DOXbbPXC-CqTp-mSh.js";
import { n as MarkdownRenderer } from "./server-MarkdownRenderer-CWn3CeTy-lToasg6Z.js";
import { n as isHovercardHintEnabledForUser, r as useGetHovercardAttributesForType, t as HOVERCARD_KEYBOARD_SHORTCUT } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { b as isSessionState } from "./server-session-CpgPVfEW-Bkmi4-Or.js";
import { n as Table, u as getSessionStatusIcon } from "./server-StatusIcon-HHc9xqXJ-i9XmT_r2.js";
import { A as useLatestAgentModel, O as useAgentInfo, c as COPILOT_ASSIGNMENT_BRANCH_CAPTION, d as COPILOT_ASSIGNMENT_REPO_LABEL, f as COPILOT_ASSIGNMENT_SELECT_BRANCH_HEADING, h as CopilotCodingAgentQuotaBanner, i as AGENT_ASSIGNMENT_BRANCH_CAPTION, l as COPILOT_ASSIGNMENT_BRANCH_LABEL, m as COPILOT_INSTRUCTIONS_MAX_LENGTH, s as COPILOT_ASSIGNMENT_API_ENDPOINT, u as COPILOT_ASSIGNMENT_PROMPT_LABEL, v as ModelPicker } from "./server-CopilotCodingAgentQuotaBanner-W2Ye6Fax-B_w68npu.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { t as InlineMessage } from "./server-InlineMessage-BhmmT-Sd-CKllIEFZ.js";
import { t as reportError$1 } from "./server-failbot-DcTQsQvG-1jpM1RlB.js";
import { t as useEmojisQuery } from "./server-use-emojis-query-C5iJFZbs-B6tC0vOQ.js";
import { a as MarkdownEditor, f as useViewerSettings, g as validateTextField, h as validateIssueTitle, m as validateIssueBody, o as MarkdownViewer, s as VALIDATORS, t as CommentBox } from "./server-validators-DpH9Vi4K-BgoqazXb.js";
import { r as incrementIssuesTabCounter, t as ContributorFooter } from "./server-issues-tab-counter-CnxY27eB-Dsxgdp-i.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { n as clientSideRelayFetchQueryRetained } from "./server-relay-environment-37zIk8_--Ci7dtWT_.js";
import { a as VALUES, c as readRepositoryFromFragment, i as RepositoryPicker, n as LABELS$3, r as RepositoryAndIssuePicker, s as fetchTopRepositories, u as useItemPickerErrorFallback } from "./server-RepositoryAndIssuePicker-pJUBAgRS-Bhe6Vlwu.js";
import { t as useFeatureFlag } from "./server-use-feature-flag-CDC46uBu-B9UHPW6C.js";
import { a as colorNames, c as require_hooks, d as storageTitleAndBodyKeys, f as useIssueState, i as VALUES$1, l as storageKeys, m as useShouldShowCopilotFunctionalityInIssues, n as IssueStateReason, o as discardStorageKeys, p as useNamedColor, r as TEMP_SUB_ISSUE_ID_PREFIX, t as IssueState, u as storageMetadataKeys } from "./server-use-issue-pr-state-Ca7HKQL5-BTNcVLo6.js";
import { t as ProfileReference } from "./server-ProfileReference-BiGysK1d-VyvZmlrw.js";
import { n as TEST_IDS$2, r as useCopilotGeneratePanel, t as CopilotGenerateDescriptionPanel } from "./server-test-ids-BnesLCJj-D-AL_t-I.js";
import { c as getFieldTypeOcticon, d as toIssueFieldType, f as useUser, i as ISSUE_FIELD_TEXT_VALUE_TYPE, l as getIssueFieldValue, n as ISSUE_FIELD_NUMBER_VALUE_TYPE, o as asIssueFieldSelection, r as ISSUE_FIELD_SINGLE_SELECT_VALUE_TYPE, s as clearFieldValue, t as ISSUE_FIELD_DATE_VALUE_TYPE, u as parsePinnedIssueFields } from "./server-use-user-CNSliVdg-D1BtlcwW.js";
import { t as fuzzyFilter } from "./server-fuzzy-filter-WZcmODdB-CGCfWix3.js";
import { t as DatePicker } from "./server-DatePicker-BGOTKwic-Dh0P8bLZ.js";
import { t as useIssueAgentTasks } from "./server-use-issue-agent-tasks-CHK8cdRW-CwhhCocr.js";
import { t as LabelToken } from "./server-LabelToken-D9qiz0SP-C1EDhfRF.js";
import React, { Fragment, Suspense, createContext, createRef, use, useCallback, useDeferredValue, useEffect, useEffectEvent, useId, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { parseISO } from "date-fns";
function isCopilot(login) {
	const lowercaseLogin = login.toLocaleLowerCase();
	return lowercaseLogin === "copilot-swe-agent" || lowercaseLogin === "copilot";
}
var node$76 = (function() {
	var v0 = {
		"defaultValue": false,
		"kind": "LocalArgument",
		"name": "includeTemplates"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "name"
	}, v2 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "owner"
	}, v3 = [{
		"kind": "Variable",
		"name": "name",
		"variableName": "name"
	}, {
		"kind": "Variable",
		"name": "owner",
		"variableName": "owner"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isBlankIssuesEnabled",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "issueTypesEnabled",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isLocked",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "visibility",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "slashCommandsEnabled",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanPush",
		"storageKey": null
	}, v21 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "action",
			"value": "create an issue"
		}],
		"kind": "ScalarField",
		"name": "viewerInteractionLimitReasonHTML",
		"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
	}, v22 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueCreationPermissions",
		"kind": "LinkedField",
		"name": "viewerIssueCreationPermissions",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "labelable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "milestoneable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "assignable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "triageable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "typeable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "canSetIssueFields",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v23 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	}, v24 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v25 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "filename",
		"storageKey": null
	}, v26 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "about",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [
				v0,
				v1,
				v2
			],
			"kind": "Fragment",
			"metadata": null,
			"name": "CreateIssueDialogEntryQuery",
			"selections": [{
				"alias": null,
				"args": v3,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v4,
					v5,
					v6,
					{
						"kind": "InlineDataFragmentSpread",
						"name": "RepositoryPickerRepository",
						"selections": [
							v7,
							v8,
							v9,
							v10,
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "owner",
								"plural": false,
								"selections": [
									v8,
									v11,
									v12,
									v13
								],
								"storageKey": null
							},
							v14,
							v15,
							v16,
							v17,
							v18,
							v6,
							v4,
							v19,
							v20,
							v5,
							v21,
							v22,
							v23
						],
						"args": null,
						"argumentDefinitions": []
					},
					{
						"args": [{
							"kind": "Variable",
							"name": "includeTemplates",
							"variableName": "includeTemplates"
						}],
						"kind": "FragmentSpread",
						"name": "CreateIssueDialog"
					}
				],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [
				v2,
				v1,
				v0
			],
			"kind": "Operation",
			"name": "CreateIssueDialogEntryQuery",
			"selections": [{
				"alias": null,
				"args": v3,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v4,
					v5,
					v6,
					v7,
					v8,
					v9,
					v10,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [
							v24,
							v8,
							v11,
							v12,
							v13,
							v7
						],
						"storageKey": null
					},
					v14,
					v15,
					v16,
					v17,
					v18,
					v19,
					v20,
					v21,
					v22,
					v23,
					{
						"condition": "includeTemplates",
						"kind": "Condition",
						"passingValue": true,
						"selections": [
							{
								"alias": null,
								"args": null,
								"concreteType": "IssueForm",
								"kind": "LinkedField",
								"name": "issueForms",
								"plural": true,
								"selections": [
									v24,
									v25,
									v9,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "description",
										"storageKey": null
									}
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "IssueTemplate",
								"kind": "LinkedField",
								"name": "issueTemplates",
								"plural": true,
								"selections": [
									v24,
									v25,
									v9,
									v26
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isBlankIssuesMaintainerOverride",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isSecurityPolicyEnabled",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "securityPolicyUrl",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "RepositoryContactLink",
								"kind": "LinkedField",
								"name": "contactLinks",
								"plural": true,
								"selections": [
									v9,
									v26,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "url",
										"storageKey": null
									}
								],
								"storageKey": null
							}
						]
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "29d55202ca7dc5eee15013e77d9dc025",
			"metadata": {},
			"name": "CreateIssueDialogEntryQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$76.hash = "3637b8207b4416b73b8db4727054b1cd";
var IssueCreateContext = createContext(null);
IssueCreateContext.displayName = "IssueCreateContext";
function IssueCreateConfigContextProvider({ optionConfig, overrideFallbackDisplaymode, children }) {
	const { issueCreateMore } = VALUES$1.localStorageKeys;
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [isFileUploading, setIsFileUploading] = useState(false);
	const [createMore, setCreateMore] = useSessionStorage(`config.${issueCreateMore(optionConfig.storageKeyPrefix)}`, false);
	const [createMoreCreatedPath, setCreateMoreCreatedPath] = useState({
		owner: "",
		repo: "",
		number: void 0
	});
	const initialDefaultDisplayMode = optionConfig.getDefaultDisplayMode(overrideFallbackDisplaymode);
	const [displayMode, setDisplayMode] = useState(initialDefaultDisplayMode);
	const onCreateAction = useRef(null);
	return /* @__PURE__ */ jsx(IssueCreateContext, {
		value: useMemo(() => {
			return {
				optionConfig,
				createMore,
				setCreateMore,
				createMoreCreatedPath,
				setCreateMoreCreatedPath,
				displayMode,
				setDisplayMode,
				initialDefaultDisplayMode,
				isSubmitting,
				isFileUploading,
				setIsFileUploading,
				setIsSubmitting,
				onCreateAction,
				isSubIssue: !!optionConfig.issueCreateArguments?.parentIssue?.id,
				isCreatingSubIssueFromProject: optionConfig.issueCreateArguments?.isCreatingSubIssueFromProject ?? false
			};
		}, [
			optionConfig,
			createMore,
			setCreateMore,
			createMoreCreatedPath,
			setCreateMoreCreatedPath,
			displayMode,
			initialDefaultDisplayMode,
			isSubmitting,
			isFileUploading
		]),
		children
	});
}
IssueCreateConfigContextProvider.displayName = "IssueCreateConfigContextProvider";
var useIssueCreateConfigContext = () => {
	const context = use(IssueCreateContext);
	if (!context) throw new Error("useIssueCreateConfigContext must be used within a IssueCreateConfigContextProvider.");
	return context;
};
/**
* Pure function that determines what metadata should be preserved/cleared
* when resetting metadata for issue creation.
*/
function getMetadataResetActions(isSubIssue, preselectedProjects, preselectedMilestone, options) {
	if (!isSubIssue) return {
		projectsToSet: [],
		milestoneToSet: null
	};
	const isSameOrganization = options?.repository?.owner.login === options?.selectedRepository?.owner.login;
	const isSameRepository = isSameOrganization && options?.repository?.name === options?.selectedRepository?.name;
	return {
		projectsToSet: isSameOrganization && preselectedProjects.length > 0 ? preselectedProjects : [],
		milestoneToSet: isSameRepository && !!preselectedMilestone ? preselectedMilestone : null
	};
}
var BLANK_ISSUE = "Blank issue";
var BLANK_ISSUE_ID = "BLANK_ISSUE";
function instanceOfIssueFormData(data) {
	return data.__typename === "IssueForm";
}
function instanceOfIssueTemplateData(data) {
	return data.__typename === "IssueTemplate";
}
function instanceOfBlankIssueData(data) {
	return data.__typename === "BlankIssue";
}
var IssueCreationKind = {
	IssueForm: "IssueForm",
	IssueTemplate: "IssueTemplate",
	ContactLink: "ContactLink",
	BlankIssue: "BlankIssue"
};
var blankIssue = {
	name: BLANK_ISSUE,
	fileName: BLANK_ISSUE_ID,
	kind: IssueCreationKind.BlankIssue,
	data: {
		__typename: "BlankIssue",
		__id: BLANK_ISSUE_ID,
		title: "",
		body: "",
		assignees: { edges: [] },
		labels: { edges: [] }
	}
};
function getBlankIssue() {
	return blankIssue;
}
/**
* Extracts projects from an issue template.
*/
function getProjectsFromTemplate(template) {
	let initialProjects = [];
	if (template?.data && instanceOfIssueFormData(template?.data)) initialProjects = template.data.projects?.edges?.flatMap((e) => e?.node ? [e.node] : []) || [];
	return initialProjects;
}
/**
* Utility function for determining initial projects for issue creation based on template and parent inheritance.
* This follows the same pattern as other metadata (labels, assignees, etc.) in the codebase.
*
* Priority logic:
* 1. Explicit non-parent projects (URL params, Memex, etc.) - highest precedence
* 2. Template projects - override parent inheritance
* 3. Parent projects (inheritance) - used when no template projects
* 4. Empty array (final fallback)
*/
function getInitialProjects(options) {
	const { template, projects = [], isParentInheritance = false } = options;
	if (!isParentInheritance && projects.length > 0) return projects;
	const templateProjects = template ? getProjectsFromTemplate(template) : [];
	if (templateProjects.length > 0) return templateProjects;
	return projects;
}
var IssueCreateDataContext = createContext(null);
IssueCreateDataContext.displayName = "IssueCreateDataContext";
function getLabelsFromTemplate(template) {
	let initialLabels = [];
	if (template?.data) initialLabels = template?.data.labels?.edges?.flatMap((e) => e?.node ? [e?.node] : []) || [];
	return initialLabels;
}
function getAssigneesFromTemplate(template) {
	let initialAssignees = [];
	if (template?.data) initialAssignees = template?.data.assignees?.edges?.flatMap((e) => e?.node ? [e?.node] : []) || [];
	return initialAssignees;
}
function getTitleFromTemplate(template) {
	let initialTitle = "";
	if (template?.data) initialTitle = template?.data.title || "";
	return initialTitle;
}
function getBodyFromTemplate(template) {
	let initialBody = "";
	if (template?.data && instanceOfIssueTemplateData(template?.data)) initialBody = template?.data.body || "";
	return initialBody;
}
function getIssueTypeFromTemplate(template) {
	let initialIssueType = null;
	if (template?.data && (instanceOfIssueFormData(template?.data) || instanceOfIssueTemplateData(template?.data))) initialIssueType = template?.data.type || null;
	return initialIssueType;
}
function IssueCreateDataContextProvider({ optionConfig, preselectedData, children }) {
	const { storageKeyPrefix, issueCreateArguments } = optionConfig;
	const { issueTitle, issueBody } = VALUES$1.localTitleAndBodyStorageKeys;
	const { issueLabels, issueAssignees, issueProjects, issueMilestone, issueIssueType, issueIssueFields } = VALUES$1.localStorageMetadataKeys;
	const [repository, setRepository] = useState(preselectedData?.repository);
	const [template, setTemplateInternal] = useState(preselectedData?.template);
	const [usedStorageKeyPrefix, setUsedStorageKeyPrefix] = useState(`${storageKeyPrefix}.${template?.fileName || "BLANK_ISSUE"}`);
	let initialTitle = "";
	if (issueCreateArguments?.initialValues?.discussion) initialTitle = issueCreateArguments?.initialValues?.discussion.title;
	else if (issueCreateArguments?.initialValues?.title) initialTitle = issueCreateArguments?.initialValues?.title;
	else if (template) {
		const templateTitle = getTitleFromTemplate(template);
		let userInputTitle = "";
		if (issueCreateArguments?.initialValues?.appendTitleToTemplate) userInputTitle = ` ${issueCreateArguments?.initialValues?.appendTitleToTemplate}`;
		initialTitle = [templateTitle, userInputTitle].join("").trimStart();
	} else if (issueCreateArguments?.initialValues?.appendTitleToTemplate) initialTitle = issueCreateArguments?.initialValues?.appendTitleToTemplate;
	const [title, setTitle, reinitTitle] = useSessionStorage(issueTitle(usedStorageKeyPrefix), initialTitle);
	let initialBody = "";
	if (issueCreateArguments?.initialValues?.discussion) initialBody = issueCreateArguments?.initialValues?.discussion.formattedBody;
	else if (issueCreateArguments?.initialValues?.body) initialBody = issueCreateArguments?.initialValues?.body;
	else if (template) initialBody = getBodyFromTemplate(template);
	const [body, setBody, reinitBody] = useSessionStorage(issueBody(usedStorageKeyPrefix), initialBody);
	let initialLabels = [];
	if (issueCreateArguments?.initialValues?.discussion) initialLabels = issueCreateArguments?.initialValues?.discussion?.labels || [];
	else if (issueCreateArguments?.initialValues?.labels) initialLabels = issueCreateArguments?.initialValues?.labels;
	else if (template) initialLabels = getLabelsFromTemplate(template);
	const [labels, setLabels, reinitLabels] = useSessionStorage(issueLabels(usedStorageKeyPrefix), initialLabels);
	let initialAssignees = [];
	if (issueCreateArguments?.initialValues?.assignees) initialAssignees = issueCreateArguments?.initialValues?.assignees;
	else if (template) initialAssignees = getAssigneesFromTemplate(template);
	const [assignees, _setAssignees, reinitAssignees] = useSessionStorage(issueAssignees(usedStorageKeyPrefix), initialAssignees);
	const preselectedProjects = useMemo(() => issueCreateArguments?.initialValues?.projects ?? [], [issueCreateArguments?.initialValues?.projects]);
	const initialProjects = getInitialProjects({
		template,
		projects: issueCreateArguments?.initialValues?.projects ?? [],
		isParentInheritance: !!issueCreateArguments?.parentIssue
	});
	const [projects, setProjects, reinitProjects] = useSessionStorage(issueProjects(usedStorageKeyPrefix), initialProjects);
	const preselectedMilestone = useMemo(() => issueCreateArguments?.initialValues?.milestone ?? null, [issueCreateArguments?.initialValues?.milestone]);
	const initialMilestone = useMemo(() => {
		if (!preselectedMilestone || !preselectedData?.parentIssue) return preselectedMilestone;
		return getMetadataResetActions(true, [], preselectedMilestone, {
			repository: preselectedData?.repository,
			selectedRepository: repository
		}).milestoneToSet;
	}, [
		preselectedMilestone,
		preselectedData?.parentIssue,
		preselectedData?.repository,
		repository
	]);
	const [milestone, setMilestone, reinitMilestone] = useSessionStorage(issueMilestone(usedStorageKeyPrefix), initialMilestone);
	let initialIssueType = null;
	if (issueCreateArguments?.initialValues?.type) initialIssueType = issueCreateArguments?.initialValues?.type;
	else if (template) initialIssueType = getIssueTypeFromTemplate(template);
	const [issueType, setIssueType, reinitIssueType] = useSessionStorage(issueIssueType(usedStorageKeyPrefix), initialIssueType);
	const initialIssueFields = issueCreateArguments?.initialValues?.issueFields ?? [];
	const [issueFields, setIssueFields] = useSessionStorage(issueIssueFields(usedStorageKeyPrefix), initialIssueFields);
	const [isCopilotAssignmentDialogOpen, setIsCopilotAssignmentDialogOpen] = useState(false);
	const [copilotAssignmentAttributes, setCopilotAssignmentAttributes] = useState(null);
	const [issueFormBody, setIssueFormBody] = useState("");
	const [originalTitle, setOriginalTitle] = useState(title);
	const [originalBody, setOriginalBody] = useState(body);
	const previousAssigneesRef = useRef(assignees);
	useEffect(() => {
		previousAssigneesRef.current = assignees;
	}, [assignees]);
	const setNewTitle = useCallback((newTitle) => {
		setTitle(newTitle);
		setOriginalTitle(newTitle);
	}, [setTitle, setOriginalTitle]);
	const setNewBody = useCallback((newBody) => {
		setBody(newBody);
		setOriginalBody(newBody);
	}, [setBody, setOriginalBody]);
	const setAssignees = useCallback((newAssignees) => {
		const previousHadCopilot = previousAssigneesRef.current.some((assignee) => isCopilot(assignee.login));
		const newHasCopilot = newAssignees.some((assignee_0) => isCopilot(assignee_0.login));
		_setAssignees(newAssignees);
		if (!optionConfig.disableCopilotAssignmentModal && !previousHadCopilot && newHasCopilot) setIsCopilotAssignmentDialogOpen(true);
	}, [_setAssignees, optionConfig.disableCopilotAssignmentModal]);
	const resetMetadata = useCallback((options) => {
		setAssignees([]);
		setLabels([]);
		setIssueFields([]);
		const actions_0 = getMetadataResetActions(!!preselectedData?.parentIssue, preselectedProjects, preselectedMilestone, options);
		setProjects(actions_0.projectsToSet);
		setMilestone(actions_0.milestoneToSet);
	}, [
		setAssignees,
		setLabels,
		setIssueFields,
		preselectedData?.parentIssue,
		preselectedMilestone,
		preselectedProjects,
		setProjects,
		setMilestone
	]);
	const clearSessionData = useCallback(() => {
		clearSessionStorage(storageKeys(usedStorageKeyPrefix));
	}, [usedStorageKeyPrefix]);
	const clearSessionMetadata = useCallback(() => {
		clearSessionStorage(storageMetadataKeys(usedStorageKeyPrefix));
	}, [usedStorageKeyPrefix]);
	const clearSessionTitleAndBody = useCallback(() => {
		clearSessionStorage(storageTitleAndBodyKeys(usedStorageKeyPrefix));
	}, [usedStorageKeyPrefix]);
	const clearSessionCreateMore = useCallback(() => {
		clearSessionStorage([`config.${VALUES$1.localStorageKeys.issueCreateMore(storageKeyPrefix)}`]);
	}, [storageKeyPrefix]);
	const clearTitleAndBody = useCallback(() => {
		setTitle("");
		setBody("");
		setOriginalTitle("");
		setOriginalBody("");
	}, [
		setTitle,
		setBody,
		setOriginalTitle,
		setOriginalBody
	]);
	const origin = ssrSafeLocation?.origin ?? "";
	const repoNwo = repository?.nameWithOwner ?? "";
	const repositoryAbsolutePath = useMemo(() => `${origin}/${repoNwo}`, [origin, repoNwo]);
	const initialParentIssue = preselectedData?.parentIssue;
	const [parentIssue, setParentIssue] = useState(initialParentIssue && "title" in initialParentIssue ? initialParentIssue : null);
	const parentIssueId = (parentIssue ?? preselectedData?.parentIssue ?? null)?.id ?? null;
	const [blockedByIssues, setBlockedByIssues] = useState([]);
	const blockedByIssueIds = useMemo(() => blockedByIssues.map((issue) => issue.id), [blockedByIssues]);
	const [blockingIssues, setBlockingIssues] = useState([]);
	const blockingIssueIds = useMemo(() => blockingIssues.map((issue_0) => issue_0.id), [blockingIssues]);
	const setTemplate = useCallback((newTemplate) => {
		setTemplateInternal(newTemplate);
		setUsedStorageKeyPrefix(`${storageKeyPrefix}.${newTemplate?.fileName || "BLANK_ISSUE"}`);
	}, [storageKeyPrefix]);
	return /* @__PURE__ */ jsx(IssueCreateDataContext, {
		value: useMemo(() => {
			return {
				reinitTitle,
				reinitBody,
				reinitAssignees,
				reinitLabels,
				reinitProjects,
				reinitMilestone,
				reinitIssueType,
				usedStorageKeyPrefix,
				clearSessionData,
				clearSessionMetadata,
				clearSessionTitleAndBody,
				clearSessionCreateMore,
				resetMetadata,
				clearTitleAndBody,
				setNewTitle,
				setNewBody,
				originalTitle,
				setOriginalTitle,
				originalBody,
				setOriginalBody,
				title,
				setTitle,
				body,
				setBody,
				repository,
				setRepository,
				repositoryAbsolutePath,
				template,
				setTemplate,
				preselectedRepository: preselectedData?.repository,
				preselectedTemplate: preselectedData?.template,
				labels,
				setLabels,
				assignees,
				setAssignees,
				replaceAssignees: _setAssignees,
				projects,
				setProjects,
				milestone,
				setMilestone,
				issueType,
				setIssueType,
				issueFields,
				setIssueFields,
				parentIssue,
				setParentIssue,
				parentIssueId,
				blockedByIssues,
				setBlockedByIssues,
				blockedByIssueIds,
				blockingIssues,
				setBlockingIssues,
				blockingIssueIds,
				isCopilotAssignmentDialogOpen,
				setIsCopilotAssignmentDialogOpen,
				copilotAssignmentAttributes,
				setCopilotAssignmentAttributes,
				issueFormBody,
				setIssueFormBody
			};
		}, [
			reinitTitle,
			reinitBody,
			reinitAssignees,
			reinitLabels,
			reinitProjects,
			reinitMilestone,
			reinitIssueType,
			usedStorageKeyPrefix,
			clearSessionData,
			clearSessionMetadata,
			clearSessionTitleAndBody,
			clearSessionCreateMore,
			resetMetadata,
			clearTitleAndBody,
			setNewTitle,
			setNewBody,
			originalTitle,
			originalBody,
			title,
			setTitle,
			body,
			setBody,
			repository,
			repositoryAbsolutePath,
			template,
			setTemplate,
			preselectedData?.repository,
			preselectedData?.template,
			labels,
			setLabels,
			assignees,
			setAssignees,
			_setAssignees,
			projects,
			setProjects,
			milestone,
			setMilestone,
			issueType,
			setIssueType,
			issueFields,
			setIssueFields,
			parentIssue,
			parentIssueId,
			blockedByIssues,
			blockedByIssueIds,
			blockingIssues,
			blockingIssueIds,
			isCopilotAssignmentDialogOpen,
			copilotAssignmentAttributes,
			issueFormBody
		]),
		children
	});
}
IssueCreateDataContextProvider.displayName = "IssueCreateDataContextProvider";
var useIssueCreateDataContext = () => {
	const context = use(IssueCreateDataContext);
	if (!context) throw new Error("useIssueCreateDataContext must be used within a IssueCreateDataContextProvider.");
	return context;
};
function IssueCreateContextProvider({ children, ...props }) {
	return /* @__PURE__ */ jsx(IssueCreateConfigContextProvider, {
		...props,
		children: /* @__PURE__ */ jsx(IssueCreateDataContextProvider, {
			...props,
			children
		})
	});
}
IssueCreateContextProvider.displayName = "IssueCreateContextProvider";
var DisplayMode = {
	TemplatePicker: "TemplatePicker",
	IssueCreation: "IssueCreation",
	IssueDuplication: "IssueDuplication"
};
function deriveIssueCreateContext(optionConfig) {
	if (optionConfig.isCopilotImmersive) return "copilot_immersive";
	if (optionConfig.insidePortal) return "modal";
	return "full_page";
}
var OPTION_DEFAULT_CONFIG = {
	showFullScreenButton: false,
	navigateToFullScreenOnTemplateChoice: false,
	insidePortal: true,
	showRepositoryPicker: true,
	storageKeyPrefix: "",
	canBypassTemplateSelection: false,
	emojiSkinTonePreference: 0,
	copilotShowFunctionality: false,
	disableCopilotAssignmentModal: false,
	isCopilotImmersive: false,
	hideCreateMore: false
};
var getSafeConfig = (config) => {
	const filledConfig = {
		...OPTION_DEFAULT_CONFIG,
		...config
	};
	const overrides = { storageKeyPrefix: (filledConfig.issueCreateArguments?.repository ? `${filledConfig.issueCreateArguments?.repository.owner}-${filledConfig.issueCreateArguments?.repository.name}` : void 0) ?? filledConfig.storageKeyPrefix ?? VALUES$1.storageKeyPrefixes.defaultFallback };
	const configProperties = { getDefaultDisplayMode: (fallback) => filledConfig.defaultDisplayMode ?? fallback ?? DisplayMode.TemplatePicker };
	return {
		...filledConfig,
		...overrides,
		...configProperties
	};
};
var URLS$1 = {
	queryParams: {
		org: "org",
		repo: "repo",
		template: "template",
		title: "title",
		body: "body",
		assignees: "assignees",
		labels: "labels",
		milestone: "milestone",
		projects: "projects",
		type: "type",
		discussion: "discussion",
		permalink: "permalink"
	},
	maxQueryLengthLimits: {
		title: 256,
		body: 65536,
		assignees: 10,
		labels: 20,
		projects: 20
	}
};
var reservedQueryKeys = [...Object.values(URLS$1.queryParams), "_ui_sha"];
var REPO_NEW_ISSUES_SUFFIX = `/issues/new`;
var REPO_CHOOSE_ISSUES_SUFFIX = `${REPO_NEW_ISSUES_SUFFIX}/choose`;
var getTemplateUrl = (nameWithOwner, filename) => {
	const searchParams = new URLSearchParams(ssrSafeLocation.search || "");
	searchParams.set("template", filename);
	return `/${nameWithOwner}/issues/new?${searchParams.toString()}`;
};
var appendNewToBasePath = (path) => safeUrlAppend(path, REPO_NEW_ISSUES_SUFFIX);
var appendChooseToBasePath = (path) => safeUrlAppend(path, REPO_CHOOSE_ISSUES_SUFFIX);
var safeUrlAppend = (path, append) => {
	if (path.endsWith("/")) return path.substring(0, path.length - 1) + append;
	return path + append;
};
var newTemplateAbsolutePath = ({ repositoryAbsolutePath, fileName }) => {
	const newPath = appendNewToBasePath(repositoryAbsolutePath);
	const url = new URL(newPath, ssrSafeWindow?.location?.origin);
	const searchParams = new URLSearchParams(url.search);
	searchParams.set(URLS$1.queryParams.template, fileName);
	url.search = searchParams.toString();
	return url.toString();
};
var getPotentialFormDefaultValuesFromUrl = (urlParams) => {
	const searchParams = urlParams ?? new URLSearchParams(ssrSafeWindow?.location?.search || "");
	const defaultValuesById = {};
	for (const [key, value] of searchParams) if (reservedQueryKeys.includes(key)) continue;
	else if (value === null) defaultValuesById[key] = "";
	else defaultValuesById[key] = value.substring(0, URLS$1.maxQueryLengthLimits.body);
	return defaultValuesById;
};
var safeStringParamSet = (searchParams, key, value, maxLimit) => {
	if (value === void 0) return;
	searchParams.set(key, value.substring(0, maxLimit));
};
var safeStringArrayParamSet = (searchParams, key, values, maxLengthLimit) => {
	if (!values) return;
	searchParams.set(key, values.slice(0, maxLengthLimit).join(","));
};
function loginPath() {
	return `/login?return_to=${ssrSafeLocation?.href}`;
}
function constructIssueCreateParams({ includeRepository, repository, templateFileName, title, body, assignees, labels, projects, milestone, type }) {
	const searchParams = new URLSearchParams(ssrSafeWindow?.location?.search || "");
	if (includeRepository && repository) {
		searchParams.set(URLS$1.queryParams.org, repository.owner.login);
		searchParams.set(URLS$1.queryParams.repo, repository.name);
	}
	if (templateFileName) searchParams.set(URLS$1.queryParams.template, templateFileName);
	safeStringParamSet(searchParams, URLS$1.queryParams.title, title, URLS$1.maxQueryLengthLimits.title);
	safeStringParamSet(searchParams, URLS$1.queryParams.body, body, URLS$1.maxQueryLengthLimits.body);
	if (assignees) safeStringArrayParamSet(searchParams, URLS$1.queryParams.assignees, assignees ? assignees.map((a) => a.login) : void 0, URLS$1.maxQueryLengthLimits.assignees);
	if (labels) safeStringArrayParamSet(searchParams, URLS$1.queryParams.labels, labels.map((l) => l.name), URLS$1.maxQueryLengthLimits.assignees);
	if (projects && repository?.owner) safeStringArrayParamSet(searchParams, URLS$1.queryParams.projects, projects.map((p) => `${repository.owner.login}/${p.number}`), URLS$1.maxQueryLengthLimits.assignees);
	if (milestone) searchParams.set(URLS$1.queryParams.milestone, milestone.title);
	if (type) searchParams.set(URLS$1.queryParams.type, type.name);
	return searchParams.toString();
}
var node$75 = {
	"argumentDefinitions": [{
		"defaultValue": false,
		"kind": "LocalArgument",
		"name": "includeTemplates"
	}],
	"kind": "Fragment",
	"metadata": null,
	"name": "CreateIssueDialog",
	"selections": [{
		"args": [{
			"kind": "Variable",
			"name": "includeTemplates",
			"variableName": "includeTemplates"
		}],
		"kind": "FragmentSpread",
		"name": "CreateIssue"
	}],
	"type": "Repository",
	"abstractKey": null
};
node$75.hash = "2462dd98bf9bee7cbb97c2e845715e7c";
var { Container: PrimerDataTableContainer, ...rest } = Table;
var StyleDataTableContainer = Ye(PrimerDataTableContainer).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "DataTable__StyleDataTableContainer",
	componentId: "sc-qy1ey2-0"
})(["", ""], sx);
function DataTableContainer({ as, ...rest }) {
	return /* @__PURE__ */ jsx(StyleDataTableContainer, {
		...rest,
		...as ? { forwardedAs: as } : {}
	});
}
Object.assign(Table, {
	Container: DataTableContainer,
	...rest
});
var node$74 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "filename"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "repoId"
	}, v2 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "repoId"
	}], v3 = [{
		"kind": "Variable",
		"name": "filename",
		"variableName": "filename"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "filename",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "body",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v9 = {
		"kind": "Literal",
		"name": "first",
		"value": 20
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "color",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "description",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": [v9, {
			"kind": "Literal",
			"name": "orderBy",
			"value": {
				"direction": "ASC",
				"field": "NAME"
			}
		}],
		"concreteType": "LabelConnection",
		"kind": "LinkedField",
		"name": "labels",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "LabelEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "Label",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v10,
					v11,
					v5,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameHTML",
						"storageKey": null
					},
					v12,
					v13
				],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "labels(first:20,orderBy:{\"direction\":\"ASC\",\"field\":\"NAME\"})"
	}, v15 = [{
		"kind": "Literal",
		"name": "first",
		"value": 10
	}], v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "profileResourcePath",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v19 = {
		"alias": null,
		"args": v15,
		"concreteType": "UserConnection",
		"kind": "LinkedField",
		"name": "assignees",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "UserEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [
						v4,
						v10,
						v16,
						v5,
						v17,
						v18
					],
					"type": "Actor",
					"abstractKey": "__isActor"
				}],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "assignees(first:10)"
	}, v20 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isEnabled",
		"storageKey": null
	}, v21 = [
		v10,
		v5,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	], v22 = {
		"kind": "InlineFragment",
		"selections": v21,
		"type": "IssueFieldText",
		"abstractKey": null
	}, v23 = {
		"kind": "InlineFragment",
		"selections": v21,
		"type": "IssueFieldSingleSelect",
		"abstractKey": null
	}, v24 = {
		"kind": "InlineFragment",
		"selections": v21,
		"type": "IssueFieldDate",
		"abstractKey": null
	}, v25 = {
		"kind": "InlineFragment",
		"selections": v21,
		"type": "IssueFieldNumber",
		"abstractKey": null
	}, v26 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueType",
		"kind": "LinkedField",
		"name": "type",
		"plural": false,
		"selections": [
			v10,
			v5,
			v20,
			v12,
			v11,
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "pinnedFields",
				"plural": true,
				"selections": [
					v4,
					v22,
					v23,
					v24,
					v25
				],
				"storageKey": null
			}
		],
		"storageKey": null
	}, v27 = {
		"kind": "ClientExtension",
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "__id",
			"storageKey": null
		}]
	}, v28 = {
		"alias": null,
		"args": [v9],
		"concreteType": "ProjectV2Connection",
		"kind": "LinkedField",
		"name": "projects",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "ProjectV2Edge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v10,
					v8,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "closed",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "number",
						"storageKey": null
					},
					v13,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerCanUpdate",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "hasReachedItemsLimit",
						"storageKey": null
					},
					v4
				],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "projects(first:20)"
	}, v29 = {
		"alias": null,
		"args": v15,
		"concreteType": "UserConnection",
		"kind": "LinkedField",
		"name": "assignees",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "UserEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [v10, {
					"kind": "InlineFragment",
					"selections": [
						v4,
						v16,
						v5,
						v17,
						v18
					],
					"type": "Actor",
					"abstractKey": "__isActor"
				}],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "assignees(first:10)"
	}, v30 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueType",
		"kind": "LinkedField",
		"name": "type",
		"plural": false,
		"selections": [
			v10,
			v5,
			v20,
			v12,
			v11,
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "pinnedFields",
				"plural": true,
				"selections": [
					v4,
					v22,
					v23,
					v24,
					v25,
					{
						"kind": "InlineFragment",
						"selections": [v10],
						"type": "Node",
						"abstractKey": "__isNode"
					}
				],
				"storageKey": null
			}
		],
		"storageKey": null
	}, v31 = {
		"alias": "itemId",
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v32 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "label",
		"storageKey": null
	}, v33 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "descriptionHTML",
		"storageKey": null
	}, v34 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "placeholder",
		"storageKey": null
	}, v35 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "value",
		"storageKey": null
	}, v36 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "required",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "CreateIssueQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"kind": "InlineDataFragmentSpread",
						"name": "useHandleTemplateChange",
						"selections": [{
							"alias": null,
							"args": v3,
							"concreteType": "IssueTemplate",
							"kind": "LinkedField",
							"name": "issueTemplate",
							"plural": false,
							"selections": [{
								"kind": "InlineDataFragmentSpread",
								"name": "useHandleTemplateChangeIssueTemplate",
								"selections": [
									v4,
									v5,
									v6,
									v7,
									v8,
									v14,
									v19,
									v26,
									v27
								],
								"args": null,
								"argumentDefinitions": []
							}],
							"storageKey": null
						}, {
							"alias": null,
							"args": v3,
							"concreteType": "IssueForm",
							"kind": "LinkedField",
							"name": "issueForm",
							"plural": false,
							"selections": [{
								"kind": "InlineDataFragmentSpread",
								"name": "useHandleTemplateChangeIssueForm",
								"selections": [
									v4,
									v5,
									v6,
									v8,
									{
										"kind": "InlineDataFragmentSpread",
										"name": "IssueFormElements_templateElements",
										"selections": [{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "elements",
											"plural": true,
											"selections": [
												v4,
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "TextInputElement_input"
													}],
													"type": "IssueFormElementInput",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "TextAreaElement_input"
													}],
													"type": "IssueFormElementTextarea",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "MarkdownElement_input"
													}],
													"type": "IssueFormElementMarkdown",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "DropdownElement_input"
													}],
													"type": "IssueFormElementDropdown",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "CheckboxesElement_input"
													}],
													"type": "IssueFormElementCheckboxes",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [{
														"args": null,
														"kind": "FragmentSpread",
														"name": "UploadElement_input"
													}],
													"type": "IssueFormElementUpload",
													"abstractKey": null
												}
											],
											"storageKey": null
										}],
										"args": null,
										"argumentDefinitions": []
									},
									v14,
									v19,
									v28,
									v26,
									v27
								],
								"args": null,
								"argumentDefinitions": []
							}],
							"storageKey": null
						}],
						"args": v3,
						"argumentDefinitions": [{
							"defaultValue": "",
							"kind": "LocalArgument",
							"name": "filename"
						}]
					}],
					"type": "Repository",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "CreateIssueQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v4,
					v10,
					{
						"kind": "InlineFragment",
						"selections": [{
							"alias": null,
							"args": v3,
							"concreteType": "IssueTemplate",
							"kind": "LinkedField",
							"name": "issueTemplate",
							"plural": false,
							"selections": [
								v4,
								v5,
								v6,
								v7,
								v8,
								v14,
								v29,
								v30,
								v27
							],
							"storageKey": null
						}, {
							"alias": null,
							"args": v3,
							"concreteType": "IssueForm",
							"kind": "LinkedField",
							"name": "issueForm",
							"plural": false,
							"selections": [
								v4,
								v5,
								v6,
								v8,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "elements",
									"plural": true,
									"selections": [
										v4,
										{
											"kind": "InlineFragment",
											"selections": [
												v31,
												v32,
												v33,
												v34,
												v35,
												v36,
												v27
											],
											"type": "IssueFormElementInput",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v31,
												v32,
												v33,
												v34,
												v35,
												v36,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "render",
													"storageKey": null
												},
												v27
											],
											"type": "IssueFormElementTextarea",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "contentHTML",
												"storageKey": null
											}],
											"type": "IssueFormElementMarkdown",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v31,
												v32,
												v33,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "options",
													"storageKey": null
												},
												v36,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "multiple",
													"storageKey": null
												},
												{
													"alias": "defaultOptionIndex",
													"args": null,
													"kind": "ScalarField",
													"name": "default",
													"storageKey": null
												},
												v27
											],
											"type": "IssueFormElementDropdown",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v31,
												v32,
												v33,
												{
													"alias": "checkboxOptions",
													"args": null,
													"concreteType": "IssueFormElementCheckboxOption",
													"kind": "LinkedField",
													"name": "options",
													"plural": true,
													"selections": [
														v32,
														{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "labelHTML",
															"storageKey": null
														},
														v36
													],
													"storageKey": null
												},
												v27
											],
											"type": "IssueFormElementCheckboxes",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v31,
												v32,
												v33,
												v36,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "accept",
													"storageKey": null
												},
												v27
											],
											"type": "IssueFormElementUpload",
											"abstractKey": null
										}
									],
									"storageKey": null
								},
								v14,
								v29,
								v28,
								v30,
								v27
							],
							"storageKey": null
						}],
						"type": "Repository",
						"abstractKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "77fec564dbe8436f8d9caae7e9e1fbc4",
			"metadata": {},
			"name": "CreateIssueQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$74.hash = "a07055edea10e255144aa55d8c188972";
var node$73 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [{
			"defaultValue": false,
			"kind": "LocalArgument",
			"name": "includeTemplates"
		}],
		"kind": "Fragment",
		"metadata": null,
		"name": "CreateIssue",
		"selections": [{
			"kind": "InlineDataFragmentSpread",
			"name": "RepositoryPickerRepository",
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "id",
					"storageKey": null
				},
				v0,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "nameWithOwner",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [
						v0,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "size",
								"value": 64
							}],
							"kind": "ScalarField",
							"name": "avatarUrl",
							"storageKey": "avatarUrl(size:64)"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "issueTypesEnabled",
							"storageKey": null
						}
					],
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isLocked",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isPrivate",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "visibility",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isArchived",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isInOrganization",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "hasIssuesEnabled",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "hasAnyTemplates",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "slashCommandsEnabled",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "viewerCanPush",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isBlankIssuesEnabled",
					"storageKey": null
				},
				{
					"alias": null,
					"args": [{
						"kind": "Literal",
						"name": "action",
						"value": "create an issue"
					}],
					"kind": "ScalarField",
					"name": "viewerInteractionLimitReasonHTML",
					"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
				},
				{
					"alias": null,
					"args": null,
					"concreteType": "IssueCreationPermissions",
					"kind": "LinkedField",
					"name": "viewerIssueCreationPermissions",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "labelable",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "milestoneable",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "assignable",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "triageable",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "typeable",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "canSetIssueFields",
							"storageKey": null
						}
					],
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "shortDescriptionHTML",
					"storageKey": null
				}
			],
			"args": null,
			"argumentDefinitions": []
		}, {
			"condition": "includeTemplates",
			"kind": "Condition",
			"passingValue": true,
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "TemplatePickerButton"
			}, {
				"args": null,
				"kind": "FragmentSpread",
				"name": "TemplateListPane"
			}]
		}],
		"type": "Repository",
		"abstractKey": null
	};
})();
node$73.hash = "11a4bfcf2545d016056e98e1ea117093";
var ERRORS$1 = {
	createIssueError: "Unable to create issue.",
	unableToLoadSelectedTemplate: "Unable to selected template"
};
/**
* Fetch default branch for a specific repository using the GitHub repository path
* This is more efficient than using the search API since it targets a specific repo directly
*/
async function fetchRepositoryDefaultBranch(nameWithOwner) {
	try {
		const [owner, repo] = nameWithOwner.split("/");
		if (!owner || !repo) return null;
		const response = await verifiedFetchJSON(repositoryDefaultBranchPath({
			owner,
			repo
		}));
		if (response.ok) {
			const data = await response.json();
			if (!data) return null;
			return data?.defaultBranch || null;
		}
		return null;
	} catch {
		return null;
	}
}
/**
* Hook to fetch repository default branch with React Query caching
* This provides better caching, deduplication, and loading states
*/
function useRepositoryDefaultBranch(nameWithOwner, t0) {
	const $ = c(7);
	const enabled = t0 === void 0 ? true : t0;
	let t1;
	let t2;
	if ($[0] !== nameWithOwner) {
		t1 = ["repository-default-branch", nameWithOwner];
		t2 = () => fetchRepositoryDefaultBranch(nameWithOwner ?? "");
		$[0] = nameWithOwner;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	let t3;
	if ($[3] !== enabled || $[4] !== t1 || $[5] !== t2) {
		t3 = {
			queryKey: t1,
			queryFn: t2,
			enabled,
			staleTime: 3e5,
			gcTime: 6e5,
			retry: 1
		};
		$[3] = enabled;
		$[4] = t1;
		$[5] = t2;
		$[6] = t3;
	} else t3 = $[6];
	return useQuery(t3);
}
/**
* Hook to manage repository fetching and selection logic for Copilot assignment forms
*/
function useCopilotRepositoryFetching(initialRepo) {
	const $ = c(32);
	let t0;
	if ($[0] !== initialRepo.owner.login) {
		t0 = { login: initialRepo.owner.login };
		$[0] = initialRepo.owner.login;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== initialRepo.defaultBranch || $[3] !== initialRepo.name || $[4] !== t0) {
		t1 = {
			name: initialRepo.name,
			defaultBranch: initialRepo.defaultBranch,
			owner: t0
		};
		$[2] = initialRepo.defaultBranch;
		$[3] = initialRepo.name;
		$[4] = t0;
		$[5] = t1;
	} else t1 = $[5];
	const stableInitialRepo = t1;
	const [selectedRepo, setSelectedRepo] = useState(null);
	const [selectedBranch, setSelectedBranch] = useState("");
	const [isLoadingBranch, setIsLoadingBranch] = useState(false);
	const [initialRepoApiMetadata, setInitialRepoApiMetadata] = useState(null);
	let t2;
	if ($[6] !== initialRepoApiMetadata || $[7] !== stableInitialRepo.name || $[8] !== stableInitialRepo.owner.login) {
		t2 = (repos) => {
			if (initialRepoApiMetadata) return;
			const nameWithOwner = `${stableInitialRepo.owner.login}/${stableInitialRepo.name}`;
			const matchingRepo = repos.find((r) => r.nameWithOwner === nameWithOwner);
			if (!matchingRepo) return;
			const fetchedAttributes = {
				private: matchingRepo.private,
				isEmpty: matchingRepo.isEmpty,
				graphQLId: matchingRepo.graphQLId
			};
			setInitialRepoApiMetadata(fetchedAttributes);
			setSelectedRepo((prev) => {
				if (prev?.nameWithOwner === nameWithOwner) return {
					...prev,
					...fetchedAttributes
				};
				return prev;
			});
		};
		$[6] = initialRepoApiMetadata;
		$[7] = stableInitialRepo.name;
		$[8] = stableInitialRepo.owner.login;
		$[9] = t2;
	} else t2 = $[9];
	const handleReposLoaded = t2;
	const { data: defaultBranchFromQuery, isLoading: isLoadingFromQuery } = useRepositoryDefaultBranch(`${stableInitialRepo.owner.login}/${stableInitialRepo.name}`, !stableInitialRepo.defaultBranch);
	let t3;
	if ($[10] !== selectedRepo || $[11] !== stableInitialRepo.defaultBranch || $[12] !== stableInitialRepo.name || $[13] !== stableInitialRepo.owner.login) {
		t3 = () => {
			if (selectedRepo) return;
			const repoNameWithOwner = `${stableInitialRepo.owner.login}/${stableInitialRepo.name}`;
			setSelectedRepo({
				owner: stableInitialRepo.owner.login,
				name: repoNameWithOwner,
				nameOnly: stableInitialRepo.name,
				nameWithOwner: repoNameWithOwner,
				enabled: true,
				defaultBranch: stableInitialRepo.defaultBranch || "",
				private: false,
				graphQLId: "",
				isEmpty: false
			});
			if (stableInitialRepo.defaultBranch) setSelectedBranch(stableInitialRepo.defaultBranch);
		};
		$[10] = selectedRepo;
		$[11] = stableInitialRepo.defaultBranch;
		$[12] = stableInitialRepo.name;
		$[13] = stableInitialRepo.owner.login;
		$[14] = t3;
	} else t3 = $[14];
	let t4;
	if ($[15] !== selectedRepo || $[16] !== stableInitialRepo) {
		t4 = [stableInitialRepo, selectedRepo];
		$[15] = selectedRepo;
		$[16] = stableInitialRepo;
		$[17] = t4;
	} else t4 = $[17];
	useEffect(t3, t4);
	let t5;
	let t6;
	if ($[18] !== isLoadingFromQuery) {
		t5 = () => {
			setIsLoadingBranch(isLoadingFromQuery);
		};
		t6 = [isLoadingFromQuery];
		$[18] = isLoadingFromQuery;
		$[19] = t5;
		$[20] = t6;
	} else {
		t5 = $[19];
		t6 = $[20];
	}
	useEffect(t5, t6);
	let t7;
	let t8;
	if ($[21] !== defaultBranchFromQuery || $[22] !== stableInitialRepo.defaultBranch) {
		t7 = () => {
			if (defaultBranchFromQuery && !stableInitialRepo.defaultBranch) {
				setSelectedBranch(defaultBranchFromQuery);
				setSelectedRepo((prev_0) => prev_0 ? {
					...prev_0,
					defaultBranch: defaultBranchFromQuery
				} : prev_0);
			}
		};
		t8 = [defaultBranchFromQuery, stableInitialRepo.defaultBranch];
		$[21] = defaultBranchFromQuery;
		$[22] = stableInitialRepo.defaultBranch;
		$[23] = t7;
		$[24] = t8;
	} else {
		t7 = $[23];
		t8 = $[24];
	}
	useEffect(t7, t8);
	let t9;
	if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = (repo) => {
			if (!repo) return;
			setIsLoadingBranch(false);
			setSelectedRepo(repo);
			setSelectedBranch(repo.defaultBranch);
		};
		$[25] = t9;
	} else t9 = $[25];
	const handleRepoSelect = t9;
	let t10;
	if ($[26] !== handleReposLoaded || $[27] !== initialRepoApiMetadata || $[28] !== isLoadingBranch || $[29] !== selectedBranch || $[30] !== selectedRepo) {
		t10 = {
			selectedRepo,
			selectedBranch,
			isLoadingBranch,
			initialRepoApiMetadata,
			setSelectedBranch,
			handleRepoSelect,
			handleReposLoaded
		};
		$[26] = handleReposLoaded;
		$[27] = initialRepoApiMetadata;
		$[28] = isLoadingBranch;
		$[29] = selectedBranch;
		$[30] = selectedRepo;
		$[31] = t10;
	} else t10 = $[31];
	return t10;
}
/**
* Hook that provides a repository loader function that automatically includes
* a repository owner as defaultOwner for organization-scoped searches
*
* @param defaultOwner Owner login to use for scoped repository searches
* @param repoToIncludeInTopRepos Optional repository (in owner/repo format) to always include in top results
* when query is empty
*/
function useDefaultOwnerAwareRepositoryLoader(defaultOwner, repoToIncludeInTopRepos) {
	const $ = c(3);
	let t0;
	if ($[0] !== defaultOwner || $[1] !== repoToIncludeInTopRepos) {
		t0 = (query) => queryForRepos(query, defaultOwner, repoToIncludeInTopRepos);
		$[0] = defaultOwner;
		$[1] = repoToIncludeInTopRepos;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
var CopilotAssignmentForm_module_default = {
	assignButton: "CopilotAssignmentForm-module_cXU90a_assignButton",
	branchValidation: "CopilotAssignmentForm-module_cXU90a_branchValidation",
	buttonsContainer: "CopilotAssignmentForm-module_cXU90a_buttonsContainer",
	buttonsRow: "CopilotAssignmentForm-module_cXU90a_buttonsRow",
	decoupledBanner: "CopilotAssignmentForm-module_cXU90a_decoupledBanner",
	formContainer: "CopilotAssignmentForm-module_cXU90a_formContainer",
	formControl: "CopilotAssignmentForm-module_cXU90a_formControl",
	inputContainer: "CopilotAssignmentForm-module_cXU90a_inputContainer",
	modelPickerContainer: "CopilotAssignmentForm-module_cXU90a_modelPickerContainer",
	promptLabel: "CopilotAssignmentForm-module_cXU90a_promptLabel",
	selectorsRow: "CopilotAssignmentForm-module_cXU90a_selectorsRow",
	textarea: "CopilotAssignmentForm-module_cXU90a_textarea",
	textareaContainer: "CopilotAssignmentForm-module_cXU90a_textareaContainer",
	toolbar: "CopilotAssignmentForm-module_cXU90a_toolbar",
	toolbarButton: "CopilotAssignmentForm-module_cXU90a_toolbarButton",
	validationError: "CopilotAssignmentForm-module_cXU90a_validationError",
	warningBanner: "CopilotAssignmentForm-module_cXU90a_warningBanner"
};
function useNoticeDismissal(noticeKey) {
	const $ = c(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("copilot_mission_control_decoupled_mode") && isFeatureEnabled("issue_cca_visualization_decoupled_mode");
		$[0] = t0;
	} else t0 = $[0];
	const enabled = t0;
	let t1;
	if ($[1] !== noticeKey) {
		t1 = {
			queryKey: ["notice-dismissal", noticeKey],
			queryFn: async () => {
				const response = await verifiedFetchJSON(`/settings/notice-dismissals/${encodeURIComponent(noticeKey)}`);
				if (!response.ok) throw new Error(`Failed to check notice dismissal: ${response.status}`);
				return await response.json();
			},
			staleTime: Infinity,
			enabled
		};
		$[1] = noticeKey;
		$[2] = t1;
	} else t1 = $[2];
	return useQuery(t1);
}
var CROSS_ORG_WARNING_TEXT_AGENT = "You're assigning the agent to perform work in a different organization. The issue description will be visible to users outside this repository.";
var CROSS_ORG_WARNING_TEXT_COPILOT = "You're assigning Copilot coding agent to perform work in a different organization. The issue description will be visible to users outside this repository.";
var PRIVATE_TO_PUBLIC_WARNING_TEXT_AGENT = "You're assigning the agent to perform work in a public repository. The issue description will be visible to users outside this repository.";
var PRIVATE_TO_PUBLIC_WARNING_TEXT_COPILOT = "You're assigning Copilot coding agent to perform work in a public repository. The issue description will be visible to users outside this repository.";
var EMPTY_REPO_WARNING_TEXT = "The selected repo has no commits or branches so there's no valid base branch to create a PR against.";
function CopilotAssignmentForm({ ref, initialRepo, onSubmit, onCancel, isSubmitting = false, isQuotaExhausted = false, textareaRef, textareaAriaDescribedBy, promptPlaceholder, promptLabelHidden = false, promptRequired = false, insideDialog = false, initialAgent }) {
	const { plan } = useEntitlement();
	const { data: noticeDismissed } = useNoticeDismissal(DISMISSAL_KEY.issues);
	const [content, setContent] = useState("");
	const [textareaValidationError, setTextareaValidationError] = useState(void 0);
	const [branchValidationError, setBranchValidationError] = useState(void 0);
	const [selectedModel, setSelectedModel] = useLatestAgentModel();
	const [selectedAgent, setSelectedAgent] = useLastSelectedAgent(initialAgent);
	const { data: agentInfo } = useAgentInfo(selectedAgent.topLevelAgentId ? Number(selectedAgent.topLevelAgentId) : null);
	const cacheKey = `copilot-assignment-ref-selector-${useId()}`;
	const internalTextareaRef = useRef(null);
	const finalTextareaRef = textareaRef || internalTextareaRef;
	const initialRepoNameWithOwner = `${initialRepo.owner.login}/${initialRepo.name}`;
	const defaultOwnerAwareRepositoryLoader = useDefaultOwnerAwareRepositoryLoader(initialRepo.owner.login, initialRepoNameWithOwner);
	const { selectedRepo, selectedBranch, setSelectedBranch, isLoadingBranch, initialRepoApiMetadata, handleRepoSelect: handleRepoSelectFromHook, handleReposLoaded } = useCopilotRepositoryFetching(initialRepo);
	const isSweSubagentsEnabled = isFeatureEnabled("copilot_swe_agent_use_subagents");
	const useAgentLabels = isFeatureEnabled("issue_cca_modal_open");
	const warningMessage = useMemo(() => {
		if (!selectedRepo) return null;
		const targetIsPublic = !selectedRepo.private;
		const differentOrganization = initialRepo.owner.login !== selectedRepo.owner;
		if (selectedRepo.isEmpty) return EMPTY_REPO_WARNING_TEXT;
		if (differentOrganization) return useAgentLabels ? CROSS_ORG_WARNING_TEXT_AGENT : CROSS_ORG_WARNING_TEXT_COPILOT;
		if (initialRepoApiMetadata?.private && targetIsPublic) return useAgentLabels ? PRIVATE_TO_PUBLIC_WARNING_TEXT_AGENT : PRIVATE_TO_PUBLIC_WARNING_TEXT_COPILOT;
		return null;
	}, [
		selectedRepo,
		initialRepo.owner.login,
		initialRepoApiMetadata,
		useAgentLabels
	]);
	const handleRepoSelect = useCallback((repo) => {
		if (!repo || isSubmitting) return;
		handleRepoSelectFromHook(repo);
		setBranchValidationError(void 0);
	}, [isSubmitting, handleRepoSelectFromHook]);
	const handleSubmit = useCallback(async () => {
		if (isSubmitting) return;
		setTextareaValidationError(void 0);
		setBranchValidationError(void 0);
		if (promptRequired && !content.trim()) {
			setTextareaValidationError("Please provide a prompt.");
			return;
		}
		if (content.length > 1e4) {
			setTextareaValidationError(`Instructions must be ${COPILOT_INSTRUCTIONS_MAX_LENGTH.toLocaleString()} characters or fewer. Current length: ${content.length.toLocaleString()} characters.`);
			return;
		}
		if (!selectedRepo || !selectedBranch) {
			setBranchValidationError("Please select a repository and branch.");
			return;
		}
		if (selectedRepo.isEmpty) {
			setBranchValidationError("Please select a valid base branch.");
			return;
		}
		await onSubmit(content, selectedRepo, selectedBranch, selectedAgent, selectedModel);
	}, [
		content,
		selectedRepo,
		selectedBranch,
		selectedAgent,
		selectedModel,
		onSubmit,
		isSubmitting,
		promptRequired
	]);
	useImperativeHandle(ref, () => ({ submit: handleSubmit }), [handleSubmit]);
	const submitButtonInactive = isQuotaExhausted || selectedRepo?.isEmpty || isSubmitting || !selectedRepo || !selectedBranch;
	const refSelectorInactive = isSubmitting || isLoadingBranch || !selectedRepo?.defaultBranch || selectedRepo?.isEmpty;
	const customAgentPickerInactive = isSubmitting;
	return /* @__PURE__ */ jsxs("div", {
		className: CopilotAssignmentForm_module_default.formContainer,
		children: [
			promptLabelHidden ? /* @__PURE__ */ jsx("label", {
				htmlFor: "copilot-assignment-prompt",
				className: "sr-only",
				children: COPILOT_ASSIGNMENT_PROMPT_LABEL
			}) : /* @__PURE__ */ jsx("label", {
				htmlFor: "copilot-assignment-prompt",
				className: CopilotAssignmentForm_module_default.promptLabel,
				children: COPILOT_ASSIGNMENT_PROMPT_LABEL
			}),
			/* @__PURE__ */ jsxs("div", {
				className: CopilotAssignmentForm_module_default.inputContainer,
				children: [/* @__PURE__ */ jsxs("div", {
					className: CopilotAssignmentForm_module_default.textareaContainer,
					children: [/* @__PURE__ */ jsx("textarea", {
						id: "copilot-assignment-prompt",
						ref: finalTextareaRef,
						className: CopilotAssignmentForm_module_default.textarea,
						placeholder: promptPlaceholder ?? (useAgentLabels ? "Provide additional instructions for the agent" : "Provide additional instructions for Copilot"),
						value: content,
						onChange: (e) => setContent(e.target.value),
						rows: 2,
						"aria-describedby": textareaValidationError ? [textareaAriaDescribedBy, "copilot-assignment-prompt-error"].filter(Boolean).join(" ") : textareaAriaDescribedBy,
						maxLength: COPILOT_INSTRUCTIONS_MAX_LENGTH,
						disabled: isSubmitting
					}), textareaValidationError && /* @__PURE__ */ jsx("span", {
						id: "copilot-assignment-prompt-error",
						className: CopilotAssignmentForm_module_default.validationError,
						children: textareaValidationError
					})]
				}), /* @__PURE__ */ jsx("div", {
					className: CopilotAssignmentForm_module_default.toolbar,
					children: /* @__PURE__ */ jsxs("div", {
						className: CopilotAssignmentForm_module_default.selectorsRow,
						children: [
							/* @__PURE__ */ jsxs(FormControl$1, {
								className: CopilotAssignmentForm_module_default.formControl,
								children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
									visuallyHidden: true,
									children: COPILOT_ASSIGNMENT_REPO_LABEL
								}), /* @__PURE__ */ jsx(ReposSelector, {
									repositoryLoader: defaultOwnerAwareRepositoryLoader,
									selectionVariant: "single",
									selectAllOption: false,
									onSelect: handleRepoSelect,
									onLoad: handleReposLoaded,
									currentSelection: selectedRepo || void 0,
									buttonText: selectedRepo?.nameWithOwner || "Select repository",
									width: "large",
									truncateMaxWidth: 250,
									additionalButtonProps: {
										variant: "invisible",
										className: CopilotAssignmentForm_module_default.toolbarButton,
										"aria-label": `Repository: ${selectedRepo?.nameWithOwner || "Select repository"}`,
										disabled: isSubmitting
									}
								})]
							}),
							/* @__PURE__ */ jsxs(FormControl$1, {
								className: CopilotAssignmentForm_module_default.formControl,
								children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
									visuallyHidden: true,
									children: COPILOT_ASSIGNMENT_BRANCH_LABEL
								}), selectedRepo || selectedBranch ? /* @__PURE__ */ jsx(RefSelector, {
									useFocusZone: true,
									cacheKey,
									canCreate: false,
									currentCommitish: selectedBranch || selectedRepo?.defaultBranch || "",
									defaultBranch: selectedRepo?.defaultBranch ?? selectedBranch,
									owner: selectedRepo?.owner || "",
									repo: selectedRepo?.nameOnly || "",
									types: ["branch"],
									selectedRefType: "branch",
									closeOnSelect: true,
									hideShowAll: true,
									disabled: refSelectorInactive,
									actionListHeadingText: COPILOT_ASSIGNMENT_SELECT_BRANCH_HEADING,
									actionListDescription: useAgentLabels ? AGENT_ASSIGNMENT_BRANCH_CAPTION : COPILOT_ASSIGNMENT_BRANCH_CAPTION,
									onSelectItem: (selectedRef) => {
										if (!isSubmitting) setSelectedBranch(selectedRef);
									},
									renderAnchor: (props) => /* @__PURE__ */ jsx(IconButtonSelector, {
										...props,
										variant: "invisible",
										className: CopilotAssignmentForm_module_default.toolbarButton,
										icon: GitBranchIcon,
										selectedIcon: GitBranchCheckIcon,
										selected: selectedBranch !== selectedRepo?.defaultBranch,
										"aria-label": selectedRepo?.isEmpty ? "Branch: None available" : `Branch: ${isLoadingBranch ? "Loading branch..." : selectedBranch || "Select branch"}`,
										"aria-labelledby": void 0
									}),
									anchoredOverlayProps: {
										variant: {
											regular: "anchored",
											narrow: "fullscreen"
										},
										height: "small"
									}
								}) : /* @__PURE__ */ jsx(IconButton, {
									variant: "invisible",
									className: CopilotAssignmentForm_module_default.toolbarButton,
									icon: GitBranchIcon,
									"aria-label": "Loading branches…",
									disabled: true
								})]
							}),
							(isSweSubagentsEnabled || useAgentLabels) && selectedRepo && /* @__PURE__ */ jsxs(FormControl$1, {
								className: CopilotAssignmentForm_module_default.formControl,
								children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
									visuallyHidden: true,
									children: "Custom agent"
								}), /* @__PURE__ */ jsx(AgentSelector, {
									repo: selectedRepo,
									branch: selectedBranch || selectedRepo.defaultBranch,
									selectedAgent,
									onSelectAgent: (agent) => setSelectedAgent(agent),
									iconOnly: true,
									disabled: customAgentPickerInactive,
									insideDialog,
									buttonProps: {
										variant: "invisible",
										className: CopilotAssignmentForm_module_default.toolbarButton
									}
								})]
							}),
							copilotFeatureFlags.codingAgentModelSelection && (copilotFeatureFlags.codingAgentModelSelectionAllSkus || plan === CopilotPlan.IndividualPro || plan === CopilotPlan.IndividualProPlus || plan === CopilotPlan.IndividualStudent) && isCopilotOrCustomAgent(selectedAgent, agentInfo?.slug) && /* @__PURE__ */ jsx("div", {
								className: CopilotAssignmentForm_module_default.modelPickerContainer,
								children: /* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
									visuallyHidden: true,
									children: "Model"
								}), /* @__PURE__ */ jsx(ModelPicker, {
									onUpdateModel: setSelectedModel,
									selectedModelId: selectedModel
								})] })
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ jsx(DecoupledModeBanner, {
				className: CopilotAssignmentForm_module_default.decoupledBanner,
				dismissalKey: DISMISSAL_KEY.issues,
				enabled: !(noticeDismissed?.dismissed ?? true) && isFeatureEnabled("copilot_mission_control_decoupled_mode") && isFeatureEnabled("issue_cca_visualization_decoupled_mode")
			}),
			warningMessage && /* @__PURE__ */ jsx(Banner, {
				variant: "warning",
				title: "Warning",
				hideTitle: true,
				className: CopilotAssignmentForm_module_default.warningBanner,
				children: warningMessage
			}),
			branchValidationError && /* @__PURE__ */ jsx(InlineMessage, {
				variant: "critical",
				className: CopilotAssignmentForm_module_default.branchValidation,
				children: branchValidationError
			}),
			/* @__PURE__ */ jsx("div", {
				className: CopilotAssignmentForm_module_default.buttonsContainer,
				children: /* @__PURE__ */ jsxs("div", {
					className: CopilotAssignmentForm_module_default.buttonsRow,
					children: [onCancel && /* @__PURE__ */ jsx(ButtonComponent, {
						variant: "invisible",
						onClick: onCancel,
						disabled: isSubmitting,
						children: "Cancel"
					}), /* @__PURE__ */ jsx(CommandButton, {
						commandId: "github:submit-form",
						showKeybindingHint: true,
						variant: "primary",
						inactive: submitButtonInactive,
						loading: isSubmitting,
						className: CopilotAssignmentForm_module_default.assignButton,
						children: "Assign"
					})]
				})
			})
		]
	});
}
CopilotAssignmentForm.displayName = "CopilotAssignmentForm";
/**
* Assigns multiple issues to Copilot with the specified instructions and target repository.
*
* @param owner - The repository owner
* @param repo - The repository name
* @param issueNumbers - Array of issue numbers to assign
* @param options - Assignment options including instructions and target repository
* @returns Promise resolving to the API response
*/
async function assignIssuesToCopilot(owner, repo, issueNumbers, options) {
	try {
		const response = await verifiedFetchJSON(`/${owner}/${repo}${COPILOT_ASSIGNMENT_API_ENDPOINT}`, {
			method: "POST",
			body: {
				issue_ids: issueNumbers,
				repo_name_with_owner: options.targetRepo,
				base_ref: options.targetBranch,
				custom_instructions: options.instructions,
				custom_agent: options.customAgent,
				agent_id: options.agentId,
				model: options.model,
				skip_pull_request: options.skipPullRequest
			}
		});
		if (response.ok) {
			const data = await response.json();
			return {
				ok: true,
				status: response.status,
				data
			};
		} else {
			let errorMessage;
			try {
				const errorData = await response.json();
				errorMessage = errorData.error || `Request failed with status ${response.status}`;
				return {
					ok: false,
					status: response.status,
					errorMessage,
					jobs: errorData.jobs || []
				};
			} catch {
				errorMessage = `Request failed with status ${response.status}`;
				return {
					ok: false,
					status: response.status,
					errorMessage
				};
			}
		}
	} catch (error) {
		return {
			ok: false,
			status: 0,
			errorMessage: error instanceof Error ? error.message : "An unexpected error occurred"
		};
	}
}
/**
* Enhances error messages based on HTTP status codes with actionable guidance.
*
* @param baseMessage - The base error message
* @param status - The HTTP status code
* @returns An enhanced error message with user guidance
*/
function enhanceErrorMessage(baseMessage, status) {
	switch (status) {
		case 403: return `${baseMessage}: Please check that you have permission to assign issues in the target repository.`;
		case 404: return `${baseMessage}: The repository or branch may not exist or may not be accessible.`;
		case 422: return `${baseMessage}: Request could not be processed. Please try again or contact support if the issue persists.`;
		case 429: return `${baseMessage}: Rate limit exceeded. Please wait a few moments and try again.`;
		case 0: return `${baseMessage}. Please check your network connection and try again.`;
		default:
			if (status >= 500) return `${baseMessage}: There was a server error. Please try again in a few moments.`;
			return `${baseMessage}. Please try again or contact support if the issue persists.`;
	}
}
/**
* Formats error messages for Copilot assignment API responses.
*
* @param response - The API response object containing error information
* @param baseMessage - The base error message to enhance
* @returns A formatted error message string
*/
function formatAssignmentError(response, baseMessage) {
	if (response.errorMessage) return `${baseMessage}: ${response.errorMessage}`;
	return enhanceErrorMessage(baseMessage, response.status);
}
/**
* Builds a concise base error message for multi-issue assignment failures, e.g.
* "Assignment failed for #123, #456 and 2 others".
* The failed issue numbers are derived by subtracting successful job issue_numbers from the attempted list.
*
* @param attemptedIssueNumbers - Array of issue numbers that were attempted to be assigned
* @param successfulJobs - Array of successful assignment jobs (optional)
* @returns A formatted error message string describing the failed assignments
*/
function buildAssignmentFailureBaseMessage(attemptedIssueNumbers, successfulJobs) {
	if (!attemptedIssueNumbers || attemptedIssueNumbers.length === 0) return "Assignment failed";
	const successful = new Set((successfulJobs || []).map((j) => j.issue_number));
	const failed = [];
	for (const issueNum of attemptedIssueNumbers) if (typeof issueNum === "number" && !isNaN(issueNum) && !successful.has(issueNum)) failed.push(issueNum);
	failed.sort((a, b) => a - b);
	if (failed.length === 0 || failed.length === attemptedIssueNumbers.length) return "Assignment failed";
	if (failed.length === 1) return `Assignment failed for #${failed[0]}`;
	if (failed.length === 2) return `Assignment failed for #${failed[0]} and #${failed[1]}`;
	const [first, second, ...rest] = failed;
	const remainingCount = rest.length;
	return `Assignment failed for #${first}, #${second} and ${remainingCount} other${remainingCount === 1 ? "" : "s"}`;
}
/**
* Formats error messages for caught exceptions.
*
* @param error - The caught error
* @param operation - Brief description of the operation that failed
* @returns A formatted error message string
*/
function formatException(error, operation) {
	return error instanceof Error ? `${operation} failed: ${error.message}` : enhanceErrorMessage(`${operation} failed`, 500);
}
var CopilotAssignmentModal_module_default = {
	description: "CopilotAssignmentModal-module_S37eNa_description",
	errorContainer: "CopilotAssignmentModal-module_S37eNa_errorContainer",
	errorMarkdown: "CopilotAssignmentModal-module_S37eNa_errorMarkdown",
	feedbackLink: "CopilotAssignmentModal-module_S37eNa_feedbackLink",
	header: "CopilotAssignmentModal-module_S37eNa_header",
	previewBadge: "CopilotAssignmentModal-module_S37eNa_previewBadge",
	rightSection: "CopilotAssignmentModal-module_S37eNa_rightSection"
};
/**
* Hook to get the Copilot license type.
*
* This hook tries to get the license type from the app payload first (available in React routes).
* If the payload is not available (e.g., in Memex or other non-React-route contexts),
* it fetches the entitlement from the API.
*/
function useCopilotLicenseType() {
	const $ = c(4);
	const payloadLicenseType = useAppPayload()?.licenseType;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["copilot-chat", "entitlement"];
		$[0] = t0;
	} else t0 = $[0];
	const t1 = payloadLicenseType === void 0;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = { licenseType: CopilotLicenseType.Unlicensed };
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== t1) {
		t3 = {
			queryKey: t0,
			queryFn: _temp$28,
			enabled: t1,
			placeholderData: t2,
			staleTime: 3e5
		};
		$[2] = t1;
		$[3] = t3;
	} else t3 = $[3];
	const { data } = useQuery(t3);
	return payloadLicenseType ?? data?.licenseType ?? CopilotLicenseType.Unlicensed;
}
async function _temp$28() {
	const response = await verifiedFetchJSON("/github-copilot/chat/entitlement");
	if (!response.ok) throw new Error(`Failed to retrieve Copilot chat entitlement (${response.status} on ${response.url})`);
	return await response.json();
}
/**
* Modal component for Copilot-assisted issue assignment.
* Uses CopilotAssignmentForm component for repo/branch selection and custom instructions.
* Can be used independently of the button component.
*/
function CopilotAssignmentModal({ isOpen, onClose, repository, issueNumbers, onAssignmentComplete, returnFocusRef, onSubmit: customOnSubmit, title: customTitle, description: customDescription, initialAgent }) {
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [errorMessage, setErrorMessage] = useState(null);
	const textareaRef = useRef(null);
	const formRef = useRef(null);
	const licenseType = useCopilotLicenseType();
	const [initialIssueCount, setInitialIssueCount] = useState(() => issueNumbers?.length ?? 0);
	const wasOpenRef = useRef(isOpen);
	useEffect(() => {
		if (isOpen && !wasOpenRef.current) setInitialIssueCount(issueNumbers?.length ?? 0);
		wasOpenRef.current = isOpen;
	}, [isOpen, issueNumbers]);
	const handleClose = () => {
		setErrorMessage(null);
		setIsSubmitting(false);
		onClose();
	};
	const owner = repository.owner.login;
	const repo = repository.name;
	const multipleIssues = initialIssueCount > 1;
	const handleSubmit = useCallback(async (content, selectedRepo, selectedBranch, selectedAgent, selectedModel) => {
		if (!selectedRepo) return;
		if (customOnSubmit && selectedRepo.graphQLId) {
			setIsSubmitting(true);
			try {
				await customOnSubmit(selectedRepo.graphQLId, selectedBranch, content, selectedAgent, selectedModel, selectedRepo.nameWithOwner, selectedRepo.id);
			} finally {
				setIsSubmitting(false);
			}
			return;
		}
		if (!issueNumbers || issueNumbers.length === 0) return;
		const submittedIssueNumbers = [...issueNumbers];
		setIsSubmitting(true);
		setErrorMessage(null);
		try {
			const response = await assignIssuesToCopilot(owner, repo, submittedIssueNumbers, {
				instructions: content,
				targetRepo: selectedRepo.nameWithOwner,
				targetBranch: selectedBranch,
				customAgent: selectedAgent?.subAgentSlug || void 0,
				agentId: selectedAgent?.topLevelAgentId || void 0,
				model: selectedModel
			});
			if (response.ok) {
				await onAssignmentComplete?.(response.data?.copilot);
				onClose();
			} else setErrorMessage(formatAssignmentError(response, multipleIssues ? buildAssignmentFailureBaseMessage(submittedIssueNumbers, response.jobs) : "Assignment failed"));
		} catch (error) {
			setErrorMessage(formatException(error, "Assignment"));
		} finally {
			setIsSubmitting(false);
		}
	}, [
		issueNumbers,
		owner,
		repo,
		onAssignmentComplete,
		onClose,
		multipleIssues,
		customOnSubmit
	]);
	const initialRepo = useMemo(() => repository ? {
		name: repository.name,
		defaultBranch: void 0,
		owner: { login: repository.owner.login }
	} : null, [repository]);
	const handleFormSubmitCommand = useCallback(async () => {
		if (!isSubmitting && formRef.current) await formRef.current.submit();
	}, [isSubmitting]);
	if (!isOpen) return null;
	const useAgentLabels = isFeatureEnabled("issue_cca_modal_open");
	const defaultTitle = multipleIssues ? `Assign ${initialIssueCount} issues to ${useAgentLabels ? "agent" : "Copilot"}` : useAgentLabels ? "Assign agent to issue" : "Assign Copilot to issue";
	const title = customTitle ?? defaultTitle;
	const description = customDescription ?? (useAgentLabels ? `The agent will use the issue description, comments, and any additional prompt you provide to get started. Select a custom agent for specialized tasks.` : `Copilot will use the issue description, comments, and any additional prompt you provide to get started. Select a custom agent for specialized tasks.`);
	const feedbackHref = isStaff() ? "https://gh.io/copilot-issues-cross-repo-assign-staff-feedback" : "https://gh.io/copilot-issues-cross-repo-assign-feedback";
	return /* @__PURE__ */ jsxs(Dialog, {
		onClose: handleClose,
		width: "xlarge",
		initialFocusRef: textareaRef,
		returnFocusRef,
		renderHeader: ({ dialogLabelId }) => /* @__PURE__ */ jsxs(Dialog.Header, {
			id: dialogLabelId,
			className: CopilotAssignmentModal_module_default.header,
			children: [/* @__PURE__ */ jsx(Dialog.Title, { children: title }), /* @__PURE__ */ jsxs("div", {
				className: CopilotAssignmentModal_module_default.rightSection,
				children: [
					/* @__PURE__ */ jsx(Label, {
						variant: "success",
						className: CopilotAssignmentModal_module_default.previewBadge,
						children: "Preview"
					}),
					/* @__PURE__ */ jsx(Link, {
						href: feedbackHref,
						target: "_blank",
						rel: "noopener noreferrer",
						className: CopilotAssignmentModal_module_default.feedbackLink,
						children: "Feedback"
					}),
					/* @__PURE__ */ jsx(Dialog.CloseButton, { onClose: handleClose })
				]
			})]
		}),
		children: [errorMessage && /* @__PURE__ */ jsx("div", {
			className: CopilotAssignmentModal_module_default.errorContainer,
			children: /* @__PURE__ */ jsx(Banner, {
				variant: "critical",
				title: "Assignment Failed",
				hideTitle: true,
				description: /* @__PURE__ */ jsx("div", {
					"data-testid": "copilot-markdown",
					children: /* @__PURE__ */ jsx(MarkdownRenderer, {
						markdown: errorMessage,
						className: CopilotAssignmentModal_module_default.errorMarkdown
					})
				}),
				secondaryAction: /* @__PURE__ */ jsx(Banner.SecondaryAction, {
					onClick: () => setErrorMessage(null),
					children: "Dismiss"
				})
			})
		}), initialRepo && /* @__PURE__ */ jsx(ScopedCommands, {
			commands: { "github:submit-form": handleFormSubmitCommand },
			children: /* @__PURE__ */ jsx(ConsecutiveCAPI401sProvider, { children: /* @__PURE__ */ jsx(EntitlementProvider, {
				initialLicenseType: licenseType,
				children: /* @__PURE__ */ jsx(CopilotAssignmentModalContent, {
					formRef,
					initialRepo,
					onSubmit: handleSubmit,
					onCancel: handleClose,
					isSubmitting,
					textareaRef,
					description,
					initialAgent
				})
			}) })
		})]
	});
}
CopilotAssignmentModal.displayName = "CopilotAssignmentModal";
function CopilotAssignmentModalContent(t0) {
	const $ = c(10);
	const { formRef, initialRepo, onSubmit, onCancel, isSubmitting, textareaRef, description, initialAgent } = t0;
	const [isQuotaExhausted, setIsQuotaExhausted] = useState(false);
	let t1;
	if ($[0] !== description || $[1] !== formRef || $[2] !== initialAgent || $[3] !== initialRepo || $[4] !== isQuotaExhausted || $[5] !== isSubmitting || $[6] !== onCancel || $[7] !== onSubmit || $[8] !== textareaRef) {
		t1 = jsxs(Fragment$1, { children: [
			jsx(CopilotCodingAgentQuotaBanner, {
				onQuotaExhaustedChange: setIsQuotaExhausted,
				entrypointLocation: "ASSIGNMENT_MODAL"
			}),
			jsx("p", {
				className: CopilotAssignmentModal_module_default.description,
				children: description
			}),
			jsx(CopilotAssignmentForm, {
				ref: formRef,
				initialRepo,
				onSubmit,
				onCancel,
				isSubmitting,
				isQuotaExhausted,
				textareaRef,
				textareaAriaDescribedBy: "copilot-assignment-description",
				insideDialog: true,
				initialAgent
			})
		] });
		$[0] = description;
		$[1] = formRef;
		$[2] = initialAgent;
		$[3] = initialRepo;
		$[4] = isQuotaExhausted;
		$[5] = isSubmitting;
		$[6] = onCancel;
		$[7] = onSubmit;
		$[8] = textareaRef;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
CopilotAssignmentModalContent.displayName = "CopilotAssignmentModalContent";
var node$72 = {
	"kind": "InlineDataFragment",
	"name": "IssueFormElements_templateElements"
};
node$72.hash = "60d8de5d7abb34b5d1a8ee16008c8224";
var node$71 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "label",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "CheckboxesElement_input",
		"selections": [
			{
				"alias": "itemId",
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			},
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "descriptionHTML",
				"storageKey": null
			},
			{
				"alias": "checkboxOptions",
				"args": null,
				"concreteType": "IssueFormElementCheckboxOption",
				"kind": "LinkedField",
				"name": "options",
				"plural": true,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "labelHTML",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "required",
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"kind": "ClientExtension",
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "__id",
					"storageKey": null
				}]
			}
		],
		"type": "IssueFormElementCheckboxes",
		"abstractKey": null
	};
})();
node$71.hash = "66c71c2357977009e7b34571e8a11e21";
var GENERATED_FIELD_PREFIX = "template-field";
var safeGetDefaultValue = ({ id, indexOfFormElement, value, defaultValuesById }) => {
	let defaultEnforcedValue = defaultValuesById && id ? defaultValuesById[id] : void 0;
	if (defaultEnforcedValue === void 0 && defaultValuesById && indexOfFormElement !== void 0) defaultEnforcedValue = defaultValuesById[`${GENERATED_FIELD_PREFIX}-${indexOfFormElement}`];
	return defaultEnforcedValue ?? value ?? "";
};
var DEFAULT_RESPONSE = "_No response_";
var DEFAULT_MARKDOWN_HEADER = "###";
function prefixMarkdownTitle(title, content) {
	if (content.length === 0) content = DEFAULT_RESPONSE;
	if (!title) return content;
	return `${DEFAULT_MARKDOWN_HEADER} ${title}\n\n${content}`;
}
function prefixMarkdownCheckbox(content, selected) {
	return `- [${selected ? "x" : " "}] ${content}`;
}
function prefixMarkdownTextArea(content, render) {
	if (render && content !== DEFAULT_RESPONSE) {
		const backticks = "```";
		return `${backticks}${render}\n${cleanCodeblock(content)}\n${backticks}`;
	} else return content;
}
function cleanCodeblock(content) {
	return content.replace(/(```)(\w+)/g, "").replace(/(```)/g, "").trim();
}
var createUniqueIdForElement = (storageKeyPrefix, element, keySuffix) => element.type === "markdown" ? "" : uniqueIdForElementInternal(storageKeyPrefix, element.type, element.label, keySuffix);
var uniqueIdForElementInternal = (storageKeyPrefix, type, label, keySuffix) => {
	if (type === "markdown") return "";
	return `${storageKeyPrefix}-${type === "" ? label : `${type}-${label}`}-${keySuffix}`;
};
var CheckboxesElement_module_default = {
	CheckboxesElementGroup: "CheckboxesElement-module_DhRY4G_CheckboxesElementGroup",
	CheckboxesElementGroupDescription: "CheckboxesElement-module_DhRY4G_CheckboxesElementGroupDescription",
	CheckboxesElementGroupLabel: "CheckboxesElement-module_DhRY4G_CheckboxesElementGroupLabel",
	checkboxOptionLabel: "CheckboxesElement-module_DhRY4G_checkboxOptionLabel"
};
var import_react_relay = require_react_relay();
/**
* Extracts default values from defaultValuesById and converts them to a boolean array.
* Returns an array of booleans representing checkbox states, with proper length validation.
*/
function getValidDefaultChoices$1({ itemId, indexOfFormElement, defaultValuesById, checkboxCount }) {
	if (!itemId) return Array(checkboxCount).fill(false);
	const defaultValues = safeGetDefaultValue({
		id: itemId,
		value: "",
		indexOfFormElement,
		defaultValuesById
	}).split(",").map((str) => str.trim() === "true");
	return defaultValues.length === checkboxCount ? defaultValues : Array(checkboxCount).fill(false);
}
var CheckboxesElement = ({ ref, elementRef, index, sessionStorageKey, defaultValuesById, onFieldChange }) => {
	const data = (0, import_react_relay.useFragment)(node$71, elementRef);
	if (!data.checkboxOptions) return null;
	const elementStorageKey = uniqueIdForElementInternal(sessionStorageKey, "", data.label, data.__id);
	return /* @__PURE__ */ jsx(CheckboxesElementInternal, {
		...data,
		type: "checkboxes",
		index,
		ref,
		sessionStorageKey: elementStorageKey,
		defaultValuesById,
		onFieldChange
	});
};
CheckboxesElement.displayName = "CheckboxesElement";
var CheckboxesElementInternal = ({ ref, itemId, index: indexOfFormElement, sessionStorageKey, label, descriptionHTML, checkboxOptions, defaultValuesById, onFieldChange }) => {
	const firstCheckboxRef = useRef(null);
	const defaultCheckedValues = useMemo(() => {
		return getValidDefaultChoices$1({
			itemId,
			indexOfFormElement,
			defaultValuesById,
			checkboxCount: checkboxOptions.length
		});
	}, [
		checkboxOptions.length,
		defaultValuesById,
		indexOfFormElement,
		itemId
	]);
	const [selectedItems, setSelectedItems] = useSessionStorage(sessionStorageKey, defaultCheckedValues);
	const latestSelectedItemsRef = useRef(selectedItems);
	useEffect(() => {
		latestSelectedItemsRef.current = selectedItems;
	}, [selectedItems]);
	useEffect(() => {
		const hasDefaultValues = defaultValuesById && Object.keys(defaultValuesById).length > 0;
		if (onFieldChange && hasDefaultValues) {
			const defaultSelection = getValidDefaultChoices$1({
				itemId,
				indexOfFormElement,
				defaultValuesById,
				checkboxCount: checkboxOptions.length
			});
			setSelectedItems(defaultSelection);
			latestSelectedItemsRef.current = defaultSelection;
		}
	}, [
		defaultValuesById,
		indexOfFormElement,
		itemId,
		checkboxOptions.length,
		setSelectedItems,
		onFieldChange
	]);
	useEffect(() => {
		if (onFieldChange) {
			const selectedItemsArray = latestSelectedItemsRef.current;
			const defaultValuesArray = getValidDefaultChoices$1({
				itemId,
				indexOfFormElement,
				defaultValuesById,
				checkboxCount: checkboxOptions.length
			});
			if (!(selectedItemsArray.length === defaultValuesArray.length && selectedItemsArray.every((value, index) => value === defaultValuesArray[index]))) onFieldChange(itemId, indexOfFormElement, selectedItemsArray.map((item) => item.toString()).join(","));
		}
	}, [
		selectedItems,
		itemId,
		indexOfFormElement,
		onFieldChange,
		defaultValuesById,
		checkboxOptions.length
	]);
	const [validationResult, setValidationResult] = useState(void 0);
	useImperativeHandle(ref, () => ({
		focus: () => firstCheckboxRef.current?.focus(),
		markdown: () => {
			return prefixMarkdownTitle(label, checkboxOptions.map((option, checkboxIndex) => prefixMarkdownCheckbox(option.label, selectedItems[checkboxIndex])).join("\n"));
		},
		validate: () => {
			for (const [checkboxIndex_0, checkbox] of checkboxOptions.entries()) if (checkbox.required && !selectedItems[checkboxIndex_0]) {
				setValidationResult(VALIDATORS.checkboxInAGroupMustBeSelected);
				return false;
			}
			return true;
		},
		reset: () => {
			setSelectedItems(defaultCheckedValues);
			setValidationResult(void 0);
		},
		hasChanges: () => !defaultCheckedValues.every((value_0, index_0) => value_0 === selectedItems[index_0]),
		getSessionStorageKey: () => sessionStorageKey,
		type: "checkboxes"
	}), [
		checkboxOptions,
		defaultCheckedValues,
		label,
		selectedItems,
		sessionStorageKey,
		setSelectedItems
	]);
	useEffect(() => {
		if (validationResult && checkboxOptions.every((option_0, index_1) => !option_0.required || selectedItems[index_1])) setValidationResult(void 0);
	}, [
		checkboxOptions,
		selectedItems,
		validationResult
	]);
	return /* @__PURE__ */ jsxs(CheckboxGroup_default, {
		className: CheckboxesElement_module_default.CheckboxesElementGroup,
		children: [
			/* @__PURE__ */ jsx(CheckboxGroup_default.Label, {
				className: CheckboxesElement_module_default.CheckboxesElementGroupLabel,
				children: label
			}),
			descriptionHTML && /* @__PURE__ */ jsx(CheckboxGroup_default.Caption, {
				className: CheckboxesElement_module_default.CheckboxesElementGroupDescription,
				children: /* @__PURE__ */ jsx(VerifiedHTMLBox, {
					html: descriptionHTML,
					className: "markdown-body note text-small mb-2"
				})
			}),
			checkboxOptions.map((option_1, checkboxIndex_1) => /* @__PURE__ */ jsxs(FormControl$1, {
				required: option_1.required ?? false,
				children: [/* @__PURE__ */ jsx(Checkbox, {
					ref: checkboxIndex_1 === 0 ? firstCheckboxRef : void 0,
					checked: selectedItems[checkboxIndex_1],
					onChange: () => {
						setSelectedItems(selectedItems.map((item_0, index_2) => index_2 === checkboxIndex_1 ? !item_0 : item_0));
					}
				}), /* @__PURE__ */ jsx(FormControl$1.Label, {
					className: CheckboxesElement_module_default.checkboxOptionLabel,
					children: /* @__PURE__ */ jsx(VerifiedHTMLText, { html: option_1.labelHTML })
				})]
			}, checkboxIndex_1)),
			validationResult && /* @__PURE__ */ jsx(CheckboxGroup_default.Validation, {
				variant: "error",
				children: validationResult
			})
		]
	});
};
CheckboxesElementInternal.displayName = "CheckboxesElementInternal";
CheckboxesElement.displayName = "CheckboxesElement";
CheckboxesElementInternal.displayName = "CheckboxesElementInternal";
var node$70 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "DropdownElement_input",
	"selections": [
		{
			"alias": "itemId",
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "label",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "descriptionHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "options",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "required",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "multiple",
			"storageKey": null
		},
		{
			"alias": "defaultOptionIndex",
			"args": null,
			"kind": "ScalarField",
			"name": "default",
			"storageKey": null
		},
		{
			"kind": "ClientExtension",
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__id",
				"storageKey": null
			}]
		}
	],
	"type": "IssueFormElementDropdown",
	"abstractKey": null
};
node$70.hash = "c5f5c78821adbd1825aa041b7a1063bf";
var DropdownElement_module_default = {
	dropdownElementButtonText: "DropdownElement-module_H0sWta_dropdownElementButtonText",
	dropdownElementContainer: "DropdownElement-module_H0sWta_dropdownElementContainer",
	dropdownMenuOverlay: "DropdownElement-module_H0sWta_dropdownMenuOverlay"
};
var ElementWrapper_module_default = {
	elementDescription: "ElementWrapper-module_SSKOdq_elementDescription",
	elementLabel: "ElementWrapper-module_SSKOdq_elementLabel",
	elementLabelWithDescription: "ElementWrapper-module_SSKOdq_elementLabelWithDescription",
	elementWrapperContainer: "ElementWrapper-module_SSKOdq_elementWrapperContainer",
	validationMessage: "ElementWrapper-module_SSKOdq_validationMessage"
};
function ElementWrapper(t0) {
	const $ = c(10);
	const { children, label, required, description, validationResult, className } = t0;
	const labelId = useId();
	const descriptionId = useId();
	const validationId = useId();
	let t1;
	if ($[0] !== children || $[1] !== className || $[2] !== description || $[3] !== descriptionId || $[4] !== label || $[5] !== labelId || $[6] !== required || $[7] !== validationId || $[8] !== validationResult) {
		t1 = jsxs("div", {
			className: clsx(ElementWrapper_module_default.elementWrapperContainer, className),
			children: [
				jsxs(FormControl$1, {
					required: required ?? false,
					children: [jsx(FormControl$1.Label, {
						id: labelId,
						className: clsx(ElementWrapper_module_default.elementLabel, description && ElementWrapper_module_default.elementLabelWithDescription),
						children: label
					}), description && jsx(FormControl$1.Caption, {
						id: descriptionId,
						className: ElementWrapper_module_default.elementDescription,
						children: jsx(VerifiedHTMLBox, {
							html: description,
							className: "markdown-body note text-small mb-2"
						})
					})]
				}),
				children({
					labelId,
					descriptionIds: `${descriptionId} ${validationId}`
				}),
				validationResult && jsx(FormControl$1.Validation, {
					id: validationId,
					variant: "error",
					className: ElementWrapper_module_default.validationMessage,
					children: validationResult
				})
			]
		});
		$[0] = children;
		$[1] = className;
		$[2] = description;
		$[3] = descriptionId;
		$[4] = label;
		$[5] = labelId;
		$[6] = required;
		$[7] = validationId;
		$[8] = validationResult;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
ElementWrapper.displayName = "ElementWrapper";
var DEFAULT_CHOICE = "None";
/**
* Parses a comma-separated string where each value is quoted and internal quotes are escaped with backslash.
* Uses JSON.parse() for robust parsing by converting to a proper JSON array format.
* Example: "\"Value 1\", \"Value with \\\"quotes\\\" and, comma\", \"Value 3\"" -> ["Value 1", "Value with \"quotes\" and, comma", "Value 3"]
* The format is defined by prompt in SkillWithIssueForms skill in CAPI
*/
function parseModelDropdownValues(valuesString) {
	if (!valuesString.trim()) return [];
	try {
		const jsonString = `[${valuesString}]`;
		return JSON.parse(jsonString);
	} catch {
		return [];
	}
}
/**
* Escapes values for JSON-like format by quoting values and escaping internal backslashes and quotes.
* Example: ["Value 1", "Value with \"quotes\" and, comma", "Path\\to\\file"] -> "\"Value 1\", \"Value with \\\"quotes\\\" and, comma\", \"Path\\\\to\\\\file\""
*/
function escapeDropdownValues(values) {
	return values.map((value) => {
		return `"${value.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
	}).join(", ");
}
/**
* Extracts default values from defaultValuesById and filters them against valid option choices.
* Returns an array of valid option strings ordered by their position in optionChoices.
*/
function getValidDefaultChoices({ itemId, indexOfFormElement, defaultValuesById, optionChoices }) {
	if (!itemId) return [];
	const defaultValueString = safeGetDefaultValue({
		id: itemId,
		indexOfFormElement,
		value: "",
		defaultValuesById
	});
	const defaultValues = new Set(parseModelDropdownValues(defaultValueString));
	return optionChoices.filter((choice) => defaultValues.has(choice));
}
var DropdownElement = ({ ref, elementRef, index, sessionStorageKey, defaultValuesById, onFieldChange }) => {
	const data = (0, import_react_relay.useFragment)(node$70, elementRef);
	if (!data.options) return null;
	const elementStorageKey = uniqueIdForElementInternal(sessionStorageKey, "", data.label, data.__id);
	return /* @__PURE__ */ jsx(DropdownElementInternal, {
		...data,
		index,
		ref,
		type: "dropdown",
		sessionStorageKey: elementStorageKey,
		defaultValuesById,
		onFieldChange
	});
};
DropdownElement.displayName = "DropdownElement";
var DropdownElementInternal = ({ ref, itemId, index: indexOfFormElement, sessionStorageKey, label, options, descriptionHTML, required, multiple, defaultOptionIndex, defaultValuesById, onFieldChange }) => {
	const anchorRef = useRef(null);
	const buttonTextRef = useRef(null);
	const hasDefaultValue = defaultOptionIndex !== void 0 && defaultOptionIndex !== null;
	const optionChoices = useMemo(() => multiple || required || hasDefaultValue ? options : [DEFAULT_CHOICE, ...options], [
		hasDefaultValue,
		multiple,
		options,
		required
	]);
	const defaultSelectionValue = useMemo(() => {
		let defaultSelection = getValidDefaultChoices({
			itemId,
			indexOfFormElement,
			defaultValuesById,
			optionChoices
		});
		if (defaultSelection.length === 0 && hasDefaultValue && defaultOptionIndex >= 0 && defaultOptionIndex < optionChoices.length) return [optionChoices[defaultOptionIndex]];
		if (defaultSelection.length === 0 && optionChoices.length > 0 && !multiple) defaultSelection = [optionChoices[0]];
		return defaultSelection;
	}, [
		defaultOptionIndex,
		defaultValuesById,
		hasDefaultValue,
		indexOfFormElement,
		itemId,
		multiple,
		optionChoices
	]);
	const [selectedItems, setSelectedItems] = useSessionStorage(sessionStorageKey, defaultSelectionValue);
	const latestSelectedItemsRef = useRef(selectedItems);
	useEffect(() => {
		latestSelectedItemsRef.current = selectedItems;
	}, [selectedItems]);
	useEffect(() => {
		const hasDefaultValues = defaultValuesById && Object.keys(defaultValuesById).length > 0;
		if (onFieldChange && hasDefaultValues) {
			const defaultSelection_0 = getValidDefaultChoices({
				itemId,
				indexOfFormElement,
				defaultValuesById,
				optionChoices
			});
			setSelectedItems(defaultSelection_0);
			latestSelectedItemsRef.current = defaultSelection_0;
		}
	}, [
		defaultValuesById,
		indexOfFormElement,
		itemId,
		optionChoices,
		setSelectedItems,
		onFieldChange
	]);
	useEffect(() => {
		if (onFieldChange) {
			const selectedItemsArray = latestSelectedItemsRef.current;
			const defaultValuesArray = getValidDefaultChoices({
				itemId,
				indexOfFormElement,
				defaultValuesById,
				optionChoices
			});
			const selectedItemsSet = new Set(selectedItemsArray);
			const defaultValuesSet = new Set(defaultValuesArray);
			if (!(selectedItemsSet.size === defaultValuesSet.size && [...selectedItemsSet].every((item) => defaultValuesSet.has(item)))) onFieldChange(itemId, indexOfFormElement, escapeDropdownValues(selectedItemsArray));
		}
	}, [
		selectedItems,
		itemId,
		indexOfFormElement,
		onFieldChange,
		defaultValuesById,
		optionChoices
	]);
	const [validationResult, setValidationResult] = useState(void 0);
	const toggleSelection = useCallback((option) => () => {
		if (selectedItems.includes(option)) {
			if (multiple) setSelectedItems(selectedItems.filter((item_0) => item_0 !== option));
		} else if (multiple) setSelectedItems([...selectedItems, option]);
		else setSelectedItems([option]);
	}, [
		multiple,
		selectedItems,
		setSelectedItems
	]);
	useImperativeHandle(ref, () => ({
		focus: () => anchorRef.current?.focus(),
		markdown: () => prefixMarkdownTitle(label, selectedItems.join(", ")),
		validate: () => {
			if (required && selectedItems.length === 0) {
				setValidationResult(VALIDATORS.missingDropdownSelection);
				return false;
			}
			return true;
		},
		reset: () => {
			setSelectedItems(defaultSelectionValue);
			setValidationResult(void 0);
		},
		hasChanges: () => {
			if (selectedItems.length !== defaultSelectionValue.length) return true;
			for (const item_1 of selectedItems) if (!defaultSelectionValue.includes(item_1)) return true;
			return false;
		},
		getSessionStorageKey: () => sessionStorageKey,
		type: "dropdown"
	}), [
		defaultSelectionValue,
		label,
		required,
		selectedItems,
		sessionStorageKey,
		setSelectedItems
	]);
	useEffect(() => {
		if (selectedItems.length > 0) setValidationResult(void 0);
	}, [selectedItems]);
	const [isTruncated, setIsTruncated] = useState(false);
	const buttonText = selectedItems.length === 0 ? "None" : selectedItems.join(", ");
	useEffect(() => {
		if (!buttonTextRef.current) return;
		setIsTruncated(buttonTextRef.current.scrollWidth > buttonTextRef.current.clientWidth);
	}, [buttonTextRef, setIsTruncated]);
	return /* @__PURE__ */ jsx(ElementWrapper, {
		label,
		description: descriptionHTML,
		required,
		validationResult,
		className: DropdownElement_module_default.dropdownElementContainer,
		children: ({ labelId, descriptionIds }) => /* @__PURE__ */ jsxs(ActionMenu, {
			anchorRef,
			children: [isTruncated ? /* @__PURE__ */ jsx(Tooltip$1, {
				text: buttonText,
				children: /* @__PURE__ */ jsx(ActionMenu.Button, {
					"aria-labelledby": labelId,
					"aria-describedby": descriptionIds,
					children: /* @__PURE__ */ jsx("span", {
						ref: buttonTextRef,
						className: DropdownElement_module_default.dropdownElementButtonText,
						children: buttonText
					})
				})
			}) : /* @__PURE__ */ jsxs(ActionMenu.Button, {
				"aria-labelledby": labelId,
				"aria-describedby": descriptionIds,
				children: [" ", /* @__PURE__ */ jsx("span", {
					ref: buttonTextRef,
					className: DropdownElement_module_default.dropdownElementButtonText,
					children: buttonText
				})]
			}), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "medium",
				side: "outside-top",
				maxHeight: "medium",
				className: DropdownElement_module_default.dropdownMenuOverlay,
				children: /* @__PURE__ */ jsx(ActionList, {
					selectionVariant: multiple ? "multiple" : "single",
					children: optionChoices.map((option_0, index) => /* @__PURE__ */ jsx(ActionList.Item, {
						selected: selectedItems.includes(option_0),
						onSelect: toggleSelection(option_0),
						children: option_0
					}, index))
				})
			})]
		})
	});
};
DropdownElementInternal.displayName = "DropdownElementInternal";
DropdownElement.displayName = "DropdownElement";
DropdownElementInternal.displayName = "DropdownElementInternal";
var node$69 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "MarkdownElement_input",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "contentHTML",
		"storageKey": null
	}],
	"type": "IssueFormElementMarkdown",
	"abstractKey": null
};
node$69.hash = "bcf5223d492443ecf5db4594632948d9";
var IssuesLoadingSkeleton_module_default = { container: "IssuesLoadingSkeleton-module_7pjNWq_container" };
var sizeMap = {
	sm: 16,
	md: 20,
	lg: 24,
	xl: 32
};
var borderRadiusMap = {
	rounded: "3px",
	pill: "100px",
	elliptical: "50%"
};
var getRandomWidth = () => {
	return `${Math.floor(Math.random() * 40 + 40)}%`;
};
var IssuesLoadingSkeleton = (t0) => {
	const $ = c(7);
	const { height, width, borderRadius: t1 } = t0;
	const borderRadius = t1 === void 0 ? "rounded" : t1;
	const [randomWidth, setRandomWidth] = useState("100%");
	let t2;
	let t3;
	if ($[0] !== width) {
		t2 = () => {
			if (width === "random") setRandomWidth(getRandomWidth());
		};
		t3 = [width];
		$[0] = width;
		$[1] = t2;
		$[2] = t3;
	} else {
		t2 = $[1];
		t3 = $[2];
	}
	useEffect(t2, t3);
	const calculatedHeight = typeof height === "string" && height in sizeMap ? `${sizeMap[height]}px` : height;
	const calculatedWidth = width === "random" ? randomWidth : typeof width === "string" && width in sizeMap ? `${sizeMap[width]}px` : width;
	const calculatedBorderRadius = typeof borderRadius === "string" && borderRadius in borderRadiusMap ? borderRadiusMap[borderRadius] : borderRadius;
	let t4;
	if ($[3] !== calculatedBorderRadius || $[4] !== calculatedHeight || $[5] !== calculatedWidth) {
		t4 = jsx(SkeletonBox, {
			"data-testid": "issues-loading-skeleton",
			className: IssuesLoadingSkeleton_module_default.container,
			style: {
				width: calculatedWidth,
				height: calculatedHeight,
				borderRadius: calculatedBorderRadius
			}
		});
		$[3] = calculatedBorderRadius;
		$[4] = calculatedHeight;
		$[5] = calculatedWidth;
		$[6] = t4;
	} else t4 = $[6];
	return t4;
};
IssuesLoadingSkeleton.displayName = "IssuesLoadingSkeleton";
var FormElementLoading_module_default = { loadingSkeletonContainer: "FormElementLoading-module_8GAvRa_loadingSkeletonContainer" };
var FormElementLoading = () => {
	return /* @__PURE__ */ jsx("div", {
		className: FormElementLoading_module_default.loadingSkeletonContainer,
		children: /* @__PURE__ */ jsx(IssuesLoadingSkeleton, {
			borderRadius: "pill",
			height: "lg",
			width: "400px"
		})
	});
};
FormElementLoading.displayName = "FormElementLoading";
var MarkdownElement = (t0) => {
	const $ = c(2);
	const { elementRef } = t0;
	const data = (0, import_react_relay.useFragment)(node$69, elementRef);
	let t1;
	if ($[0] !== data.contentHTML) {
		t1 = jsx(MarkdownElementInternal, {
			verifiedHTML: data.contentHTML,
			type: "markdown"
		});
		$[0] = data.contentHTML;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
};
MarkdownElement.displayName = "MarkdownElement";
var MarkdownElementInternal = ({ verifiedHTML }) => {
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: /* @__PURE__ */ jsx(FormElementLoading, {}),
		children: /* @__PURE__ */ jsx(MarkdownViewer, { verifiedHTML })
	});
};
MarkdownElementInternal.displayName = "MarkdownElementInternal";
var node$68 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TextAreaElement_input",
	"selections": [
		{
			"alias": "itemId",
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "label",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "descriptionHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "placeholder",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "value",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "required",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "render",
			"storageKey": null
		},
		{
			"kind": "ClientExtension",
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__id",
				"storageKey": null
			}]
		}
	],
	"type": "IssueFormElementTextarea",
	"abstractKey": null
};
node$68.hash = "77263c4a3e8e6f76c8ddc25b88931e27";
var TextAreaElement_module_default = {
	codeViewTextArea: "TextAreaElement-module_HzrQ-q_codeViewTextArea",
	TextAreaElementContainer: "TextAreaElement-module_HzrQ-q_TextAreaElementContainer"
};
var DEBOUNCE_TIMEOUT_MS$1 = 500;
var TextAreaElement = ({ ref, elementRef, index, sessionStorageKey, ...props }) => {
	const data = (0, import_react_relay.useFragment)(node$68, elementRef);
	const elementStorageKey = uniqueIdForElementInternal(sessionStorageKey, "", data.label, data.__id);
	return /* @__PURE__ */ jsx(TextAreaElementInternal, {
		...data,
		...props,
		index,
		ref,
		type: "textarea",
		sessionStorageKey: elementStorageKey
	});
};
TextAreaElement.displayName = "TextAreaElement";
var TextAreaElementInternal = ({ ref, itemId, sessionStorageKey, index: indexOfFormElement, label, descriptionHTML, placeholder, required, value: templateDefaultValue, render, subject, defaultValuesById, onSave, setIsFileUploading, onFieldChange }) => {
	const defaultValue = useMemo(() => safeGetDefaultValue({
		id: itemId,
		indexOfFormElement,
		value: templateDefaultValue,
		defaultValuesById
	}), [
		itemId,
		indexOfFormElement,
		templateDefaultValue,
		defaultValuesById
	]);
	const [textValue, setValue] = useSessionStorage(sessionStorageKey, defaultValue);
	const [isUserTyping, setIsUserTyping] = useState(false);
	const timeoutRef = useRef(null);
	useEffect(() => {
		const hasDefaultValues = defaultValuesById && Object.keys(defaultValuesById).length > 0;
		if (onFieldChange && hasDefaultValues && !isUserTyping) {
			const newDefaultValue = safeGetDefaultValue({
				id: itemId,
				indexOfFormElement,
				value: templateDefaultValue,
				defaultValuesById
			});
			if (newDefaultValue !== textValue && newDefaultValue !== (templateDefaultValue ?? "")) setValue(newDefaultValue);
		}
	}, [
		defaultValuesById,
		indexOfFormElement,
		itemId,
		setValue,
		templateDefaultValue,
		isUserTyping,
		textValue,
		onFieldChange
	]);
	const handleTextChange = (value) => {
		setIsUserTyping(true);
		setValue(value);
		if (onFieldChange) onFieldChange(itemId, indexOfFormElement, value);
		if (timeoutRef.current) clearTimeout(timeoutRef.current);
		timeoutRef.current = setTimeout(() => {
			setIsUserTyping(false);
			timeoutRef.current = null;
		}, DEBOUNCE_TIMEOUT_MS$1);
	};
	const textAreaCommentBoxRef = useRef(null);
	const [validationResult, setValidationResult] = useState(void 0);
	useImperativeHandle(ref, () => ({
		focus: () => textAreaCommentBoxRef.current?.focus(),
		markdown: () => prefixMarkdownTitle(label, prefixMarkdownTextArea(textValue, render)),
		validate: () => {
			const validity = validateTextField(textValue, required ?? false);
			setValidationResult(validity.errorMessage);
			return validity.isValid;
		},
		reset: () => {
			setValue(defaultValue);
			setValidationResult(void 0);
		},
		hasChanges: () => textValue !== defaultValue,
		getSessionStorageKey: () => sessionStorageKey,
		type: "textarea"
	}), [
		defaultValue,
		label,
		render,
		required,
		sessionStorageKey,
		setValue,
		textValue
	]);
	useEffect(() => {
		if (validationResult && validateTextField(textValue, required ?? false).isValid) setValidationResult(void 0);
	}, [
		required,
		textValue,
		validationResult
	]);
	return /* @__PURE__ */ jsx(ElementWrapper, {
		label,
		required,
		description: descriptionHTML,
		validationResult,
		className: TextAreaElement_module_default.TextAreaElementContainer,
		children: ({ labelId, descriptionIds }) => render ? /* @__PURE__ */ jsx(Textarea, {
			"aria-labelledby": labelId,
			"aria-describedby": descriptionIds,
			ref: textAreaCommentBoxRef,
			placeholder: placeholder ?? void 0,
			value: textValue,
			className: TextAreaElement_module_default.codeViewTextArea,
			onChange: (e) => {
				handleTextChange(e.target.value);
			}
		}) : /* @__PURE__ */ jsx(CommentBox, {
			labelledBy: labelId,
			"aria-describedby": descriptionIds,
			ref: textAreaCommentBoxRef,
			placeholder: placeholder ?? void 0,
			value: textValue,
			onChange: (e_0) => {
				handleTextChange(e_0);
			},
			onSave,
			saveButtonTrailingIcon: false,
			subject,
			setIsFileUploading
		})
	});
};
TextAreaElementInternal.displayName = "TextAreaElementInternal";
TextAreaElement.displayName = "TextAreaElement";
TextAreaElementInternal.displayName = "TextAreaElementInternal";
var node$67 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TextInputElement_input",
	"selections": [
		{
			"alias": "itemId",
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "label",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "descriptionHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "placeholder",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "value",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "required",
			"storageKey": null
		},
		{
			"kind": "ClientExtension",
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__id",
				"storageKey": null
			}]
		}
	],
	"type": "IssueFormElementInput",
	"abstractKey": null
};
node$67.hash = "20ef068a2834313afaaf43e8b01d0d49";
var TextInputElement_module_default = { issueFormTextField: "TextInputElement-module_Vef_WG_issueFormTextField" };
var DEBOUNCE_TIMEOUT_MS = 500;
var TextInputElement = ({ ref, elementRef, sessionStorageKey, ...props }) => {
	const data = (0, import_react_relay.useFragment)(node$67, elementRef);
	const elementStorageKey = uniqueIdForElementInternal(sessionStorageKey, "", data.label, data.__id);
	return /* @__PURE__ */ jsx(TextInputElementInternal, {
		...data,
		...props,
		type: "input",
		sessionStorageKey: elementStorageKey,
		ref
	});
};
TextInputElement.displayName = "TextInputElement";
var TextInputElementInternal = ({ ref, sessionStorageKey, itemId, index: indexOfFormElement, label, descriptionHTML, placeholder, required, value: templateDefaultValue, defaultValuesById, onFieldChange }) => {
	const defaultValue = useMemo(() => safeGetDefaultValue({
		id: itemId,
		indexOfFormElement,
		value: templateDefaultValue,
		defaultValuesById
	}), [
		itemId,
		indexOfFormElement,
		templateDefaultValue,
		defaultValuesById
	]);
	const [textValue, setValue] = useSessionStorage(sessionStorageKey, defaultValue);
	const [isUserTyping, setIsUserTyping] = useState(false);
	const timeoutRef = useRef(null);
	useEffect(() => {
		const hasDefaultValues = defaultValuesById && Object.keys(defaultValuesById).length > 0;
		if (onFieldChange && hasDefaultValues && !isUserTyping) {
			const newDefaultValue = safeGetDefaultValue({
				id: itemId,
				indexOfFormElement,
				value: templateDefaultValue,
				defaultValuesById
			});
			if (newDefaultValue !== textValue && newDefaultValue !== (templateDefaultValue ?? "")) setValue(newDefaultValue);
		}
	}, [
		defaultValuesById,
		indexOfFormElement,
		isUserTyping,
		itemId,
		onFieldChange,
		setValue,
		templateDefaultValue,
		textValue
	]);
	const handleTextChange = (value) => {
		setIsUserTyping(true);
		setValue(value);
		if (onFieldChange) onFieldChange(itemId, indexOfFormElement, value);
		if (timeoutRef.current) clearTimeout(timeoutRef.current);
		timeoutRef.current = setTimeout(() => {
			setIsUserTyping(false);
			timeoutRef.current = null;
		}, DEBOUNCE_TIMEOUT_MS);
	};
	const inputRef = useRef(null);
	const [validationResult, setValidationResult] = useState(void 0);
	useImperativeHandle(ref, () => ({
		focus: () => inputRef.current?.focus(),
		markdown: () => prefixMarkdownTitle(label, textValue),
		validate: () => {
			const validity = validateTextField(textValue, required ?? false);
			setValidationResult(validity.errorMessage);
			return validity.isValid;
		},
		reset: () => {
			setValue(defaultValue);
			setValidationResult(void 0);
		},
		hasChanges: () => textValue !== defaultValue,
		getSessionStorageKey: () => sessionStorageKey,
		type: "input"
	}), [
		defaultValue,
		label,
		required,
		sessionStorageKey,
		setValue,
		textValue
	]);
	useEffect(() => {
		if (validationResult && validateTextField(textValue, required ?? false).isValid) setValidationResult(void 0);
	}, [
		required,
		textValue,
		validationResult
	]);
	return /* @__PURE__ */ jsx(ElementWrapper, {
		label,
		description: descriptionHTML,
		required,
		validationResult,
		children: ({ labelId, descriptionIds }) => /* @__PURE__ */ jsx(TextInput$1, {
			ref: inputRef,
			"aria-labelledby": labelId,
			"aria-describedby": descriptionIds,
			placeholder: placeholder ?? void 0,
			value: textValue,
			className: TextInputElement_module_default.issueFormTextField,
			onChange: (e) => {
				handleTextChange(e.target.value);
			}
		})
	});
};
TextInputElementInternal.displayName = "TextInputElementInternal";
TextInputElement.displayName = "TextInputElement";
TextInputElementInternal.displayName = "TextInputElementInternal";
var node$66 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "UploadElement_input",
	"selections": [
		{
			"alias": "itemId",
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "label",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "descriptionHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "required",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "accept",
			"storageKey": null
		},
		{
			"kind": "ClientExtension",
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__id",
				"storageKey": null
			}]
		}
	],
	"type": "IssueFormElementUpload",
	"abstractKey": null
};
node$66.hash = "ad08997c0d69269d2c83ec8f902a466c";
var UploadElement_module_default = {
	errorMessage: "UploadElement-module_hE5UwW_errorMessage",
	list: "UploadElement-module_hE5UwW_list",
	listItem: "UploadElement-module_hE5UwW_listItem",
	pasteButton: "UploadElement-module_hE5UwW_pasteButton",
	toggleButton: "UploadElement-module_hE5UwW_toggleButton",
	uploadingMessage: "UploadElement-module_hE5UwW_uploadingMessage"
};
function UploadFileListItem({ state, index, onRemoveFile }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		className: UploadElement_module_default.listItem,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(FileIcon, {}) }),
			state.url ? /* @__PURE__ */ jsx("a", {
				href: state.url,
				target: "_blank",
				rel: "noreferrer",
				children: state.file.name
			}) : /* @__PURE__ */ jsx("span", { children: state.file.name }),
			/* @__PURE__ */ jsx(ActionList.TrailingAction, {
				onClick: () => onRemoveFile(index),
				label: `Remove ${state.file.name}`,
				icon: XIcon
			})
		]
	});
}
UploadFileListItem.displayName = "UploadFileListItem";
function UploadFileList(t0) {
	const $ = c(8);
	const { uploadStates, onRemoveFile } = t0;
	const [showAllFiles, setShowAllFiles] = useState(false);
	const listId = useId();
	if (uploadStates.length === 0) return null;
	const hasMoreThanThreeFiles = uploadStates.length > 3;
	let t1;
	if ($[0] !== hasMoreThanThreeFiles || $[1] !== listId || $[2] !== onRemoveFile || $[3] !== showAllFiles || $[4] !== uploadStates) {
		const displayedStates = showAllFiles ? uploadStates : uploadStates.slice(0, 3);
		let t2;
		if ($[6] !== onRemoveFile) {
			t2 = (state, index) => jsx(UploadFileListItem, {
				state,
				index,
				onRemoveFile
			}, index);
			$[6] = onRemoveFile;
			$[7] = t2;
		} else t2 = $[7];
		t1 = jsxs(Fragment$1, { children: [jsx(ActionList, {
			className: UploadElement_module_default.list,
			id: listId,
			children: displayedStates.map(t2)
		}), hasMoreThanThreeFiles && jsxs(Link, {
			as: "button",
			type: "button",
			onClick: () => {
				setShowAllFiles(_temp$27);
			},
			className: UploadElement_module_default.toggleButton,
			"aria-expanded": showAllFiles,
			"aria-controls": listId,
			children: [jsx("span", { children: showAllFiles ? "View less" : `View ${uploadStates.length - 3} more` }), jsx("span", { children: showAllFiles ? jsx(ChevronUpIcon, {}) : jsx(ChevronDownIcon, {}) })]
		})] });
		$[0] = hasMoreThanThreeFiles;
		$[1] = listId;
		$[2] = onRemoveFile;
		$[3] = showAllFiles;
		$[4] = uploadStates;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
UploadFileList.displayName = "UploadFileList";
function _temp$27(previous) {
	return !previous;
}
/**
* Parses a comma-separated list of file extensions and filters them against the global accepted file types.
* @param accept - Comma-separated list of file extensions (e.g., ".png,.log,.webm")
* @param globalAcceptedTypes - Array of globally accepted file types from acceptedFileTypes(true)
* @returns Filtered array of accepted file types, or the global list if no valid extensions are found
*/
function parseAndFilterAcceptedFileTypes(accept, globalAcceptedTypes) {
	if (!accept || accept.trim() === "") return globalAcceptedTypes;
	const filteredExtensions = accept.split(",").map((ext) => ext.trim()).filter((ext) => ext.length > 0).map((ext) => ext.startsWith(".") ? ext : `.${ext}`).filter((ext) => globalAcceptedTypes.includes(ext));
	return filteredExtensions.length > 0 ? filteredExtensions : globalAcceptedTypes;
}
var UploadElement = ({ ref, elementRef, sessionStorageKey, ...props }) => {
	const data = (0, import_react_relay.useFragment)(node$66, elementRef);
	const elementStorageKey = uniqueIdForElementInternal(sessionStorageKey, "", data.label, data.__id);
	return /* @__PURE__ */ jsx(UploadElementInternal, {
		...data,
		...props,
		type: "upload",
		sessionStorageKey: elementStorageKey,
		ref
	});
};
UploadElement.displayName = "UploadElement";
var UploadElementInternal = ({ ref, label, descriptionHTML, required, itemId, subject, index: indexOfFormElement, sessionStorageKey, onFieldChange, accept }) => {
	const [uploadStatesStorage, setUploadStatesStorage] = useSessionStorage(sessionStorageKey, []);
	const [uploadStates, setUploadStates] = useState(() => {
		return (Array.isArray(uploadStatesStorage) ? uploadStatesStorage : []).map((stored) => ({
			file: new File([new Uint8Array(stored.fileSize)], stored.fileName, { type: "application/octet-stream" }),
			url: stored.url
		}));
	});
	const [validationResult, setValidationResult] = useState(void 0);
	const [uploadingCount, setUploadingCount] = useState(0);
	const [uploadError, setUploadError] = useState(void 0);
	const textValue = uploadStates.filter((state) => state.url).map((state_0) => `[${state_0.file.name}](${state_0.url})`).join("\n");
	const inputRef = useRef(null);
	const onUploadFile = useUploadFile(subject.repository.databaseId.toString());
	const filteredAcceptedTypes = parseAndFilterAcceptedFileTypes(accept, acceptedFileTypes(true));
	const isPasteEnabled = isFeatureEnabled("issue_form_upload_field_paste");
	const { clickTargetProps, pasteTargetProps, dropTargetProps } = useUnifiedFileSelect({
		multi: true,
		acceptedFileTypes: filteredAcceptedTypes,
		onSelect: useCallback(async (acceptedFiles, _rejectedFiles) => {
			if (acceptedFiles.length === 0) return;
			setUploadingCount((prev) => prev + acceptedFiles.length);
			setUploadError(void 0);
			for (const file of acceptedFiles) (async () => {
				try {
					const result = await onUploadFile(file);
					setUploadStates((prev_2) => {
						const updated = [...prev_2, {
							file,
							url: result.url
						}];
						const newTextValue = updated.filter((state_1) => state_1.url).map((state_2) => `[${state_2.file.name}](${state_2.url})`).join("\n");
						onFieldChange?.(itemId, indexOfFormElement, newTextValue);
						return updated;
					});
					setUploadingCount((prev_3) => prev_3 - 1);
				} catch {
					setUploadingCount((prev_0) => prev_0 - 1);
					setUploadError((prev_1) => prev_1 || "Failed to upload file. Please try again.");
				}
			})();
		}, [
			onUploadFile,
			setUploadStates,
			onFieldChange,
			itemId,
			indexOfFormElement
		])
	});
	const handleRemoveFile = useCallback((index) => {
		setUploadError(void 0);
		setUploadStates((prev_4) => {
			const updated_0 = prev_4.filter((_, i) => i !== index);
			const newTextValue_0 = updated_0.filter((state_3) => state_3.url).map((state_4) => `[${state_4.file.name}](${state_4.url})`).join("\n");
			onFieldChange?.(itemId, indexOfFormElement, newTextValue_0);
			return updated_0;
		});
	}, [
		onFieldChange,
		itemId,
		indexOfFormElement
	]);
	useEffect(() => {
		setUploadStatesStorage(uploadStates.filter((state_5) => state_5.url).map((state_6) => ({
			fileName: state_6.file.name,
			fileSize: state_6.file.size,
			url: state_6.url
		})));
	}, [uploadStates, setUploadStatesStorage]);
	useImperativeHandle(ref, () => ({
		focus: () => inputRef.current?.focus(),
		markdown: () => prefixMarkdownTitle(label, textValue),
		validate: () => {
			if (!required) return true;
			const hasCompletedUploads = uploadStates.some((uploadState) => Boolean(uploadState.url));
			const hasText = textValue.trim() !== "";
			if (!hasCompletedUploads && !hasText) {
				setValidationResult(VALIDATORS.fieldRequired);
				return false;
			}
			return true;
		},
		reset: () => {
			setUploadStates([]);
			setUploadStatesStorage([]);
			setValidationResult(void 0);
			setUploadError(void 0);
			onFieldChange?.(itemId, indexOfFormElement, "");
		},
		hasChanges: () => textValue !== "",
		getSessionStorageKey: () => sessionStorageKey,
		type: "upload"
	}), [
		label,
		required,
		sessionStorageKey,
		textValue,
		uploadStates,
		setUploadStates,
		setUploadStatesStorage,
		onFieldChange,
		itemId,
		indexOfFormElement
	]);
	useEffect(() => {
		if (validationResult) {
			const hasCompletedUploads_0 = uploadStates.some((uploadState_0) => Boolean(uploadState_0.url));
			const hasText_0 = textValue.trim() !== "";
			if (hasCompletedUploads_0 || hasText_0) setValidationResult(void 0);
		}
	}, [
		uploadStates,
		textValue,
		validationResult
	]);
	return /* @__PURE__ */ jsx(ElementWrapper, {
		label,
		description: descriptionHTML,
		required,
		validationResult,
		children: ({ labelId, descriptionIds }) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
			isPasteEnabled ? /* @__PURE__ */ jsx(ButtonComponent, {
				ref: inputRef,
				"aria-labelledby": labelId,
				"aria-describedby": descriptionIds,
				leadingVisual: UploadIcon,
				className: UploadElement_module_default.pasteButton,
				...clickTargetProps,
				...pasteTargetProps,
				...dropTargetProps,
				children: "Paste, drop, or click to add files"
			}) : /* @__PURE__ */ jsx(ButtonComponent, {
				ref: inputRef,
				"aria-labelledby": labelId,
				"aria-describedby": descriptionIds,
				leadingVisual: UploadIcon,
				...clickTargetProps,
				children: "Upload files"
			}),
			uploadingCount > 0 && /* @__PURE__ */ jsx("div", {
				className: UploadElement_module_default.uploadingMessage,
				"aria-live": "polite",
				children: `Uploading ${uploadingCount} ${uploadingCount === 1 ? "file" : "files"}...`
			}),
			/* @__PURE__ */ jsx(UploadFileList, {
				uploadStates,
				onRemoveFile: handleRemoveFile
			}),
			uploadError && /* @__PURE__ */ jsxs("div", {
				className: UploadElement_module_default.errorMessage,
				role: "alert",
				"aria-live": "assertive",
				children: [/* @__PURE__ */ jsx(AlertIcon, { "aria-hidden": "true" }), /* @__PURE__ */ jsx("span", { children: uploadError })]
			})
		] })
	});
};
UploadElementInternal.displayName = "UploadElementInternal";
var IssueFormElements_module_default = {
	formElementsContainer: "IssueFormElements-module_f3e8Fa_formElementsContainer",
	markdownElementWrapper: "IssueFormElements-module_f3e8Fa_markdownElementWrapper"
};
var IssueFormElementsTemplateElementsFragment = node$72;
var IssueFormElements = (props) => {
	if ("elements" in props) return /* @__PURE__ */ jsx(IssueFormElementsViaPayload, { ...props });
	else return /* @__PURE__ */ jsx(IssueFormElementsViaQuery, { ...props });
};
IssueFormElements.displayName = "IssueFormElements";
var IssueFormElementsViaPayload = (t0) => {
	const { elements, outputRef, sessionStorageKey, ...props } = t0;
	const inputRefs = useInputElementReferences(elements.length, outputRef);
	return jsx("div", {
		className: IssueFormElements_module_default.formElementsContainer,
		children: elements.map((element, index) => {
			const storageKey = createUniqueIdForElement(sessionStorageKey, element, index);
			switch (element.type) {
				case "markdown": return jsx(MarkdownElementInternal, { ...element }, index);
				case "textarea": return jsx(TextAreaElementInternal, {
					index,
					...element,
					ref: inputRefs[index],
					sessionStorageKey: storageKey,
					...props
				}, index);
				case "input": return jsx(TextInputElementInternal, {
					index,
					...element,
					ref: inputRefs[index],
					sessionStorageKey: storageKey,
					...props
				}, index);
				case "dropdown": return jsx(DropdownElementInternal, {
					index,
					...element,
					ref: inputRefs[index],
					sessionStorageKey: storageKey
				}, index);
				case "checkboxes": return jsx(CheckboxesElementInternal, {
					index,
					...element,
					ref: inputRefs[index],
					sessionStorageKey: storageKey
				}, index);
			}
		})
	});
};
IssueFormElementsViaPayload.displayName = "IssueFormElementsViaPayload";
var IssueFormElementsViaQuery = (t0) => {
	const { issueFormRef, outputRef, subject, ...props } = t0;
	const data = (0, import_react_relay.readInlineData)(IssueFormElementsTemplateElementsFragment, issueFormRef);
	const inputRefs = useInputElementReferences(data.elements.length, outputRef);
	const uploadFieldEnabled = useFeatureFlag("issue_form_upload_field");
	return jsx("div", {
		className: IssueFormElements_module_default.formElementsContainer,
		children: data.elements.map((element, index) => {
			switch (element.__typename) {
				case "IssueFormElementMarkdown": return jsx("div", {
					className: IssueFormElements_module_default.markdownElementWrapper,
					children: jsx(MarkdownElement, { elementRef: element })
				}, index);
				case "IssueFormElementUpload":
					if (uploadFieldEnabled && "repository" in subject && subject.repository) return jsx(UploadElement, {
						index,
						subject,
						elementRef: element,
						ref: inputRefs[index],
						...props
					}, index);
					return null;
				case "IssueFormElementInput": return jsx(TextInputElement, {
					index,
					elementRef: element,
					ref: inputRefs[index],
					...props
				}, index);
				case "IssueFormElementDropdown": return jsx(DropdownElement, {
					index,
					elementRef: element,
					ref: inputRefs[index],
					...props
				}, index);
				case "IssueFormElementTextarea": return jsx(TextAreaElement, {
					index,
					elementRef: element,
					subject,
					ref: inputRefs[index],
					...props
				}, index);
				case "IssueFormElementCheckboxes": return jsx(CheckboxesElement, {
					index,
					elementRef: element,
					ref: inputRefs[index],
					...props
				}, index);
				default: return null;
			}
		})
	});
};
IssueFormElementsViaQuery.displayName = "IssueFormElementsViaQuery";
var useInputElementReferences = (elementCount, outputRef) => {
	const $ = c(6);
	let t0;
	if ($[0] !== elementCount) {
		t0 = Array.from({ length: elementCount }, _temp$26);
		$[0] = elementCount;
		$[1] = t0;
	} else t0 = $[1];
	const inputRefs = t0;
	let t1;
	let t2;
	if ($[2] !== inputRefs || $[3] !== outputRef) {
		t1 = () => ({
			markdown: () => inputRefs.map(_temp2$14).filter(_temp3$13).join("\n\n"),
			getInvalidInputs: () => inputRefs.map(_temp4$9).filter(_temp5$5),
			validateInputs: () => !inputRefs.map(_temp6$3).some(_temp7$2),
			resetInputs: (t3) => {
				const { textOnly: t4 } = t3 === void 0 ? {} : t3;
				const textOnly = t4 === void 0 ? false : t4;
				for (const ref_3 of inputRefs) {
					if (!textOnly) {
						ref_3.current?.reset();
						continue;
					}
					if (ref_3.current?.type === "input" || ref_3.current?.type === "textarea" || ref_3.current?.type === "markdown") ref_3.current?.reset();
				}
				outputRef.current?.clearSessionStorage();
			},
			hasChanges: () => inputRefs.some(_temp8$2),
			clearSessionStorage: () => {
				clearSessionStorage(inputRefs.map(_temp9$2).filter(_temp0$1));
			}
		});
		t2 = [inputRefs, outputRef];
		$[2] = inputRefs;
		$[3] = outputRef;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useImperativeHandle(outputRef, t1, t2);
	return inputRefs;
};
function _temp$26() {
	return createRef();
}
function _temp2$14(ref) {
	return ref.current?.markdown() ?? "";
}
function _temp3$13(markdown) {
	return markdown.length > 0;
}
function _temp4$9(ref_0) {
	return ref_0.current;
}
function _temp5$5(ref_1) {
	return ref_1 !== null && !ref_1.validate();
}
function _temp6$3(ref_2) {
	return ref_2.current?.validate() ?? true;
}
function _temp7$2(isValid) {
	return !isValid;
}
function _temp8$2(ref_4) {
	return ref_4.current?.hasChanges() ?? false;
}
function _temp9$2(ref_5) {
	return ref_5.current?.getSessionStorageKey();
}
function _temp0$1(k) {
	return k !== null;
}
var DATE_FORMAT_OPTIONS = {
	year: "numeric",
	month: "short",
	day: "numeric",
	timeZone: "UTC"
};
function formatDateString(value, extraFormatOptions = {}) {
	return value.toLocaleDateString("en-us", {
		...DATE_FORMAT_OPTIONS,
		...extraFormatOptions
	});
}
function stripTimezone(isoString) {
	if (!isoString) return null;
	const dateMatch = isoString.match(/^(?<year>\d{4})-(?<month>\d{2})-(?<day>\d{2})/);
	if (!dateMatch?.groups) return null;
	const { year, month, day } = dateMatch.groups;
	if (!year || !month || !day) return null;
	const yearNum = parseInt(year, 10);
	const monthNum = parseInt(month, 10);
	const dayNum = parseInt(day, 10);
	if (isNaN(yearNum) || isNaN(monthNum) || isNaN(dayNum)) return null;
	if (monthNum < 1 || monthNum > 12) return null;
	if (dayNum < 1 || dayNum > 31) return null;
	const date = new Date(Date.UTC(yearNum, monthNum - 1, dayNum, 12, 0, 0, 0));
	return isNaN(date.getTime()) ? null : date;
}
function isTextField(field) {
	return field.dataType === "TEXT";
}
function isSingleSelectField(field) {
	return field.dataType === "SINGLE_SELECT";
}
function isDateField(field) {
	return field.dataType === "DATE";
}
function isNumberField(field) {
	return field.dataType === "NUMBER";
}
function areFieldValuesEqual(initialField, currentField) {
	if (initialField?.field?.id !== currentField?.field?.id) return false;
	if (!initialField?.field || !currentField?.field) return false;
	const fieldForTypeCheck = initialField.field;
	if (isTextField(fieldForTypeCheck) || isDateField(fieldForTypeCheck)) return initialField?.value === currentField?.value;
	if (isNumberField(fieldForTypeCheck)) return initialField?.numberValue === currentField?.numberValue;
	if (isSingleSelectField(fieldForTypeCheck)) return initialField?.name === currentField?.name;
	return true;
}
function getFieldChanges(initialValues, currentValues) {
	return {
		addedFields: currentValues.filter((fieldValue) => !initialValues.some((initialFieldValue) => initialFieldValue?.field?.id === fieldValue?.field?.id)),
		updatedFields: currentValues.filter((fieldValue) => initialValues.some((initialFieldValue) => initialFieldValue?.field?.id === fieldValue?.field?.id && !areFieldValuesEqual(initialFieldValue, fieldValue))),
		removedFields: initialValues.filter((initialFieldValue) => !currentValues.some((fv) => fv?.field?.id === initialFieldValue?.field?.id))
	};
}
function createClearedFieldValue(fieldValue) {
	if (!fieldValue || !fieldValue.field) return fieldValue;
	return toIssueFieldWithUnsavedValue(fieldValue.field, null);
}
function toIssueFieldWithUnsavedValue(selectedField, value) {
	const field = asIssueFieldSelection(selectedField);
	switch (field.dataType) {
		case "text": return {
			field: {
				...field,
				dataType: "TEXT"
			},
			value: value || ""
		};
		case "single_select": return {
			field: {
				...field,
				dataType: "SINGLE_SELECT"
			},
			value
		};
		case "date": return {
			field: {
				...field,
				dataType: "DATE"
			},
			value
		};
		case "number": return {
			field: {
				...field,
				dataType: "NUMBER"
			},
			value
		};
	}
}
function toIssueFieldWithValue(selectedField, value, readonly) {
	const field = asIssueFieldSelection(selectedField);
	switch (field.dataType) {
		case "text": return {
			field: {
				...field,
				dataType: "TEXT"
			},
			value,
			readonly
		};
		case "single_select": return {
			field: {
				...field,
				dataType: "SINGLE_SELECT"
			},
			value,
			readonly
		};
		case "date": return {
			field: {
				...field,
				dataType: "DATE"
			},
			value,
			readonly
		};
		case "number": {
			if (value === null || value === "") return {
				field: {
					...field,
					dataType: "NUMBER"
				},
				value: null,
				readonly
			};
			const number = Number(value);
			return {
				field: {
					...field,
					dataType: "NUMBER"
				},
				value: isNaN(number) ? 0 : number,
				readonly
			};
		}
	}
}
function getIssueFieldSelectionValue(fieldType, value) {
	switch (fieldType) {
		case "text": return value;
		case "single_select": {
			const singleSelectOption = value;
			return singleSelectOption && !!singleSelectOption.id ? String(singleSelectOption.id) : void 0;
		}
		case "date": return formatDateForStorage(value) || void 0;
		case "number": return value?.toString();
	}
}
function getIssueFieldSelectionPresentationValue(fieldType, value) {
	if (fieldType === "single_select") {
		const singleSelectOption = value;
		return singleSelectOption && !!singleSelectOption.name ? String(singleSelectOption.name) : void 0;
	} else if (fieldType === "date") {
		const formatted = formatDateForStorage(value);
		const dateValue = formatted ? stripTimezone(formatted) : null;
		return dateValue ? formatDateString(dateValue) : void 0;
	}
	return getIssueFieldSelectionValue(fieldType, value);
}
function formatDateForStorage(date) {
	if (!date) return null;
	return date.toISOString();
}
function parseIssueFieldValues(nodes) {
	return nodes.flatMap((node) => {
		if (!node?.field?.id || !node.field.name || !node.field.dataType) return [];
		const fieldType = toIssueFieldType(node.field.dataType);
		let value = null;
		switch (fieldType) {
			case "text":
				value = node.value ?? "";
				break;
			case "single_select": {
				const selectedName = node.singleSelectName ?? node.name;
				if (selectedName && node.optionId && node.color) value = {
					id: node.optionId,
					name: selectedName,
					description: node.description ?? null,
					color: node.color
				};
				break;
			}
			case "date":
				if (node.value) value = new Date(node.value);
				break;
			case "number":
				if (node.numberValue != null) value = Number(node.numberValue);
				break;
		}
		if (value === null && fieldType !== "text") return [];
		return [toIssueFieldWithUnsavedValue({
			id: node.field.id,
			name: node.field.name,
			dataType: fieldType
		}, value)];
	});
}
var node$65 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "connections"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "closed",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanUpdate",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasReachedItemsLimit",
		"storageKey": null
	}, v9 = [{
		"kind": "Literal",
		"name": "name",
		"value": "Status"
	}], v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "optionId",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameHTML",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "color",
		"storageKey": null
	}, v15 = {
		"kind": "InlineFragment",
		"selections": [v2],
		"type": "Node",
		"abstractKey": "__isNode"
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueProjectsRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddProjectV2ItemByIdPayload",
				"kind": "LinkedField",
				"name": "addProjectV2ItemById",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2ItemEdge",
					"kind": "LinkedField",
					"name": "projectEdge",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "ProjectV2Item",
						"kind": "LinkedField",
						"name": "node",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "ProjectItemSection"
						}, {
							"alias": null,
							"args": null,
							"concreteType": "ProjectV2",
							"kind": "LinkedField",
							"name": "project",
							"plural": false,
							"selections": [
								v2,
								v3,
								v4,
								v5,
								v6,
								v7,
								v8
							],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueProjectsRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddProjectV2ItemByIdPayload",
				"kind": "LinkedField",
				"name": "addProjectV2ItemById",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2ItemEdge",
					"kind": "LinkedField",
					"name": "projectEdge",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "ProjectV2Item",
						"kind": "LinkedField",
						"name": "node",
						"plural": false,
						"selections": [
							v2,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isArchived",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "ProjectV2",
								"kind": "LinkedField",
								"name": "project",
								"plural": false,
								"selections": [
									v2,
									v3,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "template",
										"storageKey": null
									},
									v7,
									v6,
									{
										"alias": null,
										"args": v9,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "field",
										"plural": false,
										"selections": [
											v10,
											{
												"kind": "InlineFragment",
												"selections": [
													v2,
													v11,
													{
														"alias": null,
														"args": null,
														"concreteType": "ProjectV2SingleSelectFieldOption",
														"kind": "LinkedField",
														"name": "options",
														"plural": true,
														"selections": [
															v2,
															v12,
															v11,
															v13,
															v14,
															{
																"alias": null,
																"args": null,
																"kind": "ScalarField",
																"name": "descriptionHTML",
																"storageKey": null
															},
															{
																"alias": null,
																"args": null,
																"kind": "ScalarField",
																"name": "description",
																"storageKey": null
															}
														],
														"storageKey": null
													}
												],
												"type": "ProjectV2SingleSelectField",
												"abstractKey": null
											},
											v15
										],
										"storageKey": "field(name:\"Status\")"
									},
									v4,
									v5,
									v8
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": v9,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "fieldValueByName",
								"plural": false,
								"selections": [
									v10,
									{
										"kind": "InlineFragment",
										"selections": [
											v2,
											v12,
											v11,
											v13,
											v14
										],
										"type": "ProjectV2ItemFieldSingleSelectValue",
										"abstractKey": null
									},
									v15
								],
								"storageKey": "fieldValueByName(name:\"Status\")"
							}
						],
						"storageKey": null
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"filters": null,
					"handle": "appendEdge",
					"key": "",
					"kind": "LinkedHandle",
					"name": "projectEdge",
					"handleArgs": [{
						"kind": "Variable",
						"name": "connections",
						"variableName": "connections"
					}]
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "b9a688cdfd72ea1627e9e0c19b9b67f1",
			"metadata": {},
			"name": "updateIssueProjectsRelayMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$65.hash = "dbe2b16a81c1878c83467c6e3a8a0a7c";
function commitUpdateIssueProjectsMutation({ environment, connectionId, projectId, issueId, clientMutationId, onError, onCompleted }) {
	if (!projectId) return;
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$65,
		variables: {
			input: {
				contentId: issueId,
				projectId,
				clientMutationId
			},
			connections: connectionId ? [connectionId] : []
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var LABELS$2 = {
	issueCreateDialogTitleTemplatePane: (relationType = "issue") => `Create new ${relationType}`,
	issueCreateChooseDiffTemplate: "Choose a different template",
	issueCreateDialogTitleCreationPane: (repoNwo, templateName, relationType = "issue") => `Create new ${relationType} in ${repoNwo}${templateName ? `: ${templateName}` : ""}`,
	issueCreateDialogTitleDuplicationPane: (repoNwo, relationType = "issue") => `Duplicate current ${relationType} in ${repoNwo}`,
	issueCreateTitleLabel: "Add a title",
	issueCreateTitlePlaceholder: "Title",
	issueCreateBodyLabel: "Add a description",
	issueCreatedPrefix: "Issue created ",
	lastIssueCreated: (issueNumber) => `Issue #${issueNumber} created`,
	issuesDisabledForRepo: "Issues are disabled for the selected repository. Please select a different repository.",
	issueBodyPlaceholder: "Type your description here…",
	issueNumber: (issueNumber) => `#${issueNumber}`,
	blankIssueName: "Blank issue",
	blankIssueDescription: "Create a new issue from scratch",
	blankIssueMaintainerLabel: "Maintainers only",
	securityPolicyName: "Report a security vulnerability",
	securityPolicyDescription: "Please review our security policy for more details",
	editTemplates: "Edit templates",
	viewTemplates: "View templates",
	templatesFormsTitle: "Templates and forms",
	noTemplates: "No templates available for the current repository",
	discardConfirmation: {
		title: "Discard changes?",
		content: "You have unsaved changes. Are you sure you want to discard them?",
		confirm: "Close and discard",
		cancel: "Keep editing"
	},
	loadingTooltip: "Loading...",
	templateId: (template) => `template-item-${template}`,
	templateLabelId: (template) => `template-item-${template}-label`,
	templateDescriptionId: (template) => `template-item-${template}-description`,
	typePickerLabel: "Type",
	selectIssueTypeLabel: "create-issue-issue-type-label",
	fileUploadWarning: "Issue will be created once your upload has completed",
	issueTypeReadOnly: "You do not have permission to change the type",
	issueTypeReadOnlyReason: "You need the triage role or higher in this repository to change the issue type.",
	viewProfile: (login) => `View ${login}'s profile`,
	copilotCTAButton: "Write with Copilot",
	copilotCTADialogTitle: "Navigate to Copilot Chat",
	copilotCTADialogDescription: "You have unsaved changes. Are you sure you want to discard them?",
	copilotCTADialogCancelButton: "Keep editing",
	copilotCTADialogContinueButton: "Go to Copilot",
	copilotGenerateDialogTitle: "Generate issue content with Copilot",
	copilotGenerateDialogTextareaLabel: "Additional context (optional)",
	copilotGenerateDialogTextareaPlaceholder: "Add any additional context to help Copilot generate a better issue...",
	copilotGenerateDialogGenerateButton: "Generate content",
	copilotGenerateError: "Failed to generate content with Copilot. Please try again.",
	copilotGenerateValidationWarning: "Please provide a title, existing description, or additional context to generate content.",
	copilotPanelInitialMessage: "How can I help you write your issue?",
	copilotPanelInputPlaceholder: "Type your message here...",
	copilotPanelSendButton: "Send",
	copilotPanelUpdatedMessage: "I've updated the issue title and description above.",
	copilotPanelLoadingMessage: "Writing…",
	copilotPanelAcceptButton: "Accept",
	copilotPanelDiscardButton: "Discard",
	copilotPanelTryAgainButton: "Try again",
	copilotDiscardConfirmDialog: {
		title: "Discard changes?",
		content: "You have made edits to the generated content. Discarding will lose your changes.",
		confirm: "Discard",
		cancel: "Cancel"
	},
	copilotTryAgainConfirmDialog: {
		title: "Try again?",
		content: "You have made edits to the generated content. Trying again will replace your changes with new generated content.",
		confirm: "Try again",
		cancel: "Cancel"
	},
	backToAllIssues: "Back to all issues",
	crossRepoIssueDuplicationWarning: (droppedMetadata) => `This issue is being duplicated across repositories. The following metadata might not be copied: ${droppedMetadata.join(", ")}.`,
	crossRepoIssueDuplicationDefaultWarning: "Changing the repository may remove Milestone, Labels, Type, and Assignees from the duplicate issue.",
	setAdditionalFields: "Set additional issue fields",
	addIssueField: "Add issue field",
	potentialDuplicate: "Potential duplicate",
	duplicatesCount: (count) => `${count} potential duplicates`
};
function CopilotGenerateDescriptionDialog({ isOpen, onClose, onGenerate, repoOwner, repoName, title, body, returnFocusRef }) {
	const [copilotGenerateContext, setCopilotGenerateContext] = useState("");
	const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
	const [generationError, setGenerationError] = useState(null);
	const { sendAnalyticsEvent } = useAnalytics();
	const hasValidInput = !!(title?.trim() || body?.trim() || copilotGenerateContext?.trim());
	const handleClose = useCallback(() => {
		setCopilotGenerateContext("");
		setGenerationError(null);
		onClose();
	}, [onClose]);
	const handleGenerateDescription = useCallback(async () => {
		sendAnalyticsEvent("analytics.click", "ISSUE_CREATE_GENERATE_DESCRIPTION_WITH_COPILOT", {
			repoNWO: `${repoOwner}/${repoName}`,
			hasTitle: !!title,
			hasExistingDescription: !!body,
			hasAdditionalContext: !!copilotGenerateContext
		});
		setIsGeneratingDescription(true);
		setGenerationError(null);
		try {
			const response = await verifiedFetchJSON(`/${repoOwner}/${repoName}/issues/new/generate_copilot_description`, {
				method: "POST",
				body: {
					title,
					body,
					context: copilotGenerateContext
				}
			});
			if (!response.ok) {
				setGenerationError(LABELS$2.copilotGenerateError);
				sendGenerateDescriptionEvent("response_not_ok");
				return;
			}
			const responseData = await response.json();
			const generatedTitle = responseData.title;
			const generatedDescription = responseData.description;
			if (!generatedTitle || !generatedDescription || generatedTitle.trim().length === 0 || generatedDescription.trim().length === 0) {
				setGenerationError(LABELS$2.copilotGenerateError);
				sendGenerateDescriptionEvent(`response_missing${!generatedTitle ? "_title" : ""}${!generatedDescription ? "_description" : ""}`);
				return;
			}
			sendGenerateDescriptionEvent();
			onGenerate(generatedTitle, generatedDescription);
			setCopilotGenerateContext("");
		} catch (error) {
			setGenerationError(LABELS$2.copilotGenerateError);
			sendGenerateDescriptionEvent(error instanceof Error ? error.message : "unknown_error");
			reportError$1(error);
		} finally {
			setIsGeneratingDescription(false);
		}
	}, [
		sendAnalyticsEvent,
		repoOwner,
		repoName,
		title,
		body,
		copilotGenerateContext,
		onGenerate
	]);
	if (!isOpen) return null;
	return /* @__PURE__ */ jsx(Dialog, {
		title: LABELS$2.copilotGenerateDialogTitle,
		onClose: handleClose,
		footerButtons: [{
			buttonType: "default",
			content: "Cancel",
			onClick: handleClose,
			disabled: isGeneratingDescription
		}, {
			buttonType: "primary",
			content: isGeneratingDescription ? /* @__PURE__ */ jsx(Spinner, {
				size: "small",
				className: "mt-1 mr-1"
			}) : LABELS$2.copilotGenerateDialogGenerateButton,
			onClick: handleGenerateDescription,
			disabled: isGeneratingDescription || !hasValidInput
		}],
		returnFocusRef,
		children: /* @__PURE__ */ jsxs(Box, {
			sx: {
				display: "flex",
				flexDirection: "column",
				gap: 3
			},
			children: [
				generationError && /* @__PURE__ */ jsxs(Flash, {
					variant: "danger",
					children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), generationError]
				}),
				!hasValidInput && /* @__PURE__ */ jsxs(Flash, {
					variant: "warning",
					children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), LABELS$2.copilotGenerateValidationWarning]
				}),
				/* @__PURE__ */ jsxs(FormControl$1, {
					disabled: isGeneratingDescription,
					children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: LABELS$2.copilotGenerateDialogTextareaLabel }), /* @__PURE__ */ jsx(Textarea, {
						value: copilotGenerateContext,
						onChange: (e) => setCopilotGenerateContext(e.target.value),
						placeholder: LABELS$2.copilotGenerateDialogTextareaPlaceholder,
						rows: 6,
						block: true,
						className: "tmp-mt-3"
					})]
				})
			]
		})
	});
}
CopilotGenerateDescriptionDialog.displayName = "CopilotGenerateDescriptionDialog";
function sendGenerateDescriptionEvent(error, title, body, copilotGenerateContext) {
	sendEvent("copilot.create_issue_description", {
		hasTitle: !!title,
		hasExistingDescription: !!body,
		hasAdditionalContext: !!copilotGenerateContext,
		error
	});
}
var CreateIssueForm_module_default = {
	commentBox: "CreateIssueForm-module_i2F1ia_commentBox",
	copilotWriteButton: "CreateIssueForm-module_i2F1ia_copilotWriteButton",
	CreateIssueFormWrapper: "CreateIssueForm-module_i2F1ia_CreateIssueFormWrapper",
	duplicateDetectionStickyFooter: "CreateIssueForm-module_i2F1ia_duplicateDetectionStickyFooter",
	errorBanner: "CreateIssueForm-module_i2F1ia_errorBanner",
	footerButton: "CreateIssueForm-module_i2F1ia_footerButton",
	formGridContainer: "CreateIssueForm-module_i2F1ia_formGridContainer",
	mainContentSection: "CreateIssueForm-module_i2F1ia_mainContentSection",
	metadataSection: "CreateIssueForm-module_i2F1ia_metadataSection"
};
var emptyArray = [];
function EmojiAutocomplete(t0) {
	const $ = c(7);
	const { tone, ...props } = t0;
	const [filter, setFilter] = useState();
	const emojisQuery = useEmojisQuery(filter !== void 0);
	let t1;
	if ($[0] !== tone) {
		t1 = { tone };
		$[0] = tone;
		$[1] = t1;
	} else t1 = $[1];
	const { calculateSuggestions, trigger } = useEmojiSuggestions(emojisQuery.isPending ? "loading" : emojisQuery.data ?? emptyArray, t1);
	let t2;
	if ($[2] !== calculateSuggestions || $[3] !== filter) {
		t2 = filter !== void 0 ? calculateSuggestions(filter) : null;
		$[2] = calculateSuggestions;
		$[3] = filter;
		$[4] = t2;
	} else t2 = $[4];
	const suggestions = t2;
	let t3;
	let t4;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (t5) => {
			const { query } = t5;
			return setFilter(query);
		};
		t4 = () => setFilter(void 0);
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	return jsx(InlineAutocomplete, {
		triggers: [trigger],
		suggestions,
		onShowSuggestions: t3,
		onHideSuggestions: t4,
		...props
	});
}
EmojiAutocomplete.displayName = "EmojiAutocomplete";
var CreateIssueFormTitle_module_default = {
	container: "CreateIssueFormTitle-module_bszrEW_container",
	formControl: "CreateIssueFormTitle-module_bszrEW_formControl",
	formControlLabel: "CreateIssueFormTitle-module_bszrEW_formControlLabel",
	subcontainer: "CreateIssueFormTitle-module_bszrEW_subcontainer"
};
var CreateIssueFormTitle = (t0) => {
	const $ = c(6);
	const { title, titleValidationResult, titleInputRef, handleTitleChange } = t0;
	const { settings } = useViewerSettings();
	let t1;
	if ($[0] !== handleTitleChange || $[1] !== settings.emojiTone || $[2] !== title || $[3] !== titleInputRef || $[4] !== titleValidationResult) {
		const textInput = jsx(TextInput$1, {
			ref: titleInputRef,
			"aria-label": LABELS$2.issueCreateTitleLabel,
			placeholder: LABELS$2.issueCreateTitlePlaceholder,
			"aria-describedby": "issue-create-pane-title title-validation",
			value: title,
			onChange: handleTitleChange,
			onInput: handleTitleChange,
			"data-hpc": true,
			autoFocus: true,
			"data-react-autofocus": true
		});
		t1 = jsx("div", {
			className: CreateIssueFormTitle_module_default.container,
			children: jsxs(FormControl$1, {
				className: CreateIssueFormTitle_module_default.formControl,
				required: true,
				children: [jsx(FormControl$1.Label, {
					className: CreateIssueFormTitle_module_default.formControlLabel,
					children: LABELS$2.issueCreateTitleLabel
				}), jsxs("div", {
					className: CreateIssueFormTitle_module_default.subcontainer,
					children: [jsx(Suspense, {
						fallback: textInput,
						children: jsx(EmojiAutocomplete, {
							tone: settings.emojiTone,
							children: textInput
						})
					}), titleValidationResult && jsx("span", {
						role: "alert",
						"aria-live": "assertive",
						children: jsx(FormControl$1.Validation, {
							variant: "error",
							id: "title-validation",
							children: titleValidationResult
						})
					})]
				})]
			})
		});
		$[0] = handleTitleChange;
		$[1] = settings.emojiTone;
		$[2] = title;
		$[3] = titleInputRef;
		$[4] = titleValidationResult;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
};
CreateIssueFormTitle.displayName = "CreateIssueFormTitle";
var node$64 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "securityPolicyUrl",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "contributingFileUrl",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "codeOfConductFileUrl",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "supportFileUrl",
		"storageKey": null
	}, v6 = [{
		"kind": "Literal",
		"name": "first",
		"value": 10
	}], v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v9 = [
		v8,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	], v10 = {
		"kind": "InlineFragment",
		"selections": v9,
		"type": "IssueFieldText",
		"abstractKey": null
	}, v11 = {
		"kind": "InlineFragment",
		"selections": v9,
		"type": "IssueFieldSingleSelect",
		"abstractKey": null
	}, v12 = {
		"kind": "InlineFragment",
		"selections": v9,
		"type": "IssueFieldDate",
		"abstractKey": null
	}, v13 = {
		"kind": "InlineFragment",
		"selections": v9,
		"type": "IssueFieldNumber",
		"abstractKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "useIssueFormSecondaryQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [
						v2,
						v3,
						v4,
						v5,
						{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "owner",
							"plural": false,
							"selections": [{
								"kind": "InlineFragment",
								"selections": [{
									"alias": null,
									"args": v6,
									"concreteType": "IssueFieldsConnection",
									"kind": "LinkedField",
									"name": "pinnedIssueFields",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											v7,
											v10,
											v11,
											v12,
											v13
										],
										"storageKey": null
									}],
									"storageKey": "pinnedIssueFields(first:10)"
								}],
								"type": "Organization",
								"abstractKey": null
							}],
							"storageKey": null
						}
					],
					"type": "Repository",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "useIssueFormSecondaryQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v7,
					{
						"kind": "InlineFragment",
						"selections": [
							v2,
							v3,
							v4,
							v5,
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "owner",
								"plural": false,
								"selections": [
									v7,
									{
										"kind": "InlineFragment",
										"selections": [{
											"alias": null,
											"args": v6,
											"concreteType": "IssueFieldsConnection",
											"kind": "LinkedField",
											"name": "pinnedIssueFields",
											"plural": false,
											"selections": [{
												"alias": null,
												"args": null,
												"concreteType": null,
												"kind": "LinkedField",
												"name": "nodes",
												"plural": true,
												"selections": [
													v7,
													v10,
													v11,
													v12,
													v13,
													{
														"kind": "InlineFragment",
														"selections": [v8],
														"type": "Node",
														"abstractKey": "__isNode"
													}
												],
												"storageKey": null
											}],
											"storageKey": "pinnedIssueFields(first:10)"
										}],
										"type": "Organization",
										"abstractKey": null
									},
									v8
								],
								"storageKey": null
							}
						],
						"type": "Repository",
						"abstractKey": null
					},
					v8
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d3765abb61ac2c4f9019e654724d3043",
			"metadata": {},
			"name": "useIssueFormSecondaryQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$64.hash = "72c60bf38c11334e07dfc92e81deade1";
var import_relay_runtime = require_relay_runtime();
var useIssueFormSecondaryGraphqlQuery = node$64;
function useIssueFormSecondaryQuery(t0) {
	const $ = c(4);
	const { repoId } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [secondaryQueryData, setSecondaryQueryData] = useState(null);
	let t1;
	let t2;
	if ($[0] !== environment || $[1] !== repoId) {
		t1 = () => {
			clientSideRelayFetchQueryRetained({
				environment,
				query: useIssueFormSecondaryGraphqlQuery,
				variables: { id: repoId }
			}).subscribe({ next: (data) => {
				const orgPinnedFields = parsePinnedIssueFields(data.node?.owner?.pinnedIssueFields?.nodes?.filter(_temp$25));
				setSecondaryQueryData({
					securityPolicyUrl: data.node?.securityPolicyUrl ?? null,
					contributingFileUrl: data.node?.contributingFileUrl ?? null,
					codeOfConductFileUrl: data.node?.codeOfConductFileUrl ?? null,
					supportFileUrl: data.node?.supportFileUrl ?? null,
					orgPinnedFields
				});
			} });
		};
		t2 = [environment, repoId];
		$[0] = environment;
		$[1] = repoId;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	return secondaryQueryData;
}
function _temp$25(node) {
	return node?.__typename !== "%other";
}
var MIN_TITLE_LENGTH_FOR_DUPLICATE_CHECK = 10;
var MIN_BODY_LENGTH_FOR_DUPLICATE_CHECK = 25;
/**
* @deprecated Temporary analytics hook for duplicate issue detection research
*
* **WARNING: This hook is subject to change or complete removal without notice.**
*
* This hook is part of an experimental data collection initiative to inform the development
* of semantic duplicate issue detection capabilities. It tracks user input patterns during
* issue creation to better understand content characteristics and user behavior.
*
* @example
* ```tsx
* const trackAnalytics = useSemanticSearchAnalytics(repository)
*
* // Called when title or body content changes
* trackAnalytics(issueTitle, issueBody)
* ```
*
* **Implementation Notes:**
* - Debounced by 800ms to reduce event frequency
* - Only triggers when feature flag `issues_create_semantic_similarity_analytics` is enabled
* - Requires minimum content length thresholds to be met
* - Data collected: repository NWO, title length, body length
*
* **Future Plans:**
* - May be replaced with a more comprehensive duplicate detection system
* - Constants and thresholds will be adjusted based on collected data
* - Hook may be removed entirely once research phase is complete
*
* @param repository - The repository context for issue creation
* @returns Debounced analytics function that accepts (title: string, body: string)
*
* @internal This is an experimental feature for data collection purposes only!
*/
var useSemanticSearchAnalytics = (repository) => {
	const $ = c(5);
	const { sendAnalyticsEvent } = useAnalytics();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("issues_create_semantic_similarity_analytics");
		$[0] = t0;
	} else t0 = $[0];
	const isIssuesCreateSemanticSimilarityAnalyticsEnabled = t0;
	let t1;
	if ($[1] !== repository || $[2] !== sendAnalyticsEvent) {
		t1 = async (searchTitle, searchBody) => {
			if (isIssuesCreateSemanticSimilarityAnalyticsEnabled && (searchTitle.trim().length >= MIN_TITLE_LENGTH_FOR_DUPLICATE_CHECK || searchBody.trim().length >= MIN_BODY_LENGTH_FOR_DUPLICATE_CHECK)) sendAnalyticsEvent("analytics.issue.content_update", "SEMANTIC_SIMILAR_ISSUE_ANALYTICS", {
				repoNWO: `${repository.owner.login}/${repository.name}`,
				titleLength: searchTitle.length,
				bodyLength: searchBody.length
			});
		};
		$[1] = repository;
		$[2] = sendAnalyticsEvent;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = { onChangeBehavior: "cancel" };
		$[4] = t2;
	} else t2 = $[4];
	return useDebounce(t1, 800, t2);
};
var node$63 = {
	"kind": "InlineDataFragment",
	"name": "IssueFieldPickerIssueField"
};
node$63.hash = "31d854fea63dea594c796cfb9821b91c";
var node$62 = (function() {
	var v0 = [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "databaseId",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "description",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	];
	return {
		"argumentDefinitions": [{
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "issueFieldsPageSize"
		}],
		"kind": "Fragment",
		"metadata": { "connection": [{
			"count": "issueFieldsPageSize",
			"cursor": null,
			"direction": "forward",
			"path": ["issueFields"]
		}] },
		"name": "IssueFieldPickerPaginated",
		"selections": [{
			"alias": "issueFields",
			"args": null,
			"concreteType": "IssueFieldsConnection",
			"kind": "LinkedField",
			"name": "__Organization_issueFields_connection",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "IssueFieldsEdge",
				"kind": "LinkedField",
				"name": "edges",
				"plural": true,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "node",
					"plural": false,
					"selections": [{
						"kind": "InlineDataFragmentSpread",
						"name": "IssueFieldPickerIssueField",
						"selections": [
							{
								"kind": "InlineFragment",
								"selections": v0,
								"type": "IssueFieldText",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v0,
								"type": "IssueFieldSingleSelect",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v0,
								"type": "IssueFieldDate",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v0,
								"type": "IssueFieldNumber",
								"abstractKey": null
							}
						],
						"args": null,
						"argumentDefinitions": []
					}, {
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "cursor",
					"storageKey": null
				}],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": "PageInfo",
				"kind": "LinkedField",
				"name": "pageInfo",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "endCursor",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "hasNextPage",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"type": "Organization",
		"abstractKey": null
	};
})();
node$62.hash = "8a6dd6e5fd4fe5d70ead8019af2bbe61";
var node$61 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "issueFieldsPageSize"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "name"
	}, v2 = [{
		"kind": "Variable",
		"name": "login",
		"variableName": "name"
	}], v3 = [{
		"kind": "Variable",
		"name": "first",
		"variableName": "issueFieldsPageSize"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v5 = [
		v4,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "databaseId",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "description",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	];
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "IssueFieldPickerQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "Organization",
				"kind": "LinkedField",
				"name": "organization",
				"plural": false,
				"selections": [{
					"args": [{
						"kind": "Variable",
						"name": "issueFieldsPageSize",
						"variableName": "issueFieldsPageSize"
					}],
					"kind": "FragmentSpread",
					"name": "IssueFieldPickerPaginated"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "IssueFieldPickerQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "Organization",
				"kind": "LinkedField",
				"name": "organization",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": v3,
						"concreteType": "IssueFieldsConnection",
						"kind": "LinkedField",
						"name": "issueFields",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "IssueFieldsEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "__typename",
										"storageKey": null
									},
									{
										"kind": "TypeDiscriminator",
										"abstractKey": "__isIssueFields"
									},
									{
										"kind": "InlineFragment",
										"selections": v5,
										"type": "IssueFieldText",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": v5,
										"type": "IssueFieldSingleSelect",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": v5,
										"type": "IssueFieldDate",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": v5,
										"type": "IssueFieldNumber",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": [v4],
										"type": "Node",
										"abstractKey": "__isNode"
									}
								],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "cursor",
								"storageKey": null
							}],
							"storageKey": null
						}, {
							"alias": null,
							"args": null,
							"concreteType": "PageInfo",
							"kind": "LinkedField",
							"name": "pageInfo",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "endCursor",
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "hasNextPage",
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": v3,
						"filters": null,
						"handle": "connection",
						"key": "Organization_issueFields",
						"kind": "LinkedHandle",
						"name": "issueFields"
					},
					v4
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "dadedc2e94c39085c4fdd2fe515621a9",
			"metadata": {},
			"name": "IssueFieldPickerQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$61.hash = "9a4fe5cc933711b34b06c8deb4838e9d";
var AnchorRenderer = ({ anchorElement, anchorProps, anchorRef }) => {
	return anchorElement(anchorProps, anchorRef);
};
AnchorRenderer.displayName = "AnchorRenderer";
function LazyItemPicker({ anchorElement, createChild, keybindingCommandId }) {
	const [wasTriggered, setWasTriggered] = useState(false);
	const anchorRef = useRef(null);
	const handleKeyPress = useCallback(() => {
		if (!wasTriggered) setWasTriggered(true);
	}, [wasTriggered, setWasTriggered]);
	if (!wasTriggered) return /* @__PURE__ */ jsxs(Fragment$1, { children: [keybindingCommandId && /* @__PURE__ */ jsx(GlobalCommands, { commands: { [keybindingCommandId]: handleKeyPress } }), /* @__PURE__ */ jsx(AnchorRenderer, {
		anchorElement,
		anchorProps: {
			onClick: () => setWasTriggered(true),
			onKeyPress: (event) => {
				if (event.key === "Enter" || event.key === " ") {
					event.preventDefault();
					setWasTriggered(true);
				}
			}
		},
		anchorRef
	})] });
	return createChild();
}
LazyItemPicker.displayName = "LazyItemPicker";
var ISSUE_FIELDS_FEEDBACK_URL = "https://github.com/orgs/community/discussions/189141";
var ISSUE_FIELDS_STAFF_FEEDBACK_URL = "https://github-grid.enterprise.slack.com/archives/C0969KWTU01";
var FEEDBACK_LINK_TEXT = "Share feedback";
var IssueFieldLeadingVisual_module_default = { colorIndicator: "IssueFieldLeadingVisual-module_h69oLa_colorIndicator" };
function createIssueFieldPickerItemLeadingVisual(dataType) {
	if (dataType === "TEXT") return TypographyIcon;
	else if (dataType === "SINGLE_SELECT") return SingleSelectIcon;
	else if (dataType === "DATE") return CalendarIcon;
	else if (dataType === "NUMBER") return NumberIcon;
	else return;
}
var createIssueSingleSelectFieldPickerItemLeadingVisual = (color) => {
	return function IssueSingleSelectFieldPickerItemLeadingVisual() {
		const { bg, accent } = useNamedColor(colorNames.find((c) => c === color));
		return /* @__PURE__ */ jsx("div", {
			className: IssueFieldLeadingVisual_module_default.colorIndicator,
			style: {
				backgroundColor: bg,
				borderColor: accent
			}
		});
	};
};
var IssueFieldPicker_module_default = { footer: "IssueFieldPicker-module_KbXgCG_footer" };
var isCurrentUserStaff = isStaff();
var SECONDARY_ACTION = /* @__PURE__ */ jsxs("div", {
	className: IssueFieldPicker_module_default.footer,
	children: [/* @__PURE__ */ jsx(Label, {
		variant: "success",
		children: "Preview"
	}), /* @__PURE__ */ jsx(Link, {
		href: isCurrentUserStaff ? ISSUE_FIELDS_STAFF_FEEDBACK_URL : ISSUE_FIELDS_FEEDBACK_URL,
		children: FEEDBACK_LINK_TEXT
	})]
});
var IssueFieldFragment = node$63;
var IssueFieldPickerPaginatedFragment = node$62;
var IssueFieldPickerGraphqlQuery = node$61;
function IssueFieldPicker({ anchorElement, ...props }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		anchorElement: (anchorProps) => anchorElement(anchorProps),
		createChild: () => /* @__PURE__ */ jsx(IssueFieldPickerFetcher, {
			anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
			...props
		}),
		insidePortal: props.insidePortal,
		keybindingCommandId: "item-pickers:open-fields"
	});
}
IssueFieldPicker.displayName = "IssueFieldPicker";
function IssueFieldPickerFetcher(t0) {
	const $ = c(13);
	const { owner, anchorElement, ...props } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [isLoading, setIsLoading] = useState(true);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	let t1;
	if ($[0] !== environment || $[1] !== owner) {
		t1 = () => {
			clientSideRelayFetchQueryRetained({
				environment,
				query: IssueFieldPickerGraphqlQuery,
				variables: {
					name: owner,
					issueFieldsPageSize: 50
				}
			}).subscribe({
				next: (internalData) => {
					setData(internalData.organization ?? null);
					setIsLoading(false);
					setIsError(false);
				},
				error: () => {
					setIsError(true);
					setIsLoading(false);
				}
			});
		};
		$[0] = environment;
		$[1] = owner;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== environment || $[4] !== fetchKey || $[5] !== owner) {
		t2 = [
			environment,
			fetchKey,
			owner
		];
		$[3] = environment;
		$[4] = fetchKey;
		$[5] = owner;
		$[6] = t2;
	} else t2 = $[6];
	useEffect(t1, t2);
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = LABELS$3.cantEditItems("fields");
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== anchorElement) {
		t4 = {
			errorMessage: t3,
			anchorElement,
			open: true
		};
		$[8] = anchorElement;
		$[9] = t4;
	} else t4 = $[9];
	const { createFallbackComponent } = useItemPickerErrorFallback(t4);
	if (isError) {
		let t5;
		if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
			t5 = () => setFetchKey(_temp$24);
			$[10] = t5;
		} else t5 = $[10];
		let t6;
		if ($[11] !== createFallbackComponent) {
			t6 = createFallbackComponent(t5);
			$[11] = createFallbackComponent;
			$[12] = t6;
		} else t6 = $[12];
		return t6;
	}
	return jsx(ItemPickerWrapper$1, {
		owner,
		fields: data,
		isLoading,
		anchorElement,
		...props
	});
}
IssueFieldPickerFetcher.displayName = "IssueFieldPickerFetcher";
function _temp$24(current) {
	return current + 1;
}
function ItemPickerWrapper$1({ title = LABELS$3.fieldsHeader, width = "medium", fields, fieldsSet, onSelectionChange, insidePortal, anchorElement, isLoading, nested, notice }) {
	const [filter, setFilter] = useState("");
	const data = (0, import_react_relay.useFragment)(IssueFieldPickerPaginatedFragment, fields);
	const fetchedIssueFields = useMemo(() => {
		return (data?.issueFields?.edges?.flatMap((a) => a?.node ? [(0, import_react_relay.readInlineData)(IssueFieldFragment, a.node)] : []) || []).filter((issueField) => {
			if (!issueField) return false;
			if (fieldsSet.length > 0 && issueField.name) return fieldsSet.indexOf(issueField.name) === -1;
			return true;
		});
	}, [data, fieldsSet]);
	const items_0 = useMemo(() => {
		if (!filter) return fetchedIssueFields;
		return fetchedIssueFields.filter((l) => l.name && l.name.toLowerCase().indexOf(filter.toLowerCase()) >= 0);
	}, [fetchedIssueFields, filter]);
	const filterItems = useCallback((value) => {
		setFilter(value);
	}, []);
	const getItemKey = useCallback((issueField_0) => issueField_0.id || "", []);
	const fallbackId = useId();
	const convertToItemProps = useCallback((issueField_1) => {
		return {
			id: issueField_1.id || fallbackId,
			text: issueField_1.name,
			description: issueField_1.description || "",
			descriptionVariant: "block",
			leadingVisual: createIssueFieldPickerItemLeadingVisual(issueField_1.dataType || "TEXT"),
			source: issueField_1
		};
	}, [fallbackId]);
	const anchorRef = useRef(null);
	const showNoMatchMessage = useMemo(() => items_0.length === 0, [items_0.length]);
	return /* @__PURE__ */ jsx(ItemPicker, {
		loading: isLoading,
		items: items_0,
		initialSelectedItems: [],
		filterItems,
		title,
		getItemKey,
		convertToItemProps,
		placeholderText: `Filter fields`,
		selectionVariant: "single",
		onSelectionChange,
		renderAnchor: (anchorProps) => anchorElement(anchorProps, anchorRef),
		insidePortal,
		height: "large",
		width,
		nested,
		resultListAriaLabel: "Issue Fields results",
		triggerOpen: true,
		secondaryAction: SECONDARY_ACTION,
		notice,
		selectPanelRef: anchorRef,
		keybindingCommandId: "item-pickers:open-fields",
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No issue fields were found",
			variant: "empty",
			body: "Try searching with a different query for results."
		} : void 0
	});
}
ItemPickerWrapper$1.displayName = "ItemPickerWrapper";
var HOTKEYS = {
	assigneePicker: "a",
	labelPicker: "l",
	milestonePicker: "m",
	projectPicker: "p",
	issueTypePicker: "t",
	developmentSection: "d"
};
var SharedPicker_module_default = {
	dashedPickerButton: "SharedPicker-module_YVHxhG_dashedPickerButton",
	hotkeyBadge: "SharedPicker-module_YVHxhG_hotkeyBadge",
	leadingIconContainer: "SharedPicker-module_YVHxhG_leadingIconContainer",
	leadingIconContainerHidden: "SharedPicker-module_YVHxhG_leadingIconContainerHidden",
	pickerContentContainer: "SharedPicker-module_YVHxhG_pickerContentContainer",
	pickerLabelText: "SharedPicker-module_YVHxhG_pickerLabelText",
	title: "SharedPicker-module_YVHxhG_title"
};
var SharedPicker = ({ ref, leadingIconElement, anchorText, anchorProps, sharedPickerMainValue, ariaLabel, readonly, size, nested = false, leadingIcon: LeadingIcon, hotKey, ariaLabelledBy, compressedTitle, className }) => {
	const selectionDescription = React.useMemo(() => {
		if (!sharedPickerMainValue) return void 0;
		let displayText;
		if (typeof sharedPickerMainValue === "string") displayText = sharedPickerMainValue;
		else displayText = compressedTitle || "";
		return `Currently selected: ${displayText}`;
	}, [sharedPickerMainValue, compressedTitle]);
	const sharedProps = {
		"aria-labelledby": ariaLabelledBy,
		"aria-label": !ariaLabelledBy ? ariaLabel : void 0,
		"aria-description": selectionDescription,
		"aria-disabled": nested ? readonly : void 0,
		disabled: readonly
	};
	if (nested) {
		const leadingIcon = sharedPickerMainValue ? leadingIconElement : LeadingIcon && /* @__PURE__ */ jsx(LeadingIcon, {});
		return /* @__PURE__ */ jsxs(ActionList.Item, {
			...anchorProps,
			...sharedProps,
			role: "menuitem",
			children: [leadingIcon ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: leadingIcon }) : null, anchorText]
		});
	}
	if (sharedPickerMainValue) return /* @__PURE__ */ jsx(ButtonComponent, {
		ref,
		size: size ? size : "small",
		...anchorProps,
		...sharedProps,
		className,
		children: /* @__PURE__ */ jsxs("div", {
			className: SharedPicker_module_default.pickerContentContainer,
			children: [
				/* @__PURE__ */ jsx("div", {
					className: SharedPicker_module_default.pickerLabelText,
					children: anchorText
				}),
				/* @__PURE__ */ jsx("div", {
					className: clsx(SharedPicker_module_default.leadingIconContainer, !leadingIconElement && SharedPicker_module_default.leadingIconContainerHidden),
					children: leadingIconElement
				}),
				/* @__PURE__ */ jsx("div", {
					className: SharedPicker_module_default.title,
					children: /* @__PURE__ */ jsx(Truncate, {
						title: compressedTitle ?? sharedPickerMainValue.toString() ?? "",
						children: sharedPickerMainValue
					})
				})
			]
		})
	});
	else return /* @__PURE__ */ jsx(ButtonComponent, {
		ref,
		size: "small",
		leadingVisual: LeadingIcon,
		trailingVisual: hotKey ? () => /* @__PURE__ */ jsx("div", {
			className: SharedPicker_module_default.hotkeyBadge,
			children: hotKey
		}) : void 0,
		className: clsx(SharedPicker_module_default.dashedPickerButton, className),
		...sharedProps,
		...anchorProps,
		children: anchorText
	});
};
SharedPicker.displayName = "SharedPicker";
SharedPicker.displayName = "SharedPicker";
var CompressedAssigneeAnchor_module_default = { compressedAssigneeAvatar: "CompressedAssigneeAnchor-module_GulaAq_compressedAssigneeAvatar" };
var CompressedAssigneeAnchor = ({ ref, assignees, anchorProps, displayHotkey, MAX_DISPLAYED_ASSIGNEES = 2, readonly }) => {
	return /* @__PURE__ */ jsx(SharedPicker, {
		leadingIconElement: assignees.slice(0, MAX_DISPLAYED_ASSIGNEES).map((a) => /* @__PURE__ */ jsx(AssigneeLeadingVisual, { assignee: a }, a.login)),
		anchorText: assignees.length > 1 ? LABELS$3.assignees : LABELS$3.noAssignees,
		anchorProps,
		sharedPickerMainValue: assignees.slice(0, MAX_DISPLAYED_ASSIGNEES).map((a) => a.isCopilot ? "Copilot" : a.login).join(", ").concat(assignees.length > MAX_DISPLAYED_ASSIGNEES ? `, ${assignees.length - MAX_DISPLAYED_ASSIGNEES}+` : ""),
		ariaLabel: LABELS$3.selectAssignees,
		readonly,
		leadingIcon: PeopleIcon,
		hotKey: !readonly && displayHotkey ? HOTKEYS.assigneePicker.toUpperCase() : void 0,
		ref
	});
};
CompressedAssigneeAnchor.displayName = "CompressedAssigneeAnchor";
function AssigneeLeadingVisual(t0) {
	const $ = c(5);
	const { assignee } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	if (assignee.isCopilot) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx(CopilotIcon, {});
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	} else {
		let t1;
		if ($[1] !== assignee.avatarUrl || $[2] !== assignee.login || $[3] !== getHovercardAttributesForType) {
			t1 = jsx(GitHubAvatar, {
				...getHovercardAttributesForType("user", { login: assignee.login }),
				src: assignee.avatarUrl,
				size: 16,
				alt: `@${assignee.login}`,
				className: CompressedAssigneeAnchor_module_default.compressedAssigneeAvatar
			});
			$[1] = assignee.avatarUrl;
			$[2] = assignee.login;
			$[3] = getHovercardAttributesForType;
			$[4] = t1;
		} else t1 = $[4];
		return t1;
	}
}
AssigneeLeadingVisual.displayName = "AssigneeLeadingVisual";
CompressedAssigneeAnchor.displayName = "CompressedAssigneeAnchor";
var DefaultAssigneePickerAnchor = ({ ref, assignees, readonly, anchorProps }) => {
	return /* @__PURE__ */ jsx(CompressedAssigneeAnchor, {
		assignees: assignees || [],
		displayHotkey: false,
		anchorProps: readonly ? void 0 : anchorProps,
		readonly,
		ref
	});
};
DefaultAssigneePickerAnchor.displayName = "DefaultAssigneePickerAnchor";
DefaultAssigneePickerAnchor.displayName = "DefaultAssigneePickerAnchor";
var hasFuzzyMatch = (searchQuery, text) => {
	return fuzzyScore(searchQuery, text) > NO_MATCH;
};
var CopilotAvatar_module_default = {
	copilotAvatar: "CopilotAvatar-module_pxwweG_copilotAvatar",
	defaultStyle: "CopilotAvatar-module_pxwweG_defaultStyle",
	large: "CopilotAvatar-module_pxwweG_large",
	medium: "CopilotAvatar-module_pxwweG_medium",
	small: "CopilotAvatar-module_pxwweG_small"
};
var iconSizeMap = {
	small: {
		default: 12,
		minimal: 16
	},
	medium: {
		default: 16,
		minimal: 20
	},
	large: {
		default: 24,
		minimal: 32
	}
};
function CopilotAvatar({ size = "small", minimal = false, className = "", isDecorative = false }) {
	const actualIconSize = minimal ? iconSizeMap[size].minimal : iconSizeMap[size].default;
	return /* @__PURE__ */ jsx("span", {
		className: clsx(CopilotAvatar_module_default.copilotAvatar, CopilotAvatar_module_default[size], !minimal && CopilotAvatar_module_default.defaultStyle, className),
		"data-testid": "copilot-avatar",
		role: isDecorative ? "presentation" : "img",
		"aria-label": isDecorative ? void 0 : "Copilot avatar",
		children: size === "large" ? /* @__PURE__ */ jsx(CopilotAnimation, {
			animationType: "static",
			loopAnimation: true,
			size: actualIconSize
		}) : /* @__PURE__ */ jsx(CopilotIcon, { size: actualIconSize })
	});
}
CopilotAvatar.displayName = "CopilotAvatar";
var SPECIAL_VALUES = {
	noMilestoneData: {
		id: "no-milestone",
		title: "No milestone",
		closed: false
	},
	noLabelsData: {
		id: "no-labels",
		name: "No labels",
		color: "ededed",
		description: "Issues with no labels"
	},
	noAssigneeData: {
		id: "no-assignee",
		login: "No assignees",
		avatarUrl: ""
	},
	noMatchData: {
		id: "no-match-item",
		avatarUrl: "",
		description: "Filter by user"
	},
	noTypeData: {
		id: "no-type",
		name: "No type",
		color: "ededed",
		description: "Issues with no type"
	}
};
function assigneeMatchesQuery(user, query) {
	return `${user.login.toLowerCase()}#${user.name?.toLowerCase()}`.includes(query);
}
function sortAssigneePickerUsers(assignees, usersToSort, query) {
	const lowercasedQuery = query.toLowerCase().trim();
	const filteredAssignees = assignees.filter((u) => assigneeMatchesQuery(u, lowercasedQuery));
	const filteredUsersToSort = usersToSort.filter((userToSort) => !filteredAssignees.some((assignee) => assignee.id === userToSort.id));
	filteredUsersToSort.sort((a, b) => {
		if (a.isCopilot !== b.isCopilot) return a.isCopilot ? -1 : 1;
		return a.login.localeCompare(b.login);
	});
	return filteredAssignees.concat(filteredUsersToSort);
}
var assigneesGroup = { groupId: "assignees" };
var suggestionsGroup$1 = {
	groupId: "suggestions",
	header: {
		title: "Suggestions",
		variant: "filled"
	}
};
var getGroupItemId = (assignees, assignee) => {
	if (assignees.length === 0) return suggestionsGroup$1.groupId;
	else if (!assignees.find((a) => a.id === assignee.id)) return suggestionsGroup$1.groupId;
	return assigneesGroup.groupId;
};
var AssigneePickerBase_module_default = { Item: "AssigneePickerBase-module_isOnKq_Item" };
var AGENT_DESCRIPTIONS = {
	Copilot: "GitHub",
	Codex: "OpenAI",
	Claude: "Anthropic"
};
var DEFAULT_ASSIGNEES = [];
var DEFAULT_SUGGESTIONS$1 = [];
function AssigneePickerBase({ assignees = DEFAULT_ASSIGNEES, suggestions = DEFAULT_SUGGESTIONS$1, searchAssignees, onSelectionChange, insidePortal, anchorElement, nested, isLoading = false, noAssigneeOption = void 0, triggerOpen, selectionVariant = "multiple", title, maximumAssignees = 10, name = "assignee", showNoMatchItem = false, viewer, responsiveOnNarrow = false }) {
	const [filter, setFilter] = useState("");
	const [searchResults, setSearchResults] = useState(void 0);
	const [currentlySelectedAssignees, setCurrentlySelectedAssignees] = useState(assignees);
	const filterRef = useRef(filter);
	const { addToast } = useToastContext();
	const responsiveOnNarrowEnabled = responsiveOnNarrow || isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	useEffect(() => {
		setCurrentlySelectedAssignees(assignees);
	}, [assignees]);
	const getItemKey = useCallback((assignee) => assignee.login, []);
	const items = useMemo(() => {
		let sortedItems = [];
		if (searchResults) sortedItems = sortAssigneePickerUsers(assignees, searchResults, filter);
		else sortedItems = sortAssigneePickerUsers(assignees, assignees.concat(suggestions.filter((suggestion) => !assignees.find((assignee_0) => assignee_0.login === suggestion.login))), filter);
		if (viewer) {
			const currentUserIndex = sortedItems.findIndex((item) => item.login === viewer.login);
			if (currentUserIndex !== -1) sortedItems.splice(currentUserIndex, 1);
			else if (searchResults) return sortedItems;
			sortedItems.unshift(viewer);
		}
		if (noAssigneeOption && !noAssigneeOption.selected && !sortedItems.find((i) => i.id === SPECIAL_VALUES.noAssigneeData.id)) sortedItems.unshift(SPECIAL_VALUES.noAssigneeData);
		return sortedItems;
	}, [
		searchResults,
		viewer,
		noAssigneeOption,
		assignees,
		filter,
		suggestions
	]);
	const groupItemId = useCallback((assignee_1) => getGroupItemId(assignees, assignee_1), [assignees]);
	const showMaxLimitWarning = useMemo(() => !!(maximumAssignees && currentlySelectedAssignees.length >= maximumAssignees), [currentlySelectedAssignees.length, maximumAssignees]);
	const convertToItemProps = useCallback((assignee_2) => {
		const isCurrentlySelected = currentlySelectedAssignees.some((selected) => selected.id === assignee_2.id);
		const shouldDisable = showMaxLimitWarning && !isCurrentlySelected;
		if (noAssigneeOption && assignee_2.id === SPECIAL_VALUES.noAssigneeData.id) {
			const noAssigneeItem = { ...noAssigneeOption };
			noAssigneeItem.groupId = groupItemId(assignee_2);
			noAssigneeItem.disabled = shouldDisable;
			return noAssigneeItem;
		}
		if (showNoMatchItem && assignee_2.id === SPECIAL_VALUES.noMatchData.id) return {
			...SPECIAL_VALUES.noMatchData,
			groupId: groupItemId(assignee_2),
			source: assignee_2,
			text: `${name}:${filter}`,
			className: AssigneePickerBase_module_default.Item,
			disabled: shouldDisable
		};
		const assigneeIsCopilot = assignee_2.isCopilot;
		const assigneeIsBot = assignee_2.__typename === "Bot";
		const showAiBadge = assigneeIsCopilot || assignee_2.isAgent;
		const assigneeDisplayName = assigneeIsCopilot ? LABELS$3.copilotDisplayName : assigneeIsBot && assignee_2.displayName ? assignee_2.displayName : assignee_2.login;
		const assigneeDescription = (assigneeIsCopilot || assignee_2.isAgent) && assignee_2.displayName ? AGENT_DESCRIPTIONS[assignee_2.displayName] ?? "" : assignee_2.name || "";
		return {
			id: assignee_2.id,
			text: assigneeDisplayName,
			description: assigneeDescription,
			source: assignee_2,
			groupId: groupItemId(assignee_2),
			leadingVisual: () => assigneeIsCopilot ? /* @__PURE__ */ jsx(CopilotAvatar, {}) : assignee_2.avatarUrl.length === 0 ? null : /* @__PURE__ */ jsx(GitHubAvatar, {
				alt: "",
				src: assignee_2.avatarUrl
			}),
			trailingVisual: () => {
				if (showAiBadge) return /* @__PURE__ */ jsx(Label, { children: "AI" });
				if (assigneeIsBot) return /* @__PURE__ */ jsx(Label, { children: "bot" });
				return null;
			},
			className: AssigneePickerBase_module_default.Item,
			disabled: shouldDisable
		};
	}, [
		filter,
		groupItemId,
		name,
		noAssigneeOption,
		showNoMatchItem,
		showMaxLimitWarning,
		currentlySelectedAssignees
	]);
	const onClose = useCallback(() => {
		setSearchResults(void 0);
	}, []);
	const fetchSearchData = useCallback(async (query) => {
		if (query === "") {
			setSearchResults(void 0);
			return;
		}
		try {
			const suggestedAssignees = await searchAssignees(query);
			const currentFilter = filterRef.current;
			if (query.trim() === currentFilter.trim()) setSearchResults(suggestedAssignees);
		} catch {
			addToast({
				type: "error",
				message: ERRORS$2.couldNotSearchAssignees
			});
		}
	}, [addToast, searchAssignees]);
	const debounceFetchSearchData = useDebounce((nextValue) => fetchSearchData(nextValue), VALUES.pickerDebounceTime, {
		leading: true,
		trailing: true,
		onChangeBehavior: "flush"
	});
	const filterItems = useCallback((value) => {
		const trimmedFilter = value.trim();
		if (filter === trimmedFilter) return;
		debounceFetchSearchData(trimmedFilter);
		setFilter(value);
		filterRef.current = trimmedFilter;
	}, [debounceFetchSearchData, filter]);
	const onLiveSelectionChange = useCallback((selectedAssignees) => {
		const visibleItemIds = new Set(items.map((item_0) => item_0.id));
		const selectedItemIds = new Set(selectedAssignees.map((assignee_3) => assignee_3.id));
		const hiddenSelectedItems = currentlySelectedAssignees.filter((assignee_4) => !visibleItemIds.has(assignee_4.id) && !selectedItemIds.has(assignee_4.id));
		setCurrentlySelectedAssignees([...selectedAssignees, ...hiddenSelectedItems]);
	}, [currentlySelectedAssignees, items]);
	const groups = useMemo(() => {
		const itemGroups = [];
		const assigneeItems = items.filter((i_0) => assignees.find((a) => a.id === i_0.id));
		const suggestionItems = items.filter((i_1) => !assignees.find((a_0) => a_0.id === i_1.id));
		if (assigneeItems.length > 0) itemGroups.push(assigneesGroup);
		if (suggestionItems.length > 0) itemGroups.push(suggestionsGroup$1);
		return itemGroups;
	}, [assignees, items]);
	const anchorRef = useRef(null);
	const showNoMatchMessage = useMemo(() => !showNoMatchItem && items.length === 0, [showNoMatchItem, items.length]);
	return /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(ItemPicker, {
		items,
		initialSelectedItems: assignees,
		loading: isLoading,
		filterItems,
		title: title || LABELS$3.assigneesHeader,
		getItemKey,
		triggerOpen,
		convertToItemProps,
		placeholderText: LABELS$3.filterUsers(name),
		selectionVariant: maximumAssignees === 1 ? "single" : selectionVariant || "multiple",
		onSelectionChange,
		onLiveSelectionChange,
		onClose,
		renderAnchor: (props) => anchorElement(props, anchorRef),
		groups,
		insidePortal,
		height: "large",
		width: "medium",
		nested,
		resultListAriaLabel: "User results",
		selectPanelRef: anchorRef,
		notice: maximumAssignees && showMaxLimitWarning ? {
			text: LABELS$3.limitWarning(maximumAssignees),
			variant: "warning"
		} : void 0,
		customNoMatchItem: showNoMatchItem ? {
			id: SPECIAL_VALUES.noMatchData.id,
			avatarUrl: SPECIAL_VALUES.noMatchData.avatarUrl,
			login: filter
		} : void 0,
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No assignees were found",
			body: "Try searching for a different name for results.",
			variant: "empty"
		} : void 0,
		keybindingCommandId: getKeyBindingCommandId$1(name),
		responsiveOnNarrow: responsiveOnNarrowEnabled
	}) });
}
AssigneePickerBase.displayName = "AssigneePickerBase";
var getKeyBindingCommandId$1 = (name) => name === "author" ? "item-pickers:open-author" : "item-pickers:open-assignees";
var itemPickersUrlBase = "/_ghui/item-pickers";
function buildItemPickersUrl(endpoint) {
	return `${itemPickersUrlBase}/${endpoint}`;
}
function buildItemPickerSearchUrl(endpoint, params = {}) {
	const paramsString = new URLSearchParams(params).toString();
	return `${buildItemPickersUrl(endpoint)}${paramsString && `?${paramsString}`}`;
}
async function apiGetSearchAssignees({ owner, repo, query, first, number, loginNames, capabilities }) {
	const params = {
		owner,
		repo
	};
	if (query) params["query"] = query;
	if (first !== void 0) params["first"] = first;
	if (number !== void 0) params["number"] = number;
	if (loginNames) params["loginNames"] = loginNames;
	if (capabilities && capabilities.length > 0) params["capabilities"] = capabilities.join(",");
	return await (await verifiedFetchJSON(buildItemPickerSearchUrl("assignees", params))).json();
}
var itemPickerQueryKeyBase$4 = "item_picker";
function buildAssigneePickerSearchQueryKey(searchParams) {
	return [
		itemPickerQueryKeyBase$4,
		"assignees",
		searchParams
	];
}
function transformSearchAssigneeResponseToQueryData(response) {
	let assignees = [];
	let totalCount;
	if (response.repository.suggestedActors) {
		assignees = response.repository.suggestedActors.nodes;
		totalCount = response.repository.suggestedActors.totalCount;
	} else if (response.repository.assignableUsers) {
		assignees = response.repository.assignableUsers.nodes;
		totalCount = response.repository.assignableUsers.totalCount;
	} else if (response.repository.issueOrPullRequest?.suggestedActors) assignees = response.repository.issueOrPullRequest.suggestedActors.nodes;
	return {
		assignees,
		repositoryId: response.repository.id,
		totalCount
	};
}
/**
* Checks the response for a data property - if it exists just return the response, but cast
* to the GraphQLResponseWithData shape.
* If an errors property exists, throw an error, with the message of the first error from the response.
* If neither exists, throw a generic error
* @param response
* @returns
*/
function parseGraphQLResponse(response) {
	if ("data" in response) return response;
	else if ("errors" in response) {
		if (Array.isArray(response.errors) && response.errors.length > 0 && response.errors[0]?.message) throw new Error(response.errors[0].message);
	}
	throw new Error("Error in request");
}
var getActorCapabilities = ({ includeAssignableBots, includeAuthorableBots }) => {
	const capabilities = [];
	if (includeAssignableBots) capabilities.push("CAN_BE_ASSIGNED");
	if (includeAuthorableBots) capabilities.push("CAN_BE_AUTHOR");
	return capabilities;
};
var formatActorLogin = (actor) => {
	if (actor.isCopilot) return "@copilot";
	if (actor.__typename === "Bot") return `app/${actor.login}`;
	return actor.login;
};
async function fetchAssignees(queryClient, { owner, repo, query, first, number, loginNames, capabilities }) {
	let effectiveFirst;
	if (first !== void 0) effectiveFirst = first;
	else if (loginNames !== void 0) effectiveFirst = loginNames.length;
	else effectiveFirst = void 0;
	const loginNamesString = loginNames !== void 0 ? loginNames.join(",") : void 0;
	return await queryClient.fetchQuery({
		queryKey: buildAssigneePickerSearchQueryKey({
			owner,
			repo,
			query,
			first: effectiveFirst,
			number,
			loginNames: loginNamesString,
			capabilities
		}),
		queryFn: async () => {
			return transformSearchAssigneeResponseToQueryData(parseGraphQLResponse(await apiGetSearchAssignees({
				owner,
				repo,
				query,
				first: effectiveFirst,
				number,
				loginNames: loginNamesString,
				capabilities
			})).data);
		}
	});
}
function ItemPickerFetcherForIssue(t0) {
	const $ = c(21);
	const { repo, owner, number, assignees, suggestions, viewer, ...rest } = t0;
	const [isLoading, setIsLoading] = useState(!suggestions || suggestions.length === 0);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const queryClient = useQueryClient();
	const hasPreloadedData = (suggestions?.length || 0) > 0;
	let t1;
	if ($[0] !== hasPreloadedData || $[1] !== number || $[2] !== owner || $[3] !== queryClient || $[4] !== repo) {
		t1 = () => {
			if (!hasPreloadedData) {
				const fetchInitialAssignees = async () => {
					try {
						setData(await fetchAssignees(queryClient, {
							owner,
							repo,
							query: "",
							number,
							first: 10
						}));
						setIsLoading(false);
						setIsError(false);
					} catch {
						setIsError(true);
						setIsLoading(false);
					}
				};
				fetchInitialAssignees();
			}
		};
		$[0] = hasPreloadedData;
		$[1] = number;
		$[2] = owner;
		$[3] = queryClient;
		$[4] = repo;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== fetchKey || $[7] !== hasPreloadedData || $[8] !== number || $[9] !== owner || $[10] !== queryClient || $[11] !== repo) {
		t2 = [
			fetchKey,
			owner,
			queryClient,
			repo,
			number,
			hasPreloadedData
		];
		$[6] = fetchKey;
		$[7] = hasPreloadedData;
		$[8] = number;
		$[9] = owner;
		$[10] = queryClient;
		$[11] = repo;
		$[12] = t2;
	} else t2 = $[12];
	useEffect(t1, t2);
	const anchorRef = useRef(null);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("assignees"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	let t3;
	if ($[13] !== number || $[14] !== owner || $[15] !== queryClient || $[16] !== repo) {
		t3 = async (query) => {
			try {
				setIsLoading(true);
				const response_0 = await fetchAssignees(queryClient, {
					owner,
					repo,
					query,
					number,
					first: 10
				});
				setIsLoading(false);
				setIsError(false);
				return response_0.assignees;
			} catch {
				setIsLoading(false);
				setIsError(true);
				return [];
			}
		};
		$[13] = number;
		$[14] = owner;
		$[15] = queryClient;
		$[16] = repo;
		$[17] = t3;
	} else t3 = $[17];
	const searchAssignees = t3;
	const suggestedActors = suggestions || data?.assignees || [];
	if (isError) {
		let t4;
		if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
			t4 = () => setFetchKey(_temp$23);
			$[18] = t4;
		} else t4 = $[18];
		let t5;
		if ($[19] !== createFallbackComponent) {
			t5 = createFallbackComponent(t4);
			$[19] = createFallbackComponent;
			$[20] = t5;
		} else t5 = $[20];
		return t5;
	}
	return jsx(AssigneePickerBase, {
		...rest,
		assignees,
		suggestions: suggestedActors,
		isLoading,
		searchAssignees,
		viewer
	});
}
ItemPickerFetcherForIssue.displayName = "ItemPickerFetcherForIssue";
function _temp$23(current) {
	return current + 1;
}
function ItemPickerFetcherForRepository({ repo, owner, assignees, assigneeTokens, suggestions, includeAssignableBots, includeAuthorableBots, maximumAssignees, viewer, ...rest }) {
	const [isLoading, setIsLoading] = useState(false);
	const [isError, setIsError] = useState(false);
	const [fetchKey, setFetchKey] = useState(0);
	const [data, setData] = useState(null);
	const [suggestedAssignees, setSuggestedAssignees] = useState(null);
	const [totalAssignableUsers, setTotalAssignableUsers] = useState(null);
	const queryClient = useQueryClient();
	const capabilities = useMemo(() => getActorCapabilities({
		includeAssignableBots,
		includeAuthorableBots
	}), [includeAssignableBots, includeAuthorableBots]);
	const shouldFetchFromAssigneeTokens = assigneeTokens.length > 0;
	useEffect(() => {
		if (shouldFetchFromAssigneeTokens) {
			const fetchData = async () => {
				try {
					setIsLoading(true);
					setData(await fetchAssignees(queryClient, {
						owner,
						repo,
						query: "",
						loginNames: assigneeTokens,
						capabilities
					}));
					setIsLoading(false);
					setIsError(false);
				} catch {
					setIsLoading(false);
					setIsError(true);
				}
			};
			fetchData();
		}
	}, [
		fetchKey,
		owner,
		repo,
		assigneeTokens,
		capabilities,
		queryClient,
		shouldFetchFromAssigneeTokens
	]);
	const searchAssignees = useCallback(async (query) => {
		if (totalAssignableUsers && totalAssignableUsers <= VALUES.maximumSuggestedUsers && suggestedAssignees) {
			setIsLoading(false);
			return fuzzyFilter({
				items: [...suggestedAssignees, ...rest.noAssigneeOption ? [SPECIAL_VALUES.noAssigneeData] : []],
				filter: query,
				key: (l) => (l.isAgent ? l.displayName || l.login : l.login) || (rest.noAssigneeOption?.source?.login ?? ""),
				secondaryKey: (l) => `${l.name}`
			});
		}
		try {
			setIsLoading(true);
			const response = await fetchAssignees(queryClient, {
				owner,
				repo,
				query,
				first: VALUES.maximumSuggestedUsers,
				capabilities
			});
			const assignableActors = response.assignees;
			if (response.totalCount && query.trim() === "") setTotalAssignableUsers(response.totalCount);
			if (rest.noAssigneeOption && hasFuzzyMatch(query, rest.noAssigneeOption?.source?.login ?? "")) assignableActors.unshift({ ...SPECIAL_VALUES.noAssigneeData });
			setIsLoading(false);
			setIsError(false);
			return assignableActors;
		} catch {
			setIsLoading(false);
			setIsError(true);
			return [];
		}
	}, [
		totalAssignableUsers,
		suggestedAssignees,
		rest.noAssigneeOption,
		queryClient,
		owner,
		repo,
		capabilities
	]);
	const suggestedActors = useMemo(() => {
		let all = [];
		if (assignees && assignees.length > 0) all = assignees;
		else if (assigneeTokens.length > 0) all = data?.assignees || [];
		if (rest.noAssigneeOption?.selected) all.unshift(SPECIAL_VALUES.noAssigneeData);
		return all;
	}, [
		assigneeTokens.length,
		assignees,
		data?.assignees,
		rest.noAssigneeOption?.selected
	]);
	useEffect(() => {
		const fetchSuggestedAssignees = async () => {
			setSuggestedAssignees(await searchAssignees(""));
			setIsLoading(false);
		};
		fetchSuggestedAssignees();
	}, []);
	const suggestedItems = useMemo(() => {
		const copilot = (suggestedAssignees || []).find((a) => a.isCopilot);
		const source = [...suggestions ? suggestions : suggestedAssignees || []];
		if (copilot && !source.find((a) => a.isCopilot)) source.unshift(copilot);
		return source;
	}, [suggestedAssignees, suggestions]);
	const anchorRef = useRef(null);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("assignees"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	if (isError) return createFallbackComponent(() => setFetchKey((current) => current + 1));
	return /* @__PURE__ */ jsx(AssigneePickerBase, {
		...rest,
		assignees: suggestedActors,
		suggestions: suggestedItems,
		isLoading,
		searchAssignees,
		maximumAssignees,
		viewer
	});
}
ItemPickerFetcherForRepository.displayName = "ItemPickerFetcherForRepository";
var getKeyBindingCommandId = (name) => name === "author" ? "item-pickers:open-author" : "item-pickers:open-assignees";
function AssigneePicker$1({ repo, owner, number, anchorElement, readonly, assignees, suggestions, viewer, ...rest }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		keybindingCommandId: getKeyBindingCommandId(rest.name),
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		createChild: () => /* @__PURE__ */ jsx(ItemPickerFetcherForIssue, {
			repo,
			owner,
			number,
			readonly,
			assignees,
			suggestions,
			viewer,
			triggerOpen: true,
			anchorElement,
			...rest
		}),
		insidePortal: rest.insidePortal
	});
}
AssigneePicker$1.displayName = "AssigneePicker";
function AssigneeRepositoryPicker$1({ anchorElement, ...props }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		keybindingCommandId: getKeyBindingCommandId(props.name),
		createChild: () => /* @__PURE__ */ jsx(ItemPickerFetcherForRepository, {
			anchorElement,
			triggerOpen: true,
			...props
		}),
		insidePortal: props.insidePortal
	});
}
AssigneeRepositoryPicker$1.displayName = "AssigneeRepositoryPicker";
var node$60 = (function() {
	var v0 = [{
		"alias": null,
		"args": null,
		"concreteType": "User",
		"kind": "LinkedField",
		"name": "safeViewer",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__typename",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "login",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "profileResourcePath",
				"storageKey": null
			},
			{
				"alias": null,
				"args": [{
					"kind": "Literal",
					"name": "size",
					"value": 64
				}],
				"kind": "ScalarField",
				"name": "avatarUrl",
				"storageKey": "avatarUrl(size:64)"
			}
		],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": [],
			"kind": "Fragment",
			"metadata": null,
			"name": "useViewerSafeViewerSharedQuery",
			"selections": v0,
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [],
			"kind": "Operation",
			"name": "useViewerSafeViewerSharedQuery",
			"selections": v0
		},
		"params": {
			"id": "e04bcb743a2af95309967488bc0303c0",
			"metadata": {},
			"name": "useViewerSafeViewerSharedQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$60.hash = "ec14349f609753fe2f861f8c75dc87f5";
/**
* @deprecated use '@github-ui/item-picker-assignee-tsq' instead
*
* Tries to get viewer from app payload or relay store to and does a query over the network if needed
*/
function useViewer() {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { currentUser } = useUser();
	const [viewer, setViewer] = useState(currentUser);
	if (!IS_SERVER && !viewer) clientSideRelayFetchQueryRetained({
		environment,
		query: node$60,
		variables: {}
	}).subscribe({ next: (data) => {
		if (data.safeViewer) setViewer(data.safeViewer);
	} });
	return viewer;
}
/**
* @deprecated use '@github-ui/item-picker-assignee-tsq' instead
*/
function AssigneePicker(props) {
	const $ = c(3);
	const viewer = useViewer();
	let t0;
	if ($[0] !== props || $[1] !== viewer) {
		t0 = jsx(AssigneePicker$1, {
			...props,
			viewer
		});
		$[0] = props;
		$[1] = viewer;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
/**
* @deprecated use '@github-ui/item-picker-assignee-tsq' instead
*/
AssigneePicker.displayName = "AssigneePicker";
function AssigneeRepositoryPicker(props) {
	const $ = c(3);
	const viewer = useViewer();
	let t0;
	if ($[0] !== props || $[1] !== viewer) {
		t0 = jsx(AssigneeRepositoryPicker$1, {
			...props,
			viewer
		});
		$[0] = props;
		$[1] = viewer;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
AssigneeRepositoryPicker.displayName = "AssigneeRepositoryPicker";
var DefaultIssueTypePickerAnchor_module_default = { issueTypeDot: "DefaultIssueTypePickerAnchor-module_bItyuW_issueTypeDot" };
var IssueTypeDot = (t0) => {
	const $ = c(4);
	const { color } = t0;
	let t1;
	if ($[0] !== color) {
		t1 = colorNames.find((c) => c === color);
		$[0] = color;
		$[1] = t1;
	} else t1 = $[1];
	const { fg } = useNamedColor(t1);
	const t2 = `${fg}`;
	let t3;
	if ($[2] !== t2) {
		t3 = jsx("div", {
			style: { "--bg": t2 },
			className: DefaultIssueTypePickerAnchor_module_default.issueTypeDot
		});
		$[2] = t2;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
};
IssueTypeDot.displayName = "IssueTypeDot";
var DefaultIssueTypePickerAnchor = ({ ref, activeIssueType, readonly, anchorProps }) => {
	return /* @__PURE__ */ jsx(SharedPicker, {
		anchorText: LABELS$3.noIssueTypes,
		sharedPickerMainValue: activeIssueType?.name,
		anchorProps: readonly ? void 0 : anchorProps,
		ariaLabel: LABELS$3.selectIssueTypes,
		readonly,
		leadingIcon: IssueOpenedIcon,
		hotKey: void 0,
		ref,
		leadingIconElement: activeIssueType && /* @__PURE__ */ jsx(IssueTypeDot, { color: activeIssueType.color })
	});
};
DefaultIssueTypePickerAnchor.displayName = "DefaultIssueTypePickerAnchor";
DefaultIssueTypePickerAnchor.displayName = "DefaultIssueTypePickerAnchor";
var IssueTypePickerItemLeadingVisual_module_default = {
	issueTypeColorIndicator: "IssueTypePickerItemLeadingVisual-module_Bbmv3W_issueTypeColorIndicator",
	leadingVisual: "IssueTypePickerItemLeadingVisual-module_Bbmv3W_leadingVisual"
};
function NoTypeIndicator() {
	return /* @__PURE__ */ jsxs("svg", {
		width: "12",
		height: "12",
		viewBox: "0 0 12 12",
		fill: "none",
		"aria-hidden": "true",
		xmlns: "http://www.w3.org/2000/svg",
		children: [/* @__PURE__ */ jsx("rect", {
			width: "12",
			height: "12",
			rx: "6",
			fill: "var(--bgColor-muted)"
		}), /* @__PURE__ */ jsx("rect", {
			x: "1",
			y: "1",
			width: "10",
			height: "10",
			rx: "5",
			stroke: "var(--borderColor-muted)",
			strokeWidth: "2",
			strokeDasharray: "2.5 1.4",
			strokeDashoffset: "1.25"
		})]
	});
}
NoTypeIndicator.displayName = "NoTypeIndicator";
var createIssueTypePickerItemLeadingVisual = (color) => function IssueTypePickerItemLeadingVisual() {
	const { bg, accent } = useNamedColor(colorNames.find((c) => c === color));
	return /* @__PURE__ */ jsx("div", {
		style: {
			"--bg": `${bg}`,
			"--accent": `${accent}`
		},
		className: IssueTypePickerItemLeadingVisual_module_default.issueTypeColorIndicator
	});
};
function IssueTypeColorIndicator(t0) {
	const $ = c(5);
	const { color } = t0;
	let t1;
	if ($[0] !== color) {
		t1 = colorNames.find((c) => c === color);
		$[0] = color;
		$[1] = t1;
	} else t1 = $[1];
	const { bg, accent } = useNamedColor(t1);
	const t2 = `${bg}`;
	const t3 = `${accent}`;
	let t4;
	if ($[2] !== t2 || $[3] !== t3) {
		t4 = jsx("div", {
			style: {
				"--bg": t2,
				"--accent": t3
			},
			className: IssueTypePickerItemLeadingVisual_module_default.issueTypeColorIndicator
		});
		$[2] = t2;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	return t4;
}
IssueTypeColorIndicator.displayName = "IssueTypeColorIndicator";
var UNSET_ID = "UNSET";
var DEFAULT_ISSUE_TYPES = [];
function IssueTypePickerBase({ activeIssueType, issueTypes = DEFAULT_ISSUE_TYPES, issueTypeToken, noTypeItem, showUnset = false, anchorElement, insidePortal, isLoading, nested, onSelectionChange, title = LABELS$3.typesHeader, triggerOpen = true, width = "large", onOpen }) {
	const [filter, setFilter] = useState("");
	const issueTypeFromToken = useMemo(() => {
		const formattedIssueTypeToken = issueTypeToken && issueTypeToken[0] === "\"" && issueTypeToken[issueTypeToken.length - 1] === "\"" ? issueTypeToken.slice(1, -1) : issueTypeToken;
		return issueTypes.find((issueType) => issueType.name === formattedIssueTypeToken);
	}, [issueTypes, issueTypeToken]);
	const items = useMemo(() => {
		const repositoryIssueTypes = issueTypes.slice().sort((a, b) => a.name.localeCompare(b.name));
		if (noTypeItem) repositoryIssueTypes.unshift(SPECIAL_VALUES.noTypeData);
		else if (showUnset) repositoryIssueTypes.unshift({
			id: UNSET_ID,
			name: "No issue type",
			isEnabled: true,
			description: "",
			color: "GRAY"
		});
		if (!filter) return repositoryIssueTypes;
		return repositoryIssueTypes.filter((l) => l.name.toLowerCase().indexOf(filter.toLowerCase()) >= 0);
	}, [
		issueTypes,
		filter,
		showUnset,
		noTypeItem
	]);
	const filterItems = useCallback((value) => {
		setFilter(value);
	}, []);
	const getItemKey = useCallback((issueType_0) => issueType_0.id, []);
	const convertToItemProps = useCallback((issueType_1) => {
		return {
			id: issueType_1.id,
			text: issueType_1.name,
			description: issueType_1.description ?? "",
			descriptionVariant: "block",
			leadingVisual: createIssueTypePickerItemLeadingVisual(issueType_1.color),
			source: issueType_1
		};
	}, []);
	const initialSelectedItems = useMemo(() => {
		if (noTypeItem?.selected) return [SPECIAL_VALUES.noTypeData];
		if (activeIssueType) return [activeIssueType];
		if (issueTypeFromToken) return [issueTypeFromToken];
		return [];
	}, [
		activeIssueType,
		issueTypeFromToken,
		noTypeItem
	]);
	const anchorRef = useRef(null);
	const showNoMatchMessage = useMemo(() => items.length === 0, [items.length]);
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	return /* @__PURE__ */ jsx(ItemPicker, {
		loading: isLoading,
		items,
		initialSelectedItems,
		filterItems,
		title,
		getItemKey,
		convertToItemProps,
		placeholderText: `Filter types`,
		selectionVariant: "single",
		onSelectionChange,
		onOpen,
		renderAnchor: (anchorProps) => anchorElement(anchorProps),
		insidePortal,
		height: "large",
		width,
		nested,
		resultListAriaLabel: "Issue Type results",
		triggerOpen,
		keybindingCommandId: "item-pickers:open-issue-type",
		selectPanelRef: anchorRef,
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No issue types were found",
			variant: "empty",
			body: "Try searching with a different query for results."
		} : void 0,
		responsiveOnNarrow: responsiveOnNarrowEnabled
	});
}
IssueTypePickerBase.displayName = "IssueTypePickerBase";
async function apiGetSearchIssueTypes({ owner, repo, query, count }) {
	const params = {
		owner,
		repo
	};
	if (query) params["query"] = query;
	if (count) params["count"] = count;
	return await (await verifiedFetchJSON(buildItemPickerSearchUrl("issue_types", params))).json();
}
var itemPickerQueryKeyBase$3 = "item_picker";
function buildItemPickerIssueTypeSearchQueryKey(searchParams) {
	return [
		itemPickerQueryKeyBase$3,
		"issue_types",
		searchParams
	];
}
function transformSearchIssueTypeResponseToQueryData(response) {
	return { issueTypes: response.repository.issueTypes.edges.map((e) => e.node) };
}
function isIssueType(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	const item = obj;
	return typeof item.id === "string" && typeof item.name === "string" && (typeof item.description === "string" || item.description === null || item.description === void 0) && typeof item.color === "string" && (typeof item.isEnabled === "boolean" || item.isEnabled === void 0);
}
function isIssueTypePickerQueryData(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	const data = obj;
	return Array.isArray(data.issueTypes) && data.issueTypes.every(isIssueType);
}
var IssueTypePickerQueryDataValidator = {
	Check: (value) => isIssueTypePickerQueryData(value),
	Code: () => "manual-validator",
	*Errors() {}
};
function createIssueTypePersister(sendAnalyticsEvent) {
	return createPersister({
		validator: IssueTypePickerQueryDataValidator,
		sendAnalyticsEvent,
		enabled: true
	});
}
async function fetchIssueTypes(queryClient, { owner, repo, query, count, persister }) {
	return await queryClient.fetchQuery({
		queryKey: buildItemPickerIssueTypeSearchQueryKey({
			owner,
			repo,
			query,
			count
		}),
		queryFn: async () => {
			return transformSearchIssueTypeResponseToQueryData(parseGraphQLResponse(await apiGetSearchIssueTypes({
				owner,
				repo,
				query,
				count
			})).data);
		},
		persister
	});
}
function ItemPickerFetcher$3(t0) {
	const $ = c(22);
	const { owner, repo, ...rest } = t0;
	const [isLoading, setIsLoading] = useState(false);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const [openCount, setOpenCount] = useState(1);
	const queryClient = useQueryClient();
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	useEffect(_temp$22, t1);
	let t2;
	if ($[1] !== owner || $[2] !== queryClient || $[3] !== repo || $[4] !== sendAnalyticsEvent) {
		t2 = () => {
			const fetchInitialIssueTypes = async () => {
				try {
					setIsLoading(true);
					const persister = async (queryFn, context, query) => {
						return createIssueTypePersister(sendAnalyticsEvent)(queryFn, context, query);
					};
					setData(await fetchIssueTypes(queryClient, {
						owner,
						repo,
						query: "",
						persister
					}));
					setIsLoading(false);
					setIsError(false);
				} catch {
					setIsError(true);
					setIsLoading(false);
				}
			};
			fetchInitialIssueTypes();
		};
		$[1] = owner;
		$[2] = queryClient;
		$[3] = repo;
		$[4] = sendAnalyticsEvent;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== fetchKey || $[7] !== owner || $[8] !== queryClient || $[9] !== repo || $[10] !== sendAnalyticsEvent) {
		t3 = [
			fetchKey,
			owner,
			repo,
			queryClient,
			sendAnalyticsEvent
		];
		$[6] = fetchKey;
		$[7] = owner;
		$[8] = queryClient;
		$[9] = repo;
		$[10] = sendAnalyticsEvent;
		$[11] = t3;
	} else t3 = $[11];
	useEffect(t2, t3);
	let t4;
	let t5;
	if ($[12] !== data || $[13] !== isLoading || $[14] !== openCount || $[15] !== sendAnalyticsEvent) {
		t4 = () => {
			if (!isLoading && data && openCount > 0) try {
				performance.mark("issue-type-picker-rendered");
				sendAnalyticsEvent("issue_type_picker.render_duration", void 0, {
					duration: performance.measure("issue-type-picker-duration", "issue-type-picker-opened", "issue-type-picker-rendered").duration,
					caching_enabled: true
				});
				performance.clearMarks("issue-type-picker-opened");
				performance.clearMarks("issue-type-picker-rendered");
				performance.clearMeasures("issue-type-picker-duration");
			} catch {}
		};
		t5 = [
			isLoading,
			data,
			sendAnalyticsEvent,
			openCount
		];
		$[12] = data;
		$[13] = isLoading;
		$[14] = openCount;
		$[15] = sendAnalyticsEvent;
		$[16] = t4;
		$[17] = t5;
	} else {
		t4 = $[16];
		t5 = $[17];
	}
	useEffect(t4, t5);
	const anchorRef = useRef(null);
	let t6;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => {
			performance.mark("issue-type-picker-opened");
			setOpenCount(_temp2$13);
		};
		$[18] = t6;
	} else t6 = $[18];
	const handleOpen = t6;
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("types"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	if (isError) {
		let t7;
		if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setFetchKey(_temp3$12);
			$[19] = t7;
		} else t7 = $[19];
		let t8;
		if ($[20] !== createFallbackComponent) {
			t8 = createFallbackComponent(t7);
			$[20] = createFallbackComponent;
			$[21] = t8;
		} else t8 = $[21];
		return t8;
	}
	return jsx(IssueTypePickerBase, {
		issueTypes: data?.issueTypes ?? [],
		isLoading,
		...rest,
		onOpen: handleOpen
	});
}
ItemPickerFetcher$3.displayName = "ItemPickerFetcher";
function _temp3$12(current) {
	return current + 1;
}
function _temp2$13(prev) {
	return prev + 1;
}
function _temp$22() {
	performance.mark("issue-type-picker-opened");
}
function IssueTypePicker({ owner, repo, anchorElement, readonly, activeIssueType, ...rest }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		keybindingCommandId: "item-pickers:open-issue-type",
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		createChild: () => /* @__PURE__ */ jsx(ItemPickerFetcher$3, {
			owner,
			repo,
			readonly,
			activeIssueType,
			triggerOpen: true,
			anchorElement,
			...rest
		}),
		insidePortal: rest.insidePortal
	});
}
IssueTypePicker.displayName = "IssueTypePicker";
var LabelDots_module_default = {
	labelDot: "LabelDots-module_j_FyCG_labelDot",
	labelDotsContainer: "LabelDots-module_j_FyCG_labelDotsContainer"
};
var LabelDots = ({ MAX_DISPLAYED_LABELS = 5, labelColors }) => {
	return /* @__PURE__ */ jsx("div", {
		className: LabelDots_module_default.labelDotsContainer,
		children: labelColors.slice(0, MAX_DISPLAYED_LABELS).map((color, i) => /* @__PURE__ */ jsx("div", {
			style: { backgroundColor: `#${color}` },
			className: LabelDots_module_default.labelDot
		}, `${i}-${color}`))
	});
};
LabelDots.displayName = "LabelDots";
var CompressedLabelsToken = ({ ref, size = "large", labelNamesWithColor, anchorProps, MAX_DISPLAYED_LABELS = 5, readonly, leadingIcon, hotKey, anchorText }) => {
	const compressedLabelTitle = labelNamesWithColor.slice(0, MAX_DISPLAYED_LABELS).map((a) => a.nameHTML).join(", ").concat(labelNamesWithColor.length > MAX_DISPLAYED_LABELS ? `, ${labelNamesWithColor.length - MAX_DISPLAYED_LABELS}+` : "");
	return /* @__PURE__ */ jsx(SharedPicker, {
		anchorProps,
		readonly,
		anchorText: anchorText ? anchorText : labelNamesWithColor.length > 1 ? LABELS$3.labels : LABELS$3.noLabels,
		sharedPickerMainValue: labelNamesWithColor.length > 0 && /* @__PURE__ */ jsx(LabelNames, {
			labelNamesWithColor,
			MAX_DISPLAYED_LABELS,
			compressedLabelTitle
		}),
		leadingIconElement: labelNamesWithColor.length > 0 && /* @__PURE__ */ jsx(LabelDots, {
			MAX_DISPLAYED_LABELS,
			labelColors: labelNamesWithColor.map((l) => l.color)
		}),
		ariaLabel: LABELS$3.selectLabels,
		size,
		leadingIcon,
		hotKey,
		ref,
		compressedTitle: compressedLabelTitle
	});
};
CompressedLabelsToken.displayName = "CompressedLabelsToken";
CompressedLabelsToken.displayName = "CompressedLabelsToken";
var LabelNames = ({ compressedLabelTitle }) => {
	return /* @__PURE__ */ jsx(VerifiedHTMLText, { html: compressedLabelTitle });
};
LabelNames.displayName = "LabelNames";
var CompressedLabelAnchor = ({ ref, size = "small", labels, anchorProps, displayHotkey, MAX_DISPLAYED_LABELS = 2, readonly }) => {
	return /* @__PURE__ */ jsx(CompressedLabelsToken, {
		size,
		labelNamesWithColor: labels.map((l) => ({
			nameHTML: l.nameHTML,
			color: l.color
		})),
		anchorProps,
		MAX_DISPLAYED_LABELS,
		readonly,
		leadingIcon: TagIcon,
		hotKey: !readonly && displayHotkey ? HOTKEYS.labelPicker.toUpperCase() : void 0,
		anchorText: labels?.length === 0 ? LABELS$3.noLabels : void 0,
		ref
	});
};
CompressedLabelAnchor.displayName = "CompressedLabelAnchor";
CompressedLabelAnchor.displayName = "CompressedLabelAnchor";
var DefaultLabelPickerAnchor = ({ ref, labels, readonly, anchorProps }) => {
	return /* @__PURE__ */ jsx(CompressedLabelAnchor, {
		labels,
		readonly,
		displayHotkey: false,
		anchorProps: readonly ? void 0 : anchorProps,
		ref
	});
};
DefaultLabelPickerAnchor.displayName = "DefaultLabelPickerAnchor";
DefaultLabelPickerAnchor.displayName = "DefaultLabelAnchor";
var URLS = { labelPageSuffix: "/issues/labels" };
var LabelPickerBase_module_default = {
	labelColorBox: "LabelPickerBase-module_nhFLda_labelColorBox",
	labelNameText: "LabelPickerBase-module_nhFLda_labelNameText",
	labelPickerContainer: "LabelPickerBase-module_nhFLda_labelPickerContainer",
	labelPickerItem: "LabelPickerBase-module_nhFLda_labelPickerItem"
};
var DEFAULT_SUGGESTIONS = [];
var FILTERED_RESULTS_LIMIT = 30;
var labelsGroup = {
	groupId: "labels",
	header: {
		title: "Selected labels",
		variant: "filled"
	}
};
var favoriteGroup = {
	groupId: "favorite",
	header: {
		title: "Favorite",
		variant: "filled"
	}
};
var suggestionsGroup = {
	groupId: "suggestions",
	header: {
		title: "Suggestions",
		variant: "filled"
	}
};
var copilotGroup = {
	groupId: "copilot",
	header: {
		title: "Copilot suggestions",
		variant: "filled"
	}
};
function LabelPickerBase({ labels: selectedLabels, suggestions = DEFAULT_SUGGESTIONS, totalNumberOfLabels, copilotSuggestedLabels, favoriteLabelIds, searchLabels, onSelectionChange, insidePortal, anchorElement, nested = false, triggerOpen = true, initialFilter, owner, repo, showEditLabelsButton = true, noLabelOption = void 0, title, showNoMatchItem = false, showColors = true, canCreateLabel, repositoryId, isLoading = false, setIsLoading, onCreate }) {
	const removeLabelsLoadingEnabled = isFeatureEnabled("issues_react_remove_labels_loading");
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	const [filter, setFilter] = useState("");
	const deferredFilterValue = useDeferredValue(filter);
	const filterTermCache = useRef(/* @__PURE__ */ new Set());
	const [isServerFetching, setIsServerFetching] = useState(false);
	const [loadedLabels, setLoadedLabels] = useState(suggestions);
	const { addToast } = useToastContext();
	const repoNwo = `${owner}/${repo}`;
	useEffect(() => {
		setLoadedLabels(suggestions);
	}, [suggestions]);
	const shouldServerFetch = searchLabels && totalNumberOfLabels > suggestions.length;
	const sortedSelectedLabels = useMemo(() => selectedLabels.slice().sort((a, b) => a.name.localeCompare(b.name)), [selectedLabels]);
	const getLabelName = useCallback((l) => l.name, []);
	const getLabelNameAndDescription = useCallback((l_0) => `${l_0.name} ${l_0.description ?? ""}`, []);
	const items = useMemo(() => {
		if (!deferredFilterValue) {
			const relevantLabels = removeLabelsLoadingEnabled ? loadedLabels : suggestions;
			const allLabels = [...sortedSelectedLabels];
			const unselectedCopilotLabels = (copilotSuggestedLabels ?? []).filter((l_1) => !selectedLabels.find((l2) => l2.id === l_1.id));
			const unselectedRegularLabels = relevantLabels.filter((l_2) => !selectedLabels.find((l2_1) => l2_1.id === l_2.id) && !unselectedCopilotLabels.find((l2_0) => l2_0.id === l_2.id));
			allLabels.push(...unselectedCopilotLabels, ...unselectedRegularLabels);
			return allLabels.slice(0, VALUES.labelsInitialLoadCount);
		}
		const uniqueItemsMap = /* @__PURE__ */ new Map();
		for (const label of loadedLabels) uniqueItemsMap.set(label.id, label);
		for (const label_0 of copilotSuggestedLabels ?? []) if (!uniqueItemsMap.has(label_0.id)) uniqueItemsMap.set(label_0.id, label_0);
		return fuzzyFilter({
			items: Array.from(uniqueItemsMap.values()),
			filter: deferredFilterValue,
			key: getLabelName,
			secondaryKey: getLabelNameAndDescription
		}).slice(0, FILTERED_RESULTS_LIMIT);
	}, [
		deferredFilterValue,
		loadedLabels,
		removeLabelsLoadingEnabled,
		suggestions,
		sortedSelectedLabels,
		copilotSuggestedLabels,
		selectedLabels,
		getLabelName,
		getLabelNameAndDescription
	]);
	const fetchSearchData = useCallback(async (query) => {
		if (!removeLabelsLoadingEnabled && query === "") {
			setLoadedLabels(suggestions);
			setIsServerFetching(false);
			return;
		}
		if (removeLabelsLoadingEnabled && filterTermCache.current.has(query)) {
			setIsServerFetching(false);
			return;
		}
		if (!searchLabels) return;
		setIsServerFetching(true);
		try {
			setLoadedLabels(removeLabelsLoadingEnabled ? uniqById([...loadedLabels, ...await searchLabels(query)]) : await searchLabels(query));
		} catch {
			addToast({
				type: "error",
				message: ERRORS$2.couldNotSearchLabels
			});
		} finally {
			setIsServerFetching(false);
			if (removeLabelsLoadingEnabled) filterTermCache.current.add(query);
		}
	}, [
		removeLabelsLoadingEnabled,
		searchLabels,
		suggestions,
		loadedLabels,
		addToast
	]);
	const debounceFetchSearchData = useDebounce((nextValue) => fetchSearchData(nextValue), VALUES.pickerDebounceTime);
	const filterItems = useCallback((value) => {
		const trimmedFilter = value.trim();
		if (filter !== trimmedFilter && shouldServerFetch) {
			setIsServerFetching(true);
			debounceFetchSearchData(trimmedFilter);
			setFilter(value);
			return;
		}
		if (suggestions.length !== 0) setFilter(value);
	}, [
		debounceFetchSearchData,
		filter,
		shouldServerFetch,
		suggestions.length
	]);
	const getItemKey = useCallback((label_1) => label_1.id, []);
	const createNewLabel = useCallback((_, label_2, event) => {
		event.preventDefault();
		event.stopPropagation();
		if (!repositoryId || !onCreate || !setIsLoading) return;
		setIsLoading(true);
		onCreate({
			repositoryId,
			color: label_2.color,
			name: label_2.name
		}, {
			onError: () => {
				addToast({
					type: "error",
					message: ERRORS$2.couldNotCreateLabel
				});
				setIsLoading(false);
			},
			onSuccess: (response) => {
				if (response) setLoadedLabels([{
					...response,
					__isNew__: true
				}, ...loadedLabels]);
				setIsLoading(false);
			}
		});
	}, [
		addToast,
		loadedLabels,
		onCreate,
		repositoryId,
		setIsLoading
	]);
	const convertToItemProps = useCallback((label_3) => {
		if (noLabelOption && label_3.id === SPECIAL_VALUES.noLabelsData.id) {
			const noLabelItem = { ...noLabelOption };
			noLabelItem.groupId = noLabelItem.selected ? labelsGroup.groupId : suggestionsGroup.groupId;
			return noLabelItem;
		}
		if (label_3.id === filter) return {
			id: label_3.id,
			description: label_3.description || void 0,
			descriptionVariant: "block",
			source: label_3,
			text: `Create new label: "${label_3.name}"`,
			trailingVisual: PlusIcon,
			className: LabelPickerBase_module_default.labelPickerItem,
			onAction: (item, event_0) => createNewLabel(item, label_3, event_0)
		};
		const isCopilotLabel = (copilotSuggestedLabels ?? []).some((copilotLabel) => copilotLabel.id === label_3.id);
		const isfavoriteLabel = (favoriteLabelIds ?? []).some((favoriteLabelId) => favoriteLabelId === label_3.id);
		let groupId;
		if (selectedLabels.find((l_3) => l_3.id === label_3.id)) groupId = labelsGroup.groupId;
		else if (isfavoriteLabel) groupId = favoriteGroup.groupId;
		else if (isCopilotLabel) groupId = copilotGroup.groupId;
		else groupId = suggestionsGroup.groupId;
		return {
			id: label_3.id,
			description: label_3.description ?? void 0,
			descriptionVariant: "block",
			children: /* @__PURE__ */ jsx(VerifiedHTMLText, {
				html: label_3.nameHTML,
				className: LabelPickerBase_module_default.labelNameText
			}),
			source: label_3,
			groupId,
			leadingVisual: showColors ? () => /* @__PURE__ */ jsx("div", {
				style: {
					background: `#${label_3.color}`,
					borderColor: `#${label_3.color}`
				},
				className: LabelPickerBase_module_default.labelColorBox
			}) : void 0
		};
	}, [
		noLabelOption,
		filter,
		copilotSuggestedLabels,
		favoriteLabelIds,
		selectedLabels,
		createNewLabel,
		showColors
	]);
	const groups = useMemo(() => {
		const itemGroups = [];
		if (selectedLabels.length > 0) itemGroups.push(labelsGroup);
		if ((favoriteLabelIds ?? []).some((favoriteLabelId_0) => !selectedLabels.some((selectedLabel) => selectedLabel.id === favoriteLabelId_0))) itemGroups.push(favoriteGroup);
		if ((copilotSuggestedLabels ?? []).some((label_4) => !selectedLabels.some((selectedLabel_0) => selectedLabel_0.id === label_4.id) && favoriteLabelIds?.indexOf(label_4.id) === -1)) itemGroups.push(copilotGroup);
		if (items.length > 0 && items.length - selectedLabels.length > 0) itemGroups.push(suggestionsGroup);
		return itemGroups;
	}, [
		selectedLabels,
		favoriteLabelIds,
		copilotSuggestedLabels,
		items.length
	]);
	const editLabelsPath = useMemo(() => {
		if (!repoNwo || !ssrSafeDocument?.location) return void 0;
		return `${ssrSafeDocument.location.origin}/${repoNwo}${URLS.labelPageSuffix}`;
	}, [repoNwo]);
	const onEditLabels = useCallback((e) => {
		if (ssrSafeDocument?.location?.href && showEditLabelsButton && editLabelsPath) {
			if (e.button === 1) return;
			if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
			e.preventDefault();
			ssrSafeDocument.location.href = editLabelsPath;
		}
	}, [editLabelsPath, showEditLabelsButton]);
	const anchorRef = useRef(null);
	const showNoMatchMessage = useMemo(() => {
		const noPickerItems = !isServerFetching && !filter && items.length === 0;
		const noFilterResults = !(showNoMatchItem && canCreateLabel && !isServerFetching) && !!filter && items.length === 0;
		return noPickerItems || noFilterResults;
	}, [
		isServerFetching,
		filter,
		items.length,
		showNoMatchItem,
		canCreateLabel
	]);
	return /* @__PURE__ */ jsx("div", {
		className: LabelPickerBase_module_default.labelPickerContainer,
		children: /* @__PURE__ */ jsx(ItemPicker, {
			loading: removeLabelsLoadingEnabled ? isLoading : isLoading || isServerFetching,
			items,
			initialSelectedItems: selectedLabels,
			title: title || LABELS$3.labelsHeader,
			filterItems,
			getItemKey,
			convertToItemProps,
			placeholderText: "Filter labels",
			selectionVariant: items.length === 0 ? "single" : "multiple",
			onSelectionChange,
			renderAnchor: (props) => anchorElement(props, anchorRef),
			groups: !filter ? groups : void 0,
			insidePortal,
			height: "large",
			width: "medium",
			nested,
			resultListAriaLabel: "Label results",
			triggerOpen,
			initialFilter,
			selectPanelRef: anchorRef,
			keybindingCommandId: "item-pickers:open-labels",
			eventsTag: "label",
			customNoMatchItem: canCreateLabel && showNoMatchItem && filter && !isServerFetching ? {
				id: filter,
				color: "aaaaaa",
				name: filter,
				nameHTML: filter,
				description: void 0,
				url: ""
			} : void 0,
			suppressNoMatchItem: true,
			improvedNoMatchAccessibility: showNoMatchMessage,
			noMatchMessage: showNoMatchMessage ? {
				title: "No labels were found",
				body: "Try searching with a different query for results.",
				variant: "empty"
			} : void 0,
			secondaryAction: showEditLabelsButton ? /* @__PURE__ */ jsx(SelectPanel.SecondaryActionLink, {
				onClick: onEditLabels,
				href: editLabelsPath,
				size: "small",
				children: LABELS$3.editLabels
			}) : void 0,
			responsiveOnNarrow: responsiveOnNarrowEnabled,
			focusPrependedElements: true
		})
	});
}
LabelPickerBase.displayName = "LabelPickerBase";
var uniqById = (arr) => {
	return arr.filter((i, idx, a) => a.findIndex((item) => item.id === i.id) === idx);
};
async function apiGetSearchLabels({ owner, repo, query, count, labelNames }) {
	const params = {
		owner,
		repo
	};
	if (query) params["query"] = query;
	if (count) params["count"] = count;
	if (labelNames && labelNames.length > 0) params["labelNames"] = labelNames.join(",");
	return await (await verifiedFetchJSON(buildItemPickerSearchUrl("labels", params))).json();
}
var itemPickerQueryKeyBase$2 = "item_picker";
function buildItemPickerLabelSearchQueryKey(searchParams) {
	return [
		itemPickerQueryKeyBase$2,
		"labels",
		searchParams
	];
}
/**
* Helper function to strip quotes from label names and optionally filter labels by those names
* @param labelNames Array of label names that may have quotes
* @param labels Optional array of labels to filter
* @returns Object with stripped names and optionally filtered labels
*/
function processLabelNames(labelNames, labels) {
	const strippedNames = labelNames.map((name) => name.replace(/^"/, "").replace(/"$/, ""));
	return labels.filter((label) => strippedNames.includes(label.name));
}
function transformSearchLabelResponseToQueryData(response, labelNames) {
	let matchedLabels = response.repository.labelsByNames?.nodes;
	if (labelNames && labelNames.length > 0 && matchedLabels) matchedLabels = processLabelNames(labelNames, matchedLabels);
	return {
		labels: response.repository.labels.nodes,
		repositoryId: response.repository.id,
		totalCount: response.repository.labels.totalCount,
		labelsByNames: matchedLabels
	};
}
function isLabel(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	const item = obj;
	return typeof item.id === "string" && typeof item.color === "string" && typeof item.name === "string" && typeof item.nameHTML === "string" && (typeof item.description === "string" || item.description === null || item.description === void 0) && typeof item.url === "string";
}
function isLabelPickerQueryData(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	const data = obj;
	return typeof data.repositoryId === "string" && typeof data.totalCount === "number" && Array.isArray(data.labels) && data.labels.every(isLabel) && (data.labelsByNames === void 0 || Array.isArray(data.labelsByNames) && data.labelsByNames.every(isLabel));
}
var LabelPickerQueryDataValidator = {
	Check: (value) => isLabelPickerQueryData(value),
	Code: () => "manual-validator",
	*Errors() {}
};
function createLabelPersister(sendAnalyticsEvent) {
	return createPersister({
		validator: LabelPickerQueryDataValidator,
		sendAnalyticsEvent,
		enabled: true
	});
}
async function apiCreateLabel(request) {
	return (await verifiedFetchJSON(buildItemPickersUrl("labels"), {
		method: "POST",
		body: request
	})).json();
}
var useCreateLabelMutation = () => {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { mutationFn: _temp$21 };
		$[0] = t0;
	} else t0 = $[0];
	return useMutation(t0);
};
async function _temp$21(request) {
	return parseGraphQLResponse(await apiCreateLabel(request)).data.createLabel.label;
}
async function fetchLabels(queryClient, { owner, repo, query, count, labelNames, persister }) {
	return await queryClient.fetchQuery({
		queryKey: buildItemPickerLabelSearchQueryKey({
			owner,
			repo,
			query,
			count,
			labelNames
		}),
		queryFn: async () => {
			return transformSearchLabelResponseToQueryData(parseGraphQLResponse(await apiGetSearchLabels({
				owner,
				repo,
				query,
				count,
				labelNames
			})).data, labelNames);
		},
		persister
	});
}
function ItemPickerFetcher$2({ repo, owner, labels, labelNames, noLabelOption, ...rest }) {
	const [isLoading, setIsLoading] = useState(true);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const [initialLabels, setInitialLabels] = useState(labels);
	const queryClient = useQueryClient();
	const { mutate: createLabelMutate } = useCreateLabelMutation();
	const { sendAnalyticsEvent } = useAnalytics();
	useEffect(() => {
		const fetchInitialLabels = async () => {
			try {
				setIsLoading(true);
				const persister = async (queryFn, context, query) => {
					return createLabelPersister(sendAnalyticsEvent)(queryFn, context, query);
				};
				const response = await fetchLabels(queryClient, {
					owner,
					repo,
					query: "",
					count: 1e3,
					labelNames,
					persister
				});
				setData(response);
				if (labelNames && labelNames.length > 0) setInitialLabels(response.labelsByNames || []);
				setIsLoading(false);
				setIsError(false);
			} catch {
				setIsError(true);
				setIsLoading(false);
			}
		};
		fetchInitialLabels();
	}, [
		fetchKey,
		owner,
		queryClient,
		repo,
		labelNames,
		sendAnalyticsEvent
	]);
	const anchorRef = useRef(null);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("labels"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	const fetchLabelsWithQueryClient = useCallback(async (query_0) => {
		return (await fetchLabels(queryClient, {
			owner,
			repo,
			query: query_0
		})).labels;
	}, [
		queryClient,
		owner,
		repo
	]);
	const onCreate = useCallback((input, { onSuccess, onError }) => {
		createLabelMutate(input, {
			onSuccess,
			onError
		});
	}, [createLabelMutate]);
	const suggestions = useMemo(() => {
		const suggestionsList = data?.labels ?? [];
		if (noLabelOption) return [SPECIAL_VALUES.noLabelsData, ...suggestionsList];
		return suggestionsList;
	}, [data?.labels, noLabelOption]);
	const allLabels = useMemo(() => {
		const labelsList = labelNames ? initialLabels : labels;
		if (noLabelOption?.selected && !labelsList.find((l) => l.id === SPECIAL_VALUES.noLabelsData.id)) return [SPECIAL_VALUES.noLabelsData, ...labelsList];
		return labelsList;
	}, [
		initialLabels,
		labelNames,
		labels,
		noLabelOption?.selected
	]);
	if (isError) return createFallbackComponent(() => setFetchKey((current) => current + 1));
	return /* @__PURE__ */ jsx(LabelPickerBase, {
		repo,
		owner,
		repositoryId: data?.repositoryId ?? "",
		labels: allLabels,
		suggestions,
		totalNumberOfLabels: data?.totalCount ?? 0,
		isLoading,
		setIsLoading,
		searchLabels: fetchLabelsWithQueryClient,
		onCreate,
		noLabelOption,
		...rest
	});
}
ItemPickerFetcher$2.displayName = "ItemPickerFetcher";
function LabelPicker({ repo, owner, anchorElement, readonly, labels, labelNames, noLabelOption, ...rest }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		keybindingCommandId: "item-pickers:open-labels",
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		createChild: () => /* @__PURE__ */ jsx(ItemPickerFetcher$2, {
			repo,
			owner,
			readonly,
			initialFilter: "",
			labels,
			labelNames,
			triggerOpen: true,
			anchorElement,
			noLabelOption,
			...rest
		}),
		insidePortal: rest.insidePortal
	});
}
LabelPicker.displayName = "LabelPicker";
var DefaultMilestonePickerAnchor = ({ ref, activeMilestone, readonly, nested, anchorProps }) => {
	return /* @__PURE__ */ jsx(SharedPicker, {
		anchorText: LABELS$3.noMilestones,
		sharedPickerMainValue: activeMilestone?.title,
		anchorProps: readonly ? void 0 : anchorProps,
		ariaLabel: LABELS$3.selectMilestones,
		readonly,
		nested,
		leadingIcon: MilestoneIcon,
		hotKey: void 0,
		ref
	});
};
DefaultMilestonePickerAnchor.displayName = "DefaultMilestonePickerAnchor";
DefaultMilestonePickerAnchor.displayName = "DefaultMilestonePickerAnchor";
var RelativeTimeDescription = ({ closed, givenDate, currentDate }) => {
	const relativeMonth = closed ? "short" : "long";
	const relativeYear = closed && !isInPreviousYears(givenDate, currentDate) ? void 0 : "numeric";
	const relativeTense = closed && isGreaterThanAMonth(currentDate, givenDate) ? "auto" : "past";
	const relativeFormat = closed ? "auto" : "elapsed";
	const relativePrecision = closed ? "second" : isGreaterThanAMonth(givenDate, currentDate) ? "month" : "day";
	return /* @__PURE__ */ jsx(RelativeTime, {
		date: givenDate,
		day: "numeric",
		month: relativeMonth,
		tense: isInPreviousYears(givenDate, currentDate) ? void 0 : relativeTense,
		year: relativeYear,
		format: relativeFormat,
		precision: relativePrecision,
		"data-testid": LABELS$3.testIds.relativeTimeDescription
	});
};
RelativeTimeDescription.displayName = "RelativeTimeDescription";
var isInPreviousYears = (givenDate, currentDate) => {
	const currentYear = currentDate.getFullYear();
	return givenDate.getFullYear() < currentYear;
};
var isGreaterThanAMonth = (givenDate, currentDate) => {
	const yearDiff = givenDate.getFullYear() - currentDate.getFullYear();
	const monthDiff = givenDate.getMonth() - currentDate.getMonth();
	return yearDiff * 12 + monthDiff >= 1;
};
var MilestoneDescription_module_default = {
	danger: "MilestoneDescription-module_cEM_Iq_danger",
	subtle: "MilestoneDescription-module_cEM_Iq_subtle"
};
var MilestoneDescription = (t0) => {
	const $ = c(10);
	const { closed, closedAt, dueOn, progressPercentage, showProgressPercentage: t1 } = t0;
	const showProgressPercentage = t1 === void 0 ? false : t1;
	const date = closed ? closedAt : dueOn;
	const { isBrowser } = useRuntimeEnvironment();
	if (!date || !isValidDate(date)) return LABELS$3.milestones.noDueDate;
	let t2;
	if ($[0] !== closed || $[1] !== date || $[2] !== dueOn || $[3] !== isBrowser || $[4] !== progressPercentage || $[5] !== showProgressPercentage) {
		const givenDate = new Date(date);
		const currentDate = /* @__PURE__ */ new Date();
		let t3;
		if ($[7] !== date || $[8] !== dueOn) {
			t3 = dueOn ? new Date(date) < /* @__PURE__ */ new Date() : false;
			$[7] = date;
			$[8] = dueOn;
			$[9] = t3;
		} else t3 = $[9];
		const isPastDate = t3 && !isToday$1(givenDate, currentDate);
		t2 = jsx("div", {
			className: isPastDate && !closed ? MilestoneDescription_module_default.danger : MilestoneDescription_module_default.subtle,
			children: isBrowser ? jsxs(Fragment$1, { children: [
				getMilestoneDescriptionLabel({
					isPastDate,
					closed
				}),
				"\xA0",
				!isPastDate && !closed ? dueOnDateDescription(date) : jsx(RelativeTimeDescription, {
					closed,
					givenDate,
					currentDate
				}),
				progressPercentage && showProgressPercentage ? LABELS$3.milestones.progressPercentage(progressPercentage) : ""
			] }) : jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "sm",
				width: "50%"
			})
		});
		$[0] = closed;
		$[1] = date;
		$[2] = dueOn;
		$[3] = isBrowser;
		$[4] = progressPercentage;
		$[5] = showProgressPercentage;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
};
MilestoneDescription.displayName = "MilestoneDescription";
var getMilestoneDescriptionLabel = ({ isPastDate, closed }) => {
	if (closed) return LABELS$3.milestones.milestoneClosed;
	if (isPastDate) return LABELS$3.milestones.pastDue;
	return LABELS$3.milestones.milestoneDue;
};
var dueOnDateDescription = (date) => {
	return new Date(date).toLocaleDateString("en-us", {
		month: "long",
		year: "numeric",
		day: "numeric"
	});
};
var isValidDate = (dateString) => {
	const date = new Date(dateString);
	return !isNaN(date.getTime());
};
var isToday$1 = (givenDate, currentDate) => {
	return givenDate.getFullYear() === currentDate.getFullYear() && givenDate.getMonth() === currentDate.getMonth() && givenDate.getUTCDate() === currentDate.getUTCDate();
};
var ItemPickerMilestone_module_default = {
	MilestoneFilterItem: "ItemPickerMilestone-module_tcos1a_MilestoneFilterItem",
	MilestoneItem: "ItemPickerMilestone-module_tcos1a_MilestoneItem"
};
var openGroup = {
	groupId: "open",
	header: {
		title: "Open",
		variant: "filled"
	}
};
var closedGroup = {
	groupId: "closed",
	header: {
		title: "Closed",
		variant: "filled"
	}
};
function compareMilestones(a, b) {
	if (!a.closed && !b.closed) {
		if (a.dueOn && b.dueOn) return new Date(a.dueOn).getTime() - new Date(b.dueOn).getTime();
		if (a.dueOn) return -1;
		if (b.dueOn) return 1;
		return a.title.localeCompare(b.title);
	}
	if (a.closed && b.closed) {
		if (a.closedAt && b.closedAt) return new Date(b.closedAt).getTime() - new Date(a.closedAt).getTime();
		if (a.closedAt) return -1;
		if (b.closedAt) return 1;
		return a.title.localeCompare(b.title);
	}
	return a.closed ? 1 : -1;
}
function MilestonePickerBase({ repo, owner, milestones, repositoryId, activeMilestone, onSelectionChange, insidePortal, anchorElement, nested, triggerOpen, initialFilter, isLoading, setIsLoading, noMilestoneItem, showMilestoneDescription, title, canCreateMilestone, fetchMilestones, onCreate, showNoMatchItem = false }) {
	const [filter, setFilter] = useState("");
	const deferredFilter = useDeferredValue(filter);
	const [isServerFetching, setIsServerFetching] = useState(false);
	const [searchedMilestones, setSearchedMilestones] = useState();
	const [loadedMilestones, setLoadedMilestones] = useState([]);
	const { addToast } = useToastContext();
	const items = useMemo(() => {
		if (searchedMilestones !== void 0 && searchedMilestones.length > 0) return searchedMilestones;
		const repositoryMilestones = milestones.slice().sort(compareMilestones).concat(loadedMilestones);
		if (noMilestoneItem) repositoryMilestones.unshift(SPECIAL_VALUES.noMilestoneData);
		if (!deferredFilter) return repositoryMilestones;
		return repositoryMilestones.filter((l) => l.title.toLowerCase().indexOf(deferredFilter.toLowerCase()) >= 0);
	}, [
		milestones,
		deferredFilter,
		loadedMilestones,
		noMilestoneItem,
		searchedMilestones
	]);
	const isNoMilestoneSelected = noMilestoneItem && noMilestoneItem.selected;
	const openItems = useMemo(() => {
		if (noMilestoneItem) return items.filter((m) => m.closed === false);
		else return [];
	}, [noMilestoneItem, items]);
	const searchMilestones = useCallback(async (query) => {
		setIsServerFetching(true);
		setFilter(query);
		try {
			const fetchedData = await fetchMilestones({
				query,
				owner,
				repo,
				count: 10
			});
			if (fetchedData !== void 0) {
				if (noMilestoneItem && hasFuzzyMatch(query, noMilestoneItem.source?.title ?? "")) fetchedData.unshift(SPECIAL_VALUES.noMilestoneData);
				setSearchedMilestones(fetchedData);
			}
		} catch {
			addToast({
				type: "error",
				message: ERRORS$2.couldNotSearchMilestones
			});
		} finally {
			setIsServerFetching(false);
		}
	}, [
		addToast,
		fetchMilestones,
		noMilestoneItem,
		owner,
		repo
	]);
	const debounceFetchSearchData = useDebounce((nextValue) => searchMilestones(nextValue), VALUES.pickerDebounceTime);
	const filterItems = useCallback(async (value) => {
		const trimmedFilter = value.trim();
		if (filter === trimmedFilter) return;
		if (trimmedFilter === "") {
			setSearchedMilestones(void 0);
			setFilter(trimmedFilter);
			return;
		}
		debounceFetchSearchData(trimmedFilter);
	}, [debounceFetchSearchData, filter]);
	const getItemKey = useCallback((milestone) => milestone.id, []);
	const createNewMilestone = useCallback((_, milestone_0, event) => {
		event.preventDefault();
		event.stopPropagation();
		if (!repositoryId) return;
		setIsLoading(true);
		onCreate({
			repositoryId,
			title: milestone_0.title
		}, {
			onError: () => {
				addToast({
					type: "error",
					message: ERRORS$2.couldNotCreateMilestone
				});
				setIsLoading(false);
			},
			onSuccess: (newMilestone) => {
				if (newMilestone) setLoadedMilestones([{
					...newMilestone,
					__isNew__: true
				}, ...loadedMilestones]);
				setIsLoading(false);
			}
		});
	}, [
		addToast,
		loadedMilestones,
		onCreate,
		repositoryId,
		setIsLoading
	]);
	const convertToItemProps = useCallback((milestone_1) => {
		if (noMilestoneItem && milestone_1.id === SPECIAL_VALUES.noMilestoneData.id) return { ...noMilestoneItem };
		if (milestone_1.id === filter) return {
			id: milestone_1.id,
			text: `Create new milestone: "${milestone_1.title}"`,
			source: milestone_1,
			trailingVisual: PlusIcon,
			className: ItemPickerMilestone_module_default.MilestoneFilterItem,
			onAction: (item, event_0) => createNewMilestone(item, milestone_1, event_0)
		};
		const { closed, closedAt, progressPercentage, dueOn } = milestone_1;
		return {
			id: milestone_1.id,
			text: milestone_1.title,
			description: showMilestoneDescription ? /* @__PURE__ */ jsx(MilestoneDescription, {
				closed,
				closedAt,
				progressPercentage,
				dueOn,
				showProgressPercentage: false
			}) : void 0,
			descriptionVariant: "block",
			className: ItemPickerMilestone_module_default.MilestoneItem,
			source: milestone_1,
			groupId: milestone_1.closed ? closedGroup.groupId : openGroup.groupId,
			leadingVisual: () => /* @__PURE__ */ jsx(MilestoneIcon, { size: 16 })
		};
	}, [
		createNewMilestone,
		filter,
		noMilestoneItem,
		showMilestoneDescription
	]);
	const groups = useMemo(() => {
		const itemGroups = [];
		if (items.some((i) => !i.closed)) itemGroups.push(openGroup);
		if (items.some((i_0) => i_0.closed)) itemGroups.push(closedGroup);
		return itemGroups;
	}, [items]);
	if (noMilestoneItem && isNoMilestoneSelected) activeMilestone = SPECIAL_VALUES.noMilestoneData;
	const anchorRef = useRef(null);
	const initialSelectedItems = useMemo(() => {
		return activeMilestone ? [activeMilestone] : [];
	}, [activeMilestone]);
	const showNoMatchMessage = useMemo(() => {
		const hasNoItems = !isServerFetching && !filter && items.length === 0;
		const hasNoFilterResults = !(showNoMatchItem && canCreateMilestone) && !!filter && items.length === 0;
		return hasNoItems || hasNoFilterResults;
	}, [
		filter,
		isServerFetching,
		items.length,
		showNoMatchItem,
		canCreateMilestone
	]);
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	return /* @__PURE__ */ jsx(ItemPicker, {
		loading: isLoading || isServerFetching,
		items: noMilestoneItem ? openItems : items,
		initialSelectedItems,
		filterItems,
		title: title ?? LABELS$3.milestonesHeader,
		getItemKey,
		convertToItemProps,
		placeholderText: `Filter milestones ${milestones.length >= VALUES.milestonesMaxPreloadCount ? `(${VALUES.milestonesMaxPreloadCount} milestones loaded)` : ""}`,
		selectionVariant: "single",
		onSelectionChange,
		groups: noMilestoneItem ? void 0 : groups,
		renderAnchor: (props) => anchorElement(props, anchorRef),
		insidePortal,
		height: "large",
		width: "medium",
		nested,
		resultListAriaLabel: "Milestone results",
		triggerOpen,
		initialFilter,
		selectPanelRef: anchorRef,
		keybindingCommandId: "item-pickers:open-milestone",
		customNoMatchItem: canCreateMilestone && showNoMatchItem && filter ? {
			id: filter,
			closed: false,
			progressPercentage: 0,
			title: filter,
			url: ""
		} : void 0,
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No milestones were found",
			body: "Try searching with a different query for results.",
			variant: "empty"
		} : void 0,
		responsiveOnNarrow: responsiveOnNarrowEnabled
	});
}
MilestonePickerBase.displayName = "MilestonePickerBase";
async function apiGetSearchMilestones({ owner, repo, query, count }) {
	const params = {
		owner,
		repo
	};
	if (query) params["query"] = query;
	if (count) params["count"] = count;
	return await (await verifiedFetchJSON(buildItemPickerSearchUrl("milestones", params))).json();
}
var itemPickerQueryKeyBase$1 = "item_picker";
function buildMilestonePickerSearchQueryKey(searchParams) {
	return [
		itemPickerQueryKeyBase$1,
		"milestones",
		searchParams
	];
}
function transformSearchMilestoneResponseToQueryData(response) {
	return {
		milestones: response.repository.milestones.nodes,
		repositoryId: response.repository.id
	};
}
async function apiCreateMilestone(request) {
	return (await verifiedFetchJSON(buildItemPickersUrl("milestones"), {
		method: "POST",
		body: request
	})).json();
}
var useCreateMilestoneMutation = () => {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { mutationFn: _temp$20 };
		$[0] = t0;
	} else t0 = $[0];
	return useMutation(t0);
};
async function _temp$20(request) {
	return parseGraphQLResponse(await apiCreateMilestone(request)).data.createMilestone.milestone;
}
async function fetchMilestones(queryClient, { owner, repo, query, count }) {
	return await queryClient.fetchQuery({
		queryKey: buildMilestonePickerSearchQueryKey({
			owner,
			repo,
			query,
			count
		}),
		queryFn: async () => {
			return transformSearchMilestoneResponseToQueryData(parseGraphQLResponse(await apiGetSearchMilestones({
				owner,
				repo,
				query,
				count
			})).data);
		}
	});
}
function ItemPickerFetcher$1(t0) {
	const $ = c(16);
	const { repo, owner, ...rest } = t0;
	const [isLoading, setIsLoading] = useState(true);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const queryClient = useQueryClient();
	const { mutate: createMilestoneMutate } = useCreateMilestoneMutation();
	let t1;
	if ($[0] !== owner || $[1] !== queryClient || $[2] !== repo) {
		t1 = () => {
			const fetchInitialMilestones = async () => {
				try {
					setData(await fetchMilestones(queryClient, {
						owner,
						repo,
						query: ""
					}));
					setIsLoading(false);
					setIsError(false);
				} catch {
					setIsError(true);
					setIsLoading(false);
				}
			};
			fetchInitialMilestones();
		};
		$[0] = owner;
		$[1] = queryClient;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== fetchKey || $[5] !== owner || $[6] !== queryClient || $[7] !== repo) {
		t2 = [
			fetchKey,
			owner,
			queryClient,
			repo
		];
		$[4] = fetchKey;
		$[5] = owner;
		$[6] = queryClient;
		$[7] = repo;
		$[8] = t2;
	} else t2 = $[8];
	useEffect(t1, t2);
	const anchorRef = useRef(null);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("milestones"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	let t3;
	if ($[9] !== queryClient) {
		t3 = async (options) => {
			return (await fetchMilestones(queryClient, options)).milestones;
		};
		$[9] = queryClient;
		$[10] = t3;
	} else t3 = $[10];
	const fetchMilestonesWithQueryClient = t3;
	let t4;
	if ($[11] !== createMilestoneMutate) {
		t4 = (input, t5) => {
			const { onSuccess, onError } = t5;
			createMilestoneMutate(input, {
				onSuccess,
				onError
			});
		};
		$[11] = createMilestoneMutate;
		$[12] = t4;
	} else t4 = $[12];
	const onCreate = t4;
	if (isError) {
		let t5;
		if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
			t5 = () => setFetchKey(_temp$19);
			$[13] = t5;
		} else t5 = $[13];
		let t6;
		if ($[14] !== createFallbackComponent) {
			t6 = createFallbackComponent(t5);
			$[14] = createFallbackComponent;
			$[15] = t6;
		} else t6 = $[15];
		return t6;
	}
	return jsx(MilestonePickerBase, {
		repo,
		owner,
		repositoryId: data?.repositoryId ?? "",
		milestones: data?.milestones ?? [],
		isLoading,
		setIsLoading,
		fetchMilestones: fetchMilestonesWithQueryClient,
		onCreate,
		...rest
	});
}
ItemPickerFetcher$1.displayName = "ItemPickerFetcher";
function _temp$19(current) {
	return current + 1;
}
function MilestonePicker({ repo, owner, anchorElement, readonly, activeMilestone, noMilestoneItem, ...rest }) {
	return /* @__PURE__ */ jsx(LazyItemPicker, {
		keybindingCommandId: "item-pickers:open-milestone",
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		createChild: () => /* @__PURE__ */ jsx(ItemPickerFetcher$1, {
			repo,
			owner,
			readonly,
			initialFilter: "",
			activeMilestone,
			triggerOpen: true,
			anchorElement,
			noMilestoneItem,
			...rest
		}),
		insidePortal: rest.insidePortal
	});
}
MilestonePicker.displayName = "MilestonePicker";
var ProjectItemsLimitReachedDialog = ({ onClose, returnFocusRef }) => {
	return /* @__PURE__ */ jsx(Dialog, {
		"aria-label": LABELS$3.projectItemsLimitReachedDialogLabel,
		title: LABELS$3.projectItemsLimitReachedDialogTitle,
		onClose,
		returnFocusRef,
		width: "large",
		footerButtons: [{
			content: LABELS$3.closeButton,
			onClick: onClose,
			buttonType: "primary"
		}],
		children: /* @__PURE__ */ jsx("div", { children: LABELS$3.projectItemsLimitReachedDialogMessage })
	});
};
ProjectItemsLimitReachedDialog.displayName = "ProjectItemsLimitReachedDialog";
var DEFAULT_FILTERED_PROJECTS = [];
var DEFAULT_GROUPS = [];
function ProjectPickerBase({ items: filteredProjects = DEFAULT_FILTERED_PROJECTS, groups = DEFAULT_GROUPS, selectedProjects, isDialogOpen, handleDialogClose, filterValue, onCancel, onOpenChange, onFilterChange, anchorElement, onSelectionChange: onSelectedChange, insidePortal, isLoading: loading, title, triggerOpen: open }) {
	const handleGlobalCommand = useCallback(() => {
		if (open) return;
		onOpenChange(true, "anchor-key-press");
	}, [open, onOpenChange]);
	const buttonRef = useRef(null);
	const regularHeight = filteredProjects.length <= 2 ? "auto" : "large";
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	const adjustedOverlayProps = useMemo(() => getAdjustedOverlayProps(insidePortal, buttonRef, regularHeight, responsiveOnNarrowEnabled, open), [
		insidePortal,
		regularHeight,
		responsiveOnNarrowEnabled,
		open
	]);
	const showNoMatchMessage = useMemo(() => filteredProjects.length === 0, [filteredProjects.length]);
	const selectPanelProps = useMemo(() => {
		const props = {
			renderAnchor: (anchorProps) => anchorElement(anchorProps),
			anchorRef: buttonRef,
			placeholderText: LABELS$3.filterProjects,
			items: filteredProjects,
			selected: selectedProjects,
			open: open || false,
			onOpenChange,
			onCancel,
			onSelectedChange,
			filterValue,
			onFilterChange,
			showItemDividers: true,
			overlayProps: {
				width: "medium",
				...adjustedOverlayProps
			},
			loading,
			title: title ?? LABELS$3.selectProjects,
			message: showNoMatchMessage ? {
				title: "No projects were found",
				variant: "empty",
				body: "Please try a different search query."
			} : void 0
		};
		if (groups?.length > 0 && filteredProjects.length > 0) props.groupMetadata = groups;
		return props;
	}, [
		adjustedOverlayProps,
		anchorElement,
		filterValue,
		filteredProjects,
		groups,
		loading,
		onCancel,
		onFilterChange,
		onOpenChange,
		onSelectedChange,
		open,
		selectedProjects,
		showNoMatchMessage,
		title
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(GlobalCommands, { commands: { "item-pickers:open-projects": handleGlobalCommand } }),
		/* @__PURE__ */ jsx(FeatureFlags, {
			flags: { primer_react_select_panel_fullscreen_on_narrow: responsiveOnNarrowEnabled },
			children: /* @__PURE__ */ jsx(SelectPanel, {
				"aria-label": "Project results",
				"data-id": IDS.itemPickerRootId,
				"data-testid": IDS.itemPickerTestId,
				...selectPanelProps
			})
		}),
		isDialogOpen && /* @__PURE__ */ jsx(ProjectItemsLimitReachedDialog, {
			onClose: handleDialogClose,
			returnFocusRef: buttonRef
		})
	] });
}
ProjectPickerBase.displayName = "ProjectPickerBase";
function DefaultProjectPickerAnchor({ firstSelectedProjectTitle, readonly, nested, anchorProps }) {
	return /* @__PURE__ */ jsx(SharedPicker, {
		anchorText: LABELS$3.noProjects,
		sharedPickerMainValue: firstSelectedProjectTitle,
		anchorProps: readonly ? void 0 : anchorProps,
		ariaLabel: LABELS$3.selectProjects,
		readonly,
		nested,
		leadingIcon: TableIcon,
		hotKey: void 0
	});
}
DefaultProjectPickerAnchor.displayName = "DefaultProjectPickerAnchor";
async function apiGetSearchProjects({ owner, repo, query, count }) {
	const params = {
		owner,
		repo
	};
	if (query) params["query"] = query;
	if (count) params["count"] = count;
	return await (await verifiedFetchJSON(buildItemPickerSearchUrl("projects", params))).json();
}
var itemPickerQueryKeyBase = "item_picker";
function buildProjectPickerSearchQueryKey(searchParams) {
	return [
		itemPickerQueryKeyBase,
		"projects",
		searchParams
	];
}
function transformSearchProjectResponseToQueryData(response) {
	return {
		repositoryId: response.repository.id,
		repositoryProjects: response.repository.projectsV2.nodes,
		recentRepositoryProjects: response.repository.recentProjects.edges.map((edge) => edge.node),
		ownerProjects: response.repository.owner.projectsV2.edges.map((edge) => edge.node),
		recentOwnerProjects: response.repository.owner.recentProjects.edges.map((edge) => edge.node)
	};
}
var recentGroup = {
	groupId: "recent",
	header: {
		title: "Recent",
		variant: "filled"
	}
};
var repoGroup = {
	groupId: "repository",
	header: {
		title: "Repository",
		variant: "filled"
	}
};
var orgGroup = {
	groupId: "organization",
	header: {
		title: "Organization",
		variant: "filled"
	}
};
var selectedGroup = { groupId: "selected" };
function searchProjectsQueryOptions({ owner, repo, query, count }) {
	return queryOptions$1({
		queryKey: buildProjectPickerSearchQueryKey({
			owner,
			repo,
			query,
			count
		}),
		queryFn: async () => {
			return transformSearchProjectResponseToQueryData(parseGraphQLResponse(await apiGetSearchProjects({
				owner,
				repo,
				query,
				count
			})).data);
		}
	});
}
var DEFAULT_SELECTED_PROJECTS = [];
function SelectPanelWrapper(t0) {
	const $ = c(98);
	const { projectsData: initialProjectsData, selectedProjects: t1, onSave, anchorElement, insidePortal, owner, repo, isLoading: t2, triggerOpen: t3, readonly, title, getSelectedProjects, pickerId } = t0;
	const initialSelected = t1 === void 0 ? DEFAULT_SELECTED_PROJECTS : t1;
	const initialLoading = t2 === void 0 ? false : t2;
	const triggerOpen = t3 === void 0 ? false : t3;
	const [projectsData, setProjectsData] = useState(initialProjectsData);
	const [previousProjectsData, setPreviousProjectsData] = useState(initialProjectsData);
	const [searchLoading, setSearchLoading] = useState(false);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const queryClient = useQueryClient();
	const { addToast } = useToastContext();
	const [filter, setFilter] = useState("");
	const [isOpen, setIsOpen] = useState(triggerOpen);
	if (previousProjectsData !== initialProjectsData) {
		setPreviousProjectsData(initialProjectsData);
		if (filter.length === 0) setProjectsData(initialProjectsData);
	}
	let t4;
	if ($[0] !== initialProjectsData) {
		t4 = () => {
			setProjectsData(initialProjectsData);
		};
		$[0] = initialProjectsData;
		$[1] = t4;
	} else t4 = $[1];
	const resetToInitialData = useEffectEvent(t4);
	let t5;
	if ($[2] !== addToast || $[3] !== owner || $[4] !== queryClient || $[5] !== repo) {
		t5 = async (searchQuery) => {
			setSearchLoading(true);
			try {
				setProjectsData(await queryClient.fetchQuery(searchProjectsQueryOptions({
					repo,
					owner,
					query: searchQuery
				})));
				setSearchLoading(false);
			} catch {
				setSearchLoading(false);
				addToast({
					type: "error",
					message: ERRORS$2.couldNotSearchProjects
				});
			}
		};
		$[2] = addToast;
		$[3] = owner;
		$[4] = queryClient;
		$[5] = repo;
		$[6] = t5;
	} else t5 = $[6];
	const fetchSearchData = useEffectEvent(t5);
	let t6;
	if ($[7] !== fetchSearchData || $[8] !== filter || $[9] !== resetToInitialData) {
		t6 = () => {
			if (filter.length === 0) {
				resetToInitialData();
				return;
			}
			const timeoutId = setTimeout(() => {
				fetchSearchData(filter);
			}, VALUES.pickerDebounceTime);
			return () => {
				clearTimeout(timeoutId);
			};
		};
		$[7] = fetchSearchData;
		$[8] = filter;
		$[9] = resetToInitialData;
		$[10] = t6;
	} else t6 = $[10];
	let t7;
	if ($[11] !== filter) {
		t7 = [filter];
		$[11] = filter;
		$[12] = t7;
	} else t7 = $[12];
	useEffect(t6, t7);
	let t8;
	if ($[13] !== projectsData?.recentOwnerProjects) {
		t8 = projectsData?.recentOwnerProjects || [];
		$[13] = projectsData?.recentOwnerProjects;
		$[14] = t8;
	} else t8 = $[14];
	let t9;
	if ($[15] !== t8) {
		t9 = t8.filter(_temp$18);
		$[15] = t8;
		$[16] = t9;
	} else t9 = $[16];
	const recentProjects = t9;
	let t10;
	if ($[17] !== projectsData?.repositoryProjects) {
		t10 = projectsData?.repositoryProjects || [];
		$[17] = projectsData?.repositoryProjects;
		$[18] = t10;
	} else t10 = $[18];
	let t11;
	if ($[19] !== t10) {
		t11 = t10.filter(_temp2$12);
		$[19] = t10;
		$[20] = t11;
	} else t11 = $[20];
	const repositoryProjects = t11;
	let t12;
	if ($[21] !== projectsData?.ownerProjects) {
		t12 = projectsData?.ownerProjects || [];
		$[21] = projectsData?.ownerProjects;
		$[22] = t12;
	} else t12 = $[22];
	let t13;
	if ($[23] !== t12) {
		t13 = t12.filter(_temp3$11);
		$[23] = t12;
		$[24] = t13;
	} else t13 = $[24];
	const organizationProjects = t13;
	let t14;
	if ($[25] !== getSelectedProjects || $[26] !== initialSelected || $[27] !== organizationProjects || $[28] !== recentProjects || $[29] !== repositoryProjects) {
		t14 = getSelectedProjects ? getSelectedProjects([
			...recentProjects,
			...repositoryProjects,
			...organizationProjects
		]) : initialSelected;
		$[25] = getSelectedProjects;
		$[26] = initialSelected;
		$[27] = organizationProjects;
		$[28] = recentProjects;
		$[29] = repositoryProjects;
		$[30] = t14;
	} else t14 = $[30];
	const initialSelectedProjects = t14;
	let t15;
	if ($[31] !== initialSelectedProjects) {
		t15 = () => initialSelectedProjects.map(_temp4$8);
		$[31] = initialSelectedProjects;
		$[32] = t15;
	} else t15 = $[32];
	const [selected, setSelected] = useState(t15);
	const [previousInitialSelected, setPreviousInitialSelected] = useState(initialSelectedProjects);
	if (previousInitialSelected !== initialSelectedProjects) {
		setPreviousInitialSelected(initialSelectedProjects);
		setSelected(initialSelectedProjects.map(_temp5$4));
	}
	let t16;
	if ($[33] !== initialSelectedProjects || $[34] !== readonly || $[35] !== selected) {
		t16 = (groupId, p_1) => {
			const { title: text, id } = p_1;
			const variant = p_1.hasReachedItemsLimit && !initialSelectedProjects.some((proj) => proj.id === id) ? "danger" : "default";
			const descriptionVariant = p_1.hasReachedItemsLimit ? "block" : "inline";
			return {
				text,
				description: p_1.hasReachedItemsLimit ? `${LABELS$3.projectItemsLimitReached}` : void 0,
				descriptionVariant,
				id,
				groupId,
				selected: selected.includes(id),
				disabled: readonly || !p_1.viewerCanUpdate,
				leadingVisual: TableIcon,
				variant
			};
		};
		$[33] = initialSelectedProjects;
		$[34] = readonly;
		$[35] = selected;
		$[36] = t16;
	} else t16 = $[36];
	const generateItemProps = t16;
	let t17;
	let t18;
	let t19;
	let t20;
	if ($[37] !== initialSelectedProjects || $[38] !== organizationProjects || $[39] !== recentProjects || $[40] !== repositoryProjects) {
		const selectedProjectIds = initialSelectedProjects.map(_temp6$2);
		t17 = initialSelectedProjects;
		t18 = recentProjects.filter((p_3) => !selectedProjectIds.includes(p_3.id));
		t19 = repositoryProjects.filter((p_4) => !selectedProjectIds.includes(p_4.id));
		t20 = organizationProjects.filter((p_5) => !selectedProjectIds.includes(p_5.id));
		$[37] = initialSelectedProjects;
		$[38] = organizationProjects;
		$[39] = recentProjects;
		$[40] = repositoryProjects;
		$[41] = t17;
		$[42] = t18;
		$[43] = t19;
		$[44] = t20;
	} else {
		t17 = $[41];
		t18 = $[42];
		t19 = $[43];
		t20 = $[44];
	}
	let t21;
	if ($[45] !== t17 || $[46] !== t18 || $[47] !== t19 || $[48] !== t20) {
		t21 = {
			selected: t17,
			recent: t18,
			repository: t19,
			organization: t20
		};
		$[45] = t17;
		$[46] = t18;
		$[47] = t19;
		$[48] = t20;
		$[49] = t21;
	} else t21 = $[49];
	const allProjects = t21;
	let t22;
	if ($[50] !== allProjects || $[51] !== generateItemProps) {
		t22 = Object.keys(allProjects).flatMap((pKey) => {
			const projects = allProjects[pKey];
			return projects ? projects.map((p_6) => generateItemProps(pKey, p_6)) : [];
		});
		$[50] = allProjects;
		$[51] = generateItemProps;
		$[52] = t22;
	} else t22 = $[52];
	const projectsToSelect = t22;
	let t23;
	if ($[53] !== projectsToSelect || $[54] !== selected) {
		t23 = projectsToSelect.filter((p_7) => p_7.id && selected.includes(p_7.id.toString()));
		$[53] = projectsToSelect;
		$[54] = selected;
		$[55] = t23;
	} else t23 = $[55];
	const selectedProjects = t23;
	let t24;
	bb0: {
		if (projectsToSelect.length < 1) {
			let t25;
			if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
				t25 = [];
				$[56] = t25;
			} else t25 = $[56];
			t24 = t25;
			break bb0;
		}
		if (filter === "") {
			t24 = projectsToSelect;
			break bb0;
		}
		let t25;
		if ($[57] !== filter || $[58] !== projectsToSelect) {
			t25 = projectsToSelect.filter((item_3) => (item_3.text || "").toLowerCase().indexOf(filter.trim().toLowerCase()) >= 0);
			$[57] = filter;
			$[58] = projectsToSelect;
			$[59] = t25;
		} else t25 = $[59];
		const filtered = t25;
		if (filtered.length < 1) {
			let t26;
			if ($[60] === Symbol.for("react.memo_cache_sentinel")) {
				t26 = [];
				$[60] = t26;
			} else t26 = $[60];
			t24 = t26;
			break bb0;
		}
		t24 = filtered;
	}
	const filteredProjects = t24;
	const t25 = initialSelectedProjects.length > 0 ? selectedGroup : null;
	const t26 = recentProjects.length > 0 ? recentGroup : null;
	const t27 = repositoryProjects.length > 0 ? repoGroup : null;
	const t28 = organizationProjects.length > 0 ? orgGroup : null;
	let t29;
	if ($[61] !== t25 || $[62] !== t26 || $[63] !== t27 || $[64] !== t28) {
		t29 = [
			t25,
			t26,
			t27,
			t28
		].filter(_temp7$1);
		$[61] = t25;
		$[62] = t26;
		$[63] = t27;
		$[64] = t28;
		$[65] = t29;
	} else t29 = $[65];
	const groups = t29;
	let t30;
	if ($[66] !== selected || $[67] !== selectedProjects) {
		t30 = (selection) => {
			const diff = selectedProjects.filter((p_8) => !selection.includes(p_8)).map(_temp8$1);
			let projectIds = selected;
			const selectedIds = selection.filter(_temp9$1).map(_temp0);
			projectIds = [...projectIds, ...selectedIds];
			if (diff.length > 0) projectIds = projectIds.filter((p_10) => !diff.includes(p_10));
			setSelected([...new Set(projectIds)]);
		};
		$[66] = selected;
		$[67] = selectedProjects;
		$[68] = t30;
	} else t30 = $[68];
	const handleSelectionChange = t30;
	let t31;
	if ($[69] !== initialSelected || $[70] !== selected) {
		t31 = () => {
			setIsOpen(false);
			setFilter("");
			if (selected.length !== initialSelected.length || selected.some((item_6) => !initialSelected.some((item2) => item_6 === item2.id))) setSelected(initialSelected.map(_temp1));
		};
		$[69] = initialSelected;
		$[70] = selected;
		$[71] = t31;
	} else t31 = $[71];
	const onCancel = t31;
	const { updateOpenState } = useItemPickersContext();
	let t32;
	if ($[72] !== allProjects || $[73] !== onSave || $[74] !== pickerId || $[75] !== selectedProjects || $[76] !== updateOpenState) {
		t32 = (open, gesture) => {
			if (!open && document.activeElement instanceof HTMLElement) document.activeElement?.blur();
			if (gesture === "cancel") return;
			setIsOpen(open);
			updateOpenState(pickerId, open);
			if (!open) {
				setFilter("");
				if (selectedProjects.filter(_temp10).length > 0) setIsDialogOpen(true);
				const validSelected = selectedProjects.filter(_temp11).map(_temp12).filter(_temp13);
				setSelected(validSelected);
				const allProjectsList = Object.keys(allProjects).flatMap((pKey_0) => {
					return allProjects[pKey_0] || [];
				});
				const projectsMap = /* @__PURE__ */ new Map();
				for (const project of allProjectsList) projectsMap.set(project.id, project);
				const uniqueProjects = [...new Set(validSelected)].map((id_1) => projectsMap.get(id_1)).filter(_temp14);
				if (onSave) onSave(uniqueProjects);
			}
		};
		$[72] = allProjects;
		$[73] = onSave;
		$[74] = pickerId;
		$[75] = selectedProjects;
		$[76] = updateOpenState;
		$[77] = t32;
	} else t32 = $[77];
	const onOpenChange = t32;
	let t33;
	if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
		t33 = () => {
			setIsDialogOpen(false);
		};
		$[78] = t33;
	} else t33 = $[78];
	const handleDialogClose = t33;
	let t34;
	if ($[79] !== filteredProjects || $[80] !== isOpen) {
		t34 = (event) => {
			if (isOpen) {
				const activeOption = document.querySelector(SELECTORS.activePickerOption(IDS.itemPickerRootId));
				if (activeOption) {
					const activeDataId = activeOption.getAttribute("data-id");
					const item_9 = [...filteredProjects.values()].find((i) => i.id === activeDataId);
					if (item_9 && item_9.id) {
						if (item_9.disabled) return;
						event.preventDefault();
						event.stopPropagation();
						const itemId = item_9.id.toString();
						setSelected((prevState) => {
							const newState = [...prevState];
							const index = newState.indexOf(itemId);
							if (index > -1) newState.splice(index, 1);
							else newState.push(itemId);
							return newState;
						});
					}
				}
			}
		};
		$[79] = filteredProjects;
		$[80] = isOpen;
		$[81] = t34;
	} else t34 = $[81];
	const onSpaceKeyPress = t34;
	let t35;
	if ($[82] === Symbol.for("react.memo_cache_sentinel")) {
		t35 = [" "];
		$[82] = t35;
	} else t35 = $[82];
	let t36;
	if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
		t36 = {
			triggerWhenInputElementHasFocus: true,
			triggerWhenPortalIsActive: true
		};
		$[83] = t36;
	} else t36 = $[83];
	useKeyPress(t35, onSpaceKeyPress, t36);
	const t37 = initialLoading || searchLoading;
	let t38;
	if ($[84] !== anchorElement || $[85] !== filter || $[86] !== filteredProjects || $[87] !== groups || $[88] !== handleSelectionChange || $[89] !== insidePortal || $[90] !== isDialogOpen || $[91] !== isOpen || $[92] !== onCancel || $[93] !== onOpenChange || $[94] !== selectedProjects || $[95] !== t37 || $[96] !== title) {
		t38 = jsx(ProjectPickerBase, {
			anchorElement,
			title,
			items: filteredProjects,
			selectedProjects,
			groups,
			onOpenChange,
			isDialogOpen,
			handleDialogClose,
			insidePortal,
			onCancel,
			onSelectionChange: handleSelectionChange,
			triggerOpen: isOpen,
			isLoading: t37,
			onFilterChange: setFilter,
			filterValue: filter
		});
		$[84] = anchorElement;
		$[85] = filter;
		$[86] = filteredProjects;
		$[87] = groups;
		$[88] = handleSelectionChange;
		$[89] = insidePortal;
		$[90] = isDialogOpen;
		$[91] = isOpen;
		$[92] = onCancel;
		$[93] = onOpenChange;
		$[94] = selectedProjects;
		$[95] = t37;
		$[96] = title;
		$[97] = t38;
	} else t38 = $[97];
	return t38;
}
SelectPanelWrapper.displayName = "SelectPanelWrapper";
function _temp14(p_13) {
	return p_13 !== void 0;
}
function _temp13(id_0) {
	return id_0 !== void 0;
}
function _temp12(p_12) {
	return p_12.id;
}
function _temp11(item_8) {
	return item_8.variant !== "danger";
}
function _temp10(item_7) {
	return item_7.variant === "danger";
}
function _temp1(p_11) {
	return p_11.id ? p_11.id.toString() : "";
}
function _temp0(item_5) {
	return item_5.id;
}
function _temp9$1(item_4) {
	return item_4.id !== void 0;
}
function _temp8$1(p_9) {
	return p_9.id;
}
function _temp7$1(group) {
	return group !== null;
}
function _temp6$2(p_2) {
	return p_2.id;
}
function _temp5$4(p_0) {
	return p_0.id;
}
function _temp4$8(p) {
	return p.id;
}
function _temp3$11(item_1) {
	return item_1.closed === false;
}
function _temp2$12(item_0) {
	return item_0.closed === false;
}
function _temp$18(item) {
	return item.closed === false;
}
function ItemPickerFetcher(t0) {
	const $ = c(12);
	const { repo, owner, ...rest } = t0;
	const [isLoading, setIsLoading] = useState(true);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const queryClient = useQueryClient();
	let t1;
	if ($[0] !== owner || $[1] !== queryClient || $[2] !== repo) {
		t1 = () => {
			const fetchInitialProjects = async () => {
				try {
					setData(await queryClient.fetchQuery(searchProjectsQueryOptions({
						owner,
						repo,
						query: ""
					})));
					setIsLoading(false);
					setIsError(false);
				} catch {
					setIsError(true);
					setIsLoading(false);
				}
			};
			fetchInitialProjects();
		};
		$[0] = owner;
		$[1] = queryClient;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== fetchKey || $[5] !== owner || $[6] !== queryClient || $[7] !== repo) {
		t2 = [
			fetchKey,
			owner,
			queryClient,
			repo
		];
		$[4] = fetchKey;
		$[5] = owner;
		$[6] = queryClient;
		$[7] = repo;
		$[8] = t2;
	} else t2 = $[8];
	useEffect(t1, t2);
	const anchorRef = useRef(null);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS$3.cantEditItems("projects"),
		anchorElement: (anchorProps) => rest.anchorElement(anchorProps, anchorRef),
		open: true
	});
	if (isError) {
		let t3;
		if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = () => setFetchKey(_temp15);
			$[9] = t3;
		} else t3 = $[9];
		let t4;
		if ($[10] !== createFallbackComponent) {
			t4 = createFallbackComponent(t3);
			$[10] = createFallbackComponent;
			$[11] = t4;
		} else t4 = $[11];
		return t4;
	}
	return jsx(SelectPanelWrapper, {
		projectsData: data,
		owner,
		repo,
		isLoading,
		...rest
	});
}
ItemPickerFetcher.displayName = "ItemPickerFetcher";
function _temp15(current) {
	return current + 1;
}
function ProjectPicker(t0) {
	const $ = c(9);
	const { anchorElement, triggerOpen, ...rest } = t0;
	const [wasTriggered, setWasTriggered] = useState(triggerOpen);
	let t1;
	if ($[0] !== wasTriggered) {
		t1 = () => {
			if (!wasTriggered) setWasTriggered(true);
		};
		$[0] = wasTriggered;
		$[1] = t1;
	} else t1 = $[1];
	const handleGlobalCommand = t1;
	if (!wasTriggered) {
		let t2;
		if ($[2] !== anchorElement || $[3] !== handleGlobalCommand) {
			let t3;
			let t4;
			if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
				t3 = () => {
					setWasTriggered(true);
				};
				t4 = (event) => {
					if (event.key === "Enter" || event.key === " ") {
						event.preventDefault();
						setWasTriggered(true);
					}
				};
				$[5] = t3;
				$[6] = t4;
			} else {
				t3 = $[5];
				t4 = $[6];
			}
			t2 = jsxs(Fragment$1, { children: [jsx(GlobalCommands, { commands: { "item-pickers:open-projects": handleGlobalCommand } }), anchorElement({
				onClick: t3,
				onKeyPress: t4
			})] });
			$[2] = anchorElement;
			$[3] = handleGlobalCommand;
			$[4] = t2;
		} else t2 = $[4];
		return t2;
	}
	let t2;
	if ($[7] !== anchorElement) {
		t2 = (props) => anchorElement(props);
		$[7] = anchorElement;
		$[8] = t2;
	} else t2 = $[8];
	return jsx(ItemPickerFetcher, {
		triggerOpen: true,
		anchorElement: t2,
		...rest,
		pickerId: "list-header-projects-picker"
	});
}
ProjectPicker.displayName = "ProjectPicker";
var MetadataFooterLoading_module_default = { MetadataFooterLoadingContainer: "MetadataFooterLoading-module_GHuY1W_MetadataFooterLoadingContainer" };
var MetadataFooterLoading = () => {
	return /* @__PURE__ */ jsx("div", {
		className: MetadataFooterLoading_module_default.MetadataFooterLoadingContainer,
		children: /* @__PURE__ */ jsx(IssuesLoadingSkeleton, {
			borderRadius: "pill",
			height: "lg",
			width: "400px"
		})
	});
};
MetadataFooterLoading.displayName = "MetadataFooterLoading";
function useIssueFieldPickers(t0) {
	const $ = c(26);
	const { pinnedFieldsFromType, setIssueFieldsWithValues, scopedFields, issueFields } = t0;
	const [pendingSelectedField, setPendingSelectedField] = useState(null);
	let t1;
	if ($[0] !== pinnedFieldsFromType) {
		t1 = pinnedFieldsFromType || [];
		$[0] = pinnedFieldsFromType;
		$[1] = t1;
	} else t1 = $[1];
	const selectedPinnedFields = t1;
	let t2;
	if ($[2] !== setIssueFieldsWithValues) {
		t2 = (fields) => {
			const setFields = [];
			for (const field of fields) if (field.value) setFields.push(field);
			setIssueFieldsWithValues(setFields);
		};
		$[2] = setIssueFieldsWithValues;
		$[3] = t2;
	} else t2 = $[3];
	const updateIssueFields = t2;
	let t3;
	if ($[4] !== issueFields || $[5] !== pendingSelectedField || $[6] !== updateIssueFields) {
		t3 = (fieldId, fieldValue) => {
			if (!pendingSelectedField || pendingSelectedField.id !== fieldId) return;
			setPendingSelectedField(null);
			const value = getIssueFieldSelectionValue(toIssueFieldType(pendingSelectedField.dataType), fieldValue);
			if (typeof value === "string" ? !value.trim() : !value) return;
			const newFields = [...issueFields];
			if (pendingSelectedField.name && !newFields.some((f) => f.field.name === pendingSelectedField.name)) newFields.push(toIssueFieldWithUnsavedValue(pendingSelectedField, fieldValue));
			updateIssueFields(newFields);
		};
		$[4] = issueFields;
		$[5] = pendingSelectedField;
		$[6] = updateIssueFields;
		$[7] = t3;
	} else t3 = $[7];
	const onPendingFieldCommit = t3;
	let t4;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (fields_0) => {
			const field_0 = fields_0[0];
			if (field_0?.id && field_0?.name && field_0?.dataType) setPendingSelectedField({
				id: field_0.id,
				name: field_0.name,
				dataType: toIssueFieldType(field_0.dataType)
			});
		};
		$[8] = t4;
	} else t4 = $[8];
	const onIssueFieldPickerSelectionChange = t4;
	let t5;
	if ($[9] !== issueFields || $[10] !== selectedPinnedFields || $[11] !== updateIssueFields) {
		t5 = (field_1, value_0) => {
			if (selectedPinnedFields.find((f_1) => f_1.id === field_1.field.id) && !issueFields.find((f_0) => f_0.field.id === field_1.field.id)) {
				updateIssueFields([...issueFields, toIssueFieldWithUnsavedValue(field_1.field, value_0)]);
				return;
			}
			updateIssueFields(issueFields.map((f_2) => {
				if (f_2.field.id === field_1.field.id) return toIssueFieldWithUnsavedValue(f_2.field, value_0);
				return f_2;
			}).filter(_temp$17));
		};
		$[9] = issueFields;
		$[10] = selectedPinnedFields;
		$[11] = updateIssueFields;
		$[12] = t5;
	} else t5 = $[12];
	const onIssueFieldValueChanged = t5;
	let pinnedFields;
	let t6;
	let unpinnedFields;
	if ($[13] !== issueFields || $[14] !== scopedFields || $[15] !== selectedPinnedFields) {
		pinnedFields = getPinnedFields(issueFields, selectedPinnedFields, scopedFields);
		unpinnedFields = getUnpinnedFields(issueFields, selectedPinnedFields, scopedFields);
		t6 = pinnedFields.map(_temp2$11).concat(unpinnedFields.map(_temp3$10)).filter(_temp4$7);
		$[13] = issueFields;
		$[14] = scopedFields;
		$[15] = selectedPinnedFields;
		$[16] = pinnedFields;
		$[17] = t6;
		$[18] = unpinnedFields;
	} else {
		pinnedFields = $[16];
		t6 = $[17];
		unpinnedFields = $[18];
	}
	const selectedFieldNames = t6;
	let t7;
	if ($[19] !== onIssueFieldValueChanged || $[20] !== onPendingFieldCommit || $[21] !== pendingSelectedField || $[22] !== pinnedFields || $[23] !== selectedFieldNames || $[24] !== unpinnedFields) {
		t7 = {
			pendingSelectedField,
			setPendingSelectedField,
			pinnedFields,
			unpinnedFields,
			selectedFieldNames,
			onPendingFieldCommit,
			onIssueFieldPickerSelectionChange,
			onIssueFieldValueChanged
		};
		$[19] = onIssueFieldValueChanged;
		$[20] = onPendingFieldCommit;
		$[21] = pendingSelectedField;
		$[22] = pinnedFields;
		$[23] = selectedFieldNames;
		$[24] = unpinnedFields;
		$[25] = t7;
	} else t7 = $[25];
	return t7;
}
function _temp4$7(n) {
	return n !== void 0;
}
function _temp3$10(f_5) {
	return f_5.field.name;
}
function _temp2$11(f_4) {
	return f_4.field.name;
}
function _temp$17(f_3) {
	return f_3 !== null;
}
var getUnpinnedFields = (fields, pinnedFieldsFromType, scopedFields) => {
	const scopedFieldIds = scopedFields?.map((sf) => sf.fieldId) || [];
	const fieldIDs = fields.map((f) => f.field.id).filter((id) => id !== void 0);
	const allFieldIds = [...new Set([...fieldIDs, ...scopedFieldIds])];
	const unpinnedFields = [];
	for (const fieldId of allFieldIds) if (!pinnedFieldsFromType.find((f) => f.id === fieldId)) {
		const scopedField = scopedFields?.find((sf) => sf.fieldId === fieldId);
		const existingField = fields.find((f) => f.field.id === fieldId);
		unpinnedFields.push(existingField ? existingField : toIssueFieldWithValue({
			id: fieldId,
			name: scopedField.fieldName,
			dataType: scopedField.fieldType
		}, scopedField.value, true));
	}
	return unpinnedFields;
};
var getPinnedFields = (fields, pinnedFieldsFromType, scopedFields) => {
	const pinnedFields = [];
	for (const field of pinnedFieldsFromType) {
		const match = fields.find((f) => f.field.id === field.id);
		if (match) pinnedFields.push(match);
		else {
			const scopedField = scopedFields.find((sf) => sf.fieldId === field.id);
			pinnedFields.push(toIssueFieldWithValue(field, scopedField ? scopedField.value : null, !!scopedField));
		}
	}
	return pinnedFields;
};
var LABELS$1 = {
	mutationErrorMessage: "Something went wrong while setting the field value. Please try again.",
	loadingFieldsTooltipMessage: "Couldn't load issue fields",
	loadingFieldsErrorMessage: "We couldn't load the issue fields. Please try again later or if the problem persists contact support",
	setValue: "None yet",
	reloadWarningMessage: "Reload site? Changes you made might not be saved.",
	textValidationMaxLength: (length, maxLength) => `Value cannot be more than ${maxLength} characters (${length})`,
	textValidationEmpty: "Text cannot be empty.",
	textEditorLabel: (fieldName) => `The value for the ${fieldName} field`,
	textEditorToolbarLabel: (fieldName) => `Toolbar for ${fieldName} field`,
	textEditorPlaceholder: "Type text…",
	numberEditorPlaceholder: "Type number…",
	numberValidation: {
		errorMessage: "Must contain only numbers, decimals, and optional negative sign",
		max: (max) => `Cannot be greater than ${max}`,
		min: (min) => `Cannot be less than ${min}`
	},
	textEditorUpdateButton: "Update",
	textEditorRemoveFieldButtonLabel: (fieldName) => `Remove field ${fieldName}`,
	textEditorUpdateButtonAriaLabel: (fieldName) => `Update field ${fieldName} (press enter to submit)`,
	textEditorCancelButton: "Cancel",
	errorUpdatingIssueField: "There was an error updating this value. Please try again.",
	editFieldValueLabel: (title) => `Edit ${title}`,
	noPinnedFieldsMessage: (issueTypeName) => issueTypeName ? `No fields configured for ${issueTypeName}.` : "No fields configured for issues without a type."
};
var FALLBACK_WIDTH$1 = "256px";
var textValidation = (value) => {
	const { length } = value;
	if (length > 255) return LABELS$1.textValidationMaxLength(length, 255);
	return null;
};
var IssueFieldItem_module_default = {
	alertIcon: "IssueFieldItem-module_pmGm6W_alertIcon",
	alertIconWrapper: "IssueFieldItem-module_pmGm6W_alertIconWrapper",
	hasValue: "IssueFieldItem-module_pmGm6W_hasValue",
	isEditing: "IssueFieldItem-module_pmGm6W_isEditing",
	issueFieldActionButton: "IssueFieldItem-module_pmGm6W_issueFieldActionButton",
	issueFieldFormWrapper: "IssueFieldItem-module_pmGm6W_issueFieldFormWrapper",
	issueFieldFormWrapperClickable: "IssueFieldItem-module_pmGm6W_issueFieldFormWrapperClickable",
	issueFieldLabel: "IssueFieldItem-module_pmGm6W_issueFieldLabel",
	issueFieldValueText: "IssueFieldItem-module_pmGm6W_issueFieldValueText",
	small: "IssueFieldItem-module_pmGm6W_small"
};
var IssueFieldTextToken_module_default = {
	actionButton: "IssueFieldTextToken-module_LKYJVW_actionButton",
	issueFieldTextInput: "IssueFieldTextToken-module_LKYJVW_issueFieldTextInput",
	issueFieldTextTextarea: "IssueFieldTextToken-module_LKYJVW_issueFieldTextTextarea",
	issuesFieldText: "IssueFieldTextToken-module_LKYJVW_issuesFieldText",
	issuesFieldTextError: "IssueFieldTextToken-module_LKYJVW_issuesFieldTextError",
	issuesFieldTextInputContainer: "IssueFieldTextToken-module_LKYJVW_issuesFieldTextInputContainer",
	issuesFieldToolbar: "IssueFieldTextToken-module_LKYJVW_issuesFieldToolbar",
	issuesFieldToolbarActions: "IssueFieldTextToken-module_LKYJVW_issuesFieldToolbarActions",
	noValueContainer: "IssueFieldTextToken-module_LKYJVW_noValueContainer"
};
var dompurifyConfig = {
	FORBID_TAGS: ["style"],
	ALLOW_DATA_ATTR: false,
	ALLOWED_TAGS: [
		"h1",
		"h2",
		"h3",
		"h4",
		"h5",
		"h6",
		"h7",
		"h8",
		"br",
		"b",
		"i",
		"strong",
		"em",
		"a",
		"pre",
		"code",
		"img",
		"tt",
		"div",
		"span",
		"ins",
		"del",
		"sup",
		"sub",
		"p",
		"ol",
		"ul",
		"table",
		"thead",
		"tbody",
		"tfoot",
		"blockquote",
		"dl",
		"dt",
		"dd",
		"kbd",
		"q",
		"samp",
		"var",
		"hr",
		"ruby",
		"rt",
		"rp",
		"li",
		"tr",
		"td",
		"th",
		"s",
		"strike",
		"summary",
		"details",
		"picture",
		"source"
	]
};
/**
* Prefixes strings starting w/ www. w/ https:// protocols
* This is to support link parsing in projects text fields because strings like www.google.com are treated
* as valid urls, so we want to mirror the same functionality in issues project TextFields
* @param url
* @returns {string}
*/
function prefixUrl(url) {
	return (url?.startsWith("www.") ? "https://" : "") + url;
}
/**
* A wrapper around URL.canParse that acts as a polyfill for older browsers
* @param url
* @returns {boolean} - True if the URL can be parsed, otherwise false.
*/
function canParse(url) {
	try {
		new window.URL(url);
		return true;
	} catch {
		return false;
	}
}
var sanitizeInput = (input) => {
	return sanitize(input, dompurifyConfig);
};
/**
* Check whether a url is valid utilizing URL.canParse and uses a safe scheme (http or https)
* @param url
* @returns {boolean}
*/
var isValidAndSafeUrl = (url) => {
	if (!url || !canParse(url)) return false;
	try {
		const parsedUrl = new URL(url, window.location.origin);
		return ["http:", "https:"].includes(parsedUrl.protocol);
	} catch {
		return false;
	}
};
var containsSafeContent = (url) => {
	return sanitizeInput(url) === url;
};
var PUNCTUATION_REGEX = /^([(['"]{0,3})(.{1,1000}?)([.,:;!?\])"']{0,10})$/;
function cleanPunctuation(text) {
	const match = text.match(PUNCTUATION_REGEX);
	if (!match) return {
		cleanText: text,
		prefix: "",
		suffix: ""
	};
	const [_fullMatch, prefix = "", cleanText = "", suffix = ""] = match;
	return {
		cleanText,
		prefix,
		suffix
	};
}
function renderTextWithLinks(text) {
	if (!text) return null;
	if (IS_SERVER) return /* @__PURE__ */ jsx(Fragment$1, { children: text });
	return /* @__PURE__ */ jsx(Fragment$1, { children: text.split(/(\s+)/).map((fragment, index) => {
		const fragmentKey = `${fragment}-${index}`;
		if (!fragment.trim()) return /* @__PURE__ */ jsx(Fragment, { children: fragment }, fragmentKey);
		const { cleanText, prefix, suffix } = cleanPunctuation(fragment);
		if (!cleanText) return /* @__PURE__ */ jsx(Fragment, { children: fragment }, fragmentKey);
		const sanitizedFragment = sanitizeInput(cleanText);
		const prefixedUrl = prefixUrl(sanitizedFragment);
		if (isValidAndSafeUrl(prefixedUrl) && containsSafeContent(prefixedUrl)) return /* @__PURE__ */ jsxs(Fragment, { children: [
			prefix,
			/* @__PURE__ */ jsx(Link, {
				href: prefixedUrl,
				rel: "noopener noreferrer",
				children: sanitizedFragment
			}),
			suffix
		] }, fragmentKey);
		return /* @__PURE__ */ jsx(Fragment, { children: fragment }, fragmentKey);
	}) });
}
var defaultValidate = (value) => textValidation(value);
var IssueFieldCompactTextEditorButton = ({ buttonRef, className, onClick, fieldName, initialValue, errorPresent = false }) => {
	const content = /* @__PURE__ */ jsxs("button", {
		ref: buttonRef,
		type: "button",
		className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, IssueFieldItem_module_default.issueFieldFormWrapperClickable, className),
		onClick,
		"aria-label": initialValue ? `Edit ${fieldName}` : `Set ${fieldName}`,
		children: [
			/* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.issueFieldLabel,
				children: fieldName
			}),
			/* @__PURE__ */ jsx("span", {
				className: clsx(IssueFieldItem_module_default.issueFieldValueText, initialValue && IssueFieldItem_module_default.hasValue),
				children: initialValue ? renderTextWithLinks(initialValue) : LABELS$1.setValue
			}),
			errorPresent && /* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.alertIconWrapper,
				children: /* @__PURE__ */ jsx(AlertIcon, { className: IssueFieldItem_module_default.alertIcon })
			})
		]
	});
	return errorPresent ? /* @__PURE__ */ jsx(Tooltip$1, {
		text: LABELS$1.errorUpdatingIssueField,
		type: "description",
		children: content
	}) : content;
};
IssueFieldCompactTextEditorButton.displayName = "IssueFieldCompactTextEditorButton";
var IssueFieldTextEditor$1 = ({ initialValue, validate = defaultValidate, className, errorPresent = false, readonly, ...props }) => {
	return /* @__PURE__ */ jsx(IssueFieldCompactTextEditor, {
		initialValue,
		validate,
		readonly,
		errorPresent,
		className,
		...props
	});
};
IssueFieldTextEditor$1.displayName = "IssueFieldTextEditor";
var IssueFieldCompactTextEditor = ({ fieldId, fieldName, initialValue, onCommit, shouldOpen = false, validate = defaultValidate, inputProps, readonly, className, isNumber = false, errorPresent = false }) => {
	const [isClean, setIsClean] = useState(true);
	const [isUnsaved, setIsUnsaved] = useState(false);
	const buttonRef = useRef(null);
	const shouldRestoreRowFocusRef = useRef(false);
	useEffect(() => {
		const handleBeforeUnload = (event) => {
			if (isUnsaved) {
				event.preventDefault();
				event.returnValue = "";
			}
		};
		window.addEventListener("beforeunload", handleBeforeUnload);
		return () => {
			window.removeEventListener("beforeunload", handleBeforeUnload);
		};
	}, [isUnsaved]);
	const [inputValue, setInputValue] = useState(initialValue);
	const handleTextChange = (e) => {
		const { value } = e.target;
		setInputValue(value);
		if (value === initialValue) setIsClean(true);
		else setIsClean(false);
	};
	const validationMessage = useMemo(() => isClean ? null : validate(inputValue), [
		isClean,
		inputValue,
		validate
	]);
	const preventSubmit = useMemo(() => !!validationMessage, [validationMessage]);
	const [isEditing, setIsEditing] = useState(shouldOpen);
	const openEditor = useCallback(() => {
		if (isClean) setInputValue(initialValue);
		setIsEditing(true);
	}, [initialValue, isClean]);
	const onCancel = useCallback(() => {
		setInputValue(initialValue);
		shouldRestoreRowFocusRef.current = true;
		setIsEditing(false);
		setIsClean(true);
		setIsUnsaved(false);
	}, [initialValue]);
	const onUpdate = useCallback(() => {
		setIsEditing(false);
		setIsClean(true);
		setIsUnsaved(false);
		onCommit(fieldId, inputValue);
		shouldRestoreRowFocusRef.current = true;
	}, [
		fieldId,
		onCommit,
		inputValue
	]);
	useLayoutEffect(() => {
		if (!isEditing && shouldRestoreRowFocusRef.current) {
			shouldRestoreRowFocusRef.current = false;
			buttonRef.current?.focus();
		}
	}, [isEditing]);
	const onKeyDown = useCallback((e_0) => {
		e_0.stopPropagation();
		if (e_0.key === "Enter") {
			e_0.preventDefault();
			onUpdate();
		} else if (e_0.key === "Escape") onCancel();
	}, [onUpdate, onCancel]);
	const handleBlur = useCallback((e_1) => {
		if (!e_1.currentTarget.contains(e_1.relatedTarget)) {
			if (isClean) setIsEditing(false);
		}
	}, [isClean]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: isEditing && !readonly ? /* @__PURE__ */ jsx("div", {
		onBlur: handleBlur,
		children: /* @__PURE__ */ jsxs(FormControl$1, {
			className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, IssueFieldItem_module_default.issueFieldFormWrapperClickable, IssueFieldItem_module_default.isEditing, className),
			children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, {
					className: IssueFieldItem_module_default.issueFieldLabel,
					children: fieldName
				}),
				isNumber ? /* @__PURE__ */ jsx(TextInput$1, {
					value: inputValue,
					placeholder: LABELS$1.textEditorPlaceholder,
					onChange: handleTextChange,
					size: "small",
					onKeyDown,
					className: IssueFieldTextToken_module_default.issueFieldTextInput,
					autoFocus: true,
					onFocus: (event_0) => event_0.target.setSelectionRange(event_0.target.value.length, event_0.target.value.length),
					...inputProps
				}) : /* @__PURE__ */ jsx(Textarea, {
					value: inputValue,
					resize: "none",
					placeholder: LABELS$1.textEditorPlaceholder,
					onChange: handleTextChange,
					onKeyDown,
					className: clsx(IssueFieldTextToken_module_default.issueFieldTextInput, IssueFieldTextToken_module_default.issueFieldTextTextarea),
					autoFocus: true,
					onFocus: (event_1) => event_1.target.setSelectionRange(event_1.target.value.length, event_1.target.value.length)
				}),
				/* @__PURE__ */ jsx(IconButton, {
					icon: CheckIcon,
					onClick: preventSubmit ? void 0 : onUpdate,
					size: "small",
					"aria-disabled": preventSubmit,
					inactive: preventSubmit,
					"aria-label": LABELS$1.textEditorUpdateButton,
					className: IssueFieldItem_module_default.issueFieldActionButton
				}),
				validationMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					className: IssueFieldTextToken_module_default.issuesFieldTextError,
					children: validationMessage
				})
			]
		})
	}) : readonly ? /* @__PURE__ */ jsxs("div", {
		className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, className),
		children: [/* @__PURE__ */ jsx("p", {
			className: IssueFieldItem_module_default.issueFieldLabel,
			children: fieldName
		}), /* @__PURE__ */ jsx("div", {
			className: clsx(IssueFieldItem_module_default.issueFieldValueText, initialValue && IssueFieldItem_module_default.hasValue),
			children: initialValue ? renderTextWithLinks(initialValue) : LABELS$1.setValue
		})]
	}) : /* @__PURE__ */ jsx(IssueFieldCompactTextEditorButton, {
		buttonRef,
		className,
		onClick: openEditor,
		fieldName,
		initialValue,
		errorPresent
	}) });
};
IssueFieldCompactTextEditor.displayName = "IssueFieldCompactTextEditor";
var IssueFieldTextEditorInternal = ({ fieldId, fieldName, initialValue, onCommit, shouldOpen = false, validate = defaultValidate, inputProps, isDraft = false, isNumber = false, renderAnchor, overrideWidth, onClose: onClosed }) => {
	const [isClean, setIsClean] = useState(true);
	const [isUnsaved, setIsUnsaved] = useState(false);
	useEffect(() => {
		const handleBeforeUnload = (event) => {
			if (isUnsaved) {
				event.preventDefault();
				event.returnValue = "";
			}
		};
		window.addEventListener("beforeunload", handleBeforeUnload);
		return () => {
			window.removeEventListener("beforeunload", handleBeforeUnload);
		};
	}, [isUnsaved]);
	const [inputValue, setInputValue] = useState(initialValue);
	const handleTextChange = (e) => {
		const { value } = e.target;
		setInputValue(value);
		if (value === initialValue) setIsClean(true);
		else setIsClean(false);
	};
	const validationMessage = useMemo(() => isClean ? null : validate(inputValue), [
		isClean,
		inputValue,
		validate
	]);
	const preventSubmit = useMemo(() => isClean || !!validationMessage, [isClean, validationMessage]);
	const [isEditing, setIsEditing] = useState(shouldOpen);
	const onRemove = useCallback(() => {
		onCommit(fieldId, isNumber ? null : "");
		setIsUnsaved(false);
	}, [
		fieldId,
		isNumber,
		onCommit
	]);
	const onCancel = useCallback(() => {
		if (isDraft) {
			onRemove();
			return;
		}
		setInputValue(initialValue);
		setIsEditing(false);
		setIsClean(true);
		setIsUnsaved(false);
	}, [
		initialValue,
		isDraft,
		onRemove
	]);
	const onUpdate = useCallback(() => {
		onCommit(fieldId, inputValue);
		setIsEditing(false);
		setIsClean(true);
		setIsUnsaved(false);
	}, [
		fieldId,
		onCommit,
		inputValue
	]);
	const onOpen = useCallback(() => {
		if (isClean) setInputValue(initialValue);
		setIsEditing(true);
	}, [initialValue, isClean]);
	const onClose = useCallback(() => {
		onClosed?.();
		if (isDraft) {
			onRemove();
			return;
		}
		if (!isClean) setIsUnsaved(true);
		setIsEditing(false);
	}, [
		isClean,
		isDraft,
		onClosed,
		onRemove
	]);
	const commandProps = useMemo(() => ({
		commands: {
			"github:cancel": onCancel,
			"github:submit-form": preventSubmit ? void 0 : onUpdate
		},
		keys: {
			"github:cancel": ["Escape"],
			"github:submit-form": ["Enter"]
		}
	}), [
		preventSubmit,
		onCancel,
		onUpdate
	]);
	const headerRef = useRef(null);
	const [calculatedWidth, setCalculatedWidth] = useState(FALLBACK_WIDTH$1);
	useEffect(() => {
		if (isEditing && headerRef.current) {
			const width = headerRef.current.getBoundingClientRect().width;
			if (width > 0) setCalculatedWidth(`${width}px`);
		}
	}, [isEditing]);
	const displayTitle = useMemo(() => {
		return isUnsaved ? `${fieldName} (edited)` : fieldName;
	}, [fieldName, isUnsaved]);
	return /* @__PURE__ */ jsx(AnchoredOverlay, {
		open: isEditing,
		anchorRef: headerRef,
		renderAnchor: (props) => renderAnchor(props, headerRef, displayTitle),
		onClose,
		onOpen,
		overlayProps: { style: { width: overrideWidth ?? calculatedWidth } },
		children: /* @__PURE__ */ jsxs(ScopedCommands, {
			...commandProps,
			children: [/* @__PURE__ */ jsx("div", {
				className: IssueFieldTextToken_module_default.issuesFieldTextInputContainer,
				children: /* @__PURE__ */ jsxs(FormControl$1, { children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, {
						visuallyHidden: true,
						children: LABELS$1.textEditorLabel(fieldName)
					}),
					/* @__PURE__ */ jsx(TextInput$1, {
						block: true,
						value: inputValue,
						placeholder: LABELS$1.textEditorPlaceholder,
						onChange: handleTextChange,
						...inputProps
					}),
					validationMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
						variant: "error",
						className: IssueFieldTextToken_module_default.issuesFieldTextError,
						children: validationMessage
					})
				] })
			}), /* @__PURE__ */ jsx("div", {
				className: IssueFieldTextToken_module_default.issuesFieldToolbar,
				role: "toolbar",
				"aria-label": LABELS$1.textEditorToolbarLabel(fieldName),
				children: /* @__PURE__ */ jsxs("div", {
					className: IssueFieldTextToken_module_default.issuesFieldToolbarActions,
					children: [/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						onClick: onCancel,
						className: IssueFieldTextToken_module_default.actionButton,
						trailingVisual: /* @__PURE__ */ jsx(CommandKeybindingHint, { commandId: "github:cancel" }),
						children: LABELS$1.textEditorCancelButton
					}), /* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						variant: "primary",
						onClick: preventSubmit ? void 0 : onUpdate,
						"aria-disabled": preventSubmit,
						inactive: preventSubmit,
						"aria-label": LABELS$1.textEditorUpdateButtonAriaLabel(fieldName),
						className: IssueFieldTextToken_module_default.actionButton,
						trailingVisual: /* @__PURE__ */ jsx(CommandKeybindingHint, { commandId: "github:submit-form" }),
						children: LABELS$1.textEditorUpdateButton
					})]
				})
			})]
		})
	});
};
IssueFieldTextEditorInternal.displayName = "IssueFieldTextEditorInternal";
var NUMBER_PATTERN = /^-?\d+(\.\d+)?$/;
var MAX_INTEGER_VALUE = 2147483647;
var MIN_INTEGER_VALUE = -2147483648;
var numberValidation = (value) => {
	if (value === "") return null;
	if (!NUMBER_PATTERN.test(value)) return LABELS$1.numberValidation.errorMessage;
	const parsed = parseFloat(value);
	if (parsed > MAX_INTEGER_VALUE) return LABELS$1.numberValidation.max(MAX_INTEGER_VALUE);
	if (parsed < MIN_INTEGER_VALUE) return LABELS$1.numberValidation.min(MIN_INTEGER_VALUE);
	return null;
};
var IssueFieldNumberEditor$1 = (props) => {
	return /* @__PURE__ */ jsx(IssueFieldTextEditor$1, {
		...props,
		inputProps: {
			placeholder: LABELS$1.numberEditorPlaceholder,
			inputMode: "numeric"
		},
		validate: numberValidation,
		isNumber: true,
		className: props.className
	});
};
IssueFieldNumberEditor$1.displayName = "IssueFieldNumberEditor";
var node$59 = {
	"kind": "InlineDataFragment",
	"name": "IssueSingleSelectFieldPickerOption"
};
node$59.hash = "d8bcb73a6758269a0f127f7a03e396bc";
var node$58 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [
		v2,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "description",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "color",
			"storageKey": null
		}
	];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "IssueSingleSelectFieldPickerFieldQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "IssueFieldSingleSelectOption",
						"kind": "LinkedField",
						"name": "options",
						"plural": true,
						"selections": [{
							"kind": "InlineDataFragmentSpread",
							"name": "IssueSingleSelectFieldPickerOption",
							"selections": v3,
							"args": null,
							"argumentDefinitions": []
						}],
						"storageKey": null
					}],
					"type": "IssueFieldSingleSelect",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "IssueSingleSelectFieldPickerFieldQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					},
					{
						"kind": "InlineFragment",
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "IssueFieldSingleSelectOption",
							"kind": "LinkedField",
							"name": "options",
							"plural": true,
							"selections": v3,
							"storageKey": null
						}],
						"type": "IssueFieldSingleSelect",
						"abstractKey": null
					},
					v2
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "c64e6ba36203e1baee1d8517134d7d4c",
			"metadata": {},
			"name": "IssueSingleSelectFieldPickerFieldQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$58.hash = "0979e35fc8348ec832d8c8f2a2b59fec";
var IssueSingleSelectFieldPickerOptionFragment = node$59;
var IssueSingleSelectFieldPickerFieldGraphqlQuery = node$58;
function IssueSingleSelectFieldPicker({ anchorElement, isLazy, shouldOpen = false, ...props }) {
	if (isLazy && !shouldOpen) return /* @__PURE__ */ jsx(LazyItemPicker, {
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		createChild: () => /* @__PURE__ */ jsx(IssueSingleSelectFieldPickerFetcher, {
			anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
			...props
		})
	});
	else return /* @__PURE__ */ jsx(IssueSingleSelectFieldPickerFetcher, {
		anchorElement: (anchorProps, ref) => anchorElement(anchorProps, ref),
		...props
	});
}
IssueSingleSelectFieldPicker.displayName = "IssueSingleSelectFieldPicker";
function IssueSingleSelectFieldPickerFetcher(t0) {
	const $ = c(14);
	const { fieldId, anchorElement, ...props } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [isLoading, setIsLoading] = useState(true);
	const [fetchKey, setFetchKey] = useState(0);
	const [isError, setIsError] = useState(false);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [data, setData] = useState(t1);
	let t2;
	if ($[1] !== environment || $[2] !== fieldId) {
		t2 = () => {
			clientSideRelayFetchQueryRetained({
				environment,
				query: IssueSingleSelectFieldPickerFieldGraphqlQuery,
				variables: { id: fieldId }
			}).subscribe({
				next: (internalData) => {
					const keys = internalData.node?.options;
					setData(keys ?? []);
					setIsLoading(false);
					setIsError(false);
				},
				error: () => {
					setIsError(true);
					setIsLoading(false);
				}
			});
		};
		$[1] = environment;
		$[2] = fieldId;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== environment || $[5] !== fetchKey || $[6] !== fieldId) {
		t3 = [
			environment,
			fetchKey,
			fieldId
		];
		$[4] = environment;
		$[5] = fetchKey;
		$[6] = fieldId;
		$[7] = t3;
	} else t3 = $[7];
	useEffect(t2, t3);
	let t4;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = LABELS$3.cantEditItems("fields");
		$[8] = t4;
	} else t4 = $[8];
	let t5;
	if ($[9] !== anchorElement) {
		t5 = {
			errorMessage: t4,
			anchorElement,
			open: true
		};
		$[9] = anchorElement;
		$[10] = t5;
	} else t5 = $[10];
	const { createFallbackComponent } = useItemPickerErrorFallback(t5);
	if (isError) {
		let t6;
		if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
			t6 = () => setFetchKey(_temp$16);
			$[11] = t6;
		} else t6 = $[11];
		let t7;
		if ($[12] !== createFallbackComponent) {
			t7 = createFallbackComponent(t6);
			$[12] = createFallbackComponent;
			$[13] = t7;
		} else t7 = $[13];
		return t7;
	}
	return jsx(ItemPickerWrapper, {
		fieldId,
		values: data,
		isLoading,
		anchorElement,
		...props
	});
}
IssueSingleSelectFieldPickerFetcher.displayName = "IssueSingleSelectFieldPickerFetcher";
function _temp$16(current) {
	return current + 1;
}
function ItemPickerWrapper({ title = LABELS$3.fieldSingleSelectHeader, width = "medium", values, fieldName, selectedOption, onSelectionChange, onOpen, onClose, insidePortal, anchorElement, isLoading }) {
	const [filter, setFilter] = useState("");
	const dynamicTitle = fieldName ? LABELS$3.fieldSingleSelectHeaderWithName(fieldName) : title;
	const fetchedIssueFieldOptions = values.flatMap((a) => a ? [(0, import_react_relay.readInlineData)(IssueSingleSelectFieldPickerOptionFragment, a)] : []);
	const items = useMemo(() => {
		if (!filter) return fetchedIssueFieldOptions;
		return fetchedIssueFieldOptions.filter((l) => l.name && l.name.toLowerCase().indexOf(filter.toLowerCase()) >= 0);
	}, [fetchedIssueFieldOptions, filter]);
	const filterItems = useCallback((value) => {
		setFilter(value);
	}, []);
	const getItemKey = useCallback((option) => option.id || "", []);
	const convertToItemProps = useCallback((option_0) => {
		return {
			id: option_0.id,
			text: option_0.name,
			description: option_0.description || "",
			descriptionVariant: "block",
			leadingVisual: createIssueSingleSelectFieldPickerItemLeadingVisual(option_0.color),
			source: option_0
		};
	}, []);
	const initialSelectedItems = useMemo(() => {
		if (selectedOption) {
			const selectedItem = fetchedIssueFieldOptions.find((item) => item.name === selectedOption);
			if (selectedItem) return [selectedItem];
		}
		return [];
	}, [fetchedIssueFieldOptions, selectedOption]);
	const anchorRef = useRef(null);
	const showNoMatchMessage = useMemo(() => items.length === 0, [items]);
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	return /* @__PURE__ */ jsx(ItemPicker, {
		loading: isLoading,
		items,
		initialSelectedItems,
		filterItems,
		title: dynamicTitle,
		getItemKey,
		convertToItemProps,
		placeholderText: `Filter option`,
		selectionVariant: "single",
		onSelectionChange: (selectedItems) => onSelectionChange(selectedItems && selectedItems.length > 0 && selectedItems[0] ? selectedItems[0] : null),
		onOpen,
		onClose,
		renderAnchor: (anchorProps) => anchorElement(anchorProps, anchorRef),
		insidePortal,
		height: "large",
		width,
		resultListAriaLabel: "Issue field option results",
		triggerOpen: true,
		selectPanelRef: anchorRef,
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No option found",
			variant: "empty",
			body: "Try searching with a different query for results."
		} : void 0,
		responsiveOnNarrow: responsiveOnNarrowEnabled
	});
}
ItemPickerWrapper.displayName = "ItemPickerWrapper";
var MetadataFooter_module_default = {
	animationClass: "MetadataFooter-module_U7zZjG_animationClass",
	MetadataFooterContainer: "MetadataFooter-module_U7zZjG_MetadataFooterContainer",
	MetadataFooterSeparator: "MetadataFooter-module_U7zZjG_MetadataFooterSeparator",
	SingleSelectFieldDot: "MetadataFooter-module_U7zZjG_SingleSelectFieldDot"
};
var IssueFieldValueSharedEditorAnchor = ({ fieldWithValue, buttonProps, className, readonly }) => {
	const fieldType = toIssueFieldType(fieldWithValue.field.dataType);
	const text = getIssueFieldSelectionPresentationValue(fieldType, fieldWithValue.value);
	const leadingIconElement = getLeadingIconElement(fieldWithValue);
	return /* @__PURE__ */ jsx(SharedPicker, {
		anchorText: text ? `${fieldWithValue.field.name}:` : fieldWithValue.field.name,
		sharedPickerMainValue: text,
		leadingIcon: getFieldTypeOcticon(fieldType),
		leadingIconElement,
		anchorProps: buttonProps,
		className,
		readonly
	}, fieldWithValue.field.id);
};
IssueFieldValueSharedEditorAnchor.displayName = "IssueFieldValueSharedEditorAnchor";
var getLeadingIconElement = (fieldWithValue) => {
	if (fieldWithValue.field.dataType === "SINGLE_SELECT" && fieldWithValue.value) return /* @__PURE__ */ jsx(SingleSelectFieldDot, { color: fieldWithValue.value?.color || "GRAY" });
	return null;
};
var SingleSelectFieldDot = (t0) => {
	const $ = c(4);
	const { color } = t0;
	let t1;
	if ($[0] !== color) {
		t1 = colorNames.find((c) => c === color);
		$[0] = color;
		$[1] = t1;
	} else t1 = $[1];
	const { fg } = useNamedColor(t1);
	const t2 = `${fg}`;
	let t3;
	if ($[2] !== t2) {
		t3 = jsx("div", {
			style: { "--bg": t2 },
			className: MetadataFooter_module_default.SingleSelectFieldDot
		});
		$[2] = t2;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
};
SingleSelectFieldDot.displayName = "SingleSelectFieldDot";
var addIssueFieldAnchor = (anchorProps, ref) => {
	return /* @__PURE__ */ jsx(IconButton, {
		onClick: (event) => {
			anchorProps.onClick?.(event);
		},
		ref,
		icon: PlusIcon,
		variant: "default",
		"aria-label": LABELS$2.setAdditionalFields,
		tooltipDirection: "n",
		size: "small"
	});
};
var FALLBACK_WIDTH = "256px";
var NORMALIZED_HOUR$1 = 12;
var IssueFieldValueSharedPendingEditor = ({ pendingField, onCommit, onClose }) => {
	return /* @__PURE__ */ jsx(IssueFieldEditor, {
		field: toIssueFieldWithUnsavedValue(pendingField, null),
		onCommit,
		onClose,
		shouldOpen: true
	});
};
IssueFieldValueSharedPendingEditor.displayName = "IssueFieldValueSharedPendingEditor";
var IssueFieldValueSharedEditor = (t0) => {
	const $ = c(8);
	const { field, onChange, className, readonly } = t0;
	let t1;
	if ($[0] !== field || $[1] !== onChange) {
		t1 = (fieldId, value) => {
			onChange(field, value);
		};
		$[0] = field;
		$[1] = onChange;
		$[2] = t1;
	} else t1 = $[2];
	const onCommit = t1;
	if (!field.field.id || !field.field.name) return null;
	let t2;
	if ($[3] !== className || $[4] !== field || $[5] !== onCommit || $[6] !== readonly) {
		t2 = jsx(IssueFieldEditor, {
			field,
			onCommit,
			className,
			readonly
		});
		$[3] = className;
		$[4] = field;
		$[5] = onCommit;
		$[6] = readonly;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
};
IssueFieldValueSharedEditor.displayName = "IssueFieldValueSharedEditor";
var IssueFieldNumberEditor = ({ field, onCommit, anchorElement, shouldOpen = false, onClose }) => {
	return /* @__PURE__ */ jsx(IssueFieldTextEditorInternal, {
		fieldId: field.field.id,
		fieldName: field.field.name,
		initialValue: field.value,
		onCommit,
		renderAnchor: anchorElement,
		overrideWidth: FALLBACK_WIDTH,
		isNumber: true,
		validate: numberValidation,
		shouldOpen,
		onClose
	});
};
IssueFieldNumberEditor.displayName = "IssueFieldNumberEditor";
var IssueFieldTextEditor = ({ field, onCommit, anchorElement, shouldOpen = false, onClose }) => {
	return /* @__PURE__ */ jsx(IssueFieldTextEditorInternal, {
		fieldId: field.field.id,
		fieldName: field.field.name,
		initialValue: field.value,
		onCommit,
		renderAnchor: anchorElement,
		overrideWidth: FALLBACK_WIDTH,
		shouldOpen,
		onClose
	});
};
IssueFieldTextEditor.displayName = "IssueFieldTextEditor";
var IssueFieldDateEditor$1 = (t0) => {
	const $ = c(17);
	const { field, onCommit, anchorElement, shouldOpen: t1, onClose } = t0;
	const [open, setOpen] = useState(t1 === void 0 ? false : t1);
	let t2;
	bb0: {
		const value = field.value;
		if (!value) {
			t2 = null;
			break bb0;
		}
		let t3;
		if ($[0] !== value) {
			t3 = new Date(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate());
			$[0] = value;
			$[1] = t3;
		} else t3 = $[1];
		t2 = t3;
	}
	const datePickerValue = t2;
	let t3;
	if ($[2] !== field.field.id || $[3] !== onCommit) {
		t3 = (date) => {
			let normalizedDate = null;
			if (date) normalizedDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), NORMALIZED_HOUR$1, 0, 0, 0));
			onCommit(field.field.id, normalizedDate);
		};
		$[2] = field.field.id;
		$[3] = onCommit;
		$[4] = t3;
	} else t3 = $[4];
	const handleDateChange = t3;
	let t4;
	if ($[5] !== anchorElement) {
		t4 = (anchorProps) => anchorElement(anchorProps);
		$[5] = anchorElement;
		$[6] = t4;
	} else t4 = $[6];
	let t5;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = () => {
			setOpen(true);
		};
		$[7] = t5;
	} else t5 = $[7];
	let t6;
	if ($[8] !== onClose) {
		t6 = () => {
			setOpen(false);
			onClose?.();
		};
		$[8] = onClose;
		$[9] = t6;
	} else t6 = $[9];
	let t7;
	if ($[10] !== datePickerValue || $[11] !== field.field.id || $[12] !== handleDateChange || $[13] !== open || $[14] !== t4 || $[15] !== t6) {
		t7 = jsx(DatePicker, {
			anchor: t4,
			showClearButton: true,
			showTodayButton: true,
			variant: "single",
			dateFormat: "long",
			onChange: handleDateChange,
			value: datePickerValue,
			placeholder: "Set date",
			open,
			onOpen: t5,
			onClose: t6,
			anchoredOverlayProps: { side: "outside-top" }
		}, field.field.id);
		$[10] = datePickerValue;
		$[11] = field.field.id;
		$[12] = handleDateChange;
		$[13] = open;
		$[14] = t4;
		$[15] = t6;
		$[16] = t7;
	} else t7 = $[16];
	return t7;
};
IssueFieldDateEditor$1.displayName = "IssueFieldDateEditor";
var IssueFieldSingleSelectEditor$1 = ({ field, onCommit, anchorElement, shouldOpen = false, onClose }) => {
	const ssFieldValue = field.value;
	return /* @__PURE__ */ jsx(IssueSingleSelectFieldPicker, {
		fieldId: field.field.id,
		fieldName: field.field.name || "",
		selectedOption: ssFieldValue?.name || null,
		onSelectionChange: (selectedOption) => {
			onCommit(field.field.id, selectedOption);
		},
		anchorElement: (anchorProps) => anchorElement(anchorProps),
		readonly: false,
		isLazy: true,
		shouldOpen,
		onClose,
		insidePortal: true
	}, field.field.id);
};
IssueFieldSingleSelectEditor$1.displayName = "IssueFieldSingleSelectEditor";
var IssueFieldEditor = (t0) => {
	const $ = c(28);
	const { field, onCommit, onClose, shouldOpen: t1, className, readonly } = t0;
	const shouldOpen = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== className || $[1] !== field || $[2] !== readonly) {
		t2 = (buttonProps) => jsx(IssueFieldValueSharedEditorAnchor, {
			fieldWithValue: field,
			buttonProps,
			className,
			readonly
		}, field.field.id);
		$[0] = className;
		$[1] = field;
		$[2] = readonly;
		$[3] = t2;
	} else t2 = $[3];
	const anchorElement = t2;
	switch (field.field.dataType) {
		case "SINGLE_SELECT": {
			let t3;
			if ($[4] !== anchorElement || $[5] !== field || $[6] !== onClose || $[7] !== onCommit || $[8] !== shouldOpen) {
				t3 = jsx(IssueFieldSingleSelectEditor$1, {
					field,
					onCommit,
					anchorElement,
					shouldOpen,
					onClose
				});
				$[4] = anchorElement;
				$[5] = field;
				$[6] = onClose;
				$[7] = onCommit;
				$[8] = shouldOpen;
				$[9] = t3;
			} else t3 = $[9];
			return t3;
		}
		case "DATE": {
			let t3;
			if ($[10] !== anchorElement || $[11] !== field || $[12] !== onClose || $[13] !== onCommit || $[14] !== shouldOpen) {
				t3 = jsx(IssueFieldDateEditor$1, {
					field,
					onCommit,
					anchorElement,
					shouldOpen,
					onClose
				});
				$[10] = anchorElement;
				$[11] = field;
				$[12] = onClose;
				$[13] = onCommit;
				$[14] = shouldOpen;
				$[15] = t3;
			} else t3 = $[15];
			return t3;
		}
		case "TEXT": {
			let t3;
			if ($[16] !== anchorElement || $[17] !== field || $[18] !== onClose || $[19] !== onCommit || $[20] !== shouldOpen) {
				t3 = jsx(IssueFieldTextEditor, {
					field,
					onCommit,
					anchorElement,
					shouldOpen,
					onClose
				});
				$[16] = anchorElement;
				$[17] = field;
				$[18] = onClose;
				$[19] = onCommit;
				$[20] = shouldOpen;
				$[21] = t3;
			} else t3 = $[21];
			return t3;
		}
		case "NUMBER": {
			let t3;
			if ($[22] !== anchorElement || $[23] !== field || $[24] !== onClose || $[25] !== onCommit || $[26] !== shouldOpen) {
				t3 = jsx(IssueFieldNumberEditor, {
					field,
					onCommit,
					anchorElement,
					shouldOpen,
					onClose
				});
				$[22] = anchorElement;
				$[23] = field;
				$[24] = onClose;
				$[25] = onCommit;
				$[26] = shouldOpen;
				$[27] = t3;
			} else t3 = $[27];
			return t3;
		}
	}
};
IssueFieldEditor.displayName = "IssueFieldEditor";
var MetadataFooter = (t0) => {
	const $ = c(10);
	const { repo, owner, canSetAssignees, canSetLabels, canSetMilestone, canCreateLabel, canCreateMilestone, canSetProjects, canSetIssueFields, canSetType, issueTypesEnabled, orgPinnedFields } = t0;
	const { optionConfig } = useIssueCreateConfigContext();
	const { repository, labels, setLabels, assignees, setAssignees, projects, setProjects, milestone, setMilestone, issueType, setIssueType, issueFields, setIssueFields } = useIssueCreateDataContext();
	const sharedConfigProps = { insidePortal: optionConfig.insidePortal };
	const showAddFieldButton = isFeatureEnabled("issue_metadata_add_field_button");
	let t1;
	if ($[0] !== issueType || $[1] !== orgPinnedFields) {
		t1 = issueType ? parsePinnedIssueFields(issueType.pinnedFields?.filter(_temp$15)) ?? [] : orgPinnedFields ?? [];
		$[0] = issueType;
		$[1] = orgPinnedFields;
		$[2] = t1;
	} else t1 = $[2];
	const mergedPinnedFields = t1;
	let t2;
	if ($[3] !== optionConfig.scopedFields) {
		t2 = optionConfig.scopedFields || [];
		$[3] = optionConfig.scopedFields;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== issueFields || $[6] !== mergedPinnedFields || $[7] !== setIssueFields || $[8] !== t2) {
		t3 = {
			pinnedFieldsFromType: mergedPinnedFields,
			setIssueFieldsWithValues: setIssueFields,
			scopedFields: t2,
			issueFields
		};
		$[5] = issueFields;
		$[6] = mergedPinnedFields;
		$[7] = setIssueFields;
		$[8] = t2;
		$[9] = t3;
	} else t3 = $[9];
	const { pendingSelectedField, setPendingSelectedField, pinnedFields, unpinnedFields, selectedFieldNames, onPendingFieldCommit, onIssueFieldPickerSelectionChange, onIssueFieldValueChanged } = useIssueFieldPickers(t3);
	const firstSelectedProjectTitle = projects[0]?.title || "";
	const { sendAnalyticsEvent } = useAnalytics();
	const pickerProps = repository && (canSetAssignees || assignees.length > 0) && !optionConfig.scopedAssignees ? {
		repo: repository.name,
		owner: repository.owner.login,
		readonly: !canSetAssignees,
		includeAuthorableBots: false,
		includeAssignableBots: true,
		assignees,
		assigneeTokens: [],
		anchorElement: (anchorProps, ref) => jsx(DefaultAssigneePickerAnchor, {
			assignees,
			readonly: !canSetAssignees,
			anchorProps: {
				...anchorProps,
				id: "assignees-select-menu"
			},
			ref,
			...sharedConfigProps
		}),
		onSelectionChange: setAssignees,
		...sharedConfigProps
	} : null;
	let picker = null;
	if (pickerProps) picker = jsx(AssigneeRepositoryPicker, { ...pickerProps });
	return jsx(Suspense, {
		fallback: jsx(MetadataFooterLoading, {}),
		children: jsxs("div", {
			className: MetadataFooter_module_default.MetadataFooterContainer,
			children: [
				picker,
				optionConfig.scopedAssignees && jsx(CompressedAssigneeAnchor, {
					assignees: optionConfig.scopedAssignees,
					displayHotkey: false,
					anchorProps: void 0,
					readonly: true
				}),
				(canSetLabels || labels.length > 0) && jsx(LabelPicker, {
					repo,
					owner,
					readonly: !canSetLabels,
					canCreateLabel,
					showNoMatchItem: true,
					labels,
					anchorElement: (anchorProps_0, ref_0) => jsx(DefaultLabelPickerAnchor, {
						readonly: !canSetLabels,
						labels,
						anchorProps: anchorProps_0,
						ref: ref_0,
						...sharedConfigProps
					}),
					onSelectionChange: setLabels,
					...sharedConfigProps
				}),
				issueTypesEnabled && (canSetType || issueType !== null) && !optionConfig.scopedIssueType && jsx(IssueTypePicker, {
					owner,
					repo,
					onSelectionChange: (issueTypes) => {
						const newType = issueTypes?.[0] || null;
						sendAnalyticsEvent("issue_create.update_issue_type", "ISSUE_CREATE_UPDATE_ISSUE_TYPE_DIALOG", { issueTypeId: newType?.id ?? "" });
						setIssueType(newType);
					},
					anchorElement: (anchorProps_1) => jsx(DefaultIssueTypePickerAnchor, {
						readonly: !canSetType,
						activeIssueType: issueType,
						anchorProps: anchorProps_1,
						...sharedConfigProps
					}),
					readonly: !canSetType,
					activeIssueType: issueType ?? null,
					width: "medium",
					...sharedConfigProps
				}),
				canSetIssueFields && pinnedFields.map((field) => jsx(IssueFieldValueSharedEditor, {
					field,
					onChange: onIssueFieldValueChanged,
					className: MetadataFooter_module_default.animationClass,
					readonly: field.readonly
				}, field.field.id)),
				(issueTypesEnabled && (canSetType || issueType !== null) || canSetIssueFields && pinnedFields.length > 0) && jsx("div", {
					className: MetadataFooter_module_default.MetadataFooterSeparator,
					"data-testid": "issue-fields-divider"
				}),
				optionConfig.scopedIssueType && jsx(SharedPicker, {
					anchorText: optionConfig.scopedIssueType,
					leadingIcon: IssueOpenedIcon,
					readonly: true
				}),
				repository && !optionConfig.scopedProjectTitle && (canSetProjects || projects.length > 0) && jsx(ErrorBoundary, {
					fallback: jsx(SharedPicker, {
						anchorText: "Projects are unavailable",
						leadingIcon: AlertIcon,
						readonly: true
					}),
					children: jsx(ProjectPicker, {
						pickerId: "create-issue-projects-picker",
						readonly: !canSetProjects,
						onSave: setProjects,
						selectedProjects: projects,
						owner: repository.owner.login,
						repo: repository.name,
						anchorElement: (anchorProps_2) => jsx(DefaultProjectPickerAnchor, {
							nested: false,
							readonly: !canSetProjects,
							anchorProps: anchorProps_2,
							firstSelectedProjectTitle,
							...sharedConfigProps
						}),
						...sharedConfigProps
					})
				}),
				optionConfig.scopedProjectTitle && jsx(SharedPicker, {
					anchorText: optionConfig.scopedProjectTitle,
					leadingIcon: TableIcon,
					readonly: true
				}),
				(canSetMilestone || milestone !== null) && !optionConfig.scopedMilestone && jsx(MilestonePicker, {
					repo,
					owner,
					readonly: !canSetMilestone,
					canCreateMilestone,
					showNoMatchItem: true,
					activeMilestone: milestone,
					anchorElement: (anchorProps_3, ref_1) => jsx(DefaultMilestonePickerAnchor, {
						nested: false,
						readonly: !canSetMilestone,
						activeMilestone: milestone,
						anchorProps: anchorProps_3,
						ref: ref_1,
						...sharedConfigProps
					}),
					onSelectionChange: (milestones) => setMilestone(milestones?.[0] || null),
					...sharedConfigProps
				}),
				optionConfig.scopedMilestone && jsx(SharedPicker, {
					anchorText: optionConfig.scopedMilestone,
					leadingIcon: MilestoneIcon,
					readonly: true
				}),
				canSetIssueFields && unpinnedFields.map((field_0) => jsx(IssueFieldValueSharedEditor, {
					field: field_0,
					onChange: onIssueFieldValueChanged,
					className: MetadataFooter_module_default.animationClass,
					readonly: field_0.readonly
				}, field_0.field.id)),
				pendingSelectedField && jsx(IssueFieldValueSharedPendingEditor, {
					pendingField: pendingSelectedField,
					onCommit: onPendingFieldCommit,
					onClose: () => {
						setPendingSelectedField(null);
					}
				}),
				canSetIssueFields && showAddFieldButton && jsxs(Fragment$1, { children: [jsx("div", { className: MetadataFooter_module_default.MetadataFooterSeparator }), jsx(IssueFieldPicker, {
					owner,
					title: LABELS$2.addIssueField,
					fieldsSet: selectedFieldNames,
					onSelectionChange: onIssueFieldPickerSelectionChange,
					anchorElement: addIssueFieldAnchor,
					...sharedConfigProps
				})] })
			]
		})
	});
};
MetadataFooter.displayName = "MetadataFooter";
function _temp$15(f) {
	return f?.__typename !== "%other";
}
var node$57 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "AssigneesSectionLazyFragment",
	"selections": [{
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 10
		}],
		"concreteType": "AssigneeConnection",
		"kind": "LinkedField",
		"name": "suggestedActors",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "nodes",
			"plural": true,
			"selections": [{
				"kind": "InlineFragment",
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "id",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "login",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "name",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "profileResourcePath",
						"storageKey": null
					},
					{
						"alias": null,
						"args": [{
							"kind": "Literal",
							"name": "size",
							"value": 64
						}],
						"kind": "ScalarField",
						"name": "avatarUrl",
						"storageKey": "avatarUrl(size:64)"
					},
					{
						"kind": "InlineFragment",
						"selections": [
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isCopilot",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isAgent",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "displayName",
								"storageKey": null
							}
						],
						"type": "Bot",
						"abstractKey": null
					}
				],
				"type": "Actor",
				"abstractKey": "__isActor"
			}],
			"storageKey": null
		}],
		"storageKey": "suggestedActors(first:10)"
	}],
	"type": "Issue",
	"abstractKey": null
};
node$57.hash = "627359ef0b6d54885728c97ff256ba6d";
var node$56 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isCopilot",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isAgent",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "displayName",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "AssigneesSectionAssignees",
		"selections": [{
			"alias": null,
			"args": [{
				"kind": "Literal",
				"name": "first",
				"value": 20
			}],
			"concreteType": "AssigneeConnection",
			"kind": "LinkedField",
			"name": "assignedActors",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "nodes",
				"plural": true,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [
						v0,
						v1,
						v2,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "name",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "profileResourcePath",
							"storageKey": null
						},
						v3,
						{
							"kind": "InlineFragment",
							"selections": [
								v4,
								v5,
								v6
							],
							"type": "Bot",
							"abstractKey": null
						}
					],
					"type": "Actor",
					"abstractKey": "__isActor"
				}],
				"storageKey": null
			}],
			"storageKey": "assignedActors(first:20)"
		}, {
			"alias": null,
			"args": null,
			"concreteType": "AgentAssignment",
			"kind": "LinkedField",
			"name": "agentAssignments",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "Bot",
				"kind": "LinkedField",
				"name": "assignee",
				"plural": false,
				"selections": [
					v1,
					v2,
					v3,
					v4,
					v5,
					v6
				],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "assigner",
				"plural": false,
				"selections": [
					v0,
					{
						"kind": "InlineFragment",
						"selections": [v1],
						"type": "Node",
						"abstractKey": "__isNode"
					},
					v2
				],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$56.hash = "351c302a681998931dfc7f70781c6be3";
var node$55 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "AssigneesSectionCopilotRepositoryFragment",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isCopilotAgentEnabled",
		"storageKey": null
	}],
	"type": "Repository",
	"abstractKey": null
};
node$55.hash = "d0d5039c0af037561a9f4ee503f04833";
var node$54 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "AssigneesSectionFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "number",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "login",
						"storageKey": null
					}],
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isArchived",
					"storageKey": null
				},
				{
					"args": null,
					"kind": "FragmentSpread",
					"name": "AssigneesSectionCopilotRepositoryFragment"
				}
			],
			"storageKey": null
		},
		{
			"args": null,
			"kind": "FragmentSpread",
			"name": "AssigneesSectionAssignees"
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanAssign",
			"storageKey": null
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$54.hash = "d3c6b2757554e31ea145489e96bddf6e";
var node$53 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "AssigneesSectionViewer",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "__typename",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "login",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "profileResourcePath",
			"storageKey": null
		},
		{
			"alias": null,
			"args": [{
				"kind": "Literal",
				"name": "size",
				"value": 64
			}],
			"kind": "ScalarField",
			"name": "avatarUrl",
			"storageKey": "avatarUrl(size:64)"
		},
		{
			"kind": "InlineFragment",
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isCopilot",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isAgent",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "displayName",
					"storageKey": null
				}
			],
			"type": "Bot",
			"abstractKey": null
		}
	],
	"type": "Actor",
	"abstractKey": "__isActor"
};
node$53.hash = "46cd158d7367cb350d33a4333817d807";
var CopilotAssignmentButton = ({ ref, onClick }) => {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	return /* @__PURE__ */ jsx(ButtonComponent, {
		ref,
		leadingVisual: AgentIcon,
		size: "small",
		block: true,
		onClick: useCallback(() => {
			sendClickAnalyticsEvent({
				category: "copilot_assignment",
				action: "click_assign_to_copilot_button",
				label: "ref_cta:assign_to_copilot"
			});
			onClick();
		}, [sendClickAnalyticsEvent, onClick]),
		children: isFeatureEnabled("issue_cca_modal_open") ? "Assign to Agent" : "Assign to Copilot"
	});
};
CopilotAssignmentButton.displayName = "CopilotAssignmentButton";
CopilotAssignmentButton.displayName = "CopilotAssignmentButton";
function AssigneeVisual({ login, id, avatarUrl, isCopilot }) {
	if (isCopilot) return /* @__PURE__ */ jsx(CopilotAvatar, {});
	else return /* @__PURE__ */ jsx(GitHubAvatar, {
		src: avatarUrl,
		size: 20,
		alt: `@${login}`
	}, id);
}
AssigneeVisual.displayName = "AssigneeVisual";
function addKeyboardHint(attributes) {
	if (isHovercardHintEnabledForUser()) return {
		...attributes,
		"aria-keyshortcuts": HOVERCARD_KEYBOARD_SHORTCUT
	};
	return attributes;
}
function addTrackingAttributes(attributes) {
	return addKeyboardHint({
		...attributes,
		"octo-click": "hovercard-link-click",
		"octo-dimensions": "link_type:self"
	});
}
/**
* Legacy helper for actor hovercards (user/copilot).
* Prefer using hovercardAttributes('user', {login}) or hovercardAttributes('copilot', {botSlug}) directly.
*
* @deprecated Use hovercardAttributes('user', {login}) or hovercardAttributes('copilot', {botSlug}) instead
*/
function hovercardAttributesForActor(login, { isCopilot = false, tracking = true, isAgent = false } = {}) {
	if (isCopilot || isAgent) {
		const url = copilotHovercardPath({ bot_slug: login });
		return tracking ? addTrackingAttributes(addKeyboardHint({
			"data-hovercard-url": url,
			"data-hovercard-type": "copilot"
		})) : addKeyboardHint({
			"data-hovercard-url": url,
			"data-hovercard-type": "copilot"
		});
	} else {
		const url = userHovercardPath({ owner: login });
		return tracking ? addTrackingAttributes(addKeyboardHint({
			"data-hovercard-url": url,
			"data-hovercard-type": "user"
		})) : addKeyboardHint({
			"data-hovercard-url": url,
			"data-hovercard-type": "user"
		});
	}
}
var Assignees_module_default = {
	agentTaskCount: "Assignees-module_b8Ph1q_agentTaskCount",
	agentTaskStatus: "Assignees-module_b8Ph1q_agentTaskStatus",
	assigneeNameLabel: "Assignees-module_b8Ph1q_assigneeNameLabel",
	assigneesList: "Assignees-module_b8Ph1q_assigneesList",
	connector: "Assignees-module_b8Ph1q_connector",
	connectorLast: "Assignees-module_b8Ph1q_connectorLast",
	connectorMiddle: "Assignees-module_b8Ph1q_connectorMiddle",
	nestedAgentItem: "Assignees-module_b8Ph1q_nestedAgentItem",
	nestedAgentVisual: "Assignees-module_b8Ph1q_nestedAgentVisual"
};
function Assignees(t0) {
	const $ = c(8);
	const { assignees, testId } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== assignees || $[1] !== sendAnalyticsEvent || $[2] !== testId) {
		const copilotMissionControlDecoupledMode = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		const issueCcaVisualization = isFeatureEnabled("issue_cca_visualization");
		const issueCcaVisualizationDecoupledMode = isFeatureEnabled("issue_cca_visualization_decoupled_mode");
		const isVisualizationEnabled = issueCcaVisualization || copilotMissionControlDecoupledMode && issueCcaVisualizationDecoupledMode;
		let t2;
		if ($[4] !== sendAnalyticsEvent) {
			t2 = () => {
				sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_ASSIGNEE_CLICK");
			};
			$[4] = sendAnalyticsEvent;
			$[5] = t2;
		} else t2 = $[5];
		const handleClick = t2;
		let t3;
		if ($[6] !== sendAnalyticsEvent) {
			t3 = () => {
				sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_ASSIGNEE_RIGHT_CLICK");
			};
			$[6] = sendAnalyticsEvent;
			$[7] = t3;
		} else t3 = $[7];
		const handleContextMenu = t3;
		t1 = jsx(ActionList, {
			variant: "full",
			className: Assignees_module_default.assigneesList,
			"data-icv-visible": true,
			children: [...assignees].sort(sortByLogin).map((t4) => {
				const { login, name, avatarUrl, profileResourcePath, id, isCopilot, displayName, isAgent, assignedAgents } = t4;
				const hasNestedAgents = isVisualizationEnabled && assignedAgents && assignedAgents.length > 0;
				return jsxs(Fragment, { children: [jsxs(ActionList.LinkItem, {
					href: profileResourcePath ?? void 0,
					target: "_blank",
					onClick: handleClick,
					onContextMenu: handleContextMenu,
					...hovercardAttributesForActor(login, {
						isCopilot,
						isAgent
					}),
					children: [jsx(ActionList.LeadingVisual, { children: jsx(AssigneeVisual, {
						login,
						id,
						avatarUrl,
						isCopilot
					}) }), jsx("div", {
						"data-testid": testId,
						className: Assignees_module_default.assigneeNameLabel,
						children: jsx(ProfileReference, {
							login: displayName,
							profileName: name,
							isAgent
						})
					})]
				}), hasNestedAgents && jsx("li", { children: jsx(ActionList, {
					"aria-label": `Agents assigned by ${displayName}`,
					children: assignedAgents.map((agent, agentIndex) => {
						const isLastAgent = agentIndex === assignedAgents.length - 1;
						const taskInfo = agent.agentTaskInfo;
						const agentHref = taskInfo?.taskUrl ?? agent.profileResourcePath ?? void 0;
						const linkItem = jsxs(ActionList.LinkItem, {
							href: agentHref,
							target: "_blank",
							onClick: handleClick,
							onContextMenu: handleContextMenu,
							className: Assignees_module_default.nestedAgentItem,
							"data-testid": "nested-agent-item",
							children: [
								jsx(ActionList.LeadingVisual, { children: jsxs("span", {
									className: Assignees_module_default.nestedAgentVisual,
									children: [jsx("span", {
										className: `${Assignees_module_default.connector} ${isLastAgent ? Assignees_module_default.connectorLast : Assignees_module_default.connectorMiddle}`,
										"aria-hidden": "true"
									}), jsx(AssigneeVisual, {
										login: agent.login,
										id: agent.id,
										avatarUrl: agent.avatarUrl,
										isCopilot: agent.isCopilot
									})]
								}) }),
								jsx("div", {
									className: Assignees_module_default.assigneeNameLabel,
									children: jsx(ProfileReference, {
										login: agent.displayName,
										profileName: agent.name,
										isAgent: agent.isAgent
									})
								}),
								taskInfo && taskInfo.count > 0 && jsx(ActionList.TrailingVisual, { children: jsxs("span", {
									className: Assignees_module_default.agentTaskStatus,
									children: [
										taskInfo.count > 1 && jsx(Token, {
											as: "span",
											className: Assignees_module_default.agentTaskCount,
											"aria-hidden": "true",
											text: String(taskInfo.count)
										}),
										taskInfo.count > 1 && jsxs("span", {
											className: "sr-only",
											children: [taskInfo.count, " tasks,"]
										}),
										taskInfo.statusIcon
									]
								}) })
							]
						}, agent.id);
						return taskInfo && taskInfo.count > 0 ? jsx(Tooltip$1, {
							text: taskInfo.count > 1 ? "View latest session" : "View session",
							children: linkItem
						}, agent.id) : linkItem;
					})
				}) })] }, id);
			})
		});
		$[0] = assignees;
		$[1] = sendAnalyticsEvent;
		$[2] = testId;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
Assignees.displayName = "Assignees";
function sortByLogin(a, b) {
	return a.login === b.login ? 0 : a.login > b.login ? 1 : -1;
}
var node$52 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 20
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "profileResourcePath",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isCopilot",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isAgent",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "displayName",
		"storageKey": null
	}, v12 = {
		"kind": "InlineFragment",
		"selections": [
			v9,
			v10,
			v11
		],
		"type": "Bot",
		"abstractKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"concreteType": "Bot",
		"kind": "LinkedField",
		"name": "assignee",
		"plural": false,
		"selections": [
			v2,
			v5,
			v8,
			v9,
			v10,
			v11
		],
		"storageKey": null
	}, v14 = {
		"kind": "InlineFragment",
		"selections": [v2],
		"type": "Node",
		"abstractKey": "__isNode"
	}, v15 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 10
		}],
		"concreteType": "UserConnection",
		"kind": "LinkedField",
		"name": "participants",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "User",
			"kind": "LinkedField",
			"name": "nodes",
			"plural": true,
			"selections": [
				v2,
				v5,
				v6,
				v7,
				v8
			],
			"storageKey": null
		}],
		"storageKey": "participants(first:10)"
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "replaceActorsForAssignableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReplaceActorsForAssignablePayload",
				"kind": "LinkedField",
				"name": "replaceActorsForAssignable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "assignable",
					"plural": false,
					"selections": [{
						"kind": "InlineFragment",
						"selections": [
							v2,
							{
								"alias": null,
								"args": v3,
								"concreteType": "AssigneeConnection",
								"kind": "LinkedField",
								"name": "assignedActors",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "nodes",
									"plural": true,
									"selections": [{
										"kind": "InlineFragment",
										"selections": [
											v4,
											v2,
											v5,
											v6,
											v7,
											v8,
											v12
										],
										"type": "Actor",
										"abstractKey": "__isActor"
									}],
									"storageKey": null
								}],
								"storageKey": "assignedActors(first:20)"
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "AgentAssignment",
								"kind": "LinkedField",
								"name": "agentAssignments",
								"plural": true,
								"selections": [v13, {
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "assigner",
									"plural": false,
									"selections": [
										v4,
										v14,
										v5
									],
									"storageKey": null
								}],
								"storageKey": null
							},
							v15
						],
						"type": "Issue",
						"abstractKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "replaceActorsForAssignableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReplaceActorsForAssignablePayload",
				"kind": "LinkedField",
				"name": "replaceActorsForAssignable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "assignable",
					"plural": false,
					"selections": [
						v4,
						{
							"kind": "InlineFragment",
							"selections": [
								v2,
								{
									"alias": null,
									"args": v3,
									"concreteType": "AssigneeConnection",
									"kind": "LinkedField",
									"name": "assignedActors",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											v4,
											{
												"kind": "InlineFragment",
												"selections": [
													v2,
													v5,
													v6,
													v7,
													v8,
													v12
												],
												"type": "Actor",
												"abstractKey": "__isActor"
											},
											v14
										],
										"storageKey": null
									}],
									"storageKey": "assignedActors(first:20)"
								},
								{
									"alias": null,
									"args": null,
									"concreteType": "AgentAssignment",
									"kind": "LinkedField",
									"name": "agentAssignments",
									"plural": true,
									"selections": [v13, {
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "assigner",
										"plural": false,
										"selections": [
											v4,
											{
												"kind": "TypeDiscriminator",
												"abstractKey": "__isActor"
											},
											v5,
											v2,
											{
												"kind": "TypeDiscriminator",
												"abstractKey": "__isNode"
											}
										],
										"storageKey": null
									}],
									"storageKey": null
								},
								v15
							],
							"type": "Issue",
							"abstractKey": null
						},
						v14
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "5b6e41ee455f3851175cbb618af2aa29",
			"metadata": {},
			"name": "replaceActorsForAssignableRelayMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$52.hash = "70f5798a1f26796ff91037faab127ae2";
function buildOptimisticResponse$1(issueId, assignedActors, newParticipants, existingAgentAssignments) {
	return { replaceActorsForAssignable: { assignable: {
		__typename: "Issue",
		__isNode: "Issue",
		id: issueId,
		assignedActors: { nodes: assignedActors.map((a) => {
			if (a.__typename === "Bot") return {
				__typename: "Bot",
				__isActor: "Bot",
				__isNode: "Bot",
				id: a.id,
				login: a.login,
				name: a.name ?? null,
				avatarUrl: a.avatarUrl,
				profileResourcePath: a.profileResourcePath ?? null,
				displayName: a.displayName ?? "",
				isCopilot: a.isCopilot || false,
				isAgent: a.isAgent || false
			};
			else return {
				__typename: "User",
				__isActor: "User",
				__isNode: "User",
				id: a.id,
				login: a.login,
				name: a.name ?? null,
				avatarUrl: a.avatarUrl,
				profileResourcePath: a.profileResourcePath ?? null
			};
		}) },
		agentAssignments: (existingAgentAssignments ?? []).map((a) => ({
			assignee: a.assignee ? {
				id: a.assignee.id,
				login: a.assignee.login,
				avatarUrl: a.assignee.avatarUrl,
				isCopilot: a.assignee.isCopilot,
				isAgent: a.assignee.isAgent,
				displayName: a.assignee.displayName
			} : null,
			assigner: a.assigner && a.assigner.id ? {
				__typename: a.assigner.__typename,
				__isActor: a.assigner.__typename,
				__isNode: a.assigner.__typename,
				id: a.assigner.id,
				login: a.assigner.login
			} : null
		})),
		participants: { nodes: newParticipants.map((a) => ({
			id: a.id,
			login: a.login,
			name: a.name ?? null,
			avatarUrl: a.avatarUrl,
			profileResourcePath: a.profileResourcePath ?? null
		})) }
	} } };
}
function commitUpdateIssueAssigneesMutation({ environment, input: { issueId, assignedActors, participants }, existingAgentAssignments, clientMutationId, onError, onCompleted }) {
	const newParticipants = [...new Map([...assignedActors, ...participants].filter((a) => !a.isCopilot && !a.isAgent).map((item) => [item.login, item])).values()].slice(0, 5);
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$52,
		variables: { input: {
			assignableId: issueId,
			actorIds: assignedActors.map((a) => a.id),
			clientMutationId
		} },
		optimisticResponse: buildOptimisticResponse$1(issueId, assignedActors, newParticipants, existingAgentAssignments),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var LABELS = {
	archivedDescription: "Archived in project:",
	archivedError: "Issue could not be restored in project",
	archivedSuccess: "Issue restored in project",
	emptySections: {
		labels: "No labels",
		assignees: (viewerCanAssign) => viewerCanAssign ? "No one - " : "No one assigned",
		selfAssign: "Assign yourself",
		milestones: "No milestone",
		projects: "No projects",
		status: "No status",
		types: "No type",
		relationships: "None yet",
		noValue: (fieldName) => `No ${fieldName.toLowerCase()}`,
		iterationPlaceholder: "Choose an iteration",
		datePlaceholder: "Choose a date",
		numberPlaceholder: "Enter number…",
		iterationFilterPlaceholder: "Choose an option",
		singleSelectFilterPlaceholder: "Choose an option"
	},
	sectionTitles: {
		assignees: "Assignees",
		labels: "Labels",
		milestones: "Milestone",
		projects: "Projects",
		types: "Type",
		relationships: "Relationships"
	},
	awaitingTriage: "Awaiting triage",
	defaultProjectFieldName: "Status",
	moveCardToColumn: "Move card to column",
	selectProjects: "Select projects",
	filterProjects: "Filter projects",
	showMoreProjects: (count, closedCount) => count === closedCount ? `Show ${closedCount} closed ${closedCount === 1 ? "project" : "projects"}` : closedCount > 0 ? `Show ${count} more (${closedCount} closed)` : `Show ${count} more`,
	showLessProjects: "Show less",
	showMoreProjectFields: "Show more project fields",
	hideMoreProjectFields: "Hide project fields",
	relationNames: {
		parentIssue: "Parent issue",
		blockedByIssues: "Blocked by",
		blockingIssues: "Is blocking"
	},
	textEditorUpdateButton: "Update"
};
var TEST_IDS$1 = {
	assignees: "issue-assignees",
	issueLabels: "issue-labels",
	milestoneContainer: "issue-milestone-container",
	milestoneProgressIcon: "issue-milestone-progress-bar",
	typeContainer: "issue-type-container"
};
var SectionHeader_module_default = {
	editButton: "SectionHeader-module_JG7brq_editButton",
	screenReaderText: "SectionHeader-module_JG7brq_screenReaderText",
	SectionHeaderTitle: "SectionHeader-module_JG7brq_SectionHeaderTitle"
};
var SectionHeader = ({ ref, id, title, buttonProps, headingProps: { as: Component = "h3", ...headingProps } = {}, readonly, errorPresent, ...props }) => {
	const content = /* @__PURE__ */ jsxs(Box, {
		sx: readonly ? {
			display: "flex",
			flexDirection: "row",
			justifyContent: "space-between",
			alignItems: "center",
			width: "100%",
			pb: "8px",
			...props.sx
		} : {
			width: "100%",
			position: "relative",
			display: "flex",
			alignItems: "center",
			...props.sx
		},
		children: [/* @__PURE__ */ jsx(Heading, {
			id,
			as: Component,
			sx: {
				position: readonly ? "relative" : "absolute",
				...headingProps
			},
			className: SectionHeader_module_default.SectionHeaderTitle,
			children: title
		}), !readonly && /* @__PURE__ */ jsxs(ButtonComponent, {
			ref,
			...buttonProps,
			variant: "invisible",
			size: "small",
			trailingAction: () => errorPresent ? /* @__PURE__ */ jsx(AlertIcon, { className: "fgColor-danger" }) : /* @__PURE__ */ jsx(GearIcon, {}),
			block: true,
			className: SectionHeader_module_default.editButton,
			"aria-describedby": errorPresent ? `error-message-${id}` : void 0,
			children: [/* @__PURE__ */ jsx("span", {
				className: clsx("sr-only", SectionHeader_module_default.screenReaderText),
				children: LABELS$1.editFieldValueLabel(title)
			}), errorPresent && /* @__PURE__ */ jsx("span", {
				id: `error-message-${id}`,
				className: "sr-only",
				children: LABELS$1.errorUpdatingIssueField
			})]
		})]
	});
	return errorPresent && !readonly ? /* @__PURE__ */ jsx(Tooltip$1, {
		text: LABELS$1.errorUpdatingIssueField,
		children: content
	}) : content;
};
SectionHeader.displayName = "SectionHeader";
SectionHeader.displayName = "SectionHeader";
function ReadonlySectionHeader({ title, headingProps: { ...headingProps } = {}, ...props }) {
	return /* @__PURE__ */ jsx(SectionHeader, {
		title,
		headingProps,
		...props,
		readonly: true
	});
}
ReadonlySectionHeader.displayName = "ReadonlySectionHeader";
var Section_module_default = {
	childrenContainer: "Section-module_OyRRka_childrenContainer",
	emptyText: "Section-module_OyRRka_emptyText",
	headerContentWrapper: "Section-module_OyRRka_headerContentWrapper",
	hiddenChildrenContainer: "Section-module_OyRRka_hiddenChildrenContainer",
	SectionContainer: "Section-module_OyRRka_SectionContainer"
};
function Section({ children, emptyText, sectionHeader, sectionFooter, hideDivider, id, sx, className }) {
	return /* @__PURE__ */ jsxs(Box, {
		"data-testid": id ?? "sidebar-section",
		sx: {
			marginBottom: hideDivider ? 0 : 2,
			":after": hideDivider ? void 0 : {
				content: "\"\"",
				position: "absolute",
				height: "1px",
				bottom: "-8px",
				left: "8px",
				right: "8px",
				bg: "border.muted"
			},
			...sx
		},
		className: clsx(Section_module_default.SectionContainer, className),
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: Section_module_default.headerContentWrapper,
				children: [sectionHeader, emptyText && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
					className: Section_module_default.emptyText,
					children: emptyText
				}), /* @__PURE__ */ jsx("div", {
					className: Section_module_default.hiddenChildrenContainer,
					children
				})] })]
			}),
			!emptyText && /* @__PURE__ */ jsx("div", {
				className: Section_module_default.childrenContainer,
				children
			}),
			sectionFooter
		]
	});
}
Section.displayName = "Section";
var AssigneesSection_module_default = { selfAssignButton: "AssigneesSection-module__7wMKa_selfAssignButton" };
var addAgentAssignmentToIssueLocally = (store, issueId, assignee, assigner) => {
	const issueRecord = store.get(issueId);
	if (!issueRecord) return;
	let agentAssignments = issueRecord.getLinkedRecords("agentAssignments") || [];
	if (agentAssignments.some((record) => {
		const existingAssignee = record?.getLinkedRecord("assignee");
		return existingAssignee && existingAssignee.getValue("id") === assignee.id;
	})) return;
	const assignmentClientId = `client:AgentAssignment:${issueId}:${assignee.id}`;
	const assignmentRecord = store.get(assignmentClientId) ?? store.create(assignmentClientId, "AgentAssignment");
	const assigneeRecord = store.get(assignee.id) ?? createAssigneeRecord(store, assignee);
	assignmentRecord.setLinkedRecord(assigneeRecord, "assignee");
	if (assigner) {
		const assignerRecord = store.get(assigner.id) ?? store.create(assigner.id, assigner.__typename);
		assignerRecord.setValue(assigner.id, "id");
		assignerRecord.setValue(assigner.login, "login");
		assignerRecord.setValue(assigner.__typename, "__typename");
		assignmentRecord.setLinkedRecord(assignerRecord, "assigner");
	} else assignmentRecord.setValue(null, "assigner");
	agentAssignments = [...agentAssignments, assignmentRecord];
	issueRecord.setLinkedRecords(agentAssignments, "agentAssignments");
};
var addAssigneesToIssueLocally = (store, issueId, assignees) => {
	const issueRecord = store.get(issueId);
	if (issueRecord) {
		const assignedActors = issueRecord.getLinkedRecord("assignedActors(first:20)");
		if (assignedActors) {
			let nodes = assignedActors.getLinkedRecords("nodes") || [];
			for (const assignee of assignees) if (!nodes.some((node) => node && node.getValue("id") === assignee.id)) {
				let assigneeRecord = store.get(assignee.id);
				if (!assigneeRecord) assigneeRecord = createAssigneeRecord(store, assignee);
				nodes = [...nodes, assigneeRecord];
			}
			const sortedNodes = nodes.sort((a, b) => {
				const loginA = a?.getValue("login") || "";
				const loginB = b?.getValue("login") || "";
				return loginA.toLowerCase().localeCompare(loginB.toLowerCase());
			});
			assignedActors.setLinkedRecords(sortedNodes, "nodes");
		}
	}
};
var createAssigneeRecord = (store, assignee) => {
	const assigneeRecord = store.create(assignee.id, assignee.__typename);
	const propertiesToSet = {
		id: assignee.id,
		login: assignee.login,
		name: assignee.name,
		avatarUrl: assignee.avatarUrl,
		isCopilot: assignee.isCopilot,
		isAgent: assignee.isAgent,
		profileResourcePath: assignee.profileResourcePath,
		__typename: assignee.__typename,
		displayName: assignee.displayName
	};
	for (const [key, value] of Object.entries(propertiesToSet)) assigneeRecord.setValue(value, key);
	return assigneeRecord;
};
var import_hooks = require_hooks();
var ReadonlyAssigneesSectionHeader = () => /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.assignees });
ReadonlyAssigneesSectionHeader.displayName = "ReadonlyAssigneesSectionHeader";
var assigneesEqual = (a, b) => {
	if (a.length !== b.length) return false;
	const aIds = new Set(a.map((assignee) => assignee.id));
	return b.every((assignee) => aIds.has(assignee.id));
};
var AssigneesSectionLazyFragment = node$57;
var AssigneesSection = (t0) => {
	const $ = c(20);
	const { sectionHeader, onSelfAssignClick, assignees, agentAssignments, issueAgentTasks, agents, readonly, copilotAssignmentButton } = t0;
	let t1;
	if ($[0] !== agentAssignments || $[1] !== agents || $[2] !== assignees || $[3] !== copilotAssignmentButton || $[4] !== issueAgentTasks || $[5] !== onSelfAssignClick || $[6] !== readonly || $[7] !== sectionHeader) {
		const emptyHeader = !readonly ? jsxs(Fragment$1, { children: [LABELS.emptySections.assignees(true), jsx(ButtonComponent, {
			variant: "link",
			onClick: onSelfAssignClick,
			className: AssigneesSection_module_default.selfAssignButton,
			children: LABELS.emptySections.selfAssign
		})] }) : LABELS.emptySections.assignees(false);
		const sectionFooter = copilotAssignmentButton ? jsx("div", {
			className: "width-full d-flex flex-column flex-items-stretch pt-2 px-2",
			children: jsx("div", { children: copilotAssignmentButton })
		}) : void 0;
		let t2;
		if ($[9] !== agents || $[10] !== issueAgentTasks) {
			bb0: {
				const map = /* @__PURE__ */ new Map();
				if (!issueAgentTasks?.length || !agents?.length) {
					t2 = map;
					break bb0;
				}
				for (const agent of agents) {
					const agentTasks = issueAgentTasks.filter((task) => task.agent_collaborators?.some((c) => c.agent_id === agent.id));
					if (!agentTasks.length) continue;
					const mostRecent = agentTasks.reduce(_temp$14);
					const mostRecentState = mostRecent.state ?? mostRecent.status;
					if (agent.bot_global_relay_id && isSessionState(mostRecentState)) map.set(agent.bot_global_relay_id, {
						statusIcon: getSessionStatusIcon(mostRecentState),
						count: agentTasks.length,
						taskUrl: mostRecent.url
					});
				}
				t2 = map;
			}
			$[9] = agents;
			$[10] = issueAgentTasks;
			$[11] = t2;
		} else t2 = $[11];
		const agentTaskMap = t2;
		let t3;
		if ($[12] !== agentAssignments || $[13] !== agentTaskMap || $[14] !== assignees) {
			bb1: {
				const baseAssignees = assignees.map(_temp2$10);
				if (!(isFeatureEnabled("issue_cca_visualization") || isFeatureEnabled("copilot_mission_control_decoupled_mode") && isFeatureEnabled("issue_cca_visualization_decoupled_mode")) || !agentAssignments?.length) {
					t3 = baseAssignees;
					break bb1;
				}
				let t4;
				if ($[16] !== assignees) {
					t4 = new Set(assignees.map(_temp3$9));
					$[16] = assignees;
					$[17] = t4;
				} else t4 = $[17];
				const assignedLogins = t4;
				let t5;
				if ($[18] !== assignedLogins) {
					t5 = (a_0) => a_0?.assignee?.login && a_0?.assigner?.login && assignedLogins.has(a_0.assignee.login) && assignedLogins.has(a_0.assigner.login);
					$[18] = assignedLogins;
					$[19] = t5;
				} else t5 = $[19];
				const validAssignments = agentAssignments.filter(t5);
				if (!validAssignments.length) {
					t3 = baseAssignees;
					break bb1;
				}
				const agentIds = new Set(validAssignments.map(_temp4$6));
				t3 = baseAssignees.filter((a_2) => !agentIds.has(a_2.id)).map((assignee_0) => ({
					...assignee_0,
					assignedAgents: validAssignments.filter((a_3) => a_3?.assigner?.login === assignee_0.login).map((a_4) => ({
						id: a_4?.assignee?.id ?? "",
						login: a_4?.assignee?.login ?? "",
						avatarUrl: a_4?.assignee?.avatarUrl ?? "",
						name: a_4?.assignee?.displayName ?? a_4?.assignee?.login ?? null,
						displayName: a_4?.assignee?.displayName ?? a_4?.assignee?.login ?? "",
						profileResourcePath: `/apps/${a_4?.assignee?.login}`,
						isCopilot: a_4?.assignee?.isCopilot ?? false,
						isAgent: a_4?.assignee?.isAgent ?? true,
						agentTaskInfo: agentTaskMap.get(a_4?.assignee?.id ?? "") ?? void 0
					}))
				}));
			}
			$[12] = agentAssignments;
			$[13] = agentTaskMap;
			$[14] = assignees;
			$[15] = t3;
		} else t3 = $[15];
		const assigneeList = t3;
		t1 = jsx(Section, {
			id: "sidebar-assignees-section",
			sectionHeader,
			sectionFooter,
			emptyText: assignees.length > 0 ? void 0 : emptyHeader,
			children: jsx(Assignees, {
				assignees: assigneeList,
				testId: TEST_IDS$1.assignees
			})
		});
		$[0] = agentAssignments;
		$[1] = agents;
		$[2] = assignees;
		$[3] = copilotAssignmentButton;
		$[4] = issueAgentTasks;
		$[5] = onSelfAssignClick;
		$[6] = readonly;
		$[7] = sectionHeader;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
};
AssigneesSection.displayName = "AssigneesSection";
function CreateIssueAssigneesSection$1(t0) {
	const $ = c(3);
	const { repo, owner, readonly, assignees, onSelectionChange, className, sx, repository, issueNumber, onIssueUpdate, ...sharedConfigProps } = t0;
	const viewer = useViewer();
	const pickerProps = {
		repo,
		owner,
		readonly,
		includeAuthorableBots: false,
		includeAssignableBots: true,
		assigneeTokens: [],
		assignees,
		onSelectionChange,
		anchorElement: _temp5$3,
		...sharedConfigProps
	};
	const sectionHeader = readonly ? jsx(ReadonlyAssigneesSectionHeader, {}) : jsx(AssigneeRepositoryPicker, { ...pickerProps });
	let t1;
	if ($[0] !== onSelectionChange || $[1] !== viewer) {
		t1 = () => onSelectionChange(viewer ? [viewer] : []);
		$[0] = onSelectionChange;
		$[1] = viewer;
		$[2] = t1;
	} else t1 = $[2];
	return jsx(AssigneesSection, {
		sectionHeader,
		onSelfAssignClick: t1,
		assignees,
		readonly,
		sx,
		className
	});
}
CreateIssueAssigneesSection$1.displayName = "CreateIssueAssigneesSection";
function _temp5$3(anchorProps, ref) {
	return jsx(SectionHeader, {
		title: LABELS.sectionTitles.assignees,
		buttonProps: {
			...anchorProps,
			id: "assignees-select-menu"
		},
		ref
	});
}
var assigneesSectionAssignees = node$56;
var assigneesSectionCopilotRepositoryFragment = node$55;
var assigneesSectionFragment = node$54;
function EditIssueAssigneesSection({ issue, viewer, lazyKey, onIssueUpdate, insideSidePanel, readonly }) {
	const { sendAnalyticsEvent } = useAnalytics();
	const data = (0, import_hooks.useFragment)(assigneesSectionFragment, issue);
	const { repository, repository: { owner: { login: owner }, name: repo, isArchived: isRepositoryArchived }, number } = data;
	const copilotRepositoryData = (0, import_hooks.useFragment)(assigneesSectionCopilotRepositoryFragment, data.repository);
	const assigneesData = (0, import_hooks.useFragment)(assigneesSectionAssignees, data);
	const viewerData = (0, import_hooks.useFragment)(node$53, viewer);
	const { id: issueId, viewerCanAssign } = data;
	const lazyData = (0, import_hooks.useFragment)(AssigneesSectionLazyFragment, lazyKey);
	const suggestions = useMemo(() => {
		return (lazyData?.suggestedActors?.nodes || []).flatMap((actor) => actor ? [actor] : []);
	}, [lazyData?.suggestedActors?.nodes]);
	const assignees = useMemo(() => {
		return (assigneesData.assignedActors?.nodes || []).flatMap((actor_0) => actor_0 ? [actor_0] : []);
	}, [assigneesData.assignedActors?.nodes]);
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const copilotButtonRef = useRef(null);
	const { data: issueAgentTasksData } = useIssueAgentTasks({
		owner,
		repo,
		issueNumber: number
	});
	const readonlyAssignee = readonly || !viewerCanAssign || isRepositoryArchived;
	const canUseCopilotAssignment = useMemo(() => {
		const isCopilotCurrentlyAssigned = assignees.some((assignee) => isCopilot(assignee.login));
		return !readonlyAssignee && copilotRepositoryData.isCopilotAgentEnabled && !isCopilotCurrentlyAssigned;
	}, [
		assignees,
		readonlyAssignee,
		copilotRepositoryData.isCopilotAgentEnabled
	]);
	const canUseAgentAssignment = !readonlyAssignee && copilotRepositoryData.isCopilotAgentEnabled;
	const [copilotModalOpen, setCopilotModalOpen] = useState(false);
	const [pickerInstanceKey, setPickerInstanceKey] = useState(0);
	const [selectedAgentForModal, setSelectedAgentForModal] = useState(void 0);
	const handleOpenCopilotModal = useCallback(() => {
		setCopilotModalOpen(true);
		setPickerInstanceKey((prev) => prev + 1);
	}, [setCopilotModalOpen]);
	const handleCloseCopilotModal = useCallback(() => {
		setCopilotModalOpen(false);
		setSelectedAgentForModal(void 0);
	}, [setCopilotModalOpen]);
	const updateAssignees = useCallback((selectedAssignees, newAgentAssignments) => {
		const existingAgentAssignments = isFeatureEnabled("issue_cca_visualization") || isFeatureEnabled("copilot_mission_control_decoupled_mode") && isFeatureEnabled("issue_cca_visualization_decoupled_mode") ? assigneesData.agentAssignments : void 0;
		commitUpdateIssueAssigneesMutation({
			environment,
			input: {
				issueId,
				assignedActors: selectedAssignees,
				participants: suggestions
			},
			existingAgentAssignments: newAgentAssignments?.length ? [...existingAgentAssignments ?? [], ...newAgentAssignments] : existingAgentAssignments,
			onError: () => addToast({
				type: "error",
				message: ERRORS$2.couldNotUpdateAssignees
			}),
			onCompleted: onIssueUpdate
		});
	}, [
		addToast,
		environment,
		issueId,
		onIssueUpdate,
		suggestions,
		assigneesData.agentAssignments
	]);
	const updateAssigneesWithCopilotDetection = useCallback((selectedAssignees_0) => {
		const wasCopilotPreviouslyAssigned = assignees.some((assignee_0) => isCopilot(assignee_0.login));
		const hasCopilotAssignee = selectedAssignees_0.some((assignee_1) => assignee_1.isCopilot);
		const nonCopilotAssignees = selectedAssignees_0.filter((assignee_2) => !assignee_2.isCopilot);
		let assigneesToSave = canUseCopilotAssignment ? nonCopilotAssignees : selectedAssignees_0;
		let newAgentAssignments_0;
		if (viewerData) {
			const previousAgentLogins = new Set(assignees.filter((a) => a.isAgent && !isCopilot(a.login)).map((a_0) => a_0.login));
			const thirdPartyAgentsAdded = selectedAssignees_0.filter((assignee_3) => assignee_3.isAgent && !isCopilot(assignee_3.login) && !previousAgentLogins.has(assignee_3.login));
			if (thirdPartyAgentsAdded.length > 0) {
				const isViewerAlreadyAssigned = assignees.some((assignee_4) => assignee_4.login === viewerData.login);
				const isViewerInSelection = selectedAssignees_0.some((assignee_5) => assignee_5.login === viewerData.login);
				if (!isViewerAlreadyAssigned && !isViewerInSelection && selectedAssignees_0.length < 10) assigneesToSave = [...assigneesToSave, viewerData];
				newAgentAssignments_0 = thirdPartyAgentsAdded.map((agent) => ({
					assignee: {
						id: agent.id,
						login: agent.login,
						avatarUrl: agent.avatarUrl,
						isCopilot: agent.isCopilot ?? false,
						isAgent: agent.isAgent ?? true,
						displayName: agent.displayName ?? agent.login
					},
					assigner: {
						__typename: viewerData.__typename,
						id: viewerData.id,
						login: viewerData.login
					}
				}));
			}
		}
		if (canUseCopilotAssignment) {
			const currentNonCopilotAssignees = assignees.filter((assignee_6) => !isCopilot(assignee_6.login));
			if (!assigneesEqual(assigneesToSave, currentNonCopilotAssignees)) updateAssignees(assigneesToSave, newAgentAssignments_0);
		} else updateAssignees(assigneesToSave, newAgentAssignments_0);
		if (hasCopilotAssignee && canUseCopilotAssignment && !wasCopilotPreviouslyAssigned) handleOpenCopilotModal();
	}, [
		assignees,
		canUseCopilotAssignment,
		updateAssignees,
		handleOpenCopilotModal,
		viewerData
	]);
	const updateAssigneesWithAgentDetection = useCallback((selectedAssignees_1) => {
		if (!canUseAgentAssignment) {
			updateAssignees(selectedAssignees_1);
			return;
		}
		const previousAgentLogins_0 = new Set(assignees.filter((a_1) => a_1.isAgent || a_1.isCopilot).map((a_2) => a_2.login));
		const newlyAddedAgents = selectedAssignees_1.filter((assignee_7) => (assignee_7.isAgent || assignee_7.isCopilot) && !previousAgentLogins_0.has(assignee_7.login));
		if (newlyAddedAgents.length > 0) {
			const assigneesToSave_0 = selectedAssignees_1.filter((assignee_8) => !newlyAddedAgents.some((a_3) => a_3.login === assignee_8.login));
			if (!assigneesEqual(assigneesToSave_0, assignees)) updateAssignees(assigneesToSave_0);
			const agent_0 = newlyAddedAgents[0];
			setSelectedAgentForModal({
				typeName: "topLevel",
				displayName: agent_0.displayName ?? agent_0.login,
				avatarUrl: agent_0.avatarUrl,
				login: agent_0.login,
				botGlobalRelayId: agent_0.id
			});
			handleOpenCopilotModal();
		} else if (!assigneesEqual(selectedAssignees_1, assignees)) updateAssignees(selectedAssignees_1);
	}, [
		assignees,
		canUseAgentAssignment,
		updateAssignees,
		handleOpenCopilotModal
	]);
	const handleAssigneeSelectionChange = useCallback((selectedAssignees_2) => {
		if (isFeatureEnabled("issue_cca_modal_open")) updateAssigneesWithAgentDetection(selectedAssignees_2);
		else updateAssigneesWithCopilotDetection(selectedAssignees_2);
	}, [updateAssigneesWithAgentDetection, updateAssigneesWithCopilotDetection]);
	const onAssignmentComplete = useCallback((agent_1) => {
		if (agent_1) (0, import_hooks.commitLocalUpdate)(environment, (store) => {
			const assigneesToAdd = [{
				...agent_1,
				isCopilot: isCopilot(agent_1.login),
				isAgent: true,
				__typename: "Bot"
			}];
			const shouldAddViewer_0 = !assignees.some((assignee_9) => assignee_9.login === viewerData?.login) && assignees.length + 1 < 10;
			if (viewerData && shouldAddViewer_0) assigneesToAdd.push(viewerData);
			addAssigneesToIssueLocally(store, issueId, assigneesToAdd);
			if (viewerData) addAgentAssignmentToIssueLocally(store, issueId, agent_1, viewerData);
		});
		onIssueUpdate?.();
	}, [
		assignees,
		environment,
		issueId,
		onIssueUpdate,
		viewerData
	]);
	const copilotAssignmentButton = canUseCopilotAssignment ? /* @__PURE__ */ jsx(CopilotAssignmentButton, {
		onClick: handleOpenCopilotModal,
		ref: copilotButtonRef
	}) : void 0;
	const isAgentCurrentlyAssigned = assignees.some((assignee_10) => assignee_10.isAgent || assignee_10.isCopilot);
	const agentAssignmentButton = canUseAgentAssignment && !isAgentCurrentlyAssigned ? /* @__PURE__ */ jsx(CopilotAssignmentButton, {
		onClick: handleOpenCopilotModal,
		ref: copilotButtonRef
	}) : void 0;
	const copilotAssignmentModal = (isFeatureEnabled("issue_cca_modal_open") ? canUseAgentAssignment : canUseCopilotAssignment) && copilotModalOpen ? /* @__PURE__ */ jsx(CopilotAssignmentModal, {
		isOpen: copilotModalOpen,
		onClose: handleCloseCopilotModal,
		repository: {
			name: repository.name,
			owner: { login: repository.owner.login }
		},
		issueNumbers: [number],
		onAssignmentComplete,
		returnFocusRef: copilotButtonRef,
		initialAgent: selectedAgentForModal
	}) : void 0;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(AssigneesSection, {
		sectionHeader: useMemo(() => {
			if (readonlyAssignee) return /* @__PURE__ */ jsx(ReadonlyAssigneesSectionHeader, {});
			return /* @__PURE__ */ jsx(AssigneePicker, {
				repo,
				owner,
				number,
				anchorElement: (props, ref) => /* @__PURE__ */ jsx(SectionHeader, {
					title: LABELS.sectionTitles.assignees,
					buttonProps: {
						...props,
						onClick: (e) => {
							sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_ASSIGNEE_SECTION_EDIT_CLICK");
							props.onClick?.(e);
						}
					},
					ref
				}),
				readonly: readonlyAssignee,
				assignees,
				onSelectionChange: (selectedAssignees_3) => handleAssigneeSelectionChange(selectedAssignees_3),
				insidePortal: insideSidePanel,
				suggestions
			}, `assignee-picker-${pickerInstanceKey}`);
		}, [
			readonlyAssignee,
			repo,
			owner,
			number,
			assignees,
			insideSidePanel,
			suggestions,
			pickerInstanceKey,
			sendAnalyticsEvent,
			handleAssigneeSelectionChange
		]),
		assignees,
		agentAssignments: assigneesData.agentAssignments,
		issueAgentTasks: issueAgentTasksData?.tasks,
		agents: issueAgentTasksData?.assigned_agents,
		onSelfAssignClick: () => viewerData ? updateAssignees([viewerData]) : noop$1,
		readonly: readonlyAssignee,
		copilotAssignmentButton: isFeatureEnabled("issue_cca_modal_open") ? agentAssignmentButton : copilotAssignmentButton
	}), copilotAssignmentModal] });
}
EditIssueAssigneesSection.displayName = "EditIssueAssigneesSection";
function _temp$14(latest, task_0) {
	return new Date(task_0.updated_at ?? task_0.last_updated_at ?? "").getTime() > new Date(latest.updated_at ?? latest.last_updated_at ?? "").getTime() ? task_0 : latest;
}
function _temp2$10(assignee) {
	return {
		...assignee,
		displayName: assignee.displayName || assignee.login,
		isCopilot: assignee.isCopilot ?? false,
		isAgent: assignee.isAgent ?? false
	};
}
function _temp3$9(a) {
	return a.login;
}
function _temp4$6(a_1) {
	return a_1?.assignee?.id;
}
var node$51 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v2 = [
		v0,
		v1,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	], v3 = [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "__typename",
			"storageKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": v2,
			"type": "IssueFieldText",
			"abstractKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": v2,
			"type": "IssueFieldSingleSelect",
			"abstractKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": v2,
			"type": "IssueFieldDate",
			"abstractKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": v2,
			"type": "IssueFieldNumber",
			"abstractKey": null
		}
	];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "FieldsSectionFragment",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isPrivate",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "databaseId",
							"storageKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": [
								{
									"alias": "issueFieldsEnabled",
									"args": [{
										"kind": "Literal",
										"name": "name",
										"value": "issue_fields"
									}],
									"kind": "ScalarField",
									"name": "isFeatureEnabled",
									"storageKey": "isFeatureEnabled(name:\"issue_fields\")"
								},
								{
									"alias": "issueFieldsVisibilitySettingsEnabled",
									"args": [{
										"kind": "Literal",
										"name": "name",
										"value": "issue_fields_visibility_settings"
									}],
									"kind": "ScalarField",
									"name": "isFeatureEnabled",
									"storageKey": "isFeatureEnabled(name:\"issue_fields_visibility_settings\")"
								},
								{
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 100
									}],
									"concreteType": "IssueFieldsConnection",
									"kind": "LinkedField",
									"name": "pinnedIssueFields",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": v3,
										"storageKey": null
									}],
									"storageKey": "pinnedIssueFields(first:100)"
								}
							],
							"type": "Organization",
							"abstractKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanSetFields",
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "FieldsSectionFieldValues"
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "IssueType",
				"kind": "LinkedField",
				"name": "issueType",
				"plural": false,
				"selections": [
					v0,
					v1,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "pinnedFields",
						"plural": true,
						"selections": v3,
						"storageKey": null
					}
				],
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$51.hash = "34188f1fed5f8db468617a7386738b5e";
var node$50 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v2 = [
		v0,
		v1,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "value",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "FieldsSectionFieldValues",
		"selections": [
			v0,
			{
				"alias": null,
				"args": [{
					"kind": "Literal",
					"name": "first",
					"value": 25
				}],
				"concreteType": "IssueFieldValueConnection",
				"kind": "LinkedField",
				"name": "issueFieldValues",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "nodes",
					"plural": true,
					"selections": [
						{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "field",
								"plural": false,
								"selections": [{
									"kind": "InlineFragment",
									"selections": v2,
									"type": "IssueFieldText",
									"abstractKey": null
								}],
								"storageKey": null
							}, v3],
							"type": "IssueFieldTextValue",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": [
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "field",
									"plural": false,
									"selections": [{
										"kind": "InlineFragment",
										"selections": v2,
										"type": "IssueFieldSingleSelect",
										"abstractKey": null
									}],
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "optionId",
									"storageKey": null
								},
								v1,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "color",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "description",
									"storageKey": null
								}
							],
							"type": "IssueFieldSingleSelectValue",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "field",
								"plural": false,
								"selections": [{
									"kind": "InlineFragment",
									"selections": v2,
									"type": "IssueFieldDate",
									"abstractKey": null
								}],
								"storageKey": null
							}, v3],
							"type": "IssueFieldDateValue",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "field",
								"plural": false,
								"selections": [{
									"kind": "InlineFragment",
									"selections": v2,
									"type": "IssueFieldNumber",
									"abstractKey": null
								}],
								"storageKey": null
							}, {
								"alias": "numberValue",
								"args": null,
								"kind": "ScalarField",
								"name": "value",
								"storageKey": null
							}],
							"type": "IssueFieldNumberValue",
							"abstractKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": "issueFieldValues(first:25)"
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanSetFields",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "IssueType",
				"kind": "LinkedField",
				"name": "issueType",
				"plural": false,
				"selections": [v0, v1],
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$50.hash = "8b4ff24ca874524863bc07d02383f919";
var EVENT_NAMESPACE = "issue_fields_usage";
var VERSION = "1.0.1";
function reportIssueFieldsUsage(event) {
	const formattedEvent = {};
	for (const [key, value] of Object.entries(event)) if (value !== void 0) {
		const snakeCaseKey = key.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
		if (Array.isArray(value)) formattedEvent[snakeCaseKey] = value.join(",");
		else formattedEvent[snakeCaseKey] = value;
	}
	sendEvent(EVENT_NAMESPACE, {
		...formattedEvent,
		version: VERSION
	});
}
function useIssueFieldsAnalytics() {
	const $ = c(3);
	const interactionStartRef = useRef(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			interactionStartRef.current = Date.now();
		};
		$[0] = t0;
	} else t0 = $[0];
	const markInteractionStart = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (event) => {
			const interactionDuration = interactionStartRef.current !== null ? Date.now() - interactionStartRef.current : void 0;
			interactionStartRef.current = null;
			reportIssueFieldsUsage({
				...event,
				interactionDuration
			});
		};
		$[1] = t1;
	} else t1 = $[1];
	const reportUsage = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = {
			markInteractionStart,
			reportUsage
		};
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
var AddIssueFieldButton_module_default = {
	button: "AddIssueFieldButton-module_FXjQ3q_button",
	container: "AddIssueFieldButton-module_FXjQ3q_container"
};
var AddIssueFieldButton = ({ ref, ...props }) => {
	const { anchorProps, inactive = false, disabled = false, onClick } = props;
	return /* @__PURE__ */ jsx("div", {
		className: AddIssueFieldButton_module_default.container,
		children: /* @__PURE__ */ jsx(ButtonComponent, {
			leadingVisual: inactive ? AlertIcon : void 0,
			trailingVisual: !inactive ? PlusIcon : void 0,
			size: "small",
			ref,
			...anchorProps,
			className: AddIssueFieldButton_module_default.button,
			inactive: inactive || disabled,
			onClick: (event) => {
				if (disabled) return;
				onClick();
				anchorProps?.onClick?.(event);
			},
			children: "Add field"
		})
	});
};
AddIssueFieldButton.displayName = "AddIssueFieldButton";
AddIssueFieldButton.displayName = "AddIssueFieldButton";
function FieldsSelector({ owner, fieldsSet, onIssueFieldSelected, markInteractionStart, inactive = false, disabled = false, onButtonElementReceived, hideAddFieldButton = false }) {
	const anchorElement = useMemo(() => {
		return (anchorProps, ref) => {
			if (ref?.current) onButtonElementReceived?.(ref.current);
			return /* @__PURE__ */ jsx(AddIssueFieldButton, {
				anchorProps,
				ref,
				onClick: markInteractionStart,
				inactive,
				disabled
			});
		};
	}, [
		markInteractionStart,
		inactive,
		disabled,
		onButtonElementReceived
	]);
	const selectIssueField = useCallback((selectedFields) => {
		const field = selectedFields[0];
		if (!field) return;
		onIssueFieldSelected(asIssueFieldSelection(field));
	}, [onIssueFieldSelected]);
	if (hideAddFieldButton) return null;
	return /* @__PURE__ */ jsx(IssueFieldPicker, {
		owner,
		fieldsSet,
		onSelectionChange: selectIssueField,
		anchorElement,
		insidePortal: false
	});
}
FieldsSelector.displayName = "FieldsSelector";
var FieldsSection_module_default = {
	animationClass: "FieldsSection-module_mIjtsa_animationClass",
	animationFirst: "FieldsSection-module_mIjtsa_animationFirst",
	animationLast: "FieldsSection-module_mIjtsa_animationLast",
	animationMiddle: "FieldsSection-module_mIjtsa_animationMiddle",
	animationOnly: "FieldsSection-module_mIjtsa_animationOnly",
	compactSectionEmptyText: "FieldsSection-module_mIjtsa_compactSectionEmptyText",
	compactSectionHeader: "FieldsSection-module_mIjtsa_compactSectionHeader",
	giveFeedbackLink: "FieldsSection-module_mIjtsa_giveFeedbackLink",
	loadingRow: "FieldsSection-module_mIjtsa_loadingRow",
	pinnedField: "FieldsSection-module_mIjtsa_pinnedField",
	sectionHeaderWrapper: "FieldsSection-module_mIjtsa_sectionHeaderWrapper"
};
function usePendingFieldFocus(pendingField) {
	const $ = c(5);
	const addFieldButtonRef = useRef(null);
	const previousPendingField = useRef(pendingField);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (element) => {
			addFieldButtonRef.current = element;
		};
		$[0] = t0;
	} else t0 = $[0];
	const setAddFieldButtonElement = t0;
	let t1;
	let t2;
	if ($[1] !== pendingField) {
		t1 = () => {
			if (previousPendingField.current !== null && pendingField === null) addFieldButtonRef.current?.focus();
			previousPendingField.current = pendingField;
		};
		t2 = [pendingField];
		$[1] = pendingField;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { setAddFieldButtonElement };
		$[4] = t3;
	} else t3 = $[4];
	return t3;
}
function usePinnedFieldsAnimation(currentValue) {
	const $ = c(5);
	const [animatePinned, setAnimatePinned] = useState(false);
	const previousValue = useRef(null);
	const hasMounted = useRef(false);
	const lastAnimationValue = useRef(null);
	let t0;
	let t1;
	if ($[0] !== currentValue) {
		t0 = () => {
			if (hasMounted.current && currentValue !== lastAnimationValue.current && currentValue !== null) {
				setAnimatePinned(false);
				lastAnimationValue.current = currentValue;
				const startTimer = setTimeout(() => {
					setAnimatePinned(true);
				}, 0);
				const endTimer = setTimeout(() => {
					setAnimatePinned(false);
				}, 2e3);
				return () => {
					clearTimeout(startTimer);
					clearTimeout(endTimer);
				};
			}
			if (!hasMounted.current) lastAnimationValue.current = currentValue;
			previousValue.current = currentValue;
			hasMounted.current = true;
		};
		t1 = [currentValue];
		$[0] = currentValue;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	let t2;
	if ($[3] !== animatePinned) {
		t2 = { animatePinned };
		$[3] = animatePinned;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
var positionClassMap = {
	only: FieldsSection_module_default.animationOnly,
	first: FieldsSection_module_default.animationFirst,
	middle: FieldsSection_module_default.animationMiddle,
	last: FieldsSection_module_default.animationLast
};
function getPinnedFieldClassName(isPinned, animatePinned, position = null) {
	if (isPinned && animatePinned) {
		const positionClass = position ? positionClassMap[position] : "";
		return `${FieldsSection_module_default.pinnedField} ${FieldsSection_module_default.animationClass} ${positionClass}`.trim();
	}
	if (isPinned) return FieldsSection_module_default.pinnedField;
}
/**
* Calculates the position of a pinned field within the list of pinned fields.
* Returns 'only' if there's only one pinned field, 'first'/'middle'/'last' based on position,
* or null if the field is not pinned.
*/
function getPinnedFieldPosition(fieldId, pinnedFieldIds, allFieldIds) {
	if (!pinnedFieldIds.has(fieldId)) return null;
	const orderedPinnedIds = allFieldIds.filter((id) => pinnedFieldIds.has(id));
	const index = orderedPinnedIds.indexOf(fieldId);
	if (orderedPinnedIds.length === 1) return "only";
	if (index === 0) return "first";
	if (index === orderedPinnedIds.length - 1) return "last";
	return "middle";
}
function runFieldMutation({ mutationFn, input, environment, action, fieldId, fieldType, inProjectsPage, ownerId, reportUsage, onError, onCompleted }) {
	const startTime = Date.now();
	mutationFn({
		environment,
		input,
		onCompleted: () => {
			const duration = Date.now() - startTime;
			reportUsage({
				page: inProjectsPage ? "memex#show" : "issue#show",
				action,
				fieldId,
				fieldType,
				status: "success",
				duration,
				orgId: ownerId?.toString()
			});
			onCompleted?.();
		},
		onError: (error) => {
			const duration = Date.now() - startTime;
			reportUsage({
				page: inProjectsPage ? "memex#show" : "issue#show",
				action,
				fieldId,
				fieldType,
				status: "error",
				errorDetails: error instanceof Error ? error.message : String(error),
				duration,
				orgId: ownerId?.toString()
			});
			onError?.(error);
		}
	});
}
/**
* Custom hook that manages pinned fields state for issue types and organization-level pinned fields.
* Handles filtering, mapping, and auto-population of pinned fields.
*/
function usePinnedFieldsState(t0) {
	const $ = c(19);
	const { pinnedFields: pinnedFieldsInput, setFields, setFieldsSet } = t0;
	let t1;
	if ($[0] !== pinnedFieldsInput) {
		t1 = pinnedFieldsInput || [];
		$[0] = pinnedFieldsInput;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t1) {
		t2 = t1.map(_temp$13);
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	const pinnedFields = t2;
	let t3;
	if ($[4] !== pinnedFields) {
		t3 = new Set(pinnedFields.map(_temp2$9));
		$[4] = pinnedFields;
		$[5] = t3;
	} else t3 = $[5];
	const pinnedFieldIds = t3;
	let t4;
	if ($[6] !== pinnedFieldIds || $[7] !== pinnedFields || $[8] !== setFields || $[9] !== setFieldsSet) {
		t4 = () => {
			if (pinnedFields.length > 0) {
				setFields((prevFields) => {
					const fieldsWithValues = pinnedFields.map((pinnedField) => {
						const existingField = prevFields.find((f_0) => f_0.field.id === pinnedField.field.id);
						return existingField && existingField.value ? existingField : pinnedField;
					});
					const userFields = prevFields.filter((f_1) => !pinnedFieldIds.has(f_1.field.id) && f_1.value);
					return [...fieldsWithValues, ...userFields];
				});
				setFieldsSet(pinnedFields.map(_temp3$8));
			} else {
				setFields((prevFields_0) => prevFields_0.filter((f_2) => !pinnedFieldIds.has(f_2.field.id) && f_2.value));
				setFieldsSet((prevFields_1) => prevFields_1.filter((name) => !pinnedFields.map(_temp4$5).includes(name)));
			}
		};
		$[6] = pinnedFieldIds;
		$[7] = pinnedFields;
		$[8] = setFields;
		$[9] = setFieldsSet;
		$[10] = t4;
	} else t4 = $[10];
	let t5;
	if ($[11] !== pinnedFieldIds || $[12] !== pinnedFields || $[13] !== pinnedFieldsInput || $[14] !== setFields || $[15] !== setFieldsSet) {
		t5 = [
			pinnedFieldsInput,
			pinnedFieldIds,
			pinnedFields,
			setFields,
			setFieldsSet
		];
		$[11] = pinnedFieldIds;
		$[12] = pinnedFields;
		$[13] = pinnedFieldsInput;
		$[14] = setFields;
		$[15] = setFieldsSet;
		$[16] = t5;
	} else t5 = $[16];
	useEffect(t4, t5);
	let t6;
	if ($[17] !== pinnedFieldIds) {
		t6 = { pinnedFieldIds };
		$[17] = pinnedFieldIds;
		$[18] = t6;
	} else t6 = $[18];
	return t6;
}
function _temp4$5(f_3) {
	return f_3.field.name;
}
function _temp3$8(field_0) {
	return field_0.field.name;
}
function _temp2$9(f) {
	return f.field.id;
}
function _temp$13(field) {
	return toIssueFieldWithUnsavedValue(asIssueFieldSelection(field), null);
}
var IssueFieldDateEditorButton = ({ anchorProps, fieldName, value, displayValue, formattedDate, isOpen, errorPresent = false, className }) => {
	const content = /* @__PURE__ */ jsxs("button", {
		...anchorProps,
		className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, IssueFieldItem_module_default.issueFieldFormWrapperClickable, isOpen && IssueFieldItem_module_default.isEditing, className),
		"aria-label": value ? `Edit ${fieldName}` : `Set ${fieldName}`,
		children: [
			/* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.issueFieldLabel,
				children: fieldName
			}),
			/* @__PURE__ */ jsx("span", {
				className: clsx(IssueFieldItem_module_default.issueFieldValueText, formattedDate && IssueFieldItem_module_default.hasValue),
				children: displayValue
			}),
			errorPresent && /* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.alertIconWrapper,
				children: /* @__PURE__ */ jsx(AlertIcon, { className: IssueFieldItem_module_default.alertIcon })
			})
		]
	});
	return errorPresent ? /* @__PURE__ */ jsx(Tooltip$1, {
		text: LABELS$1.errorUpdatingIssueField,
		type: "description",
		children: content
	}) : content;
};
IssueFieldDateEditorButton.displayName = "IssueFieldDateEditorButton";
var IssueFieldDateEditor = (t0) => {
	const $ = c(31);
	const { fieldId, fieldName, value, onCommit, shouldOpen: t1, isDraft: t2, readonly, errorPresent: t3, className } = t0;
	const shouldOpen = t1 === void 0 ? false : t1;
	const isDraft = t2 === void 0 ? false : t2;
	const errorPresent = t3 === void 0 ? false : t3;
	const [isOpen, setIsOpen] = useState(shouldOpen);
	let t4;
	bb0: {
		if (!value) {
			t4 = "";
			break bb0;
		}
		let t5;
		if ($[0] !== value) {
			t5 = formatDateString(value);
			$[0] = value;
			$[1] = t5;
		} else t5 = $[1];
		t4 = t5;
	}
	const formattedDate = t4;
	let t5;
	bb1: {
		if (!value) {
			t5 = null;
			break bb1;
		}
		let t6;
		if ($[2] !== value) {
			t6 = new Date(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate());
			$[2] = value;
			$[3] = t6;
		} else t6 = $[3];
		t5 = t6;
	}
	const datePickerValue = t5;
	let t6;
	if ($[4] !== fieldId || $[5] !== isDraft || $[6] !== onCommit) {
		t6 = () => {
			if (isDraft) onCommit(fieldId, null);
			setIsOpen(false);
		};
		$[4] = fieldId;
		$[5] = isDraft;
		$[6] = onCommit;
		$[7] = t6;
	} else t6 = $[7];
	const onClose = t6;
	let t7;
	if ($[8] !== fieldId || $[9] !== onCommit) {
		t7 = (date) => {
			let normalizedDate = null;
			if (date) normalizedDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0));
			onCommit(fieldId, normalizedDate);
			setIsOpen(false);
		};
		$[8] = fieldId;
		$[9] = onCommit;
		$[10] = t7;
	} else t7 = $[10];
	const handleDateChange = t7;
	const displayValue = formattedDate || LABELS$1.setValue;
	if (readonly) {
		let t8;
		if ($[11] !== className || $[12] !== displayValue || $[13] !== fieldName || $[14] !== formattedDate) {
			t8 = jsxs("div", {
				className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, className),
				children: [jsx("p", {
					className: IssueFieldItem_module_default.issueFieldLabel,
					children: fieldName
				}), jsx("div", {
					className: clsx(IssueFieldItem_module_default.issueFieldValueText, formattedDate && IssueFieldItem_module_default.hasValue),
					children: displayValue
				})]
			});
			$[11] = className;
			$[12] = displayValue;
			$[13] = fieldName;
			$[14] = formattedDate;
			$[15] = t8;
		} else t8 = $[15];
		return t8;
	}
	let t8;
	if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = () => setIsOpen(true);
		$[16] = t8;
	} else t8 = $[16];
	let t9;
	if ($[17] !== className || $[18] !== displayValue || $[19] !== errorPresent || $[20] !== fieldName || $[21] !== formattedDate || $[22] !== isOpen || $[23] !== value) {
		t9 = (anchorProps) => jsx(IssueFieldDateEditorButton, {
			anchorProps,
			fieldName,
			value,
			displayValue,
			formattedDate,
			isOpen,
			errorPresent,
			className
		});
		$[17] = className;
		$[18] = displayValue;
		$[19] = errorPresent;
		$[20] = fieldName;
		$[21] = formattedDate;
		$[22] = isOpen;
		$[23] = value;
		$[24] = t9;
	} else t9 = $[24];
	let t10;
	if ($[25] !== datePickerValue || $[26] !== handleDateChange || $[27] !== isOpen || $[28] !== onClose || $[29] !== t9) {
		t10 = jsx(DatePicker, {
			variant: "single",
			showClearButton: true,
			value: datePickerValue,
			onChange: handleDateChange,
			open: isOpen,
			onOpen: t8,
			onClose,
			anchor: t9
		});
		$[25] = datePickerValue;
		$[26] = handleDateChange;
		$[27] = isOpen;
		$[28] = onClose;
		$[29] = t9;
		$[30] = t10;
	} else t10 = $[30];
	return t10;
};
IssueFieldDateEditor.displayName = "IssueFieldDateEditor";
var IssueFieldSingleSelectValueToken_module_default = {
	compactContainer: "IssueFieldSingleSelectValueToken-module_Q0JlIq_compactContainer",
	compactValueContainer: "IssueFieldSingleSelectValueToken-module_Q0JlIq_compactValueContainer",
	container: "IssueFieldSingleSelectValueToken-module_Q0JlIq_container",
	token: "IssueFieldSingleSelectValueToken-module_Q0JlIq_token",
	tokenText: "IssueFieldSingleSelectValueToken-module_Q0JlIq_tokenText"
};
var IssueFieldSingleSelectValueToken = ({ name, color, getTooltipText, size, sx, containerClassName }) => {
	const tokenRef = useRef(null);
	const [truncated, setTruncated] = useState(false);
	useEffect(() => setTruncated(isTextTruncated$1(tokenRef.current)), [setTruncated, tokenRef]);
	const tooltipText = getTooltipText(truncated);
	const internal = /* @__PURE__ */ jsx(Token$1, {
		className: IssueFieldSingleSelectValueToken_module_default.token,
		"data-color": color,
		ref: tokenRef,
		sx,
		text: /* @__PURE__ */ jsx("span", {
			className: IssueFieldSingleSelectValueToken_module_default.tokenText,
			children: name
		}),
		as: tooltipText ? "button" : "span",
		...tooltipText && {
			type: "button",
			"aria-label": `${name} token`
		}
	});
	return /* @__PURE__ */ jsx("div", {
		className: clsx(IssueFieldSingleSelectValueToken_module_default.container, containerClassName),
		"data-size": size,
		children: tooltipText ? /* @__PURE__ */ jsx(Tooltip$1, {
			text: tooltipText,
			children: internal
		}) : internal
	});
};
IssueFieldSingleSelectValueToken.displayName = "IssueFieldSingleSelectValueToken";
var isTextTruncated$1 = (e) => {
	if (!e || !e.firstElementChild) return false;
	return e.firstElementChild.scrollWidth > e.firstElementChild.clientWidth;
};
var IssueFieldSingleSelectEditorButton = ({ anchorProps, buttonRef, ariaLabel, fieldName, displayValue, isNoValue, className, errorPresent }) => {
	const content = /* @__PURE__ */ jsxs("button", {
		ref: buttonRef,
		className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, IssueFieldItem_module_default.issueFieldFormWrapperClickable, className),
		"aria-label": ariaLabel,
		...anchorProps,
		children: [
			/* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.issueFieldLabel,
				children: fieldName
			}),
			/* @__PURE__ */ jsx("span", {
				className: clsx(IssueFieldItem_module_default.issueFieldValueText, !isNoValue && IssueFieldItem_module_default.hasValue, IssueFieldSingleSelectValueToken_module_default.compactValueContainer),
				children: displayValue
			}),
			errorPresent && /* @__PURE__ */ jsx("span", {
				className: IssueFieldItem_module_default.alertIconWrapper,
				children: /* @__PURE__ */ jsx(AlertIcon, { className: IssueFieldItem_module_default.alertIcon })
			})
		]
	});
	return errorPresent ? /* @__PURE__ */ jsx(Tooltip$1, {
		text: LABELS$1.errorUpdatingIssueField,
		type: "description",
		children: content
	}) : content;
};
IssueFieldSingleSelectEditorButton.displayName = "IssueFieldSingleSelectEditorButton";
var IssueFieldSingleSelectEditor = (t0) => {
	const $ = c(19);
	const { fieldId, fieldName, readonly, initialValue, onCommit, shouldOpen: t1, isDraft: t2, className, errorPresent: t3 } = t0;
	const shouldOpen = t1 === void 0 ? false : t1;
	const isDraft = t2 === void 0 ? false : t2;
	const errorPresent = t3 === void 0 ? false : t3;
	let t4;
	if ($[0] !== fieldId || $[1] !== onCommit) {
		t4 = (selectedOption) => {
			onCommit(fieldId, selectedOption);
		};
		$[0] = fieldId;
		$[1] = onCommit;
		$[2] = t4;
	} else t4 = $[2];
	const onSelectionChanged = t4;
	let t5;
	if ($[3] !== fieldId || $[4] !== isDraft || $[5] !== onCommit) {
		t5 = () => {
			if (isDraft) onCommit(fieldId, null);
		};
		$[3] = fieldId;
		$[4] = isDraft;
		$[5] = onCommit;
		$[6] = t5;
	} else t5 = $[6];
	const onClose = t5;
	const isNoValue = !initialValue || initialValue.name === "" && initialValue.color === "";
	let t6;
	let t7;
	if ($[7] !== className || $[8] !== errorPresent || $[9] !== fieldId || $[10] !== fieldName || $[11] !== initialValue || $[12] !== isNoValue || $[13] !== onClose || $[14] !== onSelectionChanged || $[15] !== readonly || $[16] !== shouldOpen) {
		t7 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const displayValue = isNoValue ? LABELS$1.setValue : jsx(IssueFieldSingleSelectValueToken, {
				name: initialValue.name,
				color: initialValue.color,
				getTooltipText: _temp$12,
				size: "small",
				containerClassName: IssueFieldSingleSelectValueToken_module_default.compactContainer
			});
			const ariaLabel = isNoValue ? `Set ${fieldName}` : `Edit ${fieldName}`;
			if (readonly) {
				t7 = jsxs("div", {
					className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, className),
					children: [jsx("p", {
						className: IssueFieldItem_module_default.issueFieldLabel,
						children: fieldName
					}), jsx("div", {
						className: clsx(IssueFieldItem_module_default.issueFieldValueText, !isNoValue && IssueFieldItem_module_default.hasValue, IssueFieldSingleSelectValueToken_module_default.compactValueContainer),
						children: displayValue
					})]
				});
				break bb0;
			}
			t6 = jsx(IssueSingleSelectFieldPicker, {
				fieldId,
				fieldName,
				selectedOption: initialValue ? initialValue.name : null,
				onSelectionChange: onSelectionChanged,
				anchorElement: (anchorProps, ref) => jsx(IssueFieldSingleSelectEditorButton, {
					anchorProps,
					buttonRef: ref,
					ariaLabel,
					fieldName,
					displayValue,
					isNoValue,
					className,
					errorPresent
				}),
				readonly: false,
				isLazy: true,
				onClose,
				shouldOpen
			});
		}
		$[7] = className;
		$[8] = errorPresent;
		$[9] = fieldId;
		$[10] = fieldName;
		$[11] = initialValue;
		$[12] = isNoValue;
		$[13] = onClose;
		$[14] = onSelectionChanged;
		$[15] = readonly;
		$[16] = shouldOpen;
		$[17] = t6;
		$[18] = t7;
	} else {
		t6 = $[17];
		t7 = $[18];
	}
	if (t7 !== Symbol.for("react.early_return_sentinel")) return t7;
	return t6;
};
IssueFieldSingleSelectEditor.displayName = "IssueFieldSingleSelectEditor";
function _temp$12() {}
function getIssueFieldEditor({ errorPresent, setErrorPresent, fieldValue, ...props }) {
	if (!fieldValue.field) return null;
	const fieldId = fieldValue.field.id;
	const showErrorDialog = fieldValue.field.dataType === "SINGLE_SELECT";
	return /* @__PURE__ */ jsxs(Fragment, { children: [getEditor({
		fieldValue,
		...props
	}, errorPresent[fieldId]), showErrorDialog && errorPresent[fieldId] && /* @__PURE__ */ jsx(ErrorDialog, {
		onClose: () => setErrorPresent(fieldId, false),
		message: LABELS$1.mutationErrorMessage
	})] }, fieldValue.field.name);
}
function getEditor({ fieldValue, readonly, onCommit, className }, errorPresent) {
	const isCleared = fieldValue.value === "";
	switch (fieldValue.field.dataType) {
		case "TEXT": return /* @__PURE__ */ jsx(IssueFieldTextEditor$1, {
			fieldId: fieldValue.field.id,
			fieldName: fieldValue.field.name || "",
			initialValue: fieldValue.value || "",
			readonly,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			errorPresent,
			className
		}, fieldValue.field.name);
		case "SINGLE_SELECT": return /* @__PURE__ */ jsx(IssueFieldSingleSelectEditor, {
			fieldId: fieldValue.field.id,
			fieldName: fieldValue.field.name || "",
			initialValue: {
				name: isCleared || !fieldValue?.name ? "" : fieldValue.name,
				color: isCleared || !fieldValue?.color ? "" : fieldValue.color,
				description: isCleared || !fieldValue?.description ? "" : fieldValue.description
			},
			readonly,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			className,
			errorPresent
		}, fieldValue.field.name);
		case "DATE": {
			let dateValue = null;
			const rawValue = fieldValue.value;
			if (rawValue) {
				if (rawValue instanceof Date) dateValue = rawValue;
				else if (typeof rawValue === "string") dateValue = stripTimezone(rawValue);
			}
			return /* @__PURE__ */ jsx(IssueFieldDateEditor, {
				fieldId: fieldValue.field.id,
				fieldName: fieldValue.field.name || "",
				value: dateValue,
				readonly,
				onCommit: (fieldId, value) => onCommit(fieldId, value),
				errorPresent,
				className
			}, fieldValue.field.name);
		}
		case "NUMBER": {
			const hasNumberValue = fieldValue.numberValue !== void 0 && fieldValue.numberValue !== null;
			const hasValue = fieldValue.value !== void 0 && fieldValue.value !== null && fieldValue.value !== "";
			const numberValue = hasNumberValue ? fieldValue.numberValue.toString() : hasValue ? String(fieldValue.value) : "";
			return /* @__PURE__ */ jsx(IssueFieldNumberEditor$1, {
				fieldId: fieldValue.field.id,
				fieldName: fieldValue.field.name || "",
				initialValue: numberValue,
				readonly,
				onCommit: (fieldId, value) => {
					if (value === "") onCommit(fieldId, value);
					else onCommit(fieldId, Number(value));
				},
				errorPresent,
				className
			}, fieldValue.field.name);
		}
		default: throw new Error(`Unsupported field type: ${fieldValue.field.dataType}`);
	}
}
function getPendingEditor({ fieldSelection, onCommit, className }) {
	switch (fieldSelection.dataType) {
		case "text": return /* @__PURE__ */ jsx(IssueFieldTextEditor$1, {
			fieldId: fieldSelection.id || "",
			fieldName: fieldSelection.name || "",
			initialValue: "",
			readonly: false,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			shouldOpen: true,
			isDraft: true,
			className
		}, fieldSelection.id);
		case "single_select": return /* @__PURE__ */ jsx(IssueFieldSingleSelectEditor, {
			fieldId: fieldSelection.id,
			fieldName: fieldSelection.name || "",
			initialValue: {
				name: "",
				color: "",
				description: ""
			},
			readonly: false,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			shouldOpen: true,
			isDraft: true,
			className
		}, fieldSelection.name);
		case "date": return /* @__PURE__ */ jsx(IssueFieldDateEditor, {
			fieldId: fieldSelection.id,
			fieldName: fieldSelection.name || "",
			value: null,
			readonly: false,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			shouldOpen: true,
			isDraft: true,
			className
		}, fieldSelection.name);
		case "number": return /* @__PURE__ */ jsx(IssueFieldNumberEditor$1, {
			fieldId: fieldSelection.id || "",
			fieldName: fieldSelection.name || "",
			initialValue: "",
			readonly: false,
			onCommit: (fieldId, value) => onCommit(fieldId, value),
			shouldOpen: true,
			isDraft: true,
			className
		}, fieldSelection.id);
		default: throw new Error(`Unsupported field type: ${fieldSelection.dataType}`);
	}
}
function ErrorDialog({ onClose, message }) {
	return /* @__PURE__ */ jsx(ConfirmationDialog, {
		title: "Error",
		confirmButtonContent: "OK",
		confirmButtonType: "primary",
		onClose,
		children: message
	});
}
ErrorDialog.displayName = "ErrorDialog";
var node$49 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [v2, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "value",
		"storageKey": null
	}], v4 = {
		"kind": "InlineFragment",
		"selections": v3,
		"type": "IssueFieldTextValue",
		"abstractKey": null
	}, v5 = {
		"kind": "InlineFragment",
		"selections": [
			v2,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "color",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "description",
				"storageKey": null
			}
		],
		"type": "IssueFieldSingleSelectValue",
		"abstractKey": null
	}, v6 = {
		"kind": "InlineFragment",
		"selections": v3,
		"type": "IssueFieldDateValue",
		"abstractKey": null
	}, v7 = {
		"kind": "InlineFragment",
		"selections": [v2, {
			"alias": "numberValue",
			"args": null,
			"kind": "ScalarField",
			"name": "value",
			"storageKey": null
		}],
		"type": "IssueFieldNumberValue",
		"abstractKey": null
	}, v8 = [v2], v9 = {
		"alias": null,
		"args": null,
		"concreteType": "Issue",
		"kind": "LinkedField",
		"name": "issue",
		"plural": false,
		"selections": v8,
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "createIssueFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "CreateIssueFieldValuePayload",
				"kind": "LinkedField",
				"name": "createIssueFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "issueFieldValue",
					"plural": false,
					"selections": [
						v4,
						v5,
						v6,
						v7
					],
					"storageKey": null
				}, v9],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "createIssueFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "CreateIssueFieldValuePayload",
				"kind": "LinkedField",
				"name": "createIssueFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "issueFieldValue",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						v4,
						v5,
						v6,
						v7,
						{
							"kind": "InlineFragment",
							"selections": v8,
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}, v9],
				"storageKey": null
			}]
		},
		"params": {
			"id": "7d34c7a47ddc5e24a7fe4d1980651c76",
			"metadata": {},
			"name": "createIssueFieldValueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$49.hash = "efaa5ef3592a90da63e7e17d2645f75c";
var getFieldValueType = (fieldInput) => {
	if (fieldInput.singleSelectOptionId !== void 0) return ISSUE_FIELD_SINGLE_SELECT_VALUE_TYPE;
	if (fieldInput.dateValue !== void 0) return ISSUE_FIELD_DATE_VALUE_TYPE;
	if (fieldInput.numberValue !== void 0) return ISSUE_FIELD_NUMBER_VALUE_TYPE;
	return ISSUE_FIELD_TEXT_VALUE_TYPE;
};
var updateNodeValues = (store, node, fieldInput) => {
	if (!node) return;
	if (fieldInput.textValue !== void 0) node.setValue(fieldInput.textValue, "value");
	if (fieldInput.singleSelectOptionId !== void 0 && fieldInput.singleSelectOptionId !== null) {
		const found = (store.get(fieldInput.fieldId)?.getLinkedRecords("options") || []).find((opt) => opt.getDataID() === fieldInput.singleSelectOptionId);
		node.setValue(found?.getValue("name") ?? null, "name");
		node.setValue(found?.getValue("color") ?? null, "color");
		node.setValue(found?.getValue("description") ?? null, "description");
	}
	if (fieldInput.dateValue !== void 0) node.setValue(fieldInput.dateValue, "value");
	if (fieldInput.numberValue !== void 0) node.setValue(fieldInput.numberValue, "value");
};
var replaceFieldValueInCollection = (fieldValues, fieldId, newNode) => {
	if (!fieldValues || !newNode) return;
	const updatedNodes = (fieldValues.getLinkedRecords("nodes") || []).filter((n) => n?.getLinkedRecord("field")?.getDataID() !== fieldId);
	updatedNodes.push(newNode);
	fieldValues.setLinkedRecords(updatedNodes, "nodes");
};
function commitCreateIssueFieldValueMutation({ environment, input, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$49,
		variables: { input },
		onCompleted: () => {
			onCompleted?.();
		},
		onError: (error) => onError?.(error),
		optimisticUpdater: (store) => {
			const issue = store.get(input.issueId);
			if (!issue) return;
			const fieldInput = input.issueField;
			const fieldValues = issue.getLinkedRecord("issueFieldValues", { first: 25 });
			const nodes = fieldValues?.getLinkedRecords("nodes") || [];
			const type = getFieldValueType(fieldInput);
			const node = store.create(`client:newFieldValue:${fieldInput.fieldId}`, type);
			node.setValue(`client:newFieldValue:${fieldInput.fieldId}`, "id");
			const fieldRecord = store.get(fieldInput.fieldId);
			if (fieldRecord) node.setLinkedRecord(fieldRecord, "field");
			updateNodeValues(store, node, fieldInput);
			nodes.push(node);
			if (fieldValues) fieldValues.setLinkedRecords(nodes, "nodes");
		},
		updater: (store) => {
			const issue = store.get(input.issueId);
			const fieldValues = issue?.getLinkedRecord("issueFieldValues", { first: 25 });
			const newValue = store.getRootField("createIssueFieldValue")?.getLinkedRecord("issueFieldValue");
			if (!issue || !newValue || !fieldValues) return;
			const fieldInput = input.issueField;
			if (!newValue.getLinkedRecord("field")) {
				const fieldRecord = store.get(fieldInput.fieldId);
				if (fieldRecord) newValue.setLinkedRecord(fieldRecord, "field");
			}
			replaceFieldValueInCollection(fieldValues, fieldInput.fieldId, newValue);
		}
	});
}
var node$48 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "DeleteIssueFieldValuePayload",
		"kind": "LinkedField",
		"name": "deleteIssueFieldValue",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "success",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "issue",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "deleteIssueFieldValueMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "deleteIssueFieldValueMutation",
			"selections": v1
		},
		"params": {
			"id": "07154732cd6de9c83b93caf7e4fdb17b",
			"metadata": {},
			"name": "deleteIssueFieldValueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$48.hash = "ade9c121a42280fa29046520cd641e3c";
function commitDeleteIssueFieldValueMutation({ environment, input, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$48,
		variables: { input },
		onCompleted: () => {
			onCompleted?.();
		},
		onError: (error) => onError?.(error),
		optimisticUpdater: (store) => {
			const issue = store.get(input.issueId);
			if (issue) handleFieldClear(issue, input.fieldId);
		},
		updater: (store) => {
			const issue = store.get(input.issueId);
			if (issue) handleFieldClear(issue, input.fieldId);
		}
	});
}
var handleFieldClear = (issue, fieldId) => {
	if (!issue) return;
	const fieldValues = issue.getLinkedRecord("issueFieldValues", { first: 25 });
	if (!fieldValues) return;
	const clearedNode = (fieldValues.getLinkedRecords("nodes") || []).find((node) => node?.getLinkedRecord("field")?.getDataID() === fieldId);
	if (!clearedNode) return;
	clearFieldValue(clearedNode, clearedNode.getType());
};
var node$47 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [v2, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "value",
		"storageKey": null
	}], v4 = {
		"kind": "InlineFragment",
		"selections": v3,
		"type": "IssueFieldTextValue",
		"abstractKey": null
	}, v5 = {
		"kind": "InlineFragment",
		"selections": [
			v2,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "color",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "description",
				"storageKey": null
			}
		],
		"type": "IssueFieldSingleSelectValue",
		"abstractKey": null
	}, v6 = {
		"kind": "InlineFragment",
		"selections": v3,
		"type": "IssueFieldDateValue",
		"abstractKey": null
	}, v7 = {
		"kind": "InlineFragment",
		"selections": [v2, {
			"alias": "numberValue",
			"args": null,
			"kind": "ScalarField",
			"name": "value",
			"storageKey": null
		}],
		"type": "IssueFieldNumberValue",
		"abstractKey": null
	}, v8 = [v2], v9 = {
		"alias": null,
		"args": null,
		"concreteType": "Issue",
		"kind": "LinkedField",
		"name": "issue",
		"plural": false,
		"selections": v8,
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueFieldValuePayload",
				"kind": "LinkedField",
				"name": "updateIssueFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "issueFieldValue",
					"plural": false,
					"selections": [
						v4,
						v5,
						v6,
						v7
					],
					"storageKey": null
				}, v9],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueFieldValuePayload",
				"kind": "LinkedField",
				"name": "updateIssueFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "issueFieldValue",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						v4,
						v5,
						v6,
						v7,
						{
							"kind": "InlineFragment",
							"selections": v8,
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}, v9],
				"storageKey": null
			}]
		},
		"params": {
			"id": "c9b8f156814615ff82eb2393351e0719",
			"metadata": {},
			"name": "updateIssueFieldValueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$47.hash = "42fa492eab38e97eb091a4309e4f4202";
function commitUpdateIssueFieldValueMutation({ environment, input, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$47,
		variables: { input },
		onCompleted: () => {
			onCompleted?.();
		},
		onError: (error) => onError?.(error),
		optimisticUpdater: (store) => {
			const fieldValues = store.get(input.issueId)?.getLinkedRecord("issueFieldValues", { first: 25 });
			const nodes = fieldValues?.getLinkedRecords("nodes") || [];
			const fieldInput = input.issueField;
			const type = getFieldValueType(fieldInput);
			let node = nodes.find((n) => n.getLinkedRecord("field")?.getDataID() === fieldInput.fieldId);
			if (!node) {
				node = store.create(`client:updateFieldValue:${fieldInput.fieldId}`, type);
				const fieldRecord = store.get(fieldInput.fieldId);
				if (fieldRecord) node.setLinkedRecord(fieldRecord, "field");
			}
			updateNodeValues(store, node, fieldInput);
			replaceFieldValueInCollection(fieldValues, fieldInput.fieldId, node);
		},
		updater: (store) => {
			const fieldValues = store.get(input.issueId)?.getLinkedRecord("issueFieldValues", { first: 25 });
			const newValue = store.getRootField("updateIssueFieldValue")?.getLinkedRecord("issueFieldValue");
			const fieldInput = input.issueField;
			if (!newValue) return;
			if (!newValue.getLinkedRecord("field")) {
				const fieldRecord = store.get(fieldInput.fieldId);
				if (fieldRecord) newValue.setLinkedRecord(fieldRecord, "field");
			}
			replaceFieldValueInCollection(fieldValues, fieldInput.fieldId, newValue);
		}
	});
}
var fieldsSectionFragment = node$51;
var fieldsSectionFieldValuesFragment = node$50;
function CreateIssueFieldsSection(t0) {
	const $ = c(39);
	const { owner, ownerId, onSelectionChange, issueType, orgPinnedFields, isPinnedFieldsLoading } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [fields, setFields] = useState(t1);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[1] = t2;
	} else t2 = $[1];
	const [fieldsSet, setFieldsSet] = useState(t2);
	const [pendingField, setPendingField] = useState(null);
	const { animatePinned } = usePinnedFieldsAnimation(issueType?.name || null);
	const { markInteractionStart, reportUsage } = useIssueFieldsAnalytics();
	const { setAddFieldButtonElement } = usePendingFieldFocus(pendingField);
	let t3;
	if ($[2] !== issueType || $[3] !== orgPinnedFields) {
		t3 = issueType ? parsePinnedIssueFields(issueType.pinnedFields?.filter(_temp$11)) ?? [] : orgPinnedFields ?? [];
		$[2] = issueType;
		$[3] = orgPinnedFields;
		$[4] = t3;
	} else t3 = $[4];
	const mergedPinnedFields = t3;
	let t4;
	if ($[5] !== mergedPinnedFields) {
		t4 = {
			pinnedFields: mergedPinnedFields,
			setFields,
			setFieldsSet
		};
		$[5] = mergedPinnedFields;
		$[6] = t4;
	} else t4 = $[6];
	const { pinnedFieldIds } = usePinnedFieldsState(t4);
	let t5;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = isFeatureEnabled("issue_metadata_add_field_button");
		$[7] = t5;
	} else t5 = $[7];
	const hideAddFieldButton = !t5;
	let t6;
	let t7;
	if ($[8] !== fields || $[9] !== onSelectionChange) {
		t6 = () => {
			onSelectionChange(fields.filter(_temp2$8));
		};
		t7 = [fields, onSelectionChange];
		$[8] = fields;
		$[9] = onSelectionChange;
		$[10] = t6;
		$[11] = t7;
	} else {
		t6 = $[10];
		t7 = $[11];
	}
	useEffect(t6, t7);
	let t8;
	let t9;
	if ($[12] !== fields || $[13] !== fieldsSet) {
		t8 = () => {
			const allVisibleFieldNames = fields.map(_temp3$7).filter(_temp4$4);
			const allFieldNames = [...new Set([...allVisibleFieldNames, ...fieldsSet])];
			if (allFieldNames.length !== fieldsSet.length || !allFieldNames.every((name_0) => fieldsSet.includes(name_0))) setFieldsSet(allFieldNames);
		};
		t9 = [fields, fieldsSet];
		$[12] = fields;
		$[13] = fieldsSet;
		$[14] = t8;
		$[15] = t9;
	} else {
		t8 = $[14];
		t9 = $[15];
	}
	useEffect(t8, t9);
	let t10;
	if ($[16] !== markInteractionStart) {
		t10 = (selectedField) => {
			markInteractionStart();
			if (!selectedField.id) return;
			setPendingField(selectedField);
			if (selectedField.name) setFieldsSet((prev) => [...prev, selectedField.name]);
		};
		$[16] = markInteractionStart;
		$[17] = t10;
	} else t10 = $[17];
	const onIssueFieldSelected = t10;
	let t11;
	if ($[18] !== ownerId || $[19] !== pinnedFieldIds || $[20] !== reportUsage) {
		t11 = (fieldId, value) => {
			setFields((prevFields) => {
				let committedField;
				const updatedFields = prevFields.map((field_0) => {
					if (field_0.field.id === fieldId) {
						committedField = toIssueFieldWithValue(field_0.field, value);
						return committedField;
					}
					return field_0;
				}).filter((f_1) => f_1.value !== void 0 || f_1.field.id && pinnedFieldIds.has(f_1.field.id));
				if (committedField && !committedField.value) {
					if (!(committedField.field.id && pinnedFieldIds.has(committedField.field.id))) setFieldsSet((prev_0) => prev_0.filter((name_1) => name_1 !== committedField?.field.name));
				}
				if (committedField && committedField.field.dataType) reportUsage({
					page: "issue#new",
					action: "create",
					fieldId,
					fieldType: toIssueFieldType(committedField.field.dataType),
					status: "success",
					orgId: ownerId?.toString()
				});
				return updatedFields;
			});
		};
		$[18] = ownerId;
		$[19] = pinnedFieldIds;
		$[20] = reportUsage;
		$[21] = t11;
	} else t11 = $[21];
	const onCommit = t11;
	let t12;
	if ($[22] !== pendingField) {
		t12 = (fieldId_0, fieldValue) => {
			if (!pendingField || pendingField.id !== fieldId_0) return;
			setPendingField(null);
			const value_0 = getIssueFieldSelectionValue(toIssueFieldType(pendingField.dataType), fieldValue);
			const isEmpty = typeof value_0 === "string" ? !value_0.trim() : !value_0;
			if (pendingField.name && isEmpty) {
				setFieldsSet((prev_1) => prev_1.filter((name_2) => name_2 !== pendingField.name));
				return;
			}
			if (isEmpty) return;
			setFields((prevFields_0) => {
				const newFields = [...prevFields_0];
				if (pendingField.name && !newFields.some((f_2) => f_2.field.name === pendingField.name)) newFields.push(toIssueFieldWithUnsavedValue(pendingField, fieldValue));
				return newFields;
			});
			if (pendingField.name) setFieldsSet((prev_2) => prev_2.includes(pendingField.name) ? prev_2 : [...prev_2, pendingField.name]);
		};
		$[22] = pendingField;
		$[23] = t12;
	} else t12 = $[23];
	const onPendingFieldCommit = t12;
	let t13;
	if ($[24] !== animatePinned || $[25] !== fields || $[26] !== fieldsSet || $[27] !== isPinnedFieldsLoading || $[28] !== issueType?.name || $[29] !== markInteractionStart || $[30] !== mergedPinnedFields.length || $[31] !== onCommit || $[32] !== onIssueFieldSelected || $[33] !== onPendingFieldCommit || $[34] !== owner || $[35] !== pendingField || $[36] !== pinnedFieldIds || $[37] !== setAddFieldButtonElement) {
		const allFieldIds = fields.map(_temp5$2).filter(_temp6$1);
		const fieldEditors = fields.map((field_1) => {
			if (!field_1.field.id) return null;
			return getEditor({
				fieldValue: typeof field_1.value === "object" && field_1.value !== null ? {
					...field_1,
					...field_1.value
				} : field_1,
				readonly: false,
				onCommit,
				className: getPinnedFieldClassName(pinnedFieldIds.has(field_1.field.id), animatePinned, getPinnedFieldPosition(field_1.field.id, pinnedFieldIds, allFieldIds))
			});
		});
		const pendingFieldEditor = pendingField ? (() => {
			const isPinned_0 = pinnedFieldIds.has(pendingField.id);
			const allIdsWithPending = pendingField.id ? [...allFieldIds, pendingField.id] : allFieldIds;
			return getPendingEditor({
				fieldSelection: pendingField,
				readonly: false,
				onCommit: onPendingFieldCommit,
				className: getPinnedFieldClassName(isPinned_0, animatePinned, pendingField.id ? getPinnedFieldPosition(pendingField.id, pinnedFieldIds, allIdsWithPending) : null)
			});
		})() : null;
		const fieldSelector = jsx(FieldsSelector, {
			owner,
			fieldsSet,
			onIssueFieldSelected,
			markInteractionStart,
			disabled: pendingField !== null,
			onButtonElementReceived: setAddFieldButtonElement,
			hideAddFieldButton
		});
		const visibleFieldEditors = fieldEditors.filter(Boolean);
		const isWaitingForFieldsToRender = mergedPinnedFields.length > 0 && visibleFieldEditors.length === 0;
		const showNoPinnedFieldsMessage = !isPinnedFieldsLoading && !isWaitingForFieldsToRender;
		t13 = jsxs(Fragment$1, { children: [
			jsx(Section, {
				sectionHeader: jsx(Heading$2, {
					as: "h3",
					className: FieldsSection_module_default.compactSectionHeader,
					children: "Fields"
				}),
				children: visibleFieldEditors.length > 0 ? jsx(Fragment$1, { children: visibleFieldEditors }) : showNoPinnedFieldsMessage ? jsx("span", {
					className: FieldsSection_module_default.compactSectionEmptyText,
					children: LABELS$1.noPinnedFieldsMessage(issueType?.name)
				}) : jsx(Fragment$1, { children: jsxs("span", {
					className: FieldsSection_module_default.loadingRow,
					children: [jsx(IssuesLoadingSkeleton, {
						height: "md",
						width: "40%"
					}), jsx(IssuesLoadingSkeleton, {
						height: "md",
						width: "60%"
					})]
				}) })
			}),
			pendingFieldEditor,
			fieldSelector
		] });
		$[24] = animatePinned;
		$[25] = fields;
		$[26] = fieldsSet;
		$[27] = isPinnedFieldsLoading;
		$[28] = issueType?.name;
		$[29] = markInteractionStart;
		$[30] = mergedPinnedFields.length;
		$[31] = onCommit;
		$[32] = onIssueFieldSelected;
		$[33] = onPendingFieldCommit;
		$[34] = owner;
		$[35] = pendingField;
		$[36] = pinnedFieldIds;
		$[37] = setAddFieldButtonElement;
		$[38] = t13;
	} else t13 = $[38];
	return t13;
}
CreateIssueFieldsSection.displayName = "CreateIssueFieldsSection";
function _temp6$1(id) {
	return !!id;
}
function _temp5$2(f_3) {
	return f_3.field.id;
}
function _temp4$4(name) {
	return !!name;
}
function _temp3$7(f_0) {
	return f_0.field.name;
}
function _temp2$8(field) {
	return field.value;
}
function _temp$11(f) {
	return f?.__typename !== "%other";
}
function EditIssueFieldsSection(t0) {
	const $ = c(34);
	const { issue, onUpdate, inProjectsPage, readonly } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [fieldsSet, setFieldsSet] = useState(t1);
	const [mutationErrorPresent, setMutationErrorPresent] = useState(false);
	const [errorDialogOpen, setErrorDialogOpen] = useState(false);
	const [pendingField, setPendingField] = useState(null);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { markInteractionStart, reportUsage } = useIssueFieldsAnalytics();
	const { setAddFieldButtonElement } = usePendingFieldFocus(pendingField);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = isFeatureEnabled("issue_metadata_add_field_button");
		$[1] = t2;
	} else t2 = $[1];
	const hideAddFieldButton = !t2;
	const data = (0, import_react_relay.useFragment)(fieldsSectionFragment, issue);
	const { repository: t3, viewerCanSetFields, issueType } = data;
	const { isPrivate, owner: t4 } = t3;
	const { login: owner } = t4;
	const issueFieldsEnabled = data.repository.owner.issueFieldsEnabled ?? false;
	let t5;
	if ($[2] !== data.repository.owner.pinnedIssueFields?.nodes) {
		t5 = parsePinnedIssueFields(data.repository.owner.pinnedIssueFields?.nodes?.filter(_temp7) ?? []);
		$[2] = data.repository.owner.pinnedIssueFields?.nodes;
		$[3] = t5;
	} else t5 = $[3];
	const orgPinnedFields = t5;
	let t6;
	if ($[4] !== issueType || $[5] !== orgPinnedFields) {
		t6 = issueType ? parsePinnedIssueFields(issueType.pinnedFields?.filter(_temp8)) ?? [] : orgPinnedFields ?? [];
		$[4] = issueType;
		$[5] = orgPinnedFields;
		$[6] = t6;
	} else t6 = $[6];
	const mergedPinnedFields = t6;
	let t7;
	if ($[7] !== mergedPinnedFields) {
		t7 = mergedPinnedFields.map(_temp9);
		$[7] = mergedPinnedFields;
		$[8] = t7;
	} else t7 = $[8];
	const pinnedFields = t7;
	let t8;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = () => {
			setMutationErrorPresent(true);
		};
		$[9] = t8;
	} else t8 = $[9];
	const handleErrors = t8;
	let t9;
	if ($[10] !== data.id || $[11] !== data.repository.owner.databaseId || $[12] !== environment || $[13] !== inProjectsPage || $[14] !== pendingField || $[15] !== reportUsage) {
		t9 = (fieldId, payload) => {
			if (!pendingField || pendingField.id !== fieldId) return;
			setPendingField(null);
			const value = getIssueFieldSelectionValue(pendingField.dataType, payload || "");
			const isEmpty = typeof value === "string" ? !value.trim() : !value;
			if (pendingField.name && isEmpty) {
				setFieldsSet((prev) => prev.filter((name) => name !== pendingField.name));
				return;
			}
			if (isEmpty) return;
			runFieldMutation({
				mutationFn: commitCreateIssueFieldValueMutation,
				input: {
					issueId: data.id,
					issueField: {
						fieldId,
						...getIssueFieldValue(pendingField.dataType, value)
					}
				},
				environment,
				action: "create",
				fieldId,
				fieldType: toIssueFieldType(pendingField.dataType),
				inProjectsPage,
				ownerId: data.repository?.owner?.databaseId,
				reportUsage,
				onError: handleErrors
			});
		};
		$[10] = data.id;
		$[11] = data.repository.owner.databaseId;
		$[12] = environment;
		$[13] = inProjectsPage;
		$[14] = pendingField;
		$[15] = reportUsage;
		$[16] = t9;
	} else t9 = $[16];
	const onCommitPendingField = t9;
	let t10;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = (selectedField) => {
			if (!selectedField.id) return;
			setPendingField(selectedField);
			if (selectedField.name) setFieldsSet((prev_0) => [...prev_0, selectedField.name]);
		};
		$[17] = t10;
	} else t10 = $[17];
	const onIssueFieldSelected = t10;
	const visibilityEnabled = data.repository.owner.issueFieldsVisibilitySettingsEnabled ?? false;
	if (!isPrivate && !visibilityEnabled || !issueFieldsEnabled) return null;
	let t11;
	if ($[18] !== data || $[19] !== errorDialogOpen || $[20] !== fieldsSet || $[21] !== inProjectsPage || $[22] !== markInteractionStart || $[23] !== mutationErrorPresent || $[24] !== onCommitPendingField || $[25] !== onUpdate || $[26] !== owner || $[27] !== pendingField || $[28] !== pinnedFields || $[29] !== readonly || $[30] !== setAddFieldButtonElement || $[31] !== viewerCanSetFields) {
		let t12;
		if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
			t12 = () => setErrorDialogOpen(true);
			$[33] = t12;
		} else t12 = $[33];
		t11 = jsxs(Fragment$1, { children: [jsxs(ErrorBoundary, {
			fallback: jsxs("div", { children: [jsx(Tooltip$1, {
				text: LABELS$1.loadingFieldsTooltipMessage,
				children: jsx("span", { children: jsx(AddIssueFieldButton, {
					inactive: true,
					anchorProps: { onClick: t12 },
					onClick: noop$1
				}) })
			}), errorDialogOpen && jsx(ErrorDialog, {
				onClose: () => setErrorDialogOpen(false),
				message: LABELS$1.loadingFieldsErrorMessage
			})] }),
			children: [
				jsx(IssueFields, {
					issue: data,
					fieldsSet,
					setFieldsSet,
					inProjectsPage,
					pinnedFields,
					readonly,
					onUpdate
				}),
				pendingField && getPendingEditor({
					fieldSelection: pendingField,
					readonly: false,
					onCommit: onCommitPendingField,
					className: pinnedFields.some((field_0) => field_0.field.id === pendingField.id) ? FieldsSection_module_default.pinnedField : void 0
				}),
				!readonly && viewerCanSetFields && jsx(FieldsSelector, {
					owner,
					fieldsSet,
					onIssueFieldSelected,
					markInteractionStart,
					disabled: pendingField !== null,
					onButtonElementReceived: setAddFieldButtonElement,
					hideAddFieldButton
				})
			]
		}), mutationErrorPresent && jsx(ErrorDialog, {
			onClose: () => setMutationErrorPresent(false),
			message: LABELS$1.mutationErrorMessage
		})] });
		$[18] = data;
		$[19] = errorDialogOpen;
		$[20] = fieldsSet;
		$[21] = inProjectsPage;
		$[22] = markInteractionStart;
		$[23] = mutationErrorPresent;
		$[24] = onCommitPendingField;
		$[25] = onUpdate;
		$[26] = owner;
		$[27] = pendingField;
		$[28] = pinnedFields;
		$[29] = readonly;
		$[30] = setAddFieldButtonElement;
		$[31] = viewerCanSetFields;
		$[32] = t11;
	} else t11 = $[32];
	return t11;
}
EditIssueFieldsSection.displayName = "EditIssueFieldsSection";
function _temp9(field) {
	return toIssueFieldWithUnsavedValue(asIssueFieldSelection(field), null);
}
function _temp8(f) {
	return f?.__typename !== "%other";
}
function _temp7(node) {
	return node?.__typename !== "%other";
}
function IssueFields({ issue, fieldsSet, setFieldsSet, inProjectsPage, onUpdate, pinnedFields, readonly }) {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [errorPresent, setErrorPresent] = useState({});
	const { reportUsage } = useIssueFieldsAnalytics();
	useEffect(() => {
		const hasAnyErrors = Object.values(errorPresent).some((isError) => isError);
		const handleBeforeUnload = (event) => {
			if (hasAnyErrors) {
				event.preventDefault();
				event.returnValue = LABELS$1.reloadWarningMessage;
				return event.returnValue;
			}
		};
		window.addEventListener("beforeunload", handleBeforeUnload);
		return () => {
			window.removeEventListener("beforeunload", handleBeforeUnload);
		};
	}, [errorPresent]);
	const data = (0, import_react_relay.useFragment)(fieldsSectionFieldValuesFragment, issue);
	const { animatePinned } = usePinnedFieldsAnimation(data.issueType?.id || null);
	const filteredFieldValues = (data.issueFieldValues?.nodes || []).map((fv) => fv);
	const [effectiveFieldValues, setEffectiveFieldValues] = useState(filteredFieldValues.filter((fv) => fv?.field != null));
	useEffect(() => {
		setEffectiveFieldValues((data.issueFieldValues?.nodes || []).map((fv) => fv).filter((fv) => fv?.field != null));
	}, [data.id]);
	const handleErrors = useCallback((fieldId) => {
		setErrorPresent((prev) => ({
			...prev,
			[fieldId]: true
		}));
	}, []);
	const onCommitField = useCallback((fieldId, fieldType, value) => {
		const issueFieldType = toIssueFieldType(fieldType);
		const selectionValue = getIssueFieldSelectionValue(issueFieldType, value);
		if (value === "" || value === null) runFieldMutation({
			mutationFn: commitDeleteIssueFieldValueMutation,
			input: {
				issueId: data.id,
				fieldId
			},
			environment,
			action: "delete",
			fieldId,
			fieldType: issueFieldType,
			inProjectsPage,
			reportUsage,
			onCompleted: () => {
				setErrorPresent((prev) => ({
					...prev,
					[fieldId]: false
				}));
				onUpdate();
			},
			onError: () => handleErrors(fieldId)
		});
		else runFieldMutation({
			mutationFn: commitUpdateIssueFieldValueMutation,
			input: {
				issueId: data.id,
				issueField: {
					fieldId,
					...getIssueFieldValue(issueFieldType, selectionValue)
				}
			},
			environment,
			action: "update",
			fieldId,
			fieldType: issueFieldType,
			inProjectsPage,
			reportUsage,
			onCompleted: () => {
				setErrorPresent((prev) => ({
					...prev,
					[fieldId]: false
				}));
				onUpdate();
			},
			onError: () => handleErrors(fieldId)
		});
	}, [
		data.id,
		environment,
		handleErrors,
		inProjectsPage,
		reportUsage,
		onUpdate
	]);
	useMemo(() => {
		const { addedFields, updatedFields, removedFields } = getFieldChanges(effectiveFieldValues, filteredFieldValues);
		if (addedFields.length === 0 && updatedFields.length === 0 && removedFields.length === 0) return;
		let shouldSet = addedFields.length > 0;
		const updatedFieldValues = effectiveFieldValues.map((fieldValue) => {
			const updatedField = updatedFields.find((uf) => uf?.field?.id === fieldValue?.field?.id);
			if (updatedField) {
				if (!areFieldValuesEqual(updatedField, fieldValue)) shouldSet = true;
				return updatedField;
			}
			if (removedFields.some((removedField) => removedField?.field?.id === fieldValue?.field?.id)) {
				const clearedField = createClearedFieldValue(fieldValue);
				if (!areFieldValuesEqual(clearedField, fieldValue)) shouldSet = true;
				return clearedField;
			}
			return fieldValue;
		}).filter((fv) => fv !== null && fv !== void 0);
		if (shouldSet) setEffectiveFieldValues([...updatedFieldValues, ...addedFields]);
	}, [filteredFieldValues, effectiveFieldValues]);
	const allFields = useMemo(() => {
		if (!pinnedFields || pinnedFields.length === 0) return effectiveFieldValues;
		const newPinnedFields = pinnedFields.map((pinnedField) => {
			const userSetField = effectiveFieldValues.find((fieldValue) => fieldValue.field.id === pinnedField.field.id);
			return userSetField ? userSetField : pinnedField;
		});
		const pinnedIds = newPinnedFields.map((pinnedField) => pinnedField.field.id);
		const userSetFields = effectiveFieldValues.filter((fv) => !pinnedIds.includes(fv.field.id));
		return [...newPinnedFields, ...userSetFields];
	}, [pinnedFields, effectiveFieldValues]);
	useEffect(() => {
		const allVisibleFieldNames = allFields.map((fv) => fv?.field?.name || "").filter((name) => name);
		if (!(fieldsSet.length === allVisibleFieldNames.length && fieldsSet.every((name, idx) => name === allVisibleFieldNames[idx]))) setFieldsSet(allVisibleFieldNames);
	}, [
		fieldsSet,
		allFields,
		setFieldsSet
	]);
	const allFieldIds = allFields.map((fv) => fv?.field?.id).filter((id) => !!id);
	const pinnedFieldIdSet = new Set(pinnedFields?.map((pf) => pf.field.id).filter((id) => !!id) ?? []);
	const visibleFieldValues = allFields.map((fieldValue) => {
		if (!fieldValue || !fieldValue.field || !fieldValue.field.id) return null;
		if (fieldValue.field === void 0 || fieldValue.field.dataType === void 0) return null;
		const isPinned = pinnedFields?.some((pf) => pf.field.id === fieldValue.field.id) || false;
		return getIssueFieldEditor({
			errorPresent,
			setErrorPresent: (fieldId, present) => setErrorPresent((prev) => ({
				...prev,
				[fieldId]: present
			})),
			fieldValue,
			readonly: readonly || !data.viewerCanSetFields,
			onCommit: (fieldId, value) => onCommitField(fieldId, fieldValue.field.dataType, value),
			className: getPinnedFieldClassName(isPinned, animatePinned, getPinnedFieldPosition(fieldValue.field.id, pinnedFieldIdSet, allFieldIds))
		});
	}).filter(Boolean);
	return /* @__PURE__ */ jsx(Section, {
		sectionHeader: /* @__PURE__ */ jsxs("div", {
			className: FieldsSection_module_default.sectionHeaderWrapper,
			children: [/* @__PURE__ */ jsx(Heading$2, {
				as: "h3",
				className: FieldsSection_module_default.compactSectionHeader,
				children: "Fields"
			}), /* @__PURE__ */ jsx(Link, {
				href: "https://github.com/orgs/community/discussions/189141",
				target: "_blank",
				rel: "noopener noreferrer",
				className: FieldsSection_module_default.giveFeedbackLink,
				children: "Give feedback"
			})]
		}),
		children: visibleFieldValues.length > 0 ? /* @__PURE__ */ jsx(Fragment$1, { children: visibleFieldValues }) : /* @__PURE__ */ jsx("span", {
			className: FieldsSection_module_default.compactSectionEmptyText,
			children: LABELS$1.noPinnedFieldsMessage(data.issueType?.name)
		})
	});
}
IssueFields.displayName = "IssueFields";
var node$46 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "LabelsSectionFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "title",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "body",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "login",
						"storageKey": null
					}],
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isArchived",
					"storageKey": null
				}
			],
			"storageKey": null
		},
		{
			"args": null,
			"kind": "FragmentSpread",
			"name": "LabelsSectionAssignedLabels"
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanLabel",
			"storageKey": null
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$46.hash = "89d173296b36dd6c47d64eaffcd8fa74";
var node$45 = (function() {
	var v0 = [
		{
			"defaultValue": 100,
			"kind": "LocalArgument",
			"name": "assignedLabelPageSize"
		},
		{
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "cursor"
		},
		{
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "id"
		}
	], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v4 = [
		{
			"kind": "Variable",
			"name": "after",
			"variableName": "cursor"
		},
		{
			"kind": "Variable",
			"name": "first",
			"variableName": "assignedLabelPageSize"
		},
		{
			"kind": "Literal",
			"name": "orderBy",
			"value": {
				"direction": "ASC",
				"field": "NAME"
			}
		}
	];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "LabelsSectionAssignedLabelsQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"args": [{
						"kind": "Variable",
						"name": "assignedLabelPageSize",
						"variableName": "assignedLabelPageSize"
					}, {
						"kind": "Variable",
						"name": "cursor",
						"variableName": "cursor"
					}],
					"kind": "FragmentSpread",
					"name": "LabelsSectionAssignedLabels"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "LabelsSectionAssignedLabelsQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					v3,
					{
						"kind": "InlineFragment",
						"selections": [
							{
								"alias": null,
								"args": v4,
								"concreteType": "LabelConnection",
								"kind": "LinkedField",
								"name": "labels",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "LabelEdge",
									"kind": "LinkedField",
									"name": "edges",
									"plural": true,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": "Label",
										"kind": "LinkedField",
										"name": "node",
										"plural": false,
										"selections": [
											v3,
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "color",
												"storageKey": null
											},
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "name",
												"storageKey": null
											},
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "nameHTML",
												"storageKey": null
											},
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "description",
												"storageKey": null
											},
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "url",
												"storageKey": null
											},
											v2
										],
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "cursor",
										"storageKey": null
									}],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"concreteType": "PageInfo",
									"kind": "LinkedField",
									"name": "pageInfo",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "endCursor",
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "hasNextPage",
										"storageKey": null
									}],
									"storageKey": null
								}],
								"storageKey": null
							},
							{
								"alias": null,
								"args": v4,
								"filters": ["orderBy"],
								"handle": "connection",
								"key": "MetadataSectionAssignedLabels_labels",
								"kind": "LinkedHandle",
								"name": "labels"
							},
							{
								"kind": "TypeDiscriminator",
								"abstractKey": "__isNode"
							}
						],
						"type": "Labelable",
						"abstractKey": "__isLabelable"
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d103ad1af39cfc73beab26bc9a07c330",
			"metadata": {},
			"name": "LabelsSectionAssignedLabelsQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$45.hash = "20f7e48e94311f48bdecc097fbeb646a";
var node$44 = (function() {
	var v0 = ["labels"], v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [{
			"defaultValue": 100,
			"kind": "LocalArgument",
			"name": "assignedLabelPageSize"
		}, {
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "cursor"
		}],
		"kind": "Fragment",
		"metadata": {
			"connection": [{
				"count": "assignedLabelPageSize",
				"cursor": "cursor",
				"direction": "forward",
				"path": v0
			}],
			"refetch": {
				"connection": {
					"forward": {
						"count": "assignedLabelPageSize",
						"cursor": "cursor"
					},
					"backward": null,
					"path": v0
				},
				"fragmentPathInResult": ["node"],
				"operation": node$45,
				"identifierInfo": {
					"identifierField": "id",
					"identifierQueryVariableName": "id"
				}
			}
		},
		"name": "LabelsSectionAssignedLabels",
		"selections": [{
			"alias": "labels",
			"args": [{
				"kind": "Literal",
				"name": "orderBy",
				"value": {
					"direction": "ASC",
					"field": "NAME"
				}
			}],
			"concreteType": "LabelConnection",
			"kind": "LinkedField",
			"name": "__MetadataSectionAssignedLabels_labels_connection",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "LabelEdge",
				"kind": "LinkedField",
				"name": "edges",
				"plural": true,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Label",
					"kind": "LinkedField",
					"name": "node",
					"plural": false,
					"selections": [
						v1,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "color",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "name",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "nameHTML",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "description",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "url",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						}
					],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "cursor",
					"storageKey": null
				}],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": "PageInfo",
				"kind": "LinkedField",
				"name": "pageInfo",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "endCursor",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "hasNextPage",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": "__MetadataSectionAssignedLabels_labels_connection(orderBy:{\"direction\":\"ASC\",\"field\":\"NAME\"})"
		}, {
			"kind": "InlineFragment",
			"selections": [v1],
			"type": "Node",
			"abstractKey": "__isNode"
		}],
		"type": "Labelable",
		"abstractKey": "__isLabelable"
	};
})();
node$44.hash = "20f7e48e94311f48bdecc097fbeb646a";
var node$43 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 100
	}, {
		"kind": "Literal",
		"name": "orderBy",
		"value": {
			"direction": "ASC",
			"field": "NAME"
		}
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "setLabelsForLabelableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "SetLabelsForLabelablePayload",
				"kind": "LinkedField",
				"name": "setLabelsForLabelable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "labelableRecord",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "LabelsSectionAssignedLabels"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "setLabelsForLabelableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "SetLabelsForLabelablePayload",
				"kind": "LinkedField",
				"name": "setLabelsForLabelable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "labelableRecord",
					"plural": false,
					"selections": [
						v2,
						{
							"kind": "TypeDiscriminator",
							"abstractKey": "__isLabelable"
						},
						{
							"alias": null,
							"args": v3,
							"concreteType": "LabelConnection",
							"kind": "LinkedField",
							"name": "labels",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "LabelEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "Label",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v4,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "color",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "name",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "nameHTML",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "description",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "url",
											"storageKey": null
										},
										v2
									],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "cursor",
									"storageKey": null
								}],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"concreteType": "PageInfo",
								"kind": "LinkedField",
								"name": "pageInfo",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "endCursor",
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasNextPage",
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "labels(first:100,orderBy:{\"direction\":\"ASC\",\"field\":\"NAME\"})"
						},
						{
							"alias": null,
							"args": v3,
							"filters": ["orderBy"],
							"handle": "connection",
							"key": "MetadataSectionAssignedLabels_labels",
							"kind": "LinkedHandle",
							"name": "labels"
						},
						{
							"kind": "InlineFragment",
							"selections": [v4],
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "ce4e6c29b102596a5c1e65c7da660aef",
			"metadata": {},
			"name": "setLabelsForLabelableRelayMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$43.hash = "f0eeb3a48d277042e107513ab4ed8f62";
function commitSetLabelsForLabelableMutation({ environment, input: { labelableId, labels, labelableTypeName }, clientMutationId, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$43,
		variables: { input: {
			labelableId,
			labelIds: labels.map((a) => a.id),
			clientMutationId
		} },
		optimisticResponse: { setLabelsForLabelable: { labelableRecord: {
			__typename: labelableTypeName,
			__isNode: "true",
			__isLabelable: "true",
			id: labelableId,
			labels: {
				pageInfo: {
					hasNextPage: false,
					endCursor: null
				},
				edges: labels.map((a) => ({
					cursor: a.id,
					node: {
						__typename: "Label",
						id: a.id,
						name: a.name,
						nameHTML: a.nameHTML,
						color: a.color,
						url: a.url,
						description: a.description
					}
				}))
			}
		} } },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var node$42 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 100
	}, {
		"kind": "Literal",
		"name": "orderBy",
		"value": {
			"direction": "ASC",
			"field": "NAME"
		}
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateLabelsForLabelableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateLabelsForLabelablePayload",
				"kind": "LinkedField",
				"name": "updateLabelsForLabelable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "labelable",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "LabelsSectionAssignedLabels"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateLabelsForLabelableRelayMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateLabelsForLabelablePayload",
				"kind": "LinkedField",
				"name": "updateLabelsForLabelable",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "labelable",
					"plural": false,
					"selections": [
						v2,
						{
							"kind": "TypeDiscriminator",
							"abstractKey": "__isLabelable"
						},
						{
							"alias": null,
							"args": v3,
							"concreteType": "LabelConnection",
							"kind": "LinkedField",
							"name": "labels",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "LabelEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "Label",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v4,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "color",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "name",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "nameHTML",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "description",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "url",
											"storageKey": null
										},
										v2
									],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "cursor",
									"storageKey": null
								}],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"concreteType": "PageInfo",
								"kind": "LinkedField",
								"name": "pageInfo",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "endCursor",
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasNextPage",
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "labels(first:100,orderBy:{\"direction\":\"ASC\",\"field\":\"NAME\"})"
						},
						{
							"alias": null,
							"args": v3,
							"filters": ["orderBy"],
							"handle": "connection",
							"key": "MetadataSectionAssignedLabels_labels",
							"kind": "LinkedHandle",
							"name": "labels"
						},
						{
							"kind": "InlineFragment",
							"selections": [v4],
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d1b4e5c8f6c37b19f17a1d33ab76d991",
			"metadata": {},
			"name": "updateLabelsForLabelableRelayMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$42.hash = "450aaaa7e561ede05f9fc306800eb902";
/**
* Computes the diff between initial and selected labels
*/ function computeLabelDiff(initialLabels, selectedLabels) {
	const initialIds = new Set(initialLabels.map((l) => l.id));
	const selectedIds = new Set(selectedLabels.map((l) => l.id));
	return {
		labelsToAdd: selectedLabels.filter((label) => !initialIds.has(label.id)),
		labelsToRemove: initialLabels.filter((label) => !selectedIds.has(label.id))
	};
}
/**
* Updates labels on a labelable (Issue or PullRequest) using diff-based approach.
* This mutation is safer for concurrent edits as it only adds/removes specific labels
* rather than replacing the entire label set.
*/ function commitUpdateLabelsForLabelableMutation({ environment, input: { labelableId, labelsToAdd, labelsToRemove, labelableTypeName }, clientMutationId, onError, onCompleted, expectedFinalLabels }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$42,
		variables: { input: {
			labelableId,
			addLabelIds: labelsToAdd.map((l) => l.id),
			removeLabelIds: labelsToRemove.map((l) => l.id),
			clientMutationId
		} },
		optimisticResponse: { updateLabelsForLabelable: { labelable: {
			__typename: labelableTypeName,
			__isNode: "true",
			__isLabelable: "true",
			id: labelableId,
			labels: {
				pageInfo: {
					hasNextPage: false,
					endCursor: null
				},
				edges: expectedFinalLabels.map((a) => ({
					cursor: a.id,
					node: {
						__typename: "Label",
						id: a.id,
						name: a.name,
						nameHTML: a.nameHTML,
						color: a.color,
						url: a.url,
						description: a.description
					}
				}))
			}
		} } },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var LabelsList_module_default = {
	labelDescriptionTooltip: "LabelsList-module_0r7TjG_labelDescriptionTooltip",
	labelLink: "LabelsList-module_0r7TjG_labelLink",
	labelsListContainer: "LabelsList-module_0r7TjG_labelsListContainer"
};
/**
*
* A list of label tokens sorted by name.
* This component is used in the Issues and Pull Requests sidebars.
* If we find either one needs to diverge too much we should consider
* making two separate components instead of trying to make this one fit both.
*
*/
function LabelsList(t0) {
	const $ = c(11);
	const { labels, testId, onDelete, emptyText: t1 } = t0;
	const emptyText = t1 === void 0 ? "No labels" : t1;
	const { sendAnalyticsEvent } = useAnalytics();
	let t2;
	bb0: {
		if (labels.length === 0 || !labels[0]) {
			t2 = "";
			break bb0;
		}
		let t3;
		if ($[0] !== labels[0].url) {
			t3 = labels[0].url.slice(0, labels[0].url.lastIndexOf("/labels/"));
			$[0] = labels[0].url;
			$[1] = t3;
		} else t3 = $[1];
		t2 = `${t3}/issues`;
	}
	const repoIssuesPath = t2;
	let t3;
	if ($[2] !== repoIssuesPath) {
		t3 = (label) => `${repoIssuesPath}?q=${encodeURIComponent(`state:open label:"${label.name}"`)}`;
		$[2] = repoIssuesPath;
		$[3] = t3;
	} else t3 = $[3];
	const labelIndexUrl = t3;
	let t4;
	if ($[4] !== emptyText || $[5] !== labelIndexUrl || $[6] !== labels || $[7] !== onDelete || $[8] !== sendAnalyticsEvent || $[9] !== testId) {
		t4 = jsx("div", {
			tabIndex: -1,
			"data-testid": testId,
			className: LabelsList_module_default.labelsListContainer,
			children: labels.length > 0 ? [...labels].sort(_temp$10).map((label_0) => jsx(Tooltip, {
				text: label_0.description ?? "",
				type: "description",
				"aria-label": label_0.description ?? "",
				sx: { visibility: label_0.description ? "visible" : "hidden" },
				className: LabelsList_module_default.labelDescriptionTooltip,
				children: jsxs(Link, {
					href: labelIndexUrl(label_0),
					muted: true,
					"aria-describedby": `${label_0.id}-tooltip`,
					className: LabelsList_module_default.labelLink,
					onClick: () => {
						sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_LABEL_CLICK");
					},
					onContextMenu: () => {
						sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_LABEL_RIGHT_CLICK");
					},
					children: [jsx(LabelToken, {
						text: jsx(VerifiedHTMLText, { html: label_0.nameHTML }),
						onDelete: onDelete ? () => onDelete(label_0.id) : void 0,
						fillColor: `#${label_0.color}`,
						style: {
							overflow: "hidden",
							textOverflow: "ellipsis",
							cursor: "pointer",
							maxWidth: "100%"
						}
					}, label_0.id), jsx("span", {
						className: "sr-only",
						id: `${label_0.id}-tooltip`,
						children: label_0.description ?? ""
					})]
				}, label_0.id)
			}, label_0.id)) : emptyText
		});
		$[4] = emptyText;
		$[5] = labelIndexUrl;
		$[6] = labels;
		$[7] = onDelete;
		$[8] = sendAnalyticsEvent;
		$[9] = testId;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
LabelsList.displayName = "LabelsList";
function _temp$10(a, b) {
	return a.name === b.name ? 0 : a.name > b.name ? 1 : -1;
}
var node$41 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "RemoveLabelsFromLabelablePayload",
		"kind": "LinkedField",
		"name": "removeLabelsFromLabelable",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "removeLabelsFromLabelableMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "removeLabelsFromLabelableMutation",
			"selections": v1
		},
		"params": {
			"id": "cce4e0522a0bbf89aa28f9e4da5d7beb",
			"metadata": {},
			"name": "removeLabelsFromLabelableMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$41.hash = "9f3ee532d3745a09f037181e4a226f48";
function commitRemoveLabelsFromLabelable({ environment, input, onError, onCompleted }) {
	const updater = (store) => {
		const connectionId = import_react_relay.ConnectionHandler.getConnectionID(input.labelableId, "MetadataSectionAssignedLabels_labels");
		const connection = store.get(`${connectionId}(orderBy:{"direction":"ASC","field":"NAME"})`);
		if (connection && input.labelIds[0]) import_react_relay.ConnectionHandler.deleteNode(connection, input.labelIds[0]);
	};
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$41,
		variables: { input },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response),
		updater,
		optimisticUpdater: updater
	});
}
var FAVORITE_LABELS_STORAGE_PREFIX = "favorite-labels";
var safeLocalStorage = safeStorage("localStorage", {
	throwQuotaErrorsOnSet: false,
	ttl: 1e3 * 60 * 60 * 24 * 30
});
/**
* Creates a storage key for a specific repository
*/
function createStorageKey(repoNwo) {
	return `${FAVORITE_LABELS_STORAGE_PREFIX}:${repoNwo}`;
}
/**
* Gets the favorite labels storage for a specific repository
*/
function getFavoriteLabelsStorage(repoNwo) {
	const key = createStorageKey(repoNwo);
	const stored = safeLocalStorage.getItem(key);
	if (!stored) return { labels: {} };
	try {
		return JSON.parse(stored);
	} catch {
		return { labels: {} };
	}
}
/**
* Saves favorite labels storage for a specific repository
*/
function saveFavoriteLabelsStorage(repoNwo, storage) {
	const key = createStorageKey(repoNwo);
	try {
		safeLocalStorage.setItem(key, JSON.stringify(storage));
	} catch {}
}
/**
* Records usage for multiple labels
*/
function recordLabelsUsage(repoNwo, labelIds) {
	if (labelIds.length === 0) return;
	const storage = getFavoriteLabelsStorage(repoNwo);
	const now = Date.now();
	for (const labelId of labelIds) {
		const existingEntry = storage.labels[labelId];
		storage.labels[labelId] = {
			labelId,
			count: existingEntry ? existingEntry.count + 1 : 1,
			lastUsed: now
		};
	}
	saveFavoriteLabelsStorage(repoNwo, storage);
}
/**
* Gets the most frequently used labels for a repository
*/
function getMostUsedLabels(repoNwo, days = 10, limit = 4) {
	const storage = getFavoriteLabelsStorage(repoNwo);
	const cutoff = Date.now() - days * 24 * 60 * 60 * 1e3;
	return Object.values(storage.labels).filter((entry) => entry.lastUsed >= cutoff).sort((a, b) => {
		if (a.count !== b.count) return b.count - a.count;
		return b.lastUsed - a.lastUsed;
	}).slice(0, limit);
}
var ReadonlyLabelsSectionHeader = () => /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.labels });
ReadonlyLabelsSectionHeader.displayName = "ReadonlyLabelsSectionHeader";
var LabelsSection = ({ sectionHeader, onDelete, labels }) => {
	return /* @__PURE__ */ jsx(Section, {
		id: `sidebar-labels-section`,
		sectionHeader,
		emptyText: labels.length > 0 ? void 0 : LABELS.emptySections.labels,
		children: /* @__PURE__ */ jsx(LabelsList, {
			labels,
			onDelete,
			testId: TEST_IDS$1.issueLabels
		})
	});
};
LabelsSection.displayName = "LabelsSection";
var CreateIssueLabelsSection = ({ repo, owner, readonly, canCreateLabel, labels, onSelectionChange, ...sharedConfigProps }) => {
	return /* @__PURE__ */ jsx(LabelsSection, {
		sectionHeader: readonly ? /* @__PURE__ */ jsx(ReadonlyLabelsSectionHeader, {}) : /* @__PURE__ */ jsx(LabelPicker, {
			repo,
			owner,
			readonly,
			canCreateLabel,
			labels,
			onSelectionChange,
			showNoMatchItem: true,
			anchorElement: (anchorProps, ref) => /* @__PURE__ */ jsx(SectionHeader, {
				title: LABELS.sectionTitles.labels,
				buttonProps: anchorProps,
				ref
			}),
			...sharedConfigProps
		}),
		labels
	});
};
CreateIssueLabelsSection.displayName = "CreateIssueLabelsSection";
var labelsSectionFragment = node$46;
var LabelsSectionAssignedLabelsFragment = node$44;
function EditIssueLabelsSection(t0) {
	const $ = c(31);
	const { issue, canCreateLabel: t1, onIssueUpdate, insideSidePanel, readonly } = t0;
	const canCreateLabel = t1 === void 0 ? false : t1;
	const { sendAnalyticsEvent } = useAnalytics();
	const data = (0, import_hooks.useFragment)(labelsSectionFragment, issue);
	const { repository: t2 } = data;
	const { owner: t3, name: repo, isArchived: isRepositoryArchived } = t2;
	const { login: owner } = t3;
	const { data: labelDataRaw } = (0, import_hooks.usePaginationFragment)(LabelsSectionAssignedLabelsFragment, data);
	const labelData = labelDataRaw;
	const { id: issueId, viewerCanLabel } = data;
	let t4;
	if ($[0] !== labelData.labels?.edges) {
		t4 = labelData.labels?.edges?.flatMap(_temp$9) || [];
		$[0] = labelData.labels?.edges;
		$[1] = t4;
	} else t4 = $[1];
	const labels = t4;
	const environment = (0, import_hooks.useRelayEnvironment)();
	let t5;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = isFeatureEnabled("issues_react_favorite_labels");
		$[2] = t5;
	} else t5 = $[2];
	const storeFavoriteLabels = t5;
	const useDiffBasedLabelUpdates = useFeatureFlag("issues_diff_based_label_updates");
	const readonlyLabel = readonly || !viewerCanLabel || isRepositoryArchived;
	const { addToast } = useToastContext();
	let t6;
	if ($[3] !== addToast || $[4] !== environment || $[5] !== issueId || $[6] !== labels || $[7] !== onIssueUpdate || $[8] !== owner || $[9] !== repo || $[10] !== useDiffBasedLabelUpdates) {
		t6 = (selectedLabels) => {
			const onSuccess = () => {
				if (storeFavoriteLabels && selectedLabels.length > 0) recordLabelsUsage(`${owner}/${repo}`, selectedLabels.map(_temp2$7));
				onIssueUpdate?.();
			};
			const onErrorHandler = () => addToast({
				type: "error",
				message: ERRORS$2.couldNotUpdateLabels
			});
			if (useDiffBasedLabelUpdates) {
				const { labelsToAdd, labelsToRemove } = computeLabelDiff(labels, selectedLabels);
				if (labelsToAdd.length === 0 && labelsToRemove.length === 0) return;
				const removeIds = new Set(labelsToRemove.map(_temp3$6));
				const currentWithoutRemoved = labels.filter((l_0) => !removeIds.has(l_0.id));
				const existingIds = new Set(currentWithoutRemoved.map(_temp4$3));
				const optimisticLabels = [...currentWithoutRemoved, ...labelsToAdd.filter((l_2) => !existingIds.has(l_2.id))];
				commitUpdateLabelsForLabelableMutation({
					environment,
					input: {
						labelableId: issueId,
						labelsToAdd,
						labelsToRemove,
						labelableTypeName: "Issue"
					},
					expectedFinalLabels: optimisticLabels,
					onError: onErrorHandler,
					onCompleted: onSuccess
				});
			} else commitSetLabelsForLabelableMutation({
				environment,
				input: {
					labelableId: issueId,
					labels: selectedLabels,
					labelableTypeName: "Issue"
				},
				onError: onErrorHandler,
				onCompleted: onSuccess
			});
		};
		$[3] = addToast;
		$[4] = environment;
		$[5] = issueId;
		$[6] = labels;
		$[7] = onIssueUpdate;
		$[8] = owner;
		$[9] = repo;
		$[10] = useDiffBasedLabelUpdates;
		$[11] = t6;
	} else t6 = $[11];
	const onSelectionChanged = t6;
	const isRemoveLabelEnabled = isFeatureEnabled("issues_react_remove_labels_oneclick");
	let t7;
	if ($[12] !== environment || $[13] !== issueId) {
		t7 = (labelId) => {
			commitRemoveLabelsFromLabelable({
				environment,
				input: {
					labelableId: issueId,
					labelIds: [labelId]
				}
			});
		};
		$[12] = environment;
		$[13] = issueId;
		$[14] = t7;
	} else t7 = $[14];
	const onDeleteLabelCallback = t7;
	let t8;
	bb0: {
		if (readonlyLabel) {
			let t9;
			if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
				t9 = jsx(ReadonlyLabelsSectionHeader, {});
				$[15] = t9;
			} else t9 = $[15];
			t8 = t9;
			break bb0;
		}
		let t9;
		if ($[16] !== canCreateLabel || $[17] !== insideSidePanel || $[18] !== labels || $[19] !== onSelectionChanged || $[20] !== owner || $[21] !== readonlyLabel || $[22] !== repo || $[23] !== sendAnalyticsEvent) {
			const favoriteLabelIds = storeFavoriteLabels ? getMostUsedLabels(`${owner}/${repo}`).map(_temp5$1) : [];
			let t10;
			if ($[25] !== sendAnalyticsEvent) {
				t10 = (anchorProps, ref) => jsx(SectionHeader, {
					title: LABELS.sectionTitles.labels,
					buttonProps: {
						...anchorProps,
						onClick: (e_0) => {
							sendAnalyticsEvent("analytics.click", "ISSUE_SIDEBAR_LABELS_SECTION_EDIT_CLICK");
							anchorProps.onClick?.(e_0);
						}
					},
					ref
				});
				$[25] = sendAnalyticsEvent;
				$[26] = t10;
			} else t10 = $[26];
			t9 = jsx(LabelPicker, {
				repo,
				owner,
				readonly: readonlyLabel,
				labels,
				canCreateLabel,
				favoriteLabelIds,
				onSelectionChange: onSelectionChanged,
				anchorElement: t10,
				insidePortal: insideSidePanel,
				showNoMatchItem: true
			});
			$[16] = canCreateLabel;
			$[17] = insideSidePanel;
			$[18] = labels;
			$[19] = onSelectionChanged;
			$[20] = owner;
			$[21] = readonlyLabel;
			$[22] = repo;
			$[23] = sendAnalyticsEvent;
			$[24] = t9;
		} else t9 = $[24];
		t8 = t9;
	}
	const labelSectionHeader = t8;
	const t9 = isRemoveLabelEnabled && !readonlyLabel ? onDeleteLabelCallback : void 0;
	let t10;
	if ($[27] !== labelSectionHeader || $[28] !== labels || $[29] !== t9) {
		t10 = jsx(LabelsSection, {
			sectionHeader: labelSectionHeader,
			onDelete: t9,
			labels
		});
		$[27] = labelSectionHeader;
		$[28] = labels;
		$[29] = t9;
		$[30] = t10;
	} else t10 = $[30];
	return t10;
}
EditIssueLabelsSection.displayName = "EditIssueLabelsSection";
function _temp5$1(entry) {
	return entry.labelId;
}
function _temp4$3(l_1) {
	return l_1.id;
}
function _temp3$6(l) {
	return l.id;
}
function _temp2$7(label) {
	return label.id;
}
function _temp$9(e) {
	return e?.node ? [e?.node] : [];
}
var node$40 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "MilestonesSectionMilestone",
	"selections": [{
		"alias": null,
		"args": null,
		"concreteType": "Milestone",
		"kind": "LinkedField",
		"name": "milestone",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "title",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "closed",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "dueOn",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "progressPercentage",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "closedAt",
				"storageKey": null
			}
		],
		"storageKey": null
	}],
	"type": "Issue",
	"abstractKey": null
};
node$40.hash = "76d2f86529ad47c916131104f23ee735";
var node$39 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "MilestonesSectionFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "login",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"args": null,
			"kind": "FragmentSpread",
			"name": "MilestonesSectionMilestone"
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanSetMilestone",
			"storageKey": null
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$39.hash = "72b43b6f8433e4a47b0321cf2aa3c5ea";
var node$38 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v2 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "UpdateIssuePayload",
		"kind": "LinkedField",
		"name": "updateIssue",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "issue",
			"plural": false,
			"selections": [v1, {
				"alias": null,
				"args": null,
				"concreteType": "Milestone",
				"kind": "LinkedField",
				"name": "milestone",
				"plural": false,
				"selections": [
					v1,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "title",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "closed",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "dueOn",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "progressPercentage",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "url",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "closedAt",
						"storageKey": null
					}
				],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueMilestoneRelayMutation",
			"selections": v2,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueMilestoneRelayMutation",
			"selections": v2
		},
		"params": {
			"id": "15f7936034547bc129d53f9c6b14fba9",
			"metadata": {},
			"name": "updateIssueMilestoneRelayMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$38.hash = "253dc6aa9f06016bb138f16bb1697b39";
function commitUpdateIssueMilestoneMutation({ environment, input: { issueId, milestone, clientMutationId }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$38,
		variables: { input: {
			id: issueId,
			milestoneId: milestone ? milestone.id : null,
			clientMutationId
		} },
		optimisticResponse: { updateIssue: { issue: {
			id: issueId,
			milestone: milestone ? {
				id: milestone.id,
				title: milestone.title,
				closed: milestone.closed,
				dueOn: milestone.dueOn,
				progressPercentage: milestone.progressPercentage,
				url: milestone.url,
				closedAt: milestone.closedAt
			} : null
		} } },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var Milestone_module_default = { hiddenPlaceholder: "Milestone-module_ezNELa_hiddenPlaceholder" };
var ProgressIcon = ({ progress }) => {
	return /* @__PURE__ */ jsxs("svg", {
		role: "presentation",
		width: "16",
		height: "16",
		"data-target": "tracked-issues-progress.progress",
		"data-circumference": "38",
		style: { transform: "rotate(-90deg)" },
		"data-testid": TEST_IDS$1.milestoneProgressIcon,
		children: [
			progress < 1 ? null : /* @__PURE__ */ jsx("path", {
				fillRule: "evenodd",
				clipRule: "evenodd",
				d: "M10.0206 11.1074C9.68518 11.3949 9.18014 11.3561 8.8926 11.0206L5.8926 7.52061C5.62055 7.20322 5.63873 6.72989 5.93432 6.4343L7.43432 4.9343C7.74674 4.62188 8.25327 4.62188 8.56569 4.9343C8.87811 5.24672 8.87811 5.75325 8.56569 6.06567L7.58953 7.04182L10.1074 9.97935C10.3949 10.3148 10.3561 10.8198 10.0206 11.1074Z",
				fill: "var(--fgColor-done, var(--color-done-fg))"
			}),
			/* @__PURE__ */ jsx("circle", {
				stroke: "var(--borderColor-default, var(--color-border-default))",
				strokeWidth: "2",
				fill: "transparent",
				cx: "50%",
				cy: "50%",
				r: "6"
			}),
			/* @__PURE__ */ jsx("circle", {
				style: { transition: "stroke-dashoffset 0.35s" },
				stroke: "var(--fgColor-done, var(--color-done-fg))",
				strokeWidth: "2",
				strokeDasharray: 38,
				strokeDashoffset: 38 - progress * 38,
				strokeLinecap: "round",
				fill: "transparent",
				cx: "50%",
				cy: "50%",
				r: "6"
			})
		]
	});
};
ProgressIcon.displayName = "ProgressIcon";
function Milestone({ milestone, anchorProps }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: milestone ? /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		href: milestone.url || "#",
		target: "_blank",
		"data-testid": TEST_IDS$1.milestoneContainer,
		...anchorProps,
		onClick: noop$1,
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ProgressIcon, { progress: milestone.progressPercentage / 100 }) }),
			milestone.title,
			/* @__PURE__ */ jsx(ActionList.Description, {
				variant: "block",
				children: /* @__PURE__ */ jsx(MilestoneDescription, {
					closed: milestone.closed,
					closedAt: milestone.closedAt,
					progressPercentage: milestone.progressPercentage,
					dueOn: milestone.dueOn,
					showProgressPercentage: true
				})
			})
		]
	}, milestone.id) : /* @__PURE__ */ jsx("div", {
		className: Milestone_module_default.hiddenPlaceholder,
		...anchorProps
	}) });
}
Milestone.displayName = "Milestone";
var ReadonlyMilestonesSectionHeader = () => /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.milestones });
ReadonlyMilestonesSectionHeader.displayName = "ReadonlyMilestonesSectionHeader";
var MilestonesSection = ({ sectionHeader, milestone, sx, className }) => /* @__PURE__ */ jsx(Section, {
	id: `sidebar-milestones-section`,
	sx,
	className,
	sectionHeader,
	emptyText: milestone ? void 0 : LABELS.emptySections.milestones,
	children: /* @__PURE__ */ jsx(ActionList, {
		variant: "full",
		children: /* @__PURE__ */ jsx(Milestone, { milestone })
	})
});
MilestonesSection.displayName = "MilestonesSection";
function CreateIssueMilestonesSection({ milestone, onSelectionChange, viewerCanSetMilestone, canCreateMilestone, className, sx, ...sharedConfigProps }) {
	return /* @__PURE__ */ jsx(MilestonesSection, {
		sx,
		className,
		sectionHeader: !viewerCanSetMilestone ? /* @__PURE__ */ jsx(ReadonlyMilestonesSectionHeader, {}) : /* @__PURE__ */ jsx(MilestonePicker, {
			onSelectionChange: (milestones) => {
				onSelectionChange(milestones?.[0] || null);
			},
			readonly: false,
			canCreateMilestone,
			activeMilestone: milestone,
			anchorElement: (anchorProps, ref) => /* @__PURE__ */ jsx(SectionHeader, {
				title: LABELS.sectionTitles.milestones,
				buttonProps: anchorProps,
				ref
			}),
			showMilestoneDescription: true,
			...sharedConfigProps
		}),
		milestone
	});
}
CreateIssueMilestonesSection.displayName = "CreateIssueMilestonesSection";
var milestonesSectionMilestone = node$40;
var MilestonesSectionFragment = node$39;
function EditIssueMilestonesSection(t0) {
	const $ = c(17);
	const { issue, canCreateMilestone: t1, onIssueUpdate, insideSidePanel, readonly } = t0;
	const canCreateMilestone = t1 === void 0 ? false : t1;
	const data = (0, import_react_relay.useFragment)(MilestonesSectionFragment, issue);
	const { repository: t2, id: issueId, viewerCanSetMilestone } = data;
	const { owner: t3, name: repo } = t2;
	const { login: owner } = t3;
	const { milestone } = (0, import_react_relay.useFragment)(milestonesSectionMilestone, data);
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t4;
	if ($[0] !== addToast || $[1] !== environment || $[2] !== issueId || $[3] !== onIssueUpdate) {
		t4 = (selectedMilestones) => {
			commitUpdateIssueMilestoneMutation({
				environment,
				input: {
					issueId,
					milestone: selectedMilestones.length > 0 ? selectedMilestones.at(-1) : null
				},
				onError: () => addToast({
					type: "error",
					message: ERRORS$2.couldNotUpdateMilestone
				}),
				onCompleted: onIssueUpdate
			});
		};
		$[0] = addToast;
		$[1] = environment;
		$[2] = issueId;
		$[3] = onIssueUpdate;
		$[4] = t4;
	} else t4 = $[4];
	const onSelectionChanged = t4;
	let t5;
	bb0: {
		const readonlyMilestone = readonly || !viewerCanSetMilestone;
		if (readonlyMilestone) {
			let t6;
			if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
				t6 = jsx(ReadonlyMilestonesSectionHeader, {});
				$[5] = t6;
			} else t6 = $[5];
			t5 = t6;
			break bb0;
		}
		const t6 = milestone ?? null;
		let t7;
		if ($[6] !== canCreateMilestone || $[7] !== insideSidePanel || $[8] !== onSelectionChanged || $[9] !== owner || $[10] !== readonlyMilestone || $[11] !== repo || $[12] !== t6) {
			t7 = jsx(MilestonePicker, {
				repo,
				owner,
				onSelectionChange: onSelectionChanged,
				anchorElement: _temp$8,
				readonly: readonlyMilestone,
				canCreateMilestone,
				activeMilestone: t6,
				insidePortal: insideSidePanel,
				showMilestoneDescription: true,
				showNoMatchItem: true
			});
			$[6] = canCreateMilestone;
			$[7] = insideSidePanel;
			$[8] = onSelectionChanged;
			$[9] = owner;
			$[10] = readonlyMilestone;
			$[11] = repo;
			$[12] = t6;
			$[13] = t7;
		} else t7 = $[13];
		t5 = t7;
	}
	const sectionHeader = t5;
	const t6 = milestone ?? null;
	let t7;
	if ($[14] !== sectionHeader || $[15] !== t6) {
		t7 = jsx(MilestonesSection, {
			sectionHeader,
			milestone: t6
		});
		$[14] = sectionHeader;
		$[15] = t6;
		$[16] = t7;
	} else t7 = $[16];
	return t7;
}
EditIssueMilestonesSection.displayName = "EditIssueMilestonesSection";
function _temp$8(anchorProps, ref) {
	return jsx(SectionHeader, {
		title: LABELS.sectionTitles.milestones,
		buttonProps: anchorProps,
		ref
	});
}
var node$37 = (function() {
	var v0 = {
		"count": null,
		"cursor": null,
		"direction": "forward",
		"path": ["projectItems"]
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"concreteType": "Repository",
		"kind": "LinkedField",
		"name": "repository",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "login",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isArchived",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanUpdate",
		"storageKey": null
	}, v5 = {
		"alias": "projectItems",
		"args": [{
			"kind": "Literal",
			"name": "allowSameEnterprise",
			"value": true
		}, {
			"kind": "Variable",
			"name": "allowedOwner",
			"variableName": "allowedOwner"
		}],
		"concreteType": "ProjectV2ItemConnection",
		"kind": "LinkedField",
		"name": "__ProjectSection_projectItems_connection",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "ProjectV2ItemEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2Item",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v3,
					{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ProjectItemSection"
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "ProjectV2",
						"kind": "LinkedField",
						"name": "project",
						"plural": false,
						"selections": [
							v3,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "title",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "closed",
								"storageKey": null
							},
							v1,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "url",
								"storageKey": null
							},
							v4,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "hasReachedItemsLimit",
								"storageKey": null
							}
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					}
				],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "cursor",
				"storageKey": null
			}],
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "PageInfo",
			"kind": "LinkedField",
			"name": "pageInfo",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "endCursor",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "hasNextPage",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	};
	return {
		"argumentDefinitions": [{
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "allowedOwner"
		}],
		"kind": "Fragment",
		"metadata": { "connection": [v0, v0] },
		"name": "ProjectsSectionFragment",
		"selections": [{
			"kind": "InlineFragment",
			"selections": [
				v1,
				v2,
				v3,
				v5,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "viewerCanUpdateMetadata",
					"storageKey": null
				}
			],
			"type": "Issue",
			"abstractKey": null
		}, {
			"kind": "InlineFragment",
			"selections": [
				v1,
				v2,
				v3,
				v5,
				v4
			],
			"type": "PullRequest",
			"abstractKey": null
		}],
		"type": "IssueOrPullRequest",
		"abstractKey": "__isIssueOrPullRequest"
	};
})();
node$37.hash = "aa8eff7cb76d53436c7a694582ac8bfb";
var ERRORS = {
	couldNotUpdateProjects: "Could not update projects",
	projectsUnavailable: "Projects are currently unavailable",
	tryAgainLater: "Please try again later"
};
var node$36 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "connections"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "deletedItemId",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "deleteIssueProjectsMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteProjectV2ItemPayload",
				"kind": "LinkedField",
				"name": "deleteProjectV2Item",
				"plural": false,
				"selections": [v2],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "deleteIssueProjectsMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteProjectV2ItemPayload",
				"kind": "LinkedField",
				"name": "deleteProjectV2Item",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"filters": null,
					"handle": "deleteEdge",
					"key": "",
					"kind": "ScalarHandle",
					"name": "deletedItemId",
					"handleArgs": [{
						"kind": "Variable",
						"name": "connections",
						"variableName": "connections"
					}]
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "cdc2c4b69492faa142269c6a6a60df92",
			"metadata": {},
			"name": "deleteIssueProjectsMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$36.hash = "b546b455603fb197fd8347b4cec2351a";
function commitDeleteIssueProjectsMutation({ environment, connectionId, projectId, itemId, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$36,
		variables: {
			input: {
				itemId,
				projectId
			},
			connections: [connectionId]
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var node$35 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "ProjectItemSection",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isArchived",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2",
				"kind": "LinkedField",
				"name": "project",
				"plural": false,
				"selections": [v0],
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "ProjectItemSectionView"
			}
		],
		"type": "ProjectV2Item",
		"abstractKey": null
	};
})();
node$35.hash = "d514f44f54887c87d0f242aa077953b2";
var ProjectItemSection_module_default = { ProjectItemSectionContainer: "ProjectItemSection-module_tKwHXa_ProjectItemSectionContainer" };
var node$34 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanUpdate",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v7 = [{
		"kind": "Literal",
		"name": "first",
		"value": 50
	}, {
		"kind": "Literal",
		"name": "orderBy",
		"value": {
			"direction": "ASC",
			"field": "POSITION"
		}
	}], v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "dataType",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isIssueField",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "startDate",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "duration",
		"storageKey": null
	}, v14 = [
		v4,
		v6,
		v11,
		v12,
		v13
	], v15 = {
		"alias": null,
		"args": null,
		"concreteType": "ProjectV2IterationFieldConfiguration",
		"kind": "LinkedField",
		"name": "configuration",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "ProjectV2IterationFieldIteration",
			"kind": "LinkedField",
			"name": "iterations",
			"plural": true,
			"selections": v14,
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "ProjectV2IterationFieldIteration",
			"kind": "LinkedField",
			"name": "completedIterations",
			"plural": true,
			"selections": v14,
			"storageKey": null
		}],
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "optionId",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameHTML",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "color",
		"storageKey": null
	}, v19 = [v4], v20 = {
		"kind": "InlineFragment",
		"selections": v19,
		"type": "Node",
		"abstractKey": "__isNode"
	}, v21 = {
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "field",
		"plural": false,
		"selections": [
			v5,
			{
				"kind": "InlineFragment",
				"selections": [v4, v9],
				"type": "ProjectV2Field",
				"abstractKey": null
			},
			v20
		],
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "ProjectItemSectionFieldListQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "ProjectV2",
						"kind": "LinkedField",
						"name": "project",
						"plural": false,
						"selections": [
							v2,
							v3,
							v4
						],
						"storageKey": null
					}, {
						"args": null,
						"kind": "FragmentSpread",
						"name": "ProjectItemSectionFields"
					}],
					"type": "ProjectV2Item",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "ProjectItemSectionFieldListQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v5,
					v4,
					{
						"kind": "InlineFragment",
						"selections": [
							{
								"alias": null,
								"args": null,
								"concreteType": "ProjectV2",
								"kind": "LinkedField",
								"name": "project",
								"plural": false,
								"selections": [
									v2,
									v3,
									v4,
									v6,
									{
										"alias": null,
										"args": v7,
										"concreteType": "ProjectV2FieldConfigurationConnection",
										"kind": "LinkedField",
										"name": "fields",
										"plural": false,
										"selections": [{
											"alias": null,
											"args": null,
											"concreteType": "ProjectV2FieldConfigurationEdge",
											"kind": "LinkedField",
											"name": "edges",
											"plural": true,
											"selections": [{
												"alias": null,
												"args": null,
												"concreteType": null,
												"kind": "LinkedField",
												"name": "node",
												"plural": false,
												"selections": [
													v5,
													{
														"kind": "InlineFragment",
														"selections": [
															v4,
															v8,
															v9,
															v10
														],
														"type": "ProjectV2Field",
														"abstractKey": null
													},
													{
														"kind": "InlineFragment",
														"selections": [
															v4,
															v8,
															v9,
															v10,
															v15
														],
														"type": "ProjectV2IterationField",
														"abstractKey": null
													},
													{
														"kind": "InlineFragment",
														"selections": [
															v4,
															v8,
															v9,
															v10,
															{
																"alias": null,
																"args": null,
																"concreteType": "ProjectV2SingleSelectFieldOption",
																"kind": "LinkedField",
																"name": "options",
																"plural": true,
																"selections": [
																	v4,
																	v16,
																	v9,
																	v17,
																	v18,
																	{
																		"alias": null,
																		"args": null,
																		"kind": "ScalarField",
																		"name": "descriptionHTML",
																		"storageKey": null
																	},
																	{
																		"alias": null,
																		"args": null,
																		"kind": "ScalarField",
																		"name": "description",
																		"storageKey": null
																	}
																],
																"storageKey": null
															}
														],
														"type": "ProjectV2SingleSelectField",
														"abstractKey": null
													},
													v20
												],
												"storageKey": null
											}],
											"storageKey": null
										}],
										"storageKey": "fields(first:50,orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
									}
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isArchived",
								"storageKey": null
							},
							{
								"alias": null,
								"args": v7,
								"concreteType": "ProjectV2ItemFieldValueConnection",
								"kind": "LinkedField",
								"name": "fieldValues",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "ProjectV2ItemFieldValueEdge",
									"kind": "LinkedField",
									"name": "edges",
									"plural": true,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "node",
										"plural": false,
										"selections": [
											v5,
											{
												"kind": "InlineFragment",
												"selections": [
													v4,
													v21,
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "text",
														"storageKey": null
													}
												],
												"type": "ProjectV2ItemFieldTextValue",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v4,
													v21,
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "number",
														"storageKey": null
													}
												],
												"type": "ProjectV2ItemFieldNumberValue",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v4,
													v21,
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "date",
														"storageKey": null
													}
												],
												"type": "ProjectV2ItemFieldDateValue",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v4,
													{
														"alias": null,
														"args": null,
														"concreteType": null,
														"kind": "LinkedField",
														"name": "field",
														"plural": false,
														"selections": [
															v5,
															{
																"kind": "InlineFragment",
																"selections": v19,
																"type": "ProjectV2SingleSelectField",
																"abstractKey": null
															},
															v20
														],
														"storageKey": null
													},
													v16,
													v9,
													v17,
													v18
												],
												"type": "ProjectV2ItemFieldSingleSelectValue",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v4,
													{
														"alias": null,
														"args": null,
														"concreteType": null,
														"kind": "LinkedField",
														"name": "field",
														"plural": false,
														"selections": [
															v5,
															{
																"kind": "InlineFragment",
																"selections": [
																	v4,
																	v9,
																	v15
																],
																"type": "ProjectV2IterationField",
																"abstractKey": null
															},
															v20
														],
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "iterationId",
														"storageKey": null
													},
													v6,
													v11,
													v12,
													v13
												],
												"type": "ProjectV2ItemFieldIterationValue",
												"abstractKey": null
											},
											v20
										],
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "cursor",
										"storageKey": null
									}],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"concreteType": "PageInfo",
									"kind": "LinkedField",
									"name": "pageInfo",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "endCursor",
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "hasNextPage",
										"storageKey": null
									}],
									"storageKey": null
								}],
								"storageKey": "fieldValues(first:50,orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
							},
							{
								"alias": null,
								"args": v7,
								"filters": ["orderBy"],
								"handle": "connection",
								"key": "ProjectItemSection_fieldValues",
								"kind": "LinkedHandle",
								"name": "fieldValues"
							}
						],
						"type": "ProjectV2Item",
						"abstractKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "241d243a15a751aa4668f46296a39636",
			"metadata": {},
			"name": "ProjectItemSectionFieldListQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$34.hash = "b0347ba7355910f2a5163bb08004baef";
var node$33 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "unarchiveProjectItemMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UnarchiveProjectV2ItemPayload",
				"kind": "LinkedField",
				"name": "unarchiveProjectV2Item",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "item",
					"plural": false,
					"selections": [v2],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "unarchiveProjectItemMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UnarchiveProjectV2ItemPayload",
				"kind": "LinkedField",
				"name": "unarchiveProjectV2Item",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "item",
					"plural": false,
					"selections": [v2, {
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "id",
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "1d1e59700f5c9977430696b2338a0674",
			"metadata": {},
			"name": "unarchiveProjectItemMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$33.hash = "774df17c4810f952c016355065fbcd6c";
function commitUnArchiveProjectItem({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$33,
		variables: { input },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var ProjectItemSectionFieldList_module_default = { restoreLink: "ProjectItemSectionFieldList-module_yjLSIW_restoreLink" };
var node$32 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "dataType",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isIssueField",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "ProjectItemSectionFields",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isArchived",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2",
				"kind": "LinkedField",
				"name": "project",
				"plural": false,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "title",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "url",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerCanUpdate",
						"storageKey": null
					},
					{
						"alias": null,
						"args": [{
							"kind": "Literal",
							"name": "first",
							"value": 50
						}, {
							"kind": "Literal",
							"name": "orderBy",
							"value": {
								"direction": "ASC",
								"field": "POSITION"
							}
						}],
						"concreteType": "ProjectV2FieldConfigurationConnection",
						"kind": "LinkedField",
						"name": "fields",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "ProjectV2FieldConfigurationEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [
									{
										"kind": "InlineFragment",
										"selections": [
											v0,
											v1,
											v2,
											v3,
											{
												"args": null,
												"kind": "FragmentSpread",
												"name": "TextFieldConfigFragment"
											},
											{
												"args": null,
												"kind": "FragmentSpread",
												"name": "DateFieldConfigFragment"
											},
											{
												"args": null,
												"kind": "FragmentSpread",
												"name": "NumberFieldConfigFragment"
											}
										],
										"type": "ProjectV2Field",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": [
											v0,
											v1,
											v2,
											v3,
											{
												"args": null,
												"kind": "FragmentSpread",
												"name": "IterationFieldConfigFragment"
											}
										],
										"type": "ProjectV2IterationField",
										"abstractKey": null
									},
									{
										"kind": "InlineFragment",
										"selections": [
											v0,
											v1,
											v2,
											v3,
											{
												"args": null,
												"kind": "FragmentSpread",
												"name": "SingleSelectFieldConfigFragment"
											}
										],
										"type": "ProjectV2SingleSelectField",
										"abstractKey": null
									}
								],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": "fields(first:50,orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
					}
				],
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "ProjectItemSectionFieldsValues"
			}
		],
		"type": "ProjectV2Item",
		"abstractKey": null
	};
})();
node$32.hash = "9e108cec835ef8bbd41e623d8601e11b";
var node$31 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = [v0], v2 = [v0, {
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "field",
		"plural": false,
		"selections": [{
			"kind": "InlineFragment",
			"selections": v1,
			"type": "ProjectV2Field",
			"abstractKey": null
		}],
		"storageKey": null
	}];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": { "connection": [{
			"count": null,
			"cursor": null,
			"direction": "forward",
			"path": ["fieldValues"]
		}] },
		"name": "ProjectItemSectionFieldsValues",
		"selections": [{
			"alias": "fieldValues",
			"args": [{
				"kind": "Literal",
				"name": "orderBy",
				"value": {
					"direction": "ASC",
					"field": "POSITION"
				}
			}],
			"concreteType": "ProjectV2ItemFieldValueConnection",
			"kind": "LinkedField",
			"name": "__ProjectItemSection_fieldValues_connection",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2ItemFieldValueEdge",
				"kind": "LinkedField",
				"name": "edges",
				"plural": true,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "node",
					"plural": false,
					"selections": [
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "ProjectV2ItemFieldTextValue",
							"abstractKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "TextFieldFragment"
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "ProjectV2ItemFieldNumberValue",
							"abstractKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "NumberFieldFragment"
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "ProjectV2ItemFieldDateValue",
							"abstractKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "DateFieldFragment"
						},
						{
							"kind": "InlineFragment",
							"selections": [v0, {
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "field",
								"plural": false,
								"selections": [{
									"kind": "InlineFragment",
									"selections": v1,
									"type": "ProjectV2SingleSelectField",
									"abstractKey": null
								}],
								"storageKey": null
							}],
							"type": "ProjectV2ItemFieldSingleSelectValue",
							"abstractKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SingleSelectFieldFragment"
						},
						{
							"kind": "InlineFragment",
							"selections": [v0, {
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "field",
								"plural": false,
								"selections": [{
									"kind": "InlineFragment",
									"selections": v1,
									"type": "ProjectV2IterationField",
									"abstractKey": null
								}],
								"storageKey": null
							}],
							"type": "ProjectV2ItemFieldIterationValue",
							"abstractKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "IterationFieldFragment"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						}
					],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "cursor",
					"storageKey": null
				}],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": "PageInfo",
				"kind": "LinkedField",
				"name": "pageInfo",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "endCursor",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "hasNextPage",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": "__ProjectItemSection_fieldValues_connection(orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
		}],
		"type": "ProjectV2Item",
		"abstractKey": null
	};
})();
node$31.hash = "6064e6f5025ede2958816599a371f827";
var node$30 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "DateFieldFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "date",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "field",
			"plural": false,
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "DateFieldConfigFragment"
			}],
			"storageKey": null
		}
	],
	"type": "ProjectV2ItemFieldDateValue",
	"abstractKey": null
};
node$30.hash = "77aee2b1b5d211b322b848ac87e2ca19";
var node$29 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "DateFieldConfigFragment",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}],
	"type": "ProjectV2Field",
	"abstractKey": null
};
node$29.hash = "137f1e064b5aa98d4b4aa184ee4db814";
var node$28 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "type",
		"storageKey": null
	}, v4 = [v2], v5 = {
		"alias": null,
		"args": null,
		"concreteType": "ProjectV2",
		"kind": "LinkedField",
		"name": "project",
		"plural": false,
		"selections": v4,
		"storageKey": null
	}, v6 = [{
		"kind": "Literal",
		"name": "name",
		"value": "Status"
	}], v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v8 = {
		"kind": "InlineFragment",
		"selections": [v7],
		"type": "ProjectV2ItemFieldSingleSelectValue",
		"abstractKey": null
	}, v9 = [{
		"kind": "Literal",
		"name": "first",
		"value": 50
	}, {
		"kind": "Literal",
		"name": "orderBy",
		"value": {
			"direction": "ASC",
			"field": "POSITION"
		}
	}], v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v11 = {
		"kind": "InlineFragment",
		"selections": v4,
		"type": "Node",
		"abstractKey": "__isNode"
	}, v12 = {
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "field",
		"plural": false,
		"selections": [
			v10,
			{
				"kind": "InlineFragment",
				"selections": [v2, v7],
				"type": "ProjectV2Field",
				"abstractKey": null
			},
			v11
		],
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "startDate",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "duration",
		"storageKey": null
	}, v17 = [
		v2,
		v13,
		v14,
		v15,
		v16
	];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "clearProjectItemFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ClearProjectV2ItemFieldValuePayload",
				"kind": "LinkedField",
				"name": "clearProjectV2ItemFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "projectV2Item",
					"plural": false,
					"selections": [
						v2,
						v3,
						v5,
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "ProjectItemSectionFieldsValues"
						},
						{
							"alias": null,
							"args": v6,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "fieldValueByName",
							"plural": false,
							"selections": [v8],
							"storageKey": "fieldValueByName(name:\"Status\")"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "clearProjectItemFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ClearProjectV2ItemFieldValuePayload",
				"kind": "LinkedField",
				"name": "clearProjectV2ItemFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "projectV2Item",
					"plural": false,
					"selections": [
						v2,
						v3,
						v5,
						{
							"alias": null,
							"args": v9,
							"concreteType": "ProjectV2ItemFieldValueConnection",
							"kind": "LinkedField",
							"name": "fieldValues",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "ProjectV2ItemFieldValueEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v10,
										{
											"kind": "InlineFragment",
											"selections": [
												v2,
												v12,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "text",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldTextValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v2,
												v12,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "number",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldNumberValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v2,
												v12,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "date",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldDateValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v2,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "field",
													"plural": false,
													"selections": [
														v10,
														{
															"kind": "InlineFragment",
															"selections": v4,
															"type": "ProjectV2SingleSelectField",
															"abstractKey": null
														},
														v11
													],
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "optionId",
													"storageKey": null
												},
												v7,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "nameHTML",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "color",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldSingleSelectValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v2,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "field",
													"plural": false,
													"selections": [
														v10,
														{
															"kind": "InlineFragment",
															"selections": [
																v2,
																v7,
																{
																	"alias": null,
																	"args": null,
																	"concreteType": "ProjectV2IterationFieldConfiguration",
																	"kind": "LinkedField",
																	"name": "configuration",
																	"plural": false,
																	"selections": [{
																		"alias": null,
																		"args": null,
																		"concreteType": "ProjectV2IterationFieldIteration",
																		"kind": "LinkedField",
																		"name": "iterations",
																		"plural": true,
																		"selections": v17,
																		"storageKey": null
																	}, {
																		"alias": null,
																		"args": null,
																		"concreteType": "ProjectV2IterationFieldIteration",
																		"kind": "LinkedField",
																		"name": "completedIterations",
																		"plural": true,
																		"selections": v17,
																		"storageKey": null
																	}],
																	"storageKey": null
																}
															],
															"type": "ProjectV2IterationField",
															"abstractKey": null
														},
														v11
													],
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "iterationId",
													"storageKey": null
												},
												v13,
												v14,
												v15,
												v16
											],
											"type": "ProjectV2ItemFieldIterationValue",
											"abstractKey": null
										},
										v11
									],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "cursor",
									"storageKey": null
								}],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"concreteType": "PageInfo",
								"kind": "LinkedField",
								"name": "pageInfo",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "endCursor",
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasNextPage",
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "fieldValues(first:50,orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
						},
						{
							"alias": null,
							"args": v9,
							"filters": ["orderBy"],
							"handle": "connection",
							"key": "ProjectItemSection_fieldValues",
							"kind": "LinkedHandle",
							"name": "fieldValues"
						},
						{
							"alias": null,
							"args": v6,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "fieldValueByName",
							"plural": false,
							"selections": [
								v10,
								v8,
								v11
							],
							"storageKey": "fieldValueByName(name:\"Status\")"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d132dec069be1a67131a5e271bc909a6",
			"metadata": {},
			"name": "clearProjectItemFieldValueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$28.hash = "1cc97421540c4997953175725e1f92c9";
function clearProjectItemFieldValueOptimistic(store, input) {
	const connectionId = `${import_react_relay.ConnectionHandler.getConnectionID(input.itemId, "ProjectItemSection_fieldValues")}(orderBy:{"direction":"ASC","field":"POSITION"})`;
	const connection = store.get(connectionId);
	if (!connection) return;
	connection.getLinkedRecords("edges")?.map((edge, index) => {
		if (edge?.getLinkedRecord("node")?.getLinkedRecord("field")?.getDataID() === input.fieldId) {
			const updatedEdges = connection.getLinkedRecords("edges") || [];
			updatedEdges.splice(index, 1);
			connection.setLinkedRecords(updatedEdges, "edges");
		}
	});
}
function commitClearProjectItemFieldValueMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$28,
		variables: { input },
		optimisticUpdater: (store) => clearProjectItemFieldValueOptimistic(store, input),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var node$27 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = [{
		"kind": "Literal",
		"name": "name",
		"value": "Status"
	}], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v4 = {
		"kind": "InlineFragment",
		"selections": [v3],
		"type": "ProjectV2ItemFieldSingleSelectValue",
		"abstractKey": null
	}, v5 = [{
		"kind": "Literal",
		"name": "first",
		"value": 50
	}, {
		"kind": "Literal",
		"name": "orderBy",
		"value": {
			"direction": "ASC",
			"field": "POSITION"
		}
	}], v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v8 = [v7], v9 = {
		"kind": "InlineFragment",
		"selections": v8,
		"type": "Node",
		"abstractKey": "__isNode"
	}, v10 = {
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "field",
		"plural": false,
		"selections": [
			v6,
			{
				"kind": "InlineFragment",
				"selections": [v7, v3],
				"type": "ProjectV2Field",
				"abstractKey": null
			},
			v9
		],
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "startDate",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "duration",
		"storageKey": null
	}, v15 = [
		v7,
		v11,
		v12,
		v13,
		v14
	];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateProjectItemFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateProjectV2ItemFieldValuePayload",
				"kind": "LinkedField",
				"name": "updateProjectV2ItemFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "projectV2Item",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ProjectItemSectionFieldsValues"
					}, {
						"alias": null,
						"args": v2,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "fieldValueByName",
						"plural": false,
						"selections": [v4],
						"storageKey": "fieldValueByName(name:\"Status\")"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateProjectItemFieldValueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateProjectV2ItemFieldValuePayload",
				"kind": "LinkedField",
				"name": "updateProjectV2ItemFieldValue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2Item",
					"kind": "LinkedField",
					"name": "projectV2Item",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": v5,
							"concreteType": "ProjectV2ItemFieldValueConnection",
							"kind": "LinkedField",
							"name": "fieldValues",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "ProjectV2ItemFieldValueEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v6,
										{
											"kind": "InlineFragment",
											"selections": [
												v7,
												v10,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "text",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldTextValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v7,
												v10,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "number",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldNumberValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v7,
												v10,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "date",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldDateValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v7,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "field",
													"plural": false,
													"selections": [
														v6,
														{
															"kind": "InlineFragment",
															"selections": v8,
															"type": "ProjectV2SingleSelectField",
															"abstractKey": null
														},
														v9
													],
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "optionId",
													"storageKey": null
												},
												v3,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "nameHTML",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "color",
													"storageKey": null
												}
											],
											"type": "ProjectV2ItemFieldSingleSelectValue",
											"abstractKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												v7,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "field",
													"plural": false,
													"selections": [
														v6,
														{
															"kind": "InlineFragment",
															"selections": [
																v7,
																v3,
																{
																	"alias": null,
																	"args": null,
																	"concreteType": "ProjectV2IterationFieldConfiguration",
																	"kind": "LinkedField",
																	"name": "configuration",
																	"plural": false,
																	"selections": [{
																		"alias": null,
																		"args": null,
																		"concreteType": "ProjectV2IterationFieldIteration",
																		"kind": "LinkedField",
																		"name": "iterations",
																		"plural": true,
																		"selections": v15,
																		"storageKey": null
																	}, {
																		"alias": null,
																		"args": null,
																		"concreteType": "ProjectV2IterationFieldIteration",
																		"kind": "LinkedField",
																		"name": "completedIterations",
																		"plural": true,
																		"selections": v15,
																		"storageKey": null
																	}],
																	"storageKey": null
																}
															],
															"type": "ProjectV2IterationField",
															"abstractKey": null
														},
														v9
													],
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "iterationId",
													"storageKey": null
												},
												v11,
												v12,
												v13,
												v14
											],
											"type": "ProjectV2ItemFieldIterationValue",
											"abstractKey": null
										},
										v9
									],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "cursor",
									"storageKey": null
								}],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"concreteType": "PageInfo",
								"kind": "LinkedField",
								"name": "pageInfo",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "endCursor",
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasNextPage",
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "fieldValues(first:50,orderBy:{\"direction\":\"ASC\",\"field\":\"POSITION\"})"
						},
						{
							"alias": null,
							"args": v5,
							"filters": ["orderBy"],
							"handle": "connection",
							"key": "ProjectItemSection_fieldValues",
							"kind": "LinkedHandle",
							"name": "fieldValues"
						},
						{
							"alias": null,
							"args": v2,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "fieldValueByName",
							"plural": false,
							"selections": [
								v6,
								v4,
								v9
							],
							"storageKey": "fieldValueByName(name:\"Status\")"
						},
						v7
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "8b296fae9f2499af49f72d6df68d6b5c",
			"metadata": {},
			"name": "updateProjectItemFieldValueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$27.hash = "de3a39d4584b64ead2a58f140d26d900";
function updateProjectItemFieldValueOptimistic(store, input) {
	const connectionId = `${import_react_relay.ConnectionHandler.getConnectionID(input.itemId, "ProjectItemSection_fieldValues")}(orderBy:{"direction":"ASC","field":"POSITION"})`;
	const connection = store.get(connectionId);
	if (!connection) return;
	const node = (connection.getLinkedRecords("edges")?.map((edge) => edge.getLinkedRecord("node")) || []).find((cur_node) => {
		if (!cur_node) return false;
		const field = cur_node.getLinkedRecord("field");
		if (!field) return false;
		return field.getDataID() === input.fieldId;
	});
	if (node) switch (node.getType()) {
		case "ProjectV2ItemFieldTextValue":
			node.setValue(input.value.text, "text");
			break;
		case "ProjectV2ItemFieldNumberValue":
			node.setValue(input.value.number, "number");
			break;
		case "ProjectV2ItemFieldDateValue":
			node.setValue(input.value.date, "date");
			break;
		case "ProjectV2ItemFieldSingleSelectValue": {
			if (!input.value.singleSelectOptionId) return;
			const singleSelectOption = store.get(input.value.singleSelectOptionId);
			if (!singleSelectOption) return;
			node.setValue(input.value.singleSelectOptionId, "optionId");
			for (const key of [
				"color",
				"name",
				"nameHTML"
			]) node.setValue(singleSelectOption.getValue(key), key);
			break;
		}
		case "ProjectV2ItemFieldIterationValue": {
			if (!input.value.iterationId) return;
			const iteration = store.get(input.value.iterationId);
			if (!iteration) return;
			node.setValue(input.value.iterationId, "iterationId");
			for (const key of [
				"duration",
				"startDate",
				"title",
				"titleHTML"
			]) node.setValue(iteration.getValue(key), key);
			break;
		}
	}
}
function commitUpdateProjectItemFieldValueMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$27,
		variables: { input },
		optimisticUpdater: (store) => updateProjectItemFieldValueOptimistic(store, input),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var ProjectsSections_module_default = {
	ArchivedLi: "ProjectsSections-module_WjgBHq_ArchivedLi",
	FieldBasisAuto: "ProjectsSections-module_WjgBHq_FieldBasisAuto",
	FieldListInternal: "ProjectsSections-module_WjgBHq_FieldListInternal",
	FieldListLi: "ProjectsSections-module_WjgBHq_FieldListLi",
	FieldListLiText: "ProjectsSections-module_WjgBHq_FieldListLiText",
	FieldListUl: "ProjectsSections-module_WjgBHq_FieldListUl",
	FieldWrapperLabel: "ProjectsSections-module_WjgBHq_FieldWrapperLabel",
	ListFieldWrapper: "ProjectsSections-module_WjgBHq_ListFieldWrapper",
	ListFieldWrapperText: "ProjectsSections-module_WjgBHq_ListFieldWrapperText",
	loading: "ProjectsSections-module_WjgBHq_loading",
	projectFieldMetadataContainer: "ProjectsSections-module_WjgBHq_projectFieldMetadataContainer"
};
var FieldWrapper_module_default = {
	fieldContentContainer: "FieldWrapper-module_VKBLmW_fieldContentContainer",
	fieldItemError: "FieldWrapper-module_VKBLmW_fieldItemError",
	fieldPlaceholderText: "FieldWrapper-module_VKBLmW_fieldPlaceholderText",
	fieldValueText: "FieldWrapper-module_VKBLmW_fieldValueText",
	metadataFieldButton: "FieldWrapper-module_VKBLmW_metadataFieldButton"
};
function ProjectFieldDisplayContent({ children, isStatusField, name }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: isStatusField ? /* @__PURE__ */ jsx("div", {
		className: FieldWrapper_module_default.fieldContentContainer,
		children
	}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		className: IssueFieldItem_module_default.issueFieldLabel,
		children: name
	}), /* @__PURE__ */ jsx(Fragment$1, { children })] }) });
}
ProjectFieldDisplayContent.displayName = "ProjectFieldDisplayContent";
function ProjectFieldDisplay({ children, onClick, anchorProps, readOnly, isStatusField = false, isEditing = false, placeholder, name, ref }) {
	const btnStyles = isStatusField ? FieldWrapper_module_default.metadataFieldButton : clsx(ProjectsSections_module_default.projectFieldMetadataContainer, IssueFieldItem_module_default.issueFieldFormWrapper, !readOnly && IssueFieldItem_module_default.issueFieldFormWrapperClickable, isEditing && IssueFieldItem_module_default.isEditing);
	return readOnly ? /* @__PURE__ */ jsx("div", {
		className: btnStyles,
		children: /* @__PURE__ */ jsx(ProjectFieldDisplayContent, {
			isStatusField,
			name,
			children
		})
	}) : /* @__PURE__ */ jsx("button", {
		ref,
		type: "button",
		"aria-label": placeholder,
		onClick: readOnly ? noop$1 : onClick,
		className: btnStyles,
		...anchorProps,
		children: /* @__PURE__ */ jsx(ProjectFieldDisplayContent, {
			isStatusField,
			name,
			children
		})
	});
}
ProjectFieldDisplay.displayName = "ProjectFieldDisplay";
function FieldWrapper({ ref, name, placeholder, value, input, anchorProps, showInput, setShowInput, canUpdate = true, isStatusField = false, onCommit = noop$1, validationMessage, preventSubmit, isClean, setIsClean, shouldRestoreRowFocus = false, setShouldRestoreRowFocus }) {
	const localRef = useRef(null);
	const labelId = useId();
	const buttonRef = useRef(null);
	const handleClick = useCallback((e) => {
		if (!anchorProps && canUpdate) setShowInput(true);
		else if (anchorProps?.onClick) anchorProps.onClick(e);
	}, [
		anchorProps,
		canUpdate,
		setShowInput
	]);
	const handleBlur = useCallback((e_0) => {
		if (!e_0.currentTarget.contains(e_0.relatedTarget)) {
			if (isClean) setShowInput(false);
		}
	}, [isClean, setShowInput]);
	useLayoutEffect(() => {
		if (!showInput && shouldRestoreRowFocus) {
			buttonRef.current?.focus();
			setShouldRestoreRowFocus?.(false);
		}
	}, [
		setShouldRestoreRowFocus,
		shouldRestoreRowFocus,
		showInput
	]);
	return /* @__PURE__ */ jsx("span", {
		ref: ref || localRef,
		className: clsx(isStatusField && ProjectsSections_module_default.ListFieldWrapper),
		children: showInput && canUpdate ? /* @__PURE__ */ jsx("div", {
			onBlur: handleBlur,
			children: /* @__PURE__ */ jsxs(FormControl$1, {
				className: clsx(IssueFieldItem_module_default.issueFieldFormWrapper, IssueFieldItem_module_default.issueFieldFormWrapperClickable, IssueFieldItem_module_default.isEditing),
				children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, {
						id: labelId,
						className: ProjectsSections_module_default.FieldWrapperLabel,
						children: /* @__PURE__ */ jsx("span", {
							className: isStatusField ? clsx(ProjectsSections_module_default.ListFieldWrapperText, ProjectsSections_module_default.FieldBasisAuto) : clsx(IssueFieldItem_module_default.issueFieldLabel),
							children: name
						})
					}),
					input,
					/* @__PURE__ */ jsx(IconButton, {
						"aria-label": LABELS.textEditorUpdateButton,
						size: "small",
						icon: CheckIcon,
						onClick: preventSubmit ? void 0 : () => {
							onCommit();
							setShowInput(false);
							setIsClean?.(true);
							setShouldRestoreRowFocus?.(true);
						},
						inactive: preventSubmit,
						"aria-disabled": preventSubmit,
						className: IssueFieldItem_module_default.issueFieldActionButton
					}),
					validationMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
						variant: "error",
						className: FieldWrapper_module_default.fieldItemError,
						children: validationMessage
					})
				]
			})
		}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [isStatusField ? /* @__PURE__ */ jsx("p", {
			className: isStatusField ? clsx(ProjectsSections_module_default.ListFieldWrapperText, ProjectsSections_module_default.FieldBasisAuto) : clsx(IssueFieldItem_module_default.issueFieldLabel),
			children: name
		}) : null, /* @__PURE__ */ jsx(ProjectFieldDisplay, {
			ref: buttonRef,
			isStatusField,
			anchorProps: {
				...anchorProps,
				"aria-describedby": labelId
			},
			onClick: handleClick,
			readOnly: !canUpdate,
			name,
			isEditing: showInput,
			children: /* @__PURE__ */ jsx("span", {
				className: value ? isStatusField ? FieldWrapper_module_default.fieldValueText : clsx(IssueFieldItem_module_default.issueFieldValueText, IssueFieldItem_module_default.hasValue) : isStatusField ? FieldWrapper_module_default.fieldPlaceholderText : IssueFieldItem_module_default.issueFieldValueText,
				children: value ? value : placeholder
			})
		})] })
	});
}
FieldWrapper.displayName = "FieldWrapper";
var DateFieldFragment = node$30;
var DateFieldConfigFragment = node$29;
function DateField(t0) {
	const $ = c(21);
	const { viewerCanUpdate, itemId, projectId, field, value, onIssueUpdate } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const fieldData = (0, import_react_relay.useFragment)(DateFieldConfigFragment, field);
	const valueData = (0, import_react_relay.useFragment)(DateFieldFragment, value);
	const fieldId = fieldData.id;
	const fieldName = fieldData.name;
	let t1;
	let valueDataAsDate;
	if ($[0] !== valueData) {
		valueDataAsDate = valueData ? new Date(valueData.date) : null;
		t1 = valueDataAsDate ? formatDateString(valueDataAsDate) : "No date";
		$[0] = valueData;
		$[1] = t1;
		$[2] = valueDataAsDate;
	} else {
		t1 = $[1];
		valueDataAsDate = $[2];
	}
	const currentDisplayValue = t1;
	const [currentValue, setCurrentValue] = useState(valueDataAsDate);
	const [showInput, setShowInput] = useState(false);
	let t2;
	if ($[3] !== environment || $[4] !== fieldId || $[5] !== itemId || $[6] !== onIssueUpdate || $[7] !== projectId) {
		t2 = (date) => {
			setCurrentValue(date);
			if (!date) commitClearProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId
				},
				onCompleted: onIssueUpdate
			});
			else commitUpdateProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId,
					value: { date: (/* @__PURE__ */ new Date(date.getTime() - date.getTimezoneOffset() * 6e4)).toISOString().slice(0, 10) }
				},
				onCompleted: onIssueUpdate
			});
		};
		$[3] = environment;
		$[4] = fieldId;
		$[5] = itemId;
		$[6] = onIssueUpdate;
		$[7] = projectId;
		$[8] = t2;
	} else t2 = $[8];
	const onDatePickerChange = t2;
	let t3;
	if ($[9] !== currentDisplayValue || $[10] !== fieldName || $[11] !== showInput) {
		t3 = (anchorProps) => jsx(FieldWrapper, {
			showInput,
			setShowInput,
			anchorProps,
			placeholder: LABELS.emptySections.datePlaceholder,
			value: currentDisplayValue || LABELS.emptySections.noValue(fieldName),
			name: fieldName
		});
		$[9] = currentDisplayValue;
		$[10] = fieldName;
		$[11] = showInput;
		$[12] = t3;
	} else t3 = $[12];
	const renderAnchor = t3;
	if (!viewerCanUpdate) {
		let t4;
		if ($[13] !== currentDisplayValue || $[14] !== fieldName || $[15] !== showInput) {
			t4 = jsx(FieldWrapper, {
				showInput,
				setShowInput,
				placeholder: LABELS.emptySections.noValue(fieldName),
				canUpdate: false,
				name: fieldName,
				value: currentDisplayValue
			});
			$[13] = currentDisplayValue;
			$[14] = fieldName;
			$[15] = showInput;
			$[16] = t4;
		} else t4 = $[16];
		return t4;
	}
	let t4;
	if ($[17] !== currentValue || $[18] !== onDatePickerChange || $[19] !== renderAnchor) {
		t4 = jsx(DatePicker, {
			variant: "single",
			showClearButton: true,
			value: currentValue,
			onChange: onDatePickerChange,
			anchor: renderAnchor
		});
		$[17] = currentValue;
		$[18] = onDatePickerChange;
		$[19] = renderAnchor;
		$[20] = t4;
	} else t4 = $[20];
	return t4;
}
DateField.displayName = "DateField";
var node$26 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IterationFieldFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "iterationId",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "title",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "titleHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "startDate",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "duration",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "field",
			"plural": false,
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "IterationFieldConfigFragment"
			}],
			"storageKey": null
		}
	],
	"type": "ProjectV2ItemFieldIterationValue",
	"abstractKey": null
};
node$26.hash = "57212d5c33092763cd6c9ea8afef0615";
var node$25 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = [{
		"kind": "InlineDataFragmentSpread",
		"name": "IterationFieldIterationFragment",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "title",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "titleHTML",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "startDate",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "duration",
				"storageKey": null
			}
		],
		"args": null,
		"argumentDefinitions": []
	}];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IterationFieldConfigFragment",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2IterationFieldConfiguration",
				"kind": "LinkedField",
				"name": "configuration",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2IterationFieldIteration",
					"kind": "LinkedField",
					"name": "iterations",
					"plural": true,
					"selections": v1,
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2IterationFieldIteration",
					"kind": "LinkedField",
					"name": "completedIterations",
					"plural": true,
					"selections": v1,
					"storageKey": null
				}],
				"storageKey": null
			}
		],
		"type": "ProjectV2IterationField",
		"abstractKey": null
	};
})();
node$25.hash = "1820eb43fb63bb62abf4c8f24979732c";
var node$24 = {
	"kind": "InlineDataFragment",
	"name": "IterationFieldIterationFragment"
};
node$24.hash = "28591c2749a30e9b111acd7e77a057f9";
var IterationItem_module_default = {
	currentIndicator: "IterationItem-module_CNKgRW_currentIndicator",
	iterationDateRange: "IterationItem-module_CNKgRW_iterationDateRange",
	IterationItemContainer: "IterationItem-module_CNKgRW_IterationItemContainer",
	iterationTitleContainer: "IterationItem-module_CNKgRW_iterationTitleContainer"
};
function IterationItem({ startDate, durationInDays, titleHTML }) {
	const now = /* @__PURE__ */ new Date();
	const iterationStartDate = parseISO(startDate);
	const endDate = getIterationEndDate(iterationStartDate, durationInDays);
	const isCurrent = iterationStartDate <= now && now <= endDate;
	const formatDate = (d) => d.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	});
	return /* @__PURE__ */ jsxs("div", {
		className: IterationItem_module_default.IterationItemContainer,
		children: [
			/* @__PURE__ */ jsx("div", {
				className: IterationItem_module_default.iterationTitleContainer,
				children: /* @__PURE__ */ jsx(VerifiedHTMLText, { html: titleHTML })
			}),
			/* @__PURE__ */ jsx(Fragment$1, { children: "• " }),
			/* @__PURE__ */ jsxs("span", {
				className: IterationItem_module_default.iterationDateRange,
				children: [
					`${formatDate(iterationStartDate)} - ${formatDate(endDate)}`,
					" ",
					isCurrent && /* @__PURE__ */ jsx(Fragment$1, { children: "• " })
				]
			}),
			isCurrent && /* @__PURE__ */ jsx("span", {
				className: IterationItem_module_default.currentIndicator,
				children: "Current"
			})
		]
	});
}
IterationItem.displayName = "IterationItem";
function getIterationEndDate(iterationStartDate, durationInDays) {
	return new Date(iterationStartDate.getTime() + (durationInDays - 1) * 24 * 60 * 60 * 1e3);
}
var IterationFieldFragment = node$26;
var IterationFieldConfigFragment = node$25;
var IterationFieldIterationFragment = node$24;
var completedGroup = {
	groupId: "completed",
	header: {
		title: "Completed",
		variant: "filled"
	}
};
var activeGroup = {
	groupId: "active",
	header: {
		title: "Active",
		variant: "filled"
	}
};
function IterationField(t0) {
	const $ = c(42);
	const { viewerCanUpdate, itemId, projectId, field, value, onIssueUpdate } = t0;
	const [showInput, setShowInput] = useState(false);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const fieldData = (0, import_react_relay.useFragment)(IterationFieldConfigFragment, field);
	const valueData = (0, import_react_relay.useFragment)(IterationFieldFragment, value);
	const fieldId = fieldData.id;
	const fieldName = fieldData.name;
	const [filter, setFilter] = useState("");
	let t1;
	if ($[0] !== environment || $[1] !== fieldId || $[2] !== itemId || $[3] !== onIssueUpdate || $[4] !== projectId) {
		t1 = (selection) => {
			if (selection.length === 1) commitUpdateProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId,
					value: { iterationId: selection[0].id }
				},
				onCompleted: onIssueUpdate
			});
			else if (selection.length === 0) commitClearProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId
				},
				onCompleted: onIssueUpdate
			});
			setShowInput(false);
		};
		$[0] = environment;
		$[1] = fieldId;
		$[2] = itemId;
		$[3] = onIssueUpdate;
		$[4] = projectId;
		$[5] = t1;
	} else t1 = $[5];
	const onSelectionChange = t1;
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (v) => {
			setFilter(v);
		};
		$[6] = t2;
	} else t2 = $[6];
	const filterItems = t2;
	fieldData.configuration?.completedIterations;
	fieldData.configuration?.iterations;
	let t3;
	if ($[7] !== fieldData.configuration?.completedIterations || $[8] !== fieldData.configuration?.iterations || $[9] !== filter) {
		bb0: {
			const iterationsData = (fieldData.configuration?.iterations || []).concat(fieldData.configuration?.completedIterations || []).map(_temp$7);
			if (!filter) {
				t3 = iterationsData;
				break bb0;
			}
			let t4;
			if ($[11] !== filter) {
				t4 = (l) => l.title.toLowerCase().indexOf(filter.toLowerCase()) >= 0;
				$[11] = filter;
				$[12] = t4;
			} else t4 = $[12];
			t3 = iterationsData.filter(t4);
		}
		$[7] = fieldData.configuration?.completedIterations;
		$[8] = fieldData.configuration?.iterations;
		$[9] = filter;
		$[10] = t3;
	} else t3 = $[10];
	const items = t3;
	let t4;
	if ($[13] !== fieldData.configuration?.completedIterations) {
		t4 = () => {
			const iterations_0 = fieldData.configuration?.completedIterations || [];
			return new Set(iterations_0.map(_temp2$6));
		};
		$[13] = fieldData.configuration?.completedIterations;
		$[14] = t4;
	} else t4 = $[14];
	fieldData.configuration?.completedIterations;
	let t5;
	if ($[15] !== t4) {
		t5 = t4();
		$[15] = t4;
		$[16] = t5;
	} else t5 = $[16];
	const completedIds = t5;
	fieldData.configuration?.completedIterations;
	fieldData.configuration?.iterations;
	valueData?.iterationId;
	let t6;
	if ($[17] !== fieldData.configuration?.completedIterations || $[18] !== fieldData.configuration?.iterations || $[19] !== valueData?.iterationId) {
		const activeIterations = fieldData.configuration?.iterations || [];
		const completedIterations = fieldData.configuration?.completedIterations || [];
		const iterationsData_0 = activeIterations.concat(completedIterations).map(_temp3$5);
		let t7;
		if ($[21] !== valueData?.iterationId) {
			t7 = (i_2) => i_2.id === valueData?.iterationId;
			$[21] = valueData?.iterationId;
			$[22] = t7;
		} else t7 = $[22];
		t6 = iterationsData_0.filter(t7);
		$[17] = fieldData.configuration?.completedIterations;
		$[18] = fieldData.configuration?.iterations;
		$[19] = valueData?.iterationId;
		$[20] = t6;
	} else t6 = $[20];
	const selectedItems = t6;
	let t7;
	if ($[23] !== completedIds) {
		t7 = (option) => ({
			id: option.id,
			children: jsx(IterationItem, {
				startDate: option.startDate,
				durationInDays: option.duration,
				titleHTML: option.titleHTML
			}),
			source: option,
			groupId: completedIds.has(option.id) ? completedGroup.groupId : activeGroup.groupId
		});
		$[23] = completedIds;
		$[24] = t7;
	} else t7 = $[24];
	const convertToItemProps = t7;
	let t8;
	if ($[25] !== fieldName || $[26] !== showInput || $[27] !== valueData) {
		t8 = (anchorProps) => jsx(FieldWrapper, {
			showInput,
			setShowInput,
			anchorProps,
			placeholder: LABELS.emptySections.iterationPlaceholder,
			value: valueData ? jsx(IterationItem, {
				startDate: valueData.startDate,
				durationInDays: valueData.duration,
				titleHTML: valueData.titleHTML
			}) : null,
			name: fieldName
		});
		$[25] = fieldName;
		$[26] = showInput;
		$[27] = valueData;
		$[28] = t8;
	} else t8 = $[28];
	const renderAnchor = t8;
	let t9;
	if ($[29] !== completedIds.size) {
		t9 = completedIds.size > 0 ? [activeGroup, completedGroup] : [activeGroup];
		$[29] = completedIds.size;
		$[30] = t9;
	} else t9 = $[30];
	const groups = t9;
	if (!viewerCanUpdate) {
		let t10;
		if ($[31] !== fieldName || $[32] !== showInput || $[33] !== valueData) {
			t10 = jsx(FieldWrapper, {
				showInput,
				setShowInput,
				value: valueData ? jsx(IterationItem, {
					startDate: valueData.startDate,
					durationInDays: valueData.duration,
					titleHTML: valueData.titleHTML
				}) : null,
				placeholder: LABELS.emptySections.noValue(fieldName),
				canUpdate: false,
				name: fieldName
			});
			$[31] = fieldName;
			$[32] = showInput;
			$[33] = valueData;
			$[34] = t10;
		} else t10 = $[34];
		return t10;
	}
	let t10;
	if ($[35] !== convertToItemProps || $[36] !== groups || $[37] !== items || $[38] !== onSelectionChange || $[39] !== renderAnchor || $[40] !== selectedItems) {
		t10 = jsx(ItemPicker, {
			items,
			groups,
			initialSelectedItems: selectedItems,
			filterItems,
			getItemKey: _temp4$2,
			convertToItemProps,
			placeholderText: LABELS.emptySections.iterationFilterPlaceholder,
			selectionVariant: "single",
			onSelectionChange,
			renderAnchor,
			height: "large"
		});
		$[35] = convertToItemProps;
		$[36] = groups;
		$[37] = items;
		$[38] = onSelectionChange;
		$[39] = renderAnchor;
		$[40] = selectedItems;
		$[41] = t10;
	} else t10 = $[41];
	return t10;
}
IterationField.displayName = "IterationField";
function _temp4$2(i_3) {
	return i_3.id;
}
function _temp3$5(i_1) {
	return (0, import_react_relay.readInlineData)(IterationFieldIterationFragment, i_1);
}
function _temp2$6(i_0) {
	return (0, import_react_relay.readInlineData)(IterationFieldIterationFragment, i_0).id;
}
function _temp$7(i) {
	return (0, import_react_relay.readInlineData)(IterationFieldIterationFragment, i);
}
var node$23 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "NumberFieldFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "number",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "field",
			"plural": false,
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "NumberFieldConfigFragment"
			}],
			"storageKey": null
		}
	],
	"type": "ProjectV2ItemFieldNumberValue",
	"abstractKey": null
};
node$23.hash = "ac86c256f18719392417c8d6f6be4c01";
var node$22 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "NumberFieldConfigFragment",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}],
	"type": "ProjectV2Field",
	"abstractKey": null
};
node$22.hash = "aa7c72083a9ec843850d1089ba1ddda3";
var Resources = {
	fieldMustBeANumber: "This field must be a number",
	fieldMustBeBetween: "This value must be between",
	fieldMustBeDate: "This field must be a date",
	fieldValueTooLong: "This value is too long",
	floatingPointValueTooPrecise: "This floating point value is too precise"
};
var MAX_NUMBER_VALUE = 2147483647;
function getNumberFieldValidationMessage(text) {
	const parsed = parseNumber(text);
	if (Number.isNaN(parsed)) return Resources.fieldMustBeANumber;
	if (parsed < -MAX_NUMBER_VALUE || parsed > MAX_NUMBER_VALUE) return `${Resources.fieldMustBeBetween} -${MAX_NUMBER_VALUE} and ${MAX_NUMBER_VALUE}`;
	const decimalPart = text.split(".")[1];
	if (decimalPart && decimalPart.length > 15) return Resources.floatingPointValueTooPrecise;
}
/**
* Scrubs commas from input and returns a number.
* NOTE: This does not support I18n. A more robust solution for number
* formatting will eventually be required.
* @param text - Numeric-like text input
*/
function parseNumber(text) {
	return Number(text.replace(/,/g, ""));
}
var NumberFieldFragment = node$23;
var NumberFieldConfigFragment = node$22;
function NumberField({ viewerCanUpdate, itemId, projectId, field, value, onIssueUpdate }) {
	const [showInput, setShowInput] = useState(false);
	const inputRef = useRef(null);
	const [isClean, setIsClean] = useState(true);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const fieldData = (0, import_react_relay.useFragment)(NumberFieldConfigFragment, field);
	const valueData = (0, import_react_relay.useFragment)(NumberFieldFragment, value);
	const fieldId = fieldData.id;
	const fieldName = fieldData.name;
	const originalValue = valueData?.number?.toString() ?? "";
	const [currentValue, setCurrentValue] = useState(originalValue);
	const [invalidMessage, setInvalidMessage] = useState(void 0);
	const [shouldRestoreRowFocus, setShouldRestoreRowFocus] = useState(false);
	const commitCurrentValue = useCallback(() => {
		if (invalidMessage) {
			setCurrentValue(originalValue);
			setInvalidMessage(void 0);
		} else commitUpdateProjectItemFieldValueMutation({
			environment,
			input: {
				fieldId,
				itemId,
				projectId,
				value: { number: currentValue === "" ? null : parseNumber(currentValue) }
			},
			onCompleted: onIssueUpdate
		});
	}, [
		currentValue,
		environment,
		fieldId,
		invalidMessage,
		itemId,
		onIssueUpdate,
		originalValue,
		projectId
	]);
	const onChange = useCallback((e) => {
		const newValue_0 = e.target.value;
		setInvalidMessage(getNumberFieldValidationMessage(newValue_0));
		setCurrentValue(newValue_0);
		if (newValue_0 === originalValue) setIsClean(true);
		else setIsClean(false);
	}, [originalValue]);
	const onUpdate = useCallback(() => {
		commitCurrentValue();
		setShowInput(false);
		setIsClean(true);
		setShouldRestoreRowFocus(true);
	}, [commitCurrentValue]);
	const onCancel = useCallback(() => {
		if (inputRef.current) {
			setCurrentValue(originalValue);
			inputRef.current.blur();
			setShowInput(false);
			setIsClean(true);
			setShouldRestoreRowFocus(true);
		}
	}, [originalValue]);
	const onKeyDown = useCallback((e_0) => {
		if (e_0.key === "Enter") {
			e_0.preventDefault();
			onUpdate();
		}
		if (e_0.key === "Escape") {
			e_0.stopPropagation();
			onCancel();
		}
	}, [onCancel, onUpdate]);
	const preventSubmit = useMemo(() => !!invalidMessage, [invalidMessage]);
	if (!viewerCanUpdate) return /* @__PURE__ */ jsx(FieldWrapper, {
		showInput,
		setShowInput,
		placeholder: LABELS.emptySections.noValue(fieldName),
		canUpdate: false,
		value: currentValue,
		name: fieldName
	});
	return /* @__PURE__ */ jsx(FieldWrapper, {
		showInput,
		setShowInput,
		value: currentValue,
		name: fieldName,
		placeholder: LABELS.emptySections.numberPlaceholder,
		onCommit: commitCurrentValue,
		validationMessage: invalidMessage,
		preventSubmit,
		isClean,
		setIsClean,
		shouldRestoreRowFocus,
		setShouldRestoreRowFocus,
		input: /* @__PURE__ */ jsx(TextInput$1, {
			"data-testid": "number-field-input",
			placeholder: LABELS.emptySections.numberPlaceholder,
			ref: inputRef,
			size: "small",
			onChange,
			onKeyDown,
			value: currentValue,
			className: IssueFieldTextToken_module_default.issueFieldTextInput,
			onFocus: (event) => event.target.setSelectionRange(event.target.value.length, event.target.value.length),
			inputMode: "numeric",
			autoFocus: true
		})
	});
}
NumberField.displayName = "NumberField";
var node$21 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "SingleSelectFieldFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "optionId",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "nameHTML",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "color",
			"storageKey": null
		}
	],
	"type": "ProjectV2ItemFieldSingleSelectValue",
	"abstractKey": null
};
node$21.hash = "46251798d3a30836a6711ecaa3cc54e8";
var node$20 = {
	"kind": "InlineDataFragment",
	"name": "SingleSelectFieldOptionFragment"
};
node$20.hash = "be640a30fa15271b4fa34e75d3ddb9b1";
var node$19 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "color",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "SingleSelectFieldConfigFragment",
		"selections": [
			v0,
			v1,
			{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2SingleSelectFieldOption",
				"kind": "LinkedField",
				"name": "options",
				"plural": true,
				"selections": [
					{
						"kind": "InlineDataFragmentSpread",
						"name": "SingleSelectFieldOptionFragment",
						"selections": [
							v0,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "optionId",
								"storageKey": null
							},
							v1,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "nameHTML",
								"storageKey": null
							},
							v2,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "descriptionHTML",
								"storageKey": null
							}
						],
						"args": null,
						"argumentDefinitions": []
					},
					v0,
					v1,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "description",
						"storageKey": null
					},
					v2
				],
				"storageKey": null
			}
		],
		"type": "ProjectV2SingleSelectField",
		"abstractKey": null
	};
})();
node$19.hash = "7609e6b1ac2a8d003401b9f85fcd3e61";
var truncatedTokenWithIconStyle = {
	overflow: "hidden",
	cursor: "inherit",
	"> span": {
		overflow: "hidden",
		textOverflow: "ellipsis"
	}
};
var truncatedTokenNoIconStyle = {
	overflow: "hidden",
	textOverflow: "ellipsis",
	display: "inline-flex",
	cursor: "inherit",
	"> span": { verticalAlign: "text-top" }
};
function getTokenStyle(input, withIcon) {
	return withIcon ? truncatedTokenWithIconStyle : truncatedTokenNoIconStyle;
}
var SingleSelectField_module_default = {
	optionContent: "SingleSelectField-module_aBJa5q_optionContent",
	selectedValueContainer: "SingleSelectField-module_aBJa5q_selectedValueContainer",
	statusPlaceholder: "SingleSelectField-module_aBJa5q_statusPlaceholder",
	VerifiedHTMLText: "SingleSelectField-module_aBJa5q_VerifiedHTMLText"
};
var SingleSelectToken_module_default = {
	colorIndicator: "SingleSelectToken-module_cMoqyG_colorIndicator",
	Token: "SingleSelectToken-module_cMoqyG_Token"
};
var SingleSelectToken = (t0) => {
	const $ = c(5);
	const { inputName, inputColor } = t0;
	const color = useNamedColor(inputColor);
	let t1;
	if ($[0] !== color.bg || $[1] !== color.border || $[2] !== color.fg || $[3] !== inputName) {
		t1 = jsx(Token$1, {
			sx: {
				bg: color.bg,
				color: color.fg,
				borderColor: color.border,
				":hover": {
					bg: color.bg,
					color: color.fg,
					borderColor: color.border
				},
				...getTokenStyle(inputName)
			},
			size: "medium",
			text: inputName,
			className: SingleSelectToken_module_default.Token
		});
		$[0] = color.bg;
		$[1] = color.border;
		$[2] = color.fg;
		$[3] = inputName;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
SingleSelectToken.displayName = "SingleSelectToken";
var SingleSelectLeadingVisual = (t0) => {
	const $ = c(3);
	const { inputColor } = t0;
	const { bg, accent } = useNamedColor(inputColor);
	let t1;
	if ($[0] !== accent || $[1] !== bg) {
		t1 = jsx(Box, {
			sx: {
				bg,
				borderColor: accent
			},
			className: SingleSelectToken_module_default.colorIndicator
		});
		$[0] = accent;
		$[1] = bg;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
SingleSelectLeadingVisual.displayName = "SingleSelectLeadingVisual";
var SingleSelectFieldFragment = node$21;
var SingleSelectFieldOptionFragment = node$20;
var SingleSelectFieldConfigFragment = node$19;
function SingleSelectField(t0) {
	const $ = c(33);
	const { viewerCanUpdate, itemId, projectId, field, value, onIssueUpdate, isStatusField } = t0;
	const [showInput, setShowInput] = useState(false);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const fieldData = (0, import_react_relay.useFragment)(SingleSelectFieldConfigFragment, field);
	const valueData = (0, import_react_relay.useFragment)(SingleSelectFieldFragment, value);
	const fieldId = fieldData.id;
	const fieldName = fieldData.name;
	const [filter, setFilter] = useState("");
	let t1;
	if ($[0] !== environment || $[1] !== fieldId || $[2] !== itemId || $[3] !== onIssueUpdate || $[4] !== projectId) {
		t1 = (selection) => {
			if (selection.length === 1) commitUpdateProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId,
					value: { singleSelectOptionId: selection[0].optionId }
				},
				onCompleted: onIssueUpdate
			});
			else if (selection.length === 0) commitClearProjectItemFieldValueMutation({
				environment,
				input: {
					fieldId,
					itemId,
					projectId
				},
				onCompleted: onIssueUpdate
			});
			setShowInput(false);
		};
		$[0] = environment;
		$[1] = fieldId;
		$[2] = itemId;
		$[3] = onIssueUpdate;
		$[4] = projectId;
		$[5] = t1;
	} else t1 = $[5];
	const onSelectionChange = t1;
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (v) => {
			setFilter(v);
		};
		$[6] = t2;
	} else t2 = $[6];
	const filterItems = t2;
	let t3;
	if ($[7] !== fieldData.options || $[8] !== filter) {
		bb0: {
			const optionsData = (fieldData.options || []).map(_temp$6);
			if (!filter) {
				t3 = optionsData;
				break bb0;
			}
			let t4;
			if ($[10] !== filter) {
				t4 = (l) => l.name.toLowerCase().indexOf(filter.toLowerCase()) >= 0;
				$[10] = filter;
				$[11] = t4;
			} else t4 = $[11];
			t3 = optionsData.filter(t4);
		}
		$[7] = fieldData.options;
		$[8] = filter;
		$[9] = t3;
	} else t3 = $[9];
	const items = t3;
	let t4;
	if ($[12] !== fieldData.options || $[13] !== valueData?.optionId) {
		t4 = () => {
			return (fieldData.options || []).map(_temp2$5).filter((i_1) => i_1.optionId === valueData?.optionId);
		};
		$[12] = fieldData.options;
		$[13] = valueData?.optionId;
		$[14] = t4;
	} else t4 = $[14];
	valueData?.optionId;
	let t5;
	if ($[15] !== t4) {
		t5 = t4();
		$[15] = t4;
		$[16] = t5;
	} else t5 = $[16];
	const selectedItems = t5;
	const convertToItemProps = _temp3$4;
	const valueDataColor = valueData?.color;
	const valueDataName = valueData?.name;
	let t6;
	if ($[17] !== fieldName || $[18] !== isStatusField || $[19] !== showInput || $[20] !== valueDataColor || $[21] !== valueDataName) {
		t6 = (anchorProps) => jsx(FieldWrapper, {
			showInput,
			setShowInput,
			name: fieldName,
			isStatusField,
			placeholder: isStatusField ? jsxs("div", {
				className: SingleSelectField_module_default.statusPlaceholder,
				children: [LABELS.emptySections.status, jsx(TriangleDownIcon, {})]
			}) : jsx(Fragment$1, { children: LABELS.emptySections.singleSelectFilterPlaceholder }),
			value: valueDataName && valueDataColor ? jsxs("div", {
				className: SingleSelectField_module_default.selectedValueContainer,
				children: [jsx(SingleSelectToken, {
					inputName: valueDataName,
					inputColor: valueDataColor
				}), isStatusField && jsx(TriangleDownIcon, {})]
			}) : null,
			anchorProps
		});
		$[17] = fieldName;
		$[18] = isStatusField;
		$[19] = showInput;
		$[20] = valueDataColor;
		$[21] = valueDataName;
		$[22] = t6;
	} else t6 = $[22];
	const renderAnchor = t6;
	if (!viewerCanUpdate) {
		let t7;
		if ($[23] !== fieldName || $[24] !== isStatusField || $[25] !== showInput || $[26] !== valueData) {
			t7 = jsx(FieldWrapper, {
				showInput,
				setShowInput,
				canUpdate: false,
				name: fieldName,
				placeholder: LABELS.emptySections.noValue(fieldName),
				value: valueData?.name ? jsx(Token$1, {
					sx: getTokenStyle(valueData.name),
					size: "medium",
					text: valueData.name
				}) : null,
				isStatusField
			});
			$[23] = fieldName;
			$[24] = isStatusField;
			$[25] = showInput;
			$[26] = valueData;
			$[27] = t7;
		} else t7 = $[27];
		return t7;
	}
	let t7;
	if ($[28] !== items || $[29] !== onSelectionChange || $[30] !== renderAnchor || $[31] !== selectedItems) {
		t7 = jsx(ItemPicker, {
			items,
			initialSelectedItems: selectedItems,
			filterItems,
			getItemKey: _temp4$1,
			convertToItemProps,
			placeholderText: LABELS.emptySections.singleSelectFilterPlaceholder,
			selectionVariant: "single",
			onSelectionChange,
			renderAnchor,
			height: "large"
		});
		$[28] = items;
		$[29] = onSelectionChange;
		$[30] = renderAnchor;
		$[31] = selectedItems;
		$[32] = t7;
	} else t7 = $[32];
	return t7;
}
SingleSelectField.displayName = "SingleSelectField";
function _temp4$1(i_2) {
	return i_2.optionId;
}
function _temp3$4(option) {
	return {
		id: option.optionId,
		children: jsxs("div", {
			className: SingleSelectField_module_default.optionContent,
			children: [jsx(VerifiedHTMLText, { html: option.nameHTML }), jsx(VerifiedHTMLText, {
				html: option.descriptionHTML,
				className: SingleSelectField_module_default.VerifiedHTMLText
			})]
		}),
		source: option,
		leadingVisual: () => jsx(SingleSelectLeadingVisual, { inputColor: option.color })
	};
}
function _temp2$5(i_0) {
	return (0, import_react_relay.readInlineData)(SingleSelectFieldOptionFragment, i_0);
}
function _temp$6(i) {
	return (0, import_react_relay.readInlineData)(SingleSelectFieldOptionFragment, i);
}
var node$18 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TextFieldFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "text",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "field",
			"plural": false,
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "TextFieldConfigFragment"
			}],
			"storageKey": null
		}
	],
	"type": "ProjectV2ItemFieldTextValue",
	"abstractKey": null
};
node$18.hash = "69f479d8a39d90ca27cb126efa7b738b";
var node$17 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TextFieldConfigFragment",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}],
	"type": "ProjectV2Field",
	"abstractKey": null
};
node$17.hash = "7fbd4e4b2889e3438c0acaa4655bcc8d";
var TextFieldFragment = node$18;
var TextFieldConfigFragment = node$17;
function TextField({ viewerCanUpdate, itemId, projectId, field, value, onIssueUpdate }) {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const inputRef = useRef(null);
	const fieldData = (0, import_react_relay.useFragment)(TextFieldConfigFragment, field);
	const valueData = (0, import_react_relay.useFragment)(TextFieldFragment, value);
	const fieldId = fieldData.id;
	const fieldName = fieldData.name;
	const [showInput, setShowInput] = useState(false);
	const originalValue = valueData?.text ?? "";
	const [currentValue, setCurrentValue] = useState(originalValue);
	const [isClean, setIsClean] = useState(true);
	const [shouldRestoreRowFocus, setShouldRestoreRowFocus] = useState(false);
	const commitCurrentValue = useCallback(() => {
		commitUpdateProjectItemFieldValueMutation({
			environment,
			input: {
				fieldId,
				itemId,
				projectId,
				value: { text: currentValue }
			},
			onCompleted: onIssueUpdate
		});
	}, [
		environment,
		fieldId,
		itemId,
		projectId,
		currentValue,
		onIssueUpdate
	]);
	const onChange = useCallback((e) => {
		const newValue = e.target.value;
		setCurrentValue(newValue);
		if (newValue === originalValue) setIsClean(true);
		else setIsClean(false);
	}, [originalValue]);
	const onUpdate = useCallback(() => {
		commitCurrentValue();
		setShowInput(false);
		setIsClean(true);
		setShouldRestoreRowFocus(true);
	}, [commitCurrentValue]);
	const onCancel = useCallback(() => {
		if (inputRef.current) {
			setCurrentValue(valueData?.text ?? "");
			inputRef.current.blur();
			setShowInput(false);
			setIsClean(true);
			setShouldRestoreRowFocus(true);
		}
	}, [valueData?.text]);
	const onKeyDown = useCallback((e_0) => {
		if (e_0.key === "Enter") {
			e_0.preventDefault();
			onUpdate();
		}
		if (e_0.key === "Escape") {
			e_0.stopPropagation();
			onCancel();
		}
	}, [onUpdate, onCancel]);
	const [menuOpen, setMenuOpen] = useState(false);
	const anchorRef = useRef(null);
	const linkHandler = useCallback((link) => () => ssrSafeWindow?.open(prefixUrl(link), "_blank", "noreferrer"), []);
	const editHandler = useCallback(() => setShowInput(true), [setShowInput]);
	const clickHandler = useCallback(() => setMenuOpen(true), [setMenuOpen]);
	const linkOnKeyDown = useCallback((e_1) => {
		if (e_1.key === "Enter") {
			e_1.preventDefault();
			clickHandler();
		}
	}, [clickHandler]);
	const linkOnClick = useCallback((e_2) => viewerCanUpdate && e_2.preventDefault(), [viewerCanUpdate]);
	const fragments = useMemo(() => currentValue.split(/(\s+)/), [currentValue]);
	const [currentValueHtml, containsUrl, urls] = useMemo(() => {
		const urlList = [];
		let contains = false;
		return [
			fragments.map((fragment, key) => {
				const prefixedUrl = prefixUrl(sanitizeInput(fragment));
				if (isValidAndSafeUrl(prefixedUrl) && containsSafeContent(prefixedUrl)) {
					contains = true;
					urlList.push(fragment);
					return /* @__PURE__ */ jsx(Link, {
						tabIndex: 0,
						href: prefixUrl(fragment),
						onKeyDown: linkOnKeyDown,
						onClick: linkOnClick,
						target: "_blank",
						children: fragment
					}, `text-field-link-${key}`);
				} else return fragment;
			}),
			contains,
			urlList
		];
	}, [
		fragments,
		linkOnClick,
		linkOnKeyDown
	]);
	const anchorProps = containsUrl ? { onClick: clickHandler } : void 0;
	const actionMenu = /* @__PURE__ */ jsx(ActionMenu, {
		open: menuOpen,
		onOpenChange: (open) => setMenuOpen(open),
		anchorRef,
		children: /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			width: "small",
			children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [urls?.map((url, index) => /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: linkHandler(url),
				role: "button",
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LinkIcon, {}) }), url]
			}, index)), viewerCanUpdate && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: editHandler,
				role: "button",
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PencilIcon, {}) }), "Edit"]
			})] }) })
		})
	});
	if (!viewerCanUpdate) return /* @__PURE__ */ jsx(FieldWrapper, {
		showInput,
		setShowInput,
		placeholder: `No ${fieldName}`,
		canUpdate: false,
		value: currentValue ? currentValueHtml : void 0,
		name: fieldName
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(FieldWrapper, {
		ref: anchorRef,
		value: currentValue ? currentValueHtml : void 0,
		anchorProps,
		name: fieldName,
		placeholder: "Enter text…",
		showInput,
		setShowInput,
		onCommit: commitCurrentValue,
		isClean,
		setIsClean,
		shouldRestoreRowFocus,
		setShouldRestoreRowFocus,
		input: /* @__PURE__ */ jsx(Textarea, {
			"data-testid": "text-field-input",
			placeholder: "Enter text…",
			ref: inputRef,
			resize: "none",
			onChange,
			onKeyDown,
			value: currentValue,
			className: clsx(IssueFieldTextToken_module_default.issueFieldTextInput, IssueFieldTextToken_module_default.issueFieldTextTextarea),
			onFocus: (event) => event.target.setSelectionRange(event.target.value.length, event.target.value.length),
			autoFocus: true
		})
	}), actionMenu] });
}
TextField.displayName = "TextField";
var ProjectItemSectionFieldsFragment = node$32;
function ProjectItemSectionFields(t0) {
	const $ = c(17);
	const { projectItem, onIssueUpdate } = t0;
	const projectItemFields = (0, import_react_relay.useFragment)(ProjectItemSectionFieldsFragment, projectItem);
	const { fieldValues } = (0, import_react_relay.useFragment)(node$31, projectItemFields);
	projectItemFields.project.fields?.edges;
	fieldValues?.edges;
	let t1;
	if ($[0] !== fieldValues?.edges || $[1] !== onIssueUpdate || $[2] !== projectItemFields.id || $[3] !== projectItemFields.isArchived || $[4] !== projectItemFields.project.fields?.edges || $[5] !== projectItemFields.project.id || $[6] !== projectItemFields.project.viewerCanUpdate) {
		let t2;
		if ($[8] !== fieldValues?.edges || $[9] !== onIssueUpdate || $[10] !== projectItemFields.id || $[11] !== projectItemFields.isArchived || $[12] !== projectItemFields.project.id || $[13] !== projectItemFields.project.viewerCanUpdate) {
			t2 = (edge) => {
				if (!edge?.node || edge.node.isIssueField || edge.node.name === "Status") return;
				const field = edge.node;
				const dataType = field.dataType;
				const fieldId = field.id;
				const value = (fieldValues?.edges || []).flatMap(_temp$5).find((e_0) => e_0?.field?.id === fieldId) || null;
				const props = {
					viewerCanUpdate: !projectItemFields.isArchived && projectItemFields.project.viewerCanUpdate,
					itemId: projectItemFields.id,
					projectId: projectItemFields.project.id,
					field,
					value,
					onIssueUpdate
				};
				switch (dataType) {
					case "SINGLE_SELECT": return jsx(SingleSelectField, { ...props }, fieldId);
					case "TEXT": return jsx(TextField, { ...props }, fieldId);
					case "DATE": return jsx(DateField, { ...props }, fieldId);
					case "NUMBER": return jsx(NumberField, { ...props }, fieldId);
					case "ITERATION": return jsx(IterationField, { ...props }, fieldId);
				}
			};
			$[8] = fieldValues?.edges;
			$[9] = onIssueUpdate;
			$[10] = projectItemFields.id;
			$[11] = projectItemFields.isArchived;
			$[12] = projectItemFields.project.id;
			$[13] = projectItemFields.project.viewerCanUpdate;
			$[14] = t2;
		} else t2 = $[14];
		t1 = (projectItemFields?.project.fields?.edges || []).map(t2).filter(_temp2$4);
		$[0] = fieldValues?.edges;
		$[1] = onIssueUpdate;
		$[2] = projectItemFields.id;
		$[3] = projectItemFields.isArchived;
		$[4] = projectItemFields.project.fields?.edges;
		$[5] = projectItemFields.project.id;
		$[6] = projectItemFields.project.viewerCanUpdate;
		$[7] = t1;
	} else t1 = $[7];
	const fields = t1;
	let t2;
	if ($[15] !== fields) {
		t2 = fields.length === 0 ? jsx(Fragment$1, { children: " " }) : jsx("ul", {
			className: clsx(ProjectsSections_module_default.FieldListUl, ProjectsSections_module_default.FieldListInternal),
			children: fields.map(_temp3$3)
		});
		$[15] = fields;
		$[16] = t2;
	} else t2 = $[16];
	return t2;
}
ProjectItemSectionFields.displayName = "ProjectItemSectionFields";
function _temp3$3(field_0, index) {
	return jsx("li", {
		className: ProjectsSections_module_default.FieldListLi,
		children: field_0
	}, `project-field-${index}`);
}
function _temp2$4(i) {
	return i !== void 0;
}
function _temp$5(e) {
	return e?.node ? [e.node] : [];
}
function ProjectItemSectionFieldsLoading() {
	return /* @__PURE__ */ jsx("ul", {
		className: ProjectsSections_module_default.FieldListUl,
		children: /* @__PURE__ */ jsxs("li", {
			className: clsx(ProjectsSections_module_default.FieldListLi, ProjectsSections_module_default.loading),
			children: [
				/* @__PURE__ */ jsx(ProjectFieldLoading, {}),
				/* @__PURE__ */ jsx(ProjectFieldLoading, {}),
				/* @__PURE__ */ jsx(ProjectFieldLoading, {})
			]
		})
	});
}
ProjectItemSectionFieldsLoading.displayName = "ProjectItemSectionFieldsLoading";
function ProjectFieldLoading() {
	return /* @__PURE__ */ jsxs("span", {
		style: {
			display: "flex",
			flexDirection: "row",
			alignItems: "center",
			gap: 8,
			width: "100%",
			marginTop: 2
		},
		children: [/* @__PURE__ */ jsx(IssuesLoadingSkeleton, {
			height: "md",
			width: "40%"
		}), /* @__PURE__ */ jsx(IssuesLoadingSkeleton, {
			height: "md",
			width: "60%"
		})]
	});
}
ProjectFieldLoading.displayName = "ProjectFieldLoading";
function ProjectItemSectionFieldList(props) {
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: /* @__PURE__ */ jsx(ProjectItemSectionFieldsLoading, {}),
		children: /* @__PURE__ */ jsx(ProjectItemSectionFieldListInternal, { ...props })
	});
}
ProjectItemSectionFieldList.displayName = "ProjectItemSectionFieldList";
function ProjectItemSectionFieldListInternal(t0) {
	const $ = c(12);
	const { isArchived, projectItemId, projectId, onIssueUpdate } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	let t1;
	if ($[0] !== projectItemId) {
		t1 = { id: projectItemId };
		$[0] = projectItemId;
		$[1] = t1;
	} else t1 = $[1];
	const { node } = (0, import_react_relay.useLazyLoadQuery)(node$34, t1);
	let t2;
	if ($[2] !== addToast || $[3] !== environment || $[4] !== projectId || $[5] !== projectItemId) {
		t2 = () => {
			commitUnArchiveProjectItem({
				environment,
				input: {
					projectId,
					itemId: projectItemId
				},
				onCompleted: () => {
					addToast({
						type: "success",
						message: LABELS.archivedSuccess
					});
				},
				onError: () => {
					addToast({
						type: "error",
						message: LABELS.archivedError
					});
				}
			});
		};
		$[2] = addToast;
		$[3] = environment;
		$[4] = projectId;
		$[5] = projectItemId;
		$[6] = t2;
	} else t2 = $[6];
	const restore = t2;
	if (!node || !node.project) return null;
	const canRestore = isArchived && node.project.viewerCanUpdate;
	let t3;
	if ($[7] !== canRestore || $[8] !== node || $[9] !== onIssueUpdate || $[10] !== restore) {
		t3 = jsxs(Fragment$1, { children: [canRestore && jsx("ul", {
			className: ProjectsSections_module_default.FieldListUl,
			children: jsx("li", {
				className: ProjectsSections_module_default.ArchivedLi,
				children: jsxs("span", {
					className: ProjectsSections_module_default.FieldListLiText,
					children: [
						LABELS.archivedDescription,
						"\xA0",
						jsx(Link, {
							onClick: restore,
							className: ProjectItemSectionFieldList_module_default.restoreLink,
							children: "Restore"
						})
					]
				})
			})
		}), jsx(ProjectItemSectionFields, {
			onIssueUpdate,
			projectItem: node
		})] });
		$[7] = canRestore;
		$[8] = node;
		$[9] = onIssueUpdate;
		$[10] = restore;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
ProjectItemSectionFieldListInternal.displayName = "ProjectItemSectionFieldListInternal";
var node$16 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = [{
		"kind": "Literal",
		"name": "name",
		"value": "Status"
	}];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "ProjectItemSectionView",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isArchived",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "ProjectV2",
				"kind": "LinkedField",
				"name": "project",
				"plural": false,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "title",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "template",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerCanUpdate",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "url",
						"storageKey": null
					},
					{
						"alias": null,
						"args": v1,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "field",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SingleSelectFieldConfigFragment"
						}],
						"storageKey": "field(name:\"Status\")"
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "fieldValueByName",
				"plural": false,
				"selections": [{
					"args": null,
					"kind": "FragmentSpread",
					"name": "SingleSelectFieldFragment"
				}],
				"storageKey": "fieldValueByName(name:\"Status\")"
			}
		],
		"type": "ProjectV2Item",
		"abstractKey": null
	};
})();
node$16.hash = "7d5cd0d9d7271a8e8f19cce6e01dac52";
function ClosedProjectIcon({ className }) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "16",
		height: "16",
		viewBox: "0 0 16 16",
		fill: "currentColor",
		xmlns: "http://www.w3.org/2000/svg",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ jsx("path", { d: "M14.25 0C15.2165 0 16 0.783502 16 1.75V8.24805C16 8.66226 15.6642 9 15.25 9C14.8358 9 14.5 8.66421 14.5 8.25V6.5H6.5V14.5H7.25C7.66421 14.5 8 14.8358 8 15.25C8 15.6642 7.66317 15.9999 7.24902 16H1.75C0.783501 16 0 15.2165 0 14.25V1.75C0 0.783501 0.783502 0 1.75 0H14.25ZM1.5 14.25C1.5 14.3881 1.61193 14.5 1.75 14.5H5V6.5H1.5V14.25ZM1.75 1.5C1.61193 1.5 1.5 1.61193 1.5 1.75V5H5V1.5H1.75ZM6.5 1.5V5H14.5V1.75C14.5 1.61193 14.3881 1.5 14.25 1.5H6.5Z" }), /* @__PURE__ */ jsx("path", { d: "M15.9625 11.7368C15.9659 11.9311 15.8938 12.1191 15.7613 12.2613L12.2613 15.7613C12.1207 15.9017 11.93 15.9806 11.7313 15.9806C11.5325 15.9806 11.3419 15.9017 11.2013 15.7613L9.20129 13.7613C9.06881 13.6191 8.99669 13.4311 9.00012 13.2368C9.00355 13.0425 9.08226 12.8571 9.21967 12.7197C9.35708 12.5823 9.54247 12.5035 9.73677 12.5001C9.93107 12.4967 10.1191 12.5688 10.2613 12.7013L11.7313 14.1713L14.7013 11.2013C14.8435 11.0688 15.0315 10.9967 15.2258 11.0001C15.4201 11.0035 15.6055 11.0823 15.7429 11.2197C15.8803 11.3571 15.959 11.5425 15.9625 11.7368Z" })]
	});
}
ClosedProjectIcon.displayName = "ClosedProjectIcon";
var ProjectItemSectionView_module_default = {
	closedLabel: "ProjectItemSectionView-module_FGgEDa_closedLabel",
	projectIcon: "ProjectItemSectionView-module_FGgEDa_projectIcon",
	ProjectItemSectionViewContainer: "ProjectItemSectionView-module_FGgEDa_ProjectItemSectionViewContainer",
	projectLink: "ProjectItemSectionView-module_FGgEDa_projectLink",
	projectLinkContainer: "ProjectItemSectionView-module_FGgEDa_projectLinkContainer",
	projectTitleText: "ProjectItemSectionView-module_FGgEDa_projectTitleText",
	statusFieldContainer: "ProjectItemSectionView-module_FGgEDa_statusFieldContainer",
	Truncate: "ProjectItemSectionView-module_FGgEDa_Truncate",
	truncatedProjectTitle: "ProjectItemSectionView-module_FGgEDa_truncatedProjectTitle"
};
function ProjectItemSectionView(t0) {
	const $ = c(18);
	const { projectItem, setOpen, open, onIssueUpdate, isSelectedProject, isProjectClosed } = t0;
	const { id, project, fieldValueByName, isArchived } = (0, import_react_relay.useFragment)(node$16, projectItem);
	let t1;
	if ($[0] !== fieldValueByName || $[1] !== id || $[2] !== isArchived || $[3] !== isProjectClosed || $[4] !== isSelectedProject || $[5] !== onIssueUpdate || $[6] !== open || $[7] !== project.field || $[8] !== project.id || $[9] !== project.template || $[10] !== project.title || $[11] !== project.url || $[12] !== project.viewerCanUpdate || $[13] !== setOpen) {
		const projectIcon = isProjectClosed ? jsx(ClosedProjectIcon, { className: ProjectItemSectionView_module_default.projectIcon }) : project.template ? jsx(ProjectTemplateIcon, {
			className: ProjectItemSectionView_module_default.projectIcon,
			"aria-hidden": "true"
		}) : jsx(TableIcon, {
			className: ProjectItemSectionView_module_default.projectIcon,
			"aria-hidden": "true"
		});
		let t2;
		if ($[15] !== open || $[16] !== setOpen) {
			t2 = () => {
				setOpen(!open);
			};
			$[15] = open;
			$[16] = setOpen;
			$[17] = t2;
		} else t2 = $[17];
		t1 = jsxs("div", {
			className: ProjectItemSectionView_module_default.ProjectItemSectionViewContainer,
			children: [isSelectedProject ? jsxs("span", {
				className: ProjectItemSectionView_module_default.projectTitleText,
				children: [
					projectIcon,
					jsx("span", {
						className: ProjectItemSectionView_module_default.truncatedProjectTitle,
						children: project.title
					}),
					isProjectClosed && jsx("span", {
						className: "sr-only",
						children: "Closed"
					})
				]
			}) : jsx("div", {
				className: ProjectItemSectionView_module_default.projectLinkContainer,
				children: jsxs(Link, {
					href: project.url,
					hoverColor: "accent.fg",
					tabIndex: 0,
					className: ProjectItemSectionView_module_default.projectLink,
					children: [
						projectIcon,
						jsx(Truncate, {
							title: project.title,
							"data-testid": TEST_IDS$2.projectTitle,
							className: ProjectItemSectionView_module_default.Truncate,
							children: project.title
						}),
						isProjectClosed && jsx("span", {
							className: ProjectItemSectionView_module_default.closedLabel,
							children: "Closed"
						})
					]
				})
			}), jsxs("div", {
				className: ProjectItemSectionView_module_default.statusFieldContainer,
				children: [project.field && fieldValueByName !== void 0 && jsx(SingleSelectField, {
					viewerCanUpdate: project.viewerCanUpdate && !isArchived,
					itemId: id,
					projectId: project.id,
					field: project.field,
					value: fieldValueByName,
					onIssueUpdate,
					isStatusField: true
				}), jsx(IconButton, {
					variant: "invisible",
					onClick: t2,
					size: "small",
					icon: !open ? ChevronDownIcon : ChevronUpIcon,
					"aria-label": !open ? LABELS.showMoreProjectFields : LABELS.hideMoreProjectFields,
					"aria-expanded": open
				})]
			})]
		});
		$[0] = fieldValueByName;
		$[1] = id;
		$[2] = isArchived;
		$[3] = isProjectClosed;
		$[4] = isSelectedProject;
		$[5] = onIssueUpdate;
		$[6] = open;
		$[7] = project.field;
		$[8] = project.id;
		$[9] = project.template;
		$[10] = project.title;
		$[11] = project.url;
		$[12] = project.viewerCanUpdate;
		$[13] = setOpen;
		$[14] = t1;
	} else t1 = $[14];
	return t1;
}
ProjectItemSectionView.displayName = "ProjectItemSectionView";
function ProjectItemSection(t0) {
	const $ = c(6);
	const { projectItem, onIssueUpdate, isOpen: t1, isProjectClosed } = t0;
	const isOpen = t1 === void 0 ? false : t1;
	const [open, setOpen] = useState(isOpen);
	const data = (0, import_react_relay.useFragment)(node$35, projectItem);
	let t2;
	if ($[0] !== data || $[1] !== isOpen || $[2] !== isProjectClosed || $[3] !== onIssueUpdate || $[4] !== open) {
		t2 = jsxs("div", {
			className: ProjectItemSection_module_default.ProjectItemSectionContainer,
			children: [jsx(ProjectItemSectionView, {
				projectItem: data,
				open,
				setOpen,
				onIssueUpdate,
				isSelectedProject: isOpen,
				isProjectClosed
			}), open && jsx(ProjectItemSectionFieldList, {
				projectItemId: data.id,
				projectId: data.project.id,
				isArchived: data.isArchived,
				onIssueUpdate
			})]
		});
		$[0] = data;
		$[1] = isOpen;
		$[2] = isProjectClosed;
		$[3] = onIssueUpdate;
		$[4] = open;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
ProjectItemSection.displayName = "ProjectItemSection";
var ProjectsSection_module_default = {
	ActionList_LinkItem: "ProjectsSection-module_rIO9CW_ActionList_LinkItem",
	projectActionList: "ProjectsSection-module_rIO9CW_projectActionList",
	projectItemsContainer: "ProjectsSection-module_rIO9CW_projectItemsContainer",
	toggleProjectsButton: "ProjectsSection-module_rIO9CW_toggleProjectsButton"
};
var MAX_VISIBLE_ITEMS = 5;
var PROJECT_OVERFLOW_CONTAINER_ID = "sidebar-projects-overflow-items";
var ReadonlyProjectsSectionHeader = () => /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.projects });
ReadonlyProjectsSectionHeader.displayName = "ReadonlyProjectsSectionHeader";
var ProjectsSectionHeader = ({ ref, ...props }) => /* @__PURE__ */ jsx(SectionHeader, {
	ref,
	id: props.id,
	title: LABELS.sectionTitles.projects,
	buttonProps: props
});
ProjectsSectionHeader.displayName = "ProjectsSectionHeader";
var ProjectsSection = ({ sectionHeader, hasItems, children }) => {
	return /* @__PURE__ */ jsx(Section, {
		id: `sidebar-projects-section`,
		sectionHeader,
		emptyText: hasItems ? void 0 : LABELS.emptySections.projects,
		children
	});
};
ProjectsSection.displayName = "ProjectsSection";
var ProjectsSectionFallback = () => /* @__PURE__ */ jsx(Section, {
	id: "projects-section-fallback",
	sectionHeader: /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: ERRORS.projectsUnavailable }),
	emptyText: ERRORS.tryAgainLater
});
ProjectsSectionFallback.displayName = "ProjectsSectionFallback";
var CreateIssueProjectsSection = ({ owner, repo, projects, readonly, onSelectionChange, ...sharedConfigProps }) => {
	const headingLabelId = "create-issue-sidebar-projects-section-heading";
	const sectionHeader = readonly ? /* @__PURE__ */ jsx(ReadonlyProjectsSectionHeader, {}) : /* @__PURE__ */ jsx(ProjectPicker, {
		pickerId: "create-issue-projects-picker",
		owner,
		repo,
		selectedProjects: projects,
		readonly,
		onSave: onSelectionChange,
		anchorElement: (props) => /* @__PURE__ */ jsx(ProjectsSectionHeader, {
			...props,
			id: headingLabelId
		}),
		...sharedConfigProps
	});
	return /* @__PURE__ */ jsx(ErrorBoundary, {
		fallback: /* @__PURE__ */ jsx(ProjectsSectionFallback, {}),
		children: /* @__PURE__ */ jsx(ProjectsSection, {
			sectionHeader,
			hasItems: projects.length > 0,
			children: projects.length > 0 && /* @__PURE__ */ jsx(ActionList, {
				"aria-labelledby": headingLabelId,
				variant: "full",
				className: ProjectsSection_module_default.projectActionList,
				children: projects.map((project) => /* @__PURE__ */ jsx(ActionList.LinkItem, {
					href: project.url,
					className: ProjectsSection_module_default.ActionList_LinkItem,
					children: project.title
				}, project.id))
			})
		})
	});
};
CreateIssueProjectsSection.displayName = "CreateIssueProjectsSection";
var projectSectionFragment = node$37;
function EditIssueProjectsSection(props) {
	const $ = c(4);
	const projectsSectionData = (0, import_react_relay.useFragment)(projectSectionFragment, props.issueOrPullRequest);
	if (!projectsSectionData.projectItems) {
		let t0;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t0 = jsx(ProjectsSectionFallback, {});
			$[0] = t0;
		} else t0 = $[0];
		return t0;
	}
	let t0;
	if ($[1] !== projectsSectionData || $[2] !== props) {
		t0 = jsx(EditIssueProjectsSectionInternal, {
			projectsSectionData,
			...props
		});
		$[1] = projectsSectionData;
		$[2] = props;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
EditIssueProjectsSection.displayName = "EditIssueProjectsSection";
var EditIssueProjectsSectionInternal = (t0) => {
	const $ = c(44);
	const { projectsSectionData, allowedProjectOwner, onIssueUpdate, onRemovedFromProject, insideSidePanel, selectedProjectId, readonly } = t0;
	const { addToast } = useToastContext();
	let t1;
	if ($[0] !== projectsSectionData.projectItems?.edges) {
		t1 = (projectsSectionData.projectItems?.edges ?? []).flatMap(_temp$4).filter(_temp2$3);
		$[0] = projectsSectionData.projectItems?.edges;
		$[1] = t1;
	} else t1 = $[1];
	const projectItems = t1;
	let t2;
	if ($[2] !== projectsSectionData.projectItems?.edges) {
		t2 = (projectsSectionData.projectItems?.edges ?? []).flatMap(_temp3$2).filter(_temp4);
		$[2] = projectsSectionData.projectItems?.edges;
		$[3] = t2;
	} else t2 = $[3];
	const closedProjectItems = t2;
	let t3;
	bb0: {
		if (selectedProjectId === void 0) {
			t3 = false;
			break bb0;
		}
		if (closedProjectItems.some((item) => item.project.id === selectedProjectId)) {
			t3 = true;
			break bb0;
		}
		let t4;
		if ($[4] !== projectItems || $[5] !== selectedProjectId) {
			t4 = projectItems.length > MAX_VISIBLE_ITEMS && projectItems.findIndex((item_0) => item_0.project.id === selectedProjectId) >= MAX_VISIBLE_ITEMS;
			$[4] = projectItems;
			$[5] = selectedProjectId;
			$[6] = t4;
		} else t4 = $[6];
		t3 = t4;
	}
	const [showAllProjects, setShowAllProjects] = useState(t3);
	const { viewerCanUpdateMetadata, viewerCanUpdate, repository } = projectsSectionData;
	const readonlyProject = readonly || !(viewerCanUpdateMetadata || viewerCanUpdate) || repository?.isArchived;
	const issueId = projectsSectionData.id || "";
	const hasProjectItems = projectItems.length > 0 || closedProjectItems.length > 0;
	let t4;
	if ($[7] !== allowedProjectOwner || $[8] !== issueId) {
		t4 = import_relay_runtime.ConnectionHandler.getConnectionID(issueId, "ProjectSection_projectItems", {
			allowedOwner: allowedProjectOwner,
			allowSameEnterprise: true
		});
		$[7] = allowedProjectOwner;
		$[8] = issueId;
		$[9] = t4;
	} else t4 = $[9];
	const connectionId = t4;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t5;
	if ($[10] !== addToast || $[11] !== connectionId || $[12] !== environment || $[13] !== issueId || $[14] !== onIssueUpdate || $[15] !== onRemovedFromProject || $[16] !== projectItems || $[17] !== selectedProjectId) {
		t5 = (selectedProjects) => {
			const projectsToAdd = selectedProjects.filter((project) => !projectItems.some((p) => p.project.id === project.id));
			const projectsToRemove = projectItems.filter((project_0) => !selectedProjects.some((p_0) => p_0.id === project_0.project.id));
			let hasError = false;
			for (const project_1 of projectsToAdd) commitUpdateIssueProjectsMutation({
				environment,
				connectionId,
				projectId: project_1.id,
				issueId,
				onError: () => hasError = true,
				onCompleted: onIssueUpdate
			});
			for (const project_2 of projectsToRemove) commitDeleteIssueProjectsMutation({
				environment,
				connectionId,
				projectId: project_2.project.id,
				itemId: project_2.id,
				onError: () => hasError = true,
				onCompleted: () => {
					if (project_2.project.id === selectedProjectId) onRemovedFromProject();
				}
			});
			if (hasError) addToast({
				type: "error",
				message: ERRORS.couldNotUpdateProjects
			});
		};
		$[10] = addToast;
		$[11] = connectionId;
		$[12] = environment;
		$[13] = issueId;
		$[14] = onIssueUpdate;
		$[15] = onRemovedFromProject;
		$[16] = projectItems;
		$[17] = selectedProjectId;
		$[18] = t5;
	} else t5 = $[18];
	const saveProjects = t5;
	let t6;
	if ($[19] !== projectItems) {
		t6 = projectItems.map(_temp5);
		$[19] = projectItems;
		$[20] = t6;
	} else t6 = $[20];
	const selectedProjects_0 = t6;
	let t7;
	bb1: {
		if (!projectsSectionData.repository || readonlyProject) {
			let t8;
			if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
				t8 = jsx(ReadonlyProjectsSectionHeader, {});
				$[21] = t8;
			} else t8 = $[21];
			t7 = t8;
			break bb1;
		}
		const t8 = `edit-issue-projects-picker-${issueId}`;
		let t9;
		if ($[22] !== insideSidePanel || $[23] !== projectsSectionData.repository.name || $[24] !== projectsSectionData.repository.owner.login || $[25] !== readonlyProject || $[26] !== saveProjects || $[27] !== selectedProjects_0 || $[28] !== t8) {
			t9 = jsx(ProjectPicker, {
				pickerId: t8,
				repo: projectsSectionData.repository.name,
				owner: projectsSectionData.repository.owner.login,
				selectedProjects: selectedProjects_0,
				readonly: readonlyProject,
				onSave: saveProjects,
				anchorElement: _temp6,
				insidePortal: insideSidePanel
			});
			$[22] = insideSidePanel;
			$[23] = projectsSectionData.repository.name;
			$[24] = projectsSectionData.repository.owner.login;
			$[25] = readonlyProject;
			$[26] = saveProjects;
			$[27] = selectedProjects_0;
			$[28] = t8;
			$[29] = t9;
		} else t9 = $[29];
		t7 = t9;
	}
	const sectionHeader = t7;
	let t8;
	let t9;
	if ($[30] !== closedProjectItems || $[31] !== hasProjectItems || $[32] !== onIssueUpdate || $[33] !== projectItems || $[34] !== projectsSectionData.number || $[35] !== projectsSectionData.repository || $[36] !== sectionHeader || $[37] !== selectedProjectId || $[38] !== showAllProjects) {
		t9 = Symbol.for("react.early_return_sentinel");
		bb2: {
			const visibleProjects = projectItems.slice(0, MAX_VISIBLE_ITEMS);
			const overflowProjects = projectItems.slice(MAX_VISIBLE_ITEMS);
			const totalHiddenCount = overflowProjects.length + closedProjectItems.length;
			const hasHiddenItems = totalHiddenCount > 0;
			if (!projectsSectionData.repository || !projectsSectionData.number) {
				t9 = null;
				break bb2;
			}
			let t10;
			if ($[41] !== onIssueUpdate || $[42] !== selectedProjectId) {
				t10 = (projectItem_2) => jsx(ProjectItemSection, {
					onIssueUpdate,
					projectItem: projectItem_2,
					isOpen: selectedProjectId === projectItem_2.project.id,
					isProjectClosed: projectItem_2.project.closed
				}, projectItem_2.id);
				$[41] = onIssueUpdate;
				$[42] = selectedProjectId;
				$[43] = t10;
			} else t10 = $[43];
			t8 = jsxs(ProjectsSection, {
				sectionHeader,
				hasItems: hasProjectItems,
				children: [jsxs("div", {
					className: ProjectsSection_module_default.projectItemsContainer,
					children: [
						visibleProjects.map(t10),
						showAllProjects && overflowProjects.length > 0 && jsx("div", {
							id: PROJECT_OVERFLOW_CONTAINER_ID,
							children: overflowProjects.map((projectItem_3) => jsx(ProjectItemSection, {
								onIssueUpdate,
								projectItem: projectItem_3,
								isOpen: selectedProjectId === projectItem_3.project.id,
								isProjectClosed: projectItem_3.project.closed
							}, projectItem_3.id))
						}),
						showAllProjects && closedProjectItems.map((projectItem_4) => jsx(ProjectItemSection, {
							onIssueUpdate,
							projectItem: projectItem_4,
							isOpen: selectedProjectId === projectItem_4.project.id,
							isProjectClosed: projectItem_4.project.closed
						}, projectItem_4.id))
					]
				}), hasHiddenItems && jsx(ButtonComponent, {
					variant: "invisible",
					block: true,
					alignContent: "start",
					trailingVisual: showAllProjects ? ChevronUpIcon : ChevronDownIcon,
					onClick: () => setShowAllProjects(!showAllProjects),
					className: ProjectsSection_module_default.toggleProjectsButton,
					"aria-expanded": showAllProjects,
					"aria-controls": showAllProjects ? PROJECT_OVERFLOW_CONTAINER_ID : void 0,
					size: "small",
					children: showAllProjects ? LABELS.showLessProjects : LABELS.showMoreProjects(totalHiddenCount, closedProjectItems.length)
				})]
			});
		}
		$[30] = closedProjectItems;
		$[31] = hasProjectItems;
		$[32] = onIssueUpdate;
		$[33] = projectItems;
		$[34] = projectsSectionData.number;
		$[35] = projectsSectionData.repository;
		$[36] = sectionHeader;
		$[37] = selectedProjectId;
		$[38] = showAllProjects;
		$[39] = t8;
		$[40] = t9;
	} else {
		t8 = $[39];
		t9 = $[40];
	}
	if (t9 !== Symbol.for("react.early_return_sentinel")) return t9;
	return t8;
};
EditIssueProjectsSectionInternal.displayName = "EditIssueProjectsSectionInternal";
function _temp$4(edge) {
	return edge?.node ? edge?.node : [];
}
function _temp2$3(projectItem) {
	return projectItem.project.closed !== true;
}
function _temp3$2(edge_0) {
	return edge_0?.node ? edge_0?.node : [];
}
function _temp4(projectItem_0) {
	return projectItem_0.project.closed === true;
}
function _temp5(projectItem_1) {
	return projectItem_1.project;
}
function _temp6(props) {
	return jsx(ProjectsSectionHeader, { ...props });
}
function IssueItem(t0) {
	const $ = c(13);
	const { issue, onLinkClick } = t0;
	let t1;
	if ($[0] !== issue.url || $[1] !== onLinkClick) {
		t1 = () => {
			onLinkClick?.(issue.url);
		};
		$[0] = issue.url;
		$[1] = onLinkClick;
		$[2] = t1;
	} else t1 = $[2];
	const handleClick = t1;
	let t2;
	if ($[3] !== issue.state || $[4] !== issue.stateReason) {
		t2 = {
			state: issue.state,
			stateReason: issue.stateReason
		};
		$[3] = issue.state;
		$[4] = issue.stateReason;
		$[5] = t2;
	} else t2 = $[5];
	const { sourceIcon } = useIssueState(t2);
	let t3;
	if ($[6] !== handleClick || $[7] !== issue.number || $[8] !== issue.repository.nameWithOwner || $[9] !== issue.title || $[10] !== issue.url || $[11] !== sourceIcon) {
		const IconComponent = sourceIcon("Issue");
		t3 = jsxs(ActionList.LinkItem, {
			href: issue.url,
			target: "_blank",
			onClick: handleClick,
			children: [
				jsx(ActionList.LeadingVisual, { children: jsx(IconComponent, {}) }),
				jsx("span", {
					className: "markdown-title",
					children: issue.title
				}),
				jsxs(ActionList.Description, {
					variant: "block",
					children: [
						issue.repository.nameWithOwner,
						"#",
						issue.number
					]
				})
			]
		});
		$[6] = handleClick;
		$[7] = issue.number;
		$[8] = issue.repository.nameWithOwner;
		$[9] = issue.title;
		$[10] = issue.url;
		$[11] = sourceIcon;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
}
IssueItem.displayName = "IssueItem";
var RelationshipsSection_module_default = {
	actionListOverrides: "RelationshipsSection-module_h1G3Na_actionListOverrides",
	groupHeading: "RelationshipsSection-module_h1G3Na_groupHeading"
};
var EMPTY_ARRAY = [];
var RelationshipsSection = ({ sectionHeader, relationships, className }) => {
	const { parent, blockedBy, blocking } = relationships;
	const hasBlockedBy = blockedBy && blockedBy.length > 0;
	const hasBlocking = blocking && blocking.length > 0;
	return /* @__PURE__ */ jsx(Section, {
		id: "sidebar-relationships-section",
		sectionHeader,
		emptyText: parent || hasBlockedBy || hasBlocking ? void 0 : LABELS.emptySections.relationships,
		className,
		children: /* @__PURE__ */ jsxs(ActionList, {
			variant: "full",
			className: RelationshipsSection_module_default.actionListOverrides,
			children: [
				parent && /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
					as: "h4",
					className: RelationshipsSection_module_default.groupHeading,
					children: LABELS.relationNames.parentIssue
				}), /* @__PURE__ */ jsx(IssueItem, { issue: parent })] }),
				hasBlockedBy && /* @__PURE__ */ jsxs(Fragment$1, { children: [parent && /* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
					as: "h4",
					className: RelationshipsSection_module_default.groupHeading,
					children: LABELS.relationNames.blockedByIssues
				}), blockedBy.map((issue) => /* @__PURE__ */ jsx(IssueItem, { issue }, issue.id))] })] }),
				hasBlocking && /* @__PURE__ */ jsxs(Fragment$1, { children: [(parent || hasBlockedBy) && /* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
					as: "h4",
					className: RelationshipsSection_module_default.groupHeading,
					children: LABELS.relationNames.blockingIssues
				}), blocking.map((issue) => /* @__PURE__ */ jsx(IssueItem, { issue }, issue.id))] })] })
			]
		})
	});
};
RelationshipsSection.displayName = "RelationshipsSection";
function CreateIssueRelationshipsSection({ owner, repo, readonly, parentIssue, onParentChange, blockedByIssues = EMPTY_ARRAY, onBlockedByChange, blockingIssues = EMPTY_ARRAY, onBlockingChange, className }) {
	const [menuOpen, setMenuOpen] = useState(false);
	const [pickerType, setPickerType] = useState(null);
	const [currentRelationType, setCurrentRelationType] = useState(null);
	const sectionHeaderRef = useRef(null);
	const onPickerTypeChange = useCallback((type) => {
		setPickerType(type);
	}, []);
	const onParentSelection = useCallback((selectedIssues) => {
		onParentChange(selectedIssues[0] || null);
		setPickerType(null);
		setCurrentRelationType(null);
	}, [onParentChange]);
	const onBlockedBySelection = useCallback((selectedIssues_0) => {
		onBlockedByChange(selectedIssues_0);
		setPickerType(null);
		setCurrentRelationType(null);
	}, [onBlockedByChange]);
	const onBlockingSelection = useCallback((selectedIssues_1) => {
		onBlockingChange(selectedIssues_1);
		setPickerType(null);
		setCurrentRelationType(null);
	}, [onBlockingChange]);
	const onIssueSelection = useCallback((selectedIssues_2) => {
		if (currentRelationType === "parent") onParentSelection(selectedIssues_2);
		else if (currentRelationType === "blockedBy") onBlockedBySelection(selectedIssues_2);
		else if (currentRelationType === "blocking") onBlockingSelection(selectedIssues_2);
	}, [
		currentRelationType,
		onParentSelection,
		onBlockedBySelection,
		onBlockingSelection
	]);
	const selectedIssueIds = useMemo(() => {
		if (currentRelationType === "parent") return parentIssue ? [parentIssue.id] : [];
		if (currentRelationType === "blockedBy") return blockedByIssues.map((i) => i.id);
		if (currentRelationType === "blocking") return blockingIssues.map((i_0) => i_0.id);
		return [];
	}, [
		currentRelationType,
		parentIssue,
		blockedByIssues,
		blockingIssues
	]);
	const pickerSubtitle = useMemo(() => {
		if (currentRelationType === "parent") return "Select parent issue";
		if (currentRelationType === "blockedBy") return "Mark current issue as blocked by…";
		if (currentRelationType === "blocking") return "Mark current issue as blocking…";
	}, [currentRelationType]);
	const hiddenIssueIds = useMemo(() => {
		if (currentRelationType === "blockedBy") return blockingIssues.map((i_1) => i_1.id);
		if (currentRelationType === "blocking") return blockedByIssues.map((i_2) => i_2.id);
		return [];
	}, [
		currentRelationType,
		blockingIssues,
		blockedByIssues
	]);
	const handleEditParent = useCallback(() => {
		setMenuOpen(false);
		setCurrentRelationType("parent");
		setPickerType("Issue");
	}, []);
	const handleMarkBlockedBy = useCallback(() => {
		setMenuOpen(false);
		setCurrentRelationType("blockedBy");
		setPickerType("Issue");
	}, []);
	const handleMarkBlocking = useCallback(() => {
		setMenuOpen(false);
		setCurrentRelationType("blocking");
		setPickerType("Issue");
	}, []);
	const handleSectionHeaderClick = useCallback(() => {
		setPickerType(null);
		setCurrentRelationType(null);
		setMenuOpen((o) => !o);
	}, []);
	const anchorElement = useCallback((props) => {
		const { ref } = props;
		if (ref) ref.current = sectionHeaderRef.current;
		return /* @__PURE__ */ jsx(Fragment$1, {});
	}, [sectionHeaderRef]);
	return /* @__PURE__ */ jsx(RelationshipsSection, {
		sectionHeader: readonly ? /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.relationships }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(GlobalCommands, { commands: {
				"issue-create:edit-parent": handleEditParent,
				"issue-create:mark-blocked-by": handleMarkBlockedBy,
				"issue-create:mark-blocking": handleMarkBlocking
			} }),
			/* @__PURE__ */ jsx(SectionHeader, {
				ref: sectionHeaderRef,
				buttonProps: { onClick: handleSectionHeaderClick },
				readonly,
				title: LABELS.sectionTitles.relationships
			}),
			/* @__PURE__ */ jsx(RepositoryAndIssuePicker, {
				onPickerTypeChange,
				selectedIssueIds,
				hiddenIssueIds,
				onIssueSelection,
				organization: owner,
				defaultRepositoryNameWithOwner: `${owner}/${repo}`,
				pickerType,
				issuePickerProps: {
					selectionVariant: currentRelationType === "parent" ? "single" : "multiple",
					subtitle: pickerSubtitle
				},
				anchorElement
			}),
			/* @__PURE__ */ jsx(ActionMenu, {
				open: menuOpen,
				onOpenChange: setMenuOpen,
				anchorRef: sectionHeaderRef,
				children: /* @__PURE__ */ jsx(ActionMenu.Overlay, {
					width: "medium",
					children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [
						/* @__PURE__ */ jsx(CommandActionListItem, {
							commandId: "issue-create:edit-parent",
							onSelect: handleEditParent,
							children: parentIssue ? "Change or remove parent" : "Add parent"
						}),
						/* @__PURE__ */ jsx(CommandActionListItem, {
							commandId: "issue-create:mark-blocked-by",
							onSelect: handleMarkBlockedBy,
							children: blockedByIssues.length > 0 ? "Add or change blocked by" : "Mark as blocked by"
						}),
						/* @__PURE__ */ jsx(CommandActionListItem, {
							commandId: "issue-create:mark-blocking",
							onSelect: handleMarkBlocking,
							children: blockingIssues.length > 0 ? "Add or change blocking" : "Mark as blocking"
						})
					] }) })
				})
			})
		] }),
		relationships: {
			parent: parentIssue,
			blockedBy: blockedByIssues,
			blocking: blockingIssues
		},
		className
	});
}
CreateIssueRelationshipsSection.displayName = "CreateIssueRelationshipsSection";
var node$15 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v2 = [
		v0,
		v1,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "TypesSectionTypeFragment",
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "IssueType",
			"kind": "LinkedField",
			"name": "issueType",
			"plural": false,
			"selections": [
				v0,
				v1,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isEnabled",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "description",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "color",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "pinnedFields",
					"plural": true,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "IssueFieldText",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "IssueFieldSingleSelect",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "IssueFieldDate",
							"abstractKey": null
						},
						{
							"kind": "InlineFragment",
							"selections": v2,
							"type": "IssueFieldNumber",
							"abstractKey": null
						}
					],
					"storageKey": null
				}
			],
			"storageKey": null
		}],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$15.hash = "5de1a91f4e1d4ecaa3f0a9efbb82f741";
var node$14 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "TypesSectionFragment",
		"selections": [
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "name",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameWithOwner",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": [{
							"kind": "Literal",
							"name": "first",
							"value": 100
						}],
						"concreteType": "IssueTypeConnection",
						"kind": "LinkedField",
						"name": "issueTypes",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "IssueTypeEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "IssueType",
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [v0],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": "issueTypes(first:100)"
					}
				],
				"storageKey": null
			},
			v0,
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "TypesSectionTypeFragment"
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanType",
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$14.hash = "ed89df93a2fdaab7d32e7dfddf950293";
var node$13 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isEnabled",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "description",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "color",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v8 = [
		v2,
		v3,
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "dataType",
			"storageKey": null
		}
	], v9 = {
		"kind": "InlineFragment",
		"selections": v8,
		"type": "IssueFieldText",
		"abstractKey": null
	}, v10 = {
		"kind": "InlineFragment",
		"selections": v8,
		"type": "IssueFieldSingleSelect",
		"abstractKey": null
	}, v11 = {
		"kind": "InlineFragment",
		"selections": v8,
		"type": "IssueFieldDate",
		"abstractKey": null
	}, v12 = {
		"kind": "InlineFragment",
		"selections": v8,
		"type": "IssueFieldNumber",
		"abstractKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueIssueTypeSharedMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueIssueTypePayload",
				"kind": "LinkedField",
				"name": "updateIssueIssueType",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "IssueType",
						"kind": "LinkedField",
						"name": "issueType",
						"plural": false,
						"selections": [
							v2,
							v3,
							v4,
							v5,
							v6,
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "pinnedFields",
								"plural": true,
								"selections": [
									v7,
									v9,
									v10,
									v11,
									v12
								],
								"storageKey": null
							}
						],
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueIssueTypeSharedMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueIssueTypePayload",
				"kind": "LinkedField",
				"name": "updateIssueIssueType",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "IssueType",
						"kind": "LinkedField",
						"name": "issueType",
						"plural": false,
						"selections": [
							v2,
							v3,
							v4,
							v5,
							v6,
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "pinnedFields",
								"plural": true,
								"selections": [
									v7,
									v9,
									v10,
									v11,
									v12,
									{
										"kind": "InlineFragment",
										"selections": [v2],
										"type": "Node",
										"abstractKey": "__isNode"
									}
								],
								"storageKey": null
							}
						],
						"storageKey": null
					}, v2],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "627a164ed640a00cd8e7321559a066d7",
			"metadata": {},
			"name": "updateIssueIssueTypeSharedMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$13.hash = "76d56c8a5faaf2f8168ab652ced0278b";
/**
* Builds an optimistic response for the updateIssueIssueType mutation.
* This allows the UI to update immediately without waiting for the server response.
*/ function buildOptimisticResponse(issueId, issueType) {
	return { updateIssueIssueType: { issue: {
		id: issueId,
		issueType: issueType ? {
			id: issueType.id,
			name: issueType.name,
			description: issueType.description ?? null,
			color: issueType.color,
			isEnabled: issueType.isEnabled ?? true,
			pinnedFields: (issueType.pinnedFields ?? []).map((field) => {
				if (field.__typename === "%other") return {
					__typename: "%other",
					__isNode: "%other",
					id: ""
				};
				return {
					__typename: field.__typename,
					__isNode: field.__typename,
					id: field.id,
					name: field.name,
					dataType: field.dataType
				};
			})
		} : null
	} } };
}
function commitUpdateIssueIssueTypeMutation({ environment, input, optimisticIssueType, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$13,
		variables: { input },
		optimisticResponse: optimisticIssueType !== void 0 ? buildOptimisticResponse(input.issueId, optimisticIssueType) : void 0,
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var IssueTypeToken_module_default = {
	issueTypeTokenContainer: "IssueTypeToken-module_zoJtiG_issueTypeTokenContainer",
	token: "IssueTypeToken-module_zoJtiG_token",
	tokenText: "IssueTypeToken-module_zoJtiG_tokenText"
};
var IssueTypeToken$1 = ({ name, color, href, getTooltipText, size, sx, className }) => {
	const tokenRef = useRef(null);
	const [truncated, setTruncated] = useState(false);
	useEffect(() => setTruncated(isTextTruncated(tokenRef.current)), [setTruncated, tokenRef]);
	const internal = /* @__PURE__ */ jsx(Link, {
		href,
		children: /* @__PURE__ */ jsx(Token$1, {
			className: clsx(IssueTypeToken_module_default.token, className),
			"data-color": color,
			ref: tokenRef,
			sx,
			text: /* @__PURE__ */ jsx("span", {
				className: IssueTypeToken_module_default.tokenText,
				children: name
			})
		})
	});
	const tooltipText = getTooltipText(truncated);
	return /* @__PURE__ */ jsx("div", {
		className: IssueTypeToken_module_default.issueTypeTokenContainer,
		"data-size": size,
		children: tooltipText ? /* @__PURE__ */ jsx(Tooltip$1, {
			text: tooltipText,
			children: internal
		}) : internal
	});
};
IssueTypeToken$1.displayName = "IssueTypeToken";
var isTextTruncated = (e) => {
	if (!e || !e.firstElementChild) return false;
	return e.firstElementChild.scrollWidth > e.firstElementChild.clientWidth;
};
var IssueType_module_default = {
	hiddenPlaceholder: "IssueType-module_A3xxvW_hiddenPlaceholder",
	IssueTypeToken: "IssueType-module_A3xxvW_IssueTypeToken"
};
function IssueType({ type, anchorProps, repoNameWithOwner }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: type ? /* @__PURE__ */ jsx("div", {
		"data-testid": TEST_IDS$1.typeContainer,
		className: IssueType_module_default.IssueTypeToken,
		children: /* @__PURE__ */ jsx(IssueTypeToken$1, {
			name: type.name,
			color: type.color,
			href: `/${repoNameWithOwner}/issues?q=type:"${type.name}"`,
			getTooltipText: (isTruncated) => isTruncated ? type.name : void 0
		})
	}) : /* @__PURE__ */ jsx("div", {
		className: IssueType_module_default.hiddenPlaceholder,
		...anchorProps
	}) });
}
IssueType.displayName = "IssueType";
var TypesSection_module_default = { typeContainer: "TypesSection-module_5lksoa_typeContainer" };
var ReadonlyTypesSectionHeader = () => /* @__PURE__ */ jsx(ReadonlySectionHeader, { title: LABELS.sectionTitles.types });
ReadonlyTypesSectionHeader.displayName = "ReadonlyTypesSectionHeader";
var TypesSection = ({ sectionHeader, type, repoNameWithOwner, sx }) => /* @__PURE__ */ jsx(Section, {
	id: `sidebar-types-section`,
	sx,
	sectionHeader,
	emptyText: type ? void 0 : LABELS.emptySections.types,
	children: /* @__PURE__ */ jsx("div", {
		className: TypesSection_module_default.typeContainer,
		children: /* @__PURE__ */ jsx(IssueType, {
			type,
			repoNameWithOwner
		})
	})
});
TypesSection.displayName = "TypesSection";
function CreateIssueIssueTypesSection(t0) {
	const { type, onSelectionChange, viewerCanType, sx, ...sharedConfigProps } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	const sectionHeader = () => {
		if (!viewerCanType) return jsx(ReadonlyTypesSectionHeader, {});
		else return jsx(IssueTypePicker, {
			onSelectionChange: (newType) => {
				const issueType = newType?.[0] || null;
				sendAnalyticsEvent("issue_create.update_issue_type", "ISSUE_CREATE_UPDATE_ISSUE_TYPE_DIALOG", { issueTypeId: issueType?.id ?? "" });
				onSelectionChange(issueType);
			},
			readonly: viewerCanType,
			activeIssueType: type,
			anchorElement: _temp$3,
			...sharedConfigProps,
			width: "medium"
		});
	};
	const { repo, owner } = sharedConfigProps;
	return jsx(TypesSection, {
		sx,
		sectionHeader: sectionHeader(),
		type,
		repoNameWithOwner: `${owner}/${repo}`
	});
}
CreateIssueIssueTypesSection.displayName = "CreateIssueIssueTypesSection";
function _temp$3(anchorProps, ref) {
	return jsx(SectionHeader, {
		title: LABELS.sectionTitles.types,
		buttonProps: anchorProps,
		ref
	});
}
var TypesSectionTypeFragment = node$15;
var TypesSectionFragment = node$14;
function EditIssueIssueTypeSection(t0) {
	const $ = c(19);
	const { issue, onIssueUpdate, insideSidePanel, readonly } = t0;
	const data = (0, import_react_relay.useFragment)(TypesSectionFragment, issue);
	const { repository: t1, id: issueId, viewerCanType } = data;
	const { name: repo, owner: t2, nameWithOwner, issueTypes } = t1;
	const { login: owner } = t2;
	const formattedIssueTypes = issueTypes?.edges?.map(_temp2$2) || [];
	const { issueType } = (0, import_react_relay.useFragment)(TypesSectionTypeFragment, data);
	const activeType = issueType || null;
	const { sendAnalyticsEvent } = useAnalytics();
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t3;
	if ($[0] !== activeType?.id || $[1] !== addToast || $[2] !== environment || $[3] !== issueId || $[4] !== onIssueUpdate || $[5] !== sendAnalyticsEvent) {
		t3 = (selectedTypes) => {
			const selectedType = selectedTypes.length > 0 ? selectedTypes[0] : null;
			const issueTypeId = selectedType?.id ?? null;
			sendAnalyticsEvent("issue_viewer.update_issue_type", "ISSUE_VIEWER_UPDATE_ISSUE_TYPE_DIALOG", {
				initialIssueTypeId: activeType?.id ?? "",
				issueTypeId: issueTypeId ?? ""
			});
			const optimisticIssueType = selectedType ? {
				id: selectedType.id,
				name: selectedType.name,
				description: selectedType.description,
				color: selectedType.color,
				isEnabled: selectedType.isEnabled,
				pinnedFields: selectedType.pinnedFields
			} : null;
			commitUpdateIssueIssueTypeMutation({
				environment,
				input: {
					issueId,
					issueTypeId
				},
				optimisticIssueType,
				onError: () => addToast({
					type: "error",
					message: ERRORS$2.couldNotUpdateType
				}),
				onCompleted: onIssueUpdate
			});
		};
		$[0] = activeType?.id;
		$[1] = addToast;
		$[2] = environment;
		$[3] = issueId;
		$[4] = onIssueUpdate;
		$[5] = sendAnalyticsEvent;
		$[6] = t3;
	} else t3 = $[6];
	activeType?.id;
	const onSelectionChanged = t3;
	let t4;
	bb0: {
		const readonlyType = readonly || !viewerCanType;
		if (readonlyType) {
			let t5;
			if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
				t5 = jsx(ReadonlyTypesSectionHeader, {});
				$[7] = t5;
			} else t5 = $[7];
			t4 = t5;
			break bb0;
		}
		const t5 = activeType ?? null;
		let t6;
		if ($[8] !== insideSidePanel || $[9] !== onSelectionChanged || $[10] !== owner || $[11] !== readonlyType || $[12] !== repo || $[13] !== t5) {
			t6 = jsx(IssueTypePicker, {
				owner,
				repo,
				onSelectionChange: onSelectionChanged,
				anchorElement: _temp3$1,
				readonly: readonlyType,
				activeIssueType: t5,
				insidePortal: insideSidePanel,
				width: "medium"
			});
			$[8] = insideSidePanel;
			$[9] = onSelectionChanged;
			$[10] = owner;
			$[11] = readonlyType;
			$[12] = repo;
			$[13] = t5;
			$[14] = t6;
		} else t6 = $[14];
		t4 = t6;
	}
	const sectionHeader = t4;
	if (!viewerCanType && formattedIssueTypes.length === 0) return null;
	const t5 = activeType ?? null;
	let t6;
	if ($[15] !== nameWithOwner || $[16] !== sectionHeader || $[17] !== t5) {
		t6 = jsx(TypesSection, {
			sectionHeader,
			type: t5,
			repoNameWithOwner: nameWithOwner
		});
		$[15] = nameWithOwner;
		$[16] = sectionHeader;
		$[17] = t5;
		$[18] = t6;
	} else t6 = $[18];
	return t6;
}
EditIssueIssueTypeSection.displayName = "EditIssueIssueTypeSection";
function _temp3$1(anchorProps, ref) {
	return jsx(SectionHeader, {
		title: LABELS.sectionTitles.types,
		buttonProps: anchorProps,
		ref
	});
}
function _temp2$2(edge) {
	return edge?.node?.id;
}
var MetadataSidebar_module_default = {
	CreateIssueAssigneesSection: "MetadataSidebar-module_-KM2Da_CreateIssueAssigneesSection",
	MetadataSidebarContainer: "MetadataSidebar-module_-KM2Da_MetadataSidebarContainer"
};
var MetadataSidebar = (t0) => {
	const $ = c(33);
	const { canSetAssignees, canSetLabels, canSetMilestone, canCreateLabel, canCreateMilestone, canSetProjects, canSetType, canSetIssueFields, canSetRelationships, issueTypesEnabled, orgPinnedFields, isPinnedFieldsLoading } = t0;
	const { optionConfig } = useIssueCreateConfigContext();
	const { repository, labels, setLabels, assignees, setAssignees, projects, setProjects, milestone, setMilestone, issueType, setIssueType, setIssueFields, parentIssue, setParentIssue, blockedByIssues, setBlockedByIssues, blockingIssues, setBlockingIssues } = useIssueCreateDataContext();
	const t1 = optionConfig.insidePortal;
	let t2;
	let t3;
	if ($[0] !== assignees || $[1] !== blockedByIssues || $[2] !== blockingIssues || $[3] !== canCreateLabel || $[4] !== canCreateMilestone || $[5] !== canSetAssignees || $[6] !== canSetIssueFields || $[7] !== canSetLabels || $[8] !== canSetMilestone || $[9] !== canSetProjects || $[10] !== canSetRelationships || $[11] !== canSetType || $[12] !== isPinnedFieldsLoading || $[13] !== issueType || $[14] !== issueTypesEnabled || $[15] !== labels || $[16] !== milestone || $[17] !== optionConfig.insidePortal || $[18] !== orgPinnedFields || $[19] !== parentIssue || $[20] !== projects || $[21] !== repository || $[22] !== setAssignees || $[23] !== setBlockedByIssues || $[24] !== setBlockingIssues || $[25] !== setIssueFields || $[26] !== setIssueType || $[27] !== setLabels || $[28] !== setMilestone || $[29] !== setParentIssue || $[30] !== setProjects) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const sharedConfigProps = { insidePortal: t1 };
			if (!repository) {
				t3 = null;
				break bb0;
			}
			t2 = jsxs("div", {
				className: MetadataSidebar_module_default.MetadataSidebarContainer,
				children: [
					jsx("h2", {
						className: "sr-only",
						children: "Metadata"
					}),
					repository && jsx(CreateIssueAssigneesSection$1, {
						repo: repository.name,
						owner: repository.owner.login,
						readonly: !canSetAssignees,
						assignees,
						onSelectionChange: setAssignees,
						className: MetadataSidebar_module_default.CreateIssueAssigneesSection,
						repository,
						issueNumber: void 0,
						onIssueUpdate: void 0,
						...sharedConfigProps
					}),
					jsx(CreateIssueLabelsSection, {
						repo: repository.name,
						owner: repository.owner.login,
						readonly: !canSetLabels,
						canCreateLabel,
						labels,
						onSelectionChange: setLabels,
						...sharedConfigProps
					}),
					issueTypesEnabled && jsx(CreateIssueIssueTypesSection, {
						owner: repository.owner.login,
						repo: repository.name,
						...sharedConfigProps,
						viewerCanType: canSetType,
						type: issueType,
						onSelectionChange: setIssueType
					}),
					canSetIssueFields && jsx(CreateIssueFieldsSection, {
						owner: repository.owner.login,
						ownerId: repository.owner.databaseId,
						onSelectionChange: setIssueFields,
						issueType,
						orgPinnedFields,
						isPinnedFieldsLoading,
						...sharedConfigProps
					}),
					jsx(CreateIssueProjectsSection, {
						owner: repository.owner.login,
						repo: repository.name,
						projects,
						readonly: !canSetProjects,
						onSelectionChange: setProjects,
						...sharedConfigProps
					}),
					jsx(CreateIssueMilestonesSection, {
						repo: repository.name,
						owner: repository.owner.login,
						milestone,
						onSelectionChange: setMilestone,
						viewerCanSetMilestone: canSetMilestone ?? false,
						canCreateMilestone,
						className: MetadataSidebar_module_default.CreateIssueAssigneesSection,
						...sharedConfigProps
					}),
					isFeatureEnabled("issue_create_relationships") && jsx(CreateIssueRelationshipsSection, {
						owner: repository.owner.login,
						repo: repository.name,
						readonly: !canSetRelationships,
						parentIssue,
						onParentChange: setParentIssue,
						blockedByIssues,
						onBlockedByChange: setBlockedByIssues,
						blockingIssues,
						onBlockingChange: setBlockingIssues
					})
				]
			});
		}
		$[0] = assignees;
		$[1] = blockedByIssues;
		$[2] = blockingIssues;
		$[3] = canCreateLabel;
		$[4] = canCreateMilestone;
		$[5] = canSetAssignees;
		$[6] = canSetIssueFields;
		$[7] = canSetLabels;
		$[8] = canSetMilestone;
		$[9] = canSetProjects;
		$[10] = canSetRelationships;
		$[11] = canSetType;
		$[12] = isPinnedFieldsLoading;
		$[13] = issueType;
		$[14] = issueTypesEnabled;
		$[15] = labels;
		$[16] = milestone;
		$[17] = optionConfig.insidePortal;
		$[18] = orgPinnedFields;
		$[19] = parentIssue;
		$[20] = projects;
		$[21] = repository;
		$[22] = setAssignees;
		$[23] = setBlockedByIssues;
		$[24] = setBlockingIssues;
		$[25] = setIssueFields;
		$[26] = setIssueType;
		$[27] = setLabels;
		$[28] = setMilestone;
		$[29] = setParentIssue;
		$[30] = setProjects;
		$[31] = t2;
		$[32] = t3;
	} else {
		t2 = $[31];
		t3 = $[32];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
};
MetadataSidebar.displayName = "MetadataSidebar";
var MetadataSelectors = (t0) => {
	const $ = c(15);
	const { orgPinnedFields, isPinnedFieldsLoading } = t0;
	const { optionConfig } = useIssueCreateConfigContext();
	const showMetadataInSidebar = !optionConfig.insidePortal;
	const { repository } = useIssueCreateDataContext();
	const canSetAssignees = repository?.viewerIssueCreationPermissions?.assignable ?? false;
	const canSetLabels = repository?.viewerIssueCreationPermissions?.labelable ?? false;
	const canSetMilestone = repository?.viewerIssueCreationPermissions?.milestoneable ?? false;
	const viewerCanPush = repository?.viewerCanPush ?? false;
	const canSetProjects = repository?.viewerIssueCreationPermissions?.triageable ?? false;
	const canSetType = repository?.viewerIssueCreationPermissions?.typeable ?? false;
	const canSetIssueFields = repository?.viewerIssueCreationPermissions?.canSetIssueFields ?? false;
	const canSetRelationships = repository?.viewerIssueCreationPermissions?.triageable ?? false;
	const issueTypesEnabled = repository?.owner?.issueTypesEnabled ?? false;
	const t1 = repository?.name || "";
	const t2 = repository?.owner.login || "";
	let t3;
	if ($[0] !== canSetAssignees || $[1] !== canSetIssueFields || $[2] !== canSetLabels || $[3] !== canSetMilestone || $[4] !== canSetProjects || $[5] !== canSetRelationships || $[6] !== canSetType || $[7] !== isPinnedFieldsLoading || $[8] !== issueTypesEnabled || $[9] !== orgPinnedFields || $[10] !== showMetadataInSidebar || $[11] !== t1 || $[12] !== t2 || $[13] !== viewerCanPush) {
		const sharedMetadataProps = {
			repo: t1,
			owner: t2,
			canSetAssignees,
			canSetLabels,
			canSetMilestone,
			canCreateLabel: viewerCanPush,
			canCreateMilestone: viewerCanPush,
			canSetProjects,
			canSetType,
			canSetIssueFields,
			canSetRelationships,
			issueTypesEnabled,
			orgPinnedFields,
			isPinnedFieldsLoading
		};
		t3 = showMetadataInSidebar ? jsx(MetadataSidebar, { ...sharedMetadataProps }) : jsx(MetadataFooter, { ...sharedMetadataProps });
		$[0] = canSetAssignees;
		$[1] = canSetIssueFields;
		$[2] = canSetLabels;
		$[3] = canSetMilestone;
		$[4] = canSetProjects;
		$[5] = canSetRelationships;
		$[6] = canSetType;
		$[7] = isPinnedFieldsLoading;
		$[8] = issueTypesEnabled;
		$[9] = orgPinnedFields;
		$[10] = showMetadataInSidebar;
		$[11] = t1;
		$[12] = t2;
		$[13] = viewerCanPush;
		$[14] = t3;
	} else t3 = $[14];
	return t3;
};
MetadataSelectors.displayName = "MetadataSelectors";
var node$12 = (function() {
	var v0 = {
		"defaultValue": false,
		"kind": "LocalArgument",
		"name": "fetchParent"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}, v2 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "total",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "completed",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"concreteType": "Issue",
		"kind": "LinkedField",
		"name": "parent",
		"plural": false,
		"selections": [v4, {
			"alias": null,
			"args": null,
			"concreteType": "SubIssuesSummary",
			"kind": "LinkedField",
			"name": "subIssuesSummary",
			"plural": false,
			"selections": [
				v10,
				v11,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "percentCompleted",
					"storageKey": null
				}
			],
			"storageKey": null
		}],
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "message",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "createIssueMutation",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "CreateIssuePayload",
				"kind": "LinkedField",
				"name": "createIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "repository",
							"plural": false,
							"selections": [
								v3,
								v4,
								v5,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [v6],
									"storageKey": null
								}
							],
							"storageKey": null
						},
						v7,
						v8,
						v4,
						v9,
						{
							"condition": "fetchParent",
							"kind": "Condition",
							"passingValue": true,
							"selections": [{
								"args": null,
								"kind": "FragmentSpread",
								"name": "SubIssuesListItem"
							}, v12]
						}
					],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "errors",
					"plural": true,
					"selections": [v13],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "createIssueMutation",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "CreateIssuePayload",
				"kind": "LinkedField",
				"name": "createIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "repository",
							"plural": false,
							"selections": [
								v3,
								v4,
								v5,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [
										v14,
										v6,
										v4
									],
									"storageKey": null
								}
							],
							"storageKey": null
						},
						v7,
						v8,
						v4,
						v9,
						{
							"condition": "fetchParent",
							"kind": "Condition",
							"passingValue": true,
							"selections": [
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "state",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "stateReason",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"concreteType": "IssueDependenciesSummary",
									"kind": "LinkedField",
									"name": "issueDependenciesSummary",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "blockedBy",
										"storageKey": null
									}],
									"storageKey": null
								},
								{
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 10
									}],
									"concreteType": "UserConnection",
									"kind": "LinkedField",
									"name": "assignees",
									"plural": false,
									"selections": [v15, {
										"alias": null,
										"args": null,
										"concreteType": "UserEdge",
										"kind": "LinkedField",
										"name": "edges",
										"plural": true,
										"selections": [{
											"alias": null,
											"args": null,
											"concreteType": "User",
											"kind": "LinkedField",
											"name": "node",
											"plural": false,
											"selections": [
												v4,
												v6,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "avatarUrl",
													"storageKey": null
												}
											],
											"storageKey": null
										}],
										"storageKey": null
									}],
									"storageKey": "assignees(first:10)"
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "titleHTML",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"concreteType": "IssueType",
									"kind": "LinkedField",
									"name": "issueType",
									"plural": false,
									"selections": [
										v4,
										v5,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "color",
											"storageKey": null
										}
									],
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"concreteType": "SubIssuesSummary",
									"kind": "LinkedField",
									"name": "subIssuesSummary",
									"plural": false,
									"selections": [v10, v11],
									"storageKey": null
								},
								{
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 0
									}, {
										"kind": "Literal",
										"name": "includeClosedPrs",
										"value": true
									}],
									"concreteType": "PullRequestConnection",
									"kind": "LinkedField",
									"name": "closedByPullRequestsReferences",
									"plural": false,
									"selections": [v15],
									"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
								},
								v12
							]
						}
					],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "errors",
					"plural": true,
					"selections": [v14, v13],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "f06cbfa3acc3dd5ed6724c55e1fd64a2",
			"metadata": {},
			"name": "createIssueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$12.hash = "a0fc1d6cb2e696257826bd50783fb175";
function escapeHtml(text) {
	return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
/**
* Gets or creates the subIssues connection on a parent issue record.
*/ function getOrCreateSubIssuesConnection(store, parentRecord) {
	if (!parentRecord) return null;
	const subIssuesConnection = parentRecord.getLinkedRecord("subIssues", { first: 100 });
	if (!subIssuesConnection) return null;
	return subIssuesConnection;
}
/**
* Creates an optimistic assignees connection for a sub-issue.
*/ function createOptimisticAssigneesConnection(store, optimisticId, assigneeIds) {
	const assigneesId = `${optimisticId}-assignees`;
	const assigneesConnection = store.create(assigneesId, "UserConnection");
	const assigneeEdges = [];
	if (assigneeIds && assigneeIds.length > 0) for (const assigneeId of assigneeIds) {
		const userRecord = store.get(assigneeId);
		if (userRecord) {
			const edgeId = `${optimisticId}-assignee-edge-${assigneeId}`;
			const edge = store.create(edgeId, "UserEdge");
			edge.setLinkedRecord(userRecord, "node");
			assigneeEdges.push(edge);
		}
	}
	assigneesConnection.setValue(assigneeEdges.length, "totalCount");
	assigneesConnection.setLinkedRecords(assigneeEdges, "edges");
	return assigneesConnection;
}
/**
* Creates an optimistic sub-issue record with all required fields for SubIssuesListItem fragment.
*/ function createOptimisticSubIssue(store, inputHash, parentRecord) {
	const optimisticId = `${TEMP_SUB_ISSUE_ID_PREFIX}${Date.now()}`;
	const newSubIssue = store.create(optimisticId, "Issue");
	newSubIssue.setValue(optimisticId, "id");
	newSubIssue.setValue(inputHash.title, "title");
	newSubIssue.setValue(escapeHtml(inputHash.title), "titleHTML");
	newSubIssue.setValue("OPEN", "state");
	newSubIssue.setValue(null, "stateReason");
	const assigneesConnection = createOptimisticAssigneesConnection(store, optimisticId, inputHash.assigneeIds);
	newSubIssue.setLinkedRecord(assigneesConnection, "assignees", { first: 10 });
	const repoRecord = store.get(inputHash.repositoryId);
	if (repoRecord) newSubIssue.setLinkedRecord(repoRecord, "repository");
	else {
		const parentRepo = parentRecord.getLinkedRecord("repository");
		if (parentRepo) newSubIssue.setLinkedRecord(parentRepo, "repository");
	}
	newSubIssue.setValue("", "url");
	const depsId = `${optimisticId}-deps`;
	const depsSummary = store.create(depsId, "IssueDependenciesSummary");
	depsSummary.setValue(0, "blockedBy");
	newSubIssue.setLinkedRecord(depsSummary, "issueDependenciesSummary");
	const subIssuesSummaryId = `${optimisticId}-subIssuesSummary`;
	const subIssuesSummary = store.create(subIssuesSummaryId, "SubIssuesSummary");
	subIssuesSummary.setValue(0, "total");
	newSubIssue.setLinkedRecord(subIssuesSummary, "subIssuesSummary");
	return newSubIssue;
}
/**
* Updates the parent's subIssuesSummary.total count.
*/ function updateParentSubIssuesSummary(store, parentRecord, parentIssueId) {
	let parentSubIssuesSummary = parentRecord.getLinkedRecord("subIssuesSummary");
	if (!parentSubIssuesSummary) {
		const parentSummaryId = `${parentIssueId}-subIssuesSummary`;
		parentSubIssuesSummary = store.create(parentSummaryId, "SubIssuesSummary");
		const parentSubIssuesSummaryData = {
			total: 0,
			completed: 0,
			percentCompleted: 0
		};
		for (const key in parentSubIssuesSummaryData) parentSubIssuesSummary.setValue(parentSubIssuesSummaryData[key], key);
		parentRecord.setLinkedRecord(parentSubIssuesSummary, "subIssuesSummary");
	}
	const currentTotal = parentSubIssuesSummary.getValue("total");
	if (typeof currentTotal === "number") parentSubIssuesSummary.setValue(currentTotal + 1, "total");
	else parentSubIssuesSummary.setValue(1, "total");
}
/**
* Optimistic updater for creating a sub-issue. Adds the new issue to the parent's
* subIssues connection immediately for responsive UI.
* @internal Exported for testing purposes
*/ function optimisticUpdateSubIssuesConnection(store, inputHash) {
	if (!inputHash.parentIssueId) return;
	const parentRecord = store.get(inputHash.parentIssueId);
	if (!parentRecord) return;
	const subIssuesConnection = getOrCreateSubIssuesConnection(store, parentRecord);
	if (!subIssuesConnection) return;
	const newSubIssue = createOptimisticSubIssue(store, inputHash, parentRecord);
	const currentNodes = subIssuesConnection.getLinkedRecords("nodes") || [];
	subIssuesConnection.setLinkedRecords([...currentNodes, newSubIssue], "nodes");
	const currentTotalCount = subIssuesConnection.getValue("totalCount");
	if (typeof currentTotalCount === "number") subIssuesConnection.setValue(currentTotalCount + 1, "totalCount");
	else subIssuesConnection.setValue(1, "totalCount");
	updateParentSubIssuesSummary(store, parentRecord, inputHash.parentIssueId);
}
/**
* Updater that runs after the server response. Adds the new issue to the parent's
* subIssues connection if not already present (handles deduplication).
* @internal Exported for testing purposes
*/ function updateSubIssuesConnectionAfterResponse(store, inputHash) {
	if (!inputHash.parentIssueId) return;
	const payload = store.getRootField("createIssue");
	if (!payload) return;
	const newIssue = payload.getLinkedRecord("issue");
	if (!newIssue) return;
	const parentRecord = store.get(inputHash.parentIssueId);
	if (!parentRecord) return;
	const subIssuesConnection = getOrCreateSubIssuesConnection(store, parentRecord);
	if (!subIssuesConnection) return;
	const currentNodes = subIssuesConnection.getLinkedRecords("nodes") || [];
	const newIssueId = newIssue.getValue("id");
	if (!currentNodes.some((node) => node?.getValue("id") === newIssueId)) {
		subIssuesConnection.setLinkedRecords([...currentNodes, newIssue], "nodes");
		const currentTotalCount = subIssuesConnection.getValue("totalCount");
		if (typeof currentTotalCount === "number") subIssuesConnection.setValue(currentTotalCount + 1, "totalCount");
		else subIssuesConnection.setValue(currentNodes.length + 1, "totalCount");
	}
}
function commitCreateIssueMutation({ environment, input: inputHash, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$12,
		variables: {
			input: inputHash,
			fetchParent: !!inputHash.parentIssueId
		},
		optimisticUpdater: (store) => optimisticUpdateSubIssuesConnection(store, inputHash),
		updater: (store) => updateSubIssuesConnectionAfterResponse(store, inputHash),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => {
			onCompleted?.(response);
			incrementIssuesTabCounter();
		}
	});
}
var UserRestrictedView_module_default = {
	backToAllIssuesButton: "UserRestrictedView-module_7CDyRa_backToAllIssuesButton",
	userRestrictedContainer: "UserRestrictedView-module_7CDyRa_userRestrictedContainer"
};
var UserRestrictedView = ({ reasonHTML, issuesUrl }) => {
	return /* @__PURE__ */ jsxs("div", {
		className: UserRestrictedView_module_default.userRestrictedContainer,
		children: [reasonHTML && /* @__PURE__ */ jsx(Banner, {
			"aria-label": "Warning",
			variant: "warning",
			hideTitle: true,
			title: "Action restricted",
			children: /* @__PURE__ */ jsx(Banner.Description, { children: /* @__PURE__ */ jsx(VerifiedHTMLText, { html: reasonHTML }) })
		}), issuesUrl && /* @__PURE__ */ jsx(ButtonComponent, {
			as: "a",
			href: issuesUrl,
			className: UserRestrictedView_module_default.backToAllIssuesButton,
			children: LABELS$2.backToAllIssues
		})]
	});
};
UserRestrictedView.displayName = "UserRestrictedView";
var node$11 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}], v2 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "AddBlockedByPayload",
		"kind": "LinkedField",
		"name": "addBlockedBy",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "issue",
			"plural": false,
			"selections": v1,
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "blockingIssue",
			"plural": false,
			"selections": v1,
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "createIssueAddBlockedByMutation",
			"selections": v2,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "createIssueAddBlockedByMutation",
			"selections": v2
		},
		"params": {
			"id": "e0daa3cc39578a0c6d16892c620ba652",
			"metadata": {},
			"name": "createIssueAddBlockedByMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$11.hash = "bddab089b466747a365e4f8c57ef56f1";
function commitCreateIssueAddBlockedByMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$11,
		variables: { input },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
/**
* Helper to create a single relationship mutation as a promise
*/
function createRelationshipMutation(environment, issueId, blockingIssueId) {
	return new Promise((resolve) => {
		commitCreateIssueAddBlockedByMutation({
			environment,
			input: {
				issueId,
				blockingIssueId
			},
			onError: (error) => {
				resolve({
					success: false,
					issueId: blockingIssueId,
					error: error.message
				});
			},
			onCompleted: (response) => {
				resolve({
					success: response.addBlockedBy !== null,
					issueId: blockingIssueId
				});
			}
		});
	});
}
/**
* Helper to create multiple relationship mutations and throw errors
*/
async function createRelationships(environment, issueIds, relationshipType) {
	const failedCount = (await Promise.allSettled(issueIds.map(({ issueId, blockingIssueId }) => createRelationshipMutation(environment, issueId, blockingIssueId)))).filter((r) => r.status === "fulfilled" && !r.value.success).length;
	if (failedCount > 0) setTimeout(() => {
		throw new Error(`Failed to add ${failedCount} of ${issueIds.length} ${relationshipType} relationship(s)`);
	});
}
/**
* Create issue relationships after creation (fire-and-forget).
*
* Failures are reported but don't block issue creation success.
* Matches project assignment pattern. This will be replaced when createIssue
* mutation supports blocking/blockedBy parameters (tracked in github/github#412771).
*/
async function handleIssueRelationships(environment, newIssueId, blockedByIssueIds, blockingIssueIds) {
	const promises = [];
	if (blockedByIssueIds.length > 0) promises.push(createRelationships(environment, blockedByIssueIds.map((blockingIssueId) => ({
		issueId: newIssueId,
		blockingIssueId
	})), "blocked-by"));
	if (blockingIssueIds.length > 0) promises.push(createRelationships(environment, blockingIssueIds.map((blockedIssueId) => ({
		issueId: blockedIssueId,
		blockingIssueId: newIssueId
	})), "blocking"));
	await Promise.all(promises);
}
var EMPTY_ORG_PINNED_FIELDS = [];
var CreateIssueForm = ({ repository, title, setTitle, body, setBody, clearOnCreate, onCreateSuccess, onCreateError, selectedTemplate, footer, issueFormRef, onBeforeCreate, defaultValuesById, showUserRestrictedView = false, onFieldChange, duplicateDetection }) => {
	const { optionConfig, createMore, createMoreCreatedPath, setCreateMoreCreatedPath, isSubmitting, setIsSubmitting, onCreateAction, setIsFileUploading, displayMode, isCreatingSubIssueFromProject } = useIssueCreateConfigContext();
	const showMetadataSidepanel = !optionConfig.insidePortal;
	const titleInputRef = useRef(null);
	const clientMutationIdRef = useRef(void 0);
	const [viewMode, setViewMode] = useState();
	const [titleValidationResult, setTitleValidationResult] = useState(void 0);
	const [bodyValidationResult, setBodyValidationResult] = useState(void 0);
	const [submissionErrors, setSubmissionErrors] = useState(null);
	const secondaryIssueFormData = useIssueFormSecondaryQuery({ repoId: repository.id });
	const errorBanner = useRef(null);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { sendAnalyticsEvent } = useAnalytics();
	const { addToast } = useToastContext();
	const { labels, assignees, replaceAssignees, projects, milestone, issueType, issueFields, parentIssueId, blockedByIssueIds, blockingIssueIds, usedStorageKeyPrefix, isCopilotAssignmentDialogOpen, setIsCopilotAssignmentDialogOpen, copilotAssignmentAttributes, setCopilotAssignmentAttributes, setIssueFormBody } = useIssueCreateDataContext();
	const resetDuplicateDetection = duplicateDetection?.resetForNewSession;
	const trackDuplicateDetectionIssueCreated = duplicateDetection?.trackIssueCreated;
	const shouldShowCopilotFunctionality = useShouldShowCopilotFunctionalityInIssues({
		additionalConditions: [selectedTemplate ? !instanceOfIssueFormData(selectedTemplate.data) : true],
		repositoryVisibility: repository.visibility,
		userCanPushToRepo: repository.viewerCanPush
	});
	const postSemanticSearchAnalytics = useSemanticSearchAnalytics(repository);
	useEffect(() => {
		if (shouldShowCopilotFunctionality) sendAnalyticsEvent("analytics.view", "ISSUE_CREATE_NEW_ISSUE_WITH_COPILOT_BUTTON_VIEW", { repoNWO: `${repository.owner.login}/${repository.name}` });
	}, [
		repository.name,
		repository.owner.login,
		sendAnalyticsEvent,
		shouldShowCopilotFunctionality
	]);
	const pendingCreationRef = useRef(false);
	useEffect(() => {
		if (copilotAssignmentAttributes && pendingCreationRef.current) {
			pendingCreationRef.current = false;
			onCreateAction.current?.onCreate(false, false);
		}
	}, [copilotAssignmentAttributes]);
	useEffect(() => {
		if (!isCopilotAssignmentDialogOpen && !copilotAssignmentAttributes) pendingCreationRef.current = false;
	}, [isCopilotAssignmentDialogOpen, copilotAssignmentAttributes]);
	const restrictedViewContent = /* @__PURE__ */ jsx(UserRestrictedView, {
		reasonHTML: repository.viewerInteractionLimitReasonHTML,
		issuesUrl: `/${repository.owner.login}/${repository.name}/issues`
	});
	const canIssueType = repository.viewerIssueCreationPermissions.typeable;
	const canSetIssueFields = repository.viewerIssueCreationPermissions.canSetIssueFields;
	const formatFormErrorMessage = (errors) => {
		const errorMessages = errors.map((err) => err?.message).filter(Boolean).join(", ");
		return (errorMessages ? errorMessages.charAt(0).toUpperCase() + errorMessages.slice(1) : null) ?? ERRORS$1.createIssueError;
	};
	const selectedDefaultValuesById = useMemo(() => defaultValuesById || getPotentialFormDefaultValuesFromUrl(), [defaultValuesById]);
	useEffect(() => {
		if (submissionErrors && submissionErrors.length > 0 && errorBanner?.current) errorBanner.current.focus();
	}, [errorBanner, submissionErrors]);
	const isDuplicateDetectionEnabled = duplicateDetection?.isDuplicateDetectionEnabled ?? false;
	const isIssueForm = selectedTemplate && instanceOfIssueFormData(selectedTemplate.data);
	const handleFormFieldChangeForDuplicateDetection = useCallback((id, indexOfFormElement, value) => {
		if (isDuplicateDetectionEnabled && issueFormRef.current) setIssueFormBody(issueFormRef.current.markdown() ?? "");
		onFieldChange?.(id, indexOfFormElement, value);
	}, [
		isDuplicateDetectionEnabled,
		issueFormRef,
		setIssueFormBody,
		onFieldChange
	]);
	useImperativeHandle(onCreateAction, () => ({ onCreate: async (isSubmittingArg, createMoreArg) => {
		if (isSubmittingArg) return;
		let refToFocusOnError = void 0;
		const inputValidationResult = validateIssueTitle(title);
		setTitleValidationResult(inputValidationResult.errorMessage);
		if (!inputValidationResult.isValid && titleInputRef.current) refToFocusOnError = titleInputRef.current;
		const isUsingIssueForm = selectedTemplate && instanceOfIssueFormData(selectedTemplate.data);
		let issueBodyToSave = body;
		if (isUsingIssueForm && issueFormRef.current) {
			const invalidInputs = issueFormRef.current.getInvalidInputs();
			if (invalidInputs.length > 0) refToFocusOnError = refToFocusOnError || invalidInputs[0];
			else issueBodyToSave = issueFormRef.current.markdown() ?? "";
		}
		if (refToFocusOnError || titleValidationResult !== void 0 || (title ?? "").trim().length === 0 || repository === void 0 || bodyValidationResult !== void 0) {
			refToFocusOnError?.focus();
			return;
		}
		setSubmissionErrors(null);
		setIsSubmitting(true);
		if (assignees.some((assignee) => isCopilot(assignee.login)) && !copilotAssignmentAttributes) {
			pendingCreationRef.current = true;
			setIsCopilotAssignmentDialogOpen(true);
			setIsSubmitting(false);
			return;
		}
		if (onBeforeCreate) issueBodyToSave = await onBeforeCreate(issueBodyToSave);
		let issueTemplate = void 0;
		if (selectedTemplate && (selectedTemplate.kind === IssueCreationKind.IssueTemplate || selectedTemplate.kind === IssueCreationKind.IssueForm)) issueTemplate = selectedTemplate.name;
		const input = {
			repositoryId: repository.id,
			title: title ? title.trim() : "",
			body: issueBodyToSave,
			labelIds: labels.length > 0 ? labels.map((label) => label.id) : void 0,
			assigneeIds: assignees.length > 0 ? assignees.map((assignee) => assignee.id) : void 0,
			milestoneId: milestone?.id,
			issueTypeId: canIssueType || issueTemplate ? issueType?.id : null,
			issueFields: canSetIssueFields ? issueFields.map((field) => {
				if (field.field.dataType === void 0 || field.field.id === void 0) return null;
				const value = getIssueFieldSelectionValue(toIssueFieldType(field.field.dataType), field.value);
				return {
					fieldId: field.field.id,
					...getIssueFieldValue(toIssueFieldType(field.field.dataType), value)
				};
			}).filter((v) => !!v) : null,
			issueTemplate,
			isDuplicated: displayMode === DisplayMode.IssueDuplication,
			parentIssueId,
			clientMutationId: clientMutationIdRef.current ??= crypto.randomUUID(),
			copilotAssignment: copilotAssignmentAttributes ?? void 0
		};
		const closeImmediately = !isCreatingSubIssueFromProject && !!parentIssueId && !createMoreArg;
		commitCreateIssueMutation({
			environment,
			input,
			onError: (error) => {
				reportError$1(formatError(error.message));
				onCreateError(error);
				setIsSubmitting(false);
				let errorMessage = ERRORS$1.createIssueError;
				if (error.cause && Array.isArray(error.cause) && error.cause.length > 0) errorMessage = formatFormErrorMessage(error.cause);
				if (closeImmediately) addToast({
					type: "error",
					message: errorMessage
				});
				else setSubmissionErrors(errorMessage);
			},
			onCompleted: (response) => {
				setIsSubmitting(false);
				if (!response.createIssue?.issue) {
					response.createIssue?.errors.map((e) => reportError$1(formatError(e.message)));
					let errorMessage = ERRORS$1.createIssueError;
					if (response.createIssue?.errors && response.createIssue?.errors.length > 0) errorMessage = formatFormErrorMessage(response.createIssue.errors);
					if (closeImmediately) addToast({
						type: "error",
						message: errorMessage
					});
					else setSubmissionErrors(errorMessage);
					return;
				}
				const newIssue = response.createIssue.issue;
				sendAnalyticsEvent("analytics.click", "ISSUE_CREATE_NEW_ISSUE_BUTTON", {
					issueId: newIssue.id,
					issueNumber: newIssue.number,
					issueNWO: `${newIssue.repository.owner.login}/${newIssue.repository.name}`
				});
				if (isDuplicateDetectionEnabled) trackDuplicateDetectionIssueCreated?.();
				if (projects.length > 0) assignIssueToProjects(newIssue.id, projects, environment);
				if (blockedByIssueIds.length > 0 || blockingIssueIds.length > 0) handleIssueRelationships(environment, newIssue.id, blockedByIssueIds, blockingIssueIds);
				clientMutationIdRef.current = crypto.randomUUID();
				if (createMoreArg) {
					setViewMode("edit");
					setCreateMoreCreatedPath({
						...createMoreCreatedPath,
						number: newIssue.number
					});
					if (isDuplicateDetectionEnabled) {
						resetDuplicateDetection?.();
						setIssueFormBody("");
					}
				} else clearOnCreate();
				if (!closeImmediately) onCreateSuccess({
					issue: newIssue,
					createMore: createMoreArg
				});
			}
		});
		if (closeImmediately) {
			clearOnCreate();
			onCreateSuccess({
				issue: {
					id: clientMutationIdRef.current ?? "",
					number: 0,
					repository: {
						name: repository.name,
						owner: { login: repository.owner.login },
						databaseId: void 0,
						id: ""
					},
					databaseId: void 0,
					title: "",
					url: "",
					" $fragmentSpreads": {}
				},
				createMore: false
			});
		}
	} }), [
		title,
		selectedTemplate,
		body,
		issueFormRef,
		titleValidationResult,
		repository,
		bodyValidationResult,
		setIsSubmitting,
		onBeforeCreate,
		labels,
		assignees,
		milestone?.id,
		canIssueType,
		issueType?.id,
		canSetIssueFields,
		issueFields,
		displayMode,
		parentIssueId,
		blockedByIssueIds,
		blockingIssueIds,
		copilotAssignmentAttributes,
		setIsCopilotAssignmentDialogOpen,
		environment,
		onCreateError,
		sendAnalyticsEvent,
		projects,
		onCreateSuccess,
		setCreateMoreCreatedPath,
		createMoreCreatedPath,
		clearOnCreate,
		addToast,
		isCreatingSubIssueFromProject,
		isDuplicateDetectionEnabled,
		resetDuplicateDetection,
		trackDuplicateDetectionIssueCreated,
		setIssueFormBody
	]);
	const handleTitleChange = (e) => {
		const inputTitle = e.currentTarget.value;
		validateAndSetTitle(inputTitle);
	};
	const validateAndSetTitle = (newTitle) => {
		if (validateIssueTitle(newTitle).isValid) setTitleValidationResult(void 0);
		setTitle(newTitle);
		postSemanticSearchAnalytics(newTitle, body);
	};
	const handleBodyChange = (inputBody) => {
		validateAndSetBody(inputBody);
	};
	const validateAndSetBody = (newBody) => {
		setBodyValidationResult(validateIssueBody(newBody).errorMessage);
		setBody(newBody);
		postSemanticSearchAnalytics(title, newBody);
	};
	const subject = useMemo(() => {
		if (repository) return {
			type: "issue",
			repository: {
				databaseId: repository.databaseId,
				nwo: `${repository.owner.login}/${repository.name}`,
				slashCommandsEnabled: repository.slashCommandsEnabled
			}
		};
	}, [repository]);
	const validationErrorId = useId();
	const footerButtons = [];
	const navigate = useNavigate$1();
	const copilotCTARef = useRef(null);
	const assigneesButtonRef = useRef(null);
	const commentBoxRef = useRef(null);
	const [isCopilotCTADialogOpen, setIsCopilotCTADialogOpen] = useState(false);
	const [isCopilotGenerateDialogOpen, setIsCopilotGenerateDialogOpen] = useState(false);
	const isCreateIssueDescriptionWithCopilotEnabled = isFeatureEnabled("create_issue_description_with_copilot");
	const shouldUseDialogCopilotWriting = isCreateIssueDescriptionWithCopilotEnabled && shouldShowCopilotFunctionality;
	const { isPanelOpen: isCopilotGeneratePanelOpen, isGenerating: isCopilotGenerating, shouldShowCopilot: shouldUseInlineCopilotWriting, togglePanel: toggleCopilotPanel, handleInputFocus: handleCommentBoxInputFocus, commands: copilotPanelCommands, panelProps: copilotPanelProps, containerStyle: copilotContainerStyle } = useCopilotGeneratePanel({
		editorRef: commentBoxRef,
		body,
		onChange: (newBody, newTitle) => {
			validateAndSetBody(newBody);
			if (newTitle !== void 0) validateAndSetTitle(newTitle);
		},
		shouldShowCopilotFunctionality,
		repoOwner: repository.owner.login,
		repoName: repository.name,
		title,
		generateTitle: true,
		commandId: "issue-create:open-copilot-panel",
		canToggle: viewMode !== "preview"
	});
	useEffect(() => {
		const assigneesButton = document.getElementById("assignees-select-menu");
		if (assigneesButton) assigneesButtonRef.current = assigneesButton;
	}, []);
	const navigateToCopilot = () => {
		sendAnalyticsEvent("analytics.click", "ISSUE_CREATE_NEW_ISSUE_WITH_COPILOT_BUTTON", { repoNWO: `${repository.owner.login}/${repository.name}` });
		const prompt = `Create an issue in ${repository.nameWithOwner} to `;
		navigate(`${COPILOT_PATH}?${new URLSearchParams({ prompt }).toString()}`);
	};
	const handleGenerateDescription = (generatedTitle, generatedDescription) => {
		setTitle(generatedTitle);
		setBody(generatedDescription);
		setIsCopilotGenerateDialogOpen(false);
	};
	const handleCTAOnClick = () => {
		if (shouldUseInlineCopilotWriting) toggleCopilotPanel();
		else if (isCreateIssueDescriptionWithCopilotEnabled) setIsCopilotGenerateDialogOpen(true);
		else if (body.length || title.length) setIsCopilotCTADialogOpen(true);
		else navigateToCopilot();
	};
	if (shouldShowCopilotFunctionality && !shouldUseInlineCopilotWriting) footerButtons.push(/* @__PURE__ */ jsx(MarkdownEditor.FooterButton, {
		ref: copilotCTARef,
		variant: "invisible",
		leadingVisual: shouldUseDialogCopilotWriting ? CopilotIcon : ArrowUpRightIcon,
		size: "small",
		className: CreateIssueForm_module_default.footerButton,
		onClick: () => {
			handleCTAOnClick();
		},
		children: LABELS$2.copilotCTAButton
	}, "create-issue-with-copilot"));
	const handleCloseCopilotModal = () => {
		setIsCopilotAssignmentDialogOpen(false);
	};
	const onCopilotModalSubmit = (repositoryId, branch, instructions, selectedAgent, model) => {
		setCopilotAssignmentAttributes({
			targetRepositoryId: repositoryId,
			baseRef: branch,
			customInstructions: instructions,
			customAgent: selectedAgent?.subAgentSlug,
			model
		});
		if (selectedAgent?.displayName && selectedAgent?.login && selectedAgent?.botGlobalRelayId) {
			if (!isCopilot(selectedAgent.login)) {
				const agentAssignee = {
					id: selectedAgent.botGlobalRelayId ?? "",
					login: selectedAgent.login,
					name: selectedAgent.displayName,
					avatarUrl: selectedAgent.avatarUrl ?? "",
					__typename: "Bot",
					isCopilot: false,
					isAgent: true,
					displayName: selectedAgent.displayName
				};
				replaceAssignees(assignees.map((a) => isCopilot(a.login) ? agentAssignee : a));
			}
		}
		handleCloseCopilotModal();
	};
	const mainContent = showUserRestrictedView ? restrictedViewContent : /* @__PURE__ */ jsxs(Fragment$1, { children: [
		isCopilotCTADialogOpen && /* @__PURE__ */ jsx(Dialog, {
			title: LABELS$2.copilotCTADialogTitle,
			onClose: () => setIsCopilotCTADialogOpen(false),
			footerButtons: [{
				buttonType: "default",
				content: LABELS$2.copilotCTADialogCancelButton,
				onClick: () => setIsCopilotCTADialogOpen(false)
			}, {
				buttonType: "primary",
				content: LABELS$2.copilotCTADialogContinueButton,
				onClick: navigateToCopilot
			}],
			returnFocusRef: copilotCTARef,
			children: LABELS$2.copilotCTADialogDescription
		}),
		!shouldUseInlineCopilotWriting && isCreateIssueDescriptionWithCopilotEnabled && /* @__PURE__ */ jsx(CopilotGenerateDescriptionDialog, {
			isOpen: isCopilotGenerateDialogOpen,
			onClose: () => setIsCopilotGenerateDialogOpen(false),
			onGenerate: handleGenerateDescription,
			repoOwner: repository.owner.login,
			repoName: repository.name,
			title,
			body,
			returnFocusRef: copilotCTARef
		}),
		submissionErrors && /* @__PURE__ */ jsx(Banner, {
			ref: errorBanner,
			title: "Error",
			description: /* @__PURE__ */ jsx(AriaAlert, { children: submissionErrors }),
			variant: "critical",
			className: CreateIssueForm_module_default.errorBanner,
			role: "alert"
		}),
		/* @__PURE__ */ jsx(CopilotAssignmentModal, {
			isOpen: isCopilotAssignmentDialogOpen,
			onClose: handleCloseCopilotModal,
			onSubmit: onCopilotModalSubmit,
			repository: {
				name: repository.name,
				owner: { login: repository.owner.login }
			},
			returnFocusRef: assigneesButtonRef
		}),
		/* @__PURE__ */ jsx(CreateIssueFormTitle, {
			title,
			titleInputRef,
			handleTitleChange,
			titleValidationResult
		}),
		subject && !isIssueForm && /* @__PURE__ */ jsx(ScopedCommands, {
			commands: copilotPanelCommands,
			children: /* @__PURE__ */ jsxs("div", {
				className: CreateIssueForm_module_default.commentBox,
				style: copilotContainerStyle,
				children: [
					/* @__PURE__ */ jsx(CommentBox, {
						ref: commentBoxRef,
						subject,
						label: LABELS$2.issueCreateBodyLabel,
						showLabel: true,
						placeholder: LABELS$2.issueBodyPlaceholder,
						viewMode,
						onChangeViewMode: setViewMode,
						value: body,
						onSave: () => onCreateAction?.current?.onCreate(isSubmitting, createMore),
						onChange: handleBodyChange,
						saveButtonTrailingIcon: false,
						minHeightLines: optionConfig.insidePortal ? 14 : 20,
						"aria-describedby": bodyValidationResult ? validationErrorId : void 0,
						setIsFileUploading,
						toolbarButtons: shouldUseInlineCopilotWriting ? /* @__PURE__ */ jsx(MarkdownEditor.ToolbarButton, {
							variant: "invisible",
							icon: PencilAiIcon,
							size: "small",
							className: CreateIssueForm_module_default.copilotWriteButton,
							onClick: toggleCopilotPanel,
							"aria-pressed": isCopilotGeneratePanelOpen,
							"aria-label": LABELS$2.copilotCTAButton
						}) : null,
						footerButtons,
						disabled: isCopilotGenerating,
						generatingText: isCopilotGenerating,
						onInputFocus: handleCommentBoxInputFocus
					}),
					shouldUseInlineCopilotWriting && isCopilotGeneratePanelOpen && viewMode !== "preview" && /* @__PURE__ */ jsx(CopilotGenerateDescriptionPanel, { ...copilotPanelProps }),
					bodyValidationResult && /* @__PURE__ */ jsxs(Flash, {
						variant: "danger",
						id: validationErrorId,
						children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), bodyValidationResult]
					})
				]
			})
		}),
		subject && isIssueForm && instanceOfIssueFormData(selectedTemplate.data) && /* @__PURE__ */ jsx(IssueFormElements, {
			outputRef: issueFormRef,
			issueFormRef: selectedTemplate.data,
			subject,
			sessionStorageKey: usedStorageKeyPrefix,
			defaultValuesById: selectedDefaultValuesById,
			onSave: () => onCreateAction?.current?.onCreate(isSubmitting, createMore),
			setIsFileUploading,
			onFieldChange: isDuplicateDetectionEnabled ? handleFormFieldChangeForDuplicateDetection : onFieldChange
		})
	] });
	const metadataContent = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(MetadataSelectors, {
		orgPinnedFields: secondaryIssueFormData?.orgPinnedFields ?? EMPTY_ORG_PINNED_FIELDS,
		isPinnedFieldsLoading: secondaryIssueFormData === null
	}), secondaryIssueFormData && /* @__PURE__ */ jsx(ContributorFooter, {
		supportFileUrl: secondaryIssueFormData.supportFileUrl ?? void 0,
		codeOfConductFileUrl: secondaryIssueFormData.codeOfConductFileUrl ?? void 0,
		securityPolicyUrl: secondaryIssueFormData.securityPolicyUrl ?? void 0,
		contributingFileUrl: secondaryIssueFormData.contributingFileUrl ?? void 0
	})] });
	const footerContent = showUserRestrictedView ? null : /* @__PURE__ */ jsx(Fragment$1, { children: footer && /* @__PURE__ */ jsx(Box, {
		className: clsx(!optionConfig.insidePortal && isDuplicateDetectionEnabled && CreateIssueForm_module_default.duplicateDetectionStickyFooter),
		sx: {
			gridArea: "footer",
			mt: [
				4,
				4,
				isIssueForm ? 2 : 0
			]
		},
		children: footer
	}) });
	if (showMetadataSidepanel) return /* @__PURE__ */ jsx("div", {
		className: CreateIssueForm_module_default.CreateIssueFormWrapper,
		children: /* @__PURE__ */ jsxs(Box, {
			className: clsx("width-fit", CreateIssueForm_module_default.formGridContainer),
			sx: { gridTemplateAreas: `
              "body metadata"
              "footer nil"
            ` },
			children: [
				/* @__PURE__ */ jsx("div", {
					className: CreateIssueForm_module_default.mainContentSection,
					children: mainContent
				}),
				/* @__PURE__ */ jsx("div", {
					className: CreateIssueForm_module_default.metadataSection,
					children: metadataContent
				}),
				footerContent
			]
		})
	});
	else return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		mainContent,
		metadataContent,
		footerContent
	] });
};
CreateIssueForm.displayName = "CreateIssueForm";
function assignIssueToProjects(issueId, projects, environment) {
	for (const project of projects) commitUpdateIssueProjectsMutation({
		environment,
		issueId,
		projectId: project.id
	});
}
function formatError(message) {
	return /* @__PURE__ */ new Error(`Issue create mutation failed with error: ${message}`);
}
var DEFAULT_NOTICE = LABELS$2.crossRepoIssueDuplicationDefaultWarning;
var useOnRepositoryChange = () => {
	const $ = c(43);
	const { repository, setRepository, assignees, setAssignees, issueType, setIssueType, issueFields, setIssueFields, milestone, setMilestone, labels, setLabels } = useIssueCreateDataContext();
	let t0;
	if ($[0] !== assignees || $[1] !== issueFields || $[2] !== issueType || $[3] !== labels || $[4] !== milestone || $[5] !== repository) {
		t0 = {
			repository,
			assignees,
			issueType,
			issueFields,
			milestone,
			labels
		};
		$[0] = assignees;
		$[1] = issueFields;
		$[2] = issueType;
		$[3] = labels;
		$[4] = milestone;
		$[5] = repository;
		$[6] = t0;
	} else t0 = $[6];
	const [initialMetadata, setInitialMetadata] = useState(t0);
	const [notice, setNotice] = useState(DEFAULT_NOTICE);
	let t1;
	if ($[7] !== initialMetadata.assignees || $[8] !== initialMetadata.issueFields || $[9] !== initialMetadata.issueType || $[10] !== initialMetadata.labels || $[11] !== initialMetadata.milestone || $[12] !== initialMetadata.repository?.id || $[13] !== initialMetadata.repository?.owner?.databaseId || $[14] !== initialMetadata.repository?.owner?.issueTypesEnabled || $[15] !== setAssignees || $[16] !== setIssueFields || $[17] !== setIssueType || $[18] !== setLabels || $[19] !== setMilestone || $[20] !== setRepository) {
		t1 = (newRepository) => {
			if (!newRepository) return;
			const droppedMetadata = [];
			const isSameRepo = newRepository.id === initialMetadata.repository?.id;
			const isSameOwner = newRepository.owner?.databaseId === initialMetadata.repository?.owner?.databaseId;
			if (isSameRepo) {
				setAssignees?.(initialMetadata.assignees);
				setIssueFields?.(initialMetadata.issueFields);
				setIssueType?.(initialMetadata.issueType);
				setMilestone?.(initialMetadata.milestone);
				setLabels?.(initialMetadata.labels);
			} else {
				setMilestone?.(null);
				droppedMetadata.push("Milestone", "Labels");
				if (isSameOwner) {
					setAssignees?.(initialMetadata.assignees);
					setIssueFields?.(initialMetadata.issueFields);
					setIssueType?.(initialMetadata.issueType);
				} else {
					setAssignees?.([]);
					setIssueFields?.([]);
					setIssueType?.(null);
					droppedMetadata.push("Assignees", "Fields");
					if (initialMetadata.repository?.owner?.issueTypesEnabled) droppedMetadata.push("Type");
				}
			}
			setNotice(droppedMetadata.length > 0 ? LABELS$2.crossRepoIssueDuplicationWarning(droppedMetadata) : DEFAULT_NOTICE);
			setRepository(newRepository);
		};
		$[7] = initialMetadata.assignees;
		$[8] = initialMetadata.issueFields;
		$[9] = initialMetadata.issueType;
		$[10] = initialMetadata.labels;
		$[11] = initialMetadata.milestone;
		$[12] = initialMetadata.repository?.id;
		$[13] = initialMetadata.repository?.owner?.databaseId;
		$[14] = initialMetadata.repository?.owner?.issueTypesEnabled;
		$[15] = setAssignees;
		$[16] = setIssueFields;
		$[17] = setIssueType;
		$[18] = setLabels;
		$[19] = setMilestone;
		$[20] = setRepository;
		$[21] = t1;
	} else t1 = $[21];
	const onRepositoryChange = t1;
	let t2;
	if ($[22] !== assignees || $[23] !== initialMetadata.repository || $[24] !== issueFields || $[25] !== issueType || $[26] !== labels || $[27] !== milestone || $[28] !== repository) {
		t2 = () => {
			if (initialMetadata.repository === void 0 || repository?.databaseId === initialMetadata.repository?.databaseId) setInitialMetadata({
				repository,
				assignees,
				issueType,
				issueFields,
				milestone,
				labels
			});
		};
		$[22] = assignees;
		$[23] = initialMetadata.repository;
		$[24] = issueFields;
		$[25] = issueType;
		$[26] = labels;
		$[27] = milestone;
		$[28] = repository;
		$[29] = t2;
	} else t2 = $[29];
	const t3 = initialMetadata.repository?.databaseId;
	let t4;
	if ($[30] !== assignees || $[31] !== initialMetadata.repository || $[32] !== issueFields || $[33] !== issueType || $[34] !== labels || $[35] !== milestone || $[36] !== repository || $[37] !== t3) {
		t4 = [
			repository,
			assignees,
			issueType,
			issueFields,
			milestone,
			labels,
			t3,
			initialMetadata.repository
		];
		$[30] = assignees;
		$[31] = initialMetadata.repository;
		$[32] = issueFields;
		$[33] = issueType;
		$[34] = labels;
		$[35] = milestone;
		$[36] = repository;
		$[37] = t3;
		$[38] = t4;
	} else t4 = $[38];
	useEffect(t2, t4);
	let t5;
	if ($[39] !== initialMetadata.repository || $[40] !== notice || $[41] !== onRepositoryChange) {
		t5 = {
			onRepositoryChange,
			notice,
			sourceRepository: initialMetadata.repository
		};
		$[39] = initialMetadata.repository;
		$[40] = notice;
		$[41] = onRepositoryChange;
		$[42] = t5;
	} else t5 = $[42];
	return t5;
};
function CreateDuplicateIssueForm(t0) {
	const $ = c(2);
	const { onCreateSuccess, topRepositories, issueFormRef, ...props } = t0;
	const { title, body, setBody, repository, setNewTitle, clearSessionData } = useIssueCreateDataContext();
	const { onRepositoryChange, notice, sourceRepository } = useOnRepositoryChange();
	const responsiveOnNarrowEnabled = isFeatureEnabled("issues_react_select_panel_fullscreen_on_narrow");
	let t1;
	if ($[0] !== sourceRepository?.id) {
		t1 = (repo) => {
			if (repo.id === sourceRepository?.id) return repo.viewerIssueCreationPermissions.triageable;
			else return repo.viewerIssueCreationPermissions.triageable && repo.isBlankIssuesEnabled;
		};
		$[0] = sourceRepository?.id;
		$[1] = t1;
	} else t1 = $[1];
	sourceRepository?.id;
	const getEligibleRepositoriesForIssueDuplication = t1;
	if (topRepositories === "unset" || !topRepositories || !repository) return null;
	return jsxs(Fragment$1, { children: [jsx(RepositoryPicker, {
		"aria-describedby": "Choose repository to duplicate issue in",
		initialRepository: repository,
		topRepositories,
		onSelect: onRepositoryChange,
		focusRepositoryPicker: true,
		enforceAtleastOneSelected: true,
		options: { hasIssuesEnabled: true },
		notice: {
			text: notice,
			variant: "warning"
		},
		repositoryFilter: getEligibleRepositoriesForIssueDuplication,
		responsiveOnNarrow: responsiveOnNarrowEnabled
	}), jsx(CreateIssueForm, {
		...props,
		issueFormRef,
		onCreateSuccess,
		repository,
		title,
		setTitle: setNewTitle,
		body,
		setBody,
		clearOnCreate: clearSessionData,
		focusTitleInput: false
	})] });
}
CreateDuplicateIssueForm.displayName = "CreateDuplicateIssueForm";
var CreateIssue_module_default = {
	CreateIssueContainer: "CreateIssue-module_AcScLa_CreateIssueContainer",
	LoadingContainer: "CreateIssue-module_AcScLa_LoadingContainer"
};
var useOnCreateSuccess = (t0) => {
	const $ = c(13);
	const { issueFormRef, callback, handleTemplateChange, navigate, template } = t0;
	const { clearTitleAndBody, clearSessionData, clearSessionMetadata, clearSessionTitleAndBody, clearSessionCreateMore } = useIssueCreateDataContext();
	let t1;
	if ($[0] !== callback || $[1] !== clearSessionData || $[2] !== clearSessionTitleAndBody || $[3] !== clearTitleAndBody || $[4] !== handleTemplateChange || $[5] !== issueFormRef || $[6] !== navigate || $[7] !== template) {
		t1 = (t2) => {
			const { issue, createMore } = t2;
			callback?.({
				issue,
				createMore
			});
			if (createMore) if (template && template.kind !== IssueCreationKind.BlankIssue ? template : void 0) {
				clearSessionTitleAndBody();
				issueFormRef.current?.resetInputs({ textOnly: true });
				handleTemplateChange(template);
			} else clearTitleAndBody();
			else {
				issueFormRef.current?.clearSessionStorage();
				clearSessionData();
				navigate?.(issuePath({
					owner: issue.repository.owner.login,
					repo: issue.repository.name,
					issueNumber: issue.number
				}));
			}
		};
		$[0] = callback;
		$[1] = clearSessionData;
		$[2] = clearSessionTitleAndBody;
		$[3] = clearTitleAndBody;
		$[4] = handleTemplateChange;
		$[5] = issueFormRef;
		$[6] = navigate;
		$[7] = template;
		$[8] = t1;
	} else t1 = $[8];
	const onCreateSuccess = t1;
	let t2;
	let t3;
	if ($[9] !== clearSessionCreateMore || $[10] !== clearSessionMetadata) {
		t2 = () => () => {
			clearSessionMetadata();
			clearSessionCreateMore();
		};
		t3 = [clearSessionCreateMore, clearSessionMetadata];
		$[9] = clearSessionCreateMore;
		$[10] = clearSessionMetadata;
		$[11] = t2;
		$[12] = t3;
	} else {
		t2 = $[11];
		t3 = $[12];
	}
	useEffect(t2, t3);
	return onCreateSuccess;
};
var TEST_IDS = {
	createIssueButton: "create-issue-button",
	createMoreIssuesCheckbox: "create-more-check",
	templateList: "template-list",
	issueCreatedLink: "issue-created-link",
	issueCreatedAnnouncement: "issue-created-announcement",
	repositoryAndTemplateDialog: "repository-and-template-picker-dialog",
	templatePickerButton: "template-picker-button"
};
var TemplateList_module_default = {
	skeletonContainer: "TemplateList-module_3vE-0W_skeletonContainer",
	templateHeader: "TemplateList-module_3vE-0W_templateHeader"
};
var loadingSkeletonWidths = [
	"220px",
	"250px",
	"290px",
	"210px"
].map((width, index) => ({
	id: `skeleton-${index}`,
	width
}));
function TemplateListLoading() {
	const $ = c(2);
	const { optionConfig } = useIssueCreateConfigContext();
	const t0 = `${TemplateList_module_default.skeletonContainer} ${optionConfig.insidePortal && "tmp-ml-3"}`;
	let t1;
	if ($[0] !== t0) {
		t1 = jsx("div", {
			className: t0,
			children: loadingSkeletonWidths.map(_temp$2)
		});
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
TemplateListLoading.displayName = "TemplateListLoading";
function _temp$2(t0) {
	const { id, width } = t0;
	return jsx(IssuesLoadingSkeleton, {
		height: "xl",
		width
	}, id);
}
var node$10 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "filename",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "about",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "TemplateListPaneQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "TemplateListPane"
					}],
					"type": "Repository",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "TemplateListPaneQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "id",
						"storageKey": null
					},
					{
						"kind": "InlineFragment",
						"selections": [
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "hasIssuesEnabled",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "nameWithOwner",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "IssueForm",
								"kind": "LinkedField",
								"name": "issueForms",
								"plural": true,
								"selections": [
									v2,
									v3,
									v4,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "description",
										"storageKey": null
									}
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "IssueTemplate",
								"kind": "LinkedField",
								"name": "issueTemplates",
								"plural": true,
								"selections": [
									v2,
									v3,
									v4,
									v5
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isBlankIssuesEnabled",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isBlankIssuesMaintainerOverride",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "isSecurityPolicyEnabled",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "securityPolicyUrl",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "RepositoryContactLink",
								"kind": "LinkedField",
								"name": "contactLinks",
								"plural": true,
								"selections": [
									v4,
									v5,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "url",
										"storageKey": null
									}
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "hasAnyTemplates",
								"storageKey": null
							}
						],
						"type": "Repository",
						"abstractKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "ad8aeb3f2b97aee44c655f5ed9fb6181",
			"metadata": {},
			"name": "TemplateListPaneQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$10.hash = "48fd58d3a414612124beb28d391e3930";
var node$9 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TemplateListPane",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, {
		"args": null,
		"kind": "FragmentSpread",
		"name": "TemplateList"
	}],
	"type": "Repository",
	"abstractKey": null
};
node$9.hash = "881cdbdb34820ab9cdf5b5c8e6409bb0";
var node$8 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "filename",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "TemplateList",
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "nameWithOwner",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "IssueForm",
				"kind": "LinkedField",
				"name": "issueForms",
				"plural": true,
				"selections": [
					v0,
					v1,
					{
						"args": null,
						"kind": "FragmentSpread",
						"name": "IssueFormRow"
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "IssueTemplate",
				"kind": "LinkedField",
				"name": "issueTemplates",
				"plural": true,
				"selections": [
					v0,
					v1,
					{
						"args": null,
						"kind": "FragmentSpread",
						"name": "IssueTemplateRow"
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isBlankIssuesEnabled",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isBlankIssuesMaintainerOverride",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isSecurityPolicyEnabled",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "securityPolicyUrl",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "RepositoryContactLink",
				"kind": "LinkedField",
				"name": "contactLinks",
				"plural": true,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				}, {
					"args": null,
					"kind": "FragmentSpread",
					"name": "ExternalLinkTemplateRow"
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "hasAnyTemplates",
				"storageKey": null
			}
		],
		"type": "Repository",
		"abstractKey": null
	};
})();
node$8.hash = "60173277f9653eb27e95f30b7198d399";
var IssueTemplateItem_module_default = {
	actionListTitle: "IssueTemplateItem-module_ESPJua_actionListTitle",
	inlineLabel: "IssueTemplateItem-module_ESPJua_inlineLabel",
	templateItemContainer: "IssueTemplateItem-module_ESPJua_templateItemContainer"
};
var IssueTemplateItem = ({ filename, onTemplateSelected, name, about, link, externalLink, trailingIcon, inlineLabel }) => {
	const wrappedOnClick = (e) => {
		if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
		if (!externalLink && !link) {
			e.preventDefault();
			e.stopPropagation();
		}
		onTemplateSelected(filename);
	};
	return /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		as: Link$1,
		to: link ?? "#",
		target: externalLink ? "_blank" : void 0,
		onClick: wrappedOnClick,
		className: IssueTemplateItem_module_default.templateItemContainer,
		children: [
			/* @__PURE__ */ jsxs("span", {
				className: IssueTemplateItem_module_default.actionListTitle,
				children: [name, inlineLabel && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(VisuallyHidden, { children: ` (${inlineLabel})` }), /* @__PURE__ */ jsx(Label, {
					size: "small",
					variant: "secondary",
					className: IssueTemplateItem_module_default.inlineLabel,
					"aria-hidden": "true",
					children: inlineLabel
				})] })]
			}),
			/* @__PURE__ */ jsx(ActionList.Description, {
				variant: "block",
				children: about
			}),
			/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: trailingIcon ?? /* @__PURE__ */ jsx(ArrowRightIcon, {}) })
		]
	}, filename);
};
IssueTemplateItem.displayName = "IssueTemplateItem";
var BlankIssueItem = ({ nameWithOwner, onTemplateSelected, isMaintainerOverride }) => {
	return /* @__PURE__ */ jsx(IssueTemplateItem, {
		filename: BLANK_ISSUE_ID,
		onTemplateSelected: () => onTemplateSelected?.(BLANK_ISSUE_ID, IssueCreationKind.BlankIssue),
		name: LABELS$2.blankIssueName,
		about: LABELS$2.blankIssueDescription,
		inlineLabel: isMaintainerOverride ? LABELS$2.blankIssueMaintainerLabel : void 0,
		link: onTemplateSelected ? void 0 : getTemplateUrl(nameWithOwner, BLANK_ISSUE_ID)
	});
};
BlankIssueItem.displayName = "BlankIssueItem";
var node$7 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "ExternalLinkTemplateRow",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "about",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "url",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		}
	],
	"type": "RepositoryContactLink",
	"abstractKey": null
};
node$7.hash = "89d8106fd30fe009b4d13c1f4908f32e";
var ExternalLinkTemplateRow = (t0) => {
	const $ = c(4);
	const { repositoryContactLink } = t0;
	const data = (0, import_react_relay.useFragment)(node$7, repositoryContactLink);
	let t1;
	if ($[0] !== data.about || $[1] !== data.name || $[2] !== data.url) {
		t1 = jsx(IssueTemplateItem, {
			filename: data.name,
			onTemplateSelected: noop$1,
			name: data.name,
			link: data.url,
			about: data.about,
			externalLink: true,
			trailingIcon: jsx(LinkExternalIcon, {})
		});
		$[0] = data.about;
		$[1] = data.name;
		$[2] = data.url;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
ExternalLinkTemplateRow.displayName = "ExternalLinkTemplateRow";
var node$6 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueFormRow",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "description",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "filename",
			"storageKey": null
		}
	],
	"type": "IssueForm",
	"abstractKey": null
};
node$6.hash = "4707734c7aff8e836f17a948f0fc6e8d";
var IssueFormRow = (t0) => {
	const $ = c(9);
	const { nameWithOwner, form, onTemplateSelected } = t0;
	const data = (0, import_react_relay.useFragment)(node$6, form);
	let t1;
	if ($[0] !== onTemplateSelected) {
		t1 = (filename) => onTemplateSelected?.(filename, IssueCreationKind.IssueForm);
		$[0] = onTemplateSelected;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== data.description || $[3] !== data.filename || $[4] !== data.name || $[5] !== nameWithOwner || $[6] !== onTemplateSelected || $[7] !== t1) {
		t2 = jsx(IssueTemplateItem, {
			filename: data.filename,
			onTemplateSelected: t1,
			name: data.name,
			about: data.description,
			link: onTemplateSelected ? void 0 : getTemplateUrl(nameWithOwner, data.filename)
		});
		$[2] = data.description;
		$[3] = data.filename;
		$[4] = data.name;
		$[5] = nameWithOwner;
		$[6] = onTemplateSelected;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
};
IssueFormRow.displayName = "IssueFormRow";
var node$5 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueTemplateRow",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "about",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "filename",
			"storageKey": null
		}
	],
	"type": "IssueTemplate",
	"abstractKey": null
};
node$5.hash = "2047157ce521e245c1030871b4d976b7";
var IssueTemplateRow = (t0) => {
	const $ = c(9);
	const { nameWithOwner, template, onTemplateSelected } = t0;
	const data = (0, import_react_relay.useFragment)(node$5, template);
	let t1;
	if ($[0] !== onTemplateSelected) {
		t1 = (filename) => onTemplateSelected?.(filename, IssueCreationKind.IssueTemplate);
		$[0] = onTemplateSelected;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== data.about || $[3] !== data.filename || $[4] !== data.name || $[5] !== nameWithOwner || $[6] !== onTemplateSelected || $[7] !== t1) {
		t2 = jsx(IssueTemplateItem, {
			filename: data.filename,
			onTemplateSelected: t1,
			name: data.name,
			about: data.about,
			link: onTemplateSelected ? void 0 : getTemplateUrl(nameWithOwner, data.filename)
		});
		$[2] = data.about;
		$[3] = data.filename;
		$[4] = data.name;
		$[5] = nameWithOwner;
		$[6] = onTemplateSelected;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
};
IssueTemplateRow.displayName = "IssueTemplateRow";
var SecurityPolicyRow = ({ link }) => {
	return /* @__PURE__ */ jsx(IssueTemplateItem, {
		filename: "default-security-policy",
		link,
		externalLink: true,
		onTemplateSelected: noop$1,
		name: LABELS$2.securityPolicyName,
		about: LABELS$2.securityPolicyDescription,
		trailingIcon: /* @__PURE__ */ jsx(ShieldIcon, {})
	});
};
SecurityPolicyRow.displayName = "SecurityPolicyRow";
function TemplateList(t0) {
	const $ = c(22);
	const { repository, onTemplateSelected, className, setIsNavigatingToNew } = t0;
	const { optionConfig, displayMode } = useIssueCreateConfigContext();
	const data = (0, import_react_relay.useFragment)(node$8, repository);
	if (!data.hasAnyTemplates && !data.isBlankIssuesEnabled && !data.isSecurityPolicyEnabled) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx("span", { children: LABELS$2.noTemplates });
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	}
	if (optionConfig.canBypassTemplateSelection) {
		let t1;
		if ($[1] !== data || $[2] !== optionConfig || $[3] !== setIsNavigatingToNew) {
			t1 = Symbol.for("react.early_return_sentinel");
			bb0: {
				const directHrefToIssueCreate = getDirectUrlToIssueCreate(data);
				if (directHrefToIssueCreate) {
					setIsNavigatingToNew?.(true);
					optionConfig.navigate?.(directHrefToIssueCreate);
					t1 = null;
					break bb0;
				} else setIsNavigatingToNew?.(false);
			}
			$[1] = data;
			$[2] = optionConfig;
			$[3] = setIsNavigatingToNew;
			$[4] = t1;
		} else t1 = $[4];
		if (t1 !== Symbol.for("react.early_return_sentinel")) return t1;
	}
	let t1;
	if ($[5] !== className || $[6] !== data.contactLinks || $[7] !== data.isBlankIssuesEnabled || $[8] !== data.isBlankIssuesMaintainerOverride || $[9] !== data.isSecurityPolicyEnabled || $[10] !== data.issueForms || $[11] !== data.issueTemplates || $[12] !== data.nameWithOwner || $[13] !== data.securityPolicyUrl || $[14] !== displayMode || $[15] !== onTemplateSelected || $[16] !== optionConfig.insidePortal || $[17] !== optionConfig.showRepositoryPicker) {
		const issueForms = data.issueForms || [];
		const issueTemplates = data.issueTemplates || [];
		let t2;
		if ($[19] !== data.nameWithOwner || $[20] !== onTemplateSelected) {
			t2 = (template) => {
				if (template.__typename === "IssueForm") return jsx(IssueFormRow, {
					onTemplateSelected,
					form: template,
					nameWithOwner: data.nameWithOwner
				}, template.filename);
				return jsx(IssueTemplateRow, {
					onTemplateSelected,
					template,
					nameWithOwner: data.nameWithOwner
				}, template.filename);
			};
			$[19] = data.nameWithOwner;
			$[20] = onTemplateSelected;
			$[21] = t2;
		} else t2 = $[21];
		const templateContent = jsxs(Fragment$1, { children: [
			[...issueForms, ...issueTemplates].sort(_temp$1).map(t2),
			data.isBlankIssuesEnabled && jsx(BlankIssueItem, {
				onTemplateSelected,
				nameWithOwner: data.nameWithOwner,
				isMaintainerOverride: data.isBlankIssuesMaintainerOverride
			}, "BLANK_ISSUE"),
			data.isSecurityPolicyEnabled && jsx(SecurityPolicyRow, { link: data.securityPolicyUrl }, "security_policy"),
			data.contactLinks && data.contactLinks.map(_temp2$1)
		] });
		t1 = jsx(Fragment$1, { children: jsx(ActionList, {
			className,
			"data-testid": TEST_IDS.templateList,
			showDividers: true,
			variant: "inset",
			children: optionConfig.showRepositoryPicker && displayMode === DisplayMode.TemplatePicker ? jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, {
				as: "h2",
				variant: "filled",
				className: `position-sticky top-0 x ${!optionConfig.insidePortal && "border-top-0"} ${TemplateList_module_default.templateHeader}`,
				children: LABELS$2.templatesFormsTitle
			}), templateContent] }) : templateContent
		}) });
		$[5] = className;
		$[6] = data.contactLinks;
		$[7] = data.isBlankIssuesEnabled;
		$[8] = data.isBlankIssuesMaintainerOverride;
		$[9] = data.isSecurityPolicyEnabled;
		$[10] = data.issueForms;
		$[11] = data.issueTemplates;
		$[12] = data.nameWithOwner;
		$[13] = data.securityPolicyUrl;
		$[14] = displayMode;
		$[15] = onTemplateSelected;
		$[16] = optionConfig.insidePortal;
		$[17] = optionConfig.showRepositoryPicker;
		$[18] = t1;
	} else t1 = $[18];
	return t1;
}
TemplateList.displayName = "TemplateList";
function _temp2$1(link) {
	return jsx(ExternalLinkTemplateRow, { repositoryContactLink: link }, `contact_links.${link.name}`);
}
function _temp$1(a, b) {
	return a.filename.localeCompare(b.filename);
}
function getDirectUrlToIssueCreate(data) {
	if (data.contactLinks && data.contactLinks.length > 0) return null;
	if (data.isSecurityPolicyEnabled && data.securityPolicyUrl) return null;
	if (data.isBlankIssuesEnabled) return null;
	let singleTemplateOrFormFilename = null;
	if (data.issueForms) {
		if (data.issueForms.length === 1) singleTemplateOrFormFilename = data.issueForms[0].filename;
		else if (data.issueForms.length > 1) return null;
	}
	if (data.issueTemplates) {
		if (singleTemplateOrFormFilename) {
			if (data.issueTemplates.length > 0) return null;
		} else if (data.issueTemplates.length === 1) singleTemplateOrFormFilename = data.issueTemplates[0].filename;
	}
	if (!singleTemplateOrFormFilename) return null;
	return newTemplateAbsolutePath({
		repositoryAbsolutePath: `${ssrSafeLocation?.origin ?? ""}/${data.nameWithOwner}`,
		fileName: singleTemplateOrFormFilename
	});
}
var TemplateListPane_module_default = { disabledStateGap: "TemplateListPane-module_YNXgtW_disabledStateGap" };
var TemplateListPaneGraphQLQuery = node$10;
function TemplateListPaneFromRepo(t0) {
	const $ = c(2);
	const { repositoryId, ...props } = t0;
	let t1;
	if ($[0] !== repositoryId) {
		t1 = { id: repositoryId };
		$[0] = repositoryId;
		$[1] = t1;
	} else t1 = $[1];
	const data = (0, import_react_relay.useLazyLoadQuery)(TemplateListPaneGraphQLQuery, t1);
	if (!data.node) return null;
	return jsx(TemplateListInternal, {
		repository: data.node,
		...props
	});
}
TemplateListPaneFromRepo.displayName = "TemplateListPaneFromRepo";
function TemplateListInternal(t0) {
	const { repository, descriptionId, ...props } = t0;
	const { optionConfig } = useIssueCreateConfigContext();
	const { insidePortal } = optionConfig;
	const data = (0, import_react_relay.useFragment)(node$9, repository);
	return jsx("div", { children: data.hasIssuesEnabled ? jsx(TemplateList, {
		repository: data,
		...props,
		className: `${!insidePortal ? `border borderColor-muted rounded-2 overflow-hidden
                ${optionConfig.showRepositoryPicker ? "pt-0 mt-0" : "py-2 mt-2"}` : ""}`
	}) : jsxs("div", {
		className: `${TemplateListPane_module_default.disabledStateGap} d-flex flex-row flex-items-center tmp-m-3`,
		children: [jsx(InfoIcon, {}), jsx("span", {
			id: descriptionId,
			children: LABELS$2.issuesDisabledForRepo
		})]
	}) });
}
TemplateListInternal.displayName = "TemplateListInternal";
function RepositoryAndTemplatePicker(t0) {
	const $ = c(10);
	const { repository, topRepositories, organization, onRepositorySelected, onTemplateSelected } = t0;
	const { optionConfig } = useIssueCreateConfigContext();
	const descriptionId = useId();
	const repoLeftMargin = optionConfig.insidePortal ? "tmp-ml-3" : "ml-0";
	const t1 = optionConfig.insidePortal ? "pt-2" : "";
	let t2;
	if ($[0] !== descriptionId || $[1] !== onRepositorySelected || $[2] !== onTemplateSelected || $[3] !== optionConfig.insidePortal || $[4] !== organization || $[5] !== repoLeftMargin || $[6] !== repository || $[7] !== t1 || $[8] !== topRepositories) {
		t2 = jsxs("div", {
			className: t1,
			"data-testid": TEST_IDS.repositoryAndTemplateDialog,
			children: [
				jsx(Field, {
					className: repoLeftMargin,
					name: "Repository"
				}),
				jsx("div", {
					className: `${optionConfig.insidePortal ? "mb-2" : "tmp-mb-3"} ${repoLeftMargin}`,
					children: jsx(RepositoryPicker, {
						"aria-describedby": descriptionId,
						initialRepository: repository,
						onSelect: onRepositorySelected,
						organization,
						topRepositories,
						focusRepositoryPicker: true,
						enforceAtleastOneSelected: true,
						options: {
							hasIssuesEnabled: true,
							includeForks: true
						}
					})
				}),
				jsx(Suspense, {
					fallback: jsx(TemplateListLoading, {}),
					children: repository && jsx(TemplateListPaneFromRepo, {
						repositoryId: repository.id,
						onTemplateSelected,
						descriptionId
					})
				})
			]
		});
		$[0] = descriptionId;
		$[1] = onRepositorySelected;
		$[2] = onTemplateSelected;
		$[3] = optionConfig.insidePortal;
		$[4] = organization;
		$[5] = repoLeftMargin;
		$[6] = repository;
		$[7] = t1;
		$[8] = topRepositories;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
RepositoryAndTemplatePicker.displayName = "RepositoryAndTemplatePicker";
function Field({ name, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: `pt-1 pb-1 ${className}`,
		children: [/* @__PURE__ */ jsx("span", {
			className: "text-bold",
			children: name
		}), /* @__PURE__ */ jsx("span", {
			className: "ml-1 mb-1 fgColor-danger",
			children: "*"
		})]
	});
}
Field.displayName = "Field";
var node$4 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "TemplatePickerButton",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}],
	"type": "Repository",
	"abstractKey": null
};
node$4.hash = "fc9ace64aa764ca00db0ea2f61b67a2b";
var TemplatePickerButton_module_default = {
	repositoryConnectorText: "TemplatePickerButton-module_aLmAaG_repositoryConnectorText",
	TemplatePickerButtonContainer: "TemplatePickerButton-module_aLmAaG_TemplatePickerButtonContainer"
};
function TemplatePickerButton({ repository, template }) {
	const data = (0, import_react_relay.useFragment)(node$4, repository);
	const { setDisplayMode } = useIssueCreateConfigContext();
	const templateText = template ? template.name : LABELS$2.blankIssueName;
	const templatePickerButtonRef = useRef(null);
	useEffect(() => {
		templatePickerButtonRef.current?.focus();
	}, []);
	if (!data.hasAnyTemplates) return null;
	return /* @__PURE__ */ jsx("div", {
		"data-testid": "template-picker-button",
		className: TemplatePickerButton_module_default.TemplatePickerButtonContainer,
		children: /* @__PURE__ */ jsxs(ButtonComponent, {
			"data-testid": "template-picker-button-el",
			onClick: () => setDisplayMode(DisplayMode.TemplatePicker),
			leadingVisual: RepoIcon,
			trailingVisual: PencilIcon,
			ref: templatePickerButtonRef,
			children: [data && /* @__PURE__ */ jsxs("span", { children: [
				templateText,
				" ",
				/* @__PURE__ */ jsx("span", {
					className: TemplatePickerButton_module_default.repositoryConnectorText,
					children: "in"
				}),
				" ",
				data.nameWithOwner
			] }), !repository && /* @__PURE__ */ jsx(Fragment$1, { children: "Select a repository" })]
		})
	});
}
TemplatePickerButton.displayName = "TemplatePickerButton";
var node$3 = {
	"kind": "InlineDataFragment",
	"name": "useHandleTemplateChangeIssueTemplate"
};
node$3.hash = "f40f14b9fc5e68c991814566f1700581";
var node$2 = {
	"kind": "InlineDataFragment",
	"name": "useHandleTemplateChangeIssueForm"
};
node$2.hash = "2b91a8d5f416e7948a2fa0b96775011d";
var node$1 = {
	"kind": "InlineDataFragment",
	"name": "useHandleTemplateChange"
};
node$1.hash = "a08364bb21fe7bb90b32c5dd4a84a3c6";
var UseHandleTemplateChangeIssueTemplateFragment = node$3;
var UseHandleTemplateChangeIssueFormFragment = node$2;
var getSelectedTemplate = (repository) => {
	const data = (0, import_relay_runtime.readInlineData)(node$1, repository);
	let fetchedTemplate = void 0;
	if (data.issueTemplate) {
		const templateData = (0, import_relay_runtime.readInlineData)(UseHandleTemplateChangeIssueTemplateFragment, data.issueTemplate);
		fetchedTemplate = {
			name: templateData.name,
			fileName: templateData.filename,
			kind: IssueCreationKind.IssueTemplate,
			data: templateData
		};
	} else if (data.issueForm) {
		const templateData = (0, import_relay_runtime.readInlineData)(UseHandleTemplateChangeIssueFormFragment, data.issueForm);
		fetchedTemplate = {
			name: templateData.name,
			fileName: templateData.filename,
			kind: IssueCreationKind.IssueForm,
			data: templateData
		};
	}
	return fetchedTemplate;
};
var useHandleTemplateChange = (t0) => {
	const $ = c(13);
	const { optionConfig, repository, navigate, setDisplayMode } = t0;
	const { setTemplate, reinitTitle, reinitBody, reinitAssignees, reinitLabels, reinitProjects, reinitMilestone, reinitIssueType } = useIssueCreateDataContext();
	let t1;
	if ($[0] !== navigate || $[1] !== optionConfig.navigateToFullScreenOnTemplateChoice || $[2] !== reinitAssignees || $[3] !== reinitBody || $[4] !== reinitIssueType || $[5] !== reinitLabels || $[6] !== reinitMilestone || $[7] !== reinitProjects || $[8] !== reinitTitle || $[9] !== repository || $[10] !== setDisplayMode || $[11] !== setTemplate) {
		t1 = (selectedTemplate, enforcedInitialValues, t2) => {
			const enforceNavigate = t2 === void 0 ? false : t2;
			setTemplate(selectedTemplate);
			let newTitle;
			if (enforcedInitialValues?.discussion) newTitle = enforcedInitialValues.discussion.title;
			else if (enforcedInitialValues?.title) newTitle = enforcedInitialValues.title || "";
			else {
				const templateTitle = selectedTemplate?.data.title || "";
				let userInputTitle = "";
				if (enforcedInitialValues?.appendTitleToTemplate) userInputTitle = ` ${enforcedInitialValues.appendTitleToTemplate}`;
				newTitle = [templateTitle, userInputTitle].join("").trimStart();
			}
			reinitTitle(newTitle);
			let newBody = "";
			if (enforcedInitialValues?.discussion) newBody = enforcedInitialValues.discussion.formattedBody || "";
			else if (enforcedInitialValues?.body) newBody = enforcedInitialValues.body || "";
			else if (selectedTemplate && (instanceOfIssueTemplateData(selectedTemplate.data) || instanceOfBlankIssueData(selectedTemplate.data))) newBody = selectedTemplate.data.body || "";
			reinitBody(newBody);
			let templateLabels;
			if (enforcedInitialValues?.discussion) templateLabels = enforcedInitialValues.discussion?.labels || [];
			else if (enforcedInitialValues?.labels) templateLabels = enforcedInitialValues.labels;
			else templateLabels = selectedTemplate?.data.labels?.edges?.flatMap(_temp) || [];
			reinitLabels(templateLabels);
			reinitAssignees(enforcedInitialValues?.assignees ?? ((selectedTemplate?.data.assignees?.edges || []).flatMap(_temp2) || []));
			if (enforcedInitialValues?.projects) reinitProjects(enforcedInitialValues.projects);
			else if (selectedTemplate && instanceOfIssueFormData(selectedTemplate?.data)) reinitProjects(selectedTemplate.data.projects?.edges?.flatMap(_temp3) || []);
			if (enforcedInitialValues?.milestone) reinitMilestone(enforcedInitialValues?.milestone);
			let templateType = enforcedInitialValues?.type ?? null;
			if (selectedTemplate && !templateType && (instanceOfIssueFormData(selectedTemplate.data) || instanceOfIssueTemplateData(selectedTemplate.data)) && selectedTemplate.data.type !== void 0) templateType = selectedTemplate.data.type || null;
			reinitIssueType(templateType ?? null);
			if (!enforcedInitialValues || enforceNavigate) if (optionConfig.navigateToFullScreenOnTemplateChoice && repository && selectedTemplate) navigate(getTemplateUrl(repository.nameWithOwner, selectedTemplate.fileName));
			else setDisplayMode(DisplayMode.IssueCreation);
		};
		$[0] = navigate;
		$[1] = optionConfig.navigateToFullScreenOnTemplateChoice;
		$[2] = reinitAssignees;
		$[3] = reinitBody;
		$[4] = reinitIssueType;
		$[5] = reinitLabels;
		$[6] = reinitMilestone;
		$[7] = reinitProjects;
		$[8] = reinitTitle;
		$[9] = repository;
		$[10] = setDisplayMode;
		$[11] = setTemplate;
		$[12] = t1;
	} else t1 = $[12];
	return t1;
};
function _temp(e) {
	return e?.node ? [e?.node] : [];
}
function _temp2(e_0) {
	return e_0?.node ? [e_0?.node] : [];
}
function _temp3(e_1) {
	return e_1?.node ? [e_1.node] : [];
}
var TemplateQuery = node$74;
var CreateIssue = ({ topRepositories, navigate, currentRepository, onCreateSuccess, issueFormRef, duplicateDetection, ...props }) => {
	const isLoadingRepositoryData = currentRepository !== "unset" && currentRepository === null || topRepositories !== "unset" && topRepositories === null;
	const data = (0, import_react_relay.useFragment)(node$73, currentRepository !== "unset" ? currentRepository : null);
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { title, body, setBody, repository, setRepository, template, setNewTitle, resetMetadata, clearSessionData } = useIssueCreateDataContext();
	const { optionConfig, displayMode, initialDefaultDisplayMode, setDisplayMode, setCreateMoreCreatedPath } = useIssueCreateConfigContext();
	const defaultIssueCreateRepoEnabled = isFeatureEnabled("memex_default_issue_create_repository");
	const initialRef = useRef({
		defaultIssueCreateRepoEnabled,
		isInitialRender: true,
		values: {
			resetMetadata,
			initialDefaultDisplayMode,
			repository,
			setDisplayMode
		}
	});
	useEffect(() => {
		if (initialRef.current.isInitialRender) {
			initialRef.current.isInitialRender = false;
			if (!initialRef.current.defaultIssueCreateRepoEnabled) return;
			const { resetMetadata: resetMetadataRef, initialDefaultDisplayMode: initialDefaultDisplayModeRef, repository: repositoryRef, setDisplayMode: setDisplayModeRef } = initialRef.current.values;
			if (initialDefaultDisplayModeRef === DisplayMode.IssueDuplication) return;
			resetMetadataRef();
			if (repositoryRef?.hasAnyTemplates) {
				setDisplayModeRef(DisplayMode.TemplatePicker);
				return;
			}
			if (!repositoryRef?.hasAnyTemplates && repositoryRef?.isBlankIssuesEnabled) {
				setDisplayModeRef(DisplayMode.IssueCreation);
				return;
			}
			setDisplayModeRef(initialDefaultDisplayModeRef);
		}
	}, []);
	const onRepositorySelected = useCallback((selectedRepository) => {
		if (selectedRepository) {
			if (repository && repository.id !== selectedRepository.id) {
				resetMetadata({
					repository: initialRef.current.values.repository,
					selectedRepository
				});
				if (defaultIssueCreateRepoEnabled) {
					if (selectedRepository.hasAnyTemplates) setDisplayMode(DisplayMode.TemplatePicker);
					else if (!selectedRepository.hasAnyTemplates && selectedRepository.isBlankIssuesEnabled) setDisplayMode(DisplayMode.IssueCreation);
				}
			}
			setRepository(selectedRepository);
			setCreateMoreCreatedPath({
				owner: selectedRepository.owner.login,
				repo: selectedRepository.name,
				number: void 0
			});
		}
	}, [
		resetMetadata,
		repository,
		setCreateMoreCreatedPath,
		setRepository,
		setDisplayMode,
		defaultIssueCreateRepoEnabled
	]);
	const handleTemplateChange = useHandleTemplateChange({
		optionConfig,
		repository,
		navigate,
		setDisplayMode
	});
	const appendTitleToTemplate = optionConfig.issueCreateArguments?.initialValues?.appendTitleToTemplate;
	const onTemplateSelected = useCallback((filename, kind) => {
		if (!repository) return;
		if (repository?.viewerInteractionLimitReasonHTML && repository.viewerInteractionLimitReasonHTML.length > 0) {
			navigate(`/${repository.owner.login}/${repository.name}/issues/new`);
			return;
		}
		if (kind === IssueCreationKind.ContactLink) return;
		let extraArgs = void 0;
		if (appendTitleToTemplate) extraArgs = { appendTitleToTemplate };
		if (kind === IssueCreationKind.BlankIssue) {
			handleTemplateChange(getBlankIssue(), extraArgs, true);
			return;
		}
		(0, import_react_relay.fetchQuery)(environment, TemplateQuery, {
			repoId: repository.id,
			filename
		}).subscribe({
			next: (response) => {
				if (!response.node) return;
				const fetchedTemplate = getSelectedTemplate(response.node);
				if (fetchedTemplate) handleTemplateChange(fetchedTemplate, extraArgs, true);
			},
			error: () => {
				reportError(new Error(ERRORS$1.unableToLoadSelectedTemplate));
				addToast({
					type: "error",
					message: ERRORS$1.unableToLoadSelectedTemplate
				});
			}
		});
	}, [
		repository,
		environment,
		appendTitleToTemplate,
		handleTemplateChange,
		addToast,
		navigate
	]);
	const onCreateSuccessInternal = useOnCreateSuccess({
		issueFormRef,
		handleTemplateChange,
		template,
		callback: onCreateSuccess
	});
	useEffect(() => {
		if (repository) setCreateMoreCreatedPath({
			owner: repository.owner?.login || "",
			repo: repository.name || "",
			number: void 0
		});
	}, [repository, setCreateMoreCreatedPath]);
	useEffect(() => {
		if (repository !== void 0) return;
		if (data) onRepositorySelected(readRepositoryFromFragment(data));
		else if (!isLoadingRepositoryData && topRepositories !== "unset" && topRepositories && topRepositories.length > 0) onRepositorySelected(topRepositories[0]);
	}, [
		currentRepository,
		data,
		isLoadingRepositoryData,
		onRepositorySelected,
		repository,
		topRepositories
	]);
	let element = /* @__PURE__ */ jsx("div", {
		className: CreateIssue_module_default.LoadingContainer,
		children: /* @__PURE__ */ jsx(Spinner, { size: "large" })
	});
	const shouldShowTemplateButton = initialDefaultDisplayMode === DisplayMode.IssueCreation;
	if (displayMode === DisplayMode.IssueCreation && !isLoadingRepositoryData) element = /* @__PURE__ */ jsxs(Fragment$1, { children: [shouldShowTemplateButton && data && /* @__PURE__ */ jsx(TemplatePickerButton, {
		repository: data,
		template
	}), repository && /* @__PURE__ */ jsx(CreateIssueForm, {
		...props,
		issueFormRef,
		onCreateSuccess: onCreateSuccessInternal,
		selectedTemplate: template,
		repository,
		title,
		setTitle: setNewTitle,
		body,
		setBody,
		clearOnCreate: clearSessionData,
		focusTitleInput: !shouldShowTemplateButton,
		footer: void 0,
		duplicateDetection
	})] });
	else if (displayMode === DisplayMode.IssueDuplication && !isLoadingRepositoryData) element = /* @__PURE__ */ jsx(CreateDuplicateIssueForm, {
		navigate,
		onCreateSuccess: onCreateSuccessInternal,
		topRepositories,
		issueFormRef,
		...props
	});
	else if (!isLoadingRepositoryData && topRepositories !== "unset" && (displayMode === DisplayMode.TemplatePicker && optionConfig.showRepositoryPicker || displayMode === DisplayMode.TemplatePicker && !data && !repository)) element = /* @__PURE__ */ jsx(RepositoryAndTemplatePicker, {
		repository,
		onRepositorySelected,
		topRepositories,
		organization: optionConfig.scopedOrganization,
		onTemplateSelected
	});
	else if (displayMode === DisplayMode.TemplatePicker && !optionConfig.showRepositoryPicker && !isLoadingRepositoryData && !!currentRepository && !!data) element = /* @__PURE__ */ jsx("div", {
		"data-hpc": true,
		children: /* @__PURE__ */ jsx(TemplateListInternal, {
			repository: data,
			onTemplateSelected,
			...props
		})
	});
	return /* @__PURE__ */ jsx("div", {
		tabIndex: -1,
		className: CreateIssue_module_default.CreateIssueContainer,
		children: element
	});
};
CreateIssue.displayName = "CreateIssue";
var BUTTON_LABELS = {
	createMore: "Create more",
	createMoreSubIssues: "Create more sub-issues",
	createFullscreen: "Open issue creation in fullscreen",
	copyUrl: "Copy link",
	create: "Create",
	cancel: "Cancel"
};
var CreateIssueFooter_module_default = {
	actionButtonsContainer: "CreateIssueFooter-module_X0q2gq_actionButtonsContainer",
	Checkbox: "CreateIssueFooter-module_X0q2gq_Checkbox",
	checkboxAndLinksSection: "CreateIssueFooter-module_X0q2gq_checkboxAndLinksSection",
	container: "CreateIssueFooter-module_X0q2gq_container",
	CreateIssueFooterContainer: "CreateIssueFooter-module_X0q2gq_CreateIssueFooterContainer",
	duplicateDetectionOnlyActionsGroup: "CreateIssueFooter-module_X0q2gq_duplicateDetectionOnlyActionsGroup",
	duplicateDetectionOnlyWrapper: "CreateIssueFooter-module_X0q2gq_duplicateDetectionOnlyWrapper",
	fileUploadWarningSection: "CreateIssueFooter-module_X0q2gq_fileUploadWarningSection",
	FormControl: "CreateIssueFooter-module_X0q2gq_FormControl",
	mainContentWrapper: "CreateIssueFooter-module_X0q2gq_mainContentWrapper",
	separatorDot: "CreateIssueFooter-module_X0q2gq_separatorDot",
	warningMessageText: "CreateIssueFooter-module_X0q2gq_warningMessageText"
};
var PotentialDuplicates_module_default = {
	container: "PotentialDuplicates-module_Izxa6W_container",
	label: "PotentialDuplicates-module_Izxa6W_label",
	labelGroup: "PotentialDuplicates-module_Izxa6W_labelGroup",
	warningIcon: "PotentialDuplicates-module_Izxa6W_warningIcon"
};
var PotentialDuplicatesMenu_module_default = {
	actionMenuButton: "PotentialDuplicatesMenu-module_qoYeBa_actionMenuButton",
	firstButton: "PotentialDuplicatesMenu-module_qoYeBa_firstButton",
	issueTitle: "PotentialDuplicatesMenu-module_qoYeBa_issueTitle",
	mutedText: "PotentialDuplicatesMenu-module_qoYeBa_mutedText"
};
function IssueIcon(t0) {
	const $ = c(5);
	const { state, stateReason } = t0;
	let t1;
	if ($[0] !== state || $[1] !== stateReason) {
		t1 = {
			state,
			stateReason
		};
		$[0] = state;
		$[1] = stateReason;
		$[2] = t1;
	} else t1 = $[2];
	const { sourceIcon } = useIssueState(t1);
	let t2;
	if ($[3] !== sourceIcon) {
		t2 = jsx(sourceIcon("Issue"), {});
		$[3] = sourceIcon;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
IssueIcon.displayName = "IssueIcon";
function PotentialDuplicatesMenu(t0) {
	const $ = c(33);
	const { items, repoOwner, repoName, onIssueClick, trackIssueClicked } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const firstIssue = items[0];
	const t1 = !firstIssue;
	let t2;
	let t3;
	if ($[0] !== firstIssue || $[1] !== getHovercardAttributesForType || $[2] !== items || $[3] !== onIssueClick || $[4] !== repoName || $[5] !== repoOwner || $[6] !== t1 || $[7] !== trackIssueClicked) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			if (t1) {
				t3 = null;
				break bb0;
			}
			if ($[10] !== firstIssue || $[11] !== getHovercardAttributesForType || $[12] !== items || $[13] !== onIssueClick || $[14] !== repoName || $[15] !== repoOwner || $[16] !== trackIssueClicked) {
				const issueUrl = issuePath({
					owner: repoOwner,
					repo: repoName,
					issueNumber: firstIssue.number
				});
				const hovercardAttrs = getHovercardAttributesForType("issue", {
					owner: repoOwner,
					repo: repoName,
					issueNumber: firstIssue.number
				});
				let t4;
				if ($[18] !== firstIssue || $[19] !== onIssueClick || $[20] !== trackIssueClicked) {
					t4 = (e) => {
						trackIssueClicked(1);
						if (!onIssueClick) return;
						if (e.button === 1 || e.shiftKey || e.ctrlKey || e.metaKey) return;
						e.preventDefault();
						onIssueClick(firstIssue);
					};
					$[18] = firstIssue;
					$[19] = onIssueClick;
					$[20] = trackIssueClicked;
					$[21] = t4;
				} else t4 = $[21];
				const handleFirstIssueClick = t4;
				let t5;
				if ($[22] !== onIssueClick || $[23] !== trackIssueClicked) {
					t5 = (e_0, issue, index) => {
						trackIssueClicked(index + 1);
						if (!onIssueClick) return;
						if (e_0.button === 1 || e_0.shiftKey || e_0.ctrlKey || e_0.metaKey) return;
						e_0.preventDefault();
						onIssueClick(issue);
					};
					$[22] = onIssueClick;
					$[23] = trackIssueClicked;
					$[24] = t5;
				} else t5 = $[24];
				const handleDropdownIssueClick = t5;
				let t6;
				if ($[25] !== firstIssue.state || $[26] !== firstIssue.stateReason) {
					t6 = () => jsx(IssueIcon, {
						state: firstIssue.state,
						stateReason: firstIssue.stateReason
					});
					$[25] = firstIssue.state;
					$[26] = firstIssue.stateReason;
					$[27] = t6;
				} else t6 = $[27];
				const firstIssueButton = jsx(ButtonComponent, {
					as: "a",
					href: issueUrl,
					...hovercardAttrs,
					target: onIssueClick ? void 0 : "_blank",
					onClick: handleFirstIssueClick,
					size: "small",
					className: PotentialDuplicatesMenu_module_default.firstButton,
					leadingVisual: t6,
					children: jsxs("span", {
						className: PotentialDuplicatesMenu_module_default.issueTitle,
						children: [
							firstIssue.title,
							"\xA0",
							jsxs("span", {
								className: PotentialDuplicatesMenu_module_default.mutedText,
								children: ["#", firstIssue.number]
							})
						]
					})
				});
				if (items.length === 1) {
					t3 = firstIssueButton;
					break bb0;
				}
				let t7;
				if ($[28] !== handleDropdownIssueClick || $[29] !== onIssueClick || $[30] !== repoName || $[31] !== repoOwner) {
					t7 = (issue_0, index_0) => jsxs(ActionList.LinkItem, {
						href: issuePath({
							owner: repoOwner,
							repo: repoName,
							issueNumber: issue_0.number
						}),
						target: onIssueClick ? void 0 : "_blank",
						onClick: (e_1) => handleDropdownIssueClick(e_1, issue_0, index_0),
						children: [
							jsx(ActionList.LeadingVisual, { children: jsx(IssueIcon, {
								state: issue_0.state,
								stateReason: issue_0.stateReason
							}) }),
							jsx("span", { children: issue_0.title }),
							jsxs("span", {
								className: PotentialDuplicatesMenu_module_default.mutedText,
								children: ["\xA0#", issue_0.number]
							})
						]
					}, issue_0.id);
					$[28] = handleDropdownIssueClick;
					$[29] = onIssueClick;
					$[30] = repoName;
					$[31] = repoOwner;
					$[32] = t7;
				} else t7 = $[32];
				t2 = jsxs(ButtonGroup, {
					"data-issue-and-pr-hovercards-enabled": true,
					children: [firstIssueButton, jsxs(ActionMenu, { children: [jsx(Tooltip$1, {
						type: "label",
						text: "View all potential duplicates",
						children: jsx(ActionMenu.Button, {
							className: PotentialDuplicatesMenu_module_default.actionMenuButton,
							icon: TriangleDownIcon,
							size: "small"
						})
					}), jsx(ActionMenu.Overlay, {
						width: "medium",
						align: "end",
						side: "outside-top",
						children: jsx(ActionList, { children: items.map(t7) })
					})] })]
				});
				$[10] = firstIssue;
				$[11] = getHovercardAttributesForType;
				$[12] = items;
				$[13] = onIssueClick;
				$[14] = repoName;
				$[15] = repoOwner;
				$[16] = trackIssueClicked;
				$[17] = t2;
			} else t2 = $[17];
		}
		$[0] = firstIssue;
		$[1] = getHovercardAttributesForType;
		$[2] = items;
		$[3] = onIssueClick;
		$[4] = repoName;
		$[5] = repoOwner;
		$[6] = t1;
		$[7] = trackIssueClicked;
		$[8] = t2;
		$[9] = t3;
	} else {
		t2 = $[8];
		t3 = $[9];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
PotentialDuplicatesMenu.displayName = "PotentialDuplicatesMenu";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "issueId"
	}], v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v2 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "id",
			"variableName": "issueId"
		}],
		"concreteType": "IssueUpdatedPayload",
		"kind": "LinkedField",
		"name": "issueUpdated",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "issueTitleUpdated",
			"plural": false,
			"selections": [v1, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "title",
				"storageKey": null
			}],
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "issueStateUpdated",
			"plural": false,
			"selections": [
				v1,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "state",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "stateReason",
					"storageKey": null
				}
			],
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "similarIssueSubscription",
			"selections": v2,
			"type": "EventSubscription",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "similarIssueSubscription",
			"selections": v2
		},
		"params": {
			"id": "ce208cd8cf060b3df4cb37683438e939",
			"metadata": {},
			"name": "similarIssueSubscription",
			"operationKind": "subscription",
			"text": null
		}
	};
})();
node.hash = "d9c4976b73150160ed339373d542ef46";
var subscription = node;
/** Type-safe conversion of GraphQL state to local type */
function toIssueState(state) {
	if (state && state in IssueState) return state;
}
/** Type-safe conversion of GraphQL stateReason to local type */
function toIssueStateReason(stateReason) {
	if (stateReason == null) return stateReason;
	if (stateReason in IssueStateReason) return stateReason;
}
/**
* Subscribe to updates for a similar issue. When the issue's title or state changes,
* the onUpdate callback is called with the new values.
*
* This hook should only be called when issueNodeId is defined. Use the
* SimilarIssueSubscription component pattern to conditionally render subscriptions.
*
* @param issueNodeId - GraphQL node ID of the issue to subscribe to (required)
* @param params.onUpdate - Callback for updates. Should be stable (memoized with useCallback)
*/
var useSimilarIssueSubscription = (issueNodeId, t0) => {
	const $ = c(8);
	const { onUpdate } = t0;
	let t1;
	if ($[0] !== issueNodeId) {
		t1 = { issueId: issueNodeId };
		$[0] = issueNodeId;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== issueNodeId || $[3] !== onUpdate) {
		t2 = (_store, data) => {
			if (!data?.issueUpdated) return;
			const { issueTitleUpdated, issueStateUpdated } = data.issueUpdated;
			if (issueTitleUpdated || issueStateUpdated) onUpdate({
				nodeId: issueNodeId,
				title: issueTitleUpdated?.title,
				state: toIssueState(issueStateUpdated?.state),
				stateReason: toIssueStateReason(issueStateUpdated?.stateReason)
			});
		};
		$[2] = issueNodeId;
		$[3] = onUpdate;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== t1 || $[6] !== t2) {
		t3 = {
			variables: t1,
			subscription,
			updater: t2
		};
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
	} else t3 = $[7];
	(0, import_react_relay.useSubscription)(t3);
};
var noop = () => {};
/** Inner component that subscribes to a single issue - only rendered when we have valid props */
function IssueSubscriptionInner(t0) {
	const $ = c(2);
	const { nodeId, onIssueUpdate } = t0;
	let t1;
	if ($[0] !== onIssueUpdate) {
		t1 = { onUpdate: onIssueUpdate };
		$[0] = onIssueUpdate;
		$[1] = t1;
	} else t1 = $[1];
	useSimilarIssueSubscription(nodeId, t1);
	return null;
}
/** Wrapper that conditionally subscribes to all issues in the list */
IssueSubscriptionInner.displayName = "IssueSubscriptionInner";
function IssueSubscriptions({ items, onIssueUpdate }) {
	if (!onIssueUpdate) return null;
	return /* @__PURE__ */ jsx(Fragment$1, { children: items.map((item) => /* @__PURE__ */ jsx(IssueSubscriptionInner, {
		nodeId: item.nodeId,
		onIssueUpdate
	}, item.nodeId)) });
}
/**
* Displays potential duplicate issues as a split button with label.
* Left button shows first issue with hovercard, right dropdown shows remaining issues.
* Supports SidePanel viewing via onIssueClick and real-time updates via subscriptions.
*/
IssueSubscriptions.displayName = "IssueSubscriptions";
function PotentialDuplicates(t0) {
	const $ = c(14);
	const { items, isError, repoOwner, repoName, onIssueClick, onIssueUpdate, onIssueClickTracking, onIssuesToPreheat, sessionResetKey } = t0;
	let t1;
	let t2;
	if ($[0] !== items || $[1] !== onIssuesToPreheat || $[2] !== repoName || $[3] !== repoOwner) {
		t1 = () => {
			if (!onIssuesToPreheat || items.length === 0) return;
			onIssuesToPreheat(items.map((item) => ({
				owner: repoOwner,
				repo: repoName,
				number: item.number
			})));
		};
		t2 = [
			items,
			repoOwner,
			repoName,
			onIssuesToPreheat
		];
		$[0] = items;
		$[1] = onIssuesToPreheat;
		$[2] = repoName;
		$[3] = repoOwner;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
	if (items.length === 0 || isError) return null;
	let t3;
	if ($[6] !== items || $[7] !== onIssueClick || $[8] !== onIssueClickTracking || $[9] !== onIssueUpdate || $[10] !== repoName || $[11] !== repoOwner || $[12] !== sessionResetKey) {
		t3 = jsxs("div", {
			className: PotentialDuplicates_module_default.container,
			children: [
				jsx(IssueSubscriptions, {
					items,
					onIssueUpdate
				}),
				jsxs("div", {
					className: PotentialDuplicates_module_default.labelGroup,
					children: [jsx(AlertFillIcon, {
						size: 12,
						className: PotentialDuplicates_module_default.warningIcon
					}), jsx("span", {
						className: PotentialDuplicates_module_default.label,
						children: items.length === 1 ? LABELS$2.potentialDuplicate : LABELS$2.duplicatesCount(items.length)
					})]
				}),
				jsx(PotentialDuplicatesMenu, {
					items,
					repoOwner,
					repoName,
					onIssueClick,
					trackIssueClicked: onIssueClickTracking ?? noop
				})
			]
		}, sessionResetKey);
		$[6] = items;
		$[7] = onIssueClick;
		$[8] = onIssueClickTracking;
		$[9] = onIssueUpdate;
		$[10] = repoName;
		$[11] = repoOwner;
		$[12] = sessionResetKey;
		$[13] = t3;
	} else t3 = $[13];
	return t3;
}
PotentialDuplicates.displayName = "PotentialDuplicates";
var CreateIssueFooter = ({ className, sx, hideCreateMore = false, onClose, onDuplicateIssueSidePanelClick, onDuplicateIssuesToPreheat, duplicateDetection }) => {
	const { createMore, setCreateMore, createMoreCreatedPath, onCreateAction, isSubmitting, isFileUploading, isSubIssue, optionConfig: { insidePortal } } = useIssueCreateConfigContext();
	const { repository } = useIssueCreateDataContext();
	const showDuplicateDetection = duplicateDetection?.isDuplicateDetectionEnabled && duplicateDetection.items.length > 0 && !duplicateDetection.isError;
	const handleCheckMoreChange = () => {
		setCreateMore(!createMore);
	};
	const handleCreateMore = () => {
		setCreateMore(true);
		if (!shouldSubmit()) return;
		onCreateAction?.current?.onCreate(isSubmitting, true);
	};
	const [createWaitingOnUpload, setCreateWaitingOnUpload] = useState(false);
	const buttonRef = useRef(null);
	const shouldSubmit = () => {
		if (isSubmitting) return false;
		if (isFileUploading) {
			setCreateWaitingOnUpload(true);
			return false;
		}
		return true;
	};
	const handleSubmit = async () => {
		if (!shouldSubmit()) return;
		onCreateAction?.current?.onCreate(isSubmitting, createMore);
	};
	useEffect(() => {
		if (buttonRef.current && !isFileUploading && !isSubmitting && createWaitingOnUpload) {
			setCreateWaitingOnUpload(false);
			buttonRef.current.dispatchEvent(new MouseEvent("click", {
				bubbles: true,
				cancelable: true
			}));
		}
	}, [
		isFileUploading,
		isSubmitting,
		createWaitingOnUpload
	]);
	const commands = { "github:submit-form": handleSubmit };
	if (!hideCreateMore) commands["issue-create:submit-and-create-more"] = handleCreateMore;
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(CreateIssueFooter_module_default.container, className, CreateIssueFooter_module_default.CreateIssueFooterContainer, showDuplicateDetection && CreateIssueFooter_module_default.duplicateDetectionOnlyWrapper),
		children: [
			/* @__PURE__ */ jsx(GlobalCommands, { commands }),
			createWaitingOnUpload && /* @__PURE__ */ jsxs("div", {
				className: CreateIssueFooter_module_default.fileUploadWarningSection,
				children: [/* @__PURE__ */ jsx(Octicon, {
					icon: InfoIcon,
					size: 16
				}), /* @__PURE__ */ jsx("span", {
					className: CreateIssueFooter_module_default.warningMessageText,
					children: LABELS$2.fileUploadWarning
				})]
			}),
			showDuplicateDetection && repository && duplicateDetection && /* @__PURE__ */ jsx(PotentialDuplicates, {
				items: duplicateDetection.items,
				isError: duplicateDetection.isError,
				repoName: repository.name,
				repoOwner: repository.owner.login,
				onIssueClick: onDuplicateIssueSidePanelClick,
				onIssueUpdate: duplicateDetection.updateIssue,
				onIssueClickTracking: duplicateDetection.trackIssueClicked,
				onIssuesToPreheat: onDuplicateIssuesToPreheat,
				sessionResetKey: duplicateDetection.sessionResetKey
			}),
			/* @__PURE__ */ jsxs(Box, {
				sx: { ...sx },
				className: clsx(CreateIssueFooter_module_default.mainContentWrapper, showDuplicateDetection && CreateIssueFooter_module_default.duplicateDetectionOnlyActionsGroup),
				children: [!hideCreateMore && /* @__PURE__ */ jsxs(Box, {
					sx: { ml: insidePortal ? 0 : 2 },
					className: CreateIssueFooter_module_default.checkboxAndLinksSection,
					children: [
						/* @__PURE__ */ jsxs(FormControl$1, {
							className: CreateIssueFooter_module_default.FormControl,
							children: [/* @__PURE__ */ jsx(Checkbox, {
								"data-testid": TEST_IDS.createMoreIssuesCheckbox,
								checked: createMore,
								onChange: handleCheckMoreChange,
								className: CreateIssueFooter_module_default.Checkbox
							}), /* @__PURE__ */ jsx(FormControl$1.Label, { children: isSubIssue ? BUTTON_LABELS.createMoreSubIssues : BUTTON_LABELS.createMore })]
						}),
						/* @__PURE__ */ jsx("div", {
							"data-testid": TEST_IDS.issueCreatedAnnouncement,
							className: "sr-only",
							"aria-live": "polite",
							"aria-atomic": "true",
							role: "status",
							children: createMoreCreatedPath.number ? LABELS$2.lastIssueCreated(createMoreCreatedPath.number) : null
						}),
						createMoreCreatedPath.number ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
							className: CreateIssueFooter_module_default.separatorDot,
							children: "·"
						}), /* @__PURE__ */ jsx(Link, {
							href: issuePath({
								owner: createMoreCreatedPath.owner,
								repo: createMoreCreatedPath.repo,
								issueNumber: createMoreCreatedPath.number
							}),
							"data-testid": TEST_IDS.issueCreatedLink,
							children: LABELS$2.lastIssueCreated(createMoreCreatedPath.number)
						})] }) : null
					]
				}), /* @__PURE__ */ jsxs("div", {
					className: CreateIssueFooter_module_default.actionButtonsContainer,
					children: [onClose && /* @__PURE__ */ jsx(ButtonComponent, {
						onClick: () => onClose(),
						children: BUTTON_LABELS.cancel
					}), /* @__PURE__ */ jsx(CommandButton, {
						commandId: "github:submit-form",
						variant: "primary",
						inactive: isSubmitting || isFileUploading,
						"data-testid": TEST_IDS.createIssueButton,
						ref: buttonRef,
						showKeybindingHint: true,
						children: BUTTON_LABELS.create
					})]
				})]
			})
		]
	});
};
CreateIssueFooter.displayName = "CreateIssueFooter";
var useSafeClose = (t0) => {
	const $ = c(11);
	const { storageKeyPrefix, issueFormRef, onCancel } = t0;
	const confirm = useConfirm();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = safeStorage("sessionStorage");
		$[0] = t1;
	} else t1 = $[0];
	const safeSessionStorage = t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = JSON.stringify("");
		$[1] = t2;
	} else t2 = $[1];
	const emptyStringValue = t2;
	let t3;
	if ($[2] !== confirm) {
		t3 = async () => await confirm({
			title: LABELS$2.discardConfirmation.title,
			content: LABELS$2.discardConfirmation.content,
			confirmButtonContent: LABELS$2.discardConfirmation.confirm,
			confirmButtonType: "danger",
			cancelButtonContent: LABELS$2.discardConfirmation.cancel
		});
		$[2] = confirm;
		$[3] = t3;
	} else t3 = $[3];
	const confirmCancel = t3;
	let t4;
	if ($[4] !== confirmCancel || $[5] !== issueFormRef || $[6] !== onCancel || $[7] !== storageKeyPrefix) {
		t4 = async () => {
			if (!(discardStorageKeys(storageKeyPrefix).some((key) => safeSessionStorage.getItem(key) !== null && safeSessionStorage.getItem(key) !== emptyStringValue) || issueFormRef?.current?.hasChanges()) || await confirmCancel()) {
				clearSessionStorage(storageKeys(storageKeyPrefix));
				issueFormRef?.current?.clearSessionStorage();
				onCancel();
			}
		};
		$[4] = confirmCancel;
		$[5] = issueFormRef;
		$[6] = onCancel;
		$[7] = storageKeyPrefix;
		$[8] = t4;
	} else t4 = $[8];
	const onSafeClose = t4;
	let t5;
	if ($[9] !== onSafeClose) {
		t5 = { onSafeClose };
		$[9] = onSafeClose;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
};
var ANALYTICS_TARGET = "SIMILAR_ISSUES_ISSUE_CREATION";
var SimilarIssuesAnalyticsEvent = {
	SectionShown: "issue_create.similar_issues.section_shown",
	SectionExpanded: "issue_create.similar_issues.section_expanded",
	InputStarted: "issue_create.similar_issues.input_started",
	ResultsShown: "issue_create.similar_issues.results_shown",
	IssueClicked: "issue_create.similar_issues.issue_clicked",
	IssueCreated: "issue_create.similar_issues.issue_created",
	RequestMade: "issue_create.similar_issues.semantic_search_request_made"
};
/**
* Hook for sending similar issues analytics events.
* Session ID is passed at call time to ensure callbacks are stable and always use the current value.
*
* @param context - The context in which the issue is being created
* @param repoNWO - The repository name with owner (e.g. "owner/repo") to explicitly attach to events
*/
function useSimilarIssuesAnalytics(context, repoNWO, t0) {
	const $ = c(27);
	const enableAnalytics = t0 === void 0 ? true : t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== context || $[1] !== enableAnalytics || $[2] !== repoNWO || $[3] !== sendAnalyticsEvent) {
		t1 = (event, sessionId, extra) => {
			if (enableAnalytics) sendAnalyticsEvent(event, ANALYTICS_TARGET, {
				issueCreateSessionId: sessionId,
				issueCreateContext: context,
				repoNWO,
				...extra
			});
		};
		$[0] = context;
		$[1] = enableAnalytics;
		$[2] = repoNWO;
		$[3] = sendAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	const sendSimilarIssuesEvent = t1;
	let t2;
	if ($[5] !== sendSimilarIssuesEvent) {
		t2 = (sessionId_0, title, body) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.RequestMade, sessionId_0, {
			titleLength: title.length,
			bodyLength: body.length
		});
		$[5] = sendSimilarIssuesEvent;
		$[6] = t2;
	} else t2 = $[6];
	const sendRequestMade = t2;
	let t3;
	if ($[7] !== sendSimilarIssuesEvent) {
		t3 = (sessionId_1) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.SectionShown, sessionId_1);
		$[7] = sendSimilarIssuesEvent;
		$[8] = t3;
	} else t3 = $[8];
	const sendSectionShown = t3;
	let t4;
	if ($[9] !== sendSimilarIssuesEvent) {
		t4 = (sessionId_2) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.SectionExpanded, sessionId_2);
		$[9] = sendSimilarIssuesEvent;
		$[10] = t4;
	} else t4 = $[10];
	const sendSectionExpanded = t4;
	let t5;
	if ($[11] !== sendSimilarIssuesEvent) {
		t5 = (sessionId_3) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.InputStarted, sessionId_3);
		$[11] = sendSimilarIssuesEvent;
		$[12] = t5;
	} else t5 = $[12];
	const sendInputStarted = t5;
	let t6;
	if ($[13] !== sendSimilarIssuesEvent) {
		t6 = (sessionId_4) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.ResultsShown, sessionId_4);
		$[13] = sendSimilarIssuesEvent;
		$[14] = t6;
	} else t6 = $[14];
	const sendResultsShown = t6;
	let t7;
	if ($[15] !== sendSimilarIssuesEvent) {
		t7 = (sessionId_5, position) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.IssueClicked, sessionId_5, { position });
		$[15] = sendSimilarIssuesEvent;
		$[16] = t7;
	} else t7 = $[16];
	const sendIssueClicked = t7;
	let t8;
	if ($[17] !== sendSimilarIssuesEvent) {
		t8 = (sessionId_6, payload) => sendSimilarIssuesEvent(SimilarIssuesAnalyticsEvent.IssueCreated, sessionId_6, {
			hadNonEmptyResults: payload.hadResults,
			wasSectionExpanded: payload.wasSectionExpanded,
			wasIssueClicked: payload.wasIssueClicked,
			issueClickCount: payload.issueClickCount
		});
		$[17] = sendSimilarIssuesEvent;
		$[18] = t8;
	} else t8 = $[18];
	const sendIssueCreated = t8;
	let t9;
	if ($[19] !== sendInputStarted || $[20] !== sendIssueClicked || $[21] !== sendIssueCreated || $[22] !== sendRequestMade || $[23] !== sendResultsShown || $[24] !== sendSectionExpanded || $[25] !== sendSectionShown) {
		t9 = {
			sendSectionShown,
			sendSectionExpanded,
			sendInputStarted,
			sendResultsShown,
			sendIssueClicked,
			sendIssueCreated,
			sendRequestMade
		};
		$[19] = sendInputStarted;
		$[20] = sendIssueClicked;
		$[21] = sendIssueCreated;
		$[22] = sendRequestMade;
		$[23] = sendResultsShown;
		$[24] = sendSectionExpanded;
		$[25] = sendSectionShown;
		$[26] = t9;
	} else t9 = $[26];
	return t9;
}
var DEFAULT_MIN_QUERY_LENGTH = 250;
var DEFAULT_DEBOUNCE_MS = 1500;
var initialAnalyticsState = {
	hasSentSectionShown: false,
	hasSentSectionExpanded: false,
	hasSentInputStarted: false,
	hasSentResultsShown: false,
	wasIssueClicked: false,
	issueClickCount: 0,
	hadResults: false
};
var EMPTY_ITEMS = [];
function useSimilarIssues({ repoOwner, repoName, title, body, isSimilarIssuesEnabled, context }) {
	const queryClient = useQueryClient();
	const previousCountRef = useRef(null);
	const [queryTitle, setQueryTitle] = useState(title.trim());
	const [queryBody, setQueryBody] = useState(body.trim());
	const sessionIdRef = useRef(void 0);
	const getSessionId = useCallback(() => sessionIdRef.current ??= crypto.randomUUID(), []);
	const [sessionResetKey, setSessionResetKey] = useState(0);
	const analyticsRef = useRef({ ...initialAnalyticsState });
	const { sendRequestMade, sendSectionShown, sendInputStarted, sendResultsShown, sendIssueClicked, sendIssueCreated } = useSimilarIssuesAnalytics(context, `${repoOwner}/${repoName}`, false);
	const debounceQueryTitleUpdate = useDebounce((value) => setQueryTitle(value.trim()), DEFAULT_DEBOUNCE_MS);
	const debounceQueryBodyUpdate = useDebounce((value_0) => setQueryBody(value_0.trim()), DEFAULT_DEBOUNCE_MS);
	useEffect(() => {
		if (!isSimilarIssuesEnabled) return;
		if (!analyticsRef.current.hasSentSectionShown) {
			analyticsRef.current.hasSentSectionShown = true;
			sendSectionShown(getSessionId());
		}
	}, [
		isSimilarIssuesEnabled,
		sendSectionShown,
		getSessionId,
		sessionResetKey
	]);
	useEffect(() => {
		if (!isSimilarIssuesEnabled) return;
		if ((title.trim().length > 0 || body.trim().length > 0) && !analyticsRef.current.hasSentInputStarted) {
			analyticsRef.current.hasSentInputStarted = true;
			sendInputStarted(getSessionId());
		}
	}, [
		isSimilarIssuesEnabled,
		title,
		body,
		sendInputStarted,
		getSessionId
	]);
	useEffect(() => {
		if (!isSimilarIssuesEnabled) return;
		debounceQueryTitleUpdate(title.trim());
	}, [
		isSimilarIssuesEnabled,
		title,
		debounceQueryTitleUpdate
	]);
	useEffect(() => {
		if (!isSimilarIssuesEnabled) return;
		debounceQueryBodyUpdate(body.trim());
	}, [
		isSimilarIssuesEnabled,
		body,
		debounceQueryBodyUpdate
	]);
	const isQueryValid = queryTitle.length + queryBody.length >= DEFAULT_MIN_QUERY_LENGTH;
	const queryKey = useMemo(() => [
		"similar-issues",
		repoOwner,
		repoName,
		queryTitle,
		queryBody,
		context
	], [
		repoOwner,
		repoName,
		queryTitle,
		queryBody,
		context
	]);
	const { data, isFetching, isError } = useQuery({
		queryKey,
		queryFn: async ({ signal }) => {
			const response = await verifiedFetchJSON(`/${repoOwner}/${repoName}/issues/semantically_similar`, {
				method: "POST",
				body: { search: {
					title: queryTitle,
					body: queryBody,
					page: 1,
					per_page: 5,
					context
				} },
				signal
			});
			sendRequestMade(getSessionId(), queryTitle, queryBody);
			if (!response.ok) throw new Error(`Failed to fetch similar issues: ${response.status}`);
			return ((await response.json()).similar_issues ?? []).map((item) => ({
				id: String(item.issue.id),
				nodeId: item.issue.node_id,
				number: item.issue.number,
				title: item.issue.title,
				state: item.issue.state.toUpperCase(),
				stateReason: item.issue.state_reason?.toUpperCase(),
				score: item.score
			}));
		},
		enabled: isSimilarIssuesEnabled && isQueryValid,
		placeholderData: keepPreviousData,
		staleTime: 60 * 1e3
	});
	const items = isQueryValid ? data ?? EMPTY_ITEMS : EMPTY_ITEMS;
	const updateIssue = useCallback((update) => {
		queryClient.setQueryData(queryKey, (oldData) => {
			if (!oldData) return oldData;
			return oldData.map((item_0) => {
				if (item_0.nodeId !== update.nodeId) return item_0;
				return {
					...item_0,
					...update.title !== void 0 && { title: update.title },
					...update.state !== void 0 && { state: update.state },
					...update.stateReason !== void 0 && { stateReason: update.stateReason }
				};
			});
		});
	}, [queryClient, queryKey]);
	useEffect(() => {
		if (!isSimilarIssuesEnabled) return;
		if (!isFetching && previousCountRef.current !== items.length) {
			previousCountRef.current = items.length;
			if (items.length > 0) {
				analyticsRef.current.hadResults = true;
				if (!analyticsRef.current.hasSentResultsShown) {
					analyticsRef.current.hasSentResultsShown = true;
					sendResultsShown(getSessionId());
				}
			}
			const count = items.length;
			if (count === 0) announce$1("No similar issues found");
			else if (count === 1) announce$1("1 similar issue found");
			else announce$1(`${count} similar issues found`);
		}
	}, [
		isSimilarIssuesEnabled,
		items.length,
		isFetching,
		sendResultsShown,
		getSessionId
	]);
	const trackIssueClicked = useCallback((position) => {
		analyticsRef.current.wasIssueClicked = true;
		analyticsRef.current.issueClickCount += 1;
		sendIssueClicked(getSessionId(), position);
	}, [sendIssueClicked, getSessionId]);
	const trackIssueCreated = useCallback(() => {
		const analyticsState = analyticsRef.current;
		sendIssueCreated(getSessionId(), {
			hadResults: analyticsState.hadResults,
			wasSectionExpanded: analyticsState.hasSentSectionExpanded,
			wasIssueClicked: analyticsState.wasIssueClicked,
			issueClickCount: analyticsState.issueClickCount
		});
	}, [sendIssueCreated, getSessionId]);
	return {
		items,
		isError,
		isDuplicateDetectionEnabled: isSimilarIssuesEnabled,
		sessionResetKey,
		updateIssue,
		trackIssueClicked,
		resetForNewSession: useCallback(() => {
			previousCountRef.current = null;
			setQueryTitle("");
			setQueryBody("");
			analyticsRef.current = { ...initialAnalyticsState };
			sessionIdRef.current = crypto.randomUUID();
			setSessionResetKey((prev) => prev + 1);
		}, []),
		trackIssueCreated
	};
}
var CreateIssueDialog_module_default = { CreateIssueDialogContainer: "CreateIssueDialog-module_zn7X2W_CreateIssueDialogContainer" };
var CreateIssueDialogHeader_module_default = {
	CopyToClipboardButton: "CreateIssueDialogHeader-module_kDSYIG_CopyToClipboardButton",
	CreateIssueDialogHeaderContainer: "CreateIssueDialogHeader-module_kDSYIG_CreateIssueDialogHeaderContainer",
	dialogTitleSection: "CreateIssueDialogHeader-module_kDSYIG_dialogTitleSection"
};
var CreateIssueDialogHeader = (t0) => {
	const $ = c(34);
	const { navigate, dialogLabelId, onClose } = t0;
	const { displayMode, setDisplayMode, optionConfig, isSubIssue } = useIssueCreateConfigContext();
	const { repository, repositoryAbsolutePath, template, resetMetadata, setTemplate } = useIssueCreateDataContext();
	let t1;
	if ($[0] !== dialogLabelId || $[1] !== displayMode || $[2] !== isSubIssue || $[3] !== navigate || $[4] !== onClose || $[5] !== optionConfig || $[6] !== repository || $[7] !== repositoryAbsolutePath || $[8] !== resetMetadata || $[9] !== setDisplayMode || $[10] !== setTemplate || $[11] !== template) {
		const defaultIssueCreateRepoEnabled = isFeatureEnabled("memex_default_issue_create_repository");
		let t2;
		if ($[13] !== onClose) {
			t2 = () => {
				onClose("close-button");
			};
			$[13] = onClose;
			$[14] = t2;
		} else t2 = $[14];
		const onCloseClick = t2;
		let t3;
		if ($[15] !== repositoryAbsolutePath) {
			t3 = appendChooseToBasePath(repositoryAbsolutePath);
			$[15] = repositoryAbsolutePath;
			$[16] = t3;
		} else t3 = $[16];
		const chooseUrlForCopy = t3;
		const showCopyUrlButton = displayMode === DisplayMode.TemplatePicker && repository !== void 0;
		const showFullScreenButton = displayMode === DisplayMode.IssueCreation && optionConfig.showFullScreenButton && navigate !== noop$1 && repository !== void 0;
		let t4;
		if ($[17] !== repository || $[18] !== resetMetadata || $[19] !== setDisplayMode || $[20] !== setTemplate) {
			t4 = () => {
				resetMetadata({
					repository,
					selectedRepository: repository
				});
				setTemplate(void 0);
				setDisplayMode(DisplayMode.TemplatePicker);
			};
			$[17] = repository;
			$[18] = resetMetadata;
			$[19] = setDisplayMode;
			$[20] = setTemplate;
			$[21] = t4;
		} else t4 = $[21];
		const handleBackToTemplates = t4;
		let t5;
		if ($[22] !== navigate || $[23] !== repository || $[24] !== showFullScreenButton || $[25] !== template) {
			t5 = () => {
				if (!showFullScreenButton) return;
				const baseUrl = `/${repository.nameWithOwner}/issues/new`;
				const templateFileName = !template || template.kind === IssueCreationKind.BlankIssue ? void 0 : template.fileName;
				navigate(templateFileName ? `${baseUrl}?template=${encodeURIComponent(templateFileName)}` : baseUrl);
			};
			$[22] = navigate;
			$[23] = repository;
			$[24] = showFullScreenButton;
			$[25] = template;
			$[26] = t5;
		} else t5 = $[26];
		const navigateToFullscreen = t5;
		const repositoryNameWithOwner = repository?.nameWithOwner;
		let t6;
		bb0: {
			const relationType = isSubIssue ? "sub-issue" : "issue";
			if (displayMode === DisplayMode.TemplatePicker || !repositoryNameWithOwner) {
				const initialTitle = optionConfig.issueCreateArguments?.initialValues?.title;
				t6 = LABELS$2.issueCreateDialogTitleTemplatePane(relationType) + (initialTitle ? ` - "${initialTitle}"` : "");
				break bb0;
			}
			const templateName = !template || template.kind === IssueCreationKind.BlankIssue ? void 0 : template.name;
			if (displayMode === DisplayMode.IssueDuplication) {
				let t7;
				if ($[27] !== relationType || $[28] !== repositoryNameWithOwner) {
					t7 = LABELS$2.issueCreateDialogTitleDuplicationPane(repositoryNameWithOwner, relationType);
					$[27] = relationType;
					$[28] = repositoryNameWithOwner;
					$[29] = t7;
				} else t7 = $[29];
				t6 = t7;
				break bb0;
			}
			let t7;
			if ($[30] !== relationType || $[31] !== repositoryNameWithOwner || $[32] !== templateName) {
				t7 = LABELS$2.issueCreateDialogTitleCreationPane(repositoryNameWithOwner, templateName, relationType);
				$[30] = relationType;
				$[31] = repositoryNameWithOwner;
				$[32] = templateName;
				$[33] = t7;
			} else t7 = $[33];
			t6 = t7;
		}
		const dialogTitle = t6;
		t1 = jsxs(Dialog.Header, { children: [jsx(GlobalCommands, { commands: { "issue-create:open-fullscreen": navigateToFullscreen } }), jsxs("div", {
			className: CreateIssueDialogHeader_module_default.CreateIssueDialogHeaderContainer,
			children: [
				defaultIssueCreateRepoEnabled && displayMode === DisplayMode.IssueCreation && jsx(IconButton, {
					icon: ArrowLeftIcon,
					"aria-label": "Back to templates",
					variant: "invisible",
					onClick: handleBackToTemplates,
					className: CreateIssueDialogHeader_module_default.CopyToClipboardButton
				}),
				jsx("div", {
					className: CreateIssueDialogHeader_module_default.dialogTitleSection,
					children: jsx(Dialog.Title, {
						id: dialogLabelId,
						children: dialogTitle
					})
				}),
				showCopyUrlButton && jsx(CopyToClipboardButton, {
					textToCopy: chooseUrlForCopy,
					ariaLabel: BUTTON_LABELS.copyUrl,
					icon: CopyIcon,
					tooltipProps: { direction: "n" },
					className: CreateIssueDialogHeader_module_default.CopyToClipboardButton
				}),
				showFullScreenButton && jsx(CommandIconButton, {
					variant: "invisible",
					commandId: "issue-create:open-fullscreen",
					icon: ScreenFullIcon,
					className: CreateIssueDialogHeader_module_default.CopyToClipboardButton
				}),
				jsx(Dialog.CloseButton, { onClose: onCloseClick })
			]
		})] });
		$[0] = dialogLabelId;
		$[1] = displayMode;
		$[2] = isSubIssue;
		$[3] = navigate;
		$[4] = onClose;
		$[5] = optionConfig;
		$[6] = repository;
		$[7] = repositoryAbsolutePath;
		$[8] = resetMetadata;
		$[9] = setDisplayMode;
		$[10] = setTemplate;
		$[11] = template;
		$[12] = t1;
	} else t1 = $[12];
	return t1;
};
CreateIssueDialogHeader.displayName = "CreateIssueDialogHeader";
var CreateIssueDialog = (t0) => {
	const $ = c(23);
	const { onCreateSuccess, onCancel, navigate, currentRepository, isNavigatingToNew, returnFocusRef, onDuplicateIssueSidePanelClick, onDuplicateIssuesToPreheat, ...props } = t0;
	const { optionConfig, initialDefaultDisplayMode, setDisplayMode, displayMode, setCreateMore } = useIssueCreateConfigContext();
	const { usedStorageKeyPrefix, title, body, issueFormBody, repository, template } = useIssueCreateDataContext();
	const data = (0, import_react_relay.useFragment)(node$75, currentRepository !== "unset" ? currentRepository : null);
	const similarIssuesBody = template && instanceOfIssueFormData(template.data) ? issueFormBody : body;
	const t1 = repository?.owner.login ?? "";
	const t2 = repository?.name ?? "";
	let t3;
	if ($[0] !== displayMode || $[1] !== repository) {
		t3 = displayMode !== DisplayMode.IssueDuplication && isFeatureEnabled("semantic_similarity_duplicate_issue_detection") && !!repository;
		$[0] = displayMode;
		$[1] = repository;
		$[2] = t3;
	} else t3 = $[2];
	let t4;
	if ($[3] !== optionConfig) {
		t4 = deriveIssueCreateContext(optionConfig);
		$[3] = optionConfig;
		$[4] = t4;
	} else t4 = $[4];
	let t5;
	if ($[5] !== similarIssuesBody || $[6] !== t1 || $[7] !== t2 || $[8] !== t3 || $[9] !== t4 || $[10] !== title) {
		t5 = {
			repoOwner: t1,
			repoName: t2,
			title,
			body: similarIssuesBody,
			isSimilarIssuesEnabled: t3,
			context: t4
		};
		$[5] = similarIssuesBody;
		$[6] = t1;
		$[7] = t2;
		$[8] = t3;
		$[9] = t4;
		$[10] = title;
		$[11] = t5;
	} else t5 = $[11];
	const duplicateDetection = useSimilarIssues(t5);
	let t6;
	if ($[12] !== initialDefaultDisplayMode || $[13] !== onCancel || $[14] !== setCreateMore || $[15] !== setDisplayMode) {
		t6 = () => {
			setCreateMore(false);
			setDisplayMode(initialDefaultDisplayMode);
			onCancel();
		};
		$[12] = initialDefaultDisplayMode;
		$[13] = onCancel;
		$[14] = setCreateMore;
		$[15] = setDisplayMode;
		$[16] = t6;
	} else t6 = $[16];
	const onCancelInternal = t6;
	const { onSafeClose } = useSafeClose({
		storageKeyPrefix: usedStorageKeyPrefix,
		issueFormRef: props.issueFormRef,
		onCancel: onCancelInternal
	});
	let t7;
	if ($[17] !== initialDefaultDisplayMode || $[18] !== onCreateSuccess || $[19] !== setDisplayMode) {
		t7 = (t8) => {
			const { issue, createMore } = t8;
			onCreateSuccess({
				issue,
				createMore
			});
			if (!createMore) setDisplayMode(initialDefaultDisplayMode);
		};
		$[17] = initialDefaultDisplayMode;
		$[18] = onCreateSuccess;
		$[19] = setDisplayMode;
		$[20] = t7;
	} else t7 = $[20];
	const resetDisplayModeOnCreateSuccess = t7;
	const issueDialogProps = {
		...props,
		onCancel: onSafeClose
	};
	const showCreateDialog = !isNavigatingToNew || !optionConfig.canBypassTemplateSelection;
	let t8;
	if ($[21] !== navigate) {
		t8 = (headerProps) => jsx(CreateIssueDialogHeader, {
			navigate,
			...headerProps
		});
		$[21] = navigate;
		$[22] = t8;
	} else t8 = $[22];
	return jsx(Portal, { children: jsx(Dialog$1, {
		returnFocusRef,
		renderHeader: t8,
		renderFooter: () => {
			if (displayMode === DisplayMode.IssueCreation || displayMode === DisplayMode.IssueDuplication) return jsx(Dialog$1.Footer, { children: jsx(CreateIssueFooter, {
				onClose: () => onSafeClose(),
				onDuplicateIssueSidePanelClick,
				onDuplicateIssuesToPreheat,
				duplicateDetection,
				...props
			}) });
			return null;
		},
		renderBody: () => jsx("div", {
			className: `${displayMode === DisplayMode.IssueCreation || displayMode === DisplayMode.IssueDuplication ? "tmp-p-3" : "p-0"}`,
			children: jsx(CreateIssue, {
				onCreateSuccess: resetDisplayModeOnCreateSuccess,
				navigate,
				currentRepository: currentRepository === "unset" ? "unset" : data || null,
				duplicateDetection,
				...issueDialogProps
			})
		}),
		onClose: onSafeClose,
		width: "xlarge",
		height: "auto",
		sx: { visibility: showCreateDialog ? "visible" : "hidden" },
		className: CreateIssueDialog_module_default.CreateIssueDialogContainer
	}) });
};
CreateIssueDialog.displayName = "CreateIssueDialog";
var CreateIssueDialogEntryGraphQLQuery = node$76;
var CreateIssueDialogEntry = ({ navigate, isCreateDialogOpen, setIsCreateDialogOpen, onCancel, onCreateSuccess, onCreateError, optionConfig, isNavigatingToNew, setIsNavigatingToNew, returnFocusRef, fallbackElement }) => {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [topRepositories, setTopRepositories] = useState(null);
	const [currentRepository, setCurrentRepository] = useState(null);
	const config = getSafeConfig(optionConfig);
	const shouldLoadTopRepos = config.showRepositoryPicker;
	const shouldLoadCurrentRepo = config.issueCreateArguments?.repository ? true : false;
	useEffect(() => {
		const fetchTopRepos = async () => {
			setTopRepositories(await fetchTopRepositories(environment, {
				first: VALUES$1.repositoriesPreloadCount,
				hasIssuesEnabled: true
			}));
		};
		const fetchCurrentRepo = async () => {
			setCurrentRepository(await (0, import_react_relay.fetchQuery)(environment, CreateIssueDialogEntryGraphQLQuery, {
				owner: config.issueCreateArguments.repository.owner,
				name: config.issueCreateArguments.repository.name,
				includeTemplates: true
			}, { fetchPolicy: "store-or-network" }).toPromise() ?? null);
		};
		if (shouldLoadCurrentRepo) fetchCurrentRepo();
		if (shouldLoadTopRepos) fetchTopRepos();
	}, []);
	const handleDialogClose = () => {
		onCancel?.();
		setIsCreateDialogOpen(false);
	};
	const handleOnCreate = ({ issue, createMore }) => {
		if (onCreateSuccess) onCreateSuccess({
			issue,
			createMore
		});
		else if (!createMore) {
			handleDialogClose();
			navigate(issuePath({
				owner: issue.repository.owner.login,
				repo: issue.repository.name,
				issueNumber: issue.number
			}));
		}
	};
	const handleOnError = (error) => onCreateError?.(error);
	const createIssueDialogProps = {
		topRepositories: shouldLoadTopRepos ? topRepositories : "unset",
		onCreateSuccess: handleOnCreate,
		onCreateError: handleOnError,
		onCancel: handleDialogClose,
		navigate,
		isNavigatingToNew,
		setIsNavigatingToNew
	};
	if (!isCreateDialogOpen) return null;
	return /* @__PURE__ */ jsx(CreateIssueEntryWrapper, {
		createIssueProps: createIssueDialogProps,
		config,
		currentRepository: shouldLoadCurrentRepo ? currentRepository : "unset",
		returnFocusRef,
		fallbackElement
	});
};
CreateIssueDialogEntry.displayName = "CreateIssueDialogEntry";
var CreateIssueEntryWrapper = ({ createIssueProps, config, currentRepository, returnFocusRef, fallbackElement }) => {
	const navigate = createIssueProps.navigate ?? noop$1;
	const repository = currentRepository !== "unset" && currentRepository && currentRepository.repository ? readRepositoryFromFragment(currentRepository.repository) : null;
	const issueFormRef = useRef(null);
	const preselectedData = {
		repository: repository ?? void 0,
		template: void 0,
		parentIssue: config.issueCreateArguments?.parentIssue
	};
	const props = {
		...createIssueProps,
		issueFormRef,
		hideCreateMore: config.hideCreateMore
	};
	let redirect = false;
	if (repository?.hasIssuesEnabled && config.defaultDisplayMode !== DisplayMode.IssueDuplication) redirect = navigate !== noop$1 && !repository.hasAnyTemplates && repository.isBlankIssuesEnabled;
	useEffect(() => {
		if (redirect && repository) {
			const searchParams = constructIssueCreateParams({
				includeRepository: false,
				repository,
				templateFileName: void 0,
				...config.issueCreateArguments?.initialValues
			});
			navigate(`/${repository.nameWithOwner}/issues/new${searchParams ? `?${searchParams}` : ""}`);
		}
	}, [
		navigate,
		redirect,
		repository,
		config.issueCreateArguments?.initialValues
	]);
	if (redirect) return null;
	const isLoadingCurrentRepo = currentRepository === "unset" ? false : currentRepository === null;
	const isLoadingTopRepos = createIssueProps.topRepositories === "unset" ? false : createIssueProps.topRepositories === null;
	if (fallbackElement && (isLoadingCurrentRepo || isLoadingTopRepos)) return fallbackElement;
	return /* @__PURE__ */ jsx(IssueCreateContextProvider, {
		optionConfig: config,
		overrideFallbackDisplaymode: DisplayMode.TemplatePicker,
		preselectedData,
		children: /* @__PURE__ */ jsx(CreateIssueDialog, {
			currentRepository: currentRepository === "unset" ? "unset" : currentRepository?.repository || null,
			...props,
			returnFocusRef
		})
	});
};
CreateIssueEntryWrapper.displayName = "CreateIssueEntryWrapper";
export { projectSectionFragment as $, assigneesSectionFragment as A, fieldsSectionFragment as B, Section as C, TypesSectionTypeFragment as D, TypesSectionFragment as E, commitUpdateIssueProjectsMutation as F, getSelectedTemplate as G, formatAssignmentError as H, fetchAssignees as I, isCopilot as J, hovercardAttributesForActor as K, fetchIssueTypes as L, commitUpdateIssueAssigneesMutation as M, commitUpdateIssueIssueTypeMutation as N, assignIssuesToCopilot as O, commitUpdateIssueMilestoneMutation as P, parseIssueFieldValues as Q, fetchMilestones as R, ReadonlySectionHeader as S, TemplateQuery as T, getActorCapabilities as U, formatActorLogin as V, getSafeConfig as W, loginPath as X, labelsSectionFragment as Y, milestonesSectionMilestone as Z, LABELS$2 as _, EditIssueAssigneesSection as a, MilestonesSectionFragment as b, EditIssueLabelsSection as c, EmojiAutocomplete as d, searchProjectsQueryOptions as et, IssueCreateContextProvider as f, IssuesLoadingSkeleton as g, IssueTypeToken$1 as h, DisplayMode as i, commitSetLabelsForLabelableMutation as j, assigneesSectionAssignees as k, EditIssueMilestonesSection as l, IssueFormElements as m, CreateIssueDialogEntry as n, EditIssueFieldsSection as o, IssueFieldSingleSelectValueToken as p, instanceOfIssueFormData as q, CreateIssueForm as r, EditIssueIssueTypeSection as s, CopilotAvatar as t, useIssueCreateDataContext as tt, EditIssueProjectsSection as u, LabelsList as v, SectionHeader as w, ProjectsSectionFallback as x, LabelsSectionAssignedLabelsFragment as y, fieldsSectionFieldValuesFragment as z };
