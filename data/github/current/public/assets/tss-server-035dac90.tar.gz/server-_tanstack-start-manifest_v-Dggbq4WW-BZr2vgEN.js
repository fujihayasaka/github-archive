performance.mark("js-parse-end:server-_tanstack-start-manifest_v-Dggbq4WW-BZr2vgEN.js");
performance.mark("js-parse-end:_tanstack-start-manifest_v-Dggbq4WW.js");
var tsrStartManifest = () => ({
	"routes": {
		"__root__": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/root/root.tsx",
			"children": [
				"/_nav",
				"/healthcheck",
				"/ui/version"
			],
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/main-BChbnewi.js"]
		},
		"/_nav": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/root/global-nav-layout.tsx",
			"children": [
				"/_nav/_pulls_layout",
				"/_nav/_react_sandbox_future",
				"/_nav/_repos_layout",
				"/_nav/$owner/$repo/_repo_layout"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/global-nav-layout-DXWYZGDv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/staffbar-C9lNBvIr.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/global-nav-layout-CHL25lNJ.js",
				"https://github.githubassets.com/assets/copilot-local-storage-DigwhclQ.js",
				"https://github.githubassets.com/assets/connect-alive-subscription-DGRMqiiv.js",
				"https://github.githubassets.com/assets/Avatar-xPFmGBjh.js",
				"https://github.githubassets.com/assets/ButtonGroup-oGA1jZgP.js",
				"https://github.githubassets.com/assets/useQuery-CNDSveMM.js",
				"https://github.githubassets.com/assets/create-safe-indexed-db-storage-D7Ruy6pv.js",
				"https://github.githubassets.com/assets/immer-B674F3WE.js",
				"https://github.githubassets.com/assets/typebox-CYT9V66w.js",
				"https://github.githubassets.com/assets/cookies-CF80j-p_.js",
				"https://github.githubassets.com/assets/copilot-auth-token-DEu1bw8z.js",
				"https://github.githubassets.com/assets/copilot-chat-events-CXqsQJJ1.js",
				"https://github.githubassets.com/assets/copilot-chat-helpers-DjwMibZz.js",
				"https://github.githubassets.com/assets/GitHubAvatar-xT9FAk66.js",
				"https://github.githubassets.com/assets/global-navigation-D7kzuFAs.js",
				"https://github.githubassets.com/assets/constants-BSaMprpA.js",
				"https://github.githubassets.com/assets/constants-BThHgcqt.js",
				"https://github.githubassets.com/assets/LazyGlobalSsoBanner-SkNd6DA9.js",
				"https://github.githubassets.com/assets/CoreSsoBanner-DIqBznHV.js",
				"https://github.githubassets.com/assets/in-product-targeting-2F7wP-N3.js",
				"https://github.githubassets.com/assets/IncludeFragment-DUzgt3aX.js",
				"https://github.githubassets.com/assets/ItemPicker-BfmHvjLi.js",
				"https://github.githubassets.com/assets/strings-D9duskHa.js",
				"https://github.githubassets.com/assets/NavigableRef-CMcSq39M.js",
				"https://github.githubassets.com/assets/CustomIcon-CpjySpMB.js",
				"https://github.githubassets.com/assets/ErrorBoundary-CkRtIwzn.js",
				"https://github.githubassets.com/assets/Link-Pur7V-h-.js",
				"https://github.githubassets.com/assets/lazy-with-preload-UHgScfXv.js",
				"https://github.githubassets.com/assets/react-partial-anchor-ByjzkgYt.js",
				"https://github.githubassets.com/assets/react-query-persister-Ct4eBpcy.js",
				"https://github.githubassets.com/assets/staffbar.module-y8m2bGwL.js",
				"https://github.githubassets.com/assets/use-route-query-BIJNQ9-n.js",
				"https://github.githubassets.com/assets/use-alive-DGQ9Ff7L.js",
				"https://github.githubassets.com/assets/use-is-mounted-yE7a7hLj.js"
			]
		},
		"/_nav/_pulls_layout": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/pulls/layout.tsx",
			"children": ["/_nav/_pulls_layout/pulls"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-DJFcgZlv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposSelector-DzcPtoeR.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/UserFeedback-TRB_fcnh.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-WyvK8ph8.js",
				"https://github.githubassets.com/assets/react-relay-DCCMczbn.js",
				"https://github.githubassets.com/assets/dashboard-types-iExLSDsR.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/PageLayout-CwzugeoN.js",
				"https://github.githubassets.com/assets/Filter-DVk_MefO.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-wX_tYo8D.js",
				"https://github.githubassets.com/assets/use-user-HR1U4uri.js",
				"https://github.githubassets.com/assets/PreviewCard-CAtzDQlT.js",
				"https://github.githubassets.com/assets/ReposSelector-ChwkQsm1.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-wL8hULdw.js",
				"https://github.githubassets.com/assets/use-app-payload-sQWHJ9yx.js",
				"https://github.githubassets.com/assets/use-stable-random-E41Olg5L.js",
				"https://github.githubassets.com/assets/UserFeedback-CAANWJ2E.js"
			]
		},
		"/_nav/_react_sandbox_future": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-layout.tsx",
			"children": ["/_nav/_react_sandbox_future/react_sandbox_future/", "/_nav/_react_sandbox_future/react_sandbox_future/$id"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/react-sandbox-future-layout-CA3XD2Yu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-layout-Bac5VZL8.js", "https://github.githubassets.com/assets/PageLayout-CwzugeoN.js"]
		},
		"/_nav/_repos_layout": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/repos/layout.tsx",
			"children": ["/_nav/_repos_layout/repos"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-BYQps9c3.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-MQaFYaQv.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/PageLayout-CwzugeoN.js",
				"https://github.githubassets.com/assets/Filter-DVk_MefO.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-wX_tYo8D.js",
				"https://github.githubassets.com/assets/use-feature-flag-PIjB6dmO.js",
				"https://github.githubassets.com/assets/ReposFinderStateContext-nX_wlttZ.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-wL8hULdw.js",
				"https://github.githubassets.com/assets/use-app-payload-sQWHJ9yx.js",
				"https://github.githubassets.com/assets/use-stable-random-E41Olg5L.js"
			]
		},
		"/_nav/_pulls_layout/pulls": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/pulls/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/pulls-DyzpB9ty.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelToken-Cj_rz1dY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/pulls-BibY0t8D.js",
				"https://github.githubassets.com/assets/Pagination-BzCXOcuV.js",
				"https://github.githubassets.com/assets/LabelToken-Bu4PlnKi.js",
				"https://github.githubassets.com/assets/use-get-hovercard-attributes-for-type-Didoah7M.js",
				"https://github.githubassets.com/assets/Icons-CGLTxdCO.js",
				"https://github.githubassets.com/assets/ProfileReference-B9cTrSvp.js"
			]
		},
		"/_nav/_repos_layout/repos": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/repos/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/repos-hCrk19KR.js", "https://github.githubassets.com/assets/Pagination-BzCXOcuV.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-index.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-index-BlNKq9Av.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/$id": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-id.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-id-DVPN2fd-.js"]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScrollMarksContainer-jgZd6-5D.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-85LWIG2N.js",
				"https://github.githubassets.com/assets/PageLayout-CwzugeoN.js",
				"https://github.githubassets.com/assets/TreeView-BUt5Qa-y.js",
				"https://github.githubassets.com/assets/SkeletonText-C3XcvuCx.js",
				"https://github.githubassets.com/assets/use-is-data-router-enabled-DsZdfB8C.js",
				"https://github.githubassets.com/assets/repos-file-tree-view-jBNAPXBO.js",
				"https://github.githubassets.com/assets/CodeLine-BvsB1A8z.js",
				"https://github.githubassets.com/assets/AllShortcutsEnabled-DkYzTULe.js",
				"https://github.githubassets.com/assets/HiddenUnicodeCharacter-3WXa6fiQ.js",
				"https://github.githubassets.com/assets/ReposHeaderRefSelector-Bv-xG6JM.js",
				"https://github.githubassets.com/assets/FileResultsList-DpvjMiqJ.js",
				"https://github.githubassets.com/assets/CodeViewBannersContext-DIRMy-XK.js",
				"https://github.githubassets.com/assets/CopilotSettingsContext-D-DVUe0i.js",
				"https://github.githubassets.com/assets/EditPermissionsContext-C-0hUxAl.js",
				"https://github.githubassets.com/assets/find-file-BIJ9hy7z.js",
				"https://github.githubassets.com/assets/FilesPageInfoContext-B06zJvcd.js",
				"https://github.githubassets.com/assets/CodeViewOptionsProvider-DmqCPnIL.js",
				"https://github.githubassets.com/assets/CodeNavSymbolNavigation-Dti0ULvw.js",
				"https://github.githubassets.com/assets/ScrollMarksContainer-C4xFmIOl.js",
				"https://github.githubassets.com/assets/CodeNavContext-CYnsAlxi.js",
				"https://github.githubassets.com/assets/TreePaneContext-CkSSbZIj.js",
				"https://github.githubassets.com/assets/ExpandButton-B_3YOYSd.js",
				"https://github.githubassets.com/assets/history-CUjdXmzR.js",
				"https://github.githubassets.com/assets/NewAgentTaskButton-CZPJQ12z.js",
				"https://github.githubassets.com/assets/react-observable-3EQ-A0GQ.js",
				"https://github.githubassets.com/assets/PortalTooltip-mQ4Dlofa.js",
				"https://github.githubassets.com/assets/use-route-payload-CfHVfWHe.js",
				"https://github.githubassets.com/assets/RefSelector-0XzMxKGo.js",
				"https://github.githubassets.com/assets/ScreenSize-BIJ7VmW_.js",
				"https://github.githubassets.com/assets/use-app-payload-sQWHJ9yx.js",
				"https://github.githubassets.com/assets/use-file-tree-tooltip-CKFoSIEU.js",
				"https://github.githubassets.com/assets/use-is-platform-CNElMTed.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/repo-overview.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/repo-overview-Dt-zJ_DH.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-Dki0VNLl.js",
				"https://github.githubassets.com/assets/CircleOcticon-DxdnGtm5.js",
				"https://github.githubassets.com/assets/use-codespaces-data-DmqaDXZC.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-DK9bxaOR.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-Cn57fzyk.js",
				"https://github.githubassets.com/assets/PublishBanners-CWbPtIB7.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CgzQuUhe.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/SharedPageLayout-D49RnkES.js",
				"https://github.githubassets.com/assets/commit-checks-status-DhU_Tw78.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CBVLh9eO.js",
				"https://github.githubassets.com/assets/ProfileReference-B9cTrSvp.js",
				"https://github.githubassets.com/assets/use-page-data-url-CAC01sTn.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DRpXv8Xv.js",
				"https://github.githubassets.com/assets/use-latest-commit-BOd-hYo7.js",
				"https://github.githubassets.com/assets/use-web-vitals-BmposP7r.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/file-tree-layout.tsx",
			"children": [
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/file-tree-layout-B2kVSyVy.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/file-tree-layout-BExKRTCW.js",
				"https://github.githubassets.com/assets/overview-types-iJX8LBpY.js",
				"https://github.githubassets.com/assets/SharedPageLayout-D49RnkES.js",
				"https://github.githubassets.com/assets/use-hide-footer-rSdoutO6.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/blob-layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-layout-DcRi6Sdw.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-Cn57fzyk.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CgzQuUhe.js",
				"https://github.githubassets.com/assets/NavigationMenu-Gg-_KdY1.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DKAjwByA.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CBVLh9eO.js",
				"https://github.githubassets.com/assets/Breadcrumb-gqvA2YDa.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DRpXv8Xv.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/delete-DXjAQnVO.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-Cn57fzyk.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/NavigationMenu-Gg-_KdY1.js",
				"https://github.githubassets.com/assets/EditIssues-C2x5OIKQ.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CU18zXLG.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DKAjwByA.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CBVLh9eO.js",
				"https://github.githubassets.com/assets/diff-parts-Bqx2JtI2.js",
				"https://github.githubassets.com/assets/Breadcrumb-gqvA2YDa.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DRpXv8Xv.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/edit.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/edit-DsDGY1KY.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/CodeViewEditor-Bsk3THzV.js",
				"https://github.githubassets.com/assets/SuspenseFallback-l55LM2Nv.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/new.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/new-BlT5MgHK.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/CodeViewEditor-Bsk3THzV.js",
				"https://github.githubassets.com/assets/SuspenseFallback-l55LM2Nv.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/tree.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/tree-CEjCnYpa.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-DSXKNUhT.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-Dki0VNLl.js",
				"https://github.githubassets.com/assets/CircleOcticon-DxdnGtm5.js",
				"https://github.githubassets.com/assets/use-codespaces-data-DmqaDXZC.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-DK9bxaOR.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-Cn57fzyk.js",
				"https://github.githubassets.com/assets/PublishBanners-CWbPtIB7.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CgzQuUhe.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/NavigationMenu-Gg-_KdY1.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BGtVhZ_6.js",
				"https://github.githubassets.com/assets/Panel-w5MDwR_8.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DKAjwByA.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js",
				"https://github.githubassets.com/assets/commit-checks-status-DhU_Tw78.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CBVLh9eO.js",
				"https://github.githubassets.com/assets/BetaLabel-C6lsxJm2.js",
				"https://github.githubassets.com/assets/LabelWithLink-C0sF_SXT.js",
				"https://github.githubassets.com/assets/ProfileReference-B9cTrSvp.js",
				"https://github.githubassets.com/assets/use-page-data-url-CAC01sTn.js",
				"https://github.githubassets.com/assets/Breadcrumb-gqvA2YDa.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DRpXv8Xv.js",
				"https://github.githubassets.com/assets/use-latest-commit-BOd-hYo7.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DELQLm5Y.js",
				"https://github.githubassets.com/assets/use-web-vitals-BmposP7r.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/blame.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blame-BjXo3MXy.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/BlobViewContent-DwlsmNUf.js",
				"https://github.githubassets.com/assets/PublishBanners-CWbPtIB7.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BGtVhZ_6.js",
				"https://github.githubassets.com/assets/Panel-w5MDwR_8.js",
				"https://github.githubassets.com/assets/SuspenseFallback-l55LM2Nv.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js",
				"https://github.githubassets.com/assets/commit-checks-status-DhU_Tw78.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-ztNqbV3o.js",
				"https://github.githubassets.com/assets/CopilotPopover-qPjDH2W2.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-DwsYCtph.js",
				"https://github.githubassets.com/assets/FeatureRequest-C4H4ez5z.js",
				"https://github.githubassets.com/assets/BetaLabel-C6lsxJm2.js",
				"https://github.githubassets.com/assets/LabelWithLink-C0sF_SXT.js",
				"https://github.githubassets.com/assets/ProfileReference-B9cTrSvp.js",
				"https://github.githubassets.com/assets/use-feature-flag-PIjB6dmO.js",
				"https://github.githubassets.com/assets/use-contributors-DXw0iw5w.js",
				"https://github.githubassets.com/assets/use-latest-commit-BOd-hYo7.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DELQLm5Y.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/blob.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-DmTY6TTt.js",
				"https://github.githubassets.com/assets/AvatarStack-DritE6s-.js",
				"https://github.githubassets.com/assets/BlobViewContent-DwlsmNUf.js",
				"https://github.githubassets.com/assets/PublishBanners-CWbPtIB7.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BGtVhZ_6.js",
				"https://github.githubassets.com/assets/Panel-w5MDwR_8.js",
				"https://github.githubassets.com/assets/SuspenseFallback-l55LM2Nv.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js",
				"https://github.githubassets.com/assets/commit-checks-status-DhU_Tw78.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-ztNqbV3o.js",
				"https://github.githubassets.com/assets/CopilotPopover-qPjDH2W2.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-DwsYCtph.js",
				"https://github.githubassets.com/assets/FeatureRequest-C4H4ez5z.js",
				"https://github.githubassets.com/assets/BetaLabel-C6lsxJm2.js",
				"https://github.githubassets.com/assets/LabelWithLink-C0sF_SXT.js",
				"https://github.githubassets.com/assets/ProfileReference-B9cTrSvp.js",
				"https://github.githubassets.com/assets/use-feature-flag-PIjB6dmO.js",
				"https://github.githubassets.com/assets/use-contributors-DXw0iw5w.js",
				"https://github.githubassets.com/assets/use-latest-commit-BOd-hYo7.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DELQLm5Y.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$": {
			"filePath": "/home/runner/work/github-ui/github-ui/packages/tss-server/src/routes/code-view/tree-delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-delete-cpgCJH-8.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-Cn57fzyk.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-D_7ZY2E9.js",
				"https://github.githubassets.com/assets/NavigationMenu-Gg-_KdY1.js",
				"https://github.githubassets.com/assets/EditIssues-C2x5OIKQ.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CU18zXLG.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BKxCy1mh.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DKAjwByA.js",
				"https://github.githubassets.com/assets/CodeView-BT1KXUKB.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CBVLh9eO.js",
				"https://github.githubassets.com/assets/diff-parts-Bqx2JtI2.js",
				"https://github.githubassets.com/assets/Breadcrumb-gqvA2YDa.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DRpXv8Xv.js"
			]
		}
	},
	"clientEntry": "https://github.githubassets.com/assets/main-BChbnewi.js"
});
export { tsrStartManifest };
