performance.mark("js-parse-end:server-pulls-Nn2C5fjp-DxFbEpBf.js");
import { Ai as XCircleFillIcon, E as CheckCircleFillIcon, Jt as GitPullRequestIcon, Mi as XIcon, O as CheckIcon, Rn as NoEntryFillIcon, V as ClockIcon, Z as CommentIcon, bn as Link, o as AlertIcon, sn as InboxIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { g as useLocation$1, y as useNavigation } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as useRouteQuery, r as useSuspenseRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as Pagination } from "./server-Pagination-B4OyqKu2-DIEgelho.js";
import { n as PullRequestStateIcons } from "./server-Icons-BGcf3kco-Dw59hRar.js";
import { t as ProfileReference } from "./server-ProfileReference-BiGysK1d-VyvZmlrw.js";
import { t as LabelToken } from "./server-LabelToken-D9qiz0SP-C1EDhfRF.js";
import { _ as useListViewVariant, a as ListItemLeadingVisual, c as ListItemTitle, d as human, i as ListItemLeadingContent, l as ListView, o as ListItemMainContent, r as ListItemDescription, s as ListItemMetadata, t as ListItem, u as getSignificanceBasedPrecision } from "./server-MainContent-ouZQ_bM_-DHVoK7D7.js";
import { r as pullsDashboardSurfaceContentRoute } from "./server-pulls-dashboard-surface-content-route-CY12u0dp-B-R1iWh6.js";
import { a as StateType, c as dashboardTypeLabels, d as usePullsDashboardSurfaceStateContext, i as ReviewDecisionState, o as StatusCheckState, s as dashboardTypeLabelSingular, u as usePullsDashboardSurfaceLayoutState } from "./server-dashboard-types-BuwdHcA--CDy_6se1.js";
import { a as getSortFromQuery, i as addSortToQuery, n as ListViewMetadata, o as getSortingKeyAndDirection, r as SortingDropdown, s as getSortingOptionLabel, t as ListViewDensityToggle } from "./server-query-DlQMbiaN-CidcEdMM.js";
import { t as PullsListLoadingSkeleton } from "./server-PullsListLoadingSkeleton-DhYMWKWJ-5yMD5jGg.js";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:pulls-Nn2C5fjp.js");
function PullsListEmptyMessage(t0) {
	const $ = c(6);
	const { heading, description } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== description || $[1] !== heading || $[2] !== sendAnalyticsEvent) {
		let t2;
		if ($[4] !== sendAnalyticsEvent) {
			t2 = () => sendAnalyticsEvent("pull-requests.click", "EMPTY_STATE", { label: "learn-more-link" });
			$[4] = sendAnalyticsEvent;
			$[5] = t2;
		} else t2 = $[5];
		t1 = jsxs(BlankslateContainer, {
			"data-testid": "pulls-empty-state",
			children: [
				jsx(BlankslateContainer.Visual, { children: jsx(GitPullRequestIcon, { size: 24 }) }),
				jsx(BlankslateContainer.Heading, { children: heading }),
				jsxs(BlankslateContainer.Description, { children: [
					jsx("span", { children: description ?? "Try a different search query." }),
					" ",
					jsx(Link, {
						inline: true,
						href: "https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/filtering-and-searching-issues-and-pull-requests",
						onClick: t2,
						children: "Learn more about searching and filtering pull requests."
					})
				] })
			]
		});
		$[0] = description;
		$[1] = heading;
		$[2] = sendAnalyticsEvent;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
PullsListEmptyMessage.displayName = "PullsListEmptyMessage";
var reviewDecision = (reviewDecisionState) => {
	let reviewDecisionIcon = null;
	switch (reviewDecisionState) {
		case ReviewDecisionState.Approved:
			reviewDecisionIcon = /* @__PURE__ */ jsxs("span", { children: [
				/* @__PURE__ */ jsx(CheckCircleFillIcon, {
					size: 12,
					className: "color-fg-success"
				}),
				" ",
				/* @__PURE__ */ jsx("span", { children: "Approved" })
			] });
			break;
		case ReviewDecisionState.ChangesRequested:
			reviewDecisionIcon = /* @__PURE__ */ jsxs("span", { children: [
				/* @__PURE__ */ jsx(XCircleFillIcon, {
					size: 12,
					className: "color-fg-danger"
				}),
				" ",
				/* @__PURE__ */ jsx("span", { children: "Changes requested" })
			] });
			break;
		case ReviewDecisionState.ReviewRequired:
			reviewDecisionIcon = /* @__PURE__ */ jsxs("span", { children: [
				/* @__PURE__ */ jsx(NoEntryFillIcon, {
					size: 12,
					className: "color-fg-attention"
				}),
				" ",
				/* @__PURE__ */ jsx("span", { children: "Review required" })
			] });
			break;
		default: return null;
	}
	return /* @__PURE__ */ jsxs("span", {
		"data-testid": "review-decision-icon",
		children: [/* @__PURE__ */ jsx("span", {
			className: "mr-1 ml-1",
			children: "· "
		}), reviewDecisionIcon]
	});
};
var statusCheckDisplay = (statusCheckRollup) => {
	let statusIcon = null;
	switch (statusCheckRollup.state) {
		case StatusCheckState.Success:
			statusIcon = /* @__PURE__ */ jsx(CheckIcon, {
				size: 12,
				className: "color-fg-success"
			});
			break;
		case StatusCheckState.Failure:
			statusIcon = /* @__PURE__ */ jsx(XIcon, {
				size: 12,
				className: "color-fg-danger"
			});
			break;
		case StatusCheckState.Pending:
			statusIcon = /* @__PURE__ */ jsx(ClockIcon, {
				size: 12,
				className: "color-fg-attention"
			});
			break;
		default: return null;
	}
	return /* @__PURE__ */ jsxs("span", {
		"data-testid": "ci-status-check",
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "mr-1 ml-1",
				children: "· "
			}),
			statusIcon,
			" ",
			statusCheckRollup.successCount,
			"/",
			statusCheckRollup.totalCount
		]
	});
};
var PullsListItem_module_default = {
	description: "PullsListItem-module_VsET7q_description",
	listItem: "PullsListItem-module_VsET7q_listItem",
	listItemCompact: "PullsListItem-module_VsET7q_listItemCompact",
	titleLink: "PullsListItem-module_VsET7q_titleLink"
};
var TimestampContainer = ({ prState, author, createdAt, updatedAt, isAgent = false }) => {
	const hasBeenUpdated = createdAt.getTime() !== updatedAt.getTime();
	const isOpen = prState === StateType.Opened;
	const isClosed = !isOpen;
	return /* @__PURE__ */ jsxs("span", {
		"data-testid": "timestamp-container",
		children: [
			/* @__PURE__ */ jsx("span", { children: "· " }),
			/* @__PURE__ */ jsx(ProfileReference, {
				login: author,
				profileName: author,
				isAgent
			}),
			/* @__PURE__ */ jsx("span", { children: " opened " }),
			/* @__PURE__ */ jsx(RelativeTime, { date: createdAt }),
			isOpen && hasBeenUpdated && /* @__PURE__ */ jsxs("span", { children: [
				" ",
				/* @__PURE__ */ jsx("span", { children: "·" }),
				" ",
				/* @__PURE__ */ jsx("span", { children: "Updated" }),
				" ",
				/* @__PURE__ */ jsx(RelativeTime, { date: updatedAt })
			] }),
			isClosed && /* @__PURE__ */ jsxs("span", { children: [
				" ",
				/* @__PURE__ */ jsx("span", { children: "·" }),
				" ",
				/* @__PURE__ */ jsx("span", { children: "Closed" }),
				" ",
				/* @__PURE__ */ jsx(RelativeTime, { date: updatedAt })
			] })
		]
	});
};
TimestampContainer.displayName = "TimestampContainer";
function PullsListItem(t0) {
	const $ = c(9);
	const { pulls } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const { variant } = useListViewVariant();
	const isCompact = variant === "compact";
	let t1;
	if ($[0] !== getHovercardAttributesForType || $[1] !== isCompact || $[2] !== pulls || $[3] !== sendAnalyticsEvent) {
		let t2;
		if ($[5] !== getHovercardAttributesForType || $[6] !== isCompact || $[7] !== sendAnalyticsEvent) {
			t2 = (pull) => {
				const PRStateIcon = PullRequestStateIcons[pull.displayState];
				const [owner, repo] = pull.repoNameWithOwner.split("/");
				const hovercardAttributes = getHovercardAttributesForType("pull_request", {
					owner,
					repo,
					pullRequestNumber: pull.number
				});
				const onTitleClick = () => sendAnalyticsEvent("pull-requests.click", "LIST_ITEM_TITLE", { displayState: pull.displayState });
				const labelBadges = pull.labels.map(_temp);
				return jsxs(ListItem, {
					className: isCompact ? PullsListItem_module_default.listItemCompact : PullsListItem_module_default.listItem,
					title: jsx(ListItemTitle, {
						href: pull.permalink,
						onClick: onTitleClick,
						value: pull.titleHtml ? jsx(UnsafeHTMLText, {
							as: "span",
							html: pull.titleHtml
						}) : jsx("span", { children: pull.title }),
						linkProps: {
							...hovercardAttributes,
							"data-testid": "listitem-title-link"
						},
						anchorClassName: PullsListItem_module_default.titleLink,
						trailingBadges: labelBadges
					}),
					metadata: jsx(Fragment$1, { children: pull.commentCount > 0 ? jsxs(ListItemMetadata, { children: [
						jsx(CommentIcon, { size: 16 }),
						" ",
						pull.commentCount
					] }) : null }),
					children: [jsx(ListItemLeadingContent, { children: jsx(ListItemLeadingVisual, { children: jsx(PRStateIcon, {}) }) }), jsx(ListItemMainContent, { children: jsxs(ListItemDescription, {
						className: isCompact ? void 0 : PullsListItem_module_default.description,
						children: [
							jsxs("span", { children: [
								pull.repoNameWithOwner,
								"#",
								pull.number,
								" "
							] }),
							jsx(TimestampContainer, {
								createdAt: new Date(pull.createdAt),
								updatedAt: new Date(pull.updatedAt),
								prState: pull.state,
								author: pull.author.displayLogin
							}),
							pull.reviewDecisionState ? reviewDecision(pull.reviewDecisionState) : null,
							pull.statusCheckRollup ? statusCheckDisplay(pull.statusCheckRollup) : null
						]
					}) })]
				}, pull.id);
			};
			$[5] = getHovercardAttributesForType;
			$[6] = isCompact;
			$[7] = sendAnalyticsEvent;
			$[8] = t2;
		} else t2 = $[8];
		t1 = jsx(Fragment$1, { children: pulls.map(t2) });
		$[0] = getHovercardAttributesForType;
		$[1] = isCompact;
		$[2] = pulls;
		$[3] = sendAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
PullsListItem.displayName = "PullsListItem";
function _temp(label) {
	return jsx(LabelToken, {
		text: label.name,
		fillColor: label.color ? `#${label.color}` : void 0,
		style: { marginRight: "4px" }
	}, label.id);
}
var DisplayMode = {
	Compact: "compact",
	Default: "default"
};
var PullsList_module_default = { pullsListContainer: "PullsList-module_LqtGbq_pullsListContainer" };
var DEFAULT_SORTING_KEY = "updated";
var defaultSortingOptions = {
	created: {
		label: "Created on",
		defaultDirection: "desc"
	},
	updated: {
		label: "Last updated",
		defaultDirection: "desc"
	},
	comments: {
		label: "Total comments",
		defaultDirection: "desc"
	},
	relevance: {
		label: "Best match",
		defaultDirection: void 0
	}
};
function PullsList({ pulls, pageInfo, compactMode, onCompactModeChange, sortingItemSelected, onSortingItemSelect, pullsEmptyListMessages }) {
	const resultText = pageInfo.totalCount === 1 ? "result" : "results";
	return /* @__PURE__ */ jsx(ListView, {
		title: "Pull requests",
		titleHeaderTag: "h2",
		className: PullsList_module_default.pullsListContainer,
		onVariantChange: (value) => onCompactModeChange(value === DisplayMode.Compact),
		variant: compactMode ? DisplayMode.Compact : DisplayMode.Default,
		metadata: /* @__PURE__ */ jsx(ListViewMetadata, {
			title: /* @__PURE__ */ jsxs("span", {
				"data-testid": "results-count",
				children: [
					pageInfo.totalCount,
					" ",
					resultText
				]
			}),
			densityToggle: /* @__PURE__ */ jsx(ListViewDensityToggle, {}),
			children: /* @__PURE__ */ jsx("div", {
				className: "mr-2",
				children: /* @__PURE__ */ jsx(SortingDropdown, {
					sortingItemSelected: sortingItemSelected || "",
					onSortingItemSelect,
					defaultSortingKey: DEFAULT_SORTING_KEY,
					sortingOptions: defaultSortingOptions,
					directionRestrictedKeys: ["relevance"],
					sortFieldsRequireDescSuffix: true
				})
			})
		}),
		children: pulls.length > 0 ? /* @__PURE__ */ jsx(PullsListItem, { pulls }) : /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(PullsListEmptyMessage, { ...pullsEmptyListMessages }) })
	});
}
PullsList.displayName = "PullsList";
var variants = {
	empty: {
		icon: InboxIcon,
		heading: "All caught up",
		description: "When a pull request needs your review or attention, it'll appear here."
	},
	error: {
		icon: AlertIcon,
		heading: "Something went wrong",
		description: "Failed to load pull requests. Try refreshing the page."
	}
};
function DashboardBlankslate({ variant }) {
	const { icon: Icon, heading, description } = variants[variant];
	return /* @__PURE__ */ jsx("div", {
		className: "border border-color-muted rounded-2",
		role: variant === "error" ? "alert" : "status",
		children: /* @__PURE__ */ jsxs(BlankslateContainer, {
			border: false,
			spacious: false,
			children: [
				/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(Icon, { size: 24 }) }),
				/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: heading }),
				/* @__PURE__ */ jsx(BlankslateContainer.Description, { children: description })
			]
		})
	});
}
DashboardBlankslate.displayName = "DashboardBlankslate";
function useEnrichedPulls() {
	const $ = c(10);
	const { data: payload } = useSuspenseRouteQuery(pullsDashboardSurfaceContentRoute, "mainQuery");
	const { data: deferredData, isPending, isError } = useRouteQuery(pullsDashboardSurfaceContentRoute, "deferred");
	const dataResults = payload?.results;
	const deferredResults = deferredData?.payload?.pullsDashboardSurfaceContentDeferredData.results;
	let t0;
	if ($[0] !== dataResults || $[1] !== deferredResults) {
		let t1;
		if ($[3] !== deferredResults) {
			t1 = (pull) => {
				const deferredPull = deferredResults?.find((deferredPullData) => deferredPullData.id === pull.id);
				return {
					...pull,
					reviewDecisionState: deferredPull?.reviewDecisionState,
					statusCheckRollup: deferredPull?.statusCheckRollup
				};
			};
			$[3] = deferredResults;
			$[4] = t1;
		} else t1 = $[4];
		t0 = dataResults.map(t1);
		$[0] = dataResults;
		$[1] = deferredResults;
		$[2] = t0;
	} else t0 = $[2];
	const enrichedPullsData = t0;
	const t1 = payload?.pageInfo;
	let t2;
	if ($[5] !== enrichedPullsData || $[6] !== isError || $[7] !== isPending || $[8] !== t1) {
		t2 = {
			pulls: enrichedPullsData,
			pageInfo: t1,
			isPending,
			isError
		};
		$[5] = enrichedPullsData;
		$[6] = isError;
		$[7] = isPending;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
/**
* Hook to manage the state of the pulls dashboard page results.
* Handles the display logic for showing empty results when the query is cleared.
*
* @param payload - The page payload containing pull request search results
* @returns An object containing:
*   - isLoading: Whether the data is currently loading
*   - fetchedQuery: The current search query
*   - results: The pull request search results (or empty results if query is cleared)
*   - currentPage: The current page number
*   - methods: Object with fetchResults and updateAndSubmitQuery functions
*/
function usePullsDashboardState(payload) {
	const $ = c(12);
	const { fetchedQuery, currentPage, fetchResults, isLoading } = usePullsDashboardSurfaceStateContext();
	const { sendAnalyticsEvent } = useAnalytics();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			results: [],
			pageInfo: {
				currentPage: 1,
				totalPages: 1,
				totalCount: 0
			}
		};
		$[0] = t0;
	} else t0 = $[0];
	const results = !!fetchedQuery ? payload : t0;
	let t1;
	if ($[1] !== fetchResults || $[2] !== sendAnalyticsEvent) {
		t1 = (q) => {
			sendAnalyticsEvent("pull-requests.search", "UPDATE_AND_SUBMIT_QUERY", { sort: getSortFromQuery(q) });
			fetchResults({
				q,
				page: 1
			});
		};
		$[1] = fetchResults;
		$[2] = sendAnalyticsEvent;
		$[3] = t1;
	} else t1 = $[3];
	const updateAndSubmitQuery = t1;
	let t2;
	if ($[4] !== fetchResults || $[5] !== updateAndSubmitQuery) {
		t2 = {
			fetchResults,
			updateAndSubmitQuery
		};
		$[4] = fetchResults;
		$[5] = updateAndSubmitQuery;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== currentPage || $[8] !== isLoading || $[9] !== results || $[10] !== t2) {
		t3 = {
			isLoading,
			results,
			currentPage,
			methods: t2
		};
		$[7] = currentPage;
		$[8] = isLoading;
		$[9] = results;
		$[10] = t2;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
/**
* Hook to manage and persist the compact mode setting for lists.
* @param compactMode The initial compact mode value.
* @param preferenceKey The key to use for the FormData.
*/
function useUpdateCompactModeSetting(compactMode, preferenceKey) {
	const $ = c(3);
	const savedCompactModeRef = useRef(compactMode);
	const { sendAnalyticsEvent } = useAnalytics();
	let t0;
	if ($[0] !== preferenceKey || $[1] !== sendAnalyticsEvent) {
		t0 = { updateCompactModeSetting: async function updateCompactModeSetting(value) {
			if (savedCompactModeRef.current === value) return;
			sendAnalyticsEvent("pull-requests.click", "DENSITY_TOGGLE", { density: value ? DisplayMode.Compact : DisplayMode.Default });
			savedCompactModeRef.current = value;
			const formData = new FormData();
			formData.set(preferenceKey, value.toString());
			await verifiedFetch("/pulls/preferences", {
				method: "PUT",
				body: formData
			});
		} };
		$[0] = preferenceKey;
		$[1] = sendAnalyticsEvent;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
function getScreenReaderMessage(dashboardType, sortingOptions, defaultSortingKey, getEmptyMessage, isFetching, currentPage, query, resultCount, pageCount) {
	if (isFetching) return "";
	if (resultCount === 0) {
		const { heading, description } = getEmptyMessage({
			dashboardType,
			filtered: !!query,
			currentPage,
			pageCount
		});
		return `${heading} ${description || ""}`.trim();
	}
	const [sortKey, direction] = getSortingKeyAndDirection(getSortFromQuery(query), defaultSortingKey);
	const sortingLabel = getSortingOptionLabel(sortKey, sortingOptions);
	const sortOrder = direction === "asc" ? "ascending" : "descending";
	return `${getDisplayCount(dashboardType, resultCount)} found. List is sorted by ${sortingLabel} in ${sortOrder} order.`;
}
function getDisplayCount(dashboardType, count) {
	return `${human(count, { precision: getSignificanceBasedPrecision(count) })} ${count === 1 ? dashboardTypeLabelSingular[dashboardType] : dashboardTypeLabels[dashboardType]}`;
}
function getEmptyMessage({ dashboardType, filtered, currentPage, pageCount, errorMessage }) {
	if (errorMessage) return {
		heading: "Invalid query",
		description: errorMessage
	};
	if (pageCount > 0 && currentPage > pageCount) return {
		heading: `No more ${dashboardTypeLabels[dashboardType]}.`,
		description: "Visit a lower page."
	};
	if (filtered) return {
		heading: `No ${dashboardTypeLabels[dashboardType]} matched your search.`,
		description: "Try a different search query."
	};
	return { heading: "Enter a query to start searching." };
}
/**
* Hook to manage screen reader announcements.
* Announces search results and empty states to screen reader users.
* @param dashboardType - The type of dashboard (e.g., issues, pull requests).
* @param isFetching - Whether a fetch is currently in progress.
* @param currentPage - The current page number.
* @param fetchedQuery - The query string that was fetched.
* @param defaultSortingKey - The default sorting key to use.
* @param resultCount - The number of results returned from the search.
* @param pageCount - The total number of pages available for the current query.
* @param errorMessage - Optional error message to announce when the query is invalid or results in an error.
* @returns An object containing the empty messages for display.
*/
function useScreenReaderAnnouncements(dashboardType, isFetching, currentPage, fetchedQuery, defaultSortingKey, resultCount, pageCount, errorMessage) {
	const $ = c(16);
	let emptyMessages;
	let t0;
	if ($[0] !== currentPage || $[1] !== dashboardType || $[2] !== defaultSortingKey || $[3] !== errorMessage || $[4] !== fetchedQuery || $[5] !== isFetching || $[6] !== pageCount || $[7] !== resultCount) {
		emptyMessages = getEmptyMessage({
			dashboardType,
			filtered: !!fetchedQuery,
			currentPage,
			pageCount,
			errorMessage
		});
		t0 = getScreenReaderMessage(dashboardType, defaultSortingOptions, defaultSortingKey, () => emptyMessages, isFetching, currentPage, fetchedQuery, resultCount, pageCount);
		$[0] = currentPage;
		$[1] = dashboardType;
		$[2] = defaultSortingKey;
		$[3] = errorMessage;
		$[4] = fetchedQuery;
		$[5] = isFetching;
		$[6] = pageCount;
		$[7] = resultCount;
		$[8] = emptyMessages;
		$[9] = t0;
	} else {
		emptyMessages = $[8];
		t0 = $[9];
	}
	const message = t0;
	let t1;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = debounce(announce$1, 300);
		$[10] = t1;
	} else t1 = $[10];
	const debouncedAnnounceRef = useRef(t1);
	let t2;
	let t3;
	if ($[11] !== message) {
		t2 = () => {
			const debouncedAnnounce = debouncedAnnounceRef.current;
			if (message) debouncedAnnounce(message);
			return () => {
				debouncedAnnounce.cancel();
			};
		};
		t3 = [message];
		$[11] = message;
		$[12] = t2;
		$[13] = t3;
	} else {
		t2 = $[12];
		t3 = $[13];
	}
	useEffect(t2, t3);
	let t4;
	if ($[14] !== emptyMessages) {
		t4 = { emptyMessages };
		$[14] = emptyMessages;
		$[15] = t4;
	} else t4 = $[15];
	return t4;
}
function isSameLocation(a, b) {
	return a.pathname === b.pathname && a.search === b.search;
}
function PullsDashboardSurfaceContentComponent() {
	const $ = c(2);
	const navigation = useNavigation();
	const location = useLocation$1();
	if (Boolean(navigation.location && !isSameLocation(navigation.location, location))) {
		let t0;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t0 = jsx(PullsListLoadingSkeleton, {});
			$[0] = t0;
		} else t0 = $[0];
		return t0;
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = jsx(ErrorBoundary, {
			boundaryName: "PullsDashboardContent",
			fallback: jsx("div", {
				className: "tmp-my-3",
				children: jsx(DashboardBlankslate, { variant: "error" })
			}),
			children: jsx(PullsDashboardPageContent, {})
		});
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
PullsDashboardSurfaceContentComponent.displayName = "PullsDashboardSurfaceContentComponent";
function PullsDashboardPageContent() {
	const $ = c(14);
	const { pulls, pageInfo, isPending } = useEnrichedPulls();
	const { compactMode } = usePullsDashboardSurfaceLayoutState();
	let t0;
	if ($[0] !== pageInfo || $[1] !== pulls) {
		t0 = {
			results: pulls,
			pageInfo
		};
		$[0] = pageInfo;
		$[1] = pulls;
		$[2] = t0;
	} else t0 = $[2];
	const { currentPage, methods, isLoading } = usePullsDashboardState(t0);
	const { fetchedQuery } = usePullsDashboardSurfaceStateContext();
	const { emptyMessages } = useScreenReaderAnnouncements("pull-requests", isLoading || !!isPending, currentPage, fetchedQuery, DEFAULT_SORTING_KEY, pageInfo.totalCount, pageInfo.totalPages);
	const { updateCompactModeSetting } = useUpdateCompactModeSetting(compactMode, "dashboard_surface_compact_mode");
	let t1;
	if ($[3] !== compactMode || $[4] !== emptyMessages || $[5] !== fetchedQuery || $[6] !== methods || $[7] !== pageInfo || $[8] !== pulls || $[9] !== updateCompactModeSetting) {
		let t2;
		if ($[11] !== fetchedQuery || $[12] !== methods) {
			t2 = (sort) => methods.updateAndSubmitQuery(addSortToQuery(fetchedQuery, sort));
			$[11] = fetchedQuery;
			$[12] = methods;
			$[13] = t2;
		} else t2 = $[13];
		t1 = jsx(Fragment$1, { children: jsx("div", {
			className: "tmp-my-3",
			children: jsxs("div", {
				"data-hpc": true,
				children: [jsx(PullsList, {
					pulls,
					pageInfo,
					compactMode,
					onCompactModeChange: updateCompactModeSetting,
					onSortingItemSelect: t2,
					sortingItemSelected: getSortFromQuery(fetchedQuery),
					pullsEmptyListMessages: emptyMessages
				}), pageInfo.totalPages > 1 && jsx(Pagination, {
					pageCount: pageInfo.totalPages,
					currentPage: pageInfo.currentPage,
					onPageChange: (e, page) => {
						e.preventDefault();
						methods.fetchResults({
							q: fetchedQuery,
							page
						});
						window.scrollTo({ top: 0 });
					}
				})]
			})
		}) });
		$[3] = compactMode;
		$[4] = emptyMessages;
		$[5] = fetchedQuery;
		$[6] = methods;
		$[7] = pageInfo;
		$[8] = pulls;
		$[9] = updateCompactModeSetting;
		$[10] = t1;
	} else t1 = $[10];
	return t1;
}
PullsDashboardPageContent.displayName = "PullsDashboardPageContent";
var SplitComponent = PullsDashboardSurfaceContentComponent;
export { SplitComponent as component };
