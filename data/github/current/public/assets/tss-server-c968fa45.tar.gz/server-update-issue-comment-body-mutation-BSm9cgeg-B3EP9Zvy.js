import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Lt as FoldIcon, On as MarkdownIcon, Sn as LinkIcon, Zn as PencilIcon, _n as KebabHorizontalIcon, an as IconButton, bi as UnfoldIcon, bn as Link, br as ReportIcon, dr as Radio, et as CopilotIcon, fn as IssueOpenedIcon, fr as RadioGroup_default, mi as TrashIcon, n as ActionList, nr as PinSlashIcon, pt as DotFillIcon, tr as PinIcon, ur as QuoteIcon, v as BlockedIcon, vt as EyeClosedIcon, yt as EyeIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { s as Label$1, t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { n as useConfirm, t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as AnalyticsContext } from "./server-context-CRkr38GV-DyKv_rx3.js";
import { i as CopilotChatIntents } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as copyText } from "./server-copy-ByVwvIP0-X47hrvCx.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as PortalTooltip } from "./server-PortalTooltip-DECeLuvi-BZbUqJOn.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { i as publishOpenCopilotChat } from "./server-copilot-chat-events-CAR-de8z-CxKg4yWR.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { n as md2html } from "./server-md2html-TgcTyYQC-DzwxtslQ.js";
import { t as reportError } from "./server-failbot-DcTQsQvG-1jpM1RlB.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { t as ErrorWithRetry } from "./server-RepositoryAndIssuePicker-pJUBAgRS-Bhe6Vlwu.js";
import { a as TEST_IDS, i as LABELS$1, n as ERRORS$1, s as selectQuoteFromComment } from "./server-quotes-Biwbbu-B-YKXYFdbk.js";
import { t as ProfileReference } from "./server-ProfileReference-BiGysK1d-VyvZmlrw.js";
import { i as DisplayMode, n as CreateIssueDialogEntry, q as isCopilot } from "./server-CreateIssueDialogEntry-DoIrAy1x-N5DbhlQU.js";
import React, { Component, Suspense, use, useCallback, useEffect, useId, useMemo, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { format, isThisYear, isToday, isValid, isYesterday } from "date-fns";
var node$16 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "createdAt",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v5 = [v3];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IssueCommentHeader",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "databaseId",
				"storageKey": null
			},
			v1,
			v2,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "body",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "authorAssociation",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanUpdate",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanDelete",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanMinimize",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanUnminimize",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanReport",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanReportToMaintainer",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanBlockFromOrg",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanUnblockFromOrg",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanPin",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanUnpin",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "App",
				"kind": "LinkedField",
				"name": "viaApp",
				"plural": false,
				"selections": [v3, v1],
				"storageKey": null
			},
			{
				"alias": "isHidden",
				"args": null,
				"kind": "ScalarField",
				"name": "isMinimized",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "minimizedReason",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "showSpammyBadge",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "createdViaEmail",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerDidAuthor",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Sponsorship",
				"kind": "LinkedField",
				"name": "authorToRepoOwnerSponsorship",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isActive",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "author",
				"plural": false,
				"selections": [
					v0,
					v4,
					{
						"kind": "InlineFragment",
						"selections": v5,
						"type": "User",
						"abstractKey": null
					},
					{
						"kind": "InlineFragment",
						"selections": v5,
						"type": "EnterpriseUserAccount",
						"abstractKey": null
					},
					{
						"kind": "InlineFragment",
						"selections": v5,
						"type": "Mannequin",
						"abstractKey": null
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v0,
					v3,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [
							v0,
							v4,
							v1
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "isPrivate",
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Issue",
				"kind": "LinkedField",
				"name": "issue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "number",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "MarkdownEditHistoryViewer_comment"
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "MarkdownLastEditedBy"
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "pinnedBy",
				"plural": false,
				"selections": [v4],
				"storageKey": null
			},
			{
				"kind": "ClientExtension",
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "pendingMinimizeReason",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "pendingBlock",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "pendingUnblock",
						"storageKey": null
					}
				]
			}
		],
		"type": "IssueComment",
		"abstractKey": null
	};
})();
node$16.hash = "e6d836bbc05ec0d67c6ed0d29ac7eee0";
var node$15 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "PinIssueCommentPayload",
		"kind": "LinkedField",
		"name": "pinIssueComment",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "IssueComment",
			"kind": "LinkedField",
			"name": "issueComment",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isPinned",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "pinCommentMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "pinCommentMutation",
			"selections": v1
		},
		"params": {
			"id": "603a99eb4de760eebcce53e70a42aeb9",
			"metadata": {},
			"name": "pinCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$15.hash = "673a6daa0f5af1be2c52b8dd35e34de1";
var import_react_relay = require_react_relay();
function pinCommentMutation({ environment, input: { id }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$15,
		variables: { input: { issueCommentId: id } },
		optimisticResponse: { pinIssueComment: {
			clientMutationId: "",
			issueComment: {
				id,
				isPinned: true
			}
		} },
		onCompleted: (response) => {
			if (response.pinIssueComment === null) onError?.();
			else onCompleted?.();
		},
		onError: (error) => onError?.(error)
	});
}
var node$14 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "UnpinIssueCommentPayload",
		"kind": "LinkedField",
		"name": "unpinIssueComment",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "IssueComment",
			"kind": "LinkedField",
			"name": "issueComment",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "id",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "isPinned",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "unpinCommentMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "unpinCommentMutation",
			"selections": v1
		},
		"params": {
			"id": "9710a8e78e25f0ad7f1915ebcb8856f8",
			"metadata": {},
			"name": "unpinCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$14.hash = "1a59136c3365b4350e72719aa0ad14c2";
function unpinCommentMutation({ environment, input: { id }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$14,
		variables: { input: { issueCommentId: id } },
		optimisticResponse: { unpinIssueComment: {
			clientMutationId: "",
			issueComment: {
				id,
				isPinned: false
			}
		} },
		onCompleted: (response) => {
			if (response.unpinIssueComment === null) onError?.();
			else onCompleted?.();
		},
		onError: (error) => onError?.(error)
	});
}
function usePinnedComment() {
	const $ = c(9);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	let t0;
	if ($[0] !== addToast || $[1] !== environment) {
		t0 = (commentId) => {
			pinCommentMutation({
				environment,
				input: { id: commentId },
				onError: () => {
					addToast({
						type: "error",
						message: "Failed to pin comment"
					});
				}
			});
		};
		$[0] = addToast;
		$[1] = environment;
		$[2] = t0;
	} else t0 = $[2];
	const pinComment = t0;
	let t1;
	if ($[3] !== addToast || $[4] !== environment) {
		t1 = (commentId_0) => {
			unpinCommentMutation({
				environment,
				input: { id: commentId_0 },
				onError: () => {
					addToast({
						type: "error",
						message: "Failed to unpin comment"
					});
				}
			});
		};
		$[3] = addToast;
		$[4] = environment;
		$[5] = t1;
	} else t1 = $[5];
	const unpinComment = t1;
	let t2;
	if ($[6] !== pinComment || $[7] !== unpinComment) {
		t2 = {
			pinComment,
			unpinComment
		};
		$[6] = pinComment;
		$[7] = unpinComment;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
var node$13 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "connections"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "clientMutationId",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "deleteIssueCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteIssueCommentPayload",
				"kind": "LinkedField",
				"name": "deleteIssueComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": "IssueComment",
					"kind": "LinkedField",
					"name": "issueComment",
					"plural": false,
					"selections": [v3],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "deleteIssueCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteIssueCommentPayload",
				"kind": "LinkedField",
				"name": "deleteIssueComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": "IssueComment",
					"kind": "LinkedField",
					"name": "issueComment",
					"plural": false,
					"selections": [v3, {
						"alias": null,
						"args": null,
						"filters": null,
						"handle": "deleteEdge",
						"key": "",
						"kind": "ScalarHandle",
						"name": "id",
						"handleArgs": [{
							"kind": "Variable",
							"name": "connections",
							"variableName": "connections"
						}]
					}],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "b0f125991160e607a64d9407db9c01b3",
			"metadata": {},
			"name": "deleteIssueCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$13.hash = "df574a3555b46c55b652c9621c8d3581";
function updateTotalCount(store, connectionIds) {
	for (const connectionId of connectionIds) {
		const connection = store.get(connectionId);
		if (connection) {
			const previousCount = Number(connection.getValue("totalCount"));
			if (!isNaN(previousCount)) connection.setValue(previousCount - 1, "totalCount");
		}
	}
}
function commitDeleteIssueCommentMutation({ environment, connectionIds, input: { id }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$13,
		variables: {
			input: { id },
			connections: connectionIds
		},
		optimisticResponse: { deleteIssueComment: {
			clientMutationId: "",
			issueComment: { id }
		} },
		optimisticUpdater: (store) => updateTotalCount(store, connectionIds),
		updater: (store) => updateTotalCount(store, connectionIds),
		onCompleted: (response) => {
			if (response.deleteIssueComment === null) onError?.();
			else onCompleted?.();
		},
		onError: (error) => onError?.(error)
	});
}
var node$12 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "clientMutationId",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isMinimized",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "minimizedReason",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "minimizeCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "MinimizeCommentPayload",
				"kind": "LinkedField",
				"name": "minimizeComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "minimizedComment",
					"plural": false,
					"selections": [v3, v4],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "minimizeCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "MinimizeCommentPayload",
				"kind": "LinkedField",
				"name": "minimizeComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "minimizedComment",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						v3,
						v4,
						{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "id",
								"storageKey": null
							}],
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "04ba37f7e52d10064ab666f7ddeec8cf",
			"metadata": {},
			"name": "minimizeCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$12.hash = "32b76c06b9ed656b474cba5d4a6b96e4";
function minimizeCommentMutation({ environment, input: { id, reason }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$12,
		variables: { input: {
			subjectId: id,
			classifier: reason
		} },
		optimisticResponse: { minimizeComment: {
			clientMutationId: "",
			minimizedComment: {
				id,
				__typename: "IssueComment",
				__isNode: "IssueComment",
				isMinimized: true,
				minimizedReason: reason
			}
		} },
		onCompleted: (response) => {
			if (response.minimizeComment === null) onError?.();
			else onCompleted?.();
		},
		onError: (error) => onError?.(error)
	});
}
var node$11 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "clientMutationId",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isMinimized",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "minimizedReason",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "unminimizeCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UnminimizeCommentPayload",
				"kind": "LinkedField",
				"name": "unminimizeComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "unminimizedComment",
					"plural": false,
					"selections": [v3, v4],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "unminimizeCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UnminimizeCommentPayload",
				"kind": "LinkedField",
				"name": "unminimizeComment",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "unminimizedComment",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						v3,
						v4,
						{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "id",
								"storageKey": null
							}],
							"type": "Node",
							"abstractKey": "__isNode"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "988dd6bb9180a9aaf6aa1e5b469f0443",
			"metadata": {},
			"name": "unminimizeCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$11.hash = "03ac2faeeddfe3c11f404095d6800e93";
function unminimizeCommentMutation({ environment, input: { id }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$11,
		variables: { input: { subjectId: id } },
		optimisticResponse: { unminimizeComment: {
			clientMutationId: "",
			unminimizedComment: {
				id,
				__typename: "IssueComment",
				__isNode: "IssueComment",
				isMinimized: false,
				minimizedReason: null
			}
		} },
		onCompleted: (response) => {
			if (response.unminimizeComment === null) onError?.();
			else {
				(0, import_react_relay.commitLocalUpdate)(environment, (store) => {
					store.get(id)?.setValue(null, "pendingMinimizeReason");
				});
				onCompleted?.();
			}
		},
		onError: (error) => onError?.(error)
	});
}
var node$10 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "includesCreatedEdit",
		"storageKey": null
	}, v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 100
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "editedAt",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "deletedAt",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "MarkdownEditHistoryViewerQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [v2, {
						"alias": null,
						"args": v3,
						"concreteType": "UserContentEditConnection",
						"kind": "LinkedField",
						"name": "userContentEdits",
						"plural": false,
						"selections": [v4, {
							"alias": null,
							"args": null,
							"concreteType": "UserContentEditEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "UserContentEdit",
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [
									v5,
									v6,
									v7,
									{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "editor",
										"plural": false,
										"selections": [v8, v9],
										"storageKey": null
									}
								],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": "userContentEdits(first:100)"
					}],
					"type": "Comment",
					"abstractKey": "__isComment"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "MarkdownEditHistoryViewerQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v10,
					{
						"kind": "InlineFragment",
						"selections": [v2, {
							"alias": null,
							"args": v3,
							"concreteType": "UserContentEditConnection",
							"kind": "LinkedField",
							"name": "userContentEdits",
							"plural": false,
							"selections": [v4, {
								"alias": null,
								"args": null,
								"concreteType": "UserContentEditEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "UserContentEdit",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v5,
										v6,
										v7,
										{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "editor",
											"plural": false,
											"selections": [
												v10,
												v8,
												v9,
												v5
											],
											"storageKey": null
										}
									],
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "userContentEdits(first:100)"
						}],
						"type": "Comment",
						"abstractKey": "__isComment"
					},
					v5
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "c6113eea560ba83b319c9b30fc5d4f7e",
			"metadata": {},
			"name": "MarkdownEditHistoryViewerQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$10.hash = "58ea81646b217a25de6cfe147936e7f6";
var node$9 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "MarkdownEditHistoryViewer_comment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanReadUserContentEdits",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "lastEditedAt",
			"storageKey": null
		}
	],
	"type": "Comment",
	"abstractKey": "__isComment"
};
node$9.hash = "fcc1ee717c6a87a4ffdb4f4d9391d55c";
var defaultFallBack = (retry) => {
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", { children: "Error:" }), /* @__PURE__ */ jsx("button", {
		onClick: retry,
		children: "Retry"
	})] });
};
var BasicPreloadedQueryBoundary = class extends Component {
	state = {
		error: null,
		hasAutoRetried: false
	};
	static getDerivedStateFromError(error) {
		error.shouldSkipReport = true;
		return { error };
	}
	componentDidCatch(error) {
		const willRetry = !this.state.hasAutoRetried;
		reportError(error, {
			critical: willRetry ? false : this.props.critical ?? false,
			reactAppName: this.props.appName,
			reactErrorBoundaryName: "BasicPreloadedQueryBoundary"
		});
		if (willRetry) {
			this.props.onRetry();
			this.setState({
				hasAutoRetried: true,
				error: null
			});
		}
	}
	_retry = () => {
		this.props.onRetry();
		this.setState({
			error: null,
			hasAutoRetried: false
		});
	};
	render() {
		const { children } = this.props;
		const { error } = this.state;
		const fallback = this.props.fallback || defaultFallBack;
		if (error) return fallback(this._retry, error);
		return children;
	}
};
function PreloadedQueryBoundary(props) {
	const { appName: propsAppName } = props;
	const context = use(AnalyticsContext);
	const appName = propsAppName || context?.appName;
	return /* @__PURE__ */ jsx(BasicPreloadedQueryBoundary, {
		...props,
		appName
	});
}
PreloadedQueryBoundary.displayName = "PreloadedQueryBoundary";
var ERRORS = {
	couldNotDeleteEditRevision: "Failed to delete this revision",
	couldNotLoad: `Couldn't load`
};
var CouldNotFindFallbackError_module_default = { CouldNotFindFallbackErrorContainer: "CouldNotFindFallbackError-module_LWXBfG_CouldNotFindFallbackErrorContainer" };
var CouldNotFindFallbackError = ({ retry }) => /* @__PURE__ */ jsx(ErrorWithRetry, {
	message: ERRORS.couldNotLoad,
	retry,
	className: CouldNotFindFallbackError_module_default.CouldNotFindFallbackErrorContainer
});
CouldNotFindFallbackError.displayName = "CouldNotFindFallbackError";
var node$8 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "diff",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "diffBefore",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "deletedAt",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "EditHistoryDialogQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [
						v2,
						v3,
						v4,
						{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "deletedBy",
							"plural": false,
							"selections": [v5],
							"storageKey": null
						},
						{
							"args": null,
							"kind": "FragmentSpread",
							"name": "EditHistoryDialogHeaderFragment"
						}
					],
					"type": "UserContentEdit",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "EditHistoryDialogQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v6,
					{
						"kind": "InlineFragment",
						"selections": [
							v2,
							v3,
							v4,
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "deletedBy",
								"plural": false,
								"selections": [
									v6,
									v5,
									v7
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": null,
								"kind": "LinkedField",
								"name": "editor",
								"plural": false,
								"selections": [
									v6,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "avatarUrl",
										"storageKey": null
									},
									v5,
									v7
								],
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "editedAt",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "newest",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "firstEdit",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "viewerCanDelete",
								"storageKey": null
							}
						],
						"type": "UserContentEdit",
						"abstractKey": null
					},
					v7
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "95112ed4d46018d629c28241b711a389",
			"metadata": {},
			"name": "EditHistoryDialogQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$8.hash = "027faee365f58b6aa217941196bb5c80";
var LABELS = {
	confirmations: {
		deleteEditHistoryTitle: "Are you sure you want to delete this revision from the history?",
		deleteEditHistoryContent: "This edit’s content will no longer be visible. This action can not be undone.",
		deleteEditHistoryConfirmButtonContent: "Remove"
	},
	editHistory: {
		viewingEditTitle: "Viewing edit",
		deleted: "Deleted",
		mostRecent: "Most recent",
		emptyEdit: "This revision does not contain any content.",
		deletedThisRevision: "deleted this revision",
		created: "created",
		edited: "edited",
		deleteRevisionAriaLabel: "Delete this edit revision",
		ariaLabel: "Open edits",
		openEditsButton: "Edits",
		editedBy: "edited by"
	}
};
var EditHistoryDialog_module_default = {
	contentViewerContainer: "EditHistoryDialog-module_BCb9sW_contentViewerContainer",
	editHistoryContentScrollable: "EditHistoryDialog-module_BCb9sW_editHistoryContentScrollable",
	EditHistoryDialogContainer: "EditHistoryDialog-module_BCb9sW_EditHistoryDialogContainer",
	loadingSkeletonContainer: "EditHistoryDialog-module_BCb9sW_loadingSkeletonContainer",
	mutedInfoText: "EditHistoryDialog-module_BCb9sW_mutedInfoText"
};
var node$7 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "EditHistoryDialogHeaderFragment",
	"selections": [
		{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "editor",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "avatarUrl",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "login",
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "deletedAt",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "editedAt",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "newest",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "firstEdit",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanDelete",
			"storageKey": null
		}
	],
	"type": "UserContentEdit",
	"abstractKey": null
};
node$7.hash = "173b0fbf2e248d6057ccd670ace2eea7";
var BUTTON_LABELS = { deleteEditRevision: "Delete revision" };
var VALUES = { ghostUserLogin: "ghost" };
var node$6 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "deletedAt",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "diff",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "deleteUserContentEditMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteUserContentEditPayload",
				"kind": "LinkedField",
				"name": "deleteUserContentEdit",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "UserContentEdit",
					"kind": "LinkedField",
					"name": "userContentEdit",
					"plural": false,
					"selections": [
						v2,
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "deletedBy",
							"plural": false,
							"selections": [v4, v5],
							"storageKey": null
						},
						v6
					],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "deleteUserContentEditMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "DeleteUserContentEditPayload",
				"kind": "LinkedField",
				"name": "deleteUserContentEdit",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "UserContentEdit",
					"kind": "LinkedField",
					"name": "userContentEdit",
					"plural": false,
					"selections": [
						v2,
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "deletedBy",
							"plural": false,
							"selections": [
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "__typename",
									"storageKey": null
								},
								v4,
								v5,
								v2
							],
							"storageKey": null
						},
						v6
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "71452b9f40a7828ac05811d1ad4f821e",
			"metadata": {},
			"name": "deleteUserContentEditMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$6.hash = "45e1f3e7d425560f65ef39e8c357794d";
function commitDeleteUserContentEditMutation({ environment, input: { id }, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$6,
		variables: { input: { id } },
		onCompleted: (response) => {
			if (response.deleteUserContentEdit === null) onError?.();
			else onCompleted?.();
		},
		onError: (error) => onError?.(error)
	});
}
var EditHistoryDialogHeader_module_default = {
	actorDetailsWrapper: "EditHistoryDialogHeader-module_MXtKoa_actorDetailsWrapper",
	deleteRevisionButton: "EditHistoryDialogHeader-module_MXtKoa_deleteRevisionButton",
	EditHistoryDialogHeaderContainer: "EditHistoryDialogHeader-module_MXtKoa_EditHistoryDialogHeaderContainer",
	statusLabel: "EditHistoryDialogHeader-module_MXtKoa_statusLabel",
	userAvatar: "EditHistoryDialogHeader-module_MXtKoa_userAvatar",
	usernameBold: "EditHistoryDialogHeader-module_MXtKoa_usernameBold"
};
var EditHistoryDialogHeader = (t0) => {
	const $ = c(14);
	const { queryRef, userContentEditId } = t0;
	const data = (0, import_react_relay.useFragment)(node$7, queryRef);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const confirm = useConfirm();
	const { addToast } = useToastContext();
	let t1;
	if ($[0] !== addToast || $[1] !== confirm || $[2] !== environment || $[3] !== userContentEditId) {
		t1 = async () => {
			if (await confirm({
				title: LABELS.confirmations.deleteEditHistoryTitle,
				content: LABELS.confirmations.deleteEditHistoryContent,
				confirmButtonType: "danger",
				confirmButtonContent: LABELS.confirmations.deleteEditHistoryConfirmButtonContent
			})) commitDeleteUserContentEditMutation({
				environment,
				input: { id: userContentEditId },
				onError: () => {
					addToast({
						type: "error",
						message: ERRORS.couldNotDeleteEditRevision
					});
				}
			});
		};
		$[0] = addToast;
		$[1] = confirm;
		$[2] = environment;
		$[3] = userContentEditId;
		$[4] = t1;
	} else t1 = $[4];
	const deleteRevision = t1;
	const hasTrailingElement = data.newest || data.deletedAt;
	let t2;
	if ($[5] !== data.deletedAt || $[6] !== data.editedAt || $[7] !== data.editor || $[8] !== data.firstEdit || $[9] !== data.newest || $[10] !== data.viewerCanDelete || $[11] !== deleteRevision || $[12] !== hasTrailingElement) {
		t2 = jsxs("div", {
			className: EditHistoryDialogHeader_module_default.EditHistoryDialogHeaderContainer,
			children: [data.editor && jsx(ActorOperationDetails, {
				login: data.editor.login,
				avatarUrl: data.editor.avatarUrl,
				time: data.editedAt,
				details: data.firstEdit ? LABELS.editHistory.created : LABELS.editHistory.edited,
				trailingElement: hasTrailingElement ? jsx(Label, {
					className: EditHistoryDialogHeader_module_default.statusLabel,
					children: data.deletedAt ? LABELS.editHistory.deleted : LABELS.editHistory.mostRecent
				}) : void 0
			}), data.viewerCanDelete && !data.newest && !data.deletedAt && jsxs(ButtonComponent, {
				variant: "danger",
				size: "small",
				"aria-label": LABELS.editHistory.deleteRevisionAriaLabel,
				onClick: deleteRevision,
				className: EditHistoryDialogHeader_module_default.deleteRevisionButton,
				children: [
					jsx(Octicon, { icon: TrashIcon }),
					" ",
					BUTTON_LABELS.deleteEditRevision
				]
			})]
		});
		$[5] = data.deletedAt;
		$[6] = data.editedAt;
		$[7] = data.editor;
		$[8] = data.firstEdit;
		$[9] = data.newest;
		$[10] = data.viewerCanDelete;
		$[11] = deleteRevision;
		$[12] = hasTrailingElement;
		$[13] = t2;
	} else t2 = $[13];
	return t2;
};
EditHistoryDialogHeader.displayName = "EditHistoryDialogHeader";
function ActorOperationDetails({ login, avatarUrl, details, time, className, trailingElement }) {
	const showUserAvatar = !!avatarUrl && !!login;
	return /* @__PURE__ */ jsxs("div", {
		className: EditHistoryDialogHeader_module_default.actorDetailsWrapper,
		children: [/* @__PURE__ */ jsxs("div", {
			className,
			children: [
				showUserAvatar && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(GitHubAvatar, {
					src: avatarUrl,
					size: 16,
					alt: `@${login}`,
					className: EditHistoryDialogHeader_module_default.userAvatar
				}), /* @__PURE__ */ jsx(Link, {
					href: `/${login}`,
					className: EditHistoryDialogHeader_module_default.usernameBold,
					"aria-label": `View profile for @${login}`,
					children: login
				})] }),
				!showUserAvatar && /* @__PURE__ */ jsx("span", { children: login ?? VALUES.ghostUserLogin }),
				/* @__PURE__ */ jsxs("span", { children: [
					" ",
					details,
					" "
				] }),
				time && /* @__PURE__ */ jsx(RelativeTime, { date: new Date(time) })
			]
		}), trailingElement]
	});
}
ActorOperationDetails.displayName = "ActorOperationDetails";
var safeSplitLines = (text) => text.split(/\r?\n/);
var safeSplitLine = (text) => text.split(/\s+/);
var singleGroup = (words, modification) => {
	return {
		groups: [{
			words: words ?? "",
			modification
		}],
		modification
	};
};
function groupChanges(before, after) {
	const beforeWords = before ? safeSplitLine(before) : [];
	const afterWords = after ? safeSplitLine(after) : [];
	if (beforeWords.length === 0 && afterWords.length === 0 || before === after) return singleGroup(before, "UNCHANGED");
	if (beforeWords.length === 0) return singleGroup(after, "ADDED");
	if (afterWords.length === 0) return singleGroup(before, "REMOVED");
	const groups = [];
	let unchanged = {
		words: "",
		modification: "UNCHANGED"
	};
	let added = {
		words: "",
		modification: "ADDED"
	};
	let removed = {
		words: "",
		modification: "REMOVED"
	};
	for (let index = 0; index < beforeWords.length || index < afterWords.length; index++) {
		const beforeWord = beforeWords[index];
		const afterWord = afterWords[index];
		if (beforeWord === afterWord) {
			unchanged.words = `${unchanged.words}${unchanged.words.length === 0 ? "" : " "}${beforeWord}`;
			if (added.words !== "") {
				groups.push(added);
				added = {
					words: "",
					modification: "ADDED"
				};
			}
			if (removed.words !== "") {
				groups.push(removed);
				removed = {
					words: "",
					modification: "REMOVED"
				};
			}
		} else {
			if (unchanged.words !== "" && (beforeWord !== void 0 || afterWord !== void 0)) {
				groups.push(unchanged);
				unchanged = {
					words: "",
					modification: "UNCHANGED"
				};
			}
			if (beforeWord !== void 0) removed.words = `${removed.words}${removed.words.length === 0 ? "" : " "}${beforeWord}`;
			if (afterWord !== void 0) added.words = `${added.words}${added.words.length === 0 ? "" : " "}${afterWord}`;
		}
	}
	if (added.words !== "") groups.push(added);
	if (removed.words !== "") groups.push(removed);
	if (unchanged.words !== "") groups.push(unchanged);
	return {
		groups,
		modification: "EDITED"
	};
}
function textDiff({ before, after }) {
	const beforeLines = before ? safeSplitLines(before) : [];
	const afterLines = after ? safeSplitLines(after) : [];
	const outputLines = [];
	for (let index = 0; index < beforeLines.length || index < afterLines.length; index++) {
		const beforeLine = beforeLines[index];
		const afterLine = afterLines[index];
		outputLines.push(groupChanges(beforeLine, afterLine));
	}
	return { lines: outputLines };
}
var GroupedTextDiffViewer_module_default = {
	borderStylingAdded: "GroupedTextDiffViewer-module_Qpmc_G_borderStylingAdded",
	borderStylingChanged: "GroupedTextDiffViewer-module_Qpmc_G_borderStylingChanged",
	borderStylingRemoved: "GroupedTextDiffViewer-module_Qpmc_G_borderStylingRemoved",
	diffContainer: "GroupedTextDiffViewer-module_Qpmc_G_diffContainer",
	diffLine: "GroupedTextDiffViewer-module_Qpmc_G_diffLine",
	wordStylingAdded: "GroupedTextDiffViewer-module_Qpmc_G_wordStylingAdded",
	wordStylingRemoved: "GroupedTextDiffViewer-module_Qpmc_G_wordStylingRemoved"
};
var getBorderStyling = (modification) => {
	switch (modification) {
		case "ADDED": return GroupedTextDiffViewer_module_default.borderStylingAdded;
		case "REMOVED": return GroupedTextDiffViewer_module_default.borderStylingRemoved;
		case "EDITED": return GroupedTextDiffViewer_module_default.borderStylingChanged;
		case "UNCHANGED": return "";
	}
};
var getWordStyling = (modification) => {
	switch (modification) {
		case "ADDED": return GroupedTextDiffViewer_module_default.wordStylingAdded;
		case "REMOVED": return GroupedTextDiffViewer_module_default.wordStylingRemoved;
		case "UNCHANGED": return "";
	}
};
var getScreenReaderHint = (modification) => {
	switch (modification) {
		case "ADDED": return {
			open: "[+]",
			close: "[/+]"
		};
		case "REMOVED": return {
			open: "[-]",
			close: "[/-]"
		};
	}
	return {
		open: "",
		close: ""
	};
};
var needsScreenReaderHint = (modification) => {
	return modification === "ADDED" || modification === "REMOVED";
};
var LineDiffViewer = ({ groups, modification }) => {
	const fullSentence = groups.map((group) => group.words).join(" ");
	return /* @__PURE__ */ jsxs("span", {
		className: GroupedTextDiffViewer_module_default.diffLine,
		children: [
			modification === "EDITED" && groups?.map((group, index) => {
				return /* @__PURE__ */ jsxs(Fragment$1, { children: [
					needsScreenReaderHint(group.modification) && /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: getScreenReaderHint(group.modification).open
					}),
					/* @__PURE__ */ jsx("span", {
						className: getWordStyling(group.modification),
						children: `${index === 0 ? "" : " "}${group.words}`
					}),
					needsScreenReaderHint(group.modification) && /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: getScreenReaderHint(group.modification).close
					})
				] }, index - 1);
			}),
			modification !== "EDITED" && groups.length > 0 && /* @__PURE__ */ jsxs(Fragment$1, { children: [
				/* @__PURE__ */ jsx("span", {
					className: "sr-only",
					children: getScreenReaderHint(modification).open
				}),
				/* @__PURE__ */ jsx("span", { children: fullSentence }),
				/* @__PURE__ */ jsx("span", {
					className: "sr-only",
					children: getScreenReaderHint(modification).close
				})
			] }),
			groups.length === 0 && /* @__PURE__ */ jsx("br", {})
		]
	});
};
LineDiffViewer.displayName = "LineDiffViewer";
var GroupedTextDiffViewer = ({ before, after }) => {
	const groupDiffSummary = textDiff({
		before,
		after
	});
	return /* @__PURE__ */ jsx("div", {
		className: GroupedTextDiffViewer_module_default.diffContainer,
		children: groupDiffSummary.lines.map((line, index) => {
			return /* @__PURE__ */ jsx("div", {
				className: getBorderStyling(line.modification),
				children: /* @__PURE__ */ jsx(LineDiffViewer, { ...line })
			}, index);
		})
	});
};
GroupedTextDiffViewer.displayName = "GroupedTextDiffViewer";
var EditHistoryContentGraphql = node$8;
var EditHistoryDialog = ({ userContentEditId, onClose }) => {
	return /* @__PURE__ */ jsx(Dialog, {
		renderBody: () => /* @__PURE__ */ jsx(EditContent, { userContentEditId }),
		onClose,
		title: LABELS.editHistory.viewingEditTitle,
		width: "xlarge",
		height: "auto",
		className: EditHistoryDialog_module_default.EditHistoryDialogContainer
	});
};
EditHistoryDialog.displayName = "EditHistoryDialog";
var EditContent = (t0) => {
	const $ = c(12);
	const { userContentEditId } = t0;
	const [queryRef, loadEditContent] = (0, import_react_relay.useQueryLoader)(EditHistoryContentGraphql);
	let t1;
	let t2;
	if ($[0] !== loadEditContent || $[1] !== userContentEditId) {
		t1 = () => {
			loadEditContent({ id: userContentEditId });
		};
		t2 = [loadEditContent, userContentEditId];
		$[0] = loadEditContent;
		$[1] = userContentEditId;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	if (!queryRef) {
		let t3;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = jsx(EditContentLoading, {});
			$[4] = t3;
		} else t3 = $[4];
		return t3;
	}
	let t3;
	if ($[5] !== loadEditContent || $[6] !== queryRef || $[7] !== userContentEditId) {
		let t4;
		if ($[9] !== loadEditContent || $[10] !== userContentEditId) {
			t4 = () => loadEditContent({ id: userContentEditId }, { fetchPolicy: "network-only" });
			$[9] = loadEditContent;
			$[10] = userContentEditId;
			$[11] = t4;
		} else t4 = $[11];
		t3 = jsx(Suspense, {
			fallback: jsx(EditContentLoading, {}),
			children: jsx(PreloadedQueryBoundary, {
				onRetry: t4,
				fallback: _temp$1,
				children: jsx(EditContentInternal, {
					queryRef,
					userContentEditId
				})
			})
		});
		$[5] = loadEditContent;
		$[6] = queryRef;
		$[7] = userContentEditId;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
};
EditContent.displayName = "EditContent";
var EditContentInternal = (t0) => {
	const $ = c(5);
	const { queryRef, userContentEditId } = t0;
	const data = (0, import_react_relay.usePreloadedQuery)(EditHistoryContentGraphql, queryRef).node;
	if (!data) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx(EditContentLoading, {});
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	}
	const emptyDiff = !data.diffBefore && !data.diff;
	let t1;
	if ($[1] !== data || $[2] !== emptyDiff || $[3] !== userContentEditId) {
		t1 = jsxs("div", {
			className: EditHistoryDialog_module_default.editHistoryContentScrollable,
			children: [jsx(EditHistoryDialogHeader, {
				queryRef: data,
				userContentEditId
			}), jsxs("div", {
				className: EditHistoryDialog_module_default.contentViewerContainer,
				children: [
					!data.deletedAt && !emptyDiff && jsx(GroupedTextDiffViewer, {
						before: data.diffBefore ?? void 0,
						after: data.diff ?? void 0
					}),
					!data.deletedAt && emptyDiff && jsx("span", {
						className: EditHistoryDialog_module_default.mutedInfoText,
						children: LABELS.editHistory.emptyEdit
					}),
					data.deletedAt && jsx(ActorOperationDetails, {
						login: data.deletedBy?.login,
						details: LABELS.editHistory.deletedThisRevision,
						time: data.deletedAt,
						className: EditHistoryDialog_module_default.mutedInfoText
					})
				]
			})]
		});
		$[1] = data;
		$[2] = emptyDiff;
		$[3] = userContentEditId;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
EditContentInternal.displayName = "EditContentInternal";
function EditContentLoading() {
	return /* @__PURE__ */ jsxs("div", {
		className: EditHistoryDialog_module_default.loadingSkeletonContainer,
		children: [/* @__PURE__ */ jsx(LoadingSkeleton, {
			variant: "rounded",
			height: "md",
			width: "100%"
		}), /* @__PURE__ */ jsx(LoadingSkeleton, {
			variant: "rounded",
			height: "md",
			width: "100%"
		})]
	});
}
EditContentLoading.displayName = "EditContentLoading";
function _temp$1(retry) {
	return jsx(CouldNotFindFallbackError, { retry });
}
var MarkdownEditHistoryViewer_module_default = {
	editHistoryContainer: "MarkdownEditHistoryViewer-module_ftIT2G_editHistoryContainer",
	editHistoryItemMetadata: "MarkdownEditHistoryViewer-module_ftIT2G_editHistoryItemMetadata",
	editHistoryMenuButton: "MarkdownEditHistoryViewer-module_ftIT2G_editHistoryMenuButton",
	editorAvatar: "MarkdownEditHistoryViewer-module_ftIT2G_editorAvatar",
	editorUsername: "MarkdownEditHistoryViewer-module_ftIT2G_editorUsername",
	loadingSkeletonContainer: "MarkdownEditHistoryViewer-module_ftIT2G_loadingSkeletonContainer",
	scrollableEditHistoryList: "MarkdownEditHistoryViewer-module_ftIT2G_scrollableEditHistoryList"
};
var MarkdownEditHistoryViewerGraphql = node$10;
function MarkdownEditHistoryViewer(t0) {
	const $ = c(5);
	const { editHistory } = t0;
	const data = (0, import_react_relay.useFragment)(node$9, editHistory);
	const [isEditHistoryDialogOpen, setIsEditHistoryDialogOpen] = useState(false);
	const [selectedId, setSelectedId] = useState("");
	if (!data || !data.viewerCanReadUserContentEdits || !data.lastEditedAt) return null;
	let t1;
	if ($[0] !== data.id || $[1] !== data.lastEditedAt || $[2] !== isEditHistoryDialogOpen || $[3] !== selectedId) {
		t1 = jsxs("div", {
			className: MarkdownEditHistoryViewer_module_default.editHistoryContainer,
			children: [jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
				variant: "invisible",
				size: "small",
				"aria-label": LABELS.editHistory.ariaLabel,
				className: MarkdownEditHistoryViewer_module_default.editHistoryMenuButton,
				children: LABELS.editHistory.openEditsButton
			}), jsx(ActionMenu.Overlay, {
				width: "auto",
				children: jsx(EditHistoryActionMenuContent, {
					setIsEditHistoryDialogOpen,
					setSelectedId,
					editHistoryId: data.id,
					lastEditedAt: data.lastEditedAt
				})
			})] }), isEditHistoryDialogOpen && jsx(EditHistoryDialog, {
				onClose: () => setIsEditHistoryDialogOpen(false),
				userContentEditId: selectedId
			})]
		});
		$[0] = data.id;
		$[1] = data.lastEditedAt;
		$[2] = isEditHistoryDialogOpen;
		$[3] = selectedId;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
MarkdownEditHistoryViewer.displayName = "MarkdownEditHistoryViewer";
var EditHistoryActionMenuContent = (t0) => {
	const $ = c(11);
	const { editHistoryId, lastEditedAt, ...props } = t0;
	const [queryRef, loadEditHistory] = (0, import_react_relay.useQueryLoader)(MarkdownEditHistoryViewerGraphql);
	let t1;
	if ($[0] !== editHistoryId || $[1] !== loadEditHistory) {
		t1 = () => {
			loadEditHistory({ id: editHistoryId }, { fetchPolicy: "network-only" });
		};
		$[0] = editHistoryId;
		$[1] = loadEditHistory;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== editHistoryId || $[4] !== lastEditedAt || $[5] !== loadEditHistory) {
		t2 = [
			editHistoryId,
			loadEditHistory,
			lastEditedAt
		];
		$[3] = editHistoryId;
		$[4] = lastEditedAt;
		$[5] = loadEditHistory;
		$[6] = t2;
	} else t2 = $[6];
	useEffect(t1, t2);
	if (!queryRef) {
		let t3;
		if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = jsx(EditHistoryLoading, {});
			$[7] = t3;
		} else t3 = $[7];
		return t3;
	}
	let t3;
	if ($[8] !== editHistoryId || $[9] !== loadEditHistory) {
		t3 = () => loadEditHistory({ id: editHistoryId }, { fetchPolicy: "network-only" });
		$[8] = editHistoryId;
		$[9] = loadEditHistory;
		$[10] = t3;
	} else t3 = $[10];
	return jsx(Suspense, {
		fallback: jsx(EditHistoryLoading, {}),
		children: jsx(PreloadedQueryBoundary, {
			onRetry: t3,
			fallback: _temp,
			children: jsx(EditHistoryActionMenuContentInternal, {
				queryRef,
				...props
			})
		})
	});
};
EditHistoryActionMenuContent.displayName = "EditHistoryActionMenuContent";
var EditHistoryActionMenuContentInternal = (t0) => {
	const $ = c(7);
	const { setIsEditHistoryDialogOpen, setSelectedId, queryRef } = t0;
	const data = (0, import_react_relay.usePreloadedQuery)(MarkdownEditHistoryViewerGraphql, queryRef);
	if (!data.node?.userContentEdits) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx(EditHistoryLoading, {});
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	}
	const totalCount = data.node.userContentEdits.totalCount;
	let t1;
	if ($[1] !== data.node.includesCreatedEdit || $[2] !== data.node.userContentEdits.edges || $[3] !== setIsEditHistoryDialogOpen || $[4] !== setSelectedId || $[5] !== totalCount) {
		t1 = jsx(ActionList, {
			className: MarkdownEditHistoryViewer_module_default.scrollableEditHistoryList,
			children: jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, { children: `Edited ${totalCount - 1} time${totalCount > 2 ? "s" : ""}` }), data.node.userContentEdits.edges?.map((edge, index) => {
				const edit = edge?.node;
				if (!edit?.editor) return null;
				const isCreation = data.node?.includesCreatedEdit && index === totalCount - 1;
				return jsxs(ActionList.Item, {
					onSelect: () => {
						setSelectedId(edit.id);
						setIsEditHistoryDialogOpen(true);
					},
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(GitHubAvatar, {
							src: edit.editor.avatarUrl,
							size: 16,
							alt: `@${edit.editor.login}`,
							className: MarkdownEditHistoryViewer_module_default.editorAvatar
						}) }),
						jsx("span", {
							className: MarkdownEditHistoryViewer_module_default.editorUsername,
							children: edit.editor.login
						}),
						jsxs(ActionList.Description, {
							truncate: true,
							className: MarkdownEditHistoryViewer_module_default.editHistoryItemMetadata,
							children: [isCreation && jsx("div", {
								title: "",
								children: LABELS.editHistory.created
							}), jsx(RelativeTime, { date: new Date(edit.editedAt) })]
						}),
						(index === 0 || edit.deletedAt) && jsx(ActionList.TrailingVisual, { children: jsx(Label, { children: index === 0 ? LABELS.editHistory.mostRecent : LABELS.editHistory.deleted }) })
					]
				}, edit.id);
			})] })
		});
		$[1] = data.node.includesCreatedEdit;
		$[2] = data.node.userContentEdits.edges;
		$[3] = setIsEditHistoryDialogOpen;
		$[4] = setSelectedId;
		$[5] = totalCount;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
};
EditHistoryActionMenuContentInternal.displayName = "EditHistoryActionMenuContentInternal";
function EditHistoryLoading() {
	return /* @__PURE__ */ jsxs("div", {
		className: MarkdownEditHistoryViewer_module_default.loadingSkeletonContainer,
		children: [
			/* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "md",
				width: "100%"
			}),
			/* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "md",
				width: "100%"
			}),
			/* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "md",
				width: "100%"
			}),
			/* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "md",
				width: "100%"
			})
		]
	});
}
EditHistoryLoading.displayName = "EditHistoryLoading";
function _temp(retry) {
	return jsx(CouldNotFindFallbackError, { retry });
}
var node$5 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "useMarkdownEditHistoryViewerQueryQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "MarkdownEditHistoryViewer_comment"
					}, {
						"args": null,
						"kind": "FragmentSpread",
						"name": "MarkdownLastEditedBy"
					}],
					"type": "Comment",
					"abstractKey": "__isComment"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "useMarkdownEditHistoryViewerQueryQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					v3,
					{
						"kind": "InlineFragment",
						"selections": [
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "viewerCanReadUserContentEdits",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "lastEditedAt",
								"storageKey": null
							},
							{
								"alias": null,
								"args": null,
								"concreteType": "UserContentEdit",
								"kind": "LinkedField",
								"name": "lastUserContentEdit",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "editor",
									"plural": false,
									"selections": [
										v2,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "url",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "login",
											"storageKey": null
										},
										v3
									],
									"storageKey": null
								}, v3],
								"storageKey": null
							}
						],
						"type": "Comment",
						"abstractKey": "__isComment"
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d72649dd9392589f64dd4570b992b900",
			"metadata": {},
			"name": "useMarkdownEditHistoryViewerQueryQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$5.hash = "4c6ffc38d14bcfbd11af3056fe1ca692";
function useMarkdownEditHistoryViewerQuery(t0) {
	const $ = c(2);
	const { id } = t0;
	let t1;
	if ($[0] !== id) {
		t1 = { id };
		$[0] = id;
		$[1] = t1;
	} else t1 = $[1];
	const data = (0, import_react_relay.useLazyLoadQuery)(node$5, t1);
	if (!data.node) return null;
	return data.node;
}
var ActivityHeader_module_default = {
	ActionsButtonsContainer: "ActivityHeader-module__jVGRq_ActionsButtonsContainer",
	ActionsContainer: "ActivityHeader-module__jVGRq_ActionsContainer",
	activityHeader: "ActivityHeader-module__jVGRq_activityHeader",
	ActivityHeaderContainer: "ActivityHeader-module__jVGRq_ActivityHeaderContainer",
	ActivityHeaderGridLayout: "ActivityHeader-module__jVGRq_ActivityHeaderGridLayout",
	AuthorLink: "ActivityHeader-module__jVGRq_AuthorLink",
	AuthorName: "ActivityHeader-module__jVGRq_AuthorName",
	AvatarContainer: "ActivityHeader-module__jVGRq_AvatarContainer",
	BadgesContainer: "ActivityHeader-module__jVGRq_BadgesContainer",
	BadgesGroupContainer: "ActivityHeader-module__jVGRq_BadgesGroupContainer",
	CommentHeaderBadge: "ActivityHeader-module__jVGRq_CommentHeaderBadge",
	CommentHeaderContentContainer: "ActivityHeader-module__jVGRq_CommentHeaderContentContainer",
	edits: "ActivityHeader-module__jVGRq_edits",
	EditsContainer: "ActivityHeader-module__jVGRq_EditsContainer",
	footer: "ActivityHeader-module__jVGRq_footer",
	FooterContainer: "ActivityHeader-module__jVGRq_FooterContainer",
	HeaderLink: "ActivityHeader-module__jVGRq_HeaderLink",
	HeaderMutedText: "ActivityHeader-module__jVGRq_HeaderMutedText",
	HeaderMutedTextNoEllipsis: "ActivityHeader-module__jVGRq_HeaderMutedTextNoEllipsis",
	narrowViewportWrapper: "ActivityHeader-module__jVGRq_narrowViewportWrapper",
	TitleContainer: "ActivityHeader-module__jVGRq_TitleContainer"
};
var Avatar_module_default = {
	activityAvatar: "Avatar-module__mII_W_activityAvatar",
	avatarInner: "Avatar-module__mII_W_avatarInner",
	avatarLink: "Avatar-module__mII_W_avatarLink",
	avatarOuter: "Avatar-module__mII_W_avatarOuter",
	avatarWithDivider: "Avatar-module__mII_W_avatarWithDivider",
	avatarWithoutDivider: "Avatar-module__mII_W_avatarWithoutDivider",
	avatarWithoutLink: "Avatar-module__mII_W_avatarWithoutLink",
	hiddenActivityAvatar: "Avatar-module__mII_W_hiddenActivityAvatar",
	issueViewerAvatar: "Avatar-module__mII_W_issueViewerAvatar"
};
/**
* A hook that returns a set of props for controlling a portal tooltip from a parent element, as well as the
* portalled element
*
* This provides a simple, base case usage, without having to configure much directly, automatically generating an id and using
* that for aria-describedby when not given an id to use instead.
*/
function usePortalTooltip({ includeAriaAttributes = true, ...props }) {
	const id = useId();
	const [open, setOpen] = useState(false);
	const isOpen = props.open ?? open;
	const actualId = props.id ?? id;
	const ariaAttributes = includeAriaAttributes ? { "aria-describedby": actualId } : {};
	const onSetOpen = useCallback(() => setOpen(true), []);
	const onSetClose = useCallback(() => setOpen(false), []);
	return [
		{
			...ariaAttributes,
			onPointerEnter: onSetOpen,
			onPointerLeave: onSetClose,
			onFocus: onSetOpen,
			onBlur: onSetClose
		},
		/* @__PURE__ */ jsx(PortalTooltip, {
			...props,
			open: isOpen,
			id: actualId
		}, "portal-tooltip"),
		() => setOpen(!open)
	];
}
var CommentHeaderBadge = ({ label, ariaLabel, testId, viewerDidAuthor, variant, leadingElement, className, tooltipDirection }) => {
	const contentRef = React.useRef(null);
	const [buttonContentProps, buttonTooltipElement] = usePortalTooltip({
		contentRef,
		"aria-label": ariaLabel,
		...tooltipDirection && { direction: tooltipDirection }
	});
	return /* @__PURE__ */ jsxs(Label$1, {
		variant: variant || "secondary",
		"data-testid": testId,
		"aria-label": ariaLabel,
		className,
		ref: contentRef,
		sx: viewerDidAuthor ? { borderColor: "accent.muted" } : {},
		...buttonContentProps,
		children: [
			leadingElement,
			label,
			buttonTooltipElement
		]
	});
};
CommentHeaderBadge.displayName = "CommentHeaderBadge";
var MAP_ASSOCIATION = {
	MEMBER: "Member",
	OWNER: "Owner",
	MANNEQUIN: "Mannequin",
	COLLABORATOR: "Collaborator",
	CONTRIBUTOR: "Contributor",
	FIRST_TIME_CONTRIBUTOR: "First-time contributor",
	FIRST_TIMER: "First-time GitHub contributor",
	NONE: ""
};
var MAP_ASSOCIATION_LABELS = {
	MEMBER: ({ viewerDidAuthor, org }) => `${viewerDidAuthor ? "You are" : "This user is"} a member of the ${org} organization.`,
	OWNER: ({ viewerDidAuthor, repo }) => `${viewerDidAuthor ? "You are" : "This user is"} the owner of the ${repo} repository.`,
	MANNEQUIN: () => `This is a mannequin user.`,
	COLLABORATOR: ({ viewerDidAuthor, repo }) => `${viewerDidAuthor ? "You have" : "This user has"} been invited to collaborate on the ${repo} repository.`,
	CONTRIBUTOR: ({ viewerDidAuthor, repo }) => `${viewerDidAuthor ? "You have" : "This user has"} previously committed to the ${repo} repository.`,
	FIRST_TIME_CONTRIBUTOR: ({ viewerDidAuthor, repo }) => `${viewerDidAuthor ? "You are" : "This user is"} a first-time contributor to the ${repo} repository.`,
	FIRST_TIMER: ({ viewerDidAuthor }) => `${viewerDidAuthor ? "This is your" : "This user's"} first pull request on GitHub.`,
	NONE: () => ""
};
var CommentAuthorAssociation = ({ association, org, repo, viewerDidAuthor, tooltipDirection }) => {
	const associationForLabel = MAP_ASSOCIATION[association] ? association : "NONE";
	if (associationForLabel === "NONE") return null;
	const ariaLabel = MAP_ASSOCIATION_LABELS[associationForLabel]({
		viewerDidAuthor: viewerDidAuthor ?? false,
		org,
		repo
	});
	return /* @__PURE__ */ jsx(CommentHeaderBadge, {
		label: MAP_ASSOCIATION[associationForLabel],
		ariaLabel,
		testId: TEST_IDS.commentAuthorAssociation,
		viewerDidAuthor,
		tooltipDirection
	});
};
CommentAuthorAssociation.displayName = "CommentAuthorAssociation";
var CommentSubjectAuthor = ({ viewerDidAuthor, subjectType, tooltipDirection }) => {
	return /* @__PURE__ */ jsx(CommentHeaderBadge, {
		viewerDidAuthor,
		ariaLabel: LABELS$1.commentSubjectAuthor(viewerDidAuthor ?? false, subjectType ?? "comment"),
		label: LABELS$1.commentAuthor,
		testId: TEST_IDS.commentSubjectAuthor,
		tooltipDirection
	});
};
CommentSubjectAuthor.displayName = "CommentSubjectAuthor";
var PinnedByBadge_module_default = {
	PinnedByContainer: "PinnedByBadge-module_CUdP7q_PinnedByContainer",
	PinnedByIcon: "PinnedByBadge-module_CUdP7q_PinnedByIcon",
	PinnedByLink: "PinnedByBadge-module_CUdP7q_PinnedByLink"
};
function PinnedByBadge(t0) {
	const $ = c(3);
	const { pinnedByLogin } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	if ($[0] !== getHovercardAttributesForType || $[1] !== pinnedByLogin) {
		t1 = jsxs("span", {
			className: PinnedByBadge_module_default.PinnedByContainer,
			children: [
				" ",
				"·",
				jsx(PinIcon, {
					size: 12,
					className: PinnedByBadge_module_default.PinnedByIcon
				}),
				" Pinned by",
				" ",
				jsx(Link, {
					href: `/${pinnedByLogin}`,
					...getHovercardAttributesForType("user", { login: pinnedByLogin }),
					className: PinnedByBadge_module_default.PinnedByLink,
					children: jsx(ProfileReference, {
						login: pinnedByLogin,
						isAgent: false
					})
				})
			]
		});
		$[0] = getHovercardAttributesForType;
		$[1] = pinnedByLogin;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
PinnedByBadge.displayName = "PinnedByBadge";
var SpammyBadge = () => {
	return /* @__PURE__ */ jsx(CommentHeaderBadge, {
		variant: "danger",
		ariaLabel: LABELS$1.spammyBadgeTooltip,
		label: LABELS$1.spammyBadge,
		testId: TEST_IDS.spammyLabel
	});
};
SpammyBadge.displayName = "SpammyBadge";
var SponsorsBadge = ({ createdAt, owner, viewerDidAuthor }) => {
	const sponsorDate = new Date(createdAt);
	const sponsorMmonth = sponsorDate.toLocaleString("default", { month: "long" });
	const label = LABELS$1.sponsor(owner, `${sponsorMmonth} ${sponsorDate.getFullYear()}`);
	return /* @__PURE__ */ jsx(CommentHeaderBadge, {
		label: LABELS$1.sponsorBadge,
		ariaLabel: label,
		testId: TEST_IDS.sponsorLabel,
		viewerDidAuthor
	});
};
SponsorsBadge.displayName = "SponsorsBadge";
var CommentAuthorTypes = {
	Bot: "Bot",
	Mannequin: "Mannequin",
	User: "User"
};
function getOutdatedCommentUrl(originalDiffPathUri) {
	if (!originalDiffPathUri) return void 0;
	const url = new URL(originalDiffPathUri, window.location.origin);
	url.searchParams.set("new_files_changed", "true");
	return url.toString();
}
/**
* Abstraction of a comment header that can be used in different contexts.
*/
function ActivityHeader(t0) {
	const { actions, badges, comment, commentAuthorType, commentAuthorSlug, commentAuthorLogin, commentAuthorProfileName, isMinimized: t1, avatarUrl, lastEditedByMessage, editHistoryComponent, additionalHeaderMessage, sx, viewerDidAuthor: t2, userAvatar, commentSubjectAuthorLogin, commentSubjectType, isReply: t3, headingProps: t4, id, forceInlineAvatar, containerStyle, originalDiffPathUri, isOutdated, hideProfileLink: t5, pinnedByLogin, tooltipDirection } = t0;
	const isMinimized = t1 === void 0 ? false : t1;
	const viewerDidAuthor = t2 === void 0 ? false : t2;
	const isReply = t3 === void 0 ? false : t3;
	const { as: HeadingElement, ...headingProps } = t4 === void 0 ? { as: "h3" } : t4;
	const hideProfileLink = t5 === void 0 ? false : t5;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const containerStyles = containerStyle || isReply ? {} : {
		backgroundColor: viewerDidAuthor ? "accent.subtle" : "canvas.subtle",
		borderTopLeftRadius: "6px",
		borderTopRightRadius: "6px",
		borderBottom: "1px solid",
		borderColor: viewerDidAuthor ? "accent.muted" : "border.default",
		borderBottomWidth: isMinimized ? 0 : 1,
		py: forceInlineAvatar ? [
			1,
			1,
			2,
			2
		] : 1,
		pr: 1,
		pl: 3,
		...sx
	};
	const commentMinimizedReason = comment.pendingMinimizeReason ?? comment.minimizedReason;
	const commentHidden = !!commentMinimizedReason || comment.isHidden;
	const createdAt = new Date(comment.createdAt);
	const isBot = commentAuthorType === CommentAuthorTypes.Bot;
	const isMannequin = commentAuthorType === CommentAuthorTypes.Mannequin;
	const isCopilot = isBot && (commentAuthorLogin === "Copilot" && !!commentAuthorSlug || commentAuthorLogin === "copilot-swe-agent");
	const profileUrl = isMannequin || hideProfileLink ? void 0 : `/${isBot ? "apps/" : ""}${commentAuthorSlug ?? commentAuthorLogin}`;
	const profileLogin = isCopilot ? "Copilot" : commentAuthorLogin;
	let hovercardAttributes = {};
	if (isCopilot) hovercardAttributes = getHovercardAttributesForType("copilot", { botSlug: commentAuthorSlug ?? commentAuthorLogin });
	else if (!isMannequin) hovercardAttributes = getHovercardAttributesForType("user", { login: commentAuthorLogin });
	const showPinnedByBadge = pinnedByLogin && !commentHidden;
	const subText = jsxs(Fragment$1, { children: [
		additionalHeaderMessage && jsx("span", {
			className: ActivityHeader_module_default.HeaderMutedText,
			children: additionalHeaderMessage
		}),
		jsxs("span", {
			className: ActivityHeader_module_default.HeaderMutedText,
			children: [
				jsx(Link, {
					href: isOutdated ? getOutdatedCommentUrl(originalDiffPathUri) : comment.url,
					"data-turbo": isOutdated ? "false" : "true",
					className: ActivityHeader_module_default.HeaderLink,
					children: jsxs(RelativeTime, {
						date: createdAt,
						children: ["on ", createdAt.toLocaleDateString("en-US", {
							month: "short",
							day: "numeric",
							year: "numeric"
						})]
					})
				}),
				comment.createdViaEmail && jsx("span", { children: ` ${LABELS$1.sentViaEmail}` }),
				comment.viaApp && jsxs("span", { children: [
					" ",
					"– with",
					" ",
					jsx(Link, {
						inline: true,
						href: comment.viaApp.url,
						children: comment.viaApp.name
					})
				] })
			]
		}),
		commentHidden && jsxs("span", {
			className: ActivityHeader_module_default.HeaderMutedTextNoEllipsis,
			children: [
				" ",
				"·",
				" ",
				commentMinimizedReason ? jsxs("span", { children: [
					LABELS$1.hiddenCommentWithReason,
					" ",
					commentMinimizedReason.replace(/_/g, "-").toLowerCase()
				] }) : jsx("span", { children: LABELS$1.hiddenComment })
			]
		}),
		lastEditedByMessage && !commentHidden && jsx(Suspense, { children: lastEditedByMessage }),
		showPinnedByBadge && jsx(PinnedByBadge, { pinnedByLogin })
	] });
	return jsx(Box, {
		id,
		sx: { ...containerStyles },
		"data-testid": TEST_IDS.commentHeader,
		className: ActivityHeader_module_default.ActivityHeaderContainer,
		children: jsxs(Box, {
			className: clsx(ActivityHeader_module_default.activityHeader, ActivityHeader_module_default.ActivityHeaderGridLayout),
			sx: { paddingBottom: !lastEditedByMessage && !forceInlineAvatar ? "var(--base-size-6, 6px)" : 0 },
			children: [
				jsx(HeadingElement, {
					...headingProps,
					className: "sr-only",
					children: jsxs(Fragment$1, { children: [
						isCopilot ? "Copilot" : commentAuthorLogin,
						" ",
						isReply ? "replied" : "commented",
						" ",
						jsxs(RelativeTime, {
							date: createdAt,
							children: [
								"on ",
								createdAt.toLocaleDateString("en-US", {
									month: "short",
									day: "numeric",
									year: "numeric"
								}),
								" "
							]
						})
					] })
				}),
				jsx(Box, {
					className: clsx(forceInlineAvatar ? "" : Avatar_module_default.avatarInner, ActivityHeader_module_default.AvatarContainer),
					sx: { display: forceInlineAvatar ? "flex" : [
						"flex",
						"flex",
						"none",
						"none"
					] },
					children: userAvatar ?? jsx(DefaultAvatar, {
						avatarUrl,
						login: commentAuthorLogin,
						isCopilot,
						isHidden: commentHidden,
						hovercardAttributes,
						profileUrl
					})
				}),
				jsxs("div", {
					className: clsx(ActivityHeader_module_default.narrowViewportWrapper, ActivityHeader_module_default.CommentHeaderContentContainer),
					"data-testid": TEST_IDS.commentHeaderLeftSideItems,
					children: [jsxs("div", {
						className: ActivityHeader_module_default.TitleContainer,
						children: [profileUrl ? jsx(Link, {
							href: profileUrl,
							"data-testid": TEST_IDS.avatarLink,
							...hovercardAttributes,
							className: clsx(ActivityHeader_module_default.AuthorName, ActivityHeader_module_default.AuthorLink, commentHidden ? "color-fg-muted" : "color-fg-default"),
							children: jsx(ProfileReference, {
								login: profileLogin,
								profileName: commentAuthorProfileName,
								isAgent: isCopilot
							})
						}) : jsx("span", {
							"data-testid": TEST_IDS.avatarName,
							...hovercardAttributes,
							className: clsx(ActivityHeader_module_default.AuthorName, commentHidden ? "color-fg-muted" : "color-fg-default"),
							children: jsx(ProfileReference, {
								login: profileLogin,
								profileName: commentAuthorProfileName,
								isAgent: isCopilot
							})
						}), (isBot || isMannequin) && jsx(Label, {
							variant: "secondary",
							className: "ml-1",
							children: LABELS$1.authorLabel(isBot, isCopilot)
						})]
					}), jsx("div", {
						className: clsx(ActivityHeader_module_default.footer, ActivityHeader_module_default.FooterContainer),
						children: subText
					})]
				}),
				jsxs("div", {
					"data-testid": TEST_IDS.commentHeaderRightSideItems,
					className: clsx(ActivityHeader_module_default.narrowViewportWrapper, ActivityHeader_module_default.ActionsContainer),
					children: [editHistoryComponent && jsx("div", {
						className: ActivityHeader_module_default.EditsContainer,
						children: editHistoryComponent
					}), jsxs("div", {
						className: ActivityHeader_module_default.BadgesContainer,
						children: [jsxs("div", {
							className: ActivityHeader_module_default.BadgesGroupContainer,
							children: [
								comment.state?.toUpperCase() === "PENDING" && jsx(CommentHeaderBadge, {
									leadingElement: jsx(DotFillIcon, {}),
									label: "Pending",
									ariaLabel: "This review comment is pending",
									testId: "pending-badge",
									variant: "attention",
									className: ActivityHeader_module_default.CommentHeaderBadge
								}),
								!commentHidden && !isMinimized && comment.authorToRepoOwnerSponsorship && comment.authorToRepoOwnerSponsorship.isActive && jsx(SponsorsBadge, {
									createdAt: comment.authorToRepoOwnerSponsorship.createdAt,
									owner: comment.repository.owner.login,
									viewerDidAuthor
								}),
								!commentHidden && !isMinimized && comment.showSpammyBadge && jsx(SpammyBadge, {}),
								!comment.repository.isPrivate && !commentHidden && !isMinimized && jsx(CommentAuthorAssociation, {
									association: comment.authorAssociation,
									viewerDidAuthor,
									org: comment.repository.owner.login,
									repo: comment.repository.name,
									tooltipDirection
								}),
								commentAuthorLogin === commentSubjectAuthorLogin && jsx(CommentSubjectAuthor, {
									viewerDidAuthor,
									subjectType: commentSubjectType,
									tooltipDirection
								}),
								badges
							]
						}), jsx("div", {
							className: ActivityHeader_module_default.ActionsButtonsContainer,
							children: actions
						})]
					})]
				})
			]
		})
	});
}
ActivityHeader.displayName = "ActivityHeader";
function DefaultAvatar({ avatarUrl, login, isHidden, isCopilot, hovercardAttributes, profileUrl }) {
	const avatarElement = /* @__PURE__ */ jsx(GitHubAvatar, {
		src: avatarUrl,
		alt: isCopilot ? "Copilot" : `@${login}`,
		size: 24,
		square: isCopilot,
		className: isHidden ? Avatar_module_default.hiddenActivityAvatar : Avatar_module_default.activityAvatar
	});
	if (profileUrl) return /* @__PURE__ */ jsx(Link, {
		href: profileUrl,
		className: Avatar_module_default.avatarLink,
		...hovercardAttributes,
		"aria-label": isCopilot ? "Copilot" : `@${login}'s profile`,
		children: avatarElement
	});
	return /* @__PURE__ */ jsx("div", {
		className: Avatar_module_default.avatarWithoutLink,
		...hovercardAttributes,
		children: avatarElement
	});
}
DefaultAvatar.displayName = "DefaultAvatar";
/**
*
* @param date - The date to format
* @description - Formats a date into a more readable string. Meant to be used as a unique identifier in places such as
* comments. Inspired by the equivalent aria_label_date available in our Ruby files.
*
* There is a known caveat with this approach:
* - If the user keeps a tab open for a long time, the text will become outdated.
* - The format is different from our relative-time element (which uses relative minute unites and auto-updates as time passes).
* These caveats are acceptable trade-offs for the use case of this function (serving as a unique identifier in comments).
* See: https://www.loom.com/share/0bfa364077aa447d9eb199b12e51672e?sid=c9b0e7fd-6007-4fa0-89cb-bb733a895d9b
* @returns - A string that describes the date and time, in increasing verbosity.
*/
function ariaLabelDate(date) {
	if (!isValid(date)) return "";
	const timeString = format(date, "h:mm a");
	if (isToday(date)) return `${timeString} today`;
	else if (isYesterday(date)) return `${timeString} yesterday`;
	else if (isThisYear(date)) return `${timeString} on ${format(date, "MMMM d")}`;
	else return `${timeString} on ${format(date, "MMMM d, yyyy")}`;
}
/**
* Builds the prompt for updating an issue based on comment feedback.
*/
function buildCopilotUpdateIssuePrompt({ ownerLogin, repoName, issueNumber, commentBody }) {
	return `Using the following feedback, update the issue body in @${ownerLogin}/${repoName}/issues/${issueNumber} and also make sure to include a diff of your changes in your response.

<feedback>
${commentBody}
</feedback>`;
}
var UPDATE_ISSUE_FROM_COMMENT_BUTTON_ID = "copilot-update-issue-from-comment-button";
/**
* Hook to handle updating an issue body using GitHub Copilot.
* Extracts the issue number from the comment URL, sends analytics, and opens Copilot chat.
*/
function useUpdateIssueFromCommentWithCopilot() {
	const $ = c(4);
	const { sendAnalyticsEvent } = useAnalytics();
	let t0;
	if ($[0] !== sendAnalyticsEvent) {
		t0 = (comment) => {
			const issueNumberMatch = comment.url.match(/\/issues\/(\d+)/);
			const issueNumber = issueNumberMatch ? issueNumberMatch[1] : "";
			if (!issueNumber) return;
			sendAnalyticsEvent("analytics.click", "COPILOT_COMMENT_UPDATE_ISSUE_BUTTON", {
				commentId: comment.id,
				issueNumber,
				repoNWO: `${comment.repository.owner.login}/${comment.repository.name}`
			});
			const prompt = buildCopilotUpdateIssuePrompt({
				ownerLogin: comment.repository.owner.login,
				repoName: comment.repository.name,
				issueNumber,
				commentBody: comment.body
			});
			const issueUrlReference = {
				type: "github-url",
				url: comment.url.split("#")[0] ?? ""
			};
			publishOpenCopilotChat({
				intent: CopilotChatIntents.conversation,
				content: prompt,
				references: [issueUrlReference],
				id: UPDATE_ISSUE_FROM_COMMENT_BUTTON_ID
			});
		};
		$[0] = sendAnalyticsEvent;
		$[1] = t0;
	} else t0 = $[1];
	const updateIssueWithCopilot = t0;
	let t1;
	if ($[2] !== updateIssueWithCopilot) {
		t1 = { updateIssueWithCopilot };
		$[2] = updateIssueWithCopilot;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
function canBlock(params) {
	const { viewerCanBlockFromOrg, pendingBlock, hasAuthor, pendingUnblock, isAuthorCopilot } = params;
	if (!hasAuthor) return false;
	if (isAuthorCopilot) return false;
	if (pendingBlock) return false;
	if (pendingUnblock) return true;
	return viewerCanBlockFromOrg;
}
function canUnblock(params) {
	const { viewerCanUnblockFromOrg, pendingBlock, hasAuthor, pendingUnblock } = params;
	if (!hasAuthor) return false;
	if (pendingUnblock) return false;
	if (pendingBlock) return true;
	return viewerCanUnblockFromOrg;
}
var CommentActions_module_default = {
	CommentActionsIconButton: "CommentActions-module_jAUtjq_CommentActionsIconButton",
	CommentActionsListItem: "CommentActions-module_jAUtjq_CommentActionsListItem"
};
var node$4 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "BlockUserFromOrganizationPayload",
		"kind": "LinkedField",
		"name": "blockUserFromOrganization",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "blockUserFromOrganizationMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "blockUserFromOrganizationMutation",
			"selections": v1
		},
		"params": {
			"id": "cc2dfdd4807633d71341d55e85bdcec5",
			"metadata": {},
			"name": "blockUserFromOrganizationMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$4.hash = "1cc6b979024f82ac249a77676892c1f0";
function blockUserFromOrganization({ environment, input: { organizationId, blockedUserId, duration, notifyBlockedUser, hiddenReason, contentId }, onError, onCompleted }) {
	let inputHash = {
		organizationId,
		blockedUserId,
		duration,
		notifyBlockedUser,
		contentId
	};
	if (hiddenReason) inputHash = {
		...inputHash,
		hiddenReason
	};
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$4,
		variables: { input: inputHash },
		onError: (error) => onError && onError(error),
		onCompleted: () => {
			onCompleted?.();
		}
	});
}
var BlockUserFromOrgDialog_module_default = {
	BlockUserContainer: "BlockUserFromOrgDialog-module_R44zvG_BlockUserContainer",
	BlockUserDialog: "BlockUserFromOrgDialog-module_R44zvG_BlockUserDialog",
	BlockUserDivider: "BlockUserFromOrgDialog-module_R44zvG_BlockUserDivider",
	BlockUserFormControl: "BlockUserFromOrgDialog-module_R44zvG_BlockUserFormControl",
	BlockUserFormRow: "BlockUserFromOrgDialog-module_R44zvG_BlockUserFormRow",
	BlockUserHelpText: "BlockUserFromOrgDialog-module_R44zvG_BlockUserHelpText",
	BlockUserIndentedContainer: "BlockUserFromOrgDialog-module_R44zvG_BlockUserIndentedContainer",
	BlockUserLeftPadding: "BlockUserFromOrgDialog-module_R44zvG_BlockUserLeftPadding",
	Button: "BlockUserFromOrgDialog-module_R44zvG_Button"
};
var HIDE_OPTION_TO_READABLE_MAP = {
	SPAM: "Spam",
	ABUSE: "Abuse",
	OFF_TOPIC: "Off-topic",
	OUTDATED: "Outdated",
	DUPLICATE: "Duplicate",
	RESOLVED: "Resolved"
};
var HideCommentActionItems = ({ setMenuOpen, onSelect }) => {
	return /* @__PURE__ */ jsx(Fragment$1, { children: Object.keys(HIDE_OPTION_TO_READABLE_MAP).map((option) => /* @__PURE__ */ jsx(ActionList.Item, {
		"aria-label": `Hide comment as ${HIDE_OPTION_TO_READABLE_MAP[option]}`,
		onSelect: () => {
			onSelect(option);
			setMenuOpen?.(false);
		},
		children: HIDE_OPTION_TO_READABLE_MAP[option]
	}, option)) });
};
HideCommentActionItems.displayName = "HideCommentActionItems";
var import_relay_runtime = require_relay_runtime();
var BLOCKING_DURATION_TO_READABLE_MAP = {
	ONE_DAY: "For 1 day",
	THREE_DAYS: "For 3 days",
	SEVEN_DAYS: "For 7 days",
	THIRTY_DAYS: "For 30 days",
	INDEFINITE: "Until I unblock them"
};
var BLOCKING_DURATION_TO_DAYS_MAP = {
	ONE_DAY: "1",
	THREE_DAYS: "3",
	SEVEN_DAYS: "7",
	THIRTY_DAYS: "30",
	INDEFINITE: "0"
};
var INITIAL_SELECTED_BLOCKING_DURATION = "INDEFINITE";
var BlockUserFromOrgDialog = (t0) => {
	const $ = c(4);
	const { onBlock, onClose, ...props } = t0;
	const [selectedBlockingDuration, setSelectedBlockingDuration] = useState(INITIAL_SELECTED_BLOCKING_DURATION);
	const [notifyBlockedUser, setNotifyBlockedUser] = useState(true);
	const [hideComment, setHideComment] = useState(false);
	const [commentHideOption, setCommentHideOption] = useState(void 0);
	const userToBlock = props.contentAuthor.login;
	let t1;
	if ($[0] !== notifyBlockedUser) {
		t1 = () => setNotifyBlockedUser(!notifyBlockedUser);
		$[0] = notifyBlockedUser;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== hideComment) {
		t2 = () => setHideComment(!hideComment);
		$[2] = hideComment;
		$[3] = t2;
	} else t2 = $[3];
	return jsx(Portal, { children: jsx(Dialog, {
		title: `Block ${props.contentAuthor.login} from ${props.organization.login}`,
		renderFooter: () => onBlock ? jsx(BlockUserFromOrgDialogFooterWithoutRelay, {
			onBlock,
			onClose,
			...props,
			notifyBlockedUser,
			hideComment,
			duration: selectedBlockingDuration,
			hiddenReason: commentHideOption
		}) : jsx(BlockUserFromOrgDialogFooterWithRelay, {
			onClose,
			...props,
			notifyBlockedUser,
			hideComment,
			duration: selectedBlockingDuration,
			hiddenReason: commentHideOption
		}),
		width: "xlarge",
		height: "auto",
		onClose,
		className: BlockUserFromOrgDialog_module_default.BlockUserDialog,
		children: jsxs("div", {
			className: BlockUserFromOrgDialog_module_default.BlockUserContainer,
			children: [
				jsx("div", {
					className: BlockUserFromOrgDialog_module_default.BlockUserFormRow,
					children: jsx("div", { children: jsxs("span", { children: [
						"Blocking a user prevents them from interacting with repositories of this organization, such as opening or commenting on pull requests or issues. Learn more about",
						" ",
						jsx("a", {
							href: "https://docs.github.com/communities/maintaining-your-safety-on-github/blocking-a-user-from-your-organization",
							children: "blocking a user."
						})
					] }) })
				}),
				jsx("div", {
					className: BlockUserFromOrgDialog_module_default.BlockUserFormRow,
					children: jsxs(ActionMenu, { children: [jsxs(ActionMenu.Button, { children: ["Block a user: ", BLOCKING_DURATION_TO_READABLE_MAP[selectedBlockingDuration]] }), jsx(ActionMenu.Overlay, { children: jsx(ActionList, {
						selectionVariant: "single",
						children: jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, { children: "Block options" }), Object.keys(BLOCKING_DURATION_TO_READABLE_MAP).map((option) => jsx(ActionList.Item, {
							onSelect: () => {
								setSelectedBlockingDuration(option);
							},
							selected: option === selectedBlockingDuration,
							children: BLOCKING_DURATION_TO_READABLE_MAP[option]
						}, option))] })
					}) })] })
				}),
				jsx(DialogDivider, {}),
				jsx("h4", { children: "More options" }),
				jsxs(FormControl$1, {
					className: BlockUserFromOrgDialog_module_default.BlockUserFormControl,
					children: [
						jsx(Checkbox, {
							checked: notifyBlockedUser,
							onChange: t1,
							"aria-checked": notifyBlockedUser
						}),
						jsx(FormControl$1.Label, { children: "Send user a notification and show activity in timeline" }),
						jsx(FormControl$1.Caption, { children: jsxs("span", {
							className: BlockUserFromOrgDialog_module_default.BlockUserHelpText,
							children: [
								"You can notify ",
								jsx("b", { children: userToBlock }),
								" as to why they're being blocked. A public timeline entry will show that this user was blocked. They will receive an email notification and a notice when they try to comment with the following message:",
								jsx("div", {
									className: BlockUserFromOrgDialog_module_default.BlockUserIndentedContainer,
									children: jsxs("blockquote", { children: [
										"A maintainer of the @",
										props.organization.login,
										" organization has blocked you because of",
										" ",
										jsx("a", {
											href: props.contentUrl,
											children: "this content"
										}),
										". For more information please see",
										" ",
										jsx("a", {
											href: "https://docs.github.com/site-policy/github-terms/github-community-guidelines",
											children: "the community guidelines"
										}),
										"."
									] })
								})
							]
						}) })
					]
				}),
				jsxs(FormControl$1, { children: [
					jsx(Checkbox, {
						checked: hideComment,
						onChange: t2,
						"aria-checked": hideComment
					}),
					jsx(FormControl$1.Label, { children: "Hide this user's comments" }),
					jsx(FormControl$1.Caption, { children: jsxs("span", {
						className: BlockUserFromOrgDialog_module_default.BlockUserHelpText,
						children: [
							"All of their comments in this organization",
							" ",
							jsx("a", {
								href: "https://docs.github.com/communities/moderating-comments-and-conversations/managing-disruptive-comments#hiding-a-comment",
								children: "will be hidden"
							}),
							" ",
							"to all users and will display a reason."
						]
					}) })
				] }),
				jsx("div", {
					className: BlockUserFromOrgDialog_module_default.BlockUserLeftPadding,
					children: jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, { children: (commentHideOption && HIDE_OPTION_TO_READABLE_MAP[commentHideOption]) ?? "Choose a reason" }), jsx(ActionMenu.Overlay, { children: jsx(ActionList, {
						selectionVariant: "single",
						children: jsx(HideCommentActionItems, { onSelect: setCommentHideOption })
					}) })] })
				})
			]
		})
	}) });
};
BlockUserFromOrgDialog.displayName = "BlockUserFromOrgDialog";
var DialogDivider = () => {
	return /* @__PURE__ */ jsx("div", { className: BlockUserFromOrgDialog_module_default.BlockUserDivider });
};
DialogDivider.displayName = "DialogDivider";
var BlockUserFromOrgDialogFooterWithRelay = (t0) => {
	const $ = c(14);
	const { organization, contentAuthor, contentId, notifyBlockedUser, hideComment, duration, hiddenReason, onClose } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t1;
	if ($[0] !== contentAuthor.id || $[1] !== contentId || $[2] !== duration || $[3] !== environment || $[4] !== hiddenReason || $[5] !== hideComment || $[6] !== notifyBlockedUser || $[7] !== onClose || $[8] !== organization.id) {
		t1 = () => {
			blockUserFromOrganization({
				environment,
				input: {
					organizationId: organization.id,
					contentId,
					blockedUserId: contentAuthor.id,
					duration,
					hiddenReason: hideComment && hiddenReason ? hiddenReason : void 0,
					notifyBlockedUser
				},
				onError: noop,
				onCompleted: () => (0, import_relay_runtime.commitLocalUpdate)(environment, (store) => {
					const contentObject = store.get(contentId);
					contentObject?.setValue(false, "pendingUnblock");
					contentObject?.setValue(true, "pendingBlock");
					if (hiddenReason) contentObject?.setValue(hiddenReason, "pendingMinimizeReason");
				})
			});
			onClose();
		};
		$[0] = contentAuthor.id;
		$[1] = contentId;
		$[2] = duration;
		$[3] = environment;
		$[4] = hiddenReason;
		$[5] = hideComment;
		$[6] = notifyBlockedUser;
		$[7] = onClose;
		$[8] = organization.id;
		$[9] = t1;
	} else t1 = $[9];
	const onSubmit = t1;
	let t2;
	if ($[10] !== hiddenReason || $[11] !== hideComment || $[12] !== onSubmit) {
		t2 = jsx(BlockUserFromOrgDialogFooterComponent, {
			hideComment,
			hiddenReason,
			onSubmit
		});
		$[10] = hiddenReason;
		$[11] = hideComment;
		$[12] = onSubmit;
		$[13] = t2;
	} else t2 = $[13];
	return t2;
};
BlockUserFromOrgDialogFooterWithRelay.displayName = "BlockUserFromOrgDialogFooterWithRelay";
var BlockUserFromOrgDialogFooterWithoutRelay = ({ contentAuthor, duration, hideComment, hiddenReason, onBlock, onClose, organization, notifyBlockedUser }) => {
	const onSubmit = () => {
		onBlock?.(BLOCKING_DURATION_TO_DAYS_MAP[duration] ?? "0", hideComment, hiddenReason, organization.login, notifyBlockedUser, contentAuthor.login);
		onClose();
	};
	return /* @__PURE__ */ jsx(BlockUserFromOrgDialogFooterComponent, {
		hideComment,
		hiddenReason,
		onSubmit
	});
};
BlockUserFromOrgDialogFooterWithoutRelay.displayName = "BlockUserFromOrgDialogFooterWithoutRelay";
var BlockUserFromOrgDialogFooterComponent = ({ hideComment, hiddenReason, onSubmit }) => {
	return /* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsx(ButtonComponent, {
		variant: "danger",
		disabled: hideComment && !hiddenReason,
		onClick: onSubmit,
		className: BlockUserFromOrgDialog_module_default.Button,
		children: "Block user from organization"
	}) });
};
BlockUserFromOrgDialogFooterComponent.displayName = "BlockUserFromOrgDialogFooterComponent";
var node$3 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "SubmitAbuseReportPayload",
		"kind": "LinkedField",
		"name": "submitAbuseReport",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "submitAbuseReportMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "submitAbuseReportMutation",
			"selections": v1
		},
		"params": {
			"id": "0603fe0f6dabc68adea31e484c57deb7",
			"metadata": {},
			"name": "submitAbuseReportMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$3.hash = "8b252221b8eab001809aa2a2d583cb84";
function submitAbuseReportMutation({ environment, input: { reportedContentId, reason }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$3,
		variables: { input: {
			reportedContent: reportedContentId,
			reason
		} },
		onError: (error) => onError && onError(error),
		onCompleted: () => onCompleted && onCompleted()
	});
}
var ReportContentDialog_module_default = {
	ReportContentContainer: "ReportContentDialog-module_UsEZ6q_ReportContentContainer",
	ReportContentDialog: "ReportContentDialog-module_UsEZ6q_ReportContentDialog",
	ReportContentFooterSpacing: "ReportContentDialog-module_UsEZ6q_ReportContentFooterSpacing",
	ReportContentHelpText: "ReportContentDialog-module_UsEZ6q_ReportContentHelpText",
	ReportContentRadioContainer: "ReportContentDialog-module_UsEZ6q_ReportContentRadioContainer",
	ReportContentRadioLabel: "ReportContentDialog-module_UsEZ6q_ReportContentRadioLabel",
	ReportContentSpacing: "ReportContentDialog-module_UsEZ6q_ReportContentSpacing",
	ReportContentSubmitButton: "ReportContentDialog-module_UsEZ6q_ReportContentSubmitButton",
	ReportContentTopMargin: "ReportContentDialog-module_UsEZ6q_ReportContentTopMargin"
};
var ReportContentDialog = (t0) => {
	const $ = c(22);
	const { owner, ownerUrl, reportUrl, contentId, onClose, contentType: t1 } = t0;
	const contentType = t1 === void 0 ? "content" : t1;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	const [reportReason, setReportReason] = useState("Choose a reason");
	const [isLoading, setIsLoading] = useState(false);
	const [reportType, setReportType] = useState("admins");
	let t2;
	if ($[0] !== addToast || $[1] !== contentId || $[2] !== environment || $[3] !== onClose || $[4] !== reportReason) {
		t2 = () => {
			setIsLoading(true);
			submitAbuseReportMutation({
				environment,
				input: {
					reportedContentId: contentId,
					reason: getReason(reportReason)
				},
				onError(error) {
					addToast({
						type: "error",
						message: `Unable to submit report: ${error}`
					});
					setIsLoading(false);
				},
				onCompleted() {
					addToast({
						type: "success",
						message: "Report submitted"
					});
					setIsLoading(false);
					onClose();
				}
			});
		};
		$[0] = addToast;
		$[1] = contentId;
		$[2] = environment;
		$[3] = onClose;
		$[4] = reportReason;
		$[5] = t2;
	} else t2 = $[5];
	const onSubmitReportToRepositoryAdmins = t2;
	let t3;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (selectedValue) => {
			setReportType(selectedValue);
		};
		$[6] = t3;
	} else t3 = $[6];
	const handleReportTypeChange = t3;
	let t4;
	if ($[7] !== contentType || $[8] !== isLoading || $[9] !== onClose || $[10] !== onSubmitReportToRepositoryAdmins || $[11] !== owner || $[12] !== ownerUrl || $[13] !== reportReason || $[14] !== reportType || $[15] !== reportUrl) {
		let t5;
		if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
			t5 = () => setReportReason("ABUSE");
			$[17] = t5;
		} else t5 = $[17];
		let t6;
		if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
			t6 = () => setReportReason("SPAM");
			$[18] = t6;
		} else t6 = $[18];
		let t7;
		if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setReportReason("OFF_TOPIC");
			$[19] = t7;
		} else t7 = $[19];
		let t8;
		if ($[20] !== onSubmitReportToRepositoryAdmins) {
			t8 = () => onSubmitReportToRepositoryAdmins();
			$[20] = onSubmitReportToRepositoryAdmins;
			$[21] = t8;
		} else t8 = $[21];
		const reportToMaintainers = jsxs("div", {
			className: ReportContentDialog_module_default.ReportContentContainer,
			children: [
				jsxs("div", { children: [
					jsxs("p", { children: [
						jsxs("span", { children: [
							"This ",
							contentType,
							" violates "
						] }),
						jsx(Link, {
							inline: true,
							href: ownerUrl,
							children: `@${owner}'s`
						}),
						jsx("span", { children: " Code of Conduct and should be submitted to the maintainers of this repository for review." })
					] }),
					jsx("p", { children: "This report, as well as your username as the reporter, will be viewable by all admins of this repository." }),
					jsxs("p", { children: ["Choose a reason for reporting this ", contentType] })
				] }),
				jsx("div", {
					className: ReportContentDialog_module_default.ReportContentSpacing,
					children: jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, { children: reportReason }), jsx(ActionMenu.Overlay, { children: jsxs(ActionList, { children: [
						jsx(ActionList.Item, {
							onSelect: t5,
							children: "Abuse"
						}),
						jsx(ActionList.Item, {
							onSelect: t6,
							children: "Spam"
						}),
						jsx(ActionList.Item, {
							onSelect: t7,
							children: "Off Topic"
						})
					] }) })] })
				}),
				jsxs("div", {
					className: ReportContentDialog_module_default.ReportContentTopMargin,
					children: [jsxs("div", {
						className: ReportContentDialog_module_default.ReportContentHelpText,
						children: [jsx("span", { children: "Learn more about " }), jsx(Link, {
							href: "https://docs.github.com/articles/reporting-abuse-or-spam",
							children: "requesting that maintainers moderate content."
						})]
					}), jsx(ButtonComponent, {
						variant: "danger",
						onClick: t8,
						disabled: isLoading,
						className: ReportContentDialog_module_default.ReportContentSubmitButton,
						children: "Report to repository admins"
					})]
				})
			]
		});
		const reportToSupport = jsxs("div", {
			className: ReportContentDialog_module_default.ReportContentContainer,
			children: [jsx("span", { children: "Contact GitHub Support about this user's spammy or abusive behavior." }), jsxs("div", {
				className: ReportContentDialog_module_default.ReportContentFooterSpacing,
				children: [jsxs("div", {
					className: ReportContentDialog_module_default.ReportContentHelpText,
					children: [jsx("span", { children: "Learn more about " }), jsx(Link, {
						href: "https://docs.github.com/articles/reporting-abuse-or-spam",
						children: "reporting abuse to GitHub support"
					})]
				}), jsx(ButtonComponent, {
					variant: "danger",
					as: "a",
					href: reportUrl,
					disabled: isLoading,
					className: ReportContentDialog_module_default.ReportContentSubmitButton,
					children: "Report abuse to GitHub support"
				})]
			})]
		});
		t4 = jsx(Portal, { children: jsx(Dialog, {
			title: `Report ${contentType}`,
			width: "xlarge",
			height: "auto",
			onClose,
			className: ReportContentDialog_module_default.ReportContentDialog,
			children: jsxs("div", {
				className: ReportContentDialog_module_default.ReportContentRadioContainer,
				children: [
					jsxs(RadioGroup_default, {
						name: "choiceGroup",
						onChange: handleReportTypeChange,
						children: [
							jsxs(RadioGroup_default.Label, {
								className: ReportContentDialog_module_default.ReportContentRadioLabel,
								children: [
									"Where would you like to report this ",
									contentType,
									" to?"
								]
							}),
							jsxs(FormControl$1, { children: [jsx(Radio, {
								value: "admins",
								defaultChecked: true
							}), jsx(FormControl$1.Label, { children: "To repository admins" })] }),
							jsxs(FormControl$1, { children: [jsx(Radio, { value: "support" }), jsx(FormControl$1.Label, { children: "To GitHub support" })] })
						]
					}),
					reportType === "admins" && reportToMaintainers,
					reportType === "support" && reportToSupport
				]
			})
		}) });
		$[7] = contentType;
		$[8] = isLoading;
		$[9] = onClose;
		$[10] = onSubmitReportToRepositoryAdmins;
		$[11] = owner;
		$[12] = ownerUrl;
		$[13] = reportReason;
		$[14] = reportType;
		$[15] = reportUrl;
		$[16] = t4;
	} else t4 = $[16];
	return t4;
};
ReportContentDialog.displayName = "ReportContentDialog";
function getReason(reportReason) {
	if (reportReason === "Choose a reason") return "UNSPECIFIED";
	return reportReason;
}
var node$2 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "input",
			"variableName": "input"
		}],
		"concreteType": "UnblockUserFromOrganizationPayload",
		"kind": "LinkedField",
		"name": "unblockUserFromOrganization",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "clientMutationId",
			"storageKey": null
		}],
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "unblockUserFromOrganizationMutation",
			"selections": v1,
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "unblockUserFromOrganizationMutation",
			"selections": v1
		},
		"params": {
			"id": "3bb2b18124f6d9e474f1e4d67f4d648c",
			"metadata": {},
			"name": "unblockUserFromOrganizationMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$2.hash = "05b84828fae0f7858c1ccd7347bfbb3e";
function unblockUserFromOrganization({ environment, input: { organizationId, unblockedUserId }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$2,
		variables: { input: {
			organizationId,
			unblockedUserId
		} },
		onError: (error) => onError && onError(error),
		onCompleted: () => {
			onCompleted?.();
		}
	});
}
var UnblockUserFromOrgDialog = (props) => {
	return props.onUnblock ? /* @__PURE__ */ jsx(UnblockUserFromOrgDialogWithoutRelay, { ...props }) : /* @__PURE__ */ jsx(UnblockUserFromOrgDialogWithRelay, { ...props });
};
UnblockUserFromOrgDialog.displayName = "UnblockUserFromOrgDialog";
var UnblockUserFromOrgDialogWithRelay = (t0) => {
	const $ = c(11);
	const { contentAuthor, organization, onClose, contentId } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t1;
	if ($[0] !== contentAuthor.id || $[1] !== contentId || $[2] !== environment || $[3] !== onClose || $[4] !== organization.id) {
		t1 = (gesture) => {
			if (gesture === "confirm") unblockUserFromOrganization({
				environment,
				input: {
					unblockedUserId: contentAuthor.id,
					organizationId: organization.id
				},
				onCompleted: () => (0, import_relay_runtime.commitLocalUpdate)(environment, (store) => {
					const contentObject = store.get(contentId);
					contentObject?.setValue(true, "pendingUnblock");
					contentObject?.setValue(false, "pendingBlock");
				})
			});
			onClose();
		};
		$[0] = contentAuthor.id;
		$[1] = contentId;
		$[2] = environment;
		$[3] = onClose;
		$[4] = organization.id;
		$[5] = t1;
	} else t1 = $[5];
	const onDialogClose = t1;
	const t2 = `Unblock ${contentAuthor.login} from ${organization.login}`;
	let t3;
	if ($[6] !== contentAuthor.login || $[7] !== onDialogClose || $[8] !== organization.login || $[9] !== t2) {
		t3 = jsxs(ConfirmationDialog, {
			title: t2,
			confirmButtonContent: "Unblock user",
			confirmButtonType: "danger",
			onClose: onDialogClose,
			children: [
				"Are you sure you want to unblock ",
				jsx("strong", { children: contentAuthor.login }),
				" from ",
				jsx("strong", { children: organization.login }),
				"?"
			]
		});
		$[6] = contentAuthor.login;
		$[7] = onDialogClose;
		$[8] = organization.login;
		$[9] = t2;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
};
UnblockUserFromOrgDialogWithRelay.displayName = "UnblockUserFromOrgDialogWithRelay";
var UnblockUserFromOrgDialogWithoutRelay = (t0) => {
	const $ = c(10);
	const { contentAuthor, organization, onClose, onUnblock } = t0;
	let t1;
	if ($[0] !== contentAuthor.login || $[1] !== onClose || $[2] !== onUnblock || $[3] !== organization.login) {
		t1 = (gesture) => {
			if (gesture === "confirm") onUnblock?.(organization.login, contentAuthor.login);
			onClose();
		};
		$[0] = contentAuthor.login;
		$[1] = onClose;
		$[2] = onUnblock;
		$[3] = organization.login;
		$[4] = t1;
	} else t1 = $[4];
	const onDialogClose = t1;
	const t2 = `Unblock ${contentAuthor.login} from ${organization.login}`;
	let t3;
	if ($[5] !== contentAuthor.login || $[6] !== onDialogClose || $[7] !== organization.login || $[8] !== t2) {
		t3 = jsxs(ConfirmationDialog, {
			title: t2,
			confirmButtonContent: "Unblock user",
			confirmButtonType: "danger",
			onClose: onDialogClose,
			children: [
				"Are you sure you want to unblock ",
				jsx("strong", { children: contentAuthor.login }),
				" from ",
				jsx("strong", { children: organization.login }),
				"?"
			]
		});
		$[5] = contentAuthor.login;
		$[6] = onDialogClose;
		$[7] = organization.login;
		$[8] = t2;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
};
UnblockUserFromOrgDialogWithoutRelay.displayName = "UnblockUserFromOrgDialogWithoutRelay";
function CommentActions({ comment, commentAuthorLogin, editComment, onReplySelect, isMinimized = false, isReply = false, navigate, onBlock, onUnblock, onMinimize: onMinimized, hideComment, unhideComment, deleteComment, onSuccessfulBlock, commentRef, isDisabled = false, showCopilotMenuItem = false, pinComment, unpinComment, onEditHover }) {
	const [menuOpened, setMenuOpened] = useState(false);
	const [selection, setSelection] = useState(null);
	const [isNewIssueOpen, setIsNewIssueOpen] = useState(false);
	const [isReportContentOpen, setIsReportContentOpen] = useState(false);
	const [isBlockUserFromOrgOpen, setIsBlockUserFromOrgOpen] = useState(false);
	const [isUnblockUserFromOrgOpen, setIsUnblockUserFromOrgOpen] = useState(false);
	const { updateIssueWithCopilot } = useUpdateIssueFromCommentWithCopilot();
	const { sendAnalyticsEvent } = useAnalytics();
	const shouldShowCopilotMenuItem = showCopilotMenuItem && comment.viewerCanUpdate;
	const formatBodyAsReference = useCallback((str) => {
		return `${str.replace(/^(?!>)/gm, "> ")} \n\n _Originally posted by @${commentAuthorLogin} in [${comment.referenceText}](${comment.url})_`;
	}, [
		comment.referenceText,
		commentAuthorLogin,
		comment.url
	]);
	const copyToClipboard = (textToCopy) => {
		copyText(textToCopy);
	};
	const onUpdateIssue = useCallback(() => {
		updateIssueWithCopilot(comment);
	}, [updateIssueWithCopilot, comment]);
	const commentHidden = !!comment.pendingMinimizeReason || comment.isHidden;
	const minimizeButton = useMemo(() => {
		return !commentHidden || isMinimized || !comment.viewerCanSeeMinimizeButton ? null : /* @__PURE__ */ jsx(IconButton, {
			"aria-label": "hide comment",
			variant: "invisible",
			onClick: () => onMinimized?.(true),
			icon: FoldIcon,
			size: "small",
			className: CommentActions_module_default.CommentActionsIconButton
		});
	}, [
		commentHidden,
		isMinimized,
		onMinimized,
		comment.viewerCanSeeMinimizeButton
	]);
	const unminimizeButton = useMemo(() => {
		return !commentHidden || !isMinimized || !comment.viewerCanSeeUnminimizeButton ? null : /* @__PURE__ */ jsx(IconButton, {
			"aria-label": "show comment",
			variant: "invisible",
			onClick: () => onMinimized?.(false),
			icon: UnfoldIcon,
			size: "small",
			className: CommentActions_module_default.CommentActionsIconButton
		});
	}, [
		commentHidden,
		isMinimized,
		onMinimized,
		comment.viewerCanSeeUnminimizeButton
	]);
	const reportUrl = useMemo(() => {
		if (!comment.author) return void 0;
		const host = ssrSafeWindow?.location.origin;
		if (!host) return void 0;
		return `${host}/contact/report-content?${`content_url=${encodeURIComponent(comment.url)}&report=${commentAuthorLogin}+(user)`}`;
	}, [
		commentAuthorLogin,
		comment.author,
		comment.url
	]);
	const showReportSection = (comment.viewerCanReport || comment.viewerCanReportToMaintainer) && comment.author;
	const isAuthorCopilot = isCopilot(commentAuthorLogin);
	const userCanBlock = canBlock({
		viewerCanBlockFromOrg: comment.viewerCanBlockFromOrg,
		pendingBlock: !!comment.pendingBlock,
		pendingUnblock: !!comment.pendingUnblock,
		hasAuthor: !!comment.author,
		isAuthorCopilot
	});
	const userCanUnblock = canUnblock({
		viewerCanUnblockFromOrg: comment.viewerCanUnblockFromOrg,
		pendingBlock: !!comment.pendingBlock,
		pendingUnblock: !!comment.pendingUnblock,
		hasAuthor: !!comment.author
	});
	const userCanReferenceInIssue = typeof comment.viewerCanReferenceInIssue === "boolean" ? comment.viewerCanReferenceInIssue : true;
	const userCanQuoteReply = typeof comment.viewerCanQuoteReply === "boolean" ? comment.viewerCanQuoteReply : true;
	const isPinned = Boolean(comment.pinnedBy);
	const userCanPin = comment.viewerCanPin && !isPinned && pinComment !== void 0;
	const userCanUnpin = comment.viewerCanUnpin && isPinned && unpinComment !== void 0;
	const handlePin = () => {
		pinComment?.(comment.id);
	};
	const handleUnpin = () => {
		unpinComment?.(comment.id);
	};
	const issueCreateProps = {
		isCreateDialogOpen: isNewIssueOpen,
		setIsCreateDialogOpen: setIsNewIssueOpen,
		navigate,
		optionConfig: {
			storageKeyPrefix: comment.id,
			defaultDisplayMode: DisplayMode.IssueCreation,
			scopedOrganization: comment.repository.owner.login,
			issueCreateArguments: {
				initialValues: { body: formatBodyAsReference(comment.body) },
				repository: {
					name: comment.repository.name,
					owner: comment.repository.owner.login
				}
			}
		}
	};
	const createdAtFormatted = ariaLabelDate(new Date(comment.createdAt));
	const commentActionsLabel = `Actions for ${commentAuthorLogin}'s ${isReply ? "reply" : "comment"}, ${createdAtFormatted}`;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		isNewIssueOpen && /* @__PURE__ */ jsx(CreateIssueDialogEntry, { ...issueCreateProps }),
		isReportContentOpen && /* @__PURE__ */ jsx(ReportContentDialog, {
			owner: comment.repository.owner.login,
			ownerUrl: comment.repository.owner.url,
			reportUrl,
			contentId: comment.id,
			onClose: () => setIsReportContentOpen(false),
			contentType: "comment"
		}),
		isBlockUserFromOrgOpen && comment.author && /* @__PURE__ */ jsx(BlockUserFromOrgDialog, {
			onBlock,
			onClose: () => {
				onSuccessfulBlock?.();
				setIsBlockUserFromOrgOpen(false);
			},
			organization: comment.repository.owner,
			contentId: comment.id,
			contentAuthor: comment.author,
			contentUrl: comment.url
		}),
		isUnblockUserFromOrgOpen && comment.author && /* @__PURE__ */ jsx(UnblockUserFromOrgDialog, {
			onClose: () => setIsUnblockUserFromOrgOpen(false),
			onUnblock,
			organization: comment.repository.owner,
			contentAuthor: comment.author,
			contentId: comment.id
		}),
		minimizeButton,
		unminimizeButton,
		/* @__PURE__ */ jsxs(ActionMenu, {
			open: menuOpened,
			onOpenChange: (value) => {
				if (value) {
					const current = window.getSelection();
					if (current && current.anchorNode) setSelection({
						anchorNode: current.anchorNode,
						range: current.getRangeAt(0)
					});
					else setSelection(null);
					if (!menuOpened && isFeatureEnabled("copilot_comment_update_issue_body") && shouldShowCopilotMenuItem) sendAnalyticsEvent("analytics.click", "COMMENT_ACTIONS_MENU_OPENED", { commentId: comment.id });
				}
				setMenuOpened(value);
			},
			children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, {
				"data-testid": TEST_IDS.commentHeaderHamburger,
				children: /* @__PURE__ */ jsx(IconButton, {
					disabled: isDisabled,
					size: "small",
					icon: KebabHorizontalIcon,
					variant: "invisible",
					"aria-label": commentActionsLabel,
					tooltipDirection: "n",
					description: "More actions",
					className: CommentActions_module_default.CommentActionsIconButton
				})
			}), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, {
				"data-testid": TEST_IDS.commentHeaderHamburgerOpen,
				children: [
					/* @__PURE__ */ jsxs(ActionList.Item, {
						inactiveText: comment.url === "" ? "Comment must have a URL to be copied" : void 0,
						onSelect: () => copyToClipboard(comment.url),
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LinkIcon, {}) }), "Copy link"]
					}),
					isFeatureEnabled("comment_viewer_copy_raw_markdown") ? /* @__PURE__ */ jsxs(ActionList.Item, {
						inactiveText: comment.body === "" ? "Comment must have content to be copied" : void 0,
						onSelect: () => copyToClipboard(comment.bodyForClipboard || comment.body),
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(MarkdownIcon, {}) }), "Copy Markdown"]
					}) : null,
					isLoggedIn() && /* @__PURE__ */ jsxs(Fragment$1, { children: [userCanQuoteReply && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							onReplySelect(selectQuoteFromComment(commentRef?.current, selection, comment.body));
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(QuoteIcon, {}) }), "Quote reply"]
					}), userCanReferenceInIssue && /* @__PURE__ */ jsxs(Fragment$1, { children: [
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsxs(ActionList.Item, {
							"data-testid": TEST_IDS.commentMenuRefComment,
							onSelect: () => setIsNewIssueOpen(true),
							className: CommentActions_module_default.CommentActionsListItem,
							children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(IssueOpenedIcon, {}) }), "Reference in a new issue"]
						}),
						isFeatureEnabled("copilot_comment_update_issue_body") && shouldShowCopilotMenuItem && /* @__PURE__ */ jsxs(ActionList.Item, {
							onSelect: onUpdateIssue,
							children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CopilotIcon, {}) }), "Update issue"]
						})
					] })] }),
					(comment.viewerCanUpdate || comment.viewerCanMinimize || comment.viewerCanPin || comment.viewerCanUnpin || comment.viewerCanDelete) && /* @__PURE__ */ jsx(ActionList.Divider, {}),
					comment.viewerCanUpdate && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => editComment(),
						onMouseEnter: onEditHover,
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PencilIcon, {}) }), "Edit"]
					}),
					userCanPin && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: handlePin,
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PinIcon, {}) }), "Pin"]
					}),
					userCanUnpin && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: handleUnpin,
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PinSlashIcon, {}) }), "Unpin"]
					}),
					comment.viewerCanMinimize && !commentHidden && /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs(ActionList.Item, { children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(EyeClosedIcon, {}) }), "Hide"] }) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsx(HideCommentActionItems, {
						onSelect: hideComment,
						setMenuOpen: setMenuOpened
					}) }) })] }),
					comment.viewerCanUnminimize && commentHidden && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: unhideComment,
						children: [
							/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(EyeIcon, {}) }),
							" ",
							"Unhide"
						]
					}),
					comment.viewerCanDelete && /* @__PURE__ */ jsxs(ActionList.Item, {
						variant: "danger",
						onSelect: deleteComment,
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(TrashIcon, {}) }), "Delete"]
					}),
					showReportSection && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), comment.viewerCanReportToMaintainer ? /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							setIsReportContentOpen(true);
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ReportIcon, {}) }), "Report content"]
					}) : /* @__PURE__ */ jsxs(ActionList.LinkItem, {
						href: reportUrl,
						target: "_blank",
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ReportIcon, {}) }), "Report content"]
					})] }),
					(userCanBlock || userCanUnblock) && !showReportSection && /* @__PURE__ */ jsx(ActionList.Divider, {}),
					userCanBlock && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => setIsBlockUserFromOrgOpen(true),
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(BlockedIcon, {}) }), "Block user"]
					}),
					userCanUnblock && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => setIsUnblockUserFromOrgOpen(true),
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(BlockedIcon, {}) }), "Unblock user"]
					})
				]
			}) })]
		})
	] });
}
CommentActions.displayName = "CommentActions";
var node$1 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "MarkdownLastEditedBy",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanReadUserContentEdits",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"concreteType": "UserContentEdit",
		"kind": "LinkedField",
		"name": "lastUserContentEdit",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": null,
			"kind": "LinkedField",
			"name": "editor",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "login",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": null
	}],
	"type": "Comment",
	"abstractKey": "__isComment"
};
node$1.hash = "bbab0cb2d43eeaaa0ed5b010868ec7f4";
var MarkdownLastEditedBy_module_default = {
	lastEditInfoContainer: "MarkdownLastEditedBy-module_9eEdgG_lastEditInfoContainer",
	mutedEditorLink: "MarkdownLastEditedBy-module_9eEdgG_mutedEditorLink"
};
function MarkdownLastEditedBy(t0) {
	const $ = c(5);
	const { editInformation, includeSeparator, forceUnderline } = t0;
	const data = (0, import_react_relay.useFragment)(node$1, editInformation);
	if (!data || !data.viewerCanReadUserContentEdits || !data.lastUserContentEdit || !data.lastUserContentEdit.editor) return null;
	const { login, url } = data.lastUserContentEdit.editor;
	let t1;
	if ($[0] !== forceUnderline || $[1] !== includeSeparator || $[2] !== login || $[3] !== url) {
		t1 = jsxs("span", {
			className: MarkdownLastEditedBy_module_default.lastEditInfoContainer,
			children: [includeSeparator && jsx("span", { children: " · " }), jsxs("span", { children: [`${LABELS.editHistory.editedBy} `, jsx(Link, {
				href: url,
				inline: forceUnderline,
				className: MarkdownLastEditedBy_module_default.mutedEditorLink,
				children: login
			})] })]
		});
		$[0] = forceUnderline;
		$[1] = includeSeparator;
		$[2] = login;
		$[3] = url;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
MarkdownLastEditedBy.displayName = "MarkdownLastEditedBy";
function CommentHeaderLastEditedBy(t0) {
	const $ = c(4);
	const { id } = t0;
	let t1;
	if ($[0] !== id) {
		t1 = { id };
		$[0] = id;
		$[1] = t1;
	} else t1 = $[1];
	const data = useMarkdownEditHistoryViewerQuery(t1);
	let t2;
	if ($[2] !== data) {
		t2 = data ? jsx(MarkdownLastEditedBy, {
			editInformation: data,
			includeSeparator: true
		}) : null;
		$[2] = data;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
CommentHeaderLastEditedBy.displayName = "CommentHeaderLastEditedBy";
function CommentHeader({ hideActions, lazyFetchEditHistory = false, onEditHover, ...props }) {
	return /* @__PURE__ */ jsx(ActivityHeader, {
		lastEditedByMessage: /* @__PURE__ */ jsx(CommentHeaderLastEditedBy, { id: props.comment.id }),
		editHistoryComponent: lazyFetchEditHistory ? /* @__PURE__ */ jsx(Suspense, {
			fallback: null,
			children: /* @__PURE__ */ jsx(CommentHeaderEditHistory, { id: props.comment.id })
		}) : /* @__PURE__ */ jsx(MarkdownEditHistoryViewer, { editHistory: props.comment }),
		...props,
		actions: hideActions ? void 0 : /* @__PURE__ */ jsx(CommentActions, {
			...props,
			onEditHover
		})
	});
}
CommentHeader.displayName = "CommentHeader";
function CommentHeaderEditHistory(t0) {
	const $ = c(4);
	const { id } = t0;
	let t1;
	if ($[0] !== id) {
		t1 = { id };
		$[0] = id;
		$[1] = t1;
	} else t1 = $[1];
	const data = useMarkdownEditHistoryViewerQuery(t1);
	let t2;
	if ($[2] !== data) {
		t2 = data ? jsx(MarkdownEditHistoryViewer, { editHistory: data }) : null;
		$[2] = data;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
CommentHeaderEditHistory.displayName = "CommentHeaderEditHistory";
function IssueCommentHeader({ anchorBaseUrl, comment, commentAuthorLogin, editComment, onReplySelect, isMinimized = false, onMinimize: onMinimized, navigate, avatarUrl, commentRef, relayConnectionIds, commentSubjectAuthorLogin, hideActions = false, commentAuthorType, hasDisabledActions = false, showCopilotMenuItem = false, onEditHover }) {
	const commentData = (0, import_react_relay.useFragment)(node$16, comment);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const confirm = useConfirm();
	const { addToast } = useToastContext();
	const { pinComment, unpinComment } = usePinnedComment();
	const hideComment = useCallback(async (reason) => {
		if (!commentData) return;
		minimizeCommentMutation({
			environment,
			input: {
				id: commentData.id,
				reason
			},
			onError: () => {
				addToast({
					type: "error",
					message: "Failed to hide comment"
				});
			}
		});
	}, [
		addToast,
		environment,
		commentData?.id
	]);
	const unhideComment = useCallback(async () => {
		if (!commentData) return;
		unminimizeCommentMutation({
			environment,
			input: { id: commentData.id },
			onError: () => {
				addToast({
					type: "error",
					message: "Failed to unhide comment"
				});
			}
		});
	}, [
		addToast,
		environment,
		commentData?.id
	]);
	const deleteComment = useCallback(async () => {
		if (!commentData) return;
		if (!await confirm({
			title: LABELS$1.confirmations.deleteCommentTitle,
			content: LABELS$1.confirmations.deleteCommentContent,
			confirmButtonContent: LABELS$1.confirmations.deleteCommentConfirmButtonContent,
			confirmButtonType: "danger"
		})) return;
		commitDeleteIssueCommentMutation({
			environment,
			connectionIds: relayConnectionIds ?? [],
			input: { id: commentData.id },
			onError: () => {
				addToast({
					type: "error",
					message: ERRORS$1.couldNotDeleteComment
				});
			}
		});
	}, [
		confirm,
		commentData?.id,
		relayConnectionIds,
		environment,
		addToast
	]);
	if (!commentData) return null;
	const url = anchorBaseUrl ? `${anchorBaseUrl}#issuecomment-${commentData.databaseId}` : commentData.url;
	const viewerCanPin = isLoggedIn() && commentData.viewerCanPin;
	const viewerCanUnpin = isLoggedIn() && commentData.viewerCanUnpin;
	return /* @__PURE__ */ jsx(CommentHeader, {
		comment: {
			...commentData,
			referenceText: `#${commentData.issue?.number ?? "?"}`,
			url,
			viewerCanSeeMinimizeButton: true,
			viewerCanSeeUnminimizeButton: true,
			viewerCanUnminimize: commentData.viewerCanUnminimize ?? false,
			viaApp: commentData.viaApp || void 0,
			viewerCanPin,
			viewerCanUnpin
		},
		editComment,
		onReplySelect,
		isMinimized,
		onMinimize: onMinimized,
		commentAuthorLogin,
		commentAuthorProfileName: commentData.author?.name,
		navigate,
		avatarUrl,
		hideComment,
		unhideComment,
		deleteComment,
		commentRef,
		viewerDidAuthor: commentData.viewerDidAuthor,
		commentSubjectAuthorLogin,
		commentSubjectType: "issue",
		hideActions,
		isDisabled: hasDisabledActions,
		commentAuthorType,
		id: `issuecomment-${commentData.databaseId}`,
		showCopilotMenuItem,
		pinComment,
		unpinComment,
		pinnedByLogin: commentData?.pinnedBy?.login,
		onEditHover
	});
}
IssueCommentHeader.displayName = "IssueCommentHeader";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "bodyVersion",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueCommentBodyMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueCommentPayload",
				"kind": "LinkedField",
				"name": "updateIssueComment",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "IssueComment",
					"kind": "LinkedField",
					"name": "issueComment",
					"plural": false,
					"selections": [v2, {
						"args": null,
						"kind": "FragmentSpread",
						"name": "IssueCommentViewerMarkdownViewer"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueCommentBodyMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateIssueCommentPayload",
				"kind": "LinkedField",
				"name": "updateIssueComment",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "IssueComment",
					"kind": "LinkedField",
					"name": "issueComment",
					"plural": false,
					"selections": [
						v2,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "id",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "body",
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "unfurlReferences",
								"value": true
							}],
							"kind": "ScalarField",
							"name": "bodyHTML",
							"storageKey": "bodyHTML(unfurlReferences:true)"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "viewerCanUpdate",
							"storageKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "93dc3b03583ff1e7ca5a159bb4220086",
			"metadata": {},
			"name": "updateIssueCommentBodyMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "f4cdbbb6d54b34b2c63e5485bb3c7366";
function commitUpdateIssueCommentBodyMutation({ environment, input: { id, body, bodyVersion }, onCompleted, onError, withOptimisticResponse = false }) {
	if (!body) return;
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		variables: { input: {
			id,
			body,
			bodyVersion
		} },
		optimisticResponse: withOptimisticResponse ? { updateIssueComment: { issueComment: {
			id,
			body,
			bodyHTML: md2html(body),
			bodyVersion,
			viewerCanUpdate: false
		} } } : void 0,
		onCompleted: (response) => onCompleted && onCompleted(response),
		onError: (error) => onError && onError(error)
	});
}
export { usePinnedComment as _, CommentActions as a, IssueCommentHeader as c, PreloadedQueryBoundary as d, ReportContentDialog as f, commitUpdateIssueCommentBodyMutation as g, ariaLabelDate as h, BlockUserFromOrgDialog as i, MarkdownEditHistoryViewer as l, UnblockUserFromOrgDialog as m, ActivityHeader_module_default as n, CommentAuthorAssociation as o, SpammyBadge as p, Avatar_module_default as r, CommentAuthorTypes as s, ActivityHeader as t, MarkdownLastEditedBy as u };
