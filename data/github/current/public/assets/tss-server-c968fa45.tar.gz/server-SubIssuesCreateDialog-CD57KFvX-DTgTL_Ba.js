performance.mark("js-parse-end:server-SubIssuesCreateDialog-CD57KFvX-DTgTL_Ba.js");
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { n as CreateIssueDialogEntry } from "./server-CreateIssueDialogEntry-DoIrAy1x-N5DbhlQU.js";
import { n as useAlert, t as RelationshipsAlertDialog } from "./server-use-alert-DENoqsF4-DQy6Y9S2.js";
import { useCallback, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:SubIssuesCreateDialog-CD57KFvX.js");
var node = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "closed",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": { "connection": [{
			"count": null,
			"cursor": null,
			"direction": "forward",
			"path": ["projectItems"]
		}] },
		"name": "SubIssuesCreateDialog",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "name",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						}],
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"alias": "projectItems",
				"args": null,
				"concreteType": "ProjectV2ItemConnection",
				"kind": "LinkedField",
				"name": "__ProjectSection_projectItems_connection",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "ProjectV2ItemEdge",
					"kind": "LinkedField",
					"name": "edges",
					"plural": true,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "ProjectV2Item",
						"kind": "LinkedField",
						"name": "node",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "ProjectV2",
							"kind": "LinkedField",
							"name": "project",
							"plural": false,
							"selections": [
								v0,
								v1,
								v2,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "number",
									"storageKey": null
								},
								v3,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "viewerCanUpdate",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasReachedItemsLimit",
									"storageKey": null
								},
								v4
							],
							"storageKey": null
						}, v4],
						"storageKey": null
					}, {
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "cursor",
						"storageKey": null
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": "PageInfo",
					"kind": "LinkedField",
					"name": "pageInfo",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "endCursor",
						"storageKey": null
					}, {
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "hasNextPage",
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Milestone",
				"kind": "LinkedField",
				"name": "milestone",
				"plural": false,
				"selections": [
					v0,
					v1,
					v2,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "dueOn",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "progressPercentage",
						"storageKey": null
					},
					v3,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "closedAt",
						"storageKey": null
					}
				],
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node.hash = "c42ba6aa0f953d624e9271e5ca77a407";
var import_react_relay = require_react_relay();
function SubIssuesCreateDialog(t0) {
	const $ = c(16);
	const { issue, open, setOpen, onCreateSuccess } = t0;
	const { alert, resetAlert, showServerAlert } = useAlert();
	const data = (0, import_react_relay.useFragment)(node, issue);
	let t1;
	if ($[0] !== showServerAlert) {
		t1 = (error) => showServerAlert(error);
		$[0] = showServerAlert;
		$[1] = t1;
	} else t1 = $[1];
	const onCreateError = t1;
	data.projectItems?.edges;
	let t2;
	if ($[2] !== data.projectItems?.edges) {
		t2 = (data.projectItems?.edges ?? []).flatMap(_temp).filter(_temp2).map(_temp3);
		$[2] = data.projectItems?.edges;
		$[3] = t2;
	} else t2 = $[3];
	const preselectedProjects = t2;
	const preselectedMilestone = data.milestone ? data.milestone : void 0;
	let t3;
	if ($[4] !== alert || $[5] !== data.id || $[6] !== data.repository.name || $[7] !== data.repository.owner.login || $[8] !== onCreateError || $[9] !== onCreateSuccess || $[10] !== open || $[11] !== preselectedMilestone || $[12] !== preselectedProjects || $[13] !== resetAlert || $[14] !== setOpen) {
		const issueCreateProps = {
			navigate: noop,
			onCreateSuccess,
			onCreateError,
			isCreateDialogOpen: open,
			setIsCreateDialogOpen: setOpen,
			optionConfig: {
				scopedOrganization: data.repository.owner.login,
				issueCreateArguments: {
					repository: {
						owner: data.repository.owner.login,
						name: data.repository.name
					},
					parentIssue: { id: data.id },
					initialValues: {
						projects: preselectedProjects,
						milestone: preselectedMilestone
					}
				}
			}
		};
		t3 = jsxs(Fragment$1, { children: [alert && jsx(RelationshipsAlertDialog, {
			title: alert.title,
			onClose: resetAlert,
			children: alert.body
		}), jsx(CreateIssueDialogEntry, { ...issueCreateProps })] });
		$[4] = alert;
		$[5] = data.id;
		$[6] = data.repository.name;
		$[7] = data.repository.owner.login;
		$[8] = onCreateError;
		$[9] = onCreateSuccess;
		$[10] = open;
		$[11] = preselectedMilestone;
		$[12] = preselectedProjects;
		$[13] = resetAlert;
		$[14] = setOpen;
		$[15] = t3;
	} else t3 = $[15];
	return t3;
}
SubIssuesCreateDialog.displayName = "SubIssuesCreateDialog";
function _temp3(projectItem_0) {
	return projectItem_0.project;
}
function _temp2(projectItem) {
	return projectItem.project.closed !== true;
}
function _temp(edge) {
	return edge?.node ? [edge.node] : [];
}
export { SubIssuesCreateDialog };
