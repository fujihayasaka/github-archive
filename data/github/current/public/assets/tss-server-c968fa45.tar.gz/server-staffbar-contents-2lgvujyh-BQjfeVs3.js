performance.mark("js-parse-end:server-staffbar-contents-2lgvujyh-BQjfeVs3.js");
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bt as GiftIcon, Lr as SlidersIcon, Mi as XIcon, Mn as MeterIcon, Mr as SidebarCollapseIcon, Nr as SidebarExpandIcon, Tr as ServerIcon, Ur as SparklesFillIcon, an as IconButton, di as ToolsIcon, gr as RepoIcon, h as BeakerIcon, n as ActionList, tt as CopyIcon, xn as LinkExternalIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { r as reactFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { s as useMutation } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { a as updateSearchParams } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { t as ActionBar } from "./server-ActionBar-DNCrmOcX-Dfop-h7_.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { o as ScopedCommands, r as CommandIconButton } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { t as UnderlinePanels_default } from "./server-UnderlinePanels-Bz0l-b06-rTTkq7jx.js";
import { t as useLocalStorage } from "./server-use-local-storage-CXtv8Nou-C7yzA4lh.js";
import { t as lazyWithPreload } from "./server-lazy-with-preload-CGaVyU2--DP3_troP.js";
import { t as staffbar_module_default } from "./server-staffbar.module-D7igjJkz-j9MHV7kN.js";
import { t as useWebVitals } from "./server-use-web-vitals-ePxIuvZ_-Cf0rAEz6.js";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:staffbar-contents-2lgvujyh.js");
var devtools_panels_module_default = {
	closeButton: "devtools-panels-module_31J2aa_closeButton",
	DevtoolsPanels: "devtools-panels-module_31J2aa_DevtoolsPanels",
	errorFallback: "devtools-panels-module_31J2aa_errorFallback",
	loadingFallback: "devtools-panels-module_31J2aa_loadingFallback",
	tabBar: "devtools-panels-module_31J2aa_tabBar",
	TabPanel: "devtools-panels-module_31J2aa_TabPanel"
};
var use_drag_to_resize_module_default = {
	container: "use-drag-to-resize-module_iB79Fq_container",
	resizing: "use-drag-to-resize-module_iB79Fq_resizing"
};
/** Bind event handlers to support dragging top edge of container to resize it. */
function useDragToResize(containerRef, setHeight) {
	const $ = c(8);
	const [resizing, setResizing] = useState(false);
	let t0;
	let t1;
	if ($[0] !== containerRef || $[1] !== setHeight) {
		t0 = () => {
			const panel = containerRef.current;
			if (!panel) return;
			const controller = new AbortController();
			const onPointerDown = (downEvent) => {
				if (!downEvent.isPrimary || downEvent.button !== 0) return;
				const { top } = panel.getBoundingClientRect();
				if (downEvent.clientY > top + 8) return;
				setResizing(true);
				downEvent.preventDefault();
				panel.setPointerCapture(downEvent.pointerId);
				const startY = downEvent.clientY;
				const startH = panel.offsetHeight;
				const onMove = (moveEvent) => {
					const delta = startY - moveEvent.clientY;
					setHeight(`${Math.floor(startH + delta)}px`);
				};
				const onUp = () => {
					document.body.removeEventListener("pointermove", onMove);
					document.body.removeEventListener("pointerup", onUp);
					setResizing(false);
				};
				document.body.addEventListener("pointermove", onMove, { signal: controller.signal });
				document.body.addEventListener("pointerup", onUp, { signal: controller.signal });
			};
			panel.addEventListener("pointerdown", onPointerDown, { signal: controller.signal });
			return () => controller.abort("component unmounted");
		};
		t1 = [containerRef, setHeight];
		$[0] = containerRef;
		$[1] = setHeight;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	const t2 = resizing && use_drag_to_resize_module_default.resizing;
	let t3;
	if ($[4] !== t2) {
		t3 = clsx(use_drag_to_resize_module_default.container, t2);
		$[4] = t2;
		$[5] = t3;
	} else t3 = $[5];
	let t4;
	if ($[6] !== t3) {
		t4 = { className: t3 };
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
}
function TabPanel({ children }) {
	return /* @__PURE__ */ jsx("div", {
		role: "tabpanel",
		className: devtools_panels_module_default.TabPanel,
		children: /* @__PURE__ */ jsx(ErrorBoundary, {
			fallback: /* @__PURE__ */ jsx("div", {
				className: devtools_panels_module_default.errorFallback,
				children: "Failed to load devtools panel. Check the browser console for details."
			}),
			children: /* @__PURE__ */ jsx(Suspense, {
				fallback: /* @__PURE__ */ jsx("div", {
					className: devtools_panels_module_default.loadingFallback,
					children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
				}),
				children
			})
		})
	});
}
TabPanel.displayName = "TabPanel";
function DevtoolsPanels({ onClose }) {
	const containerRef = useRef(null);
	const [height, setHeight] = useLocalStorage("staffbar-devtools-height", "400px");
	const [panel, setPanel] = useLocalStorage("staffbar-devtools-active-panel", "react-query");
	const { className: resizeClassName } = useDragToResize(containerRef, setHeight);
	return /* @__PURE__ */ jsx(ScopedCommands, {
		commands: { "github:cancel": onClose },
		children: /* @__PURE__ */ jsxs("section", {
			className: clsx(devtools_panels_module_default.DevtoolsPanels, resizeClassName),
			style: { height },
			"aria-label": "Developer tools",
			ref: containerRef,
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: devtools_panels_module_default.tabBar,
					children: [/* @__PURE__ */ jsx(CommandIconButton, {
						icon: XIcon,
						commandId: "github:cancel",
						"aria-label": "Close",
						className: devtools_panels_module_default.closeButton,
						variant: "invisible"
					}), /* @__PURE__ */ jsx("div", {
						style: { flex: 1 },
						children: /* @__PURE__ */ jsxs(UnderlinePanels_default, { children: [
							/* @__PURE__ */ jsx(UnderlinePanels_default.Tab, {
								"aria-selected": panel === "react-query",
								onSelect: () => setPanel("react-query"),
								children: "React Query"
							}),
							/* @__PURE__ */ jsx(UnderlinePanels_default.Panel, { "aria-hidden": true }),
							/* @__PURE__ */ jsx(UnderlinePanels_default.Tab, {
								"aria-selected": panel === "router",
								onSelect: () => setPanel("router"),
								children: "Router"
							}),
							/* @__PURE__ */ jsx(UnderlinePanels_default.Panel, { "aria-hidden": true })
						] })
					})]
				}),
				panel === "react-query" && /* @__PURE__ */ jsx(TabPanel, { children: /* @__PURE__ */ jsx(AsyncReactQueryDevtoolsPanel, {
					onClose,
					style: { height: "100%" }
				}) }),
				panel === "router" && /* @__PURE__ */ jsx(TabPanel, { children: /* @__PURE__ */ jsx(AsyncTanStackRouterDevtoolsPanelInProd, {
					isOpen: true,
					setIsOpen: (isOpen) => !isOpen && onClose()
				}) })
			]
		})
	});
}
/**
* The production build of DevTools is a lazy import only. The regular export
* is null in production.
*
* Using this import style lets us access the panel in production and review lab
*/
DevtoolsPanels.displayName = "DevtoolsPanels";
var AsyncReactQueryDevtoolsPanel = lazyWithPreload(async () => {
	return { default: (await import("@tanstack/react-query-devtools/build/modern/production.js")).ReactQueryDevtoolsPanel };
});
var AsyncTanStackRouterDevtoolsPanelInProd = lazyWithPreload(async () => {
	return { default: (await import("@tanstack/react-router-devtools")).TanStackRouterDevtoolsPanelInProd };
});
var perf_menu_module_default = {
	metricCode: "perf-menu-module_NJ_-PW_metricCode",
	metricLabel: "perf-menu-module_NJ_-PW_metricLabel"
};
function EnvironmentSection({ heading, environment, tone, versionRef, repo, onExitEnvironment }) {
	const shortRef = versionRef && versionRef.length > 7 ? versionRef.slice(0, 7) : versionRef;
	const repoUrl = versionRef ? `https://github.com/${repo}/tree/${versionRef}` : `https://github.com/${repo}`;
	return /* @__PURE__ */ jsxs(ActionList.Group, { children: [
		/* @__PURE__ */ jsxs(ActionList.GroupHeading, { children: [heading, /* @__PURE__ */ jsx(Label, {
			style: { marginLeft: "var(--base-size-16)" },
			variant: tone,
			children: environment
		})] }),
		/* @__PURE__ */ jsxs(ActionList.Item, {
			disabled: !versionRef,
			onSelect: () => {
				if (versionRef) navigator.clipboard.writeText(versionRef);
			},
			children: [/* @__PURE__ */ jsx("code", {
				className: perf_menu_module_default.metricCode,
				children: versionRef ?? "no ref available"
			}), /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(CopyIcon, { size: 16 }) })]
		}),
		onExitEnvironment && /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: onExitEnvironment,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(XIcon, { size: 16 }) }), `Exit ${environment}`]
		}),
		/* @__PURE__ */ jsxs(ActionList.LinkItem, {
			href: repoUrl,
			target: "_blank",
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(RepoIcon, { size: 16 }) }), /* @__PURE__ */ jsx("span", { children: shortRef ? `View ${repo} at ${shortRef}` : `View ${repo}` })]
		})
	] });
}
EnvironmentSection.displayName = "EnvironmentSection";
function useCanaryToggleMutation(t0) {
	const $ = c(2);
	const { path } = t0;
	let t1;
	if ($[0] !== path) {
		t1 = { mutationFn: async () => {
			if (!path) throw new Error("Canary toggle path is not defined");
			const response = await reactFetch(path, {
				method: "PATCH",
				redirect: "manual"
			});
			if (response.type === "opaqueredirect" || response.status === 0 || response.status >= 300 && response.status < 400) {
				const redirectTarget = response.headers.get("Location");
				if (redirectTarget) window.location.href = redirectTarget;
				else window.location.reload();
				return;
			}
			if (!response.ok) throw new Error(`Failed to toggle canary: ${response.status} "${response.statusText}"`);
		} };
		$[0] = path;
		$[1] = t1;
	} else t1 = $[1];
	return useMutation(t1);
}
function getInitialLcp() {
	const entries = performance.getEntriesByType("largest-contentful-paint");
	const last = entries[entries.length - 1];
	return last ? Math.round(last.startTime) : null;
}
function getInitialFcp() {
	const entry = performance.getEntriesByName("first-contentful-paint")[0];
	return entry ? Math.round(entry.startTime) : null;
}
function getInitialTtfb() {
	const nav = performance.getEntriesByType("navigation")[0];
	return nav?.responseStart ? Math.round(nav.responseStart) : null;
}
function MetricItem({ label, value, unit }) {
	const formatted = value != null ? `${value}${unit ?? ""}` : null;
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		disabled: formatted == null,
		onSelect: () => {
			if (formatted != null) navigator.clipboard.writeText(formatted);
		},
		children: [
			/* @__PURE__ */ jsxs("span", {
				className: perf_menu_module_default.metricLabel,
				children: [label, ":"]
			}),
			/* @__PURE__ */ jsx("code", {
				className: perf_menu_module_default.metricCode,
				children: formatted ?? "—"
			}),
			formatted != null && /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(CopyIcon, { size: 16 }) })
		]
	});
}
MetricItem.displayName = "MetricItem";
function PerfMenu() {
	const $ = c(13);
	const [lcp, setLcp] = useState(getInitialLcp);
	const [fcp, setFcp] = useState(getInitialFcp);
	const [ttfb, setTtfb] = useState(getInitialTtfb);
	const [cls, setCls] = useState(null);
	const [inp, setInp] = useState(null);
	const [hpc, setHpc] = useState(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (e) => e.detail.lcp != null && setLcp(Math.round(e.detail.lcp));
		$[0] = t0;
	} else t0 = $[0];
	useWebVitals("lcp", t0);
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (e_0) => e_0.detail.fcp != null && setFcp(Math.round(e_0.detail.fcp));
		$[1] = t1;
	} else t1 = $[1];
	useWebVitals("fcp", t1);
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (e_1) => e_1.detail.ttfb != null && setTtfb(Math.round(e_1.detail.ttfb));
		$[2] = t2;
	} else t2 = $[2];
	useWebVitals("ttfb", t2);
	let t3;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (e_2) => e_2.detail.cls != null && setCls(parseFloat(e_2.detail.cls.toFixed(4)));
		$[3] = t3;
	} else t3 = $[3];
	useWebVitals("cls", t3);
	let t4;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (e_3) => e_3.detail.inp != null && setInp(Math.round(e_3.detail.inp));
		$[4] = t4;
	} else t4 = $[4];
	useWebVitals("inp", t4);
	let t5;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = (e_4) => e_4.detail.hpc != null && setHpc(Math.round(e_4.detail.hpc));
		$[5] = t5;
	} else t5 = $[5];
	useWebVitals("hpc", t5);
	let t6;
	if ($[6] !== cls || $[7] !== fcp || $[8] !== hpc || $[9] !== inp || $[10] !== lcp || $[11] !== ttfb) {
		t6 = jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
			variant: "invisible",
			size: "small",
			leadingVisual: jsx(MeterIcon, {}),
			children: "Perf"
		}), jsx(ActionMenu.Overlay, {
			side: "outside-top",
			children: jsxs(ActionList, { children: [
				jsxs(ActionList.Group, { children: [
					jsx(ActionList.GroupHeading, { children: "Nav performance" }),
					jsx(MetricItem, {
						label: "LCP",
						value: lcp,
						unit: "ms"
					}),
					jsx(MetricItem, {
						label: "FCP",
						value: fcp,
						unit: "ms"
					}),
					jsx(MetricItem, {
						label: "TTFB",
						value: ttfb,
						unit: "ms"
					}),
					jsx(MetricItem, {
						label: "CLS",
						value: cls
					}),
					jsx(MetricItem, {
						label: "HPC",
						value: hpc,
						unit: "ms"
					})
				] }),
				jsx(ActionList.Divider, {}),
				jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, { children: "Interaction performance" }), jsx(MetricItem, {
					label: "INP",
					value: inp,
					unit: "ms"
				})] })
			] })
		})] });
		$[6] = cls;
		$[7] = fcp;
		$[8] = hpc;
		$[9] = inp;
		$[10] = lcp;
		$[11] = ttfb;
		$[12] = t6;
	} else t6 = $[12];
	return t6;
}
PerfMenu.displayName = "PerfMenu";
var staffbar_contents_module_default = {
	actionBar: "staffbar-contents-module_4l8jWq_actionBar",
	actionBarCollapsed: "staffbar-contents-module_4l8jWq_actionBarCollapsed",
	collapseButton: "staffbar-contents-module_4l8jWq_collapseButton",
	menuItems: "staffbar-contents-module_4l8jWq_menuItems",
	menuItemsCollapsed: "staffbar-contents-module_4l8jWq_menuItemsCollapsed",
	menuItemsExpanded: "staffbar-contents-module_4l8jWq_menuItemsExpanded",
	toneAccent: "staffbar-contents-module_4l8jWq_toneAccent",
	toneAttention: "staffbar-contents-module_4l8jWq_toneAttention",
	toneDanger: "staffbar-contents-module_4l8jWq_toneDanger",
	toneDone: "staffbar-contents-module_4l8jWq_toneDone",
	toneSevere: "staffbar-contents-module_4l8jWq_toneSevere"
};
function clearUiSha() {
	const url = new URL(window.location.href, window.location.origin);
	url.searchParams.delete("_ui_sha");
	url.searchParams.set("_clear_ui_sha", "true");
	updateSearchParams(url.searchParams);
	window.location.reload();
}
var apiEnvColors = {
	production: "default",
	"production:proxima": "accent",
	"production:enterprise": "accent",
	canary: "attention",
	lab: "severe",
	development: "danger",
	"development:proxima": "danger",
	"development:enterprise": "danger"
};
var uiEnvColors = {
	production: "default",
	"production:proxima": "accent",
	"production:enterprise": "accent",
	canary: "attention",
	preview: "done",
	development: "danger"
};
var labelUrgency = {
	default: 0,
	accent: 1,
	done: 2,
	attention: 3,
	severe: 4,
	danger: 5
};
var toneClass = {
	default: void 0,
	accent: staffbar_contents_module_default.toneAccent,
	done: staffbar_contents_module_default.toneDone,
	attention: staffbar_contents_module_default.toneAttention,
	severe: staffbar_contents_module_default.toneSevere,
	danger: staffbar_contents_module_default.toneDanger
};
/** Pick the most urgent tone from a list of tones. */
function mostUrgentTone(tones) {
	let result = "default";
	for (const t of tones) if (labelUrgency[t] > labelUrgency[result]) result = t;
	return result;
}
function StaffbarContents(t0) {
	const $ = c(22);
	const { apiEnvironment, apiVersionRef, uiEnvironment, uiVersionRef, canaryEnabled, canaryTogglePath } = t0;
	const [devtoolsOpen, setDevtoolsOpen] = useState(false);
	const [isExpanded, setIsExpanded] = useLocalStorage("staffbar-expanded", true);
	let t1;
	if ($[0] !== canaryTogglePath) {
		t1 = { path: canaryTogglePath };
		$[0] = canaryTogglePath;
		$[1] = t1;
	} else t1 = $[1];
	const canaryToggle = useCanaryToggleMutation(t1);
	let buildInfoTone;
	let t2;
	if ($[2] !== apiEnvironment || $[3] !== uiEnvironment) {
		buildInfoTone = mostUrgentTone([apiEnvColors[apiEnvironment], uiEnvColors[uiEnvironment]]);
		t2 = mostUrgentTone([buildInfoTone]);
		$[2] = apiEnvironment;
		$[3] = uiEnvironment;
		$[4] = buildInfoTone;
		$[5] = t2;
	} else {
		buildInfoTone = $[4];
		t2 = $[5];
	}
	const collapsedTone = t2;
	let t3;
	if ($[6] !== apiEnvironment || $[7] !== apiVersionRef || $[8] !== buildInfoTone || $[9] !== canaryEnabled || $[10] !== canaryToggle || $[11] !== canaryTogglePath || $[12] !== collapsedTone || $[13] !== devtoolsOpen || $[14] !== isExpanded || $[15] !== setIsExpanded || $[16] !== uiEnvironment || $[17] !== uiVersionRef) {
		let t4;
		if ($[19] !== setIsExpanded) {
			t4 = () => setIsExpanded(_temp);
			$[19] = setIsExpanded;
			$[20] = t4;
		} else t4 = $[20];
		let t5;
		if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
			t5 = () => setDevtoolsOpen(_temp2);
			$[21] = t5;
		} else t5 = $[21];
		t3 = jsxs(Fragment$1, { children: [jsxs(ActionBar, {
			"aria-label": "Staffbar tools",
			className: clsx(staffbar_module_default.staffbar, staffbar_contents_module_default.actionBar, !isExpanded && staffbar_contents_module_default.actionBarCollapsed),
			flush: true,
			gap: "none",
			children: [jsx(IconButton, {
				variant: "invisible",
				size: "small",
				"aria-label": isExpanded ? "Collapse staffbar" : "Expand staffbar",
				icon: isExpanded ? SidebarExpandIcon : SidebarCollapseIcon,
				tooltipDirection: "n",
				className: clsx(staffbar_contents_module_default.collapseButton, !isExpanded && toneClass[collapsedTone]),
				onClick: t4
			}), jsxs("div", {
				"aria-hidden": !isExpanded,
				className: clsx(staffbar_contents_module_default.menuItems, isExpanded ? staffbar_contents_module_default.menuItemsExpanded : staffbar_contents_module_default.menuItemsCollapsed),
				children: [
					jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
						variant: "invisible",
						size: "small",
						leadingVisual: jsx(ServerIcon, {}),
						className: toneClass[buildInfoTone],
						children: "Build info"
					}), jsx(ActionMenu.Overlay, {
						side: "outside-top",
						children: jsxs(ActionList, { children: [
							jsxs(ActionList.Item, {
								disabled: true,
								children: [jsx(ActionList.LeadingVisual, { children: jsx(SparklesFillIcon, {}) }), "This route was served by the UI service"]
							}),
							jsx(ActionList.Divider, {}),
							jsx(EnvironmentSection, {
								heading: "UI Service",
								environment: uiEnvironment,
								tone: uiEnvColors[uiEnvironment],
								versionRef: uiVersionRef,
								repo: "github/github-ui",
								onExitEnvironment: uiEnvironment === "preview" ? clearUiSha : void 0
							}),
							jsx(ActionList.Divider, {}),
							jsx(EnvironmentSection, {
								heading: "Rails API",
								environment: apiEnvironment,
								tone: apiEnvColors[apiEnvironment],
								versionRef: apiVersionRef,
								repo: "github/github"
							}),
							canaryTogglePath && jsxs(Fragment$1, { children: [jsx(ActionList.Divider, {}), jsxs(ActionList.Item, {
								onSelect: () => canaryToggle.mutate(),
								loading: canaryToggle.isPending,
								children: [jsx(ActionList.LeadingVisual, { children: jsx(BeakerIcon, { size: 16 }) }), jsx("span", { children: canaryEnabled ? "Opt out of canary" : "Opt in to canary" })]
							})] })
						] })
					})] }),
					jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
						variant: "invisible",
						size: "small",
						leadingVisual: jsx(GiftIcon, {}),
						children: "Product info"
					}), jsx(ActionMenu.Overlay, {
						side: "outside-top",
						children: jsxs(ActionList, { children: [jsx(ActionList.Item, {
							disabled: true,
							children: "Catalog owner: coming soon"
						}), jsxs(ActionList.LinkItem, {
							href: "https://github-grid.enterprise.slack.com/archives/C0848P38F6H",
							target: "_blank",
							rel: "noopener noreferrer",
							children: ["Give feedback in #ui-service", jsx(ActionList.TrailingVisual, { children: jsx(LinkExternalIcon, {}) })]
						})] })
					})] }),
					jsx(ButtonComponent, {
						variant: "invisible",
						size: "small",
						leadingVisual: jsx(ToolsIcon, {}),
						onClick: t5,
						children: "Dev tools"
					}),
					jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
						variant: "invisible",
						size: "small",
						leadingVisual: jsx(SlidersIcon, {}),
						children: "Admin"
					}), jsx(ActionMenu.Overlay, {
						side: "outside-top",
						children: jsxs(ActionList, { children: [jsxs(ActionList.LinkItem, {
							href: "/stafftools",
							children: ["Staff tools", jsx(ActionList.TrailingVisual, { children: jsx(LinkExternalIcon, {}) })]
						}), jsxs(ActionList.LinkItem, {
							href: "https://devportal.githubapp.com/",
							target: "_blank",
							children: ["Dev portal", jsx(ActionList.TrailingVisual, { children: jsx(LinkExternalIcon, {}) })]
						})] })
					})] }),
					jsx(PerfMenu, {})
				]
			})]
		}), devtoolsOpen && jsx(DevtoolsPanels, { onClose: () => setDevtoolsOpen(false) })] });
		$[6] = apiEnvironment;
		$[7] = apiVersionRef;
		$[8] = buildInfoTone;
		$[9] = canaryEnabled;
		$[10] = canaryToggle;
		$[11] = canaryTogglePath;
		$[12] = collapsedTone;
		$[13] = devtoolsOpen;
		$[14] = isExpanded;
		$[15] = setIsExpanded;
		$[16] = uiEnvironment;
		$[17] = uiVersionRef;
		$[18] = t3;
	} else t3 = $[18];
	return t3;
}
StaffbarContents.displayName = "StaffbarContents";
function _temp2(prev_0) {
	return !prev_0;
}
function _temp(prev) {
	return !prev;
}
export { StaffbarContents as default };
