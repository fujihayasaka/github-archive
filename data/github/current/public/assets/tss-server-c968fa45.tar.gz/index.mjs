globalThis.__nitro_main__ = import.meta.url;
import { n as node_server_default } from "./server-nitro-eHvVNdaa.js";
export { node_server_default as default };
