performance.mark("js-parse-end:server-_tanstack-start-manifest_v-DxrxO1NV-Dfhb9eC4.js");
performance.mark("js-parse-end:_tanstack-start-manifest_v-DxrxO1NV.js");
var tsrStartManifest = () => ({
	"routes": {
		"__root__": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/root.tsx",
			"children": [
				"/_nav",
				"/healthcheck",
				"/ui/version"
			],
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/main-D0KdNlO7.js"]
		},
		"/_nav": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/global-nav-layout.tsx",
			"children": [
				"/_nav/_pulls_layout",
				"/_nav/_react_sandbox_future",
				"/_nav/_repos_layout",
				"/_nav/$owner/$repo/_repo_layout"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/global-nav-layout-DXWYZGDv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/staffbar-C9lNBvIr.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/global-nav-layout-DCYEdt2a.js",
				"https://github.githubassets.com/assets/copilot-local-storage-BmIJ5Zdi.js",
				"https://github.githubassets.com/assets/connect-alive-subscription-DViOxzKE.js",
				"https://github.githubassets.com/assets/Avatar-NNcKR6pj.js",
				"https://github.githubassets.com/assets/ButtonGroup-Brsvojg2.js",
				"https://github.githubassets.com/assets/useQuery-hy49gECq.js",
				"https://github.githubassets.com/assets/create-safe-indexed-db-storage-ChPX8zdl.js",
				"https://github.githubassets.com/assets/immer-B674F3WE.js",
				"https://github.githubassets.com/assets/typebox-wxYylyEs.js",
				"https://github.githubassets.com/assets/cookies-CF80j-p_.js",
				"https://github.githubassets.com/assets/copilot-auth-token-BabUlGpP.js",
				"https://github.githubassets.com/assets/copilot-chat-events-CXqsQJJ1.js",
				"https://github.githubassets.com/assets/copilot-chat-helpers-D0s1GbKD.js",
				"https://github.githubassets.com/assets/GitHubAvatar-BKq_94Hk.js",
				"https://github.githubassets.com/assets/global-navigation-D7kzuFAs.js",
				"https://github.githubassets.com/assets/constants-BqajxRW5.js",
				"https://github.githubassets.com/assets/constants-BThHgcqt.js",
				"https://github.githubassets.com/assets/LazyGlobalSsoBanner-D7g3c_4v.js",
				"https://github.githubassets.com/assets/CoreSsoBanner-DCLvq7yf.js",
				"https://github.githubassets.com/assets/in-product-targeting-BcuIT6Ad.js",
				"https://github.githubassets.com/assets/IncludeFragment-BvuEMK8t.js",
				"https://github.githubassets.com/assets/ItemPicker-CoCsO0Zp.js",
				"https://github.githubassets.com/assets/strings-FChYwouP.js",
				"https://github.githubassets.com/assets/NavigableRef-PxhjRtSH.js",
				"https://github.githubassets.com/assets/CustomIcon-CMYse4c1.js",
				"https://github.githubassets.com/assets/ErrorBoundary-BZdkCUOb.js",
				"https://github.githubassets.com/assets/Link-Pur7V-h-.js",
				"https://github.githubassets.com/assets/lazy-with-preload-DTvGezXl.js",
				"https://github.githubassets.com/assets/react-partial-anchor-0e9KJZMw.js",
				"https://github.githubassets.com/assets/react-query-persister-BIIaHANC.js",
				"https://github.githubassets.com/assets/staffbar.module-y8m2bGwL.js",
				"https://github.githubassets.com/assets/use-route-query-BE2Njw3g.js",
				"https://github.githubassets.com/assets/use-alive-DetR2k0K.js",
				"https://github.githubassets.com/assets/use-is-mounted-muiLYRfp.js"
			]
		},
		"/_nav/_pulls_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/layout.tsx",
			"children": ["/_nav/_pulls_layout/pulls"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-DJFcgZlv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposSelector-DzcPtoeR.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/UserFeedback-TRB_fcnh.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-BUuZUSQy.js",
				"https://github.githubassets.com/assets/react-relay-C8JwdlUg.js",
				"https://github.githubassets.com/assets/dashboard-types-Hq7_1uL2.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/PageLayout-CdyWvqmG.js",
				"https://github.githubassets.com/assets/Filter-BrWDuiiF.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-CPWgvLPe.js",
				"https://github.githubassets.com/assets/use-user-CS5PmvdZ.js",
				"https://github.githubassets.com/assets/PreviewCard-D-Wm7HVD.js",
				"https://github.githubassets.com/assets/ReposSelector-DX-cEiki.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-CevqDrZt.js",
				"https://github.githubassets.com/assets/use-app-payload-C5iGDpE5.js",
				"https://github.githubassets.com/assets/use-stable-random-CpKSlHmw.js",
				"https://github.githubassets.com/assets/UserFeedback-Bsw5s649.js"
			]
		},
		"/_nav/_react_sandbox_future": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-layout.tsx",
			"children": ["/_nav/_react_sandbox_future/react_sandbox_future/", "/_nav/_react_sandbox_future/react_sandbox_future/$id"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/react-sandbox-future-layout-CA3XD2Yu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-layout-C3MazNRg.js", "https://github.githubassets.com/assets/PageLayout-CdyWvqmG.js"]
		},
		"/_nav/_repos_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/layout.tsx",
			"children": ["/_nav/_repos_layout/repos"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-BYQps9c3.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-DEZJE0cK.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/PageLayout-CdyWvqmG.js",
				"https://github.githubassets.com/assets/Filter-BrWDuiiF.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-CPWgvLPe.js",
				"https://github.githubassets.com/assets/use-feature-flag-CWKYRLOC.js",
				"https://github.githubassets.com/assets/ReposFinderStateContext-CMRlSILQ.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-CevqDrZt.js",
				"https://github.githubassets.com/assets/use-app-payload-C5iGDpE5.js",
				"https://github.githubassets.com/assets/use-stable-random-CpKSlHmw.js"
			]
		},
		"/_nav/_pulls_layout/pulls": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/pulls-DyzpB9ty.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelToken-Cj_rz1dY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/pulls-0VGme-rc.js",
				"https://github.githubassets.com/assets/Pagination-DnPxnhyO.js",
				"https://github.githubassets.com/assets/LabelToken-1WCX_h6a.js",
				"https://github.githubassets.com/assets/use-get-hovercard-attributes-for-type-DP_7dUJC.js",
				"https://github.githubassets.com/assets/Icons-Cux5h6gr.js",
				"https://github.githubassets.com/assets/ProfileReference-CUduPI6a.js"
			]
		},
		"/_nav/_repos_layout/repos": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/repos-BgfE7IYM.js", "https://github.githubassets.com/assets/Pagination-DnPxnhyO.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-index.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-index-50ly2tsX.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/$id": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-id.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-id-CxU6bmVq.js"]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScrollMarksContainer-jgZd6-5D.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-4N5EWOcV.js",
				"https://github.githubassets.com/assets/PageLayout-CdyWvqmG.js",
				"https://github.githubassets.com/assets/TreeView-BiEThOQW.js",
				"https://github.githubassets.com/assets/SkeletonText-WlW2Nhxj.js",
				"https://github.githubassets.com/assets/use-is-data-router-enabled-CzCxvcNg.js",
				"https://github.githubassets.com/assets/repos-file-tree-view-D6Q4rMZQ.js",
				"https://github.githubassets.com/assets/CodeLine-Cfqh4dfm.js",
				"https://github.githubassets.com/assets/AllShortcutsEnabled-DvehAhAV.js",
				"https://github.githubassets.com/assets/HiddenUnicodeCharacter-DRkWGUDF.js",
				"https://github.githubassets.com/assets/ReposHeaderRefSelector-HH8Bs0V0.js",
				"https://github.githubassets.com/assets/FileResultsList-4-nF9kec.js",
				"https://github.githubassets.com/assets/CodeViewBannersContext-C2AecuK6.js",
				"https://github.githubassets.com/assets/CopilotSettingsContext-COiSjplY.js",
				"https://github.githubassets.com/assets/EditPermissionsContext-BWGHymqA.js",
				"https://github.githubassets.com/assets/find-file-BTgl2MZG.js",
				"https://github.githubassets.com/assets/FilesPageInfoContext-DBlyxxjQ.js",
				"https://github.githubassets.com/assets/CodeViewOptionsProvider-BHtGa8Dg.js",
				"https://github.githubassets.com/assets/CodeNavSymbolNavigation-BxR5IM2X.js",
				"https://github.githubassets.com/assets/ScrollMarksContainer-Db1G320L.js",
				"https://github.githubassets.com/assets/CodeNavContext-DOWweg-F.js",
				"https://github.githubassets.com/assets/TreePaneContext-CTrf48Bf.js",
				"https://github.githubassets.com/assets/ExpandButton-BWFmRON3.js",
				"https://github.githubassets.com/assets/history-Syz5IHfp.js",
				"https://github.githubassets.com/assets/NewAgentTaskButton-CJvILI81.js",
				"https://github.githubassets.com/assets/react-observable-CwUYr4uD.js",
				"https://github.githubassets.com/assets/PortalTooltip-DtHuwgEU.js",
				"https://github.githubassets.com/assets/use-route-payload-BkXV3UOC.js",
				"https://github.githubassets.com/assets/RefSelector-cysL6Sc3.js",
				"https://github.githubassets.com/assets/ScreenSize-D3Iq5UZE.js",
				"https://github.githubassets.com/assets/use-app-payload-C5iGDpE5.js",
				"https://github.githubassets.com/assets/use-file-tree-tooltip-lfZayek5.js",
				"https://github.githubassets.com/assets/use-is-platform-BxE2UeBn.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/repo-overview.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/repo-overview-MS_-C4jl.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-RxELdaaH.js",
				"https://github.githubassets.com/assets/CircleOcticon-C_Hbm5Io.js",
				"https://github.githubassets.com/assets/use-codespaces-data-B-E4Om4Y.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-De8-ZReL.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-afyx31r5.js",
				"https://github.githubassets.com/assets/PublishBanners-CQhIRzM_.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CGLO2kGh.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/SharedPageLayout-DNLD_ZEI.js",
				"https://github.githubassets.com/assets/commit-checks-status-BELxSTmj.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-ClpZKz6B.js",
				"https://github.githubassets.com/assets/ProfileReference-CUduPI6a.js",
				"https://github.githubassets.com/assets/use-page-data-url-B2HbICo2.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-CbvRoKj3.js",
				"https://github.githubassets.com/assets/use-latest-commit-BzHaTB5o.js",
				"https://github.githubassets.com/assets/use-web-vitals-BAvPWRF3.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/file-tree-layout.tsx",
			"children": [
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/file-tree-layout-B2kVSyVy.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/file-tree-layout-BKeEjnvD.js",
				"https://github.githubassets.com/assets/overview-types-iJX8LBpY.js",
				"https://github.githubassets.com/assets/SharedPageLayout-DNLD_ZEI.js",
				"https://github.githubassets.com/assets/use-hide-footer-DJ99GMdG.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob-layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-layout-BLiFi32L.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-afyx31r5.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CGLO2kGh.js",
				"https://github.githubassets.com/assets/NavigationMenu-DyjkfhT_.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-0QmaN2Fn.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-ClpZKz6B.js",
				"https://github.githubassets.com/assets/Breadcrumb-xhvnva5M.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-CbvRoKj3.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/delete-BLxGNGq3.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-afyx31r5.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/NavigationMenu-DyjkfhT_.js",
				"https://github.githubassets.com/assets/EditIssues-CKAPhNRh.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CpMuJwhc.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-0QmaN2Fn.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-ClpZKz6B.js",
				"https://github.githubassets.com/assets/diff-parts-BZEqDpVm.js",
				"https://github.githubassets.com/assets/Breadcrumb-xhvnva5M.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-CbvRoKj3.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/edit.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/edit-DNty5gNz.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/CodeViewEditor-CHAswWUl.js",
				"https://github.githubassets.com/assets/SuspenseFallback-Bub7diuY.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/new.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/new-DVpN6K__.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/CodeViewEditor-CHAswWUl.js",
				"https://github.githubassets.com/assets/SuspenseFallback-Bub7diuY.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/tree-CEjCnYpa.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-MIK2C_P-.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-RxELdaaH.js",
				"https://github.githubassets.com/assets/CircleOcticon-C_Hbm5Io.js",
				"https://github.githubassets.com/assets/use-codespaces-data-B-E4Om4Y.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-De8-ZReL.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-afyx31r5.js",
				"https://github.githubassets.com/assets/PublishBanners-CQhIRzM_.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CGLO2kGh.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/NavigationMenu-DyjkfhT_.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BWrvBOKt.js",
				"https://github.githubassets.com/assets/Panel-C4YgHGlZ.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-0QmaN2Fn.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js",
				"https://github.githubassets.com/assets/commit-checks-status-BELxSTmj.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-ClpZKz6B.js",
				"https://github.githubassets.com/assets/BetaLabel-B4X2TMN4.js",
				"https://github.githubassets.com/assets/LabelWithLink-CPTORDit.js",
				"https://github.githubassets.com/assets/ProfileReference-CUduPI6a.js",
				"https://github.githubassets.com/assets/use-page-data-url-B2HbICo2.js",
				"https://github.githubassets.com/assets/Breadcrumb-xhvnva5M.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-CbvRoKj3.js",
				"https://github.githubassets.com/assets/use-latest-commit-BzHaTB5o.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BA96DAJj.js",
				"https://github.githubassets.com/assets/use-web-vitals-BAvPWRF3.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blame.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blame-CALKBXjm.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/BlobViewContent-DOKrF-sY.js",
				"https://github.githubassets.com/assets/PublishBanners-CQhIRzM_.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BWrvBOKt.js",
				"https://github.githubassets.com/assets/Panel-C4YgHGlZ.js",
				"https://github.githubassets.com/assets/SuspenseFallback-Bub7diuY.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js",
				"https://github.githubassets.com/assets/commit-checks-status-BELxSTmj.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-dXCCUMJB.js",
				"https://github.githubassets.com/assets/CopilotPopover-DIU4It81.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-CpjahQjg.js",
				"https://github.githubassets.com/assets/FeatureRequest-C9W6RneJ.js",
				"https://github.githubassets.com/assets/BetaLabel-B4X2TMN4.js",
				"https://github.githubassets.com/assets/LabelWithLink-CPTORDit.js",
				"https://github.githubassets.com/assets/ProfileReference-CUduPI6a.js",
				"https://github.githubassets.com/assets/use-feature-flag-CWKYRLOC.js",
				"https://github.githubassets.com/assets/use-contributors-DwhEnxor.js",
				"https://github.githubassets.com/assets/use-latest-commit-BzHaTB5o.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BA96DAJj.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-BK4p42Fv.js",
				"https://github.githubassets.com/assets/AvatarStack-LUrnNOnY.js",
				"https://github.githubassets.com/assets/BlobViewContent-DOKrF-sY.js",
				"https://github.githubassets.com/assets/PublishBanners-CQhIRzM_.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/CodeViewBanners-BWrvBOKt.js",
				"https://github.githubassets.com/assets/Panel-C4YgHGlZ.js",
				"https://github.githubassets.com/assets/SuspenseFallback-Bub7diuY.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js",
				"https://github.githubassets.com/assets/commit-checks-status-BELxSTmj.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-dXCCUMJB.js",
				"https://github.githubassets.com/assets/CopilotPopover-DIU4It81.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-CpjahQjg.js",
				"https://github.githubassets.com/assets/FeatureRequest-C9W6RneJ.js",
				"https://github.githubassets.com/assets/BetaLabel-B4X2TMN4.js",
				"https://github.githubassets.com/assets/LabelWithLink-CPTORDit.js",
				"https://github.githubassets.com/assets/ProfileReference-CUduPI6a.js",
				"https://github.githubassets.com/assets/use-feature-flag-CWKYRLOC.js",
				"https://github.githubassets.com/assets/use-contributors-DwhEnxor.js",
				"https://github.githubassets.com/assets/use-latest-commit-BzHaTB5o.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BA96DAJj.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree-delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-delete-Rn0waVOb.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-afyx31r5.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-hpoq0L6H.js",
				"https://github.githubassets.com/assets/NavigationMenu-DyjkfhT_.js",
				"https://github.githubassets.com/assets/EditIssues-CKAPhNRh.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CpMuJwhc.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-Du5wSmr3.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-0QmaN2Fn.js",
				"https://github.githubassets.com/assets/CodeView-DRu7nzOl.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-ClpZKz6B.js",
				"https://github.githubassets.com/assets/diff-parts-BZEqDpVm.js",
				"https://github.githubassets.com/assets/Breadcrumb-xhvnva5M.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-CbvRoKj3.js"
			]
		}
	},
	"clientEntry": "https://github.githubassets.com/assets/main-D0KdNlO7.js"
});
export { tsrStartManifest };
