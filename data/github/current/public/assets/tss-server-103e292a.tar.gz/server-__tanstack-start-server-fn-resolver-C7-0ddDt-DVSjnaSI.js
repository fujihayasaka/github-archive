var manifest = {
	"3e67a847c1db09f01c56541acdb4c043f45b7b244cc33e6b6fb6f26b114156df": {
		functionName: "pullsLayoutServerFn_createServerFn_handler",
		importer: () => import("./server-layout-C5NsFauo-Bcyo9dih.js")
	},
	"311f5ad21c11f471b5aa30726222748ccf67f7812e97330a0371cfccb7db5b1d": {
		functionName: "reposIndexServerFn_createServerFn_handler",
		importer: () => import("./server-repos-iytMuOCN-Cn_NtVvG.js")
	},
	"180951b37fb889ea2e493ea1bafe7f5ab5f986463ee4bb5efb952295c78c841d": {
		functionName: "pullsIndexServerFn_createServerFn_handler",
		importer: () => import("./server-pulls-BuZP-j0g-Dd96NwAu.js")
	},
	"794b44b5a606c614b0fdffa923edd1b2e81d253620199a4f9c920ed8b2abf094": {
		functionName: "pullsIndexDeferredServerFn_createServerFn_handler",
		importer: () => import("./server-pulls-BuZP-j0g-Dd96NwAu.js")
	},
	"a64794e92b23f483ccd07044c4f01cab0f6dfdc92540bdffa335bb2ae630e5a0": {
		functionName: "idLoader_createServerFn_handler",
		importer: () => import("./server-react-sandbox-future-id-Bd-i_VHU-ys6Z1Tk8.js")
	},
	"ad0a48c2e16c9d6dc580cf6e1f28842ad0acd3d852e622e196513c14d28b6462": {
		functionName: "codeViewTreeServerFn_createServerFn_handler",
		importer: () => import("./server-tree-BtNOExGF-Cdj2tTla.js")
	},
	"114d5388eb2fca2a18c6c57a9d2b1ab96be2fc0e35d9bde5632d3e85f658dcf2": {
		functionName: "codeViewBlameServerFn_createServerFn_handler",
		importer: () => import("./server-blame-YlGLOaEO-BTd4YQMo.js")
	},
	"54cf7fcad24fb13d72cc3a43b3d405c09019149320a1716f6dbbc03c570651e7": {
		functionName: "contributorsServerFn_createServerFn_handler",
		importer: () => import("./server-blame-YlGLOaEO-BTd4YQMo.js")
	},
	"97b2c57eea454ae235ed19f793122279887e262457fa282a73f7366119742801": {
		functionName: "globalNavLayoutLoader_createServerFn_handler",
		importer: () => import("./server-global-nav-layout-DMZ_GYbh-hCdarT7M.js")
	},
	"4049c22acbc78625404fbadcb7664ccb9e28a38a67961cbf52184858fa8188b8": {
		functionName: "reposLayoutServerFn_createServerFn_handler",
		importer: () => import("./server-layout-CWQJp43k-uUp9-nxf.js")
	},
	"485aab9949f91d6ded9cd342ed5bbfe78020f1699252653dea689a9897608303": {
		functionName: "codeViewNewServerFn_createServerFn_handler",
		importer: () => import("./server-new-a1sasIHx-DTIvzQ25.js")
	},
	"76837b393b559363a9cd378daa2414bc95808736e1245f9fb3a38db41a020fb5": {
		functionName: "layoutLoader_createServerFn_handler",
		importer: () => import("./server-react-sandbox-future-layout-Biq2FIBv-Ds937t87.js")
	},
	"a07e5a1811e99c52a112dcf349e8057d914dd5e979710806dce91e8db540ec44": {
		functionName: "indexLoader_createServerFn_handler",
		importer: () => import("./server-react-sandbox-future-index-BvPz6tj5-nGCL01KQ.js")
	},
	"49ebf714316715b57e796c434675bccb1d1f4fe6328a00e55a409ab6fe3d1933": {
		functionName: "codeViewTreeDeleteServerFn_createServerFn_handler",
		importer: () => import("./server-tree-delete-CXmAfLPs-CdwfaJTq.js")
	},
	"93143f62fd7abef2b06e315700aa1d9d03a0b62a785fe928a82638f4879af70a": {
		functionName: "codeViewBlobServerFn_createServerFn_handler",
		importer: () => import("./server-blob-BZ3Z5N8V-C1ZyIB3V.js")
	},
	"0171e77204682a42c63d8f4aabb2374f77edfad4696d22265c4d82b119aeb6cf": {
		functionName: "codeViewEditServerFn_createServerFn_handler",
		importer: () => import("./server-edit-z1-6nKRo-DkiVYR6-.js")
	},
	"b675b2614abc8b6e4bf1724b1e67a55a35682e23fb9ce0522bd2075187e4566a": {
		functionName: "codeViewLayoutServerFn_createServerFn_handler",
		importer: () => import("./server-layout-rpRdFgpE-D_C71xQP.js")
	},
	"8a17754e5d26e19e0c86f0f44a9d847ecc33a7285eb228ef9c1b69805a32feee": {
		functionName: "codeViewDeleteServerFn_createServerFn_handler",
		importer: () => import("./server-delete-DXDfzzHp-BIlWS5L0.js")
	},
	"c83dfe310299fc5ef2a93f49a7327eabe3cf9dedae2230f9a88bf953a13368cb": {
		functionName: "codeViewBlobLayoutServerFn_createServerFn_handler",
		importer: () => import("./server-blob-layout-Cahhi3Zs-QsRvXK_y.js")
	},
	"8504c6d56c3efae37bf79d9b8c60c5a14489f3720fd612aa3cb53417d9f5a9da": {
		functionName: "codeViewBlobLayoutStyledBlobServerFn_createServerFn_handler",
		importer: () => import("./server-blob-layout-Cahhi3Zs-QsRvXK_y.js")
	},
	"140174379d70ac1fb8fe0e39cc460887e8bbb07eb0ae1ce7e2488ed81b793b6f": {
		functionName: "deferredMetadataServerFn_createServerFn_handler",
		importer: () => import("./server-blob-layout-Cahhi3Zs-QsRvXK_y.js")
	},
	"694f3736e0b5f75f6cc2581eab05ece8a1ffe21b38dcd1f6a5e06fb6915e3cfe": {
		functionName: "codeViewFileTreeLayoutServerFn_createServerFn_handler",
		importer: () => import("./server-file-tree-layout-BYKg68WU-CJiUUAeo.js")
	},
	"5570a6dfaea5b5a8291c280a1b6bf2d11d3943232fdcb95f6ef940f99f19a782": {
		functionName: "codeViewRepoOverviewServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"11ecefba7033308c84e7125a569cd4e43612780a5a95ae1b856cf272e4dc792f": {
		functionName: "headerPartialServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"7f955aae96327dca072e229ce256f7a4e6ffe65004b0cbf55e83efea5d9f703e": {
		functionName: "sidebarPartialServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"209ee1152b7c97b2cb4358ec3ed1101afbfb79eb8d7415a7869d6e9ccacb308f": {
		functionName: "recentlyTouchedBranchesServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"02b53bedb79ffba7123f46f6683fd076943a6c59c1fbc50fb98f29e4762fdce5": {
		functionName: "branchAndTagCountServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"ede11af01410f853c6f30f37d655e27965917c49dbbfa223a0a0f02152b2112c": {
		functionName: "aboutQueryServerFn_createServerFn_handler",
		importer: () => import("./server-repo-overview-CO-iH8G4-CeTaMz_z.js")
	},
	"c095f5f847e3e9e85a9cdbf02c3a0a9306f74ec8da2d4181dc43a5b337a1716b": {
		functionName: "latestCommitServerFn_createServerFn_handler",
		importer: () => import("./server-latest-commit-query-DsvYyfXy-Dx-XjV7R.js")
	},
	"1900fd1372f2c4547c9dabe0cb6c502a5f5cba01a8e66c69a6397b1bad093695": {
		functionName: "treeCommitInfoServerFn_createServerFn_handler",
		importer: () => import("./server-tree-commit-info-query-orC2iX5H--IOITR6H.js")
	}
};
async function getServerFnById(id) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = await serverFnInfo.importer();
	if (!fnModule) {
		console.info("serverFnInfo", serverFnInfo);
		throw new Error("Server function module not resolved for " + id);
	}
	const action = fnModule[serverFnInfo.functionName];
	if (!action) {
		console.info("serverFnInfo", serverFnInfo);
		console.info("fnModule", fnModule);
		throw new Error(`Server function module export not resolved for serverFn ID: ${id}`);
	}
	return action;
}
export { getServerFnById as t };
