performance.mark("js-parse-end:server-_tanstack-start-manifest_v-Dg1SJYd3-BAyx9kbJ.js");
performance.mark("js-parse-end:_tanstack-start-manifest_v-Dg1SJYd3.js");
var tsrStartManifest = () => ({
	"routes": {
		"__root__": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/root.tsx",
			"children": [
				"/_nav",
				"/healthcheck",
				"/ui/version"
			],
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/main-E2ZqskIP.js"]
		},
		"/_nav": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/global-nav-layout.tsx",
			"children": [
				"/_nav/_pulls_layout",
				"/_nav/_react_sandbox_future",
				"/_nav/_repos_layout",
				"/_nav/$owner/$repo/_repo_layout"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/global-nav-layout-DXWYZGDv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/staffbar-C9lNBvIr.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/global-nav-layout-UY3Gr55t.js",
				"https://github.githubassets.com/assets/copilot-local-storage-Cwnay_Vl.js",
				"https://github.githubassets.com/assets/connect-alive-subscription-Dn4p17qT.js",
				"https://github.githubassets.com/assets/Avatar-B5_Z0ns-.js",
				"https://github.githubassets.com/assets/ButtonGroup-g1g2TsW1.js",
				"https://github.githubassets.com/assets/useQuery-B0Sn6p1t.js",
				"https://github.githubassets.com/assets/create-safe-indexed-db-storage-raUBfKuT.js",
				"https://github.githubassets.com/assets/immer-B674F3WE.js",
				"https://github.githubassets.com/assets/typebox-D28siLWR.js",
				"https://github.githubassets.com/assets/cookies-CF80j-p_.js",
				"https://github.githubassets.com/assets/copilot-auth-token-CQ0Q1nAq.js",
				"https://github.githubassets.com/assets/copilot-chat-events-CXqsQJJ1.js",
				"https://github.githubassets.com/assets/copilot-chat-helpers-Lx4irqMz.js",
				"https://github.githubassets.com/assets/GitHubAvatar-DzOfFadb.js",
				"https://github.githubassets.com/assets/global-navigation-D7kzuFAs.js",
				"https://github.githubassets.com/assets/constants-D8lvKrod.js",
				"https://github.githubassets.com/assets/constants-BThHgcqt.js",
				"https://github.githubassets.com/assets/LazyGlobalSsoBanner-D_tlU_Rx.js",
				"https://github.githubassets.com/assets/CoreSsoBanner-CtHhzJND.js",
				"https://github.githubassets.com/assets/in-product-targeting-CawWNlkS.js",
				"https://github.githubassets.com/assets/IncludeFragment-BYeklJ4m.js",
				"https://github.githubassets.com/assets/ItemPicker-Bdhjv200.js",
				"https://github.githubassets.com/assets/strings-DTI963Pd.js",
				"https://github.githubassets.com/assets/NavigableRef-ZFxLALHg.js",
				"https://github.githubassets.com/assets/CustomIcon-CC8IPhtZ.js",
				"https://github.githubassets.com/assets/ErrorBoundary-D3ExtHIx.js",
				"https://github.githubassets.com/assets/Link-Pur7V-h-.js",
				"https://github.githubassets.com/assets/lazy-with-preload-eTCVcETj.js",
				"https://github.githubassets.com/assets/react-partial-anchor-BtVyKzzZ.js",
				"https://github.githubassets.com/assets/react-query-persister-pqbjgcRX.js",
				"https://github.githubassets.com/assets/staffbar.module-y8m2bGwL.js",
				"https://github.githubassets.com/assets/use-route-query-CNmxx09_.js",
				"https://github.githubassets.com/assets/use-alive-u-OOpjrx.js",
				"https://github.githubassets.com/assets/use-is-mounted-Cy46ddQw.js"
			]
		},
		"/_nav/_pulls_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/layout.tsx",
			"children": ["/_nav/_pulls_layout/pulls"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-DJFcgZlv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposSelector-DzcPtoeR.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/UserFeedback-TRB_fcnh.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-D6x0KmVz.js",
				"https://github.githubassets.com/assets/react-relay-Mj_DqWmq.js",
				"https://github.githubassets.com/assets/dashboard-types-BQIj1lq_.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/PageLayout-Bq6jlQk0.js",
				"https://github.githubassets.com/assets/Filter-9QFFaqTo.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-DIKUfFvV.js",
				"https://github.githubassets.com/assets/use-user-WJyWisvX.js",
				"https://github.githubassets.com/assets/PreviewCard-a62REjW4.js",
				"https://github.githubassets.com/assets/ReposSelector-uWLsDSBl.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-D0g8uGRz.js",
				"https://github.githubassets.com/assets/use-app-payload-BhLZdagC.js",
				"https://github.githubassets.com/assets/use-stable-random-CiT6LZQ_.js",
				"https://github.githubassets.com/assets/UserFeedback-BCpcXEZr.js"
			]
		},
		"/_nav/_react_sandbox_future": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-layout.tsx",
			"children": ["/_nav/_react_sandbox_future/react_sandbox_future/", "/_nav/_react_sandbox_future/react_sandbox_future/$id"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/react-sandbox-future-layout-CA3XD2Yu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-layout-D3KkxhkM.js", "https://github.githubassets.com/assets/PageLayout-Bq6jlQk0.js"]
		},
		"/_nav/_repos_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/layout.tsx",
			"children": ["/_nav/_repos_layout/repos"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-BYQps9c3.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-CQikqchu.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/PageLayout-Bq6jlQk0.js",
				"https://github.githubassets.com/assets/Filter-9QFFaqTo.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-DIKUfFvV.js",
				"https://github.githubassets.com/assets/use-feature-flag-B4bfdsuz.js",
				"https://github.githubassets.com/assets/ReposFinderStateContext-kowJ5Cfg.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-D0g8uGRz.js",
				"https://github.githubassets.com/assets/use-app-payload-BhLZdagC.js",
				"https://github.githubassets.com/assets/use-stable-random-CiT6LZQ_.js"
			]
		},
		"/_nav/_pulls_layout/pulls": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/pulls-DyzpB9ty.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelToken-Cj_rz1dY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/pulls-De1GGSyM.js",
				"https://github.githubassets.com/assets/Pagination-Duoixixz.js",
				"https://github.githubassets.com/assets/LabelToken-Cu8nVXQy.js",
				"https://github.githubassets.com/assets/use-get-hovercard-attributes-for-type-DU8AgzQB.js",
				"https://github.githubassets.com/assets/Icons-DzVWj5tX.js",
				"https://github.githubassets.com/assets/ProfileReference-CZ7Di_kc.js"
			]
		},
		"/_nav/_repos_layout/repos": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/repos-DkoFHzV-.js", "https://github.githubassets.com/assets/Pagination-Duoixixz.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-index.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-index-A_okpEj7.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/$id": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-id.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-id-CSd2VERs.js"]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScrollMarksContainer-jgZd6-5D.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-bPKaopkF.js",
				"https://github.githubassets.com/assets/PageLayout-Bq6jlQk0.js",
				"https://github.githubassets.com/assets/TreeView-BNZaBPDc.js",
				"https://github.githubassets.com/assets/SkeletonText-DaOvieqt.js",
				"https://github.githubassets.com/assets/use-is-data-router-enabled-BbjX8pOr.js",
				"https://github.githubassets.com/assets/repos-file-tree-view-Du10JZdc.js",
				"https://github.githubassets.com/assets/CodeLine-BINGKpXY.js",
				"https://github.githubassets.com/assets/AllShortcutsEnabled-DYeosGdc.js",
				"https://github.githubassets.com/assets/HiddenUnicodeCharacter-ihwK0dp_.js",
				"https://github.githubassets.com/assets/ReposHeaderRefSelector-Ceg7qpgL.js",
				"https://github.githubassets.com/assets/FileResultsList-zejoyR4z.js",
				"https://github.githubassets.com/assets/CodeViewBannersContext-C7ywMeAR.js",
				"https://github.githubassets.com/assets/CopilotSettingsContext-BYbLVBjf.js",
				"https://github.githubassets.com/assets/EditPermissionsContext-CDLRyWgl.js",
				"https://github.githubassets.com/assets/find-file-DyW4wAgm.js",
				"https://github.githubassets.com/assets/FilesPageInfoContext-BllAXmQi.js",
				"https://github.githubassets.com/assets/CodeViewOptionsProvider-C2XSXAsn.js",
				"https://github.githubassets.com/assets/CodeNavSymbolNavigation-CnxXUHQ2.js",
				"https://github.githubassets.com/assets/ScrollMarksContainer-Dq_5GALz.js",
				"https://github.githubassets.com/assets/CodeNavContext-5VzSd7Jy.js",
				"https://github.githubassets.com/assets/TreePaneContext-C2iPlLCU.js",
				"https://github.githubassets.com/assets/ExpandButton-CQ_EdNhH.js",
				"https://github.githubassets.com/assets/history-B1mjOWOv.js",
				"https://github.githubassets.com/assets/NewAgentTaskButton-BE_p_1w0.js",
				"https://github.githubassets.com/assets/react-observable-3TiKZ-IK.js",
				"https://github.githubassets.com/assets/PortalTooltip-DxAdy2ep.js",
				"https://github.githubassets.com/assets/use-route-payload-BY6q_vxK.js",
				"https://github.githubassets.com/assets/RefSelector-DZZMyFSb.js",
				"https://github.githubassets.com/assets/ScreenSize-Bfq5pGIA.js",
				"https://github.githubassets.com/assets/use-app-payload-BhLZdagC.js",
				"https://github.githubassets.com/assets/use-file-tree-tooltip-DNP5oe6R.js",
				"https://github.githubassets.com/assets/use-is-platform-BnOHYs3g.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/repo-overview.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/repo-overview-B51qSOQ6.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-CIUNAsfH.js",
				"https://github.githubassets.com/assets/CircleOcticon-COGcDcGq.js",
				"https://github.githubassets.com/assets/use-codespaces-data-DCVzVRRH.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-CmDzgVzQ.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-BJTngiK9.js",
				"https://github.githubassets.com/assets/PublishBanners-BEpO2leI.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CEKCjCMh.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/SharedPageLayout-B0QICwiq.js",
				"https://github.githubassets.com/assets/commit-checks-status-D218Ds48.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-BxliG-Sf.js",
				"https://github.githubassets.com/assets/ProfileReference-CZ7Di_kc.js",
				"https://github.githubassets.com/assets/use-page-data-url-32Ps0PG0.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DD0rk1bX.js",
				"https://github.githubassets.com/assets/use-latest-commit-DRiGLenQ.js",
				"https://github.githubassets.com/assets/use-web-vitals-Cy8VLVdU.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/file-tree-layout.tsx",
			"children": [
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/file-tree-layout-B2kVSyVy.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/file-tree-layout-DJe3MWoS.js",
				"https://github.githubassets.com/assets/overview-types-iJX8LBpY.js",
				"https://github.githubassets.com/assets/SharedPageLayout-B0QICwiq.js",
				"https://github.githubassets.com/assets/use-hide-footer-5ZPhxBqM.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob-layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-layout-CFl30m05.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-BJTngiK9.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CEKCjCMh.js",
				"https://github.githubassets.com/assets/NavigationMenu-DHlH-40b.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-C_ocYRKj.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-BxliG-Sf.js",
				"https://github.githubassets.com/assets/Breadcrumb-LyVXgz24.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DD0rk1bX.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/delete-BMLT9I7m.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-BJTngiK9.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/NavigationMenu-DHlH-40b.js",
				"https://github.githubassets.com/assets/EditIssues-BXJDALYp.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CiZbKeXS.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-C_ocYRKj.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-BxliG-Sf.js",
				"https://github.githubassets.com/assets/diff-parts-D4AUwISk.js",
				"https://github.githubassets.com/assets/Breadcrumb-LyVXgz24.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DD0rk1bX.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/edit.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/edit-COlvlgCO.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/CodeViewEditor-CHpCbt5X.js",
				"https://github.githubassets.com/assets/SuspenseFallback-CqdPrk0z.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/new.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/new-C49JxLFM.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/CodeViewEditor-CHpCbt5X.js",
				"https://github.githubassets.com/assets/SuspenseFallback-CqdPrk0z.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/tree-CEjCnYpa.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-9zAk_mtO.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-CIUNAsfH.js",
				"https://github.githubassets.com/assets/CircleOcticon-COGcDcGq.js",
				"https://github.githubassets.com/assets/use-codespaces-data-DCVzVRRH.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-CmDzgVzQ.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-BJTngiK9.js",
				"https://github.githubassets.com/assets/PublishBanners-BEpO2leI.js",
				"https://github.githubassets.com/assets/LatestCommitContext-CEKCjCMh.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/NavigationMenu-DHlH-40b.js",
				"https://github.githubassets.com/assets/CodeViewBanners-CBhCi1aY.js",
				"https://github.githubassets.com/assets/Panel-uirek-De.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-C_ocYRKj.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js",
				"https://github.githubassets.com/assets/commit-checks-status-D218Ds48.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-BxliG-Sf.js",
				"https://github.githubassets.com/assets/BetaLabel-DAgnehbj.js",
				"https://github.githubassets.com/assets/LabelWithLink-D7mfvQae.js",
				"https://github.githubassets.com/assets/ProfileReference-CZ7Di_kc.js",
				"https://github.githubassets.com/assets/use-page-data-url-32Ps0PG0.js",
				"https://github.githubassets.com/assets/Breadcrumb-LyVXgz24.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DD0rk1bX.js",
				"https://github.githubassets.com/assets/use-latest-commit-DRiGLenQ.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BeLxdhTt.js",
				"https://github.githubassets.com/assets/use-web-vitals-Cy8VLVdU.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blame.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blame-TyuAkige.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/BlobViewContent-B0e6cOnL.js",
				"https://github.githubassets.com/assets/PublishBanners-BEpO2leI.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/CodeViewBanners-CBhCi1aY.js",
				"https://github.githubassets.com/assets/Panel-uirek-De.js",
				"https://github.githubassets.com/assets/SuspenseFallback-CqdPrk0z.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js",
				"https://github.githubassets.com/assets/commit-checks-status-D218Ds48.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-CzwcqhBl.js",
				"https://github.githubassets.com/assets/CopilotPopover-DWRnIkoP.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-BpKJ9UhQ.js",
				"https://github.githubassets.com/assets/FeatureRequest-BhXux_yK.js",
				"https://github.githubassets.com/assets/BetaLabel-DAgnehbj.js",
				"https://github.githubassets.com/assets/LabelWithLink-D7mfvQae.js",
				"https://github.githubassets.com/assets/ProfileReference-CZ7Di_kc.js",
				"https://github.githubassets.com/assets/use-feature-flag-B4bfdsuz.js",
				"https://github.githubassets.com/assets/use-contributors-C-rDwy8Z.js",
				"https://github.githubassets.com/assets/use-latest-commit-DRiGLenQ.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BeLxdhTt.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-CTlP12xX.js",
				"https://github.githubassets.com/assets/AvatarStack-uDcLwboo.js",
				"https://github.githubassets.com/assets/BlobViewContent-B0e6cOnL.js",
				"https://github.githubassets.com/assets/PublishBanners-BEpO2leI.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/CodeViewBanners-CBhCi1aY.js",
				"https://github.githubassets.com/assets/Panel-uirek-De.js",
				"https://github.githubassets.com/assets/SuspenseFallback-CqdPrk0z.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js",
				"https://github.githubassets.com/assets/commit-checks-status-D218Ds48.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-CzwcqhBl.js",
				"https://github.githubassets.com/assets/CopilotPopover-DWRnIkoP.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-BpKJ9UhQ.js",
				"https://github.githubassets.com/assets/FeatureRequest-BhXux_yK.js",
				"https://github.githubassets.com/assets/BetaLabel-DAgnehbj.js",
				"https://github.githubassets.com/assets/LabelWithLink-D7mfvQae.js",
				"https://github.githubassets.com/assets/ProfileReference-CZ7Di_kc.js",
				"https://github.githubassets.com/assets/use-feature-flag-B4bfdsuz.js",
				"https://github.githubassets.com/assets/use-contributors-C-rDwy8Z.js",
				"https://github.githubassets.com/assets/use-latest-commit-DRiGLenQ.js",
				"https://github.githubassets.com/assets/use-sticky-observer-BeLxdhTt.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree-delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-delete-0nxM9Mjv.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-BJTngiK9.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-CJp9mLuL.js",
				"https://github.githubassets.com/assets/NavigationMenu-DHlH-40b.js",
				"https://github.githubassets.com/assets/EditIssues-BXJDALYp.js",
				"https://github.githubassets.com/assets/DeleteViewContent-CiZbKeXS.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-BbA31DVZ.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-C_ocYRKj.js",
				"https://github.githubassets.com/assets/CodeView-Cc4oi5_k.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-BxliG-Sf.js",
				"https://github.githubassets.com/assets/diff-parts-D4AUwISk.js",
				"https://github.githubassets.com/assets/Breadcrumb-LyVXgz24.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-DD0rk1bX.js"
			]
		}
	},
	"clientEntry": "https://github.githubassets.com/assets/main-E2ZqskIP.js"
});
export { tsrStartManifest };
