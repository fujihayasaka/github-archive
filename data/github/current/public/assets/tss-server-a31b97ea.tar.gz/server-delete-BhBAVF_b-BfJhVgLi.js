performance.mark("js-parse-end:server-delete-BhBAVF_b-BfJhVgLi.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { i as DeleteHeaderButtons, r as CodeViewHeaderDataRouter } from "./server-NavigationMenu-uMjhVPeq-CFyfVkte.js";
import { t as CodeView } from "./server-CodeView-7LjWoTBQ-VJPpV5hX.js";
import { t as codeViewDeleteRoute } from "./server-code-view-delete-route-DHSuVl8s-xWgwtbBT.js";
import { t as DeleteViewContent } from "./server-DeleteViewContent-DP9ZdPXB-DQ788Ot0.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:delete-BhBAVF_b.js");
function CodeViewDeleteEntrypoint() {
	const $ = c(5);
	const { data: payload } = useRouteQuery(codeViewDeleteRoute, "mainQuery");
	let t0;
	if ($[0] !== payload) {
		const actions = jsx(DeleteHeaderButtons, {
			webCommitInfo: payload.webCommitInfo,
			isBlob: payload.deleteInfo.isBlob
		});
		let t1;
		if ($[2] !== payload.deleteInfo || $[3] !== payload.webCommitInfo) {
			t1 = () => jsx(DeleteViewContent, {
				deleteInfo: payload.deleteInfo,
				webCommitInfo: payload.webCommitInfo
			});
			$[2] = payload.deleteInfo;
			$[3] = payload.webCommitInfo;
			$[4] = t1;
		} else t1 = $[4];
		t0 = jsxs(Fragment, { children: [jsx(CodeViewHeaderDataRouter, {
			narrowActions: actions,
			wideActions: actions,
			commitish: payload.refInfo.name,
			path: payload.path,
			modelsRepoIntegrationEnabled: payload.modelsRepoIntegrationEnabled
		}), jsx(CodeView, {
			payload,
			action: "tree",
			children: t1
		})] });
		$[0] = payload;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
CodeViewDeleteEntrypoint.displayName = "CodeViewDeleteEntrypoint";
var SplitComponent = CodeViewDeleteEntrypoint;
export { SplitComponent as component };
