performance.mark("js-parse-end:server-edit-BuC3l5LS-BpVwJsqB.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as CodeView } from "./server-CodeView-7LjWoTBQ-VJPpV5hX.js";
import { t as codeViewEditRoute } from "./server-code-view-edit-route-CUHyRXnW-CWvnzfL0.js";
import { t as CodeViewEditor } from "./server-CodeViewEditor-BXyU9MUX-DwwEK3oF.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:edit-BuC3l5LS.js");
function CodeViewEditEntrypoint() {
	const $ = c(2);
	const { data: payload } = useRouteQuery(codeViewEditRoute, "mainQuery");
	let t0;
	if ($[0] !== payload) {
		t0 = jsx("div", {
			className: "tmp-pt-3",
			children: jsx(CodeView, {
				payload,
				action: "edit",
				children: () => jsx(CodeViewEditor, {
					editInfo: payload.editInfo,
					path: payload.path,
					webCommitInfo: payload.webCommitInfo,
					copilotInfo: payload.copilotInfo,
					copilotGenerateCommitMessageAuthInfo: payload.copilotGenerateCommitMessageAuthInfo
				})
			})
		});
		$[0] = payload;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
CodeViewEditEntrypoint.displayName = "CodeViewEditEntrypoint";
var SplitComponent = CodeViewEditEntrypoint;
export { SplitComponent as component };
