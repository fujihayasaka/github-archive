performance.mark("js-parse-end:server-GlobalAgentsMenu-ChbpYCXl-DnSBppXg.js");
import { t as GlobalAgentsMenuWithAnchor } from "./server-GlobalAgentsMenu-CUqNtAoN-VAHUcBVS.js";
performance.mark("js-parse-end:GlobalAgentsMenu-ChbpYCXl.js");
export { GlobalAgentsMenuWithAnchor };
