performance.mark("js-parse-end:server-NewAgentTaskButtonContent-CegOXl_a-2uYqICOk.js");
import { t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { E as useTasks, b as useCreateAPITask, h as getFlatTaskList, i as NewAgentTaskForm, m as getAgentTasksQueryKeyForMutation, v as setFlatTaskList } from "./server-use-sso-change-detection-Ctg81XL_-Dl49uEpE.js";
import { n as TOGGLE_COPILOT_OVERLAY } from "./server-GlobalAgentsMenu-CUqNtAoN-VAHUcBVS.js";
import { useEffect, useRef } from "react";
import { jsx } from "react/jsx-runtime";
performance.mark("js-parse-end:NewAgentTaskButtonContent-CegOXl_a.js");
function NewAgentTaskButtonContent(props) {
	return /* @__PURE__ */ jsx(ConsecutiveCAPI401sProvider, { children: /* @__PURE__ */ jsx(InnerNewAgentTaskButtonContent, { ...props }) });
}
NewAgentTaskButtonContent.displayName = "NewAgentTaskButtonContent";
function InnerNewAgentTaskButtonContent({ currentRepo, currentReference, hideRepoSelector, setOpen, eventType, initialText, maxTextareaHeight, skipOverlayToggle, decoupledModeEnabled }) {
	useTasks({
		sessionsPollingInterval: false,
		taskFilter: "active"
	});
	const { createTask } = useCreateAPITask({
		queryKey: getAgentTasksQueryKeyForMutation(),
		pageSize: 10,
		getFlatTaskList,
		setFlatTaskList,
		decoupledModeEnabled
	});
	const textAreaRef = useRef(null);
	useEffect(() => {
		textAreaRef.current?.focus();
	}, []);
	return /* @__PURE__ */ jsx(NewAgentTaskForm, {
		createTask,
		currentRepo,
		currentReference,
		onCreate: () => {
			setOpen(false);
			if (!skipOverlayToggle) document.dispatchEvent(new CustomEvent(TOGGLE_COPILOT_OVERLAY));
		},
		hideRepoSelector,
		eventType,
		showHeader: false,
		textAreaRef,
		initialText,
		maxTextareaHeight,
		isInPortal: true,
		decoupledModeEnabled
	});
}
InnerNewAgentTaskButtonContent.displayName = "InnerNewAgentTaskButtonContent";
export { NewAgentTaskButtonContent };
