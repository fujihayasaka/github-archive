import { a as useFeatureFlag, o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Hi as useProvidedRefOrCreate, Mi as XIcon, Ui as useRenderForcingRef, Vi as useOnEscapePress, an as IconButton } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useOnOutsideClick } from "./server-useOnOutsideClick-DKLusJ3D-nDHIGoWL.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { r as useFocusTrap, t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { iterateFocusableElements } from "@primer/behaviors/utils";
import { getAnchoredPosition } from "@primer/behaviors";
function useOpenAndCloseFocus(t0) {
	const $ = c(6);
	const { initialFocusRef, returnFocusRef, containerRef, preventFocusOnOpen } = t0;
	let t1;
	let t2;
	if ($[0] !== containerRef || $[1] !== initialFocusRef || $[2] !== preventFocusOnOpen || $[3] !== returnFocusRef) {
		t1 = () => {
			if (!preventFocusOnOpen) {
				if (initialFocusRef && initialFocusRef.current) initialFocusRef.current.focus();
				else if (containerRef.current) {
					const firstItem = iterateFocusableElements(containerRef.current).next().value;
					firstItem === null || firstItem === void 0 || firstItem.focus();
				}
			}
			const returnFocusRefCurrent = returnFocusRef.current;
			return function() {
				returnFocusRefCurrent === null || returnFocusRefCurrent === void 0 || returnFocusRefCurrent.focus();
			};
		};
		t2 = [
			initialFocusRef,
			returnFocusRef,
			containerRef,
			preventFocusOnOpen
		];
		$[0] = containerRef;
		$[1] = initialFocusRef;
		$[2] = preventFocusOnOpen;
		$[3] = returnFocusRef;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
}
var useOverlay = (t0) => {
	const $ = c(13);
	const { overlayRef: _overlayRef, returnFocusRef, initialFocusRef, onEscape, ignoreClickRefs, onClickOutside, preventFocusOnOpen } = t0;
	const overlayRef = useProvidedRefOrCreate(_overlayRef);
	let t1;
	if ($[0] !== initialFocusRef || $[1] !== overlayRef || $[2] !== preventFocusOnOpen || $[3] !== returnFocusRef) {
		t1 = {
			containerRef: overlayRef,
			returnFocusRef,
			initialFocusRef,
			preventFocusOnOpen
		};
		$[0] = initialFocusRef;
		$[1] = overlayRef;
		$[2] = preventFocusOnOpen;
		$[3] = returnFocusRef;
		$[4] = t1;
	} else t1 = $[4];
	useOpenAndCloseFocus(t1);
	let t2;
	if ($[5] !== ignoreClickRefs || $[6] !== onClickOutside || $[7] !== overlayRef) {
		t2 = {
			containerRef: overlayRef,
			ignoreClickRefs,
			onClickOutside
		};
		$[5] = ignoreClickRefs;
		$[6] = onClickOutside;
		$[7] = overlayRef;
		$[8] = t2;
	} else t2 = $[8];
	useOnOutsideClick(t2);
	let t3;
	if ($[9] !== onEscape) {
		t3 = (event) => {
			onEscape(event);
			event.preventDefault();
		};
		$[9] = onEscape;
		$[10] = t3;
	} else t3 = $[10];
	useOnEscapePress(t3);
	let t4;
	if ($[11] !== overlayRef) {
		t4 = { ref: overlayRef };
		$[11] = overlayRef;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
};
function useResizeObserver(callback, target, depsArray = []) {
	const [targetClientRect, setTargetClientRect] = useState(null);
	const savedCallback = useRef(callback);
	useIsomorphicLayoutEffect(() => {
		savedCallback.current = callback;
	});
	useIsomorphicLayoutEffect(() => {
		const targetEl = target && "current" in target ? target.current : document.documentElement;
		if (!targetEl) return;
		if (typeof ResizeObserver === "function") {
			const observer = new ResizeObserver((entries) => {
				savedCallback.current(entries);
			});
			observer.observe(targetEl);
			return () => {
				observer.disconnect();
			};
		} else {
			const saveTargetDimensions = () => {
				const currTargetRect = targetEl.getBoundingClientRect();
				if (currTargetRect.width !== (targetClientRect === null || targetClientRect === void 0 ? void 0 : targetClientRect.width) || currTargetRect.height !== targetClientRect.height) savedCallback.current([{ contentRect: currTargetRect }]);
				setTargetClientRect(currTargetRect);
			};
			window.addEventListener("resize", saveTargetDimensions);
			return () => {
				window.removeEventListener("resize", saveTargetDimensions);
			};
		}
	}, [target === null || target === void 0 ? void 0 : target.current, ...depsArray]);
}
/**
* Calculates the top and left values for an absolutely-positioned floating element
* to be anchored to some anchor element. Returns refs for the floating element
* and the anchor element, along with the position.
* @param settings Settings for calculating the anchored position.
* @param dependencies Dependencies to determine when to re-calculate the position.
* @returns An object of {top: number, left: number} to absolutely-position the
* floating element.
*/
function useAnchoredPosition(settings, dependencies = []) {
	const floatingElementRef = useProvidedRefOrCreate(settings === null || settings === void 0 ? void 0 : settings.floatingElementRef);
	const anchorElementRef = useProvidedRefOrCreate(settings === null || settings === void 0 ? void 0 : settings.anchorElementRef);
	const savedOnPositionChange = React.useRef(settings === null || settings === void 0 ? void 0 : settings.onPositionChange);
	const [position, setPosition] = React.useState(void 0);
	const [_, setPrevHeight] = React.useState(void 0);
	const topPositionChanged = (prevPosition, newPosition) => {
		return prevPosition && ["outside-top", "inside-top"].includes(prevPosition.anchorSide) && (prevPosition.anchorSide !== newPosition.anchorSide || prevPosition.top < newPosition.top);
	};
	const updateElementHeight = () => {
		let heightUpdated = false;
		setPrevHeight((prevHeight) => {
			var _floatingElementRef$c, _floatingElementRef$c2;
			if (prevHeight && prevHeight > ((_floatingElementRef$c = (_floatingElementRef$c2 = floatingElementRef.current) === null || _floatingElementRef$c2 === void 0 ? void 0 : _floatingElementRef$c2.clientHeight) !== null && _floatingElementRef$c !== void 0 ? _floatingElementRef$c : 0)) {
				requestAnimationFrame(() => {
					floatingElementRef.current.style.height = `${prevHeight}px`;
				});
				heightUpdated = true;
			}
			return prevHeight;
		});
		return heightUpdated;
	};
	const updatePosition = React.useCallback(() => {
		var _floatingElementRef$c5;
		if (floatingElementRef.current instanceof Element && anchorElementRef.current instanceof Element) {
			const newPosition = getAnchoredPosition(floatingElementRef.current, anchorElementRef.current, settings);
			setPosition((prev) => {
				if (settings !== null && settings !== void 0 && settings.pinPosition && topPositionChanged(prev, newPosition)) {
					var _anchorElementRef$cur, _anchorElementRef$cur2, _floatingElementRef$c3, _floatingElementRef$c4;
					if (((_anchorElementRef$cur = (_anchorElementRef$cur2 = anchorElementRef.current) === null || _anchorElementRef$cur2 === void 0 ? void 0 : _anchorElementRef$cur2.getBoundingClientRect().top) !== null && _anchorElementRef$cur !== void 0 ? _anchorElementRef$cur : 0) > ((_floatingElementRef$c3 = (_floatingElementRef$c4 = floatingElementRef.current) === null || _floatingElementRef$c4 === void 0 ? void 0 : _floatingElementRef$c4.clientHeight) !== null && _floatingElementRef$c3 !== void 0 ? _floatingElementRef$c3 : 0) && updateElementHeight()) return prev;
				}
				if (prev && prev.anchorSide === newPosition.anchorSide) {
					var _savedOnPositionChang;
					(_savedOnPositionChang = savedOnPositionChange.current) === null || _savedOnPositionChang === void 0 || _savedOnPositionChang.call(savedOnPositionChange, newPosition);
				}
				return newPosition;
			});
		} else {
			var _savedOnPositionChang2;
			setPosition(void 0);
			(_savedOnPositionChang2 = savedOnPositionChange.current) === null || _savedOnPositionChang2 === void 0 || _savedOnPositionChang2.call(savedOnPositionChange, void 0);
		}
		setPrevHeight((_floatingElementRef$c5 = floatingElementRef.current) === null || _floatingElementRef$c5 === void 0 ? void 0 : _floatingElementRef$c5.clientHeight);
	}, [
		floatingElementRef,
		anchorElementRef,
		...dependencies
	]);
	useIsomorphicLayoutEffect(() => {
		savedOnPositionChange.current = settings === null || settings === void 0 ? void 0 : settings.onPositionChange;
	}, [settings === null || settings === void 0 ? void 0 : settings.onPositionChange]);
	useIsomorphicLayoutEffect(updatePosition, [updatePosition]);
	useResizeObserver(updatePosition);
	useResizeObserver(updatePosition, floatingElementRef);
	return {
		floatingElementRef,
		anchorElementRef,
		position
	};
}
var classes$1 = {
	"ResponsiveCloseButtonContainer": "prc-AnchoredOverlay-ResponsiveCloseButtonContainer-nuium",
	"ResponsiveCloseButton": "prc-AnchoredOverlay-ResponsiveCloseButton-z-2rx",
	"Wrapper": "prc-AnchoredOverlay-Wrapper-w6jU3",
	"Anchor": "prc-AnchoredOverlay-Anchor-DWRfK",
	"AnchoredOverlay": "prc-AnchoredOverlay-AnchoredOverlay-fYg9Z"
};
var classes = {
	"Overlay": "prc-Overlay-Overlay-jfs-T",
	"overlay-appear": "prc-Overlay-overlay-appear-JpFey"
};
var heightMap = {
	xsmall: "192px",
	small: "256px",
	medium: "320px",
	large: "432px",
	xlarge: "600px",
	auto: "auto",
	initial: "auto",
	"fit-content": "fit-content"
};
var animationDuration = 200;
function getSlideAnimationStartingVector(anchorSide) {
	if (anchorSide !== null && anchorSide !== void 0 && anchorSide.endsWith("bottom")) return {
		x: 0,
		y: -1
	};
	else if (anchorSide !== null && anchorSide !== void 0 && anchorSide.endsWith("top")) return {
		x: 0,
		y: 1
	};
	else if (anchorSide !== null && anchorSide !== void 0 && anchorSide.endsWith("right")) return {
		x: -1,
		y: 0
	};
	else if (anchorSide !== null && anchorSide !== void 0 && anchorSide.endsWith("left")) return {
		x: 1,
		y: 0
	};
	return {
		x: 0,
		y: 0
	};
}
/**
* An `Overlay` is a flexible floating surface, used to display transient content such as menus,
* selection options, dialogs, and more. Overlays use shadows to express elevation. The `Overlay`
* component handles all behaviors needed by overlay UIs as well as the common styles that all overlays * should have.
* @param height Sets the height of the `Overlay`, pick from our set list of heights, or pass `auto` to automatically set the height based on the content of the `Overlay`, or pass `initial` to set the height based on the initial content of the `Overlay` (i.e. ignoring content changes). `xsmall` corresponds to `192px`, `small` corresponds to `256px`, `medium` corresponds to `320px`, `large` corresponds to `432px`, `xlarge` corresponds to `600px`.
* @param width Sets the width of the `Overlay`, pick from our set list of widths, or pass `auto` to automatically set the width based on the content of the `Overlay`. `small` corresponds to `256px`, `medium` corresponds to `320px`, `large` corresponds to `480px`, `xlarge` corresponds to `640px`, `xxlarge` corresponds to `960px`.
* @param maxHeight Sets the maximum height of the `Overlay`, pick from our set list of heights. `xsmall` corresponds to `192px`, `small` corresponds to `256px`, `medium` corresponds to `320px`, `large` corresponds to `432px`, `xlarge` corresponds to `600px`.
* @param top Optional. Vertical top position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param left Optional. Horizontal left position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param right Optional. Horizontal right position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param bottom Optional. Vertical bottom position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param position Optional. Sets how an element is positioned in a document. Defaults to `absolute` positioning.
*/
var BaseOverlay = /* @__PURE__ */ React.forwardRef(({ visibility, height, width, top, left, right, bottom, position, style: styleFromProps, className, maxHeight, maxWidth, as: Component = "div", ...rest }, forwardedRef) => {
	return /* @__PURE__ */ jsx(Component, {
		...rest,
		ref: forwardedRef,
		style: {
			"--top": typeof top === "number" ? `${top}px` : top,
			"--left": typeof left === "number" ? `${left}px` : left,
			"--right": typeof right === "number" ? `${right}px` : right,
			"--bottom": typeof bottom === "number" ? `${bottom}px` : bottom,
			position,
			...styleFromProps
		},
		[`data-width-${width}`]: "",
		[`data-max-width-${maxWidth}`]: maxWidth ? "" : void 0,
		[`data-height-${height}`]: "",
		[`data-max-height-${maxHeight}`]: maxHeight ? "" : void 0,
		[`data-visibility-${visibility}`]: "",
		[`data-overflow-${rest.overflow}`]: rest.overflow ? "" : void 0,
		className: clsx(className, classes.Overlay)
	});
});
/**
* @param anchorSide If provided, the Overlay will slide into position from the side of the anchor with a brief animation
* @param height Sets the height of the `Overlay`, pick from our set list of heights, or pass `auto` to automatically set the height based on the content of the `Overlay`, or pass `initial` to set the height based on the initial content of the `Overlay` (i.e. ignoring content changes). `xsmall` corresponds to `192px`, `small` corresponds to `256px`, `medium` corresponds to `320px`, `large` corresponds to `432px`, `xlarge` corresponds to `600px`.
* @param ignoreClickRefs Optional. An array of ref objects to ignore clicks on in the `onOutsideClick` behavior. This is often used to ignore clicking on the element that toggles the open/closed state for the `Overlay` to prevent the `Overlay` from being toggled twice.
* @param initialFocusRef Optional. Ref for the element to focus when the `Overlay` is opened. If nothing is provided, the first focusable element in the `Overlay` body is focused.
* @param left Optional. Horizontal left position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param onClickOutside  Required. Function to call when clicking outside of the `Overlay`. Typically this function removes the Overlay.
* @param onEscape Required. Function to call when user presses `Escape`. Typically this function removes the Overlay.
* @param portalContainerName Optional. The name of the portal container to render the Overlay into.
* @param preventOverflow Optional. The Overlay width will be adjusted responsively if there is not enough space to display the Overlay. If `preventOverflow` is `true`, the width of the `Overlay` will not be adjusted.
* @param preventFocusOnOpen Optional. If 'true', focus will not be applied when the component is first mounted, even if initialFocusRef prop is given.
* @param returnFocusRef Required. Ref for the element to focus when the `Overlay` is closed.
* @param right Optional. Horizontal right position of the overlay, relative to its closest positioned ancestor (often its `Portal`).
* @param width Sets the width of the `Overlay`, pick from our set list of widths, or pass `auto` to automatically set the width based on the content of the `Overlay`. `small` corresponds to `256px`, `medium` corresponds to `320px`, `large` corresponds to `480px`, `xlarge` corresponds to `640px`, `xxlarge` corresponds to `960px`.

*/
var Overlay = /* @__PURE__ */ React.forwardRef((t0, forwardedRef) => {
	const $ = c(45);
	let anchorSide;
	let ignoreClickRefs;
	let initialFocusRef;
	let left;
	let onClickOutside;
	let onEscape;
	let portalContainerName;
	let preventFocusOnOpen;
	let props;
	let responsiveVariant;
	let returnFocusRef;
	let right;
	let t1;
	let t2;
	let t3;
	let t4;
	let t5;
	if ($[0] !== t0) {
		({anchorSide, height: t1, ignoreClickRefs, initialFocusRef, left, onClickOutside, onEscape, portalContainerName, preventOverflow: t2, preventFocusOnOpen, returnFocusRef, right, role: t3, visibility: t4, width: t5, responsiveVariant, ...props} = t0);
		$[0] = t0;
		$[1] = anchorSide;
		$[2] = ignoreClickRefs;
		$[3] = initialFocusRef;
		$[4] = left;
		$[5] = onClickOutside;
		$[6] = onEscape;
		$[7] = portalContainerName;
		$[8] = preventFocusOnOpen;
		$[9] = props;
		$[10] = responsiveVariant;
		$[11] = returnFocusRef;
		$[12] = right;
		$[13] = t1;
		$[14] = t2;
		$[15] = t3;
		$[16] = t4;
		$[17] = t5;
	} else {
		anchorSide = $[1];
		ignoreClickRefs = $[2];
		initialFocusRef = $[3];
		left = $[4];
		onClickOutside = $[5];
		onEscape = $[6];
		portalContainerName = $[7];
		preventFocusOnOpen = $[8];
		props = $[9];
		responsiveVariant = $[10];
		returnFocusRef = $[11];
		right = $[12];
		t1 = $[13];
		t2 = $[14];
		t3 = $[15];
		t4 = $[16];
		t5 = $[17];
	}
	const height = t1 === void 0 ? "auto" : t1;
	const preventOverflow = t2 === void 0 ? true : t2;
	const role = t3 === void 0 ? "none" : t3;
	const visibility = t4 === void 0 ? "visible" : t4;
	const width = t5 === void 0 ? "auto" : t5;
	const cssAnchorPositioning = useFeatureFlag("primer_react_css_anchor_positioning");
	const overlayRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, overlayRef);
	let t6;
	if ($[18] !== ignoreClickRefs || $[19] !== initialFocusRef || $[20] !== onClickOutside || $[21] !== onEscape || $[22] !== preventFocusOnOpen || $[23] !== returnFocusRef) {
		t6 = {
			overlayRef,
			returnFocusRef,
			onEscape,
			ignoreClickRefs,
			onClickOutside,
			initialFocusRef,
			preventFocusOnOpen
		};
		$[18] = ignoreClickRefs;
		$[19] = initialFocusRef;
		$[20] = onClickOutside;
		$[21] = onEscape;
		$[22] = preventFocusOnOpen;
		$[23] = returnFocusRef;
		$[24] = t6;
	} else t6 = $[24];
	useOverlay(t6);
	let t7;
	let t8;
	if ($[25] !== height) {
		t7 = () => {
			var _overlayRef$current;
			if (height === "initial" && (_overlayRef$current = overlayRef.current) !== null && _overlayRef$current !== void 0 && _overlayRef$current.clientHeight) overlayRef.current.style.height = `${overlayRef.current.clientHeight}px`;
		};
		t8 = [height];
		$[25] = height;
		$[26] = t7;
		$[27] = t8;
	} else {
		t7 = $[26];
		t8 = $[27];
	}
	useEffect(t7, t8);
	let t10;
	let t9;
	if ($[28] !== anchorSide || $[29] !== visibility) {
		t9 = () => {
			var _overlayRef$current2;
			const { x, y } = getSlideAnimationStartingVector(anchorSide);
			if (!x && !y || !((_overlayRef$current2 = overlayRef.current) !== null && _overlayRef$current2 !== void 0 && _overlayRef$current2.animate) || visibility === "hidden") return;
			overlayRef.current.animate({ transform: [`translate(${8 * x}px, ${8 * y}px)`, "translate(0, 0)"] }, {
				duration: animationDuration,
				easing: "cubic-bezier(0.33, 1, 0.68, 1)"
			});
		};
		t10 = [
			anchorSide,
			8,
			"cubic-bezier(0.33, 1, 0.68, 1)",
			visibility
		];
		$[28] = anchorSide;
		$[29] = visibility;
		$[30] = t10;
		$[31] = t9;
	} else {
		t10 = $[30];
		t9 = $[31];
	}
	useIsomorphicLayoutEffect(t9, t10);
	const leftPosition = left === void 0 && right === void 0 ? 0 : left;
	const t11 = !preventOverflow ? true : void 0;
	let t12;
	if ($[32] !== height || $[33] !== leftPosition || $[34] !== props || $[35] !== responsiveVariant || $[36] !== right || $[37] !== role || $[38] !== t11 || $[39] !== visibility || $[40] !== width) {
		t12 = /* @__PURE__ */ jsx(BaseOverlay, {
			role,
			width,
			"data-reflow-container": t11,
			ref: overlayRef,
			left: leftPosition,
			right,
			height,
			visibility,
			"data-responsive": responsiveVariant,
			...props
		});
		$[32] = height;
		$[33] = leftPosition;
		$[34] = props;
		$[35] = responsiveVariant;
		$[36] = right;
		$[37] = role;
		$[38] = t11;
		$[39] = visibility;
		$[40] = width;
		$[41] = t12;
	} else t12 = $[41];
	const overlayContent = t12;
	if (cssAnchorPositioning) return overlayContent;
	let t13;
	if ($[42] !== overlayContent || $[43] !== portalContainerName) {
		t13 = /* @__PURE__ */ jsx(Portal, {
			containerName: portalContainerName,
			children: overlayContent
		});
		$[42] = overlayContent;
		$[43] = portalContainerName;
		$[44] = t13;
	} else t13 = $[44];
	return t13;
});
var applyAnchorPositioningPolyfill = async () => {
	if (typeof window !== "undefined" && !("anchorName" in document.documentElement.style)) try {
		await import("@oddbird/css-anchor-positioning");
	} catch (e) {
		console.warn("Failed to load CSS anchor positioning polyfill:", e);
	}
};
var defaultVariant = {
	regular: "anchored",
	narrow: "anchored"
};
var defaultCloseButtonProps = {};
/**
* An `AnchoredOverlay` provides an anchor that will open a floating overlay positioned relative to the anchor.
* The overlay can be opened and navigated using keyboard or mouse.
*/
var AnchoredOverlay = ({ renderAnchor, anchorRef: externalAnchorRef, anchorId: externalAnchorId, children, open, onOpen, onClose, height, width, overlayProps, focusTrapSettings, focusZoneSettings, side = (overlayProps === null || overlayProps === void 0 ? void 0 : overlayProps["anchorSide"]) || "outside-bottom", align = "start", alignmentOffset, anchorOffset, displayInViewport, className, pinPosition, variant = defaultVariant, preventOverflow = true, onPositionChange, displayCloseButton = true, closeButtonProps = defaultCloseButtonProps }) => {
	const cssAnchorPositioning = useFeatureFlag("primer_react_css_anchor_positioning");
	const anchorRef = useProvidedRefOrCreate(externalAnchorRef);
	const [overlayRef, updateOverlayRef] = useRenderForcingRef();
	const anchorId = useId$1(externalAnchorId);
	const onClickOutside = useCallback(() => onClose === null || onClose === void 0 ? void 0 : onClose("click-outside"), [onClose]);
	const onEscape = useCallback(() => onClose === null || onClose === void 0 ? void 0 : onClose("escape"), [onClose]);
	const onAnchorKeyDown = useCallback((event) => {
		if (!event.defaultPrevented) {
			if (!open && [
				"ArrowDown",
				"ArrowUp",
				" ",
				"Enter"
			].includes(event.key)) {
				onOpen === null || onOpen === void 0 || onOpen("anchor-key-press", event);
				event.preventDefault();
			}
		}
	}, [open, onOpen]);
	const onAnchorClick = useCallback((event_0) => {
		if (event_0.defaultPrevented || event_0.button !== 0) return;
		if (!open) onOpen === null || onOpen === void 0 || onOpen("anchor-click");
		else onClose === null || onClose === void 0 || onClose("anchor-click");
	}, [
		open,
		onOpen,
		onClose
	]);
	const positionChange = (position) => {
		if (onPositionChange && position) onPositionChange({ position });
	};
	const { position: position_0 } = useAnchoredPosition({
		anchorElementRef: anchorRef,
		floatingElementRef: overlayRef,
		pinPosition,
		side,
		align,
		alignmentOffset,
		anchorOffset,
		displayInViewport,
		onPositionChange: positionChange
	}, [overlayRef.current]);
	const hasLoadedAnchorPositioningPolyfill = useRef(false);
	useEffect(() => {
		if (!open && overlayRef.current) updateOverlayRef(null);
		if (cssAnchorPositioning && !hasLoadedAnchorPositioningPolyfill.current) {
			applyAnchorPositioningPolyfill();
			hasLoadedAnchorPositioningPolyfill.current = true;
		}
	}, [
		open,
		overlayRef,
		updateOverlayRef,
		cssAnchorPositioning
	]);
	useFocusZone({
		containerRef: overlayRef,
		disabled: !open || !position_0,
		...focusZoneSettings
	});
	useFocusTrap({
		containerRef: overlayRef,
		disabled: !open || !position_0,
		...focusTrapSettings
	});
	const showXIcon = onClose && variant.narrow === "fullscreen" && displayCloseButton;
	const XButtonAriaLabelledBy = closeButtonProps["aria-labelledby"];
	const XButtonAriaLabel = closeButtonProps["aria-label"];
	const { className: overlayClassName, ...restOverlayProps } = overlayProps || {};
	const innerContent = /* @__PURE__ */ jsxs(Fragment$1, { children: [renderAnchor && renderAnchor({
		ref: anchorRef,
		id: anchorId,
		"aria-haspopup": "true",
		"aria-expanded": open,
		tabIndex: 0,
		onClick: onAnchorClick,
		onKeyDown: onAnchorKeyDown,
		...cssAnchorPositioning ? { className: classes$1.Anchor } : {}
	}), open ? /* @__PURE__ */ jsxs(Overlay, {
		returnFocusRef: anchorRef,
		onClickOutside,
		ignoreClickRefs: [anchorRef],
		onEscape,
		role: "none",
		visibility: cssAnchorPositioning || position_0 ? "visible" : "hidden",
		height,
		width,
		top: cssAnchorPositioning ? void 0 : (position_0 === null || position_0 === void 0 ? void 0 : position_0.top) || 0,
		left: cssAnchorPositioning ? void 0 : (position_0 === null || position_0 === void 0 ? void 0 : position_0.left) || 0,
		responsiveVariant: variant.narrow === "fullscreen" ? "fullscreen" : void 0,
		anchorSide: cssAnchorPositioning ? void 0 : position_0 === null || position_0 === void 0 ? void 0 : position_0.anchorSide,
		className: clsx(className, overlayClassName, cssAnchorPositioning ? classes$1.AnchoredOverlay : void 0),
		preventOverflow,
		"data-component": "AnchoredOverlay",
		...restOverlayProps,
		ref: (node) => {
			if (overlayProps !== null && overlayProps !== void 0 && overlayProps.ref) assignRef(overlayProps.ref, node);
			updateOverlayRef(node);
		},
		"data-anchor-position": cssAnchorPositioning,
		"data-side": cssAnchorPositioning ? side : position_0 === null || position_0 === void 0 ? void 0 : position_0.anchorSide,
		children: [showXIcon ? /* @__PURE__ */ jsx("div", {
			className: classes$1.ResponsiveCloseButtonContainer,
			children: /* @__PURE__ */ jsx(IconButton, {
				...closeButtonProps,
				type: "button",
				variant: "invisible",
				icon: XIcon,
				...XButtonAriaLabelledBy ? {
					"aria-labelledby": XButtonAriaLabelledBy,
					"aria-label": void 0
				} : {
					"aria-label": XButtonAriaLabel !== null && XButtonAriaLabel !== void 0 ? XButtonAriaLabel : "Close",
					"aria-labelledby": void 0
				},
				className: clsx(classes$1.ResponsiveCloseButton, closeButtonProps.className),
				onClick: () => {
					onClose("close");
				}
			})
		}) : null, children]
	}) : null] });
	if (cssAnchorPositioning) return /* @__PURE__ */ jsx("div", {
		className: classes$1.Wrapper,
		children: innerContent
	});
	return innerContent;
};
function assignRef(ref, value) {
	if (typeof ref === "function") ref(value);
	else if (ref) ref.current = value;
}
AnchoredOverlay.displayName = "AnchoredOverlay";
export { useAnchoredPosition as a, heightMap as i, BaseOverlay as n, useResizeObserver as o, Overlay as r, AnchoredOverlay as t };
