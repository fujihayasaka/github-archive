import { bn as Link, qr as Stack } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var FeedbackLink_module_default = { link: "FeedbackLink-module_tNIwIW_link" };
/** "Give feedback" link. Renders nothing if no URL is passed. */
var FeedbackLink = ({ feedbackUrl }) => /* @__PURE__ */ jsx(Link, {
	className: FeedbackLink_module_default.link,
	href: feedbackUrl,
	inline: true,
	children: "Give feedback"
});
FeedbackLink.displayName = "FeedbackLink";
/** Render a `Label` with an optional link adjacent. */
var LabelWithLink = ({ label, link, className }) => {
	if (link) return /* @__PURE__ */ jsxs(Stack, {
		direction: "horizontal",
		gap: "condensed",
		align: "baseline",
		className,
		children: [
			label,
			" ",
			link
		]
	});
	if (className) return /* @__PURE__ */ jsx("span", {
		className,
		children: label
	});
	return /* @__PURE__ */ jsx(Fragment, { children: label });
};
LabelWithLink.displayName = "LabelWithLink";
export { LabelWithLink as n, FeedbackLink as t };
