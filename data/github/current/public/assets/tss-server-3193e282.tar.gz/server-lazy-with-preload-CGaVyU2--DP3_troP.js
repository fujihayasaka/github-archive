import { lazy } from "react";
/**
* Extends `React.lazy` with a preload method to begin
* fetching the component at an earlier point.
*
* Helps to avoid waterfalls
*/
function lazyWithPreload(load) {
	const component = lazy(load);
	return Object.assign(component, { preload: async () => {
		await load();
	} });
}
export { lazyWithPreload as t };
