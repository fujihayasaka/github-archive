import { n as isDev } from "./server-env-CmF5Q86i-CMsKyIar.js";
import { a as getRequestHeader, n as getCurrentRequest, t as getCookie } from "./server-request-C9AEnFH8-C42vJH27.js";
import require$$1 from "crypto";
import { AsyncLocalStorage } from "node:async_hooks";
import { Agent, Pool, fetch } from "undici";
import process$1, { env } from "node:process";
import pino from "pino";
import { StatsD } from "hot-shots";
import { performance } from "node:perf_hooks";
import { Failbot, HTTPBackend, LogBackend } from "@github/failbot";
import jwt from "jsonwebtoken";
/**
* Get the type of a JSON value.
* Distinguishes between array, null and object.
*/
function typeofJsonValue(value) {
	let t = typeof value;
	if (t == "object") {
		if (Array.isArray(value)) return "array";
		if (value === null) return "null";
	}
	return t;
}
/**
* Is this a JSON object (instead of an array or null)?
*/
function isJsonObject(value) {
	return value !== null && typeof value == "object" && !Array.isArray(value);
}
var encTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
var decTable = [];
for (let i = 0; i < encTable.length; i++) decTable[encTable[i].charCodeAt(0)] = i;
decTable["-".charCodeAt(0)] = encTable.indexOf("+");
decTable["_".charCodeAt(0)] = encTable.indexOf("/");
/**
* Decodes a base64 string to a byte array.
*
* - ignores white-space, including line breaks and tabs
* - allows inner padding (can decode concatenated base64 strings)
* - does not require padding
* - understands base64url encoding:
*   "-" instead of "+",
*   "_" instead of "/",
*   no padding
*/
function base64decode(base64Str) {
	let es = base64Str.length * 3 / 4;
	if (base64Str[base64Str.length - 2] == "=") es -= 2;
	else if (base64Str[base64Str.length - 1] == "=") es -= 1;
	let bytes = new Uint8Array(es), bytePos = 0, groupPos = 0, b, p = 0;
	for (let i = 0; i < base64Str.length; i++) {
		b = decTable[base64Str.charCodeAt(i)];
		if (b === void 0) switch (base64Str[i]) {
			case "=": groupPos = 0;
			case "\n":
			case "\r":
			case "	":
			case " ": continue;
			default: throw Error(`invalid base64 string.`);
		}
		switch (groupPos) {
			case 0:
				p = b;
				groupPos = 1;
				break;
			case 1:
				bytes[bytePos++] = p << 2 | (b & 48) >> 4;
				p = b;
				groupPos = 2;
				break;
			case 2:
				bytes[bytePos++] = (p & 15) << 4 | (b & 60) >> 2;
				p = b;
				groupPos = 3;
				break;
			case 3:
				bytes[bytePos++] = (p & 3) << 6 | b;
				groupPos = 0;
				break;
		}
	}
	if (groupPos == 1) throw Error(`invalid base64 string.`);
	return bytes.subarray(0, bytePos);
}
/**
* Encodes a byte array to a base64 string.
* Adds padding at the end.
* Does not insert newlines.
*/
function base64encode(bytes) {
	let base64 = "", groupPos = 0, b, p = 0;
	for (let i = 0; i < bytes.length; i++) {
		b = bytes[i];
		switch (groupPos) {
			case 0:
				base64 += encTable[b >> 2];
				p = (b & 3) << 4;
				groupPos = 1;
				break;
			case 1:
				base64 += encTable[p | b >> 4];
				p = (b & 15) << 2;
				groupPos = 2;
				break;
			case 2:
				base64 += encTable[p | b >> 6];
				base64 += encTable[b & 63];
				groupPos = 0;
				break;
		}
	}
	if (groupPos) {
		base64 += encTable[p];
		base64 += "=";
		if (groupPos == 1) base64 += "=";
	}
	return base64;
}
/**
* This handler implements the default behaviour for unknown fields.
* When reading data, unknown fields are stored on the message, in a
* symbol property.
* When writing data, the symbol property is queried and unknown fields
* are serialized into the output again.
*/
var UnknownFieldHandler;
(function(UnknownFieldHandler) {
	/**
	* The symbol used to store unknown fields for a message.
	* The property must conform to `UnknownFieldContainer`.
	*/
	UnknownFieldHandler.symbol = Symbol.for("protobuf-ts/unknown");
	/**
	* Store an unknown field during binary read directly on the message.
	* This method is compatible with `BinaryReadOptions.readUnknownField`.
	*/
	UnknownFieldHandler.onRead = (typeName, message, fieldNo, wireType, data) => {
		(is(message) ? message[UnknownFieldHandler.symbol] : message[UnknownFieldHandler.symbol] = []).push({
			no: fieldNo,
			wireType,
			data
		});
	};
	/**
	* Write unknown fields stored for the message to the writer.
	* This method is compatible with `BinaryWriteOptions.writeUnknownFields`.
	*/
	UnknownFieldHandler.onWrite = (typeName, message, writer) => {
		for (let { no, wireType, data } of UnknownFieldHandler.list(message)) writer.tag(no, wireType).raw(data);
	};
	/**
	* List unknown fields stored for the message.
	* Note that there may be multiples fields with the same number.
	*/
	UnknownFieldHandler.list = (message, fieldNo) => {
		if (is(message)) {
			let all = message[UnknownFieldHandler.symbol];
			return fieldNo ? all.filter((uf) => uf.no == fieldNo) : all;
		}
		return [];
	};
	/**
	* Returns the last unknown field by field number.
	*/
	UnknownFieldHandler.last = (message, fieldNo) => UnknownFieldHandler.list(message, fieldNo).slice(-1)[0];
	const is = (message) => message && Array.isArray(message[UnknownFieldHandler.symbol]);
})(UnknownFieldHandler || (UnknownFieldHandler = {}));
/**
* Protobuf binary format wire types.
*
* A wire type provides just enough information to find the length of the
* following value.
*
* See https://developers.google.com/protocol-buffers/docs/encoding#structure
*/
var WireType;
(function(WireType) {
	/**
	* Used for int32, int64, uint32, uint64, sint32, sint64, bool, enum
	*/
	WireType[WireType["Varint"] = 0] = "Varint";
	/**
	* Used for fixed64, sfixed64, double.
	* Always 8 bytes with little-endian byte order.
	*/
	WireType[WireType["Bit64"] = 1] = "Bit64";
	/**
	* Used for string, bytes, embedded messages, packed repeated fields
	*
	* Only repeated numeric types (types which use the varint, 32-bit,
	* or 64-bit wire types) can be packed. In proto3, such fields are
	* packed by default.
	*/
	WireType[WireType["LengthDelimited"] = 2] = "LengthDelimited";
	/**
	* Used for groups
	* @deprecated
	*/
	WireType[WireType["StartGroup"] = 3] = "StartGroup";
	/**
	* Used for groups
	* @deprecated
	*/
	WireType[WireType["EndGroup"] = 4] = "EndGroup";
	/**
	* Used for fixed32, sfixed32, float.
	* Always 4 bytes with little-endian byte order.
	*/
	WireType[WireType["Bit32"] = 5] = "Bit32";
})(WireType || (WireType = {}));
/**
* Read a 64 bit varint as two JS numbers.
*
* Returns tuple:
* [0]: low bits
* [0]: high bits
*
* Copyright 2008 Google Inc.  All rights reserved.
*
* See https://github.com/protocolbuffers/protobuf/blob/8a71927d74a4ce34efe2d8769fda198f52d20d12/js/experimental/runtime/kernel/buffer_decoder.js#L175
*/
function varint64read() {
	let lowBits = 0;
	let highBits = 0;
	for (let shift = 0; shift < 28; shift += 7) {
		let b = this.buf[this.pos++];
		lowBits |= (b & 127) << shift;
		if ((b & 128) == 0) {
			this.assertBounds();
			return [lowBits, highBits];
		}
	}
	let middleByte = this.buf[this.pos++];
	lowBits |= (middleByte & 15) << 28;
	highBits = (middleByte & 112) >> 4;
	if ((middleByte & 128) == 0) {
		this.assertBounds();
		return [lowBits, highBits];
	}
	for (let shift = 3; shift <= 31; shift += 7) {
		let b = this.buf[this.pos++];
		highBits |= (b & 127) << shift;
		if ((b & 128) == 0) {
			this.assertBounds();
			return [lowBits, highBits];
		}
	}
	throw new Error("invalid varint");
}
/**
* Write a 64 bit varint, given as two JS numbers, to the given bytes array.
*
* Copyright 2008 Google Inc.  All rights reserved.
*
* See https://github.com/protocolbuffers/protobuf/blob/8a71927d74a4ce34efe2d8769fda198f52d20d12/js/experimental/runtime/kernel/writer.js#L344
*/
function varint64write(lo, hi, bytes) {
	for (let i = 0; i < 28; i = i + 7) {
		const shift = lo >>> i;
		const hasNext = !(shift >>> 7 == 0 && hi == 0);
		const byte = (hasNext ? shift | 128 : shift) & 255;
		bytes.push(byte);
		if (!hasNext) return;
	}
	const splitBits = lo >>> 28 & 15 | (hi & 7) << 4;
	const hasMoreBits = !(hi >> 3 == 0);
	bytes.push((hasMoreBits ? splitBits | 128 : splitBits) & 255);
	if (!hasMoreBits) return;
	for (let i = 3; i < 31; i = i + 7) {
		const shift = hi >>> i;
		const hasNext = !(shift >>> 7 == 0);
		const byte = (hasNext ? shift | 128 : shift) & 255;
		bytes.push(byte);
		if (!hasNext) return;
	}
	bytes.push(hi >>> 31 & 1);
}
var TWO_PWR_32_DBL$1 = 65536 * 65536;
/**
* Parse decimal string of 64 bit integer value as two JS numbers.
*
* Returns tuple:
* [0]: minus sign?
* [1]: low bits
* [2]: high bits
*
* Copyright 2008 Google Inc.
*/
function int64fromString(dec) {
	let minus = dec[0] == "-";
	if (minus) dec = dec.slice(1);
	const base = 1e6;
	let lowBits = 0;
	let highBits = 0;
	function add1e6digit(begin, end) {
		const digit1e6 = Number(dec.slice(begin, end));
		highBits *= base;
		lowBits = lowBits * base + digit1e6;
		if (lowBits >= TWO_PWR_32_DBL$1) {
			highBits = highBits + (lowBits / TWO_PWR_32_DBL$1 | 0);
			lowBits = lowBits % TWO_PWR_32_DBL$1;
		}
	}
	add1e6digit(-24, -18);
	add1e6digit(-18, -12);
	add1e6digit(-12, -6);
	add1e6digit(-6);
	return [
		minus,
		lowBits,
		highBits
	];
}
/**
* Format 64 bit integer value (as two JS numbers) to decimal string.
*
* Copyright 2008 Google Inc.
*/
function int64toString(bitsLow, bitsHigh) {
	if (bitsHigh >>> 0 <= 2097151) return "" + (TWO_PWR_32_DBL$1 * bitsHigh + (bitsLow >>> 0));
	let low = bitsLow & 16777215;
	let mid = (bitsLow >>> 24 | bitsHigh << 8) >>> 0 & 16777215;
	let high = bitsHigh >> 16 & 65535;
	let digitA = low + mid * 6777216 + high * 6710656;
	let digitB = mid + high * 8147497;
	let digitC = high * 2;
	let base = 1e7;
	if (digitA >= base) {
		digitB += Math.floor(digitA / base);
		digitA %= base;
	}
	if (digitB >= base) {
		digitC += Math.floor(digitB / base);
		digitB %= base;
	}
	function decimalFrom1e7(digit1e7, needLeadingZeros) {
		let partial = digit1e7 ? String(digit1e7) : "";
		if (needLeadingZeros) return "0000000".slice(partial.length) + partial;
		return partial;
	}
	return decimalFrom1e7(digitC, 0) + decimalFrom1e7(digitB, digitC) + decimalFrom1e7(digitA, 1);
}
/**
* Write a 32 bit varint, signed or unsigned. Same as `varint64write(0, value, bytes)`
*
* Copyright 2008 Google Inc.  All rights reserved.
*
* See https://github.com/protocolbuffers/protobuf/blob/1b18833f4f2a2f681f4e4a25cdf3b0a43115ec26/js/binary/encoder.js#L144
*/
function varint32write(value, bytes) {
	if (value >= 0) {
		while (value > 127) {
			bytes.push(value & 127 | 128);
			value = value >>> 7;
		}
		bytes.push(value);
	} else {
		for (let i = 0; i < 9; i++) {
			bytes.push(value & 127 | 128);
			value = value >> 7;
		}
		bytes.push(1);
	}
}
/**
* Read an unsigned 32 bit varint.
*
* See https://github.com/protocolbuffers/protobuf/blob/8a71927d74a4ce34efe2d8769fda198f52d20d12/js/experimental/runtime/kernel/buffer_decoder.js#L220
*/
function varint32read() {
	let b = this.buf[this.pos++];
	let result = b & 127;
	if ((b & 128) == 0) {
		this.assertBounds();
		return result;
	}
	b = this.buf[this.pos++];
	result |= (b & 127) << 7;
	if ((b & 128) == 0) {
		this.assertBounds();
		return result;
	}
	b = this.buf[this.pos++];
	result |= (b & 127) << 14;
	if ((b & 128) == 0) {
		this.assertBounds();
		return result;
	}
	b = this.buf[this.pos++];
	result |= (b & 127) << 21;
	if ((b & 128) == 0) {
		this.assertBounds();
		return result;
	}
	b = this.buf[this.pos++];
	result |= (b & 15) << 28;
	for (let readBytes = 5; (b & 128) !== 0 && readBytes < 10; readBytes++) b = this.buf[this.pos++];
	if ((b & 128) != 0) throw new Error("invalid varint");
	this.assertBounds();
	return result >>> 0;
}
var BI;
function detectBi() {
	const dv = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	BI = globalThis.BigInt !== void 0 && typeof dv.getBigInt64 === "function" && typeof dv.getBigUint64 === "function" && typeof dv.setBigInt64 === "function" && typeof dv.setBigUint64 === "function" ? {
		MIN: BigInt("-9223372036854775808"),
		MAX: BigInt("9223372036854775807"),
		UMIN: BigInt("0"),
		UMAX: BigInt("18446744073709551615"),
		C: BigInt,
		V: dv
	} : void 0;
}
detectBi();
function assertBi(bi) {
	if (!bi) throw new Error("BigInt unavailable, see https://github.com/timostamm/protobuf-ts/blob/v1.0.8/MANUAL.md#bigint-support");
}
var RE_DECIMAL_STR = /^-?[0-9]+$/;
var TWO_PWR_32_DBL = 4294967296;
var HALF_2_PWR_32 = 2147483648;
var SharedPbLong = class {
	/**
	* Create a new instance with the given bits.
	*/
	constructor(lo, hi) {
		this.lo = lo | 0;
		this.hi = hi | 0;
	}
	/**
	* Is this instance equal to 0?
	*/
	isZero() {
		return this.lo == 0 && this.hi == 0;
	}
	/**
	* Convert to a native number.
	*/
	toNumber() {
		let result = this.hi * TWO_PWR_32_DBL + (this.lo >>> 0);
		if (!Number.isSafeInteger(result)) throw new Error("cannot convert to safe number");
		return result;
	}
};
/**
* 64-bit unsigned integer as two 32-bit values.
* Converts between `string`, `number` and `bigint` representations.
*/
var PbULong = class PbULong extends SharedPbLong {
	/**
	* Create instance from a `string`, `number` or `bigint`.
	*/
	static from(value) {
		if (BI) switch (typeof value) {
			case "string":
				if (value == "0") return this.ZERO;
				if (value == "") throw new Error("string is no integer");
				value = BI.C(value);
			case "number":
				if (value === 0) return this.ZERO;
				value = BI.C(value);
			case "bigint":
				if (!value) return this.ZERO;
				if (value < BI.UMIN) throw new Error("signed value for ulong");
				if (value > BI.UMAX) throw new Error("ulong too large");
				BI.V.setBigUint64(0, value, true);
				return new PbULong(BI.V.getInt32(0, true), BI.V.getInt32(4, true));
		}
		else switch (typeof value) {
			case "string":
				if (value == "0") return this.ZERO;
				value = value.trim();
				if (!RE_DECIMAL_STR.test(value)) throw new Error("string is no integer");
				let [minus, lo, hi] = int64fromString(value);
				if (minus) throw new Error("signed value for ulong");
				return new PbULong(lo, hi);
			case "number":
				if (value == 0) return this.ZERO;
				if (!Number.isSafeInteger(value)) throw new Error("number is no integer");
				if (value < 0) throw new Error("signed value for ulong");
				return new PbULong(value, value / TWO_PWR_32_DBL);
		}
		throw new Error("unknown value " + typeof value);
	}
	/**
	* Convert to decimal string.
	*/
	toString() {
		return BI ? this.toBigInt().toString() : int64toString(this.lo, this.hi);
	}
	/**
	* Convert to native bigint.
	*/
	toBigInt() {
		assertBi(BI);
		BI.V.setInt32(0, this.lo, true);
		BI.V.setInt32(4, this.hi, true);
		return BI.V.getBigUint64(0, true);
	}
};
/**
* ulong 0 singleton.
*/
PbULong.ZERO = new PbULong(0, 0);
/**
* 64-bit signed integer as two 32-bit values.
* Converts between `string`, `number` and `bigint` representations.
*/
var PbLong = class PbLong extends SharedPbLong {
	/**
	* Create instance from a `string`, `number` or `bigint`.
	*/
	static from(value) {
		if (BI) switch (typeof value) {
			case "string":
				if (value == "0") return this.ZERO;
				if (value == "") throw new Error("string is no integer");
				value = BI.C(value);
			case "number":
				if (value === 0) return this.ZERO;
				value = BI.C(value);
			case "bigint":
				if (!value) return this.ZERO;
				if (value < BI.MIN) throw new Error("signed long too small");
				if (value > BI.MAX) throw new Error("signed long too large");
				BI.V.setBigInt64(0, value, true);
				return new PbLong(BI.V.getInt32(0, true), BI.V.getInt32(4, true));
		}
		else switch (typeof value) {
			case "string":
				if (value == "0") return this.ZERO;
				value = value.trim();
				if (!RE_DECIMAL_STR.test(value)) throw new Error("string is no integer");
				let [minus, lo, hi] = int64fromString(value);
				if (minus) {
					if (hi > HALF_2_PWR_32 || hi == HALF_2_PWR_32 && lo != 0) throw new Error("signed long too small");
				} else if (hi >= HALF_2_PWR_32) throw new Error("signed long too large");
				let pbl = new PbLong(lo, hi);
				return minus ? pbl.negate() : pbl;
			case "number":
				if (value == 0) return this.ZERO;
				if (!Number.isSafeInteger(value)) throw new Error("number is no integer");
				return value > 0 ? new PbLong(value, value / TWO_PWR_32_DBL) : new PbLong(-value, -value / TWO_PWR_32_DBL).negate();
		}
		throw new Error("unknown value " + typeof value);
	}
	/**
	* Do we have a minus sign?
	*/
	isNegative() {
		return (this.hi & HALF_2_PWR_32) !== 0;
	}
	/**
	* Negate two's complement.
	* Invert all the bits and add one to the result.
	*/
	negate() {
		let hi = ~this.hi, lo = this.lo;
		if (lo) lo = ~lo + 1;
		else hi += 1;
		return new PbLong(lo, hi);
	}
	/**
	* Convert to decimal string.
	*/
	toString() {
		if (BI) return this.toBigInt().toString();
		if (this.isNegative()) {
			let n = this.negate();
			return "-" + int64toString(n.lo, n.hi);
		}
		return int64toString(this.lo, this.hi);
	}
	/**
	* Convert to native bigint.
	*/
	toBigInt() {
		assertBi(BI);
		BI.V.setInt32(0, this.lo, true);
		BI.V.setInt32(4, this.hi, true);
		return BI.V.getBigInt64(0, true);
	}
};
/**
* long 0 singleton.
*/
PbLong.ZERO = new PbLong(0, 0);
var defaultsRead$1 = {
	readUnknownField: true,
	readerFactory: (bytes) => new BinaryReader(bytes)
};
/**
* Make options for reading binary data form partial options.
*/
function binaryReadOptions(options) {
	return options ? Object.assign(Object.assign({}, defaultsRead$1), options) : defaultsRead$1;
}
var BinaryReader = class {
	constructor(buf, textDecoder) {
		this.varint64 = varint64read;
		/**
		* Read a `uint32` field, an unsigned 32 bit varint.
		*/
		this.uint32 = varint32read;
		this.buf = buf;
		this.len = buf.length;
		this.pos = 0;
		this.view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
		this.textDecoder = textDecoder !== null && textDecoder !== void 0 ? textDecoder : new TextDecoder("utf-8", {
			fatal: true,
			ignoreBOM: true
		});
	}
	/**
	* Reads a tag - field number and wire type.
	*/
	tag() {
		let tag = this.uint32(), fieldNo = tag >>> 3, wireType = tag & 7;
		if (fieldNo <= 0 || wireType < 0 || wireType > 5) throw new Error("illegal tag: field no " + fieldNo + " wire type " + wireType);
		return [fieldNo, wireType];
	}
	/**
	* Skip one element on the wire and return the skipped data.
	* Supports WireType.StartGroup since v2.0.0-alpha.23.
	*/
	skip(wireType) {
		let start = this.pos;
		switch (wireType) {
			case WireType.Varint:
				while (this.buf[this.pos++] & 128);
				break;
			case WireType.Bit64: this.pos += 4;
			case WireType.Bit32:
				this.pos += 4;
				break;
			case WireType.LengthDelimited:
				let len = this.uint32();
				this.pos += len;
				break;
			case WireType.StartGroup:
				let t;
				while ((t = this.tag()[1]) !== WireType.EndGroup) this.skip(t);
				break;
			default: throw new Error("cant skip wire type " + wireType);
		}
		this.assertBounds();
		return this.buf.subarray(start, this.pos);
	}
	/**
	* Throws error if position in byte array is out of range.
	*/
	assertBounds() {
		if (this.pos > this.len) throw new RangeError("premature EOF");
	}
	/**
	* Read a `int32` field, a signed 32 bit varint.
	*/
	int32() {
		return this.uint32() | 0;
	}
	/**
	* Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
	*/
	sint32() {
		let zze = this.uint32();
		return zze >>> 1 ^ -(zze & 1);
	}
	/**
	* Read a `int64` field, a signed 64-bit varint.
	*/
	int64() {
		return new PbLong(...this.varint64());
	}
	/**
	* Read a `uint64` field, an unsigned 64-bit varint.
	*/
	uint64() {
		return new PbULong(...this.varint64());
	}
	/**
	* Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
	*/
	sint64() {
		let [lo, hi] = this.varint64();
		let s = -(lo & 1);
		lo = (lo >>> 1 | (hi & 1) << 31) ^ s;
		hi = hi >>> 1 ^ s;
		return new PbLong(lo, hi);
	}
	/**
	* Read a `bool` field, a variant.
	*/
	bool() {
		let [lo, hi] = this.varint64();
		return lo !== 0 || hi !== 0;
	}
	/**
	* Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
	*/
	fixed32() {
		return this.view.getUint32((this.pos += 4) - 4, true);
	}
	/**
	* Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
	*/
	sfixed32() {
		return this.view.getInt32((this.pos += 4) - 4, true);
	}
	/**
	* Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
	*/
	fixed64() {
		return new PbULong(this.sfixed32(), this.sfixed32());
	}
	/**
	* Read a `fixed64` field, a signed, fixed-length 64-bit integer.
	*/
	sfixed64() {
		return new PbLong(this.sfixed32(), this.sfixed32());
	}
	/**
	* Read a `float` field, 32-bit floating point number.
	*/
	float() {
		return this.view.getFloat32((this.pos += 4) - 4, true);
	}
	/**
	* Read a `double` field, a 64-bit floating point number.
	*/
	double() {
		return this.view.getFloat64((this.pos += 8) - 8, true);
	}
	/**
	* Read a `bytes` field, length-delimited arbitrary data.
	*/
	bytes() {
		let len = this.uint32();
		let start = this.pos;
		this.pos += len;
		this.assertBounds();
		return this.buf.subarray(start, start + len);
	}
	/**
	* Read a `string` field, length-delimited data converted to UTF-8 text.
	*/
	string() {
		return this.textDecoder.decode(this.bytes());
	}
};
/**
* assert that condition is true or throw error (with message)
*/
function assert(condition, msg) {
	if (!condition) throw new Error(msg);
}
var FLOAT32_MAX = 34028234663852886e22, FLOAT32_MIN = -34028234663852886e22, UINT32_MAX = 4294967295, INT32_MAX = 2147483647, INT32_MIN = -2147483648;
function assertInt32(arg) {
	if (typeof arg !== "number") throw new Error("invalid int 32: " + typeof arg);
	if (!Number.isInteger(arg) || arg > INT32_MAX || arg < INT32_MIN) throw new Error("invalid int 32: " + arg);
}
function assertUInt32(arg) {
	if (typeof arg !== "number") throw new Error("invalid uint 32: " + typeof arg);
	if (!Number.isInteger(arg) || arg > UINT32_MAX || arg < 0) throw new Error("invalid uint 32: " + arg);
}
function assertFloat32(arg) {
	if (typeof arg !== "number") throw new Error("invalid float 32: " + typeof arg);
	if (!Number.isFinite(arg)) return;
	if (arg > FLOAT32_MAX || arg < FLOAT32_MIN) throw new Error("invalid float 32: " + arg);
}
var defaultsWrite$1 = {
	writeUnknownFields: true,
	writerFactory: () => new BinaryWriter()
};
/**
* Make options for writing binary data form partial options.
*/
function binaryWriteOptions(options) {
	return options ? Object.assign(Object.assign({}, defaultsWrite$1), options) : defaultsWrite$1;
}
var BinaryWriter = class {
	constructor(textEncoder) {
		/**
		* Previous fork states.
		*/
		this.stack = [];
		this.textEncoder = textEncoder !== null && textEncoder !== void 0 ? textEncoder : new TextEncoder();
		this.chunks = [];
		this.buf = [];
	}
	/**
	* Return all bytes written and reset this writer.
	*/
	finish() {
		this.chunks.push(new Uint8Array(this.buf));
		let len = 0;
		for (let i = 0; i < this.chunks.length; i++) len += this.chunks[i].length;
		let bytes = new Uint8Array(len);
		let offset = 0;
		for (let i = 0; i < this.chunks.length; i++) {
			bytes.set(this.chunks[i], offset);
			offset += this.chunks[i].length;
		}
		this.chunks = [];
		return bytes;
	}
	/**
	* Start a new fork for length-delimited data like a message
	* or a packed repeated field.
	*
	* Must be joined later with `join()`.
	*/
	fork() {
		this.stack.push({
			chunks: this.chunks,
			buf: this.buf
		});
		this.chunks = [];
		this.buf = [];
		return this;
	}
	/**
	* Join the last fork. Write its length and bytes, then
	* return to the previous state.
	*/
	join() {
		let chunk = this.finish();
		let prev = this.stack.pop();
		if (!prev) throw new Error("invalid state, fork stack empty");
		this.chunks = prev.chunks;
		this.buf = prev.buf;
		this.uint32(chunk.byteLength);
		return this.raw(chunk);
	}
	/**
	* Writes a tag (field number and wire type).
	*
	* Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
	*
	* Generated code should compute the tag ahead of time and call `uint32()`.
	*/
	tag(fieldNo, type) {
		return this.uint32((fieldNo << 3 | type) >>> 0);
	}
	/**
	* Write a chunk of raw bytes.
	*/
	raw(chunk) {
		if (this.buf.length) {
			this.chunks.push(new Uint8Array(this.buf));
			this.buf = [];
		}
		this.chunks.push(chunk);
		return this;
	}
	/**
	* Write a `uint32` value, an unsigned 32 bit varint.
	*/
	uint32(value) {
		assertUInt32(value);
		while (value > 127) {
			this.buf.push(value & 127 | 128);
			value = value >>> 7;
		}
		this.buf.push(value);
		return this;
	}
	/**
	* Write a `int32` value, a signed 32 bit varint.
	*/
	int32(value) {
		assertInt32(value);
		varint32write(value, this.buf);
		return this;
	}
	/**
	* Write a `bool` value, a variant.
	*/
	bool(value) {
		this.buf.push(value ? 1 : 0);
		return this;
	}
	/**
	* Write a `bytes` value, length-delimited arbitrary data.
	*/
	bytes(value) {
		this.uint32(value.byteLength);
		return this.raw(value);
	}
	/**
	* Write a `string` value, length-delimited data converted to UTF-8 text.
	*/
	string(value) {
		let chunk = this.textEncoder.encode(value);
		this.uint32(chunk.byteLength);
		return this.raw(chunk);
	}
	/**
	* Write a `float` value, 32-bit floating point number.
	*/
	float(value) {
		assertFloat32(value);
		let chunk = new Uint8Array(4);
		new DataView(chunk.buffer).setFloat32(0, value, true);
		return this.raw(chunk);
	}
	/**
	* Write a `double` value, a 64-bit floating point number.
	*/
	double(value) {
		let chunk = new Uint8Array(8);
		new DataView(chunk.buffer).setFloat64(0, value, true);
		return this.raw(chunk);
	}
	/**
	* Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
	*/
	fixed32(value) {
		assertUInt32(value);
		let chunk = new Uint8Array(4);
		new DataView(chunk.buffer).setUint32(0, value, true);
		return this.raw(chunk);
	}
	/**
	* Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
	*/
	sfixed32(value) {
		assertInt32(value);
		let chunk = new Uint8Array(4);
		new DataView(chunk.buffer).setInt32(0, value, true);
		return this.raw(chunk);
	}
	/**
	* Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
	*/
	sint32(value) {
		assertInt32(value);
		value = (value << 1 ^ value >> 31) >>> 0;
		varint32write(value, this.buf);
		return this;
	}
	/**
	* Write a `fixed64` value, a signed, fixed-length 64-bit integer.
	*/
	sfixed64(value) {
		let chunk = new Uint8Array(8);
		let view = new DataView(chunk.buffer);
		let long = PbLong.from(value);
		view.setInt32(0, long.lo, true);
		view.setInt32(4, long.hi, true);
		return this.raw(chunk);
	}
	/**
	* Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
	*/
	fixed64(value) {
		let chunk = new Uint8Array(8);
		let view = new DataView(chunk.buffer);
		let long = PbULong.from(value);
		view.setInt32(0, long.lo, true);
		view.setInt32(4, long.hi, true);
		return this.raw(chunk);
	}
	/**
	* Write a `int64` value, a signed 64-bit varint.
	*/
	int64(value) {
		let long = PbLong.from(value);
		varint64write(long.lo, long.hi, this.buf);
		return this;
	}
	/**
	* Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
	*/
	sint64(value) {
		let long = PbLong.from(value), sign = long.hi >> 31;
		varint64write(long.lo << 1 ^ sign, (long.hi << 1 | long.lo >>> 31) ^ sign, this.buf);
		return this;
	}
	/**
	* Write a `uint64` value, an unsigned 64-bit varint.
	*/
	uint64(value) {
		let long = PbULong.from(value);
		varint64write(long.lo, long.hi, this.buf);
		return this;
	}
};
var defaultsWrite = {
	emitDefaultValues: false,
	enumAsInteger: false,
	useProtoFieldName: false,
	prettySpaces: 0
}, defaultsRead = { ignoreUnknownFields: false };
/**
* Make options for reading JSON data from partial options.
*/
function jsonReadOptions(options) {
	return options ? Object.assign(Object.assign({}, defaultsRead), options) : defaultsRead;
}
/**
* Make options for writing JSON data from partial options.
*/
function jsonWriteOptions(options) {
	return options ? Object.assign(Object.assign({}, defaultsWrite), options) : defaultsWrite;
}
/**
* The symbol used as a key on message objects to store the message type.
*
* Note that this is an experimental feature - it is here to stay, but
* implementation details may change without notice.
*/
const MESSAGE_TYPE = Symbol.for("protobuf-ts/message-type");
/**
* Converts snake_case to lowerCamelCase.
*
* Should behave like protoc:
* https://github.com/protocolbuffers/protobuf/blob/e8ae137c96444ea313485ed1118c5e43b2099cf1/src/google/protobuf/compiler/java/java_helpers.cc#L118
*/
function lowerCamelCase(snakeCase) {
	let capNext = false;
	const sb = [];
	for (let i = 0; i < snakeCase.length; i++) {
		let next = snakeCase.charAt(i);
		if (next == "_") capNext = true;
		else if (/\d/.test(next)) {
			sb.push(next);
			capNext = true;
		} else if (capNext) {
			sb.push(next.toUpperCase());
			capNext = false;
		} else if (i == 0) sb.push(next.toLowerCase());
		else sb.push(next);
	}
	return sb.join("");
}
/**
* Scalar value types. This is a subset of field types declared by protobuf
* enum google.protobuf.FieldDescriptorProto.Type The types GROUP and MESSAGE
* are omitted, but the numerical values are identical.
*/
var ScalarType;
(function(ScalarType) {
	ScalarType[ScalarType["DOUBLE"] = 1] = "DOUBLE";
	ScalarType[ScalarType["FLOAT"] = 2] = "FLOAT";
	ScalarType[ScalarType["INT64"] = 3] = "INT64";
	ScalarType[ScalarType["UINT64"] = 4] = "UINT64";
	ScalarType[ScalarType["INT32"] = 5] = "INT32";
	ScalarType[ScalarType["FIXED64"] = 6] = "FIXED64";
	ScalarType[ScalarType["FIXED32"] = 7] = "FIXED32";
	ScalarType[ScalarType["BOOL"] = 8] = "BOOL";
	ScalarType[ScalarType["STRING"] = 9] = "STRING";
	ScalarType[ScalarType["BYTES"] = 12] = "BYTES";
	ScalarType[ScalarType["UINT32"] = 13] = "UINT32";
	ScalarType[ScalarType["SFIXED32"] = 15] = "SFIXED32";
	ScalarType[ScalarType["SFIXED64"] = 16] = "SFIXED64";
	ScalarType[ScalarType["SINT32"] = 17] = "SINT32";
	ScalarType[ScalarType["SINT64"] = 18] = "SINT64";
})(ScalarType || (ScalarType = {}));
/**
* JavaScript representation of 64 bit integral types. Equivalent to the
* field option "jstype".
*
* By default, protobuf-ts represents 64 bit types as `bigint`.
*
* You can change the default behaviour by enabling the plugin parameter
* `long_type_string`, which will represent 64 bit types as `string`.
*
* Alternatively, you can change the behaviour for individual fields
* with the field option "jstype":
*
* ```protobuf
* uint64 my_field = 1 [jstype = JS_STRING];
* uint64 other_field = 2 [jstype = JS_NUMBER];
* ```
*/
var LongType;
(function(LongType) {
	/**
	* Use JavaScript `bigint`.
	*
	* Field option `[jstype = JS_NORMAL]`.
	*/
	LongType[LongType["BIGINT"] = 0] = "BIGINT";
	/**
	* Use JavaScript `string`.
	*
	* Field option `[jstype = JS_STRING]`.
	*/
	LongType[LongType["STRING"] = 1] = "STRING";
	/**
	* Use JavaScript `number`.
	*
	* Large values will loose precision.
	*
	* Field option `[jstype = JS_NUMBER]`.
	*/
	LongType[LongType["NUMBER"] = 2] = "NUMBER";
})(LongType || (LongType = {}));
/**
* Protobuf 2.1.0 introduced packed repeated fields.
* Setting the field option `[packed = true]` enables packing.
*
* In proto3, all repeated fields are packed by default.
* Setting the field option `[packed = false]` disables packing.
*
* Packed repeated fields are encoded with a single tag,
* then a length-delimiter, then the element values.
*
* Unpacked repeated fields are encoded with a tag and
* value for each element.
*
* `bytes` and `string` cannot be packed.
*/
var RepeatType;
(function(RepeatType) {
	/**
	* The field is not repeated.
	*/
	RepeatType[RepeatType["NO"] = 0] = "NO";
	/**
	* The field is repeated and should be packed.
	* Invalid for `bytes` and `string`, they cannot be packed.
	*/
	RepeatType[RepeatType["PACKED"] = 1] = "PACKED";
	/**
	* The field is repeated but should not be packed.
	* The only valid repeat type for repeated `bytes` and `string`.
	*/
	RepeatType[RepeatType["UNPACKED"] = 2] = "UNPACKED";
})(RepeatType || (RepeatType = {}));
/**
* Turns PartialFieldInfo into FieldInfo.
*/
function normalizeFieldInfo(field) {
	var _a, _b, _c, _d;
	field.localName = (_a = field.localName) !== null && _a !== void 0 ? _a : lowerCamelCase(field.name);
	field.jsonName = (_b = field.jsonName) !== null && _b !== void 0 ? _b : lowerCamelCase(field.name);
	field.repeat = (_c = field.repeat) !== null && _c !== void 0 ? _c : RepeatType.NO;
	field.opt = (_d = field.opt) !== null && _d !== void 0 ? _d : field.repeat ? false : field.oneof ? false : field.kind == "message";
	return field;
}
/**
* Is the given value a valid oneof group?
*
* We represent protobuf `oneof` as algebraic data types (ADT) in generated
* code. But when working with messages of unknown type, the ADT does not
* help us.
*
* This type guard checks if the given object adheres to the ADT rules, which
* are as follows:
*
* 1) Must be an object.
*
* 2) Must have a "oneofKind" discriminator property.
*
* 3) If "oneofKind" is `undefined`, no member field is selected. The object
* must not have any other properties.
*
* 4) If "oneofKind" is a `string`, the member field with this name is
* selected.
*
* 5) If a member field is selected, the object must have a second property
* with this name. The property must not be `undefined`.
*
* 6) No extra properties are allowed. The object has either one property
* (no selection) or two properties (selection).
*
*/
function isOneofGroup(any) {
	if (typeof any != "object" || any === null || !any.hasOwnProperty("oneofKind")) return false;
	switch (typeof any.oneofKind) {
		case "string":
			if (any[any.oneofKind] === void 0) return false;
			return Object.keys(any).length == 2;
		case "undefined": return Object.keys(any).length == 1;
		default: return false;
	}
}
var ReflectionTypeCheck = class {
	constructor(info) {
		var _a;
		this.fields = (_a = info.fields) !== null && _a !== void 0 ? _a : [];
	}
	prepare() {
		if (this.data) return;
		const req = [], known = [], oneofs = [];
		for (let field of this.fields) if (field.oneof) {
			if (!oneofs.includes(field.oneof)) {
				oneofs.push(field.oneof);
				req.push(field.oneof);
				known.push(field.oneof);
			}
		} else {
			known.push(field.localName);
			switch (field.kind) {
				case "scalar":
				case "enum":
					if (!field.opt || field.repeat) req.push(field.localName);
					break;
				case "message":
					if (field.repeat) req.push(field.localName);
					break;
				case "map":
					req.push(field.localName);
					break;
			}
		}
		this.data = {
			req,
			known,
			oneofs: Object.values(oneofs)
		};
	}
	/**
	* Is the argument a valid message as specified by the
	* reflection information?
	*
	* Checks all field types recursively. The `depth`
	* specifies how deep into the structure the check will be.
	*
	* With a depth of 0, only the presence of fields
	* is checked.
	*
	* With a depth of 1 or more, the field types are checked.
	*
	* With a depth of 2 or more, the members of map, repeated
	* and message fields are checked.
	*
	* Message fields will be checked recursively with depth - 1.
	*
	* The number of map entries / repeated values being checked
	* is < depth.
	*/
	is(message, depth, allowExcessProperties = false) {
		if (depth < 0) return true;
		if (message === null || message === void 0 || typeof message != "object") return false;
		this.prepare();
		let keys = Object.keys(message), data = this.data;
		if (keys.length < data.req.length || data.req.some((n) => !keys.includes(n))) return false;
		if (!allowExcessProperties) {
			if (keys.some((k) => !data.known.includes(k))) return false;
		}
		if (depth < 1) return true;
		for (const name of data.oneofs) {
			const group = message[name];
			if (!isOneofGroup(group)) return false;
			if (group.oneofKind === void 0) continue;
			const field = this.fields.find((f) => f.localName === group.oneofKind);
			if (!field) return false;
			if (!this.field(group[group.oneofKind], field, allowExcessProperties, depth)) return false;
		}
		for (const field of this.fields) {
			if (field.oneof !== void 0) continue;
			if (!this.field(message[field.localName], field, allowExcessProperties, depth)) return false;
		}
		return true;
	}
	field(arg, field, allowExcessProperties, depth) {
		let repeated = field.repeat;
		switch (field.kind) {
			case "scalar":
				if (arg === void 0) return field.opt;
				if (repeated) return this.scalars(arg, field.T, depth, field.L);
				return this.scalar(arg, field.T, field.L);
			case "enum":
				if (arg === void 0) return field.opt;
				if (repeated) return this.scalars(arg, ScalarType.INT32, depth);
				return this.scalar(arg, ScalarType.INT32);
			case "message":
				if (arg === void 0) return true;
				if (repeated) return this.messages(arg, field.T(), allowExcessProperties, depth);
				return this.message(arg, field.T(), allowExcessProperties, depth);
			case "map":
				if (typeof arg != "object" || arg === null) return false;
				if (depth < 2) return true;
				if (!this.mapKeys(arg, field.K, depth)) return false;
				switch (field.V.kind) {
					case "scalar": return this.scalars(Object.values(arg), field.V.T, depth, field.V.L);
					case "enum": return this.scalars(Object.values(arg), ScalarType.INT32, depth);
					case "message": return this.messages(Object.values(arg), field.V.T(), allowExcessProperties, depth);
				}
				break;
		}
		return true;
	}
	message(arg, type, allowExcessProperties, depth) {
		if (allowExcessProperties) return type.isAssignable(arg, depth);
		return type.is(arg, depth);
	}
	messages(arg, type, allowExcessProperties, depth) {
		if (!Array.isArray(arg)) return false;
		if (depth < 2) return true;
		if (allowExcessProperties) {
			for (let i = 0; i < arg.length && i < depth; i++) if (!type.isAssignable(arg[i], depth - 1)) return false;
		} else for (let i = 0; i < arg.length && i < depth; i++) if (!type.is(arg[i], depth - 1)) return false;
		return true;
	}
	scalar(arg, type, longType) {
		let argType = typeof arg;
		switch (type) {
			case ScalarType.UINT64:
			case ScalarType.FIXED64:
			case ScalarType.INT64:
			case ScalarType.SFIXED64:
			case ScalarType.SINT64: switch (longType) {
				case LongType.BIGINT: return argType == "bigint";
				case LongType.NUMBER: return argType == "number" && !isNaN(arg);
				default: return argType == "string";
			}
			case ScalarType.BOOL: return argType == "boolean";
			case ScalarType.STRING: return argType == "string";
			case ScalarType.BYTES: return arg instanceof Uint8Array;
			case ScalarType.DOUBLE:
			case ScalarType.FLOAT: return argType == "number" && !isNaN(arg);
			default: return argType == "number" && Number.isInteger(arg);
		}
	}
	scalars(arg, type, depth, longType) {
		if (!Array.isArray(arg)) return false;
		if (depth < 2) return true;
		if (Array.isArray(arg)) {
			for (let i = 0; i < arg.length && i < depth; i++) if (!this.scalar(arg[i], type, longType)) return false;
		}
		return true;
	}
	mapKeys(map, type, depth) {
		let keys = Object.keys(map);
		switch (type) {
			case ScalarType.INT32:
			case ScalarType.FIXED32:
			case ScalarType.SFIXED32:
			case ScalarType.SINT32:
			case ScalarType.UINT32: return this.scalars(keys.slice(0, depth).map((k) => parseInt(k)), type, depth);
			case ScalarType.BOOL: return this.scalars(keys.slice(0, depth).map((k) => k == "true" ? true : k == "false" ? false : k), type, depth);
			default: return this.scalars(keys, type, depth, LongType.STRING);
		}
	}
};
/**
* Utility method to convert a PbLong or PbUlong to a JavaScript
* representation during runtime.
*
* Works with generated field information, `undefined` is equivalent
* to `STRING`.
*/
function reflectionLongConvert(long, type) {
	switch (type) {
		case LongType.BIGINT: return long.toBigInt();
		case LongType.NUMBER: return long.toNumber();
		default: return long.toString();
	}
}
/**
* Reads proto3 messages in canonical JSON format using reflection information.
*
* https://developers.google.com/protocol-buffers/docs/proto3#json
*/
var ReflectionJsonReader = class {
	constructor(info) {
		this.info = info;
	}
	prepare() {
		var _a;
		if (this.fMap === void 0) {
			this.fMap = {};
			const fieldsInput = (_a = this.info.fields) !== null && _a !== void 0 ? _a : [];
			for (const field of fieldsInput) {
				this.fMap[field.name] = field;
				this.fMap[field.jsonName] = field;
				this.fMap[field.localName] = field;
			}
		}
	}
	assert(condition, fieldName, jsonValue) {
		if (!condition) {
			let what = typeofJsonValue(jsonValue);
			if (what == "number" || what == "boolean") what = jsonValue.toString();
			throw new Error(`Cannot parse JSON ${what} for ${this.info.typeName}#${fieldName}`);
		}
	}
	/**
	* Reads a message from canonical JSON format into the target message.
	*
	* Repeated fields are appended. Map entries are added, overwriting
	* existing keys.
	*
	* If a message field is already present, it will be merged with the
	* new data.
	*/
	read(input, message, options) {
		this.prepare();
		const oneofsHandled = [];
		for (const [jsonKey, jsonValue] of Object.entries(input)) {
			const field = this.fMap[jsonKey];
			if (!field) {
				if (!options.ignoreUnknownFields) throw new Error(`Found unknown field while reading ${this.info.typeName} from JSON format. JSON key: ${jsonKey}`);
				continue;
			}
			const localName = field.localName;
			let target;
			if (field.oneof) {
				if (jsonValue === null && (field.kind !== "enum" || field.T()[0] !== "google.protobuf.NullValue")) continue;
				if (oneofsHandled.includes(field.oneof)) throw new Error(`Multiple members of the oneof group "${field.oneof}" of ${this.info.typeName} are present in JSON.`);
				oneofsHandled.push(field.oneof);
				target = message[field.oneof] = { oneofKind: localName };
			} else target = message;
			if (field.kind == "map") {
				if (jsonValue === null) continue;
				this.assert(isJsonObject(jsonValue), field.name, jsonValue);
				const fieldObj = target[localName];
				for (const [jsonObjKey, jsonObjValue] of Object.entries(jsonValue)) {
					this.assert(jsonObjValue !== null, field.name + " map value", null);
					let val;
					switch (field.V.kind) {
						case "message":
							val = field.V.T().internalJsonRead(jsonObjValue, options);
							break;
						case "enum":
							val = this.enum(field.V.T(), jsonObjValue, field.name, options.ignoreUnknownFields);
							if (val === false) continue;
							break;
						case "scalar":
							val = this.scalar(jsonObjValue, field.V.T, field.V.L, field.name);
							break;
					}
					this.assert(val !== void 0, field.name + " map value", jsonObjValue);
					let key = jsonObjKey;
					if (field.K == ScalarType.BOOL) key = key == "true" ? true : key == "false" ? false : key;
					key = this.scalar(key, field.K, LongType.STRING, field.name).toString();
					fieldObj[key] = val;
				}
			} else if (field.repeat) {
				if (jsonValue === null) continue;
				this.assert(Array.isArray(jsonValue), field.name, jsonValue);
				const fieldArr = target[localName];
				for (const jsonItem of jsonValue) {
					this.assert(jsonItem !== null, field.name, null);
					let val;
					switch (field.kind) {
						case "message":
							val = field.T().internalJsonRead(jsonItem, options);
							break;
						case "enum":
							val = this.enum(field.T(), jsonItem, field.name, options.ignoreUnknownFields);
							if (val === false) continue;
							break;
						case "scalar":
							val = this.scalar(jsonItem, field.T, field.L, field.name);
							break;
					}
					this.assert(val !== void 0, field.name, jsonValue);
					fieldArr.push(val);
				}
			} else switch (field.kind) {
				case "message":
					if (jsonValue === null && field.T().typeName != "google.protobuf.Value") {
						this.assert(field.oneof === void 0, field.name + " (oneof member)", null);
						continue;
					}
					target[localName] = field.T().internalJsonRead(jsonValue, options, target[localName]);
					break;
				case "enum":
					if (jsonValue === null) continue;
					let val = this.enum(field.T(), jsonValue, field.name, options.ignoreUnknownFields);
					if (val === false) continue;
					target[localName] = val;
					break;
				case "scalar":
					if (jsonValue === null) continue;
					target[localName] = this.scalar(jsonValue, field.T, field.L, field.name);
					break;
			}
		}
	}
	/**
	* Returns `false` for unrecognized string representations.
	*
	* google.protobuf.NullValue accepts only JSON `null` (or the old `"NULL_VALUE"`).
	*/
	enum(type, json, fieldName, ignoreUnknownFields) {
		if (type[0] == "google.protobuf.NullValue") assert(json === null || json === "NULL_VALUE", `Unable to parse field ${this.info.typeName}#${fieldName}, enum ${type[0]} only accepts null.`);
		if (json === null) return 0;
		switch (typeof json) {
			case "number":
				assert(Number.isInteger(json), `Unable to parse field ${this.info.typeName}#${fieldName}, enum can only be integral number, got ${json}.`);
				return json;
			case "string":
				let localEnumName = json;
				if (type[2] && json.substring(0, type[2].length) === type[2]) localEnumName = json.substring(type[2].length);
				let enumNumber = type[1][localEnumName];
				if (typeof enumNumber === "undefined" && ignoreUnknownFields) return false;
				assert(typeof enumNumber == "number", `Unable to parse field ${this.info.typeName}#${fieldName}, enum ${type[0]} has no value for "${json}".`);
				return enumNumber;
		}
		assert(false, `Unable to parse field ${this.info.typeName}#${fieldName}, cannot parse enum value from ${typeof json}".`);
	}
	scalar(json, type, longType, fieldName) {
		let e;
		try {
			switch (type) {
				case ScalarType.DOUBLE:
				case ScalarType.FLOAT:
					if (json === null) return 0;
					if (json === "NaN") return NaN;
					if (json === "Infinity") return Number.POSITIVE_INFINITY;
					if (json === "-Infinity") return Number.NEGATIVE_INFINITY;
					if (json === "") {
						e = "empty string";
						break;
					}
					if (typeof json == "string" && json.trim().length !== json.length) {
						e = "extra whitespace";
						break;
					}
					if (typeof json != "string" && typeof json != "number") break;
					let float = Number(json);
					if (Number.isNaN(float)) {
						e = "not a number";
						break;
					}
					if (!Number.isFinite(float)) {
						e = "too large or small";
						break;
					}
					if (type == ScalarType.FLOAT) assertFloat32(float);
					return float;
				case ScalarType.INT32:
				case ScalarType.FIXED32:
				case ScalarType.SFIXED32:
				case ScalarType.SINT32:
				case ScalarType.UINT32:
					if (json === null) return 0;
					let int32;
					if (typeof json == "number") int32 = json;
					else if (json === "") e = "empty string";
					else if (typeof json == "string") if (json.trim().length !== json.length) e = "extra whitespace";
					else int32 = Number(json);
					if (int32 === void 0) break;
					if (type == ScalarType.UINT32) assertUInt32(int32);
					else assertInt32(int32);
					return int32;
				case ScalarType.INT64:
				case ScalarType.SFIXED64:
				case ScalarType.SINT64:
					if (json === null) return reflectionLongConvert(PbLong.ZERO, longType);
					if (typeof json != "number" && typeof json != "string") break;
					return reflectionLongConvert(PbLong.from(json), longType);
				case ScalarType.FIXED64:
				case ScalarType.UINT64:
					if (json === null) return reflectionLongConvert(PbULong.ZERO, longType);
					if (typeof json != "number" && typeof json != "string") break;
					return reflectionLongConvert(PbULong.from(json), longType);
				case ScalarType.BOOL:
					if (json === null) return false;
					if (typeof json !== "boolean") break;
					return json;
				case ScalarType.STRING:
					if (json === null) return "";
					if (typeof json !== "string") {
						e = "extra whitespace";
						break;
					}
					return json;
				case ScalarType.BYTES:
					if (json === null || json === "") return new Uint8Array(0);
					if (typeof json !== "string") break;
					return base64decode(json);
			}
		} catch (error) {
			e = error.message;
		}
		this.assert(false, fieldName + (e ? " - " + e : ""), json);
	}
};
/**
* Writes proto3 messages in canonical JSON format using reflection
* information.
*
* https://developers.google.com/protocol-buffers/docs/proto3#json
*/
var ReflectionJsonWriter = class {
	constructor(info) {
		var _a;
		this.fields = (_a = info.fields) !== null && _a !== void 0 ? _a : [];
	}
	/**
	* Converts the message to a JSON object, based on the field descriptors.
	*/
	write(message, options) {
		const json = {}, source = message;
		for (const field of this.fields) {
			if (!field.oneof) {
				let jsonValue = this.field(field, source[field.localName], options);
				if (jsonValue !== void 0) json[options.useProtoFieldName ? field.name : field.jsonName] = jsonValue;
				continue;
			}
			const group = source[field.oneof];
			if (group.oneofKind !== field.localName) continue;
			const opt = field.kind == "scalar" || field.kind == "enum" ? Object.assign(Object.assign({}, options), { emitDefaultValues: true }) : options;
			let jsonValue = this.field(field, group[field.localName], opt);
			assert(jsonValue !== void 0);
			json[options.useProtoFieldName ? field.name : field.jsonName] = jsonValue;
		}
		return json;
	}
	field(field, value, options) {
		let jsonValue = void 0;
		if (field.kind == "map") {
			assert(typeof value == "object" && value !== null);
			const jsonObj = {};
			switch (field.V.kind) {
				case "scalar":
					for (const [entryKey, entryValue] of Object.entries(value)) {
						const val = this.scalar(field.V.T, entryValue, field.name, false, true);
						assert(val !== void 0);
						jsonObj[entryKey.toString()] = val;
					}
					break;
				case "message":
					const messageType = field.V.T();
					for (const [entryKey, entryValue] of Object.entries(value)) {
						const val = this.message(messageType, entryValue, field.name, options);
						assert(val !== void 0);
						jsonObj[entryKey.toString()] = val;
					}
					break;
				case "enum":
					const enumInfo = field.V.T();
					for (const [entryKey, entryValue] of Object.entries(value)) {
						assert(entryValue === void 0 || typeof entryValue == "number");
						const val = this.enum(enumInfo, entryValue, field.name, false, true, options.enumAsInteger);
						assert(val !== void 0);
						jsonObj[entryKey.toString()] = val;
					}
					break;
			}
			if (options.emitDefaultValues || Object.keys(jsonObj).length > 0) jsonValue = jsonObj;
		} else if (field.repeat) {
			assert(Array.isArray(value));
			const jsonArr = [];
			switch (field.kind) {
				case "scalar":
					for (let i = 0; i < value.length; i++) {
						const val = this.scalar(field.T, value[i], field.name, field.opt, true);
						assert(val !== void 0);
						jsonArr.push(val);
					}
					break;
				case "enum":
					const enumInfo = field.T();
					for (let i = 0; i < value.length; i++) {
						assert(value[i] === void 0 || typeof value[i] == "number");
						const val = this.enum(enumInfo, value[i], field.name, field.opt, true, options.enumAsInteger);
						assert(val !== void 0);
						jsonArr.push(val);
					}
					break;
				case "message":
					const messageType = field.T();
					for (let i = 0; i < value.length; i++) {
						const val = this.message(messageType, value[i], field.name, options);
						assert(val !== void 0);
						jsonArr.push(val);
					}
					break;
			}
			if (options.emitDefaultValues || jsonArr.length > 0 || options.emitDefaultValues) jsonValue = jsonArr;
		} else switch (field.kind) {
			case "scalar":
				jsonValue = this.scalar(field.T, value, field.name, field.opt, options.emitDefaultValues);
				break;
			case "enum":
				jsonValue = this.enum(field.T(), value, field.name, field.opt, options.emitDefaultValues, options.enumAsInteger);
				break;
			case "message":
				jsonValue = this.message(field.T(), value, field.name, options);
				break;
		}
		return jsonValue;
	}
	/**
	* Returns `null` as the default for google.protobuf.NullValue.
	*/
	enum(type, value, fieldName, optional, emitDefaultValues, enumAsInteger) {
		if (type[0] == "google.protobuf.NullValue") return !emitDefaultValues && !optional ? void 0 : null;
		if (value === void 0) {
			assert(optional);
			return;
		}
		if (value === 0 && !emitDefaultValues && !optional) return void 0;
		assert(typeof value == "number");
		assert(Number.isInteger(value));
		if (enumAsInteger || !type[1].hasOwnProperty(value)) return value;
		if (type[2]) return type[2] + type[1][value];
		return type[1][value];
	}
	message(type, value, fieldName, options) {
		if (value === void 0) return options.emitDefaultValues ? null : void 0;
		return type.internalJsonWrite(value, options);
	}
	scalar(type, value, fieldName, optional, emitDefaultValues) {
		if (value === void 0) {
			assert(optional);
			return;
		}
		const ed = emitDefaultValues || optional;
		switch (type) {
			case ScalarType.INT32:
			case ScalarType.SFIXED32:
			case ScalarType.SINT32:
				if (value === 0) return ed ? 0 : void 0;
				assertInt32(value);
				return value;
			case ScalarType.FIXED32:
			case ScalarType.UINT32:
				if (value === 0) return ed ? 0 : void 0;
				assertUInt32(value);
				return value;
			case ScalarType.FLOAT: assertFloat32(value);
			case ScalarType.DOUBLE:
				if (value === 0) return ed ? 0 : void 0;
				assert(typeof value == "number");
				if (Number.isNaN(value)) return "NaN";
				if (value === Number.POSITIVE_INFINITY) return "Infinity";
				if (value === Number.NEGATIVE_INFINITY) return "-Infinity";
				return value;
			case ScalarType.STRING:
				if (value === "") return ed ? "" : void 0;
				assert(typeof value == "string");
				return value;
			case ScalarType.BOOL:
				if (value === false) return ed ? false : void 0;
				assert(typeof value == "boolean");
				return value;
			case ScalarType.UINT64:
			case ScalarType.FIXED64:
				assert(typeof value == "number" || typeof value == "string" || typeof value == "bigint");
				let ulong = PbULong.from(value);
				if (ulong.isZero() && !ed) return void 0;
				return ulong.toString();
			case ScalarType.INT64:
			case ScalarType.SFIXED64:
			case ScalarType.SINT64:
				assert(typeof value == "number" || typeof value == "string" || typeof value == "bigint");
				let long = PbLong.from(value);
				if (long.isZero() && !ed) return void 0;
				return long.toString();
			case ScalarType.BYTES:
				assert(value instanceof Uint8Array);
				if (!value.byteLength) return ed ? "" : void 0;
				return base64encode(value);
		}
	}
};
/**
* Creates the default value for a scalar type.
*/
function reflectionScalarDefault(type, longType = LongType.STRING) {
	switch (type) {
		case ScalarType.BOOL: return false;
		case ScalarType.UINT64:
		case ScalarType.FIXED64: return reflectionLongConvert(PbULong.ZERO, longType);
		case ScalarType.INT64:
		case ScalarType.SFIXED64:
		case ScalarType.SINT64: return reflectionLongConvert(PbLong.ZERO, longType);
		case ScalarType.DOUBLE:
		case ScalarType.FLOAT: return 0;
		case ScalarType.BYTES: return new Uint8Array(0);
		case ScalarType.STRING: return "";
		default: return 0;
	}
}
/**
* Reads proto3 messages in binary format using reflection information.
*
* https://developers.google.com/protocol-buffers/docs/encoding
*/
var ReflectionBinaryReader = class {
	constructor(info) {
		this.info = info;
	}
	prepare() {
		var _a;
		if (!this.fieldNoToField) {
			const fieldsInput = (_a = this.info.fields) !== null && _a !== void 0 ? _a : [];
			this.fieldNoToField = new Map(fieldsInput.map((field) => [field.no, field]));
		}
	}
	/**
	* Reads a message from binary format into the target message.
	*
	* Repeated fields are appended. Map entries are added, overwriting
	* existing keys.
	*
	* If a message field is already present, it will be merged with the
	* new data.
	*/
	read(reader, message, options, length) {
		this.prepare();
		const end = length === void 0 ? reader.len : reader.pos + length;
		while (reader.pos < end) {
			const [fieldNo, wireType] = reader.tag(), field = this.fieldNoToField.get(fieldNo);
			if (!field) {
				let u = options.readUnknownField;
				if (u == "throw") throw new Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.info.typeName}`);
				let d = reader.skip(wireType);
				if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.info.typeName, message, fieldNo, wireType, d);
				continue;
			}
			let target = message, repeated = field.repeat, localName = field.localName;
			if (field.oneof) {
				target = target[field.oneof];
				if (target.oneofKind !== localName) target = message[field.oneof] = { oneofKind: localName };
			}
			switch (field.kind) {
				case "scalar":
				case "enum":
					let T = field.kind == "enum" ? ScalarType.INT32 : field.T;
					let L = field.kind == "scalar" ? field.L : void 0;
					if (repeated) {
						let arr = target[localName];
						if (wireType == WireType.LengthDelimited && T != ScalarType.STRING && T != ScalarType.BYTES) {
							let e = reader.uint32() + reader.pos;
							while (reader.pos < e) arr.push(this.scalar(reader, T, L));
						} else arr.push(this.scalar(reader, T, L));
					} else target[localName] = this.scalar(reader, T, L);
					break;
				case "message":
					if (repeated) {
						let arr = target[localName];
						let msg = field.T().internalBinaryRead(reader, reader.uint32(), options);
						arr.push(msg);
					} else target[localName] = field.T().internalBinaryRead(reader, reader.uint32(), options, target[localName]);
					break;
				case "map":
					let [mapKey, mapVal] = this.mapEntry(field, reader, options);
					target[localName][mapKey] = mapVal;
					break;
			}
		}
	}
	/**
	* Read a map field, expecting key field = 1, value field = 2
	*/
	mapEntry(field, reader, options) {
		let length = reader.uint32();
		let end = reader.pos + length;
		let key = void 0;
		let val = void 0;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					if (field.K == ScalarType.BOOL) key = reader.bool().toString();
					else key = this.scalar(reader, field.K, LongType.STRING);
					break;
				case 2:
					switch (field.V.kind) {
						case "scalar":
							val = this.scalar(reader, field.V.T, field.V.L);
							break;
						case "enum":
							val = reader.int32();
							break;
						case "message":
							val = field.V.T().internalBinaryRead(reader, reader.uint32(), options);
							break;
					}
					break;
				default: throw new Error(`Unknown field ${fieldNo} (wire type ${wireType}) in map entry for ${this.info.typeName}#${field.name}`);
			}
		}
		if (key === void 0) {
			let keyRaw = reflectionScalarDefault(field.K);
			key = field.K == ScalarType.BOOL ? keyRaw.toString() : keyRaw;
		}
		if (val === void 0) switch (field.V.kind) {
			case "scalar":
				val = reflectionScalarDefault(field.V.T, field.V.L);
				break;
			case "enum":
				val = 0;
				break;
			case "message":
				val = field.V.T().create();
				break;
		}
		return [key, val];
	}
	scalar(reader, type, longType) {
		switch (type) {
			case ScalarType.INT32: return reader.int32();
			case ScalarType.STRING: return reader.string();
			case ScalarType.BOOL: return reader.bool();
			case ScalarType.DOUBLE: return reader.double();
			case ScalarType.FLOAT: return reader.float();
			case ScalarType.INT64: return reflectionLongConvert(reader.int64(), longType);
			case ScalarType.UINT64: return reflectionLongConvert(reader.uint64(), longType);
			case ScalarType.FIXED64: return reflectionLongConvert(reader.fixed64(), longType);
			case ScalarType.FIXED32: return reader.fixed32();
			case ScalarType.BYTES: return reader.bytes();
			case ScalarType.UINT32: return reader.uint32();
			case ScalarType.SFIXED32: return reader.sfixed32();
			case ScalarType.SFIXED64: return reflectionLongConvert(reader.sfixed64(), longType);
			case ScalarType.SINT32: return reader.sint32();
			case ScalarType.SINT64: return reflectionLongConvert(reader.sint64(), longType);
		}
	}
};
/**
* Writes proto3 messages in binary format using reflection information.
*
* https://developers.google.com/protocol-buffers/docs/encoding
*/
var ReflectionBinaryWriter = class {
	constructor(info) {
		this.info = info;
	}
	prepare() {
		if (!this.fields) this.fields = (this.info.fields ? this.info.fields.concat() : []).sort((a, b) => a.no - b.no);
	}
	/**
	* Writes the message to binary format.
	*/
	write(message, writer, options) {
		this.prepare();
		for (const field of this.fields) {
			let value, emitDefault, repeated = field.repeat, localName = field.localName;
			if (field.oneof) {
				const group = message[field.oneof];
				if (group.oneofKind !== localName) continue;
				value = group[localName];
				emitDefault = true;
			} else {
				value = message[localName];
				emitDefault = false;
			}
			switch (field.kind) {
				case "scalar":
				case "enum":
					let T = field.kind == "enum" ? ScalarType.INT32 : field.T;
					if (repeated) {
						assert(Array.isArray(value));
						if (repeated == RepeatType.PACKED) this.packed(writer, T, field.no, value);
						else for (const item of value) this.scalar(writer, T, field.no, item, true);
					} else if (value === void 0) assert(field.opt);
					else this.scalar(writer, T, field.no, value, emitDefault || field.opt);
					break;
				case "message":
					if (repeated) {
						assert(Array.isArray(value));
						for (const item of value) this.message(writer, options, field.T(), field.no, item);
					} else this.message(writer, options, field.T(), field.no, value);
					break;
				case "map":
					assert(typeof value == "object" && value !== null);
					for (const [key, val] of Object.entries(value)) this.mapEntry(writer, options, field, key, val);
					break;
			}
		}
		let u = options.writeUnknownFields;
		if (u !== false) (u === true ? UnknownFieldHandler.onWrite : u)(this.info.typeName, message, writer);
	}
	mapEntry(writer, options, field, key, value) {
		writer.tag(field.no, WireType.LengthDelimited);
		writer.fork();
		let keyValue = key;
		switch (field.K) {
			case ScalarType.INT32:
			case ScalarType.FIXED32:
			case ScalarType.UINT32:
			case ScalarType.SFIXED32:
			case ScalarType.SINT32:
				keyValue = Number.parseInt(key);
				break;
			case ScalarType.BOOL:
				assert(key == "true" || key == "false");
				keyValue = key == "true";
				break;
		}
		this.scalar(writer, field.K, 1, keyValue, true);
		switch (field.V.kind) {
			case "scalar":
				this.scalar(writer, field.V.T, 2, value, true);
				break;
			case "enum":
				this.scalar(writer, ScalarType.INT32, 2, value, true);
				break;
			case "message":
				this.message(writer, options, field.V.T(), 2, value);
				break;
		}
		writer.join();
	}
	message(writer, options, handler, fieldNo, value) {
		if (value === void 0) return;
		handler.internalBinaryWrite(value, writer.tag(fieldNo, WireType.LengthDelimited).fork(), options);
		writer.join();
	}
	/**
	* Write a single scalar value.
	*/
	scalar(writer, type, fieldNo, value, emitDefault) {
		let [wireType, method, isDefault] = this.scalarInfo(type, value);
		if (!isDefault || emitDefault) {
			writer.tag(fieldNo, wireType);
			writer[method](value);
		}
	}
	/**
	* Write an array of scalar values in packed format.
	*/
	packed(writer, type, fieldNo, value) {
		if (!value.length) return;
		assert(type !== ScalarType.BYTES && type !== ScalarType.STRING);
		writer.tag(fieldNo, WireType.LengthDelimited);
		writer.fork();
		let [, method] = this.scalarInfo(type);
		for (let i = 0; i < value.length; i++) writer[method](value[i]);
		writer.join();
	}
	/**
	* Get information for writing a scalar value.
	*
	* Returns tuple:
	* [0]: appropriate WireType
	* [1]: name of the appropriate method of IBinaryWriter
	* [2]: whether the given value is a default value
	*
	* If argument `value` is omitted, [2] is always false.
	*/
	scalarInfo(type, value) {
		let t = WireType.Varint;
		let m;
		let i = value === void 0;
		let d = value === 0;
		switch (type) {
			case ScalarType.INT32:
				m = "int32";
				break;
			case ScalarType.STRING:
				d = i || !value.length;
				t = WireType.LengthDelimited;
				m = "string";
				break;
			case ScalarType.BOOL:
				d = value === false;
				m = "bool";
				break;
			case ScalarType.UINT32:
				m = "uint32";
				break;
			case ScalarType.DOUBLE:
				t = WireType.Bit64;
				m = "double";
				break;
			case ScalarType.FLOAT:
				t = WireType.Bit32;
				m = "float";
				break;
			case ScalarType.INT64:
				d = i || PbLong.from(value).isZero();
				m = "int64";
				break;
			case ScalarType.UINT64:
				d = i || PbULong.from(value).isZero();
				m = "uint64";
				break;
			case ScalarType.FIXED64:
				d = i || PbULong.from(value).isZero();
				t = WireType.Bit64;
				m = "fixed64";
				break;
			case ScalarType.BYTES:
				d = i || !value.byteLength;
				t = WireType.LengthDelimited;
				m = "bytes";
				break;
			case ScalarType.FIXED32:
				t = WireType.Bit32;
				m = "fixed32";
				break;
			case ScalarType.SFIXED32:
				t = WireType.Bit32;
				m = "sfixed32";
				break;
			case ScalarType.SFIXED64:
				d = i || PbLong.from(value).isZero();
				t = WireType.Bit64;
				m = "sfixed64";
				break;
			case ScalarType.SINT32:
				m = "sint32";
				break;
			case ScalarType.SINT64:
				d = i || PbLong.from(value).isZero();
				m = "sint64";
				break;
		}
		return [
			t,
			m,
			i || d
		];
	}
};
/**
* Creates an instance of the generic message, using the field
* information.
*/
function reflectionCreate(type) {
	/**
	* This ternary can be removed in the next major version.
	* The `Object.create()` code path utilizes a new `messagePrototype`
	* property on the `IMessageType` which has this same `MESSAGE_TYPE`
	* non-enumerable property on it. Doing it this way means that we only
	* pay the cost of `Object.defineProperty()` once per `IMessageType`
	* class of once per "instance". The falsy code path is only provided
	* for backwards compatibility in cases where the runtime library is
	* updated without also updating the generated code.
	*/
	const msg = type.messagePrototype ? Object.create(type.messagePrototype) : Object.defineProperty({}, MESSAGE_TYPE, { value: type });
	for (let field of type.fields) {
		let name = field.localName;
		if (field.opt) continue;
		if (field.oneof) msg[field.oneof] = { oneofKind: void 0 };
		else if (field.repeat) msg[name] = [];
		else switch (field.kind) {
			case "scalar":
				msg[name] = reflectionScalarDefault(field.T, field.L);
				break;
			case "enum":
				msg[name] = 0;
				break;
			case "map":
				msg[name] = {};
				break;
		}
	}
	return msg;
}
/**
* Copy partial data into the target message.
*
* If a singular scalar or enum field is present in the source, it
* replaces the field in the target.
*
* If a singular message field is present in the source, it is merged
* with the target field by calling mergePartial() of the responsible
* message type.
*
* If a repeated field is present in the source, its values replace
* all values in the target array, removing extraneous values.
* Repeated message fields are copied, not merged.
*
* If a map field is present in the source, entries are added to the
* target map, replacing entries with the same key. Entries that only
* exist in the target remain. Entries with message values are copied,
* not merged.
*
* Note that this function differs from protobuf merge semantics,
* which appends repeated fields.
*/
function reflectionMergePartial(info, target, source) {
	let fieldValue, input = source, output;
	for (let field of info.fields) {
		let name = field.localName;
		if (field.oneof) {
			const group = input[field.oneof];
			if ((group === null || group === void 0 ? void 0 : group.oneofKind) == void 0) continue;
			fieldValue = group[name];
			output = target[field.oneof];
			output.oneofKind = group.oneofKind;
			if (fieldValue == void 0) {
				delete output[name];
				continue;
			}
		} else {
			fieldValue = input[name];
			output = target;
			if (fieldValue == void 0) continue;
		}
		if (field.repeat) output[name].length = fieldValue.length;
		switch (field.kind) {
			case "scalar":
			case "enum":
				if (field.repeat) for (let i = 0; i < fieldValue.length; i++) output[name][i] = fieldValue[i];
				else output[name] = fieldValue;
				break;
			case "message":
				let T = field.T();
				if (field.repeat) for (let i = 0; i < fieldValue.length; i++) output[name][i] = T.create(fieldValue[i]);
				else if (output[name] === void 0) output[name] = T.create(fieldValue);
				else T.mergePartial(output[name], fieldValue);
				break;
			case "map":
				switch (field.V.kind) {
					case "scalar":
					case "enum":
						Object.assign(output[name], fieldValue);
						break;
					case "message":
						let T = field.V.T();
						for (let k of Object.keys(fieldValue)) output[name][k] = T.create(fieldValue[k]);
						break;
				}
				break;
		}
	}
}
/**
* Determines whether two message of the same type have the same field values.
* Checks for deep equality, traversing repeated fields, oneof groups, maps
* and messages recursively.
* Will also return true if both messages are `undefined`.
*/
function reflectionEquals(info, a, b) {
	if (a === b) return true;
	if (!a || !b) return false;
	for (let field of info.fields) {
		let localName = field.localName;
		let val_a = field.oneof ? a[field.oneof][localName] : a[localName];
		let val_b = field.oneof ? b[field.oneof][localName] : b[localName];
		switch (field.kind) {
			case "enum":
			case "scalar":
				let t = field.kind == "enum" ? ScalarType.INT32 : field.T;
				if (!(field.repeat ? repeatedPrimitiveEq(t, val_a, val_b) : primitiveEq(t, val_a, val_b))) return false;
				break;
			case "map":
				if (!(field.V.kind == "message" ? repeatedMsgEq(field.V.T(), objectValues(val_a), objectValues(val_b)) : repeatedPrimitiveEq(field.V.kind == "enum" ? ScalarType.INT32 : field.V.T, objectValues(val_a), objectValues(val_b)))) return false;
				break;
			case "message":
				let T = field.T();
				if (!(field.repeat ? repeatedMsgEq(T, val_a, val_b) : T.equals(val_a, val_b))) return false;
				break;
		}
	}
	return true;
}
var objectValues = Object.values;
function primitiveEq(type, a, b) {
	if (a === b) return true;
	if (type !== ScalarType.BYTES) return false;
	let ba = a;
	let bb = b;
	if (ba.length !== bb.length) return false;
	for (let i = 0; i < ba.length; i++) if (ba[i] != bb[i]) return false;
	return true;
}
function repeatedPrimitiveEq(type, a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (!primitiveEq(type, a[i], b[i])) return false;
	return true;
}
function repeatedMsgEq(type, a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (!type.equals(a[i], b[i])) return false;
	return true;
}
var baseDescriptors = Object.getOwnPropertyDescriptors(Object.getPrototypeOf({}));
var messageTypeDescriptor = baseDescriptors[MESSAGE_TYPE] = {};
/**
* This standard message type provides reflection-based
* operations to work with a message.
*/
var MessageType = class {
	constructor(name, fields, options) {
		this.defaultCheckDepth = 16;
		this.typeName = name;
		this.fields = fields.map(normalizeFieldInfo);
		this.options = options !== null && options !== void 0 ? options : {};
		messageTypeDescriptor.value = this;
		this.messagePrototype = Object.create(null, baseDescriptors);
		this.refTypeCheck = new ReflectionTypeCheck(this);
		this.refJsonReader = new ReflectionJsonReader(this);
		this.refJsonWriter = new ReflectionJsonWriter(this);
		this.refBinReader = new ReflectionBinaryReader(this);
		this.refBinWriter = new ReflectionBinaryWriter(this);
	}
	create(value) {
		let message = reflectionCreate(this);
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	/**
	* Clone the message.
	*
	* Unknown fields are discarded.
	*/
	clone(message) {
		let copy = this.create();
		reflectionMergePartial(this, copy, message);
		return copy;
	}
	/**
	* Determines whether two message of the same type have the same field values.
	* Checks for deep equality, traversing repeated fields, oneof groups, maps
	* and messages recursively.
	* Will also return true if both messages are `undefined`.
	*/
	equals(a, b) {
		return reflectionEquals(this, a, b);
	}
	/**
	* Is the given value assignable to our message type
	* and contains no [excess properties](https://www.typescriptlang.org/docs/handbook/interfaces.html#excess-property-checks)?
	*/
	is(arg, depth = this.defaultCheckDepth) {
		return this.refTypeCheck.is(arg, depth, false);
	}
	/**
	* Is the given value assignable to our message type,
	* regardless of [excess properties](https://www.typescriptlang.org/docs/handbook/interfaces.html#excess-property-checks)?
	*/
	isAssignable(arg, depth = this.defaultCheckDepth) {
		return this.refTypeCheck.is(arg, depth, true);
	}
	/**
	* Copy partial data into the target message.
	*/
	mergePartial(target, source) {
		reflectionMergePartial(this, target, source);
	}
	/**
	* Create a new message from binary format.
	*/
	fromBinary(data, options) {
		let opt = binaryReadOptions(options);
		return this.internalBinaryRead(opt.readerFactory(data), data.byteLength, opt);
	}
	/**
	* Read a new message from a JSON value.
	*/
	fromJson(json, options) {
		return this.internalJsonRead(json, jsonReadOptions(options));
	}
	/**
	* Read a new message from a JSON string.
	* This is equivalent to `T.fromJson(JSON.parse(json))`.
	*/
	fromJsonString(json, options) {
		let value = JSON.parse(json);
		return this.fromJson(value, options);
	}
	/**
	* Write the message to canonical JSON value.
	*/
	toJson(message, options) {
		return this.internalJsonWrite(message, jsonWriteOptions(options));
	}
	/**
	* Convert the message to canonical JSON string.
	* This is equivalent to `JSON.stringify(T.toJson(t))`
	*/
	toJsonString(message, options) {
		var _a;
		let value = this.toJson(message, options);
		return JSON.stringify(value, null, (_a = options === null || options === void 0 ? void 0 : options.prettySpaces) !== null && _a !== void 0 ? _a : 0);
	}
	/**
	* Write the message to binary format.
	*/
	toBinary(message, options) {
		let opt = binaryWriteOptions(options);
		return this.internalBinaryWrite(message, opt.writerFactory(), opt).finish();
	}
	/**
	* This is an internal method. If you just want to read a message from
	* JSON, use `fromJson()` or `fromJsonString()`.
	*
	* Reads JSON value and merges the fields into the target
	* according to protobuf rules. If the target is omitted,
	* a new instance is created first.
	*/
	internalJsonRead(json, options, target) {
		if (json !== null && typeof json == "object" && !Array.isArray(json)) {
			let message = target !== null && target !== void 0 ? target : this.create();
			this.refJsonReader.read(json, message, options);
			return message;
		}
		throw new Error(`Unable to parse message ${this.typeName} from JSON ${typeofJsonValue(json)}.`);
	}
	/**
	* This is an internal method. If you just want to write a message
	* to JSON, use `toJson()` or `toJsonString().
	*
	* Writes JSON value and returns it.
	*/
	internalJsonWrite(message, options) {
		return this.refJsonWriter.write(message, options);
	}
	/**
	* This is an internal method. If you just want to write a message
	* in binary format, use `toBinary()`.
	*
	* Serializes the message in binary format and appends it to the given
	* writer. Returns passed writer.
	*/
	internalBinaryWrite(message, writer, options) {
		this.refBinWriter.write(message, writer, options);
		return writer;
	}
	/**
	* This is an internal method. If you just want to read a message from
	* binary data, use `fromBinary()`.
	*
	* Reads data from binary format and merges the fields into
	* the target according to protobuf rules. If the target is
	* omitted, a new instance is created first.
	*/
	internalBinaryRead(reader, length, options, target) {
		let message = target !== null && target !== void 0 ? target : this.create();
		this.refBinReader.read(reader, message, options, length);
		return message;
	}
};
function buildUrl(baseUrl, path, params) {
	const url = new URL(path, baseUrl);
	if (params) {
		for (const [key, value] of Object.entries(params)) if (value !== void 0 && value !== null) url.searchParams.append(key, String(value));
	}
	return url.toString();
}
var Timestamp$Type = class extends MessageType {
	constructor() {
		super("google.protobuf.Timestamp", [{
			no: 1,
			name: "seconds",
			kind: "scalar",
			T: 3,
			L: 2
		}, {
			no: 2,
			name: "nanos",
			kind: "scalar",
			T: 5
		}]);
	}
	/**
	* Creates a new `Timestamp` for the current time.
	*/
	now() {
		const msg = this.create();
		const ms = Date.now();
		msg.seconds = PbLong.from(Math.floor(ms / 1e3)).toNumber();
		msg.nanos = ms % 1e3 * 1e6;
		return msg;
	}
	/**
	* Converts a `Timestamp` to a JavaScript Date.
	*/
	toDate(message) {
		return new Date(PbLong.from(message.seconds).toNumber() * 1e3 + Math.ceil(message.nanos / 1e6));
	}
	/**
	* Converts a JavaScript Date to a `Timestamp`.
	*/
	fromDate(date) {
		const msg = this.create();
		const ms = date.getTime();
		msg.seconds = PbLong.from(Math.floor(ms / 1e3)).toNumber();
		msg.nanos = (ms % 1e3 + (ms < 0 && ms % 1e3 !== 0 ? 1e3 : 0)) * 1e6;
		return msg;
	}
	/**
	* In JSON format, the `Timestamp` type is encoded as a string
	* in the RFC 3339 format.
	*/
	internalJsonWrite(message, options) {
		let ms = PbLong.from(message.seconds).toNumber() * 1e3;
		if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new Error("Unable to encode Timestamp to JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
		if (message.nanos < 0) throw new Error("Unable to encode invalid Timestamp to JSON. Nanos must not be negative.");
		let z = "Z";
		if (message.nanos > 0) {
			let nanosStr = (message.nanos + 1e9).toString().substring(1);
			if (nanosStr.substring(3) === "000000") z = "." + nanosStr.substring(0, 3) + "Z";
			else if (nanosStr.substring(6) === "000") z = "." + nanosStr.substring(0, 6) + "Z";
			else z = "." + nanosStr + "Z";
		}
		return new Date(ms).toISOString().replace(".000Z", z);
	}
	/**
	* In JSON format, the `Timestamp` type is encoded as a string
	* in the RFC 3339 format.
	*/
	internalJsonRead(json, options, target) {
		if (typeof json !== "string") throw new Error("Unable to parse Timestamp from JSON " + typeofJsonValue(json) + ".");
		let matches = json.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
		if (!matches) throw new Error("Unable to parse Timestamp from JSON. Invalid format.");
		let ms = Date.parse(matches[1] + "-" + matches[2] + "-" + matches[3] + "T" + matches[4] + ":" + matches[5] + ":" + matches[6] + (matches[8] ? matches[8] : "Z"));
		if (Number.isNaN(ms)) throw new Error("Unable to parse Timestamp from JSON. Invalid value.");
		if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new globalThis.Error("Unable to parse Timestamp from JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
		if (!target) target = this.create();
		target.seconds = PbLong.from(ms / 1e3).toNumber();
		target.nanos = 0;
		if (matches[7]) target.nanos = parseInt("1" + matches[7] + "0".repeat(9 - matches[7].length)) - 1e9;
		return target;
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.seconds = 0;
		message.nanos = 0;
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.seconds = reader.int64().toNumber();
					break;
				case 2:
					message.nanos = reader.int32();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.seconds !== 0) writer.tag(1, WireType.Varint).int64(message.seconds);
		if (message.nanos !== 0) writer.tag(2, WireType.Varint).int32(message.nanos);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message google.protobuf.Timestamp
*/
var Timestamp = new Timestamp$Type();
/**
* `NullValue` is a singleton enumeration to represent the null value for the
* `Value` type union.
*
* The JSON representation for `NullValue` is JSON `null`.
*
* @generated from protobuf enum google.protobuf.NullValue
*/
var NullValue = /* @__PURE__ */ function(NullValue) {
	/**
	* Null value.
	*
	* @generated from protobuf enum value: NULL_VALUE = 0;
	*/
	NullValue[NullValue["NULL_VALUE"] = 0] = "NULL_VALUE";
	return NullValue;
}({});
var Struct$Type = class extends MessageType {
	constructor() {
		super("google.protobuf.Struct", [{
			no: 1,
			name: "fields",
			kind: "map",
			K: 9,
			V: {
				kind: "message",
				T: () => Value$1
			}
		}]);
	}
	/**
	* Encode `Struct` to JSON object.
	*/
	internalJsonWrite(message, options) {
		let json = {};
		for (let [k, v] of Object.entries(message.fields)) json[k] = Value$1.toJson(v);
		return json;
	}
	/**
	* Decode `Struct` from JSON object.
	*/
	internalJsonRead(json, options, target) {
		if (!isJsonObject(json)) throw new globalThis.Error("Unable to parse message " + this.typeName + " from JSON " + typeofJsonValue(json) + ".");
		if (!target) target = this.create();
		for (let [k, v] of globalThis.Object.entries(json)) target.fields[k] = Value$1.fromJson(v);
		return target;
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.fields = {};
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					this.binaryReadMap1(message.fields, reader, options);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	binaryReadMap1(map, reader, options) {
		let len = reader.uint32(), end = reader.pos + len, key, val;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					key = reader.string();
					break;
				case 2:
					val = Value$1.internalBinaryRead(reader, reader.uint32(), options);
					break;
				default: throw new globalThis.Error("unknown map entry field for google.protobuf.Struct.fields");
			}
		}
		map[key ?? ""] = val ?? Value$1.create();
	}
	internalBinaryWrite(message, writer, options) {
		for (let k of globalThis.Object.keys(message.fields)) {
			writer.tag(1, WireType.LengthDelimited).fork().tag(1, WireType.LengthDelimited).string(k);
			writer.tag(2, WireType.LengthDelimited).fork();
			Value$1.internalBinaryWrite(message.fields[k], writer, options);
			writer.join().join();
		}
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message google.protobuf.Struct
*/
var Struct = new Struct$Type();
var Value$Type$1 = class extends MessageType {
	constructor() {
		super("google.protobuf.Value", [
			{
				no: 1,
				name: "null_value",
				kind: "enum",
				oneof: "kind",
				T: () => ["google.protobuf.NullValue", NullValue]
			},
			{
				no: 2,
				name: "number_value",
				kind: "scalar",
				oneof: "kind",
				T: 1
			},
			{
				no: 3,
				name: "string_value",
				kind: "scalar",
				oneof: "kind",
				T: 9
			},
			{
				no: 4,
				name: "bool_value",
				kind: "scalar",
				oneof: "kind",
				T: 8
			},
			{
				no: 5,
				name: "struct_value",
				kind: "message",
				oneof: "kind",
				T: () => Struct
			},
			{
				no: 6,
				name: "list_value",
				kind: "message",
				oneof: "kind",
				T: () => ListValue
			}
		]);
	}
	/**
	* Encode `Value` to JSON value.
	*/
	internalJsonWrite(message, options) {
		if (message.kind.oneofKind === void 0) throw new globalThis.Error();
		switch (message.kind.oneofKind) {
			case void 0: throw new globalThis.Error();
			case "boolValue": return message.kind.boolValue;
			case "nullValue": return null;
			case "numberValue":
				let numberValue = message.kind.numberValue;
				if (typeof numberValue == "number" && !Number.isFinite(numberValue)) throw new globalThis.Error();
				return numberValue;
			case "stringValue": return message.kind.stringValue;
			case "listValue":
				let listValueField = this.fields.find((f) => f.no === 6);
				if (listValueField?.kind !== "message") throw new globalThis.Error();
				return listValueField.T().toJson(message.kind.listValue);
			case "structValue":
				let structValueField = this.fields.find((f) => f.no === 5);
				if (structValueField?.kind !== "message") throw new globalThis.Error();
				return structValueField.T().toJson(message.kind.structValue);
		}
	}
	/**
	* Decode `Value` from JSON value.
	*/
	internalJsonRead(json, options, target) {
		if (!target) target = this.create();
		switch (typeof json) {
			case "number":
				target.kind = {
					oneofKind: "numberValue",
					numberValue: json
				};
				break;
			case "string":
				target.kind = {
					oneofKind: "stringValue",
					stringValue: json
				};
				break;
			case "boolean":
				target.kind = {
					oneofKind: "boolValue",
					boolValue: json
				};
				break;
			case "object":
				if (json === null) target.kind = {
					oneofKind: "nullValue",
					nullValue: NullValue.NULL_VALUE
				};
				else if (globalThis.Array.isArray(json)) target.kind = {
					oneofKind: "listValue",
					listValue: ListValue.fromJson(json)
				};
				else target.kind = {
					oneofKind: "structValue",
					structValue: Struct.fromJson(json)
				};
				break;
			default: throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json));
		}
		return target;
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.kind = { oneofKind: void 0 };
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.kind = {
						oneofKind: "nullValue",
						nullValue: reader.int32()
					};
					break;
				case 2:
					message.kind = {
						oneofKind: "numberValue",
						numberValue: reader.double()
					};
					break;
				case 3:
					message.kind = {
						oneofKind: "stringValue",
						stringValue: reader.string()
					};
					break;
				case 4:
					message.kind = {
						oneofKind: "boolValue",
						boolValue: reader.bool()
					};
					break;
				case 5:
					message.kind = {
						oneofKind: "structValue",
						structValue: Struct.internalBinaryRead(reader, reader.uint32(), options, message.kind.structValue)
					};
					break;
				case 6:
					message.kind = {
						oneofKind: "listValue",
						listValue: ListValue.internalBinaryRead(reader, reader.uint32(), options, message.kind.listValue)
					};
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.kind.oneofKind === "nullValue") writer.tag(1, WireType.Varint).int32(message.kind.nullValue);
		if (message.kind.oneofKind === "numberValue") writer.tag(2, WireType.Bit64).double(message.kind.numberValue);
		if (message.kind.oneofKind === "stringValue") writer.tag(3, WireType.LengthDelimited).string(message.kind.stringValue);
		if (message.kind.oneofKind === "boolValue") writer.tag(4, WireType.Varint).bool(message.kind.boolValue);
		if (message.kind.oneofKind === "structValue") Struct.internalBinaryWrite(message.kind.structValue, writer.tag(5, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "listValue") ListValue.internalBinaryWrite(message.kind.listValue, writer.tag(6, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message google.protobuf.Value
*/
var Value$1 = new Value$Type$1();
var ListValue$Type = class extends MessageType {
	constructor() {
		super("google.protobuf.ListValue", [{
			no: 1,
			name: "values",
			kind: "message",
			repeat: 2,
			T: () => Value$1
		}]);
	}
	/**
	* Encode `ListValue` to JSON array.
	*/
	internalJsonWrite(message, options) {
		return message.values.map((v) => Value$1.toJson(v));
	}
	/**
	* Decode `ListValue` from JSON array.
	*/
	internalJsonRead(json, options, target) {
		if (!globalThis.Array.isArray(json)) throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json));
		if (!target) target = this.create();
		let values = json.map((v) => Value$1.fromJson(v));
		target.values.push(...values);
		return target;
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.values = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.values.push(Value$1.internalBinaryRead(reader, reader.uint32(), options));
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		for (let i = 0; i < message.values.length; i++) Value$1.internalBinaryWrite(message.values[i], writer.tag(1, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message google.protobuf.ListValue
*/
var ListValue = new ListValue$Type();
var Attribute$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.Attribute", [{
			no: 1,
			name: "id",
			kind: "scalar",
			T: 9
		}, {
			no: 2,
			name: "value",
			kind: "message",
			T: () => Value
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.id = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.id = reader.string();
					break;
				case 2:
					message.value = Value.internalBinaryRead(reader, reader.uint32(), options, message.value);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.id !== "") writer.tag(1, WireType.LengthDelimited).string(message.id);
		if (message.value) Value.internalBinaryWrite(message.value, writer.tag(2, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.Attribute
*/
var Attribute = new Attribute$Type();
var AttributeList$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.AttributeList", [{
			no: 1,
			name: "attributes",
			kind: "message",
			repeat: 2,
			T: () => Attribute
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.attributes = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.attributes.push(Attribute.internalBinaryRead(reader, reader.uint32(), options));
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		for (let i = 0; i < message.attributes.length; i++) Attribute.internalBinaryWrite(message.attributes[i], writer.tag(1, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
new AttributeList$Type();
var Value$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.Value", [
			{
				no: 1,
				name: "null_value",
				kind: "enum",
				oneof: "kind",
				T: () => ["google.protobuf.NullValue", NullValue]
			},
			{
				no: 2,
				name: "integer_value",
				kind: "scalar",
				oneof: "kind",
				T: 3,
				L: 2
			},
			{
				no: 3,
				name: "double_value",
				kind: "scalar",
				oneof: "kind",
				T: 1
			},
			{
				no: 4,
				name: "string_value",
				kind: "scalar",
				oneof: "kind",
				T: 9
			},
			{
				no: 5,
				name: "bool_value",
				kind: "scalar",
				oneof: "kind",
				T: 8
			},
			{
				no: 6,
				name: "integer_list_value",
				kind: "message",
				oneof: "kind",
				T: () => IntegerList
			},
			{
				no: 7,
				name: "string_list_value",
				kind: "message",
				oneof: "kind",
				T: () => StringList
			},
			{
				no: 8,
				name: "time_value",
				kind: "message",
				oneof: "kind",
				T: () => Timestamp
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.kind = { oneofKind: void 0 };
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.kind = {
						oneofKind: "nullValue",
						nullValue: reader.int32()
					};
					break;
				case 2:
					message.kind = {
						oneofKind: "integerValue",
						integerValue: reader.int64().toNumber()
					};
					break;
				case 3:
					message.kind = {
						oneofKind: "doubleValue",
						doubleValue: reader.double()
					};
					break;
				case 4:
					message.kind = {
						oneofKind: "stringValue",
						stringValue: reader.string()
					};
					break;
				case 5:
					message.kind = {
						oneofKind: "boolValue",
						boolValue: reader.bool()
					};
					break;
				case 6:
					message.kind = {
						oneofKind: "integerListValue",
						integerListValue: IntegerList.internalBinaryRead(reader, reader.uint32(), options, message.kind.integerListValue)
					};
					break;
				case 7:
					message.kind = {
						oneofKind: "stringListValue",
						stringListValue: StringList.internalBinaryRead(reader, reader.uint32(), options, message.kind.stringListValue)
					};
					break;
				case 8:
					message.kind = {
						oneofKind: "timeValue",
						timeValue: Timestamp.internalBinaryRead(reader, reader.uint32(), options, message.kind.timeValue)
					};
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.kind.oneofKind === "nullValue") writer.tag(1, WireType.Varint).int32(message.kind.nullValue);
		if (message.kind.oneofKind === "integerValue") writer.tag(2, WireType.Varint).int64(message.kind.integerValue);
		if (message.kind.oneofKind === "doubleValue") writer.tag(3, WireType.Bit64).double(message.kind.doubleValue);
		if (message.kind.oneofKind === "stringValue") writer.tag(4, WireType.LengthDelimited).string(message.kind.stringValue);
		if (message.kind.oneofKind === "boolValue") writer.tag(5, WireType.Varint).bool(message.kind.boolValue);
		if (message.kind.oneofKind === "integerListValue") IntegerList.internalBinaryWrite(message.kind.integerListValue, writer.tag(6, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "stringListValue") StringList.internalBinaryWrite(message.kind.stringListValue, writer.tag(7, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "timeValue") Timestamp.internalBinaryWrite(message.kind.timeValue, writer.tag(8, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.Value
*/
var Value = new Value$Type();
var IntegerList$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.IntegerList", [{
			no: 1,
			name: "values",
			kind: "scalar",
			repeat: 1,
			T: 3,
			L: 2
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.values = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					if (wireType === WireType.LengthDelimited) for (let e = reader.int32() + reader.pos; reader.pos < e;) message.values.push(reader.int64().toNumber());
					else message.values.push(reader.int64().toNumber());
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.values.length) {
			writer.tag(1, WireType.LengthDelimited).fork();
			for (let i = 0; i < message.values.length; i++) writer.int64(message.values[i]);
			writer.join();
		}
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.IntegerList
*/
var IntegerList = new IntegerList$Type();
var StringList$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.StringList", [{
			no: 1,
			name: "values",
			kind: "scalar",
			repeat: 2,
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.values = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.values.push(reader.string());
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		for (let i = 0; i < message.values.length; i++) writer.tag(1, WireType.LengthDelimited).string(message.values[i]);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.StringList
*/
var StringList = new StringList$Type();
/**
* Domain is the domain of the user session
*
* @generated from protobuf enum github.authentication.v0.UserSession.Domain
*/
var UserSession_Domain = /* @__PURE__ */ function(UserSession_Domain) {
	/**
	* github.com
	*
	* @generated from protobuf enum value: DOMAIN_DOTCOM = 0;
	*/
	UserSession_Domain[UserSession_Domain["DOTCOM"] = 0] = "DOTCOM";
	/**
	* gist.github.com
	*
	* @generated from protobuf enum value: DOMAIN_GIST = 1;
	*/
	UserSession_Domain[UserSession_Domain["GIST"] = 1] = "GIST";
	return UserSession_Domain;
}({});
var Credentials$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.Credentials", [
			{
				no: 1,
				name: "login_password",
				kind: "message",
				oneof: "kind",
				T: () => LoginPassword
			},
			{
				no: 4,
				name: "ssh_public_key",
				kind: "message",
				oneof: "kind",
				T: () => SSHPublicKey
			},
			{
				no: 5,
				name: "signed_auth_token",
				kind: "message",
				oneof: "kind",
				T: () => SignedAuthToken
			},
			{
				no: 6,
				name: "access_token",
				kind: "message",
				oneof: "kind",
				T: () => AccessToken
			},
			{
				no: 7,
				name: "user_session",
				kind: "message",
				oneof: "kind",
				T: () => UserSession
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.kind = { oneofKind: void 0 };
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.kind = {
						oneofKind: "loginPassword",
						loginPassword: LoginPassword.internalBinaryRead(reader, reader.uint32(), options, message.kind.loginPassword)
					};
					break;
				case 4:
					message.kind = {
						oneofKind: "sshPublicKey",
						sshPublicKey: SSHPublicKey.internalBinaryRead(reader, reader.uint32(), options, message.kind.sshPublicKey)
					};
					break;
				case 5:
					message.kind = {
						oneofKind: "signedAuthToken",
						signedAuthToken: SignedAuthToken.internalBinaryRead(reader, reader.uint32(), options, message.kind.signedAuthToken)
					};
					break;
				case 6:
					message.kind = {
						oneofKind: "accessToken",
						accessToken: AccessToken.internalBinaryRead(reader, reader.uint32(), options, message.kind.accessToken)
					};
					break;
				case 7:
					message.kind = {
						oneofKind: "userSession",
						userSession: UserSession.internalBinaryRead(reader, reader.uint32(), options, message.kind.userSession)
					};
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.kind.oneofKind === "loginPassword") LoginPassword.internalBinaryWrite(message.kind.loginPassword, writer.tag(1, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "sshPublicKey") SSHPublicKey.internalBinaryWrite(message.kind.sshPublicKey, writer.tag(4, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "signedAuthToken") SignedAuthToken.internalBinaryWrite(message.kind.signedAuthToken, writer.tag(5, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "accessToken") AccessToken.internalBinaryWrite(message.kind.accessToken, writer.tag(6, WireType.LengthDelimited).fork(), options).join();
		if (message.kind.oneofKind === "userSession") UserSession.internalBinaryWrite(message.kind.userSession, writer.tag(7, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.Credentials
*/
var Credentials = new Credentials$Type();
var LoginPassword$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.LoginPassword", [{
			no: 1,
			name: "login",
			kind: "scalar",
			T: 9
		}, {
			no: 2,
			name: "password",
			kind: "scalar",
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.login = "";
		message.password = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.login = reader.string();
					break;
				case 2:
					message.password = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.login !== "") writer.tag(1, WireType.LengthDelimited).string(message.login);
		if (message.password !== "") writer.tag(2, WireType.LengthDelimited).string(message.password);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.LoginPassword
*/
var LoginPassword = new LoginPassword$Type();
var SSHPublicKey$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.SSHPublicKey", [{
			no: 1,
			name: "key",
			kind: "scalar",
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.key = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.key = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.key !== "") writer.tag(1, WireType.LengthDelimited).string(message.key);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.SSHPublicKey
*/
var SSHPublicKey = new SSHPublicKey$Type();
var SignedAuthToken$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.SignedAuthToken", [{
			no: 1,
			name: "token",
			kind: "scalar",
			T: 9
		}, {
			no: 2,
			name: "scope",
			kind: "scalar",
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.token = "";
		message.scope = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.token = reader.string();
					break;
				case 2:
					message.scope = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.token !== "") writer.tag(1, WireType.LengthDelimited).string(message.token);
		if (message.scope !== "") writer.tag(2, WireType.LengthDelimited).string(message.scope);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.SignedAuthToken
*/
var SignedAuthToken = new SignedAuthToken$Type();
var AccessToken$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.AccessToken", [{
			no: 1,
			name: "token",
			kind: "scalar",
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.token = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.token = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.token !== "") writer.tag(1, WireType.LengthDelimited).string(message.token);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.AccessToken
*/
var AccessToken = new AccessToken$Type();
var UserSession$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.UserSession", [{
			no: 1,
			name: "key",
			kind: "scalar",
			T: 9
		}, {
			no: 2,
			name: "domain",
			kind: "enum",
			T: () => [
				"github.authentication.v0.UserSession.Domain",
				UserSession_Domain,
				"DOMAIN_"
			]
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.key = "";
		message.domain = 0;
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.key = reader.string();
					break;
				case 2:
					message.domain = reader.int32();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.key !== "") writer.tag(1, WireType.LengthDelimited).string(message.key);
		if (message.domain !== 0) writer.tag(2, WireType.Varint).int32(message.domain);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.UserSession
*/
var UserSession = new UserSession$Type();
/**
* Result is a high level result of the validation attempt.
*
* @generated from protobuf enum github.authentication.v0.AuthenticateResponse.Result
*/
var AuthenticateResponse_Result = /* @__PURE__ */ function(AuthenticateResponse_Result) {
	/**
	* RESULT_UNKNOWN is not returned by the Authnd service.
	* It serves as only the zero-value for the Result type.
	*
	* @generated from protobuf enum value: RESULT_UNKNOWN = 0;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["UNKNOWN"] = 0] = "UNKNOWN";
	/**
	* RESULT_SUCCESS indicates the validation succeeded.
	*
	* @generated from protobuf enum value: RESULT_SUCCESS = 1;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["SUCCESS"] = 1] = "SUCCESS";
	/**
	* RESULT_FAILED_MAINTENANCE indicates validation was not possible
	* because GitHub is in maintenance mode.
	*
	* @generated from protobuf enum value: RESULT_FAILED_MAINTENANCE = 2;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_MAINTENANCE"] = 2] = "FAILED_MAINTENANCE";
	/**
	* RESULT_FAILED_WEAK_PASSWORD indicates the validation was not
	* attempted due to the quality of the password.
	*
	* @generated from protobuf enum value: RESULT_FAILED_WEAK_PASSWORD = 3;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_WEAK_PASSWORD"] = 3] = "FAILED_WEAK_PASSWORD";
	/**
	* RESULT_FAILED_SUSPENDED indicates the validation failed
	* because the user has been suspended
	*
	* @generated from protobuf enum value: RESULT_FAILED_SUSPENDED = 4;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_SUSPENDED"] = 4] = "FAILED_SUSPENDED";
	/**
	* RESULT_FAILED_PUBLIC_KEY_NOT_FOUND indicates the fingerprint
	* failed to match any known key
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_NOT_FOUND = 5;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_NOT_FOUND"] = 5] = "FAILED_PUBLIC_KEY_NOT_FOUND";
	/**
	* RESULT_FAILED_USER_UNKNOWN indicates a user for the supplied
	* credential could not be found
	*
	* @generated from protobuf enum value: RESULT_FAILED_USER_UNKNOWN = 6;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_USER_UNKNOWN"] = 6] = "FAILED_USER_UNKNOWN";
	/**
	* RESULT_FAILED_USER_DISABLED indicates a user for the supplied
	* credential is disabled
	*
	* @generated from protobuf enum value: RESULT_FAILED_USER_DISABLED = 7;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_USER_DISABLED"] = 7] = "FAILED_USER_DISABLED";
	/**
	* RESULT_FAILED_USER_SPAMMY indicates a user for the supplied
	* credential is marked as spammy
	*
	* @generated from protobuf enum value: RESULT_FAILED_USER_SPAMMY = 8;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_USER_SPAMMY"] = 8] = "FAILED_USER_SPAMMY";
	/**
	* RESULT_FAILED_PUBLIC_KEY_MISSING indicates a public key for the
	* supplied public key does not exists
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_MISSING = 9;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_MISSING"] = 9] = "FAILED_PUBLIC_KEY_MISSING";
	/**
	* RESULT_FAILED_PUBLIC_KEY_MISMATCH indicates the supplied public key
	* failed to match the public key.
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_MISMATCH = 10;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_MISMATCH"] = 10] = "FAILED_PUBLIC_KEY_MISMATCH";
	/**
	* RESULT_FAILED_PASSWORD_MISMATCH indicates the supplied password did
	* not match.
	*
	* @generated from protobuf enum value: RESULT_FAILED_PASSWORD_MISMATCH = 11;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PASSWORD_MISMATCH"] = 11] = "FAILED_PASSWORD_MISMATCH";
	/**
	* RESULT_FAILED_ACCESS_TOKEN_NOT_FOUND indicates the access token
	* failed to match any known token.
	*
	* @generated from protobuf enum value: RESULT_FAILED_ACCESS_TOKEN_NOT_FOUND = 12;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_ACCESS_TOKEN_NOT_FOUND"] = 12] = "FAILED_ACCESS_TOKEN_NOT_FOUND";
	/**
	* RESULT_FAILED_ACCESS_TOKEN_LAST_EIGHT_MISMATCH indicates the last eight
	* digits of the access token did not match.
	*
	* @generated from protobuf enum value: RESULT_FAILED_ACCESS_TOKEN_LAST_EIGHT_MISMATCH = 13;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_ACCESS_TOKEN_LAST_EIGHT_MISMATCH"] = 13] = "FAILED_ACCESS_TOKEN_LAST_EIGHT_MISMATCH";
	/**
	* RESULT_FAILED_PUBLIC_KEY_MALFORMED indicates the supplied public key
	* was not properly formed.
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_MALFORMED = 14;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_MALFORMED"] = 14] = "FAILED_PUBLIC_KEY_MALFORMED";
	/**
	* RESULT_FAILED_PUBLIC_KEY_NOT_VERIFIED indicates the supplied public key
	* has not been verified or the verification date is in the future.
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_NOT_VERIFIED = 15;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_NOT_VERIFIED"] = 15] = "FAILED_PUBLIC_KEY_NOT_VERIFIED";
	/**
	* RESULT_FAILED_PUBLIC_KEY_ALGO_NOT_SUPPORTED is deprecated and no longer returned.
	* Key algorithms are not checked during authentication.
	*
	* @generated from protobuf enum value: RESULT_FAILED_PUBLIC_KEY_ALGO_NOT_SUPPORTED = 16;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_PUBLIC_KEY_ALGO_NOT_SUPPORTED"] = 16] = "FAILED_PUBLIC_KEY_ALGO_NOT_SUPPORTED";
	/**
	* RESULT_FAILED_CREDENTIAL_EXPIRED indicates that the credential has expired.
	*
	* @generated from protobuf enum value: RESULT_FAILED_CREDENTIAL_EXPIRED = 17;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_CREDENTIAL_EXPIRED"] = 17] = "FAILED_CREDENTIAL_EXPIRED";
	/**
	* RESULT_FAILED_NOT_SUPPORTED indicates that the requested operation is not supported.
	*
	* @generated from protobuf enum value: RESULT_FAILED_NOT_SUPPORTED = 18;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_NOT_SUPPORTED"] = 18] = "FAILED_NOT_SUPPORTED";
	/**
	* RESULT_FAILED_CREDENTIAL_INVALID indicates the credential could not be validated.
	* This could be due to an invalid signature or a malformed token.
	*
	* @generated from protobuf enum value: RESULT_FAILED_CREDENTIAL_INVALID = 19;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_CREDENTIAL_INVALID"] = 19] = "FAILED_CREDENTIAL_INVALID";
	/**
	* RESULT_FAILED_SESSION_UNKNOWN indicates the credential is attached to a user session that does not exist.
	* This usually indicates a corrupt token (as expired/revoked sessions have a separate error code).
	*
	* @generated from protobuf enum value: RESULT_FAILED_SESSION_UNKNOWN = 20;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_SESSION_UNKNOWN"] = 20] = "FAILED_SESSION_UNKNOWN";
	/**
	* RESULT_FAILED_SESSION_EXPIRED indicates the credential is attached to a user session that has expired.
	*
	* @generated from protobuf enum value: RESULT_FAILED_SESSION_EXPIRED = 21;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_SESSION_EXPIRED"] = 21] = "FAILED_SESSION_EXPIRED";
	/**
	* RESULT_FAILED_SESSION_REVOKED indicates the credential is attached to a user session that has been revoked.
	*
	* @generated from protobuf enum value: RESULT_FAILED_SESSION_REVOKED = 22;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_SESSION_REVOKED"] = 22] = "FAILED_SESSION_REVOKED";
	/**
	* RESULT_FAILED_CREDENTIAL_REVOKED indicates the credential has been revoked.
	*
	* @generated from protobuf enum value: RESULT_FAILED_CREDENTIAL_REVOKED = 23;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_CREDENTIAL_REVOKED"] = 23] = "FAILED_CREDENTIAL_REVOKED";
	/**
	* RESULT_FAILED_INTEGRATION_SUSPENDED indicates the parent integration for the GitHub app credential is suspended.
	*
	* @generated from protobuf enum value: RESULT_FAILED_INTEGRATION_SUSPENDED = 24;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_INTEGRATION_SUSPENDED"] = 24] = "FAILED_INTEGRATION_SUSPENDED";
	/**
	* RESULT_FAILED_INSTALLATION_SUSPENDED indicates the installation for the GitHub app credential is suspended.
	*
	* @generated from protobuf enum value: RESULT_FAILED_INSTALLATION_SUSPENDED = 25;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_INSTALLATION_SUSPENDED"] = 25] = "FAILED_INSTALLATION_SUSPENDED";
	/**
	* RESULT_FAILED_APPLICATION_OWNER_SPAMMY indicates the application owner for the GitHub app is marked as spammy.
	*
	* @generated from protobuf enum value: RESULT_FAILED_APPLICATION_OWNER_SPAMMY = 26;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_APPLICATION_OWNER_SPAMMY"] = 26] = "FAILED_APPLICATION_OWNER_SPAMMY";
	/**
	* RESULT_FAILED_INTEGRATION_NOT_FOUND indicates the integration could not be found.
	*
	* @generated from protobuf enum value: RESULT_FAILED_INTEGRATION_NOT_FOUND = 27;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_INTEGRATION_NOT_FOUND"] = 27] = "FAILED_INTEGRATION_NOT_FOUND";
	/**
	* RESULT_FAILED_OAUTH_APPLICATION_SUSPENDED indicates the oauth application for which the token was issued has been suspended.
	*
	* @generated from protobuf enum value: RESULT_FAILED_OAUTH_APPLICATION_SUSPENDED = 28;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_OAUTH_APPLICATION_SUSPENDED"] = 28] = "FAILED_OAUTH_APPLICATION_SUSPENDED";
	/**
	* RESULT_FAILED_USER_IS_AN_ORGANIZATION indicates the user is an organization, not an individual user.
	*
	* @generated from protobuf enum value: RESULT_FAILED_USER_IS_AN_ORGANIZATION = 29;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_USER_IS_AN_ORGANIZATION"] = 29] = "FAILED_USER_IS_AN_ORGANIZATION";
	/**
	* RESULT_FAILED_SESSION_NOT_FOUND indicates the user session failed to match any known session.
	*
	* @generated from protobuf enum value: RESULT_FAILED_SESSION_NOT_FOUND = 30;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_SESSION_NOT_FOUND"] = 30] = "FAILED_SESSION_NOT_FOUND";
	/**
	* RESULT_FAILED_RATE_LIMIT_EXCEEDED indicates that the authentication attempt was blocked because the token exceeded it's rate limit.
	*
	* @generated from protobuf enum value: RESULT_FAILED_RATE_LIMIT_EXCEEDED = 100;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_RATE_LIMIT_EXCEEDED"] = 100] = "FAILED_RATE_LIMIT_EXCEEDED";
	/**
	* RESULT_FAILED_GENERIC indicates the validation failed.
	* If possible a more descriptive result code should be used.
	*
	* @generated from protobuf enum value: RESULT_FAILED_GENERIC = -1;
	*/
	AuthenticateResponse_Result[AuthenticateResponse_Result["FAILED_GENERIC"] = -1] = "FAILED_GENERIC";
	return AuthenticateResponse_Result;
}({});
/**
* Result is a high level result of the fetch attempt.
*
* @generated from protobuf enum github.authentication.v0.FetchDelegatedExchangeTokenClaimsResponse.Result
*/
var FetchDelegatedExchangeTokenClaimsResponse_Result = /* @__PURE__ */ function(FetchDelegatedExchangeTokenClaimsResponse_Result) {
	/**
	* RESULT_UNKNOWN
	* Should never be used because it is the zero value for this
	* field and will be invisible when encoded into JSON.
	*
	* @generated from protobuf enum value: RESULT_UNKNOWN = 0;
	*/
	FetchDelegatedExchangeTokenClaimsResponse_Result[FetchDelegatedExchangeTokenClaimsResponse_Result["UNKNOWN"] = 0] = "UNKNOWN";
	/**
	* RESULT_SUCCESS indicates the request was successful.
	*
	* @generated from protobuf enum value: RESULT_SUCCESS = 1;
	*/
	FetchDelegatedExchangeTokenClaimsResponse_Result[FetchDelegatedExchangeTokenClaimsResponse_Result["SUCCESS"] = 1] = "SUCCESS";
	/**
	* RESULT_FAILED_INVALID_CREDENTIAL indicates that the provided credential is invalid.
	*
	* @generated from protobuf enum value: RESULT_FAILED_INVALID_CREDENTIAL = 2;
	*/
	FetchDelegatedExchangeTokenClaimsResponse_Result[FetchDelegatedExchangeTokenClaimsResponse_Result["FAILED_INVALID_CREDENTIAL"] = 2] = "FAILED_INVALID_CREDENTIAL";
	/**
	* RESULT_FAILED_NOT_SUPPORTED indicates that the requested operation is not supported.
	*
	* @generated from protobuf enum value: RESULT_FAILED_NOT_SUPPORTED = 3;
	*/
	FetchDelegatedExchangeTokenClaimsResponse_Result[FetchDelegatedExchangeTokenClaimsResponse_Result["FAILED_NOT_SUPPORTED"] = 3] = "FAILED_NOT_SUPPORTED";
	/**
	* RESULT_FAILED_GENERIC indicates the request failed.
	* If possible a more descriptive result code should be used.
	*
	* @generated from protobuf enum value: RESULT_FAILED_GENERIC = -1;
	*/
	FetchDelegatedExchangeTokenClaimsResponse_Result[FetchDelegatedExchangeTokenClaimsResponse_Result["FAILED_GENERIC"] = -1] = "FAILED_GENERIC";
	return FetchDelegatedExchangeTokenClaimsResponse_Result;
}({});
var AuthenticateRequest$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.AuthenticateRequest", [{
			no: 1,
			name: "credentials",
			kind: "message",
			T: () => Credentials
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.credentials = Credentials.internalBinaryRead(reader, reader.uint32(), options, message.credentials);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.credentials) Credentials.internalBinaryWrite(message.credentials, writer.tag(1, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.AuthenticateRequest
*/
var AuthenticateRequest = new AuthenticateRequest$Type();
var AuthenticateResponse$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.AuthenticateResponse", [
			{
				no: 1,
				name: "result",
				kind: "enum",
				T: () => [
					"github.authentication.v0.AuthenticateResponse.Result",
					AuthenticateResponse_Result,
					"RESULT_"
				]
			},
			{
				no: 2,
				name: "attributes",
				kind: "message",
				repeat: 2,
				T: () => Attribute
			},
			{
				no: 3,
				name: "ticket",
				kind: "scalar",
				opt: true,
				T: 9
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.result = 0;
		message.attributes = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.result = reader.int32();
					break;
				case 2:
					message.attributes.push(Attribute.internalBinaryRead(reader, reader.uint32(), options));
					break;
				case 3:
					message.ticket = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.result !== 0) writer.tag(1, WireType.Varint).int32(message.result);
		for (let i = 0; i < message.attributes.length; i++) Attribute.internalBinaryWrite(message.attributes[i], writer.tag(2, WireType.LengthDelimited).fork(), options).join();
		if (message.ticket !== void 0) writer.tag(3, WireType.LengthDelimited).string(message.ticket);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.AuthenticateResponse
*/
var AuthenticateResponse = new AuthenticateResponse$Type();
var ExchangeTokenRequest$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.ExchangeTokenRequest", [{
			no: 1,
			name: "credentials",
			kind: "message",
			T: () => Credentials
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.credentials = Credentials.internalBinaryRead(reader, reader.uint32(), options, message.credentials);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.credentials) Credentials.internalBinaryWrite(message.credentials, writer.tag(1, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.ExchangeTokenRequest
*/
var ExchangeTokenRequest = new ExchangeTokenRequest$Type();
var ExchangeTokenResponse$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.ExchangeTokenResponse", [
			{
				no: 1,
				name: "result",
				kind: "enum",
				T: () => [
					"github.authentication.v0.AuthenticateResponse.Result",
					AuthenticateResponse_Result,
					"RESULT_"
				]
			},
			{
				no: 2,
				name: "token",
				kind: "scalar",
				T: 9
			},
			{
				no: 3,
				name: "expires_at",
				kind: "message",
				T: () => Timestamp
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.result = 0;
		message.token = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.result = reader.int32();
					break;
				case 2:
					message.token = reader.string();
					break;
				case 3:
					message.expiresAt = Timestamp.internalBinaryRead(reader, reader.uint32(), options, message.expiresAt);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.result !== 0) writer.tag(1, WireType.Varint).int32(message.result);
		if (message.token !== "") writer.tag(2, WireType.LengthDelimited).string(message.token);
		if (message.expiresAt) Timestamp.internalBinaryWrite(message.expiresAt, writer.tag(3, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.ExchangeTokenResponse
*/
var ExchangeTokenResponse = new ExchangeTokenResponse$Type();
var FetchDelegatedExchangeTokenClaimsRequest$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.FetchDelegatedExchangeTokenClaimsRequest", [{
			no: 1,
			name: "token",
			kind: "scalar",
			T: 9
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.token = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.token = reader.string();
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.token !== "") writer.tag(1, WireType.LengthDelimited).string(message.token);
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
new FetchDelegatedExchangeTokenClaimsRequest$Type();
var FetchDelegatedExchangeTokenClaimsResponse$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.FetchDelegatedExchangeTokenClaimsResponse", [{
			no: 1,
			name: "result",
			kind: "enum",
			T: () => [
				"github.authentication.v0.FetchDelegatedExchangeTokenClaimsResponse.Result",
				FetchDelegatedExchangeTokenClaimsResponse_Result,
				"RESULT_"
			]
		}, {
			no: 2,
			name: "attributes",
			kind: "message",
			repeat: 2,
			T: () => Attribute
		}]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.result = 0;
		message.attributes = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.result = reader.int32();
					break;
				case 2:
					message.attributes.push(Attribute.internalBinaryRead(reader, reader.uint32(), options));
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.result !== 0) writer.tag(1, WireType.Varint).int32(message.result);
		for (let i = 0; i < message.attributes.length; i++) Attribute.internalBinaryWrite(message.attributes[i], writer.tag(2, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
new FetchDelegatedExchangeTokenClaimsResponse$Type();
var IssueSignedAuthTokenRequest$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.IssueSignedAuthTokenRequest", [
			{
				no: 1,
				name: "user_id",
				kind: "scalar",
				T: 3,
				L: 2
			},
			{
				no: 2,
				name: "session_id",
				kind: "scalar",
				T: 3,
				L: 2
			},
			{
				no: 3,
				name: "scope",
				kind: "scalar",
				T: 9
			},
			{
				no: 4,
				name: "expires_at_time",
				kind: "message",
				T: () => Timestamp
			},
			{
				no: 5,
				name: "attributes",
				kind: "message",
				repeat: 1,
				T: () => Attribute
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.userId = 0;
		message.sessionId = 0;
		message.scope = "";
		message.attributes = [];
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.userId = reader.int64().toNumber();
					break;
				case 2:
					message.sessionId = reader.int64().toNumber();
					break;
				case 3:
					message.scope = reader.string();
					break;
				case 4:
					message.expiresAtTime = Timestamp.internalBinaryRead(reader, reader.uint32(), options, message.expiresAtTime);
					break;
				case 5:
					message.attributes.push(Attribute.internalBinaryRead(reader, reader.uint32(), options));
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.userId !== 0) writer.tag(1, WireType.Varint).int64(message.userId);
		if (message.sessionId !== 0) writer.tag(2, WireType.Varint).int64(message.sessionId);
		if (message.scope !== "") writer.tag(3, WireType.LengthDelimited).string(message.scope);
		if (message.expiresAtTime) Timestamp.internalBinaryWrite(message.expiresAtTime, writer.tag(4, WireType.LengthDelimited).fork(), options).join();
		for (let i = 0; i < message.attributes.length; i++) Attribute.internalBinaryWrite(message.attributes[i], writer.tag(5, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.IssueSignedAuthTokenRequest
*/
var IssueSignedAuthTokenRequest = new IssueSignedAuthTokenRequest$Type();
var IssueSignedAuthTokenResponse$Type = class extends MessageType {
	constructor() {
		super("github.authentication.v0.IssueSignedAuthTokenResponse", [
			{
				no: 1,
				name: "token",
				kind: "scalar",
				T: 9
			},
			{
				no: 2,
				name: "error",
				kind: "scalar",
				T: 9
			},
			{
				no: 3,
				name: "expires_at_time",
				kind: "message",
				T: () => Timestamp
			}
		]);
	}
	create(value) {
		const message = globalThis.Object.create(this.messagePrototype);
		message.token = "";
		message.error = "";
		if (value !== void 0) reflectionMergePartial(this, message, value);
		return message;
	}
	internalBinaryRead(reader, length, options, target) {
		let message = target ?? this.create(), end = reader.pos + length;
		while (reader.pos < end) {
			let [fieldNo, wireType] = reader.tag();
			switch (fieldNo) {
				case 1:
					message.token = reader.string();
					break;
				case 2:
					message.error = reader.string();
					break;
				case 3:
					message.expiresAtTime = Timestamp.internalBinaryRead(reader, reader.uint32(), options, message.expiresAtTime);
					break;
				default:
					let u = options.readUnknownField;
					if (u === "throw") throw new globalThis.Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.typeName}`);
					let d = reader.skip(wireType);
					if (u !== false) (u === true ? UnknownFieldHandler.onRead : u)(this.typeName, message, fieldNo, wireType, d);
			}
		}
		return message;
	}
	internalBinaryWrite(message, writer, options) {
		if (message.token !== "") writer.tag(1, WireType.LengthDelimited).string(message.token);
		if (message.error !== "") writer.tag(2, WireType.LengthDelimited).string(message.error);
		if (message.expiresAtTime) Timestamp.internalBinaryWrite(message.expiresAtTime, writer.tag(3, WireType.LengthDelimited).fork(), options).join();
		let u = options.writeUnknownFields;
		if (u !== false) (u == true ? UnknownFieldHandler.onWrite : u)(this.typeName, message, writer);
		return writer;
	}
};
/**
* @generated MessageType for protobuf message github.authentication.v0.IssueSignedAuthTokenResponse
*/
var IssueSignedAuthTokenResponse = new IssueSignedAuthTokenResponse$Type();
function getUnknownAuthContext() {
	return {
		result: AuthenticateResponse_Result.UNKNOWN,
		actorId: void 0,
		userLogin: void 0,
		userSpammy: void 0,
		sessionId: void 0,
		iet: void 0,
		expiresAt: void 0,
		isStaff: false
	};
}
var options = () => {
	const opts = {
		formatters: { level: (label) => ({ level: label }) },
		mixin: (logObject) => {
			const result = logObject;
			if (typeof result.req === "object") {
				const { req } = result;
				const [path, query] = req.url.split("?");
				return {
					"http.request.header.accept": req.headers.accept,
					"http.request.header.content-length": req.headers["content-length"],
					"http.request.header.content-type": req.headers["content-type"],
					"http.request.header.host": req.headers.host,
					"http.request.header.traceparent": req.headers.traceparent,
					"http.request.header.user-agent": req.headers["user-agent"],
					"http.request.header.x-github-request-id": req.headers["x-github-request-id"],
					"http.request.header.x-glb-via": req.headers["x-glb-via"],
					"http.request.method": req.method,
					"http.route": req.routeOptions?.url,
					"url.path": path,
					"url.query": query
				};
			}
			if (typeof result.res === "object") {
				const { res } = result;
				return { "http.response.status_code": res.statusCode };
			}
			return result;
		},
		mixinMergeStrategy: (logObject, mixinObject) => {
			const { req, res, ...rest } = logObject;
			return {
				...rest,
				...mixinObject
			};
		}
	};
	if (process$1.env.NODE_ENV !== "production") opts["transport"] = {
		target: "pino-pretty",
		options: {
			translateTime: "HH:MM:ss Z",
			ignore: "pid,hostname"
		}
	};
	if (process$1.env.NODE_ENV === "test") opts["level"] = "silent";
	return opts;
};
var sonicBoom = pino.destination({
	sync: false,
	maxLength: 16 * 1024 * 1024
});
var logger = pino(options(), sonicBoom);
var APP_NAME = "github-ui";
var UnknownError = class extends Error {
	constructor(message, options = {}) {
		super(`An unknown error occurred in github-ui: ${message}`, {
			...options,
			cause: message
		});
		this.name = "UnknownError";
	}
};
/**
* Error thrown when a service fetch request fails.
* Contains the HTTP status code and service name for error handling.
*/
var ServiceFetchError = class extends Error {
	status;
	statusText;
	service;
	constructor(status, statusText, service) {
		super(`Failed to fetch from ${service}: ${status} ${statusText}`);
		this.name = "ServiceFetchError";
		this.status = status;
		this.statusText = statusText;
		this.service = service;
	}
	/**
	* Returns true if this error represents a 404 Not Found response.
	*
	* TanStack Router automatically detects errors with an `isNotFound` property
	* and renders the not-found component instead of the error boundary.
	* @see https://github.com/TanStack/router/blob/main/packages/router-core/src/not-found.ts#L39
	*/
	get isNotFound() {
		return this.status === 404;
	}
};
function coerceToError(error) {
	if (error instanceof Error || error?.name === "Error") return error;
	if (typeof error === "string") return new Error(error);
	return new UnknownError(error);
}
var { FAILBOT_HAYSTACK_URL } = env;
var appName = "ui-runtime";
var failbot = createFailbot();
function createFailbot() {
	const logger = getLogger();
	const backends = [new LogBackend({ log: logger.error.bind(logger) })];
	if (FAILBOT_HAYSTACK_URL) backends.push(new HTTPBackend({ haystackURL: FAILBOT_HAYSTACK_URL }));
	else logger.info("FAILBOT_HAYSTACK_URL not set in ui-runtime, not reporting to failbotg");
	return new Failbot({
		app: appName,
		backends
	});
}
function getLogger() {
	if (process$1.env.NODE_ENV === "test") return {
		error: () => {},
		info: () => {}
	};
	return logger;
}
function reportError(e, message) {
	const error = coerceToError(e);
	const results = failbot.report(error, { context: {
		"#deployment": appName,
		...message ? { "#exception.message": message } : {}
	} });
	for (const result of results) result.catch((err) => {
		logger.error("Error reporting to Failbot", err);
	});
}
var statsd = new StatsD({
	mock: process$1.env.NODE_ENV === "test" || !process$1.env.DD_AGENT_HOST,
	cacheDns: true,
	globalTags: {
		app: APP_NAME,
		deployed_to: process$1.env.HEAVEN_DEPLOYED_ENV || "unknown"
	},
	errorHandler: (err) => {
		reportError(err, "statsd.error");
	}
}).childClient({ prefix: "github_ui." });
function statsWrapper(method) {
	return function(stat, value, tags) {
		if (process$1.env.LOG_STATS === "true") logger.info({
			stat,
			value,
			tags
		}, `statsd.${method}`);
		try {
			statsd[method](stat, value, tags);
		} catch (err) {
			reportError(err, "statsd.error");
		}
	};
}
var increment = statsWrapper("increment");
statsWrapper("gauge");
var distribution = statsWrapper("distribution");
sonicBoom.on("drop", () => {
	increment("logger.messages.drop", 1);
});
var StatsTimer = class {
	start;
	name;
	tags = {};
	constructor(name, tags = {}) {
		this.start = performance.now();
		this.name = name;
		this.tags = tags;
	}
	send(tags = {}, name = this.name) {
		distribution(name, this.time, {
			...this.tags,
			...tags
		});
	}
	get time() {
		return performance.now() - this.start;
	}
};
var dataFetchMetricsAsyncLocalStorage = new AsyncLocalStorage();
function runWithDataFetchMetricsContext(fn) {
	return dataFetchMetricsAsyncLocalStorage.run(/* @__PURE__ */ new Map(), fn);
}
function recordDataFetchDuration(name, durationMs) {
	const store = dataFetchMetricsAsyncLocalStorage.getStore();
	if (!store) return;
	store.set(name, (store.get(name) ?? 0) + durationMs);
}
function getDataFetchMetrics() {
	const store = dataFetchMetricsAsyncLocalStorage.getStore();
	if (!store) return {};
	return Object.fromEntries(store.entries());
}
/**
* Default backoff function: linear 10ms * attempt
*/
function defaultBackoff(attempt) {
	return attempt * 10;
}
/**
* Sleep for the specified number of milliseconds
*/
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
/**
* Returns true if the error is an AbortError (request was intentionally cancelled or timed out).
* AbortErrors should not be retried.
*/
function isAbortError(error) {
	return error instanceof Error && error.name === "AbortError";
}
/**
* Execute a fetch operation with retry logic.
*
* @param fetchFn - Function that performs the fetch and returns a Response
* @param options - Retry configuration
* @returns The response after retries
*/
async function fetchWithRetry(fetchFn, options = {}) {
	const { count = 3, backoff = defaultBackoff } = options;
	let retries = 0;
	while (true) {
		try {
			const response = await fetchFn();
			if (response.status < 500) return response;
			if (retries === count) return response;
		} catch (error) {
			if (isAbortError(error) || retries === count) throw error;
		}
		retries++;
		await sleep(backoff(retries));
	}
}
var DataService = class {
	name;
	baseUrl;
	parsedBaseUrl;
	warmup;
	fetch;
	dispatcher;
	forwardHostHeaders;
	forwardIETHeader;
	getAdditionalHeaders;
	getAdditionalParams;
	timeout;
	ownedAgent;
	fetchOptions;
	pools = /* @__PURE__ */ new Map();
	statsIntervalId;
	constructor(options) {
		this.name = options.name;
		this.forwardHostHeaders = options.forwardHostHeaders ?? false;
		this.forwardIETHeader = options.forwardIETHeader ?? false;
		this.getAdditionalHeaders = options.getAdditionalHeaders;
		this.getAdditionalParams = options.getAdditionalParams;
		this.baseUrl = this.createServiceUrl(options);
		this.parsedBaseUrl = new URL(this.baseUrl);
		this.warmup = options.warmup;
		this.timeout = options.timeout ?? 8e3;
		const { fetchOptions, ...agentOpts } = options.dispatcherOptions ?? {};
		this.fetchOptions = fetchOptions;
		const userFactory = agentOpts.factory;
		this.ownedAgent = new Agent({
			connections: 50,
			keepAliveTimeout: 6e4,
			keepAliveMaxTimeout: 6e5,
			pipelining: 1,
			...agentOpts,
			factory: (origin, opts) => {
				const dispatcher = userFactory ? userFactory(origin, opts) : new Pool(origin, opts);
				if (dispatcher instanceof Pool) {
					const originKey = origin.toString();
					this.pools.set(originKey, dispatcher);
				}
				return dispatcher;
			}
		});
		this.statsIntervalId = setInterval(() => {
			this.logAgentStats();
		}, 3e5);
		this.statsIntervalId.unref();
		this.dispatcher = this.ownedAgent;
		this.fetch = this.createFetch();
	}
	/**
	* Wrap a fetch call with standardized stats timing and duration recording.
	* Callers pass in the prepared url/init plus per-call metric metadata.
	*/
	async fetchWithMetrics(url, init, meta, retry) {
		const timer = new StatsTimer("data_fetch_time", {
			service: this.name,
			method: meta.method,
			mechanism: meta.mechanism,
			type: meta.metricTag
		});
		let response;
		try {
			response = await this.fetch(url, init, retry);
			if (!response.ok) logger.error({
				event: `${meta.mechanism}_http_error`,
				service: this.name,
				url,
				method: init.method,
				status: response.status,
				statusText: response.statusText
			}, `[${this.name}] HTTP error: upstream returned ${response.status} for ${url}`);
			return response;
		} catch (error) {
			logger.error({
				event: `${meta.mechanism}_network_error`,
				service: this.name,
				url,
				method: init.method,
				error: error instanceof Error ? error.message : String(error),
				errorStack: error instanceof Error ? error.stack : void 0,
				errorCause: error instanceof Error ? error.cause : void 0
			}, `[${this.name}] Network error: failed to connect to ${url}`);
			throw new Error(`Network error: ${this.name} is unreachable`, { cause: error });
		} finally {
			timer.send({ result: response?.ok ? "success" : "error" });
			recordDataFetchDuration(`${this.name}.${meta.metricTag}`, timer.time);
		}
	}
	/** Close the pooled dispatcher associated with this service (if owned). */
	async close() {
		if (this.statsIntervalId) clearInterval(this.statsIntervalId);
		if (this.ownedAgent) await this.ownedAgent.close();
	}
	/** Replace the dispatcher (used in tests or custom wiring). */
	setDispatcher(dispatcher, fetchOptions) {
		if (this.ownedAgent) {
			this.ownedAgent.close();
			this.ownedAgent = void 0;
		}
		this.dispatcher = dispatcher;
		this.fetchOptions = fetchOptions;
		this.fetch = this.createFetch();
	}
	createFetch() {
		return (url, init, retry) => {
			const signal = AbortSignal.timeout(this.timeout);
			const mergedInit = init?.signal ? {
				...this.fetchOptions,
				...init,
				signal: AbortSignal.any([signal, init.signal])
			} : {
				...this.fetchOptions,
				...init,
				signal
			};
			return fetchWithRetry(() => fetch(url, {
				...mergedInit,
				dispatcher: this.dispatcher
			}), retry);
		};
	}
	resolveWarmupConfig(overrides) {
		return {
			path: overrides?.path ?? this.warmup?.path ?? "/status",
			method: overrides?.method ?? this.warmup?.method ?? "HEAD",
			headers: overrides?.headers ?? this.warmup?.headers ?? void 0
		};
	}
	/**
	* Pre-warm connections for this service using the shared Undici dispatcher.
	* Uses the service's configured timeout for each warmup request.
	*/
	async prewarm(options = {}) {
		const { warmupConnections = 10, ...overrides } = options;
		const { path, method, headers } = this.resolveWarmupConfig(overrides);
		const warmupUrl = buildUrl(this.baseUrl, path);
		const attemptWarmup = async () => {
			try {
				const response = await this.fetch(warmupUrl, {
					method,
					headers
				});
				if (response.ok) {
					await response.body?.cancel();
					return {
						service: this.name,
						ok: true,
						status: response.status
					};
				}
				await response.body?.cancel();
				return {
					service: this.name,
					ok: false,
					status: response.status,
					error: /* @__PURE__ */ new Error(`Warmup request failed with status ${response.status}`)
				};
			} catch (error) {
				return {
					service: this.name,
					ok: false,
					error
				};
			}
		};
		const warmups = Array.from({ length: Math.max(1, warmupConnections) }, () => attemptWarmup());
		const results = await Promise.all(warmups);
		this.logAgentStats();
		const success = results.find((result) => result.ok);
		if (success) return success;
		const lastResult = results[results.length - 1];
		if (!lastResult) throw new Error("prewarmDataServices returned no results");
		return lastResult;
	}
	/** Build the service URL from constructor options; overridable by subclasses/tests. */
	createServiceUrl(options) {
		const resolved = {
			...options,
			connectionType: options.connectionType ?? "mesh",
			devPort: options.devPort ?? options.port
		};
		switch (resolved.connectionType) {
			case "sidecar": return this.#createSidecarUrl(resolved);
			case "mesh": return this.#createMeshUrl(resolved);
		}
	}
	/** Sidecar services always use localhost regardless of environment. */
	#createSidecarUrl(options) {
		return `http://localhost:${isDev() ? options.devPort : options.port}`;
	}
	/** Mesh services use localhost in dev, service mesh URL in production. */
	#createMeshUrl(options) {
		if (isDev()) return `http://localhost:${options.devPort}`;
		const environment = options.environment ?? process.env.PROXIMA_STAMP ?? "production";
		const repo = options.repo ?? options.service;
		return `http://${options.service}.${repo}-${environment}.svc.cluster.local:${options.port}`;
	}
	logAgentStats() {
		const stats = this.getAgentStats();
		if (Object.keys(stats).length > 0) logger.info({ stats }, `[${this.name}] Undici Agent Stats:`);
	}
	getAgentStats() {
		const stats = {};
		stats["pools"] = this.pools;
		for (const [origin, pool] of this.pools) {
			stats["origin"] = origin;
			stats["connected"] = pool.stats.connected;
			stats["total"] = pool.stats.size;
			stats["queued"] = pool.stats.queued;
			stats["running"] = pool.stats.running;
			stats["pending"] = pool.stats.pending;
			stats["free"] = pool.stats.free;
		}
		return stats;
	}
};
var CATALOG_SERVICE = "github-ui";
/** Default JSON write options for serializing protobuf requests. */
var DEFAULT_JSON_WRITE_OPTIONS = {
	emitDefaultValues: true,
	enumAsInteger: true
};
/** Default JSON read options for deserializing protobuf responses. */
var DEFAULT_JSON_READ_OPTIONS = { ignoreUnknownFields: true };
var TwirpTransport = class extends DataService {
	constructor(options) {
		super(options);
	}
	/**
	* Low-level Twirp call using pre-serialized JSON.
	*
	* - Adds the Twirp prefix if missing.
	* - Sends/accepts JSON by default.
	* - Forwards cookies from the current request context (if present).
	*
	*/
	async fetchRPC(options) {
		const path = this.buildRpcPath(options.rpc);
		const url = buildUrl(this.baseUrl, path);
		const metricTag = options.metricTag ?? this.metricTagFromRpc(options.rpc);
		const additionalHeaders = this.getAdditionalHeaders?.({
			url,
			method: "POST",
			body: options.body
		});
		const headers = {
			Accept: "application/json",
			"Content-Type": "application/json",
			"Catalog-Service": CATALOG_SERVICE,
			"User-Agent": CATALOG_SERVICE,
			...additionalHeaders
		};
		const cookieHeader = getRequestHeader("cookie");
		if (cookieHeader) headers["Cookie"] = cookieHeader;
		const fetchOptions = {
			method: "POST",
			headers,
			body: JSON.stringify(options.body ?? {})
		};
		logger.info({
			event: "twirp_request_start",
			service: this.name,
			rpc: options.rpc,
			url,
			method: fetchOptions.method
		}, `[${this.name}] Twirp request starting: ${options.rpc}`);
		const response = await this.fetchWithMetrics(url, fetchOptions, {
			method: fetchOptions.method,
			mechanism: "twirp",
			metricTag
		});
		if (response.ok) return await response.json();
		let errorDetail;
		try {
			errorDetail = await response.text();
		} catch {}
		logger.error({
			event: "twirp_response_error",
			service: this.name,
			status: response.status,
			rpc: options.rpc,
			detail: errorDetail
		});
		throw new Error(`[${this.name}] Twirp RPC ${options.rpc} returned HTTP ${response.status}`);
	}
	/**
	* Call a Twirp RPC endpoint with typed protobuf serialization.
	*
	* Handles toJson/fromJson with standardized options so callers don't need to
	* remember serialization details. Options can be overridden per call.
	*/
	async call(options) {
		const writeOptions = {
			...DEFAULT_JSON_WRITE_OPTIONS,
			...options.jsonWriteOptions
		};
		const readOptions = {
			...DEFAULT_JSON_READ_OPTIONS,
			...options.jsonReadOptions
		};
		const jsonBody = options.requestType.toJson(options.request, writeOptions);
		const responseJson = await this.fetchRPC({
			rpc: options.rpc,
			body: jsonBody,
			metricTag: options.metricTag
		});
		return options.responseType.fromJson(responseJson, readOptions);
	}
	buildRpcPath(rpc) {
		const trimmed = rpc.startsWith("/") ? rpc : `/${rpc}`;
		return trimmed.startsWith("/twirp/") ? trimmed : `/twirp${trimmed}`;
	}
	metricTagFromRpc(rpc) {
		const snake = ((rpc.startsWith("/twirp/") ? rpc.slice(7) : rpc.replace(/^\/+/, "")).split("/").pop() ?? "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase();
		return `${this.name}_${snake || "unknown"}`;
	}
};
var ActorIDAttribute = "actor.id";
var UserLoginAttribute = "user.login";
var UserSpammyAttribute = "user.spammy";
var CredentialIDAttribute = "credential.id";
var CredentialTypeAttribute = "credential.type";
function generatePublicKeyFingerprint(publicKeyData) {
	const decoded = Buffer.from(publicKeyData, "base64");
	return require$$1.createHash("sha256").update(decoded).digest("base64").replace(/=+$/, "");
}
function loadPublicKey(publicKeyData) {
	const pem = Buffer.from(publicKeyData, "base64").toString("utf8");
	return require$$1.createPublicKey(pem);
}
function loadKeysFromEnv() {
	const env = process.env.TOKEN_EXCHANGER_PUBLIC_KEYS;
	if (!env) throw new Error("TOKEN_EXCHANGER_PUBLIC_KEYS environment variable is required");
	const keys = /* @__PURE__ */ new Map();
	for (const entry of env.split(";")) {
		const keyObject = loadPublicKey(entry);
		const fingerprint = generatePublicKeyFingerprint(entry);
		increment("authnd.client.token_verifier.public_key_loaded", 1, { kid: fingerprint });
		keys.set(fingerprint, keyObject);
	}
	return keys;
}
function decodeJwtHeader(token) {
	const decoded = jwt.decode(token, { complete: true });
	if (!decoded || typeof decoded === "string" || !decoded.header || !decoded.payload) throw new Error("invalid JWT format");
	if (typeof decoded.payload === "string") throw new Error("invalid JWT payload");
	const issuer = decoded.payload.iss;
	return {
		...decoded.header,
		iss: issuer
	};
}
function getClaimValue(payload, dottedKey) {
	if (Object.prototype.hasOwnProperty.call(payload, dottedKey)) return payload[dottedKey];
	const [rootKey, leafKey] = dottedKey.split(".", 2);
	if (!rootKey || !leafKey) return void 0;
	const root = payload[rootKey];
	if (root && typeof root === "object" && leafKey in root) return root[leafKey];
}
function extractClaims(payload, mapping) {
	const result = {};
	for (const [outputKey, claimKey] of Object.entries(mapping)) result[outputKey] = getClaimValue(payload, claimKey);
	return result;
}
function getAuthClaims(payload) {
	const { actorId, userLogin, userSpammy, sessionId, credentialType } = extractClaims(payload, {
		actorId: ActorIDAttribute,
		userLogin: UserLoginAttribute,
		userSpammy: UserSpammyAttribute,
		sessionId: CredentialIDAttribute,
		credentialType: CredentialTypeAttribute
	});
	if (typeof actorId !== "number") throw new Error("invalid actor.id");
	if (typeof userLogin !== "string") throw new Error("invalid user.login");
	if (typeof sessionId !== "number") throw new Error("invalid credential.id");
	if (typeof credentialType !== "string") throw new Error("invalid credential.type");
	if (userSpammy !== void 0 && typeof userSpammy !== "boolean") throw new Error("invalid user.spammy");
	return {
		actorId,
		userLogin,
		userSpammy,
		sessionId,
		credentialType
	};
}
function verifyTokenPayload(token, keys) {
	const decodedJwt = decodeJwtHeader(token);
	if (decodedJwt.alg !== "ES256") throw new Error("unexpected alg");
	const kid = typeof decodedJwt.kid === "string" ? decodedJwt.kid : void 0;
	if (!kid) throw new Error("missing kid");
	const key = keys.get(kid);
	if (!key) throw new Error("unknown kid");
	if (decodedJwt.iss !== "github/authnd") throw new Error("invalid issuer");
	const verified = jwt.verify(token, key, {
		algorithms: ["ES256"],
		ignoreExpiration: true,
		ignoreNotBefore: true
	});
	if (typeof verified === "string") throw new Error("invalid JWT payload");
	return verified;
}
function verifyAuthToken(token) {
	const keys = loadKeysFromEnv();
	const fail = (result) => ({
		iet: token,
		result,
		actorId: void 0,
		userLogin: void 0,
		sessionId: void 0,
		userSpammy: void 0
	});
	let payload;
	try {
		payload = verifyTokenPayload(token, keys);
	} catch (error) {
		logger.error({ error: error instanceof Error ? error.message : String(error) }, "Auth token verification failed");
		return fail(AuthenticateResponse_Result.FAILED_PUBLIC_KEY_NOT_VERIFIED);
	}
	const exp = payload.exp;
	if (typeof exp === "number" && exp < Math.floor(Date.now() / 1e3)) return fail(AuthenticateResponse_Result.FAILED_CREDENTIAL_EXPIRED);
	let claims;
	try {
		claims = getAuthClaims(payload);
	} catch (error) {
		logger.error({ error: error instanceof Error ? error.message : String(error) }, "Auth token claims extraction failed");
		return fail(AuthenticateResponse_Result.FAILED_PUBLIC_KEY_NOT_VERIFIED);
	}
	if (claims?.credentialType !== "UserSession") {
		logger.error({ credentialType: claims?.credentialType }, "Auth token has unsupported credential type");
		return fail(AuthenticateResponse_Result.FAILED_CREDENTIAL_INVALID);
	}
	const { actorId, userLogin, sessionId, userSpammy } = claims;
	return {
		iet: token,
		result: AuthenticateResponse_Result.SUCCESS,
		actorId,
		userLogin,
		sessionId,
		userSpammy
	};
}
var tokenExchangerFailureMetric = "authnd.client.token_exchanger.failures";
var tokenExchangerMethod = "ExchangeToken";
var AuthndClient = class {
	name = "authnd";
	transport;
	constructor() {
		this.transport = new TwirpTransport({
			name: this.name,
			service: this.name,
			repo: this.name,
			port: 8080,
			devPort: 8092,
			getAdditionalHeaders: buildHmacHeaders(process.env.AUTHND_HMAC_KEY)
		});
	}
	async exchangeToken(request) {
		let failureResult;
		try {
			const response = await this.transport.call({
				rpc: "github.authentication.v0.TokenExchanger/ExchangeToken",
				request,
				requestType: ExchangeTokenRequest,
				responseType: ExchangeTokenResponse
			});
			const responseResultTag = getAuthndResultTag(response.result);
			if (responseResultTag !== "SUCCESS") {
				failureResult ??= responseResultTag;
				return getUnknownAuthContext();
			}
			let authContext;
			try {
				authContext = verifyAuthToken(response.token);
			} catch {
				failureResult ??= "token_verifier_error";
				return getUnknownAuthContext();
			}
			if (authContext.result !== AuthenticateResponse_Result.SUCCESS) {
				failureResult ??= getAuthndResultTag(authContext.result);
				return getUnknownAuthContext();
			}
			return {
				...authContext,
				expiresAt: timestampToDate(response.expiresAt)
			};
		} catch {
			failureResult ??= "twirp_client_error";
			return getUnknownAuthContext();
		} finally {
			if (failureResult) emitAuthFailure(this.name, failureResult);
		}
	}
	/**
	* Verify a credential via authnd's Authenticate RPC.
	*
	* Supports any credential type in the Credentials oneof (SignedAuthToken,
	* UserSession, AccessToken, etc). Returns the raw AuthenticateResponse
	* — callers are responsible for interpreting the result and attributes.
	*
	* RPC: github.authentication.v0.Authenticator/Authenticate
	*/
	async authenticate(request) {
		return this.transport.call({
			rpc: "github.authentication.v0.Authenticator/Authenticate",
			request,
			requestType: AuthenticateRequest,
			responseType: AuthenticateResponse
		});
	}
	/**
	* Issue a new SignedAuthToken via authnd's CredentialManager service.
	*
	* Mints a SAT bound to a user ID (and optionally a session ID) with
	* the given scope and expiry. Returns the raw IssueSignedAuthTokenResponse
	* — callers are responsible for checking the token field.
	*
	* RPC: github.authentication.v0.CredentialManager/IssueSignedAuthToken
	*/
	async issueSignedAuthToken(request) {
		return this.transport.call({
			rpc: "github.authentication.v0.CredentialManager/IssueSignedAuthToken",
			request,
			requestType: IssueSignedAuthTokenRequest,
			responseType: IssueSignedAuthTokenResponse
		});
	}
};
var authndClient = new AuthndClient();
function timestampToDate(timestamp) {
	if (!timestamp) return void 0;
	return new Date(timestamp.seconds * 1e3 + Math.floor(timestamp.nanos / 1e6));
}
function emitAuthFailure(service, result) {
	increment(tokenExchangerFailureMetric, 1, {
		service,
		method: tokenExchangerMethod,
		result
	});
}
function getAuthndResultTag(result) {
	if (result === void 0) return "unknown";
	return AuthenticateResponse_Result[result] ?? "unknown";
}
function buildHmacHeaders(secret) {
	if (!secret) return void 0;
	return () => {
		const now = /* @__PURE__ */ new Date();
		const timestamp = Math.floor(now.getTime() / 1e3).toString();
		const mac = require$$1.createHmac("sha256", secret).update(timestamp).digest("hex");
		return { "Request-HMAC": `${timestamp}.${mac}` };
	};
}
var authAsyncLocalStorage = new AsyncLocalStorage();
function getAuthContext() {
	return authAsyncLocalStorage.getStore() || void 0;
}
function isStaff() {
	return getAuthContext()?.isStaff ?? false;
}
async function runWithAuthContext(fn) {
	getCurrentRequest();
	const context = await buildAuthContext();
	return authAsyncLocalStorage.run(context, () => Promise.resolve(fn()));
}
async function buildAuthContext() {
	const userSession = getCookie("user_session");
	if (!userSession) return getUnknownAuthContext();
	const staffCookie = getCookie("staffonly");
	try {
		return {
			...await authndClient.exchangeToken({ credentials: { kind: {
				oneofKind: "userSession",
				userSession: {
					key: userSession,
					domain: 0
				}
			} } }),
			isStaff: staffCookie !== null
		};
	} catch {}
	return getUnknownAuthContext();
}
var VERIFY_METRIC = "signed_auth_token.verify";
/**
* Verify a SignedAuthToken by calling authnd's Authenticate RPC.
*
* @param token - The raw SAT string
* @param scope - The expected scope (e.g. "StaffOnly:yes")
* @returns VerifyResult with valid=true and actorId on success, valid=false on any failure
*/
async function verifySignedAuthToken(token, scope) {
	try {
		const response = await authndClient.authenticate({ credentials: { kind: {
			oneofKind: "signedAuthToken",
			signedAuthToken: {
				token,
				scope
			}
		} } });
		if (response.result === AuthenticateResponse_Result.SUCCESS) {
			const actorAttr = response.attributes?.find((a) => a.id === "actor.id");
			const actorId = actorAttr?.value?.kind?.oneofKind === "integerValue" ? actorAttr.value.kind.integerValue : void 0;
			const contextActorId = getAuthContext()?.actorId;
			if (contextActorId !== void 0 && contextActorId !== actorId) {
				logger.info({
					event: "signed_auth_token.verify actor_mismatch",
					expectedActorId: contextActorId,
					actualActorId: actorId
				});
				increment(VERIFY_METRIC, 1, { result: "actor_mismatch" });
				return { valid: false };
			}
			increment(VERIFY_METRIC, 1, { result: "success" });
			return {
				valid: true,
				actorId
			};
		}
		increment(VERIFY_METRIC, 1, { result: "failed" });
		return { valid: false };
	} catch {
		increment(VERIFY_METRIC, 1, { result: "error" });
		return { valid: false };
	}
}
var ISSUE_METRIC = "signed_auth_token.issue";
/**
* Issue a new SignedAuthToken via authnd's IssueSignedAuthToken RPC.
* The user ID is taken from the current auth context's actorId.
*
* @param options.scope  - The scope string
* @param options.expiresInSeconds - Seconds until expiry
* @returns The minted token string, or undefined on failure
* @throws {Error} If the current auth context has no actorId
*/
async function issueSignedAuthToken({ scope, expiresInSeconds }) {
	const userId = getAuthContext()?.actorId;
	if (userId === void 0) throw new Error("issueSignedAuthToken requires an authenticated user");
	try {
		const expiresAt = new Date(Date.now() + expiresInSeconds * 1e3);
		const response = await authndClient.issueSignedAuthToken({
			userId,
			sessionId: 0,
			scope,
			expiresAtTime: {
				seconds: Math.floor(expiresAt.getTime() / 1e3),
				nanos: 0
			},
			attributes: []
		});
		if (response.token) {
			increment(ISSUE_METRIC, 1, { result: "success" });
			return response.token;
		}
		increment(ISSUE_METRIC, 1, { result: "empty_token" });
		return;
	} catch {
		increment(ISSUE_METRIC, 1, { result: "error" });
		return;
	}
}
export { buildUrl as a, getDataFetchMetrics as c, issueSignedAuthToken as d, logger as f, verifySignedAuthToken as g, runWithDataFetchMetricsContext as h, StatsTimer as i, increment as l, runWithAuthContext as m, DataService as n, coerceToError as o, reportError as p, ServiceFetchError as r, getAuthContext as s, APP_NAME as t, isStaff as u };
