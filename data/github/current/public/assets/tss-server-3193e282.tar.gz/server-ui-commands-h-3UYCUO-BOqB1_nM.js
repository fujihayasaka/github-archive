import { i as ButtonComponent, m as useRefObjectAsForwardedRef, s as KeybindingHint } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { an as IconButton, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { t as useTrackingRef } from "./server-use-tracking-ref-CdNeH4dZ-DBOS4qOg.js";
import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { t as hotkey_exports } from "./server-hotkey-CjmZAe2y-CaimUUmF.js";
import { r as isShortcutAllowed } from "./server-keyboard-shortcuts-helper-BRqP2m0f-DOsDhPIe.js";
import { c as useRegisterCommands, i as getCommandMetadata, n as CommandEventHandlersMap, o as getKeybindingsForCommands, s as getPrimaryKeybinding, t as CommandEvent } from "./server-commands-registry-PhKKp09d-CINoICbD.js";
import React, { createContext, use, useCallback, useEffect, useEffectEvent, useId, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/** https://hydro.githubapp.com/hydro_analytics/apps/ui-commands */
var HYDRO_APP_ID = "ui-commands";
var CommandTriggerEvent = {
	TYPE: "command.trigger",
	send(context) {
		sendEvent(CommandTriggerEvent.TYPE, context);
	}
};
/** Get the opening HTML tag of the given element. */
function getOpeningHtmlTag(element) {
	const tagName = element.tagName.toLowerCase();
	const attributes = Array.from(element.attributes).map((attr) => `${attr.name}="${attr.value.replaceAll("\"", "\\\"")}"`).join(" ");
	return `<${tagName}${attributes ? ` ${attributes}` : ""}>`;
}
/** Record a Hydro analytics event for triggering a command. */
function recordCommandTriggerEvent(commandEvent, domEvent) {
	CommandTriggerEvent.send({
		app_name: HYDRO_APP_ID,
		command_id: commandEvent.commandId,
		trigger_type: domEvent instanceof KeyboardEvent ? "keybinding" : "click",
		target_element_html: domEvent.target instanceof HTMLElement ? getOpeningHtmlTag(domEvent.target) : void 0,
		keybinding: getPrimaryKeybinding(commandEvent.commandId)
	});
}
/** Return a copy of the array without the first encountered instance of `value` (based on `===` comparison). */
function filterOnce(array, value) {
	let encounteredOnce = false;
	return array.filter((el) => {
		if (el === value && !encounteredOnce) {
			encounteredOnce = true;
			return false;
		}
		return true;
	});
}
function getActiveModal() {
	const nonEmptyModals = [...document.querySelectorAll("dialog:modal, [role=\"dialog\"][aria-modal=\"true\"]")].filter((modal) => {
		return modal.childNodes.length > 0 && elementHasNonZeroHeight(modal);
	});
	return nonEmptyModals.length ? nonEmptyModals[nonEmptyModals.length - 1] : null;
}
function isInsideModal(modal, element) {
	if (!element) return false;
	return modal.contains(element) ?? false;
}
function elementHasNonZeroHeight(element) {
	if (element.clientHeight > 0) return true;
	for (const child of element.children) if (elementHasNonZeroHeight(child)) return true;
	return false;
}
var registeredGlobalCommands = /* @__PURE__ */ new Map();
function useDetectConflicts(scope, commands) {
	const $ = c(5);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ new Map();
		$[0] = t0;
	} else t0 = $[0];
	const registeredCommands = scope === "global" ? registeredGlobalCommands : t0;
	let t1;
	let t2;
	if ($[1] !== commands || $[2] !== registeredCommands) {
		t1 = () => {
			for (const [commandId, keybinding] of getKeybindingsForCommands(CommandEventHandlersMap.keys(commands))) {
				const alreadyRegisteredIds = registeredCommands.get(keybinding)?.filter((id) => id !== commandId) ?? [];
				if (alreadyRegisteredIds.length) console.warn(`The keybinding (${keybinding}) for the "${commandId}" command conflicts with the keybinding for the already-registered command(s) "${alreadyRegisteredIds.join(", ")}". This may result in unpredictable behavior.`);
				registeredCommands.set(keybinding, alreadyRegisteredIds.concat(commandId));
			}
			return () => {
				for (const [commandId_0, keybinding_0] of getKeybindingsForCommands(CommandEventHandlersMap.keys(commands))) {
					const remainingCommandIds = filterOnce(registeredCommands.get(keybinding_0) ?? [], commandId_0);
					if (remainingCommandIds?.length) registeredCommands.set(keybinding_0, remainingCommandIds);
					else registeredCommands.delete(keybinding_0);
				}
			};
		};
		t2 = [commands, registeredCommands];
		$[1] = commands;
		$[2] = registeredCommands;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
}
/**
* @param triggerCommand Callback to trigger the command handler. Explicitly return `false` to indicate that the
* command was ignored and the event should be allowed to propagate as normal.
*/
function useOnKeyDown(commandsIds, triggerCommand, t0) {
	const $ = c(9);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { triggerOnDefaultPrevented: t2 } = t1;
	const triggerOnDefaultPrevented = t2 === void 0 ? false : t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = new hotkey_exports.SequenceTracker();
		$[2] = t3;
	} else t3 = $[2];
	const sequenceTracker = t3;
	let map;
	if ($[3] !== commandsIds) {
		map = /* @__PURE__ */ new Map();
		for (const [id, keybinding] of getKeybindingsForCommands(commandsIds)) map.set(keybinding, id);
		$[3] = commandsIds;
		$[4] = map;
	} else map = $[4];
	const keybindingMap = map;
	const lastEventRef = useRef(null);
	let t4;
	if ($[5] !== keybindingMap || $[6] !== triggerCommand || $[7] !== triggerOnDefaultPrevented) {
		t4 = (event) => {
			const nativeEvent = "nativeEvent" in event ? event.nativeEvent : event;
			if (!triggerOnDefaultPrevented && nativeEvent.defaultPrevented) return;
			if (lastEventRef.current === nativeEvent) return;
			lastEventRef.current = nativeEvent;
			if (!isShortcutAllowed(nativeEvent)) {
				sequenceTracker.reset();
				return;
			}
			sequenceTracker.registerKeypress(nativeEvent);
			const commandId = keybindingMap.get(sequenceTracker.sequence) ?? keybindingMap.get((0, hotkey_exports.eventToHotkeyString)(nativeEvent));
			if (!commandId) return;
			if (triggerCommand(commandId, nativeEvent) ?? true) {
				sequenceTracker.reset();
				event.preventDefault();
				event.stopPropagation();
				nativeEvent.stopImmediatePropagation();
			}
		};
		$[5] = keybindingMap;
		$[6] = triggerCommand;
		$[7] = triggerOnDefaultPrevented;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
}
var UiCommandTriggerEvent = class extends Event {
	commandId;
	domEvent;
	constructor(commandId, domEvent) {
		super(customDomEventName);
		this.commandId = commandId;
		this.domEvent = domEvent;
	}
};
/**
* There's no context for global commands because they can be defined in any react app on the page. So to be able to
* trigger them without keyboard events, we emit and listen for custom DOM events instead.
*/
var customDomEventName = "ui-command-trigger";
/** Trigger a global command without a keyboard event. */
function dispatchGlobalCommand(commandId, domEvent) {
	document.dispatchEvent(new UiCommandTriggerEvent(commandId, domEvent));
}
/**
* Provide command handlers that are activatable when focus is anywhere on the current page, including outside this
* React app.
*
* @example
* <GlobalCommands commands={{'issues:navigateToCode': navigateToCode}} />
*/
var GlobalCommands = ({ commands }) => {
	const elementRef = useRef(null);
	const triggerCommand = useCallback((commandId, domEvent) => {
		if (domEvent instanceof KeyboardEvent) {
			const activeModal = getActiveModal();
			if (activeModal && !isInsideModal(activeModal, elementRef.current)) return false;
		}
		const handler = commands[commandId];
		if (handler) {
			const event = new CommandEvent(commandId);
			try {
				handler(event);
			} finally {
				recordCommandTriggerEvent(event, domEvent);
			}
		} else return false;
	}, [commands]);
	const triggerCommandEvent = useEffectEvent(triggerCommand);
	const onKeyDown = useEffectEvent(useOnKeyDown(CommandEventHandlersMap.keys(commands), triggerCommand));
	useDetectConflicts("global", commands);
	useRegisterCommands(commands);
	useEffect(() => {
		const onCustomEvent = (event_0) => {
			if (!isValidCommandEvent(event_0)) return;
			const { commandId: commandId_0, domEvent: domEvent_0 } = event_0;
			triggerCommandEvent(commandId_0, domEvent_0);
		};
		document.addEventListener("keydown", onKeyDown);
		document.addEventListener(customDomEventName, onCustomEvent);
		return () => {
			document.removeEventListener("keydown", onKeyDown);
			document.removeEventListener(customDomEventName, onCustomEvent);
		};
	}, []);
	return /* @__PURE__ */ jsx("div", {
		ref: elementRef,
		className: "d-none"
	});
};
GlobalCommands.displayName = "GlobalCommands";
function isValidCommandEvent(event) {
	return event instanceof UiCommandTriggerEvent;
}
var CommandsContext = createContext({
	triggerCommand(id, domEvent, isLimitedScope = false) {
		if (isLimitedScope) return false;
		dispatchGlobalCommand(id, domEvent);
	},
	registerLimitedKeybindingScope: () => {}
});
CommandsContext.displayName = "CommandsContext";
var CommandsContextProvider = CommandsContext;
var useCommandsContext = () => use(CommandsContext);
/** Renders a visual representing the keybinding for a command. If no keybinding is present, renders nothing. */
var CommandKeybindingHint = ({ commandId, ...props }) => {
	const keys = getPrimaryKeybinding(commandId);
	return keys ? /* @__PURE__ */ jsx(KeybindingHint, {
		keys,
		...props
	}) : null;
};
CommandKeybindingHint.displayName = "CommandKeybindingHint";
/**
* `CommandActionListItem` is a wrapper around `@primer/react` `ActionList.Item`, but instead of an `onClick` handler
* it takes a command ID and handles clicks by emitting command trigger events.
*
* If the command is gated by a disabled feature flag, nothing will render.
*/
var CommandActionListItem = (t0) => {
	const $ = c(3);
	const { commandId, children, description, leadingVisual, trailingVisual, ...forwardProps } = t0;
	const metadata = getCommandMetadata(commandId);
	const { triggerCommand } = useCommandsContext();
	if (!metadata) return null;
	let t1;
	if ($[0] !== commandId || $[1] !== triggerCommand) {
		t1 = (event) => triggerCommand(commandId, event.nativeEvent);
		$[0] = commandId;
		$[1] = triggerCommand;
		$[2] = t1;
	} else t1 = $[2];
	return jsxs(ActionList.Item, {
		...forwardProps,
		onSelect: t1,
		children: [
			children ?? jsx("span", { children: metadata.name }),
			description ? jsx(ActionList.Description, {
				truncate: true,
				children: description
			}) : null,
			leadingVisual ? jsx(ActionList.LeadingVisual, { children: leadingVisual }) : null,
			trailingVisual !== null && jsxs(ActionList.TrailingVisual, { children: [
				jsx("span", {
					className: "sr-only",
					children: "("
				}),
				trailingVisual ?? jsx(CommandKeybindingHint, {
					commandId,
					format: "condensed"
				}),
				jsx("span", {
					className: "sr-only",
					children: ")"
				})
			] })
		]
	});
};
CommandActionListItem.displayName = "CommandActionListItem";
CommandActionListItem.displayName = "ActionList.CommandItem";
var ButtonKeybindingHint = ({ commandId }) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
	/* @__PURE__ */ jsx("span", {
		className: "sr-only",
		children: "("
	}),
	/* @__PURE__ */ jsx(CommandKeybindingHint, {
		commandId,
		format: "condensed"
	}),
	/* @__PURE__ */ jsx("span", {
		className: "sr-only",
		children: ")"
	})
] });
/**
* `CommandButton` is a wrapper around `@primer/react` `Button`, but instead of an `onClick` handler it takes a
* command ID and handles clicks by emitting command trigger events.
*
* If the command is gated by a disabled feature flag, nothing will render.
*/
ButtonKeybindingHint.displayName = "ButtonKeybindingHint";
var CommandButton = ({ ref, commandId, children, trailingVisual, showKeybindingHint = false, onClick: externalOnClick, ...forwardProps }) => {
	const metadata = getCommandMetadata(commandId);
	const { triggerCommand } = useCommandsContext();
	if (!metadata) return null;
	return /* @__PURE__ */ jsx(ButtonComponent, {
		...forwardProps,
		onClick: (event) => {
			externalOnClick?.(event);
			if (!event.defaultPrevented) triggerCommand(commandId, event.nativeEvent);
		},
		trailingVisual: trailingVisual ?? (showKeybindingHint ? /* @__PURE__ */ jsx(ButtonKeybindingHint, { commandId }) : void 0),
		ref,
		children: children ?? metadata.name
	});
};
CommandButton.displayName = "CommandButton";
CommandButton.displayName = "CommandButton";
/**
* `CommandButton` is a wrapper around `@primer/react` `Button`, but instead of an `onClick` handler it takes a
* command ID and handles clicks by emitting command trigger events.
*
* If the command is gated by a disabled feature flag, nothing will render.
*/
var CommandIconButton = ({ ref, commandId, ["aria-label"]: ariaLabel, onClick: externalOnClick, icon, ...forwardProps }) => {
	const metadata = getCommandMetadata(commandId);
	const { triggerCommand } = useCommandsContext();
	if (!metadata) return null;
	return /* @__PURE__ */ jsx(IconButton, {
		"aria-label": ariaLabel ?? metadata.name,
		onClick: (event) => {
			externalOnClick?.(event);
			if (!event.defaultPrevented) triggerCommand(commandId, event.nativeEvent);
		},
		icon,
		ref,
		keybindingHint: getPrimaryKeybinding(commandId),
		...forwardProps
	});
};
CommandIconButton.displayName = "CommandIconButton";
CommandIconButton.displayName = "CommandIconButton";
var ignoredKeysLowercase = new Set(["enter", "tab"]);
/**
* If the user is composing text, we don't want to respond to
* the `Enter` key to perform a typical activation
*
* Composing text is a special case where the user is inputting
* text from IME (e.g. Japanese) and we don't want to save the
* item upon receiving the enter key as that may be part of the
* selection of the character into the input.
*
* issue: https://github.com/github/memex/issues/5680
* related: https://github.com/github/memex/issues/5680
* related: https://github.com/facebook/react/issues/3926
*
* @param onKeyDown: A keyboard handler callback to wrap with a callback which ignores `ENTER`
* and `TAB` while composing.
*
* @returns props which should be spread onto an `<input>` element
**/
var useIgnoreKeyboardActionsWhileComposing = (onKeyDown) => {
	const $ = c(5);
	const isComposingRef = useRef(false);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (event) => {
			if (event.type === "compositionstart") isComposingRef.current = true;
			if (event.type === "compositionend") isComposingRef.current = false;
		};
		$[0] = t0;
	} else t0 = $[0];
	const handleComposition = t0;
	let t1;
	if ($[1] !== onKeyDown) {
		t1 = (event_0) => {
			const nativeEvent = event_0.nativeEvent;
			const isComposingNative = nativeEvent && "isComposing" in nativeEvent && nativeEvent.isComposing;
			const isSafariProcessKey = event_0.key === "Process";
			if (isMacOS() && event_0.keyCode === 229) return;
			const isComposingInput = isComposingRef.current || isComposingNative || isSafariProcessKey;
			if (ignoredKeysLowercase.has(event_0.key.toLowerCase()) && isComposingInput) return;
			onKeyDown(event_0);
		};
		$[1] = onKeyDown;
		$[2] = t1;
	} else t1 = $[2];
	const wrappedOnKeyDown = t1;
	let t2;
	if ($[3] !== wrappedOnKeyDown) {
		t2 = {
			onCompositionStart: handleComposition,
			onCompositionEnd: handleComposition,
			onKeyDown: wrappedOnKeyDown
		};
		$[3] = wrappedOnKeyDown;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
var emptyLimitedScopeMap = /* @__PURE__ */ new Map();
var ScopedCommandsComponent = ({ ref: forwardedRef, commands, ...props }) => {
	const commandsRef = useTrackingRef(commands);
	const parentContext = useCommandsContext();
	const triggerCommand = useCallback((commandId, domEvent, isLimitedScope = false) => {
		const handler = commandsRef.current[commandId];
		if (handler) {
			const event = new CommandEvent(commandId);
			try {
				handler(event);
			} finally {
				recordCommandTriggerEvent(event, domEvent);
			}
		} else return parentContext.triggerCommand(commandId, domEvent, isLimitedScope);
	}, [commandsRef, parentContext]);
	useDetectConflicts("scoped", commands);
	useRegisterCommands(commands);
	const [limitedScopeMap, setLimitedScopeMap] = useState(emptyLimitedScopeMap);
	const registerLimitedKeybindingScope = useCallback((uniqueKey, newIds) => setLimitedScopeMap((map) => {
		const currentIds = map.get(uniqueKey);
		if (newIds.length === currentIds?.length && newIds.every((id, i) => currentIds[i] === id)) return map;
		return new Map([...map, [uniqueKey, newIds]]);
	}), []);
	/** The set of command IDs that are not limited in scope and should be registered at this level. */
	const commandIdsWithoutLimitedScope = useMemo(() => {
		const commandIdsWithLimitedScope = new Set(Array.from(limitedScopeMap.values()).flat());
		return CommandEventHandlersMap.keys(commands).filter((id_0) => commands[id_0] !== void 0 && !commandIdsWithLimitedScope.has(id_0));
	}, [commands, limitedScopeMap]);
	return /* @__PURE__ */ jsx(CommandsContextProvider, {
		value: useMemo(() => ({
			triggerCommand,
			registerLimitedKeybindingScope
		}), [triggerCommand, registerLimitedKeybindingScope]),
		children: /* @__PURE__ */ jsx(KeybindingScope, {
			commandIds: commandIdsWithoutLimitedScope,
			...props,
			ref: forwardedRef
		})
	});
};
ScopedCommandsComponent.displayName = "ScopedCommands";
/**
* Internal: binds keyboard event listeners for the given command IDs, using handlers from context.
*
* Unlike `LimitKeybindingScope`, this doesn't register the commands as limited-scope, so it can be shared with
* `ScopedCommands`.
*/
var KeybindingScope = ({ ref: forwardedRef, commandIds: commands, as, limited = false, triggerOnDefaultPrevented, ...props }) => {
	const parentContext = useCommandsContext();
	const keyDownProps = useIgnoreKeyboardActionsWhileComposing(useOnKeyDown(commands, useCallback((id, domEvent) => parentContext.triggerCommand(id, domEvent, limited), [parentContext, limited]), { triggerOnDefaultPrevented }));
	const containerRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef ?? null, containerRef);
	const handler = useEffectEvent(keyDownProps.onKeyDown);
	useEffect(() => {
		const target = containerRef.current;
		if (!target) return;
		target.addEventListener("keydown", handler);
		return () => target.removeEventListener("keydown", handler);
	}, []);
	const style = as !== void 0 || props.className !== void 0 ? void 0 : { display: "contents" };
	return /* @__PURE__ */ jsx(as ?? "div", {
		style,
		...props,
		...keyDownProps,
		ref: containerRef
	});
};
KeybindingScope.displayName = "KeyboardScope";
/**
* By default, `ScopedCommands` will bind keybinding handlers for its entire child tree. This usually works fine, but
* sometimes you need to render a command-bound component outside of the desired keybinding area. For this case, you
* can limit the keybinding area of certain commands by wrapping the desired area in `ScopedCommands.LimitKeybindingScope`.
*
* For example, here the `CommandButton` component has access to the "format bold" command but is not included in the
* keybinding scope -- the keybinding for bold formatting can only be triggered when focus is inside the input. On the
* other hand, the "submit" keybinding can be triggered anywhere inside the scope:
*
* ```
* <ScopedCommands commands={{'comment-box:format-bold': handleFormatBold, 'comment-box:submit': handleSubmit}}>
*   <CommandButton commandId="comment-box:format-bold" />
*
*   <ScopedCommands.LimitKeybindingScope commands={["comment-box:format-bold"]}>
*     <textarea />
*   </ScopedCommands.LimitKeybindingScope>
* </ScopedCommands>
* ```
*/
var LimitKeybindingScope = ({ ref: forwardedRef, commandIds: commands, ...props }) => {
	const parentContext = useCommandsContext();
	const uniqueKey = useId();
	useEffect(() => parentContext.registerLimitedKeybindingScope(uniqueKey, commands), [
		parentContext,
		commands,
		uniqueKey
	]);
	useEffect(() => () => parentContext.registerLimitedKeybindingScope(uniqueKey, []), [parentContext, uniqueKey]);
	return /* @__PURE__ */ jsx(KeybindingScope, {
		limited: true,
		commandIds: commands,
		...props,
		ref: forwardedRef
	});
};
LimitKeybindingScope.displayName = "LimitKeybindingScope";
/**
* Provide command handlers that only work when focus is within a certain part of the React component tree.
*
* NOTE: By default this component will wrap contents in a `div` with `display: contents`. In certain cases this breaks
* the page's HTML structure (for example, when wrapping list items or table cells). In this case the component element
* type can be overridden with `as`.
* @example
* <ScopedCommands commands={{
*   'comment-box:format-bold': handleFormatBold
* }}>
*   <textarea></textarea>
* </ScopedCommands>
*/
var ScopedCommands = Object.assign(ScopedCommandsComponent, { LimitKeybindingScope });
export { GlobalCommands as a, CommandKeybindingHint as i, CommandButton as n, ScopedCommands as o, CommandIconButton as r, useIgnoreKeyboardActionsWhileComposing as s, CommandActionListItem as t };
