import { EditorView } from "@codemirror/view";
import { Annotation, EditorState } from "@codemirror/state";
import { indentUnit } from "@codemirror/language";
var spacingControls = (options) => {
	const extensions = [EditorState.tabSize.of(options.indentUnit)];
	if (options.indentWithTabs) extensions.push(indentUnit.of("	"));
	else extensions.push(indentUnit.of(" ".repeat(options.indentUnit)));
	if (options.lineWrapping) extensions.push(EditorView.lineWrapping);
	return extensions;
};
var externalUpdate = Annotation.define();
function readOnly() {
	return [EditorState.readOnly.of(true), EditorState.transactionFilter.of((tr) => {
		if (tr.docChanged && !tr.annotation(externalUpdate)) return [];
		return tr;
	})];
}
export { readOnly as n, spacingControls as r, externalUpdate as t };
