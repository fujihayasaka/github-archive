import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
var allCaches = [];
if (typeof window !== "undefined") window.__SAFE_STORAGE_CLEAR_ALL_CACHES__ = () => {
	for (const cache of allCaches) cache.clear();
};
var createStore = (storageType) => {
	const storage = safeStorage(storageType);
	const cache = /* @__PURE__ */ new Map();
	const listeners = /* @__PURE__ */ new Map();
	allCaches.push(cache);
	function isEqual(a, b) {
		if (a === b) return true;
		try {
			return JSON.stringify(a) === JSON.stringify(b);
		} catch {
			return false;
		}
	}
	function emit(key) {
		const set = listeners.get(key);
		if (set) for (const listener of set) listener();
	}
	function subscribe(key, listener) {
		let set = listeners.get(key);
		if (!set) {
			set = /* @__PURE__ */ new Set();
			listeners.set(key, set);
		}
		set.add(listener);
		return () => {
			set.delete(listener);
			if (set.size === 0) listeners.delete(key);
		};
	}
	function readStorage(key, initial) {
		if (cache.has(key)) return cache.get(key);
		try {
			const raw = storage.getItem(key);
			const value = raw == null ? initial : JSON.parse(raw);
			cache.set(key, value);
			return value;
		} catch {
			cache.set(key, initial);
			return initial;
		}
	}
	function writeStorage(key, value) {
		if (isEqual(cache.get(key), value)) return;
		cache.set(key, value);
		emit(key);
		storage.setItem(key, JSON.stringify(value));
	}
	/**
	* Remove a key from storage and cache, notifying subscribers
	*/
	function removeStorage(key) {
		cache.delete(key);
		storage.removeItem(key);
		emit(key);
	}
	/**
	* Reset a key to a default value atomically - updates cache before emitting
	* to avoid timing issues with useSyncExternalStore snapshots
	*/
	function resetStorage(key, defaultValue) {
		if (isEqual(cache.get(key), defaultValue)) return;
		cache.set(key, defaultValue);
		storage.removeItem(key);
		emit(key);
	}
	/**
	* Clear all cached data (useful for testing).
	* Emits to subscribers - components should handle cache miss in getSnapshot
	* by reseeding with their initialValue.
	*/
	function clearAll() {
		const keys = [...cache.keys()];
		for (const key of keys) {
			cache.delete(key);
			storage.removeItem(key);
			emit(key);
		}
	}
	/**
	* Clear specified keys from cache and storage.
	* Emits to subscribers - components should handle cache miss in getSnapshot
	* by reseeding with their initialValue.
	*/
	function clearKeys(keys) {
		for (const key of keys) {
			cache.delete(key);
			storage.removeItem(key);
			emit(key);
		}
	}
	/**
	* Clear keys matching a prefix from cache and storage.
	* Emits to subscribers - components should handle cache miss in getSnapshot
	* by reseeding with their initialValue.
	*/
	function clearKeysByPrefix(prefix) {
		const keysToRemove = getKeysByPrefix(prefix);
		for (const key of keysToRemove) {
			cache.delete(key);
			storage.removeItem(key);
			emit(key);
		}
	}
	/**
	* Get all items whose keys start with a prefix
	*/
	function getItemsByPrefix(prefix) {
		const items = [];
		const keys = getKeysByPrefix(prefix);
		for (const key of keys) if (cache.has(key)) items.push(cache.get(key));
		else {
			const raw = storage.getItem(key);
			if (raw != null) try {
				items.push(JSON.parse(raw));
			} catch {}
		}
		return items;
	}
	/**
	* Get all keys from cache and storage that start with the provided prefix, de-duplicated.
	*/
	function getKeysByPrefix(prefix) {
		const cacheKeys = [...cache.keys()].filter((key) => key.startsWith(prefix));
		const storageKeys = storage.getKeys().filter((key) => key.startsWith(prefix));
		return [...new Set([...cacheKeys, ...storageKeys])];
	}
	return {
		writeStorage,
		readStorage,
		removeStorage,
		resetStorage,
		subscribe,
		cache,
		clearAll,
		clearKeys,
		clearKeysByPrefix,
		getItemsByPrefix,
		getKeysByPrefix
	};
};
export { createStore as t };
