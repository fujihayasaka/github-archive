import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { Hn as NoteIcon, fn as IssueOpenedIcon, hn as IssueTracksIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { b as useParams$1, g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { a as KnownTypes, f as useUser } from "./server-use-user-CNSliVdg-D1BtlcwW.js";
import { n as setTitle } from "./server-document-metadata-T1_tkk9h-DjLTfGyB.js";
import { $ as isFilterBlock, K as getHasValueSuggestion, M as defaultFilterProviderOptions, Q as isEmptyFilterBlockValue, S as TIME_RANGE_VALUES, T as ValidationTypes, U as getFilterValue, V as getExcludeKeySuggestion, Y as getNoValueSuggestion, at as sanitizeOperators, b as Strings, c as FilterProviderType, i as FILTER_KEYS, q as getLastFilterBlockValue, rt as isNestedFilterProvider } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { n as OrgFilterProvider, r as RepositoryFilterProvider } from "./server-repository-CE0zbnIG-CI4ka2FT.js";
import { a as queryResolver, i as queryMap, t as PULLS_PATH } from "./server-pulls-dashboard-surface-content-route-CY12u0dp-B-R1iWh6.js";
import { $ as useShortcutEditor, A as ReactionsFilterProvider, B as StateFilterProvider, C as MentionsFilterProvider, E as NestedFilterProvider, G as UpdatedFilterProvider, H as StatusFilterProvider, I as ShaFilterProvider, K as UserFilterProvider, M as ReviewFilterProvider, N as ReviewRequestedFilterProvider, O as ParentIssueFilterProvider, P as ReviewedByFilterProvider, Q as useShortcutDeletion, S as LinkedFilterProvider, T as MilestoneFilterProvider, U as TeamFilterProvider, V as StaticFilterProvider, W as TeamReviewRequestedFilterProvider, Z as getShortcutsWithSaved, _ as InteractionsFilterProvider, a as BlockedBySearchFilterProvider, b as LabelFilterProvider, c as ClosedFilterProvider, d as CreatedFilterProvider, g as InFilterProvider, h as HeadFilterProvider, i as BaseFilterProvider, j as ReasonFilterProvider, k as ProjectFilterProvider, l as CommenterFilterProvider, n as AssigneeFilterProvider, o as BlockingSearchFilterProvider, p as DraftFilterProvider, q as UserReviewRequestedFilterProvider, r as AuthorFilterProvider, t as ArchivedFilterProvider, u as CommentsFilterProvider, v as InvolvesFilterProvider, w as MergedFilterProvider, x as LanguageFilterProvider, y as IsFilterProvider, z as SortFilterProvider } from "./server-providers-w0hxsmcG-B_8wxADa.js";
import { createContext, use, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
import { parse } from "@github/blackbird-parser";
var PullsInboxMaxAge = {
	OneMonth: "1m",
	ThreeMonths: "3m",
	OneYear: "1y",
	None: "none"
};
var PULLS_INBOX_MAX_AGE_LABELS = {
	[PullsInboxMaxAge.OneMonth]: "Last month",
	[PullsInboxMaxAge.ThreeMonths]: "Last 3 months",
	[PullsInboxMaxAge.OneYear]: "Last year",
	[PullsInboxMaxAge.None]: "Any time"
};
var StateType = {
	Opened: "OPEN",
	Closed: "CLOSED",
	Merged: "MERGED"
};
var ReviewDecisionState = {
	Approved: "APPROVED",
	ChangesRequested: "CHANGES_REQUESTED",
	ReviewRequired: "REVIEW_REQUIRED"
};
var StatusCheckState = {
	Success: "SUCCESS",
	Failure: "FAILURE",
	Pending: "PENDING"
};
var isInboxEnabled = () => {
	return isFeatureEnabled("pulls_dashboard_inbox");
};
var isOnInboxPath = ({ pathname }) => {
	if (!isInboxEnabled()) return false;
	const normalized = pathname.length > 1 ? pathname.replace(/\/+$/, "") : pathname;
	return normalized === "/pulls" || normalized === "/pulls/inbox";
};
function isQualifier(node) {
	return !!node.qualifier;
}
function isContentNode(node) {
	return node.value !== void 0;
}
function hasChildren(node) {
	return !!node.children;
}
var nonBreakingSpace = String.fromCharCode(160);
function parseString(value) {
	const regex = new RegExp(nonBreakingSpace, "g");
	return parse(value.replace(regex, " "));
}
/**
* Checks whether the query AST contains an explicit issue type qualifier
* (e.g. `is:issue` or `type:issue`) that is not negated.
*
* This function parses the query string into an AST and walks it to detect
* explicit issue intent, handling edge cases like:
* - Both `is:issue` and `type:issue` qualifiers
* - Negated queries (e.g., `NOT is:issue`)
* - Qualifiers inside quoted text (ignored)
* - Case-sensitive matching for the qualifier value (`issue` only)
*
* @param query - The search query string
* @returns true if the query contains an explicit, non-negated issue qualifier
*/
function isExplicitIssueQuery(query) {
	if (!query) return false;
	return checkNode(parseString(query));
}
function checkNode(node, negated = false) {
	if (node.kind === "Not") {
		if (hasChildren(node)) return node.children.some((child) => checkNode(child, true));
		return false;
	}
	if (isQualifier(node) && isContentNode(node.content) && !negated) {
		const value = node.content.value.toString();
		if (node.qualifier === "Is" && value === "issue") return true;
		if (node.qualifier === "Type" && value === "issue") return true;
	}
	if (hasChildren(node)) return node.children.some((child) => checkNode(child, negated));
	return false;
}
/**
* Hook to manage URL-based list results state.
* Handles query parameters, pagination, and navigation for list results.
*
* @param params Configuration object
* @param params.defaultFilterValue Default filter value to use when no query param is present
* @returns An object containing:
*   - fetchedQuery: The active query (empty string if explicitly cleared)
*   - currentPage: The current page number from URL
*   - fetchResults: Function to navigate to new search results
*   - locationSidebarLinkId: The sidebar link path
*/
function useListResults(t0) {
	const $ = c(12);
	const { defaultFilterValue: t1 } = t0;
	const defaultFilterValue = t1 === void 0 ? "" : t1;
	const navigate = useNavigate$1();
	const location = useLocation$1();
	const { sendAnalyticsEvent } = useAnalytics();
	const { mode } = useParams$1();
	const currentParams = new URLSearchParams(location.search);
	const [isEmptyQuery, setIsEmptyQuery] = useState(false);
	const query = queryResolver({
		searchParams: currentParams,
		params: { mode }
	});
	const fetchedQuery = isEmptyQuery ? "" : query;
	const prevQueryRef = useRef(query);
	useEffect(() => {
		if (prevQueryRef.current !== query) {
			setIsEmptyQuery(false);
			prevQueryRef.current = query;
		}
	}, [query]);
	const currentPage = Number(currentParams.get("page") || 1);
	let t2;
	if ($[0] !== defaultFilterValue || $[1] !== location.state || $[2] !== mode || $[3] !== navigate || $[4] !== sendAnalyticsEvent || $[5] !== setIsEmptyQuery) {
		t2 = function fetchResults(t3) {
			const { q, page, sidebarLinkId } = t3;
			if (isExplicitIssueQuery(q)) {
				sendAnalyticsEvent("pull-requests.search", "IS_ISSUE", { query: q });
				navigate(`/issues?q=${encodeURIComponent(q)}`);
				return;
			}
			sendAnalyticsEvent("pull-requests.search", "LIST_RESULTS", { query: q });
			if (!q) {
				setIsEmptyQuery(true);
				return;
			}
			const navigateParams = new URLSearchParams();
			if (q && q !== defaultFilterValue) navigateParams.set("q", q);
			if (page > 1) navigateParams.set("page", page.toString());
			const search = navigateParams.toString();
			const navigationState = location.state;
			const effectiveSidebarLinkId = sidebarLinkId !== void 0 ? sidebarLinkId : navigationState?.sidebarLinkId;
			navigate({
				pathname: mode ? `${PULLS_PATH}/${mode}` : PULLS_PATH,
				search: search ? `?${search}` : ""
			}, effectiveSidebarLinkId ? { state: { sidebarLinkId: effectiveSidebarLinkId } } : void 0);
		};
		$[0] = defaultFilterValue;
		$[1] = location.state;
		$[2] = mode;
		$[3] = navigate;
		$[4] = sendAnalyticsEvent;
		$[5] = setIsEmptyQuery;
		$[6] = t2;
	} else t2 = $[6];
	const fetchResults = t2;
	let t3;
	if ($[7] !== currentPage || $[8] !== fetchResults || $[9] !== fetchedQuery || $[10] !== mode) {
		t3 = {
			fetchedQuery,
			currentPage,
			fetchResults,
			mode,
			locationSidebarLinkId: mode
		};
		$[7] = currentPage;
		$[8] = fetchResults;
		$[9] = fetchedQuery;
		$[10] = mode;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
var PullsDashboardSurfaceStateContext = createContext(null);
PullsDashboardSurfaceStateContext.displayName = "PullsDashboardSurfaceStateContext";
function PullsDashboardSurfaceStateProvider(t0) {
	const $ = c(17);
	const { children, payload, isLoading } = t0;
	const { pathname } = useLocation$1();
	let t1;
	if ($[0] !== pathname) {
		t1 = isOnInboxPath({ pathname });
		$[0] = pathname;
		$[1] = t1;
	} else t1 = $[1];
	const isOnInbox = t1;
	let t2;
	if ($[2] !== isOnInbox) {
		t2 = isOnInbox ? "" : queryMap().authored;
		$[2] = isOnInbox;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== t2) {
		t3 = { defaultFilterValue: t2 };
		$[4] = t2;
		$[5] = t3;
	} else t3 = $[5];
	const { fetchedQuery, currentPage, fetchResults, locationSidebarLinkId } = useListResults(t3);
	const [maxPrAge, setMaxPrAge] = useState(payload.filters?.maxPrAge ?? PullsInboxMaxAge.OneMonth);
	let t4;
	if ($[6] !== currentPage || $[7] !== fetchResults || $[8] !== fetchedQuery || $[9] !== isLoading || $[10] !== locationSidebarLinkId || $[11] !== maxPrAge || $[12] !== payload) {
		t4 = {
			payload,
			fetchedQuery,
			currentPage,
			fetchResults,
			locationSidebarLinkId,
			isLoading,
			maxPrAge,
			setMaxPrAge
		};
		$[6] = currentPage;
		$[7] = fetchResults;
		$[8] = fetchedQuery;
		$[9] = isLoading;
		$[10] = locationSidebarLinkId;
		$[11] = maxPrAge;
		$[12] = payload;
		$[13] = t4;
	} else t4 = $[13];
	const value = t4;
	let t5;
	if ($[14] !== children || $[15] !== value) {
		t5 = jsx(PullsDashboardSurfaceStateContext, {
			value,
			children
		});
		$[14] = children;
		$[15] = value;
		$[16] = t5;
	} else t5 = $[16];
	return t5;
}
PullsDashboardSurfaceStateProvider.displayName = "PullsDashboardSurfaceStateProvider";
function usePullsDashboardSurfaceStateContext() {
	const context = use(PullsDashboardSurfaceStateContext);
	if (!context) throw new Error("usePullsDashboardSurfaceStateContext must be used within a PullsDashboardSurfaceStateProvider");
	return context;
}
/**
* Shared utilities for org-aware field provider processing.
* Used by both the useOrgAwareProviders hook and IssueFieldFilterQueryParser.
*/
var FIELD_PREFIX = "field.";
/**
* Extract org names from raw query string using regex patterns.
* Supports both org: and repo: filters, extracting org from repo format.
*
* @param rawQuery - The raw search query string
* @returns Array of org names found in the query
*
* @example
* extractOrgsFromRawQuery('org:github repo:microsoft/repo')
* // returns ['github', 'microsoft']
*/
function extractOrgsFromRawQuery(rawQuery) {
	const orgs = /* @__PURE__ */ new Set();
	const orgMatches = rawQuery.match(/org:"?([a-zA-Z0-9._-]+(?:,[a-zA-Z0-9._-]+)*)"?/g);
	if (orgMatches) for (const match of orgMatches) {
		const colonIndex = match.indexOf(":");
		const orgValues = match.substring(colonIndex + 1).replace(/^"(.*)"$/, "$1").split(",");
		for (const org of orgValues) if (org) orgs.add(org);
	}
	const repoMatches = rawQuery.match(/repo:"?([a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+(?:,[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+)*)"?/g);
	if (repoMatches) for (const match of repoMatches) {
		const colonIndex = match.indexOf(":");
		const repos = match.substring(colonIndex + 1).replace(/^"(.*)"$/, "$1").split(",");
		for (const repo of repos) {
			const orgFromRepo = repo.split("/")[0];
			if (orgFromRepo) orgs.add(orgFromRepo);
		}
	}
	return Array.from(orgs).filter(Boolean);
}
/**
* Parse a field suggestion or provider key to extract field name and org.
* Uses known orgs to accurately parse hyphenated org names.
*
* @param input - Field suggestion or provider key to parse
* @param knownOrgs - Set of known org names to match against
* @returns Object with fieldName and orgName, or null if not a valid field input
*
* @example
* parseFieldInput('field.priority-github:', new Set(['github']))
* // returns {fieldName: 'priority', orgName: 'github'}
*/
function parseFieldInput(input, knownOrgs) {
	if (!isFieldProviderKey(input)) return null;
	const withoutFieldPrefix = input.substring(6);
	const withoutColon = input.endsWith(":") ? withoutFieldPrefix.slice(0, -1) : withoutFieldPrefix;
	for (const org of knownOrgs) if (withoutColon.endsWith(`-${org}`)) {
		const fieldName = withoutColon.substring(0, withoutColon.length - org.length - 1);
		if (fieldName.length > 0) return {
			fieldName,
			orgName: org
		};
	}
	return null;
}
/**
* Check if a provider key represents a field provider.
*
* @param key - The provider key to check
* @returns True if this is a field provider key
*
* @example
* isFieldProviderKey('field.priority-github') // returns true
* isFieldProviderKey('field.priority') // returns true
* isFieldProviderKey('state') // returns false
*/
function isFieldProviderKey(key) {
	return key.startsWith(FIELD_PREFIX) && key !== FIELD_PREFIX;
}
/**
* Clean a field provider key by removing org suffix.
* Only removes suffix if the org is in the provided context.
*
* @param providerKey - The original provider key
* @param orgContext - Set of valid org names from context
* @param knownOrgs - Set of all known org names (optional, for better matching)
* @returns The cleaned key
*
* @example
* cleanFieldProviderKey('field.priority-github', new Set(['github']))
* // returns 'field.priority'
*
* cleanFieldProviderKey('field.priority-github', new Set(['microsoft']))
* // returns 'field.priority-github' (unchanged)
*/
function cleanFieldProviderKey(providerKey, orgContext, knownOrgs) {
	if (!isFieldProviderKey(providerKey)) return providerKey;
	const parseResult = parseFieldInput(providerKey, knownOrgs || orgContext);
	if (!parseResult) return providerKey;
	const { fieldName, orgName } = parseResult;
	if (orgContext.has(orgName)) return `field.${fieldName}`;
	return providerKey;
}
/**
* Clean display name by removing org suffix in parentheses.
*
* @param displayName - The original display name
* @returns The cleaned display name
*
* @example
* cleanDisplayName('Priority (github)') // returns 'Priority'
* cleanDisplayName('Priority') // returns 'Priority' (unchanged)
*/
function cleanDisplayName(displayName) {
	if (!displayName) return "";
	return displayName.replace(/\s*\([^)]+\)\s*$/, "") || displayName;
}
/**
* Check if a provider key matches any org in the context.
* Used to determine if a field provider should be included.
*
* @param providerKey - The provider key to check
* @param orgContext - Set of org names from query context
* @returns True if the provider matches any org in context
*
* @example
* providerMatchesOrgContext('field.priority-github', new Set(['github']))
* // returns true
*
* providerMatchesOrgContext('field.priority-microsoft', new Set(['github']))
* // returns false
*/
function providerMatchesOrgContext(providerKey, orgContext) {
	if (!isFieldProviderKey(providerKey)) return true;
	return Array.from(orgContext).some((org) => providerKey.includes(`-${org}`));
}
var NUMERIC_FILTER_OPTIONS$1 = {
	positive: true,
	negative: true,
	decimal: true
};
function buildFieldSubKey(fieldData, options, organizationName) {
	const { name, data_type, name_slug } = fieldData;
	const displayName = organizationName ? `${name} (${organizationName})` : name;
	const key = organizationName ? `${name_slug}-${organizationName}` : name_slug ?? name.toLowerCase().replace(/\s+/g, "-");
	let values = [];
	if (data_type === "single_select") values = (fieldData.options || []).map((option) => ({
		value: option.name,
		displayName: option.name,
		priority: 10
	}));
	else if (data_type === "date") values = TIME_RANGE_VALUES;
	return {
		key,
		displayName,
		icon: KnownTypes[data_type]?.icon || NoteIcon,
		type: getFieldType(data_type),
		values,
		options: getFilterOptions$1(options, data_type),
		aliases: [`field.${fieldData.name_slug || fieldData.name}`]
	};
}
function getFilterOptions$1(options, type) {
	const baseOptions = {
		...defaultFilterProviderOptions,
		filterTypes: {
			multiKey: true,
			multiValue: true,
			valueless: options.filterTypes?.valueless,
			hasValue: options.filterTypes?.hasValue
		}
	};
	if (type === "number") return {
		...baseOptions,
		...NUMERIC_FILTER_OPTIONS$1
	};
	return baseOptions;
}
function getFieldType(data_type) {
	switch (data_type) {
		case "text": return FilterProviderType.Text;
		case "single_select": return FilterProviderType.Select;
		case "date": return FilterProviderType.Date;
		case "number": return FilterProviderType.Number;
		default: return FilterProviderType.Text;
	}
}
function mapNodeToFieldData(node) {
	return {
		name: node?.name ?? "",
		name_slug: node?.name_slug,
		options: node?.options,
		data_type: node?.data_type,
		description: node?.description
	};
}
function createNestedFieldProviderConfig(description, subKeys) {
	return {
		key: "field",
		displayName: "Field",
		description,
		priority: 3,
		icon: NoteIcon,
		subKeys
	};
}
async function fetchIssueFieldData(apiURL, abortController) {
	let response;
	try {
		response = await fetch(apiURL, {
			method: "GET",
			mode: "same-origin",
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			signal: abortController?.signal
		});
		if (response?.ok) return await response.json();
		return null;
	} catch (error) {
		if (error instanceof Error && error.name !== "AbortError") throw error;
		return null;
	}
}
var DASHBOARD_ISSUE_FIELD_FILTER_ENDPOINT = "/_filter/issue_fields/dashboard";
var dashboardIssueProviderCache = /* @__PURE__ */ new Map();
var knownDashboardIssueOrgs = /* @__PURE__ */ new Set();
async function getDashboardIssueFieldFilterProvider(options) {
	if (!ssrSafeWindow) return null;
	const cacheKey = "dashboard-issue-fields-global";
	if (dashboardIssueProviderCache.has(cacheKey)) return dashboardIssueProviderCache.get(cacheKey);
	const providerPromise = createDashboardProvider(options);
	dashboardIssueProviderCache.set(cacheKey, providerPromise);
	return providerPromise;
}
async function createDashboardProvider(options) {
	const response = await fetchIssueFieldData(new URL(DASHBOARD_ISSUE_FIELD_FILTER_ENDPOINT, ssrSafeWindow.location.origin).toString());
	if (!response) return new NestedFilterProvider(createNestedFieldProviderConfig("Filter by issue fields", []), options);
	return createDashboardFieldProvider(response, options);
}
function createDashboardFieldProvider(dashboardData, options) {
	const allSubKeys = [];
	knownDashboardIssueOrgs.clear();
	const orgNames = Object.keys(dashboardData?.issue_fields ?? {});
	for (const org of orgNames) knownDashboardIssueOrgs.add(org);
	for (const [orgName, orgData] of Object.entries(dashboardData?.issue_fields ?? {})) for (const field of orgData.fields) {
		if (!field || !field.data_type) continue;
		const subKey = buildFieldSubKey(mapNodeToFieldData({
			...field,
			organization: orgName
		}), options, orgName);
		if (subKey) allSubKeys.push(subKey);
	}
	return new NestedFilterProvider(createNestedFieldProviderConfig("Filter by issue fields", allSubKeys), options);
}
/**
* Checks if the providers contain any issue field providers that would benefit from org-aware processing
*/
function hasIssueFieldProviders(providers) {
	return providers.some((provider) => {
		if (!isNestedFilterProvider(provider) || !provider.filterProviders) return false;
		return provider.filterProviders.some((subProvider) => subProvider.key && isFieldProviderKey(subProvider.key));
	});
}
function flattenProvidersToRecord(providers) {
	const providersRecord = {};
	for (const provider of providers) if (isNestedFilterProvider(provider)) {
		if (provider.filterProviders) for (const subProvider of provider.filterProviders) {
			const key = subProvider.key;
			if (key) providersRecord[key] = subProvider;
		}
	} else {
		const key = provider.key;
		if (key) providersRecord[key] = provider;
	}
	return providersRecord;
}
function createCleanedProvider(originalProvider, cleanDisplayName, cleanKey) {
	const adjustedAliases = originalProvider.aliases?.filter((alias) => alias !== cleanKey) || [];
	const cleanedProvider = {
		...originalProvider,
		displayName: cleanDisplayName,
		key: cleanKey,
		aliases: adjustedAliases,
		getSuggestions: originalProvider.getSuggestions.bind(originalProvider),
		validateFilterBlockValues: originalProvider.validateFilterBlockValues.bind(originalProvider),
		getValueRowProps: originalProvider.getValueRowProps.bind(originalProvider)
	};
	if ("getSuggestions" in originalProvider && typeof originalProvider.getSuggestions === "function") {
		const originalGetSuggestions = originalProvider.getSuggestions.bind(originalProvider);
		cleanedProvider.getSuggestions = async function(filterQuery, filterBlock, config, caretIndex) {
			const savedDisplayName = originalProvider.displayName;
			const savedKey = originalProvider.key;
			const savedAliases = originalProvider.aliases;
			const mutableProvider = originalProvider;
			mutableProvider.displayName = cleanDisplayName || "";
			mutableProvider.key = cleanKey;
			mutableProvider.aliases = adjustedAliases;
			try {
				if ("provider" in filterBlock && filterBlock.provider) return await originalGetSuggestions(filterQuery, {
					...filterBlock,
					provider: {
						...filterBlock.provider,
						key: cleanKey
					}
				}, config, caretIndex);
				return await originalGetSuggestions(filterQuery, filterBlock, config, caretIndex);
			} finally {
				mutableProvider.displayName = savedDisplayName;
				mutableProvider.key = savedKey;
				mutableProvider.aliases = savedAliases;
			}
		};
	}
	return cleanedProvider;
}
/**
* Hook for processing filter providers with org-aware logic.
*
* This hook optimizes provider processing by:
* - Only processing providers when org/repo context actually changes
* - Early exit when no org context is needed
*
* @param options Configuration options for org-aware provider processing
* @returns Processed providers filtered based on org/repo context
*/
function useOrgAwareProviders(t0) {
	const $ = c(4);
	const { baseFilterProviders, effectiveQuery, isIssueFieldsGlobalSearchEnabled } = t0;
	let t1;
	if ($[0] !== baseFilterProviders || $[1] !== effectiveQuery || $[2] !== isIssueFieldsGlobalSearchEnabled) {
		bb0: {
			if (!isIssueFieldsGlobalSearchEnabled) {
				t1 = baseFilterProviders;
				break bb0;
			}
			if (!hasIssueFieldProviders(baseFilterProviders)) {
				t1 = baseFilterProviders;
				break bb0;
			}
			const providersRecord = flattenProvidersToRecord(baseFilterProviders);
			if (!effectiveQuery) {
				t1 = Object.values(providersRecord);
				break bb0;
			}
			const orgsFromQuery = new Set(extractOrgsFromRawQuery(effectiveQuery));
			t1 = Object.values(processOrgAwareProviders(providersRecord, orgsFromQuery));
		}
		$[0] = baseFilterProviders;
		$[1] = effectiveQuery;
		$[2] = isIssueFieldsGlobalSearchEnabled;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
var processOrgAwareProviders = (filterProviders, orgNames) => {
	if (orgNames.size === 0) return filterProviders;
	const contextualFilterProviders = {};
	for (const [key, provider] of Object.entries(filterProviders)) {
		let cleanedProvider = provider;
		if (isFieldProviderKey(key)) {
			if (!providerMatchesOrgContext(key, orgNames)) continue;
			const cleanedDisplayName = cleanDisplayName(provider.displayName);
			const cleanedKey = cleanFieldProviderKey(provider.key, orgNames, knownDashboardIssueOrgs);
			if (cleanedDisplayName !== provider.displayName || cleanedKey !== provider.key) cleanedProvider = createCleanedProvider(provider, cleanedDisplayName, cleanedKey);
		}
		contextualFilterProviders[key] = cleanedProvider;
	}
	return contextualFilterProviders;
};
var IS_FILTER_PROVIDER_NON_REPO_SCOPE_VALUES_ENUM = {
	public: "public",
	private: "private"
};
/**
* Default values for the IsFilterProvider
*/
var IS_FILTER_PROVIDER_VALUES = Object.values({
	closed: "closed",
	draft: "draft",
	issue: "issue",
	locked: "locked",
	merged: "merged",
	unmerged: "unmerged",
	open: "open",
	pr: "pr",
	unlocked: "unlocked",
	blocked: "blocked",
	blocking: "blocking",
	queued: "queued"
});
/**
* A superset of values for the IsFilterProvider used within the issues dashboard, including repository and issue scope
*/
var IS_FILTER_PROVIDER_NON_REPO_SCOPE_VALUES = [...Object.values(IS_FILTER_PROVIDER_NON_REPO_SCOPE_VALUES_ENUM), ...IS_FILTER_PROVIDER_VALUES];
var node$2 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "name"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "owner"
	}], v1 = [{
		"kind": "Variable",
		"name": "name",
		"variableName": "name"
	}, {
		"kind": "Variable",
		"name": "owner",
		"variableName": "owner"
	}], v2 = [{
		"kind": "Literal",
		"name": "first",
		"value": 100
	}], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "IssueTypeFilterProviderIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": v2,
					"concreteType": "IssueTypeConnection",
					"kind": "LinkedField",
					"name": "issueTypes",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "IssueTypeEdge",
						"kind": "LinkedField",
						"name": "edges",
						"plural": true,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "IssueType",
							"kind": "LinkedField",
							"name": "node",
							"plural": false,
							"selections": [v3],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"storageKey": "issueTypes(first:100)"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "IssueTypeFilterProviderIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": v2,
					"concreteType": "IssueTypeConnection",
					"kind": "LinkedField",
					"name": "issueTypes",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "IssueTypeEdge",
						"kind": "LinkedField",
						"name": "edges",
						"plural": true,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "IssueType",
							"kind": "LinkedField",
							"name": "node",
							"plural": false,
							"selections": [v3, v4],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"storageKey": "issueTypes(first:100)"
				}, v4],
				"storageKey": null
			}]
		},
		"params": {
			"id": "deecf4e5b9723fe1e223989471673f53",
			"metadata": {},
			"name": "IssueTypeFilterProviderIssueTypeQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$2.hash = "015cbd12b22f8ce7578562a617177773";
var node$1 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "suggestedIssueTypeNames",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [],
			"kind": "Fragment",
			"metadata": null,
			"name": "IssueTypeFilterProviderViewerIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "viewer",
				"plural": false,
				"selections": [v0],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [],
			"kind": "Operation",
			"name": "IssueTypeFilterProviderViewerIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "viewer",
				"plural": false,
				"selections": [v0, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "id",
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "58ebbad60258ea0c9eb795e67cc2b575",
			"metadata": {},
			"name": "IssueTypeFilterProviderViewerIssueTypeQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$1.hash = "765a25834ce6bc541a1d98b6355cf514";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "login"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "number"
	}], v1 = [{
		"kind": "Variable",
		"name": "login",
		"variableName": "login"
	}], v2 = [{
		"kind": "Variable",
		"name": "number",
		"variableName": "number"
	}], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "suggestedIssueTypeNames",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "IssueTypeFilterProviderProjectIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "Organization",
				"kind": "LinkedField",
				"name": "organization",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": v2,
					"concreteType": "ProjectV2",
					"kind": "LinkedField",
					"name": "projectV2",
					"plural": false,
					"selections": [v3],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "IssueTypeFilterProviderProjectIssueTypeQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "Organization",
				"kind": "LinkedField",
				"name": "organization",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": v2,
					"concreteType": "ProjectV2",
					"kind": "LinkedField",
					"name": "projectV2",
					"plural": false,
					"selections": [v3, v4],
					"storageKey": null
				}, v4],
				"storageKey": null
			}]
		},
		"params": {
			"id": "4ecab7512fd17375c718ee060e7c9130",
			"metadata": {},
			"name": "IssueTypeFilterProviderProjectIssueTypeQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node.hash = "54031af5ea97af051011bdae3b3dc9af";
require_react_relay();
require_relay_runtime();
var ISSUE_TYPE_FILTER_KEY = {
	displayName: "Type",
	key: "type",
	priority: 10,
	icon: IssueOpenedIcon,
	description: "Specify the type of issue to search for"
};
function isIssueTypeFilterProvider(filterProvider) {
	return "displayName" in filterProvider && filterProvider.displayName === ISSUE_TYPE_FILTER_KEY.displayName;
}
var NUMERIC_FILTER_OPTIONS = {
	positive: true,
	negative: true,
	decimal: true
};
var ISSUE_FIELD_FILTER_ENDPOINT = "/_filter/issue_fields";
var providerCache = /* @__PURE__ */ new Map();
async function getIssueFieldFilterProvider(options, repositoryScope) {
	const cacheKey = `${repositoryScope}-${JSON.stringify(options)}`;
	if (providerCache.has(cacheKey)) return providerCache.get(cacheKey);
	const providerPromise = createProvider(options, repositoryScope);
	providerCache.set(cacheKey, providerPromise);
	return providerPromise;
}
async function createProvider(options, repositoryScope) {
	const endpoint = new URL(ISSUE_FIELD_FILTER_ENDPOINT, window.location.origin);
	if (repositoryScope) endpoint.searchParams.set("repo", repositoryScope);
	return new NestedFilterProvider({
		key: "field",
		displayName: "Field",
		description: "Filter by issue fields",
		priority: 3,
		icon: NoteIcon,
		subKeys: ((await fetchData(endpoint.toString()))?.issue_fields ?? []).filter((node) => !!node).map((node) => {
			return buildSubKey({
				name: node?.name ?? "",
				name_slug: node?.name_slug,
				options: node?.options,
				data_type: node?.data_type.toLowerCase()
			}, options);
		})
	}, options);
}
function buildSubKey(fieldData, options) {
	const { name, data_type, name_slug } = fieldData;
	let values = [];
	if (data_type === "single_select") values = (fieldData.options || []).map((option) => ({
		value: option.name,
		displayName: option.name,
		priority: 10,
		iconColor: option.color
	}));
	else if (data_type === "date") values = TIME_RANGE_VALUES;
	return {
		key: name_slug ?? name.toLowerCase().replace(/\s+/g, "-"),
		displayName: name,
		icon: KnownTypes[data_type].icon,
		type: getType(data_type),
		values,
		options: getFilterOptions(options, data_type)
	};
}
function getFilterOptions(options, type) {
	const baseOptions = {
		...defaultFilterProviderOptions,
		filterTypes: {
			multiKey: true,
			multiValue: true,
			valueless: options.filterTypes?.valueless,
			hasValue: options.filterTypes?.hasValue
		}
	};
	if (type === "number") return {
		...baseOptions,
		...NUMERIC_FILTER_OPTIONS
	};
	return baseOptions;
}
async function fetchData(apiURL, abortController) {
	let response;
	try {
		response = await fetch(apiURL, {
			method: "GET",
			mode: "same-origin",
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json"
			},
			signal: abortController?.signal
		});
		if (response?.ok) return await response.json();
		return;
	} catch (error) {
		if (error instanceof Error && error.name !== "AbortError") throw error;
		return;
	}
}
var getType = (data_type) => {
	switch (data_type) {
		case "text": return FilterProviderType.Text;
		case "single_select": return FilterProviderType.Select;
		case "date": return FilterProviderType.Date;
		case "number": return FilterProviderType.Number;
		default: return FilterProviderType.Text;
	}
};
var SubIssueFilterProvider = class extends StaticFilterProvider {
	constructor() {
		const filterKey = {
			key: "sub-issue",
			displayName: "Sub-issue",
			icon: IssueTracksIcon,
			priority: 5,
			type: FilterProviderType.Text
		};
		super(filterKey, [], { filterTypes: {
			...defaultFilterProviderOptions?.filterTypes,
			hasValue: true
		} });
	}
	getSuggestions(_filterQuery, filterBlock, _config, caretIndex) {
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		const filterProviderKey = filterBlock.provider.key;
		const suggestions = [];
		if (isEmptyFilterBlockValue(filterBlock) && filterBlock.raw !== `-${filterProviderKey}:`) {
			suggestions.push(getNoValueSuggestion(this.displayName, this.icon));
			suggestions.push(getHasValueSuggestion(this.displayName, this.icon));
		}
		if (lastValue === "" && isFilterBlock(filterBlock) && filterBlock.raw !== `-${filterProviderKey}:`) {
			const excludeKeySuggestion = getExcludeKeySuggestion(filterProviderKey);
			suggestions.unshift(excludeKeySuggestion);
		}
		return suggestions;
	}
	validateFilterBlockValues(_filterQuery, _block, values) {
		const nwoRegex = /* @__PURE__ */ new RegExp("^\"?(?<owner>[a-zA-Z0-9-_.]+)/(?<repo>[a-zA-Z0-9-_.]+)#(?<number>[0-9]+)\"?$");
		return values.map((value) => {
			const filterValue = sanitizeOperators(getFilterValue(value.value));
			if (values.length < 1 || !filterValue) return {
				...value,
				valid: false,
				validations: [{
					type: ValidationTypes.EmptyValue,
					message: Strings.filterValueEmpty(this.key)
				}]
			};
			if (!nwoRegex.test(filterValue)) return {
				...value,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: `${Strings.filterInvalidValue(this.key, filterValue)}. Use the format <pre>&lt;owner&gt;/&lt;repo&gt;#&lt;number&gt;</pre>.`
				}]
			};
			return {
				...value,
				valid: true
			};
		});
	}
};
var conditionalProvider = (condition, provider) => condition ? [provider] : [];
var useFilterProviders = (context) => {
	const $ = c(17);
	const { repositoryScope, isIssueFieldsEnabled: t0, isIssueFieldsGlobalSearchEnabled: t1 } = context;
	const isIssueFieldsEnabled = t0 === void 0 ? false : t0;
	const isIssueFieldsGlobalSearchEnabled = t1 === void 0 ? false : t1;
	const { currentUser } = useUser();
	const isRepoScope = !!repositoryScope;
	const isFilterProviderValues = isRepoScope ? IS_FILTER_PROVIDER_VALUES : IS_FILTER_PROVIDER_NON_REPO_SCOPE_VALUES;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[0] = t2;
	} else t2 = $[0];
	const [asyncIssueProviders, setAsyncIssueProviders] = useState(t2);
	const t3 = !!currentUser;
	const t4 = currentUser?.login;
	const t5 = currentUser?.avatarUrl;
	let allProviders;
	if ($[1] !== asyncIssueProviders || $[2] !== isFilterProviderValues || $[3] !== isRepoScope || $[4] !== repositoryScope || $[5] !== t3 || $[6] !== t4 || $[7] !== t5) {
		const userFilterParam = {
			showAtMe: t3,
			currentUserLogin: t4,
			currentUserAvatarUrl: t5,
			repositoryScope
		};
		const noNoneValueFilterConfig = { filterTypes: { valueless: false } };
		const hasValueFilterConfig = { filterTypes: { hasValue: true } };
		allProviders = [
			...conditionalProvider(!isRepoScope, new RepositoryFilterProvider({
				...noNoneValueFilterConfig,
				filterTypes: { multiKey: true }
			})),
			...conditionalProvider(!isRepoScope, new OrgFilterProvider({ ...noNoneValueFilterConfig })),
			new IsFilterProvider(isFilterProviderValues, noNoneValueFilterConfig),
			new StateFilterProvider("mixed", noNoneValueFilterConfig),
			new LabelFilterProvider(hasValueFilterConfig),
			...asyncIssueProviders,
			new ProjectFilterProvider(hasValueFilterConfig),
			new MilestoneFilterProvider(hasValueFilterConfig),
			new AssigneeFilterProvider({
				...userFilterParam,
				showAtCopilot: true
			}, hasValueFilterConfig),
			new AuthorFilterProvider({
				...userFilterParam,
				showAtCopilot: true
			}, noNoneValueFilterConfig),
			new InvolvesFilterProvider({
				...userFilterParam,
				showAtCopilot: true
			}, noNoneValueFilterConfig),
			new MentionsFilterProvider(userFilterParam, noNoneValueFilterConfig),
			new ParentIssueFilterProvider(FILTER_KEYS.parentIssue, hasValueFilterConfig),
			new BlockingSearchFilterProvider(),
			new BlockedBySearchFilterProvider(),
			new SubIssueFilterProvider(),
			new UpdatedFilterProvider(noNoneValueFilterConfig),
			new CreatedFilterProvider(noNoneValueFilterConfig),
			new ClosedFilterProvider(noNoneValueFilterConfig),
			new MergedFilterProvider(noNoneValueFilterConfig),
			new ReviewRequestedFilterProvider({
				...userFilterParam,
				showAtCopilot: true
			}, noNoneValueFilterConfig),
			new InFilterProvider(),
			new CommenterFilterProvider(userFilterParam, noNoneValueFilterConfig),
			new UserFilterProvider(userFilterParam, noNoneValueFilterConfig),
			new UserReviewRequestedFilterProvider(userFilterParam, noNoneValueFilterConfig),
			new ReviewedByFilterProvider({
				...userFilterParam,
				showAtCopilot: true
			}, noNoneValueFilterConfig),
			new CommentsFilterProvider(noNoneValueFilterConfig),
			new InteractionsFilterProvider(noNoneValueFilterConfig),
			new ReasonFilterProvider(noNoneValueFilterConfig),
			new LinkedFilterProvider(["issue", "pr"], noNoneValueFilterConfig),
			new ArchivedFilterProvider(noNoneValueFilterConfig),
			new ReactionsFilterProvider(noNoneValueFilterConfig),
			new DraftFilterProvider(noNoneValueFilterConfig),
			new ReviewFilterProvider(noNoneValueFilterConfig),
			new LanguageFilterProvider(noNoneValueFilterConfig),
			new ShaFilterProvider(noNoneValueFilterConfig),
			new BaseFilterProvider(noNoneValueFilterConfig),
			new HeadFilterProvider(noNoneValueFilterConfig),
			new StatusFilterProvider(noNoneValueFilterConfig),
			new TeamFilterProvider(repositoryScope, noNoneValueFilterConfig),
			new TeamReviewRequestedFilterProvider(repositoryScope, noNoneValueFilterConfig),
			new SortFilterProvider([
				"created",
				"updated",
				"reactions",
				"comments",
				"relevance"
			], noNoneValueFilterConfig)
		];
		for (const provider of allProviders) if (isNestedFilterProvider(provider)) {
			for (const childProvider of provider.filterProviders) if ("priority" in childProvider && childProvider.priority > 5) childProvider.priority = 5;
		} else if ("priority" in provider && provider.priority > 5) provider.priority = 5;
		$[1] = asyncIssueProviders;
		$[2] = isFilterProviderValues;
		$[3] = isRepoScope;
		$[4] = repositoryScope;
		$[5] = t3;
		$[6] = t4;
		$[7] = t5;
		$[8] = allProviders;
	} else allProviders = $[8];
	const providers = allProviders;
	let t6;
	let t7;
	if ($[9] !== isIssueFieldsEnabled || $[10] !== isIssueFieldsGlobalSearchEnabled || $[11] !== repositoryScope) {
		t6 = () => {
			const fetchIssueFieldProvider = async () => {
				let issueFieldProvider;
				if (repositoryScope && isIssueFieldsEnabled) issueFieldProvider = await getIssueFieldFilterProvider({ filterTypes: {
					hasValue: true,
					valueless: true
				} }, repositoryScope);
				else if (isIssueFieldsGlobalSearchEnabled) issueFieldProvider = await getDashboardIssueFieldFilterProvider({ filterTypes: {
					hasValue: true,
					valueless: true
				} });
				if (issueFieldProvider) setAsyncIssueProviders((prev) => {
					return [...prev.filter(_temp2), issueFieldProvider];
				});
			};
			if (repositoryScope && isIssueFieldsEnabled || isIssueFieldsGlobalSearchEnabled) fetchIssueFieldProvider();
		};
		t7 = [
			isIssueFieldsEnabled,
			isIssueFieldsGlobalSearchEnabled,
			repositoryScope
		];
		$[9] = isIssueFieldsEnabled;
		$[10] = isIssueFieldsGlobalSearchEnabled;
		$[11] = repositoryScope;
		$[12] = t6;
		$[13] = t7;
	} else {
		t6 = $[12];
		t7 = $[13];
	}
	useEffect(t6, t7);
	let t8;
	let t9;
	if ($[14] !== providers) {
		t8 = () => () => {
			const typeFilterProvider = providers.find(isIssueTypeFilterProvider);
			if (typeFilterProvider) typeFilterProvider.requestDisposable?.dispose();
		};
		t9 = [providers];
		$[14] = providers;
		$[15] = t8;
		$[16] = t9;
	} else {
		t8 = $[15];
		t9 = $[16];
	}
	useEffect(t8, t9);
	return providers;
};
function _temp(fp) {
	return fp.key?.startsWith("field.");
}
function _temp2(provider_0) {
	return !("key" in provider_0 && provider_0.key === "field" || "filterProviders" in provider_0 && provider_0.filterProviders?.some(_temp));
}
var INBOX_SIDEBAR_LINK_ID = "inbox";
function deriveSidebarLink({ sidebarLinkId, savedViews, sidebarLinks, location }) {
	const { pathname } = location;
	const isOnInbox = isOnInboxPath({ pathname });
	if (sidebarLinkId) {
		const getItem = getItemById(sidebarLinkId, savedViews, sidebarLinks);
		if (getItem) return getItem;
		else {
			const savedViewId = pathname.split("/")[2];
			return savedViews.find((view) => {
				return view.id.toString() === savedViewId;
			});
		}
	}
	if (isOnInbox) return getItemById(INBOX_SIDEBAR_LINK_ID, savedViews, sidebarLinks);
}
function getItemById(id, savedViews, links) {
	if (!id) return void 0;
	const allLinks = [...links, ...savedViews];
	if (id === "inbox") return allLinks.find((link) => link.id === INBOX_SIDEBAR_LINK_ID);
	else return allLinks.find((item) => {
		if (item.path) return item.path === id;
		else return item.id === id;
	});
}
var REPO_FILTER_PREFIX = "repo:";
function uniqueTerms(terms) {
	return Array.from(new Set(terms));
}
function tokenizeQuery(rawQuery) {
	return rawQuery.trim().split(/\s+/).filter(Boolean);
}
function uniqueByName(items) {
	const seen = /* @__PURE__ */ new Set();
	return items.filter((item) => {
		if (seen.has(item.name)) return false;
		seen.add(item.name);
		return true;
	});
}
function includesCaseInsensitive(value, query) {
	return value.toLowerCase().includes(query.trim().toLowerCase());
}
async function fetchFilterSuggestions(endpoint, query) {
	try {
		const searchParams = new URLSearchParams();
		searchParams.set("q", query);
		searchParams.set("filter_value", query);
		const response = await verifiedFetchJSON(`${endpoint}?${searchParams.toString()}`);
		if (!response.ok) return [];
		const json = await response.json();
		const dataKey = Object.keys(json)[0];
		const suggestions = dataKey ? json[dataKey] : null;
		return Array.isArray(suggestions) ? suggestions : [];
	} catch {
		return [];
	}
}
function parseInboxFilterQuery(rawQuery) {
	const repos = [];
	for (const term of tokenizeQuery(rawQuery)) if (term.toLowerCase().startsWith(REPO_FILTER_PREFIX)) {
		const repo = term.slice(5);
		if (repo) repos.push(repo);
		continue;
	}
	return { repos: uniqueTerms(repos) };
}
function buildInboxFilterQuery({ repos }) {
	return [...uniqueTerms(repos).map((repo) => `${REPO_FILTER_PREFIX}${repo}`)].join(" ").trim();
}
function repoOwnerFromTerm(repoNameWithOwner) {
	return repoNameWithOwner.split("/")[0];
}
/**
* Hook to manage the state of the pulls dashboard surface layout, including query state,
* saved views, and sidebar selection. Gets data from context rather than props.
* Provides methods for updating and submitting queries, managing saved views, and selecting sidebar links.
*
* @returns An object containing:
*   - savedViews: Array of saved views
*   - selectedSidebarLink: Currently selected sidebar link
*   - editing: Saved view editing state and methods
*   - deleting: Saved view deletion state and methods
*   - methods: Object with selectSidebarLink, createSavedView, editSavedView, and fetchResults functions
*   - pullsFilterProps: Props for the pulls filter component
*/
function usePullsDashboardSurfaceLayoutState() {
	const { payload, fetchedQuery, fetchResults, locationSidebarLinkId, maxPrAge, setMaxPrAge } = usePullsDashboardSurfaceStateContext();
	const compactMode = payload.compactMode ?? false;
	const sidebarLinks = useMemo(() => payload.sidebarLinks ?? [], [payload.sidebarLinks]);
	const location = useLocation$1();
	const { pathname, search: locationSearch } = location;
	const navigate = useNavigate$1();
	const isInboxEnabled = isFeatureEnabled("pulls_dashboard_inbox");
	const isOnInbox = isOnInboxPath({ pathname });
	const [query, setQuery] = useState(fetchedQuery);
	const [savedViews, setSavedViews] = useState(() => payload.savedViews.map((savedView) => ({
		...savedView,
		searchType: "pull-requests"
	})));
	const [selectedSidebarLink, setSelectedSidebarLink] = useState(() => deriveSidebarLink({
		sidebarLinkId: locationSidebarLinkId,
		savedViews,
		sidebarLinks,
		location
	}));
	useEffect(() => {
		const title = selectedSidebarLink?.name ?? "Pull Requests";
		const timeoutId = setTimeout(() => setTitle(title), 0);
		return () => clearTimeout(timeoutId);
	}, [selectedSidebarLink]);
	useEffect(() => {
		setQuery(fetchedQuery);
		setSelectedSidebarLink(deriveSidebarLink({
			sidebarLinkId: locationSidebarLinkId,
			savedViews,
			sidebarLinks,
			location
		}));
	}, [
		fetchedQuery,
		locationSidebarLinkId,
		pathname
	]);
	const onShortcutDeleted = (deletedShortcut) => {
		setSavedViews(savedViews.filter((shortcut) => shortcut.id !== deletedShortcut.id));
		setSelectedSidebarLink(void 0);
	};
	const deleting = useShortcutDeletion(onShortcutDeleted);
	const onShortcutSaved = (savedShortcut) => {
		setSavedViews(getShortcutsWithSaved(savedViews, savedShortcut));
		if (fetchedQuery !== savedShortcut.query) fetchResults({
			q: savedShortcut.query,
			page: 1,
			sidebarLinkId: savedShortcut.id
		});
		else setSelectedSidebarLink(savedShortcut);
	};
	const editing = useShortcutEditor({
		type: "pull-requests",
		onShortcutSaved
	});
	function updateQuery(q) {
		setQuery(q);
		if (editing.shortcut) editing.setValue("query", q);
	}
	function navigateInboxWithQuery(rawQuery) {
		updateQuery(rawQuery);
		const searchParams = new URLSearchParams();
		if (rawQuery) searchParams.set("q", rawQuery);
		searchParams.set("max_pr_age", maxPrAge);
		const search = searchParams.toString();
		navigate({
			pathname: PULLS_PATH,
			search: search ? `?${search}` : ""
		});
	}
	function handleMaxPrAgeChange(age) {
		setMaxPrAge(age);
		const currentParams = new URLSearchParams(locationSearch);
		currentParams.set("max_pr_age", age);
		navigate({
			pathname: PULLS_PATH,
			search: `?${currentParams.toString()}`
		});
	}
	async function kindlyDismissEditing() {
		if (editing.shortcut) {
			if (!await editing.dismiss()) return false;
		}
		return true;
	}
	async function selectSidebarLink(linkItem) {
		if (!await kindlyDismissEditing()) return;
		deleting.reset();
		fetchResults({
			q: linkItem.query,
			page: 1,
			sidebarLinkId: linkItem.id
		});
	}
	async function createShortcut() {
		if (!await kindlyDismissEditing()) return;
		setSelectedSidebarLink(void 0);
		deleting.reset();
		editing.create(query, selectedSidebarLink);
	}
	function editShortcut(shortcut) {
		deleting.reset();
		editing.edit(shortcut, query);
	}
	function updateShortcut(shortcut) {
		deleting.reset();
		editing.updateQuery(shortcut, fetchedQuery);
	}
	const providers = useOrgAwareProviders({
		baseFilterProviders: useFilterProviders({}),
		effectiveQuery: query,
		isIssueFieldsGlobalSearchEnabled: false
	});
	const routeAwareProviders = isOnInbox ? providers.filter((provider) => "key" in provider && provider.key === "repo") : providers;
	const parsedInboxFilterQuery = useMemo(() => parseInboxFilterQuery(query), [query]);
	const inboxRepoSelection = useMemo(() => parsedInboxFilterQuery.repos.map((name) => ({ name })), [parsedInboxFilterQuery.repos]);
	const inboxRepoLoader = useCallback(async (q, defaultOwner) => {
		const mergedRepos = uniqueByName([...(await fetchFilterSuggestions("/_filter/repositories", q)).map((repo) => ({
			name: repo.nameWithOwner,
			private: repo.visibility !== "public"
		})), ...inboxRepoSelection]);
		const ownerScopedRepos = defaultOwner ? mergedRepos.filter((repo) => repoOwnerFromTerm(repo.name)?.toLowerCase() === defaultOwner.toLowerCase()) : mergedRepos;
		if (!q.trim()) return ownerScopedRepos;
		return ownerScopedRepos.filter((repo) => includesCaseInsensitive(repo.name, q));
	}, [inboxRepoSelection]);
	function applyInboxPickerFilters(nextState) {
		navigateInboxWithQuery(buildInboxFilterQuery(nextState));
	}
	function selectInboxRepos(selectedRepos) {
		applyInboxPickerFilters({ repos: uniqueTerms(selectedRepos?.map((repo) => repo.name) ?? []) });
	}
	return {
		compactMode,
		savedViews,
		selectedSidebarLink,
		sidebarLinks,
		editing,
		deleting,
		methods: {
			selectSidebarLink,
			createShortcut,
			editShortcut,
			updateShortcut,
			fetchResults
		},
		pullsFilterProps: {
			id: "pulls-dashboard-surface-filter",
			label: "Search pull requests",
			variant: "input",
			placeholder: "Search pull requests",
			filterValue: query,
			providers: routeAwareProviders,
			onChange: updateQuery,
			onSubmit: (filterQuery) => {
				if (isOnInbox) {
					navigateInboxWithQuery(filterQuery.raw);
					return;
				}
				fetchResults({
					q: filterQuery.raw,
					page: 1,
					sidebarLinkId: selectedSidebarLink?.id || ""
				});
			},
			settings: { groupAndKeywordSupport: true }
		},
		inboxPickerProps: isInboxEnabled ? {
			repoSelection: inboxRepoSelection,
			repoLoader: inboxRepoLoader,
			selectRepos: selectInboxRepos,
			repoDefaultOwner: inboxRepoSelection[0]?.name,
			handleMaxPrAgeChange
		} : void 0
	};
}
var dashboardTypeLabels = {
	"pull-requests": "pull requests",
	issues: "issues",
	repositories: "repositories"
};
var dashboardTypeLabelSingular = {
	"pull-requests": "pull request",
	issues: "issue",
	repositories: "repository"
};
export { StateType as a, dashboardTypeLabels as c, usePullsDashboardSurfaceStateContext as d, ReviewDecisionState as i, isOnInboxPath as l, PullsDashboardSurfaceStateProvider as n, StatusCheckState as o, PullsInboxMaxAge as r, dashboardTypeLabelSingular as s, PULLS_INBOX_MAX_AGE_LABELS as t, usePullsDashboardSurfaceLayoutState as u };
