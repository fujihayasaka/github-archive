performance.mark("js-parse-end:server-blame-B2ImpwZD-DLDlVl7Y.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { Z as useCurrentBlob, o as CurrentBlameProvider } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { r as useCodeNav } from "./server-CodeNavContext-B-HlTATD-BC-PDvfx.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { t as codeViewBlobLayoutRoute } from "./server-code-view-blob-layout-route-dhoYwhPV-CcMKI0YH.js";
import { t as codeViewBlameRoute } from "./server-code-view-blame-route-CBnG62NQ-C6WKn_o_.js";
import { n as BlobBanners, t as BlameBanners } from "./server-CodeViewBanners-D01K_nCP-X3Rsq57I.js";
import { n as ContributorsProvider, t as BlobViewContent } from "./server-BlobViewContent-DYReMUfE-DA6d3Mwh.js";
import { t as CodeView } from "./server-CodeView-CCvwX-NJ-CNmyXFpi.js";
import { useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:blame-B2ImpwZD.js");
function CodeViewBlameEntrypoint() {
	const $ = c(25);
	const { data: payload } = useRouteQuery(codeViewBlameRoute, "mainQuery");
	const { data: layoutPayload } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { data: blobLayoutPayload } = useRouteQuery(codeViewBlobLayoutRoute, "mainQuery");
	const { data: contributorsData, error: contributorsError, isLoading: contributorsLoading } = useRouteQuery(codeViewBlameRoute, "contributors");
	const { isTreeExpanded, treeToggleElement } = useTreePaneContext();
	const { validCodeNav, setValidCodeNav } = useCodeNav();
	const blob = useCurrentBlob();
	let t0;
	if ($[0] !== blobLayoutPayload || $[1] !== payload) {
		t0 = {
			...blobLayoutPayload,
			...payload
		};
		$[0] = blobLayoutPayload;
		$[1] = payload;
		$[2] = t0;
	} else t0 = $[2];
	const mergedPayload = t0;
	let t1;
	if ($[3] !== blob || $[4] !== blobLayoutPayload || $[5] !== contributorsData || $[6] !== contributorsError || $[7] !== contributorsLoading || $[8] !== isTreeExpanded || $[9] !== layoutPayload || $[10] !== mergedPayload || $[11] !== payload.blame || $[12] !== setValidCodeNav || $[13] !== treeToggleElement || $[14] !== validCodeNav) {
		let t2;
		if ($[16] !== blob || $[17] !== blobLayoutPayload || $[18] !== isTreeExpanded || $[19] !== layoutPayload || $[20] !== payload.blame || $[21] !== setValidCodeNav || $[22] !== treeToggleElement || $[23] !== validCodeNav) {
			t2 = () => jsxs(Fragment$1, { children: [jsxs("div", {
				className: "react-code-view-bottom-padding",
				children: [jsx(BlobBanners, {}), jsx(BlameBanners, {})]
			}), jsx(BlobViewContent, {
				blame: payload.blame,
				blob,
				symbolsExpanded: layoutPayload.symbolsExpanded,
				setValidCodeNav,
				showTree: isTreeExpanded,
				treeToggleElement,
				validCodeNav,
				copilotInfo: blobLayoutPayload.copilotInfo
			})] });
			$[16] = blob;
			$[17] = blobLayoutPayload;
			$[18] = isTreeExpanded;
			$[19] = layoutPayload;
			$[20] = payload.blame;
			$[21] = setValidCodeNav;
			$[22] = treeToggleElement;
			$[23] = validCodeNav;
			$[24] = t2;
		} else t2 = $[24];
		t1 = jsx(CurrentBlameProvider, {
			blame: payload.blame,
			children: jsx(ContributorsProvider, {
				contributors: contributorsData,
				error: contributorsError,
				loading: contributorsLoading,
				children: jsx(CodeView, {
					payload: mergedPayload,
					action: "blame",
					isBlame: true,
					children: t2
				})
			})
		});
		$[3] = blob;
		$[4] = blobLayoutPayload;
		$[5] = contributorsData;
		$[6] = contributorsError;
		$[7] = contributorsLoading;
		$[8] = isTreeExpanded;
		$[9] = layoutPayload;
		$[10] = mergedPayload;
		$[11] = payload.blame;
		$[12] = setValidCodeNav;
		$[13] = treeToggleElement;
		$[14] = validCodeNav;
		$[15] = t1;
	} else t1 = $[15];
	return t1;
}
CodeViewBlameEntrypoint.displayName = "CodeViewBlameEntrypoint";
var SplitComponent = CodeViewBlameEntrypoint;
export { SplitComponent as component };
