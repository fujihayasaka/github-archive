import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { l as ERRORS_BY_STATUS } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { useCallback, useEffect, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
var SpaceDialogFooter_module_default = { footerContainer: "SpaceDialogFooter-module_71PWSq_footerContainer" };
/**
* This component renders a standardized footer with two buttons:
* - A Cancel button that triggers the onCancel callback
* - A Save button that triggers the onSave callback and can show loading/disabled states
*/
function SpaceDialogFooter({ onSave, onCancel, saveButtonText, isLoading = false, loadingAnnouncement = "", disabled = false }) {
	return /* @__PURE__ */ jsxs("div", {
		className: SpaceDialogFooter_module_default.footerContainer,
		children: [/* @__PURE__ */ jsx(ButtonComponent, {
			variant: "default",
			onClick: onCancel,
			children: "Cancel"
		}), /* @__PURE__ */ jsx(ButtonComponent, {
			variant: "primary",
			loading: isLoading,
			loadingAnnouncement,
			onClick: onSave,
			disabled,
			children: saveButtonText
		})]
	});
}
SpaceDialogFooter.displayName = "SpaceDialogFooter";
var urlPathPrefix = "/github-copilot/chat";
var COPILOT_SPACES_QUERY_KEY = ["copilot-chat", "custom-copilots"];
var COPILOT_SPACES_COUNT_QUERY_KEY = [
	"copilot-chat",
	"custom-copilots",
	"count"
];
/**
* Returns a query key for fetching spaces by category type.
* @param type - The category type for filtering spaces
*/
function copilotSpacesCategoryQueryKey(type) {
	return [
		"copilot-chat",
		"custom-copilots",
		type
	];
}
function copilotSpacesQueryKey(id) {
	if (!id) return [
		"copilot-chat",
		"custom-copilot",
		null
	];
	return [
		"copilot-chat",
		"custom-copilot",
		{
			id: id.id,
			owner: id.owner
		}
	];
}
async function fetchCopilotSpace(customCopilotID) {
	if (!customCopilotID || !customCopilotID.owner) return {
		status: 500,
		ok: false,
		error: "unexpected null custom copilot id or missing owner"
	};
	const { owner, id } = customCopilotID;
	const res = await verifiedFetchJSON(`${urlPathPrefix}/custom_copilots/${owner}/${id}`);
	if (!res.ok) return {
		status: res.status,
		ok: false,
		error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
	};
	const payload = await res.json();
	return {
		status: res.status,
		ok: true,
		payload
	};
}
function resourceMetadataToRailsPayload(resource) {
	switch (resource.type) {
		case "repository": return { repository_id: resource.repositoryId };
		case "github_file": return {
			repository_id: resource.repositoryId,
			file_path: resource.filePath,
			sha: resource.sha
		};
		case "free_text": return {
			text: resource.text,
			name: resource.name
		};
		case "github_issue":
		case "github_pull_request": return {
			repository_id: resource.repositoryId,
			number: resource.number
		};
		case "uploaded_text_file": return { name: resource.name };
		case "media_content": return {
			media_type: resource.mediaType,
			name: resource.name,
			url: resource.url,
			height: resource.height,
			width: resource.width
		};
		default: throw new Error(`Unsupported resource`);
	}
}
var SpacesOwnerDropdown_module_default = {
	errorListItem: "SpacesOwnerDropdown-module_rklVDG_errorListItem",
	orgLabel: "SpacesOwnerDropdown-module_rklVDG_orgLabel",
	ownerDropdownOverlay: "SpacesOwnerDropdown-module_rklVDG_ownerDropdownOverlay",
	ownerListGroup: "SpacesOwnerDropdown-module_rklVDG_ownerListGroup",
	ownerListItem: "SpacesOwnerDropdown-module_rklVDG_ownerListItem"
};
function SpacesOwnerDropdown({ onSelect, repoId }) {
	const [ownerItems, setOwnerItems] = useState([]);
	const [displayLoadingError, setDisplayLoadingError] = useState(false);
	const [selectedOwner, setSelectedOwner] = useState(void 0);
	const handleSelectOwner = useCallback((owner) => {
		setSelectedOwner(owner);
		onSelect(owner);
	}, [onSelect]);
	const handleLoadingError = useCallback(() => {
		setOwnerItems([]);
		setDisplayLoadingError(true);
	}, []);
	useEffect(() => {
		const loadOwners = async () => {
			try {
				const result = await verifiedFetchJSON(repoId ? `/github-copilot/chat/custom_copilots_owners?repo_id=${repoId}` : "/github-copilot/chat/custom_copilots_owners");
				const owners = (await result.json())?.owners;
				if (!result.ok || !owners) {
					handleLoadingError();
					return;
				}
				setOwnerItems(owners);
				if (owners[0]) handleSelectOwner(owners[0]);
			} catch {
				handleLoadingError();
			}
		};
		loadOwners();
	}, [
		handleLoadingError,
		handleSelectOwner,
		repoId
	]);
	const getCaption = () => {
		const screenReaderCaption = (owner) => {
			return /* @__PURE__ */ jsxs("span", {
				className: "sr-only",
				children: [
					"Space owner. Required. Selected owner: @",
					owner.displayName,
					"."
				]
			});
		};
		if (!selectedOwner) return /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Space owner. Required."
		}), " Where we will store your space."] });
		else if (selectedOwner.type === "User") return /* @__PURE__ */ jsxs("div", {
			className: "mt-2 d-flex flex-row flex-shrink flex-items-center",
			children: [
				screenReaderCaption(selectedOwner),
				/* @__PURE__ */ jsx(Label, {
					className: "mr-1",
					children: "Private"
				}),
				/* @__PURE__ */ jsx("span", {
					...testIdProps("owner-user-caption"),
					children: "Only you will be able to see this space."
				})
			]
		});
		else return /* @__PURE__ */ jsxs("div", {
			className: "mt-2 d-flex flex-row flex-shrink",
			children: [
				screenReaderCaption(selectedOwner),
				/* @__PURE__ */ jsx(Label, {
					className: SpacesOwnerDropdown_module_default.orgLabel,
					children: "Private"
				}),
				/* @__PURE__ */ jsx("span", {
					...testIdProps("owner-org-caption"),
					children: "Only visible to you and organization admins. You can share it later."
				})
			]
		});
	};
	const headerButton = () => {
		const displayName = selectedOwner?.name || "Choose an owner";
		const buttonAvatar = selectedOwner ? /* @__PURE__ */ jsx(GitHubAvatar, { src: selectedOwner.avatarUrl }, selectedOwner.avatarUrl) : void 0;
		return /* @__PURE__ */ jsx(ActionMenu.Button, {
			"data-testid": "owner-dropdown-anchor",
			alignContent: "start",
			"aria-describedby": "owner-caption",
			leadingVisual: buttonAvatar,
			children: displayName
		});
	};
	return /* @__PURE__ */ jsx("div", {
		className: "mt-2 mb-1",
		children: /* @__PURE__ */ jsxs(FormControl$1, { children: [
			/* @__PURE__ */ jsx(FormControl$1.Label, {
				required: true,
				children: "Owner"
			}),
			/* @__PURE__ */ jsxs(ActionMenu, { children: [headerButton(), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "large",
				maxHeight: "large",
				className: SpacesOwnerDropdown_module_default.ownerDropdownOverlay,
				children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsx(ActionList.Group, {
					className: SpacesOwnerDropdown_module_default.ownerListGroup,
					children: /* @__PURE__ */ jsxs(ActionList, {
						selectionVariant: "single",
						children: [
							ownerItems && ownerItems.map((item) => {
								const { name, avatarUrl, displayName } = item;
								return /* @__PURE__ */ jsxs(ActionList.Item, {
									selected: name === selectedOwner?.name,
									onSelect: () => handleSelectOwner(item),
									className: SpacesOwnerDropdown_module_default.ownerListItem,
									children: [
										/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, { src: avatarUrl }) }),
										name,
										/* @__PURE__ */ jsx(ActionList.Description, { children: displayName })
									]
								}, name);
							}),
							!ownerItems.length && !displayLoadingError && /* @__PURE__ */ jsx(ActionList.Item, {
								disabled: true,
								children: "Fetching owners…"
							}, "fetching-owners"),
							displayLoadingError && /* @__PURE__ */ jsx(ActionList.Item, {
								disabled: true,
								className: SpacesOwnerDropdown_module_default.errorListItem,
								children: "An error occurred while loading owners. Please reopen the dialog to try again."
							}, "error-fetching-owners")
						]
					})
				}) })
			})] }),
			/* @__PURE__ */ jsx(FormControl$1.Caption, {
				id: "owner-caption",
				children: getCaption()
			})
		] })
	});
}
SpacesOwnerDropdown.displayName = "SpacesOwnerDropdown";
export { copilotSpacesCategoryQueryKey as a, resourceMetadataToRailsPayload as c, SpacesOwnerDropdown as i, COPILOT_SPACES_QUERY_KEY as n, copilotSpacesQueryKey as o, SpaceDialogFooter as r, fetchCopilotSpace as s, COPILOT_SPACES_COUNT_QUERY_KEY as t };
