import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { announce, announceFromElement } from "@primer/live-region-element";
/**
* Troubleshooting guide for aria-live regions available on the Hub
* - https://thehub.github.com/epd/engineering/dev-practicals/frontend/accessibility/readiness-routine/screenreaders/live-regions-and-focus-management-techniques/#why-isnt-my-live-region-working-as-i-expect
*/
function announceFromElement$1(el, options) {
	if (isFeatureEnabled("arianotify_comprehensive_migration")) announce$1(getTextContent(el), {
		...options,
		element: options?.element ?? el
	});
	else if (isFeatureEnabled("primer_live_region_element") && options?.element === void 0) announceFromElement(el, { politeness: options?.assertive ? "assertive" : "polite" });
	else announce$1(getTextContent(el), options);
}
function announce$1(message, options) {
	const { assertive, element } = options ?? {};
	if (isFeatureEnabled("arianotify_comprehensive_migration")) try {
		const priority = assertive ? "high" : "normal";
		(element?.isConnected ? element : ssrSafeDocument).ariaNotify(message, { priority });
	} catch (error) {
		console.error("Error calling ariaNotify:", error);
	}
	else if (isFeatureEnabled("primer_live_region_element") && element === void 0) announce(message, { politeness: assertive ? "assertive" : "polite" });
	else setContainerContent(message, assertive, element);
}
function setContainerContent(message, assertive, element) {
	const getQuerySelector = () => {
		return assertive ? "#js-global-screen-reader-notice-assertive" : "#js-global-screen-reader-notice";
	};
	const container = element ?? ssrSafeDocument?.querySelector(getQuerySelector());
	if (!container) return;
	if (container.textContent === message) container.textContent = `${message}\u00A0`;
	else container.textContent = message;
}
function getTextContent(el) {
	return (el.getAttribute("aria-label") || el.innerText || "").trim();
}
export { announceFromElement$1 as n, announce$1 as t };
