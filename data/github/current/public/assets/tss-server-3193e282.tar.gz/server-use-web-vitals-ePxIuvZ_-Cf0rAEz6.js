import { useEffect } from "react";
import { c } from "react/compiler-runtime";
function useWebVitals(name, callback) {
	const $ = c(3);
	let t0;
	if ($[0] !== callback || $[1] !== name) {
		t0 = () => {
			const eventName = `web-vitals:${name}`;
			const eventListener = callback;
			document.addEventListener(eventName, eventListener);
			return () => {
				document.removeEventListener(eventName, eventListener);
			};
		};
		$[0] = callback;
		$[1] = name;
		$[2] = t0;
	} else t0 = $[2];
	useEffect(t0);
}
export { useWebVitals as t };
