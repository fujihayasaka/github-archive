performance.mark("js-parse-end:server-tree-delete-CXmAfLPs-CdwfaJTq.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:tree-delete-CXmAfLPs.js");
var codeViewTreeDeleteServerFn_createServerFn_handler = createServerRpc({
	id: "49ebf714316715b57e796c434675bccb1d1f4fe6328a00e55a409ab6fe3d1933",
	name: "codeViewTreeDeleteServerFn",
	filename: "src/routes/code-view/tree-delete.tsx"
}, (opts) => codeViewTreeDeleteServerFn.__executeServer(opts));
var codeViewTreeDeleteServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewTreeDeleteServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewTreeDeleteRoute");
});
export { codeViewTreeDeleteServerFn_createServerFn_handler };
