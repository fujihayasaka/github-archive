import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import React, { createContext, use, useCallback, useEffect, useMemo, useRef } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var NavigableRefContext = createContext({
	registerNavigableRef: () => {},
	unregisterNavigableRef: () => {}
});
NavigableRefContext.displayName = "NavigableRefContext";
function NavigableRefProvider(t0) {
	const $ = c(9);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [navigableRefs, setNavigableRefs] = React.useState(t1);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (ref) => {
			setNavigableRefs((prevNavigableRefs) => prevNavigableRefs.some((r) => r === ref) ? prevNavigableRefs : [...prevNavigableRefs, ref]);
		};
		$[1] = t2;
	} else t2 = $[1];
	const registerNavigableRef = t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (ref_0) => {
			setNavigableRefs((prevNavigableRefs_0) => prevNavigableRefs_0.filter((r_0) => r_0 !== ref_0));
		};
		$[2] = t3;
	} else t3 = $[2];
	const unregisterNavigableRef = t3;
	let t4;
	let t5;
	if ($[3] !== navigableRefs) {
		t4 = () => {
			const handleKeyDown = (event) => {
				if (event.altKey && event.key === "F6") {
					event.preventDefault();
					const navigableRefsInDOMOrder = navigableRefs.filter(_temp).sort(_temp2);
					if (navigableRefsInDOMOrder.length === 0) return;
					const activeRefIndex = navigableRefsInDOMOrder.findIndex(_temp3);
					const refToFocus = (!event.shiftKey ? navigableRefsInDOMOrder[activeRefIndex + 1] ?? navigableRefsInDOMOrder[0] : navigableRefsInDOMOrder[activeRefIndex - 1] ?? navigableRefsInDOMOrder[navigableRefsInDOMOrder.length - 1])?.current;
					if (!refToFocus) return;
					if (![
						"A",
						"BUTTON",
						"INPUT",
						"SELECT",
						"TEXTAREA"
					].includes(refToFocus.tagName) && !refToFocus.hasAttribute("tabindex")) {
						refToFocus.setAttribute("tabindex", "-1");
						const handleBlur = () => {
							refToFocus.removeAttribute("tabindex");
							refToFocus.removeEventListener("blur", handleBlur);
						};
						refToFocus.addEventListener("blur", handleBlur, { once: true });
					}
					refToFocus.focus();
				}
			};
			ssrSafeDocument?.addEventListener("keydown", handleKeyDown);
			return () => {
				ssrSafeDocument?.removeEventListener("keydown", handleKeyDown);
			};
		};
		t5 = [navigableRefs];
		$[3] = navigableRefs;
		$[4] = t4;
		$[5] = t5;
	} else {
		t4 = $[4];
		t5 = $[5];
	}
	useEffect(t4, t5);
	let t6;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = {
			registerNavigableRef,
			unregisterNavigableRef
		};
		$[6] = t6;
	} else t6 = $[6];
	const navigableRefProviderValue = t6;
	let t7;
	if ($[7] !== children) {
		t7 = jsx(NavigableRefContext, {
			value: navigableRefProviderValue,
			children
		});
		$[7] = children;
		$[8] = t7;
	} else t7 = $[8];
	return t7;
}
NavigableRefProvider.displayName = "NavigableRefProvider";
function _temp3(r_1) {
	return r_1.current?.contains(ssrSafeDocument?.activeElement || null);
}
function _temp2(a, b) {
	const aNode = a.current;
	const bNode = b.current;
	if (aNode === bNode) return 0;
	if (aNode.compareDocumentPosition(bNode) & Node.DOCUMENT_POSITION_PRECEDING) return 1;
	return -1;
}
function _temp(ref_1) {
	return ref_1.current !== null;
}
function useNavigableRef() {
	const $ = c(4);
	const ref = useRef(null);
	const { registerNavigableRef, unregisterNavigableRef } = use(NavigableRefContext);
	let t0;
	let t1;
	if ($[0] !== registerNavigableRef || $[1] !== unregisterNavigableRef) {
		t0 = () => {
			registerNavigableRef(ref);
			return () => {
				unregisterNavigableRef(ref);
			};
		};
		t1 = [registerNavigableRef, unregisterNavigableRef];
		$[0] = registerNavigableRef;
		$[1] = unregisterNavigableRef;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	return ref;
}
export { useNavigableRef as n, NavigableRefProvider as t };
