import { jsx, jsxs } from "react/jsx-runtime";
var NodeIcon = ({ size = 16, className } = {}) => {
	if (size === 24) return /* @__PURE__ */ jsxs("svg", {
		className,
		width: size,
		height: size,
		style: {
			display: "inline-block",
			verticalAlign: "text-bottom"
		},
		viewBox: "0 0 16 16",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ jsx("path", {
				d: "M11.1997 3.60004H12.4797C13.5401 3.60004 14.3997 4.45965 14.3997 5.52004V10.64C14.3997 11.7005 13.5401 12.56 12.4797 12.56H11.1997",
				stroke: "currentColor",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M4.79985 12.56H3.51985C2.45947 12.56 1.59985 11.7005 1.59985 10.64V5.52004C1.59985 4.45965 2.45947 3.60004 3.51985 3.60004H4.79985",
				stroke: "currentColor",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M8.00015 5.2C8.8838 5.2 9.60015 4.48366 9.60015 3.6C9.60015 2.71634 8.8838 2 8.00015 2C7.11649 2 6.40015 2.71634 6.40015 3.6C6.40015 4.48366 7.11649 5.2 8.00015 5.2Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M8.00015 14.16C8.8838 14.16 9.60015 13.4437 9.60015 12.56C9.60015 11.6764 8.8838 10.96 8.00015 10.96C7.11649 10.96 6.40015 11.6764 6.40015 12.56C6.40015 13.4437 7.11649 14.16 8.00015 14.16Z",
				fill: "currentColor"
			})
		]
	});
	return /* @__PURE__ */ jsxs("svg", {
		className,
		width: size,
		height: size,
		style: {
			display: "inline-block",
			verticalAlign: "text-bottom"
		},
		viewBox: "0 0 16 16",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M0.5 6V10.5C0.5 11.8807 1.61929 13 3 13H4.64494C4.55064 12.6831 4.5 12.3475 4.5 12C4.5 11.8302 4.51209 11.6633 4.53544 11.5H3C2.44772 11.5 2 11.0523 2 10.5L2 6H0.5ZM14 6L14 10.5C14 11.0523 13.5523 11.5 13 11.5H11.4646C11.4879 11.6633 11.5 11.8302 11.5 12C11.5 12.3475 11.4494 12.6831 11.3551 13H13C14.3807 13 15.5 11.8807 15.5 10.5L15.5 6H14ZM10 12C10 13.1046 9.10457 14 8 14C6.89543 14 6 13.1046 6 12C6 10.8954 6.89543 10 8 10C9.10457 10 10 10.8954 10 12Z",
			fill: "currentColor"
		}), /* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M15.5 10L15.5 5.5C15.5 4.11929 14.3807 3 13 3L11.3551 3C11.4494 3.31685 11.5 3.65251 11.5 4C11.5 4.16976 11.4879 4.3367 11.4646 4.5L13 4.5C13.5523 4.5 14 4.94772 14 5.5L14 10L15.5 10ZM2 10L2 5.5C2 4.94771 2.44772 4.5 3 4.5L4.53544 4.5C4.51209 4.3367 4.5 4.16976 4.5 4C4.5 3.65251 4.55064 3.31685 4.64494 3L3 3C1.61929 3 0.500002 4.11929 0.500002 5.5L0.500001 10L2 10ZM6 4C6 2.89543 6.89543 2 8 2C9.10457 2 10 2.89543 10 4C10 5.10457 9.10457 6 8 6C6.89543 6 6 5.10457 6 4Z",
			fill: "currentColor"
		})]
	});
};
NodeIcon.displayName = "NodeIcon";
var ComposeIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsx("svg", {
	className,
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	xmlns: "http://www.w3.org/2000/svg",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: /* @__PURE__ */ jsx("path", {
		fill: "currentColor",
		fillRule: "evenodd",
		d: "M14.515.456a1.555 1.555 0 00-2.2 0L6.58 6.19a1.556 1.556 0 00-.396.673l-.825 2.89a.667.667 0 00.824.824l2.89-.826c.254-.072.485-.209.672-.396l5.735-5.734a1.556 1.556 0 000-2.2l-.965-.965zm-1.257.942a.222.222 0 01.314 0l.965.966a.222.222 0 010 .314L13.415 3.8l-1.28-1.28 1.123-1.122zm-2.065 2.066l1.279 1.279-3.67 3.67a.221.221 0 01-.096.056l-1.736.496.496-1.736c.01-.036.03-.07.057-.096l3.67-3.67zM1.639 4.778a2.25 2.25 0 012.25-2.25h3.154a.75.75 0 000-1.5H3.889a3.75 3.75 0 00-3.75 3.75v7.333a3.75 3.75 0 003.75 3.75h7.333a3.75 3.75 0 003.75-3.75V8.445a.75.75 0 00-1.5 0v3.666a2.25 2.25 0 01-2.25 2.25H3.889a2.25 2.25 0 01-2.25-2.25V4.778z",
		clipRule: "evenodd"
	})
});
ComposeIcon.displayName = "ComposeIcon";
var DiceIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsx("svg", {
	className,
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	xmlns: "http://www.w3.org/2000/svg",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: /* @__PURE__ */ jsx("path", {
		fill: "currentColor",
		fillRule: "evenodd",
		d: "M13 .5H3A2.5 2.5 0 0 0 .5 3v10A2.5 2.5 0 0 0 3 15.5h10a2.5 2.5 0 0 0 2.5-2.5V3A2.5 2.5 0 0 0 13 .5M2 3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1zm6 6.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5M12.25 5a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0M5 12.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5",
		clipRule: "evenodd"
	})
});
DiceIcon.displayName = "DiceIcon";
var SpacesIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	xmlns: "http://www.w3.org/2000/svg",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsx("path", {
		d: "M7.41299 14.25H1.75C1.19772 14.25 0.75 13.8023 0.75 13.25V2.75C0.75 2.19772 1.19772 1.75 1.75 1.75H5C5.31476 1.75 5.61115 1.89819 5.8 2.15L6.7 3.35C6.88885 3.60181 7.18524 3.75 7.5 3.75H14.25C14.8023 3.75 15.25 4.19772 15.25 4.75V8.48779",
		stroke: "currentColor",
		strokeWidth: "1.5",
		strokeLinecap: "round"
	}), /* @__PURE__ */ jsx("path", {
		d: "M12.265 9.15977C12.3446 8.94235 12.6521 8.94235 12.7317 9.15977L12.9693 9.80865C13.3464 10.8387 14.158 11.6503 15.1881 12.0274L15.8369 12.265C16.0544 12.3446 16.0544 12.6521 15.8369 12.7317L15.1881 12.9692C14.158 13.3463 13.3464 14.158 12.9693 15.188L12.7317 15.8369C12.6521 16.0543 12.3446 16.0543 12.265 15.8369L12.0275 15.188C11.6504 14.158 10.8387 13.3463 9.80871 12.9692L9.15983 12.7317C8.94241 12.6521 8.94241 12.3446 9.15983 12.265L9.80871 12.0274C10.8387 11.6503 11.6504 10.8387 12.0275 9.80865L12.265 9.15977Z",
		fill: "currentColor"
	})]
});
SpacesIcon.displayName = "SpacesIcon";
var LoopsIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	xmlns: "http://www.w3.org/2000/svg",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsx("path", {
		d: "M16.0376 9.67565V5.82038C16.0376 5.69043 15.9257 5.58508 15.7876 5.58508H11.6914C11.4687 5.58508 11.3571 5.83853 11.5146 5.98676L15.6108 9.84196C15.7683 9.99019 16.0376 9.88525 16.0376 9.67565Z",
		fill: "currentColor"
	}), /* @__PURE__ */ jsx("path", {
		d: "M1.89601 3.25629C4.26064 1.03075 8.04807 0.960969 10.5015 3.04765L10.7339 3.25629L10.7857 3.3096C11.0259 3.58685 11.0085 3.99602 10.7339 4.25445C10.4593 4.51252 10.0254 4.52825 9.73097 4.30225L9.67336 4.25445L9.4966 4.09544C7.63201 2.50983 4.75358 2.56313 2.95656 4.25445C1.10158 6.00031 1.10158 8.83023 2.95656 10.5761C4.81155 12.322 7.8184 12.3219 9.67336 10.5761L13.563 6.91622C13.8559 6.64063 14.3307 6.64058 14.6236 6.91622C14.9163 7.19186 14.9163 7.63873 14.6236 7.91438L10.7339 11.5752C8.29328 13.8718 4.33667 13.8718 1.89601 11.5752C-0.544758 9.27799 -0.544771 5.55349 1.89601 3.25629Z",
		fill: "currentColor"
	})]
});
LoopsIcon.displayName = "LoopsIcon";
var BooleanOnIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsxs("g", {
		clipPath: "url(#boolean-on-a)",
		children: [/* @__PURE__ */ jsx("rect", {
			x: "1.25",
			y: "1.25",
			width: "13.5",
			height: "13.5",
			rx: "1.75",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ jsx("rect", {
			x: "7",
			y: "5",
			width: "2",
			height: "6",
			rx: "1",
			fill: "currentColor"
		})]
	}), /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("clipPath", {
		id: "boolean-on-a",
		children: /* @__PURE__ */ jsx("rect", {
			width: "16",
			height: "16",
			fill: "white"
		})
	}) })]
});
BooleanOnIcon.displayName = "BooleanOnIcon";
var BooleanOffIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsxs("g", {
		clipPath: "url(#boolean-off-a)",
		children: [/* @__PURE__ */ jsx("rect", {
			x: "1.25",
			y: "1.25",
			width: "13.5",
			height: "13.5",
			rx: "1.75",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ jsx("circle", {
			cx: "8",
			cy: "8",
			r: "2.25",
			stroke: "currentColor",
			strokeWidth: "1.5"
		})]
	}), /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("clipPath", {
		id: "boolean-off-a",
		children: /* @__PURE__ */ jsx("rect", {
			width: "16",
			height: "16",
			fill: "white"
		})
	}) })]
});
BooleanOffIcon.displayName = "BooleanOffIcon";
var InputIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [
		/* @__PURE__ */ jsx("rect", {
			x: "1.25",
			y: "3.25",
			width: "13.5",
			height: "9.5",
			rx: "1.75",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M6 6L6 10",
			stroke: "currentColor",
			strokeWidth: "1.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M4 6H8",
			stroke: "currentColor",
			strokeWidth: "1.5",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M9 10L12 10",
			stroke: "currentColor",
			strokeWidth: "1.5",
			strokeLinecap: "round"
		})
	]
});
InputIcon.displayName = "InputIcon";
var RangeIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M13 11.25L12.25 11.25L12.25 12.75L13 12.75L13 12L13 11.25ZM14 12.75C14.4142 12.75 14.75 12.4142 14.75 12C14.75 11.5858 14.4142 11.25 14 11.25L14 12L14 12.75ZM13 12L13 12.75L14 12.75L14 12L14 11.25L13 11.25L13 12Z",
			fill: "currentColor"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M2 11.25C1.58579 11.25 1.25 11.5858 1.25 12C1.25 12.4142 1.58579 12.75 2 12.75L2 12L2 11.25ZM7 12.75L7.75 12.75L7.75 11.25L7 11.25L7 12L7 12.75ZM2 12L2 12.75L7 12.75L7 12L7 11.25L2 11.25L2 12Z",
			fill: "currentColor"
		}),
		/* @__PURE__ */ jsx("circle", {
			cx: "10",
			cy: "12",
			r: "2.25",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M2 3.25C1.58579 3.25 1.25 3.58579 1.25 4C1.25 4.41421 1.58579 4.75 2 4.75L2 4L2 3.25ZM3 4.75L3.75 4.75L3.75 3.25L3 3.25L3 4L3 4.75ZM2 4L2 4.75L3 4.75L3 4L3 3.25L2 3.25L2 4Z",
			fill: "currentColor"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M9 3.25L8.25 3.25L8.25 4.75L9 4.75L9 4L9 3.25ZM14 4.75C14.4142 4.75 14.75 4.41421 14.75 4C14.75 3.58579 14.4142 3.25 14 3.25L14 4L14 4.75ZM9 4L9 4.75L14 4.75L14 4L14 3.25L9 3.25L9 4Z",
			fill: "currentColor"
		}),
		/* @__PURE__ */ jsx("circle", {
			cx: "6",
			cy: "4",
			r: "2.25",
			stroke: "currentColor",
			strokeWidth: "1.5"
		})
	]
});
RangeIcon.displayName = "RangeIcon";
var SelectIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsx("rect", {
		x: "1.25",
		y: "3.25",
		width: "13.5",
		height: "9.5",
		rx: "1.75",
		stroke: "currentColor",
		strokeWidth: "1.5"
	}), /* @__PURE__ */ jsx("path", {
		d: "M9.81055 7.75L11.1895 7.75L10.5 8.43945L9.81055 7.75Z",
		stroke: "currentColor",
		strokeWidth: "1.5",
		strokeLinecap: "round"
	})]
});
SelectIcon.displayName = "SelectIcon";
var GitBranchCheckIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsx("path", {
		d: "M15.2596 9.99995C15.4583 10.0025 15.6481 10.0834 15.787 10.2255C15.9258 10.3678 16.0022 10.5599 15.9999 10.7587C15.9974 10.9577 15.9166 11.1481 15.7743 11.2871L11.2167 15.7363C11.0753 15.8738 10.8855 15.9505 10.6883 15.9492C10.4909 15.9477 10.3013 15.8683 10.162 15.7285L8.21861 13.7783C8.08642 13.6359 8.01462 13.4472 8.01841 13.2529C8.02225 13.0587 8.10151 12.8734 8.23911 12.7363C8.37676 12.5992 8.56243 12.5206 8.75669 12.5175C8.95096 12.5145 9.1392 12.587 9.28111 12.7197L10.7001 14.1455L14.7264 10.2128C14.8688 10.074 15.0608 9.99751 15.2596 9.99995Z",
		fill: "currentColor"
	}), /* @__PURE__ */ jsx("path", {
		d: "M11.75 1C12.9926 1 14 2.00736 14 3.25C14 4.22966 13.3739 5.06319 12.5 5.37207V6C12.5 7.38071 11.3807 8.5 10 8.5H6C5.44772 8.5 5 8.94772 5 9.5V10.6279C5.87389 10.9368 6.5 11.7703 6.5 12.75C6.5 13.9926 5.49264 15 4.25 15C3.00736 15 2 13.9926 2 12.75C2 11.7703 2.62611 10.9368 3.5 10.6279V5.37207C2.62611 5.06319 2 4.22966 2 3.25C2 2.00736 3.00736 1 4.25 1C5.49264 1 6.5 2.00736 6.5 3.25C6.5 4.22966 5.87389 5.06319 5 5.37207V7.20801C5.30623 7.07421 5.64445 7 6 7H10C10.5523 7 11 6.55228 11 6V5.37207C10.1261 5.06319 9.5 4.22966 9.5 3.25C9.5 2.00736 10.5074 1 11.75 1ZM4.25 12C3.83579 12 3.5 12.3358 3.5 12.75C3.5 13.1642 3.83579 13.5 4.25 13.5C4.66421 13.5 5 13.1642 5 12.75C5 12.3358 4.66421 12 4.25 12ZM4.25 2.5C3.83579 2.5 3.5 2.83579 3.5 3.25C3.5 3.66421 3.83579 4 4.25 4C4.66421 4 5 3.66421 5 3.25C5 2.83579 4.66421 2.5 4.25 2.5ZM11.75 2.5C11.3358 2.5 11 2.83579 11 3.25C11 3.66421 11.3358 4 11.75 4C12.1642 4 12.5 3.66421 12.5 3.25C12.5 2.83579 12.1642 2.5 11.75 2.5Z",
		fill: "currentColor"
	})]
});
GitBranchCheckIcon.displayName = "GitBranchCheckIcon";
var FileCheckIcon = ({ size = 16, className } = {}) => /* @__PURE__ */ jsxs("svg", {
	className,
	xmlns: "http://www.w3.org/2000/svg",
	width: size,
	height: size,
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	style: {
		display: "inline-block",
		verticalAlign: "text-bottom"
	},
	children: [/* @__PURE__ */ jsx("path", {
		d: "M10.3359 0C10.7999 0 11.2452 0.183715 11.5732 0.512695L14.4873 3.42676C14.8163 3.75475 15 4.20008 15 4.66406V8.25098C15 8.66519 14.6642 9.00098 14.25 9.00098C13.8358 9.00098 13.5 8.66519 13.5 8.25098V6H10.75C10.2859 6 9.84088 5.81549 9.5127 5.4873C9.18451 5.15912 9 4.71413 9 4.25V1.5H3.75C3.6837 1.5 3.62013 1.52636 3.57324 1.57324C3.52636 1.62013 3.5 1.6837 3.5 1.75V14.25C3.5 14.388 3.612 14.5 3.75 14.5H7C7.41421 14.5 7.75 14.8358 7.75 15.25C7.75 15.6642 7.41421 16 7 16H3.75C3.28587 16 2.84088 15.8155 2.5127 15.4873C2.18451 15.1591 2 14.7141 2 14.25V1.75C2 0.784 2.784 0 3.75 0H10.3359ZM10.5 4.25C10.5 4.388 10.612 4.5 10.75 4.5H13.4385L13.4268 4.4873L10.5127 1.57324L10.5 1.56152V4.25Z",
		fill: "currentColor"
	}), /* @__PURE__ */ jsx("path", {
		d: "M15.2588 10C15.4577 10.0024 15.6481 10.0833 15.7871 10.2256C15.926 10.3679 16.0023 10.56 16 10.7588C15.9976 10.9577 15.9167 11.1481 15.7744 11.2871L11.2168 15.7363C11.0754 15.874 10.8849 15.9507 10.6875 15.9492C10.4901 15.9476 10.3014 15.8675 10.1621 15.7275L8.21875 13.7783C8.08653 13.6359 8.01476 13.4472 8.01855 13.2529C8.02239 13.0587 8.10162 12.8734 8.23926 12.7363C8.37693 12.5992 8.56253 12.5206 8.75684 12.5176C8.95115 12.5145 9.13933 12.587 9.28125 12.7197L10.7002 14.1445L14.7256 10.2129C14.8679 10.074 15.06 9.99767 15.2588 10Z",
		fill: "currentColor"
	})]
});
FileCheckIcon.displayName = "FileCheckIcon";
var iconMapping = {
	compose: ComposeIcon,
	dice: DiceIcon,
	loops: LoopsIcon,
	node: NodeIcon,
	spaces: SpacesIcon,
	booleanOn: BooleanOnIcon,
	booleanOff: BooleanOffIcon,
	input: InputIcon,
	range: RangeIcon,
	select: SelectIcon,
	gitBranchCheck: GitBranchCheckIcon,
	fileCheck: FileCheckIcon
};
export { SpacesIcon as n, iconMapping as r, LoopsIcon as t };
