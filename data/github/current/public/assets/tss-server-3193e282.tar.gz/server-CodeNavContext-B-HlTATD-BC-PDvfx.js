import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { createContext, use, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var UPDATE_EXPAND_PREFERENCES_URL = "/repos/preferences";
async function updateExpandPreferences(treeValue, symbolsValue, lineWrapValue) {
	if (!isLoggedIn()) return;
	const formData = new FormData();
	formData.set("tree_view_expanded_preference", treeValue === null ? "" : treeValue ? "true" : "false");
	formData.set("symbols_view_expanded_preference", symbolsValue === null ? "" : symbolsValue ? "true" : "false");
	formData.set("code_line_wrap_enabled", lineWrapValue === null ? "" : lineWrapValue ? "true" : "false");
	verifiedFetch(UPDATE_EXPAND_PREFERENCES_URL, {
		method: "PUT",
		body: formData,
		headers: { Accept: "application/json" }
	});
}
var CodeNavContext = createContext(null);
CodeNavContext.displayName = "CodeNavContext";
function CodeNavProvider(t0) {
	const $ = c(5);
	const { children } = t0;
	const [validCodeNav, setValidCodeNav] = useState(true);
	let t1;
	if ($[0] !== validCodeNav) {
		t1 = {
			validCodeNav,
			setValidCodeNav
		};
		$[0] = validCodeNav;
		$[1] = t1;
	} else t1 = $[1];
	const value = t1;
	let t2;
	if ($[2] !== children || $[3] !== value) {
		t2 = jsx(CodeNavContext, {
			value,
			children
		});
		$[2] = children;
		$[3] = value;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
CodeNavProvider.displayName = "CodeNavProvider";
function useCodeNav() {
	const context = use(CodeNavContext);
	if (!context) throw new Error("useCodeNav must be used within a CodeNavProvider");
	return context;
}
export { updateExpandPreferences as n, useCodeNav as r, CodeNavProvider as t };
