import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { O as CheckIcon, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var request = async (url, method, formData) => {
	try {
		return (await verifiedFetch(url, {
			method,
			body: formData
		})).ok;
	} catch {
		return false;
	}
};
var deleteRequest = (url, feature) => {
	return request(url, "DELETE", formData(feature));
};
var createRequest = (url, feature) => {
	return request(url, "POST", formData(feature));
};
var formData = (feature) => {
	const data = new FormData();
	data.append("feature", feature);
	return data;
};
function useFeatureRequest(featureRequestInfo) {
	const $ = c(13);
	let t0;
	if ($[0] !== featureRequestInfo) {
		t0 = featureRequestInfo ?? {};
		$[0] = featureRequestInfo;
		$[1] = t0;
	} else t0 = $[1];
	const { alreadyRequested: t1, dismissed: t2, dismissedAt: t3, featureName: t4, requestPath: t5 } = t0;
	const alreadyRequested = t1 === void 0 ? false : t1;
	const dismissed = t2 === void 0 ? false : t2;
	const dismissedAt = t3 === void 0 ? "" : t3;
	const featureName = t4 === void 0 ? "" : t4;
	const requestPath = t5 === void 0 ? "" : t5;
	const [inProgress, setInProgress] = useState(false);
	const [requested, setRequested] = useState(alreadyRequested);
	const { addToast } = useToastContext();
	let t6;
	if ($[2] !== addToast || $[3] !== featureName || $[4] !== requestPath || $[5] !== requested) {
		t6 = async () => {
			setInProgress(true);
			if (await (requested ? deleteRequest : createRequest)(requestPath, featureName)) setRequested(!requested);
			else addToast({
				type: "error",
				message: "Something went wrong. Please try again later."
			});
			setInProgress(false);
		};
		$[2] = addToast;
		$[3] = featureName;
		$[4] = requestPath;
		$[5] = requested;
		$[6] = t6;
	} else t6 = $[6];
	const toggleFeatureRequest = t6;
	let t7;
	if ($[7] !== dismissed || $[8] !== dismissedAt || $[9] !== inProgress || $[10] !== requested || $[11] !== toggleFeatureRequest) {
		t7 = {
			inProgress,
			requested,
			dismissed,
			dismissedAt,
			toggleFeatureRequest
		};
		$[7] = dismissed;
		$[8] = dismissedAt;
		$[9] = inProgress;
		$[10] = requested;
		$[11] = toggleFeatureRequest;
		$[12] = t7;
	} else t7 = $[12];
	return t7;
}
function FeatureRequest(t0) {
	const $ = c(10);
	const { featureRequestInfo, learnMorePath, requestMessage, requestedMessage } = t0;
	const { inProgress, requested, toggleFeatureRequest } = useFeatureRequest(featureRequestInfo);
	if (!featureRequestInfo.showFeatureRequest) return null;
	let t1;
	if ($[0] !== featureRequestInfo.billingEntityId || $[1] !== featureRequestInfo.featureName || $[2] !== featureRequestInfo.isEnterpriseRequest || $[3] !== inProgress || $[4] !== learnMorePath || $[5] !== requestMessage || $[6] !== requested || $[7] !== requestedMessage || $[8] !== toggleFeatureRequest) {
		t1 = requested ? jsx(CancelFeatureRequest, {
			inProgress,
			toggleFeatureRequest,
			requestedMessage
		}) : jsx(RequestFeature, {
			inProgress,
			toggleFeatureRequest,
			isEnterpriseRequest: featureRequestInfo.isEnterpriseRequest,
			featureName: featureRequestInfo.featureName,
			billingEntityId: featureRequestInfo.billingEntityId,
			learnMorePath,
			requestMessage
		});
		$[0] = featureRequestInfo.billingEntityId;
		$[1] = featureRequestInfo.featureName;
		$[2] = featureRequestInfo.isEnterpriseRequest;
		$[3] = inProgress;
		$[4] = learnMorePath;
		$[5] = requestMessage;
		$[6] = requested;
		$[7] = requestedMessage;
		$[8] = toggleFeatureRequest;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
FeatureRequest.displayName = "FeatureRequest";
var RequestFeature = (t0) => {
	const $ = c(16);
	const { inProgress, toggleFeatureRequest: submit, billingEntityId: t1, isEnterpriseRequest: t2, featureName, learnMorePath, requestMessage } = t0;
	const billingEntityId = t1 === void 0 ? "" : t1;
	const isEnterpriseRequest = t2 === void 0 ? false : t2;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t3;
	if ($[0] !== billingEntityId || $[1] !== featureName || $[2] !== isEnterpriseRequest || $[3] !== sendClickAnalyticsEvent || $[4] !== submit) {
		t3 = () => {
			submit();
			const cta_analytics_label = isEnterpriseRequest && billingEntityId ? `ref_cta:ask_enterprise_owners_for_access;ref_loc:${featureName};enterprise_id:${billingEntityId};` : `ref_cta:ask_admin_for_access;ref_loc:${featureName};`;
			sendClickAnalyticsEvent({
				category: "member_feature_request",
				action: `action.${featureName}`,
				label: cta_analytics_label
			});
		};
		$[0] = billingEntityId;
		$[1] = featureName;
		$[2] = isEnterpriseRequest;
		$[3] = sendClickAnalyticsEvent;
		$[4] = submit;
		$[5] = t3;
	} else t3 = $[5];
	const submitAndSendAnalytics = t3;
	let t4;
	if ($[6] !== featureName || $[7] !== sendClickAnalyticsEvent) {
		t4 = () => {
			sendClickAnalyticsEvent({
				category: "suggestion",
				action: "click_to_read_docs",
				label: `ref_cta:learn_more;ref_loc:${featureName};`
			});
		};
		$[6] = featureName;
		$[7] = sendClickAnalyticsEvent;
		$[8] = t4;
	} else t4 = $[8];
	const learnMoreAndSendAnalytics = t4;
	let t5;
	if ($[9] !== inProgress || $[10] !== isEnterpriseRequest || $[11] !== learnMoreAndSendAnalytics || $[12] !== learnMorePath || $[13] !== requestMessage || $[14] !== submitAndSendAnalytics) {
		t5 = jsxs(Fragment$1, { children: [
			jsx(RequestCTA, {
				onClick: submitAndSendAnalytics,
				inProgress,
				isEnterpriseRequest
			}),
			requestMessage && jsx(RequestMessage, { message: requestMessage }),
			learnMorePath && jsx(LearnMore, {
				onClick: learnMoreAndSendAnalytics,
				path: learnMorePath
			})
		] });
		$[9] = inProgress;
		$[10] = isEnterpriseRequest;
		$[11] = learnMoreAndSendAnalytics;
		$[12] = learnMorePath;
		$[13] = requestMessage;
		$[14] = submitAndSendAnalytics;
		$[15] = t5;
	} else t5 = $[15];
	return t5;
};
RequestFeature.displayName = "RequestFeature";
var CancelFeatureRequest = ({ inProgress, toggleFeatureRequest: cancel, requestedMessage }) => {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [requestedMessage && /* @__PURE__ */ jsx(RequestedMessage, { message: requestedMessage }), /* @__PURE__ */ jsx(RemoveRequestCTA, {
		onClick: cancel,
		inProgress
	})] });
};
CancelFeatureRequest.displayName = "CancelFeatureRequest";
var RequestCTA = ({ onClick, inProgress, isEnterpriseRequest }) => {
	const buttonText = isEnterpriseRequest ? "Ask enterprise owners for access" : "Ask admin for access";
	return /* @__PURE__ */ jsx(ButtonComponent, {
		onClick,
		variant: "primary",
		disabled: inProgress,
		...testIdProps("feature-request-request-button"),
		children: inProgress ? "Requesting..." : buttonText
	});
};
RequestCTA.displayName = "RequestCTA";
var LearnMore = ({ onClick, path }) => {
	return /* @__PURE__ */ jsx(Link, {
		href: path,
		onClick,
		...testIdProps("feature-request-learn-more-link"),
		children: "Learn more"
	});
};
LearnMore.displayName = "LearnMore";
var RequestMessage = ({ message }) => /* @__PURE__ */ jsx("span", { children: message });
RequestMessage.displayName = "RequestMessage";
var RequestedMessage = ({ message }) => {
	return /* @__PURE__ */ jsxs("span", {
		className: "d-inline-block color-fg-subtle mr-1",
		children: [/* @__PURE__ */ jsx(Octicon, { icon: CheckIcon }), message]
	});
};
RequestedMessage.displayName = "RequestedMessage";
var RemoveRequestCTA = ({ onClick, inProgress }) => {
	return /* @__PURE__ */ jsx(Link, {
		className: "color-fg-danger text-semibold",
		as: "button",
		onClick,
		disabled: inProgress,
		...testIdProps("feature-request-cancel-link"),
		children: inProgress ? "Cancelling..." : "Remove request"
	});
};
RemoveRequestCTA.displayName = "RemoveRequestCTA";
export { useFeatureRequest as i, FeatureRequest as n, RequestFeature as r, CancelFeatureRequest as t };
