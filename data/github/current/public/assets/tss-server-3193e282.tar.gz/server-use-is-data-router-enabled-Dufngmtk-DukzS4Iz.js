import { t as PageLayout } from "./server-PageLayout-CYFdz829-BD84oh7w.js";
import { t as IsDataRouterEnabledContext } from "./server-IsDataRouterEnabled-BOg76Qw5-CRZJ8YK-.js";
import { use } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
var Root = (props) => {
	const $ = c(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			header: Header,
			footer: Footer,
			sidebar: Sidebar
		};
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== props) {
		t1 = /* @__PURE__ */ jsx(PageLayout, {
			containerWidth: "full",
			padding: "none",
			columnGap: "none",
			rowGap: "none",
			_slotsConfig: t0,
			...props
		});
		$[1] = props;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
Root.displayName = "SplitPageLayout";
var Header = (t0) => {
	const $ = c(8);
	let props;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({padding: t1, divider: t2, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
		$[3] = t2;
	} else {
		props = $[1];
		t1 = $[2];
		t2 = $[3];
	}
	const padding = t1 === void 0 ? "normal" : t1;
	const divider = t2 === void 0 ? "line" : t2;
	let t3;
	if ($[4] !== divider || $[5] !== padding || $[6] !== props) {
		t3 = /* @__PURE__ */ jsx(PageLayout.Header, {
			padding,
			divider,
			...props
		});
		$[4] = divider;
		$[5] = padding;
		$[6] = props;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
};
Header.displayName = "SplitPageLayout.Header";
var Content = (t0) => {
	const $ = c(8);
	let props;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({width: t1, padding: t2, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
		$[3] = t2;
	} else {
		props = $[1];
		t1 = $[2];
		t2 = $[3];
	}
	const width = t1 === void 0 ? "large" : t1;
	const padding = t2 === void 0 ? "normal" : t2;
	let t3;
	if ($[4] !== padding || $[5] !== props || $[6] !== width) {
		t3 = /* @__PURE__ */ jsx(PageLayout.Content, {
			width,
			padding,
			...props
		});
		$[4] = padding;
		$[5] = props;
		$[6] = width;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
};
Content.displayName = "SplitPageLayout.Content";
var Pane = (t0) => {
	const $ = c(12);
	let props;
	let t1;
	let t2;
	let t3;
	let t4;
	if ($[0] !== t0) {
		({position: t1, sticky: t2, padding: t3, divider: t4, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
		$[3] = t2;
		$[4] = t3;
		$[5] = t4;
	} else {
		props = $[1];
		t1 = $[2];
		t2 = $[3];
		t3 = $[4];
		t4 = $[5];
	}
	const position = t1 === void 0 ? "start" : t1;
	const sticky = t2 === void 0 ? true : t2;
	const padding = t3 === void 0 ? "normal" : t3;
	const divider = t4 === void 0 ? "line" : t4;
	let t5;
	if ($[6] !== divider || $[7] !== padding || $[8] !== position || $[9] !== props || $[10] !== sticky) {
		t5 = /* @__PURE__ */ jsx(PageLayout.Pane, {
			position,
			sticky,
			padding,
			divider,
			...props
		});
		$[6] = divider;
		$[7] = padding;
		$[8] = position;
		$[9] = props;
		$[10] = sticky;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
};
Pane.displayName = "SplitPageLayout.Pane";
var Sidebar = (t0) => {
	const $ = c(10);
	let props;
	let t1;
	let t2;
	let t3;
	if ($[0] !== t0) {
		({position: t1, padding: t2, divider: t3, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
		$[3] = t2;
		$[4] = t3;
	} else {
		props = $[1];
		t1 = $[2];
		t2 = $[3];
		t3 = $[4];
	}
	const position = t1 === void 0 ? "start" : t1;
	const padding = t2 === void 0 ? "normal" : t2;
	const divider = t3 === void 0 ? "line" : t3;
	let t4;
	if ($[5] !== divider || $[6] !== padding || $[7] !== position || $[8] !== props) {
		t4 = /* @__PURE__ */ jsx(PageLayout.Sidebar, {
			position,
			padding,
			divider,
			...props
		});
		$[5] = divider;
		$[6] = padding;
		$[7] = position;
		$[8] = props;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
};
Sidebar.displayName = "SplitPageLayout.Sidebar";
var Footer = (t0) => {
	const $ = c(8);
	let props;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({padding: t1, divider: t2, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
		$[3] = t2;
	} else {
		props = $[1];
		t1 = $[2];
		t2 = $[3];
	}
	const padding = t1 === void 0 ? "normal" : t1;
	const divider = t2 === void 0 ? "line" : t2;
	let t3;
	if ($[4] !== divider || $[5] !== padding || $[6] !== props) {
		t3 = /* @__PURE__ */ jsx(PageLayout.Footer, {
			padding,
			divider,
			...props
		});
		$[4] = divider;
		$[5] = padding;
		$[6] = props;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
};
Footer.displayName = "SplitPageLayout.Footer";
var SplitPageLayout = Object.assign(Root, {
	Header,
	Content,
	Pane,
	Sidebar,
	Footer
});
function useIsDataRouterEnabled() {
	return use(IsDataRouterEnabledContext);
}
export { useIsDataRouterEnabled as n, SplitPageLayout as t };
