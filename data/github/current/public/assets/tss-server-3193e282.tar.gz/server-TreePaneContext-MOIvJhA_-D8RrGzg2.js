import { createContext, use, useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var TreePaneContext = createContext(null);
TreePaneContext.displayName = "TreePaneContext";
function TreePaneProvider(t0) {
	const $ = c(11);
	const { children, treePaneState, onFindFilesShortcut } = t0;
	const { isTreeExpanded, expandTree, collapseTree, treeToggleElement, treeToggleRef, searchBoxRef } = treePaneState;
	let t1;
	if ($[0] !== collapseTree || $[1] !== expandTree || $[2] !== isTreeExpanded || $[3] !== onFindFilesShortcut || $[4] !== searchBoxRef || $[5] !== treeToggleElement || $[6] !== treeToggleRef) {
		t1 = {
			isTreeExpanded,
			expandTree,
			collapseTree,
			treeToggleElement,
			treeToggleRef,
			searchBoxRef,
			onFindFilesShortcut
		};
		$[0] = collapseTree;
		$[1] = expandTree;
		$[2] = isTreeExpanded;
		$[3] = onFindFilesShortcut;
		$[4] = searchBoxRef;
		$[5] = treeToggleElement;
		$[6] = treeToggleRef;
		$[7] = t1;
	} else t1 = $[7];
	const value = t1;
	let t2;
	if ($[8] !== children || $[9] !== value) {
		t2 = jsx(TreePaneContext, {
			value,
			children
		});
		$[8] = children;
		$[9] = value;
		$[10] = t2;
	} else t2 = $[10];
	return t2;
}
TreePaneProvider.displayName = "TreePaneProvider";
function useTreePaneContext() {
	const context = use(TreePaneContext);
	if (!context) throw new Error("useTreePaneContext must be used within TreePaneProvider");
	return context;
}
export { useTreePaneContext as n, TreePaneProvider as t };
