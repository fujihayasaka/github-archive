var staffbar_module_default = {
	container: "staffbar-module_WNp-vq_container",
	staffbar: "staffbar-module_WNp-vq_staffbar"
};
export { staffbar_module_default as t };
