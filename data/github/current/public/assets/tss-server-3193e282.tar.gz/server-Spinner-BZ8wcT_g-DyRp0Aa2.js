import React, { createContext, useContext, useEffect, useId, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
/**
* Generate a unique id to be used in a component. If an `id` is provided, it
* will be used instead.
*
* @param id - An optional value to be used instead of generating a unique id.
* Useful when accepting an optional `id` as a prop in a component.
*/
function useId$1(id) {
	const uniqueId = useId();
	if (id) return id;
	return uniqueId;
}
var classes$1 = {
	"Box": "prc-Spinner-Box-Y-ke-",
	"SpinnerAnimation": "prc-Spinner-SpinnerAnimation-tutJZ",
	"rotate-keyframes": "prc-Spinner-rotate-keyframes-LV51p"
};
function useMedia(mediaQueryString, defaultState) {
	const $ = c(8);
	const features = useContext(MatchMediaContext);
	let t0;
	if ($[0] !== defaultState || $[1] !== features || $[2] !== mediaQueryString) {
		t0 = () => {
			if (features[mediaQueryString] !== void 0) return features[mediaQueryString];
			return defaultState;
		};
		$[0] = defaultState;
		$[1] = features;
		$[2] = mediaQueryString;
		$[3] = t0;
	} else t0 = $[3];
	const [matches, setMatches] = React.useState(t0);
	if (features[mediaQueryString] !== void 0 && matches !== features[mediaQueryString]) setMatches(features[mediaQueryString]);
	let t1;
	let t2;
	if ($[4] !== features || $[5] !== mediaQueryString) {
		t1 = () => {
			if (features[mediaQueryString] !== void 0) return;
			const listener = function listener(event) {
				setMatches(event.matches);
			};
			const mediaQueryList = window.matchMedia(mediaQueryString);
			if (mediaQueryList.addEventListener) mediaQueryList.addEventListener("change", listener);
			else mediaQueryList.addListener(listener);
			setMatches(mediaQueryList.matches);
			return () => {
				if (mediaQueryList.addEventListener) mediaQueryList.removeEventListener("change", listener);
				else mediaQueryList.removeListener(listener);
			};
		};
		t2 = [features, mediaQueryString];
		$[4] = features;
		$[5] = mediaQueryString;
		$[6] = t1;
		$[7] = t2;
	} else {
		t1 = $[6];
		t2 = $[7];
	}
	useEffect(t1, t2);
	return matches;
}
var MatchMediaContext = /* @__PURE__ */ createContext({});
var FeatureFlagScope = class FeatureFlagScope {
	static create(flags) {
		return new FeatureFlagScope(flags);
	}
	static merge(a, b) {
		const merged = new FeatureFlagScope();
		for (const [key, value] of a.flags) merged.flags.set(key, value);
		for (const [key, value] of b.flags) merged.flags.set(key, value);
		return merged;
	}
	constructor(flags = {}) {
		this.flags = /* @__PURE__ */ new Map();
		for (const [key, value] of Object.entries(flags)) this.flags.set(key, value !== null && value !== void 0 ? value : false);
	}
	/**
	* Enable a feature flag
	*/
	enable(name) {
		this.flags.set(name, true);
	}
	/**
	* Disable a feature flag
	*/
	disable(name) {
		this.flags.set(name, false);
	}
	/**
	* Check if a feature flag is enabled
	*/
	enabled(name) {
		var _this$flags$get;
		return (_this$flags$get = this.flags.get(name)) !== null && _this$flags$get !== void 0 ? _this$flags$get : false;
	}
};
var FeatureFlagContext = /* @__PURE__ */ createContext(FeatureFlagScope.create({
	primer_react_breadcrumbs_overflow_menu: false,
	primer_react_css_anchor_positioning: false,
	primer_react_css_has_selector_perf: false,
	primer_react_select_panel_fullscreen_on_narrow: false,
	primer_react_select_panel_order_selected_at_top: false,
	primer_react_select_panel_remove_active_descendant: false,
	primer_react_spinner_synchronize_animations: false,
	primer_react_action_menu_display_in_viewport_inside_dialog: false
}));
/**
* Check if the given feature flag is enabled
*/
function useFeatureFlag(flag) {
	const $ = c(3);
	const context = useContext(FeatureFlagContext);
	let t0;
	if ($[0] !== context || $[1] !== flag) {
		t0 = context.enabled(flag);
		$[0] = context;
		$[1] = flag;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
var classes = { "VisuallyHidden": "prc-VisuallyHidden-VisuallyHidden-Q0qSB" };
var VisuallyHidden = (t0) => {
	const $ = c(10);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({className, children, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx(className, classes.VisuallyHidden);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== children || $[7] !== rest || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsx("span", {
			className: t1,
			...rest,
			children
		});
		$[6] = children;
		$[7] = rest;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
};
var ANIMATION_DURATION_MS = 1e3;
var sizeMap = {
	small: "16px",
	medium: "32px",
	large: "64px"
};
function Spinner(t0) {
	var _ariaLabel;
	const $ = c(35);
	let ariaLabel;
	let className;
	let props;
	let style;
	let t1;
	let t2;
	let t3;
	if ($[0] !== t0) {
		({size: t1, srText: t2, "aria-label": ariaLabel, className, style, delay: t3, ...props} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = className;
		$[3] = props;
		$[4] = style;
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
	} else {
		ariaLabel = $[1];
		className = $[2];
		props = $[3];
		style = $[4];
		t1 = $[5];
		t2 = $[6];
		t3 = $[7];
	}
	const sizeKey = t1 === void 0 ? "medium" : t1;
	const srText = t2 === void 0 ? "Loading" : t2;
	const delay = t3 === void 0 ? false : t3;
	const syncAnimationsEnabled = useFeatureFlag("primer_react_spinner_synchronize_animations");
	const noMotionPreference = useMedia("(prefers-reduced-motion: no-preference)", false);
	const size = sizeMap[sizeKey];
	const hasHiddenLabel = srText !== null && ariaLabel === void 0;
	const labelId = useId$1();
	let t4;
	if ($[8] !== delay) {
		t4 = () => ({
			isVisible: !delay,
			syncDelay: !delay ? computeSyncDelay() : 0
		});
		$[8] = delay;
		$[9] = t4;
	} else t4 = $[9];
	const [t5, setVisibleState] = useState(t4);
	const { isVisible, syncDelay } = t5;
	let t6;
	let t7;
	if ($[10] !== delay) {
		t6 = () => {
			if (delay) {
				const delayDuration = typeof delay === "number" ? delay : delay === "short" ? 300 : 1e3;
				const timeoutId = setTimeout(() => {
					setVisibleState({
						isVisible: true,
						syncDelay: computeSyncDelay()
					});
				}, delayDuration);
				return () => clearTimeout(timeoutId);
			}
		};
		t7 = [delay];
		$[10] = delay;
		$[11] = t6;
		$[12] = t7;
	} else {
		t6 = $[11];
		t7 = $[12];
	}
	useEffect(t6, t7);
	if (!isVisible) return null;
	const shouldSync = syncAnimationsEnabled && noMotionPreference;
	let t8;
	if ($[13] !== shouldSync || $[14] !== style || $[15] !== syncDelay) {
		t8 = shouldSync ? {
			...style,
			animationDelay: `${syncDelay}ms`
		} : style;
		$[13] = shouldSync;
		$[14] = style;
		$[15] = syncDelay;
		$[16] = t8;
	} else t8 = $[16];
	const mergedStyle = t8;
	const t9 = (_ariaLabel = ariaLabel) !== null && _ariaLabel !== void 0 ? _ariaLabel : void 0;
	const t10 = hasHiddenLabel ? labelId : void 0;
	let t11;
	if ($[17] !== className) {
		t11 = clsx(className, classes$1.SpinnerAnimation);
		$[17] = className;
		$[18] = t11;
	} else t11 = $[18];
	let t12;
	let t13;
	if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = /* @__PURE__ */ jsx("circle", {
			cx: "8",
			cy: "8",
			r: "7",
			stroke: "currentColor",
			strokeOpacity: "0.25",
			strokeWidth: "2",
			vectorEffect: "non-scaling-stroke"
		});
		t13 = /* @__PURE__ */ jsx("path", {
			d: "M15 8a7.002 7.002 0 00-7-7",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			vectorEffect: "non-scaling-stroke"
		});
		$[19] = t12;
		$[20] = t13;
	} else {
		t12 = $[19];
		t13 = $[20];
	}
	let t14;
	if ($[21] !== mergedStyle || $[22] !== props || $[23] !== size || $[24] !== t10 || $[25] !== t11 || $[26] !== t9) {
		t14 = /* @__PURE__ */ jsxs("svg", {
			height: size,
			width: size,
			viewBox: "0 0 16 16",
			fill: "none",
			"aria-hidden": true,
			"aria-label": t9,
			"aria-labelledby": t10,
			className: t11,
			style: mergedStyle,
			...props,
			children: [t12, t13]
		});
		$[21] = mergedStyle;
		$[22] = props;
		$[23] = size;
		$[24] = t10;
		$[25] = t11;
		$[26] = t9;
		$[27] = t14;
	} else t14 = $[27];
	let t15;
	if ($[28] !== hasHiddenLabel || $[29] !== labelId || $[30] !== srText) {
		t15 = hasHiddenLabel ? /* @__PURE__ */ jsx(VisuallyHidden, {
			id: labelId,
			children: srText
		}) : null;
		$[28] = hasHiddenLabel;
		$[29] = labelId;
		$[30] = srText;
		$[31] = t15;
	} else t15 = $[31];
	let t16;
	if ($[32] !== t14 || $[33] !== t15) {
		t16 = /* @__PURE__ */ jsxs("span", {
			className: classes$1.Box,
			children: [t14, t15]
		});
		$[32] = t14;
		$[33] = t15;
		$[34] = t16;
	} else t16 = $[34];
	return t16;
}
Spinner.displayName = "Spinner";
/**
* Computes a negative animation-delay so all spinners land at the same
* rotation angle regardless of when they mount. Because every instance
* references the same clock (performance.now()), the CSS animation engine
* keeps them visually in sync without any Web Animations API calls
* (getAnimations, element.animate, startTime), which are significantly
* slower in Safari/WebKit.
*/
function computeSyncDelay() {
	return -((typeof performance !== "undefined" ? performance.now() : 0) % ANIMATION_DURATION_MS);
}
export { useFeatureFlag as a, VisuallyHidden as i, FeatureFlagScope as n, useId$1 as o, Spinner as r, useMedia as s, FeatureFlagContext as t };
