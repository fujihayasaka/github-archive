import { n as useStableRandom } from "./server-use-stable-random-H-NEF9zZ-D8-5Amea.js";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var LoadingSkeleton_module_default = {
	elliptical: "LoadingSkeleton-module_5N5nDW_elliptical",
	heightLg: "LoadingSkeleton-module_5N5nDW_heightLg",
	heightMd: "LoadingSkeleton-module_5N5nDW_heightMd",
	heightSm: "LoadingSkeleton-module_5N5nDW_heightSm",
	heightXl: "LoadingSkeleton-module_5N5nDW_heightXl",
	pill: "LoadingSkeleton-module_5N5nDW_pill",
	pulse: "LoadingSkeleton-module_5N5nDW_pulse",
	rectangular: "LoadingSkeleton-module_5N5nDW_rectangular",
	rounded: "LoadingSkeleton-module_5N5nDW_rounded",
	skeleton: "LoadingSkeleton-module_5N5nDW_skeleton",
	text: "LoadingSkeleton-module_5N5nDW_text",
	widthLg: "LoadingSkeleton-module_5N5nDW_widthLg",
	widthMd: "LoadingSkeleton-module_5N5nDW_widthMd",
	widthSm: "LoadingSkeleton-module_5N5nDW_widthSm",
	widthXl: "LoadingSkeleton-module_5N5nDW_widthXl"
};
var PSEUDO_RANDOM_WIDTHS = [
	60,
	40,
	54,
	77,
	57,
	41,
	75,
	45,
	76,
	55
];
var WIDTH_CLASSES = {
	xl: LoadingSkeleton_module_default.widthXl,
	lg: LoadingSkeleton_module_default.widthLg,
	md: LoadingSkeleton_module_default.widthMd,
	sm: LoadingSkeleton_module_default.widthSm
};
var HEIGHT_CLASSES = {
	xl: LoadingSkeleton_module_default.heightXl,
	lg: LoadingSkeleton_module_default.heightLg,
	md: LoadingSkeleton_module_default.heightMd,
	sm: LoadingSkeleton_module_default.heightSm
};
function isSizePreset(value) {
	return value in WIDTH_CLASSES;
}
function LoadingSkeleton(t0) {
	const $ = c(1);
	const { animationStyle: t1, as: t2, height, variant: t3, width, className, ...rest } = t0;
	const animationStyle = t1 === void 0 ? "wave" : t1;
	const Component = t2 === void 0 ? "div" : t2;
	const variant = t3 === void 0 ? "rectangular" : t3;
	let t4;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = { max: PSEUDO_RANDOM_WIDTHS.length };
		$[0] = t4;
	} else t4 = $[0];
	const index = useStableRandom(t4);
	const widthClass = width && isSizePreset(width) ? WIDTH_CLASSES[width] : void 0;
	const heightClass = height && isSizePreset(height) ? HEIGHT_CLASSES[height] : void 0;
	const inlineStyles = {};
	if (width === "random") inlineStyles.width = `${PSEUDO_RANDOM_WIDTHS[index]}%`;
	else if (width && !widthClass) inlineStyles.width = width;
	if (height && !heightClass) inlineStyles.height = height;
	return jsx(Component, {
		className: clsx(LoadingSkeleton_module_default.skeleton, animationStyle === "pulse" && LoadingSkeleton_module_default.pulse, LoadingSkeleton_module_default[variant], widthClass, heightClass, className),
		style: inlineStyles,
		...rest
	});
}
LoadingSkeleton.displayName = "LoadingSkeleton";
export { LoadingSkeleton as t };
