import { n as getEnv } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { r as CopilotAuthTokenProvider } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { H as makeCAPIRequest } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { createContext, use, useEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var AGENT_SESSIONS_TOKEN_KEY = "AGENT_SESSIONS_TOKEN";
var agentSessionsTokenProviderInstance = null;
/**
* Returns a singleton instance of AgentSessionsTokenProvider.
* This ensures request deduplication works across all callers.
*/
function getAgentSessionsTokenProvider() {
	if (!agentSessionsTokenProviderInstance) agentSessionsTokenProviderInstance = new AgentSessionsTokenProvider();
	return agentSessionsTokenProviderInstance;
}
var AgentSessionsTokenProvider = class extends CopilotAuthTokenProvider {
	constructor() {
		super([], `/copilot/agent-sessions/token`, AGENT_SESSIONS_TOKEN_KEY);
	}
	async validateAuthToken(token) {
		if (token.ssoChanged(this.ssoOrgIDs)) return this.fetchAuthToken();
		if (!token.isExpired) return token;
		return this.fetchAuthToken();
	}
	/**
	* Attempts to refresh the token by forcing a server-side cache miss.
	* Use this after receiving a 401 from CAPI (e.g., token was evicted).
	*/
	async tryRefreshToken() {
		if (this.isUnlicensed) return false;
		try {
			await this.fetchAuthToken(true);
			return true;
		} catch {
			return false;
		}
	}
};
var DEFAULT_API_URL = "https://api.githubcopilot.com";
/**
* Get a user-friendly fallback message based on HTTP status code.
* Used when the server doesn't provide a meaningful error message.
*/
function getFallbackMessage(status) {
	switch (status) {
		case 0: return "Network error. Please check your connection and try again.";
		case 400: return "The request was invalid. Please verify your input and try again.";
		case 401: return "You don't have permission to perform this action. Please sign in and try again.";
		case 402: return "You've run out of Copilot premium quota.";
		case 403: return "This feature isn't available for this repository or organization.";
		case 404: return "The requested resource couldn't be found.";
		case 408: return "The request timed out. Please try again.";
		case 409: return "A conflict occurred. The resource may already exist.";
		case 422: return "The request was rejected. A repository rule may have blocked this action.";
		case 429: return "Too many requests. Please wait a moment and try again.";
		default: return "An unexpected error occurred. Please try again.";
	}
}
var getIntegrationId = () => {
	if (typeof window === "undefined") return "copilot-developer";
	const hostname = window.location.hostname;
	if (hostname === "localhost" || hostname.endsWith(".localhost")) return "copilot-developer-dev";
	return "copilot-developer";
};
var FetchCAPIError = class extends Error {
	status;
	originalMessage;
	/** Structured validation errors returned by the API (422 responses) */
	errors;
	/** Documentation URL for the error */
	documentationUrl;
	constructor(message, status, errors, documentationUrl) {
		super(message);
		this.name = "FetchCAPIError";
		this.status = status;
		this.originalMessage = message;
		this.errors = errors;
		this.documentationUrl = documentationUrl;
	}
};
async function fetchCAPI({ path, method = "GET", streamingResponse = false, additionalHeaders, body, retryOn401, copilotApiUrl }) {
	const tokenProvider = getAgentSessionsTokenProvider();
	return requestWithAuthRetry({
		path,
		method,
		streamingResponse,
		additionalHeaders,
		body,
		basePath: copilotApiUrl ?? getEnv().copilotApiOverrideUrl ?? DEFAULT_API_URL,
		retryOn401: retryOn401 ?? isFeatureEnabled("mission_control_retry_on_401")
	}, tokenProvider);
}
var MAX_AUTH_RETRIES = 1;
async function requestWithAuthRetry(requestOptions, tokenProvider, retryAttempt = 0) {
	const token = await tokenProvider.getAuthToken();
	if (!token) throw new Error("No token available");
	let integrationId;
	if (isFeatureEnabled("copilot_mission_control_always_send_integration_id")) integrationId = getIntegrationId();
	const response = await makeCAPIRequest({
		authToken: token,
		basePath: requestOptions.basePath,
		method: requestOptions.method,
		path: requestOptions.path,
		streamingResponse: requestOptions.streamingResponse,
		body: requestOptions.body,
		integrationId,
		additionalHeaders: requestOptions.additionalHeaders
	});
	if (!response.ok) {
		if (requestOptions.retryOn401 && response.status === 401 && retryAttempt < MAX_AUTH_RETRIES) {
			if (!await tokenProvider.tryRefreshToken()) tokenProvider.removeLocalStorageAuthToken();
			return requestWithAuthRetry(requestOptions, tokenProvider, retryAttempt + 1);
		}
		let errorMessage;
		let errorDetails;
		let documentationUrl;
		if (response.status >= 500) errorMessage = getFallbackMessage(response.status);
		else {
			errorMessage = "error" in response ? response.error : getFallbackMessage(response.status);
			if ("response" in response && response.response) try {
				const text = await response.response.text();
				if (text && text.trim()) try {
					const parsed = JSON.parse(text.trim());
					if (parsed && typeof parsed.message === "string") {
						errorMessage = parsed.message;
						errorDetails = parsed.errors;
						documentationUrl = parsed.documentation_url;
					} else errorMessage = text.trim();
				} catch {
					errorMessage = text.trim();
				}
			} catch {}
		}
		throw new FetchCAPIError(errorMessage, response.status, errorDetails, documentationUrl);
	}
	return response;
}
var ConsecutiveCAPI401sContext = createContext(void 0);
ConsecutiveCAPI401sContext.displayName = "ConsecutiveCAPI401sContext";
function useConsecutiveCAPI401sContext() {
	const context = use(ConsecutiveCAPI401sContext);
	if (!context) throw new Error("useConsecutiveCAPI401sContext must be used within a ConsecutiveCAPI401sProvider");
	return context;
}
function ConsecutiveCAPI401sProvider(t0) {
	const $ = c(7);
	const { children } = t0;
	const [numberOf401s, setNumberOf401s] = useState(0);
	let t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => setNumberOf401s(_temp);
		t2 = () => setNumberOf401s(0);
		$[0] = t1;
		$[1] = t2;
	} else {
		t1 = $[0];
		t2 = $[1];
	}
	let t3;
	if ($[2] !== numberOf401s) {
		t3 = {
			numberOf401s,
			increment401s: t1,
			reset401s: t2
		};
		$[2] = numberOf401s;
		$[3] = t3;
	} else t3 = $[3];
	const properties = t3;
	let t4;
	if ($[4] !== children || $[5] !== properties) {
		t4 = jsx(ConsecutiveCAPI401sContext, {
			value: properties,
			children
		});
		$[4] = children;
		$[5] = properties;
		$[6] = t4;
	} else t4 = $[6];
	return t4;
}
ConsecutiveCAPI401sProvider.displayName = "ConsecutiveCAPI401sProvider";
function _temp(prev) {
	return prev + 1;
}
var MAX_401_RETRIES = 5;
function useCAPIQuery(...args) {
	const result = useQuery(...args);
	const { numberOf401s, increment401s, reset401s } = useConsecutiveCAPI401sContext();
	const { isError, isLoading, error } = result;
	const processedErrorRef = useRef(null);
	useEffect(() => {
		if (isError && error instanceof FetchCAPIError && error.status === 401) {
			if (processedErrorRef.current === error) return;
			if (numberOf401s >= MAX_401_RETRIES) {
				getAgentSessionsTokenProvider().tryRefreshToken();
				processedErrorRef.current = error;
				reset401s();
			} else {
				processedErrorRef.current = error;
				increment401s();
			}
		} else if (!isError && !isLoading && numberOf401s > 0) {
			processedErrorRef.current = null;
			reset401s();
		} else if (!isError) processedErrorRef.current = null;
	}, [
		isError,
		isLoading,
		error,
		increment401s,
		reset401s,
		numberOf401s
	]);
	return result;
}
export { useCAPIQuery as a, getAgentSessionsTokenProvider as i, FetchCAPIError as n, fetchCAPI as r, ConsecutiveCAPI401sProvider as t };
