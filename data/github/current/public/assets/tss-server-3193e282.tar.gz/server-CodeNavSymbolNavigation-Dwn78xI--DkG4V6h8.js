import { Ai as XCircleFillIcon, Bi as useFocusZone, Mi as XIcon, Nt as FilterIcon, _i as Truncate, an as IconButton, bn as Link, n as ActionList, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { n as TreeView } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { h as codeNavSearchPath, m as codeNavGeneralSearchPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { n as AllShortcutsEnabled, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as HighlightedText } from "./server-RefSelector-unHqlV3G-DIJhjGu-.js";
import { it as useFocusSymbolPane } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { n as fuzzyScore, t as compare } from "./server-fuzzy-filter-DktYDqCY-DJk6_pK9.js";
import React, { useCallback, useDeferredValue, useEffect, useEffectEvent, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { c } from "react/compiler-runtime";
var SymbolIndicator_module_default = {
	symbolBackground: "SymbolIndicator-module_trOXWa_symbolBackground",
	symbolLabel: "SymbolIndicator-module_trOXWa_symbolLabel",
	symbolLabelMedium: "SymbolIndicator-module_trOXWa_symbolLabelMedium",
	symbolLabelSmall: "SymbolIndicator-module_trOXWa_symbolLabelSmall",
	symbolWrapper: "SymbolIndicator-module_trOXWa_symbolWrapper",
	symbolWrapperCompact: "SymbolIndicator-module_trOXWa_symbolWrapperCompact"
};
function SymbolIndicator({ symbolKind, showFullSymbol }) {
	if (!symbolKind) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(SymbolIndicator_module_default.symbolWrapper, !showFullSymbol && SymbolIndicator_module_default.symbolWrapperCompact),
		children: [/* @__PURE__ */ jsx("div", {
			className: SymbolIndicator_module_default.symbolBackground,
			style: { backgroundColor: symbolKind.plColor }
		}), /* @__PURE__ */ jsx("div", {
			className: clsx(SymbolIndicator_module_default.symbolLabel, showFullSymbol ? SymbolIndicator_module_default.symbolLabelMedium : SymbolIndicator_module_default.symbolLabelSmall),
			style: { color: symbolKind.plColor },
			children: showFullSymbol ? symbolKind.fullName : symbolKind.shortName
		})]
	});
}
SymbolIndicator.displayName = "SymbolIndicator";
function* filterMap(items, map) {
	for (const item of items) {
		const value = map(item);
		if (value != null) yield value;
	}
}
function filterSort(items, map, compare) {
	const sortKey = (item) => {
		const key = map(item);
		return key != null ? [item, key] : null;
	};
	return [...filterMap(items, sortKey)].sort((a, b) => compare(a[1], b[1])).map(([item]) => item);
}
var CodeNavSymbolNavigation_module_default = {
	closeButton: "CodeNavSymbolNavigation-module_w5ieja_closeButton",
	container: "CodeNavSymbolNavigation-module_w5ieja_container",
	description: "CodeNavSymbolNavigation-module_w5ieja_description",
	filterInput: "CodeNavSymbolNavigation-module_w5ieja_filterInput",
	headerRow: "CodeNavSymbolNavigation-module_w5ieja_headerRow",
	headerTitle: "CodeNavSymbolNavigation-module_w5ieja_headerTitle",
	shortcutsBox: "CodeNavSymbolNavigation-module_w5ieja_shortcutsBox",
	TextInput_Action: "CodeNavSymbolNavigation-module_w5ieja_TextInput_Action",
	treeWrapper: "CodeNavSymbolNavigation-module_w5ieja_treeWrapper",
	zeroStateWrapper: "CodeNavSymbolNavigation-module_w5ieja_zeroStateWrapper"
};
var CodeNavSymbolTree_module_default = {
	filterResults: "CodeNavSymbolTree-module_gd6OAq_filterResults",
	treeContent: "CodeNavSymbolTree-module_gd6OAq_treeContent",
	truncate: "CodeNavSymbolTree-module_gd6OAq_truncate"
};
var CodeNavSymbolTree = React.memo(function CodeNavSymTree({ treeSymbols, onTreeSymbolSelect }) {
	const isFlatTree = !treeSymbols.some((node) => node.isParent || node.children.length > 0);
	return /* @__PURE__ */ jsx("div", {
		id: "filter-results",
		className: CodeNavSymbolTree_module_default.filterResults,
		children: /* @__PURE__ */ jsx(TreeView, {
			"aria-label": "Code Navigation",
			flat: isFlatTree,
			children: treeSymbols.map((s, idx) => /* @__PURE__ */ jsx(CodeNavTreeItem, {
				id: `${idx}${s.symbol.name}`,
				symbol: s,
				depth: s.isParent ? 1 : 2,
				onSelect: onTreeSymbolSelect
			}, `${idx}${s.symbol.name}`))
		})
	});
});
CodeNavSymbolTree.displayName = "CodeNavSymbolTree";
function CodeNavTreeContent({ symbol }) {
	return /* @__PURE__ */ jsxs("div", {
		className: CodeNavSymbolTree_module_default.treeContent,
		children: [
			/* @__PURE__ */ jsx(SymbolIndicator, { symbolKind: symbol.symbol.kind }),
			"  ",
			/* @__PURE__ */ jsx(Truncate, {
				title: symbol.symbol.name,
				className: CodeNavSymbolTree_module_default.truncate,
				children: /* @__PURE__ */ jsx("span", { children: symbol.symbol.name })
			})
		]
	});
}
CodeNavTreeContent.displayName = "CodeNavTreeContent";
function CodeNavTreeItem(t0) {
	const $ = c(13);
	const { symbol, depth, onSelect, id } = t0;
	const [isExpanded, setIsExpanded] = useState(depth <= 7);
	let t1;
	if ($[0] !== onSelect || $[1] !== symbol.symbol) {
		t1 = () => onSelect(symbol.symbol);
		$[0] = onSelect;
		$[1] = symbol.symbol;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== isExpanded) {
		t2 = () => setIsExpanded(!isExpanded);
		$[3] = isExpanded;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== depth || $[6] !== id || $[7] !== isExpanded || $[8] !== onSelect || $[9] !== symbol || $[10] !== t1 || $[11] !== t2) {
		t3 = jsxs(TreeView.Item, {
			onSelect: t1,
			expanded: isExpanded,
			onExpandedChange: t2,
			id,
			children: [jsx(CodeNavTreeContent, { symbol }), symbol.isParent && symbol.children.length > 0 && jsx(TreeView.SubTree, { children: symbol.children.map((childSymbol, index) => jsx(CodeNavTreeItem, {
				symbol: childSymbol,
				depth: childSymbol.isParent ? depth + 1 : depth,
				onSelect,
				id: `${index}${childSymbol.symbol.name}`
			}, `${index}${childSymbol.symbol.name}`)) })]
		});
		$[5] = depth;
		$[6] = id;
		$[7] = isExpanded;
		$[8] = onSelect;
		$[9] = symbol;
		$[10] = t1;
		$[11] = t2;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
}
CodeNavTreeItem.displayName = "CodeNavTreeItem";
var JumpToItem_module_default = {
	jumpToItem: "JumpToItem-module_CMqoHW_jumpToItem",
	jumpToItemFocused: "JumpToItem-module_CMqoHW_jumpToItemFocused",
	jumpToLink: "JumpToItem-module_CMqoHW_jumpToLink"
};
var JumpToItem = React.memo(function JumpToItemInner({ symbol, filterText, onSelect, focused, index }) {
	return /* @__PURE__ */ jsx(ActionList.Item, {
		role: "option",
		id: `jump-to-item-${index}`,
		"aria-selected": focused,
		className: clsx(JumpToItem_module_default.jumpToItem, focused && JumpToItem_module_default.jumpToItemFocused),
		onSelect: () => onSelect(symbol),
		children: /* @__PURE__ */ jsx(Link, {
			href: symbol.href(),
			className: JumpToItem_module_default.jumpToLink,
			children: /* @__PURE__ */ jsxs("div", {
				style: { display: "flex" },
				children: [
					/* @__PURE__ */ jsx(SymbolIndicator, { symbolKind: symbol.kind }),
					"  ",
					/* @__PURE__ */ jsx("div", {
						style: {
							display: "flex",
							minWidth: 0,
							alignItems: "flex-end"
						},
						children: /* @__PURE__ */ jsx(HighlightedText, {
							search: filterText,
							text: symbol.name,
							overflowWidth: 175,
							hideOverflow: true
						}, symbol.fullyQualifiedName)
					})
				]
			})
		})
	});
});
JumpToItem.displayName = "JumpToItem";
var maxHeight = "68vh";
/**
* A list of symbols that can be filtered by a search string
*/
function JumpToItemList(props) {
	return /* @__PURE__ */ jsx(FullJumpToItemList, { ...props });
}
JumpToItemList.displayName = "JumpToItemList";
function FullJumpToItemList(t0) {
	const $ = c(15);
	const { codeSymbols, filterText, onSelect, focusedIndex } = t0;
	const codeSymbolsLength = useRef(codeSymbols.length);
	const codeSymbolMessageAriaHack = useRef("");
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { bindKeys: FocusKeys.ArrowVertical | FocusKeys.HomeAndEnd };
		$[0] = t1;
	} else t1 = $[0];
	const { containerRef } = useFocusZone(t1);
	let t2;
	if ($[1] !== codeSymbols.length) {
		t2 = () => {
			if (codeSymbols.length === codeSymbolsLength.current) codeSymbolMessageAriaHack.current = codeSymbolMessageAriaHack.current + "​";
			const codeSymbolText = codeSymbols.length === 1 ? "symbol" : "symbols";
			announce$1(`${codeSymbols.length} ${codeSymbolText} found${codeSymbolMessageAriaHack.current}`);
			codeSymbolsLength.current = codeSymbols.length;
		};
		$[1] = codeSymbols.length;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== codeSymbols) {
		t3 = [codeSymbols];
		$[3] = codeSymbols;
		$[4] = t3;
	} else t3 = $[4];
	useEffect(t2, t3);
	let t4;
	if ($[5] !== codeSymbols || $[6] !== containerRef || $[7] !== filterText || $[8] !== focusedIndex || $[9] !== onSelect) {
		let t5;
		if ($[11] !== filterText || $[12] !== focusedIndex || $[13] !== onSelect) {
			t5 = (sym, index) => {
				const { name, lineNumber } = sym;
				return jsx(JumpToItem, {
					symbol: sym,
					filterText,
					onSelect,
					focused: index === focusedIndex,
					index
				}, `${name}_${lineNumber}`);
			};
			$[11] = filterText;
			$[12] = focusedIndex;
			$[13] = onSelect;
			$[14] = t5;
		} else t5 = $[14];
		t4 = jsx(ActionList, {
			ref: containerRef,
			role: "listbox",
			id: "filter-results",
			"aria-orientation": "vertical",
			style: {
				maxHeight,
				overflowY: "auto"
			},
			children: codeSymbols.map(t5)
		});
		$[5] = codeSymbols;
		$[6] = containerRef;
		$[7] = filterText;
		$[8] = focusedIndex;
		$[9] = onSelect;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
FullJumpToItemList.displayName = "FullJumpToItemList";
var SymbolZeroState_module_default = {
	container: "SymbolZeroState-module_4r3IRG_container",
	emptyStateCard: "SymbolZeroState-module_4r3IRG_emptyStateCard",
	emptyStateCardContent: "SymbolZeroState-module_4r3IRG_emptyStateCardContent",
	emptyStateDescription: "SymbolZeroState-module_4r3IRG_emptyStateDescription",
	emptyStateHeading: "SymbolZeroState-module_4r3IRG_emptyStateHeading",
	filterResultHeading: "SymbolZeroState-module_4r3IRG_filterResultHeading",
	filterZeroState: "SymbolZeroState-module_4r3IRG_filterZeroState",
	languageSupportNote: "SymbolZeroState-module_4r3IRG_languageSupportNote"
};
function SymbolZeroState(t0) {
	const $ = c(10);
	const { filterText, isFindInFile } = t0;
	const [message, setMessage] = useState(isFindInFile ? "No matches found" : "No symbols found");
	const repo = useCurrentRepository();
	const firstUpdateRef = useRef(true);
	let t1;
	if ($[0] !== message) {
		t1 = () => {
			if (firstUpdateRef.current) {
				firstUpdateRef.current = false;
				return;
			}
			setMessage(`${message}\u200B`);
		};
		$[0] = message;
		$[1] = t1;
	} else t1 = $[1];
	const handleAriaMessageAnnounceAfterFirstRender = useEffectEvent(t1);
	let t2;
	if ($[2] !== handleAriaMessageAnnounceAfterFirstRender) {
		t2 = () => {
			handleAriaMessageAnnounceAfterFirstRender();
		};
		$[2] = handleAriaMessageAnnounceAfterFirstRender;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== filterText) {
		t3 = [filterText];
		$[4] = filterText;
		$[5] = t3;
	} else t3 = $[5];
	useEffect(t2, t3);
	let t4;
	if ($[6] !== filterText || $[7] !== message || $[8] !== repo) {
		t4 = jsxs("div", {
			className: SymbolZeroState_module_default.container,
			children: [
				filterText === "" && jsxs(Fragment$1, { children: [jsx("div", {
					className: SymbolZeroState_module_default.emptyStateCard,
					children: jsxs("div", {
						className: SymbolZeroState_module_default.emptyStateCardContent,
						children: [jsx("h3", {
							className: SymbolZeroState_module_default.emptyStateHeading,
							children: "Symbol outline not available for this file"
						}), jsx("div", {
							className: SymbolZeroState_module_default.emptyStateDescription,
							children: "To inspect a symbol, try clicking on the symbol directly in the code view."
						})]
					})
				}), jsxs("div", {
					className: SymbolZeroState_module_default.languageSupportNote,
					children: [
						" ",
						"Code navigation supports a limited number of languages.",
						" ",
						jsx(Link, {
							inline: true,
							href: "https://docs.github.com/repositories/working-with-files/using-files/navigating-code-on-github",
							children: "See which languages are supported."
						})
					]
				})] }),
				filterText && jsxs(Fragment$1, { children: [jsx(Octicon, {
					icon: SearchIcon,
					size: 24
				}), jsx("h3", {
					className: SymbolZeroState_module_default.filterResultHeading,
					role: "alert",
					"aria-relevant": "all",
					children: message
				})] }),
				filterText && jsxs("span", {
					id: "filter-zero-state",
					className: SymbolZeroState_module_default.filterZeroState,
					children: [
						"No lines in this file contain that string.",
						jsx("br", {}),
						"Search in",
						" ",
						jsxs(Link, {
							href: codeNavSearchPath({
								owner: repo.ownerLogin,
								repo: repo.name,
								searchTerm: filterText
							}),
							inline: true,
							children: [
								repo.ownerLogin,
								"/",
								repo.name
							]
						}),
						" ",
						"or",
						" ",
						jsx(Link, {
							href: codeNavGeneralSearchPath({ searchTerm: filterText }),
							inline: true,
							children: "all of GitHub"
						})
					]
				})
			]
		});
		$[6] = filterText;
		$[7] = message;
		$[8] = repo;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
}
SymbolZeroState.displayName = "SymbolZeroState";
var MemoizedJumpToItemList = React.memo(JumpToItemList);
MemoizedJumpToItemList.displayName = "MemoizedJumpToItemList";
function FilterIconVisual() {
	return /* @__PURE__ */ jsx(Octicon, {
		"aria-hidden": "true",
		icon: FilterIcon
	});
}
FilterIconVisual.displayName = "FilterIconVisual";
var symbolsHeaderId = "symbols-pane-header";
/**
* An action menu that allows the user to navigate to certain sections of a given
* file.
*
* This was modeled after RefSelector, but couldn't be shoehorned into a generic
* ActionMenu component because it needs to have different functionality and specific
* visual rendering. It could potentially be made into a generic ActionMenu component
* where RefSelector and this component could both use it, but it didn't seem worth the
* effort.
*
*/
function CodeNavSymbolNavigation({ codeSymbols, onSymbolSelect, treeSymbols, autoFocusSearch, onClose }) {
	const [filterText, setFilterText] = useState("");
	const deferredFilterText = useDeferredValue(filterText);
	const [focusedIndex, setFocusedIndex] = useState(-1);
	const filteredCodeSymbols = useMemo(() => {
		if (deferredFilterText === "") return codeSymbols;
		return getFilteredCodeSymbols(deferredFilterText, codeSymbols);
	}, [deferredFilterText, codeSymbols]);
	const hasFilteredSymbols = filteredCodeSymbols?.length > 0;
	const hasAnyCodeSymbols = codeSymbols?.length > 0;
	const hasLocalCodeSymbols = treeSymbols.length > 0;
	const hasAnySymbols = hasAnyCodeSymbols || hasLocalCodeSymbols;
	const listIsFilteredOrEmpty = !hasLocalCodeSymbols || filterText !== "";
	const ariaControls = !hasFilteredSymbols && listIsFilteredOrEmpty ? "filter-zero-state" : "filter-results";
	const ariaActivedescendant = focusedIndex === -1 ? void 0 : `jump-to-item-${focusedIndex}`;
	const handleClear = useCallback(() => {
		setFilterText("");
		setFocusedIndex(-1);
	}, []);
	const handleChange = useCallback((value) => {
		setFilterText(value);
		setFocusedIndex(-1);
	}, []);
	const onSymbolSelectRef = useRef(onSymbolSelect);
	useEffect(() => {
		onSymbolSelectRef.current = onSymbolSelect;
	}, [onSymbolSelect]);
	const stableOnSymbolSelect = useCallback((sym) => {
		onSymbolSelectRef.current(sym);
	}, []);
	const onCloseRef = useRef(onClose);
	useEffect(() => {
		onCloseRef.current = onClose;
	}, [onClose]);
	const stableOnClose = useCallback(() => {
		onCloseRef.current();
	}, []);
	const handleKeyDown = useCallback((e) => {
		if (e.key === "ArrowDown" || (e.key === "N" || e.key === "n") && e.ctrlKey) setFocusedIndex(Math.min(focusedIndex + 1, filteredCodeSymbols.length - 1));
		else if (e.key === "ArrowUp" || (e.key === "P" || e.key === "p") && e.ctrlKey) setFocusedIndex(Math.max(focusedIndex - 1, 0));
		else if (e.key === "Enter" && filteredCodeSymbols[focusedIndex]) stableOnSymbolSelect(filteredCodeSymbols[focusedIndex]);
		else if (e.key === "Escape") stableOnClose();
	}, [
		filteredCodeSymbols,
		focusedIndex,
		stableOnSymbolSelect,
		stableOnClose
	]);
	return /* @__PURE__ */ jsxs("div", {
		className: CodeNavSymbolNavigation_module_default.container,
		"aria-labelledby": symbolsHeaderId,
		children: [
			/* @__PURE__ */ jsx(SymbolPaneHeader, { onClose: stableOnClose }),
			hasAnySymbols && /* @__PURE__ */ jsx("p", {
				className: CodeNavSymbolNavigation_module_default.description,
				children: "Find definitions and references for functions and other symbols in this file by clicking a symbol below or in the code."
			}),
			(hasAnyCodeSymbols || filterText !== "") && /* @__PURE__ */ jsx(MemoizedSymbolFilterInput, {
				filterText,
				ariaControls,
				ariaActivedescendant,
				autoFocusSearch,
				onClear: handleClear,
				onChange: handleChange,
				onKeyDown: handleKeyDown
			}),
			!listIsFilteredOrEmpty && /* @__PURE__ */ jsx("div", {
				className: CodeNavSymbolNavigation_module_default.treeWrapper,
				children: /* @__PURE__ */ jsx(CodeNavSymbolTree, {
					treeSymbols,
					onTreeSymbolSelect: stableOnSymbolSelect
				})
			}),
			hasFilteredSymbols && listIsFilteredOrEmpty && /* @__PURE__ */ jsx(MemoizedJumpToItemList, {
				codeSymbols: filteredCodeSymbols,
				filterText: deferredFilterText,
				onSelect: stableOnSymbolSelect,
				focusedIndex
			}),
			!hasFilteredSymbols && listIsFilteredOrEmpty && /* @__PURE__ */ jsx("span", {
				className: CodeNavSymbolNavigation_module_default.zeroStateWrapper,
				children: /* @__PURE__ */ jsx(SymbolZeroState, { filterText })
			})
		]
	});
}
CodeNavSymbolNavigation.displayName = "CodeNavSymbolNavigation";
var SymbolPaneHeader = React.memo(function SymbolPaneHeader({ onClose }) {
	return /* @__PURE__ */ jsxs("div", {
		className: CodeNavSymbolNavigation_module_default.headerRow,
		children: [/* @__PURE__ */ jsx("h2", {
			className: CodeNavSymbolNavigation_module_default.headerTitle,
			id: symbolsHeaderId,
			tabIndex: -1,
			children: "Symbols"
		}), /* @__PURE__ */ jsx(IconButton, {
			"aria-label": "Close symbols",
			tooltipDirection: "w",
			"data-hotkey": "Escape",
			icon: XIcon,
			className: CodeNavSymbolNavigation_module_default.closeButton,
			onClick: onClose,
			variant: "invisible"
		})]
	});
});
SymbolPaneHeader.displayName = "SymbolPaneHeader";
function Shortcuts() {
	return /* @__PURE__ */ jsx(AllShortcutsEnabled, { children: /* @__PURE__ */ jsx("span", {
		className: CodeNavSymbolNavigation_module_default.shortcutsBox,
		children: /* @__PURE__ */ jsx("kbd", { children: "r" })
	}) });
}
Shortcuts.displayName = "Shortcuts";
function SymbolFilterInput({ filterText, ariaControls, ariaActivedescendant, autoFocusSearch, onClear, onChange, onKeyDown }) {
	const filterSymbolsRef = useRef(null);
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	useEffect(() => {
		if (autoFocusSearch) filterSymbolsRef.current?.focus();
	}, [autoFocusSearch]);
	useFocusSymbolPane(() => {
		filterSymbolsRef.current?.focus();
	});
	const debouncedSendStats = useMemo(() => debounce(() => {
		sendRepoKeyDownEvent("BLOB_SYMBOLS_MENU.FILTER_SYMBOLS");
	}, 400), [sendRepoKeyDownEvent]);
	useEffect(() => {
		return () => {
			debouncedSendStats.cancel();
		};
	}, [debouncedSendStats]);
	const hasFilterText = filterText !== "";
	const trailingAction = useMemo(() => {
		return hasFilterText ? /* @__PURE__ */ jsx(TextInput$1.Action, {
			onClick: onClear,
			icon: XCircleFillIcon,
			"aria-label": "Clear input",
			"data-testid": "clear-search",
			className: CodeNavSymbolNavigation_module_default.TextInput_Action
		}) : /* @__PURE__ */ jsx(Fragment$1, {});
	}, [hasFilterText, onClear]);
	const trailingVisual = useMemo(() => {
		return hasFilterText ? void 0 : Shortcuts;
	}, [hasFilterText]);
	const handleInputChange = useCallback((e) => {
		onChange(e.target.value);
		debouncedSendStats();
	}, [onChange, debouncedSendStats]);
	return /* @__PURE__ */ jsx(TextInput$1, {
		block: true,
		leadingVisual: FilterIconVisual,
		ref: filterSymbolsRef,
		trailingAction,
		trailingVisual,
		className: CodeNavSymbolNavigation_module_default.filterInput,
		placeholder: "Filter symbols",
		value: filterText,
		name: "Filter symbols",
		"aria-label": "Filter symbols",
		"aria-controls": ariaControls,
		"aria-expanded": "true",
		"aria-autocomplete": "list",
		"aria-activedescendant": ariaActivedescendant,
		onKeyDown,
		role: "combobox",
		onChange: handleInputChange
	});
}
SymbolFilterInput.displayName = "SymbolFilterInput";
var MemoizedSymbolFilterInput = React.memo(SymbolFilterInput);
MemoizedSymbolFilterInput.displayName = "MemoizedSymbolFilterInput";
function getFilteredCodeSymbols(searchTerm, codeSymbols) {
	const fuzzyQuery = searchTerm.replace(/\s/g, "");
	const key = (r) => {
		const score = fuzzyScore(r.name, fuzzyQuery);
		return score > 0 ? {
			score,
			text: r.name
		} : null;
	};
	return filterSort(codeSymbols, key, compare);
}
export { SymbolIndicator as n, symbolsHeaderId as r, CodeNavSymbolNavigation as t };
