import React from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
/**
* @deprecated Use the icon component directly from `@primer/octicons-react` instead
*/
var Octicon = /* @__PURE__ */ React.forwardRef((props, ref) => {
	const $ = c(7);
	let IconComponent;
	let rest;
	if ($[0] !== props) {
		({icon: IconComponent, ...rest} = props);
		$[0] = props;
		$[1] = IconComponent;
		$[2] = rest;
	} else {
		IconComponent = $[1];
		rest = $[2];
	}
	let t0;
	if ($[3] !== IconComponent || $[4] !== ref || $[5] !== rest) {
		t0 = /* @__PURE__ */ jsx(IconComponent, {
			...rest,
			ref
		});
		$[3] = IconComponent;
		$[4] = ref;
		$[5] = rest;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
});
export { Octicon as t };
