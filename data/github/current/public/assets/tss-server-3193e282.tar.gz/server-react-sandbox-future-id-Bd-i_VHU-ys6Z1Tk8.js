performance.mark("js-parse-end:server-react-sandbox-future-id-Bd-i_VHU-ys6Z1Tk8.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:react-sandbox-future-id-Bd-i_VHU.js");
var idLoader_createServerFn_handler = createServerRpc({
	id: "a64794e92b23f483ccd07044c4f01cab0f6dfdc92540bdffa335bb2ae630e5a0",
	name: "idLoader",
	filename: "src/routes/react_sandbox_future/react-sandbox-future-id.tsx"
}, (opts) => idLoader.__executeServer(opts));
var idLoader = createServerFn().inputValidator((data) => data).handler(idLoader_createServerFn_handler, async ({ data }) => {
	const { payload } = await fetchDataRouterMainQuery({
		path: `/_react_sandbox_future/${data.id}`,
		service: "dotcom"
	}, "reactSandboxFutureIdRoute");
	return payload;
});
export { idLoader_createServerFn_handler };
