import { i as VisuallyHidden } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { t as Announce } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { O as CheckIcon, an as IconButton, pi as Tooltip$1, tt as CopyIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsMounted } from "./server-use-is-mounted-BP8yEjoH-CZJ4mOOX.js";
import { t as copyText } from "./server-copy-ByVwvIP0-X47hrvCx.js";
import React, { useId } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var CopyToClipboardButton_module_default = { tooltip: "CopyToClipboardButton-module_oTc-Pa_tooltip" };
var copyConfirmationMsDelay = 2e3;
function CopyToClipboardButton(t0) {
	const $ = c(4);
	const { icon: t1, size: t2, onCopy, textToCopy, tooltipProps, variant: t3, ariaLabel, className, disabled, ...forwardProps } = t0;
	const icon = t1 === void 0 ? CopyIcon : t1;
	const size = t2 === void 0 ? "medium" : t2;
	const variant = t3 === void 0 ? "invisible" : t3;
	const [copied, setCopied] = React.useState(false);
	const isMounted = useIsMounted();
	let t4;
	if ($[0] !== isMounted || $[1] !== onCopy || $[2] !== textToCopy) {
		t4 = () => {
			setCopied(true);
			copyText(textToCopy);
			onCopy?.();
			setTimeout(() => isMounted() && setCopied(false), copyConfirmationMsDelay);
		};
		$[0] = isMounted;
		$[1] = onCopy;
		$[2] = textToCopy;
		$[3] = t4;
	} else t4 = $[3];
	const onClickCopy = t4;
	const label = ariaLabel ?? `Copy "${textToCopy}" to clipboard`;
	const visibleTooltipText = copied ? "Copied!" : label;
	const sharedProps = {
		size,
		variant,
		onClick: onClickCopy,
		icon: copied ? CheckIcon : icon,
		className: clsx(copied ? "color-fg-success" : void 0, className),
		...forwardProps
	};
	const tooltipId = useId();
	return disabled ? jsx(IconButton, {
		...sharedProps,
		"aria-label": label,
		disabled: true
	}) : jsxs(Fragment$1, { children: [copied && jsx(VisuallyHidden, { children: jsx(Announce, { children: "Copied!" }) }), jsx(Tooltip$1, {
		text: visibleTooltipText,
		"aria-label": label,
		type: "label",
		id: tooltipId,
		"aria-hidden": true,
		...tooltipProps,
		className: clsx(CopyToClipboardButton_module_default.tooltip, tooltipProps?.className),
		children: jsx(IconButton, {
			...sharedProps,
			"aria-labelledby": tooltipId
		})
	})] });
}
CopyToClipboardButton.displayName = "CopyToClipboardButton";
export { CopyToClipboardButton as t };
