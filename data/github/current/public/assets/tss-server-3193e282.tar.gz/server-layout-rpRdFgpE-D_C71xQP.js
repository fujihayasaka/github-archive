performance.mark("js-parse-end:server-layout-rpRdFgpE-D_C71xQP.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { a as getRequestHeader, i as getParsedRequestUrl } from "./server-request-C9AEnFH8-C42vJH27.js";
import { r as ServiceFetchError } from "./server-auth-CdSUgQ-0-DHDnXnPo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
import { n as throwDotcomPassThrough } from "./server-dotcom-pass-through-LDRpZga1-DQ9ZcIX-.js";
performance.mark("js-parse-end:layout-rpRdFgpE.js");
/**
* Returns headers that tell dotcom the original page URL context.
*
* When the UI Service fetches partial endpoints (e.g. `_layout`) server-side,
* dotcom needs to know the actual page route to resolve features like
* github.dev URL generation. The browser's page URL is forwarded as `Referer`,
* and `X-Requested-With` signals this is a partial/API-style request — matching
* what the browser sends for data router XHR fetches.
*
* On client-side navigation, the browser's Referer header contains the page URL.
* On SSR, there's no Referer, so we fall back to the request URL (which is the page URL during SSR).
*/
function getPageRefererHeaders() {
	try {
		return {
			Referer: getRequestHeader("referer") ?? getParsedRequestUrl().href,
			"X-Requested-With": "XMLHttpRequest"
		};
	} catch {
		return {};
	}
}
var codeViewLayoutServerFn_createServerFn_handler = createServerRpc({
	id: "b675b2614abc8b6e4bf1724b1e67a55a35682e23fb9ce0522bd2075187e4566a",
	name: "codeViewLayoutServerFn",
	filename: "src/routes/code-view/layout.tsx"
}, (opts) => codeViewLayoutServerFn.__executeServer(opts));
var codeViewLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewLayoutServerFn_createServerFn_handler, async ({ data }) => {
	try {
		const result = await fetchDataRouterMainQuery({
			path: data.pathname,
			service: "dotcom",
			headers: getPageRefererHeaders()
		}, "codeViewLayoutRoute");
		if (result.payload.repo.isEmpty) throwDotcomPassThrough("code_view_fallback");
		return result;
	} catch (error) {
		if (error instanceof ServiceFetchError) throwDotcomPassThrough("code_view_fallback");
		throw error;
	}
});
export { codeViewLayoutServerFn_createServerFn_handler };
