import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
var Panel_module_default = { Box: "Panel-module_13TKFW_Box" };
var Panel = ({ children, className, ...rest }) => {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(Panel_module_default.Box, className),
		...rest,
		children
	});
};
Panel.displayName = "Panel";
export { Panel as t };
