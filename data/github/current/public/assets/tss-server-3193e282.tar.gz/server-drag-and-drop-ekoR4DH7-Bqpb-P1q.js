import { n as __exportAll } from "./server-rolldown-runtime-BO2ueIC9.js";
import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { n as __exportAll$1, r as __reExport } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import { i as ButtonComponent, m as useRefObjectAsForwardedRef, s as KeybindingHint } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Xt as GrabberIcon, _n as KebabHorizontalIcon, an as IconButton, cn as InfoIcon, hi as TriangleDownIcon, n as ActionList, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useOnOutsideClick } from "./server-useOnOutsideClick-DKLusJ3D-nDHIGoWL.js";
import { t as useIsomorphicLayoutEffect$1 } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { o as useResizeObserver$1 } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { r as Select$1, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { v as merge } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as noop$1 } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { t as useLocalStorage } from "./server-use-local-storage-CXtv8Nou-C7yzA4lh.js";
import { t as DatePicker } from "./server-DatePicker-BGOTKwic-Dh0P8bLZ.js";
import React, { Fragment, cloneElement, createContext, createRef, forwardRef, memo, use, useCallback, useContext, useEffect, useId, useLayoutEffect, useMemo, useReducer, useRef, useState, useSyncExternalStore } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { createPortal, unstable_batchedUpdates } from "react-dom";
import { c } from "react/compiler-runtime";
var utilities_esm_exports = /* @__PURE__ */ __exportAll({
	CSS: () => CSS,
	add: () => add,
	canUseDOM: () => canUseDOM,
	findFirstFocusableNode: () => findFirstFocusableNode,
	getEventCoordinates: () => getEventCoordinates,
	getOwnerDocument: () => getOwnerDocument,
	getWindow: () => getWindow,
	hasViewportRelativeCoordinates: () => hasViewportRelativeCoordinates,
	isDocument: () => isDocument,
	isHTMLElement: () => isHTMLElement,
	isKeyboardEvent: () => isKeyboardEvent,
	isNode: () => isNode,
	isSVGElement: () => isSVGElement,
	isTouchEvent: () => isTouchEvent,
	isWindow: () => isWindow,
	subtract: () => subtract,
	useCombinedRefs: () => useCombinedRefs,
	useEvent: () => useEvent,
	useInterval: () => useInterval,
	useIsomorphicLayoutEffect: () => useIsomorphicLayoutEffect,
	useLatestValue: () => useLatestValue,
	useLazyMemo: () => useLazyMemo,
	useNodeRef: () => useNodeRef,
	usePrevious: () => usePrevious,
	useUniqueId: () => useUniqueId
});
function useCombinedRefs() {
	for (var _len = arguments.length, refs = new Array(_len), _key = 0; _key < _len; _key++) refs[_key] = arguments[_key];
	return useMemo(() => (node) => {
		refs.forEach((ref) => ref(node));
	}, refs);
}
var canUseDOM = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
function isWindow(element) {
	const elementString = Object.prototype.toString.call(element);
	return elementString === "[object Window]" || elementString === "[object global]";
}
function isNode(node) {
	return "nodeType" in node;
}
function getWindow(target) {
	var _target$ownerDocument, _target$ownerDocument2;
	if (!target) return window;
	if (isWindow(target)) return target;
	if (!isNode(target)) return window;
	return (_target$ownerDocument = (_target$ownerDocument2 = target.ownerDocument) == null ? void 0 : _target$ownerDocument2.defaultView) != null ? _target$ownerDocument : window;
}
function isDocument(node) {
	const { Document } = getWindow(node);
	return node instanceof Document;
}
function isHTMLElement(node) {
	if (isWindow(node)) return false;
	return node instanceof getWindow(node).HTMLElement;
}
function isSVGElement(node) {
	return node instanceof getWindow(node).SVGElement;
}
function getOwnerDocument(target) {
	if (!target) return document;
	if (isWindow(target)) return target.document;
	if (!isNode(target)) return document;
	if (isDocument(target)) return target;
	if (isHTMLElement(target) || isSVGElement(target)) return target.ownerDocument;
	return document;
}
/**
* A hook that resolves to useEffect on the server and useLayoutEffect on the client
* @param callback {function} Callback function that is invoked when the dependencies of the hook change
*/
var useIsomorphicLayoutEffect = canUseDOM ? useLayoutEffect : useEffect;
function useEvent(handler) {
	const handlerRef = useRef(handler);
	useIsomorphicLayoutEffect(() => {
		handlerRef.current = handler;
	});
	return useCallback(function() {
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		return handlerRef.current == null ? void 0 : handlerRef.current(...args);
	}, []);
}
function useInterval() {
	const intervalRef = useRef(null);
	return [useCallback((listener, duration) => {
		intervalRef.current = setInterval(listener, duration);
	}, []), useCallback(() => {
		if (intervalRef.current !== null) {
			clearInterval(intervalRef.current);
			intervalRef.current = null;
		}
	}, [])];
}
function useLatestValue(value, dependencies) {
	if (dependencies === void 0) dependencies = [value];
	const valueRef = useRef(value);
	useIsomorphicLayoutEffect(() => {
		if (valueRef.current !== value) valueRef.current = value;
	}, dependencies);
	return valueRef;
}
function useLazyMemo(callback, dependencies) {
	const valueRef = useRef();
	return useMemo(() => {
		const newValue = callback(valueRef.current);
		valueRef.current = newValue;
		return newValue;
	}, [...dependencies]);
}
function useNodeRef(onChange) {
	const onChangeHandler = useEvent(onChange);
	const node = useRef(null);
	return [node, useCallback((element) => {
		if (element !== node.current) onChangeHandler?.(element, node.current);
		node.current = element;
	}, [])];
}
function usePrevious(value) {
	const ref = useRef();
	useEffect(() => {
		ref.current = value;
	}, [value]);
	return ref.current;
}
var ids = {};
function useUniqueId(prefix, value) {
	return useMemo(() => {
		if (value) return value;
		const id = ids[prefix] == null ? 0 : ids[prefix] + 1;
		ids[prefix] = id;
		return prefix + "-" + id;
	}, [prefix, value]);
}
function createAdjustmentFn(modifier) {
	return function(object) {
		for (var _len = arguments.length, adjustments = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) adjustments[_key - 1] = arguments[_key];
		return adjustments.reduce((accumulator, adjustment) => {
			const entries = Object.entries(adjustment);
			for (const [key, valueAdjustment] of entries) {
				const value = accumulator[key];
				if (value != null) accumulator[key] = value + modifier * valueAdjustment;
			}
			return accumulator;
		}, { ...object });
	};
}
var add = /* @__PURE__ */ createAdjustmentFn(1);
var subtract = /* @__PURE__ */ createAdjustmentFn(-1);
function hasViewportRelativeCoordinates(event) {
	return "clientX" in event && "clientY" in event;
}
function isKeyboardEvent(event) {
	if (!event) return false;
	const { KeyboardEvent } = getWindow(event.target);
	return KeyboardEvent && event instanceof KeyboardEvent;
}
function isTouchEvent(event) {
	if (!event) return false;
	const { TouchEvent } = getWindow(event.target);
	return TouchEvent && event instanceof TouchEvent;
}
/**
* Returns the normalized x and y coordinates for mouse and touch events.
*/
function getEventCoordinates(event) {
	if (isTouchEvent(event)) {
		if (event.touches && event.touches.length) {
			const { clientX: x, clientY: y } = event.touches[0];
			return {
				x,
				y
			};
		} else if (event.changedTouches && event.changedTouches.length) {
			const { clientX: x, clientY: y } = event.changedTouches[0];
			return {
				x,
				y
			};
		}
	}
	if (hasViewportRelativeCoordinates(event)) return {
		x: event.clientX,
		y: event.clientY
	};
	return null;
}
var CSS = /* @__PURE__ */ Object.freeze({
	Translate: { toString(transform) {
		if (!transform) return;
		const { x, y } = transform;
		return "translate3d(" + (x ? Math.round(x) : 0) + "px, " + (y ? Math.round(y) : 0) + "px, 0)";
	} },
	Scale: { toString(transform) {
		if (!transform) return;
		const { scaleX, scaleY } = transform;
		return "scaleX(" + scaleX + ") scaleY(" + scaleY + ")";
	} },
	Transform: { toString(transform) {
		if (!transform) return;
		return [CSS.Translate.toString(transform), CSS.Scale.toString(transform)].join(" ");
	} },
	Transition: { toString(_ref) {
		let { property, duration, easing } = _ref;
		return property + " " + duration + "ms " + easing;
	} }
});
var SELECTOR = "a,frame,iframe,input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled),button:not(:disabled),*[tabindex]";
function findFirstFocusableNode(element) {
	if (element.matches(SELECTOR)) return element;
	return element.querySelector(SELECTOR);
}
var hiddenStyles = { display: "none" };
function HiddenText(_ref) {
	let { id, value } = _ref;
	return React.createElement("div", {
		id,
		style: hiddenStyles
	}, value);
}
function LiveRegion(_ref) {
	let { id, announcement, ariaLiveType = "assertive" } = _ref;
	return React.createElement("div", {
		id,
		style: {
			position: "fixed",
			width: 1,
			height: 1,
			margin: -1,
			border: 0,
			padding: 0,
			overflow: "hidden",
			clip: "rect(0 0 0 0)",
			clipPath: "inset(100%)",
			whiteSpace: "nowrap"
		},
		role: "status",
		"aria-live": ariaLiveType,
		"aria-atomic": true
	}, announcement);
}
function useAnnouncement() {
	const [announcement, setAnnouncement] = useState("");
	return {
		announce: useCallback((value) => {
			if (value != null) setAnnouncement(value);
		}, []),
		announcement
	};
}
var core_esm_exports = /* @__PURE__ */ __exportAll({
	AutoScrollActivator: () => AutoScrollActivator,
	DndContext: () => DndContext,
	DragOverlay: () => DragOverlay,
	KeyboardCode: () => KeyboardCode,
	KeyboardSensor: () => KeyboardSensor,
	MeasuringFrequency: () => MeasuringFrequency,
	MeasuringStrategy: () => MeasuringStrategy,
	MouseSensor: () => MouseSensor,
	PointerSensor: () => PointerSensor,
	TouchSensor: () => TouchSensor,
	TraversalOrder: () => TraversalOrder,
	applyModifiers: () => applyModifiers,
	closestCenter: () => closestCenter,
	closestCorners: () => closestCorners,
	defaultAnnouncements: () => defaultAnnouncements,
	defaultCoordinates: () => defaultCoordinates,
	defaultDropAnimation: () => defaultDropAnimationConfiguration,
	defaultDropAnimationSideEffects: () => defaultDropAnimationSideEffects,
	defaultScreenReaderInstructions: () => defaultScreenReaderInstructions,
	getClientRect: () => getClientRect,
	getFirstCollision: () => getFirstCollision,
	getScrollableAncestors: () => getScrollableAncestors,
	pointerWithin: () => pointerWithin,
	rectIntersection: () => rectIntersection,
	useDndContext: () => useDndContext,
	useDndMonitor: () => useDndMonitor,
	useDraggable: () => useDraggable,
	useDroppable: () => useDroppable,
	useSensor: () => useSensor,
	useSensors: () => useSensors
});
var DndMonitorContext = /* @__PURE__ */ createContext(null);
function useDndMonitor(listener) {
	const registerListener = useContext(DndMonitorContext);
	useEffect(() => {
		if (!registerListener) throw new Error("useDndMonitor must be used within a children of <DndContext>");
		return registerListener(listener);
	}, [listener, registerListener]);
}
function useDndMonitorProvider() {
	const [listeners] = useState(() => /* @__PURE__ */ new Set());
	const registerListener = useCallback((listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	}, [listeners]);
	return [useCallback((_ref) => {
		let { type, event } = _ref;
		listeners.forEach((listener) => {
			var _listener$type;
			return (_listener$type = listener[type]) == null ? void 0 : _listener$type.call(listener, event);
		});
	}, [listeners]), registerListener];
}
var defaultScreenReaderInstructions = { draggable: "\n    To pick up a draggable item, press the space bar.\n    While dragging, use the arrow keys to move the item.\n    Press space again to drop the item in its new position, or press escape to cancel.\n  " };
var defaultAnnouncements = {
	onDragStart(_ref) {
		let { active } = _ref;
		return "Picked up draggable item " + active.id + ".";
	},
	onDragOver(_ref2) {
		let { active, over } = _ref2;
		if (over) return "Draggable item " + active.id + " was moved over droppable area " + over.id + ".";
		return "Draggable item " + active.id + " is no longer over a droppable area.";
	},
	onDragEnd(_ref3) {
		let { active, over } = _ref3;
		if (over) return "Draggable item " + active.id + " was dropped over droppable area " + over.id;
		return "Draggable item " + active.id + " was dropped.";
	},
	onDragCancel(_ref4) {
		let { active } = _ref4;
		return "Dragging was cancelled. Draggable item " + active.id + " was dropped.";
	}
};
function Accessibility(_ref) {
	let { announcements = defaultAnnouncements, container, hiddenTextDescribedById, screenReaderInstructions = defaultScreenReaderInstructions } = _ref;
	const { announce, announcement } = useAnnouncement();
	const liveRegionId = useUniqueId("DndLiveRegion");
	const [mounted, setMounted] = useState(false);
	useEffect(() => {
		setMounted(true);
	}, []);
	useDndMonitor(useMemo(() => ({
		onDragStart(_ref2) {
			let { active } = _ref2;
			announce(announcements.onDragStart({ active }));
		},
		onDragMove(_ref3) {
			let { active, over } = _ref3;
			if (announcements.onDragMove) announce(announcements.onDragMove({
				active,
				over
			}));
		},
		onDragOver(_ref4) {
			let { active, over } = _ref4;
			announce(announcements.onDragOver({
				active,
				over
			}));
		},
		onDragEnd(_ref5) {
			let { active, over } = _ref5;
			announce(announcements.onDragEnd({
				active,
				over
			}));
		},
		onDragCancel(_ref6) {
			let { active, over } = _ref6;
			announce(announcements.onDragCancel({
				active,
				over
			}));
		}
	}), [announce, announcements]));
	if (!mounted) return null;
	const markup = React.createElement(React.Fragment, null, React.createElement(HiddenText, {
		id: hiddenTextDescribedById,
		value: screenReaderInstructions.draggable
	}), React.createElement(LiveRegion, {
		id: liveRegionId,
		announcement
	}));
	return container ? createPortal(markup, container) : markup;
}
var Action;
(function(Action) {
	Action["DragStart"] = "dragStart";
	Action["DragMove"] = "dragMove";
	Action["DragEnd"] = "dragEnd";
	Action["DragCancel"] = "dragCancel";
	Action["DragOver"] = "dragOver";
	Action["RegisterDroppable"] = "registerDroppable";
	Action["SetDroppableDisabled"] = "setDroppableDisabled";
	Action["UnregisterDroppable"] = "unregisterDroppable";
})(Action || (Action = {}));
function noop() {}
function useSensor(sensor, options) {
	return useMemo(() => ({
		sensor,
		options: options != null ? options : {}
	}), [sensor, options]);
}
function useSensors() {
	for (var _len = arguments.length, sensors = new Array(_len), _key = 0; _key < _len; _key++) sensors[_key] = arguments[_key];
	return useMemo(() => [...sensors].filter((sensor) => sensor != null), [...sensors]);
}
var defaultCoordinates = /* @__PURE__ */ Object.freeze({
	x: 0,
	y: 0
});
/**
* Returns the distance between two points
*/
function distanceBetween(p1, p2) {
	return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
}
function getRelativeTransformOrigin(event, rect) {
	const eventCoordinates = getEventCoordinates(event);
	if (!eventCoordinates) return "0 0";
	const transformOrigin = {
		x: (eventCoordinates.x - rect.left) / rect.width * 100,
		y: (eventCoordinates.y - rect.top) / rect.height * 100
	};
	return transformOrigin.x + "% " + transformOrigin.y + "%";
}
/**
* Sort collisions from smallest to greatest value
*/
function sortCollisionsAsc(_ref, _ref2) {
	let { data: { value: a } } = _ref;
	let { data: { value: b } } = _ref2;
	return a - b;
}
/**
* Sort collisions from greatest to smallest value
*/
function sortCollisionsDesc(_ref3, _ref4) {
	let { data: { value: a } } = _ref3;
	let { data: { value: b } } = _ref4;
	return b - a;
}
/**
* Returns the coordinates of the corners of a given rectangle:
* [TopLeft {x, y}, TopRight {x, y}, BottomLeft {x, y}, BottomRight {x, y}]
*/
function cornersOfRectangle(_ref5) {
	let { left, top, height, width } = _ref5;
	return [
		{
			x: left,
			y: top
		},
		{
			x: left + width,
			y: top
		},
		{
			x: left,
			y: top + height
		},
		{
			x: left + width,
			y: top + height
		}
	];
}
function getFirstCollision(collisions, property) {
	if (!collisions || collisions.length === 0) return null;
	const [firstCollision] = collisions;
	return property ? firstCollision[property] : firstCollision;
}
/**
* Returns the coordinates of the center of a given ClientRect
*/
function centerOfRectangle(rect, left, top) {
	if (left === void 0) left = rect.left;
	if (top === void 0) top = rect.top;
	return {
		x: left + rect.width * .5,
		y: top + rect.height * .5
	};
}
/**
* Returns the closest rectangles from an array of rectangles to the center of a given
* rectangle.
*/
var closestCenter = (_ref) => {
	let { collisionRect, droppableRects, droppableContainers } = _ref;
	const centerRect = centerOfRectangle(collisionRect, collisionRect.left, collisionRect.top);
	const collisions = [];
	for (const droppableContainer of droppableContainers) {
		const { id } = droppableContainer;
		const rect = droppableRects.get(id);
		if (rect) {
			const distBetween = distanceBetween(centerOfRectangle(rect), centerRect);
			collisions.push({
				id,
				data: {
					droppableContainer,
					value: distBetween
				}
			});
		}
	}
	return collisions.sort(sortCollisionsAsc);
};
/**
* Returns the closest rectangles from an array of rectangles to the corners of
* another rectangle.
*/
var closestCorners = (_ref) => {
	let { collisionRect, droppableRects, droppableContainers } = _ref;
	const corners = cornersOfRectangle(collisionRect);
	const collisions = [];
	for (const droppableContainer of droppableContainers) {
		const { id } = droppableContainer;
		const rect = droppableRects.get(id);
		if (rect) {
			const rectCorners = cornersOfRectangle(rect);
			const distances = corners.reduce((accumulator, corner, index) => {
				return accumulator + distanceBetween(rectCorners[index], corner);
			}, 0);
			const effectiveDistance = Number((distances / 4).toFixed(4));
			collisions.push({
				id,
				data: {
					droppableContainer,
					value: effectiveDistance
				}
			});
		}
	}
	return collisions.sort(sortCollisionsAsc);
};
/**
* Returns the intersecting rectangle area between two rectangles
*/
function getIntersectionRatio(entry, target) {
	const top = Math.max(target.top, entry.top);
	const left = Math.max(target.left, entry.left);
	const right = Math.min(target.left + target.width, entry.left + entry.width);
	const bottom = Math.min(target.top + target.height, entry.top + entry.height);
	const width = right - left;
	const height = bottom - top;
	if (left < right && top < bottom) {
		const targetArea = target.width * target.height;
		const entryArea = entry.width * entry.height;
		const intersectionArea = width * height;
		const intersectionRatio = intersectionArea / (targetArea + entryArea - intersectionArea);
		return Number(intersectionRatio.toFixed(4));
	}
	return 0;
}
/**
* Returns the rectangles that has the greatest intersection area with a given
* rectangle in an array of rectangles.
*/
var rectIntersection = (_ref) => {
	let { collisionRect, droppableRects, droppableContainers } = _ref;
	const collisions = [];
	for (const droppableContainer of droppableContainers) {
		const { id } = droppableContainer;
		const rect = droppableRects.get(id);
		if (rect) {
			const intersectionRatio = getIntersectionRatio(rect, collisionRect);
			if (intersectionRatio > 0) collisions.push({
				id,
				data: {
					droppableContainer,
					value: intersectionRatio
				}
			});
		}
	}
	return collisions.sort(sortCollisionsDesc);
};
/**
* Check if a given point is contained within a bounding rectangle
*/
function isPointWithinRect(point, rect) {
	const { top, left, bottom, right } = rect;
	return top <= point.y && point.y <= bottom && left <= point.x && point.x <= right;
}
/**
* Returns the rectangles that the pointer is hovering over
*/
var pointerWithin = (_ref) => {
	let { droppableContainers, droppableRects, pointerCoordinates } = _ref;
	if (!pointerCoordinates) return [];
	const collisions = [];
	for (const droppableContainer of droppableContainers) {
		const { id } = droppableContainer;
		const rect = droppableRects.get(id);
		if (rect && isPointWithinRect(pointerCoordinates, rect)) {
			const distances = cornersOfRectangle(rect).reduce((accumulator, corner) => {
				return accumulator + distanceBetween(pointerCoordinates, corner);
			}, 0);
			const effectiveDistance = Number((distances / 4).toFixed(4));
			collisions.push({
				id,
				data: {
					droppableContainer,
					value: effectiveDistance
				}
			});
		}
	}
	return collisions.sort(sortCollisionsAsc);
};
function adjustScale(transform, rect1, rect2) {
	return {
		...transform,
		scaleX: rect1 && rect2 ? rect1.width / rect2.width : 1,
		scaleY: rect1 && rect2 ? rect1.height / rect2.height : 1
	};
}
function getRectDelta(rect1, rect2) {
	return rect1 && rect2 ? {
		x: rect1.left - rect2.left,
		y: rect1.top - rect2.top
	} : defaultCoordinates;
}
function createRectAdjustmentFn(modifier) {
	return function adjustClientRect(rect) {
		for (var _len = arguments.length, adjustments = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) adjustments[_key - 1] = arguments[_key];
		return adjustments.reduce((acc, adjustment) => ({
			...acc,
			top: acc.top + modifier * adjustment.y,
			bottom: acc.bottom + modifier * adjustment.y,
			left: acc.left + modifier * adjustment.x,
			right: acc.right + modifier * adjustment.x
		}), { ...rect });
	};
}
var getAdjustedRect = /* @__PURE__ */ createRectAdjustmentFn(1);
function parseTransform(transform) {
	if (transform.startsWith("matrix3d(")) {
		const transformArray = transform.slice(9, -1).split(/, /);
		return {
			x: +transformArray[12],
			y: +transformArray[13],
			scaleX: +transformArray[0],
			scaleY: +transformArray[5]
		};
	} else if (transform.startsWith("matrix(")) {
		const transformArray = transform.slice(7, -1).split(/, /);
		return {
			x: +transformArray[4],
			y: +transformArray[5],
			scaleX: +transformArray[0],
			scaleY: +transformArray[3]
		};
	}
	return null;
}
function inverseTransform(rect, transform, transformOrigin) {
	const parsedTransform = parseTransform(transform);
	if (!parsedTransform) return rect;
	const { scaleX, scaleY, x: translateX, y: translateY } = parsedTransform;
	const x = rect.left - translateX - (1 - scaleX) * parseFloat(transformOrigin);
	const y = rect.top - translateY - (1 - scaleY) * parseFloat(transformOrigin.slice(transformOrigin.indexOf(" ") + 1));
	const w = scaleX ? rect.width / scaleX : rect.width;
	const h = scaleY ? rect.height / scaleY : rect.height;
	return {
		width: w,
		height: h,
		top: y,
		right: x + w,
		bottom: y + h,
		left: x
	};
}
var defaultOptions = { ignoreTransform: false };
/**
* Returns the bounding client rect of an element relative to the viewport.
*/
function getClientRect(element, options) {
	if (options === void 0) options = defaultOptions;
	let rect = element.getBoundingClientRect();
	if (options.ignoreTransform) {
		const { transform, transformOrigin } = getWindow(element).getComputedStyle(element);
		if (transform) rect = inverseTransform(rect, transform, transformOrigin);
	}
	const { top, left, width, height, bottom, right } = rect;
	return {
		top,
		left,
		width,
		height,
		bottom,
		right
	};
}
/**
* Returns the bounding client rect of an element relative to the viewport.
*
* @remarks
* The ClientRect returned by this method does not take into account transforms
* applied to the element it measures.
*
*/
function getTransformAgnosticClientRect(element) {
	return getClientRect(element, { ignoreTransform: true });
}
function getWindowClientRect(element) {
	const width = element.innerWidth;
	const height = element.innerHeight;
	return {
		top: 0,
		left: 0,
		right: width,
		bottom: height,
		width,
		height
	};
}
function isFixed(node, computedStyle) {
	if (computedStyle === void 0) computedStyle = getWindow(node).getComputedStyle(node);
	return computedStyle.position === "fixed";
}
function isScrollable(element, computedStyle) {
	if (computedStyle === void 0) computedStyle = getWindow(element).getComputedStyle(element);
	const overflowRegex = /(auto|scroll|overlay)/;
	return [
		"overflow",
		"overflowX",
		"overflowY"
	].some((property) => {
		const value = computedStyle[property];
		return typeof value === "string" ? overflowRegex.test(value) : false;
	});
}
function getScrollableAncestors(element, limit) {
	const scrollParents = [];
	function findScrollableAncestors(node) {
		if (limit != null && scrollParents.length >= limit) return scrollParents;
		if (!node) return scrollParents;
		if (isDocument(node) && node.scrollingElement != null && !scrollParents.includes(node.scrollingElement)) {
			scrollParents.push(node.scrollingElement);
			return scrollParents;
		}
		if (!isHTMLElement(node) || isSVGElement(node)) return scrollParents;
		if (scrollParents.includes(node)) return scrollParents;
		const computedStyle = getWindow(element).getComputedStyle(node);
		if (node !== element) {
			if (isScrollable(node, computedStyle)) scrollParents.push(node);
		}
		if (isFixed(node, computedStyle)) return scrollParents;
		return findScrollableAncestors(node.parentNode);
	}
	if (!element) return scrollParents;
	return findScrollableAncestors(element);
}
function getFirstScrollableAncestor(node) {
	const [firstScrollableAncestor] = getScrollableAncestors(node, 1);
	return firstScrollableAncestor != null ? firstScrollableAncestor : null;
}
function getScrollableElement(element) {
	if (!canUseDOM || !element) return null;
	if (isWindow(element)) return element;
	if (!isNode(element)) return null;
	if (isDocument(element) || element === getOwnerDocument(element).scrollingElement) return window;
	if (isHTMLElement(element)) return element;
	return null;
}
function getScrollXCoordinate(element) {
	if (isWindow(element)) return element.scrollX;
	return element.scrollLeft;
}
function getScrollYCoordinate(element) {
	if (isWindow(element)) return element.scrollY;
	return element.scrollTop;
}
function getScrollCoordinates(element) {
	return {
		x: getScrollXCoordinate(element),
		y: getScrollYCoordinate(element)
	};
}
var Direction;
(function(Direction) {
	Direction[Direction["Forward"] = 1] = "Forward";
	Direction[Direction["Backward"] = -1] = "Backward";
})(Direction || (Direction = {}));
function isDocumentScrollingElement(element) {
	if (!canUseDOM || !element) return false;
	return element === document.scrollingElement;
}
function getScrollPosition(scrollingContainer) {
	const minScroll = {
		x: 0,
		y: 0
	};
	const dimensions = isDocumentScrollingElement(scrollingContainer) ? {
		height: window.innerHeight,
		width: window.innerWidth
	} : {
		height: scrollingContainer.clientHeight,
		width: scrollingContainer.clientWidth
	};
	const maxScroll = {
		x: scrollingContainer.scrollWidth - dimensions.width,
		y: scrollingContainer.scrollHeight - dimensions.height
	};
	return {
		isTop: scrollingContainer.scrollTop <= minScroll.y,
		isLeft: scrollingContainer.scrollLeft <= minScroll.x,
		isBottom: scrollingContainer.scrollTop >= maxScroll.y,
		isRight: scrollingContainer.scrollLeft >= maxScroll.x,
		maxScroll,
		minScroll
	};
}
var defaultThreshold = {
	x: .2,
	y: .2
};
function getScrollDirectionAndSpeed(scrollContainer, scrollContainerRect, _ref, acceleration, thresholdPercentage) {
	let { top, left, right, bottom } = _ref;
	if (acceleration === void 0) acceleration = 10;
	if (thresholdPercentage === void 0) thresholdPercentage = defaultThreshold;
	const { isTop, isBottom, isLeft, isRight } = getScrollPosition(scrollContainer);
	const direction = {
		x: 0,
		y: 0
	};
	const speed = {
		x: 0,
		y: 0
	};
	const threshold = {
		height: scrollContainerRect.height * thresholdPercentage.y,
		width: scrollContainerRect.width * thresholdPercentage.x
	};
	if (!isTop && top <= scrollContainerRect.top + threshold.height) {
		direction.y = Direction.Backward;
		speed.y = acceleration * Math.abs((scrollContainerRect.top + threshold.height - top) / threshold.height);
	} else if (!isBottom && bottom >= scrollContainerRect.bottom - threshold.height) {
		direction.y = Direction.Forward;
		speed.y = acceleration * Math.abs((scrollContainerRect.bottom - threshold.height - bottom) / threshold.height);
	}
	if (!isRight && right >= scrollContainerRect.right - threshold.width) {
		direction.x = Direction.Forward;
		speed.x = acceleration * Math.abs((scrollContainerRect.right - threshold.width - right) / threshold.width);
	} else if (!isLeft && left <= scrollContainerRect.left + threshold.width) {
		direction.x = Direction.Backward;
		speed.x = acceleration * Math.abs((scrollContainerRect.left + threshold.width - left) / threshold.width);
	}
	return {
		direction,
		speed
	};
}
function getScrollElementRect(element) {
	if (element === document.scrollingElement) {
		const { innerWidth, innerHeight } = window;
		return {
			top: 0,
			left: 0,
			right: innerWidth,
			bottom: innerHeight,
			width: innerWidth,
			height: innerHeight
		};
	}
	const { top, left, right, bottom } = element.getBoundingClientRect();
	return {
		top,
		left,
		right,
		bottom,
		width: element.clientWidth,
		height: element.clientHeight
	};
}
function getScrollOffsets(scrollableAncestors) {
	return scrollableAncestors.reduce((acc, node) => {
		return add(acc, getScrollCoordinates(node));
	}, defaultCoordinates);
}
function getScrollXOffset(scrollableAncestors) {
	return scrollableAncestors.reduce((acc, node) => {
		return acc + getScrollXCoordinate(node);
	}, 0);
}
function getScrollYOffset(scrollableAncestors) {
	return scrollableAncestors.reduce((acc, node) => {
		return acc + getScrollYCoordinate(node);
	}, 0);
}
function scrollIntoViewIfNeeded(element, measure) {
	if (measure === void 0) measure = getClientRect;
	if (!element) return;
	const { top, left, bottom, right } = measure(element);
	if (!getFirstScrollableAncestor(element)) return;
	if (bottom <= 0 || right <= 0 || top >= window.innerHeight || left >= window.innerWidth) element.scrollIntoView({
		block: "center",
		inline: "center"
	});
}
var properties = [[
	"x",
	["left", "right"],
	getScrollXOffset
], [
	"y",
	["top", "bottom"],
	getScrollYOffset
]];
var Rect = class {
	constructor(rect, element) {
		this.rect = void 0;
		this.width = void 0;
		this.height = void 0;
		this.top = void 0;
		this.bottom = void 0;
		this.right = void 0;
		this.left = void 0;
		const scrollableAncestors = getScrollableAncestors(element);
		const scrollOffsets = getScrollOffsets(scrollableAncestors);
		this.rect = { ...rect };
		this.width = rect.width;
		this.height = rect.height;
		for (const [axis, keys, getScrollOffset] of properties) for (const key of keys) Object.defineProperty(this, key, {
			get: () => {
				const currentOffsets = getScrollOffset(scrollableAncestors);
				const scrollOffsetsDeltla = scrollOffsets[axis] - currentOffsets;
				return this.rect[key] + scrollOffsetsDeltla;
			},
			enumerable: true
		});
		Object.defineProperty(this, "rect", { enumerable: false });
	}
};
var Listeners = class {
	constructor(target) {
		this.target = void 0;
		this.listeners = [];
		this.removeAll = () => {
			this.listeners.forEach((listener) => {
				var _this$target;
				return (_this$target = this.target) == null ? void 0 : _this$target.removeEventListener(...listener);
			});
		};
		this.target = target;
	}
	add(eventName, handler, options) {
		var _this$target2;
		(_this$target2 = this.target) == null || _this$target2.addEventListener(eventName, handler, options);
		this.listeners.push([
			eventName,
			handler,
			options
		]);
	}
};
function getEventListenerTarget(target) {
	const { EventTarget } = getWindow(target);
	return target instanceof EventTarget ? target : getOwnerDocument(target);
}
function hasExceededDistance(delta, measurement) {
	const dx = Math.abs(delta.x);
	const dy = Math.abs(delta.y);
	if (typeof measurement === "number") return Math.sqrt(dx ** 2 + dy ** 2) > measurement;
	if ("x" in measurement && "y" in measurement) return dx > measurement.x && dy > measurement.y;
	if ("x" in measurement) return dx > measurement.x;
	if ("y" in measurement) return dy > measurement.y;
	return false;
}
var EventName;
(function(EventName) {
	EventName["Click"] = "click";
	EventName["DragStart"] = "dragstart";
	EventName["Keydown"] = "keydown";
	EventName["ContextMenu"] = "contextmenu";
	EventName["Resize"] = "resize";
	EventName["SelectionChange"] = "selectionchange";
	EventName["VisibilityChange"] = "visibilitychange";
})(EventName || (EventName = {}));
function preventDefault(event) {
	event.preventDefault();
}
function stopPropagation(event) {
	event.stopPropagation();
}
var KeyboardCode;
(function(KeyboardCode) {
	KeyboardCode["Space"] = "Space";
	KeyboardCode["Down"] = "ArrowDown";
	KeyboardCode["Right"] = "ArrowRight";
	KeyboardCode["Left"] = "ArrowLeft";
	KeyboardCode["Up"] = "ArrowUp";
	KeyboardCode["Esc"] = "Escape";
	KeyboardCode["Enter"] = "Enter";
})(KeyboardCode || (KeyboardCode = {}));
var defaultKeyboardCodes$1 = {
	start: [KeyboardCode.Space, KeyboardCode.Enter],
	cancel: [KeyboardCode.Esc],
	end: [KeyboardCode.Space, KeyboardCode.Enter]
};
var defaultKeyboardCoordinateGetter = (event, _ref) => {
	let { currentCoordinates } = _ref;
	switch (event.code) {
		case KeyboardCode.Right: return {
			...currentCoordinates,
			x: currentCoordinates.x + 25
		};
		case KeyboardCode.Left: return {
			...currentCoordinates,
			x: currentCoordinates.x - 25
		};
		case KeyboardCode.Down: return {
			...currentCoordinates,
			y: currentCoordinates.y + 25
		};
		case KeyboardCode.Up: return {
			...currentCoordinates,
			y: currentCoordinates.y - 25
		};
	}
};
var KeyboardSensor = class {
	constructor(props) {
		this.props = void 0;
		this.autoScrollEnabled = false;
		this.referenceCoordinates = void 0;
		this.listeners = void 0;
		this.windowListeners = void 0;
		this.props = props;
		const { event: { target } } = props;
		this.props = props;
		this.listeners = new Listeners(getOwnerDocument(target));
		this.windowListeners = new Listeners(getWindow(target));
		this.handleKeyDown = this.handleKeyDown.bind(this);
		this.handleCancel = this.handleCancel.bind(this);
		this.attach();
	}
	attach() {
		this.handleStart();
		this.windowListeners.add(EventName.Resize, this.handleCancel);
		this.windowListeners.add(EventName.VisibilityChange, this.handleCancel);
		setTimeout(() => this.listeners.add(EventName.Keydown, this.handleKeyDown));
	}
	handleStart() {
		const { activeNode, onStart } = this.props;
		const node = activeNode.node.current;
		if (node) scrollIntoViewIfNeeded(node);
		onStart(defaultCoordinates);
	}
	handleKeyDown(event) {
		if (isKeyboardEvent(event)) {
			const { active, context, options } = this.props;
			const { keyboardCodes = defaultKeyboardCodes$1, coordinateGetter = defaultKeyboardCoordinateGetter, scrollBehavior = "smooth" } = options;
			const { code } = event;
			if (keyboardCodes.end.includes(code)) {
				this.handleEnd(event);
				return;
			}
			if (keyboardCodes.cancel.includes(code)) {
				this.handleCancel(event);
				return;
			}
			const { collisionRect } = context.current;
			const currentCoordinates = collisionRect ? {
				x: collisionRect.left,
				y: collisionRect.top
			} : defaultCoordinates;
			if (!this.referenceCoordinates) this.referenceCoordinates = currentCoordinates;
			const newCoordinates = coordinateGetter(event, {
				active,
				context: context.current,
				currentCoordinates
			});
			if (newCoordinates) {
				const coordinatesDelta = subtract(newCoordinates, currentCoordinates);
				const scrollDelta = {
					x: 0,
					y: 0
				};
				const { scrollableAncestors } = context.current;
				for (const scrollContainer of scrollableAncestors) {
					const direction = event.code;
					const { isTop, isRight, isLeft, isBottom, maxScroll, minScroll } = getScrollPosition(scrollContainer);
					const scrollElementRect = getScrollElementRect(scrollContainer);
					const clampedCoordinates = {
						x: Math.min(direction === KeyboardCode.Right ? scrollElementRect.right - scrollElementRect.width / 2 : scrollElementRect.right, Math.max(direction === KeyboardCode.Right ? scrollElementRect.left : scrollElementRect.left + scrollElementRect.width / 2, newCoordinates.x)),
						y: Math.min(direction === KeyboardCode.Down ? scrollElementRect.bottom - scrollElementRect.height / 2 : scrollElementRect.bottom, Math.max(direction === KeyboardCode.Down ? scrollElementRect.top : scrollElementRect.top + scrollElementRect.height / 2, newCoordinates.y))
					};
					const canScrollX = direction === KeyboardCode.Right && !isRight || direction === KeyboardCode.Left && !isLeft;
					const canScrollY = direction === KeyboardCode.Down && !isBottom || direction === KeyboardCode.Up && !isTop;
					if (canScrollX && clampedCoordinates.x !== newCoordinates.x) {
						const newScrollCoordinates = scrollContainer.scrollLeft + coordinatesDelta.x;
						const canScrollToNewCoordinates = direction === KeyboardCode.Right && newScrollCoordinates <= maxScroll.x || direction === KeyboardCode.Left && newScrollCoordinates >= minScroll.x;
						if (canScrollToNewCoordinates && !coordinatesDelta.y) {
							scrollContainer.scrollTo({
								left: newScrollCoordinates,
								behavior: scrollBehavior
							});
							return;
						}
						if (canScrollToNewCoordinates) scrollDelta.x = scrollContainer.scrollLeft - newScrollCoordinates;
						else scrollDelta.x = direction === KeyboardCode.Right ? scrollContainer.scrollLeft - maxScroll.x : scrollContainer.scrollLeft - minScroll.x;
						if (scrollDelta.x) scrollContainer.scrollBy({
							left: -scrollDelta.x,
							behavior: scrollBehavior
						});
						break;
					} else if (canScrollY && clampedCoordinates.y !== newCoordinates.y) {
						const newScrollCoordinates = scrollContainer.scrollTop + coordinatesDelta.y;
						const canScrollToNewCoordinates = direction === KeyboardCode.Down && newScrollCoordinates <= maxScroll.y || direction === KeyboardCode.Up && newScrollCoordinates >= minScroll.y;
						if (canScrollToNewCoordinates && !coordinatesDelta.x) {
							scrollContainer.scrollTo({
								top: newScrollCoordinates,
								behavior: scrollBehavior
							});
							return;
						}
						if (canScrollToNewCoordinates) scrollDelta.y = scrollContainer.scrollTop - newScrollCoordinates;
						else scrollDelta.y = direction === KeyboardCode.Down ? scrollContainer.scrollTop - maxScroll.y : scrollContainer.scrollTop - minScroll.y;
						if (scrollDelta.y) scrollContainer.scrollBy({
							top: -scrollDelta.y,
							behavior: scrollBehavior
						});
						break;
					}
				}
				this.handleMove(event, add(subtract(newCoordinates, this.referenceCoordinates), scrollDelta));
			}
		}
	}
	handleMove(event, coordinates) {
		const { onMove } = this.props;
		event.preventDefault();
		onMove(coordinates);
	}
	handleEnd(event) {
		const { onEnd } = this.props;
		event.preventDefault();
		this.detach();
		onEnd();
	}
	handleCancel(event) {
		const { onCancel } = this.props;
		event.preventDefault();
		this.detach();
		onCancel();
	}
	detach() {
		this.listeners.removeAll();
		this.windowListeners.removeAll();
	}
};
KeyboardSensor.activators = [{
	eventName: "onKeyDown",
	handler: (event, _ref, _ref2) => {
		let { keyboardCodes = defaultKeyboardCodes$1, onActivation } = _ref;
		let { active } = _ref2;
		const { code } = event.nativeEvent;
		if (keyboardCodes.start.includes(code)) {
			const activator = active.activatorNode.current;
			if (activator && event.target !== activator) return false;
			event.preventDefault();
			onActivation?.({ event: event.nativeEvent });
			return true;
		}
		return false;
	}
}];
function isDistanceConstraint(constraint) {
	return Boolean(constraint && "distance" in constraint);
}
function isDelayConstraint(constraint) {
	return Boolean(constraint && "delay" in constraint);
}
var AbstractPointerSensor = class {
	constructor(props, events, listenerTarget) {
		var _getEventCoordinates;
		if (listenerTarget === void 0) listenerTarget = getEventListenerTarget(props.event.target);
		this.props = void 0;
		this.events = void 0;
		this.autoScrollEnabled = true;
		this.document = void 0;
		this.activated = false;
		this.initialCoordinates = void 0;
		this.timeoutId = null;
		this.listeners = void 0;
		this.documentListeners = void 0;
		this.windowListeners = void 0;
		this.props = props;
		this.events = events;
		const { event } = props;
		const { target } = event;
		this.props = props;
		this.events = events;
		this.document = getOwnerDocument(target);
		this.documentListeners = new Listeners(this.document);
		this.listeners = new Listeners(listenerTarget);
		this.windowListeners = new Listeners(getWindow(target));
		this.initialCoordinates = (_getEventCoordinates = getEventCoordinates(event)) != null ? _getEventCoordinates : defaultCoordinates;
		this.handleStart = this.handleStart.bind(this);
		this.handleMove = this.handleMove.bind(this);
		this.handleEnd = this.handleEnd.bind(this);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleKeydown = this.handleKeydown.bind(this);
		this.removeTextSelection = this.removeTextSelection.bind(this);
		this.attach();
	}
	attach() {
		const { events, props: { options: { activationConstraint, bypassActivationConstraint } } } = this;
		this.listeners.add(events.move.name, this.handleMove, { passive: false });
		this.listeners.add(events.end.name, this.handleEnd);
		this.windowListeners.add(EventName.Resize, this.handleCancel);
		this.windowListeners.add(EventName.DragStart, preventDefault);
		this.windowListeners.add(EventName.VisibilityChange, this.handleCancel);
		this.windowListeners.add(EventName.ContextMenu, preventDefault);
		this.documentListeners.add(EventName.Keydown, this.handleKeydown);
		if (activationConstraint) {
			if (bypassActivationConstraint != null && bypassActivationConstraint({
				event: this.props.event,
				activeNode: this.props.activeNode,
				options: this.props.options
			})) return this.handleStart();
			if (isDelayConstraint(activationConstraint)) {
				this.timeoutId = setTimeout(this.handleStart, activationConstraint.delay);
				return;
			}
			if (isDistanceConstraint(activationConstraint)) return;
		}
		this.handleStart();
	}
	detach() {
		this.listeners.removeAll();
		this.windowListeners.removeAll();
		setTimeout(this.documentListeners.removeAll, 50);
		if (this.timeoutId !== null) {
			clearTimeout(this.timeoutId);
			this.timeoutId = null;
		}
	}
	handleStart() {
		const { initialCoordinates } = this;
		const { onStart } = this.props;
		if (initialCoordinates) {
			this.activated = true;
			this.documentListeners.add(EventName.Click, stopPropagation, { capture: true });
			this.removeTextSelection();
			this.documentListeners.add(EventName.SelectionChange, this.removeTextSelection);
			onStart(initialCoordinates);
		}
	}
	handleMove(event) {
		var _getEventCoordinates2;
		const { activated, initialCoordinates, props } = this;
		const { onMove, options: { activationConstraint } } = props;
		if (!initialCoordinates) return;
		const coordinates = (_getEventCoordinates2 = getEventCoordinates(event)) != null ? _getEventCoordinates2 : defaultCoordinates;
		const delta = subtract(initialCoordinates, coordinates);
		if (!activated && activationConstraint) {
			if (isDistanceConstraint(activationConstraint)) {
				if (activationConstraint.tolerance != null && hasExceededDistance(delta, activationConstraint.tolerance)) return this.handleCancel();
				if (hasExceededDistance(delta, activationConstraint.distance)) return this.handleStart();
			}
			if (isDelayConstraint(activationConstraint)) {
				if (hasExceededDistance(delta, activationConstraint.tolerance)) return this.handleCancel();
			}
			return;
		}
		if (event.cancelable) event.preventDefault();
		onMove(coordinates);
	}
	handleEnd() {
		const { onEnd } = this.props;
		this.detach();
		onEnd();
	}
	handleCancel() {
		const { onCancel } = this.props;
		this.detach();
		onCancel();
	}
	handleKeydown(event) {
		if (event.code === KeyboardCode.Esc) this.handleCancel();
	}
	removeTextSelection() {
		var _this$document$getSel;
		(_this$document$getSel = this.document.getSelection()) == null || _this$document$getSel.removeAllRanges();
	}
};
var events = {
	move: { name: "pointermove" },
	end: { name: "pointerup" }
};
var PointerSensor = class extends AbstractPointerSensor {
	constructor(props) {
		const { event } = props;
		const listenerTarget = getOwnerDocument(event.target);
		super(props, events, listenerTarget);
	}
};
PointerSensor.activators = [{
	eventName: "onPointerDown",
	handler: (_ref, _ref2) => {
		let { nativeEvent: event } = _ref;
		let { onActivation } = _ref2;
		if (!event.isPrimary || event.button !== 0) return false;
		onActivation?.({ event });
		return true;
	}
}];
var events$1 = {
	move: { name: "mousemove" },
	end: { name: "mouseup" }
};
var MouseButton;
(function(MouseButton) {
	MouseButton[MouseButton["RightClick"] = 2] = "RightClick";
})(MouseButton || (MouseButton = {}));
var MouseSensor = class extends AbstractPointerSensor {
	constructor(props) {
		super(props, events$1, getOwnerDocument(props.event.target));
	}
};
MouseSensor.activators = [{
	eventName: "onMouseDown",
	handler: (_ref, _ref2) => {
		let { nativeEvent: event } = _ref;
		let { onActivation } = _ref2;
		if (event.button === MouseButton.RightClick) return false;
		onActivation?.({ event });
		return true;
	}
}];
var events$2 = {
	move: { name: "touchmove" },
	end: { name: "touchend" }
};
var TouchSensor = class extends AbstractPointerSensor {
	constructor(props) {
		super(props, events$2);
	}
	static setup() {
		window.addEventListener(events$2.move.name, noop, {
			capture: false,
			passive: false
		});
		return function teardown() {
			window.removeEventListener(events$2.move.name, noop);
		};
		function noop() {}
	}
};
TouchSensor.activators = [{
	eventName: "onTouchStart",
	handler: (_ref, _ref2) => {
		let { nativeEvent: event } = _ref;
		let { onActivation } = _ref2;
		const { touches } = event;
		if (touches.length > 1) return false;
		onActivation?.({ event });
		return true;
	}
}];
var AutoScrollActivator;
(function(AutoScrollActivator) {
	AutoScrollActivator[AutoScrollActivator["Pointer"] = 0] = "Pointer";
	AutoScrollActivator[AutoScrollActivator["DraggableRect"] = 1] = "DraggableRect";
})(AutoScrollActivator || (AutoScrollActivator = {}));
var TraversalOrder;
(function(TraversalOrder) {
	TraversalOrder[TraversalOrder["TreeOrder"] = 0] = "TreeOrder";
	TraversalOrder[TraversalOrder["ReversedTreeOrder"] = 1] = "ReversedTreeOrder";
})(TraversalOrder || (TraversalOrder = {}));
function useAutoScroller(_ref) {
	let { acceleration, activator = AutoScrollActivator.Pointer, canScroll, draggingRect, enabled, interval = 5, order = TraversalOrder.TreeOrder, pointerCoordinates, scrollableAncestors, scrollableAncestorRects, delta, threshold } = _ref;
	const scrollIntent = useScrollIntent({
		delta,
		disabled: !enabled
	});
	const [setAutoScrollInterval, clearAutoScrollInterval] = useInterval();
	const scrollSpeed = useRef({
		x: 0,
		y: 0
	});
	const scrollDirection = useRef({
		x: 0,
		y: 0
	});
	const rect = useMemo(() => {
		switch (activator) {
			case AutoScrollActivator.Pointer: return pointerCoordinates ? {
				top: pointerCoordinates.y,
				bottom: pointerCoordinates.y,
				left: pointerCoordinates.x,
				right: pointerCoordinates.x
			} : null;
			case AutoScrollActivator.DraggableRect: return draggingRect;
		}
	}, [
		activator,
		draggingRect,
		pointerCoordinates
	]);
	const scrollContainerRef = useRef(null);
	const autoScroll = useCallback(() => {
		const scrollContainer = scrollContainerRef.current;
		if (!scrollContainer) return;
		const scrollLeft = scrollSpeed.current.x * scrollDirection.current.x;
		const scrollTop = scrollSpeed.current.y * scrollDirection.current.y;
		scrollContainer.scrollBy(scrollLeft, scrollTop);
	}, []);
	const sortedScrollableAncestors = useMemo(() => order === TraversalOrder.TreeOrder ? [...scrollableAncestors].reverse() : scrollableAncestors, [order, scrollableAncestors]);
	useEffect(() => {
		if (!enabled || !scrollableAncestors.length || !rect) {
			clearAutoScrollInterval();
			return;
		}
		for (const scrollContainer of sortedScrollableAncestors) {
			if ((canScroll == null ? void 0 : canScroll(scrollContainer)) === false) continue;
			const scrollContainerRect = scrollableAncestorRects[scrollableAncestors.indexOf(scrollContainer)];
			if (!scrollContainerRect) continue;
			const { direction, speed } = getScrollDirectionAndSpeed(scrollContainer, scrollContainerRect, rect, acceleration, threshold);
			for (const axis of ["x", "y"]) if (!scrollIntent[axis][direction[axis]]) {
				speed[axis] = 0;
				direction[axis] = 0;
			}
			if (speed.x > 0 || speed.y > 0) {
				clearAutoScrollInterval();
				scrollContainerRef.current = scrollContainer;
				setAutoScrollInterval(autoScroll, interval);
				scrollSpeed.current = speed;
				scrollDirection.current = direction;
				return;
			}
		}
		scrollSpeed.current = {
			x: 0,
			y: 0
		};
		scrollDirection.current = {
			x: 0,
			y: 0
		};
		clearAutoScrollInterval();
	}, [
		acceleration,
		autoScroll,
		canScroll,
		clearAutoScrollInterval,
		enabled,
		interval,
		JSON.stringify(rect),
		JSON.stringify(scrollIntent),
		setAutoScrollInterval,
		scrollableAncestors,
		sortedScrollableAncestors,
		scrollableAncestorRects,
		JSON.stringify(threshold)
	]);
}
var defaultScrollIntent = {
	x: {
		[Direction.Backward]: false,
		[Direction.Forward]: false
	},
	y: {
		[Direction.Backward]: false,
		[Direction.Forward]: false
	}
};
function useScrollIntent(_ref2) {
	let { delta, disabled } = _ref2;
	const previousDelta = usePrevious(delta);
	return useLazyMemo((previousIntent) => {
		if (disabled || !previousDelta || !previousIntent) return defaultScrollIntent;
		const direction = {
			x: Math.sign(delta.x - previousDelta.x),
			y: Math.sign(delta.y - previousDelta.y)
		};
		return {
			x: {
				[Direction.Backward]: previousIntent.x[Direction.Backward] || direction.x === -1,
				[Direction.Forward]: previousIntent.x[Direction.Forward] || direction.x === 1
			},
			y: {
				[Direction.Backward]: previousIntent.y[Direction.Backward] || direction.y === -1,
				[Direction.Forward]: previousIntent.y[Direction.Forward] || direction.y === 1
			}
		};
	}, [
		disabled,
		delta,
		previousDelta
	]);
}
function useCachedNode(draggableNodes, id) {
	const draggableNode = id !== null ? draggableNodes.get(id) : void 0;
	const node = draggableNode ? draggableNode.node.current : null;
	return useLazyMemo((cachedNode) => {
		var _ref;
		if (id === null) return null;
		return (_ref = node != null ? node : cachedNode) != null ? _ref : null;
	}, [node, id]);
}
function useCombineActivators(sensors, getSyntheticHandler) {
	return useMemo(() => sensors.reduce((accumulator, sensor) => {
		const { sensor: Sensor } = sensor;
		const sensorActivators = Sensor.activators.map((activator) => ({
			eventName: activator.eventName,
			handler: getSyntheticHandler(activator.handler, sensor)
		}));
		return [...accumulator, ...sensorActivators];
	}, []), [sensors, getSyntheticHandler]);
}
var MeasuringStrategy;
(function(MeasuringStrategy) {
	MeasuringStrategy[MeasuringStrategy["Always"] = 0] = "Always";
	MeasuringStrategy[MeasuringStrategy["BeforeDragging"] = 1] = "BeforeDragging";
	MeasuringStrategy[MeasuringStrategy["WhileDragging"] = 2] = "WhileDragging";
})(MeasuringStrategy || (MeasuringStrategy = {}));
var MeasuringFrequency;
(function(MeasuringFrequency) {
	MeasuringFrequency["Optimized"] = "optimized";
})(MeasuringFrequency || (MeasuringFrequency = {}));
var defaultValue = /* @__PURE__ */ new Map();
function useDroppableMeasuring(containers, _ref) {
	let { dragging, dependencies, config } = _ref;
	const [queue, setQueue] = useState(null);
	const { frequency, measure, strategy } = config;
	const containersRef = useRef(containers);
	const disabled = isDisabled();
	const disabledRef = useLatestValue(disabled);
	const measureDroppableContainers = useCallback(function(ids) {
		if (ids === void 0) ids = [];
		if (disabledRef.current) return;
		setQueue((value) => {
			if (value === null) return ids;
			return value.concat(ids.filter((id) => !value.includes(id)));
		});
	}, [disabledRef]);
	const timeoutId = useRef(null);
	const droppableRects = useLazyMemo((previousValue) => {
		if (disabled && !dragging) return defaultValue;
		if (!previousValue || previousValue === defaultValue || containersRef.current !== containers || queue != null) {
			const map = /* @__PURE__ */ new Map();
			for (let container of containers) {
				if (!container) continue;
				if (queue && queue.length > 0 && !queue.includes(container.id) && container.rect.current) {
					map.set(container.id, container.rect.current);
					continue;
				}
				const node = container.node.current;
				const rect = node ? new Rect(measure(node), node) : null;
				container.rect.current = rect;
				if (rect) map.set(container.id, rect);
			}
			return map;
		}
		return previousValue;
	}, [
		containers,
		queue,
		dragging,
		disabled,
		measure
	]);
	useEffect(() => {
		containersRef.current = containers;
	}, [containers]);
	useEffect(() => {
		if (disabled) return;
		measureDroppableContainers();
	}, [dragging, disabled]);
	useEffect(() => {
		if (queue && queue.length > 0) setQueue(null);
	}, [JSON.stringify(queue)]);
	useEffect(() => {
		if (disabled || typeof frequency !== "number" || timeoutId.current !== null) return;
		timeoutId.current = setTimeout(() => {
			measureDroppableContainers();
			timeoutId.current = null;
		}, frequency);
	}, [
		frequency,
		disabled,
		measureDroppableContainers,
		...dependencies
	]);
	return {
		droppableRects,
		measureDroppableContainers,
		measuringScheduled: queue != null
	};
	function isDisabled() {
		switch (strategy) {
			case MeasuringStrategy.Always: return false;
			case MeasuringStrategy.BeforeDragging: return dragging;
			default: return !dragging;
		}
	}
}
function useInitialValue(value, computeFn) {
	return useLazyMemo((previousValue) => {
		if (!value) return null;
		if (previousValue) return previousValue;
		return typeof computeFn === "function" ? computeFn(value) : value;
	}, [computeFn, value]);
}
function useInitialRect(node, measure) {
	return useInitialValue(node, measure);
}
/**
* Returns a new MutationObserver instance.
* If `MutationObserver` is undefined in the execution environment, returns `undefined`.
*/
function useMutationObserver(_ref) {
	let { callback, disabled } = _ref;
	const handleMutations = useEvent(callback);
	const mutationObserver = useMemo(() => {
		if (disabled || typeof window === "undefined" || typeof window.MutationObserver === "undefined") return;
		const { MutationObserver } = window;
		return new MutationObserver(handleMutations);
	}, [handleMutations, disabled]);
	useEffect(() => {
		return () => mutationObserver == null ? void 0 : mutationObserver.disconnect();
	}, [mutationObserver]);
	return mutationObserver;
}
/**
* Returns a new ResizeObserver instance bound to the `onResize` callback.
* If `ResizeObserver` is undefined in the execution environment, returns `undefined`.
*/
function useResizeObserver(_ref) {
	let { callback, disabled } = _ref;
	const handleResize = useEvent(callback);
	const resizeObserver = useMemo(() => {
		if (disabled || typeof window === "undefined" || typeof window.ResizeObserver === "undefined") return;
		const { ResizeObserver } = window;
		return new ResizeObserver(handleResize);
	}, [disabled]);
	useEffect(() => {
		return () => resizeObserver == null ? void 0 : resizeObserver.disconnect();
	}, [resizeObserver]);
	return resizeObserver;
}
function defaultMeasure(element) {
	return new Rect(getClientRect(element), element);
}
function useRect(element, measure, fallbackRect) {
	if (measure === void 0) measure = defaultMeasure;
	const [rect, measureRect] = useReducer(reducer, null);
	const mutationObserver = useMutationObserver({ callback(records) {
		if (!element) return;
		for (const record of records) {
			const { type, target } = record;
			if (type === "childList" && target instanceof HTMLElement && target.contains(element)) {
				measureRect();
				break;
			}
		}
	} });
	const resizeObserver = useResizeObserver({ callback: measureRect });
	useIsomorphicLayoutEffect(() => {
		measureRect();
		if (element) {
			resizeObserver?.observe(element);
			mutationObserver?.observe(document.body, {
				childList: true,
				subtree: true
			});
		} else {
			resizeObserver?.disconnect();
			mutationObserver?.disconnect();
		}
	}, [element]);
	return rect;
	function reducer(currentRect) {
		if (!element) return null;
		if (element.isConnected === false) {
			var _ref;
			return (_ref = currentRect != null ? currentRect : fallbackRect) != null ? _ref : null;
		}
		const newRect = measure(element);
		if (JSON.stringify(currentRect) === JSON.stringify(newRect)) return currentRect;
		return newRect;
	}
}
function useRectDelta(rect) {
	return getRectDelta(rect, useInitialValue(rect));
}
var defaultValue$1 = [];
function useScrollableAncestors(node) {
	const previousNode = useRef(node);
	const ancestors = useLazyMemo((previousValue) => {
		if (!node) return defaultValue$1;
		if (previousValue && previousValue !== defaultValue$1 && node && previousNode.current && node.parentNode === previousNode.current.parentNode) return previousValue;
		return getScrollableAncestors(node);
	}, [node]);
	useEffect(() => {
		previousNode.current = node;
	}, [node]);
	return ancestors;
}
function useScrollOffsets(elements) {
	const [scrollCoordinates, setScrollCoordinates] = useState(null);
	const prevElements = useRef(elements);
	const handleScroll = useCallback((event) => {
		const scrollingElement = getScrollableElement(event.target);
		if (!scrollingElement) return;
		setScrollCoordinates((scrollCoordinates) => {
			if (!scrollCoordinates) return null;
			scrollCoordinates.set(scrollingElement, getScrollCoordinates(scrollingElement));
			return new Map(scrollCoordinates);
		});
	}, []);
	useEffect(() => {
		const previousElements = prevElements.current;
		if (elements !== previousElements) {
			cleanup(previousElements);
			const entries = elements.map((element) => {
				const scrollableElement = getScrollableElement(element);
				if (scrollableElement) {
					scrollableElement.addEventListener("scroll", handleScroll, { passive: true });
					return [scrollableElement, getScrollCoordinates(scrollableElement)];
				}
				return null;
			}).filter((entry) => entry != null);
			setScrollCoordinates(entries.length ? new Map(entries) : null);
			prevElements.current = elements;
		}
		return () => {
			cleanup(elements);
			cleanup(previousElements);
		};
		function cleanup(elements) {
			elements.forEach((element) => {
				getScrollableElement(element)?.removeEventListener("scroll", handleScroll);
			});
		}
	}, [handleScroll, elements]);
	return useMemo(() => {
		if (elements.length) return scrollCoordinates ? Array.from(scrollCoordinates.values()).reduce((acc, coordinates) => add(acc, coordinates), defaultCoordinates) : getScrollOffsets(elements);
		return defaultCoordinates;
	}, [elements, scrollCoordinates]);
}
function useScrollOffsetsDelta(scrollOffsets, dependencies) {
	if (dependencies === void 0) dependencies = [];
	const initialScrollOffsets = useRef(null);
	useEffect(() => {
		initialScrollOffsets.current = null;
	}, dependencies);
	useEffect(() => {
		const hasScrollOffsets = scrollOffsets !== defaultCoordinates;
		if (hasScrollOffsets && !initialScrollOffsets.current) initialScrollOffsets.current = scrollOffsets;
		if (!hasScrollOffsets && initialScrollOffsets.current) initialScrollOffsets.current = null;
	}, [scrollOffsets]);
	return initialScrollOffsets.current ? subtract(scrollOffsets, initialScrollOffsets.current) : defaultCoordinates;
}
function useSensorSetup(sensors) {
	useEffect(() => {
		if (!canUseDOM) return;
		const teardownFns = sensors.map((_ref) => {
			let { sensor } = _ref;
			return sensor.setup == null ? void 0 : sensor.setup();
		});
		return () => {
			for (const teardown of teardownFns) teardown?.();
		};
	}, sensors.map((_ref2) => {
		let { sensor } = _ref2;
		return sensor;
	}));
}
function useSyntheticListeners(listeners, id) {
	return useMemo(() => {
		return listeners.reduce((acc, _ref) => {
			let { eventName, handler } = _ref;
			acc[eventName] = (event) => {
				handler(event, id);
			};
			return acc;
		}, {});
	}, [listeners, id]);
}
function useWindowRect(element) {
	return useMemo(() => element ? getWindowClientRect(element) : null, [element]);
}
var defaultValue$2 = [];
function useRects(elements, measure) {
	if (measure === void 0) measure = getClientRect;
	const [firstElement] = elements;
	const windowRect = useWindowRect(firstElement ? getWindow(firstElement) : null);
	const [rects, measureRects] = useReducer(reducer, defaultValue$2);
	const resizeObserver = useResizeObserver({ callback: measureRects });
	if (elements.length > 0 && rects === defaultValue$2) measureRects();
	useIsomorphicLayoutEffect(() => {
		if (elements.length) elements.forEach((element) => resizeObserver == null ? void 0 : resizeObserver.observe(element));
		else {
			resizeObserver?.disconnect();
			measureRects();
		}
	}, [elements]);
	return rects;
	function reducer() {
		if (!elements.length) return defaultValue$2;
		return elements.map((element) => isDocumentScrollingElement(element) ? windowRect : new Rect(measure(element), element));
	}
}
function getMeasurableNode(node) {
	if (!node) return null;
	if (node.children.length > 1) return node;
	const firstChild = node.children[0];
	return isHTMLElement(firstChild) ? firstChild : node;
}
function useDragOverlayMeasuring(_ref) {
	let { measure } = _ref;
	const [rect, setRect] = useState(null);
	const resizeObserver = useResizeObserver({ callback: useCallback((entries) => {
		for (const { target } of entries) if (isHTMLElement(target)) {
			setRect((rect) => {
				const newRect = measure(target);
				return rect ? {
					...rect,
					width: newRect.width,
					height: newRect.height
				} : newRect;
			});
			break;
		}
	}, [measure]) });
	const [nodeRef, setRef] = useNodeRef(useCallback((element) => {
		const node = getMeasurableNode(element);
		resizeObserver?.disconnect();
		if (node) resizeObserver?.observe(node);
		setRect(node ? measure(node) : null);
	}, [measure, resizeObserver]));
	return useMemo(() => ({
		nodeRef,
		rect,
		setRef
	}), [
		rect,
		nodeRef,
		setRef
	]);
}
var defaultSensors = [{
	sensor: PointerSensor,
	options: {}
}, {
	sensor: KeyboardSensor,
	options: {}
}];
var defaultData = { current: {} };
var defaultMeasuringConfiguration = {
	draggable: { measure: getTransformAgnosticClientRect },
	droppable: {
		measure: getTransformAgnosticClientRect,
		strategy: MeasuringStrategy.WhileDragging,
		frequency: MeasuringFrequency.Optimized
	},
	dragOverlay: { measure: getClientRect }
};
var DroppableContainersMap = class extends Map {
	get(id) {
		var _super$get;
		return id != null ? (_super$get = super.get(id)) != null ? _super$get : void 0 : void 0;
	}
	toArray() {
		return Array.from(this.values());
	}
	getEnabled() {
		return this.toArray().filter((_ref) => {
			let { disabled } = _ref;
			return !disabled;
		});
	}
	getNodeFor(id) {
		var _this$get$node$curren, _this$get;
		return (_this$get$node$curren = (_this$get = this.get(id)) == null ? void 0 : _this$get.node.current) != null ? _this$get$node$curren : void 0;
	}
};
var defaultPublicContext = {
	activatorEvent: null,
	active: null,
	activeNode: null,
	activeNodeRect: null,
	collisions: null,
	containerNodeRect: null,
	draggableNodes: /* @__PURE__ */ new Map(),
	droppableRects: /* @__PURE__ */ new Map(),
	droppableContainers: /* @__PURE__ */ new DroppableContainersMap(),
	over: null,
	dragOverlay: {
		nodeRef: { current: null },
		rect: null,
		setRef: noop
	},
	scrollableAncestors: [],
	scrollableAncestorRects: [],
	measuringConfiguration: defaultMeasuringConfiguration,
	measureDroppableContainers: noop,
	windowRect: null,
	measuringScheduled: false
};
var defaultInternalContext = {
	activatorEvent: null,
	activators: [],
	active: null,
	activeNodeRect: null,
	ariaDescribedById: { draggable: "" },
	dispatch: noop,
	draggableNodes: /* @__PURE__ */ new Map(),
	over: null,
	measureDroppableContainers: noop
};
var InternalContext = /* @__PURE__ */ createContext(defaultInternalContext);
var PublicContext = /* @__PURE__ */ createContext(defaultPublicContext);
function getInitialState() {
	return {
		draggable: {
			active: null,
			initialCoordinates: {
				x: 0,
				y: 0
			},
			nodes: /* @__PURE__ */ new Map(),
			translate: {
				x: 0,
				y: 0
			}
		},
		droppable: { containers: new DroppableContainersMap() }
	};
}
function reducer(state, action) {
	switch (action.type) {
		case Action.DragStart: return {
			...state,
			draggable: {
				...state.draggable,
				initialCoordinates: action.initialCoordinates,
				active: action.active
			}
		};
		case Action.DragMove:
			if (!state.draggable.active) return state;
			return {
				...state,
				draggable: {
					...state.draggable,
					translate: {
						x: action.coordinates.x - state.draggable.initialCoordinates.x,
						y: action.coordinates.y - state.draggable.initialCoordinates.y
					}
				}
			};
		case Action.DragEnd:
		case Action.DragCancel: return {
			...state,
			draggable: {
				...state.draggable,
				active: null,
				initialCoordinates: {
					x: 0,
					y: 0
				},
				translate: {
					x: 0,
					y: 0
				}
			}
		};
		case Action.RegisterDroppable: {
			const { element } = action;
			const { id } = element;
			const containers = new DroppableContainersMap(state.droppable.containers);
			containers.set(id, element);
			return {
				...state,
				droppable: {
					...state.droppable,
					containers
				}
			};
		}
		case Action.SetDroppableDisabled: {
			const { id, key, disabled } = action;
			const element = state.droppable.containers.get(id);
			if (!element || key !== element.key) return state;
			const containers = new DroppableContainersMap(state.droppable.containers);
			containers.set(id, {
				...element,
				disabled
			});
			return {
				...state,
				droppable: {
					...state.droppable,
					containers
				}
			};
		}
		case Action.UnregisterDroppable: {
			const { id, key } = action;
			const element = state.droppable.containers.get(id);
			if (!element || key !== element.key) return state;
			const containers = new DroppableContainersMap(state.droppable.containers);
			containers.delete(id);
			return {
				...state,
				droppable: {
					...state.droppable,
					containers
				}
			};
		}
		default: return state;
	}
}
function RestoreFocus(_ref) {
	let { disabled } = _ref;
	const { active, activatorEvent, draggableNodes } = useContext(InternalContext);
	const previousActivatorEvent = usePrevious(activatorEvent);
	const previousActiveId = usePrevious(active == null ? void 0 : active.id);
	useEffect(() => {
		if (disabled) return;
		if (!activatorEvent && previousActivatorEvent && previousActiveId != null) {
			if (!isKeyboardEvent(previousActivatorEvent)) return;
			if (document.activeElement === previousActivatorEvent.target) return;
			const draggableNode = draggableNodes.get(previousActiveId);
			if (!draggableNode) return;
			const { activatorNode, node } = draggableNode;
			if (!activatorNode.current && !node.current) return;
			requestAnimationFrame(() => {
				for (const element of [activatorNode.current, node.current]) {
					if (!element) continue;
					const focusableNode = findFirstFocusableNode(element);
					if (focusableNode) {
						focusableNode.focus();
						break;
					}
				}
			});
		}
	}, [
		activatorEvent,
		disabled,
		draggableNodes,
		previousActiveId,
		previousActivatorEvent
	]);
	return null;
}
function applyModifiers(modifiers, _ref) {
	let { transform, ...args } = _ref;
	return modifiers != null && modifiers.length ? modifiers.reduce((accumulator, modifier) => {
		return modifier({
			transform: accumulator,
			...args
		});
	}, transform) : transform;
}
function useMeasuringConfiguration(config) {
	return useMemo(() => ({
		draggable: {
			...defaultMeasuringConfiguration.draggable,
			...config == null ? void 0 : config.draggable
		},
		droppable: {
			...defaultMeasuringConfiguration.droppable,
			...config == null ? void 0 : config.droppable
		},
		dragOverlay: {
			...defaultMeasuringConfiguration.dragOverlay,
			...config == null ? void 0 : config.dragOverlay
		}
	}), [
		config == null ? void 0 : config.draggable,
		config == null ? void 0 : config.droppable,
		config == null ? void 0 : config.dragOverlay
	]);
}
function useLayoutShiftScrollCompensation(_ref) {
	let { activeNode, measure, initialRect, config = true } = _ref;
	const initialized = useRef(false);
	const { x, y } = typeof config === "boolean" ? {
		x: config,
		y: config
	} : config;
	useIsomorphicLayoutEffect(() => {
		if (!x && !y || !activeNode) {
			initialized.current = false;
			return;
		}
		if (initialized.current || !initialRect) return;
		const node = activeNode == null ? void 0 : activeNode.node.current;
		if (!node || node.isConnected === false) return;
		const rectDelta = getRectDelta(measure(node), initialRect);
		if (!x) rectDelta.x = 0;
		if (!y) rectDelta.y = 0;
		initialized.current = true;
		if (Math.abs(rectDelta.x) > 0 || Math.abs(rectDelta.y) > 0) {
			const firstScrollableAncestor = getFirstScrollableAncestor(node);
			if (firstScrollableAncestor) firstScrollableAncestor.scrollBy({
				top: rectDelta.y,
				left: rectDelta.x
			});
		}
	}, [
		activeNode,
		x,
		y,
		initialRect,
		measure
	]);
}
var ActiveDraggableContext = /* @__PURE__ */ createContext({
	...defaultCoordinates,
	scaleX: 1,
	scaleY: 1
});
var Status;
(function(Status) {
	Status[Status["Uninitialized"] = 0] = "Uninitialized";
	Status[Status["Initializing"] = 1] = "Initializing";
	Status[Status["Initialized"] = 2] = "Initialized";
})(Status || (Status = {}));
var DndContext = /* @__PURE__ */ memo(function DndContext(_ref) {
	var _sensorContext$curren, _dragOverlay$nodeRef$, _dragOverlay$rect, _over$rect;
	let { id, accessibility, autoScroll = true, children, sensors = defaultSensors, collisionDetection = rectIntersection, measuring, modifiers, ...props } = _ref;
	const [state, dispatch] = useReducer(reducer, void 0, getInitialState);
	const [dispatchMonitorEvent, registerMonitorListener] = useDndMonitorProvider();
	const [status, setStatus] = useState(Status.Uninitialized);
	const isInitialized = status === Status.Initialized;
	const { draggable: { active: activeId, nodes: draggableNodes, translate }, droppable: { containers: droppableContainers } } = state;
	const node = activeId ? draggableNodes.get(activeId) : null;
	const activeRects = useRef({
		initial: null,
		translated: null
	});
	const active = useMemo(() => {
		var _node$data;
		return activeId != null ? {
			id: activeId,
			data: (_node$data = node == null ? void 0 : node.data) != null ? _node$data : defaultData,
			rect: activeRects
		} : null;
	}, [activeId, node]);
	const activeRef = useRef(null);
	const [activeSensor, setActiveSensor] = useState(null);
	const [activatorEvent, setActivatorEvent] = useState(null);
	const latestProps = useLatestValue(props, Object.values(props));
	const draggableDescribedById = useUniqueId("DndDescribedBy", id);
	const enabledDroppableContainers = useMemo(() => droppableContainers.getEnabled(), [droppableContainers]);
	const measuringConfiguration = useMeasuringConfiguration(measuring);
	const { droppableRects, measureDroppableContainers, measuringScheduled } = useDroppableMeasuring(enabledDroppableContainers, {
		dragging: isInitialized,
		dependencies: [translate.x, translate.y],
		config: measuringConfiguration.droppable
	});
	const activeNode = useCachedNode(draggableNodes, activeId);
	const activationCoordinates = useMemo(() => activatorEvent ? getEventCoordinates(activatorEvent) : null, [activatorEvent]);
	const autoScrollOptions = getAutoScrollerOptions();
	const initialActiveNodeRect = useInitialRect(activeNode, measuringConfiguration.draggable.measure);
	useLayoutShiftScrollCompensation({
		activeNode: activeId ? draggableNodes.get(activeId) : null,
		config: autoScrollOptions.layoutShiftCompensation,
		initialRect: initialActiveNodeRect,
		measure: measuringConfiguration.draggable.measure
	});
	const activeNodeRect = useRect(activeNode, measuringConfiguration.draggable.measure, initialActiveNodeRect);
	const containerNodeRect = useRect(activeNode ? activeNode.parentElement : null);
	const sensorContext = useRef({
		activatorEvent: null,
		active: null,
		activeNode,
		collisionRect: null,
		collisions: null,
		droppableRects,
		draggableNodes,
		draggingNode: null,
		draggingNodeRect: null,
		droppableContainers,
		over: null,
		scrollableAncestors: [],
		scrollAdjustedTranslate: null
	});
	const overNode = droppableContainers.getNodeFor((_sensorContext$curren = sensorContext.current.over) == null ? void 0 : _sensorContext$curren.id);
	const dragOverlay = useDragOverlayMeasuring({ measure: measuringConfiguration.dragOverlay.measure });
	const draggingNode = (_dragOverlay$nodeRef$ = dragOverlay.nodeRef.current) != null ? _dragOverlay$nodeRef$ : activeNode;
	const draggingNodeRect = isInitialized ? (_dragOverlay$rect = dragOverlay.rect) != null ? _dragOverlay$rect : activeNodeRect : null;
	const usesDragOverlay = Boolean(dragOverlay.nodeRef.current && dragOverlay.rect);
	const nodeRectDelta = useRectDelta(usesDragOverlay ? null : activeNodeRect);
	const windowRect = useWindowRect(draggingNode ? getWindow(draggingNode) : null);
	const scrollableAncestors = useScrollableAncestors(isInitialized ? overNode != null ? overNode : activeNode : null);
	const scrollableAncestorRects = useRects(scrollableAncestors);
	const modifiedTranslate = applyModifiers(modifiers, {
		transform: {
			x: translate.x - nodeRectDelta.x,
			y: translate.y - nodeRectDelta.y,
			scaleX: 1,
			scaleY: 1
		},
		activatorEvent,
		active,
		activeNodeRect,
		containerNodeRect,
		draggingNodeRect,
		over: sensorContext.current.over,
		overlayNodeRect: dragOverlay.rect,
		scrollableAncestors,
		scrollableAncestorRects,
		windowRect
	});
	const pointerCoordinates = activationCoordinates ? add(activationCoordinates, translate) : null;
	const scrollOffsets = useScrollOffsets(scrollableAncestors);
	const scrollAdjustment = useScrollOffsetsDelta(scrollOffsets);
	const activeNodeScrollDelta = useScrollOffsetsDelta(scrollOffsets, [activeNodeRect]);
	const scrollAdjustedTranslate = add(modifiedTranslate, scrollAdjustment);
	const collisionRect = draggingNodeRect ? getAdjustedRect(draggingNodeRect, modifiedTranslate) : null;
	const collisions = active && collisionRect ? collisionDetection({
		active,
		collisionRect,
		droppableRects,
		droppableContainers: enabledDroppableContainers,
		pointerCoordinates
	}) : null;
	const overId = getFirstCollision(collisions, "id");
	const [over, setOver] = useState(null);
	const transform = adjustScale(usesDragOverlay ? modifiedTranslate : add(modifiedTranslate, activeNodeScrollDelta), (_over$rect = over == null ? void 0 : over.rect) != null ? _over$rect : null, activeNodeRect);
	const instantiateSensor = useCallback((event, _ref2) => {
		let { sensor: Sensor, options } = _ref2;
		if (activeRef.current == null) return;
		const activeNode = draggableNodes.get(activeRef.current);
		if (!activeNode) return;
		const activatorEvent = event.nativeEvent;
		const sensorInstance = new Sensor({
			active: activeRef.current,
			activeNode,
			event: activatorEvent,
			options,
			context: sensorContext,
			onStart(initialCoordinates) {
				const id = activeRef.current;
				if (id == null) return;
				const draggableNode = draggableNodes.get(id);
				if (!draggableNode) return;
				const { onDragStart } = latestProps.current;
				const event = { active: {
					id,
					data: draggableNode.data,
					rect: activeRects
				} };
				unstable_batchedUpdates(() => {
					onDragStart?.(event);
					setStatus(Status.Initializing);
					dispatch({
						type: Action.DragStart,
						initialCoordinates,
						active: id
					});
					dispatchMonitorEvent({
						type: "onDragStart",
						event
					});
				});
			},
			onMove(coordinates) {
				dispatch({
					type: Action.DragMove,
					coordinates
				});
			},
			onEnd: createHandler(Action.DragEnd),
			onCancel: createHandler(Action.DragCancel)
		});
		unstable_batchedUpdates(() => {
			setActiveSensor(sensorInstance);
			setActivatorEvent(event.nativeEvent);
		});
		function createHandler(type) {
			return async function handler() {
				const { active, collisions, over, scrollAdjustedTranslate } = sensorContext.current;
				let event = null;
				if (active && scrollAdjustedTranslate) {
					const { cancelDrop } = latestProps.current;
					event = {
						activatorEvent,
						active,
						collisions,
						delta: scrollAdjustedTranslate,
						over
					};
					if (type === Action.DragEnd && typeof cancelDrop === "function") {
						if (await Promise.resolve(cancelDrop(event))) type = Action.DragCancel;
					}
				}
				activeRef.current = null;
				unstable_batchedUpdates(() => {
					dispatch({ type });
					setStatus(Status.Uninitialized);
					setOver(null);
					setActiveSensor(null);
					setActivatorEvent(null);
					const eventName = type === Action.DragEnd ? "onDragEnd" : "onDragCancel";
					if (event) {
						const handler = latestProps.current[eventName];
						handler?.(event);
						dispatchMonitorEvent({
							type: eventName,
							event
						});
					}
				});
			};
		}
	}, [draggableNodes]);
	const activators = useCombineActivators(sensors, useCallback((handler, sensor) => {
		return (event, active) => {
			const nativeEvent = event.nativeEvent;
			const activeDraggableNode = draggableNodes.get(active);
			if (activeRef.current !== null || !activeDraggableNode || nativeEvent.dndKit || nativeEvent.defaultPrevented) return;
			const activationContext = { active: activeDraggableNode };
			if (handler(event, sensor.options, activationContext) === true) {
				nativeEvent.dndKit = { capturedBy: sensor.sensor };
				activeRef.current = active;
				instantiateSensor(event, sensor);
			}
		};
	}, [draggableNodes, instantiateSensor]));
	useSensorSetup(sensors);
	useIsomorphicLayoutEffect(() => {
		if (activeNodeRect && status === Status.Initializing) setStatus(Status.Initialized);
	}, [activeNodeRect, status]);
	useEffect(() => {
		const { onDragMove } = latestProps.current;
		const { active, activatorEvent, collisions, over } = sensorContext.current;
		if (!active || !activatorEvent) return;
		const event = {
			active,
			activatorEvent,
			collisions,
			delta: {
				x: scrollAdjustedTranslate.x,
				y: scrollAdjustedTranslate.y
			},
			over
		};
		unstable_batchedUpdates(() => {
			onDragMove?.(event);
			dispatchMonitorEvent({
				type: "onDragMove",
				event
			});
		});
	}, [scrollAdjustedTranslate.x, scrollAdjustedTranslate.y]);
	useEffect(() => {
		const { active, activatorEvent, collisions, droppableContainers, scrollAdjustedTranslate } = sensorContext.current;
		if (!active || activeRef.current == null || !activatorEvent || !scrollAdjustedTranslate) return;
		const { onDragOver } = latestProps.current;
		const overContainer = droppableContainers.get(overId);
		const over = overContainer && overContainer.rect.current ? {
			id: overContainer.id,
			rect: overContainer.rect.current,
			data: overContainer.data,
			disabled: overContainer.disabled
		} : null;
		const event = {
			active,
			activatorEvent,
			collisions,
			delta: {
				x: scrollAdjustedTranslate.x,
				y: scrollAdjustedTranslate.y
			},
			over
		};
		unstable_batchedUpdates(() => {
			setOver(over);
			onDragOver?.(event);
			dispatchMonitorEvent({
				type: "onDragOver",
				event
			});
		});
	}, [overId]);
	useIsomorphicLayoutEffect(() => {
		sensorContext.current = {
			activatorEvent,
			active,
			activeNode,
			collisionRect,
			collisions,
			droppableRects,
			draggableNodes,
			draggingNode,
			draggingNodeRect,
			droppableContainers,
			over,
			scrollableAncestors,
			scrollAdjustedTranslate
		};
		activeRects.current = {
			initial: draggingNodeRect,
			translated: collisionRect
		};
	}, [
		active,
		activeNode,
		collisions,
		collisionRect,
		draggableNodes,
		draggingNode,
		draggingNodeRect,
		droppableRects,
		droppableContainers,
		over,
		scrollableAncestors,
		scrollAdjustedTranslate
	]);
	useAutoScroller({
		...autoScrollOptions,
		delta: translate,
		draggingRect: collisionRect,
		pointerCoordinates,
		scrollableAncestors,
		scrollableAncestorRects
	});
	const publicContext = useMemo(() => {
		return {
			active,
			activeNode,
			activeNodeRect,
			activatorEvent,
			collisions,
			containerNodeRect,
			dragOverlay,
			draggableNodes,
			droppableContainers,
			droppableRects,
			over,
			measureDroppableContainers,
			scrollableAncestors,
			scrollableAncestorRects,
			measuringConfiguration,
			measuringScheduled,
			windowRect
		};
	}, [
		active,
		activeNode,
		activeNodeRect,
		activatorEvent,
		collisions,
		containerNodeRect,
		dragOverlay,
		draggableNodes,
		droppableContainers,
		droppableRects,
		over,
		measureDroppableContainers,
		scrollableAncestors,
		scrollableAncestorRects,
		measuringConfiguration,
		measuringScheduled,
		windowRect
	]);
	const internalContext = useMemo(() => {
		return {
			activatorEvent,
			activators,
			active,
			activeNodeRect,
			ariaDescribedById: { draggable: draggableDescribedById },
			dispatch,
			draggableNodes,
			over,
			measureDroppableContainers
		};
	}, [
		activatorEvent,
		activators,
		active,
		activeNodeRect,
		dispatch,
		draggableDescribedById,
		draggableNodes,
		over,
		measureDroppableContainers
	]);
	return React.createElement(DndMonitorContext.Provider, { value: registerMonitorListener }, React.createElement(InternalContext.Provider, { value: internalContext }, React.createElement(PublicContext.Provider, { value: publicContext }, React.createElement(ActiveDraggableContext.Provider, { value: transform }, children)), React.createElement(RestoreFocus, { disabled: (accessibility == null ? void 0 : accessibility.restoreFocus) === false })), React.createElement(Accessibility, {
		...accessibility,
		hiddenTextDescribedById: draggableDescribedById
	}));
	function getAutoScrollerOptions() {
		const activeSensorDisablesAutoscroll = (activeSensor == null ? void 0 : activeSensor.autoScrollEnabled) === false;
		const autoScrollGloballyDisabled = typeof autoScroll === "object" ? autoScroll.enabled === false : autoScroll === false;
		const enabled = isInitialized && !activeSensorDisablesAutoscroll && !autoScrollGloballyDisabled;
		if (typeof autoScroll === "object") return {
			...autoScroll,
			enabled
		};
		return { enabled };
	}
});
var NullContext = /* @__PURE__ */ createContext(null);
var defaultRole = "button";
var ID_PREFIX$1 = "Droppable";
function useDraggable(_ref) {
	let { id, data, disabled = false, attributes } = _ref;
	const key = useUniqueId(ID_PREFIX$1);
	const { activators, activatorEvent, active, activeNodeRect, ariaDescribedById, draggableNodes, over } = useContext(InternalContext);
	const { role = defaultRole, roleDescription = "draggable", tabIndex = 0 } = attributes != null ? attributes : {};
	const isDragging = (active == null ? void 0 : active.id) === id;
	const transform = useContext(isDragging ? ActiveDraggableContext : NullContext);
	const [node, setNodeRef] = useNodeRef();
	const [activatorNode, setActivatorNodeRef] = useNodeRef();
	const listeners = useSyntheticListeners(activators, id);
	const dataRef = useLatestValue(data);
	useIsomorphicLayoutEffect(() => {
		draggableNodes.set(id, {
			id,
			key,
			node,
			activatorNode,
			data: dataRef
		});
		return () => {
			const node = draggableNodes.get(id);
			if (node && node.key === key) draggableNodes.delete(id);
		};
	}, [draggableNodes, id]);
	return {
		active,
		activatorEvent,
		activeNodeRect,
		attributes: useMemo(() => ({
			role,
			tabIndex,
			"aria-disabled": disabled,
			"aria-pressed": isDragging && role === defaultRole ? true : void 0,
			"aria-roledescription": roleDescription,
			"aria-describedby": ariaDescribedById.draggable
		}), [
			disabled,
			role,
			tabIndex,
			isDragging,
			roleDescription,
			ariaDescribedById.draggable
		]),
		isDragging,
		listeners: disabled ? void 0 : listeners,
		node,
		over,
		setNodeRef,
		setActivatorNodeRef,
		transform
	};
}
function useDndContext() {
	return useContext(PublicContext);
}
var ID_PREFIX$1$1 = "Droppable";
var defaultResizeObserverConfig = { timeout: 25 };
function useDroppable(_ref) {
	let { data, disabled = false, id, resizeObserverConfig } = _ref;
	const key = useUniqueId(ID_PREFIX$1$1);
	const { active, dispatch, over, measureDroppableContainers } = useContext(InternalContext);
	const previous = useRef({ disabled });
	const resizeObserverConnected = useRef(false);
	const rect = useRef(null);
	const callbackId = useRef(null);
	const { disabled: resizeObserverDisabled, updateMeasurementsFor, timeout: resizeObserverTimeout } = {
		...defaultResizeObserverConfig,
		...resizeObserverConfig
	};
	const ids = useLatestValue(updateMeasurementsFor != null ? updateMeasurementsFor : id);
	const resizeObserver = useResizeObserver({
		callback: useCallback(() => {
			if (!resizeObserverConnected.current) {
				resizeObserverConnected.current = true;
				return;
			}
			if (callbackId.current != null) clearTimeout(callbackId.current);
			callbackId.current = setTimeout(() => {
				measureDroppableContainers(Array.isArray(ids.current) ? ids.current : [ids.current]);
				callbackId.current = null;
			}, resizeObserverTimeout);
		}, [resizeObserverTimeout]),
		disabled: resizeObserverDisabled || !active
	});
	const [nodeRef, setNodeRef] = useNodeRef(useCallback((newElement, previousElement) => {
		if (!resizeObserver) return;
		if (previousElement) {
			resizeObserver.unobserve(previousElement);
			resizeObserverConnected.current = false;
		}
		if (newElement) resizeObserver.observe(newElement);
	}, [resizeObserver]));
	const dataRef = useLatestValue(data);
	useEffect(() => {
		if (!resizeObserver || !nodeRef.current) return;
		resizeObserver.disconnect();
		resizeObserverConnected.current = false;
		resizeObserver.observe(nodeRef.current);
	}, [nodeRef, resizeObserver]);
	useIsomorphicLayoutEffect(() => {
		dispatch({
			type: Action.RegisterDroppable,
			element: {
				id,
				key,
				disabled,
				node: nodeRef,
				rect,
				data: dataRef
			}
		});
		return () => dispatch({
			type: Action.UnregisterDroppable,
			key,
			id
		});
	}, [id]);
	useEffect(() => {
		if (disabled !== previous.current.disabled) {
			dispatch({
				type: Action.SetDroppableDisabled,
				id,
				key,
				disabled
			});
			previous.current.disabled = disabled;
		}
	}, [
		id,
		key,
		disabled,
		dispatch
	]);
	return {
		active,
		rect,
		isOver: (over == null ? void 0 : over.id) === id,
		node: nodeRef,
		over,
		setNodeRef
	};
}
function AnimationManager(_ref) {
	let { animation, children } = _ref;
	const [clonedChildren, setClonedChildren] = useState(null);
	const [element, setElement] = useState(null);
	const previousChildren = usePrevious(children);
	if (!children && !clonedChildren && previousChildren) setClonedChildren(previousChildren);
	useIsomorphicLayoutEffect(() => {
		if (!element) return;
		const key = clonedChildren == null ? void 0 : clonedChildren.key;
		const id = clonedChildren == null ? void 0 : clonedChildren.props.id;
		if (key == null || id == null) {
			setClonedChildren(null);
			return;
		}
		Promise.resolve(animation(id, element)).then(() => {
			setClonedChildren(null);
		});
	}, [
		animation,
		clonedChildren,
		element
	]);
	return React.createElement(React.Fragment, null, children, clonedChildren ? cloneElement(clonedChildren, { ref: setElement }) : null);
}
var defaultTransform = {
	x: 0,
	y: 0,
	scaleX: 1,
	scaleY: 1
};
function NullifiedContextProvider(_ref) {
	let { children } = _ref;
	return React.createElement(InternalContext.Provider, { value: defaultInternalContext }, React.createElement(ActiveDraggableContext.Provider, { value: defaultTransform }, children));
}
var baseStyles = {
	position: "fixed",
	touchAction: "none"
};
var defaultTransition$1 = (activatorEvent) => {
	return isKeyboardEvent(activatorEvent) ? "transform 250ms ease" : void 0;
};
var PositionedOverlay = /* @__PURE__ */ forwardRef((_ref, ref) => {
	let { as, activatorEvent, adjustScale, children, className, rect, style, transform, transition = defaultTransition$1 } = _ref;
	if (!rect) return null;
	const scaleAdjustedTransform = adjustScale ? transform : {
		...transform,
		scaleX: 1,
		scaleY: 1
	};
	const styles = {
		...baseStyles,
		width: rect.width,
		height: rect.height,
		top: rect.top,
		left: rect.left,
		transform: CSS.Transform.toString(scaleAdjustedTransform),
		transformOrigin: adjustScale && activatorEvent ? getRelativeTransformOrigin(activatorEvent, rect) : void 0,
		transition: typeof transition === "function" ? transition(activatorEvent) : transition,
		...style
	};
	return React.createElement(as, {
		className,
		style: styles,
		ref
	}, children);
});
var defaultDropAnimationSideEffects = (options) => (_ref) => {
	let { active, dragOverlay } = _ref;
	const originalStyles = {};
	const { styles, className } = options;
	if (styles != null && styles.active) for (const [key, value] of Object.entries(styles.active)) {
		if (value === void 0) continue;
		originalStyles[key] = active.node.style.getPropertyValue(key);
		active.node.style.setProperty(key, value);
	}
	if (styles != null && styles.dragOverlay) for (const [key, value] of Object.entries(styles.dragOverlay)) {
		if (value === void 0) continue;
		dragOverlay.node.style.setProperty(key, value);
	}
	if (className != null && className.active) active.node.classList.add(className.active);
	if (className != null && className.dragOverlay) dragOverlay.node.classList.add(className.dragOverlay);
	return function cleanup() {
		for (const [key, value] of Object.entries(originalStyles)) active.node.style.setProperty(key, value);
		if (className != null && className.active) active.node.classList.remove(className.active);
	};
};
var defaultKeyframeResolver = (_ref2) => {
	let { transform: { initial, final } } = _ref2;
	return [{ transform: CSS.Transform.toString(initial) }, { transform: CSS.Transform.toString(final) }];
};
var defaultDropAnimationConfiguration = {
	duration: 250,
	easing: "ease",
	keyframes: defaultKeyframeResolver,
	sideEffects: /* @__PURE__ */ defaultDropAnimationSideEffects({ styles: { active: { opacity: "0" } } })
};
function useDropAnimation(_ref3) {
	let { config, draggableNodes, droppableContainers, measuringConfiguration } = _ref3;
	return useEvent((id, node) => {
		if (config === null) return;
		const activeDraggable = draggableNodes.get(id);
		if (!activeDraggable) return;
		const activeNode = activeDraggable.node.current;
		if (!activeNode) return;
		const measurableNode = getMeasurableNode(node);
		if (!measurableNode) return;
		const { transform } = getWindow(node).getComputedStyle(node);
		const parsedTransform = parseTransform(transform);
		if (!parsedTransform) return;
		const animation = typeof config === "function" ? config : createDefaultDropAnimation(config);
		scrollIntoViewIfNeeded(activeNode, measuringConfiguration.draggable.measure);
		return animation({
			active: {
				id,
				data: activeDraggable.data,
				node: activeNode,
				rect: measuringConfiguration.draggable.measure(activeNode)
			},
			draggableNodes,
			dragOverlay: {
				node,
				rect: measuringConfiguration.dragOverlay.measure(measurableNode)
			},
			droppableContainers,
			measuringConfiguration,
			transform: parsedTransform
		});
	});
}
function createDefaultDropAnimation(options) {
	const { duration, easing, sideEffects, keyframes } = {
		...defaultDropAnimationConfiguration,
		...options
	};
	return (_ref4) => {
		let { active, dragOverlay, transform, ...rest } = _ref4;
		if (!duration) return;
		const delta = {
			x: dragOverlay.rect.left - active.rect.left,
			y: dragOverlay.rect.top - active.rect.top
		};
		const scale = {
			scaleX: transform.scaleX !== 1 ? active.rect.width * transform.scaleX / dragOverlay.rect.width : 1,
			scaleY: transform.scaleY !== 1 ? active.rect.height * transform.scaleY / dragOverlay.rect.height : 1
		};
		const finalTransform = {
			x: transform.x - delta.x,
			y: transform.y - delta.y,
			...scale
		};
		const animationKeyframes = keyframes({
			...rest,
			active,
			dragOverlay,
			transform: {
				initial: transform,
				final: finalTransform
			}
		});
		const [firstKeyframe] = animationKeyframes;
		const lastKeyframe = animationKeyframes[animationKeyframes.length - 1];
		if (JSON.stringify(firstKeyframe) === JSON.stringify(lastKeyframe)) return;
		const cleanup = sideEffects == null ? void 0 : sideEffects({
			active,
			dragOverlay,
			...rest
		});
		const animation = dragOverlay.node.animate(animationKeyframes, {
			duration,
			easing,
			fill: "forwards"
		});
		return new Promise((resolve) => {
			animation.onfinish = () => {
				cleanup?.();
				resolve();
			};
		});
	};
}
var key = 0;
function useKey(id) {
	return useMemo(() => {
		if (id == null) return;
		key++;
		return key;
	}, [id]);
}
var DragOverlay = /* @__PURE__ */ React.memo((_ref) => {
	let { adjustScale = false, children, dropAnimation: dropAnimationConfig, style, transition, modifiers, wrapperElement = "div", className, zIndex = 999 } = _ref;
	const { activatorEvent, active, activeNodeRect, containerNodeRect, draggableNodes, droppableContainers, dragOverlay, over, measuringConfiguration, scrollableAncestors, scrollableAncestorRects, windowRect } = useDndContext();
	const transform = useContext(ActiveDraggableContext);
	const key = useKey(active == null ? void 0 : active.id);
	const modifiedTransform = applyModifiers(modifiers, {
		activatorEvent,
		active,
		activeNodeRect,
		containerNodeRect,
		draggingNodeRect: dragOverlay.rect,
		over,
		overlayNodeRect: dragOverlay.rect,
		scrollableAncestors,
		scrollableAncestorRects,
		transform,
		windowRect
	});
	const initialRect = useInitialValue(activeNodeRect);
	const dropAnimation = useDropAnimation({
		config: dropAnimationConfig,
		draggableNodes,
		droppableContainers,
		measuringConfiguration
	});
	const ref = initialRect ? dragOverlay.setRef : void 0;
	return React.createElement(NullifiedContextProvider, null, React.createElement(AnimationManager, { animation: dropAnimation }, active && key ? React.createElement(PositionedOverlay, {
		key,
		id: active.id,
		ref,
		as: wrapperElement,
		activatorEvent,
		adjustScale,
		className,
		transition,
		rect: initialRect,
		style: {
			zIndex,
			...style
		},
		transform: modifiedTransform
	}, children) : null));
});
var modifiers_esm_exports = /* @__PURE__ */ __exportAll({
	createSnapModifier: () => createSnapModifier,
	restrictToFirstScrollableAncestor: () => restrictToFirstScrollableAncestor,
	restrictToHorizontalAxis: () => restrictToHorizontalAxis,
	restrictToParentElement: () => restrictToParentElement,
	restrictToVerticalAxis: () => restrictToVerticalAxis,
	restrictToWindowEdges: () => restrictToWindowEdges,
	snapCenterToCursor: () => snapCenterToCursor
});
function createSnapModifier(gridSize) {
	return (_ref) => {
		let { transform } = _ref;
		return {
			...transform,
			x: Math.ceil(transform.x / gridSize) * gridSize,
			y: Math.ceil(transform.y / gridSize) * gridSize
		};
	};
}
var restrictToHorizontalAxis = (_ref) => {
	let { transform } = _ref;
	return {
		...transform,
		y: 0
	};
};
function restrictToBoundingRect(transform, rect, boundingRect) {
	const value = { ...transform };
	if (rect.top + transform.y <= boundingRect.top) value.y = boundingRect.top - rect.top;
	else if (rect.bottom + transform.y >= boundingRect.top + boundingRect.height) value.y = boundingRect.top + boundingRect.height - rect.bottom;
	if (rect.left + transform.x <= boundingRect.left) value.x = boundingRect.left - rect.left;
	else if (rect.right + transform.x >= boundingRect.left + boundingRect.width) value.x = boundingRect.left + boundingRect.width - rect.right;
	return value;
}
var restrictToParentElement = (_ref) => {
	let { containerNodeRect, draggingNodeRect, transform } = _ref;
	if (!draggingNodeRect || !containerNodeRect) return transform;
	return restrictToBoundingRect(transform, draggingNodeRect, containerNodeRect);
};
var restrictToFirstScrollableAncestor = (_ref) => {
	let { draggingNodeRect, transform, scrollableAncestorRects } = _ref;
	const firstScrollableAncestorRect = scrollableAncestorRects[0];
	if (!draggingNodeRect || !firstScrollableAncestorRect) return transform;
	return restrictToBoundingRect(transform, draggingNodeRect, firstScrollableAncestorRect);
};
var restrictToVerticalAxis = (_ref) => {
	let { transform } = _ref;
	return {
		...transform,
		x: 0
	};
};
var restrictToWindowEdges = (_ref) => {
	let { transform, draggingNodeRect, windowRect } = _ref;
	if (!draggingNodeRect || !windowRect) return transform;
	return restrictToBoundingRect(transform, draggingNodeRect, windowRect);
};
var snapCenterToCursor = (_ref) => {
	let { activatorEvent, draggingNodeRect, transform } = _ref;
	if (draggingNodeRect && activatorEvent) {
		const activatorCoordinates = getEventCoordinates(activatorEvent);
		if (!activatorCoordinates) return transform;
		const offsetX = activatorCoordinates.x - draggingNodeRect.left;
		const offsetY = activatorCoordinates.y - draggingNodeRect.top;
		return {
			...transform,
			x: transform.x + offsetX - draggingNodeRect.width / 2,
			y: transform.y + offsetY - draggingNodeRect.height / 2
		};
	}
	return transform;
};
var sortable_esm_exports = /* @__PURE__ */ __exportAll({
	SortableContext: () => SortableContext,
	arrayMove: () => arrayMove,
	arraySwap: () => arraySwap,
	defaultAnimateLayoutChanges: () => defaultAnimateLayoutChanges,
	defaultNewIndexGetter: () => defaultNewIndexGetter,
	hasSortableData: () => hasSortableData,
	horizontalListSortingStrategy: () => horizontalListSortingStrategy,
	rectSortingStrategy: () => rectSortingStrategy,
	rectSwappingStrategy: () => rectSwappingStrategy,
	sortableKeyboardCoordinates: () => sortableKeyboardCoordinates,
	useSortable: () => useSortable,
	verticalListSortingStrategy: () => verticalListSortingStrategy
});
/**
* Move an array item to a different position. Returns a new array with the item moved to the new position.
*/
function arrayMove(array, from, to) {
	const newArray = array.slice();
	newArray.splice(to < 0 ? newArray.length + to : to, 0, newArray.splice(from, 1)[0]);
	return newArray;
}
/**
* Swap an array item to a different position. Returns a new array with the item swapped to the new position.
*/
function arraySwap(array, from, to) {
	const newArray = array.slice();
	newArray[from] = array[to];
	newArray[to] = array[from];
	return newArray;
}
function getSortedRects(items, rects) {
	return items.reduce((accumulator, id, index) => {
		const rect = rects.get(id);
		if (rect) accumulator[index] = rect;
		return accumulator;
	}, Array(items.length));
}
function isValidIndex(index) {
	return index !== null && index >= 0;
}
function itemsEqual(a, b) {
	if (a === b) return true;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
function normalizeDisabled(disabled) {
	if (typeof disabled === "boolean") return {
		draggable: disabled,
		droppable: disabled
	};
	return disabled;
}
var defaultScale = {
	scaleX: 1,
	scaleY: 1
};
var horizontalListSortingStrategy = (_ref) => {
	var _rects$activeIndex;
	let { rects, activeNodeRect: fallbackActiveRect, activeIndex, overIndex, index } = _ref;
	const activeNodeRect = (_rects$activeIndex = rects[activeIndex]) != null ? _rects$activeIndex : fallbackActiveRect;
	if (!activeNodeRect) return null;
	const itemGap = getItemGap(rects, index, activeIndex);
	if (index === activeIndex) {
		const newIndexRect = rects[overIndex];
		if (!newIndexRect) return null;
		return {
			x: activeIndex < overIndex ? newIndexRect.left + newIndexRect.width - (activeNodeRect.left + activeNodeRect.width) : newIndexRect.left - activeNodeRect.left,
			y: 0,
			...defaultScale
		};
	}
	if (index > activeIndex && index <= overIndex) return {
		x: -activeNodeRect.width - itemGap,
		y: 0,
		...defaultScale
	};
	if (index < activeIndex && index >= overIndex) return {
		x: activeNodeRect.width + itemGap,
		y: 0,
		...defaultScale
	};
	return {
		x: 0,
		y: 0,
		...defaultScale
	};
};
function getItemGap(rects, index, activeIndex) {
	const currentRect = rects[index];
	const previousRect = rects[index - 1];
	const nextRect = rects[index + 1];
	if (!currentRect || !previousRect && !nextRect) return 0;
	if (activeIndex < index) return previousRect ? currentRect.left - (previousRect.left + previousRect.width) : nextRect.left - (currentRect.left + currentRect.width);
	return nextRect ? nextRect.left - (currentRect.left + currentRect.width) : currentRect.left - (previousRect.left + previousRect.width);
}
var rectSortingStrategy = (_ref) => {
	let { rects, activeIndex, overIndex, index } = _ref;
	const newRects = arrayMove(rects, overIndex, activeIndex);
	const oldRect = rects[index];
	const newRect = newRects[index];
	if (!newRect || !oldRect) return null;
	return {
		x: newRect.left - oldRect.left,
		y: newRect.top - oldRect.top,
		scaleX: newRect.width / oldRect.width,
		scaleY: newRect.height / oldRect.height
	};
};
var rectSwappingStrategy = (_ref) => {
	let { activeIndex, index, rects, overIndex } = _ref;
	let oldRect;
	let newRect;
	if (index === activeIndex) {
		oldRect = rects[index];
		newRect = rects[overIndex];
	}
	if (index === overIndex) {
		oldRect = rects[index];
		newRect = rects[activeIndex];
	}
	if (!newRect || !oldRect) return null;
	return {
		x: newRect.left - oldRect.left,
		y: newRect.top - oldRect.top,
		scaleX: newRect.width / oldRect.width,
		scaleY: newRect.height / oldRect.height
	};
};
var defaultScale$1 = {
	scaleX: 1,
	scaleY: 1
};
var verticalListSortingStrategy = (_ref) => {
	var _rects$activeIndex;
	let { activeIndex, activeNodeRect: fallbackActiveRect, index, rects, overIndex } = _ref;
	const activeNodeRect = (_rects$activeIndex = rects[activeIndex]) != null ? _rects$activeIndex : fallbackActiveRect;
	if (!activeNodeRect) return null;
	if (index === activeIndex) {
		const overIndexRect = rects[overIndex];
		if (!overIndexRect) return null;
		return {
			x: 0,
			y: activeIndex < overIndex ? overIndexRect.top + overIndexRect.height - (activeNodeRect.top + activeNodeRect.height) : overIndexRect.top - activeNodeRect.top,
			...defaultScale$1
		};
	}
	const itemGap = getItemGap$1(rects, index, activeIndex);
	if (index > activeIndex && index <= overIndex) return {
		x: 0,
		y: -activeNodeRect.height - itemGap,
		...defaultScale$1
	};
	if (index < activeIndex && index >= overIndex) return {
		x: 0,
		y: activeNodeRect.height + itemGap,
		...defaultScale$1
	};
	return {
		x: 0,
		y: 0,
		...defaultScale$1
	};
};
function getItemGap$1(clientRects, index, activeIndex) {
	const currentRect = clientRects[index];
	const previousRect = clientRects[index - 1];
	const nextRect = clientRects[index + 1];
	if (!currentRect) return 0;
	if (activeIndex < index) return previousRect ? currentRect.top - (previousRect.top + previousRect.height) : nextRect ? nextRect.top - (currentRect.top + currentRect.height) : 0;
	return nextRect ? nextRect.top - (currentRect.top + currentRect.height) : previousRect ? currentRect.top - (previousRect.top + previousRect.height) : 0;
}
var ID_PREFIX = "Sortable";
var Context = /* @__PURE__ */ React.createContext({
	activeIndex: -1,
	containerId: ID_PREFIX,
	disableTransforms: false,
	items: [],
	overIndex: -1,
	useDragOverlay: false,
	sortedRects: [],
	strategy: rectSortingStrategy,
	disabled: {
		draggable: false,
		droppable: false
	}
});
function SortableContext(_ref) {
	let { children, id, items: userDefinedItems, strategy = rectSortingStrategy, disabled: disabledProp = false } = _ref;
	const { active, dragOverlay, droppableRects, over, measureDroppableContainers } = useDndContext();
	const containerId = useUniqueId(ID_PREFIX, id);
	const useDragOverlay = Boolean(dragOverlay.rect !== null);
	const items = useMemo(() => userDefinedItems.map((item) => typeof item === "object" && "id" in item ? item.id : item), [userDefinedItems]);
	const isDragging = active != null;
	const activeIndex = active ? items.indexOf(active.id) : -1;
	const overIndex = over ? items.indexOf(over.id) : -1;
	const previousItemsRef = useRef(items);
	const itemsHaveChanged = !itemsEqual(items, previousItemsRef.current);
	const disableTransforms = overIndex !== -1 && activeIndex === -1 || itemsHaveChanged;
	const disabled = normalizeDisabled(disabledProp);
	useIsomorphicLayoutEffect(() => {
		if (itemsHaveChanged && isDragging) measureDroppableContainers(items);
	}, [
		itemsHaveChanged,
		items,
		isDragging,
		measureDroppableContainers
	]);
	useEffect(() => {
		previousItemsRef.current = items;
	}, [items]);
	const contextValue = useMemo(() => ({
		activeIndex,
		containerId,
		disabled,
		disableTransforms,
		items,
		overIndex,
		useDragOverlay,
		sortedRects: getSortedRects(items, droppableRects),
		strategy
	}), [
		activeIndex,
		containerId,
		disabled.draggable,
		disabled.droppable,
		disableTransforms,
		items,
		overIndex,
		droppableRects,
		useDragOverlay,
		strategy
	]);
	return React.createElement(Context.Provider, { value: contextValue }, children);
}
var defaultNewIndexGetter = (_ref) => {
	let { id, items, activeIndex, overIndex } = _ref;
	return arrayMove(items, activeIndex, overIndex).indexOf(id);
};
var defaultAnimateLayoutChanges = (_ref2) => {
	let { containerId, isSorting, wasDragging, index, items, newIndex, previousItems, previousContainerId, transition } = _ref2;
	if (!transition || !wasDragging) return false;
	if (previousItems !== items && index === newIndex) return false;
	if (isSorting) return true;
	return newIndex !== index && containerId === previousContainerId;
};
var defaultTransition = {
	duration: 200,
	easing: "ease"
};
var transitionProperty = "transform";
var disabledTransition = /* @__PURE__ */ CSS.Transition.toString({
	property: transitionProperty,
	duration: 0,
	easing: "linear"
});
var defaultAttributes = { roleDescription: "sortable" };
function useDerivedTransform(_ref) {
	let { disabled, index, node, rect } = _ref;
	const [derivedTransform, setDerivedtransform] = useState(null);
	const previousIndex = useRef(index);
	useIsomorphicLayoutEffect(() => {
		if (!disabled && index !== previousIndex.current && node.current) {
			const initial = rect.current;
			if (initial) {
				const current = getClientRect(node.current, { ignoreTransform: true });
				const delta = {
					x: initial.left - current.left,
					y: initial.top - current.top,
					scaleX: initial.width / current.width,
					scaleY: initial.height / current.height
				};
				if (delta.x || delta.y) setDerivedtransform(delta);
			}
		}
		if (index !== previousIndex.current) previousIndex.current = index;
	}, [
		disabled,
		index,
		node,
		rect
	]);
	useEffect(() => {
		if (derivedTransform) setDerivedtransform(null);
	}, [derivedTransform]);
	return derivedTransform;
}
function useSortable(_ref) {
	let { animateLayoutChanges = defaultAnimateLayoutChanges, attributes: userDefinedAttributes, disabled: localDisabled, data: customData, getNewIndex = defaultNewIndexGetter, id, strategy: localStrategy, resizeObserverConfig, transition = defaultTransition } = _ref;
	const { items, containerId, activeIndex, disabled: globalDisabled, disableTransforms, sortedRects, overIndex, useDragOverlay, strategy: globalStrategy } = useContext(Context);
	const disabled = normalizeLocalDisabled(localDisabled, globalDisabled);
	const index = items.indexOf(id);
	const data = useMemo(() => ({
		sortable: {
			containerId,
			index,
			items
		},
		...customData
	}), [
		containerId,
		customData,
		index,
		items
	]);
	const itemsAfterCurrentSortable = useMemo(() => items.slice(items.indexOf(id)), [items, id]);
	const { rect, node, isOver, setNodeRef: setDroppableNodeRef } = useDroppable({
		id,
		data,
		disabled: disabled.droppable,
		resizeObserverConfig: {
			updateMeasurementsFor: itemsAfterCurrentSortable,
			...resizeObserverConfig
		}
	});
	const { active, activatorEvent, activeNodeRect, attributes, setNodeRef: setDraggableNodeRef, listeners, isDragging, over, setActivatorNodeRef, transform } = useDraggable({
		id,
		data,
		attributes: {
			...defaultAttributes,
			...userDefinedAttributes
		},
		disabled: disabled.draggable
	});
	const setNodeRef = useCombinedRefs(setDroppableNodeRef, setDraggableNodeRef);
	const isSorting = Boolean(active);
	const displaceItem = isSorting && !disableTransforms && isValidIndex(activeIndex) && isValidIndex(overIndex);
	const shouldDisplaceDragSource = !useDragOverlay && isDragging;
	const dragSourceDisplacement = shouldDisplaceDragSource && displaceItem ? transform : null;
	const finalTransform = displaceItem ? dragSourceDisplacement != null ? dragSourceDisplacement : (localStrategy != null ? localStrategy : globalStrategy)({
		rects: sortedRects,
		activeNodeRect,
		activeIndex,
		overIndex,
		index
	}) : null;
	const newIndex = isValidIndex(activeIndex) && isValidIndex(overIndex) ? getNewIndex({
		id,
		items,
		activeIndex,
		overIndex
	}) : index;
	const activeId = active == null ? void 0 : active.id;
	const previous = useRef({
		activeId,
		items,
		newIndex,
		containerId
	});
	const itemsHaveChanged = items !== previous.current.items;
	const shouldAnimateLayoutChanges = animateLayoutChanges({
		active,
		containerId,
		isDragging,
		isSorting,
		id,
		index,
		items,
		newIndex: previous.current.newIndex,
		previousItems: previous.current.items,
		previousContainerId: previous.current.containerId,
		transition,
		wasDragging: previous.current.activeId != null
	});
	const derivedTransform = useDerivedTransform({
		disabled: !shouldAnimateLayoutChanges,
		index,
		node,
		rect
	});
	useEffect(() => {
		if (isSorting && previous.current.newIndex !== newIndex) previous.current.newIndex = newIndex;
		if (containerId !== previous.current.containerId) previous.current.containerId = containerId;
		if (items !== previous.current.items) previous.current.items = items;
	}, [
		isSorting,
		newIndex,
		containerId,
		items
	]);
	useEffect(() => {
		if (activeId === previous.current.activeId) return;
		if (activeId && !previous.current.activeId) {
			previous.current.activeId = activeId;
			return;
		}
		const timeoutId = setTimeout(() => {
			previous.current.activeId = activeId;
		}, 50);
		return () => clearTimeout(timeoutId);
	}, [activeId]);
	return {
		active,
		activeIndex,
		attributes,
		data,
		rect,
		index,
		newIndex,
		items,
		isOver,
		isSorting,
		isDragging,
		listeners,
		node,
		overIndex,
		over,
		setNodeRef,
		setActivatorNodeRef,
		setDroppableNodeRef,
		setDraggableNodeRef,
		transform: derivedTransform != null ? derivedTransform : finalTransform,
		transition: getTransition()
	};
	function getTransition() {
		if (derivedTransform || itemsHaveChanged && previous.current.newIndex === index) return disabledTransition;
		if (shouldDisplaceDragSource && !isKeyboardEvent(activatorEvent) || !transition) return;
		if (isSorting || shouldAnimateLayoutChanges) return CSS.Transition.toString({
			...transition,
			property: transitionProperty
		});
	}
}
function normalizeLocalDisabled(localDisabled, globalDisabled) {
	var _localDisabled$dragga, _localDisabled$droppa;
	if (typeof localDisabled === "boolean") return {
		draggable: localDisabled,
		droppable: false
	};
	return {
		draggable: (_localDisabled$dragga = localDisabled == null ? void 0 : localDisabled.draggable) != null ? _localDisabled$dragga : globalDisabled.draggable,
		droppable: (_localDisabled$droppa = localDisabled == null ? void 0 : localDisabled.droppable) != null ? _localDisabled$droppa : globalDisabled.droppable
	};
}
function hasSortableData(entry) {
	if (!entry) return false;
	const data = entry.data.current;
	if (data && "sortable" in data && typeof data.sortable === "object" && "containerId" in data.sortable && "items" in data.sortable && "index" in data.sortable) return true;
	return false;
}
var directions = [
	KeyboardCode.Down,
	KeyboardCode.Right,
	KeyboardCode.Up,
	KeyboardCode.Left
];
var sortableKeyboardCoordinates = (event, _ref) => {
	let { context: { active, collisionRect, droppableRects, droppableContainers, over, scrollableAncestors } } = _ref;
	if (directions.includes(event.code)) {
		event.preventDefault();
		if (!active || !collisionRect) return;
		const filteredContainers = [];
		droppableContainers.getEnabled().forEach((entry) => {
			if (!entry || entry != null && entry.disabled) return;
			const rect = droppableRects.get(entry.id);
			if (!rect) return;
			switch (event.code) {
				case KeyboardCode.Down:
					if (collisionRect.top < rect.top) filteredContainers.push(entry);
					break;
				case KeyboardCode.Up:
					if (collisionRect.top > rect.top) filteredContainers.push(entry);
					break;
				case KeyboardCode.Left:
					if (collisionRect.left > rect.left) filteredContainers.push(entry);
					break;
				case KeyboardCode.Right:
					if (collisionRect.left < rect.left) filteredContainers.push(entry);
					break;
			}
		});
		const collisions = closestCorners({
			active,
			collisionRect,
			droppableRects,
			droppableContainers: filteredContainers,
			pointerCoordinates: null
		});
		let closestId = getFirstCollision(collisions, "id");
		if (closestId === (over == null ? void 0 : over.id) && collisions.length > 1) closestId = collisions[1].id;
		if (closestId != null) {
			const activeDroppable = droppableContainers.get(active.id);
			const newDroppable = droppableContainers.get(closestId);
			const newRect = newDroppable ? droppableRects.get(newDroppable.id) : null;
			const newNode = newDroppable == null ? void 0 : newDroppable.node.current;
			if (newNode && newRect && activeDroppable && newDroppable) {
				const hasDifferentScrollAncestors = getScrollableAncestors(newNode).some((element, index) => scrollableAncestors[index] !== element);
				const hasSameContainer = isSameContainer(activeDroppable, newDroppable);
				const isAfterActive = isAfter(activeDroppable, newDroppable);
				const offset = hasDifferentScrollAncestors || !hasSameContainer ? {
					x: 0,
					y: 0
				} : {
					x: isAfterActive ? collisionRect.width - newRect.width : 0,
					y: isAfterActive ? collisionRect.height - newRect.height : 0
				};
				const rectCoordinates = {
					x: newRect.left,
					y: newRect.top
				};
				return offset.x && offset.y ? rectCoordinates : subtract(rectCoordinates, offset);
			}
		}
	}
};
function isSameContainer(a, b) {
	if (!hasSortableData(a) || !hasSortableData(b)) return false;
	return a.data.current.sortable.containerId === b.data.current.sortable.containerId;
}
function isAfter(a, b) {
	if (!hasSortableData(a) || !hasSortableData(b)) return false;
	if (!isSameContainer(a, b)) return false;
	return a.data.current.sortable.index < b.data.current.sortable.index;
}
/**
* State that stays in sync with a prop/external value.
*
* When `initialValue` changes (compared via `isEqual`), the state resets to match.
* This is the "primitives in state" pattern from React docs:
* https://react.dev/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes
*
* @param nextValue - The value to sync from (must not be a function)
* @param opts.isPropUpdateDisabled - Skip syncing (e.g., while a form is dirty)
* @param opts.isEqual - Comparison function, defaults to Object.is
*/
function useSyncedState(nextValue, t0) {
	const $ = c(4);
	const { isPropUpdateDisabled: t1, isEqual: t2 } = t0 === void 0 ? {} : t0;
	const isPropUpdateDisabled = t1 === void 0 ? false : t1;
	const isEqual = t2 === void 0 ? Object.is : t2;
	const [currentValue, setCurrentValue] = useState(nextValue);
	const [previousValue, setPreviousValue] = useState(nextValue);
	if (!isPropUpdateDisabled && !isEqual(previousValue, nextValue)) {
		setPreviousValue(nextValue);
		setCurrentValue(nextValue);
		let t3;
		if ($[0] !== nextValue) {
			t3 = [nextValue, setCurrentValue];
			$[0] = nextValue;
			$[1] = t3;
		} else t3 = $[1];
		return t3;
	}
	let t3;
	if ($[2] !== currentValue) {
		t3 = [currentValue, setCurrentValue];
		$[2] = currentValue;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
}
var ActionBarContentContext = createContext({
	actions: [],
	staticMenuActions: [],
	label: "Actions",
	gap: 0
});
ActionBarContentContext.displayName = "ActionBarContentContext";
var ActionBarContentProvider = (t0) => {
	const $ = c(11);
	const { children, value: t1 } = t0;
	const { actions: t2, staticMenuActions, variant: t3, label, gap } = t1;
	let t4;
	if ($[0] !== t2) {
		t4 = t2 === void 0 ? [] : t2;
		$[0] = t2;
		$[1] = t4;
	} else t4 = $[1];
	const actions = t4;
	const variant = t3 === void 0 ? "toolbar" : t3;
	let t5;
	if ($[2] !== actions || $[3] !== gap || $[4] !== label || $[5] !== staticMenuActions || $[6] !== variant) {
		t5 = {
			actions,
			staticMenuActions,
			variant,
			label,
			gap
		};
		$[2] = actions;
		$[3] = gap;
		$[4] = label;
		$[5] = staticMenuActions;
		$[6] = variant;
		$[7] = t5;
	} else t5 = $[7];
	const value = t5;
	let t6;
	if ($[8] !== children || $[9] !== value) {
		t6 = jsx(ActionBarContentContext, {
			value,
			children
		});
		$[8] = children;
		$[9] = value;
		$[10] = t6;
	} else t6 = $[10];
	return t6;
};
ActionBarContentProvider.displayName = "ActionBarContentProvider";
var useActionBarContent = () => {
	const context = use(ActionBarContentContext);
	if (!context) throw new Error("useActionBarContent must be used with ActionBarContentProvider.");
	return context;
};
var ActionBarRefContext = createContext({
	outerContainerRef: createRef(),
	itemContainerRef: createRef()
});
ActionBarRefContext.displayName = "ActionBarRefContext";
var ActionBarRefProvider = ({ value: { anchorRef }, children }) => {
	const outerContainerRef = useRef(null);
	const itemContainerRef = useRef(null);
	return /* @__PURE__ */ jsx(ActionBarRefContext, {
		value: useMemo(() => ({
			outerContainerRef,
			itemContainerRef,
			anchorRef
		}), [anchorRef]),
		children
	});
};
ActionBarRefProvider.displayName = "ActionBarRefProvider";
var useActionBarRef = () => {
	return use(ActionBarRefContext);
};
var columnGap = (el) => {
	if (!el) return 0;
	const computedStyle = window.getComputedStyle(el);
	if (computedStyle?.columnGap) return parseInt(computedStyle.columnGap, 10);
	return 0;
};
var calculateItemLayoutWidth = (item, gap) => {
	return item.offsetWidth + gap * 2;
};
/**
* Calculate the offset width of a single item within its container.
* Handles gap calculation internally.
*/
var getItemWidth = (item, container) => {
	return calculateItemLayoutWidth(item, columnGap(container));
};
/**
* Batch calculate offset widths for multiple items within their container.
* Reads container gap once via getComputedStyle; per-item reads use only
* offsetWidth (no per-item getComputedStyle).
*/
var batchGetItemWidths = (items, container) => {
	const widths = /* @__PURE__ */ new Map();
	if (items.length === 0) return widths;
	const gap = columnGap(container);
	for (const { key, el } of items) widths.set(key, calculateItemLayoutWidth(el, gap));
	return widths;
};
var gapFromDensity = (density) => {
	if (density === "condensed") return "var(--base-size-4)";
	if (density === "spacious") return "var(--base-size-16)";
	if (density === "none") return 0;
	return "var(--base-size-8)";
};
var ActionBarResizeContext = createContext({
	visibleChildEndIndex: 0,
	justifySpaceBetween: false,
	recalculateItemSize: noop$1
});
ActionBarResizeContext.displayName = "ActionBarResizeContext";
var ActionBarResizeProvider = ({ children, value: { actionKeys } }) => {
	const totalActions = actionKeys.length;
	const [visibleChildEndIndex, setVisibleChildEndIndex] = useSyncedState(totalActions);
	const { outerContainerRef, itemContainerRef } = useActionBarRef();
	const initialBarWidthRef = useRef(void 0);
	const [itemOffsetWidths, setItemOffsetWidths] = useState(() => new Map(actionKeys.map((key) => [key, void 0])));
	const [justifySpaceBetween, setJustifySpaceBetween] = useState(false);
	const batchMeasuredKeysRef = useRef(/* @__PURE__ */ new Set());
	const recalculateItemSize = useCallback((key_0, el) => {
		if (batchMeasuredKeysRef.current.has(key_0)) {
			batchMeasuredKeysRef.current.delete(key_0);
			return;
		}
		const itemContainer = itemContainerRef.current;
		if (!itemContainer) return;
		const newWidth = getItemWidth(el, itemContainer);
		setItemOffsetWidths((oldVal) => {
			if (newWidth === oldVal.get(key_0) || isNaN(newWidth)) return oldVal;
			const newVal = new Map(Array.from(oldVal.entries()));
			newVal.set(key_0, newWidth);
			return newVal;
		});
	}, [itemContainerRef]);
	const update = useCallback(() => {
		const outerContainer = outerContainerRef.current;
		const itemContainer_0 = itemContainerRef.current;
		if (!outerContainer || !itemContainer_0) return;
		const outerWidth = outerContainer.offsetWidth;
		if (!outerWidth) return;
		const itemContainerWidth = itemContainer_0.offsetWidth;
		const itemContainerLeft = itemContainer_0.offsetLeft;
		let availableSpace = outerWidth - itemContainerWidth;
		const menuSpace = availableSpace - itemContainerLeft;
		let index = visibleChildEndIndex;
		while (index > 0 && availableSpace <= menuSpace) {
			const key_1 = actionKeys[index - 1];
			if (!key_1) break;
			const w = itemOffsetWidths.get(key_1);
			if (typeof w === "undefined") break;
			index--;
			availableSpace += w;
		}
		while (index < totalActions) {
			const key_2 = actionKeys[index];
			if (!key_2) break;
			const w_0 = itemOffsetWidths.get(key_2);
			if (typeof w_0 === "undefined") break;
			if (availableSpace <= menuSpace + w_0) break;
			index++;
			availableSpace -= w_0;
		}
		setVisibleChildEndIndex(index);
		if (initialBarWidthRef.current === void 0) initialBarWidthRef.current = itemContainerWidth;
		setJustifySpaceBetween(outerWidth <= (initialBarWidthRef.current ?? itemContainerWidth));
	}, [
		actionKeys,
		itemOffsetWidths,
		outerContainerRef,
		itemContainerRef,
		totalActions,
		visibleChildEndIndex,
		setVisibleChildEndIndex
	]);
	useLayoutEffect(() => {
		const itemContainer_1 = itemContainerRef.current;
		if (!itemContainer_1) return;
		const items = [];
		for (const key_3 of actionKeys) {
			const el_0 = itemContainer_1.querySelector(`[data-action-bar-item="${key_3}"]`);
			if (el_0) items.push({
				key: key_3,
				el: el_0
			});
		}
		const widths = batchGetItemWidths(items, itemContainer_1);
		batchMeasuredKeysRef.current = new Set(widths.keys());
		setItemOffsetWidths(widths);
	}, [actionKeys, itemContainerRef]);
	useLayoutEffect(() => {
		update();
	}, [update]);
	useResizeObserver$1(update, outerContainerRef);
	return /* @__PURE__ */ jsx(ActionBarResizeContext, {
		value: useMemo(() => ({
			visibleChildEndIndex,
			justifySpaceBetween,
			recalculateItemSize
		}), [
			visibleChildEndIndex,
			justifySpaceBetween,
			recalculateItemSize
		]),
		children
	});
};
ActionBarResizeProvider.displayName = "ActionBarResizeProvider";
var useActionBarResize = () => {
	return use(ActionBarResizeContext);
};
var OverflowMenu_module_default = { IconButton_0: "OverflowMenu-module_VoMSmW_IconButton_0" };
var defaultMenuToggleIcon = KebabHorizontalIcon;
var defaultMenuToggleVariant = "invisible";
var OverflowMenu = (t0) => {
	const $ = c(24);
	const { anchorProps: t1, open, onOpenChange } = t0;
	let t2;
	if ($[0] !== t1) {
		t2 = t1 === void 0 ? {
			icon: defaultMenuToggleIcon,
			variant: defaultMenuToggleVariant
		} : t1;
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	let ariaLabel;
	let otherAnchorProps;
	let t3;
	let t4;
	if ($[2] !== t2) {
		({"aria-label": ariaLabel, icon: t3, variant: t4, ...otherAnchorProps} = t2);
		$[2] = t2;
		$[3] = ariaLabel;
		$[4] = otherAnchorProps;
		$[5] = t3;
		$[6] = t4;
	} else {
		ariaLabel = $[3];
		otherAnchorProps = $[4];
		t3 = $[5];
		t4 = $[6];
	}
	const icon = t3 === void 0 ? defaultMenuToggleIcon : t3;
	const variant = t4 === void 0 ? defaultMenuToggleVariant : t4;
	const { anchorRef } = useActionBarRef();
	const { actions, staticMenuActions, label } = useActionBarContent();
	const { visibleChildEndIndex } = useActionBarResize();
	let t5;
	if ($[7] !== ariaLabel || $[8] !== icon || $[9] !== label || $[10] !== otherAnchorProps || $[11] !== variant) {
		t5 = merge(otherAnchorProps, {
			"aria-label": ariaLabel?.trim() || `More ${label}`,
			icon,
			className: OverflowMenu_module_default.IconButton_0,
			variant
		});
		$[7] = ariaLabel;
		$[8] = icon;
		$[9] = label;
		$[10] = otherAnchorProps;
		$[11] = variant;
		$[12] = t5;
	} else t5 = $[12];
	const anchorProps = t5;
	let t6;
	if ($[13] !== actions || $[14] !== visibleChildEndIndex) {
		t6 = actions?.slice(visibleChildEndIndex);
		$[13] = actions;
		$[14] = visibleChildEndIndex;
		$[15] = t6;
	} else t6 = $[15];
	const overflowActions = t6;
	const hasOverflowActions = overflowActions && overflowActions.length > 0;
	const hasStaticMenuActions = staticMenuActions && staticMenuActions.length > 0;
	if (!hasOverflowActions && !hasStaticMenuActions) return null;
	let t7;
	if ($[16] !== anchorProps || $[17] !== anchorRef || $[18] !== hasStaticMenuActions || $[19] !== onOpenChange || $[20] !== open || $[21] !== overflowActions || $[22] !== staticMenuActions) {
		t7 = jsxs(ActionMenu, {
			anchorRef,
			open,
			onOpenChange,
			children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
				...testIdProps("overflow-menu-anchor"),
				...anchorProps
			}) }), jsx(ActionMenu.Overlay, {
				align: "end",
				"data-overflow-menu-overlay": true,
				children: jsxs(ActionList, { children: [hasStaticMenuActions && staticMenuActions.map(_temp$3), overflowActions?.map(_temp2$1)] })
			})]
		});
		$[16] = anchorProps;
		$[17] = anchorRef;
		$[18] = hasStaticMenuActions;
		$[19] = onOpenChange;
		$[20] = open;
		$[21] = overflowActions;
		$[22] = staticMenuActions;
		$[23] = t7;
	} else t7 = $[23];
	return t7;
};
OverflowMenu.displayName = "OverflowMenu";
function _temp$3(staticMenuAction) {
	return jsx(Fragment, { children: staticMenuAction.render() }, staticMenuAction.key);
}
function _temp2$1(action) {
	return jsx(Fragment, { children: action.render(true) }, action.key);
}
var VisibleAndOverflowContainer_module_default = {
	Box_0: "VisibleAndOverflowContainer-module_sH6FyG_Box_0",
	space: "VisibleAndOverflowContainer-module_sH6FyG_space"
};
var VisibleItem_module_default = { Box_0: "VisibleItem-module_A7iPDq_Box_0" };
var VisibleItem = ({ children, actionKey: key }) => {
	const itemRef = useRef(null);
	const { recalculateItemSize } = useActionBarResize();
	useIsomorphicLayoutEffect$1(() => {
		if (itemRef.current) recalculateItemSize(key, itemRef.current);
	}, [
		itemRef,
		recalculateItemSize,
		key
	]);
	return /* @__PURE__ */ jsx("div", {
		...testIdProps(`action-bar-item-${key}`),
		"data-action-bar-item": key,
		ref: itemRef,
		className: VisibleItem_module_default.Box_0,
		children
	});
};
VisibleItem.displayName = "VisibleItem";
var VisibleItems_module_default = { Box_1: "VisibleItems-module_MVUJma_Box_1" };
var VisibleItems = (t0) => {
	const $ = c(7);
	const { className, style } = t0;
	const { itemContainerRef } = useActionBarRef();
	const { actions, gap } = useActionBarContent();
	const { visibleChildEndIndex } = useActionBarResize();
	let t1;
	if ($[0] !== actions || $[1] !== className || $[2] !== gap || $[3] !== itemContainerRef || $[4] !== style || $[5] !== visibleChildEndIndex) {
		const visibleActions = actions?.slice(0, visibleChildEndIndex);
		t1 = jsx("div", {
			...testIdProps("action-bar"),
			ref: itemContainerRef,
			className: clsx(className, VisibleItems_module_default.Box_1),
			style: {
				gap,
				...style
			},
			children: visibleActions?.map(_temp$2)
		});
		$[0] = actions;
		$[1] = className;
		$[2] = gap;
		$[3] = itemContainerRef;
		$[4] = style;
		$[5] = visibleChildEndIndex;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
};
VisibleItems.displayName = "VisibleItems";
function _temp$2(t0) {
	const { key, render } = t0;
	return jsx(VisibleItem, {
		actionKey: key,
		children: render(false)
	}, key);
}
var VisibleAndOverflowContainer = (t0) => {
	const $ = c(5);
	const { overflowMenuToggleProps, overflowMenuProps, children, ...props } = t0;
	const { outerContainerRef } = useActionBarRef();
	const { label, variant, gap } = useActionBarContent();
	const { justifySpaceBetween } = useActionBarResize();
	const t1 = variant !== "toolbar";
	let t2;
	if ($[0] !== outerContainerRef || $[1] !== t1) {
		t2 = {
			containerRef: outerContainerRef,
			bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd,
			focusOutBehavior: "wrap",
			disabled: t1
		};
		$[0] = outerContainerRef;
		$[1] = t1;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== outerContainerRef) {
		t3 = [outerContainerRef];
		$[3] = outerContainerRef;
		$[4] = t3;
	} else t3 = $[4];
	useFocusZone(t2, t3);
	return jsxs("div", {
		ref: outerContainerRef,
		...testIdProps("action-bar-container"),
		role: variant === "toolbar" ? "toolbar" : void 0,
		"aria-label": variant === "toolbar" ? label : void 0,
		style: { gap },
		className: clsx(VisibleAndOverflowContainer_module_default.Box_0, justifySpaceBetween && VisibleAndOverflowContainer_module_default.space),
		children: [
			jsx(VisibleItems, { ...props }),
			children,
			jsx(OverflowMenu, {
				anchorProps: overflowMenuToggleProps,
				...overflowMenuProps
			})
		]
	});
};
VisibleAndOverflowContainer.displayName = "VisibleAndOverflowContainer";
var defaultDensity = "normal";
var InternalActionBar = ({ children, ...props }) => /* @__PURE__ */ jsx(VisibleAndOverflowContainer, {
	...props,
	children
});
InternalActionBar.displayName = "InternalActionBar";
var ActionBar = (t0) => {
	const $ = c(24);
	const { actions: t1, staticMenuActions, overflowMenuToggleProps, overflowMenuProps, children, label, variant, density: t2, anchorRef, className, style } = t0;
	let t3;
	if ($[0] !== t1) {
		t3 = t1 === void 0 ? [] : t1;
		$[0] = t1;
		$[1] = t3;
	} else t3 = $[1];
	const actions = t3;
	const density = t2 === void 0 ? defaultDensity : t2;
	let t4;
	if ($[2] !== density) {
		t4 = gapFromDensity(density);
		$[2] = density;
		$[3] = t4;
	} else t4 = $[3];
	let t5;
	if ($[4] !== actions || $[5] !== label || $[6] !== staticMenuActions || $[7] !== t4 || $[8] !== variant) {
		t5 = {
			actions,
			staticMenuActions,
			variant,
			label,
			gap: t4
		};
		$[4] = actions;
		$[5] = label;
		$[6] = staticMenuActions;
		$[7] = t4;
		$[8] = variant;
		$[9] = t5;
	} else t5 = $[9];
	const contentProviderValue = t5;
	let t6;
	if ($[10] !== actions) {
		t6 = actions.map(_temp$1);
		$[10] = actions;
		$[11] = t6;
	} else t6 = $[11];
	let t7;
	if ($[12] !== t6) {
		t7 = { actionKeys: t6 };
		$[12] = t6;
		$[13] = t7;
	} else t7 = $[13];
	const resizeProviderValue = t7;
	const hasStaticMenuActions = staticMenuActions && staticMenuActions.length > 0;
	const hasActions = actions && actions.length > 0;
	if (!hasActions && !hasStaticMenuActions) return null;
	let t8;
	if ($[14] !== anchorRef || $[15] !== children || $[16] !== className || $[17] !== contentProviderValue || $[18] !== hasActions || $[19] !== overflowMenuProps || $[20] !== overflowMenuToggleProps || $[21] !== resizeProviderValue || $[22] !== style) {
		const internalActionBarProps = {
			overflowMenuToggleProps,
			overflowMenuProps,
			className,
			style
		};
		t8 = jsx(ActionBarRefProvider, {
			value: { anchorRef },
			children: jsx(ActionBarContentProvider, {
				value: contentProviderValue,
				children: hasActions ? jsx(ActionBarResizeProvider, {
					value: resizeProviderValue,
					children: jsx(InternalActionBar, {
						...internalActionBarProps,
						children
					})
				}) : jsx(InternalActionBar, {
					...internalActionBarProps,
					children
				})
			})
		});
		$[14] = anchorRef;
		$[15] = children;
		$[16] = className;
		$[17] = contentProviderValue;
		$[18] = hasActions;
		$[19] = overflowMenuProps;
		$[20] = overflowMenuToggleProps;
		$[21] = resizeProviderValue;
		$[22] = style;
		$[23] = t8;
	} else t8 = $[23];
	return t8;
};
ActionBar.displayName = "ActionBar";
function _temp$1(action) {
	return action.key;
}
var prefersReducedMotionQuery;
function getQuery() {
	if (prefersReducedMotionQuery) return prefersReducedMotionQuery;
	return prefersReducedMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
}
function getPrefersReducedMotionServer() {
	return false;
}
function getPrefersReducedMotionClient() {
	return getQuery().matches;
}
function subscribe(notify) {
	const mediaQuery = getQuery();
	mediaQuery.addEventListener("change", notify);
	return () => {
		mediaQuery.removeEventListener("change", notify);
	};
}
function usePrefersReducedMotion() {
	return useSyncExternalStore(subscribe, getPrefersReducedMotionClient, getPrefersReducedMotionServer);
}
var DragAndDropContext = createContext(null);
DragAndDropContext.displayName = "DragAndDropContext";
function useBodyClass(className, dependency) {
	const $ = c(4);
	const hasAdded = useRef(false);
	let t0;
	let t1;
	if ($[0] !== className || $[1] !== dependency) {
		t0 = () => {
			if (Boolean(dependency)) {
				document.body.classList.add(className);
				hasAdded.current = true;
			} else {
				if (hasAdded.current) document.body.classList.remove(className);
				hasAdded.current = false;
			}
			return () => {
				if (hasAdded.current) document.body.classList.remove(className);
				hasAdded.current = false;
			};
		};
		t1 = [className, dependency];
		$[0] = className;
		$[1] = dependency;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
}
var RootElementContext = createContext(void 0);
RootElementContext.displayName = "RootElementContext";
function useRootElement() {
	return use(RootElementContext);
}
var DragAndDropResources = {
	instructions: (title) => `Moving ${title}.`,
	firstItemInList: "First item in list.",
	lastItemInList: "Last item in list.",
	movedBetween: (itemA, itemB) => `Between ${itemA} and ${itemB}.`,
	movePosition: "Move item one position",
	cancelDrag: "Cancel drag mode",
	endDrag: "Place item",
	cancelMove: (title) => `Cancel moving ${title}`,
	cancelMoveMultiple: (title, numberOfOtherItems) => `Cancel moving ${title} and ${numberOfOtherItems} other items`,
	successfulFirstMove: (title) => `${title} successfully moved to first item in list.`,
	successfulLastMove: (title) => `${title} successfully moved to last item in list.`,
	successfulMove: (titleA, titleB, titleC) => `${titleA} successfully moved between ${titleB} and ${titleC}.`,
	successfulNoMove: (title) => `${title} did not move.`,
	emptyAnnouncement: () => "",
	entryLessThanOne: "Entry must be greater than 0.",
	entryGreaterThanList: (length) => `Entry must be less than or equal to ${length}.`,
	entryIsRequired: "Entry is required.",
	entryIsInvalid: "Entry is invalid."
};
var DragAndDropMovingResources = {
	hasNotMoved: (title) => `${title} will be moved...`,
	itemWillNotBeMoved: (title) => `${title} will not be moved.`,
	movedToFirst: (title) => `${title} will be first item in the list.`,
	movedToLast: (title) => `${title} will be last item in the list.`,
	movedBetween: (title, item1, item2) => `${title} will be between ${item1} and ${item2}.`,
	cannotBeMoved: (title) => `${title} cannot be moved to an invalid position.`
};
var DragAndDropMoveOptions = {
	BEFORE: "Move item before",
	AFTER: "Move item after",
	ROW: "Move to position"
};
var emptyAnnouncement = () => "";
/**
* Announces a message to screen readers at a slowed-down rate. This is useful when you want to announce
* drag and drop movements to screen readers but you don't want to overwhelm the user with too many announcements
* in rapid succession. Do not use this function if interactions that trigger announcements do not happen rapidly.
*/
var debounceAnnouncement = debounce((announcement) => {
	announce$1(announcement, { assertive: true });
}, 100);
var defaultAnnouncementsOff = {
	onDragStart: emptyAnnouncement,
	onDragOver: emptyAnnouncement,
	onDragMove: emptyAnnouncement,
	onDragEnd: emptyAnnouncement,
	onDragCancel: emptyAnnouncement
};
function successfulMoveDialogAnnouncement({ newIndex, items, title, ...rest }) {
	const itemBeforeTitle = items[newIndex - 1]?.title;
	const itemAfterTitle = items[newIndex + 1]?.title;
	announce$1(getMoveDialogMessage({
		equalMessage: DragAndDropResources.successfulNoMove(title),
		firstPositionMessage: DragAndDropResources.successfulFirstMove(title),
		lastPositionMessage: DragAndDropResources.successfulLastMove(title),
		betweenBeforeMessage: DragAndDropResources.successfulMove(title, itemBeforeTitle, items[newIndex]?.title),
		betweenAfterMessage: DragAndDropResources.successfulMove(title, items[newIndex]?.title, itemAfterTitle),
		newIndex,
		items,
		...rest
	}), { assertive: true });
}
function getMoveDialogMessage({ equalMessage, firstPositionMessage, lastPositionMessage, betweenBeforeMessage, betweenAfterMessage, newIndex, currentIndex, items, moveAction }) {
	if (newIndex === currentIndex) return equalMessage;
	else if (newIndex === 0 && moveAction !== DragAndDropMoveOptions.AFTER) return firstPositionMessage;
	else if (newIndex === items.length - 1 && moveAction !== DragAndDropMoveOptions.BEFORE) return lastPositionMessage;
	else switch (moveAction) {
		case DragAndDropMoveOptions.BEFORE: return betweenBeforeMessage;
		case DragAndDropMoveOptions.AFTER: return betweenAfterMessage;
		case DragAndDropMoveOptions.ROW: if (newIndex < currentIndex) return betweenBeforeMessage;
		else return betweenAfterMessage;
	}
}
function successfulMoveAnnouncement({ newIndex, currentIndex, items, title }) {
	const itemIds = items.map((item) => item.id);
	if (newIndex === currentIndex) announce$1(DragAndDropResources.successfulNoMove(title), { assertive: true });
	else if (newIndex === 0) announce$1(DragAndDropResources.successfulFirstMove(title), { assertive: true });
	else if (newIndex === items.length - 1) announce$1(DragAndDropResources.successfulLastMove(title), { assertive: true });
	else {
		const itemA = newIndex <= currentIndex ? itemIds[newIndex - 1] : itemIds[newIndex + 1];
		const itemB = itemIds[newIndex];
		const itemATitle = items.find((item) => item.id === itemA)?.title ?? "";
		const itemBTitle = items.find((item) => item.id === itemB)?.title ?? "";
		announce$1(DragAndDropResources.successfulMove(title, itemATitle, itemBTitle), { assertive: true });
	}
}
var defaultKeyboardCodes = {
	start: [KeyboardCode.Space, KeyboardCode.Enter],
	cancel: [KeyboardCode.Esc],
	end: [KeyboardCode.Space, KeyboardCode.Enter]
};
var CustomKeyboardSensor = class extends KeyboardSensor {
	static activators = [{
		eventName: "onKeyDown",
		handler: (event, { keyboardCodes = defaultKeyboardCodes, onActivation }, { active }) => {
			const { code } = event.nativeEvent;
			if (keyboardCodes.start.includes(code)) {
				const activator = active.activatorNode.current;
				if (activator && event.target !== activator) return false;
				event.preventDefault();
				onActivation?.({ event: event.nativeEvent });
				return true;
			}
			return false;
		}
	}, {
		eventName: "onClick",
		handler: (event, { onActivation }) => {
			event.preventDefault();
			const keyboardEvent = new KeyboardEvent("keydown", {
				key: "Enter",
				code: "Enter"
			});
			onActivation?.({ event: keyboardEvent });
			return true;
		}
	}];
};
/**
* Works like `closestCenter` but along the vertical axis only. This is important for roadmap, where widths are
* infinite and the horizontal axis is not meaningful.
*/
var closestVerticalCenter = ({ collisionRect, droppableRects, droppableContainers }) => {
	const collisionRectCenter = (collisionRect.top + collisionRect.bottom) / 2;
	const collisions = [];
	for (const droppableContainer of droppableContainers) {
		const { id } = droppableContainer;
		const rect = droppableRects.get(id);
		if (rect) {
			const droppableRectCenter = (rect.top + rect.bottom) / 2;
			const distBetween = Math.abs(collisionRectCenter - droppableRectCenter);
			collisions.push({
				id,
				data: {
					droppableContainer,
					value: distBetween
				}
			});
		}
	}
	return collisions.sort((a, b) => a.data.value - b.data.value);
};
var DragAndDropContainer_module_default = {
	container: "DragAndDropContainer-module_LY8tpG_container",
	isKeyboardDragging: "DragAndDropContainer-module_LY8tpG_isKeyboardDragging"
};
/**
*
* @returns a method that will provide the hooks for drag and drop items
* when an item is selected.
*/
var useDragAndDrop = () => {
	const $ = c(13);
	const contextValue = use(DragAndDropContext);
	if (!contextValue) throw Error("useDragAndDrop can only be accessed from a DragAndDropContext.Provider component");
	const { overId, dragIndex, moveToPosition, items, direction, moveDialogItem, openMoveDialog, isInDragMode } = contextValue;
	let t0;
	if ($[0] !== overId) {
		t0 = (id) => {
			if (overId === id) return true;
			return null;
		};
		$[0] = overId;
		$[1] = t0;
	} else t0 = $[1];
	const isDropTarget = t0;
	let t1;
	if ($[2] !== dragIndex) {
		t1 = (index) => dragIndex !== null && index < dragIndex;
		$[2] = dragIndex;
		$[3] = t1;
	} else t1 = $[3];
	const isBefore = t1;
	let t2;
	if ($[4] !== direction || $[5] !== isBefore || $[6] !== isDropTarget || $[7] !== isInDragMode || $[8] !== items || $[9] !== moveDialogItem || $[10] !== moveToPosition || $[11] !== openMoveDialog) {
		t2 = {
			isDropTarget,
			isBefore,
			moveToPosition,
			items,
			direction,
			moveDialogItem,
			openMoveDialog,
			isInDragMode
		};
		$[4] = direction;
		$[5] = isBefore;
		$[6] = isDropTarget;
		$[7] = isInDragMode;
		$[8] = items;
		$[9] = moveDialogItem;
		$[10] = moveToPosition;
		$[11] = openMoveDialog;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
};
var MoveDialog_module_default = {
	dialogBody: "MoveDialog-module_cQjLFq_dialogBody",
	dialogTitle: "MoveDialog-module_cQjLFq_dialogTitle",
	form: "MoveDialog-module_cQjLFq_form",
	title: "MoveDialog-module_cQjLFq_title"
};
var MoveDialogForm_module_default = {
	autoComplete: "MoveDialogForm-module_8lpltG_autoComplete",
	datePickerAnchor: "MoveDialogForm-module_8lpltG_datePickerAnchor",
	form: "MoveDialogForm-module_8lpltG_form"
};
var MoveDialogContext = createContext({
	formLabel: "",
	onChange: () => {}
});
/**
* A form that allows the user to move an item to a new position in the list.
*
* @param props InputProps
*/
MoveDialogContext.displayName = "MoveDialogContext";
function MoveDialogForm(props) {
	const $ = c(16);
	const { formProps, setIsInvalidOption, setHelperText, helperTextId } = props;
	const { actions, onActionChange, actionsLabel } = formProps;
	const [selectedAction, setSelectedAction] = useState(actions[0]?.value);
	let t0;
	if ($[0] !== actions || $[1] !== onActionChange) {
		t0 = (event) => {
			onActionChange?.(event);
			const action = actions.find((a) => a.value === event.target.value);
			if (action) setSelectedAction(action.value);
		};
		$[0] = actions;
		$[1] = onActionChange;
		$[2] = t0;
	} else t0 = $[2];
	const onChange = t0;
	const t1 = selectedAction ?? "";
	let t2;
	if ($[3] !== setHelperText || $[4] !== setIsInvalidOption) {
		t2 = (helperText, isInValid) => {
			setHelperText(helperText);
			setIsInvalidOption(isInValid);
		};
		$[3] = setHelperText;
		$[4] = setIsInvalidOption;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== helperTextId || $[7] !== t1 || $[8] !== t2) {
		t3 = {
			formLabel: t1,
			onChange: t2,
			helperTextId
		};
		$[6] = helperTextId;
		$[7] = t1;
		$[8] = t2;
		$[9] = t3;
	} else t3 = $[9];
	const t4 = t3;
	let t5;
	if ($[10] !== actions || $[11] !== actionsLabel || $[12] !== onChange || $[13] !== selectedAction || $[14] !== t4) {
		t5 = jsx(MoveDialogContext, {
			value: t4,
			children: jsxs("div", {
				className: clsx(MoveDialogForm_module_default.form),
				children: [actions.length > 1 && jsxs(FormControl$1, {
					required: true,
					children: [jsx(FormControl$1.Label, { children: actionsLabel ?? "Action" }), jsx(Select$1, {
						block: true,
						onChange,
						children: actions.map(_temp)
					})]
				}), actions.find((a_0) => a_0.value === selectedAction)?.renderInput]
			})
		});
		$[10] = actions;
		$[11] = actionsLabel;
		$[12] = onChange;
		$[13] = selectedAction;
		$[14] = t4;
		$[15] = t5;
	} else t5 = $[15];
	return t5;
}
MoveDialogForm.displayName = "MoveDialogForm";
function _temp(action_0) {
	return jsx(Select$1.Option, {
		value: action_0.value,
		children: action_0.value
	}, action_0.value);
}
var SingleSelect = ({ ref, ...props }) => {
	const { helperText, isInvalid, ...rest } = props;
	const { formLabel, onChange: parentOnChange, helperTextId } = use(MoveDialogContext);
	useEffect(() => {
		parentOnChange(helperText ?? "", !!isInvalid);
	}, [
		helperText,
		isInvalid,
		parentOnChange
	]);
	return /* @__PURE__ */ jsxs(FormControl$1, {
		required: true,
		children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: formLabel }), /* @__PURE__ */ jsx(Select$1, {
			block: true,
			"aria-invalid": isInvalid,
			validationStatus: isInvalid ? "error" : void 0,
			"aria-describedby": helperTextId,
			ref,
			...rest
		})]
	});
};
SingleSelect.displayName = "SingleSelect";
SingleSelect.displayName = "MoveDialogForm.SingleSelect";
var Text = ({ ref, ...props }) => {
	const { isInvalid, helperText, ...rest } = props;
	const { formLabel, onChange: parentOnChange, helperTextId } = use(MoveDialogContext);
	useEffect(() => {
		parentOnChange(helperText, !!isInvalid);
	}, [
		helperText,
		isInvalid,
		parentOnChange
	]);
	return /* @__PURE__ */ jsxs(FormControl$1, {
		required: true,
		children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: formLabel }), /* @__PURE__ */ jsx(TextInput$1, {
			block: true,
			"aria-invalid": isInvalid,
			validationStatus: isInvalid ? "error" : void 0,
			"aria-describedby": helperTextId,
			ref,
			...rest
		})]
	});
};
Text.displayName = "Text";
Text.displayName = "MoveDialogForm.Text";
function MultiSelect(props) {
	const $ = c(5);
	const { isInvalid, helperText, ...rest } = props;
	const { formLabel, onChange: parentOnChange } = use(MoveDialogContext);
	let t0;
	let t1;
	if ($[0] !== helperText || $[1] !== isInvalid || $[2] !== parentOnChange) {
		t0 = () => {
			parentOnChange(helperText, !!isInvalid);
		};
		t1 = [
			helperText,
			isInvalid,
			parentOnChange
		];
		$[0] = helperText;
		$[1] = isInvalid;
		$[2] = parentOnChange;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	useEffect(t0, t1);
	const renderAnchor = _temp2;
	const selectPanelProps = {
		...rest,
		renderAnchor
	};
	return jsxs(FormControl$1, {
		required: true,
		children: [jsx(FormControl$1.Label, { children: formLabel }), jsx(SelectPanel, { ...selectPanelProps })]
	});
}
MultiSelect.displayName = "MultiSelect";
function _temp2(buttonProps) {
	const { children, ...otherProps } = buttonProps;
	return jsx(ButtonComponent, {
		trailingAction: TriangleDownIcon,
		block: true,
		...otherProps,
		children
	});
}
function DateInput(props) {
	const $ = c(5);
	const { isInvalid, helperText, ...datePickerProps } = props;
	const { formLabel, onChange: parentOnChange, helperTextId } = use(MoveDialogContext);
	const defaultDatePickerProps = {
		anchor: "button",
		anchorClassName: MoveDialogForm_module_default.datePickerAnchor,
		compressedHeader: false,
		confirmation: false,
		confirmUnsavedClose: true,
		dateFormat: "long",
		placeholder: formLabel,
		showTodayButton: true,
		showClearButton: false,
		variant: "single",
		weekStartsOn: "Sunday"
	};
	let t0;
	let t1;
	if ($[0] !== helperText || $[1] !== isInvalid || $[2] !== parentOnChange) {
		t0 = () => {
			parentOnChange(helperText, !!isInvalid);
		};
		t1 = [
			helperText,
			isInvalid,
			parentOnChange
		];
		$[0] = helperText;
		$[1] = isInvalid;
		$[2] = parentOnChange;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	useEffect(t0, t1);
	const merged = {
		...defaultDatePickerProps,
		...datePickerProps
	};
	return jsxs(FormControl$1, {
		required: true,
		children: [jsx(FormControl$1.Label, { children: formLabel }), jsx(DatePicker, {
			...merged,
			"aria-describedby": helperTextId,
			fieldName: formLabel
		})]
	});
}
DateInput.displayName = "DateInput";
MoveDialogForm.SingleSelect = SingleSelect;
MoveDialogForm.Text = Text;
MoveDialogForm.MultiSelect = MultiSelect;
MoveDialogForm.Date = DateInput;
MoveDialogForm.SingleSelectOption = Select$1.Option;
/***
* STATUS: Experimental - This component is not ready for production
* The Accessibility Team is actively working on this component.
* Please reach out to #accessibility with any questions.
*/
var MOVE_DIALOG_TITLE_ID = "move-dialog-title";
/**
* A dialog that allows the user to move an item to a new position in the list.
*
* @param props MoveDialogProps
*/
var MoveDialog = ({ closeDialog, onSubmit: onSubmitProp, formProps, title, submitButtonLabel, returnFocusRef, ...rest }) => {
	const [isInvalidOption, setIsInvalidOption] = useState(false);
	const [showErrorDialog, setShowErrorDialog] = useState(false);
	let singleSelectedItemValue = "";
	let firstSelectedMultiselectItem;
	if (!rest.multiSelectItems) singleSelectedItemValue = rest.selectedItem.value;
	else firstSelectedMultiselectItem = rest.selectPanelProps.selected[0];
	const [helperText, setHelperText] = useState("");
	const helperTextId = useId();
	const containerRef = useRef(null);
	useOnOutsideClick({
		containerRef,
		onClickOutside: (e) => e.preventDefault()
	});
	const onSubmit = async (event) => {
		event.preventDefault();
		if (isInvalidOption) {
			const invalidField = containerRef.current?.querySelector("[aria-invalid=\"true\"]");
			if (invalidField) invalidField.focus();
			return;
		}
		await onSubmitProp?.(event);
	};
	const onSelectedChange = (selected) => {
		if (!rest.multiSelectItems) return;
		if (selected[0] !== firstSelectedMultiselectItem) setShowErrorDialog(true);
		else rest.selectPanelProps.onSelectedChange?.(selected);
	};
	const renderAnchor = (buttonProps) => {
		const { children, ...otherProps } = buttonProps;
		return /* @__PURE__ */ jsx(ButtonComponent, {
			trailingAction: TriangleDownIcon,
			block: true,
			...otherProps,
			children
		});
	};
	let selectPanelProps;
	if (rest.multiSelectItems) selectPanelProps = {
		...rest.selectPanelProps,
		selected: rest.selectPanelProps.selected,
		onSelectedChange,
		renderAnchor
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Dialog, {
		title: /* @__PURE__ */ jsx("span", {
			className: clsx(MoveDialog_module_default.title),
			id: MOVE_DIALOG_TITLE_ID,
			...testIdProps(MOVE_DIALOG_TITLE_ID),
			children: title ?? (rest.multiSelectItems ? "Move selected items" : "Move selected item")
		}),
		onClose: () => {
			closeDialog();
			if (!rest.multiSelectItems) announce$1(DragAndDropResources.cancelMove(singleSelectedItemValue), { assertive: true });
			else {
				const selectedItems = rest.selectPanelProps.selected;
				announce$1(DragAndDropResources.cancelMoveMultiple(selectedItems[0]?.text ?? "", selectedItems?.length ?? 0), { assertive: true });
			}
		},
		width: "large",
		ref: containerRef,
		renderBody: () => /* @__PURE__ */ jsxs("form", {
			onSubmit,
			...testIdProps("move-dialog-form"),
			onBlur: (e_0) => e_0.stopPropagation(),
			className: clsx(MoveDialog_module_default.form),
			noValidate: true,
			"aria-labelledby": MOVE_DIALOG_TITLE_ID,
			children: [/* @__PURE__ */ jsxs(Dialog.Body, {
				className: clsx(MoveDialog_module_default.dialogBody),
				children: [
					/* @__PURE__ */ jsx("div", {
						className: clsx(MoveDialog_module_default.dialogTitle),
						children: rest.multiSelectItems ? /* @__PURE__ */ jsxs(FormControl$1, {
							required: true,
							children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
								requiredIndicator: false,
								children: "Item(s)"
							}), /* @__PURE__ */ jsx(SelectPanel, { ...selectPanelProps })]
						}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
							className: "text-bold pb-1",
							children: "Item"
						}), /* @__PURE__ */ jsx("span", { children: singleSelectedItemValue })] })
					}),
					/* @__PURE__ */ jsx(MoveDialogForm, {
						formProps,
						setHelperText,
						setIsInvalidOption,
						helperTextId
					}),
					/* @__PURE__ */ jsxs(Flash, {
						"aria-live": "assertive",
						variant: isInvalidOption ? "danger" : "default",
						id: helperTextId,
						...testIdProps("drag-and-drop-move-dialog-flash"),
						children: [isInvalidOption ? /* @__PURE__ */ jsx(AlertIcon, {}) : /* @__PURE__ */ jsx(InfoIcon, {}), helperText]
					})
				]
			}), /* @__PURE__ */ jsx(Dialog.Footer, {
				className: "p-2",
				children: /* @__PURE__ */ jsx(ButtonComponent, {
					type: "submit",
					variant: "primary",
					...testIdProps("drag-and-drop-move-dialog-move-item-button"),
					children: submitButtonLabel ?? "Move"
				})
			})]
		}),
		returnFocusRef
	}), showErrorDialog && /* @__PURE__ */ jsxs(Dialog, {
		width: "large",
		title: "Missing selection",
		onClose: () => {
			if (rest.multiSelectItems) setShowErrorDialog(false);
		},
		children: [/* @__PURE__ */ jsx(Dialog.Body, {
			className: clsx(MoveDialog_module_default.dialogBody),
			children: "The first item you selected cannot be deselected when performing a move."
		}), /* @__PURE__ */ jsx(Dialog.Footer, {
			className: "p-2",
			children: /* @__PURE__ */ jsx(ButtonComponent, {
				type: "submit",
				variant: "primary",
				onClick: () => {
					if (rest.multiSelectItems) setShowErrorDialog(false);
				},
				children: "I understand"
			})
		})]
	})] });
};
MoveDialog.displayName = "MoveDialog";
var isValidBeforeMove = (index, initialIndex) => {
	return index !== initialIndex + 1 && index !== initialIndex;
};
var isValidAfterMove = (index, initialIndex) => {
	return index !== initialIndex - 1 && index !== initialIndex;
};
var errorMessage = (items, index) => {
	if (index === void 0) return DragAndDropResources.entryIsRequired;
	if (index < 0) return DragAndDropResources.entryLessThanOne;
	if (index > items.length) return DragAndDropResources.entryGreaterThanList(items.length);
	return DragAndDropResources.entryIsInvalid;
};
var isInvalid = (items, index) => index === void 0 || index < 0 || index >= items.length || isNaN(index);
var DragAndDropMoveDialog = ({ closeDialog, dialogTitle, returnFocusRef }) => {
	const inputRef = useRef(null);
	const { moveDialogItem, moveToPosition, items } = useDragAndDrop();
	const { title, index: dragIndex } = moveDialogItem ?? {
		title: "",
		index: -1
	};
	const [invalid, setInvalid] = useState(false);
	const [dropIndex, setDropIndex] = useState();
	const [moveAction, setMoveAction] = useState(items.some((__0, index_0) => isValidBeforeMove(index_0, dragIndex)) ? DragAndDropMoveOptions.BEFORE : items.some((_, index) => isValidAfterMove(index, dragIndex)) ? DragAndDropMoveOptions.AFTER : DragAndDropMoveOptions.ROW);
	const [helperText, setHelpText] = useState("");
	const debouncedUpdateHelperText = useDebounce(useMemo(() => (idx) => {
		let message = "";
		if (idx === void 0 || isInvalid(items, idx)) message = errorMessage(items, idx);
		else {
			const itemBeforeTitle = items[idx - 1]?.title;
			const itemAfterTitle = items[idx + 1]?.title;
			message = getMoveDialogMessage({
				equalMessage: DragAndDropMovingResources.itemWillNotBeMoved(title),
				firstPositionMessage: DragAndDropMovingResources.movedToFirst(title),
				lastPositionMessage: DragAndDropMovingResources.movedToLast(title),
				betweenBeforeMessage: DragAndDropMovingResources.movedBetween(title, itemBeforeTitle, items[idx]?.title),
				betweenAfterMessage: DragAndDropMovingResources.movedBetween(title, items[idx]?.title, itemAfterTitle),
				newIndex: idx,
				currentIndex: dragIndex,
				items,
				moveAction
			});
		}
		setHelpText(message);
	}, [
		title,
		dragIndex,
		moveAction,
		items
	]), 100);
	useEffect(() => {
		if (inputRef.current?.value) {
			const indexConversion = moveAction === DragAndDropMoveOptions.ROW ? -1 : 0;
			const value = parseInt(inputRef.current?.value, 10) + indexConversion;
			setDropIndex(isNaN(value) ? void 0 : value);
			debouncedUpdateHelperText(isNaN(value) ? void 0 : value);
		}
	}, [
		debouncedUpdateHelperText,
		inputRef,
		moveAction
	]);
	const onSubmit = async () => {
		if (dropIndex === void 0) return;
		switch (moveAction) {
			case DragAndDropMoveOptions.ROW:
				if (dropIndex >= dragIndex) await moveToPosition(dragIndex, dropIndex, false);
				else await moveToPosition(dragIndex, dropIndex, true);
				break;
			case DragAndDropMoveOptions.BEFORE:
				await moveToPosition(dragIndex, dropIndex, true);
				break;
			case DragAndDropMoveOptions.AFTER:
			default:
				await moveToPosition(dragIndex, dropIndex, false);
				break;
		}
		closeDialog();
		successfulMoveDialogAnnouncement({
			newIndex: dropIndex,
			currentIndex: dragIndex,
			items,
			title,
			moveAction
		});
	};
	const onInputChange = (value_0) => {
		if (isInvalid(items, value_0)) setInvalid(true);
		else setInvalid(false);
		setDropIndex(value_0 && isNaN(value_0) ? void 0 : value_0);
		debouncedUpdateHelperText(value_0);
	};
	return /* @__PURE__ */ jsx(MoveDialog, {
		closeDialog,
		title: dialogTitle,
		formProps: {
			actions: [
				...items.some((__1, index_2) => isValidBeforeMove(index_2, dragIndex)) ? [{
					value: DragAndDropMoveOptions.BEFORE,
					renderInput: /* @__PURE__ */ jsx(MoveDialogForm.SingleSelect, {
						ref: moveAction === DragAndDropMoveOptions.BEFORE ? inputRef : void 0,
						helperText,
						onChange: (e) => {
							const value_1 = e.currentTarget.value;
							onInputChange(Number(value_1));
						},
						isInvalid: false,
						...testIdProps("drag-and-drop-move-dialog-position-input"),
						children: items.map((item, index_1) => {
							if (isValidBeforeMove(index_1, dragIndex)) return /* @__PURE__ */ jsx(Select$1.Option, {
								value: index_1.toString(),
								children: item.title
							}, `${item.title}-${index_1 + 1}`);
						})
					})
				}] : [],
				...items.some((__2, index_4) => isValidAfterMove(index_4, dragIndex)) ? [{
					value: DragAndDropMoveOptions.AFTER,
					renderInput: /* @__PURE__ */ jsx(MoveDialogForm.SingleSelect, {
						ref: moveAction === DragAndDropMoveOptions.AFTER ? inputRef : void 0,
						helperText,
						onChange: (e_0) => {
							const value_2 = e_0.currentTarget.value;
							onInputChange(Number(value_2));
						},
						isInvalid: false,
						...testIdProps("drag-and-drop-move-dialog-position-input"),
						children: items.map((item_0, index_3) => {
							if (isValidAfterMove(index_3, dragIndex)) return /* @__PURE__ */ jsx(Select$1.Option, {
								value: index_3.toString(),
								children: item_0.title
							}, `${item_0.title}-${index_3 + 1}`);
						})
					})
				}] : [],
				{
					value: DragAndDropMoveOptions.ROW,
					renderInput: /* @__PURE__ */ jsx(MoveDialogForm.Text, {
						ref: moveAction === DragAndDropMoveOptions.ROW ? inputRef : void 0,
						helperText,
						min: 1,
						max: items.length,
						defaultValue: dragIndex + 1,
						type: "number",
						onChange: (e_1) => {
							onInputChange(e_1.currentTarget.value ? parseInt(e_1.currentTarget.value, 10) - 1 : void 0);
						},
						isInvalid: invalid,
						...testIdProps("drag-and-drop-move-dialog-position-input")
					})
				}
			],
			onActionChange: (e_2) => {
				setMoveAction(e_2.target.value);
				setInvalid(false);
			}
		},
		selectedItem: { value: title },
		onSubmit,
		returnFocusRef
	});
};
DragAndDropMoveDialog.displayName = "DragAndDropMoveDialog";
var KeyboardSpecificInstructionsDialog_module_default = {
	footerButton: "KeyboardSpecificInstructionsDialog-module_MgRgjG_footerButton",
	footerContainer: "KeyboardSpecificInstructionsDialog-module_MgRgjG_footerContainer",
	footerForm: "KeyboardSpecificInstructionsDialog-module_MgRgjG_footerForm",
	instruction: "KeyboardSpecificInstructionsDialog-module_MgRgjG_instruction",
	instructionContainer: "KeyboardSpecificInstructionsDialog-module_MgRgjG_instructionContainer"
};
var HideKeyboardSpecificInstructionsDialogKey = "hideKeyboardSpecificInstructions";
var KeyboardSpecificInstructionsFooter = (t0) => {
	const $ = c(7);
	const { onClose } = t0;
	const [doNotShowAgain, setDoNotShowAgain] = useLocalStorage(HideKeyboardSpecificInstructionsDialogKey, false);
	let t1;
	if ($[0] !== doNotShowAgain || $[1] !== onClose || $[2] !== setDoNotShowAgain) {
		let t2;
		if ($[4] !== doNotShowAgain || $[5] !== setDoNotShowAgain) {
			t2 = () => setDoNotShowAgain(!doNotShowAgain);
			$[4] = doNotShowAgain;
			$[5] = setDoNotShowAgain;
			$[6] = t2;
		} else t2 = $[6];
		t1 = jsxs("div", {
			className: clsx(KeyboardSpecificInstructionsDialog_module_default.footerContainer),
			children: [jsx("div", {
				className: clsx(KeyboardSpecificInstructionsDialog_module_default.footerForm),
				children: jsxs(FormControl$1, { children: [jsx(Checkbox, {
					checked: doNotShowAgain,
					onChange: t2
				}), jsx(FormControl$1.Label, { children: "Don't show this again" })] })
			}), jsx("div", {
				className: clsx(KeyboardSpecificInstructionsDialog_module_default.footerButton),
				children: jsx(ButtonComponent, {
					onClick: onClose,
					children: "Close"
				})
			})]
		});
		$[0] = doNotShowAgain;
		$[1] = onClose;
		$[2] = setDoNotShowAgain;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
KeyboardSpecificInstructionsFooter.displayName = "KeyboardSpecificInstructionsFooter";
var KeyboardSpecificInstructionsDialog = ({ isOpen, onClose, direction, keyboardCodes = defaultKeyboardCodes }) => {
	if (!isOpen) return null;
	const onKeyDown = (e) => {
		e.stopPropagation();
		if (e.code === "Escape") onClose();
	};
	return /* @__PURE__ */ jsx("div", {
		onKeyDown,
		children: /* @__PURE__ */ jsx(Dialog, {
			title: "How to move objects via keyboard",
			subtitle: "This navigation is only available when move mode is activated.",
			onClose,
			renderFooter: () => /* @__PURE__ */ jsx(Dialog.Footer, {
				className: "d-flex",
				children: /* @__PURE__ */ jsx(KeyboardSpecificInstructionsFooter, { onClose })
			}),
			children: /* @__PURE__ */ jsxs("table", {
				className: clsx(KeyboardSpecificInstructionsDialog_module_default.instructionContainer),
				children: [/* @__PURE__ */ jsx("thead", {
					className: "sr-only",
					children: /* @__PURE__ */ jsxs("tr", { children: [/* @__PURE__ */ jsx("th", {
						className: "text=bold",
						children: "Action"
					}), /* @__PURE__ */ jsx("th", {
						className: "text=bold",
						children: "Keyboard Shortcut"
					})] })
				}), /* @__PURE__ */ jsxs("tbody", { children: [
					/* @__PURE__ */ jsxs("tr", {
						className: clsx(KeyboardSpecificInstructionsDialog_module_default.instruction),
						children: [/* @__PURE__ */ jsx("td", { children: DragAndDropResources.cancelDrag }), /* @__PURE__ */ jsx("td", { children: keyboardCodes.cancel.map((key, index) => /* @__PURE__ */ jsxs(Fragment, { children: [index > 0 && /* @__PURE__ */ jsx("span", { children: " / " }), /* @__PURE__ */ jsx(KeybindingHint, { keys: key })] }, key)) })]
					}),
					/* @__PURE__ */ jsxs("tr", {
						className: clsx(KeyboardSpecificInstructionsDialog_module_default.instruction),
						children: [/* @__PURE__ */ jsx("td", { children: DragAndDropResources.movePosition }), /* @__PURE__ */ jsxs("td", { children: [
							/* @__PURE__ */ jsx(KeybindingHint, { keys: direction === "vertical" ? "up" : "left" }),
							/* @__PURE__ */ jsx("span", { children: " / " }),
							/* @__PURE__ */ jsx(KeybindingHint, { keys: direction === "vertical" ? "down" : "right" })
						] })]
					}),
					/* @__PURE__ */ jsxs("tr", {
						className: clsx(KeyboardSpecificInstructionsDialog_module_default.instruction, "border-bottom-0"),
						children: [/* @__PURE__ */ jsx("td", { children: DragAndDropResources.endDrag }), /* @__PURE__ */ jsx("td", { children: keyboardCodes.end.map((key, index) => /* @__PURE__ */ jsxs(Fragment, { children: [index > 0 && /* @__PURE__ */ jsx("span", { children: " / " }), /* @__PURE__ */ jsx("kbd", {
							className: "bgColor-default box-shadow-none fgColor-muted",
							children: key.toLowerCase()
						})] }, key)) })]
					})
				] })]
			})
		})
	});
};
KeyboardSpecificInstructionsDialog.displayName = "KeyboardSpecificInstructionsDialog";
/**
* A container for a list of sortable items. This component is responsible for
* managing the drag and drop state and passing it down to the items.
*
* @param props DragAndDropProps
*/
var DragAndDropContainer = ({ onDrop, items, direction = "vertical", children, as: As = "ul", renderOverlay, keyboardCodes, enableTouch = false, ...htmlULprops }, ref) => {
	const [isDragging, setIsDragging] = useState(false);
	const [overIndex, setOverIndex] = useState(0);
	const [hasMoved, setHasMoved] = useState(false);
	const [dragIndex, setDragIndex] = useState(0);
	const [overId, setOverId] = useState(null);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const [doNotShowAgain] = useLocalStorage(HideKeyboardSpecificInstructionsDialogKey, false);
	const [isKeyboardDragging, setIsKeyboardDragging] = useState(false);
	const [moveDialogItem, setMoveDialogItem] = useState(null);
	const itemIds = items.map((item) => item.id);
	const titleMap = useMemo(() => {
		return items.reduce((map, item_0) => {
			map[item_0.id] = item_0.title;
			return map;
		}, {});
	}, [items]);
	useBodyClass("is-dragging", isDragging);
	useBodyClass(DragAndDropContainer_module_default.isKeyboardDragging ?? "", isKeyboardDragging);
	const [lastFocusedItem, setLastFocusedItem] = useState(null);
	const prefersReducedMotion = usePrefersReducedMotion();
	const onInstructionsClose = useCallback(() => {
		setIsDialogOpen(false);
	}, []);
	const handleDragStart = useCallback((event) => {
		if (!event.active) return;
		announce$1(DragAndDropResources.instructions(titleMap[event.active.id] ?? event.active.id), { assertive: true });
		const dragMetadata = event.active.data.current?.metadata;
		setOverId(dragMetadata?.id ?? null);
		setDragIndex(event.active.data.current?.sortable.index ?? 0);
		setOverIndex(event.active.data.current?.sortable.index ?? 0);
		setIsDragging(true);
	}, [titleMap]);
	const handleDragMove = useCallback((event_0) => {
		setOverId((event_0.over?.data.current?.metadata)?.id ?? null);
		if (!hasMoved) setHasMoved(true);
		if (event_0.over && event_0.over.data.current) {
			const positionIndex = event_0.over.data.current.sortable.index;
			setOverIndex(positionIndex);
		}
	}, [hasMoved]);
	useEffect(() => {
		if (isDragging && hasMoved) if (overIndex === 0) debounceAnnouncement(DragAndDropResources.firstItemInList);
		else if (overIndex === itemIds.length - 1) debounceAnnouncement(DragAndDropResources.lastItemInList);
		else {
			const isBefore = overIndex <= dragIndex;
			const originalPlacement = overIndex === dragIndex;
			const itemA = isBefore ? itemIds[overIndex - 1] : itemIds[overIndex + 1];
			const itemB = originalPlacement ? itemIds[overIndex + 1] : itemIds[overIndex];
			debounceAnnouncement(DragAndDropResources.movedBetween(titleMap[itemA], titleMap[itemB]));
		}
	}, [
		isDragging,
		hasMoved,
		overIndex,
		titleMap,
		itemIds,
		dragIndex
	]);
	const handleDragCancel = useCallback((event_1) => {
		announce$1(`${titleMap[event_1.active.id] ?? event_1.active.id} not moved.`, { assertive: true });
		setIsDragging(false);
		setIsKeyboardDragging(false);
		setHasMoved(false);
		setTimeout(() => {
			document.activeElement?.scrollIntoView({
				behavior: prefersReducedMotion ? "instant" : "smooth",
				block: "nearest"
			});
		}, 1);
	}, [titleMap, prefersReducedMotion]);
	const handleDragEnd = useCallback((event_2) => {
		setIsDragging(false);
		setIsKeyboardDragging(false);
		setHasMoved(false);
		if (!event_2.active || !event_2.over) return;
		const dragMetadata_0 = event_2.active.data.current?.metadata;
		const dropMetadata = event_2.over.data.current?.metadata;
		if (dragMetadata_0?.id !== dropMetadata?.id) onDrop({
			dragMetadata: dragMetadata_0,
			dropMetadata,
			isBefore: overIndex < dragIndex
		});
		setOverId(null);
		successfulMoveAnnouncement({
			newIndex: overIndex,
			currentIndex: dragIndex,
			items,
			title: titleMap[event_2.active.id]
		});
	}, [
		overIndex,
		dragIndex,
		items,
		titleMap,
		onDrop
	]);
	const moveToPosition = useCallback((currentPosition, newPosition, isBefore_1) => {
		setOverId(itemIds[newPosition] ?? null);
		const drag = itemIds[currentPosition];
		const drop = itemIds[newPosition];
		if (drag && drop) onDrop({
			dragMetadata: { id: drag },
			dropMetadata: { id: drop },
			isBefore: isBefore_1 ?? newPosition < currentPosition
		});
	}, [itemIds, onDrop]);
	const rootElement = useRootElement();
	const onActivation = useMemo(() => {
		return () => {
			if (!hasMoved && !doNotShowAgain) setIsDialogOpen(true);
			setIsKeyboardDragging(true);
		};
	}, [doNotShowAgain, hasMoved]);
	const onOpenMoveDialog = useCallback((title, index, returnFocusRef) => {
		setMoveDialogItem({
			title,
			index,
			returnFocusRef
		});
	}, []);
	const touchSensor = useSensor(TouchSensor);
	const mouseSensor = useSensor(MouseSensor);
	const keyboardSensor = useSensor(CustomKeyboardSensor, {
		coordinateGetter: sortableKeyboardCoordinates,
		keyboardCodes,
		onActivation
	});
	const sensors = useSensors(...useMemo(() => {
		return enableTouch ? [
			mouseSensor,
			touchSensor,
			keyboardSensor
		] : [mouseSensor, keyboardSensor];
	}, [
		enableTouch,
		mouseSensor,
		touchSensor,
		keyboardSensor
	]));
	useEffect(() => {
		lastFocusedItem?.focus();
		setLastFocusedItem(null);
	}, [lastFocusedItem]);
	const dragItem = items[dragIndex];
	const { isBrowser } = useRuntimeEnvironment();
	const body = isBrowser ? ssrSafeDocument?.body ?? null : null;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(KeyboardSpecificInstructionsDialog, {
		isOpen: isDialogOpen,
		onClose: onInstructionsClose,
		direction,
		keyboardCodes
	}), /* @__PURE__ */ jsx(DndContext, {
		collisionDetection: useMemo(() => direction === "horizontal" ? closestCorners : closestVerticalCenter, [direction]),
		modifiers: useMemo(() => {
			return direction === "horizontal" ? [restrictToHorizontalAxis] : [restrictToVerticalAxis];
		}, [direction]),
		sensors,
		onDragStart: handleDragStart,
		onDragOver: handleDragMove,
		onDragEnd: handleDragEnd,
		onDragCancel: handleDragCancel,
		accessibility: useMemo(() => ({
			container: rootElement,
			announcements: defaultAnnouncementsOff
		}), [rootElement]),
		children: /* @__PURE__ */ jsx(SortableContext, {
			items: itemIds,
			strategy: useMemo(() => direction === "horizontal" ? horizontalListSortingStrategy : verticalListSortingStrategy, [direction]),
			children: /* @__PURE__ */ jsxs(DragAndDropContext, {
				value: useMemo(() => ({
					overId,
					dragIndex,
					moveToPosition,
					items,
					direction,
					openMoveDialog: onOpenMoveDialog,
					moveDialogItem,
					isInDragMode: isDragging && !isDialogOpen
				}), [
					overId,
					dragIndex,
					moveToPosition,
					items,
					direction,
					onOpenMoveDialog,
					moveDialogItem,
					isDragging,
					isDialogOpen
				]),
				children: [
					moveDialogItem && /* @__PURE__ */ jsx(DragAndDropMoveDialog, { closeDialog: () => {
						setMoveDialogItem(null);
						setLastFocusedItem(moveDialogItem?.returnFocusRef?.current ?? null);
					} }),
					/* @__PURE__ */ jsx(As, {
						...htmlULprops,
						ref,
						className: clsx(DragAndDropContainer_module_default.container, htmlULprops.className),
						...testIdProps("sortable-list"),
						onKeyDown: (event_3) => {
							if (isDragging && event_3.code === "Tab") event_3.preventDefault();
						},
						children
					}),
					body ? createPortal(/* @__PURE__ */ jsx(DragOverlay, {
						dropAnimation: null,
						className: clsx(DragAndDropContainer_module_default.container),
						children: dragItem && !isDialogOpen ? renderOverlay(dragItem, dragIndex) : null
					}), body) : null
				]
			})
		})
	})] });
};
DragAndDropContainer.displayName = "DragAndDropContainer";
var DragAndDropItemContext = createContext({
	title: "",
	index: 0,
	id: ""
});
DragAndDropItemContext.displayName = "DragAndDropItemContext";
var DragAndDropItem_module_default = {
	contents: "DragAndDropItem-module_K1LYea_contents",
	dragItem: "DragAndDropItem-module_K1LYea_dragItem",
	dragOverlay: "DragAndDropItem-module_K1LYea_dragOverlay",
	horizontal: "DragAndDropItem-module_K1LYea_horizontal",
	vertical: "DragAndDropItem-module_K1LYea_vertical"
};
var useDragAndDropItem = () => {
	const context = use(DragAndDropItemContext);
	if (!context) throw new Error("useDragAndDropItem must be used within a DragAndDropItemContextProvider");
	return context;
};
var DragAndDropTrigger_module_default = {
	buttonTrigger: "DragAndDropTrigger-module_ZTm3uG_buttonTrigger",
	hideDragHandler: "DragAndDropTrigger-module_ZTm3uG_hideDragHandler",
	isKeyboardDragging: "DragAndDropTrigger-module_ZTm3uG_isKeyboardDragging",
	mouseTrigger: "DragAndDropTrigger-module_ZTm3uG_mouseTrigger",
	touchEnabled: "DragAndDropTrigger-module_ZTm3uG_touchEnabled",
	trigger: "DragAndDropTrigger-module_ZTm3uG_trigger"
};
/**
* The trigger button that activates the drag and drop of a sortable item. It is HIGHLY recommended to use
* this component to trigger drag and drop since it includes additional accessibility features
* to make the drag and drop experience work more robustly with screen readers.
*/
function DragAndDropTrigger({ ref: forwardedRef = null, ...props }) {
	const { title, id } = useDragAndDropItem();
	const { setActivatorNodeRef, listeners, isDragging, items } = useSortable({
		id,
		data: { metadata: { id } }
	});
	const ref = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, ref);
	const { onMouseDown, onClick, onKeyDown, onTouchStart } = listeners;
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("sortable-trigger-container"),
		className: clsx(DragAndDropTrigger_module_default.trigger, items.length === 1 ? DragAndDropTrigger_module_default.hideDragHandler : DragAndDropTrigger_module_default.touchEnabled),
		children: [/* @__PURE__ */ jsx("div", {
			onMouseDown,
			onTouchStart,
			className: clsx(DragAndDropTrigger_module_default.mouseTrigger),
			...testIdProps("sortable-mouse-trigger")
		}), /* @__PURE__ */ jsx(IconButton, {
			className: DragAndDropTrigger_module_default.buttonTrigger,
			"aria-label": `Move ${title}`,
			ref: (element) => {
				ref.current = element;
				setActivatorNodeRef(element);
			},
			onKeyDown,
			onClick,
			variant: "invisible",
			role: isDragging ? "application" : "button",
			icon: GrabberIcon,
			size: "large",
			...props,
			...testIdProps("sortable-trigger")
		})]
	});
}
DragAndDropTrigger.displayName = "DragAndDropTrigger";
/**
*
* A sortable list item. This component is responsible for managing the drag trigger and preview.
*
* Note: enabling `hideTrigger` and defining a custom trigger is very risky please reference the accessibility
* grabberIcon [docs](https://github.com/github/accessibility/blob/aa85cdd00de58509aee9eaba18718d2bd727e777/docs/coaching-recommendations/drag-and-drop/technical-guidance/grabber-iconButton.md)
* to ensure your trigger will be accessible.
*
* @param props DragAndDropItemProps
*/
var DragAndDropItem = (t0) => {
	const $ = c(11);
	const { children, id, index, title, containerStyle, style, hideTrigger, isDragOverlay: t1, role, as: t2, itemClassName, elementId, ...props } = t0;
	const isDragOverlay = t1 === void 0 ? false : t1;
	const as = t2 === void 0 ? "li" : t2;
	const prefersReducedMotion = usePrefersReducedMotion();
	let t3;
	if ($[0] !== id) {
		t3 = { metadata: { id } };
		$[0] = id;
		$[1] = t3;
	} else t3 = $[1];
	let t4;
	if ($[2] !== id || $[3] !== t3) {
		t4 = {
			id,
			data: t3
		};
		$[2] = id;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	const { setNodeRef, isDragging, transform, transition } = useSortable(t4);
	const { direction, isInDragMode } = useDragAndDrop();
	const containerClassName = clsx("position-relative", props.className, isInDragMode && {
		[DragAndDropItem_module_default.dragItem]: isDragging,
		[DragAndDropItem_module_default.horizontal]: direction === "horizontal",
		[DragAndDropItem_module_default.vertical]: direction === "vertical"
	});
	let t5;
	if ($[5] !== transform) {
		t5 = transform ? `
        translateX(${Math.round(transform.x)}px)
        translateY(${Math.round(transform.y)}px)
        scaleX(${transform.scaleX})
        scaleY(${transform.scaleY})
      ` : "none";
		$[5] = transform;
		$[6] = t5;
	} else t5 = $[6];
	const itemStyle = {
		transform: t5,
		transition: prefersReducedMotion ? "none" : transition
	};
	const As = isDragOverlay ? "div" : as;
	let t6;
	if ($[7] !== id || $[8] !== index || $[9] !== title) {
		t6 = {
			index,
			title,
			id
		};
		$[7] = id;
		$[8] = index;
		$[9] = title;
		$[10] = t6;
	} else t6 = $[10];
	return jsx(DragAndDropItemContext, {
		value: t6,
		children: jsx(As, {
			...props,
			...testIdProps(isDragOverlay ? "drag-overlay" : "sortable-item"),
			className: containerClassName,
			style: {
				...isDragOverlay ? {} : containerStyle,
				...itemStyle
			},
			ref: setNodeRef,
			id: elementId,
			children: jsxs("div", {
				style,
				className: clsx("position-relative", itemClassName, isInDragMode && DragAndDropItem_module_default.contents, isDragOverlay && DragAndDropItem_module_default.dragOverlay),
				role,
				children: [!hideTrigger && jsx(DragAndDropTrigger, {}), children]
			})
		})
	});
};
DragAndDropItem.displayName = "DragAndDropItem";
/**
* A trigger component that opens the move dialog when clicked.
*
* @param props MoveDialogTriggerProps
*/
var MoveDialogTrigger = ({ ref, Component, returnFocusRef: externalReturnFocusRef, ...props }) => {
	const { title, index } = useDragAndDropItem();
	const { items, openMoveDialog } = useDragAndDrop();
	const openDialog = useCallback(() => {
		openMoveDialog(title, index, externalReturnFocusRef ?? ref);
	}, [
		openMoveDialog,
		title,
		index,
		externalReturnFocusRef,
		ref
	]);
	if (items.length === 1) return null;
	return /* @__PURE__ */ jsx(Component, {
		...props,
		onClick: openDialog,
		onSelect: openDialog,
		ref
	});
};
MoveDialogTrigger.displayName = "MoveDialogTrigger";
MoveDialogTrigger.displayName = "MoveDialogTrigger";
/**
* Wrapper for the sortable list and item components.
*/
var DragAndDrop = Object.assign(DragAndDropContainer, {
	Item: DragAndDropItem,
	DragTrigger: DragAndDropTrigger,
	MoveDialog,
	MoveDialogForm,
	MoveDialogTrigger,
	DragAndDropMoveDialog
});
var drag_and_drop_exports = /* @__PURE__ */ __exportAll$1({
	DragAndDrop: () => DragAndDrop,
	DragAndDropContext: () => DragAndDropContext,
	DragAndDropMoveOptions: () => DragAndDropMoveOptions,
	MoveDialogTrigger: () => MoveDialogTrigger,
	useDragAndDrop: () => useDragAndDrop
});
__reExport(drag_and_drop_exports, core_esm_exports);
__reExport(drag_and_drop_exports, modifiers_esm_exports);
__reExport(drag_and_drop_exports, sortable_esm_exports);
__reExport(drag_and_drop_exports, utilities_esm_exports);
export { usePrefersReducedMotion as a, useDragAndDrop as i, DragAndDrop as n, useSyncedState as o, drag_and_drop_exports as r, ActionBar as t };
