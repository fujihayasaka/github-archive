import { useCallback, useEffect, useRef, useState } from "react";
import { c } from "react/compiler-runtime";
function useExternalAnchor(reactPartialAnchor) {
	const $ = c(7);
	const ref = useRef(reactPartialAnchor.__wrapperElement.anchor || null);
	const [open, setOpen] = useState(false);
	let t0;
	if ($[0] !== open) {
		t0 = () => {
			setOpen(!open);
		};
		$[0] = open;
		$[1] = t0;
	} else t0 = $[1];
	const onClick = t0;
	let t1;
	let t2;
	if ($[2] !== open) {
		t1 = () => {
			if (!ref.current) return;
			ref.current.setAttribute("aria-expanded", open.toString());
			ref.current.setAttribute("aria-haspopup", "true");
		};
		t2 = [ref, open];
		$[2] = open;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
	useOnAnchorClick(reactPartialAnchor, onClick);
	let t3;
	if ($[5] !== open) {
		t3 = {
			ref,
			open,
			setOpen
		};
		$[5] = open;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
function useOnAnchorClick(reactPartialAnchor, onClick) {
	const $ = c(3);
	const ref = useRef(reactPartialAnchor.__wrapperElement.anchor);
	let t0;
	let t1;
	if ($[0] !== onClick) {
		t0 = () => {
			const element = ref.current;
			if (!element) return;
			element.addEventListener("click", onClick);
			return () => element.removeEventListener("click", onClick);
		};
		t1 = [ref, onClick];
		$[0] = onClick;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
}
export { useOnAnchorClick as n, useExternalAnchor as t };
