import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { n as getEnv } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import memoize from "@github/memoize";
/***
* Are we rendering on the server?
*/
var IS_SERVER = typeof ssrSafeDocument === "undefined";
/***
* Are we rendering on the client?
*/
var IS_BROWSER = !IS_SERVER;
/***
* This helper returns `true` if:
* - we are rendering on the server
* - we are on the client, and the app has been hydrated from a server-render
*/
function wasServerRendered() {
	if (IS_SERVER || !ssrSafeDocument) return true;
	return Boolean(ssrSafeDocument.querySelector("react-app[data-ssr=\"true\"]") || ssrSafeDocument.querySelector("react-partial[data-ssr=\"true\"][partial-name=\"repos-overview\"]"));
}
function getEnabledFeaturesSet() {
	return new Set(getEnv().featureFlags);
}
var featuresSet = IS_SERVER || isStorybook() ? getEnabledFeaturesSet : memoize(getEnabledFeaturesSet);
function getEnabledFeatures() {
	return Array.from(featuresSet());
}
/**
* This function accesses feature flag states which have been loaded into the client env via the `client-feature-flags.ts` file.
* See https://thehub.github.com/epd/engineering/products-and-services/dotcom/features/feature-flags/typescript-frontend
* for more details.
*
* If you're trying to check a feature flag that was added to the `enabled_features` of a React payload via `add_client_feature_flag` in a
* Rails controller, you should use the `useFeatureFlag` hook (from `@github-ui/react-core/use-feature-flag`) instead to access the feature flag state.
* https://thehub.github.com/epd/engineering/products-and-services/dotcom/features/feature-flags/typescript-frontend has
* more information on `useFeatureFlag` and `add_client_feature_flag`.
*/
function isFeatureEnabled(name) {
	return featuresSet().has(name);
}
var featureFlag = { isFeatureEnabled };
function isStorybook() {
	try {
		return process?.env?.STORYBOOK === "true" || false;
	} catch {
		return false;
	}
}
export { isFeatureEnabled as a, getEnabledFeatures as i, IS_SERVER as n, wasServerRendered as o, featureFlag as r, IS_BROWSER as t };
