import { t as getInsightsUrl } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { createContext, use, useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var Reads = {
	baseComparisonInfo: "base_comparison_info",
	changeGroups: "change_groups",
	codeButton: "code_button",
	codeowners: "codeowners",
	threadPreviewPositioning: "thread_preview_positioning",
	diffEntries: "diff_entries",
	diffstat: "diffstat",
	findings: "findings",
	header: "header",
	issueComments: "issue_comments",
	mergeBox: "merge_box",
	mergeInstructions: "merge_instructions",
	pendingReview: "pending_review",
	reviewRequests: "review_requests",
	stackRebaseStatus: "stack_rebase_status",
	statusChecks: "status_checks",
	tabCounts: "tab_counts",
	threadPreviews: "thread_previews",
	threads: "threads",
	diffViewUserSettings: "user_diff_view_settings",
	diffContextLines: "diff_entry_lines",
	richDiff: "rich_diff",
	description: "description"
};
var Mutations = {
	abandonReview: "abandon_review",
	addCommentReaction: "add_comment_reaction",
	changeBase: "change_base",
	cleanupCodespaces: "cleanup_codespaces",
	convertToDraft: "convert_to_draft",
	createReviewComment: "create_review_comment",
	deleteHeadRef: "delete_head_ref",
	dequeuePullRequest: "dequeue_pull_request",
	disableAutoMerge: "disable_auto_merge",
	dismissReview: "dismiss_review",
	enableAutoMerge: "enable_auto_merge",
	generateChangeGroups: "generate_change_groups",
	markReadyForReview: "mark_ready_for_review",
	merge: "merge",
	removeCommentReaction: "remove_comment_reaction",
	reRequestReviewFromUser: "re_request_review_from_user",
	resolveThread: "resolve_thread",
	runActionRequiredWorkflows: "run_action_required_workflows",
	stackRebase: "stack_rebase",
	submitCopilotGroupsFeedback: "submit_copilot_groups_feedback",
	submitReview: "submit_review",
	submitSuggestedChanges: "apply_suggestions",
	applySuggestedChanges: "apply_review_suggestions",
	submitPullRequestTimelineComment: "create_timeline_comment",
	unresolveThread: "unresolve_thread",
	unstackPullRequests: "pull_request_stacks",
	updateReviewComment: "update_review_comment",
	updatePullRequestBranch: "update_pull_request_branch",
	updateTitle: "update_title",
	updateShowChangeGroupsPreference: "update_show_change_groups_preference",
	updateMergeBoxUserPreference: "update_merge_box_user_preference",
	updateWhitespacePreference: "update_whitespace_preference",
	hideComment: "hide_comment",
	unhideComment: "unhide_comment"
};
var PageData = {
	...Reads,
	...Mutations
};
Object.values(Reads);
Object.values(Mutations);
var PageDataContext = createContext(null);
PageDataContext.displayName = "PageDataContext";
function PageDataContextProvider(t0) {
	const $ = c(5);
	const { children, basePageDataUrl } = t0;
	let t1;
	if ($[0] !== basePageDataUrl) {
		t1 = { basePageDataUrl };
		$[0] = basePageDataUrl;
		$[1] = t1;
	} else t1 = $[1];
	const value = t1;
	let t2;
	if ($[2] !== children || $[3] !== value) {
		t2 = jsx(PageDataContext, {
			value,
			children
		});
		$[2] = children;
		$[3] = value;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
PageDataContextProvider.displayName = "PageDataContextProvider";
function usePageDataContext() {
	const contextData = use(PageDataContext);
	if (!contextData) throw new Error("usePageDataContext must be used within a PageDataContextProvider");
	return contextData;
}
function usePageDataUrl(pageDataName, params) {
	const $ = c(2);
	const { basePageDataUrl } = usePageDataContext();
	let baseUrl = `${basePageDataUrl}/page_data/${pageDataName}`;
	if (params) baseUrl = baseUrl + `?${params}`;
	let t0;
	if ($[0] !== baseUrl) {
		t0 = getInsightsUrl(baseUrl);
		$[0] = baseUrl;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
export { usePageDataUrl as i, PageDataContextProvider as n, usePageDataContext as r, PageData as t };
