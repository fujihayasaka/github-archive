performance.mark("js-parse-end:server-CodeMirrorEditor-LlCAjUWP-DDXGnBUp.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { t as useTrackingRef } from "./server-use-tracking-ref-CdNeH4dZ-DBOS4qOg.js";
import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { n as readOnly, r as spacingControls } from "./server-readonly-G_4lcq4K-NnVP_IuN.js";
import { a as useEmojiSuggestions, i as useAutocompleteTriggersAndSuggestions, o as useMentionSuggestions } from "./server-use-mention-suggestions-CJBNKUGO-wdkkDgZ6.js";
import { A as htmlTreeChanged, B as markdownParserExtension, C as getNodeAtOffset, D as getTextContent, E as getNodesOverlappingRange, F as isTag, G as selectionContextExtension, H as overlapsNode, I as isUrl, J as useReferenceSuggestions, K as setsEqual, L as linkParentNodeTypes, M as inlineFormattingNodeTypes, N as isChecked, O as hasNonEmptySelection, P as isPositionedNode, R as markdownContinuationExtension, S as getNewlineSuffix, T as getNodesInsideRange, U as parseTasklistPrefix, V as nodesEqual, W as selectionContextChanged, _ as getHtmlTree, a as Header, b as getMarkdownTree, c as Toolbar, d as buildToggledTasklistPrefixSyntax, f as feedbackUrl, g as getDelimiterType, h as getCurrentSelectionContext, i as FileUploadButton, j as initialSelectionContext, k as hastPropertiesToHtmlAttributes, m as getAccurateCaretCoords, n as ErrorBanner, p as findWordBoundaries, q as useHybridEditorTelemetry, s as HybridMarkdownEditor_module_default, v as getImageSizeFromFile, w as getNodesContainingRange, x as getNewlinePrefix, y as getLineRanges, z as markdownKeymapExtension } from "./server-use-reference-suggestions-Ixpw3mar-CrD64Jy4.js";
import { a as getSuggestionValue, i as getSuggestionKey, o as isNullSuggestion, r as calculateSuggestionsQuery, t as AutocompleteSuggestions } from "./server-AutocompleteSuggestions-BusBaWrA-D-epQMWF.js";
import { i as useUnifiedFileSelect, r as useSafeAsyncCallback } from "./server-use-unified-file-select-CEU56QFm-CLNiWm9V.js";
import React, { forwardRef, memo, useCallback, useEffect, useEffectEvent, useId, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { createPortal } from "react-dom";
import { c as c$1 } from "react/compiler-runtime";
import { BlockWrapper, Decoration, EditorView, RectangleMarker, ViewPlugin, WidgetType, keymap, layer, placeholder } from "@codemirror/view";
import { Compartment, EditorSelection, EditorState, MapMode, Prec, RangeSet, RangeSetBuilder, StateEffect, StateField } from "@codemirror/state";
import { defaultKeymap, history, historyKeymap } from "@codemirror/commands";
import { h } from "hastscript";
import { SKIP, visitParents } from "unist-util-visit-parents";
import { toMarkdown } from "mdast-util-to-markdown";
import { parseEntities } from "parse-entities";
import { toDom } from "hast-util-to-dom";
import { toHtml } from "hast-util-to-html";
performance.mark("js-parse-end:CodeMirrorEditor-LlCAjUWP.js");
var classes = {
	"ProgressBarItem": "prc-ProgressBar-ProgressBarItem-mDIlB",
	"shimmer": "prc-ProgressBar-shimmer-hIHBF",
	"ProgressBarContainer": "prc-ProgressBar-ProgressBarContainer-tCYE2"
};
var Item = /* @__PURE__ */ forwardRef((t0, forwardRef) => {
	const $ = c(32);
	let ariaLabel;
	let ariaValueNow;
	let ariaValueText;
	let bg;
	let className;
	let progress;
	let rest;
	let style;
	if ($[0] !== t0) {
		({progress, "aria-label": ariaLabel, "aria-valuenow": ariaValueNow, "aria-valuetext": ariaValueText, className, style, bg, ...rest} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = ariaValueNow;
		$[3] = ariaValueText;
		$[4] = bg;
		$[5] = className;
		$[6] = progress;
		$[7] = rest;
		$[8] = style;
	} else {
		ariaLabel = $[1];
		ariaValueNow = $[2];
		ariaValueText = $[3];
		bg = $[4];
		className = $[5];
		progress = $[6];
		rest = $[7];
		style = $[8];
	}
	const progressAsNumber = typeof progress === "string" ? parseInt(progress, 10) : progress;
	let t1;
	if ($[9] !== ariaValueNow || $[10] !== progressAsNumber) {
		var _ariaValueNow;
		t1 = (_ariaValueNow = ariaValueNow) !== null && _ariaValueNow !== void 0 ? _ariaValueNow : progressAsNumber !== void 0 && progressAsNumber >= 0 ? Math.round(progressAsNumber) : 0;
		$[9] = ariaValueNow;
		$[10] = progressAsNumber;
		$[11] = t1;
	} else t1 = $[11];
	let t2;
	if ($[12] !== ariaValueText || $[13] !== t1) {
		t2 = {
			"aria-valuenow": t1,
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-valuetext": ariaValueText
		};
		$[12] = ariaValueText;
		$[13] = t1;
		$[14] = t2;
	} else t2 = $[14];
	const ariaAttributes = t2;
	let styles;
	if ($[15] !== bg || $[16] !== progress) {
		styles = {};
		let t3;
		if ($[18] !== bg) {
			t3 = bg && bg.split(".");
			$[18] = bg;
			$[19] = t3;
		} else t3 = $[19];
		const bgType = t3;
		styles["--progress-width"] = progress ? `${progress}%` : "0%";
		styles["--progress-bg"] = bgType && `var(--bgColor-${bgType[0]}-${bgType[1] || "emphasis"})` || "var(--bgColor-success-emphasis)";
		$[15] = bg;
		$[16] = progress;
		$[17] = styles;
	} else styles = $[17];
	let t3;
	if ($[20] !== className) {
		t3 = clsx(className, classes.ProgressBarItem);
		$[20] = className;
		$[21] = t3;
	} else t3 = $[21];
	let t4;
	if ($[22] !== style || $[23] !== styles) {
		t4 = {
			...styles,
			...style
		};
		$[22] = style;
		$[23] = styles;
		$[24] = t4;
	} else t4 = $[24];
	let t5;
	if ($[25] !== ariaAttributes || $[26] !== ariaLabel || $[27] !== forwardRef || $[28] !== rest || $[29] !== t3 || $[30] !== t4) {
		t5 = /* @__PURE__ */ jsx("span", {
			className: t3,
			...rest,
			role: "progressbar",
			"aria-label": ariaLabel,
			ref: forwardRef,
			style: t4,
			...ariaAttributes
		});
		$[25] = ariaAttributes;
		$[26] = ariaLabel;
		$[27] = forwardRef;
		$[28] = rest;
		$[29] = t3;
		$[30] = t4;
		$[31] = t5;
	} else t5 = $[31];
	return t5;
});
Item.displayName = "ProgressBar.Item";
var ProgressBar$1 = /* @__PURE__ */ forwardRef((t0, forwardRef) => {
	const $ = c(32);
	let animated;
	let ariaLabel;
	let ariaValueNow;
	let ariaValueText;
	let children;
	let className;
	let inline;
	let progress;
	let rest;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({animated, progress, bg: t1, barSize: t2, children, "aria-label": ariaLabel, "aria-valuenow": ariaValueNow, "aria-valuetext": ariaValueText, className, inline, ...rest} = t0);
		$[0] = t0;
		$[1] = animated;
		$[2] = ariaLabel;
		$[3] = ariaValueNow;
		$[4] = ariaValueText;
		$[5] = children;
		$[6] = className;
		$[7] = inline;
		$[8] = progress;
		$[9] = rest;
		$[10] = t1;
		$[11] = t2;
	} else {
		animated = $[1];
		ariaLabel = $[2];
		ariaValueNow = $[3];
		ariaValueText = $[4];
		children = $[5];
		className = $[6];
		inline = $[7];
		progress = $[8];
		rest = $[9];
		t1 = $[10];
		t2 = $[11];
	}
	const bg = t1 === void 0 ? "success.emphasis" : t1;
	const barSize = t2 === void 0 ? "default" : t2;
	if (children && progress) throw new Error("You should pass `progress` or children, not both.");
	let t3;
	if ($[12] !== children) {
		t3 = React.Children.toArray(children);
		$[12] = children;
		$[13] = t3;
	} else t3 = $[13];
	const validChildren = t3.length;
	let t4;
	if ($[14] !== className) {
		t4 = clsx(className, classes.ProgressBarContainer);
		$[14] = className;
		$[15] = t4;
	} else t4 = $[15];
	const t5 = inline ? "inline" : "block";
	let t6;
	if ($[16] !== animated || $[17] !== ariaLabel || $[18] !== ariaValueNow || $[19] !== ariaValueText || $[20] !== bg || $[21] !== children || $[22] !== progress || $[23] !== validChildren) {
		t6 = validChildren ? children : /* @__PURE__ */ jsx(Item, {
			"data-animated": animated,
			progress,
			"aria-label": ariaLabel,
			"aria-valuenow": ariaValueNow,
			"aria-valuetext": ariaValueText,
			bg
		});
		$[16] = animated;
		$[17] = ariaLabel;
		$[18] = ariaValueNow;
		$[19] = ariaValueText;
		$[20] = bg;
		$[21] = children;
		$[22] = progress;
		$[23] = validChildren;
		$[24] = t6;
	} else t6 = $[24];
	let t7;
	if ($[25] !== barSize || $[26] !== forwardRef || $[27] !== rest || $[28] !== t4 || $[29] !== t5 || $[30] !== t6) {
		t7 = /* @__PURE__ */ jsx("span", {
			ref: forwardRef,
			className: t4,
			"data-progress-display": t5,
			"data-progress-bar-size": barSize,
			...rest,
			children: t6
		});
		$[25] = barSize;
		$[26] = forwardRef;
		$[27] = rest;
		$[28] = t4;
		$[29] = t5;
		$[30] = t6;
		$[31] = t7;
	} else t7 = $[31];
	return t7;
});
ProgressBar$1.displayName = "ProgressBar";
/**
* Collection of ProgressBar related components.
*/
var ProgressBar = Object.assign(ProgressBar$1, { Item });
var blockAutocompleteNodeTypes = ["code"];
/** Small margin adjustments to make CodeMirror's coordinates API match up better visually with the positioning calculated via
* `DOMInputRange` in the classic markdown editor. */
var autocompleteTopPositioningMargin = 5;
var autocompleteLeftPositioningMargin = 10;
/** Our own autocomplete extension for CodeMirror so we can use the UI in the existing `AutocompleteSuggestions`
* component; the built-in autocomplete looks super different. */
var autocompleteListenerExtension = (setSuggestionEvent, setAutocompleteVisible, setTriggerCharCoords, triggers, showEventRef) => {
	const triggerCharacters = triggers.map((t) => t.triggerChar);
	return EditorView.updateListener.of((update) => {
		if (getCurrentSelectionContext(update.state).some((node) => blockAutocompleteNodeTypes.includes(node.type))) {
			if (showEventRef.current !== null) showEventRef.current = null;
			setSuggestionEvent(null);
			setAutocompleteVisible(false);
			return;
		}
		if (!update.docChanged) return;
		const docString = update.state.doc.toString();
		let autocompleteTriggerCharFound = false;
		for (const transaction of update.transactions) {
			if (!transaction.isUserEvent("input.type") && !transaction.isUserEvent("delete") && !transaction.isUserEvent("undo") && !transaction.isUserEvent("redo")) continue;
			let triggeringChar = void 0;
			const newSelection = update.state.selection.main.anchor;
			for (const char of triggerCharacters) if (!autocompleteTriggerCharFound && newSelection > 0 && docString.lastIndexOf(char) === newSelection - 1) {
				autocompleteTriggerCharFound = true;
				triggeringChar = char;
			}
			const suggestionQuery = calculateSuggestionsQuery(triggers, docString, newSelection ?? 0);
			const contenteditableNode = update.view.contentDOM;
			showEventRef.current = suggestionQuery && {
				...suggestionQuery,
				target: contenteditableNode
			};
			setSuggestionEvent({
				query: suggestionQuery?.query ?? "",
				trigger: { triggerChar: triggeringChar ?? suggestionQuery?.trigger.triggerChar ?? "" },
				target: contenteditableNode
			});
			setAutocompleteVisible(showEventRef.current !== null);
			if (showEventRef.current !== null) {
				const caretVisualPosition = update.view.coordsAtPos(showEventRef.current.caretLocation ?? newSelection - 1, 1);
				setTriggerCharCoords({
					top: caretVisualPosition ? caretVisualPosition.top + autocompleteTopPositioningMargin : 0,
					left: caretVisualPosition ? caretVisualPosition.left + autocompleteLeftPositioningMargin : 0,
					height: caretVisualPosition ? caretVisualPosition.bottom - caretVisualPosition.top : 0
				});
			}
		}
	});
};
/**
* Create a new `Compartment` around this extension so that it can be reconfigured without replacing the entire editor
* state. For more info see: https://thetrevorharmon.com/blog/codemirror-and-react/#updating-an-extension-based-on-react-state
* @param view The editor view instance, for dispatching updates.
* @param extension The extension to track. Must be memoized. On changes, an editor state update will be dispatched.
* @returns A constant reference to a new `Extension` that contains the created compartment.
*/
function useCompartment(view, extension) {
	const $ = c$1(6);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = new Compartment();
		$[0] = t0;
	} else t0 = $[0];
	const compartment = t0;
	let t1;
	let t2;
	if ($[1] !== extension || $[2] !== view) {
		t1 = () => view?.dispatch({ effects: compartment.reconfigure(extension) });
		t2 = [
			view,
			extension,
			compartment
		];
		$[1] = extension;
		$[2] = view;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = compartment.of([]);
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
var useAutocompleteState = (t0) => {
	const $ = c$1(45);
	const { suggestions, setSuggestionEvent, setViewMode, telemetry } = t0;
	const showEventRef = useRef(null);
	const [autocompleteVisible, setAutocompleteVisible] = useState(false);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			top: 0,
			left: 0,
			height: 0
		};
		$[0] = t1;
	} else t1 = $[0];
	const [triggerCharCoords, setTriggerCharCoords] = useState(t1);
	const [activeSuggestionKey, setActiveSuggestionKey] = useState();
	let t2;
	if ($[1] !== activeSuggestionKey || $[2] !== suggestions) {
		t2 = Array.isArray(suggestions) ? suggestions.find((s) => getSuggestionKey(s) === activeSuggestionKey) ?? suggestions[0] : void 0;
		$[1] = activeSuggestionKey;
		$[2] = suggestions;
		$[3] = t2;
	} else t2 = $[3];
	const activeSuggestion = t2;
	if (activeSuggestionKey && !autocompleteVisible) setActiveSuggestionKey(void 0);
	let t3;
	if ($[4] !== setSuggestionEvent || $[5] !== setViewMode || $[6] !== telemetry) {
		t3 = (editor, suggestion) => {
			if (!suggestion) return;
			if (typeof suggestion === "object" && suggestion.key === "slash-commands") {
				setAutocompleteVisible(false);
				setSuggestionEvent(null);
				setViewMode("edit");
				return;
			}
			const isMultistep = isNullSuggestion(suggestion);
			const suggestionValue = getSuggestionValue(suggestion) ?? "";
			const suggestionKind = typeof suggestion === "string" ? "string" : isMultistep ? "null" : "object";
			if (!showEventRef?.current) return;
			const caretLocation = editor.state.selection.main.anchor ?? 0;
			const { trigger } = showEventRef.current;
			const editorInsertion = `${isMultistep || (trigger.keepTriggerCharOnCommit ?? true) ? trigger.triggerChar : ""}${suggestionValue}${!isMultistep && (trigger.insertSpaceOnCommit ?? true) ? " " : ""}`;
			const triggerCharPosition = editor.state.doc.toString().lastIndexOf(trigger.triggerChar, caretLocation);
			editor.dispatch({
				changes: [{
					from: triggerCharPosition,
					to: caretLocation,
					insert: editorInsertion
				}],
				selection: { anchor: triggerCharPosition + editorInsertion.length },
				userEvent: "input.complete",
				scrollIntoView: true
			});
			setAutocompleteVisible(false);
			setSuggestionEvent(null);
			telemetry?.trackAutocompleteSelected({
				triggerChar: trigger.triggerChar,
				insertedLength: editorInsertion.length,
				multiStep: isMultistep,
				suggestionKind
			});
		};
		$[4] = setSuggestionEvent;
		$[5] = setViewMode;
		$[6] = telemetry;
		$[7] = t3;
	} else t3 = $[7];
	const insertAutocompleteSelection = t3;
	let t4;
	if ($[8] !== activeSuggestion || $[9] !== suggestions) {
		t4 = (direction) => {
			if (!activeSuggestion || !Array.isArray(suggestions)) return;
			const setActiveSuggestion = (suggestion_0) => {
				setActiveSuggestionKey(suggestion_0 ? getSuggestionKey(suggestion_0) : void 0);
			};
			bb95: switch (direction) {
				case "up":
					setActiveSuggestion(suggestions[suggestions.indexOf(activeSuggestion) - 1] ?? suggestions.at(-1));
					break bb95;
				case "down":
					setActiveSuggestion(suggestions[suggestions.indexOf(activeSuggestion) + 1] ?? suggestions[0]);
					break bb95;
				case "start":
					setActiveSuggestion(suggestions[0]);
					break bb95;
				case "end": setActiveSuggestion(suggestions.at(-1));
			}
		};
		$[8] = activeSuggestion;
		$[9] = suggestions;
		$[10] = t4;
	} else t4 = $[10];
	const navigate = t4;
	let t5;
	if ($[11] !== activeSuggestion || $[12] !== insertAutocompleteSelection) {
		t5 = (editorView) => {
			if (!activeSuggestion) return false;
			if (!showEventRef?.current) return false;
			insertAutocompleteSelection(editorView, activeSuggestion);
			return true;
		};
		$[11] = activeSuggestion;
		$[12] = insertAutocompleteSelection;
		$[13] = t5;
	} else t5 = $[13];
	const onCommit = t5;
	let t6;
	if ($[14] !== onCommit) {
		t6 = {
			key: "Enter",
			run: onCommit,
			preventDefault: true,
			stopPropagation: true
		};
		$[14] = onCommit;
		$[15] = t6;
	} else t6 = $[15];
	let t7;
	if ($[16] !== navigate) {
		t7 = {
			key: "ArrowUp",
			run: () => {
				navigate("up");
				return true;
			}
		};
		$[16] = navigate;
		$[17] = t7;
	} else t7 = $[17];
	let t8;
	if ($[18] !== navigate) {
		t8 = {
			key: "ArrowDown",
			run: () => {
				navigate("down");
				return true;
			}
		};
		$[18] = navigate;
		$[19] = t8;
	} else t8 = $[19];
	let t9;
	if ($[20] !== navigate) {
		t9 = {
			key: "Home",
			run: () => {
				navigate("start");
				return true;
			},
			preventDefault: true,
			stopPropagation: true
		};
		$[20] = navigate;
		$[21] = t9;
	} else t9 = $[21];
	let t10;
	if ($[22] !== navigate) {
		t10 = {
			key: "End",
			run: () => {
				navigate("end");
				return true;
			},
			preventDefault: true,
			stopPropagation: true
		};
		$[22] = navigate;
		$[23] = t10;
	} else t10 = $[23];
	let t11;
	if ($[24] !== onCommit) {
		t11 = {
			key: "Tab",
			run: onCommit,
			preventDefault: true,
			stopPropagation: true
		};
		$[24] = onCommit;
		$[25] = t11;
	} else t11 = $[25];
	let t12;
	if ($[26] !== t10 || $[27] !== t11 || $[28] !== t6 || $[29] !== t7 || $[30] !== t8 || $[31] !== t9) {
		t12 = [
			t6,
			t7,
			t8,
			t9,
			t10,
			t11
		];
		$[26] = t10;
		$[27] = t11;
		$[28] = t6;
		$[29] = t7;
		$[30] = t8;
		$[31] = t9;
		$[32] = t12;
	} else t12 = $[32];
	const autocompleteKeymap = t12;
	const lastTrackedQueryRef = useRef(null);
	const lastTrackedStateRef = useRef(null);
	let t13;
	let t14;
	if ($[33] !== autocompleteVisible || $[34] !== suggestions || $[35] !== telemetry) {
		t13 = () => {
			if (!telemetry) return;
			if (!autocompleteVisible || !showEventRef.current) {
				if (!autocompleteVisible) {
					lastTrackedQueryRef.current = null;
					lastTrackedStateRef.current = null;
				}
				return;
			}
			const { query, trigger: trigger_0 } = showEventRef.current;
			let suggestionState = "empty";
			let suggestionCount;
			if (suggestions === "loading") suggestionState = "loading";
			else if (Array.isArray(suggestions)) {
				suggestionCount = suggestions.length;
				suggestionState = suggestionCount > 0 ? "results" : "empty";
			}
			if (lastTrackedQueryRef.current !== query || lastTrackedStateRef.current !== suggestionState) {
				telemetry.trackAutocompleteShown({
					triggerChar: trigger_0.triggerChar,
					queryLength: query.length,
					suggestionState,
					suggestionCount
				});
				lastTrackedQueryRef.current = query;
				lastTrackedStateRef.current = suggestionState;
			}
		};
		t14 = [
			autocompleteVisible,
			suggestions,
			telemetry
		];
		$[33] = autocompleteVisible;
		$[34] = suggestions;
		$[35] = telemetry;
		$[36] = t13;
		$[37] = t14;
	} else {
		t13 = $[36];
		t14 = $[37];
	}
	useEffect(t13, t14);
	let t15;
	if ($[38] !== activeSuggestion || $[39] !== activeSuggestionKey || $[40] !== autocompleteKeymap || $[41] !== autocompleteVisible || $[42] !== insertAutocompleteSelection || $[43] !== triggerCharCoords) {
		t15 = {
			activeSuggestionKey,
			autocompleteKeymap,
			autocompleteVisible,
			activeSuggestion,
			insertAutocompleteSelection,
			setActiveSuggestionKey,
			setAutocompleteVisible,
			setTriggerCharCoords,
			showEventRef,
			triggerCharCoords
		};
		$[38] = activeSuggestion;
		$[39] = activeSuggestionKey;
		$[40] = autocompleteKeymap;
		$[41] = autocompleteVisible;
		$[42] = insertAutocompleteSelection;
		$[43] = triggerCharCoords;
		$[44] = t15;
	} else t15 = $[44];
	return t15;
};
var slashCommandsHintSuggestion = {
	key: "slash-commands",
	value: null,
	render: (props) => {
		const message = isFeatureEnabled("markdown_experience_toolbar_redesign") ? "Switch to 'Edit' mode" : "Switch to 'Write' mode";
		return /* @__PURE__ */ jsxs(ActionList.Item, {
			...props,
			children: [message, /* @__PURE__ */ jsx(ActionList.Description, {
				variant: "block",
				children: "Slash commands are not yet available in the hybrid Markdown editor"
			})]
		});
	}
};
var slashCommandsConfig = {
	trigger: {
		triggerChar: "/",
		keepTriggerCharOnCommit: true
	},
	suggestionsCalculator: () => [slashCommandsHintSuggestion]
};
var useStandardAutocompleteConfig = (referenceSuggestions, mentionSuggestions, emojiSuggestions, emojiTone) => {
	const $ = c$1(16);
	let t0;
	if ($[0] !== emojiTone) {
		t0 = { tone: emojiTone };
		$[0] = emojiTone;
		$[1] = t0;
	} else t0 = $[1];
	const emojiConfig = t0;
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[2] = t1;
	} else t1 = $[2];
	const emptyArray = t1;
	const { trigger: emojiTrigger, calculateSuggestions: calculateEmojiSuggestions } = useEmojiSuggestions(emojiSuggestions ?? emptyArray, emojiConfig);
	const { trigger: mentionsTrigger, calculateSuggestions: calculateMentionSuggestions } = useMentionSuggestions(mentionSuggestions ?? emptyArray);
	const { trigger: referencesTrigger, calculateSuggestions: calculateReferenceSuggestions } = useReferenceSuggestions(referenceSuggestions ?? emptyArray);
	let t2;
	if ($[3] !== calculateEmojiSuggestions || $[4] !== emojiTrigger) {
		t2 = {
			trigger: emojiTrigger,
			suggestionsCalculator: calculateEmojiSuggestions
		};
		$[3] = calculateEmojiSuggestions;
		$[4] = emojiTrigger;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== calculateMentionSuggestions || $[7] !== mentionsTrigger) {
		t3 = {
			trigger: mentionsTrigger,
			suggestionsCalculator: calculateMentionSuggestions
		};
		$[6] = calculateMentionSuggestions;
		$[7] = mentionsTrigger;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== calculateReferenceSuggestions || $[10] !== referencesTrigger) {
		t4 = {
			trigger: referencesTrigger,
			suggestionsCalculator: calculateReferenceSuggestions
		};
		$[9] = calculateReferenceSuggestions;
		$[10] = referencesTrigger;
		$[11] = t4;
	} else t4 = $[11];
	let t5;
	if ($[12] !== t2 || $[13] !== t3 || $[14] !== t4) {
		t5 = [
			t2,
			t3,
			t4,
			slashCommandsConfig
		];
		$[12] = t2;
		$[13] = t3;
		$[14] = t4;
		$[15] = t5;
	} else t5 = $[15];
	return useAutocompleteTriggersAndSuggestions(t5);
};
var useAutocomplete = (t0) => {
	const $ = c$1(39);
	const { view, setViewMode, referenceSuggestions, mentionSuggestions, emojiSuggestions, emojiTone, telemetry, tabInsertsSuggestions: t1 } = t0;
	const tabInsertsSuggestions = t1 === void 0 ? false : t1;
	const { triggers, suggestions, setSuggestionEvent } = useStandardAutocompleteConfig(referenceSuggestions, mentionSuggestions, emojiSuggestions, emojiTone);
	let t2;
	if ($[0] !== setSuggestionEvent || $[1] !== setViewMode || $[2] !== suggestions || $[3] !== telemetry) {
		t2 = {
			suggestions,
			setSuggestionEvent,
			setViewMode,
			telemetry
		};
		$[0] = setSuggestionEvent;
		$[1] = setViewMode;
		$[2] = suggestions;
		$[3] = telemetry;
		$[4] = t2;
	} else t2 = $[4];
	const { activeSuggestion, autocompleteKeymap, autocompleteVisible, insertAutocompleteSelection, setAutocompleteVisible, setTriggerCharCoords, showEventRef, triggerCharCoords } = useAutocompleteState(t2);
	const listId = useId();
	let t3;
	if ($[5] !== listId) {
		t3 = (suggestion) => `${listId}-${getSuggestionKey(suggestion)}`;
		$[5] = listId;
		$[6] = t3;
	} else t3 = $[6];
	const getSuggestionId = t3;
	let t4;
	if ($[7] !== activeSuggestion || $[8] !== insertAutocompleteSelection || $[9] !== view) {
		t4 = (t5) => {
			const suggestion_0 = t5 === void 0 ? activeSuggestion : t5;
			if (!view || !suggestion_0) return;
			insertAutocompleteSelection(view, suggestion_0);
		};
		$[7] = activeSuggestion;
		$[8] = insertAutocompleteSelection;
		$[9] = view;
		$[10] = t4;
	} else t4 = $[10];
	const onCommit = t4;
	let t5;
	if ($[11] !== autocompleteKeymap || $[12] !== autocompleteVisible) {
		t5 = autocompleteVisible ? Prec.highest(keymap.of(autocompleteKeymap)) : [];
		$[11] = autocompleteKeymap;
		$[12] = autocompleteVisible;
		$[13] = t5;
	} else t5 = $[13];
	const autocompleteKeymapCompartment = useCompartment(view, t5);
	let t6;
	if ($[14] !== setAutocompleteVisible || $[15] !== setSuggestionEvent || $[16] !== setTriggerCharCoords || $[17] !== showEventRef || $[18] !== triggers) {
		t6 = autocompleteListenerExtension(setSuggestionEvent, setAutocompleteVisible, setTriggerCharCoords, triggers, showEventRef);
		$[14] = setAutocompleteVisible;
		$[15] = setSuggestionEvent;
		$[16] = setTriggerCharCoords;
		$[17] = showEventRef;
		$[18] = triggers;
		$[19] = t6;
	} else t6 = $[19];
	const autocompleteListenerCompartment = useCompartment(view, t6);
	const hasSuggestions = suggestions !== null && suggestions.length > 0;
	let t7;
	if ($[20] !== view) {
		t7 = { current: { focus: () => view?.focus() } };
		$[20] = view;
		$[21] = t7;
	} else t7 = $[21];
	const inputRef = t7;
	let t8;
	if ($[22] !== setAutocompleteVisible) {
		t8 = () => {
			setAutocompleteVisible(false);
		};
		$[22] = setAutocompleteVisible;
		$[23] = t8;
	} else t8 = $[23];
	const t9 = autocompleteVisible && hasSuggestions;
	let t10;
	if ($[24] !== activeSuggestion || $[25] !== getSuggestionId || $[26] !== inputRef || $[27] !== listId || $[28] !== onCommit || $[29] !== suggestions || $[30] !== t8 || $[31] !== t9 || $[32] !== tabInsertsSuggestions || $[33] !== triggerCharCoords) {
		t10 = jsx(AutocompleteSuggestions, {
			id: listId,
			suggestions,
			inputRef,
			onCommit,
			onClose: t8,
			triggerCharCoords,
			visible: t9,
			defaultPlacement: "below",
			activeSuggestion,
			getSuggestionId,
			role: "listbox",
			tabInsertsSuggestions
		});
		$[24] = activeSuggestion;
		$[25] = getSuggestionId;
		$[26] = inputRef;
		$[27] = listId;
		$[28] = onCommit;
		$[29] = suggestions;
		$[30] = t8;
		$[31] = t9;
		$[32] = tabInsertsSuggestions;
		$[33] = triggerCharCoords;
		$[34] = t10;
	} else t10 = $[34];
	let t11;
	if ($[35] !== autocompleteKeymapCompartment || $[36] !== autocompleteListenerCompartment || $[37] !== t10) {
		t11 = {
			autocompleteSuggestionsMenu: t10,
			autocompleteKeymapCompartment,
			autocompleteListenerCompartment
		};
		$[35] = autocompleteKeymapCompartment;
		$[36] = autocompleteListenerCompartment;
		$[37] = t10;
		$[38] = t11;
	} else t11 = $[38];
	return t11;
};
var caret_flash_module_default = { caretFlash: "caret-flash-module_CkgZdW_caretFlash" };
/**
* Creates a caret flash element positioned at the given coordinates with dynamic sizing
*/
var createFlashElement = (x, y, fontSize) => {
	const element = document.createElement("div");
	element.className = caret_flash_module_default.caretFlash || "";
	element.style.left = `${x}px`;
	element.style.top = `${y}px`;
	element.setAttribute("data-testid", "caretFlash");
	element.style.setProperty("--text-font-size", fontSize);
	element.addEventListener("animationend", () => {
		element.remove();
	}, { once: true });
	return element;
};
/**
* Get the font size of the clicked text to help us size the flash
*/
var getFontSize = (view, coords) => {
	const elementAtCursor = document.elementFromPoint(coords.left, coords.top);
	if (elementAtCursor && view.dom.contains(elementAtCursor)) return window.getComputedStyle(elementAtCursor).fontSize;
	return null;
};
function renderCaretFlash(view, lastCaretPos) {
	const selection = view.state.selection.main;
	if (!selection.empty) return;
	const coords = getAccurateCaretCoords(view, selection.head);
	if (!coords) return;
	const newCaretPos = {
		x: coords.left + window.scrollX,
		y: coords.top + window.scrollY
	};
	const caretShiftDistance = Math.hypot(newCaretPos.x - lastCaretPos.x, newCaretPos.y - lastCaretPos.y);
	if (newCaretPos.x > 0 && caretShiftDistance >= 25) {
		const fontSize = getFontSize(view, coords);
		const flashElement = createFlashElement(newCaretPos.x, newCaretPos.y, fontSize);
		document.body.appendChild(flashElement);
	}
}
/**
* Plugin to handle mouse click events and trigger caret flash
*/
var caretFlashExtension = ViewPlugin.fromClass(class {
	#lastStableCaretPos = null;
	update(update) {
		if (!update.selectionSet) return;
		const coords = getAccurateCaretCoords(update.view, update.state.selection.main.head);
		if (coords && coords.left > 0) this.#lastStableCaretPos = {
			x: coords.left + window.scrollX,
			y: coords.top + window.scrollY
		};
	}
	get lastStableCaretPos() {
		return this.#lastStableCaretPos;
	}
}, { eventObservers: { click(event, view) {
	if (this.lastStableCaretPos) renderCaretFlash(view, this.lastStableCaretPos);
} } });
var style_contents_module_default = {
	activeBlock: "style-contents-module_g4iCXG_activeBlock",
	block: "style-contents-module_g4iCXG_block",
	blockWidget: "style-contents-module_g4iCXG_blockWidget",
	comment: "style-contents-module_g4iCXG_comment",
	container: "style-contents-module_g4iCXG_container",
	editorBlurred: "style-contents-module_g4iCXG_editorBlurred",
	muted: "style-contents-module_g4iCXG_muted",
	summary: "style-contents-module_g4iCXG_summary"
};
/** Effect that will be triggered when focus changes.*/
var focusChangeEffect = StateEffect.define();
var updateObserver = EditorView.updateListener.of((update) => {
	if (update.view.hasFocus !== isFocused(update.state)) update.view.dispatch({ effects: focusChangeEffect.of(update.view.hasFocus) });
});
/** Combined field to store focus state: {isFocused, hasBeenFocused} */
var focusStateField = StateField.define({
	create: () => ({
		isFocused: false,
		hasBeenFocused: false
	}),
	update: (prev, tr) => {
		const focusEffect = tr.effects.find((eff) => eff.is(focusChangeEffect));
		if (!focusEffect) return prev;
		const newIsFocused = focusEffect.value;
		return {
			isFocused: newIsFocused,
			hasBeenFocused: prev.hasBeenFocused || !prev.isFocused && newIsFocused
		};
	},
	provide: () => [updateObserver]
});
/**
* While the focus state of the editor can be determined from `view.hasFocus`, a `StateField` plugin would not be
* provided the `EditorView` (because state is decoupled from UI). So this plugin mirrors the editor's UI focus state
* onto the editor state, and triggers an update effect when that changes. This is useful for other plugins that need
* to know whether the editor is focused or not.
*/
var focusedExtension = [focusStateField, EditorView.editorAttributes.of((view) => {
	const state = view.state;
	return { class: hasBeenFocused(state) && !isFocused(state) ? style_contents_module_default.editorBlurred : "" };
})];
/** Get the focus state from the editor state. Throws an error if `focusedExtension` is not installed. */
function isFocused(state) {
	return state.field(focusStateField).isFocused;
}
/** Get whether the editor has been focused at least once. Throws an error if `focusedExtension` is not installed. */
function hasBeenFocused(state) {
	return state.field(focusStateField).hasBeenFocused;
}
/** Check if the focus state changed in this transaction. */
function focusChanged(transaction) {
	return transaction.effects.some((eff) => eff.is(focusChangeEffect));
}
/** Effect that will be triggered when mouse button is pressed or lifted. The goal here is to keep track of whether
* the user's mouse is currently down, as we don't want to cause layout shifts fromm recalculating active blocks and
* thus showing more delimiters until the user releases the mouse to finish their selection.*/
var mousedownChangeEffect = StateEffect.define();
var mousedownObserver = EditorView.domEventObservers({ mousedown: (_, view) => {
	view.dom.ownerDocument.addEventListener("mouseup", () => {
		view.dispatch({ effects: mousedownChangeEffect.of(false) });
	}, {
		once: true,
		capture: true
	});
	view.dispatch({ effects: mousedownChangeEffect.of(true) });
} });
/** Field to store the mousedown state on the editor state. */
var isMousedownField = StateField.define({
	create: () => false,
	update: (prev, transaction) => transaction.effects.find((eff) => eff.is(mousedownChangeEffect))?.value ?? prev,
	provide: () => [mousedownObserver]
});
/** Extension that tracks when the user actively has their mouse pressed in the editor. */
var mousedownExtension = [isMousedownField];
/** Get the mousedown state from the editor state. Throws an error if `mousedownExtension` is not installed. */
function isMousedown(state) {
	return state.field(isMousedownField);
}
/**
* Field that tracks selection state to use for calculating the current active node(s). This is similar to
* `state.selection` but skips updates while the user is making a selection (while the mouse is down) and returns an
* empty selection when the editor is not focused.
*/
var activeSelectionField = StateField.define({
	create: (state) => state.selection,
	update: (prev, transaction) => {
		return isMousedown(transaction.state) ? prev : hasBeenFocused(transaction.state) ? transaction.state.selection : null;
	},
	provide: () => [focusedExtension, mousedownExtension]
});
function getActiveSelection(state) {
	return state.field(activeSelectionField);
}
function activeSelectionChanged(transaction) {
	const before = getActiveSelection(transaction.startState);
	const after = getActiveSelection(transaction.state);
	if (before === after) return false;
	if (before === null || after === null) return true;
	return !before.eq(after);
}
function calculateActiveNodes(state) {
	const selection = getActiveSelection(state);
	const tree = getHtmlTree(state);
	const activeNodes = /* @__PURE__ */ new Set();
	for (const range of selection?.ranges ?? []) {
		const overlappingNodes = getNodesOverlappingRange(tree, range.from, range.to);
		for (const node of overlappingNodes) activeNodes.add(node);
	}
	return activeNodes;
}
/** Tracks the active node(s) in the editor, limiting recalculations to only when the editor or selection changes.  */
var activeNodesField = StateField.define({
	create: calculateActiveNodes,
	update: (prev, tr) => activeSelectionChanged(tr) || htmlTreeChanged(tr) ? calculateActiveNodes(tr.state) : prev,
	provide: () => [activeSelectionField, markdownParserExtension]
});
/** Extension to calculate and track the set of active Markdown nodes in the editor. */
var activeNodesExtension = activeNodesField;
/** Get the set of active Markdown nodes */
function getActiveNodes(state) {
	return state.field(activeNodesField);
}
/** Check if the active nodes set changed. */
function activeNodesChanged(transaction) {
	return !setsEqual(getActiveNodes(transaction.startState), getActiveNodes(transaction.state));
}
var DOUBLE_CLICK_TIME_WINDOW = 500;
/**
* Effect to update the click state.
*/
var updateClickStateEffect = StateEffect.define();
/**
* StateField that tracks the last click state.
*/
var clickStateField = StateField.define({
	create: () => null,
	update: (state, tr) => {
		for (const effect of tr.effects) if (effect.is(updateClickStateEffect)) return effect.value;
		return state;
	}
});
/**
* Extension that improves double-click selection behavior by tracking click positions
* and fixing selection after layout shifts caused by active node changes.
*/
var doubleClickSelectionExtension = [clickStateField, EditorView.domEventHandlers({
	mousedown: (event, view) => {
		if (event.button !== 0) return false;
		const now = Date.now();
		const pos = view.posAtCoords({
			x: event.clientX,
			y: event.clientY
		});
		if (pos === null) return false;
		const lastClickState = view.state.field(clickStateField);
		if (lastClickState && now - lastClickState.timestamp < DOUBLE_CLICK_TIME_WINDOW) return false;
		const activeNodes = getActiveNodes(view.state);
		const wasInActiveNode = Array.from(activeNodes).some((node) => {
			if (!isPositionedNode(node)) return false;
			if (node.type === "root") return false;
			return overlapsNode(pos, pos, node.position.start.offset, node.position.end.offset);
		});
		view.dispatch({ effects: updateClickStateEffect.of({
			position: pos,
			timestamp: now,
			wasInActiveNode,
			hadMouseMove: false
		}) });
		return false;
	},
	mousemove: (event, view) => {
		const lastClickState = view.state.field(clickStateField);
		if (lastClickState && !lastClickState.hadMouseMove) view.dispatch({ effects: updateClickStateEffect.of({
			...lastClickState,
			hadMouseMove: true
		}) });
		return false;
	},
	dblclick: (event, view) => {
		const lastClickState = view.state.field(clickStateField);
		if (!lastClickState) return false;
		const firstClickPos = lastClickState.position;
		const text = view.state.doc.toString();
		if (lastClickState.wasInActiveNode) {
			view.dispatch({ effects: updateClickStateEffect.of(null) });
			return false;
		}
		if (lastClickState.hadMouseMove) {
			view.dispatch({ effects: updateClickStateEffect.of(null) });
			return false;
		}
		event.preventDefault();
		event.stopPropagation();
		const { start: wordStart, end: wordEnd } = findWordBoundaries(text, firstClickPos);
		if (wordStart !== wordEnd) {
			view.dispatch({
				selection: EditorSelection.range(wordStart, wordEnd),
				effects: [updateClickStateEffect.of(null)],
				userEvent: "select.pointer"
			});
			return true;
		}
		view.dispatch({ effects: updateClickStateEffect.of(null) });
		return false;
	}
})];
function shouldDrawBlurredSelection(view) {
	return hasBeenFocused(view.state) && !isFocused(view.state);
}
function getBase(view) {
	const rect = view.scrollDOM.getBoundingClientRect();
	const top = Math.max(0, rect.top);
	return {
		left: rect.left,
		top
	};
}
function drawSelection() {
	return [cursorLayer, selectionLayer];
}
var cursorLayer = layer({
	above: true,
	markers(view) {
		if (!shouldDrawBlurredSelection(view)) return [];
		const { state } = view;
		const cursors = [];
		for (const r of state.selection.ranges) {
			const className = r === state.selection.main ? "cm-cursor cm-cursor-primary" : "cm-cursor cm-cursor-secondary";
			const cursor = r.empty ? r : EditorSelection.cursor(r.head, r.head > r.anchor ? -1 : 1);
			for (const piece of RectangleMarker.forRange(view, className, cursor)) cursors.push(piece);
		}
		return cursors;
	},
	update() {
		return true;
	},
	class: "cm-cursorLayer"
});
var selectionLayer = layer({
	above: false,
	markers(view) {
		if (!shouldDrawBlurredSelection(view)) return [];
		const source = view.state.doc.toString();
		return view.state.selection.ranges.map((r) => {
			if (r.empty) return [];
			const lineRanges = getLineRanges(source, r.from, r.to);
			const className = "cm-selectionBackground";
			return lineRanges.flatMap((range) => {
				const browserRange = EditorSelection.range(Math.max(range.start, r.from), Math.min(range.end, r.to));
				if (browserRange.empty) {
					const pos = getAccurateCaretCoords(view, browserRange.head);
					if (!pos) return [];
					const base = getBase(view);
					return [new RectangleMarker(className, pos.left - base.left, pos.top - base.top, 3, pos.bottom - pos.top)];
				} else return RectangleMarker.forRange(view, className, browserRange);
			});
		}).reduce((a, b) => a.concat(b));
	},
	update() {
		return true;
	},
	class: "cm-selectionLayer"
});
var drop_indicator_module_default = { dropIndicator: "drop-indicator-module_w2QKtG_dropIndicator" };
/**
* Simple widget that renders the drop position indicator.
*/
var DropIndicatorWidget = class extends WidgetType {
	toDOM() {
		const indicator = document.createElement("div");
		indicator.className = drop_indicator_module_default.dropIndicator || "";
		return indicator;
	}
	eq() {
		return true;
	}
	ignoreEvent() {
		return true;
	}
};
/** Effect to update drop position (null means not dragging) */
var setDropPositionEffect = StateEffect.define();
/**
* State field to track the document position where a file would be dropped.
* Position is null when not dragging, and contains the character offset during drag operations.
*/
var dropPositionField = StateField.define({
	create: () => null,
	update: (state, tr) => {
		for (const effect of tr.effects) if (effect.is(setDropPositionEffect)) return effect.value;
		return state;
	}
});
/**
* Create decorations to show a visual indicator at the drop position.
*/
function dropPositionDecorations(position) {
	if (position === null) return Decoration.none;
	return Decoration.set([Decoration.widget({
		widget: new DropIndicatorWidget(),
		side: -1
	}).range(position)]);
}
/**
* Decoration provider that renders drop position indicators.
* Only recomputes decorations when the dropPositionField changes (via the compare function),
* not on every editor update.
*/
var dropPositionDecorationsField = StateField.define({
	create: (state) => dropPositionDecorations(state.field(dropPositionField)),
	update: (decorations, tr) => {
		if (tr.effects.some((e) => e.is(setDropPositionEffect))) return dropPositionDecorations(tr.state.field(dropPositionField));
		return decorations;
	},
	provide: (field) => EditorView.decorations.from(field)
});
function isFileDrag(event) {
	return event.dataTransfer?.types.includes("Files") ?? false;
}
/**
* DOM event handlers for drag-and-drop file tracking.
*
* Processes four drag-and-drop events:
* - dragenter: Enables drag-over state when files enter the editor
* - dragover: Updates the drop position indicator as the user drags
* - dragleave: Hides the indicator when dragging leaves the editor
* - drop: Captures the final drop position for the file handler to use
*
* Only processes file drags (ignores non-file drags). Coordinates are converted
* to document positions using CodeMirror's posAtCoords API.
*/
var dropPositionPlugin = EditorView.domEventHandlers({
	dragenter(event, view) {
		if (!isFileDrag(event)) return false;
		view.dispatch({ effects: [setDropPositionEffect.of(0)] });
		return true;
	},
	dragover(event, view) {
		if (!isFileDrag(event)) return false;
		const pos = view.posAtCoords({
			x: event.clientX,
			y: event.clientY
		});
		if (pos === null) return false;
		view.dispatch({ effects: [setDropPositionEffect.of(pos)] });
		event.dataTransfer.dropEffect = "copy";
		event.preventDefault();
		return true;
	},
	dragleave(event, view) {
		if (!isFileDrag(event)) return false;
		const relatedTarget = event.relatedTarget;
		if (relatedTarget && view.dom.contains(relatedTarget)) return false;
		view.dispatch({ effects: [setDropPositionEffect.of(null)] });
		return false;
	},
	drop(event, view) {
		if (!isFileDrag(event)) return false;
		const pos = view.posAtCoords({
			x: event.clientX,
			y: event.clientY
		});
		if (pos === null) return false;
		view.dispatch({ effects: [setDropPositionEffect.of(pos)] });
		return true;
	}
});
/**
* Retrieves the document position where files would be dropped.
*
* @param state - The CodeMirror editor state
* @returns The character offset where files will be dropped, or null if no drop is in progress
*/
function getDropPosition(state) {
	return state.field(dropPositionField, false) ?? null;
}
/**
* Clears the drop position after it has been used.
* This ensures the position is not reused for subsequent operations.
*
* @param view - The CodeMirror editor view
*/
function clearDropPosition(view) {
	view.dispatch({ effects: [setDropPositionEffect.of(null)] });
}
/**
* Extension for tracking and visualizing file drag-and-drop positions in the editor.
*
* When a file is dragged over the editor, this extension:
* 1. Tracks the document position where the file would be dropped
* 2. Displays a visual indicator (animated green line) showing the drop position
* 3. Stores the position so the file upload handler can insert at the correct location
*
* The drop position is used by the file handler to insert uploaded files at the precise
* location where the user dropped them, rather than at the current caret position.
*/
var dropPositionExtension = [
	dropPositionField,
	dropPositionDecorationsField,
	dropPositionPlugin
];
/** Effect that will be triggered when Mod (Cmd on Mac, Ctrl for Linux and Windows) is pressed or lifted.*/
var modPressedChangeEffect = StateEffect.define();
var platformModKey = isMacOS() ? "Meta" : "Ctrl";
var modKeyObserver = EditorView.domEventObservers({
	keydown(event, view) {
		if (event.key === platformModKey && !isModPressed(view.state)) view.dispatch({ effects: modPressedChangeEffect.of(true) });
	},
	keyup(event, view) {
		if (event.key === platformModKey && isModPressed(view.state)) view.dispatch({ effects: modPressedChangeEffect.of(false) });
	},
	blur(_, view) {
		if (isModPressed(view.state)) view.dispatch({ effects: modPressedChangeEffect.of(false) });
	}
});
/** Field to store the mod key pressed state on the editor state. */
var isModPressedField = StateField.define({
	create: () => false,
	update: (prev, transaction) => transaction.effects.find((eff) => eff.is(modPressedChangeEffect))?.value ?? prev,
	provide: () => [modKeyObserver]
});
/** Extension that tracks when the user is pressing the mod key in the editor. */
var modPressedExtension = [isModPressedField];
/** Get the mod key state from the editor state. Throws an error if `modPressedExtension` is not installed. */
function isModPressed(state) {
	return state.field(isModPressedField);
}
/**
* Serialize an mdast tree to a Markdown string.
*
* NOTE: Does not currently preserve our `delimiter` tokens. For example, an `emphasis` node will always be serialized
* as `_emphasis_` even if it was originally `*emphasis*`. If we eventually need to preserve the source syntax, we'll
* want to revisit that.
*/
function serializeMarkdown(node) {
	let result = toMarkdown(node);
	if (node.type !== "root") result = result.slice(0, -1);
	return result;
}
function markdownLink(text, url) {
	return serializeMarkdown({
		type: "link",
		children: [{
			type: "text",
			value: text
		}],
		url
	});
}
function markdownImage(alt, src) {
	return serializeMarkdown({
		type: "image",
		alt,
		url: src
	});
}
/** Effect that will be triggered when shift key is pressed or lifted.*/
var shiftPressedChangeEffect = StateEffect.define();
var shiftKeyObserver = EditorView.domEventObservers({
	keydown(event, view) {
		if (event.key === "Shift" && !isShiftPressed(view.state)) view.dispatch({ effects: shiftPressedChangeEffect.of(true) });
	},
	keyup(event, view) {
		if (event.key === "Shift" && isShiftPressed(view.state)) view.dispatch({ effects: shiftPressedChangeEffect.of(false) });
	},
	blur(_, view) {
		if (isShiftPressed(view.state)) view.dispatch({ effects: shiftPressedChangeEffect.of(false) });
	}
});
/** Field to store the shift key pressed state on the editor state. */
var isShiftPressedField = StateField.define({
	create: () => false,
	update: (prev, tr) => tr.effects.find((eff) => eff.is(shiftPressedChangeEffect))?.value ?? prev,
	provide: () => [shiftKeyObserver]
});
/** Extension that tracks when the user is pressing the shift key in the editor. */
var shiftPressedExtension = [isShiftPressedField];
/** Get the shift key state from the editor state. Throws an error if `shiftPressedExtension` is not installed. */
function isShiftPressed(state) {
	return state.field(isShiftPressedField);
}
/** Check if this node is allowed to contain a `Link` node. */
function isLinkParent(node) {
	return linkParentNodeTypes.has(node.type);
}
/** Check if this node is inline formatting content. */
function isInlineFormattingNode(node) {
	return inlineFormattingNodeTypes.has(node.type);
}
/**
* If this is a URL paste and the selected text is a valid place to create a link, transforms the pasted text into a
* Markdown hyperlink.
*/
function transformPastedUrlToLink(pastedText, state) {
	if (isShiftPressed(state)) return pastedText;
	if (!hasNonEmptySelection(state)) return pastedText;
	if (!pastedText || !isUrl(pastedText)) return pastedText;
	const { from, to } = state.selection.main;
	const tree = getMarkdownTree(state);
	const fromNode = getNodeAtOffset(tree, from);
	const toNode = getNodeAtOffset(tree, to);
	if (!fromNode || !toNode) return pastedText;
	if (fromNode === toNode && fromNode.type === "link") return pastedText;
	if (fromNode !== toNode) {
		const validStart = from === fromNode.position?.start.offset || fromNode.type === "paragraph";
		const validEnd = to === toNode.position?.end.offset || toNode.type === "paragraph";
		const allNodesInline = getNodesInsideRange(tree, from, to).every(isInlineFormattingNode);
		if (!validStart || !validEnd || !allNodesInline) return pastedText;
	}
	if (!isLinkParent(getNodesContainingRange(tree, from, to, false).findLast((n) => n.type !== "text" && n.type !== "delimiter") ?? tree)) return pastedText;
	return markdownLink(state.sliceDoc(from, to), pastedText);
}
/**
* Creates Markdown links when URLs are pasted onto selected text.
*/
var pasteLinksExtension = [shiftPressedExtension, EditorView.clipboardInputFilter.of(transformPastedUrlToLink)];
/** Defines configuration for editing written prose (as opposed to code). */
var proseExtension = [
	EditorView.contentAttributes.of({
		spellcheck: "true",
		autocorrect: "on",
		autocapitalize: "sentences",
		writingsuggestions: "true",
		tabindex: "0"
	}),
	spacingControls({
		indentUnit: 2,
		indentWithTabs: false,
		lineWrapping: true
	}),
	EditorState.languageData.of(() => [{ wordChars: "'" }])
];
/** Renders a parsed HTML character reference. */
var CharacterReferenceWidget = class extends WidgetType {
	#reference;
	constructor(reference) {
		super();
		this.#reference = reference;
	}
	toDOM() {
		const span = document.createElement("span");
		span.textContent = parseEntities(this.#reference);
		return span;
	}
	eq(widget) {
		return widget.#reference === this.#reference;
	}
};
/**
* Widget that renders a hast node.
*
* Typically used to display elements that have no editable child content and must be rendered as complete replacement
* decorations rather than wrapping decorations.
*/
var HastElementWidget = class HastElementWidget extends WidgetType {
	#node;
	#className;
	/**
	* @param node - hast node to render.
	* @param className - Optional CSS class name to apply in addition to node.properties.class
	*/
	constructor(node, className) {
		super();
		this.#node = node;
		this.#className = className;
	}
	toDOM(_view) {
		const result = toDom(this.#node);
		if (!(result instanceof HTMLElement)) throw new Error("HastElementWidget encountered non-element render result");
		pruneWhitespaceTextNodes(result);
		const dom = result;
		dom.style.marginBlock = "0";
		if (this.#className) dom.classList.add(...this.#className.split(" "));
		return dom;
	}
	eq(widget) {
		return widget instanceof HastElementWidget && nodesEqual(this.#node, widget.#node, { ignorePosition: true }) && widget.#className === this.#className;
	}
	/**
	* Allow events to bubble so that CodeMirror can handle them natively.
	*/
	ignoreEvent() {
		return false;
	}
};
/**
* Remove whitespace-only text nodes from a rendered DOM subtree.
*
* Hast-to-DOM conversion may produce text nodes that only contain formatting whitespace.
* These nodes cause visible blank lines inside widgets, so this routine walks the tree and
* deletes them in-place before the widget is inserted into the editor.
*
* @param root - Root element of the DOM subtree to normalize. The subtree is mutated.
*/
function pruneWhitespaceTextNodes(root) {
	const stack = Array.from(root.childNodes);
	while (stack.length > 0) {
		const node = stack.pop();
		if (node.nodeType === Node.TEXT_NODE) {
			if ((node.textContent ?? "").trim() === "") node.remove();
			continue;
		}
		if (node instanceof Element) stack.push(...Array.from(node.childNodes));
	}
}
var render_error_module_default = { errorMessage: "render-error-module_j_BWUa_errorMessage" };
var RenderErrorWidget = class extends HastElementWidget {
	constructor() {
		super(h("p", {
			role: "alert",
			className: render_error_module_default.errorMessage
		}, [
			"An unexpected error occurred while building the Markdown preview. The editor may continue to function, but some features will not work as expected. If the issue persists, please ",
			h("a", { href: feedbackUrl }, "contact support"),
			"."
		]));
	}
	ignoreEvent() {
		return true;
	}
};
function createCheckboxNode(checked) {
	return h("input", {
		type: "checkbox",
		tabindex: -1,
		checked: checked ? true : void 0,
		"aria-label": checked ? "Checked task list item" : "Unchecked task list item",
		"data-task-list-checkbox": ""
	});
}
var TaskListCheckboxWidget = class TaskListCheckboxWidget extends HastElementWidget {
	#checked;
	#renderedChecked;
	#from;
	#to;
	#view;
	#input;
	#pendingToggleToken;
	constructor(props) {
		super(createCheckboxNode(props.checked));
		this.#checked = props.checked;
		this.#renderedChecked = props.checked;
		this.#from = props.from;
		this.#to = props.to;
	}
	#onMouseDown = (event) => {
		event.preventDefault();
	};
	#onChange = (event) => {
		event.preventDefault();
	};
	#onClick = (event) => {
		event.preventDefault();
		const view = this.#view;
		if (!view) return;
		const nextChecked = !(parseTasklistPrefix(view.state.doc.sliceString(this.#from, this.#to))?.value.toLowerCase() === "x");
		this.#dispatchToggle(view, nextChecked);
	};
	#removeEventListeners(input) {
		if (!input) return;
		input.removeEventListener("mousedown", this.#onMouseDown);
		input.removeEventListener("change", this.#onChange);
		input.removeEventListener("click", this.#onClick);
	}
	#dispatchToggle(view, nextChecked) {
		const nextPrefix = buildToggledTasklistPrefixSyntax(nextChecked, view.state.doc.sliceString(this.#from, this.#to), view.state.doc.sliceString(this.#to, this.#to + 1));
		view.dispatch({
			changes: {
				from: this.#from,
				to: this.#to,
				insert: nextPrefix
			},
			selection: view.state.selection
		});
		this.#to = this.#from + nextPrefix.length;
		if (this.#input) this.#input.setAttribute("data-task-list-to", String(this.#to));
		if (this.#view) {
			const viewRef = this.#view;
			const fromRef = this.#from;
			const toRef = this.#to;
			const toggleToken = Symbol("taskListToggle");
			this.#pendingToggleToken = toggleToken;
			queueMicrotask(() => {
				if (this.#view !== viewRef) return;
				if (this.#pendingToggleToken !== toggleToken) return;
				if (this.#from !== fromRef || this.#to !== toRef) return;
				this.#pendingToggleToken = void 0;
			});
		}
	}
	toDOM(view) {
		this.#view = view;
		const input = super.toDOM(view);
		if (this.#input && this.#input !== input) this.#removeEventListeners(this.#input);
		this.#input = input;
		input.tabIndex = -1;
		this.#renderedChecked = this.#checked;
		input.checked = this.#renderedChecked;
		input.defaultChecked = this.#renderedChecked;
		input.toggleAttribute("checked", this.#renderedChecked);
		input.setAttribute("aria-label", this.#renderedChecked ? "Checked task list item" : "Unchecked task list item");
		input.setAttribute("data-task-list-from", String(this.#from));
		input.setAttribute("data-task-list-to", String(this.#to));
		input.addEventListener("mousedown", this.#onMouseDown);
		input.addEventListener("change", this.#onChange);
		input.addEventListener("click", this.#onClick);
		return input;
	}
	destroy(dom) {
		if (dom instanceof HTMLInputElement) {
			this.#removeEventListeners(dom);
			if (dom === this.#input) this.#input = void 0;
		}
		this.#view = void 0;
	}
	eq(other) {
		if (!(other instanceof TaskListCheckboxWidget)) return false;
		return false;
	}
	ignoreEvent() {
		return true;
	}
};
var updateRegistryEffect = StateEffect.define();
var registryField = StateField.define({
	create: () => /* @__PURE__ */ new Map(),
	update(registry, tr) {
		let result = registry;
		for (const effect of tr.effects) if (effect.is(updateRegistryEffect)) result = new Map([...registry, effect.value]);
		return result;
	}
});
function isKnownInvalidVideoUrl(state, url) {
	return state.field(registryField).get(url) === "invalid";
}
function isKnownValidVideoUrl(state, url) {
	return state.field(registryField).get(url) === "valid";
}
/** Register an invalid video URL on error. A known invalid URL will not be checked again. */
function registerInvalidVideoUrl(view, url) {
	view.dispatch({ effects: [updateRegistryEffect.of([url, "invalid"])] });
}
/**
* Register a known valid video URL. Known valid URLs will not render the plaintext loading placeholder, which avoids
* flickering on completed video uploads / already-checked videos.
*/
function registerValidVideoUrl(view, url) {
	view.dispatch({ effects: [updateRegistryEffect.of([url, "valid"])] });
}
function videoRegistryChanged(tr) {
	return tr.state.field(registryField) !== tr.startState.field(registryField);
}
/**
* Tracks a registry of URLs we have attempted to render as videos. Valid URLs are confirmed accessible videos, while
* invalid URLs are either inaccessible, invalid, or just not video files.
*/
var videoRegistryExtension = [registryField];
var video_link_module_default = { placeholder: "video-link-module_ioOhYq_placeholder" };
/**
* The only way to find out whether some URL points at a valid accessible video resource is to try and render it into
* a video element. So that's what this widget does, updating the video URL registry on success/failure. On failure,
* we should just render the URL as editable text instead of a widget.
*/
var VideoLinkWidget = class extends HastElementWidget {
	#src;
	#content;
	#className;
	constructor(link, className) {
		const src = link.properties.href;
		const label = getTextContent(link);
		const content = link.children;
		super(h("video", {
			src,
			controls: true,
			playsInline: true,
			ariaLabel: label,
			preload: "metadata"
		}));
		this.#src = src;
		this.#content = content;
		this.#className = className;
	}
	toDOM(view) {
		const isKnownValidUrl = isKnownValidVideoUrl(view.state, this.#src);
		const container = document.createElement("span");
		if (this.#className) container.setAttribute("class", this.#className);
		const loadingPlaceholder = toDom(h("a", {
			href: this.#src,
			class: video_link_module_default.placeholder
		}, this.#content));
		const videoElement = super.toDOM(view);
		videoElement.addEventListener("error", () => {
			registerInvalidVideoUrl(view, this.#src);
		});
		videoElement.addEventListener("canplaythrough", () => {
			videoElement.style.display = "block";
			loadingPlaceholder.style.display = "none";
			registerValidVideoUrl(view, this.#src);
		});
		if (!isKnownValidUrl) videoElement.style.display = "none";
		else loadingPlaceholder.style.display = "none";
		container.replaceChildren(loadingPlaceholder, videoElement);
		return container;
	}
};
/** Tag names to style as blocks. */
var blockElements = new Set([
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"blockquote",
	"pre",
	"ul",
	"ol",
	"dl",
	"li",
	"dd",
	"dt",
	"p",
	"table",
	"hr",
	"div",
	"details",
	"picture",
	"figure",
	"video"
]);
var isBlock = (node) => node.type === "element" && blockElements.has(node.tagName);
var withinActiveBlock = (context, nodeActive) => (nodeActive || context.some((ancestor) => isBlock(ancestor.node) && ancestor.active)) ?? false;
/** Check if this element is a link defined with `[]()` syntax. */
var isResourceLink = (element) => element.tagName === "a" && element.children.some((child) => child.type === "element" && child.properties?.dataDelimiter === "resource");
/** Check if this node is a setext heading node with only one character in the delimiter line. */
function isSingleCharSetextHeading(element) {
	return element.children.some((child) => child.type === "element" && child.tagName === "span" && child.properties?.dataDelimiter === "setextHeadingLine" && child.children?.[0]?.type === "text" && child.children[0].value.trim().length === 1);
}
function markDecoration(element) {
	return Decoration.mark({
		tagName: element.tagName,
		attributes: hastPropertiesToHtmlAttributes(element.properties),
		inclusive: true
	});
}
function widgetDecoration(widget) {
	return Decoration.replace({ widget });
}
function elementWidget(element, block, active) {
	return widgetDecoration(new HastElementWidget(block ? h("div", { class: style_contents_module_default.blockWidget }, element) : element, block ? blockClass(active) : void 0));
}
function blockClass(active) {
	return clsx(style_contents_module_default.block, active && style_contents_module_default.activeBlock);
}
function blockWrapper(element, active) {
	const { className, ...properties } = element.properties;
	return BlockWrapper.create({
		tagName: element.tagName,
		attributes: {
			class: clsx(blockClass(active), className),
			...hastPropertiesToHtmlAttributes(properties)
		}
	});
}
function getElementDecoration(element, nodeActive, context, state) {
	const active = withinActiveBlock(context, nodeActive);
	if (element.properties.dataBlankLine) return Decoration.line({ class: blockClass(active) });
	switch (element.tagName) {
		case "a":
			if ("dataVideoCandidate" in element.properties && typeof element.properties.href === "string" && !active && !isKnownInvalidVideoUrl(state, element.properties.href)) return widgetDecoration(new VideoLinkWidget(element, clsx(blockClass(active), style_contents_module_default.blockWidget)));
			if (active && isResourceLink(element)) return void 0;
			break;
		case "table": return active ? blockWrapper(h("div"), active) : elementWidget(element, true, active);
		case "tr":
		case "th":
		case "td":
		case "thead":
		case "tbody": return;
		case "details": return blockWrapper(h("div"), active);
		case "summary": return markDecoration(h("span", { className: style_contents_module_default.summary }));
		case "picture": return active ? blockWrapper(h("div"), active) : elementWidget(element, true, active);
		case "figure": return active ? blockWrapper(h("div"), active) : elementWidget(element, true, active);
		case "hr": return active ? blockWrapper(h("div"), active) : elementWidget(element, true, active);
		case "video": return active ? blockWrapper(h("div", { className: style_contents_module_default.muted }), active) : elementWidget(element, true, active);
		case "img": return active ? void 0 : elementWidget(element, false, active);
		case "br": return active ? void 0 : elementWidget(element, false, active);
		case "span": {
			const delimiterType = getDelimiterType(element);
			if (!delimiterType) break;
			const raw = element.children[0]?.type === "text" ? element.children[0].value : "";
			if (delimiterType === "characterReference" && !active) return widgetDecoration(new CharacterReferenceWidget(raw));
			if (delimiterType === "resourceDestination" && active && isUrl(raw)) return markDecoration(h("a", { href: raw }));
			if (delimiterType === "taskListCheck" && !active) {
				if (!isPositionedNode(element)) break;
				const startOffset = element.position.start.offset;
				const endOffset = element.position.end.offset;
				return widgetDecoration(new TaskListCheckboxWidget({
					checked: isChecked(raw),
					from: startOffset,
					to: endOffset
				}));
			}
			if (!active) return elementWidget({
				...element,
				children: []
			}, false, false);
			break;
		}
		case "h2":
			if (active && isSingleCharSetextHeading(element)) return blockWrapper(h("div"), active);
			break;
		case "code": {
			const parentNode = context.at(-1)?.node;
			if (parentNode && isTag(parentNode, "pre")) return blockWrapper(element, active);
			break;
		}
	}
	return isBlock(element) ? blockWrapper(element, active) : markDecoration(element);
}
function getNodeDecoration(node, active, context, state) {
	switch (node.type) {
		case "comment": return blockWrapper(h("code", { className: style_contents_module_default.comment }), active);
		case "element": return getElementDecoration(node, active, context, state);
	}
}
function buildDecorations(state) {
	const tree = getHtmlTree(state);
	const activeNodes = getActiveNodes(state);
	const decorationsBuilder = new RangeSetBuilder();
	const blockWrappersBuilder = new RangeSetBuilder();
	let prevWidgetRange = null;
	visitParents(tree, (node, parents) => {
		if (!isPositionedNode(node)) return;
		const from = node.position.start.offset;
		const to = node.position.end.offset;
		if (prevWidgetRange?.from === from && prevWidgetRange?.to === to) return;
		const nodeContext = parents.map((p) => ({
			node: p,
			active: activeNodes.has(p)
		}));
		const decoration = getNodeDecoration(node, activeNodes.has(node), nodeContext, state);
		if (decoration) {
			decoration.startSide = parents.length;
			if (decoration instanceof BlockWrapper) blockWrappersBuilder.add(from, to, decoration);
			else {
				decorationsBuilder.add(from, to, decoration);
				if ("widget" in decoration.spec) {
					prevWidgetRange = {
						from,
						to
					};
					return SKIP;
				}
			}
		}
	});
	return {
		decorations: decorationsBuilder.finish(),
		blockWrappers: blockWrappersBuilder.finish()
	};
}
var lastReportedError = void 0;
/**
* Attempt to build decorations, falling back to showing an error widget on failure. Careful error handling here is
* important because there are many subtle ways this can fail if the code is imperfect (eg, decorations added out of
* order or with ranges outside the document bounds). The default handling for errors in CodeMirror breaks the editor
* in unexpected and potentially subtle ways, so this ensures that users know there is an issue and provides a valid
* fallback.
*/
function tryWithFallback(fn) {
	try {
		return fn();
	} catch (error) {
		if (error instanceof Error) {
			if (!lastReportedError || lastReportedError.name !== error.name || lastReportedError.message !== error.message) setTimeout(() => {
				throw error;
			});
			lastReportedError = error;
		}
		const builder = new RangeSetBuilder();
		builder.add(0, 0, Decoration.widget({ widget: new RenderErrorWidget() }));
		return {
			decorations: builder.finish(),
			blockWrappers: RangeSet.empty
		};
	}
}
var styleContentsExtension = StateField.define({
	create: (state) => tryWithFallback(() => buildDecorations(state)),
	update: (prev, tr) => {
		const treeChanged = htmlTreeChanged(tr);
		return tryWithFallback(() => {
			if (tr.docChanged && !treeChanged) return {
				decorations: prev.decorations.map(tr.changes),
				blockWrappers: prev.blockWrappers.map(tr.changes)
			};
			else if (treeChanged || activeNodesChanged(tr) || videoRegistryChanged(tr)) return buildDecorations(tr.state);
			else return prev;
		});
	},
	provide: (field) => [
		markdownParserExtension,
		activeNodesExtension,
		videoRegistryExtension,
		EditorView.outerDecorations.from(field, (val) => val.decorations),
		EditorView.blockWrappers.from(field, (val) => val.blockWrappers),
		EditorView.contentAttributes.of({ class: clsx("markdown-body", style_contents_module_default.container) })
	]
});
var react_component_module_default = { container: "react-component-module_8iTCWa_container" };
var keyAttr = (widgetName) => `data-${widgetName}-key`;
var propsAttr = (widgetName) => `data-${widgetName}-props`;
/**
* CodeMirror widget decoration implementation for injecting React components into the editor. Outputs an empty
* container to select and render via the `useReactWidgets` hook.
*
* Instructions for implementing a new React component widget:
*
* 1. Create a new React component that accepts serializable props (props that conform to `JSONObject`).
* 2. Implement a new widget class that extends this class, using a unique **lowercase** `widgetName` for the class.
* 3. Render the widget as normal using CodeMirror `Decoration.widget`.
* 4. Hydrate the widget by calling `useReactWidgets` with the editor's React component and rendering the result.
*/
var ReactComponentWidget = class extends HastElementWidget {
	key;
	props;
	#widgetName;
	/**
	*
	* @param widgetName The name of this widget class, kebab-case. Must be consistent for all instances of this widget,
	* but unique across all `ReactComponentWidget` implementations.
	* @param key Unique key for this widget. Must be unique across all instances of this widget, and constant for the
	* lifetime of this instance.
	* @param props Props object to pass through to the React component. Must be JSON-serializable.
	*/
	constructor(widgetName, key, props) {
		super(h("div", {
			[propsAttr(widgetName)]: JSON.stringify(props),
			[keyAttr(widgetName)]: key,
			className: react_component_module_default.container
		}));
		this.key = key;
		this.#widgetName = widgetName;
		this.props = props;
	}
	/** Enables updating the DOM attributes rather than re-creating the element (and thus re-mounting the widget). */
	updateDOM(dom) {
		if (dom.getAttribute(keyAttr(this.#widgetName)) !== this.key) return false;
		dom.setAttribute(propsAttr(this.#widgetName), JSON.stringify(this.props));
		return true;
	}
	/**
	* Should return `false` any time anything changes; CodeMirror will then call `updateDOM` and only re-mount if that
	* also returns `false`.
	*/
	eq(other) {
		return this.key === other.key && (this.props === other.props || JSON.stringify(this.props) === JSON.stringify(other.props));
	}
};
var UploadPlaceholderWidget = class UploadPlaceholderWidget extends ReactComponentWidget {
	static widgetName = "upload-placeholder-widget";
	constructor(id, props) {
		super(UploadPlaceholderWidget.widgetName, id, props);
	}
};
/** Number of milliseconds to show an error before removing the placeholder. */
var ERROR_TIMEOUT = 3e3;
var addUploadPlaceholderEffect = StateEffect.define();
var updateUploadPlaceholderEffect = StateEffect.define();
var removeUploadPlaceholderEffect = StateEffect.define();
/**
* Get the doc as a string, but insert a placeholder character at all pending file uploads. This ensures that
* `getNewlinePrefix` and `getNewlineSuffix` insert the correct number of newlines, adding space when a new upload is
* started immediately adjacent to a pending upload.
*/
function buildDocWithPlaceholderChars(view, caretPosition) {
	const widgets = getAllEntries(view.state);
	let doc = view.state.doc.toString();
	let adjustedCaretPosition = caretPosition;
	const placeholderChar = "x";
	for (const { position } of widgets) {
		const before = doc.slice(0, position);
		const after = doc.slice(position);
		doc = before + placeholderChar + after;
		if (adjustedCaretPosition > position) adjustedCaretPosition += 1;
	}
	return [doc, adjustedCaretPosition];
}
/**
* Add one or more placeholders in a single transaction. Newlines will be automatically inserted around and between
* each placeholder. Any error placeholders will automatically remove themselves after a delay, although the newlines
* will still be inserted and will remain.
* @param position The offset in the document at which to insert the placeholders.
*/
function addUploadPlaceholders(view, position, ...specs) {
	const [doc, adjustedPositionForNewlineCalcs] = buildDocWithPlaceholderChars(view, position);
	const precedingNewlines = getNewlinePrefix(getMarkdownTree(view.state), doc, adjustedPositionForNewlineCalcs);
	const intermediateNewlines = "\n\n".repeat(Math.max(0, specs.length - 1));
	const succeedingNewlines = getNewlineSuffix(doc, adjustedPositionForNewlineCalcs, true);
	const addPlaceholderEffects = specs.map((spec, i) => addUploadPlaceholderEffect.of({
		...spec,
		position: position + precedingNewlines.length + i * 2
	}));
	view.dispatch({
		effects: addPlaceholderEffects,
		changes: {
			from: position,
			insert: `${precedingNewlines}${intermediateNewlines}${succeedingNewlines}`
		},
		selection: { anchor: position + precedingNewlines.length + intermediateNewlines.length + 2 },
		scrollIntoView: true
	});
	const errorCleanupEffects = specs.filter((spec) => spec.data.error).map((spec) => removeUploadPlaceholderEffect.of({ id: spec.id }));
	if (errorCleanupEffects.length) setTimeout(() => {
		view.dispatch({ effects: errorCleanupEffects });
	}, ERROR_TIMEOUT);
}
/** Update a placeholder. If an error message is set, the placeholder will remove itself after a delay. */
function updateUploadPlaceholder(view, update) {
	view.dispatch({ effects: [updateUploadPlaceholderEffect.of(update)] });
	if (update.data.error) setTimeout(() => view.dispatch({ effects: [removeUploadPlaceholderEffect.of({ id: update.id })] }), ERROR_TIMEOUT);
}
function isActive(state, position) {
	return getActiveSelection(state)?.ranges.some((range) => range.to >= position && range.from <= position) ?? false;
}
/** Remove the placeholder from the view and replace with the `insert` text. Has no effect if the placeholder has been deleted. */
function replaceUploadPlaceholder(view, id, insert) {
	const position = view.state.field(uploadPlaceholderField).entries.get(id)?.position ?? null;
	if (position === null) return;
	view.dispatch({
		effects: [removeUploadPlaceholderEffect.of({ id })],
		changes: {
			from: position,
			insert
		}
	});
}
/** Remove the placeholder from the view without replacing it with any text. Has no effect if the placeholder has been deleted. */
function removeUploadPlaceholder(view, id) {
	view.dispatch({ effects: [removeUploadPlaceholderEffect.of({ id })] });
}
function getAllEntries(state) {
	const field = state.field(uploadPlaceholderField);
	return Array.from(field.entries.entries()).map(([id, entry]) => ({
		id,
		...entry
	}));
}
var uploadPlaceholderField = StateField.define({
	create: () => ({
		entries: /* @__PURE__ */ new Map(),
		decorations: Decoration.none
	}),
	update: (state, tr) => {
		const entries = new Map(state.entries);
		let changed = false;
		let skipMapping = false;
		for (const effect of tr.effects) if (effect.is(addUploadPlaceholderEffect)) {
			const { id, ...entry } = effect.value;
			entries.set(id, entry);
			changed = true;
			skipMapping = true;
		} else if (effect.is(updateUploadPlaceholderEffect) && entries.has(effect.value.id)) {
			const existing = entries.get(effect.value.id);
			entries.set(effect.value.id, {
				...existing,
				data: {
					...existing.data,
					...effect.value.data
				}
			});
			changed = true;
		} else if (effect.is(removeUploadPlaceholderEffect)) changed = entries.delete(effect.value.id);
		if (tr.docChanged && entries.size > 0 && !skipMapping) for (const [id, entry] of entries) {
			const newPosition = tr.changes.mapPos(entry.position, 1, MapMode.TrackAfter);
			if (newPosition !== entry.position) {
				if (newPosition === null) entries.delete(id);
				else entries.set(id, {
					...entry,
					position: newPosition
				});
				changed = true;
			}
		}
		if (activeSelectionChanged(tr)) for (const [id, entry] of entries) {
			const newActive = isActive(tr.state, entry.position);
			if (newActive !== entry.data.active) {
				entries.set(id, {
					...entry,
					data: {
						...entry.data,
						active: newActive
					}
				});
				changed = true;
			}
		}
		if (!changed) return state;
		const builder = new RangeSetBuilder();
		const sortedEntries = Array.from(entries).sort(([, a], [, b]) => {
			if (a.position !== b.position) return a.position - b.position;
			return 0;
		});
		for (const [id, entry] of sortedEntries) {
			const decoration = Decoration.replace({ widget: new UploadPlaceholderWidget(id, entry.data) });
			builder.add(entry.position, entry.position + 1, decoration);
		}
		return {
			entries,
			decorations: builder.finish()
		};
	},
	provide: (field) => [activeNodesExtension, EditorView.decorations.from(field, (value) => value.decorations)]
});
var uploadPlaceholderExtension = [uploadPlaceholderField];
function visitingLink(mouseEvent) {
	return mouseEvent.target instanceof HTMLAnchorElement && (mouseEvent.metaKey || mouseEvent.ctrlKey);
}
/**
* Navigate to links when the `Mod` key is held down while clicking;
* plain clicking simply moves the caret as with other editable text.
*/
function handleClick(mouseEvent) {
	if (visitingLink(mouseEvent)) {
		const anchorElement = mouseEvent.target;
		window.open(anchorElement.href, "_blank", "noopener,noreferrer");
		mouseEvent.preventDefault();
		return true;
	}
}
/** Extension that handles clicks on the editor by navigating to links when they're the click target. */
function visitLinkExtension() {
	return [EditorView.domEventHandlers({
		click: handleClick,
		mousedown: (mouseEvent) => {
			if (visitingLink(mouseEvent)) {
				mouseEvent.preventDefault();
				return true;
			}
		}
	})];
}
function arraysEqual(a, b) {
	return a.length === b.length && a.every((value, index) => value === b[index]);
}
/**
* Observe a selector and force a rerender when the list of elements changes. Does not re-render when the descendants
* of an element change (this avoids infinite render loops when selecting elements to use as containers for new
* content). Returns the array of matched elements.
* @param selector The CSS selector to observe.
* @param elementClass Optional class to filter the elements by. Often `querySelectorAll` is used with a simple type
* parameter or an assertion because it returns an array of `Element` when it's often clear what the element type will
* be from the selector. This can be used to safely ensure that all the elements are of that expected type without
* having to use an assertion. For example, setting to `HTMLInputElement` will ensure that all returned elements are
* inputs.
* @param parent Parent element to limit scope of selector and observer. Defaults to `document.body`.
*/
function useObserveSelector(selector, t0, parentRef) {
	const $ = c$1(6);
	const elementClass = t0 === void 0 ? Element : t0;
	const cachedValueRef = useRef(void 0);
	let t1;
	if ($[0] !== parentRef) {
		t1 = (onUpdate) => {
			const observer = new MutationObserver(() => onUpdate());
			observer.observe(parentRef?.current ?? document.body, {
				subtree: true,
				childList: true
			});
			return () => observer.disconnect();
		};
		$[0] = parentRef;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== elementClass || $[3] !== parentRef || $[4] !== selector) {
		t2 = () => {
			const elements = Array.from((parentRef?.current ?? document.body).querySelectorAll(selector)).filter((e) => e instanceof elementClass);
			if (cachedValueRef.current && arraysEqual(cachedValueRef.current, elements)) return cachedValueRef.current;
			return cachedValueRef.current = elements;
		};
		$[2] = elementClass;
		$[3] = parentRef;
		$[4] = selector;
		$[5] = t2;
	} else t2 = $[5];
	return useSyncExternalStore(t1, t2);
}
/** Parse a string as JSON and assert that the result is an object. */
function parseJsonObject(json) {
	const result = JSON.parse(json);
	if (typeof result === "object" && result !== null && !Array.isArray(result)) return result;
	throw new TypeError(`Failed to parse JSON object: expected an object but got ${typeof result}`);
}
function parseProps(attrValue) {
	return parseJsonObject(attrValue);
}
/**
* Component that hydrates a container with a React component and re-renders when the props attribute changes.
*/
function ReactWidget(t0) {
	const $ = c$1(10);
	const { target: container, widgetName, Component } = t0;
	let t1;
	if ($[0] !== container || $[1] !== widgetName) {
		t1 = (onUpdate) => {
			const observer = new MutationObserver(() => onUpdate());
			observer.observe(container, {
				attributes: true,
				attributeFilter: [propsAttr(widgetName)]
			});
			return () => observer.disconnect();
		};
		$[0] = container;
		$[1] = widgetName;
		$[2] = t1;
	} else t1 = $[2];
	const subscribeToPropsChanges = t1;
	let t2;
	if ($[3] !== container || $[4] !== widgetName) {
		t2 = () => container.getAttribute(propsAttr(widgetName));
		$[3] = container;
		$[4] = widgetName;
		$[5] = t2;
	} else t2 = $[5];
	const propsJson = useSyncExternalStore(subscribeToPropsChanges, t2);
	let t3;
	if ($[6] !== Component || $[7] !== container || $[8] !== propsJson) {
		t3 = propsJson !== null && createPortal(jsx(Component, { ...parseProps(propsJson) }), container);
		$[6] = Component;
		$[7] = container;
		$[8] = propsJson;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
ReactWidget.displayName = "ReactWidget";
var MemoizedReactWidget = memo(ReactWidget);
/**
* Enables us to render CodeMirror widgets with React components. CodeMirror handles rendering the containers, then
* this hook queries for those containers and replaces the contents with React component instances using `Portal`s.
*
* To render widgets using React, create widget classes that extend `ReactComponentWidget` and render them using
* `Decoration.widget` as usual. Then, call `useReactWidgets` in the editor component and render the result next to
* the editor in the React component tree. Components will automatically re-render when the props change as CodeMirror
* updates the view.
*
* @see ReactComponentWidget
*/
MemoizedReactWidget.displayName = "MemoizedReactWidget";
function useReactWidgets(editorContainerRef, widgetName, Component) {
	const $ = c$1(9);
	let t0;
	if ($[0] !== widgetName) {
		t0 = keyAttr(widgetName);
		$[0] = widgetName;
		$[1] = t0;
	} else t0 = $[1];
	const targets = useObserveSelector(`[${t0}]`, void 0, editorContainerRef);
	let t1;
	if ($[2] !== Component || $[3] !== targets || $[4] !== widgetName) {
		let t2;
		if ($[6] !== Component || $[7] !== widgetName) {
			t2 = (target) => {
				const key = target.getAttribute(keyAttr(widgetName));
				if (!key) throw new Error(`Widget ${widgetName} is missing key attribute`);
				return jsx(MemoizedReactWidget, {
					target,
					widgetName,
					Component
				}, key);
			};
			$[6] = Component;
			$[7] = widgetName;
			$[8] = t2;
		} else t2 = $[8];
		t1 = jsx(Fragment$1, { children: targets.map(t2) });
		$[2] = Component;
		$[3] = targets;
		$[4] = widgetName;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
var UploadPlaceholder_module_default = {
	inline: "UploadPlaceholder-module_R4TDeW_inline",
	mediaPreview: "UploadPlaceholder-module_R4TDeW_mediaPreview",
	overlay: "UploadPlaceholder-module_R4TDeW_overlay",
	progress: "UploadPlaceholder-module_R4TDeW_progress",
	spinner: "UploadPlaceholder-module_R4TDeW_spinner",
	video: "UploadPlaceholder-module_R4TDeW_video"
};
function UploadPlaceholder({ fileName, error, mediaKind, previewUrl, active, progressPercent, dimensions }) {
	const description = `Uploading ${fileName}...`;
	if (error) return null;
	if (mediaKind && previewUrl && !active) return /* @__PURE__ */ jsxs("div", {
		className: clsx(UploadPlaceholder_module_default.mediaPreview, mediaKind === "image" && UploadPlaceholder_module_default.inline),
		style: { "--UploadPlaceholder-progress": progressPercent !== void 0 ? `${progressPercent / 100}` : 0 },
		role: "status",
		children: [mediaKind === "image" ? /* @__PURE__ */ jsx("img", {
			src: previewUrl,
			alt: description,
			height: dimensions?.height,
			width: dimensions?.width
		}) : /* @__PURE__ */ jsx("video", {
			src: previewUrl,
			controls: false,
			autoPlay: false,
			muted: true,
			"aria-label": description,
			className: UploadPlaceholder_module_default.video
		}), /* @__PURE__ */ jsx("div", {
			className: UploadPlaceholder_module_default.overlay,
			children: /* @__PURE__ */ jsx(ProgressBar, {
				progress: progressPercent,
				barSize: "large",
				animated: true,
				className: UploadPlaceholder_module_default.progress
			})
		})]
	});
	return /* @__PURE__ */ jsxs("span", {
		role: "status",
		children: [
			/* @__PURE__ */ jsx("span", {
				className: UploadPlaceholder_module_default.spinner,
				children: /* @__PURE__ */ jsx(Spinner, {
					size: "small",
					style: { verticalAlign: "text-top" }
				})
			}),
			" ",
			description
		]
	});
}
UploadPlaceholder.displayName = "UploadPlaceholder";
function htmlImage(alt, src, width, height) {
	return toHtml(h("img", {
		src,
		alt,
		width,
		height
	}));
}
/** List of image MIME types which we do not attempt to render as images. */
var excludedImageMimeTypes = new Set([
	"image/bmp",
	"image/tiff",
	"image/heic",
	"image/heif"
]);
var isImageFile = (file) => file.type.toLowerCase().startsWith("image/") && !excludedImageMimeTypes.has(file.type.toLowerCase());
var isVideoFile = (file) => file.type.toLowerCase().startsWith("video/");
var normalizeUploadUrl = (url) => {
	const trimmed = url.trim();
	if (!trimmed) return trimmed;
	if (typeof window === "undefined" || !window.location?.origin) return trimmed;
	try {
		return new URL(trimmed, window.location.origin).href;
	} catch {
		return trimmed;
	}
};
function calculateRenderedImageDimensions(originalDimensions) {
	if (originalDimensions.pixelsPerInch === 144) return {
		width: Math.round(originalDimensions.width / 2),
		height: Math.round(originalDimensions.height / 2)
	};
}
var sizedMarkdownImage = (src, alt, dimensions) => {
	return dimensions ? htmlImage(alt, src, dimensions.width, dimensions.height) : markdownImage(alt, src);
};
var markdown = (entry, result) => {
	switch (entry.mediaKind) {
		case "video": return result.url;
		case "image": return sizedMarkdownImage(result.url, "Image", entry.dimensions);
		case void 0: return markdownLink(result.file.name, result.url);
	}
};
var useFileHandler = ({ view, disabled, onUploadFile, acceptedFileTypes, onFilesRejected }, telemetry) => {
	const placeholderIdRef = useRef(0);
	const [uploadInProgress, setUploadInProgress] = useState(false);
	const [errorMessage, setErrorMessage] = useState(null);
	const viewRef = useTrackingRef(view);
	const updatePlaceholderProgress = useCallback((entryId, progressPercent) => {
		if (viewRef.current) updateUploadPlaceholder(viewRef.current, {
			id: entryId,
			data: { progressPercent }
		});
	}, [viewRef]);
	const insertPlaceholders = useCallback((entries) => {
		const editorView = viewRef.current;
		if (!editorView || entries.length === 0) return;
		let insertPos = getDropPosition(editorView.state);
		if (insertPos !== null) clearDropPosition(editorView);
		else insertPos = editorView.state.selection.main.from;
		editorView.focus();
		addUploadPlaceholders(editorView, insertPos, ...entries.map((entry) => ({
			id: entry.id,
			data: {
				fileName: entry.file.name,
				progressPercent: 0,
				previewUrl: entry.previewUrl,
				mediaKind: entry.mediaKind,
				dimensions: entry.dimensions,
				error: entry.error
			}
		})));
	}, [viewRef]);
	const handleCompletedFileUpload = useSafeAsyncCallback((entry_0, result) => {
		const editorView_0 = viewRef.current;
		if (!editorView_0) return;
		const replacement = result.url ? markdown(entry_0, result) : "";
		if (replacement) {
			replaceUploadPlaceholder(editorView_0, entry_0.id, replacement);
			if (entry_0.mediaKind === "video") registerValidVideoUrl(editorView_0, result.url ?? "");
		} else {
			const errorMsg = "error" in result && result.error !== void 0 ? `Failed to upload "${entry_0.file.name}": ${result.error.message}` : `Failed to upload "${entry_0.file.name}"`;
			removeUploadPlaceholder(editorView_0, entry_0.id);
			setErrorMessage(errorMsg);
		}
		if (entry_0.previewUrl) URL.revokeObjectURL(entry_0.previewUrl);
	});
	const uploadFiles = useCallback((entries_0) => entries_0.map(async (entry_1) => {
		const progressCallback = (progressBytes) => {
			const percent = entry_1.file.size > 0 ? Math.round(progressBytes / entry_1.file.size * 100) : 0;
			updatePlaceholderProgress(entry_1.id, Math.min(percent, 99));
		};
		let result_0 = {
			url: null,
			file: entry_1.file
		};
		try {
			result_0 = await onUploadFile?.(entry_1.file, progressCallback) ?? {
				file: entry_1.file,
				url: null
			};
		} catch (error) {
			result_0 = {
				file: entry_1.file,
				url: null,
				error: error instanceof Error ? error : void 0
			};
			setTimeout(() => {
				throw error;
			});
		}
		result_0.url &&= normalizeUploadUrl(result_0.url);
		telemetry?.trackFileUpload({
			phase: result_0.url ? "succeeded" : "failed",
			mimeType: entry_1.file.type || "unknown",
			sizeBytes: entry_1.file.size,
			mediaKind: entry_1.mediaKind ?? "other",
			errorType: result_0.url ? void 0 : "upload"
		});
		handleCompletedFileUpload(entry_1, result_0);
	}), [
		onUploadFile,
		handleCompletedFileUpload,
		telemetry,
		updatePlaceholderProgress
	]);
	const fileSelect = useUnifiedFileSelect({
		acceptedFileTypes,
		multi: true,
		onSelect: useCallback(async (accepted, rejected) => {
			setErrorMessage(null);
			const acceptedEntries = await Promise.all(accepted.map(async (file) => {
				const id = `upload-placeholder-${placeholderIdRef.current++}`;
				const mediaKind = isVideoFile(file) ? "video" : isImageFile(file) ? "image" : void 0;
				const previewUrl = mediaKind ? URL.createObjectURL(file) : void 0;
				let originalDimensions = null;
				if (mediaKind === "image") try {
					originalDimensions = await getImageSizeFromFile(file);
				} catch (error_0) {
					setTimeout(() => {
						throw error_0;
					});
				}
				return {
					id,
					file,
					previewUrl,
					mediaKind,
					dimensions: originalDimensions ? calculateRenderedImageDimensions(originalDimensions) : void 0
				};
			}));
			if (rejected.length > 0) {
				const rejectedNames = rejected.map((f) => f.name).join(", ");
				setErrorMessage(rejected.length === 1 ? `Cannot upload "${rejected[0].name}": File type is not supported` : `Cannot upload files: ${rejectedNames}. File types are not supported`);
			}
			insertPlaceholders(acceptedEntries);
			for (const entry_2 of acceptedEntries) telemetry?.trackFileUpload({
				phase: "selected",
				mimeType: entry_2.file.type || "unknown",
				sizeBytes: entry_2.file.size,
				mediaKind: entry_2.mediaKind ?? "other"
			});
			if (rejected.length > 0) {
				const rejectedTypes = new Set(rejected.map(({ name }) => {
					const parts = name.split(".");
					return parts.length > 1 ? `.${parts.at(-1)}` : "";
				}).filter((s) => s !== ""));
				onFilesRejected?.(rejected, [...rejectedTypes]);
			}
			if (acceptedEntries.length > 0) {
				setUploadInProgress(true);
				try {
					await Promise.allSettled(uploadFiles(acceptedEntries));
				} finally {
					setUploadInProgress(false);
				}
			}
		}, [
			onFilesRejected,
			insertPlaceholders,
			telemetry,
			uploadFiles
		])
	});
	if (disabled || !view) return {
		clickTargetProps: { onClick: noop },
		dropTargetProps: {
			onDragEnter: noop,
			onDragLeave: noop,
			onDrop: noop,
			onDragOver: noop
		},
		pasteTargetProps: { onPaste: noop },
		isDraggedOver: false,
		uploadInProgress: false,
		clearErrorMessage: noop
	};
	const clickTargetProps = {
		...fileSelect.clickTargetProps,
		onClick: (event) => {
			telemetry?.trackToolbarInteraction({
				control: "attachment",
				action: "attachment",
				trigger: "toolbar",
				isActive: false,
				handled: true
			});
			fileSelect.clickTargetProps.onClick(event);
		}
	};
	const dropTargetProps = {
		...fileSelect.dropTargetProps,
		onDragLeave: (event_0) => {
			if (!event_0.currentTarget.contains(event_0.relatedTarget)) fileSelect.dropTargetProps.onDragLeave(event_0);
		}
	};
	return onUploadFile ? {
		...fileSelect,
		clickTargetProps,
		dropTargetProps,
		uploadInProgress,
		errorMessage,
		clearErrorMessage: () => setErrorMessage(null)
	} : null;
};
var DEFAULT_ACCEPTED_FILE_TYPES = ["image/*", "video/*"];
/** The actual CodeMirror hybrid editor internal implementation. */
function CodeMirrorEditor({ ref = null, value, onChange, disabled, onChangeViewMode, placeholder: placeholderText, "aria-describedby": ariaDescribedBy, acceptedFileTypes = DEFAULT_ACCEPTED_FILE_TYPES, onUploadFile, onFilesRejected, onPrimaryAction, referenceSuggestions, mentionSuggestions, emojiSuggestions, emojiTone, onInputFocus, customToolbarButtons, banner, isGenerating }) {
	const telemetry = useHybridEditorTelemetry();
	const trackKeyboardShortcut = useEffectEvent((...args) => telemetry.trackKeyboardShortcut(...args));
	const viewModeRef = useRef("hybrid");
	const [selectedViewMode, setSelectedViewMode] = useState("hybrid");
	const emitViewModeChange = useCallback((nextViewMode, trigger = "view_switcher") => {
		const previousViewMode = viewModeRef.current;
		telemetry.trackViewSwitch({
			from: previousViewMode,
			to: nextViewMode,
			trigger
		});
		viewModeRef.current = nextViewMode;
		setSelectedViewMode(nextViewMode);
		onChangeViewMode?.(nextViewMode);
	}, [onChangeViewMode, telemetry]);
	const handleViewSwitchChange = useCallback((nextViewMode_0) => emitViewModeChange(nextViewMode_0, "view_switcher"), [emitViewModeChange]);
	const [selectionContext, setSelectionContext] = useState(initialSelectionContext);
	/** Tracks the expected value for the next render according to user input. */
	const [expectedValue, setExpectedValue] = useState(value);
	const onUpdate = useEffectEvent((update) => {
		if (update.docChanged) {
			const newValue = update.state.doc.toString();
			setExpectedValue(newValue);
			onChange?.(newValue);
		}
		if (update.transactions.some((tr) => selectionContextChanged(tr))) setSelectionContext(getCurrentSelectionContext(update.state));
		if (update.transactions.some((tr_0) => focusChanged(tr_0))) {
			if (isFocused(update.state)) onInputFocus?.();
		}
	});
	const [view, setView] = useState(null);
	const { autocompleteSuggestionsMenu, autocompleteKeymapCompartment, autocompleteListenerCompartment } = useAutocomplete({
		view,
		setViewMode: useCallback((viewMode) => emitViewModeChange(viewMode, "slash_commands_hint"), [emitViewModeChange]),
		referenceSuggestions,
		mentionSuggestions,
		emojiSuggestions,
		emojiTone,
		telemetry,
		tabInsertsSuggestions: true
	});
	const placeholderCompartment = useCompartment(view, useMemo(() => placeholder(placeholderText ?? ""), [placeholderText]));
	const readonlyCompartment = useCompartment(view, useMemo(() => disabled ? readOnly() : [], [disabled]));
	const a11yAttributesCompartment = useCompartment(view, useMemo(() => EditorView.contentAttributes.of({
		"aria-label": "Markdown content",
		...ariaDescribedBy ? { "aria-describedby": ariaDescribedBy } : {}
	}), [ariaDescribedBy]));
	const primaryAction = useEffectEvent(() => {
		if (onPrimaryAction) {
			onPrimaryAction();
			return true;
		}
		return false;
	});
	const containerRef = useRef(null);
	const fileHandler = useFileHandler({
		view,
		disabled,
		onUploadFile,
		acceptedFileTypes,
		onFilesRejected
	}, telemetry);
	const uploadPlaceholderWidgets = useReactWidgets(containerRef, UploadPlaceholderWidget.widgetName, UploadPlaceholder);
	const initialValueRef = useRef(value);
	useEffect(function initializeCodeMirror() {
		const extensions = [
			doubleClickSelectionExtension,
			proseExtension,
			styleContentsExtension,
			uploadPlaceholderExtension,
			dropPositionExtension,
			caretFlashExtension,
			drawSelection(),
			selectionContextExtension,
			pasteLinksExtension,
			markdownContinuationExtension,
			visitLinkExtension(),
			history(),
			EditorView.updateListener.of(onUpdate),
			autocompleteListenerCompartment,
			a11yAttributesCompartment,
			modPressedExtension,
			EditorView.contentAttributes.from(isModPressedField, (isModPressed) => ({ class: clsx(isModPressed && HybridMarkdownEditor_module_default.modPressed) })),
			placeholderCompartment,
			readonlyCompartment,
			markdownKeymapExtension({
				primaryAction,
				trackKeyboardShortcut
			}),
			autocompleteKeymapCompartment,
			keymap.of(historyKeymap),
			keymap.of(defaultKeymap)
		];
		const editorView = new EditorView({
			parent: containerRef.current,
			doc: initialValueRef.current,
			extensions
		});
		setView(editorView);
		return () => {
			editorView.destroy();
			setView(null);
		};
	}, [
		a11yAttributesCompartment,
		autocompleteKeymapCompartment,
		autocompleteListenerCompartment,
		placeholderCompartment,
		readonlyCompartment
	]);
	useLayoutEffect(function syncControlledValue() {
		if (expectedValue !== value && onChange !== void 0) view?.update([view.state.update({ changes: {
			from: 0,
			to: view.state.doc.length,
			insert: value
		} })]);
	}, [
		expectedValue,
		value,
		onChange,
		view
	]);
	useImperativeHandle(ref, () => ({
		view,
		focus: () => view?.focus(),
		reset: () => view?.dispatch({ changes: {
			from: 0,
			to: view.state.doc.length,
			insert: ""
		} }),
		scrollIntoView: (opts) => view?.dom?.scrollIntoView(opts),
		moveCursorToEnd: () => view?.dispatch({ selection: { anchor: view.state.doc.length } }),
		containerRef
	}), [view]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(Header, {
			selectedView: selectedViewMode,
			onChangeViewMode: handleViewSwitchChange,
			uploadInProgress: fileHandler?.uploadInProgress ?? false,
			children: /* @__PURE__ */ jsx(Toolbar, {
				view,
				selectedNodes: selectionContext,
				fileUploadButton: fileHandler ? /* @__PURE__ */ jsx(FileUploadButton, {
					disabled: fileHandler.uploadInProgress,
					...fileHandler.clickTargetProps
				}) : null,
				customButtons: customToolbarButtons
			})
		}),
		/* @__PURE__ */ jsxs("div", {
			className: HybridMarkdownEditor_module_default.editorWrapper,
			children: [/* @__PURE__ */ jsx("div", {
				ref: containerRef,
				className: clsx(fileHandler?.isDraggedOver && HybridMarkdownEditor_module_default.isDraggedOver, isGenerating && HybridMarkdownEditor_module_default.generatingText),
				...fileHandler?.dropTargetProps,
				...fileHandler?.pasteTargetProps
			}), isGenerating && /* @__PURE__ */ jsx("div", {
				className: HybridMarkdownEditor_module_default.skeletonOverlay,
				role: "status",
				"data-testid": "hybrid-editor-skeleton-overlay",
				"aria-live": "polite",
				"aria-label": "Generating text",
				children: /* @__PURE__ */ jsx(SkeletonText, { lines: 5 })
			})]
		}),
		fileHandler?.errorMessage ? /* @__PURE__ */ jsx(ErrorBanner, { children: fileHandler.errorMessage }) : banner,
		autocompleteSuggestionsMenu,
		uploadPlaceholderWidgets
	] });
}
CodeMirrorEditor.displayName = "CodeMirrorEditor";
export { CodeMirrorEditor };
