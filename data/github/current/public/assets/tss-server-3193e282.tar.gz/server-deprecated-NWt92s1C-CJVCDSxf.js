import { o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { O as CheckIcon, _i as Truncate, fi as Tooltip$1 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Octicon$1 } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { g as Ye, t as Box, y as sx } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { t as TabNav_default } from "./server-TabNav-ChmPEmaf-BGcvB88p.js";
import React, { createElement, forwardRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isValidElementType } from "react-is";
var classes$3 = { "Header": "prc-ActionList-Header-585kg" };
/**
* Displays the name and description of a `Group`.
*/
function Header(t0) {
	const $ = c(16);
	let auxiliaryText;
	let className;
	let props;
	let t1;
	let title;
	if ($[0] !== t0) {
		const { variant: t2, title: t3, auxiliaryText: t4, children: _children, className: t5, ...t6 } = t0;
		t1 = t2;
		title = t3;
		auxiliaryText = t4;
		className = t5;
		props = t6;
		$[0] = t0;
		$[1] = auxiliaryText;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
		$[5] = title;
	} else {
		auxiliaryText = $[1];
		className = $[2];
		props = $[3];
		t1 = $[4];
		title = $[5];
	}
	const variant = t1 === void 0 ? "subtle" : t1;
	let t2;
	if ($[6] !== className) {
		t2 = clsx(className, classes$3.Header);
		$[6] = className;
		$[7] = t2;
	} else t2 = $[7];
	const t3 = variant === "filled" ? "" : void 0;
	let t4;
	if ($[8] !== auxiliaryText) {
		t4 = auxiliaryText && /* @__PURE__ */ jsx("span", { children: auxiliaryText });
		$[8] = auxiliaryText;
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== props || $[11] !== t2 || $[12] !== t3 || $[13] !== t4 || $[14] !== title) {
		t5 = /* @__PURE__ */ jsxs("div", {
			role: "heading",
			className: t2,
			"data-filled": t3,
			"data-component": "ActionList.Header",
			...props,
			children: [title, t4]
		});
		$[10] = props;
		$[11] = t2;
		$[12] = t3;
		$[13] = t4;
		$[14] = title;
		$[15] = t5;
	} else t5 = $[15];
	return t5;
}
/**
* Collects related `Items` in an `ActionList`.
*/
function Group(t0) {
	const $ = c(10);
	let header;
	let items;
	let props;
	if ($[0] !== t0) {
		({header, items, ...props} = t0);
		$[0] = t0;
		$[1] = header;
		$[2] = items;
		$[3] = props;
	} else {
		header = $[1];
		items = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== header) {
		t1 = header && /* @__PURE__ */ jsx(Header, { ...header });
		$[4] = header;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== items || $[7] !== props || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsxs("div", {
			...props,
			children: [t1, items]
		});
		$[6] = items;
		$[7] = props;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
var classes$2 = {
	"DividedContent": "prc-ActionList-DividedContent-qks5p",
	"MainContent": "prc-ActionList-MainContent-XZAI3",
	"Item": "prc-ActionList-Item-eN6NY",
	"Item--danger": "prc-ActionList-Item--danger-2UZJs",
	"Item--disabled": "prc-ActionList-Item--disabled-6k-1w",
	"MainContent--inline": "prc-ActionList-MainContent--inline-112-0",
	"MainContent--block": "prc-ActionList-MainContent--block-l6ozE",
	"BaseVisualContainer": "prc-ActionList-BaseVisualContainer-C06g1",
	"LeadingVisualContainer": "prc-ActionList-LeadingVisualContainer-2mC-O",
	"TrailingContent": "prc-ActionList-TrailingContent-0Uf2c",
	"DescriptionContainer": "prc-ActionList-DescriptionContainer-RBvTf",
	"MultiSelectIcon": "prc-ActionList-MultiSelectIcon-XFUmo"
};
/**
* An actionable or selectable `Item` with an optional icon and description.
*/
var Item = /* @__PURE__ */ React.forwardRef((itemProps, ref) => {
	const $ = c(82);
	let LeadingVisual;
	let TrailingIcon;
	let TrailingVisual;
	let children;
	let className;
	let description;
	let disabled;
	let id;
	let onAction;
	let onClick;
	let onKeyPress;
	let props;
	let selected;
	let selectionVariant;
	let showDivider;
	let t0;
	let t1;
	let t2;
	let text;
	let trailingText;
	if ($[0] !== itemProps) {
		({as: t0, text, description, descriptionVariant: t1, selected, selectionVariant, leadingVisual: LeadingVisual, trailingIcon: TrailingIcon, trailingVisual: TrailingVisual, trailingText, variant: t2, showDivider, disabled, onAction, onKeyPress, children, onClick, id, className, ...props} = itemProps);
		$[0] = itemProps;
		$[1] = LeadingVisual;
		$[2] = TrailingIcon;
		$[3] = TrailingVisual;
		$[4] = children;
		$[5] = className;
		$[6] = description;
		$[7] = disabled;
		$[8] = id;
		$[9] = onAction;
		$[10] = onClick;
		$[11] = onKeyPress;
		$[12] = props;
		$[13] = selected;
		$[14] = selectionVariant;
		$[15] = showDivider;
		$[16] = t0;
		$[17] = t1;
		$[18] = t2;
		$[19] = text;
		$[20] = trailingText;
	} else {
		LeadingVisual = $[1];
		TrailingIcon = $[2];
		TrailingVisual = $[3];
		children = $[4];
		className = $[5];
		description = $[6];
		disabled = $[7];
		id = $[8];
		onAction = $[9];
		onClick = $[10];
		onKeyPress = $[11];
		props = $[12];
		selected = $[13];
		selectionVariant = $[14];
		showDivider = $[15];
		t0 = $[16];
		t1 = $[17];
		t2 = $[18];
		text = $[19];
		trailingText = $[20];
	}
	const Component = t0 === void 0 ? "div" : t0;
	const descriptionVariant = t1 === void 0 ? "inline" : t1;
	const variant = t2 === void 0 ? "default" : t2;
	const labelId = useId$1();
	const descriptionId = useId$1();
	let t3;
	if ($[21] !== disabled || $[22] !== itemProps || $[23] !== onAction || $[24] !== onKeyPress) {
		t3 = (event) => {
			var _onKeyPress;
			if (disabled) return;
			(_onKeyPress = onKeyPress) === null || _onKeyPress === void 0 || _onKeyPress(event);
			if (!event.defaultPrevented && [" ", "Enter"].includes(event.key)) {
				var _onAction;
				(_onAction = onAction) === null || _onAction === void 0 || _onAction(itemProps, event);
			}
		};
		$[21] = disabled;
		$[22] = itemProps;
		$[23] = onAction;
		$[24] = onKeyPress;
		$[25] = t3;
	} else t3 = $[25];
	const keyPressHandler = t3;
	let t4;
	if ($[26] !== disabled || $[27] !== itemProps || $[28] !== onAction || $[29] !== onClick) {
		t4 = (event_0) => {
			var _onClick;
			if (disabled) return;
			(_onClick = onClick) === null || _onClick === void 0 || _onClick(event_0);
			if (!event_0.defaultPrevented) {
				var _onAction2;
				(_onAction2 = onAction) === null || _onAction2 === void 0 || _onAction2(itemProps, event_0);
			}
		};
		$[26] = disabled;
		$[27] = itemProps;
		$[28] = onAction;
		$[29] = onClick;
		$[30] = t4;
	} else t4 = $[30];
	const clickHandler = t4;
	const t5 = disabled ? void 0 : -1;
	const t6 = text ? labelId : void 0;
	const t7 = description ? descriptionId : void 0;
	const t8 = showDivider ? "" : void 0;
	const t9 = variant === "danger" && classes$2["Item--danger"];
	const t10 = disabled && classes$2["Item--disabled"];
	let t11;
	if ($[31] !== className || $[32] !== t10 || $[33] !== t9) {
		t11 = clsx(classes$2.Item, t9, t10, className);
		$[31] = className;
		$[32] = t10;
		$[33] = t9;
		$[34] = t11;
	} else t11 = $[34];
	let t12;
	if ($[35] !== selected || $[36] !== selectionVariant) {
		t12 = !!selected === selected && /* @__PURE__ */ jsx("div", {
			className: classes$2.BaseVisualContainer,
			children: selectionVariant === "multiple" ? /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("svg", {
				className: classes$2.MultiSelectIcon,
				"data-selected": selected ? "" : void 0,
				width: "16",
				height: "16",
				viewBox: "0 0 16 16",
				xmlns: "http://www.w3.org/2000/svg",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ jsx("rect", {
					x: "2",
					y: "2",
					width: "12",
					height: "12",
					rx: "4"
				}), /* @__PURE__ */ jsx("path", {
					fillRule: "evenodd",
					strokeWidth: "0",
					d: "M4.03231 8.69862C3.84775 8.20646 4.49385 7.77554 4.95539 7.77554C5.41693 7.77554 6.80154 9.85246 6.80154 9.85246C6.80154 9.85246 10.2631 4.314 10.4938 4.08323C10.7246 3.85246 11.8785 4.08323 11.4169 5.00631C11.0081 5.82388 7.26308 11.4678 7.26308 11.4678C7.26308 11.4678 6.80154 12.1602 6.34 11.4678C5.87846 10.7755 4.21687 9.19077 4.03231 8.69862Z"
				})]
			}) }) : selected && /* @__PURE__ */ jsx(CheckIcon, { fill: "var(--fgColor-default)" })
		});
		$[35] = selected;
		$[36] = selectionVariant;
		$[37] = t12;
	} else t12 = $[37];
	let t13;
	if ($[38] !== LeadingVisual || $[39] !== disabled || $[40] !== variant) {
		t13 = LeadingVisual && /* @__PURE__ */ jsx("div", {
			className: classes$2.LeadingVisualContainer,
			"data-variant": variant,
			"data-disabled": disabled ? "" : void 0,
			children: /* @__PURE__ */ jsx(LeadingVisual, {})
		});
		$[38] = LeadingVisual;
		$[39] = disabled;
		$[40] = variant;
		$[41] = t13;
	} else t13 = $[41];
	const t14 = descriptionVariant === "inline" ? "row" : "column";
	let t15;
	if ($[42] !== t14) {
		t15 = { "--main-content-flex-direction": t14 };
		$[42] = t14;
		$[43] = t15;
	} else t15 = $[43];
	const t16 = t15;
	let t17;
	if ($[44] !== labelId || $[45] !== text) {
		t17 = text ? /* @__PURE__ */ jsx("span", {
			id: labelId,
			children: text
		}) : null;
		$[44] = labelId;
		$[45] = text;
		$[46] = t17;
	} else t17 = $[46];
	let t18;
	if ($[47] !== description || $[48] !== descriptionId || $[49] !== descriptionVariant) {
		t18 = description ? /* @__PURE__ */ jsx("span", {
			id: descriptionId,
			style: {
				"--description-container-margin-left": descriptionVariant === "inline" ? "var(--base-size-8)" : 0,
				"--description-container-flex-basis": descriptionVariant === "inline" ? 0 : "auto"
			},
			className: classes$2.DescriptionContainer,
			children: descriptionVariant === "block" ? description : /* @__PURE__ */ jsx(Truncate, {
				title: description,
				inline: true,
				maxWidth: "100%",
				children: description
			})
		}) : null;
		$[47] = description;
		$[48] = descriptionId;
		$[49] = descriptionVariant;
		$[50] = t18;
	} else t18 = $[50];
	let t19;
	if ($[51] !== children || $[52] !== t16 || $[53] !== t17 || $[54] !== t18) {
		t19 = /* @__PURE__ */ jsxs("div", {
			style: t16,
			className: classes$2.MainContent,
			children: [
				children,
				t17,
				t18
			]
		});
		$[51] = children;
		$[52] = t16;
		$[53] = t17;
		$[54] = t18;
		$[55] = t19;
	} else t19 = $[55];
	let t20;
	if ($[56] !== TrailingIcon || $[57] !== TrailingVisual || $[58] !== disabled || $[59] !== trailingText || $[60] !== variant) {
		t20 = TrailingVisual ? /* @__PURE__ */ jsx("div", {
			className: classes$2.TrailingContent,
			"data-variant": variant,
			"data-disabled": disabled ? "" : void 0,
			children: typeof TrailingVisual !== "string" && isValidElementType(TrailingVisual) ? /* @__PURE__ */ jsx(TrailingVisual, {}) : TrailingVisual
		}) : TrailingIcon || trailingText ? /* @__PURE__ */ jsxs("div", {
			className: classes$2.TrailingContent,
			"data-variant": variant,
			"data-disabled": disabled ? "" : void 0,
			children: [trailingText, TrailingIcon && /* @__PURE__ */ jsx(TrailingIcon, {})]
		}) : null;
		$[56] = TrailingIcon;
		$[57] = TrailingVisual;
		$[58] = disabled;
		$[59] = trailingText;
		$[60] = variant;
		$[61] = t20;
	} else t20 = $[61];
	let t21;
	if ($[62] !== t19 || $[63] !== t20) {
		t21 = /* @__PURE__ */ jsxs("div", {
			className: classes$2.DividedContent,
			"data-component": "ActionList.DividedContent",
			children: [t19, t20]
		});
		$[62] = t19;
		$[63] = t20;
		$[64] = t21;
	} else t21 = $[64];
	let t22;
	if ($[65] !== Component || $[66] !== clickHandler || $[67] !== id || $[68] !== keyPressHandler || $[69] !== props || $[70] !== ref || $[71] !== selected || $[72] !== t11 || $[73] !== t12 || $[74] !== t13 || $[75] !== t21 || $[76] !== t5 || $[77] !== t6 || $[78] !== t7 || $[79] !== t8 || $[80] !== variant) {
		t22 = /* @__PURE__ */ jsxs(Component, {
			ref,
			tabIndex: t5,
			"data-variant": variant,
			"aria-selected": selected,
			"aria-labelledby": t6,
			"aria-describedby": t7,
			"data-divider": t8,
			...props,
			"data-id": id,
			onKeyPress: keyPressHandler,
			onClick: clickHandler,
			className: t11,
			children: [
				t12,
				t13,
				t21
			]
		});
		$[65] = Component;
		$[66] = clickHandler;
		$[67] = id;
		$[68] = keyPressHandler;
		$[69] = props;
		$[70] = ref;
		$[71] = selected;
		$[72] = t11;
		$[73] = t12;
		$[74] = t13;
		$[75] = t21;
		$[76] = t5;
		$[77] = t6;
		$[78] = t7;
		$[79] = t8;
		$[80] = variant;
		$[81] = t22;
	} else t22 = $[81];
	return t22;
});
Item.displayName = "ActionList.Item";
var classes$1 = { "Divider": "prc-ActionList-Divider-hCCoA" };
function Divider() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsx("div", {
			"data-component": "ActionList.Divider",
			className: classes$1.Divider
		});
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
/**
* `Divider` fulfills the `ItemPropsWithCustomRenderer` contract,
* so it can be used inline in an `ActionList`’s `items` prop.
* In other words, `items={[ActionList.Divider]}` is supported as a concise
* alternative to `items={[{renderItem: () => <ActionList.Divider />}]}`.
*/
Divider.renderItem = Divider;
var classes = { "List": "prc-ActionList-List-0R5kQ" };
/**
* Asserts that the given value fulfills the `GroupedListProps` contract.
* @param props A value which fulfills either the `ListPropsBase` or the `GroupedListProps` contract.
*/
function isGroupedListProps(props) {
	return "groupMetadata" in props;
}
/**
* Contract for props passed to the `List` component.
*/
var listStyles = {
	fontSize: "var(--text-body-size-medium, 14px)",
	lineHeight: "20px"
};
/**
* Returns style objects for `List` children matching the given `List` style variation.
* @param variant `List` style variation.
*/
function useListVariant(variant = "inset") {
	switch (variant) {
		case "full": return {
			headerStyle: {
				paddingLeft: "var(--base-size-8, 8px)",
				paddingRight: "var(--base-size-8, 8px)"
			},
			itemStyle: { borderRadius: 0 }
		};
		default: return {
			firstGroupStyle: { marginTop: "var(--base-size-8, 8px)" },
			lastGroupStyle: { marginBottom: "var(--base-size-8, 8px)" },
			itemStyle: {
				marginLeft: "var(--base-size-8, 8px)",
				marginRight: "var(--base-size-8, 8px)"
			}
		};
	}
}
/**
* Lists `Item`s, either grouped or ungrouped, with a `Divider` between each `Group`.
*/
var List = /* @__PURE__ */ React.forwardRef((props, forwardedRef) => {
	const $ = c(14);
	const { style, ...restProps } = props;
	const { firstGroupStyle, lastGroupStyle, headerStyle, itemStyle } = useListVariant(restProps.variant);
	const renderGroup = (groupProps) => {
		var _ref;
		return /* @__PURE__ */ createElement(((_ref = "renderGroup" in groupProps && groupProps.renderGroup) !== null && _ref !== void 0 ? _ref : restProps.renderGroup) || Group, {
			...groupProps,
			key: groupProps.groupId
		});
	};
	const renderItem = (itemProps, item, itemIndex) => {
		var _ref2, _ref3, _itemProps$id;
		const ItemComponent = "renderItem" in itemProps && itemProps.renderItem || restProps.renderItem || Item;
		const key = (_ref2 = (_ref3 = "key" in itemProps ? itemProps.key : void 0) !== null && _ref3 !== void 0 ? _ref3 : (_itemProps$id = itemProps.id) === null || _itemProps$id === void 0 ? void 0 : _itemProps$id.toString()) !== null && _ref2 !== void 0 ? _ref2 : itemIndex.toString();
		return /* @__PURE__ */ createElement(ItemComponent, {
			showDivider: restProps.showItemDividers,
			selectionVariant: restProps.selectionVariant,
			...itemProps,
			key,
			style: itemStyle,
			item
		});
	};
	let groups = [];
	if (!isGroupedListProps(restProps)) {
		let t0;
		if ($[0] !== renderItem) {
			t0 = (item_0, index) => renderItem(item_0, item_0, index);
			$[0] = renderItem;
			$[1] = t0;
		} else t0 = $[1];
		groups = [{
			items: restProps.items.map(t0),
			groupId: "0"
		}];
	} else {
		const groupMap = restProps.groupMetadata.reduce(_temp, /* @__PURE__ */ new Map());
		for (const itemProps_0 of restProps.items) {
			var _group$items$length, _group$items, _group$items2;
			const group = groupMap.get(itemProps_0.groupId);
			const itemIndex_0 = (_group$items$length = group === null || group === void 0 ? void 0 : (_group$items = group.items) === null || _group$items === void 0 ? void 0 : _group$items.length) !== null && _group$items$length !== void 0 ? _group$items$length : 0;
			groupMap.set(itemProps_0.groupId, {
				...group,
				items: [...(_group$items2 = group === null || group === void 0 ? void 0 : group.items) !== null && _group$items2 !== void 0 ? _group$items2 : [], renderItem({
					showDivider: group === null || group === void 0 ? void 0 : group.showItemDividers,
					...group && "renderItem" in group && { renderItem: group.renderItem },
					...itemProps_0
				}, itemProps_0, itemIndex_0)]
			});
		}
		groups = [...groupMap.values()];
	}
	let t0;
	if ($[2] !== props.className) {
		t0 = clsx(classes.List, props.className);
		$[2] = props.className;
		$[3] = t0;
	} else t0 = $[3];
	let t1;
	if ($[4] !== style) {
		t1 = style || {};
		$[4] = style;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== t1) {
		t2 = {
			...listStyles,
			...t1
		};
		$[6] = t1;
		$[7] = t2;
	} else t2 = $[7];
	const t4 = groups.map((t3, index_0) => {
		const { header, ...groupProps_0 } = t3;
		const hasFilledHeader = (header === null || header === void 0 ? void 0 : header.variant) === "filled";
		const shouldShowDivider = index_0 > 0 && !hasFilledHeader;
		return /* @__PURE__ */ jsxs(React.Fragment, { children: [shouldShowDivider ? /* @__PURE__ */ jsx(Divider, {}, `${groupProps_0.groupId}-divider`) : null, renderGroup({
			style: {
				...index_0 === 0 && firstGroupStyle,
				...index_0 === groups.length - 1 && lastGroupStyle,
				...index_0 > 0 && !shouldShowDivider && { marginTop: "var(--base-size-8, 8px)" }
			},
			...header && { header: {
				...header,
				style: headerStyle
			} },
			...groupProps_0
		})] }, groupProps_0.groupId);
	});
	let t5;
	if ($[8] !== forwardedRef || $[9] !== restProps || $[10] !== t0 || $[11] !== t2 || $[12] !== t4) {
		t5 = /* @__PURE__ */ jsx("div", {
			...restProps,
			ref: forwardedRef,
			className: t0,
			style: t2,
			children: t4
		});
		$[8] = forwardedRef;
		$[9] = restProps;
		$[10] = t0;
		$[11] = t2;
		$[12] = t4;
		$[13] = t5;
	} else t5 = $[13];
	return t5;
});
List.displayName = "ActionList";
function _temp(groupAccumulator, groupMetadata) {
	return groupAccumulator.set(groupMetadata.groupId, groupMetadata);
}
/**
* @deprecated Use ActionList with composable API instead. See https://primer.style/react/ActionList for more details.
*/
var ActionList$1 = Object.assign(List, {
	Group,
	Item,
	Divider
});
var StyledTabNav = Ye(TabNav_default).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "TabNav__StyledTabNav",
	componentId: "sc-13kad3t-0"
})(["", ""], sx);
var TabNavImpl = ({ as, ...props }) => {
	return /* @__PURE__ */ jsx(StyledTabNav, {
		...props,
		...as ? { forwardedAs: as } : {}
	});
};
var StyledTabNavLink = Ye(TabNav_default.Link).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "TabNav__StyledTabNavLink",
	componentId: "sc-13kad3t-1"
})(["", ""], sx);
var TabNavLink = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledTabNavLink, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
Object.assign(TabNavImpl, { Link: TabNavLink });
var StyledDialog = /* @__PURE__ */ forwardRef(function Dialog(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Dialog_default,
		ref,
		...props
	});
});
var DialogImpl = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledDialog, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
var StyledDialogHeader = /* @__PURE__ */ forwardRef(function DialogHeader(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: Dialog_default.Header,
		ref,
		...props
	});
});
var DialogHeader = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledDialogHeader, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
Object.assign(DialogImpl, { Header: DialogHeader });
/**
* @deprecated Use the icon component directly from `@primer/octicons-react` instead
*/
var StyledOcticon = Ye(Octicon$1).withConfig({ shouldForwardProp(prop) {
	return prop !== "sx";
} }).withConfig({
	displayName: "Octicon__StyledOcticon",
	componentId: "sc-jtj3m8-0"
})(["", ""], ({ color, sx: sxProp }) => sx({ sx: {
	color,
	...sxProp
} }));
var Octicon = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => {
	return /* @__PURE__ */ jsx(StyledOcticon, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
var StyledTooltip = Ye(Tooltip$1).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "Tooltip__StyledTooltip",
	componentId: "sc-145jcib-0"
})(["", ""], sx);
var Tooltip = /* @__PURE__ */ forwardRef(function Tooltip({ as, ...props }, ref) {
	return /* @__PURE__ */ jsx(StyledTooltip, {
		...props,
		...as ? { forwardedAs: as } : {},
		ref
	});
});
Tooltip.alignments = Tooltip$1.alignments;
Tooltip.directions = Tooltip$1.directions;
Tooltip.__SLOT__ = Tooltip$1.__SLOT__;
var ActionListImpl = /* @__PURE__ */ forwardRef(function ActionList(props, ref) {
	return /* @__PURE__ */ jsx(Box, {
		as: ActionList$1,
		ref,
		...props
	});
});
var StyledActionListItem = Ye(ActionList$1.Item).withConfig({ shouldForwardProp: (prop) => prop !== "sx" }).withConfig({
	displayName: "ActionList__StyledActionListItem",
	componentId: "sc-1ugfmds-0"
})(["", ""], sx);
var ActionListItem = /* @__PURE__ */ forwardRef(({ as, ...props }, ref) => /* @__PURE__ */ jsx(StyledActionListItem, {
	...props,
	...as ? { forwardedAs: as } : {},
	ref
}));
function ActionListGroup(props) {
	return /* @__PURE__ */ jsx(Box, {
		as: ActionList$1.Group,
		...props
	});
}
function ActionListDivider(props) {
	return /* @__PURE__ */ jsx(Box, {
		as: ActionList$1.Divider,
		...props
	});
}
Object.assign(ActionListImpl, {
	Item: ActionListItem,
	Group: ActionListGroup,
	Divider: ActionListDivider
});
export { Octicon as t };
