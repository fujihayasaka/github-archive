import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
var MAX_ENTRIES = 10;
var buffer = new Array(MAX_ENTRIES).fill(null);
var currentIndex = 0;
function addRequestId(id) {
	buffer[currentIndex] = id;
	currentIndex = (currentIndex + 1) % MAX_ENTRIES;
}
function getRecentRequestIds() {
	const result = [];
	for (let i = 0; i < MAX_ENTRIES; i++) {
		const id = buffer[(currentIndex - 1 - i + MAX_ENTRIES) % MAX_ENTRIES];
		if (id) result.push(id);
	}
	return result;
}
var TraceDataKey = "GraphQLTraces";
var TraceDataRefreshCallbackKey = "GraphQLTracingRefresh";
var disabledClusters = getDisabledClusters();
function runsOnClient() {
	return typeof window !== "undefined";
}
function reportTraceData(json) {
	if (!runsOnClient()) return;
	if (!isTracingEnabled()) return;
	if (!json) return;
	const rootWindowContent = window;
	if (rootWindowContent && !rootWindowContent["GraphQLTraces"]) rootWindowContent[TraceDataKey] = [];
	if (rootWindowContent && json["__trace"]) {
		rootWindowContent[TraceDataKey].push(json["__trace"]);
		if (typeof rootWindowContent["GraphQLTracingRefresh"] === "function") rootWindowContent[TraceDataRefreshCallbackKey]();
	}
}
function isTracingEnabled() {
	if (!runsOnClient()) return false;
	const rootWindowContent = window;
	return new URLSearchParams(window.location.search).get("_tracing") === "true" || rootWindowContent && rootWindowContent["GraphQLTraces"] !== void 0;
}
function clustersDisabled() {
	return disabledClusters.length > 0;
}
function getInsightsUrl(url) {
	if (!runsOnClient()) return url;
	if (!isTracingEnabled() && !clustersDisabled()) return url;
	const urlObject = new URL(url, window.location.origin);
	if (isTracingEnabled()) urlObject.searchParams.set("_tracing", "true");
	if (clustersDisabled()) urlObject.searchParams.set("disable_clusters", disabledClusters.join(","));
	return urlObject.pathname + urlObject.search;
}
function getDisabledClusters() {
	if (!runsOnClient()) return [];
	return decodeURIComponent(new URLSearchParams(window.location.search).get("disable_clusters") || "").split(",").filter((c) => c !== "");
}
/**
* A Fetch function which will automatically add the correct headers for
* making requests to GitHub application servers as long as the associated controller methods allow it.
* Track down the associated controller method and confirm the controller includes
* ApplicationController::VerifiedFetchDependency as well as `allow_verified_fetch only:`
* to the relevant controller methods.
*
* ## Example
*
*     const onClick = async () => {
*       const resp = await verifiedFetch('/foo', {method: 'POST'})
*       if (resp.ok) console.log('The response was', await resp.text())
test.
*     }
*/
async function verifiedFetch(path, init = {}) {
	assertRelativePathOrSameOrigin(path);
	const { tracingEnabled, fetchPath } = addStaffMagicParams(path);
	const headers = {
		...init.headers,
		"GitHub-Verified-Fetch": "true",
		...getBaseFetchHeaders()
	};
	const response = await fetch(fetchPath, {
		...init,
		headers
	});
	const requestId = response?.headers?.get("X-Github-Request-Id");
	if (requestId) addRequestId(requestId);
	if (tracingEnabled && response) {
		const clonedResponse = response.clone();
		try {
			const textResponse = await clonedResponse.text();
			reportTraceData(textResponse && JSON.parse(textResponse));
		} catch {}
	}
	return response;
}
/**
* This function ensures that the `_features` and `_tracing` search-params are _always_ sent to the server
* if they are present in the browser's address bar. This ensures they aren't accidentally trimmed in feature code.
*/
function addStaffMagicParams(path) {
	const url = new URL(path, window.location.href);
	const locationUrl = new URL(window.location.href, window.location.origin);
	const featuresParam = locationUrl.searchParams.get("_features");
	if (featuresParam && !url.searchParams.has("_features")) url.searchParams.set("_features", featuresParam);
	const tracingParam = locationUrl.searchParams.get("_tracing");
	if (tracingParam && !url.searchParams.has("_tracing")) url.searchParams.set("_tracing", tracingParam);
	return {
		tracingEnabled: !!tracingParam,
		fetchPath: path.startsWith(window.location.origin) ? url.href : `${url.pathname}${url.search}`
	};
}
function assertRelativePathOrSameOrigin(path) {
	if (new URL(path, window.location.origin).origin !== window.location.origin) throw new Error("Can not make cross-origin requests from verifiedFetch");
}
/**
* A Fetch function which will automatically add the correct headers for
* making JSON requests
*
* Will also `JSON.stringify` the request body if provided.

* ## Example
*
*     const onClick = async () => {
*       const resp = await verifiedFetchJSON('/foo', {body: {foo: 'bar'}, method: 'POST'})
*       if (resp.ok) console.log('The response was', await resp.json())
*     }
*/
function verifiedFetchJSON(path, init) {
	const headers = {
		...init?.headers ?? {},
		Accept: "application/json",
		"Content-Type": "application/json"
	};
	const body = init?.body ? JSON.stringify(init.body) : void 0;
	return verifiedFetch(path, {
		...init,
		body,
		headers
	});
}
/**
* A Fetch function which will automatically add the GitHub-Is-React header for
* making JSON requests. It will in turn call verifiedFetchJSON.
*
* Using this in React components to fetch data enables us to track these
* requests in Datadog in the request.dist.referrer metric.
*/
function reactFetch(path, init = {}) {
	const headers = {
		...init.headers,
		"GitHub-Is-React": "true"
	};
	return verifiedFetch(path, {
		...init,
		headers
	});
}
/**
* A Fetch function which will automatically add the GitHub-Is-React header for
* making JSON requests. It will in turn call verifiedFetchJSON.
*
* Using this in React components to fetch data enables us to track these
* requests in Datadog in the request.dist.referrer metric.
*/
function reactFetchJSON(path, init) {
	const headers = {
		...init?.headers ?? {},
		"GitHub-Is-React": "true"
	};
	return verifiedFetchJSON(path, {
		...init,
		headers
	});
}
export { reportTraceData as a, reactFetchJSON as i, getRecentRequestIds as n, verifiedFetch as o, reactFetch as r, verifiedFetchJSON as s, getInsightsUrl as t };
