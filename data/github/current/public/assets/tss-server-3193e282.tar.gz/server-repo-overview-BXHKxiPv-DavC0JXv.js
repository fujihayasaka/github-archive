performance.mark("js-parse-end:server-repo-overview-BXHKxiPv-DavC0JXv.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as LatestCommitProvider } from "./server-LatestCommitContext-D4oQqyj7-DHpYqCjL.js";
import { t as codeViewRepoRoute } from "./server-code-view-repo-route-BsNI4mmi-Czvdqq85.js";
import { t as SharedPageLayout } from "./server-SharedPageLayout-CICF2ah5-T37hahkR.js";
import { c as RecentlyTouchedBranchesProvider, i as CommitInfoProvider, l as ReposOverviewPage, t as BranchAndTagCountProvider } from "./server-ReposOverviewPage-D24MR2RX-CZxxJG-r.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:repo-overview-BXHKxiPv.js");
function CodeViewRepoEntrypoint() {
	const $ = c(11);
	const { data: payload } = useRouteQuery(codeViewRepoRoute, "mainQuery");
	const { data: latestCommit, error: latestCommitError, isLoading: latestCommitLoading } = useRouteQuery(codeViewRepoRoute, "latestCommit");
	const { data: commitInfo, error: commitInfoError, isLoading: commitInfoLoading } = useRouteQuery(codeViewRepoRoute, "treeCommitInfo");
	const { data: recentlyTouchedBranches, refetch: refetchBranches } = useRouteQuery(codeViewRepoRoute, "recentlyTouchedBranches");
	const { data: branchAndTagCount } = useRouteQuery(codeViewRepoRoute, "branchAndTagCount");
	let t0;
	if ($[0] !== branchAndTagCount || $[1] !== commitInfo || $[2] !== commitInfoError || $[3] !== commitInfoLoading || $[4] !== latestCommit || $[5] !== latestCommitError || $[6] !== latestCommitLoading || $[7] !== payload || $[8] !== recentlyTouchedBranches || $[9] !== refetchBranches) {
		t0 = jsx(BranchAndTagCountProvider, {
			count: branchAndTagCount,
			children: jsx(RecentlyTouchedBranchesProvider, {
				...recentlyTouchedBranches,
				refetch: refetchBranches,
				children: jsx(SharedPageLayout, {
					narrow: false,
					children: jsx(CommitInfoProvider, {
						commitInfo,
						error: !!commitInfoError,
						loading: commitInfoLoading,
						children: jsx(LatestCommitProvider, {
							latestCommit,
							error: latestCommitError,
							isLoading: latestCommitLoading,
							children: jsx(ReposOverviewPage, {
								payload,
								isTree: false
							})
						})
					})
				})
			})
		});
		$[0] = branchAndTagCount;
		$[1] = commitInfo;
		$[2] = commitInfoError;
		$[3] = commitInfoLoading;
		$[4] = latestCommit;
		$[5] = latestCommitError;
		$[6] = latestCommitLoading;
		$[7] = payload;
		$[8] = recentlyTouchedBranches;
		$[9] = refetchBranches;
		$[10] = t0;
	} else t0 = $[10];
	return t0;
}
CodeViewRepoEntrypoint.displayName = "CodeViewRepoEntrypoint";
var SplitComponent = CodeViewRepoEntrypoint;
export { SplitComponent as component };
