performance.mark("js-parse-end:server-AccountSwitchDialog-P_LjKO5G-dcHzUNE4.js");
import { n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { i as isActiveAccount, n as ErrorDialog, r as StashedAccountItem } from "./server-ErrorDialog-DGbSeS_Q-C-O7tuGz.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:AccountSwitchDialog-P_LjKO5G.js");
var AccountSwitchDialog_module_default = {
	accountName: "AccountSwitchDialog-module_d1SgRG_accountName",
	dialogHeader: "AccountSwitchDialog-module_d1SgRG_dialogHeader",
	divider: "AccountSwitchDialog-module_d1SgRG_divider",
	popover: "AccountSwitchDialog-module_d1SgRG_popover",
	popoverContent: "AccountSwitchDialog-module_d1SgRG_popoverContent"
};
function AccountSwitchDialog(t0) {
	const $ = c(9);
	const { show, ownerLogin, stashedAccounts, switchAccountPath } = t0;
	const [error, setError] = useState(false);
	if (!show || !stashedAccounts?.length || !switchAccountPath) return null;
	if (error) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = () => setError(false);
			$[0] = t1;
		} else t1 = $[0];
		let t2;
		if ($[1] !== error) {
			t2 = jsx(ErrorDialog, {
				...error,
				onClose: t1
			});
			$[1] = error;
			$[2] = t2;
		} else t2 = $[2];
		return t2;
	}
	let t1;
	if ($[3] !== ownerLogin || $[4] !== stashedAccounts || $[5] !== switchAccountPath) {
		let t2;
		if ($[7] !== switchAccountPath) {
			t2 = (account) => isActiveAccount(account) ? jsx(StashedAccountItem, {
				switchAccountPath,
				account,
				setError
			}, account.login) : null;
			$[7] = switchAccountPath;
			$[8] = t2;
		} else t2 = $[8];
		t1 = jsx(Popover_default, {
			className: AccountSwitchDialog_module_default.popover,
			open: true,
			children: jsx(Popover_default.Content, {
				className: AccountSwitchDialog_module_default.popoverContent,
				children: jsxs(ActionList, { children: [
					jsxs(ActionList.Heading, {
						className: AccountSwitchDialog_module_default.dialogHeader,
						as: "h5",
						children: [
							jsx("span", { children: "Signed in as " }),
							" ",
							jsxs("span", {
								className: AccountSwitchDialog_module_default.accountName,
								children: ["@", ownerLogin]
							})
						]
					}),
					jsx(ActionList.Divider, { className: AccountSwitchDialog_module_default.divider }),
					jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, {
						as: "h6",
						children: "Switch to another account"
					}), stashedAccounts.map(t2)] })
				] })
			})
		});
		$[3] = ownerLogin;
		$[4] = stashedAccounts;
		$[5] = switchAccountPath;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
AccountSwitchDialog.displayName = "AccountSwitchDialog";
export { AccountSwitchDialog };
