import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
var WithShimmerEffect_module_default = {
	fadeIn: "WithShimmerEffect-module_fRS1ua_fadeIn",
	shimmerText: "WithShimmerEffect-module_fRS1ua_shimmerText"
};
var WithShimmerEffect = ({ children, className, innerClassName }) => {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(WithShimmerEffect_module_default.fadeIn, className),
		children: /* @__PURE__ */ jsx("div", {
			className: clsx(WithShimmerEffect_module_default.shimmerText, innerClassName),
			children
		})
	});
};
WithShimmerEffect.displayName = "WithShimmerEffect";
export { WithShimmerEffect as t };
