import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { t as hotkey_exports } from "./server-hotkey-CjmZAe2y-CaimUUmF.js";
/** Returns false if a user has explicitly disabled character key shortcuts. */
var areCharacterKeyShortcutsEnabled = () => {
	if (typeof document === "undefined") return false;
	const keyboardShortcutsPreference = document.querySelector("meta[name=keyboard-shortcuts-preference]");
	if (keyboardShortcutsPreference) return keyboardShortcutsPreference.content === "all";
	return true;
};
/**
* Character-key shortcuts are implemented only with lowercase characters ("g", "g f"), uppercase characters ("Shift+A", "a"),
* symbols ("Alt+g"), and punctuation ("?", "!", "/").
*
* Returns true if string is NOT what we define as a character key shortcut.
*/
var isNonCharacterKeyShortcut = (hotkey) => {
	return /Enter|Arrow|Escape|Meta|Control|Mod|Esc|Tab/.test(hotkey) || !isMacOS() && hotkey.includes("Alt") && hotkey.includes("Shift");
};
var nonEditableInputTypes = new Set([
	"button",
	"checkbox",
	"color",
	"file",
	"hidden",
	"image",
	"radio",
	"range",
	"reset",
	"submit"
]);
/**
* Returns true if `element` is editable - that is, if it can be focused and typed in like an input or textarea.
*/
function isEditableElement(target) {
	if (!(target instanceof HTMLElement)) return false;
	const name = target.nodeName.toLowerCase();
	const type = target.getAttribute("type")?.toLowerCase() ?? "text";
	const isReadonly = target.ariaReadOnly === "true" || target.getAttribute("aria-readonly") === "true" || target.getAttribute("readonly") !== null;
	return (name === "select" || name === "textarea" || name === "input" && !nonEditableInputTypes.has(type) || target.isContentEditable) && !isReadonly;
}
/**
* Returns false if a user settings has character key shortcut disabled and keyboard event corresponds to a character
* key shortcut. Character key shortcuts are never enabled on editable form inputs.
*/
var isShortcutAllowed = (event) => {
	const hotkey = (0, hotkey_exports.eventToHotkeyString)(event);
	const allowCharacterKeyShortcuts = areCharacterKeyShortcutsEnabled() && !isEditableElement(event.target);
	return isNonCharacterKeyShortcut(hotkey) || allowCharacterKeyShortcuts;
};
export { isEditableElement as n, isShortcutAllowed as r, areCharacterKeyShortcutsEnabled as t };
