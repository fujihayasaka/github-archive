import { n as __exportAll, r as __reExport } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import * as import__github_hotkey from "@github/hotkey";
var hotkey_exports = /* @__PURE__ */ __exportAll({ splitHotkeyString: () => splitHotkeyString });
__reExport(hotkey_exports, import__github_hotkey);
var chordOrKeyRegex = /(?:^|,)((?:[^,]|,(?=\+| |$))*(?:,(?=,))?)/g;
function splitHotkeyString(hotkey) {
	return Array.from(hotkey.matchAll(chordOrKeyRegex)).map(([, chord]) => chord);
}
export { splitHotkeyString as n, hotkey_exports as t };
