performance.mark("js-parse-end:server-file-tree-layout-BYKg68WU-CJiUUAeo.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:file-tree-layout-BYKg68WU.js");
var codeViewFileTreeLayoutServerFn_createServerFn_handler = createServerRpc({
	id: "694f3736e0b5f75f6cc2581eab05ece8a1ffe21b38dcd1f6a5e06fb6915e3cfe",
	name: "codeViewFileTreeLayoutServerFn",
	filename: "src/routes/code-view/file-tree-layout.tsx"
}, (opts) => codeViewFileTreeLayoutServerFn.__executeServer(opts));
var codeViewFileTreeLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewFileTreeLayoutServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewFileTreeLayoutRoute");
});
export { codeViewFileTreeLayoutServerFn_createServerFn_handler };
