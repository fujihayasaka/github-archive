import { t as SplitPageLayout } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { i as useCodeViewOptions } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import React from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var SharedPageLayout_module_default = { content: "SharedPageLayout-module_N4RGyW_content" };
function SharedPageLayout(t0) {
	const $ = c(5);
	const { sidebar, children, narrow } = t0;
	const { codeCenterOption } = useCodeViewOptions();
	let t1;
	if ($[0] !== children || $[1] !== codeCenterOption.enabled || $[2] !== narrow || $[3] !== sidebar) {
		t1 = jsxs(SplitPageLayout, { children: [sidebar, jsx(SplitPageLayout.Content, {
			as: "div",
			padding: "none",
			width: codeCenterOption.enabled ? "xlarge" : "full",
			hidden: { narrow },
			children: jsx("div", {
				className: SharedPageLayout_module_default.content,
				"data-selector": "repos-split-pane-content",
				tabIndex: 0,
				children
			})
		})] });
		$[0] = children;
		$[1] = codeCenterOption.enabled;
		$[2] = narrow;
		$[3] = sidebar;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
SharedPageLayout.displayName = "SharedPageLayout";
export { SharedPageLayout as t };
