import { i as queryOptions$1 } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { interpolatePath } from "@tanstack/react-router";
/**
* Converts a React Router style path (`:param`, `*`) to TanStack Router style (`$param`, `$`).
* Data Router routes use React Router conventions, but we want to use TanStack's interpolatePath.
* @internal Exported for testing
*/
function convertToTanStackPath(reactRouterPath) {
	return reactRouterPath.replace(/:([^/]+)/g, "$$$1").replace(/\*$/g, "$");
}
/**
* Generates a pathname from a route path pattern and params.
* Handles React Router style paths (`:param`, `*`) by converting to TanStack format.
* @internal Exported for testing
*/
function generatePathFromRoute(routePath, params) {
	const { interpolatedPath } = interpolatePath({
		path: convertToTanStackPath(routePath),
		params
	});
	return interpolatedPath;
}
/**
* Default queryDeps function for routes without dependencies.
* Returns empty deps so the query key is stable.
*/
var defaultQueryDeps = () => ({});
/**
* Normalizes route params passed to Data Router queryDeps for compatibility.
* TanStack Router provides splat under `_splat`, while some existing queryDeps
* still read React Router's `*` key. We preserve original params and add `*`
* only when it is missing.
*/
function normalizeParamsForQueryDeps(params) {
	if ("*" in params || !("_splat" in params)) return params;
	return {
		...params,
		"*": params._splat
	};
}
/**
* Query deps are used in two places with different constraints:
* - Query keys should keep URLSearchParams so they stay aligned with route queryDeps behavior.
* - Server function input must be serializable plain data.
*
* This normalizes searchParams only for queryFn input, while preserving the original deps for query keys.
*/
function serializeDepsForServerFn(deps) {
	if (!(deps.searchParams instanceof URLSearchParams)) return deps;
	return {
		...deps,
		searchParams: Object.fromEntries(deps.searchParams.entries())
	};
}
/**
* Registers one or more queries with TSS-specific configuration on a Data Router route.
* This mutates the route object to attach the `tss` config for each query, allowing
* useRouteQuery/useSuspenseRouteQuery to access the query options at runtime.
*
* The route's `queryDeps` function (if defined) is used to compute dependencies from
* the current location (pathname, params, searchParams). This ensures cache key consistency
* between the loader and the useRouteQuery shim.
*
* Returns a loader that can be spread into createFileRoute.
*
* @param route - The route object to attach the queries to (must have a `queries` object)
* @param queryConfigs - An object mapping query names to their TSS configurations
* @returns Route config with loader to spread into createFileRoute
*
* @example
* ```ts
* // With explicit params and search params types:
* const uiServiceRouteConfig = registerRouteWithUIService<
*   {owner: string; repo: string},  // TParams
*   {q?: string; page?: string}     // TSearchParams
* >(myRoute, {
*   mainQuery: {
*     queryFn: myServerFn,
*     mode: 'blocking',
*   },
* })
*
* // With just params (search defaults to {}):
* const uiServiceRouteConfig = registerRouteWithUIService<{owner: string; repo: string}>(myRoute, {...})
*
* // With just search params (params defaults to {}):
* const uiServiceRouteConfig = registerRouteWithUIService<{}, {q?: string; page?: string}>(myRoute, {...})
*
* // Without params or search (uses defaults):
* const uiServiceRouteConfig = registerRouteWithUIService(reposFinderPageFutureRoute, {
*   mainQuery: {
*     queryFn: reposIndexServerFn,
*     mode: 'streaming',
*   },
* })
*
* export const Route = createFileRoute('/repos')({
*   component: MyComponent,
*   ...uiServiceRouteConfig, // spreads loader, beforeLoad, validateSearch
* })
* ```
*/
function registerRouteWithUIService(route, queryConfigs, routeOptions) {
	const queryNames = Object.keys(queryConfigs);
	const queryOptionsFactories = [];
	for (const queryName of queryNames) {
		const config = queryConfigs[queryName];
		if (!config) continue;
		const { queryFn: configQueryFn, mode } = config;
		const query = route.queries[queryName];
		if (!query) continue;
		const queryDeps = query.queryDeps ?? defaultQueryDeps;
		const getQueryOptions = (params, searchStr) => {
			const deps = queryDeps({
				pathname: generatePathFromRoute(route.path, params),
				params: normalizeParamsForQueryDeps(params),
				searchParams: new URLSearchParams(searchStr)
			});
			const opts = {
				queryKey: query.makeQueryKey(deps),
				queryFn: () => configQueryFn({ data: serializeDepsForServerFn(deps) })
			};
			if (config.select) opts.select = config.select;
			else if (queryName === "mainQuery") opts.select = (data) => data.payload;
			return queryOptions$1(opts);
		};
		queryOptionsFactories.push({
			queryName,
			getQueryOptions,
			mode
		});
		Object.assign(query, { tss: {
			mode,
			options: ({ searchStr, params }) => getQueryOptions(params, searchStr)
		} });
	}
	return {
		validateSearch: (search) => search,
		loaderDeps: ({ search }) => search,
		beforeLoad: ({ params }) => ({
			dataRouterId: route.id,
			...routeOptions?.beforeLoad?.({ params })
		}),
		staticData: {
			queryRoute: route,
			...routeOptions?.staticData ?? {}
		},
		loader: async ({ context, params, location }) => {
			const blockingPromises = [];
			const queries = {};
			for (const { queryName, getQueryOptions, mode } of queryOptionsFactories) {
				const options = getQueryOptions(params, location.searchStr);
				queries[queryName] = { queryConfig: { queryKey: options.queryKey } };
				if (mode === "streaming") context.queryClient.prefetchQuery(options);
				else blockingPromises.push(context.queryClient.ensureQueryData({
					...options,
					revalidateIfStale: true
				}));
			}
			if (blockingPromises.length > 0) await Promise.all(blockingPromises);
			return {
				searchStr: location.searchStr,
				queries
			};
		}
	};
}
/**
* Asserts that a route has TSS config registered for the given query name.
* Throws a descriptive error if the config is missing.
*
* @param route - The route object to check
* @param queryName - The name of the query to look for
*/
function assertHasUIServiceConfig(route, queryName) {
	const routeId = route.id;
	if (!route.queries) throw new Error(`No queries registered for route "${routeId}". Did you forget to call registerRouteWithUIService() for this route?`);
	if (!route.queries[queryName]?.tss) {
		const queries = route.queries;
		const registeredQueries = Object.keys(queries).filter((q) => queries[q]?.tss).join(", ") || "none";
		throw new Error(`No TSS config found for query "${queryName}" on route "${routeId}". Registered queries: ${registeredQueries}. Did you forget to call registerRouteWithUIService() with the correct query name?`);
	}
}
export { registerRouteWithUIService as n, assertHasUIServiceConfig as t };
