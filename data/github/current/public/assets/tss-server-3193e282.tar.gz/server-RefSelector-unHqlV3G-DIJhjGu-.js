import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ht as GitBranchIcon, Mi as XIcon, O as CheckIcon, Qt as Heading$2, an as IconButton, hi as TriangleDownIcon, ii as TagIcon, n as ActionList, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { f as sendStats, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { Pt as repositoryPath, f as checkTagNameExistsPath, p as checkTagStatePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { t as TabNav_default } from "./server-TabNav-ChmPEmaf-BGcvB88p.js";
import React, { startTransition, useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { createPortal } from "react-dom";
import { c } from "react/compiler-runtime";
import { useVirtualizer } from "@tanstack/react-virtual";
var CheckTagNameDialog_module_default = { DialogFooterButtons: "CheckTagNameDialog-module_QIzC0q_DialogFooterButtons" };
function CheckTagNameDialog(t0) {
	const $ = c(5);
	const { isOpen, onDismiss, onConfirm } = t0;
	const { isBrowser } = useRuntimeEnvironment();
	const body = isBrowser ? ssrSafeDocument?.body ?? null : null;
	let t1;
	if ($[0] !== body || $[1] !== isOpen || $[2] !== onConfirm || $[3] !== onDismiss) {
		t1 = body ? createPortal(jsxs(Dialog_default, {
			isOpen,
			onDismiss,
			children: [jsx(Dialog_default.Header, { children: "Create branch" }), jsxs("div", {
				className: "tmp-p-3",
				children: [jsx("span", { children: "A tag already exists with the provided branch name. Many Git commands accept both tag and branch names, so creating this branch may cause unexpected behavior. Are you sure you want to create this branch?" }), jsxs("div", {
					className: CheckTagNameDialog_module_default.DialogFooterButtons,
					children: [jsx(ButtonComponent, {
						onClick: onDismiss,
						children: "Cancel"
					}), jsx(ButtonComponent, {
						variant: "danger",
						onClick: onConfirm,
						className: "ml-2",
						children: "Create"
					})]
				})]
			})]
		}), document.body) : null;
		$[0] = body;
		$[1] = isOpen;
		$[2] = onConfirm;
		$[3] = onDismiss;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
CheckTagNameDialog.displayName = "CheckTagNameDialog";
function getValidationMessage(state, tagName) {
	switch (state) {
		case "branch_exists":
		case "pending":
		case "valid": return `${tagName} will be created on publish`;
		case "duplicate": return `${tagName} is used by another release`;
		case "empty": return "Tag cannot be blank";
		case "immutable": return `${tagName} is used by an immutable release and cannot be reused`;
		case "invalid": return "Contains invalid characters. Use safe special characters ., -, or _ instead";
		default: return "";
	}
}
function useTagValidation(tagValidationUrl) {
	const [state, setState] = useState("empty");
	const [message, setMessage] = useState("");
	const latestTagRef = useRef("");
	const validateTag = useCallback(async (tag) => {
		latestTagRef.current = tag;
		if (!tag) {
			setState("empty");
			setMessage("Tag cannot be blank");
			return;
		}
		setState("loading");
		const validationUrl = new URL(tagValidationUrl, window.location.origin);
		const params = new URLSearchParams(validationUrl.search.slice(1));
		params.append("tag_name", tag);
		validationUrl.search = params.toString();
		try {
			const response = await verifiedFetch(validationUrl.toString(), { headers: { Accept: "application/json" } });
			if (tag !== latestTagRef.current) return;
			if (!response.ok) {
				setState("invalid");
				setMessage("Unable to validate tag name. Please try again.");
				return;
			}
			const tagState = (await response.json()).status;
			setState(tagState || "empty");
			setMessage(getValidationMessage(tagState || "empty", tag));
		} catch {
			if (tag !== latestTagRef.current) return;
			setState("invalid");
			setMessage("Unable to validate tag name. Please try again.");
		}
	}, [tagValidationUrl]);
	return {
		state,
		message,
		validateTag: useMemo(() => debounce(validateTag, 500), [validateTag])
	};
}
var CreateTagDialog_module_default = { Dialog: "CreateTagDialog-module_QAfKtq_Dialog" };
function CreateTagDialog({ onDismiss, onCreate, initialTagName, tagValidationUrl }) {
	const [tagName, setTagName] = useState(initialTagName);
	const hasInteracted = useRef(false);
	const inputRef = useRef(null);
	const trimmedTagName = tagName?.trim();
	const { state, message, validateTag } = useTagValidation(tagValidationUrl);
	const isLoading = state === "loading";
	const isEmptyAfterInput = state === "empty" && hasInteracted.current;
	const isValid = state === "valid" || state === "pending" || state === "branch_exists";
	const isInvalid = state === "invalid" || state === "immutable" || state === "duplicate" || isEmptyAfterInput;
	const showValidation = !isLoading && message && (isValid || isInvalid);
	useEffect(() => {
		if (initialTagName?.trim()) validateTag(initialTagName.trim());
	}, []);
	const handleChange = useCallback((e) => {
		const newValue = e.target.value;
		setTagName(newValue);
		hasInteracted.current = true;
		validateTag(newValue.trim());
	}, [validateTag]);
	const handleCreate = useCallback(() => {
		if (trimmedTagName) {
			onCreate(trimmedTagName);
			onDismiss();
		}
	}, [
		trimmedTagName,
		onCreate,
		onDismiss
	]);
	const handleSubmit = useCallback((e) => {
		e.preventDefault();
		if (!isLoading && !isInvalid) handleCreate();
	}, [
		handleCreate,
		isLoading,
		isInvalid
	]);
	return /* @__PURE__ */ jsx(Dialog, {
		onClose: onDismiss,
		title: "Create new tag",
		width: "medium",
		className: CreateTagDialog_module_default.Dialog,
		initialFocusRef: inputRef,
		footerButtons: [{
			buttonType: "default",
			content: "Cancel",
			onClick: onDismiss
		}, {
			buttonType: "primary",
			content: "Create",
			onClick: handleCreate,
			disabled: isLoading || isInvalid,
			type: "submit"
		}],
		children: /* @__PURE__ */ jsx("form", {
			onSubmit: handleSubmit,
			children: /* @__PURE__ */ jsxs(FormControl$1, {
				required: true,
				children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Tag" }),
					/* @__PURE__ */ jsx(TextInput$1, {
						ref: inputRef,
						value: tagName,
						onChange: handleChange,
						"aria-label": "Tag name",
						block: true,
						loading: isLoading
					}),
					showValidation && /* @__PURE__ */ jsx(FormControl$1.Validation, {
						variant: isInvalid ? "error" : "success",
						children: message
					}),
					state === "branch_exists" && /* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Creating a tag with the same name as a branch can cause ambiguity when selecting refs" })
				]
			})
		})
	});
}
CreateTagDialog.displayName = "CreateTagDialog";
async function checkTagExists(path, newRefName) {
	const body = new FormData();
	body.set("value", newRefName);
	const res = await verifiedFetch(path, {
		method: "POST",
		body,
		headers: { Accept: "application/json" }
	});
	if (!res.ok) return false;
	return !!await res.text();
}
async function createBranch(path, newRefName, baseRef) {
	const body = new FormData();
	body.set("name", newRefName);
	body.set("branch", baseRef);
	const res = await verifiedFetch(path, {
		method: "POST",
		body,
		headers: { Accept: "application/json" }
	});
	if (res.ok) return {
		success: true,
		name: (await res.json()).name
	};
	else try {
		const { error } = await res.json();
		if (error) return {
			success: false,
			error
		};
		throw new Error("Unknown response from create branch API");
	} catch {
		return {
			success: false,
			error: "Something went wrong."
		};
	}
}
var RefSelectorAnchoredOverlay_module_default = {
	RefSelectorBtnTextContainer: "RefSelectorAnchoredOverlay-module_zwGJlW_RefSelectorBtnTextContainer",
	RefSelectorOverlayBtn: "RefSelectorAnchoredOverlay-module_zwGJlW_RefSelectorOverlayBtn",
	RefSelectorOverlayContainer: "RefSelectorAnchoredOverlay-module_zwGJlW_RefSelectorOverlayContainer",
	RefSelectorOverlayHeader: "RefSelectorAnchoredOverlay-module_zwGJlW_RefSelectorOverlayHeader",
	RefSelectorText: "RefSelectorAnchoredOverlay-module_zwGJlW_RefSelectorText"
};
function RefSelectorAnchoredOverlay(props) {
	const $ = c(58);
	const { ariaDescribedBy, ariaLabelledBy, ariaLabel, hotKey, onOpenChange, size, displayCommitish, variant, refType, children, preventClosing, inputRef, overlayOpen, onOverlayChange, focusTrapEnabled: t0, buttonClassName, buttonText, persistButtonText: t1, buttonPrefix, showIcon: t2, allowResizing, useFocusZone, disabled, anchoredOverlayProps, renderAnchor } = props;
	const focusTrapEnabled = t0 === void 0 ? true : t0;
	const persistButtonText = t1 === void 0 ? true : t1;
	const showIcon = t2 === void 0 ? true : t2;
	const baseExtraIdEnding = useId();
	const buttonId = `ref-picker${`-${props.idEnding || baseExtraIdEnding}`}`;
	let t3;
	if ($[0] !== onOpenChange || $[1] !== onOverlayChange) {
		t3 = (open) => {
			onOverlayChange(open);
			onOpenChange?.(open);
		};
		$[0] = onOpenChange;
		$[1] = onOverlayChange;
		$[2] = t3;
	} else t3 = $[2];
	const onOverlayOpenChange = t3;
	let t4;
	bb0: {
		if (focusTrapEnabled) {
			let t5;
			if ($[3] !== inputRef) {
				t5 = { initialFocusRef: inputRef };
				$[3] = inputRef;
				$[4] = t5;
			} else t5 = $[4];
			t4 = t5;
			break bb0;
		}
		let t5;
		if ($[5] !== inputRef) {
			t5 = {
				initialFocusRef: inputRef,
				disabled: true
			};
			$[5] = inputRef;
			$[6] = t5;
		} else t5 = $[6];
		t4 = t5;
	}
	const focusTrapSettings = t4;
	let t5;
	if ($[7] !== buttonPrefix || $[8] !== buttonText || $[9] !== displayCommitish || $[10] !== persistButtonText) {
		t5 = () => {
			const nonEmptyDisplayCommitish = displayCommitish.length > 0;
			const text = buttonText && persistButtonText ? buttonText : nonEmptyDisplayCommitish ? displayCommitish : buttonText || "";
			return buttonPrefix ? jsxs(Fragment$1, { children: [jsxs("span", {
				className: "fgColor-muted",
				children: [buttonPrefix, ":"]
			}), jsxs("span", { children: [" ", text] })] }) : text;
		};
		$[7] = buttonPrefix;
		$[8] = buttonText;
		$[9] = displayCommitish;
		$[10] = persistButtonText;
		$[11] = t5;
	} else t5 = $[11];
	const getButtonText = t5;
	const t6 = refType === "branch" ? "Select a branch" : "Select a tag";
	let t7;
	if ($[12] !== allowResizing || $[13] !== anchoredOverlayProps || $[14] !== ariaDescribedBy || $[15] !== ariaLabel || $[16] !== ariaLabelledBy || $[17] !== buttonClassName || $[18] !== buttonId || $[19] !== children || $[20] !== disabled || $[21] !== displayCommitish || $[22] !== focusTrapSettings || $[23] !== getButtonText || $[24] !== hotKey || $[25] !== onOverlayOpenChange || $[26] !== overlayOpen || $[27] !== preventClosing || $[28] !== refType || $[29] !== renderAnchor || $[30] !== showIcon || $[31] !== size || $[32] !== t6 || $[33] !== useFocusZone || $[34] !== variant) {
		let t8;
		if ($[36] !== onOverlayOpenChange) {
			t8 = () => onOverlayOpenChange(true);
			$[36] = onOverlayOpenChange;
			$[37] = t8;
		} else t8 = $[37];
		let t9;
		if ($[38] !== onOverlayOpenChange || $[39] !== preventClosing) {
			t9 = () => !preventClosing && onOverlayOpenChange(false);
			$[38] = onOverlayOpenChange;
			$[39] = preventClosing;
			$[40] = t9;
		} else t9 = $[40];
		let t10;
		if ($[41] !== allowResizing || $[42] !== ariaDescribedBy || $[43] !== ariaLabel || $[44] !== ariaLabelledBy || $[45] !== buttonClassName || $[46] !== buttonId || $[47] !== disabled || $[48] !== displayCommitish || $[49] !== getButtonText || $[50] !== hotKey || $[51] !== onOverlayOpenChange || $[52] !== refType || $[53] !== renderAnchor || $[54] !== showIcon || $[55] !== size || $[56] !== variant) {
			t10 = (anchorProps) => {
				if (renderAnchor) return renderAnchor({
					...anchorProps,
					"aria-labelledby": ariaLabelledBy,
					disabled
				});
				return jsxs(Fragment$1, { children: [jsx(ButtonComponent, {
					...anchorProps,
					"data-hotkey": hotKey,
					disabled,
					size,
					variant,
					style: { minWidth: allowResizing ? 0 : void 0 },
					trailingVisual: TriangleDownIcon,
					"aria-describedby": ariaDescribedBy,
					"aria-labelledby": ariaLabelledBy,
					"aria-label": ariaLabelledBy ? void 0 : ariaLabel ?? `${displayCommitish} ${refType}`,
					"data-testid": "anchor-button",
					id: buttonId,
					className: clsx(buttonClassName, RefSelectorAnchoredOverlay_module_default.RefSelectorOverlayBtn),
					"data-icv-name": "Switch branches/tags",
					children: jsxs("div", {
						className: RefSelectorAnchoredOverlay_module_default.RefSelectorOverlayContainer,
						children: [showIcon && jsx("div", {
							className: RefSelectorAnchoredOverlay_module_default.RefSelectorOverlayHeader,
							children: refType === "tag" ? jsx(TagIcon, { size: "small" }) : jsx(GitBranchIcon, { size: "small" })
						}), jsx("div", {
							style: { maxWidth: allowResizing ? void 0 : 125 },
							className: clsx("ref-selector-button-text-container", RefSelectorAnchoredOverlay_module_default.RefSelectorBtnTextContainer),
							children: jsxs("span", {
								className: RefSelectorAnchoredOverlay_module_default.RefSelectorText,
								children: ["\xA0", getButtonText()]
							})
						})]
					})
				}), jsx("button", {
					hidden: true,
					"data-testid": "ref-selector-hotkey-button",
					"data-hotkey": hotKey,
					onClick: () => onOverlayOpenChange(true),
					"data-hotkey-scope": "read-only-cursor-text-area",
					disabled
				})] });
			};
			$[41] = allowResizing;
			$[42] = ariaDescribedBy;
			$[43] = ariaLabel;
			$[44] = ariaLabelledBy;
			$[45] = buttonClassName;
			$[46] = buttonId;
			$[47] = disabled;
			$[48] = displayCommitish;
			$[49] = getButtonText;
			$[50] = hotKey;
			$[51] = onOverlayOpenChange;
			$[52] = refType;
			$[53] = renderAnchor;
			$[54] = showIcon;
			$[55] = size;
			$[56] = variant;
			$[57] = t10;
		} else t10 = $[57];
		t7 = jsx(AnchoredOverlay, {
			open: overlayOpen,
			overlayProps: {
				role: "dialog",
				width: "medium",
				"aria-label": t6
			},
			onOpen: t8,
			onClose: t9,
			renderAnchor: t10,
			focusTrapSettings,
			focusZoneSettings: useFocusZone ? { bindKeys: FocusKeys.ArrowAll | FocusKeys.Tab } : { disabled: true },
			...anchoredOverlayProps,
			children: jsx("div", {
				"data-testid": "overlay-content",
				"aria-labelledby": buttonId,
				id: "selectPanel",
				style: { height: "100%" },
				children
			})
		});
		$[12] = allowResizing;
		$[13] = anchoredOverlayProps;
		$[14] = ariaDescribedBy;
		$[15] = ariaLabel;
		$[16] = ariaLabelledBy;
		$[17] = buttonClassName;
		$[18] = buttonId;
		$[19] = children;
		$[20] = disabled;
		$[21] = displayCommitish;
		$[22] = focusTrapSettings;
		$[23] = getButtonText;
		$[24] = hotKey;
		$[25] = onOverlayOpenChange;
		$[26] = overlayOpen;
		$[27] = preventClosing;
		$[28] = refType;
		$[29] = renderAnchor;
		$[30] = showIcon;
		$[31] = size;
		$[32] = t6;
		$[33] = useFocusZone;
		$[34] = variant;
		$[35] = t7;
	} else t7 = $[35];
	return t7;
}
RefSelectorAnchoredOverlay.displayName = "RefSelectorAnchoredOverlay";
var RefSelectorFooter_module_default = { actionListItem: "RefSelectorFooter-module_5azxLG_actionListItem" };
function RefSelectorFooter({ text, onClick, href, className }) {
	const isLinkItem = !!href;
	const innerContent = /* @__PURE__ */ jsx("div", {
		className,
		children: text
	});
	return isLinkItem ? /* @__PURE__ */ jsx(ActionList.LinkItem, {
		role: "link",
		href,
		onClick: () => onClick?.(),
		className: RefSelectorFooter_module_default.actionListItem,
		children: innerContent
	}) : /* @__PURE__ */ jsx(ActionList.Item, {
		role: "button",
		onSelect: () => onClick?.(),
		className: RefSelectorFooter_module_default.actionListItem,
		children: innerContent
	});
}
RefSelectorFooter.displayName = "RefSelectorFooter";
function FixedSizeVirtualList$1({ items, itemHeight, style, renderItem, makeKey, ariaControls, shouldUseActionList = false, className, containerRole = "none" }) {
	const parentRef = useRef(null);
	const virtualizer = useVirtualizer({
		count: items.length,
		getScrollElement: useCallback(() => parentRef.current, []),
		estimateSize: useCallback(() => itemHeight, [itemHeight])
	});
	return /* @__PURE__ */ jsx(ListContainer, {
		ref: parentRef,
		style,
		virtualizer,
		id: ariaControls,
		shouldUseActionList,
		className,
		children: virtualizer.getVirtualItems().map((virtualRow, index) => /* @__PURE__ */ jsx(ItemContainer, {
			containerRole,
			virtualRow,
			children: renderItem(items[virtualRow.index], index)
		}, makeKey(items[virtualRow.index])))
	});
}
FixedSizeVirtualList$1.displayName = "FixedSizeVirtualList";
function ListContainer({ ref: forwardedRef, children, style, virtualizer, id, shouldUseActionList, className }) {
	return /* @__PURE__ */ jsx("div", {
		ref: forwardedRef,
		style,
		id,
		className,
		children: shouldUseActionList ? /* @__PURE__ */ jsx(ActionList, {
			id,
			role: "menu",
			style: {
				height: virtualizer.getTotalSize(),
				width: "100%",
				position: "relative"
			},
			selectionVariant: "single",
			children
		}) : /* @__PURE__ */ jsx("ul", {
			role: "menu",
			style: {
				height: virtualizer.getTotalSize(),
				width: "100%",
				position: "relative"
			},
			id,
			children
		})
	});
}
ListContainer.displayName = "ListContainer";
function ItemContainer({ children, containerRole = "none", virtualRow }) {
	return /* @__PURE__ */ jsx("li", {
		role: containerRole,
		style: {
			position: "absolute",
			top: 0,
			left: 0,
			width: "100%",
			height: `${virtualRow.size}px`,
			transform: `translateY(${virtualRow.start}px)`
		},
		children
	});
}
ItemContainer.displayName = "ItemContainer";
var HighlightedText_module_default = { HighlightedText: "HighlightedText-module_-IVSdq_HighlightedText" };
function splitTextBySearchTerm(text, search) {
	if (!search) return [text];
	const splitLowercase = text.toLowerCase().split(search.toLowerCase());
	if (splitLowercase.length < 2) return [text];
	let idx = 0;
	const out = [];
	for (const component of splitLowercase) {
		out.push(text.substring(idx, idx + component.length));
		idx += component.length;
		out.push(text.substring(idx, idx + search.length));
		idx += search.length;
	}
	return out;
}
/**
* @param text the text to highlight
* @param search the search term to highlight within the text
* @param hideOverflow
* @returns safe HTML that has the search term highlighted within the text of the provided text
* parameter
*/
function HighlightedText({ text, search, hideOverflow = false, overflowWidth = 0 }) {
	const nodes = splitTextBySearchTerm(text, search).map((segment, index) => index % 2 === 1 ? /* @__PURE__ */ jsx("strong", {
		className: "color-fg-default",
		children: segment
	}, index) : segment);
	const overflowVal = hideOverflow ? "hidden" : "visible";
	return /* @__PURE__ */ jsx("div", {
		style: {
			maxWidth: overflowWidth ? `${overflowWidth}px` : void 0,
			overflow: overflowVal,
			color: search.length ? "fg.muted" : "fg.default"
		},
		className: HighlightedText_module_default.HighlightedText,
		children: nodes
	});
}
HighlightedText.displayName = "HighlightedText";
var RefItem_module_default = { ItemIcon: "RefItem-module_IzgH2W_ItemIcon" };
var RefItem = React.memo(function RefItemInner(t0) {
	const { isCurrent, isDefault, href, gitRef, filterText, ariaPosInSet, ariaSetSize, onSelect, onClick, shouldSetAsDiv: t1, isPendingTag: t2 } = t0;
	const shouldSetAsDiv = t1 === void 0 ? false : t1;
	const isPendingTag = t2 === void 0 ? false : t2;
	const innerRefItem = jsx(RefItemContent, {
		gitRef,
		isDefault,
		isCurrent,
		filterText,
		isPendingTag
	});
	const commonProps = {
		"aria-posinset": shouldSetAsDiv ? void 0 : ariaPosInSet,
		"aria-setsize": shouldSetAsDiv ? void 0 : ariaSetSize,
		"aria-checked": isCurrent,
		sx: { minWidth: 0 },
		onSelect: () => {
			onSelect?.(gitRef);
			if (href) navigate(href, { reloadDocument: true });
		},
		onClick: () => {
			onClick?.(gitRef);
			if (href) navigate(href, { reloadDocument: true });
		}
	};
	const navigate = useNavigate$1();
	return shouldSetAsDiv ? jsxs(ActionList.Item, {
		role: "menuitemradio",
		as: "div",
		...commonProps,
		children: [innerRefItem, isPendingTag && jsx(ActionList.TrailingVisual, {
			className: "fg-muted mr-1",
			children: "Created on publish"
		})]
	}) : jsxs(ActionList.Item, {
		role: "menuitemradio",
		...commonProps,
		children: [innerRefItem, isPendingTag && jsx(ActionList.TrailingVisual, {
			className: "fg-muted mr-1",
			children: "Created on publish"
		})]
	});
});
RefItem.displayName = "RefItem";
var RefItemContent = React.memo(function RefItemInner({ isCurrent, isDefault, gitRef, filterText, showLeadingVisual = true }) {
	return /* @__PURE__ */ jsxs("div", {
		style: {
			display: "flex",
			justifyContent: "space-between"
		},
		children: [/* @__PURE__ */ jsxs("div", {
			style: {
				display: "flex",
				minWidth: 0,
				alignItems: "flex-end"
			},
			children: [showLeadingVisual && /* @__PURE__ */ jsx(CheckIcon, {
				"aria-hidden": true,
				"data-icon-visibility": isCurrent ? "visible" : "hidden",
				className: RefItem_module_default.ItemIcon
			}), /* @__PURE__ */ jsx(HighlightedText, {
				hideOverflow: true,
				search: filterText,
				text: gitRef
			}, gitRef)]
		}), isDefault && /* @__PURE__ */ jsx(Label, { children: "default" })]
	});
});
RefItemContent.displayName = "RefItemContent";
var RefsList_module_default = { FixedSizeVirtualList: "RefsList-module_b_xgaq_FixedSizeVirtualList" };
/**
* The virtualized list has a fixed height. If we don't have very many refs,
* don't virtualize the list so that the container can shrink.
*/
var virtualizationThreshold = 20;
var maxHeight = 330;
/**
* A list of refs that is virtualized to allow very large lists.
*/
function RefsList(props) {
	return props.refs.length > virtualizationThreshold ? /* @__PURE__ */ jsx(VirtualRefsList, { ...props }) : /* @__PURE__ */ jsx(FullRefsList, { ...props });
}
/**
* Non-virtual implementation
*/
RefsList.displayName = "RefsList";
function FullRefsList({ refs, defaultBranch, currentCommitish, getHref, filterText, onSelectItem, ariaControls, pendingTag }) {
	return /* @__PURE__ */ jsx("ul", {
		style: {
			maxHeight,
			height: "100%",
			overflowY: "auto",
			padding: "var(--base-size-8)"
		},
		id: ariaControls,
		children: refs.map((gitRef, index) => /* @__PURE__ */ jsx(RefItem, {
			href: getHref?.(gitRef),
			isCurrent: currentCommitish === gitRef,
			isDefault: defaultBranch === gitRef,
			filterText,
			gitRef,
			onSelect: onSelectItem,
			onClick: onSelectItem,
			ariaPosInSet: index + 1,
			ariaSetSize: refs.length,
			isPendingTag: pendingTag === gitRef
		}, gitRef))
	});
}
FullRefsList.displayName = "FullRefsList";
function VirtualRefsList(t0) {
	const $ = c(21);
	const { refs, defaultBranch, currentCommitish, getHref, filterText, onSelectItem, ariaControls, pendingTag } = t0;
	let map;
	if ($[0] !== refs) {
		map = /* @__PURE__ */ new Map();
		for (let i = 0; i < refs.length; i++) map.set(refs[i], i);
		$[0] = refs;
		$[1] = map;
	} else map = $[1];
	const indexMap = map;
	let t1;
	if ($[2] !== ariaControls || $[3] !== currentCommitish || $[4] !== defaultBranch || $[5] !== filterText || $[6] !== getHref || $[7] !== indexMap || $[8] !== onSelectItem || $[9] !== pendingTag || $[10] !== refs) {
		let t2;
		if ($[12] !== currentCommitish || $[13] !== defaultBranch || $[14] !== filterText || $[15] !== getHref || $[16] !== indexMap || $[17] !== onSelectItem || $[18] !== pendingTag || $[19] !== refs.length) {
			t2 = (gitRef_0) => jsx(RefItem, {
				shouldSetAsDiv: true,
				href: getHref?.(gitRef_0),
				isCurrent: currentCommitish === gitRef_0,
				isDefault: defaultBranch === gitRef_0,
				filterText,
				gitRef: gitRef_0,
				onSelect: onSelectItem,
				onClick: onSelectItem,
				ariaPosInSet: (indexMap.get(gitRef_0) ?? 0) + 1,
				ariaSetSize: refs.length,
				isPendingTag: pendingTag === gitRef_0
			}, gitRef_0);
			$[12] = currentCommitish;
			$[13] = defaultBranch;
			$[14] = filterText;
			$[15] = getHref;
			$[16] = indexMap;
			$[17] = onSelectItem;
			$[18] = pendingTag;
			$[19] = refs.length;
			$[20] = t2;
		} else t2 = $[20];
		t1 = jsx(FixedSizeVirtualList$1, {
			ariaControls,
			items: refs,
			itemHeight: 32,
			style: {
				maxHeight,
				height: "100%",
				overflowY: "auto",
				padding: "var(--base-size-8)"
			},
			containerRole: "group",
			makeKey: _temp,
			renderItem: t2,
			className: RefsList_module_default.FixedSizeVirtualList
		});
		$[2] = ariaControls;
		$[3] = currentCommitish;
		$[4] = defaultBranch;
		$[5] = filterText;
		$[6] = getHref;
		$[7] = indexMap;
		$[8] = onSelectItem;
		$[9] = pendingTag;
		$[10] = refs;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
VirtualRefsList.displayName = "VirtualRefsList";
function _temp(gitRef) {
	return gitRef;
}
var { getItem, setItem, removeItem } = safeStorage("localStorage", { throwQuotaErrorsOnSet: true });
var RefType = {
	Branch: "branch",
	Tag: "tag"
};
var SearchIndex = class SearchIndex {
	refType;
	selector;
	knownItems = [];
	currentSearchResult = [];
	exactMatchFound = false;
	searchTerm = "";
	refEndpoint;
	cacheKey;
	nameWithOwner;
	isLoading = true;
	fetchInProgress = false;
	fetchFailed = false;
	static LocalStoragePrefix = "ref-selector";
	constructor(refType, selector, refEndpoint, cacheKey, nameWithOwner) {
		this.refType = refType;
		this.selector = selector;
		this.refEndpoint = refEndpoint;
		this.cacheKey = cacheKey;
		this.nameWithOwner = nameWithOwner;
	}
	render() {
		this.selector.render();
	}
	async fetchData() {
		try {
			if (!this.isLoading || this.fetchInProgress) return;
			if (!this.bootstrapFromLocalStorage()) {
				this.fetchInProgress = true;
				this.fetchFailed = false;
				const response = await fetch(`${this.refEndpoint}?type=${this.refType}`, { headers: { Accept: "application/json" } });
				await this.processResponse(response);
			}
			this.isLoading = false;
			this.fetchInProgress = false;
			this.render();
		} catch {
			this.fetchInProgress = false;
			this.fetchFailed = true;
		}
	}
	async processResponse(response) {
		this.emitStats(response);
		if (!response.ok) {
			this.fetchFailed = true;
			return;
		}
		const lsClone = response.clone();
		const decoded = await response.json();
		this.knownItems = decoded.refs;
		this.cacheKey = decoded.cacheKey;
		this.flushToLocalStorage(await lsClone.text());
	}
	emitStats(response) {
		if (!response.ok) {
			sendStats({ incrementKey: "REF_SELECTOR_BOOT_FAILED" }, true);
			return;
		}
		switch (response.status) {
			case 200:
				sendStats({ incrementKey: "REF_SELECTOR_BOOTED_FROM_UNCACHED_HTTP" });
				break;
			case 304:
				sendStats({ incrementKey: "REF_SELECTOR_BOOTED_FROM_HTTP_CACHE" });
				break;
			default: sendStats({ incrementKey: "REF_SELECTOR_UNEXPECTED_RESPONSE" });
		}
	}
	search(query) {
		this.searchTerm = query;
		if (query === "") {
			this.currentSearchResult = this.knownItems;
			return;
		}
		const result = [];
		const prefixes = [];
		this.exactMatchFound = false;
		let pos;
		for (const ref of this.knownItems) {
			pos = ref.indexOf(query);
			if (pos < 0) continue;
			if (pos === 0) {
				if (query === ref) {
					prefixes.unshift(ref);
					this.exactMatchFound = true;
				} else prefixes.push(ref);
				continue;
			}
			result.push(ref);
		}
		this.currentSearchResult = [...prefixes, ...result];
	}
	bootstrapFromLocalStorage() {
		const storedData = getItem(this.localStorageKey);
		if (!storedData) return false;
		const payload = JSON.parse(storedData);
		if (payload.cacheKey !== this.cacheKey || !("refs" in payload)) {
			removeItem(this.localStorageKey);
			return false;
		}
		this.knownItems = payload.refs;
		this.isLoading = false;
		sendStats({ incrementKey: "REF_SELECTOR_BOOTED_FROM_LOCALSTORAGE" });
		return true;
	}
	async flushToLocalStorage(serverResponse) {
		try {
			setItem(this.localStorageKey, serverResponse);
		} catch (e) {
			if (e.message.toLowerCase().includes("quota")) {
				this.clearSiblingLocalStorage();
				sendStats({ incrementKey: "REF_SELECTOR_LOCALSTORAGE_OVERFLOWED" });
				try {
					setItem(this.localStorageKey, serverResponse);
				} catch (err2) {
					if (err2.message.toLowerCase().includes("quota")) sendStats({ incrementKey: "REF_SELECTOR_LOCALSTORAGE_GAVE_UP" });
				}
			} else throw e;
		}
	}
	clearSiblingLocalStorage() {
		for (const key of Object.keys(localStorage)) if (key.startsWith(SearchIndex.LocalStoragePrefix)) removeItem(key);
	}
	clearLocalStorage() {
		removeItem(this.localStorageKey);
	}
	get localStorageKey() {
		return `${SearchIndex.LocalStoragePrefix}:${this.nameWithOwner}:${this.refType}`;
	}
};
/**
* Given repo information and filter parameters, returns a filtered list of
* refs, a state to indicate whether data is currently being loaded from the
* server, and an boolean to indicate whether an action for creating a branch
* should be shown.
*
* @remarks
* This reuses the SearchIndex which was created for the <ref-selector> web
* component. That means that any component using this hook should have
* approximate behavior parity even though the web component itself is not
* reused.
*/
function useRefs(cacheKey, owner, repo, refType, filterText, canCreate) {
	const [refsState, setRefsState] = useState({
		status: "uninitialized",
		refs: [],
		showCreateAction: false,
		searchIndex: null
	});
	const branchRendererRef = useRef({ render: () => {
		setRefsState(getStateFromIndex(branchIndexRef.current, canCreate));
	} });
	const tagRendererRef = useRef({ render: () => {
		setRefsState(getStateFromIndex(tagIndexRef.current, canCreate));
	} });
	const branchIndexRef = useRefWithOneInitialization(() => makeIndex(cacheKey, owner, repo, "branch", branchRendererRef.current));
	const tagIndexRef = useRefWithOneInitialization(() => makeIndex(cacheKey, owner, repo, "tag", tagRendererRef.current));
	useEffect(() => {
		const nameWithOwner = `${owner}/${repo}`;
		if (branchIndexRef.current.nameWithOwner !== nameWithOwner) branchIndexRef.current = makeIndex(cacheKey, owner, repo, "branch", branchRendererRef.current);
		if (tagIndexRef.current.nameWithOwner !== nameWithOwner) tagIndexRef.current = makeIndex(cacheKey, owner, repo, "tag", tagRendererRef.current);
		async function updateIndex() {
			const currentIndex = refType === "branch" ? branchIndexRef.current : tagIndexRef.current;
			currentIndex.render();
			await currentIndex.fetchData();
			currentIndex.search("");
			currentIndex.render();
		}
		updateIndex();
	}, [
		cacheKey,
		owner,
		repo,
		refType,
		branchIndexRef,
		tagIndexRef
	]);
	useEffect(() => {
		const currentIndex_0 = refType === "branch" ? branchIndexRef.current : tagIndexRef.current;
		currentIndex_0.search(filterText);
		currentIndex_0.render();
	}, [
		filterText,
		refType,
		branchIndexRef,
		tagIndexRef
	]);
	return refsState;
}
function makeIndex(cacheKey, owner, repo, refType, renderer) {
	return new SearchIndex(refType === "branch" ? RefType.Branch : RefType.Tag, renderer, repositoryPath({
		owner,
		repo,
		action: "refs"
	}), cacheKey, `${owner}/${repo}`);
}
function getStateFromIndex(index, canCreate) {
	return {
		status: index.fetchFailed ? "failed" : index.isLoading ? "loading" : "loaded",
		refs: index.currentSearchResult,
		showCreateAction: canCreate && index.searchTerm.length > 0 && !index.exactMatchFound,
		searchIndex: index
	};
}
function useRefWithOneInitialization(getInitialValue) {
	const ref = useRef(void 0);
	if (!ref.current) ref.current = getInitialValue();
	return ref;
}
var RefSelectorV1_module_default = {
	BranchOcticon: "RefSelectorV1-module_dy9Ica_BranchOcticon",
	Divider: "RefSelectorV1-module_dy9Ica_Divider",
	LoadingContainer: "RefSelectorV1-module_dy9Ica_LoadingContainer",
	RefActionText: "RefSelectorV1-module_dy9Ica_RefActionText",
	RefSelectorCloseButton: "RefSelectorV1-module_dy9Ica_RefSelectorCloseButton",
	RefSelectorContainer: "RefSelectorV1-module_dy9Ica_RefSelectorContainer",
	RefSelectorFilterContainer: "RefSelectorV1-module_dy9Ica_RefSelectorFilterContainer",
	RefSelectorHeading: "RefSelectorV1-module_dy9Ica_RefSelectorHeading",
	RefSelectorInnerContainer: "RefSelectorV1-module_dy9Ica_RefSelectorInnerContainer",
	RefSelectorInput: "RefSelectorV1-module_dy9Ica_RefSelectorInput",
	RefTypeTabs: "RefSelectorV1-module_dy9Ica_RefTypeTabs",
	ViewAllRefsActionLink: "RefSelectorV1-module_dy9Ica_ViewAllRefsActionLink",
	ViewAllRefsActionText: "RefSelectorV1-module_dy9Ica_ViewAllRefsActionText",
	ZeroStateText: "RefSelectorV1-module_dy9Ica_ZeroStateText"
};
function RefSelectorV1(props) {
	const { ariaDescribedBy, ariaLabelledBy, ariaLabel, cacheKey, owner, repo, canCreate, canCreateTag = false, types, hotKey, onOpenChange, size, variant, getHref, onBeforeCreate, onRefTypeChanged, currentCommitish, onCreateError, onSelectItem, closeOnSelect, selectedRefType, customFooterItemProps, buttonClassName, buttonText, persistButtonText, buttonPrefix, showIcon, allowResizing, idEnding, useFocusZone, disabled, anchoredOverlayProps, renderAnchor, actionListDescription } = props;
	const [filterText, setFilterText] = useState("");
	const inputRef = useRef(null);
	const createButtonRef = useRef(null);
	const normalizedSelectedRefType = selectedRefType === "tree" ? "branch" : selectedRefType;
	const displayCommitish = selectedRefType === "tree" ? currentCommitish.slice(0, 7) : currentCommitish;
	const [overlayOpen, setOverlayOpen] = useState(false);
	const [focusTrapEnabled, setFocusTrapEnabled] = useState(true);
	const [showTagWarningDialog, setShowTagWarningDialog] = useState(false);
	const [showCreateTagDialog, setShowCreateTagDialog] = useState(false);
	const [pendingTag, setPendingTag] = useState(null);
	const [refType, setRefType] = useState(normalizedSelectedRefType ?? (types ?? defaultTypes)[0]);
	const descriptionId = useId();
	const refsState = useRefs(cacheKey, owner, repo, refType, filterText, canCreate);
	const newRefName = filterText;
	const path = repositoryPath({
		owner,
		repo,
		action: "branches"
	});
	const checkTagPath = checkTagNameExistsPath({
		owner,
		repo
	});
	const tagValidationPath = checkTagStatePath({
		owner,
		repo
	});
	const createAndGoToBranch = useCallback(async () => {
		onBeforeCreate?.(newRefName);
		const result = await createBranch(path, newRefName, currentCommitish);
		if (!result.success) onCreateError?.(result.error);
		else if (getHref) {
			refsState.searchIndex?.clearLocalStorage();
			window.location.href = getHref(result.name);
		}
	}, [
		onBeforeCreate,
		newRefName,
		path,
		currentCommitish,
		getHref,
		onCreateError,
		refsState.searchIndex
	]);
	const checkTagAndCreate = useCallback(async () => {
		if (await checkTagExists(checkTagPath, newRefName)) {
			setShowTagWarningDialog(true);
			setFocusTrapEnabled(false);
			return;
		}
		setShowTagWarningDialog(false);
		setFocusTrapEnabled(false);
		createAndGoToBranch();
	}, [
		checkTagPath,
		newRefName,
		createAndGoToBranch,
		setShowTagWarningDialog
	]);
	const changeRefType = useCallback((newRefType) => {
		setRefType(newRefType);
		onRefTypeChanged?.(newRefType);
	}, [setRefType, onRefTypeChanged]);
	function closeRefSelector() {
		setOverlayOpen(false);
	}
	const onSelect = useCallback((selectedItemRef, selectedItemRefType) => {
		onSelectItem?.(selectedItemRef, selectedItemRefType);
		closeRefSelector();
	}, [onSelectItem]);
	const handleCreate = useCallback(() => {
		if (refType === "tag") {
			onSelect(newRefName, "tag");
			closeRefSelector();
		} else checkTagAndCreate();
	}, [
		refType,
		newRefName,
		onSelect,
		checkTagAndCreate
	]);
	const handleCreateTagFromDialog = useCallback((tagName) => {
		if (!refsState.refs.includes(tagName)) setPendingTag(tagName);
		setFilterText("");
		onSelect(tagName, "tag");
		setShowCreateTagDialog(false);
	}, [
		onSelect,
		setPendingTag,
		setFilterText,
		refsState.refs
	]);
	const handleOpenCreateTagDialog = useCallback(() => {
		setShowCreateTagDialog(true);
		closeRefSelector();
	}, []);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(RefSelectorAnchoredOverlay, {
			ariaDescribedBy: actionListDescription ? descriptionId : ariaDescribedBy,
			ariaLabelledBy,
			ariaLabel,
			refType,
			displayCommitish,
			focusTrapEnabled,
			preventClosing: showTagWarningDialog,
			size,
			variant,
			onOpenChange,
			hotKey,
			inputRef,
			overlayOpen,
			onOverlayChange: setOverlayOpen,
			buttonClassName,
			buttonText,
			persistButtonText,
			buttonPrefix,
			showIcon,
			allowResizing,
			idEnding,
			useFocusZone,
			disabled,
			anchoredOverlayProps,
			renderAnchor,
			children: /* @__PURE__ */ jsx(RefSelectorActionList, {
				filterText,
				displayCommitish,
				onFilterChange: setFilterText,
				refType,
				onRefTypeChange: changeRefType,
				refsState,
				onCreateError: props.onCreateError,
				showTagWarningDialog,
				setShowTagWarningDialog,
				onCreateRef: handleCreate,
				inputRef,
				createButtonRef,
				onSelectItem: onSelect,
				closeOnSelect,
				closeRefSelector,
				customFooterItemProps,
				...props,
				selectedRefType: refType,
				onOpenCreateTagDialog: handleOpenCreateTagDialog,
				pendingTag,
				canCreateTag,
				descriptionId
			})
		}),
		showTagWarningDialog && /* @__PURE__ */ jsx(CheckTagNameDialog, {
			isOpen: showTagWarningDialog,
			onDismiss: () => {
				setShowTagWarningDialog(false);
				createButtonRef.current?.focus();
			},
			onConfirm: createAndGoToBranch
		}),
		showCreateTagDialog && /* @__PURE__ */ jsx(CreateTagDialog, {
			onDismiss: () => setShowCreateTagDialog(false),
			onCreate: handleCreateTagFromDialog,
			initialTagName: newRefName,
			tagValidationUrl: tagValidationPath
		})
	] });
}
RefSelectorV1.displayName = "RefSelectorV1";
function RefSelectorActionList(t0) {
	const $ = c(46);
	const { canCreate, currentCommitish, displayCommitish, defaultBranch, filterText, getHref, hideShowAll, onSelectItem, closeOnSelect, closeRefSelector, onFilterChange, onRefTypeChange, owner, selectedRefType, refsState, refType, repo, types, onCreateRef, inputRef, createButtonRef, customFooterItemProps, viewAllJustify, actionListHeadingText, actionListDescription, onOpenCreateTagDialog, pendingTag, canCreateTag, descriptionId } = t0;
	const { refs, showCreateAction, status } = refsState;
	let t1;
	bb0: {
		if (refType === "tag" && pendingTag && !refs.includes(pendingTag)) {
			let t2;
			if ($[0] !== pendingTag || $[1] !== refs) {
				t2 = [pendingTag, ...refs];
				$[0] = pendingTag;
				$[1] = refs;
				$[2] = t2;
			} else t2 = $[2];
			t1 = t2;
			break bb0;
		}
		t1 = refs;
	}
	const displayRefs = t1;
	let t2;
	if ($[3] !== closeRefSelector || $[4] !== customFooterItemProps) {
		t2 = function onFooterItemClick() {
			customFooterItemProps?.onClick?.();
			closeRefSelector();
		};
		$[3] = closeRefSelector;
		$[4] = customFooterItemProps;
		$[5] = t2;
	} else t2 = $[5];
	const onFooterItemClick = t2;
	let t3;
	if ($[6] !== displayRefs.length || $[7] !== refType) {
		t3 = () => {
			const { single, plural } = {
				branch: {
					single: "branch",
					plural: "branches"
				},
				tag: {
					single: "tag",
					plural: "tags"
				}
			}[refType];
			const results = `${displayRefs.length} ${displayRefs.length === 1 ? single : plural} found`;
			const timeoutID = setTimeout(() => {
				announce$1(results);
			}, 1e3);
			return () => clearTimeout(timeoutID);
		};
		$[6] = displayRefs.length;
		$[7] = refType;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== displayRefs || $[10] !== refType) {
		t4 = [displayRefs, refType];
		$[9] = displayRefs;
		$[10] = refType;
		$[11] = t4;
	} else t4 = $[11];
	useEffect(t3, t4);
	let t5;
	if ($[12] !== actionListDescription || $[13] !== actionListHeadingText || $[14] !== canCreate || $[15] !== canCreateTag || $[16] !== closeOnSelect || $[17] !== closeRefSelector || $[18] !== createButtonRef || $[19] !== currentCommitish || $[20] !== customFooterItemProps || $[21] !== defaultBranch || $[22] !== descriptionId || $[23] !== displayCommitish || $[24] !== displayRefs || $[25] !== filterText || $[26] !== getHref || $[27] !== hideShowAll || $[28] !== inputRef || $[29] !== onCreateRef || $[30] !== onFilterChange || $[31] !== onFooterItemClick || $[32] !== onOpenCreateTagDialog || $[33] !== onRefTypeChange || $[34] !== onSelectItem || $[35] !== owner || $[36] !== pendingTag || $[37] !== refType || $[38] !== refs || $[39] !== repo || $[40] !== selectedRefType || $[41] !== showCreateAction || $[42] !== status || $[43] !== types || $[44] !== viewAllJustify) {
		t5 = jsxs("div", {
			className: "py-2",
			style: {
				display: "flex",
				flexDirection: "column",
				height: "100%"
			},
			children: [
				jsxs("div", {
					className: RefSelectorV1_module_default.RefSelectorContainer,
					children: [
						jsxs("div", {
							className: RefSelectorV1_module_default.RefSelectorInnerContainer,
							children: [jsx(Heading$2, {
								as: "h2",
								className: RefSelectorV1_module_default.RefSelectorHeading,
								children: actionListHeadingText ?? switchRefText(types ?? defaultTypes)
							}), jsx(IconButton, {
								tooltipDirection: "w",
								"aria-label": "Cancel",
								variant: "invisible",
								icon: XIcon,
								onClick: closeRefSelector,
								className: RefSelectorV1_module_default.RefSelectorCloseButton
							})]
						}),
						actionListDescription && jsx("p", {
							id: descriptionId,
							className: "color-fg-muted f5",
							style: {
								paddingLeft: "16px",
								paddingRight: "16px",
								paddingBottom: "8px"
							},
							children: actionListDescription
						}),
						jsx(RefTextFilter, {
							defaultText: filterText,
							refType,
							canCreate,
							onFilterChange,
							ref: inputRef
						})
					]
				}),
				jsxs("div", {
					style: {
						paddingBottom: showCreateAction && displayRefs.length === 0 ? 0 : 2,
						flex: 1,
						minHeight: 0
					},
					children: [(types ?? defaultTypes).length > 1 && jsx("div", {
						className: "px-2 pb-2",
						children: jsx(RefTypeTabs, {
							refType,
							onRefTypeChanged: onRefTypeChange,
							className: RefSelectorV1_module_default.RefTypeTabs
						})
					}), status === "loading" || status === "uninitialized" ? jsx(Loading, { refType }) : status === "failed" ? jsx(LoadingFailed, { refType }) : displayRefs.length === 0 && (!showCreateAction || refType === "tag") ? jsx(RefsZeroState, {}) : jsx(RefsList, {
						ariaControls: refType === "branch" ? "branches" : "tags",
						filterText,
						refs: displayRefs,
						defaultBranch: refType === "branch" ? defaultBranch : "",
						currentCommitish: refType === selectedRefType ? currentCommitish : "",
						getHref,
						onSelectItem: (ref) => {
							onSelectItem?.(ref, refType);
							if (closeOnSelect) closeRefSelector();
						},
						pendingTag
					})]
				}),
				jsxs(ActionList, {
					className: "p-0",
					children: [
						showCreateAction && jsxs(Fragment$1, { children: [refType === "branch" && refs.length > 0 && jsx(ActionList.Divider, { className: clsx("d-block mt-0", RefSelectorV1_module_default.Divider) }), jsx(CreateRefAction, {
							displayCommitish,
							newRefName: filterText,
							onCreateRef,
							createButtonRef,
							refType
						})] }),
						(!hideShowAll || customFooterItemProps) && jsx(ActionList.Divider, { className: clsx(`d-block ${showCreateAction ? "mt-2" : "mt-0"}`, RefSelectorV1_module_default.Divider) }),
						!hideShowAll && jsx(ViewAllRefsAction, {
							justify: viewAllJustify,
							refType,
							owner,
							repo,
							onClick: closeRefSelector
						}),
						customFooterItemProps && jsx(RefSelectorFooter, {
							...customFooterItemProps,
							onClick: onFooterItemClick
						})
					]
				}),
				refType === "tag" && canCreateTag && jsxs(Fragment$1, { children: [jsx(ActionList.Divider, { className: clsx("d-block mt-0", RefSelectorV1_module_default.Divider) }), jsx("div", {
					className: "px-2",
					children: jsx(ButtonComponent, {
						onClick: onOpenCreateTagDialog,
						block: true,
						children: "Create new tag"
					})
				})] })
			]
		});
		$[12] = actionListDescription;
		$[13] = actionListHeadingText;
		$[14] = canCreate;
		$[15] = canCreateTag;
		$[16] = closeOnSelect;
		$[17] = closeRefSelector;
		$[18] = createButtonRef;
		$[19] = currentCommitish;
		$[20] = customFooterItemProps;
		$[21] = defaultBranch;
		$[22] = descriptionId;
		$[23] = displayCommitish;
		$[24] = displayRefs;
		$[25] = filterText;
		$[26] = getHref;
		$[27] = hideShowAll;
		$[28] = inputRef;
		$[29] = onCreateRef;
		$[30] = onFilterChange;
		$[31] = onFooterItemClick;
		$[32] = onOpenCreateTagDialog;
		$[33] = onRefTypeChange;
		$[34] = onSelectItem;
		$[35] = owner;
		$[36] = pendingTag;
		$[37] = refType;
		$[38] = refs;
		$[39] = repo;
		$[40] = selectedRefType;
		$[41] = showCreateAction;
		$[42] = status;
		$[43] = types;
		$[44] = viewAllJustify;
		$[45] = t5;
	} else t5 = $[45];
	return t5;
}
RefSelectorActionList.displayName = "RefSelectorActionList";
function RefTextFilter({ refType, canCreate, onFilterChange, defaultText, ref }) {
	const [localText, setLocalText] = useState(defaultText);
	const [previousDefaultText, setPreviousDefaultText] = useState(defaultText);
	if (defaultText !== previousDefaultText) {
		setLocalText(defaultText);
		setPreviousDefaultText(defaultText);
	}
	const placeholder = refType === "tag" ? canCreate ? "Search or create a new tag" : "Search" : canCreate ? "Find or create a branch..." : "Find a branch...";
	const ariaLabel = refType === "tag" ? "Filter tags" : "Filter branches";
	return /* @__PURE__ */ jsx("div", {
		className: RefSelectorV1_module_default.RefSelectorFilterContainer,
		children: /* @__PURE__ */ jsx(TextInput$1, {
			"aria-label": ariaLabel,
			leadingVisual: SearchIcon,
			value: localText,
			placeholder,
			ref,
			onInput: (e) => {
				const target = e.target;
				if (!(target instanceof HTMLInputElement)) return;
				setLocalText(target.value);
				startTransition(() => {
					onFilterChange(target.value);
				});
			},
			className: RefSelectorV1_module_default.RefSelectorInput
		})
	});
}
RefTextFilter.displayName = "RefTextFilter";
function switchRefText(types) {
	if (types.includes("branch") && types.includes("tag")) return "Switch branches/tags";
	else if (types.includes("branch")) return "Switch branches";
	else if (types.includes("tag")) return "Switch tags";
}
function Loading({ refType }) {
	return /* @__PURE__ */ jsx("div", {
		className: RefSelectorV1_module_default.LoadingContainer,
		children: /* @__PURE__ */ jsx(Spinner, {
			size: "medium",
			"aria-label": `Loading ${refType === "branch" ? "branches" : "tags"}...`
		})
	});
}
Loading.displayName = "Loading";
function RefsZeroState() {
	return /* @__PURE__ */ jsx("div", {
		className: RefSelectorV1_module_default.ZeroStateText,
		children: "Nothing to show"
	});
}
RefsZeroState.displayName = "RefsZeroState";
function ViewAllRefsAction({ refType, owner, repo, onClick, justify = "start" }) {
	const type = refType === "branch" ? "branches" : "tags";
	return /* @__PURE__ */ jsx(ActionList.LinkItem, {
		role: "link",
		href: repositoryPath({
			owner,
			repo,
			action: type
		}),
		onClick,
		className: RefSelectorV1_module_default.ViewAllRefsActionLink,
		children: /* @__PURE__ */ jsxs("div", {
			style: { justifyContent: justify },
			className: RefSelectorV1_module_default.ViewAllRefsActionText,
			children: ["View all ", type]
		})
	});
}
ViewAllRefsAction.displayName = "ViewAllRefsAction";
function CreateRefAction({ displayCommitish, newRefName, onCreateRef, createButtonRef, refType }) {
	if (refType === "tag") return null;
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		role: "button",
		onSelect: onCreateRef,
		ref: createButtonRef,
		children: [
			/* @__PURE__ */ jsx(GitBranchIcon, { className: RefSelectorV1_module_default.BranchOcticon }),
			/* @__PURE__ */ jsx("span", { children: "Create branch\xA0" }),
			/* @__PURE__ */ jsx("span", {
				className: RefSelectorV1_module_default.RefActionText,
				children: newRefName
			}),
			/* @__PURE__ */ jsx("span", { children: "\xA0from\xA0" }),
			/* @__PURE__ */ jsx("span", {
				className: RefSelectorV1_module_default.RefActionText,
				children: displayCommitish
			})
		]
	});
}
CreateRefAction.displayName = "CreateRefAction";
var RefSelector_module_default = {
	RefSelectorTabLink: "RefSelector-module_CTif_a_RefSelectorTabLink",
	RefSelectorTabs: "RefSelector-module_CTif_a_RefSelectorTabs"
};
var defaultTypes = ["branch", "tag"];
/**
* An action menu that allows the user to switch between branches or tags.
*
* TODO: Currently this does not have support for customizing how the items,
*       zero states, and branch creation action are rendered. The old
*       <ref-selector> element allowed that by requiring each usage to pass
*       in templates. The right solution here is probably something like
*       a set of render props.
*
* @remarks
* This accomplishes something very similar to the <ref-selector> web component.
* There are a few reasons that working with that component in react is difficult:
* - React has bugs in how it handles <template> elements, and those bugs are
*   not likely to be fixed for perf reasons: https://github.com/facebook/react/issues/19932
*   This can be worked around, but it is very easy to break.
* - There is no way to attach callbacks to elements that would be rendered
*   through a template, since those DOM nodes are all going to be copied in
*   a way that is not managed by React.
*/
function RefSelector(props) {
	return /* @__PURE__ */ jsx(RefSelectorV1, { ...props });
}
RefSelector.displayName = "RefSelector";
function RefTypeTabs({ refType, onRefTypeChanged, className }) {
	return /* @__PURE__ */ jsxs(TabNav_default, {
		"aria-label": "Ref type",
		className: clsx(RefSelector_module_default.RefSelectorTabs, className),
		children: [/* @__PURE__ */ jsx(TabNav_default.Link, {
			as: ButtonComponent,
			id: "branch-button",
			"aria-controls": "branches",
			selected: refType === "branch",
			onClick: () => onRefTypeChanged("branch"),
			className: RefSelector_module_default.RefSelectorTabLink,
			children: "Branches"
		}), /* @__PURE__ */ jsx(TabNav_default.Link, {
			as: ButtonComponent,
			id: "tag-button",
			"aria-controls": "tags",
			selected: refType === "tag",
			onClick: () => onRefTypeChanged("tag"),
			className: RefSelector_module_default.RefSelectorTabLink,
			children: "Tags"
		})]
	});
}
RefTypeTabs.displayName = "RefTypeTabs";
function LoadingFailed({ refType }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "danger",
		children: ["Could not load ", refType === "branch" ? "branches" : "tags"]
	});
}
LoadingFailed.displayName = "LoadingFailed";
export { RefSelector as n, HighlightedText as t };
