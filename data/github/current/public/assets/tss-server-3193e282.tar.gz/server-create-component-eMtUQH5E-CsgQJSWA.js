import React from "react";
import { createComponent } from "@lit-labs/react";
var rename = (str) => str[0].toUpperCase() + str.slice(1).replace(/(-\w)/g, (s) => s[1].toUpperCase());
var createComponent$1 = (elementClass, tagName, events = void 0) => {
	const component = createComponent({
		tagName,
		elementClass,
		react: React,
		events
	});
	component.displayName = rename(tagName);
	return component;
};
export { createComponent$1 as t };
