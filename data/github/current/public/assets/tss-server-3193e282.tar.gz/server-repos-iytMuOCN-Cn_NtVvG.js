performance.mark("js-parse-end:server-repos-iytMuOCN-Cn_NtVvG.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:repos-iytMuOCN.js");
var reposIndexServerFn_createServerFn_handler = createServerRpc({
	id: "311f5ad21c11f471b5aa30726222748ccf67f7812e97330a0371cfccb7db5b1d",
	name: "reposIndexServerFn",
	filename: "src/routes/repos/index.tsx"
}, (opts) => reposIndexServerFn.__executeServer(opts));
var reposIndexServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(reposIndexServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom",
		params: data.searchParams
	}, "reposFinderPageRoute");
});
export { reposIndexServerFn_createServerFn_handler };
