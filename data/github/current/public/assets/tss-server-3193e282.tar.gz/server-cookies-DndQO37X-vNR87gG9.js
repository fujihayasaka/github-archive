/**
* Get a cookie by name.
* @param name
* @returns a cookie object or undefined if not found.
*/
function getCookie(name) {
	return getCookies(name)[0];
}
/**
* Get all cookies by name.
* @param name
* @returns
*/
function getCookies(name) {
	const cookies = [];
	for (const cookie of readCookies()) {
		const [key, value] = cookie.trim().split("=");
		if (name === key && typeof value !== "undefined") cookies.push({
			key,
			value
		});
	}
	return cookies;
}
function readCookies() {
	try {
		return document.cookie.split(";");
	} catch {
		return [];
	}
}
/**
* Set a new cookie with sensible defaults like secure.
* @param name
* @param value
* @param expiration
* @param strictDomain
* @param samesite
*/
function setCookie(name, value, expiration = null, strictDomain = false, samesite = "lax") {
	let domain = document.domain;
	if (domain == null) throw new Error("Unable to get document domain");
	if (domain.endsWith(".github.com")) domain = "github.com";
	const secure = location.protocol === "https:" ? "; secure" : "";
	const expire = expiration ? `; expires=${expiration}` : "";
	if (strictDomain === false) domain = `.${domain}`;
	try {
		document.cookie = `${name}=${value}; path=/; domain=${domain}${expire}${secure}; samesite=${samesite}`;
	} catch {}
}
/**
* Delete a given cookie with sensible defaults like secure.
* This sets the expires value to a second ago to delete the cookie.
* @param name
* @param strictDomain
*/
function deleteCookie(name, strictDomain = false) {
	let domain = document.domain;
	if (domain == null) throw new Error("Unable to get document domain");
	if (domain.endsWith(".github.com")) domain = "github.com";
	const time = Date.now();
	const expiration = (/* @__PURE__ */ new Date(time - 1)).toUTCString();
	const secure = location.protocol === "https:" ? "; secure" : "";
	const expire = `; expires=${expiration}`;
	if (strictDomain === false) domain = `.${domain}`;
	try {
		document.cookie = `${name}=''; path=/; domain=${domain}${expire}${secure}`;
	} catch {}
}
export { getCookie as n, setCookie as r, deleteCookie as t };
