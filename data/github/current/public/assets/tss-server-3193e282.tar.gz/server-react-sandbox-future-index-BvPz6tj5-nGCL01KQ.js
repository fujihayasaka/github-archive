performance.mark("js-parse-end:server-react-sandbox-future-index-BvPz6tj5-nGCL01KQ.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:react-sandbox-future-index-BvPz6tj5.js");
var indexLoader_createServerFn_handler = createServerRpc({
	id: "a07e5a1811e99c52a112dcf349e8057d914dd5e979710806dce91e8db540ec44",
	name: "indexLoader",
	filename: "src/routes/react_sandbox_future/react-sandbox-future-index.tsx"
}, (opts) => indexLoader.__executeServer(opts));
var indexLoader = createServerFn().handler(indexLoader_createServerFn_handler, async () => {
	const { payload } = await fetchDataRouterMainQuery({
		path: "/_react_sandbox_future",
		service: "dotcom"
	}, "reactSandboxFutureIndexRoute");
	return payload;
});
export { indexLoader_createServerFn_handler };
