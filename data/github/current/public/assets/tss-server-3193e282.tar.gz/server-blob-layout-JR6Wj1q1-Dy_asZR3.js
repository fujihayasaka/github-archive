performance.mark("js-parse-end:server-blob-layout-JR6Wj1q1-Dy_asZR3.js");
import { S as useSearchParams, n as Outlet$1, v as useMatches$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as useRouteQuery, t as useChildRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { d as EmptyDeferredMetadata, l as DeferredASTProvider, nt as useDeferredASTQuery, s as CurrentBlobProvider, u as DeferredMetadataProvider } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { t as CurrentStyledBlobProvider } from "./server-use-scroll-line-into-view-DttIeP88-D69hX7MG.js";
import { n as BlobHeaderActions, r as CodeViewHeaderDataRouter } from "./server-NavigationMenu-CKgcoy5c-Bbjbrr6N.js";
import { t as codeViewBlobLayoutRoute } from "./server-code-view-blob-layout-route-dhoYwhPV-CcMKI0YH.js";
import { t as codeViewBlameRoute } from "./server-code-view-blame-route-CBnG62NQ-C6WKn_o_.js";
import { t as LatestCommitProvider } from "./server-LatestCommitContext-D4oQqyj7-DHpYqCjL.js";
import { t as codeViewBlobRoute } from "./server-code-view-blob-route-BXbxJsMG-BeLOpqoP.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:blob-layout-JR6Wj1q1.js");
function mergeBlobPayloads(layoutData, routeData, isPlainSearchParam) {
	const { headerInfo: layoutHeaderInfo, ...layoutBlob } = layoutData.blob;
	if ("blame" in routeData) return {
		csv: null,
		csvError: null,
		richText: null,
		symbols: {
			not_analyzed: true,
			timed_out: false,
			symbols: []
		},
		renderedFileInfo: null,
		issueTemplate: null,
		discussionTemplate: void 0,
		...layoutBlob,
		headerInfo: {
			...layoutHeaderInfo,
			toc: null
		},
		isPlain: layoutBlob.isPlain || isPlainSearchParam
	};
	const { headerInfo: routeHeaderInfo, ...routeBlob } = routeData;
	return {
		...layoutBlob,
		...routeBlob,
		headerInfo: {
			...layoutHeaderInfo,
			...routeHeaderInfo
		},
		isPlain: layoutBlob.isPlain || isPlainSearchParam
	};
}
function CodeViewBlobLayout() {
	const $ = c(16);
	const { data: layoutData } = useRouteQuery(codeViewBlobLayoutRoute, "mainQuery");
	const { data: routeData } = useChildRouteQuery(!!useMatches$1().find(_temp) ? codeViewBlobRoute : codeViewBlameRoute, "mainQuery");
	const { data: styledBlobData } = useRouteQuery(codeViewBlobLayoutRoute, "codeViewBlobLayoutRoute.StyledBlob");
	const { data: deferredMetadataQuery } = useRouteQuery(codeViewBlobLayoutRoute, "deferredMetadata");
	const { data: latestCommit, error: latestCommitError, isLoading: latestCommitLoading } = useRouteQuery(codeViewBlobLayoutRoute, "latestCommit");
	const deferredAST = useDeferredASTQuery(layoutData.refInfo, layoutData.path, layoutData.error?.httpStatus === 404, styledBlobData?.rawLines?.length ?? 1e5);
	const [urlParams] = useSearchParams();
	let t0;
	if ($[0] !== urlParams) {
		t0 = urlParams.get("plain");
		$[0] = urlParams;
		$[1] = t0;
	} else t0 = $[1];
	const isPlainSearchParam = t0 === "1";
	let t1;
	if ($[2] !== isPlainSearchParam || $[3] !== layoutData || $[4] !== routeData) {
		t1 = routeData && layoutData && !layoutData.error ? mergeBlobPayloads(layoutData, routeData, isPlainSearchParam) : null;
		$[2] = isPlainSearchParam;
		$[3] = layoutData;
		$[4] = routeData;
		$[5] = t1;
	} else t1 = $[5];
	const blob = t1;
	if (layoutData?.error) {
		let t2;
		if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = jsx(Outlet$1, {});
			$[6] = t2;
		} else t2 = $[6];
		return t2;
	}
	if (!routeData || !layoutData || !blob) return null;
	const deferredMetadata = deferredMetadataQuery ?? EmptyDeferredMetadata;
	let t2;
	if ($[7] !== blob || $[8] !== deferredAST || $[9] !== deferredMetadata || $[10] !== latestCommit || $[11] !== latestCommitError || $[12] !== latestCommitLoading || $[13] !== layoutData || $[14] !== styledBlobData) {
		t2 = jsx(LatestCommitProvider, {
			latestCommit,
			error: latestCommitError,
			isLoading: latestCommitLoading,
			children: jsx(DeferredMetadataProvider, {
				...deferredMetadata,
				children: jsx(DeferredASTProvider, {
					...deferredAST,
					children: jsx(CurrentBlobProvider, {
						blob,
						children: jsxs(CurrentStyledBlobProvider, {
							blob: styledBlobData,
							children: [jsx(CodeViewHeaderDataRouter, {
								narrowActions: jsx(BlobHeaderActions, {
									payload: layoutData,
									narrow: true
								}),
								wideActions: jsx(BlobHeaderActions, {
									payload: layoutData,
									narrow: false
								}),
								path: layoutData.path,
								commitish: layoutData.refInfo.name,
								modelsRepoIntegrationEnabled: layoutData.modelsRepoIntegrationEnabled
							}), jsx(Outlet$1, {})]
						})
					})
				})
			})
		});
		$[7] = blob;
		$[8] = deferredAST;
		$[9] = deferredMetadata;
		$[10] = latestCommit;
		$[11] = latestCommitError;
		$[12] = latestCommitLoading;
		$[13] = layoutData;
		$[14] = styledBlobData;
		$[15] = t2;
	} else t2 = $[15];
	return t2;
}
CodeViewBlobLayout.displayName = "CodeViewBlobLayout";
function _temp(match) {
	return match.id === codeViewBlobRoute.id;
}
var SplitComponent = CodeViewBlobLayout;
export { SplitComponent as component };
