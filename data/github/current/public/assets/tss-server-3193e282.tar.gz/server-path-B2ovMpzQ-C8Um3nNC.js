import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
/**
* Given a path function, a set of parameters for that function, and a query, returns a URL.
*/
function getUrl(path, args, query) {
	const pathname = path(args);
	const target = new URL(pathname, ssrSafeLocation.origin || "https://github.com");
	if (pathname === ssrSafeLocation.pathname) target.search = new URLSearchParams(ssrSafeLocation.search).toString();
	for (const [key, value] of Object.entries(query || {})) if (value === null || value === void 0) target.searchParams.delete(key);
	else target.searchParams.set(key, value.toString());
	return target;
}
/**
* Get an href for use in links. This will be a relative URL, and will work properly in SSR.
*/
function getRelativeHref(path, args, query) {
	const url = getUrl(path, args, query);
	return url.href.replace(url.origin, "");
}
/**
* Encodes special characters in a URL part, except `/`
*/
function encodePart(part) {
	return part.split("/").map(encodeURIComponent).join("/");
}
/**
* Returns a relative URL to view the details page of a GitHub Models model.
* Keep in sync with the `marketplace_model_path` route helper in Rails.
*/
var modelPath = ({ registry, name }) => `/marketplace/models/${registry}/${name}`;
/**
* Returns a relative URL to the prompt editor for a GitHub Models model.
* Keep in sync with the `marketplace_model_prompt_path` route helper in Rails.
*/
function modelPromptPath({ commit, filePath, repoOwner, repoName, beginLine, endLine, ...model }) {
	const params = new URLSearchParams();
	if (commit) params.set("c", commit);
	if (filePath) params.set("path", filePath);
	if (repoOwner) params.set("l", repoOwner);
	if (repoName) params.set("n", repoName);
	if (beginLine !== null && beginLine !== void 0 && endLine !== null && endLine !== void 0) {
		let lineRange = "";
		if (beginLine === endLine) lineRange = `${Math.max(beginLine - 10, 0)}-${endLine + 10}`;
		else lineRange = `${beginLine}-${endLine}`;
		params.set("lines", lineRange);
	}
	const basePath = `${modelPath(model)}/prompt`;
	const query = params.toString();
	if (query.length < 1) return basePath;
	return `${basePath}?${query}`;
}
function repoModelsPromptPath({ repo, commitish, action, path }) {
	const parts = [
		"",
		repo.ownerLogin,
		repo.name,
		"models",
		"prompt",
		action
	];
	if (commitish) parts.push(commitish);
	if (path && path !== "/") parts.push(path);
	return parts.map(encodePart).join("/");
}
var codeNavGeneralSearchPath = ({ searchTerm }) => `/search?q=${encodePart(`${searchTerm}`)}&type=code`;
var codeNavSearchPath = ({ owner, repo, searchTerm }) => `/search?q=${encodePart(`repo:${owner}/${repo} ${searchTerm}`)}&type=code`;
var ownerPath = ({ owner }) => `/${encodePart(owner)}`;
var ownerAvatarPath = ({ owner }) => `/${encodePart(owner)}.png`;
var copilotHovercardPath = ({ bot_slug }) => `/copilot/hovercard?bot=${encodePart(bot_slug)}`;
var userHovercardPath = ({ owner }) => `/users/${encodePart(owner)}/hovercard`;
var teamHovercardPath = ({ owner, team }) => `/orgs/${encodePart(owner)}/teams/${encodePart(team)}/hovercard`;
var orgHovercardPath = ({ owner }) => `/orgs/${encodePart(owner)}/hovercard`;
var userIdHovercardPath = ({ userId }) => `/hovercards?user_id=${userId}`;
var discussionHovercardPath = ({ owner, repo, discussionNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/discussions/${discussionNumber}/hovercard`;
var advisoryHovercardPath = ({ ghsaId }) => `/advisories/${encodePart(ghsaId)}/hovercard`;
var cweHovercardPath = ({ id }) => `/advisories/cwes/${encodePart(id)}/hovercard`;
var sponsorsListingHovercardPath = ({ login }) => `/sponsors/${encodePart(login)}/hovercard`;
var achievementHovercardPath = ({ login, slug }) => `/users/${encodePart(login)}/achievements/${encodePart(slug)}/detail?hovercard=1`;
var trackedInHovercardPath = ({ owner, repo, issueNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/issues/${issueNumber}/tracked_in/hovercard`;
var trackingHovercardPath = ({ owner, repo, issueNumber, id }) => `/${encodePart(owner)}/${encodePart(repo)}/issues/${issueNumber}/tracking/${id}/hovercard`;
var securityAlertHovercardPath = ({ owner, repo, alertNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/security/code-scanning/${alertNumber}/hovercard`;
var dependabotAlertHovercardPath = ({ owner, repo, alertNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/security/dependabot/${alertNumber}/hovercard`;
var dependencyGraphPackageHovercardPath = ({ owner, repo, id, name }) => `/${encodePart(owner)}/${encodePart(repo)}/dependency-graph/package_hovercards/${encodePart(id)}/${encodePart(name)}`;
var projectHovercardPath = ({ projectId }) => `/memexes/${projectId}/hovercard`;
var integrationHovercardPath = ({ id }) => `/hovercards/integrations/${id}`;
var profileHighlightHovercardPath = ({ login, highlightType }) => `/users/${encodePart(login)}/profile_highlights/${encodePart(highlightType)}/hovercard`;
function repositoryPath({ owner, repo, action }) {
	return action ? `/${encodePart(owner)}/${encodePart(repo)}/${action}` : `/${encodePart(owner)}/${encodePart(repo)}`;
}
function repositoryDefaultBranchPath({ owner, repo }) {
	return `${repositoryPath({
		owner,
		repo
	})}/default_branch`;
}
var repositoryStatsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/stats`;
var repositoryDeployPath = ({ owner, repo, framework, packageManager }) => {
	const basePath = `/${encodePart(owner)}/${encodePart(repo)}/deploy`;
	const params = new URLSearchParams();
	if (framework) params.append("framework", framework);
	if (packageManager) params.append("package_manager", packageManager);
	return params.toString() ? `${basePath}?${params.toString()}` : basePath;
};
var repositoryParticipationPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/graphs/participation`;
var repoCommitActivityInsightsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/graphs/commit-activity`;
var checkTagNameExistsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/branches/check_tag_name_exists`;
var checkTagStatePath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/tags/check`;
var branchPath = ({ owner, repo, branch }) => `/${encodePart(owner)}/${encodePart(repo)}/tree/${encodePart(branch)}`;
var invitationsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/invitations`;
var migrateImmutableActionsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/actions/immutable_actions/migrate`;
var migrationWorkflowsPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/actions/workflows/immutable-actions-migration/migrate_release`;
var newRulesetPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/settings/rules/new?target=branch&enforcement=disabled`;
var orgBlockedUsersPath = ({ owner }) => `/organizations/${encodePart(owner)}/settings/blocked_users`;
var blobPath = ({ owner, repo, commitish, filePath, lineNumber, plain, endLineNumber }) => {
	const params = plain ? `?plain=${plain}` : "";
	const suffix = lineNumber ? `#L${lineNumber}${endLineNumber ? `-L${endLineNumber}` : ""}` : "";
	return `/${encodePart(owner)}/${encodePart(repo)}/blob/${encodePart(commitish)}/${encodePart(filePath)}${params}${suffix}`;
};
var deleteBlobPath = ({ owner, repo, commitish, filePath }) => {
	return `/${encodePart(owner)}/${encodePart(repo)}/delete/${encodePart(commitish)}/${encodePart(filePath)}`;
};
var editBlobPath = ({ owner, repo, commitish, filePath, hash, lineNumber, returnToPrPath }) => {
	const suffix = hash ? hash : lineNumber ? `#L${lineNumber}` : "";
	const returnToPr = returnToPrPath ? `?pr=${encodeURI(returnToPrPath)}` : "";
	return `/${encodePart(owner)}/${encodePart(repo)}/edit/${encodePart(commitish)}/${encodePart(filePath)}${suffix}${returnToPr}`;
};
var blamePath = ({ owner, repo, commitish, filePath, lineNumber }) => {
	const suffix = lineNumber ? `#L${lineNumber}` : "";
	return `/${encodePart(owner)}/${encodePart(repo)}/blame/${encodePart(commitish)}/${encodePart(filePath)}${suffix}`;
};
function dismissRepositoryNoticePathPath({ login }) {
	return `/users/${encodePart(login)}/dismiss_repository_notice`;
}
function deferredMetadataPath({ repo, commitish, path }) {
	return [
		"",
		repo.ownerLogin,
		repo.name,
		"deferred-metadata",
		commitish,
		path
	].map(encodePart).join("/");
}
function deferredASTPath({ repo, commitish, path }) {
	return [
		"",
		repo.ownerLogin,
		repo.name,
		"deferred-ast",
		commitish,
		path
	].map(encodePart).join("/");
}
function repoOverviewUrl(repo) {
	return `/${encodePart(repo.ownerLogin)}/${encodePart(repo.name)}`;
}
function repoDefaultBrachUrl(repo) {
	return `/${encodePart(repo.ownerLogin)}/${encodePart(repo.name)}?files=1`;
}
function repositoryTreePath({ repo, commitish, action, path }) {
	const parts = [
		"",
		repo.ownerLogin,
		repo.name,
		action
	];
	if (commitish) parts.push(commitish);
	if (path && path !== "/") parts.push(path);
	return parts.map(encodePart).join("/");
}
var blobSidePanelMetadataPath = ({ owner, repo }) => `/${owner}/${repo}/sidepanel-metadata`;
function blobDetectLanguage(repo, encodedFileName, fullDetails) {
	return `/${repo.ownerLogin}/${repo.name}/detect_language?filename=${encodedFileName}${fullDetails ? "&full_details=true" : ""}`;
}
var commitPath = ({ owner, repo, commitish }) => `/${encodePart(owner)}/${encodePart(repo)}/commit/${commitish}`;
var commitsPath = ({ owner, repo, ref, path }) => {
	const base = `/${encodePart(owner)}/${encodePart(repo)}/commits`;
	if (!ref) return base;
	if (!path) return `${base}/${encodePart(ref)}`;
	return `${base}/${encodePart(ref)}/${encodePart(stripLeadingSlash(path))}`;
};
function commitsPathByAuthor({ repo, branch, path, author }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"commits",
		branch,
		path
	].map(encodePart).join("/")}?author=${encodePart(author)}`;
}
function commitStatusDetailsPath(repo, oid) {
	return `/${repo.ownerLogin}/${repo.name}/commit/${oid}/status-details`;
}
function commitsByAuthor({ repo, author }) {
	return `/${[repo.ownerLogin, repo.name].map(encodePart).join("/")}/commits?author=${encodePart(author)}`;
}
var commitHovercardPath = ({ owner, repo, commitish }) => `/${encodePart(`${owner}/${repo}/commit/${commitish}/hovercard`)}`;
var marketplaceActionPath = ({ slug }) => `/marketplace/actions/${encodePart(slug)}`;
var codeownersErrorPath = ({ owner, repo, commitish, filePath }) => `/${owner}/${repo}/codeowners-validity/${commitish}/${filePath}`;
function stripLeadingSlash(path) {
	return path.startsWith("/") ? path.slice(1) : path;
}
function parentPath(path) {
	return path.split("/").slice(0, -1).join("/");
}
function comparePath({ repo, base = void 0, head }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"compare"
	].map(encodePart).join("/")}/${base ? `${encodePart(base)}...${encodePart(head)}` : encodePart(head)}`;
}
function mergeabilityCheckPath({ repo, base, head }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"branches",
		"pre_mergeable"
	].map(encodePart).join("/")}/${`${encodePart(base)}...${encodePart(head)}`}`;
}
function toggleGenericFeaturePath({ repo }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"toggle_generic_feature"
	].map(encodePart).join("/")}`;
}
function repoPullRequestsPath(owner, repo) {
	return `/${encodePart(owner)}/${encodePart(repo)}/pulls`;
}
function repoStargazersPath(owner, repo) {
	return `/${encodePart(owner)}/${encodePart(repo)}/stargazers`;
}
function newPullRequestPath({ repo, refName }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"pull",
		"new",
		refName
	].map(encodePart).join("/")}`;
}
function pullRequestPath({ repo, number }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"pull",
		number.toString()
	].map(encodePart).join("/")}`;
}
var pullRequestChangesPath = ({ owner, repo, number }) => `/${encodePart(owner)}/${encodePart(repo)}/pull/${number}/changes`;
var pullRequestChangesCommitRangePath = ({ owner, repo, number, base, head }) => {
	if (base) return `/${encodePart(owner)}/${encodePart(repo)}/pull/${number}/changes/${base}..${head}`;
	else return `/${encodePart(owner)}/${encodePart(repo)}/pull/${number}/changes/${head}`;
};
var pullRequestProcessingIndicatorPath = ({ owner, repo, number }) => {
	return `/${encodePart(owner)}/${encodePart(repo)}/pull/${number}/partials/processing_indicator`;
};
function fetchAndMergePath({ repo, refName, discard }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"branches",
		"fetch_and_merge",
		refName
	].map(encodePart).join("/")}${discard ? "?discard_changes=true" : ""}`;
}
function treeListPath({ repo, commitOid, includeDirectories = false }) {
	const path = `/${[
		repo.ownerLogin,
		repo.name,
		"tree-list",
		commitOid
	].map(encodePart).join("/")}`;
	return includeDirectories ? `${path}?include_directories=${includeDirectories}` : path;
}
function branchAndTagCountPath(repo) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"branch-and-tag-count"
	].map(encodePart).join("/")}`;
}
function codeNavigationPath({ repo, type, q, language, row, column, ref, path, codeNavContext, symbolKind }) {
	const repoSegment = [repo.ownerLogin, repo.name].map(encodePart).join("/");
	const params = new URLSearchParams();
	params.append("q", q);
	params.append("language", language);
	params.append("row", String(row));
	params.append("col", String(column));
	params.append("ref", ref);
	params.append("blob_path", path);
	params.append("code_nav_context", codeNavContext);
	if (symbolKind) params.append("symbol_kind", symbolKind);
	return `/${repoSegment}/find-react-${type}?${params.toString()}`;
}
function repoIssuesPath(owner, repo) {
	return `/${encodePart(owner)}/${encodePart(repo)}/issues`;
}
var issuePath = ({ owner, repo, issueNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/issues/${issueNumber}`;
var issueHovercardPath = ({ owner, repo, issueNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/issues/${issueNumber}/hovercard`;
var issueAgentTasksPath = ({ owner, repo, issueNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/issues/${issueNumber}/agent_tasks`;
var issueLinkedPullRequestHovercardPath = ({ owner, repo, pullRequestNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/pull/${pullRequestNumber}/hovercard`;
var repoContributorsPath = (repo) => `/${encodePart(repo.ownerLogin)}/${encodePart(repo.name)}/graphs/contributors`;
var repoAccessSettingsPath = (repo) => `/${encodePart(repo.ownerLogin)}/${encodePart(repo.name)}/settings/access`;
function forksListPath({ owner, repo }) {
	return `/${encodePart(`${owner}/${repo}`)}/forks`;
}
function newRepoPath({ org } = {}) {
	if (org) return `/organizations/${encodePart(org)}/repositories/new`;
	return `/new`;
}
function orgTopicReposPath({ topic, org }) {
	return `/search?q=topic%3A${encodePart(topic)}+org%3A${encodePart(org)}&type=Repositories`;
}
function shortcutsPath(id) {
	return `/users/shortcuts${id ? `/${id}` : ""}`;
}
function branchesPath({ repo }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"branches"
	].map(encodePart).join("/")}`;
}
function tagsPath({ repo }) {
	return `/${[
		repo.ownerLogin,
		repo.name,
		"tags"
	].map(encodePart).join("/")}`;
}
function dismissUserNoticePath({ noticeName }) {
	return `/settings/dismiss-notice/${noticeName}`;
}
var userPRFileTreeVisibilitySettingPath = ({ login }) => `/users/${encodePart(login)}/pulls/settings/file_tree_visibility`;
var pullRequestFileTreeWidthSettingPath = ({ owner, repo, pullNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/pull/${pullNumber}/page_data/update_file_tree_width_preference`;
var pullRequestDockedPanelWidthSettingPath = ({ owner, repo, pullNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/pull/${pullNumber}/page_data/update_docked_panel_width_preference`;
var codeScanningAlertPickerPath = ({ owner, repo }) => `/${encodePart(owner)}/${encodePart(repo)}/security/code-scanning/alert-picker`;
var codeScanningAlertPath = ({ owner, repo, alertNumber }) => `/${encodePart(owner)}/${encodePart(repo)}/security/code-scanning/${alertNumber}`;
var codeScanningOrgRepositoryListPath = ({ org }) => `/orgs/${encodePart(org)}/security/alerts/code-scanning/repository-list.json`;
var businessOrgsSuggestionsPath = ({ businessSlug }) => `/enterprises/${encodePart(businessSlug)}/organizations/suggestions`;
var businessOrgsSuggestionsValidatePath = ({ businessSlug }) => `/enterprises/${encodePart(businessSlug)}/organizations/suggestions/validate`;
var codespacesPath = () => "/codespaces/";
var pullRequestApplyAutomatedSuggestionPath = ({ basePath, automatedReviewCommentId }) => {
	return `${basePath}/automated_review_comments/${automatedReviewCommentId}/apply_suggestion`;
};
var pullRequestDismissAutomatedReviewCommentPath = ({ basePath, automatedReviewCommentId }) => {
	return `${basePath}/automated_review_comments/${automatedReviewCommentId}/dismiss`;
};
var pullRequestReopenAutomatedReviewCommentPath = ({ basePath, automatedReviewCommentId }) => {
	return `${basePath}/automated_review_comments/${automatedReviewCommentId}/reopen`;
};
var pullRequestFeedbackAutomatedReviewCommentPath = ({ basePath, automatedReviewCommentId }) => {
	return `${basePath}/automated_review_comments/${automatedReviewCommentId}/feedback`;
};
export { migrationWorkflowsPath as $, cweHovercardPath as A, repoStargazersPath as At, encodePart as B, tagsPath as Bt, commitPath as C, repoCommitActivityInsightsPath as Ct, commitsPathByAuthor as D, repoModelsPromptPath as Dt, commitsPath as E, repoIssuesPath as Et, dependencyGraphPackageHovercardPath as F, repositoryStatsPath as Ft, invitationsPath as G, treeListPath as Gt, forksListPath as H, toggleGenericFeaturePath as Ht, discussionHovercardPath as I, repositoryTreePath as It, issueLinkedPullRequestHovercardPath as J, userPRFileTreeVisibilitySettingPath as Jt, issueAgentTasksPath as K, userHovercardPath as Kt, dismissRepositoryNoticePathPath as L, securityAlertHovercardPath as Lt, deferredMetadataPath as M, repositoryDeployPath as Mt, deleteBlobPath as N, repositoryParticipationPath as Nt, comparePath as O, repoOverviewUrl as Ot, dependabotAlertHovercardPath as P, repositoryPath as Pt, migrateImmutableActionsPath as Q, dismissUserNoticePath as R, shortcutsPath as Rt, commitHovercardPath as S, repoAccessSettingsPath as St, commitsByAuthor as T, repoDefaultBrachUrl as Tt, getRelativeHref as U, trackedInHovercardPath as Ut, fetchAndMergePath as V, teamHovercardPath as Vt, integrationHovercardPath as W, trackingHovercardPath as Wt, marketplaceActionPath as X, issuePath as Y, mergeabilityCheckPath as Z, codeScanningAlertPath as _, pullRequestFeedbackAutomatedReviewCommentPath as _t, blobPath as a, orgHovercardPath as at, codeownersErrorPath as b, pullRequestProcessingIndicatorPath as bt, branchPath as c, ownerPath as ct, businessOrgsSuggestionsValidatePath as d, projectHovercardPath as dt, modelPromptPath as et, checkTagNameExistsPath as f, pullRequestApplyAutomatedSuggestionPath as ft, codeNavigationPath as g, pullRequestDockedPanelWidthSettingPath as gt, codeNavSearchPath as h, pullRequestDismissAutomatedReviewCommentPath as ht, blobDetectLanguage as i, orgBlockedUsersPath as it, deferredASTPath as j, repositoryDefaultBranchPath as jt, copilotHovercardPath as k, repoPullRequestsPath as kt, branchesPath as l, parentPath as lt, codeNavGeneralSearchPath as m, pullRequestChangesPath as mt, advisoryHovercardPath as n, newRepoPath as nt, blobSidePanelMetadataPath as o, orgTopicReposPath as ot, checkTagStatePath as p, pullRequestChangesCommitRangePath as pt, issueHovercardPath as q, userIdHovercardPath as qt, blamePath as r, newRulesetPath as rt, branchAndTagCountPath as s, ownerAvatarPath as st, achievementHovercardPath as t, newPullRequestPath as tt, businessOrgsSuggestionsPath as u, profileHighlightHovercardPath as ut, codeScanningAlertPickerPath as v, pullRequestFileTreeWidthSettingPath as vt, commitStatusDetailsPath as w, repoContributorsPath as wt, codespacesPath as x, pullRequestReopenAutomatedReviewCommentPath as xt, codeScanningOrgRepositoryListPath as y, pullRequestPath as yt, editBlobPath as z, sponsorsListingHovercardPath as zt };
