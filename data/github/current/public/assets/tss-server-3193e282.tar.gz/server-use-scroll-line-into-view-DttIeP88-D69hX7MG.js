import React, { useEffect, useEffectEvent } from "react";
import { jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CurrentStyledBlobContext = React.createContext({});
CurrentStyledBlobContext.displayName = "CurrentStyledBlobContext";
var defaultBlob = {
	colorizedLines: null,
	rawLines: null,
	stylingDirectives: void 0
};
function CurrentStyledBlobProvider({ blob, children }) {
	return /* @__PURE__ */ jsxs(CurrentStyledBlobContext, {
		value: blob ?? defaultBlob,
		children: [
			" ",
			children,
			" "
		]
	});
}
CurrentStyledBlobProvider.displayName = "CurrentStyledBlobProvider";
function useCurrentStyledBlob() {
	return React.use(CurrentStyledBlobContext);
}
var scrollLineIntoViewEvent = "react_blob_view_scroll_line_into_view";
function useScrollLineIntoView(callback) {
	const $ = c(3);
	const eventHandler = useEffectEvent(callback);
	let t0;
	if ($[0] !== eventHandler) {
		t0 = () => {
			const handleScrollEvent = (event) => eventHandler(event.detail);
			window.addEventListener(scrollLineIntoViewEvent, handleScrollEvent);
			return () => {
				window.removeEventListener(scrollLineIntoViewEvent, handleScrollEvent);
			};
		};
		$[0] = eventHandler;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[2] = t1;
	} else t1 = $[2];
	useEffect(t0, t1);
}
function scrollLineIntoView(payload) {
	window.dispatchEvent(new CustomEvent(scrollLineIntoViewEvent, { detail: payload }));
}
export { useScrollLineIntoView as i, scrollLineIntoView as n, useCurrentStyledBlob as r, CurrentStyledBlobProvider as t };
