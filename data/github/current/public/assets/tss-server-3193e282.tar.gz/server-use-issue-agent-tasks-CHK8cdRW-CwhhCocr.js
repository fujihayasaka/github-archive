import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as reactFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { K as issueAgentTasksPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { useEffect, useMemo } from "react";
import { c } from "react/compiler-runtime";
import throttle$1 from "lodash-es/throttle.js";
var THROTTLE_INTERVAL_MS = 2e3;
var getQueryKey = (owner, repo, issueNumber) => [
	"issue-agent-tasks",
	owner,
	repo,
	issueNumber
];
/**
* Fetches agent tasks for a given issue via the REST API.
* Subscribes to the alive channel returned in the API response (`issue_update_channel`)
* to refetch tasks when real-time updates arrive.
*/
function useIssueAgentTasks(t0) {
	const $ = c(28);
	const { owner, repo, issueNumber } = t0;
	const queryClient = useQueryClient();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		$[0] = t1;
	} else t1 = $[0];
	const copilotMissionControlDecoupledMode = t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = isFeatureEnabled("issue_cca_visualization");
		$[1] = t2;
	} else t2 = $[1];
	const issueCcaVisualization = t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = isFeatureEnabled("issue_cca_visualization_decoupled_mode");
		$[2] = t3;
	} else t3 = $[2];
	const isVisualizationEnabled = issueCcaVisualization || copilotMissionControlDecoupledMode && t3;
	let t4;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = isVisualizationEnabled || isFeatureEnabled("issue_cca_visualization_session_panel");
		$[3] = t4;
	} else t4 = $[3];
	const isAgentTasksFetchEnabled = t4;
	let t5;
	if ($[4] !== issueNumber || $[5] !== owner || $[6] !== repo) {
		t5 = isAgentTasksFetchEnabled && owner.length > 0 && repo.length > 0 && Number.isInteger(issueNumber) && issueNumber > 0;
		$[4] = issueNumber;
		$[5] = owner;
		$[6] = repo;
		$[7] = t5;
	} else t5 = $[7];
	const enabled = t5;
	let t6;
	if ($[8] !== issueNumber || $[9] !== owner || $[10] !== repo) {
		t6 = getQueryKey(owner, repo, issueNumber);
		$[8] = issueNumber;
		$[9] = owner;
		$[10] = repo;
		$[11] = t6;
	} else t6 = $[11];
	let t7;
	if ($[12] !== issueNumber || $[13] !== owner || $[14] !== repo) {
		t7 = async () => {
			const response = await reactFetchJSON(issueAgentTasksPath({
				owner,
				repo,
				issueNumber
			}));
			if (!response.ok) throw new Error(`Failed to fetch agent tasks: ${response.status}`);
			return await response.json();
		};
		$[12] = issueNumber;
		$[13] = owner;
		$[14] = repo;
		$[15] = t7;
	} else t7 = $[15];
	let t8;
	if ($[16] !== enabled || $[17] !== t6 || $[18] !== t7) {
		t8 = {
			enabled,
			queryKey: t6,
			queryFn: t7,
			retry: false
		};
		$[16] = enabled;
		$[17] = t6;
		$[18] = t7;
		$[19] = t8;
	} else t8 = $[19];
	const queryResult = useQuery(t8);
	let t9;
	if ($[20] !== issueNumber || $[21] !== owner || $[22] !== queryClient || $[23] !== repo) {
		t9 = throttle$1(() => queryClient.invalidateQueries({
			queryKey: getQueryKey(owner, repo, issueNumber),
			exact: true,
			refetchType: "active"
		}), THROTTLE_INTERVAL_MS, {
			leading: false,
			trailing: true
		});
		$[20] = issueNumber;
		$[21] = owner;
		$[22] = queryClient;
		$[23] = repo;
		$[24] = t9;
	} else t9 = $[24];
	const throttledRefetch = t9;
	let t10;
	let t11;
	if ($[25] !== throttledRefetch) {
		t10 = () => () => throttledRefetch.cancel();
		t11 = [throttledRefetch];
		$[25] = throttledRefetch;
		$[26] = t10;
		$[27] = t11;
	} else {
		t10 = $[26];
		t11 = $[27];
	}
	useEffect(t10, t11);
	const aliveChannel = queryResult.data?.issue_update_channel;
	useAlive(enabled ? aliveChannel : void 0, throttledRefetch);
	return queryResult;
}
export { useIssueAgentTasks as t };
