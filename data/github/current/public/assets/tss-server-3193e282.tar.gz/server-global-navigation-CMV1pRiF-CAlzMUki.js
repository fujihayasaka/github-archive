var pendingOperation = null;
var registeredContextRegion = void 0;
/**
* Registers a React-based context region handler with the global navigation system. This will take priority over any custom element-based search.
* Only one context region can be registered at a time. If a pending operation exists,
* it will be executed immediately upon registration.
*
* @param element - The context region actions interface to register
*/
function registerContextRegionHandler(element) {
	if (registeredContextRegion && registeredContextRegion !== element) return;
	registeredContextRegion = element;
	if (pendingOperation) {
		pendingOperation(element);
		pendingOperation = null;
	}
}
/** Reset the registered context region */
function clearRegisteredContextRegion() {
	registeredContextRegion = void 0;
}
function getContextRegion(options) {
	const source = options?.source ?? "both";
	const silent = options?.silent ?? true;
	let contextRegion = null;
	if (source === "element" || source === "both") contextRegion = document.querySelector("context-region");
	if (!contextRegion && (source === "react" || source === "both")) contextRegion = registeredContextRegion ?? null;
	if (!contextRegion) {
		if (!silent) console.error(`The global navigation's context region cannot be found! Make sure the <context-region> element exists on the page before calling any of the global navigation breadcrumb methods.`);
		return null;
	}
	if ("isConnected" in contextRegion && !contextRegion.isConnected) return null;
	if (!contextRegion.pushCrumb || typeof contextRegion.pushCrumb !== "function") return null;
	return contextRegion;
}
var registeredLocalNavigation = void 0;
/**
* Registers a React-based local navigation handler. This allows external code
* to update tab counts through the React tree rather than via direct DOM manipulation.
*/
function registerLocalNavigationHandler(handler) {
	registeredLocalNavigation = handler;
}
function clearRegisteredLocalNavigation() {
	registeredLocalNavigation = void 0;
}
function getLocalNavigation() {
	return registeredLocalNavigation ?? null;
}
/**
* Update a tab's count by a delta. Uses the React-based handler if registered,
* returns false if no handler is available.
*/
function updateNavigationTabCount(tabId, delta) {
	const localNav = getLocalNavigation();
	if (localNav) {
		localNav.updateTabCount(tabId, delta);
		return true;
	}
	return false;
}
export { registerLocalNavigationHandler as a, registerContextRegionHandler as i, clearRegisteredLocalNavigation as n, updateNavigationTabCount as o, getContextRegion as r, clearRegisteredContextRegion as t };
