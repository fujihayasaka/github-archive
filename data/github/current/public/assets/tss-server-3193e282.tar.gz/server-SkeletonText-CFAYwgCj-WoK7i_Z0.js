import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var classes = {
	"SkeletonText": "prc-SkeletonText-SkeletonText--DvUT",
	"SkeletonTextWrapper": "prc-SkeletonText-SkeletonTextWrapper-gfaKQ"
};
function SkeletonText(t0) {
	const $ = c(32);
	let className;
	let maxWidth;
	let rest;
	let style;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({lines: t1, maxWidth, size: t2, className, style, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = maxWidth;
		$[3] = rest;
		$[4] = style;
		$[5] = t1;
		$[6] = t2;
	} else {
		className = $[1];
		maxWidth = $[2];
		rest = $[3];
		style = $[4];
		t1 = $[5];
		t2 = $[6];
	}
	const lines = t1 === void 0 ? 1 : t1;
	const size = t2 === void 0 ? "bodyMedium" : t2;
	if (lines < 2) {
		let t3;
		if ($[7] !== className) {
			t3 = clsx(className, classes.SkeletonText);
			$[7] = className;
			$[8] = t3;
		} else t3 = $[8];
		let t4;
		if ($[9] !== maxWidth || $[10] !== style) {
			t4 = {
				...style,
				maxWidth
			};
			$[9] = maxWidth;
			$[10] = style;
			$[11] = t4;
		} else t4 = $[11];
		let t5;
		if ($[12] !== rest || $[13] !== size || $[14] !== t3 || $[15] !== t4) {
			t5 = /* @__PURE__ */ jsx(SkeletonBox, {
				"data-component": "SkeletonText",
				"data-text-skeleton-size": size,
				width: "100%",
				className: t3,
				style: t4,
				...rest
			});
			$[12] = rest;
			$[13] = size;
			$[14] = t3;
			$[15] = t4;
			$[16] = t5;
		} else t5 = $[16];
		return t5;
	}
	let t3;
	if ($[17] !== maxWidth || $[18] !== style) {
		t3 = {
			...style,
			maxWidth
		};
		$[17] = maxWidth;
		$[18] = style;
		$[19] = t3;
	} else t3 = $[19];
	let t4;
	if ($[20] !== className || $[21] !== lines || $[22] !== rest || $[23] !== size) {
		let t5;
		if ($[25] !== className || $[26] !== rest || $[27] !== size) {
			t5 = (_, index) => /* @__PURE__ */ jsx(SkeletonBox, {
				"data-component": "SkeletonText",
				"data-in-multiline": "true",
				"data-text-skeleton-size": size,
				className: clsx(className, classes.SkeletonText),
				...rest
			}, index);
			$[25] = className;
			$[26] = rest;
			$[27] = size;
			$[28] = t5;
		} else t5 = $[28];
		t4 = Array.from({ length: lines }, t5);
		$[20] = className;
		$[21] = lines;
		$[22] = rest;
		$[23] = size;
		$[24] = t4;
	} else t4 = $[24];
	let t5;
	if ($[29] !== t3 || $[30] !== t4) {
		t5 = /* @__PURE__ */ jsx("div", {
			"data-component": "multilineContainer",
			className: classes.SkeletonTextWrapper,
			style: t3,
			children: t4
		});
		$[29] = t3;
		$[30] = t4;
		$[31] = t5;
	} else t5 = $[31];
	return t5;
}
export { SkeletonText as t };
