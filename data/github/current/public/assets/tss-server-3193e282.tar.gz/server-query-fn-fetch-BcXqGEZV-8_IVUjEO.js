import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { i as getClientVersion } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { a as reportTraceData, i as reactFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
function getDocumentHtmlSafeNonces(document) {
	const nonces = [...document.querySelectorAll("meta[name=html-safe-nonce]")].map((meta) => meta.content);
	if (nonces.length < 1) throw new Error("could not find html-safe-nonce on document");
	return nonces;
}
var ResponseError$1 = class extends Error {
	response;
	constructor(message, response) {
		super(`${message} for HTTP ${response.status}`);
		this.response = response;
		this.name = "ResponseError";
	}
};
function verifyResponseHtmlSafeNonce(nonces, response, allowJson = false) {
	const contentType = response.headers.get("content-type") || "";
	if (!allowJson && !contentType.startsWith("text/html")) throw new ResponseError$1(`expected response with text/html, but was ${contentType}`, response);
	if (allowJson && !(contentType.startsWith("text/html") || contentType.startsWith("application/json"))) throw new ResponseError$1(`expected response with text/html or application/json, but was ${contentType}`, response);
	const responseNonce = response.headers.get("x-html-safe");
	if (!responseNonce) throw new ResponseError$1(`missing X-HTML-Safe nonce`, response);
	else if (!nonces.includes(responseNonce)) throw new ResponseError$1(`response X-HTML-Safe nonce did not match`, response);
}
var VERSION_MISMATCH_RATE_LIMIT_DURATION = 1e3 * 60 * 60 * 24;
var STORAGE_KEY = "VERSION_MISMATCH_LAST_TRIGGERED";
var rateLimitStorage = safeStorage("localStorage", {
	ttl: VERSION_MISMATCH_RATE_LIMIT_DURATION + 1e3 * 60 * 60,
	throwQuotaErrorsOnSet: false
});
var inMemoryFallback = null;
/**
* Global rate limiter for version mismatch detection.
* Ensures version mismatch callbacks are only triggered once per 24 hours
* across all apps regardless of client version.
*/
var VersionMismatchRateLimiter = class {
	/**
	* Checks if a version mismatch trigger is allowed.
	* Returns true if it's been more than 24 hours since the last trigger,
	* or if this is the first trigger.
	*
	* @returns true if trigger is allowed, false if rate limited
	*/
	canTrigger() {
		const lastTriggerTime = this.getLastTriggerTime();
		if (lastTriggerTime === null) return true;
		return Date.now() - lastTriggerTime >= VERSION_MISMATCH_RATE_LIMIT_DURATION;
	}
	/**
	* Records that a version mismatch trigger occurred.
	* Stores the timestamp in localStorage with fallback to in-memory storage.
	*/
	recordTrigger() {
		const timestamp = Date.now();
		rateLimitStorage.setItem(STORAGE_KEY, timestamp.toString());
		inMemoryFallback = timestamp;
	}
	/**
	* Gets the timestamp of the last version mismatch trigger.
	* Checks localStorage first, then falls back to in-memory storage.
	*
	* @returns Timestamp of last trigger, or null if never triggered
	*/
	getLastTriggerTime() {
		const storedValue = rateLimitStorage.getItem(STORAGE_KEY);
		if (storedValue) {
			const timestamp = parseInt(storedValue, 10);
			return isNaN(timestamp) ? null : timestamp;
		}
		return inMemoryFallback;
	}
	/**
	* Clears the rate limiting data.
	* Useful for testing or manual reset scenarios.
	*/
	clearTriggerRecord() {
		rateLimitStorage.removeItem(STORAGE_KEY);
		inMemoryFallback = null;
	}
};
var versionMismatchRateLimiter = new VersionMismatchRateLimiter();
var VersionMismatchDetector = class {
	#appConfigs = /* @__PURE__ */ new Map();
	registerApp(appName, config) {
		this.#appConfigs.set(appName, config);
	}
	unregisterApp(appName) {
		this.#appConfigs.delete(appName);
	}
	checkResponse(response, appName) {
		if (response.headers.get("X-GitHub-Version-Mismatch") !== "true") return false;
		if (!isFeatureEnabled("react_version_mismatch_detection")) return false;
		if (!versionMismatchRateLimiter.canTrigger()) return false;
		const details = {
			clientVersion: getClientVersion(),
			serverVersion: response.headers.get("X-GitHub-Server-Version") || void 0,
			requestUrl: response.url,
			responseHeaders: response.headers,
			appName
		};
		versionMismatchRateLimiter.recordTrigger();
		if (appName) {
			const config = this.#appConfigs.get(appName);
			if (config) {
				config.onMismatchDetected(details);
				return true;
			}
		} else {
			let handled = false;
			for (const [registeredAppName, config] of this.#appConfigs.entries()) {
				const appDetails = {
					...details,
					appName: registeredAppName
				};
				config.onMismatchDetected(appDetails);
				handled = true;
			}
			return handled;
		}
		return false;
	}
};
var versionMismatchDetector = new VersionMismatchDetector();
/**
* Stores a Response object within an Error, so that the application
* can access the response when an error is thrown.
*
* For example, a `queryFn` can throw the error like so:
*
* if (!response.ok) throw new ResponseError(response.statusText, response)
*
* which should cause the Error to be thrown from within the loader.
*
* Then an ErrorBoundary can consume the route error and access the response, like so:
*
* const routeError = useRouteError()
* const responseStatus = isResponseError(routeError) ? routeError.response.status : undefined
*
*/
var ResponseError = class extends Error {
	response;
	constructor(message, response) {
		super(message);
		this.response = response;
		this.name = "ResponseError";
	}
};
/**
* Type guard for checking to see if a parameter is a ResponseError object
*/
function isResponseError(e) {
	return e instanceof ResponseError;
}
/**
* Intended for use by `queryFn`s that need to make fetch requests.
* In addition to calling `reactFetchJSON` to add the appropriate react headers to the request,
* this function will also check the response status and throw a `ResponseError` if necessary,
* as well as hooking into `reportTraceData`.
*/
async function queryFnFetch({ queryDeps: { pathname, searchParams, init } }, { encodePath } = {}) {
	const response = await reactFetchJSON(serializePath(encodePath ? encodeParts(pathname) : pathname, searchParams), init);
	versionMismatchDetector.checkResponse(response);
	if (!response.ok) throw new ResponseError(response.statusText, response);
	const json = await response.json();
	reportTraceData(json);
	return json;
}
/**
* Intended for use by `queryFn`s that need to make fetch requests and verify HTML safe nonces.
*/
async function queryFnFetchWithSafeHTMLNonce({ queryDeps: { pathname, searchParams, init } }) {
	const response = await reactFetchJSON(serializePath(pathname, searchParams), init);
	versionMismatchDetector.checkResponse(response);
	if (!response.ok) throw new ResponseError(response.statusText, response);
	verifyResponseHtmlSafeNonce(getDocumentHtmlSafeNonces(document), response, true);
	const json = await response.json();
	reportTraceData(json);
	return json;
}
/**
* Serializes the given `pathname` and `searchParams` to a string.
*/
function serializePath(pathname, searchParams) {
	const path = [pathname];
	const search = removeNils(searchParams).toString();
	if (search) path.push(search.toString());
	return path.join("?");
}
/**
* Removes any search-params with a value of `null` or `undefined` from the given `searchParams` object.
* This is necessary as we construct `queryDeps.searchParams` with code like `{page: searchParams.get('page')}`,
* which will result in a value of `null` if the key is not present in the `searchParams` object and
* URLSeachParams.toString() will serialize `null` values as the string "null", which is not the desired behavior.
*/
function removeNils(searchParams) {
	if (searchParams instanceof URLSearchParams) return searchParams;
	if (typeof searchParams === "string") return new URLSearchParams(searchParams);
	const result = new URLSearchParams();
	if (searchParams === void 0 || searchParams === null) return result;
	for (const [key, value] of Array.isArray(searchParams) ? searchParams : Object.entries(searchParams)) if (value !== void 0 && value !== null) result.append(key, value);
	return result;
}
function encodeParts(part) {
	return part.split("/").map(encodeURIComponent).join("/");
}
export { queryFnFetch as n, queryFnFetchWithSafeHTMLNonce as r, isResponseError as t };
