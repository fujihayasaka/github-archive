performance.mark("js-parse-end:server-tree-delete-dMRTwi9U-CCdX3NUA.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { i as DeleteHeaderButtons, r as CodeViewHeaderDataRouter } from "./server-NavigationMenu-CKgcoy5c-Bbjbrr6N.js";
import { t as CodeView } from "./server-CodeView-CCvwX-NJ-CNmyXFpi.js";
import { t as DeleteViewContent } from "./server-DeleteViewContent-DP9ZdPXB-BLPhb_Wk.js";
import { t as codeViewTreeDeleteRoute } from "./server-code-view-tree-delete-route-BKfSJUYK-C-1_W8Qg.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:tree-delete-dMRTwi9U.js");
function CodeViewTreeDeleteEntrypoint() {
	const $ = c(5);
	const { data: payload } = useRouteQuery(codeViewTreeDeleteRoute, "mainQuery");
	let t0;
	if ($[0] !== payload) {
		const actions = jsx(DeleteHeaderButtons, {
			webCommitInfo: payload.webCommitInfo,
			isBlob: payload.deleteInfo.isBlob
		});
		let t1;
		if ($[2] !== payload.deleteInfo || $[3] !== payload.webCommitInfo) {
			t1 = () => jsx(DeleteViewContent, {
				deleteInfo: payload.deleteInfo,
				webCommitInfo: payload.webCommitInfo
			});
			$[2] = payload.deleteInfo;
			$[3] = payload.webCommitInfo;
			$[4] = t1;
		} else t1 = $[4];
		t0 = jsxs(Fragment, { children: [jsx(CodeViewHeaderDataRouter, {
			narrowActions: actions,
			wideActions: actions,
			commitish: payload.refInfo.name,
			path: payload.path,
			modelsRepoIntegrationEnabled: payload.modelsRepoIntegrationEnabled
		}), jsx(CodeView, {
			payload,
			action: "tree",
			children: t1
		})] });
		$[0] = payload;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
CodeViewTreeDeleteEntrypoint.displayName = "CodeViewTreeDeleteEntrypoint";
var SplitComponent = CodeViewTreeDeleteEntrypoint;
export { SplitComponent as component };
