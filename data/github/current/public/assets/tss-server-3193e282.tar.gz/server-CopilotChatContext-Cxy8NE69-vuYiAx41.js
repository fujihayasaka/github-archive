import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { a as isEnterprise, d as sendCustomMetric, o as isStaff, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { r as CopilotAuthTokenProvider } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { n as stringifyObjectValues, t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { Gt as treeListPath, i as blobDetectLanguage } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { B as isRepository, D as getCustomInstructionsFromReferences, E as getCopilotExperiments, F as hasCustomInstructions, G as makeOrgInstructionsReference, H as makeCAPIRequest, I as hasCustomInstructionsAsync, O as getCustomInstructionsFromReferencesAsync, P as getThreadStaticSuggestions, S as customInstructionsOwnersFromReferencesAsync, T as findAuthor, V as isThreadOlderThan4Hours, Y as referenceArraysAreEqual, Z as referenceID, a as CopilotLicenseType, b as copilotFeatureFlags, d as ERROR_MSG, g as SUPPORTED_FUNCTIONS, i as CopilotChatIntents, l as ERRORS_BY_STATUS, o as CopilotPlan, p as MESSAGE_STREAMING_ERROR_TYPES, q as makeRepositoryReference, t as COPILOT_BILLING_SETTINGS_URL, tt as referencesAreEqual, u as ERRORS_BY_TYPE, x as customInstructionsOwnersFromReferences, y as buildMessage, z as isFileReference } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { c as useObservedState, i as useDerivedObservable, s as useObservableValueRef } from "./server-react-observable-0DQDiDnT-BDNMoELa.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { t as CopilotChatMessageStreamer } from "./server-copilot-chat-message-streamer-DwhhquJZ-Be7HnjXD.js";
import { i as customCopilotMatchesId } from "./server-custom-copilots-helpers-DK-3dkih-DB1BoMiI.js";
import { n as clearSessionStorageByKeyPrefix } from "./server-use-session-storage-C2f28u9L-cHRWNGhU.js";
import React, { createContext, use, useCallback, useEffect, useLayoutEffect, useMemo, useReducer, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CopilotSpaceSelectionContext = createContext(null);
CopilotSpaceSelectionContext.displayName = "CopilotSpaceSelectionContext";
function CopilotSpaceSelectionProvider(t0) {
	const $ = c(7);
	const { selectedThreadId, children } = t0;
	const [selectedCopilotSpaceId, setSelectedCopilotSpaceId] = useState();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (id) => {
			setSelectedCopilotSpaceId(id);
		};
		$[0] = t1;
	} else t1 = $[0];
	const updateSelectedCopilotSpaceId = t1;
	let t2;
	if ($[1] !== selectedCopilotSpaceId || $[2] !== selectedThreadId) {
		t2 = {
			selectedCopilotSpaceId,
			setSelectedCopilotSpaceId: updateSelectedCopilotSpaceId,
			selectedThreadId
		};
		$[1] = selectedCopilotSpaceId;
		$[2] = selectedThreadId;
		$[3] = t2;
	} else t2 = $[3];
	const value = t2;
	let t3;
	if ($[4] !== children || $[5] !== value) {
		t3 = jsx(CopilotSpaceSelectionContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
/**
* Hook to access and modify copilot space selection state, intended
* for consumption by useSpaceSelection
* @returns The copilot space selection context value
* @throws Error if used outside of CopilotSpaceSelectionProvider
*/
CopilotSpaceSelectionProvider.displayName = "CopilotSpaceSelectionProvider";
function useCopilotSpaceSelection() {
	const context = use(CopilotSpaceSelectionContext);
	if (!context) throw new Error("useCopilotSpaceSelection must be used within a CopilotSpaceSelectionProvider");
	return context;
}
function copilotSpaceIdFromThread(thread) {
	if (!thread || !thread.customCopilotID || !thread.customCopilotOwner) return null;
	return {
		id: thread.customCopilotID,
		owner: thread.customCopilotOwner
	};
}
function useCopilotChatEntitlement(initialLicenseType, initialPlan, initialQuotas) {
	const $ = c(24);
	const client = useQueryClient();
	let t0;
	if ($[0] !== client) {
		t0 = () => client.invalidateQueries({ queryKey: ["copilot-chat", "entitlement"] });
		$[0] = client;
		$[1] = t0;
	} else t0 = $[1];
	const invalidateEntitlement = t0;
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = ["copilot-chat", "entitlement"];
		$[2] = t1;
	} else t1 = $[2];
	const t2 = initialLicenseType === CopilotLicenseType.LicensedLimited || initialLicenseType === CopilotLicenseType.LicensedFull && copilotFeatureFlags.premiumRequestQuotasEnabled;
	let t3;
	if ($[3] !== initialLicenseType || $[4] !== initialPlan || $[5] !== initialQuotas) {
		t3 = {
			licenseType: initialLicenseType,
			plan: initialPlan,
			quotas: initialQuotas
		};
		$[3] = initialLicenseType;
		$[4] = initialPlan;
		$[5] = initialQuotas;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== t2 || $[8] !== t3) {
		t4 = {
			queryKey: t1,
			queryFn: _temp$1,
			enabled: t2,
			placeholderData: t3,
			staleTime: 3e5
		};
		$[7] = t2;
		$[8] = t3;
		$[9] = t4;
	} else t4 = $[9];
	const { data } = useQuery(t4);
	const license = data?.licenseType ?? initialLicenseType;
	const plan = data?.plan ?? initialPlan;
	const quotas = data?.quotas ?? initialQuotas;
	const remainingChatPercentage = quotas?.remaining.chatPercentage;
	const remainingPremiumPercentage = quotas?.remaining.premiumInteractionsPercentage;
	let t5;
	if ($[10] !== initialLicenseType || $[11] !== invalidateEntitlement || $[12] !== license || $[13] !== remainingChatPercentage || $[14] !== remainingPremiumPercentage) {
		t5 = (origin) => {
			if (initialLicenseType === CopilotLicenseType.LicensedLimited || initialLicenseType === CopilotLicenseType.LicensedFull && copilotFeatureFlags.premiumRequestQuotasEnabled) {
				if (copilotFeatureFlags.reduceChatQuotaChecks && license === CopilotLicenseType.LicensedLimited && remainingChatPercentage !== void 0 && remainingChatPercentage > 50 || license === CopilotLicenseType.LicensedFull && remainingPremiumPercentage !== void 0 && remainingPremiumPercentage > 20) return;
				invalidateEntitlement();
				sendEvent("dotcom_chat.activate", {
					target: "ENTITLEMENTS_RELOAD",
					origin
				});
			}
		};
		$[10] = initialLicenseType;
		$[11] = invalidateEntitlement;
		$[12] = license;
		$[13] = remainingChatPercentage;
		$[14] = remainingPremiumPercentage;
		$[15] = t5;
	} else t5 = $[15];
	const reloadQuota = t5;
	const t6 = data?.quotas;
	const t7 = data?.trial;
	let t8;
	if ($[16] !== license || $[17] !== plan || $[18] !== t6 || $[19] !== t7) {
		t8 = new CopilotChatEntitlement(license, plan, t6, t7);
		$[16] = license;
		$[17] = plan;
		$[18] = t6;
		$[19] = t7;
		$[20] = t8;
	} else t8 = $[20];
	let t9;
	if ($[21] !== reloadQuota || $[22] !== t8) {
		t9 = [t8, reloadQuota];
		$[21] = reloadQuota;
		$[22] = t8;
		$[23] = t9;
	} else t9 = $[23];
	return t9;
}
async function _temp$1() {
	const response = await verifiedFetchJSON("/github-copilot/chat/entitlement");
	if (!response.ok) throw new Error(`Failed to retrieve Copilot chat entitlement (${response.status} on ${response.url})`);
	return await response.json();
}
var CopilotChatEntitlement = class {
	licenseType;
	plan;
	quotas;
	trial;
	constructor(licenseType, plan, quotas, trial) {
		this.licenseType = licenseType;
		this.plan = plan;
		this.quotas = quotas;
		this.trial = trial;
	}
	isLicensed() {
		return this.licenseType && this.licenseType !== CopilotLicenseType.Unlicensed;
	}
	canPurchaseAdditionalQuota() {
		return this.licenseType !== CopilotLicenseType.LicensedLimited && copilotFeatureFlags.premiumRequestQuotasEnabled && (this.plan === CopilotPlan.IndividualPro || this.plan === CopilotPlan.IndividualProPlus || this.plan === CopilotPlan.IndividualStudent);
	}
	canUpgradePlan() {
		return this.licenseType === CopilotLicenseType.LicensedLimited || copilotFeatureFlags.premiumRequestQuotasEnabled && (this.plan === CopilotPlan.IndividualPro || this.plan === CopilotPlan.IndividualStudent);
	}
	chatQuotaRemaining() {
		return copilotFeatureFlags.premiumRequestQuotasEnabled && this.quotas?.remaining.chatPercentage !== void 0 ? this.quotas?.remaining.chatPercentage ?? 0 : this.quotas?.remaining.chat ?? 0;
	}
	premiumInteractionsQuotaRemaining() {
		return this.quotas?.remaining.premiumInteractionsPercentage ?? 0;
	}
	eligibleForTrial() {
		return this.trial?.eligible ?? false;
	}
};
function isPaidUser(copilotPlan) {
	return Boolean(copilotPlan && copilotPlan !== CopilotPlan.IndividualFree);
}
var EntitlementContext = createContext(void 0);
EntitlementContext.displayName = "EntitlementContext";
function EntitlementProvider(t0) {
	const $ = c(30);
	const { children, initialLicenseType, initialPlan, initialQuotas } = t0;
	const [entitlement, reloadQuota] = useCopilotChatEntitlement(initialLicenseType, initialPlan, initialQuotas);
	const licenseType = entitlement.licenseType;
	const plan = entitlement.plan ?? null;
	let t1;
	if ($[0] !== entitlement) {
		t1 = entitlement.chatQuotaRemaining() ?? Infinity;
		$[0] = entitlement;
		$[1] = t1;
	} else t1 = $[1];
	const chatQuotaRemaining = t1;
	let t2;
	if ($[2] !== entitlement) {
		t2 = entitlement.premiumInteractionsQuotaRemaining() ?? Infinity;
		$[2] = entitlement;
		$[3] = t2;
	} else t2 = $[3];
	const premiumChatQuotaRemaining = t2;
	let t3;
	if ($[4] !== entitlement.quotas) {
		t3 = entitlement.quotas?.resetDate ? new Date(entitlement.quotas.resetDate).toLocaleDateString("en-US", {
			year: "numeric",
			month: "long",
			day: "numeric"
		}) : "";
		$[4] = entitlement.quotas;
		$[5] = t3;
	} else t3 = $[5];
	const resetDate = t3;
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = isFeatureEnabled("copilot_simulate_quota_exceeded");
		$[6] = t4;
	} else t4 = $[6];
	const simulateQuotaExceeded = t4;
	const isLicensedLimited = simulateQuotaExceeded || licenseType === CopilotLicenseType.LicensedLimited;
	let t5;
	if ($[7] !== entitlement) {
		t5 = entitlement.canPurchaseAdditionalQuota();
		$[7] = entitlement;
		$[8] = t5;
	} else t5 = $[8];
	const canPurchaseAdditionalQuota = t5;
	let t6;
	if ($[9] !== entitlement) {
		t6 = entitlement.canUpgradePlan();
		$[9] = entitlement;
		$[10] = t6;
	} else t6 = $[10];
	const canUpgradePlan = t6;
	const chatQuotaExceeded = simulateQuotaExceeded || isLicensedLimited && chatQuotaRemaining <= 0;
	const premiumInteractionsQuotaExceeded = copilotFeatureFlags.premiumRequestQuotasEnabled && !isLicensedLimited && premiumChatQuotaRemaining <= 0;
	const overagesEnabled = entitlement.quotas?.overagesEnabled ?? false;
	let t7;
	if ($[11] !== entitlement) {
		t7 = entitlement.eligibleForTrial();
		$[11] = entitlement;
		$[12] = t7;
	} else t7 = $[12];
	const eligibleForTrial = t7;
	let t8;
	if ($[13] !== canPurchaseAdditionalQuota || $[14] !== canUpgradePlan || $[15] !== chatQuotaExceeded || $[16] !== chatQuotaRemaining || $[17] !== eligibleForTrial || $[18] !== isLicensedLimited || $[19] !== licenseType || $[20] !== overagesEnabled || $[21] !== plan || $[22] !== premiumChatQuotaRemaining || $[23] !== premiumInteractionsQuotaExceeded || $[24] !== reloadQuota || $[25] !== resetDate) {
		t8 = {
			licenseType,
			chatQuotaRemaining,
			premiumChatQuotaRemaining,
			resetDate,
			isLicensedLimited,
			chatQuotaExceeded,
			premiumInteractionsQuotaExceeded,
			reloadQuota,
			plan,
			canPurchaseAdditionalQuota,
			canUpgradePlan,
			overagesEnabled,
			eligibleForTrial
		};
		$[13] = canPurchaseAdditionalQuota;
		$[14] = canUpgradePlan;
		$[15] = chatQuotaExceeded;
		$[16] = chatQuotaRemaining;
		$[17] = eligibleForTrial;
		$[18] = isLicensedLimited;
		$[19] = licenseType;
		$[20] = overagesEnabled;
		$[21] = plan;
		$[22] = premiumChatQuotaRemaining;
		$[23] = premiumInteractionsQuotaExceeded;
		$[24] = reloadQuota;
		$[25] = resetDate;
		$[26] = t8;
	} else t8 = $[26];
	const value = t8;
	let t9;
	if ($[27] !== children || $[28] !== value) {
		t9 = jsx(EntitlementContext, {
			value,
			children
		});
		$[27] = children;
		$[28] = value;
		$[29] = t9;
	} else t9 = $[29];
	return t9;
}
EntitlementProvider.displayName = "EntitlementProvider";
var useEntitlement = () => {
	const context = use(EntitlementContext);
	if (!context) throw new Error("useEntitlement must be used within EntitlementProvider");
	return context;
};
var sessionStorage = safeStorage("sessionStorage");
var RESTORED_CHAT_STATE_EXPIRY = 1e3 * 8;
/**
* No need to restore chat state if we're in immersive mode, and if there's no thread id, there can't be any messages to restore.
*/
function shouldRestoreChatState(threadId, mode) {
	return !!threadId && mode === "assistive";
}
var RESTORED_CHAT_DATA_KEY = "restored-chat-messages";
/**
* Adds event listeners to save the chat state to session storage when the user navigates between GitHub pages.
* This is used to restore the chat state so we don't show the user a loading spinner whenever
* a hard navigation takes place.
*/
function useSaveChatState(messages, threadId, threads, mode) {
	const $ = c(9);
	let t0;
	if ($[0] !== mode || $[1] !== threadId) {
		t0 = shouldRestoreChatState(threadId, mode);
		$[0] = mode;
		$[1] = threadId;
		$[2] = t0;
	} else t0 = $[2];
	const restoreChatState = t0;
	let t1;
	let t2;
	if ($[3] !== messages || $[4] !== restoreChatState || $[5] !== threadId || $[6] !== threads) {
		t1 = () => {
			if (!restoreChatState) return;
			const replacer = _temp;
			const onUnloadChat = () => {
				if (!messages?.length || !threadId) return;
				const threadTitle = threads.get(threadId)?.name;
				const state = {
					expiry: Date.now() + RESTORED_CHAT_STATE_EXPIRY,
					restoredMessages: messages,
					threadId,
					threadTitle
				};
				sessionStorage.setItem(RESTORED_CHAT_DATA_KEY, JSON.stringify(state, replacer));
			};
			window.addEventListener("turbo:before-fetch-response", onUnloadChat);
			window.addEventListener("beforeunload", onUnloadChat);
			window.addEventListener("popstate", onUnloadChat);
			return () => {
				window.removeEventListener("turbo:before-fetch-response", onUnloadChat);
				window.removeEventListener("beforeunload", onUnloadChat);
				window.removeEventListener("popstate", onUnloadChat);
			};
		};
		t2 = [
			messages,
			restoreChatState,
			threadId,
			threads
		];
		$[3] = messages;
		$[4] = restoreChatState;
		$[5] = threadId;
		$[6] = threads;
		$[7] = t1;
		$[8] = t2;
	} else {
		t1 = $[7];
		t2 = $[8];
	}
	useEffect(t1, t2);
}
/**
* Parse the restored chat state from session storage and return it if it's valid.
*/
function _temp(key, value) {
	if (key === "childMessages" || key === "parentMessage") return;
	else return value;
}
function useRestoredChatState(threadId, mode) {
	const $ = c(4);
	const restoreChatState = shouldRestoreChatState(threadId, mode);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		const restoredChatState = sessionStorage.getItem(RESTORED_CHAT_DATA_KEY);
		t0 = restoredChatState ? JSON.parse(restoredChatState) : void 0;
		$[0] = t0;
	} else t0 = $[0];
	const parsedState = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[1] = t1;
	} else t1 = $[1];
	useEffect(_temp2, t1);
	if (restoreChatState && parsedState?.expiry && parsedState.expiry > Date.now() && parsedState.threadId === threadId) {
		let t2;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = {
				restoredMessages: parsedState.restoredMessages,
				restoredThreadTitle: parsedState.threadTitle
			};
			$[2] = t2;
		} else t2 = $[2];
		return t2;
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = {};
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
function _temp2() {
	sessionStorage.removeItem(RESTORED_CHAT_DATA_KEY);
}
/**
* Constructs the message hierarchy, populating parentMessageIndex & childMessageIndexes using parentMessageID reference in each message.
* @param messages complete array of messages
* @param selectMostRecentMessages whether to update the selected messages to the most recent child message
* @returns a new list of messages with subthreading (parent/child) attributes populated
*/
function constructMessagesHierarchy(messages, selectMostRecentMessages = true) {
	const startTime = performance.now();
	let timeElapsed = 0;
	const rootMessage = {
		id: "root",
		role: "user",
		createdAt: "",
		threadID: "",
		references: null,
		childMessageIndexes: [],
		messageIndex: 0,
		clientSide: false
	};
	if (messages.length === 0) {
		messages = [rootMessage];
		timeElapsed = performance.now() - startTime;
		sendEvent("copilot.timings", {
			function: "constructMessagesHierarchy",
			timeElapsed,
			messagesLength: messages.length,
			selectMostRecentMessages
		});
		return messages;
	}
	if (messages[0].id !== "root") {
		messages = [rootMessage, ...messages];
		sendEvent("copilot.legacy_thread_updated", {
			threadID: messages[1].threadID,
			messagesLength: messages.length,
			selectMostRecentMessages
		});
	}
	let previousMessage = messages[1];
	if (!previousMessage) return messages;
	[messages, previousMessage] = mutate(messages, 1, "parentMessageID", "root");
	const messageIdToIndex = /* @__PURE__ */ new Map();
	const allChildMessageIndexes = [];
	for (let [index, message] of messages.entries()) {
		[messages, message] = mutate(messages, index, "messageIndex", index);
		allChildMessageIndexes[index] = [];
		messageIdToIndex.set(message.id, index);
		if (message.id === "root") continue;
		if (!message.parentMessageID) {
			[messages, message] = mutate(messages, index, "parentMessageID", previousMessage.id);
			previousMessage = message;
		}
		const parentMessageIndex = messageIdToIndex.get(message.parentMessageID);
		if (parentMessageIndex !== void 0) {
			[messages, message] = mutate(messages, index, "parentMessageIndex", parentMessageIndex);
			let parentMessage = messages[parentMessageIndex];
			if (parentMessage) {
				allChildMessageIndexes[parentMessageIndex].push(index);
				if (parentMessage.selectedChildIndex === void 0) [messages, parentMessage] = mutate(messages, parentMessageIndex, "selectedChildIndex", index);
			}
		}
	}
	for (let i = 0; i < messages.length; i++) [messages] = mutate(messages, i, "childMessageIndexes", allChildMessageIndexes[i]);
	if (selectMostRecentMessages) {
		let selectedNode = messages.at(-1);
		while (selectedNode) {
			let parent = getParentMessage(messages, selectedNode);
			const parentIndex = messageIdToIndex.get(parent?.id ?? "");
			if (parentIndex !== void 0) [messages, parent] = mutate(messages, parentIndex, "selectedChildIndex", selectedNode.messageIndex);
			selectedNode = parent;
		}
	}
	timeElapsed = performance.now() - startTime;
	sendEvent("copilot.timings", {
		function: "constructMessagesHierarchy",
		timeElapsed,
		messagesLength: messages.length,
		selectMostRecentMessages
	});
	return messages;
}
/**
* @param messages complete array of messages
* @returns the list of active messages (messages visible to the user)
*/
function getActiveMessages(messages, pendingFirstMessage) {
	let currentNode = messages[0];
	const activeMessages = [];
	while (currentNode) {
		if (currentNode.id !== "root") activeMessages.push(currentNode);
		currentNode = currentNode.selectedChildIndex !== void 0 ? messages[currentNode.selectedChildIndex] : void 0;
	}
	if (activeMessages.length === 0 && pendingFirstMessage) activeMessages.push(pendingFirstMessage);
	return activeMessages;
}
/**
* @param messages complete array of messages
* @param selectedMessage the message that should become active
* @returns a new list of messages with the selectedMessage active
*/
function selectActiveMessage(messages, selectedMessage) {
	const messagesClone = messages.map((m) => ({ ...m }));
	const parentMessage = messagesClone[selectedMessage.parentMessageIndex];
	if (parentMessage) parentMessage.selectedChildIndex = selectedMessage.messageIndex;
	return messagesClone;
}
/**
* @param messages complete array of messages
* @param parentMessage the message from which to remove the selectedChildIndex
* @returns a new list of messages with the provided parent childless
*/
function unselectPreviousChild(messages, parentMessage) {
	const messagesClone = messages.map((m) => ({ ...m }));
	const messageToUpdate = messagesClone[parentMessage.messageIndex];
	if (messageToUpdate && messageToUpdate.selectedChildIndex !== void 0) messageToUpdate.selectedChildIndex = void 0;
	return messagesClone;
}
/**
* Adds a message to the messages array, populating the parent/child attributes to maintain the hierarchy
* @param messages complete array of messages
* @param newMessage the message to add
* @returns a new list of messages with newMessage appended to the end, and all parent/child attributes updated
*/
function addMessageToHierarchy(messages, newMessage) {
	const parentMessageIndex = messages.findIndex((m) => m.id === newMessage?.parentMessageID);
	if (parentMessageIndex !== -1) {
		let parentMessage = messages[parentMessageIndex];
		const messageToAdd = { ...newMessage };
		messageToAdd.messageIndex = messages.length;
		messageToAdd.childMessageIndexes = [];
		messageToAdd.parentMessageIndex = parentMessage.messageIndex;
		const parentChildMessageIndexes = parentMessage.childMessageIndexes?.slice() || [];
		if (!parentChildMessageIndexes.includes(messageToAdd.messageIndex)) parentChildMessageIndexes.push(messageToAdd.messageIndex);
		parentMessage = {
			...parentMessage,
			childMessageIndexes: parentChildMessageIndexes,
			selectedChildIndex: messageToAdd.messageIndex
		};
		messages = [...messages, messageToAdd].toSpliced(parentMessageIndex, 1, parentMessage);
	}
	return messages;
}
function updateCompletedMessageParent(messages, newMessage) {
	if (messages.find((m) => m.id === newMessage?.parentMessageID) == null) {
		const activeMessages = getActiveMessages(messages);
		let lastActiveMessage = activeMessages[activeMessages.length - 1];
		if (lastActiveMessage !== void 0) if (lastActiveMessage.clientSide && lastActiveMessage.role === "user") {
			const lastActiveMessageIndex = messages.indexOf(lastActiveMessage);
			[messages, lastActiveMessage] = mutate(messages, lastActiveMessageIndex, "id", newMessage.parentMessageID);
			[messages, lastActiveMessage] = mutate(messages, lastActiveMessageIndex, "clientSide", false);
		} else newMessage.parentMessageID = lastActiveMessage.id;
	}
	return messages;
}
/**
* @param messages complete array of messages
* @param message the message to get the parent of
* @returns the parent of the given message
*/
function getParentMessage(messages, message) {
	return message.parentMessageIndex !== void 0 ? messages[message.parentMessageIndex] : void 0;
}
/**
* Given: an array of messages, the index of the message to edit, the key to change, and the new value this function:
* 1. If the key already has the given value, does nothing.
* 2. Otherwise, it clones the message, sets the value, clones the message array, and puts the new message object in the new message array and returns that.
*
* This supports changing the minimum number of ChatMessage objects possible, which is important to prevent unnecessary re-renders.
*/
function mutate(messages, index, key, value) {
	const message = messages[index];
	if (!message) throw new Error(`Message at index ${index} does not exist.`);
	const currentValue = message[key];
	if (currentValue === value) return [messages, message];
	if (Array.isArray(currentValue) && Array.isArray(value) && currentValue.length === value.length && currentValue.every((v, i) => v === value[i])) return [messages, message];
	const newMessage = {
		...message,
		[key]: value
	};
	const newMessages = [...messages];
	newMessages[index] = newMessage;
	return [newMessages, newMessages[index]];
}
var copilotChatReducer = (state, action) => {
	const setSelectedThreadID = (selectedThreadID) => {
		copilotLocalStorage.selectedThreadID = selectedThreadID;
		const isNewSelectedThread = selectedThreadID !== state.selectedThreadID;
		const modelID = copilotLocalStorage.getModel(selectedThreadID)?.id;
		const model = state.availableModels?.find((m) => m.id === modelID) ?? state.model;
		return {
			...state,
			model,
			selectedThreadID,
			threadSelectedAt: isNewSelectedThread ? /* @__PURE__ */ new Date() : state.threadSelectedAt,
			currentView: "thread",
			showTopicPicker: selectedThreadID ? false : state.showTopicPicker,
			currentReferences: isNewSelectedThread ? [] : state.currentReferences,
			threadHasNewMessages: isNewSelectedThread ? false : state.threadHasNewMessages,
			editingMessage: isNewSelectedThread ? void 0 : state.editingMessage,
			pendingFirstMessage: isNewSelectedThread ? void 0 : state.pendingFirstMessage
		};
	};
	switch (action.type) {
		case "SLASH_COMMANDS_ERROR":
			sendEvent("copilot.slash_commands_error");
			return {
				...state,
				slashCommandLoading: {
					...state.slashCommandLoading,
					state: "error"
				}
			};
		case "SLASH_COMMANDS_LOADED":
			sendEvent("copilot.slash_commands_loaded");
			return {
				...state,
				slashCommandLoading: {
					...state.slashCommandLoading,
					state: "loaded"
				}
			};
		case "SLASH_COMMANDS_LOADING": return {
			...state,
			slashCommandLoading: {
				...state.slashCommandLoading,
				state: "loading"
			}
		};
		case "OPEN_COPILOT_CHAT":
			sendEvent("copilot.open_copilot_chat", { source: action.source });
			return {
				...state,
				chatIsOpen: true,
				chatIsVisible: true,
				entryPointId: action.id
			};
		case "CLOSE_COPILOT_CHAT":
			sendEvent("copilot.close_copilot_chat");
			return {
				...state,
				chatIsOpen: false
			};
		case "HIDE_COPILOT_CHAT":
			sendEvent("copilot.hide_copilot_chat");
			return {
				...state,
				chatIsVisible: false
			};
		case "THREAD_CREATED": {
			const newThreads = new Map(state.threads);
			sendEvent("copilot.thread_created", {
				...stringifyThread(action.thread),
				mode: state.mode,
				count: newThreads.size + 1,
				defaultToAgent: copilotFeatureFlags.defaultToAgentInput,
				defaultToAgentControl: copilotFeatureFlags.defaultToAgentControl,
				askModeDropdown: copilotFeatureFlags.askModeDropdown
			});
			newThreads.set(action.thread.id, action.thread);
			return {
				...action.preventThreadSelection ? state : setSelectedThreadID(action.thread.id),
				threads: newThreads,
				pendingFirstMessage: state.pendingFirstMessage
			};
		}
		case "THREAD_CONTINUED": {
			const newThreads = new Map(state.threads);
			sendEvent("copilot.thread_continued", {
				...stringifyThread(action.thread),
				mode: state.mode,
				count: newThreads.size + 1
			});
			newThreads.set(action.thread.id, action.thread);
			return {
				...setSelectedThreadID(action.thread.id),
				threads: newThreads
			};
		}
		case "THREAD_CONTINUED_FAILED":
			sendEvent("copilot.thread_continued_failed", {
				stateSelectedThreadID: state.selectedThreadID,
				sharedIdOnFetch: state.fetchSharedThreads?.shareId,
				mode: state.mode
			});
			return { ...state };
		case "SUGGESTIONS_GENERATED": return {
			...state,
			suggestions: action.suggestions
		};
		case "CLEAR_SUGGESTIONS":
			if (state.suggestionsContext) return state;
			return {
				...state,
				suggestions: null
			};
		case "CLEAR_THREAD":
			sendEvent("copilot.clear_thread");
			return {
				...state,
				messages: [],
				currentReferences: []
			};
		case "CLEAR_CURRENT_REFERENCES": {
			sendEvent("copilot.clear_current_references");
			const keepTypes = action.keepTypes && new Set(action.keepTypes);
			const clearedRefs = keepTypes ? state.currentReferences.filter((reference) => {
				return keepTypes.has(reference.type);
			}) : [];
			return {
				...state,
				currentReferences: clearedRefs
			};
		}
		case "CLEAR_IMPLICIT_REFERENCES": {
			if (state.implicitReferences.size === 0) return state;
			const filteredReferences = state.currentReferences.filter((ref) => !state.implicitReferences.has(ref));
			const currentReferences = filteredReferences.length === state.currentReferences.length ? state.currentReferences : filteredReferences;
			return {
				...state,
				currentReferences,
				implicitReferences: /* @__PURE__ */ new Set()
			};
		}
		case "PROMOTE_IMPLICIT_REFERENCE": {
			if (!state.implicitReferences.has(action.reference)) return state;
			const newImplicitRefs = new Set(state.implicitReferences);
			newImplicitRefs.delete(action.reference);
			return {
				...state,
				implicitReferences: newImplicitRefs
			};
		}
		case "CLEAR_ALL_REFERENCES":
			sendEvent("copilot.clear_all_references");
			return {
				...state,
				currentReferences: []
			};
		case "MESSAGES_UPDATED":
			if (action.state === "error") {
				sendEvent("copilot.messages_updated", {
					count: action.messages?.length,
					loading: action.state
				});
				if (action.notFound && action.missingOrgIds && action.missingOrgIds.length > 0) copilotLocalStorage.clearAuthToken();
			}
			if (action.messages) {
				const messages = [...action.messages];
				const hasClientSideMessages = state.messages.length > 0 && state.messages.some((m) => m.id !== "root" && m.clientSide);
				const isSendingOrStreaming = state.pendingFirstMessage != null || state.isWaitingOnCopilot || state.streamingMessage != null;
				if (messages.length === 0 && state.selectedThreadID != null && (hasClientSideMessages || isSendingOrStreaming)) return {
					...state,
					messagesLoading: {
						...state.messagesLoading,
						state: action.state,
						missingOrgIds: action.missingOrgIds,
						notFound: action.notFound
					}
				};
				let defaultRecipient = state.defaultRecipient;
				let allClientConfirmations = state.allClientConfirmations;
				if (action.state === "loaded" && messages.length > 0) {
					const lastMsg = messages[messages.length - 1];
					if (lastMsg) defaultRecipient = getDefaultRecipient(lastMsg, state);
					allClientConfirmations = messages.map((message) => message.clientConfirmations?.map((cc) => JSON.stringify(Object.values(cc.confirmation).sort()))).flat().filter(Boolean);
				}
				for (const message of messages) message.clientSide = false;
				return {
					...state,
					defaultRecipient,
					allClientConfirmations,
					messages: constructMessagesHierarchy(messages),
					messagesLoading: {
						...state.messagesLoading,
						state: action.state,
						missingOrgIds: action.missingOrgIds,
						notFound: action.notFound
					},
					messagesRestored: false
				};
			} else return {
				...state,
				messagesLoading: {
					...state.messagesLoading,
					state: action.state,
					missingOrgIds: action.missingOrgIds,
					notFound: action.notFound
				}
			};
		case "WAITING_ON_COPILOT": return {
			...state,
			isWaitingOnCopilot: action.loading,
			threadHasNewMessages: true
		};
		case "WAITING_ON_ATTACHMENT": return {
			...state,
			isWaitingOnAttachment: action.loading,
			attachmentProcessingType: action.loading ? action.attachmentType || null : null
		};
		case "SELECT_THREAD": {
			sendEvent("copilot.select_thread", {
				threadID: action.thread?.id,
				mode: state.mode
			});
			const result = {
				...setSelectedThreadID(action.thread?.id || null),
				currentTopic: action.clearTopic ? void 0 : state.currentTopic,
				topicLoading: action.clearTopic ? {
					error: null,
					state: "loaded"
				} : state.topicLoading
			};
			if (action.thread === null && state.currentRepository) result.currentReferences = [makeRepositoryReference(state.currentRepository)];
			return result;
		}
		case "HANDLE_EVENT_START":
			sendEvent("copilot.handle_event_start");
			return {
				...state,
				chatIsOpen: true,
				chatIsVisible: true,
				entryPointId: action.id,
				currentReferences: action.references ?? state.currentReferences,
				suggestionsContext: action.suggestionsContext,
				suggestions: action.suggestionsContext ? getThreadStaticSuggestions({ type: action.suggestionsContext }) : state.suggestions,
				showTopicPicker: action.suggestionsContext ? false : state.showTopicPicker,
				customInstructions: action.customInstructions ?? state.customInstructions
			};
		case "THREADS_LOADING": return {
			...state,
			threadsLoading: {
				...state.threadsLoading,
				state: "loading"
			}
		};
		case "LATEST_THREAD_LOADED": {
			const newThreads = new Map(state.threads);
			newThreads.set(action.latestThread.id, action.latestThread);
			return {
				...state,
				threads: newThreads
			};
		}
		case "THREADS_LOADED": {
			sendEvent("copilot.threads_loaded", {
				count: action.threads.length,
				mode: state.mode
			});
			const selectedThread = state.selectedThreadID && state.threads.get(state.selectedThreadID);
			if (selectedThread && Date.now() - new Date(selectedThread.createdAt).getTime() < 60 * 1e3 && !action.threads.find((t) => t.id === selectedThread.id)) action.threads.push(selectedThread);
			return {
				...state,
				threadsLoading: {
					...state.threadsLoading,
					state: "loaded"
				},
				threads: new Map(action.threads.map((t) => [t.id, t])),
				threadsHidden: action.threadsHidden ?? state.threadsHidden
			};
		}
		case "THREADS_LOADING_ERROR":
			sendEvent("copilot.threads_loading_error", { error: action.message });
			return {
				...state,
				threadsLoading: {
					error: action.message,
					state: "error",
					status: action.status
				}
			};
		case "DELETE_THREAD_KEEP_SELECTION": {
			const newThreads = new Map(state.threads);
			sendEvent("copilot.thread_deleted", {
				...stringifyThread(action.thread),
				count: newThreads.size - 1
			});
			newThreads.delete(action.thread.id);
			return {
				...setSelectedThreadID(null),
				threads: newThreads,
				threadsLoading: {
					...state.threadsLoading,
					state: "loaded"
				},
				messages: [],
				messagesLoading: {
					state: "loaded",
					error: null
				},
				currentReferences: [],
				currentView: "list"
			};
		}
		case "DELETE_ALL_THREADS_KEEP_SELECTION": {
			const newThreads = new Map(state.threads);
			for (const thread of action.threads) {
				sendEvent("copilot.thread_deleted", {
					...stringifyThread(thread),
					count: newThreads.size - 1
				});
				newThreads.delete(thread.id);
			}
			return {
				...setSelectedThreadID(null),
				threads: newThreads,
				threadsLoading: {
					...state.threadsLoading,
					state: "loaded"
				},
				messages: [],
				messagesLoading: {
					state: "loaded",
					error: null
				},
				currentReferences: [],
				currentView: "list"
			};
		}
		case "DELETE_THREAD": {
			const newThreads = new Map(state.threads);
			sendEvent("copilot.thread_deleted", {
				...stringifyThread(action.thread),
				count: newThreads.size - 1,
				mode: state.mode
			});
			newThreads.delete(action.thread.id);
			if (state.selectedThreadID === action.thread.id) return {
				...setSelectedThreadID(null),
				threads: newThreads,
				threadsLoading: {
					...state.threadsLoading,
					state: "loaded"
				},
				messages: [],
				messagesLoading: {
					state: "loaded",
					error: null
				},
				currentReferences: []
			};
			else return {
				...state,
				threads: newThreads
			};
		}
		case "DELETE_THREAD_ERROR": {
			sendEvent("copilot.delete_thread_error", {
				...stringifyThread(action.thread),
				error: action.error
			});
			const newThreads = new Map(state.threads);
			newThreads.set(action.thread.id, action.thread);
			return {
				...state,
				threadsLoading: {
					...state.threadsLoading,
					error: action.error
				},
				threads: newThreads
			};
		}
		case "DELETE_ALL_THREADS_ERROR": {
			for (const thread of action.threads) sendEvent("copilot.delete_thread_error", {
				...stringifyThread(thread),
				error: action.error
			});
			const updatedThreads = new Map(state.threads);
			for (const thread of action.threads) updatedThreads.set(thread.id, thread);
			return {
				...state,
				threadsLoading: {
					...state.threadsLoading,
					error: action.error
				},
				threads: updatedThreads
			};
		}
		case "MESSAGE_ADDED": {
			sendEvent("copilot.message_added", {
				...stringifyMessage(action.message),
				count: state.messages.length + 1,
				repoHasCustomInstructions: Boolean(action.repoHasCustomInstructions),
				usedRepoCustomInstructions: Boolean(action.usedRepoCustomInstructions),
				customInstructionsOwners: action.customInstructionsOwners || ""
			});
			const messages = addMessageToHierarchy(state.messages, action.message);
			return {
				...state,
				messages,
				messagesLoading: {
					state: "loaded",
					error: null
				},
				pendingFirstMessage: void 0,
				threadHasNewMessages: true,
				editingMessage: void 0
			};
		}
		case "MESSAGE_FEEDBACK": {
			const messages = [...state.messages];
			const i = messages.findIndex((m) => m.id === action.message.id);
			const message = messages[i];
			if (!message) {
				sendEvent("copilot.message_feedback_no_message_found", { ...stringifyMessage(action.message) });
				return state;
			}
			messages[i] = {
				...message,
				feedback: action.feedback
			};
			return {
				...state,
				messages
			};
		}
		case "MESSAGES_SET_SELECTED_MESSAGE": {
			const messages = selectActiveMessage(state.messages, action.message);
			sendEvent("copilot.chat_subthread_changed", { removedReferences: state.currentReferences.length });
			return {
				...state,
				messages,
				threadHasNewMessages: false,
				threadSelectedAt: /* @__PURE__ */ new Date()
			};
		}
		case "MESSAGES_UNSELECT_PREVIOUS_MESSAGE": {
			const messages = unselectPreviousChild(state.messages, action.message);
			return {
				...state,
				messages,
				threadHasNewMessages: false
			};
		}
		case "THREAD_UPDATED": return {
			...state,
			threads: updateThread(state, action.thread)
		};
		case "REFERENCES_LOADED":
			sendEvent("copilot.references_loaded", { count: action.references.length });
			return {
				...state,
				currentReferences: state.currentReferences.filter((oldRef) => action.references.every((newRef) => referenceID(newRef) !== referenceID(oldRef))).concat(action.references)
			};
		case "ADD_REFERENCE": {
			const newCurrentReferences = [...state.currentReferences.filter((reference) => !referencesAreEqual(reference, action.reference)), action.reference];
			let newImplicitReferences = state.implicitReferences;
			if (newCurrentReferences.length > state.currentReferences.length) {
				sendEvent("copilot.add_reference", {
					...stringifyReference(action.reference),
					source: action.source,
					count: state.currentReferences.length + 1,
					implicit: !!action.implicit
				});
				if (action.reference.type === "repository") copilotLocalStorage.setLastUsedRepository(action.reference);
			}
			if (action.reference && (action.reference.type === "issue" || action.reference.type === "pull-request" || action.reference.type === "discussion")) announce$1(`Adding ${action.reference.type} ${action.reference.number} as a reference.`);
			if (action.implicit) {
				const implicitReferences = new Set(newImplicitReferences);
				implicitReferences.add(action.reference);
				newImplicitReferences = implicitReferences;
			}
			return {
				...state,
				currentReferences: newCurrentReferences,
				implicitReferences: newImplicitReferences
			};
		}
		case "REMOVE_REFERENCES": {
			const removedReferences = action.references;
			if (removedReferences.length > 0) sendEvent("copilot.remove_reference", { count: state.currentReferences.length - removedReferences.length });
			if (removedReferences[0] && (removedReferences[0].type === "issue" || removedReferences[0].type === "pull-request" || removedReferences[0].type === "discussion")) announce$1(`Removing ${removedReferences[0].type} ${removedReferences[0].number} as a reference.`);
			const storageReferences = copilotLocalStorage.getCurrentReferences(state.selectedThreadID);
			if (storageReferences) {
				const updatedStorageReferences = storageReferences.filter((r) => !removedReferences.some((removedRef) => referencesAreEqual(removedRef, r)));
				copilotLocalStorage.setCurrentReferences(state.selectedThreadID, updatedStorageReferences);
			}
			return {
				...state,
				currentReferences: state.currentReferences.filter((r) => !removedReferences.includes(r)),
				implicitReferences: new Set([...state.implicitReferences].filter((r) => !removedReferences.includes(r)))
			};
		}
		case "REPLACE_REFERENCE": {
			const updatedReferences = [];
			let implicitReferences = state.implicitReferences;
			for (const reference of state.currentReferences) if (referencesAreEqual(reference, action.referenceToDelete)) {
				updatedReferences.push(action.referenceToInsert);
				if (implicitReferences.has(reference)) {
					const newImplicitReferences = new Set(implicitReferences);
					newImplicitReferences.delete(reference);
					newImplicitReferences.add(action.referenceToInsert);
					implicitReferences = newImplicitReferences;
				}
			} else if (!referencesAreEqual(reference, action.referenceToInsert)) updatedReferences.push(reference);
			sendEvent("copilot.replace_reference", {
				removedReference: referenceID(action.referenceToDelete),
				addedReference: referenceID(action.referenceToInsert),
				count: updatedReferences.length
			});
			return {
				...state,
				implicitReferences,
				currentReferences: updatedReferences
			};
		}
		case "SHOW_TOPIC_PICKER": return {
			...state,
			showTopicPicker: action.show
		};
		case "CURRENT_TOPIC_UPDATED":
			if (action.topic) sendEvent("copilot.current_topic_updated", {
				type: !action.topic ? "none" : "repository",
				mode: state.mode
			});
			return {
				...state,
				currentTopic: action.topic,
				topicLoading: {
					...state.topicLoading,
					state: action.state
				}
			};
		case "MESSAGE_STREAMING_STARTED":
			sendEvent("copilot.message_streaming_started", {
				...stringifyMessage(action.message),
				model: state.model?.id,
				mode: state.mode
			});
			return {
				...state,
				isWaitingOnCopilot: true,
				streamingMessage: action.message,
				messages: [...state.messages]
			};
		case "MESSAGE_STREAMING_TOKEN_ADDED": return {
			...state,
			streamingMessage: state.streamingMessage ? {
				...state.streamingMessage,
				content: state.streamingMessage.content + action.token
			} : null
		};
		case "MESSAGE_STREAMING_FUNCTION_CALLED":
			if (state.streamingMessage) {
				const prevExecutions = state.streamingMessage.skillExecutions || [];
				let matchingIdx = -1;
				if (action.callId && copilotFeatureFlags.enableToolCallLogs) matchingIdx = prevExecutions.findIndex((fc) => fc.callId === action.callId);
				else matchingIdx = prevExecutions.findIndex((fc) => fc.status === "started" || fc.status === "progress");
				const matchingExecution = matchingIdx >= 0 ? prevExecutions[matchingIdx] : null;
				let executions = prevExecutions;
				let references = state.streamingMessage.references || [];
				switch (action.status) {
					case "started":
						executions = [...prevExecutions, {
							slug: action.name,
							status: action.status,
							arguments: action.arguments,
							errorMessage: action.errorMessage,
							references: [],
							callId: action.callId
						}];
						break;
					case "progress":
						if (matchingExecution) {
							const updatedExecution = {
								...matchingExecution,
								status: action.status,
								statusMessage: action.statusMessage
							};
							executions = [
								...prevExecutions.slice(0, matchingIdx),
								updatedExecution,
								...prevExecutions.slice(matchingIdx + 1)
							];
						}
						break;
					case "completed":
						if (matchingExecution) {
							executions = [...prevExecutions];
							let executionRefs = matchingExecution.references;
							if (!matchingExecution.references?.length) {
								executionRefs = action.references;
								references = Array.from(new Set([...references, ...action.references]));
							}
							executions[matchingIdx] = {
								...matchingExecution,
								status: action.status,
								references: executionRefs
							};
						} else sendEvent("copilot.function_call_missing_callid", {
							referenceCount: action.references.length,
							tool: action.name,
							callId: action.callId ?? "missing"
						});
						break;
					case "error":
						if (matchingExecution) {
							executions = [...prevExecutions];
							executions[matchingIdx] = {
								...matchingExecution,
								status: action.status,
								errorMessage: action.errorMessage
							};
						}
						break;
				}
				return {
					...state,
					streamingMessage: {
						...state.streamingMessage,
						skillExecutions: executions,
						references
					}
				};
			}
			return state;
		case "MESSAGE_STREAMING_COMPLETED": {
			let defaultRecipient = state.defaultRecipient;
			let newMessage;
			let messages = state.messages;
			if (state.streamingMessage) {
				let updatedExecutions = state.streamingMessage.skillExecutions;
				if (state.streamingMessage.skillExecutions) updatedExecutions = state.streamingMessage.skillExecutions.map((execution) => {
					if (execution.status === "started" || execution.status === "progress") return {
						...execution,
						status: "completed"
					};
					return execution;
				});
				newMessage = {
					...state.streamingMessage,
					id: action.messageResponse.id,
					references: action.messageResponse.references,
					createdAt: action.messageResponse.createdAt,
					intent: action.messageResponse.intent,
					copilotAnnotations: action.messageResponse.copilotAnnotations,
					parentMessageID: action.messageResponse.parentMessageID,
					model: action.messageResponse.model,
					clientSide: false,
					skillExecutions: updatedExecutions
				};
				defaultRecipient = getDefaultRecipient(newMessage, state);
				sendEvent("copilot.message_streaming_completed", {
					...stringifyMessage(newMessage),
					...stringifyTiming(action.timings),
					model: state.model?.id,
					mode: state.mode,
					count: state.messages.length + 1
				});
				if (state.streamingMessage.requestID) copilotLocalStorage.addRequestID(newMessage.id, state.streamingMessage?.requestID);
				messages = updateCompletedMessageParent(messages, newMessage);
				messages = addMessageToHierarchy(messages, newMessage);
			}
			return {
				...state,
				defaultRecipient,
				isWaitingOnCopilot: false,
				streamingMessage: null,
				messages
			};
		}
		case "MESSAGE_STREAMING_FAILED":
			sendEvent("copilot.message_streaming_failed", {
				...state.streamingMessage ? stringifyMessage(state.streamingMessage) : {},
				...stringifyTiming(action.timings),
				model: state.model?.id,
				mode: state.mode
			});
			return {
				...state,
				isWaitingOnCopilot: false,
				streamingMessage: null
			};
		case "MESSAGE_STREAMING_STOPPED": {
			let newMessage;
			const parentMessageID = getActiveMessages(state.messages).findLast((m) => m.role === "user")?.id;
			if (state.streamingMessage) {
				newMessage = {
					...state.streamingMessage,
					interrupted: true,
					parentMessageID
				};
				sendEvent("copilot.message_streaming_stopped", {
					...stringifyMessage(newMessage),
					...stringifyTiming(action.timings),
					model: state.model?.id,
					mode: state.mode,
					count: state.messages.length + 1
				});
			} else if (state.isWaitingOnCopilot) newMessage = {
				id: crypto.randomUUID(),
				role: "assistant",
				threadID: state.selectedThreadID ?? "",
				references: [],
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				interrupted: true,
				clientSide: true,
				parentMessageID
			};
			let messages = state.messages;
			if (newMessage != null) {
				const lastUserMessage = messages.findLast((m) => m.role === "user");
				if (lastUserMessage !== void 0) newMessage.parentMessageID = lastUserMessage.id;
				messages = addMessageToHierarchy(messages, newMessage);
			}
			return {
				...state,
				isWaitingOnCopilot: false,
				streamingMessage: null,
				messages
			};
		}
		case "MESSAGES_CLEAR_LAST_ERROR": {
			const activeMessages = getActiveMessages(state.messages);
			const allMessages = state.messages;
			const lastMessage = activeMessages[activeMessages.length - 1];
			const lastMessageHasError = lastMessage?.error || lastMessage?.interrupted;
			let filteredMessages = allMessages;
			if (lastMessageHasError) filteredMessages = allMessages.filter((message) => message.id !== lastMessage?.id);
			return {
				...state,
				streamingMessage: null,
				messages: [...filteredMessages]
			};
		}
		case "SELECT_REFERENCE":
			if (action.reference) sendEvent("copilot.select_reference", stringifyReference(action.reference));
			return {
				...state,
				selectedReference: action.reference
			};
		case "MODELS_LOADING": return {
			...state,
			modelsLoading: {
				state: "loading",
				error: null
			}
		};
		case "MODELS_LOADING_ERROR": return {
			...state,
			modelsLoading: {
				state: "error",
				error: action.error
			}
		};
		case "MODELS_LOADED": {
			let models = action.models;
			if (!copilotFeatureFlags.visionAllowedInClaude) models = action.models.map((model) => {
				if (model.id.startsWith("claude")) {
					const newModel = { ...model };
					newModel.capabilities.supports.vision = false;
					return newModel;
				}
				return model;
			});
			return {
				...state,
				model: (models || []).find((m) => m.id === state.model.id) || state.model,
				availableModels: models || [],
				modelsLoading: {
					state: "loaded",
					error: null
				}
			};
		}
		case "SELECT_MODEL": {
			if (state.mode !== "immersive" && !copilotFeatureFlags.immersiveEmbedded) return state;
			const supportedReferences = action.model?.capabilities?.supports?.vision ? state.currentReferences : state.currentReferences.filter((reference) => reference.type !== "image");
			sendEvent("copilot.select_model", {
				model: action.model?.name,
				mode: state.mode
			});
			return {
				...state,
				model: action.model,
				currentReferences: supportedReferences
			};
		}
		case "VIEW_ALL_THREADS": return {
			...state,
			currentView: "list"
		};
		case "VIEW_CURRENT_THREAD": return {
			...state,
			currentView: "thread"
		};
		case "IMPLICIT_CONTEXT_UPDATED":
			if (!referenceArraysAreEqual(action.context, state.context)) return {
				...state,
				context: action.context
			};
			return state;
		case "SET_TOP_REPOSITORIES": return {
			...state,
			topRepositoriesCache: action.topics
		};
		case "SET_AGENTS": return {
			...state,
			agents: action.agents
		};
		case "SET_CUSTOM_COPILOT": {
			const existing = state.customCopilots?.find((copilot) => customCopilotMatchesId(copilot, action.customCopilot));
			const partial = existing && action.partial;
			const customCopilots = existing ? state.customCopilots?.map((copilot) => {
				if (!customCopilotMatchesId(copilot, existing)) return copilot;
				if (partial) return {
					...copilot,
					...action.customCopilot
				};
				return action.customCopilot;
			}) : [...state.customCopilots ?? [], action.customCopilot];
			return {
				...state,
				customCopilots
			};
		}
		case "SET_CUSTOM_COPILOTS": return {
			...state,
			customCopilots: action.customCopilots
		};
		case "REMOVE_CUSTOM_COPILOT": return {
			...state,
			customCopilots: state.customCopilots?.filter((copilot) => !customCopilotMatchesId(copilot, action.customCopilotId))
		};
		case "SET_DEEP_CODESEARCH": return {
			...state,
			skillOptions: {
				...state.skillOptions,
				deepCodeSearch: action.deepCodeSearch
			}
		};
		case "MESSAGE_STREAMING_CONFIRMATION": {
			const confirmation = {
				title: action.title,
				message: action.message,
				confirmation: action.confirmation
			};
			return {
				...state,
				streamingMessage: state.streamingMessage ? {
					...state.streamingMessage,
					confirmations: state.streamingMessage.confirmations ? [...state.streamingMessage.confirmations, confirmation] : [confirmation]
				} : null
			};
		}
		case "AGENT_ERROR": {
			const streamingMessage = state.streamingMessage;
			const agentError = action.error;
			return {
				...state,
				streamingMessage: streamingMessage && {
					...streamingMessage,
					agentErrors: [...streamingMessage.agentErrors ?? [], {
						type: agentError.type,
						code: agentError.code,
						message: agentError.message,
						identifier: agentError.identifier
					}]
				}
			};
		}
		case "ENTITLEMENT_UPDATED": return {
			...state,
			entitlement: action.entitlement ?? state.entitlement
		};
		case "TOGGLE_REPO_CUSTOM_INSTRUCTIONS":
			sendEvent("copilot.repo_custom_instructions_toggled", { isEnabling: Boolean(action.value) });
			return {
				...state,
				repoCustomInstructionsEnabled: action.value
			};
		case "DISMISS_EDITOR_UPSELL_BANNER": return {
			...state,
			isEditorUpsellBannerDismissed: true
		};
		case "DISMISS_COPILOT_SPACES_MCP_BANNER": return {
			...state,
			showCopilotSpacesMcpBanner: false
		};
		case "DISMISS_AMBIENT_ERROR": return {
			...state,
			ambientError: null
		};
		case "ADD_AMBIENT_ERROR": return {
			...state,
			ambientError: { message: action.message }
		};
		case "SET_PERSONAL_INSTRUCTIONS": return {
			...state,
			personalInstructions: action.personalInstructions
		};
		case "SHARED_THREAD_UPDATED": {
			const newThreads = updateThread(state, action.thread);
			const updatedThread = newThreads.get(action.thread.id);
			if (updatedThread) sendEvent("copilot.shared_thread_update", stringifyThread(updatedThread));
			return {
				...state,
				threads: newThreads
			};
		}
		case "SHARED_THREADS_LOADING": return {
			...state,
			sharedThreadsLoading: {
				...state.sharedThreadsLoading,
				state: "loading"
			}
		};
		case "SHARED_THREADS_LOADED":
			sendEvent("copilot.shared_threads_loaded");
			return {
				...state,
				sharedThreadsLoading: {
					...state.sharedThreadsLoading,
					state: "loaded"
				}
			};
		case "SHARED_THREADS_LOADING_ERROR":
			sendEvent("copilot.shared_threads_loading_error", { error: action.message });
			return {
				...state,
				sharedThreadsLoading: {
					...state.sharedThreadsLoading,
					state: "error",
					error: action.message
				}
			};
		case "IMAGE_UPLOADED": return {
			...state,
			currentReferences: state.currentReferences.map((reference) => {
				if (reference.type === "image" && reference.id === action.referenceId) return {
					...reference,
					imageUrl: action.dotcomAttachment.previewUrl
				};
				return reference;
			})
		};
		case "START_EDITING_MESSAGE":
			sendEvent("dotcom_chat.activate", {
				target: "USER_MESSAGE_ACTION_EDIT",
				mode: "immersive"
			});
			return {
				...state,
				editingMessage: action.messageId
			};
		case "CANCEL_EDITING_MESSAGE": return {
			...state,
			editingMessage: void 0
		};
		case "FETCH_SHARED_THREAD_MESSAGES": return {
			...state,
			fetchSharedThreads: {
				ok: action.ok,
				status: action.status,
				shareId: action.shareId,
				originalThreadId: action.originalThreadId
			}
		};
		case "SET_WRAP_CODE_LINES": return {
			...state,
			wrapCodeLines: action.value
		};
		case "CLEAR_SHARED_THREAD_CHANNEL": return {
			...state,
			sharedThreadChannel: null
		};
		case "CLEAR_DEFAULT_RECIPIENT": return {
			...state,
			defaultRecipient: void 0
		};
		case "SET_PENDING_FIRST_MESSAGE": return {
			...state,
			pendingFirstMessage: action.message
		};
		case "SET_SHOULD_REPLACE_HISTORY_ON_NAVIGATION": return {
			...state,
			shouldReplaceHistoryOnNavigation: action.value
		};
	}
};
/**
* Updates a thread using the given "patch" which contains a thread ID and some
* subset of additional thread properties. Returns a copy of state.threads with
* the thread in question updated, appropriate for returning in a new state.
*/
function updateThread(state, patch) {
	const newThreads = new Map(state.threads);
	const storedThread = state.threads.get(patch.id);
	if (!storedThread) return newThreads;
	const updatedThread = {
		...storedThread,
		...patch
	};
	newThreads.set(patch.id, updatedThread);
	return newThreads;
}
/**
* Stringifies the given message while cleaning sensitive information from it.
*/
function stringifyMessage(message) {
	if (!message) return stringifyObjectValues({});
	const obj = {
		id: message.id,
		role: message.role,
		createdAt: message.createdAt,
		threadID: message.threadID,
		referenceCount: message.references?.length ?? 0
	};
	if (message.intent) obj.intent = message.intent;
	if (message.error) obj.error = message.error;
	if (message.copilotAnnotations) obj.copilotAnnotations = cleanCopilotAnnotations(message.copilotAnnotations);
	if (message.skillExecutions) obj.skillExecutions = cleanSkillExecutions(message.skillExecutions);
	if (message.interrupted) obj.interrupted = true;
	return stringifyObjectValues(obj);
}
/**
* Stringifies the given thread while cleaning sensitive information from it.
*/
function stringifyThread(thread) {
	if (!thread) return stringifyObjectValues({});
	return stringifyObjectValues({
		id: thread.id,
		createdAt: thread.createdAt,
		updatedAt: thread.updatedAt,
		currentReferenceCount: thread.currentReferences?.length ?? 0
	});
}
/**
* Stringifies the given reference while cleaning sensitive information from it.
*/
function stringifyReference(reference) {
	if (!reference) return stringifyObjectValues({});
	return stringifyObjectValues({ type: reference.type });
}
/**
* Remove sensitive information from skillExecutions in preparation for logging.
*/
function cleanSkillExecutions(skillExecutions) {
	if (!skillExecutions) return [];
	return skillExecutions.map((execution) => ({
		slug: execution?.slug,
		status: execution?.status,
		argumentCount: execution?.arguments?.length ?? 0,
		errorMessage: execution?.errorMessage,
		references: execution?.references?.length ?? 0
	}));
}
/**
* Remove sensitive information from copilotAnnotations in preparation for logging.
*/
function cleanCopilotAnnotations(annotations) {
	if (!annotations) return;
	return {
		CodeVulnerability: annotations.CodeVulnerability?.map((vuln) => ({ details: { type: vuln?.details?.type } })),
		PublicCodeReference: annotations.PublicCodeReference?.map((ref) => ({ details: {
			license: ref?.details?.license,
			language: ref?.details?.language
		} }))
	};
}
/**
* Converts the timings into relative times for reporting.
*/
function stringifyTiming(timings) {
	const result = { totalTime: timings.endTime - timings.startTime };
	if (timings.firstByte !== void 0) result["ttfb"] = timings.firstByte - timings.startTime;
	if (timings.firstToken !== void 0) result["ttft"] = timings.firstToken - timings.startTime;
	return result;
}
function getDefaultRecipient(message, state) {
	const author = findAuthor(message, state.currentUserLogin);
	if (author.type === "agent") return author.name;
}
var ObservableTraceStateContext = createContext(null);
ObservableTraceStateContext.displayName = "ObservableTraceStateContext";
function ObservableTraceStateProvider({ children, value }) {
	return /* @__PURE__ */ jsx(ObservableTraceStateContext, {
		value,
		children
	});
}
/**
* Returns a constant reference to a function that can be used inside a callback to get the current version of the trace state.
*
* The returned `getTraceState()` function should only be used inside an event handler or callback. If it is used in a render
* method, it may return outdated state.
*/
ObservableTraceStateProvider.displayName = "ObservableTraceStateProvider";
function useGetTraceState() {
	const o = use(ObservableTraceStateContext);
	if (!o || !o.current) throw new Error("useGetTraceState can only be used inside a TraceProvider");
	return useCallback(() => o.current.value, [o]);
}
var BlackbirdPermissionCaches = class BlackbirdPermissionCaches {
	static warmCachesLoopSetup = false;
	static warmResolve;
	static warm = new Promise((resolve) => {
		BlackbirdPermissionCaches.warmResolve = resolve;
	});
	async setupWarmCachesLoop() {
		if (!isLoggedIn()) return;
		if (!BlackbirdPermissionCaches.warmCachesLoopSetup) {
			BlackbirdPermissionCaches.warmCachesLoopSetup = true;
			await this.warmCaches();
		} else await BlackbirdPermissionCaches.warm;
	}
	async warmCaches() {
		let ttl = 540 * 1e3;
		try {
			const data = await (await verifiedFetchJSON("/search/warm_blackbird_caches", { headers: {
				Accept: "application/json",
				...getBaseFetchHeaders()
			} })).json();
			ttl = new Date(data.userCacheExpiresAt).getTime() - Date.now();
			ttl = ttl - 30 * 1e3;
			if (isNaN(ttl) || ttl <= 5) ttl = 30 * 1e3;
		} catch {}
		BlackbirdPermissionCaches.warmResolve();
		setTimeout(() => {
			this.warmCaches();
		}, ttl);
	}
};
/**
* Caches results of API calls based on the parameters. Ensures that only one request is dispatched for the same parameters.
*/
var ApiCache = class {
	separator = "-!-";
	cache = /* @__PURE__ */ new Map();
	fetchFn;
	constructor(fetchFn) {
		this.fetchFn = fetchFn;
	}
	async get(...params) {
		const key = params.join(this.separator);
		const cached = this.cache.get(key);
		if (cached) return cached;
		else {
			const promise = this.fetchFn(...params);
			this.cache.set(key, promise);
			if (!(await promise).ok) this.cache.delete(key);
			return promise;
		}
	}
};
var isCustomCopilotRef = (ref) => "refOrigin" in ref && ref.refOrigin === "custom_copilot";
var isCustomInstructionsRef = (ref) => "type" in ref && ref.type === "custom-instructions";
function filterOutCustomCopilotReferences(references) {
	if (!Array.isArray(references)) return references;
	return references.filter((ref) => !isCustomCopilotRef(ref) && !isCustomInstructionsRef(ref));
}
var OPEN_AI_LOGO = "/images/modules/marketplace/models/families/openai-logo.svg";
var ANTHROPIC_LOGO = "/images/modules/marketplace/models/families/anthropic.svg";
var GEMINI_LOGO = "/images/modules/marketplace/models/families/gemini.svg";
var XAI_LOGO = "/images/modules/marketplace/models/families/xai.svg";
var XAI_LOGO_DARK = "/images/modules/marketplace/models/families/xai-dark.svg";
var LOGO_BY_VENDOR = new Map([
	["Azure OpenAI", OPEN_AI_LOGO],
	["OpenAI", OPEN_AI_LOGO],
	["Anthropic", ANTHROPIC_LOGO],
	["Google", GEMINI_LOGO],
	["xAI", XAI_LOGO]
]);
function findDefaultModel(copilotModels, plan, premiumInteractionsQuotaExceeded, overagesEnabled) {
	const defaultModel = copilotFeatureFlags.premiumRequestQuotasEnabled && plan !== CopilotPlan.IndividualFree && premiumInteractionsQuotaExceeded && !overagesEnabled ? copilotModels?.find((m) => m.is_chat_fallback === true) : copilotModels?.find((m) => m.is_chat_default === true);
	if (!defaultModel) return generateDefaultModel();
	return defaultModel;
}
function generateLegacyDefaultModel() {
	return {
		capabilities: {
			family: "gpt-4o",
			limits: {
				max_prompt_tokens: 2e4,
				vision: { supported_media_types: [
					"image/jpeg",
					"image/png",
					"image/webp",
					"image/gif"
				] }
			},
			supports: {
				parallel_tool_calls: true,
				tool_calls: true
			},
			tokenizer: "o200k_base",
			type: "chat"
		},
		id: "gpt-4o",
		name: "GPT 4o",
		version: "gpt-4o-2024-05-13",
		displayName: "GPT 4o",
		vendor: "Azure OpenAI",
		logoURL: OPEN_AI_LOGO,
		hasLimitedCapabilities: false,
		preview: false,
		isThirdParty: false,
		model_picker_enabled: true
	};
}
function generateDefaultModel() {
	return {
		capabilities: {
			family: "gpt-4.1",
			limits: {
				max_prompt_tokens: 128e3,
				vision: { supported_media_types: [
					"image/jpeg",
					"image/png",
					"image/webp",
					"image/gif"
				] }
			},
			supports: {
				parallel_tool_calls: true,
				tool_calls: true
			},
			tokenizer: "o200k_base",
			type: "chat"
		},
		id: "gpt-4.1",
		name: "GPT-4.1",
		displayName: "GPT-4.1",
		model_picker_enabled: true,
		preview: false,
		vendor: "OpenAI",
		logoURL: OPEN_AI_LOGO,
		isThirdParty: false,
		hasLimitedCapabilities: false,
		version: "gpt-4.1-2025-04-14"
	};
}
function useDefaultModel(copilotModels) {
	const $ = c(5);
	const { plan, premiumInteractionsQuotaExceeded, overagesEnabled } = useEntitlement();
	let t0;
	if ($[0] !== copilotModels || $[1] !== overagesEnabled || $[2] !== plan || $[3] !== premiumInteractionsQuotaExceeded) {
		t0 = getDefaultModel(copilotModels, plan, premiumInteractionsQuotaExceeded, overagesEnabled);
		$[0] = copilotModels;
		$[1] = overagesEnabled;
		$[2] = plan;
		$[3] = premiumInteractionsQuotaExceeded;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
function getDefaultModel(copilotModels, plan, premiumInteractionsQuotaExceeded, overagesEnabled) {
	if (copilotFeatureFlags.forceLegacyChatDefaultModel) return generateLegacyDefaultModel();
	return findDefaultModel(copilotModels, plan, !!premiumInteractionsQuotaExceeded, !!overagesEnabled);
}
function toCopilotChatModels(copilotModels) {
	return (copilotModels ?? [generateDefaultModel()]).map(toAllowedCopilotChatModel).filter((m) => !!m).filter((m) => m.model_picker_enabled);
}
function toAllowedCopilotChatModel(copilotModel) {
	if (!isChatModel(copilotModel)) return null;
	if (!isAllowed(copilotModel)) return null;
	let logoUrl = LOGO_BY_VENDOR.get(copilotModel.vendor);
	if (copilotModel.vendor === "xAI" && document.querySelector("[data-color-mode=\"dark\"]") !== null) logoUrl = XAI_LOGO_DARK;
	return {
		...copilotModel,
		displayName: displayName(copilotModel),
		hasLimitedCapabilities: hasLimitedCapabilities(copilotModel, copilotFeatureFlags.copilotChatO1Tools),
		isThirdParty: isThirdParty(copilotModel),
		logoURL: logoUrl
	};
}
function hasLimitedCapabilities(m, o1ToolsEnabled) {
	if (m.capabilities.family === "o1-ga") return !o1ToolsEnabled;
	if (m.capabilities.family === "o3") return true;
	return !m.capabilities.supports.tool_calls;
}
function isAllowed(m) {
	if (!m.model_picker_enabled) return false;
	if (m.policy && m.policy.state !== "enabled" && !m.policy.terms) return false;
	return true;
}
function isThirdParty(m) {
	return m.vendor !== "Azure OpenAI";
}
function isChatModel(m) {
	return m.capabilities.type === "chat";
}
function isCustomModel(model) {
	return model.custom_model != null;
}
var betaLabels = ["(Beta)", "(Preview)"];
function displayName(m) {
	for (const suffix of betaLabels) if (m.name.endsWith(suffix)) return m.name.replace(suffix, "").trim();
	return m.name;
}
var BLACKBIRD_SUGGESTION_KIND = "SUGGESTION_KIND_SYMBOL";
var HYDRATABLE_REFERENCE_TYPES = new Set([
	"snippet",
	"file",
	"symbol",
	"repository"
]);
var TRUNCATED_MSG = "Content was truncated. Use the API to get full content.";
var MAX_BYTES = 16 * 1e3;
var CopilotChatService = class {
	apiURL;
	urlPathPrefix = "/github-copilot/chat";
	repoDetailsCache = /* @__PURE__ */ new Map();
	listMessagesCache = void 0;
	copilotAuthTokenProvider;
	blackbirdCaches = new BlackbirdPermissionCaches();
	realIp;
	apiVersion = void 0;
	constructor(apiURL, ssoOrgs, realIp, apiVersion) {
		this.apiURL = apiURL;
		this.copilotAuthTokenProvider = new CopilotAuthTokenProvider(ssoOrgs.map((org) => org.id));
		this.realIp = realIp || "";
		this.apiVersion = apiVersion;
	}
	async fetchThreads(params = {}) {
		const queryParams = new URLSearchParams();
		if (typeof params.name === "string") queryParams.set("name", params.name);
		const pathWithParams = `/threads?${queryParams.toString()}`;
		const res = await this.makeCAPIRequest(pathWithParams, "GET");
		if (!res.ok) return res;
		const json = await res.json();
		const threads = json.threads || [];
		const threadsHidden = json.threads_hidden === true;
		return {
			status: res.status,
			ok: true,
			payload: {
				threads,
				threadsHidden
			}
		};
	}
	async fetchSharedThreads() {
		const res = await this.makeCAPIRequest("/threads?shared", "GET");
		if (!res.ok) return res;
		const payload = (await res.json()).threads || [];
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async fetchLatestThread(threadId) {
		const queryParams = new URLSearchParams();
		if (typeof threadId === "string") queryParams.set("thread_id", threadId);
		const res = await this.makeCAPIRequest(`/threads/latest?${queryParams.toString()}`, "GET");
		if (!res.ok) return res;
		const payload = (await res.json()).thread;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async createThread(customCopilotId, scopeId) {
		const body = {
			custom_copilot_id: customCopilotId?.id,
			custom_copilot_owner: customCopilotId?.owner,
			scope_id: scopeId
		};
		const res = await this.makeCAPIRequest(`/threads`, "POST", body);
		if (!res.ok) return res;
		const payload = (await res.json()).thread;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async deleteThread(threadID) {
		const res = await this.makeCAPIRequest(`/threads/${threadID}`, "DELETE");
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async deleteAllThreads(body) {
		const res = await this.makeCAPIRequest(`/threads`, "DELETE", body);
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async renameThread(threadID, newName) {
		const body = {
			generate: false,
			name: newName
		};
		const res = await this.makeCAPIRequest(`/threads/${threadID}/name`, "PATCH", body);
		if (!res.ok) return res;
		const payload = (await res.json()).name || "";
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async clearThread(threadID) {
		const res = await this.makeCAPIRequest(`/threads/${threadID}/clear`, "PATCH");
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async shareThread(threadID, latestShareableMessageID) {
		const body = { shared_message_id: latestShareableMessageID };
		const res = await this.makeCAPIRequest(`/threads/${threadID}/share`, "PATCH", body);
		if (!res.ok) return res;
		const payload = (await res.json()).thread;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async unshareThread(threadID) {
		const res = await this.makeCAPIRequest(`/threads/${threadID}/unshare`, "PATCH");
		if (!res.ok) return res;
		const payload = (await res.json()).thread;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async unshareAllThreads() {
		const res = await this.makeCAPIRequest(`/threads/unshare`, "POST");
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async continueSharedThread(sharedID) {
		const res = await this.makeCAPIRequest(`/shared/${sharedID}/duplicate`, "POST");
		if (!res.ok) return res;
		return {
			status: 200,
			ok: true,
			payload: await res.json()
		};
	}
	async generateThreadName(threadID) {
		const res = await this.makeCAPIRequest(`/threads/${threadID}/name`, "PATCH", {
			generate: true,
			name: ""
		});
		if (!res.ok) return res;
		const payload = (await res.json()).name || "";
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async getSystemPrompt(mode) {
		const res = await this.makeCAPIRequest(`/system_prompt/${mode}`, "GET");
		if (!res.ok) return res;
		const payload = await res.json();
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async listMessages(threadID) {
		if (this.listMessagesCache?.thread.id === threadID) return {
			status: 200,
			ok: true,
			payload: this.listMessagesCache
		};
		const res = await this.makeCAPIRequest(`/threads/${threadID}/messages`, "GET");
		return this.handleListMessages(res, true);
	}
	async listSharedThreadMessages(sharedID) {
		const res = await this.makeCAPIRequest(`/shared/${sharedID}/messages`, "GET");
		return this.handleListMessages(res, false);
	}
	async handleListMessages(res, shouldSetCache) {
		if (isFailedApiResult(res)) if (res.status === 404 && res.response?.headers.has("Content-Type") && res.response.headers.get("Content-Type") === "application/json") {
			const payload = await res.response.json();
			return {
				...res,
				payload
			};
		} else return res;
		const payload = await res.json();
		if (shouldSetCache) {
			if (Array.isArray(payload.messages)) payload.messages = payload.messages.map((message) => {
				message.references = filterOutCustomCopilotReferences(message.references);
				return message;
			});
			this.listMessagesCache = payload;
		}
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async createMessage(threadID, content, mediaContent, intent, references, customInstructions, model) {
		this.listMessagesCache = void 0;
		const res = await this.makeCAPIRequest(`/threads/${threadID}/messages`, "POST", {
			content,
			mediaContent,
			intent,
			references,
			currentURL: window.location.href,
			customInstructions,
			model,
			settings: copilotLocalStorage.settings ?? void 0
		});
		if (!res.ok) return res;
		const payload = (await res.json()).message;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async createMessageStreaming({ threadID, messageID, content, mediaContent, intent, mode, references, context, confirmations, customInstructions, model, customCopilotID, parentMessageID, signal, skillOptions }) {
		this.listMessagesCache = void 0;
		if (customCopilotID) mode = "custom-copilots";
		const pageContext = copilotFeatureFlags.domPageContext && mode !== "immersive" && mode !== "custom-copilots" ? extractPageContext() : void 0;
		const body = {
			responseMessageID: messageID,
			content,
			intent,
			references,
			context,
			currentURL: window.location.href,
			streaming: true,
			confirmations,
			customInstructions,
			model,
			mode,
			settings: copilotLocalStorage.settings ?? void 0,
			customCopilotID: customCopilotID?.id,
			customCopilotOwner: customCopilotID?.owner,
			parentMessageID,
			mediaContent,
			skillOptions,
			pageContext,
			requestTrace: copilotLocalStorage.getTracingRequestedFlag()
		};
		const cleanedQueryParams = this.processQueryParams(new URLSearchParams(window.location.search));
		const res = await this.makeCAPIRequest(`/threads/${threadID}/messages?${cleanedQueryParams.toString()}`, "POST", body, true, void 0, signal);
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			response: res
		};
	}
	processQueryParams(queryParams) {
		const allowedParams = ["instruction_prompt"];
		const filteredParams = new URLSearchParams();
		for (const [key, value] of queryParams) if (allowedParams.includes(key)) filteredParams.append(key, value);
		return filteredParams;
	}
	async listModels() {
		const res = await this.makeCAPIRequest(`/models`, "GET", void 0, false, "");
		if (!res.ok) return res;
		const modelsResponse = await res.json();
		return {
			status: res.status,
			ok: true,
			payload: modelsResponse.data
		};
	}
	async setModelPolicyState(modelID, state) {
		const res = await this.makeCAPIRequest(`/models/${modelID}/policy`, "POST", { state }, false, "");
		if (!res.ok) return Promise.reject(/* @__PURE__ */ new Error(`Failed to update model policy state: ${res.status}`));
	}
	/** Get the model's response for a given prompt. */
	async getSimpleCompletion(prompt, model) {
		const defaultModel = generateDefaultModel();
		const selectedModel = model ?? defaultModel.id;
		const messages = [{
			role: "user",
			content: prompt
		}];
		const response = await this.makeCAPIRequest("/chat/completions", "POST", {
			messages,
			selectedModel,
			stream: false
		}, false, "");
		if (!response.ok) return response;
		const payload = (await response.json()).choices[0]?.message?.content || "";
		return {
			status: response.status,
			ok: true,
			payload
		};
	}
	async sendFeedback({ feedback, feedbackChoice, messageId, threadId, textResponse }) {
		const body = {
			feedback,
			feedback_choice: feedbackChoice,
			message_id: messageId,
			thread_id: threadId,
			text_response: textResponse
		};
		const res = await this.makeDotcomRequest(`${this.urlPathPrefix}/feedback`, "POST", body);
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async listRepoFiles(repo, includeDirectories = false) {
		const path = treeListPath({
			repo,
			commitOid: repo.commitOID,
			includeDirectories
		});
		return this.repoFilesCache.get(path);
	}
	listRepoFilesImpl = async (path) => {
		const res = await this.makeDotcomRequest(path, "GET");
		if (!res.ok) return res;
		return {
			status: 200,
			ok: true,
			payload: await res.json()
		};
	};
	repoFilesCache = new ApiCache(this.listRepoFilesImpl);
	async querySymbols(repo, query) {
		await this.blackbirdCaches.setupWarmCachesLoop();
		return this.querySymbolsCache.get(repo.ownerLogin, repo.name, query);
	}
	querySymbolsImpl = async (ownerLogin, repo, query) => {
		const response = await this.makeDotcomRequest(`/search/suggestions?query=repo:${ownerLogin}/${repo} ${query}`, "GET");
		if (!response.ok) return response;
		return {
			status: 200,
			ok: true,
			payload: (await response.json()).suggestions.filter((suggestion) => suggestion.kind === BLACKBIRD_SUGGESTION_KIND)
		};
	};
	querySymbolsCache = new ApiCache(this.querySymbolsImpl);
	async fetchImplicitContext(url, owner, repo) {
		const response = await this.makeDotcomRequest(`${this.urlPathPrefix}/implicit-context/${owner}/${repo}/${encodeURIComponent(url)}`, "GET");
		if (!response.ok) return response;
		return {
			status: response.status,
			ok: response.ok,
			payload: await response.json()
		};
	}
	/**
	* Fetch full reference details for a PR, issue, or discussion.
	* This is used to hydrate references that may have incomplete data (e.g., from implicit context).
	*/
	async fetchReferenceDetails(owner, repo, type, number) {
		const response = await this.makeDotcomRequest(`/copilot/chat/reference/${owner}/${repo}/${type}/${number}`, "GET");
		if (!response.ok) return response;
		return {
			status: response.status,
			ok: response.ok,
			payload: await response.json()
		};
	}
	getCachedRepo(repoID) {
		return this.repoDetailsCache.get(repoID);
	}
	async fetchRepo(repoID) {
		let payload;
		if (this.repoDetailsCache.has(repoID)) payload = this.repoDetailsCache.get(repoID);
		else {
			const res = await this.makeDotcomRequest(`${this.urlPathPrefix}/repositories/${repoID}`, "GET");
			if (!res.ok) return res;
			payload = await res.json();
			this.repoDetailsCache.set(repoID, payload);
		}
		return {
			status: 200,
			ok: true,
			payload
		};
	}
	async fetchFileContents(repoID, branch, filePath) {
		const res = await this.makeDotcomRequest(`${this.urlPathPrefix}/file_contents/${repoID}/${branch}/${filePath}`, "GET");
		if (!res.ok) return res;
		return {
			status: 200,
			ok: true,
			payload: await res.json()
		};
	}
	async fetchFileContentsNwo(ownerLogin, repoName, filePath, branch) {
		let res;
		if (branch) res = await this.makeDotcomRequest(`${this.urlPathPrefix}/file_contents_nwo/${ownerLogin}/${repoName}/${encodeURIComponent(branch)}/${filePath}`, "GET");
		else res = await this.makeDotcomRequest(`${this.urlPathPrefix}/file_contents_nwo/${ownerLogin}/${repoName}/${filePath}`, "GET");
		if (!res.ok) return res;
		return {
			status: 200,
			ok: true,
			payload: await res.json()
		};
	}
	async listAgents(agentsPath) {
		const res = await verifiedFetchJSON(agentsPath);
		if (!res.ok) return {
			status: res.status,
			ok: false,
			error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
		};
		const payload = await res.json();
		return {
			status: res.status,
			ok: res.ok,
			payload
		};
	}
	async listCustomCopilots() {
		const res = await verifiedFetchJSON(`${this.urlPathPrefix}/custom_copilots`);
		if (!res.ok) return {
			status: res.status,
			ok: false,
			error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
		};
		const payload = await res.json();
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async fetchCopilotSpace(customCopilotID) {
		let url;
		const { owner, id } = customCopilotID;
		if (owner) url = `${this.urlPathPrefix}/custom_copilots/${owner}/${id}`;
		else url = `${this.urlPathPrefix}/custom_copilots/${id}`;
		const res = await verifiedFetchJSON(url);
		if (!res.ok) return {
			status: res.status,
			ok: false,
			error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
		};
		const payload = await res.json();
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async fetchCustomAgents(owner, repo) {
		const res = await this.makeCAPIRequest(`/agents/swe/custom-agents/${owner}/${repo}`, "GET", void 0, void 0, "");
		if (!res.ok) {
			if (res.status === 404) return {
				status: res.status,
				ok: true,
				payload: []
			};
			return {
				status: res.status,
				ok: false,
				error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
			};
		}
		const payload = (await res.json()).agents;
		return {
			status: res.status,
			ok: true,
			payload
		};
	}
	async hydrateReference(reference) {
		if (!HYDRATABLE_REFERENCE_TYPES.has(reference.type)) return {
			status: 204,
			ok: true,
			payload: reference
		};
		const response = await this.makeDotcomRequest(`${this.urlPathPrefix}/reference_details`, "POST", { reference });
		if (!response.ok) return response;
		return {
			status: response.status,
			ok: response.ok,
			payload: await response.json()
		};
	}
	async fetchLanguageForFileReference(reference) {
		const { repoOwner: ownerLogin, repoName: name } = reference;
		const path = window.btoa(reference.path);
		const fetchPath = blobDetectLanguage({
			ownerLogin,
			name
		}, path, true);
		const response = await this.makeDotcomRequest(fetchPath, "GET");
		if (!response.ok) return response;
		return {
			status: response.status,
			ok: response.ok,
			payload: await response.json()
		};
	}
	async fetchAutocompleteIssues(repository, query) {
		const response = await this.makeDotcomRequest(`/copilot/chat/autocomplete/issues?repo=${repository}&q=${query}`, "GET");
		return response.ok ? await response.json() : [];
	}
	async fetchAutocompletePullRequests(repository, query) {
		const response = await this.makeDotcomRequest(`/copilot/chat/autocomplete/pulls?repo=${repository}&q=${query}`, "GET");
		return response.ok ? await response.json() : [];
	}
	async fetchAutocompleteDiscussions(repository, query) {
		const response = await this.makeDotcomRequest(`/copilot/chat/autocomplete/discussions?repo=${repository}&q=${query}`, "GET");
		return response.ok ? await response.json() : [];
	}
	/**
	* Search for repositories or get top repositories.
	* This replaces the Relay/GraphQL-based repository fetching.
	*
	* The backend handles all search logic:
	* - If query contains "/", extracts owner and searches within that owner's repos
	* - If query starts with current user's login, searches user's repos first
	* - Results are merged with top repos for priority sorting
	*
	* @param query - Search query (optional, returns top repos if empty)
	* @param limit - Maximum number of results (optional, default 10)
	* @param includeForks - Include forked repositories (optional, default true)
	* @param currentRepoId - ID of current repository to prioritize (optional)
	* @param owner - Owner login to filter repositories by (optional, used for org-owned spaces)
	*/
	async fetchRepositoriesSearch(query, limit, includeForks = true, currentRepoId, owner) {
		const params = new URLSearchParams();
		if (query) params.set("q", query);
		if (limit) params.set("limit", limit.toString());
		if (!includeForks) params.set("includeForks", "false");
		if (currentRepoId) params.set("currentRepoId", currentRepoId.toString());
		if (owner) params.set("owner", owner);
		const response = await this.makeDotcomRequest(`${this.urlPathPrefix}/repositories_search?${params.toString()}`, "GET");
		if (!response.ok) return [];
		return (await response.json()).repositories.map((repo) => ({
			databaseId: repo.databaseId,
			isInOrganization: repo.isInOrganization,
			name: repo.name,
			nwo: repo.nameWithOwner,
			ownerLogin: repo.ownerLogin,
			ownerAvatarUrl: repo.ownerAvatar
		}));
	}
	async fetchTopRepositories(limit = 10, includeForks = true, currentRepoId, owner) {
		return this.fetchRepositoriesSearch(void 0, limit, includeForks, currentRepoId, owner);
	}
	async makeDotcomRequest(path, method, body) {
		const headers = {};
		for (const exp of getCopilotExperiments()) {
			const components = exp.split("=");
			const name = components[0]?.replaceAll("_", "-");
			let value = "1";
			if (components.length > 1) value = components[1] ?? "1";
			headers[`X-Experiment-${name}`] = value;
		}
		headers["X-Copilot-Api-Token"] = (await this.copilotAuthTokenProvider.getAuthToken()).value;
		try {
			const res = await verifiedFetchJSON(path, {
				method,
				body,
				headers
			});
			if (res.ok) return res;
			return {
				status: res.status,
				ok: false,
				error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again."
			};
		} catch {
			return {
				status: 500,
				ok: false,
				error: ERROR_MSG
			};
		}
	}
	get directConnectConfiguration() {
		return { integrationID: "copilot-chat" };
	}
	async makeCAPIRequest(path, method, body, streamingResponse = false, basePath = "/github/chat", signal) {
		const baseURL = this.apiURL;
		const token = await this.copilotAuthTokenProvider.getAuthToken();
		return await makeCAPIRequest({
			basePath: baseURL + basePath,
			path,
			method,
			body,
			streamingResponse,
			authToken: token,
			integrationId: this.directConnectConfiguration.integrationID,
			realIp: this.realIp,
			signal,
			apiVersion: this.apiVersion
		});
	}
	async fetchTracesByThreadID(threadID, sharedID) {
		let path = `/thread/${threadID}`;
		if (sharedID) path += `?sharedID=${encodeURIComponent(sharedID)}`;
		const res = await this.makeCAPIRequest(path, "GET", void 0, false, "/traces");
		if (!res.ok) return res;
		const tracesWithSpans = await this.processTracesResponse(res);
		return {
			status: res.status,
			ok: true,
			payload: tracesWithSpans
		};
	}
	async fetchCoffeTrace(threadID) {
		const res = await this.makeCAPIRequest(`/evaluation/thread/${threadID}`, "GET", void 0, false, "/traces");
		if (!res.ok) return res;
		const tracesWithSpans = await this.processTracesResponse(res);
		return {
			status: res.status,
			ok: true,
			payload: tracesWithSpans
		};
	}
	async processTracesResponse(res) {
		const traces = await res.json();
		const tracesWithSpans = [];
		for (const trace of traces) if (trace.spans && Array.isArray(trace.spans) && trace.id) tracesWithSpans.push({
			id: trace.id,
			spans: trace.spans
		});
		return tracesWithSpans;
	}
	async deleteTrace(threadID, traceID) {
		const res = await this.makeCAPIRequest(`/thread/${threadID}/trace/${traceID}`, "DELETE", void 0, false, "/traces");
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
	async deleteTracesForThread(threadID) {
		const res = await this.makeCAPIRequest(`/thread/${threadID}`, "DELETE", void 0, false, "/traces");
		if (!res.ok) return res;
		return {
			status: res.status,
			ok: true,
			payload: null
		};
	}
};
function isFailedApiResult(res) {
	return !res.ok;
}
var extractStructuredContent = (element) => {
	const tagName = element.tagName.toLowerCase();
	const text = element.textContent;
	if (!text || !text.trim()) return null;
	const trimmedText = text.trim();
	switch (tagName) {
		case "h1": return `# ${trimmedText}`;
		case "h2": return `## ${trimmedText}`;
		case "h3": return `### ${trimmedText}`;
		case "h4": return `#### ${trimmedText}`;
		case "p": return trimmedText;
		case "li": return `• ${trimmedText}`;
		case "code": return `\`${trimmedText}\``;
		case "pre": return `\`\`\`\n${trimmedText}\n\`\`\``;
		case "blockquote": return `> ${trimmedText}`;
		default: return trimmedText;
	}
};
function extractPageContext() {
	const contentClone = (document.querySelector("main") || document.body).cloneNode(true);
	for (const selector of [
		"script",
		"style",
		"svg",
		"iframe",
		"textarea",
		".js-header-wrapper",
		".footer",
		".sr-only",
		".react-code-file-contents"
	]) for (const el of contentClone.querySelectorAll(selector)) el.remove();
	for (const el of contentClone.querySelectorAll("*")) {
		if (!el.textContent?.trim()) {
			el.remove();
			continue;
		}
		const style = window.getComputedStyle(el);
		if (style.display === "none" || style.visibility === "hidden") el.remove();
	}
	const blocks = contentClone.querySelectorAll("p, h1, h2, h3, h4, li, td, th, blockquote, pre, code:not(pre code)");
	const lines = [];
	for (const block of blocks) {
		const formattedText = extractStructuredContent(block);
		if (formattedText) lines.push(formattedText);
	}
	const text = lines.join("\n");
	return (text.length <= MAX_BYTES ? text : `${text.substring(0, MAX_BYTES)}\n${TRUNCATED_MSG}`).replace(/\s{2,}/g, " ").trim();
}
/**
* Converts a JSON encoded SpanEntry array into a tree of SpanNodes.
*/
function processTraceData(entries) {
	const spanNodeMap = /* @__PURE__ */ new Map();
	const roots = [];
	const spanEntryToSpanNode = (entry) => {
		const node = {
			name: entry.name,
			spanId: entry.spanId,
			attributes: entry.attributes,
			startTime: entry.startTime,
			endTime: entry.endTime,
			children: [],
			sessionId: entry.sessionId,
			userId: entry.userId,
			input: entry.input,
			output: entry.output,
			metadata: entry.metadata
		};
		spanNodeMap.set(node.spanId, node);
		const parentNode = entry.parentId && spanNodeMap.get(entry.parentId);
		if (parentNode) parentNode.children.push(node);
		else roots.push(node);
		return node;
	};
	entries.map(spanEntryToSpanNode);
	return roots;
}
var TraceManager = class {
	dispatch;
	service;
	getTraceState;
	constructor(dispatch, getTraceState, apiURL, ssoOrgs) {
		this.dispatch = dispatch;
		this.service = new CopilotChatService(apiURL, ssoOrgs);
		this.getTraceState = getTraceState;
	}
	showTraceDisplay = async (value, threadId) => {
		if (value && threadId) await this.fetchAndLoadTraces(threadId);
		this.dispatch({
			type: "SET_TRACE_INFO",
			traceInfo: {
				visible: value,
				threadId: threadId ?? void 0
			}
		});
	};
	async fetchAndLoadTraces(threadId, sharedId) {
		if (!copilotFeatureFlags.requestTracing || !isStaff()) return;
		const state = this.getTraceState();
		if (state.traceInfo?.loadedThreadIds?.has(threadId)) return;
		try {
			const result = await this.service.fetchTracesByThreadID(threadId, sharedId);
			if (result.ok && result.payload.length > 0) this.addTracesToState(state, result, threadId);
			else this.dispatch({
				type: "SET_TRACE_INFO",
				traceInfo: { threadId }
			});
		} catch {}
	}
	addTracesToState(state, result, threadId) {
		const currentTraces = new Map(state.traceInfo?.traces || []);
		for (const trace of result.payload) {
			const rootNodes = processTraceData(trace.spans);
			for (const [, rootNode] of rootNodes.entries()) {
				const timestamp = new Date(rootNode.startTime).toISOString();
				const messageId = `${threadId}:${timestamp}`;
				currentTraces.set(messageId, {
					spanNode: rootNode,
					threadId,
					actualTraceId: trace.id,
					timestamp
				});
			}
		}
		this.dispatch({
			type: "SET_TRACE_INFO",
			traceInfo: {
				traces: currentTraces,
				threadId
			}
		});
	}
	async fetchCoffeTrace(threadId) {
		if (!copilotFeatureFlags.requestTracing || !isStaff()) return {
			ok: false,
			status: 403,
			error: "Tracing not available"
		};
		const state = this.getTraceState();
		const result = await this.service.fetchCoffeTrace(threadId);
		if (result.ok && result.payload.length > 0) {
			this.addTracesToState(state, result, threadId);
			return result;
		} else throw new Error(`Failed to load COFFE trace: ${result.status}`);
	}
	async deleteTraceSpansForGivenThread(threadID) {
		const res = await this.service.deleteTracesForThread(threadID);
		if (res.ok) this.dispatch({
			type: "REMOVE_TRACES_FOR_THREAD",
			threadID
		});
		return res;
	}
	async deleteTrace(threadID, traceID) {
		const res = await this.service.deleteTrace(threadID, traceID);
		if (res.ok) this.dispatch({
			type: "REMOVE_TRACE",
			traceID
		});
		return res;
	}
};
var TraceManagerContext = createContext(null);
TraceManagerContext.displayName = "TraceManagerContext";
function TraceManagerProvider(t0) {
	const $ = c(8);
	const { apiURL, children, dispatch, ssoOrgs } = t0;
	const getTraceState = useGetTraceState();
	let t1;
	if ($[0] !== apiURL || $[1] !== dispatch || $[2] !== getTraceState || $[3] !== ssoOrgs) {
		t1 = new TraceManager(dispatch, getTraceState, apiURL, ssoOrgs);
		$[0] = apiURL;
		$[1] = dispatch;
		$[2] = getTraceState;
		$[3] = ssoOrgs;
		$[4] = t1;
	} else t1 = $[4];
	const traceManager = t1;
	let t2;
	if ($[5] !== children || $[6] !== traceManager) {
		t2 = jsx(TraceManagerContext, {
			value: traceManager,
			children
		});
		$[5] = children;
		$[6] = traceManager;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
TraceManagerProvider.displayName = "TraceManagerProvider";
function useTraceManager() {
	const context = use(TraceManagerContext);
	if (context === null) throw new Error("useTraceManager must be used within a TraceManagerProvider");
	return context;
}
var emptyTraces = /* @__PURE__ */ new Map();
var emptyLoadedThreadIds = /* @__PURE__ */ new Set();
function traceReducer(state, action) {
	switch (action.type) {
		case "SET_TRACE_INFO": {
			const { visible, spanNode, messageId, threadId, actualTraceId, traces } = action.traceInfo;
			let updatedTraces = state.traceInfo?.traces || emptyTraces;
			let updatedLoadedThreadIds = state.traceInfo?.loadedThreadIds || emptyLoadedThreadIds;
			if (traces && traces.size > 0) {
				const newTraces = new Map(updatedTraces);
				for (const [msgId, traceData] of traces) newTraces.set(msgId, traceData);
				updatedTraces = newTraces;
			} else if (spanNode && messageId && threadId) {
				const newTraces = new Map(updatedTraces);
				const timestamp = new Date(spanNode.startTime).toISOString();
				newTraces.set(messageId, {
					spanNode,
					threadId,
					actualTraceId: actualTraceId || "",
					timestamp
				});
				updatedTraces = newTraces;
			}
			if (threadId && !updatedLoadedThreadIds.has(threadId)) {
				const newLoadedThreadIds = new Set(updatedLoadedThreadIds);
				newLoadedThreadIds.add(threadId);
				updatedLoadedThreadIds = newLoadedThreadIds;
			}
			const updatedVisible = visible !== void 0 ? visible : state.traceInfo?.visible || false;
			return {
				...state,
				traceInfo: {
					visible: updatedVisible,
					traces: updatedTraces,
					loadedThreadIds: updatedLoadedThreadIds
				}
			};
		}
		case "REMOVE_TRACE": {
			const currentTraces = new Map(state.traceInfo?.traces || []);
			for (const [messageId, traceData] of currentTraces) if (traceData.actualTraceId === action.traceID) {
				currentTraces.delete(messageId);
				break;
			}
			return {
				...state,
				traceInfo: {
					visible: state.traceInfo?.visible || false,
					traces: currentTraces,
					loadedThreadIds: state.traceInfo?.loadedThreadIds || /* @__PURE__ */ new Set()
				}
			};
		}
		case "REMOVE_TRACES_FOR_THREAD": {
			const currentTraces = new Map(state.traceInfo?.traces || []);
			for (const [msgId, traceData] of currentTraces) if (traceData.threadId === action.threadID) currentTraces.delete(msgId);
			return {
				...state,
				traceInfo: {
					visible: state.traceInfo?.visible || false,
					traces: currentTraces,
					loadedThreadIds: state.traceInfo?.loadedThreadIds || /* @__PURE__ */ new Set()
				}
			};
		}
	}
}
var TraceStateContext = createContext(null);
TraceStateContext.displayName = "TraceStateContext";
var TraceDispatchContext = createContext(null);
TraceDispatchContext.displayName = "TraceDispatchContext";
function TraceProvider(t0) {
	const $ = c(16);
	const { apiURL, children, ssoOrgs, testReducerState } = t0;
	let t1;
	if ($[0] !== testReducerState) {
		t1 = testReducerState || {};
		$[0] = testReducerState;
		$[1] = t1;
	} else t1 = $[1];
	const [state, dispatch] = useReducer(traceReducer, t1);
	const [stateObservable, setStateObservable] = useObservableValueRef(state);
	let t2;
	if ($[2] !== setStateObservable || $[3] !== state || $[4] !== stateObservable.current.value) {
		t2 = () => {
			if (state !== stateObservable.current.value) setStateObservable(state);
		};
		$[2] = setStateObservable;
		$[3] = state;
		$[4] = stateObservable.current.value;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== setStateObservable || $[7] !== state || $[8] !== stateObservable) {
		t3 = [
			state,
			stateObservable,
			setStateObservable
		];
		$[6] = setStateObservable;
		$[7] = state;
		$[8] = stateObservable;
		$[9] = t3;
	} else t3 = $[9];
	useLayoutEffect(t2, t3);
	let t4;
	if ($[10] !== apiURL || $[11] !== children || $[12] !== ssoOrgs || $[13] !== state || $[14] !== stateObservable) {
		t4 = jsx(TraceStateContext, {
			value: state,
			children: jsx(TraceDispatchContext, {
				value: dispatch,
				children: jsx(ObservableTraceStateProvider, {
					value: stateObservable,
					children: jsx(TraceManagerProvider, {
						apiURL,
						dispatch,
						ssoOrgs,
						children
					})
				})
			})
		});
		$[10] = apiURL;
		$[11] = children;
		$[12] = ssoOrgs;
		$[13] = state;
		$[14] = stateObservable;
		$[15] = t4;
	} else t4 = $[15];
	return t4;
}
TraceProvider.displayName = "TraceProvider";
function useTraceState() {
	const traceState = use(TraceStateContext);
	if (!traceState) throw new Error("useTraceState must be used within a TraceContext");
	return traceState;
}
function useTraceDispatchMaybe() {
	return use(TraceDispatchContext);
}
var PluginsContext = createContext([]);
PluginsContext.displayName = "PluginsContext";
function ImmersivePluginsProvider({ plugins, children }) {
	return /* @__PURE__ */ jsx(PluginsContext, {
		value: plugins,
		children
	});
}
ImmersivePluginsProvider.displayName = "ImmersivePluginsProvider";
function usePlugins() {
	return use(PluginsContext);
}
/**
* Get the active plugin from the current location
*/
function getActivePluginFromLocation(location, plugins) {
	const { pathname } = location;
	if (!pathname) return;
	const fullLocation = {
		pathname,
		search: location.search || "",
		hash: location.hash || ""
	};
	return plugins.find((plugin) => {
		if (plugin.components && plugin.components.length > 0) return shouldActivatePlugin(plugin, fullLocation);
		return false;
	});
}
/**
* Determines if a plugin should be activated for the given location.
*
* If the plugin has explicit routes defined, those take precedence (backward compatibility).
* If the plugin only has components with routes, activation is derived from component routes.
*
* @param plugin The plugin to check
* @param location The current location
* @returns true if the plugin should be activated
*/
function shouldActivatePlugin(plugin, location) {
	if (plugin.components && plugin.components.length > 0) return plugin.components.some((component) => component.routes.some((route) => {
		if (route instanceof RegExp) return route.test(location.pathname);
		return route(location);
	}));
	return false;
}
var copilotChatTextAreaId = "copilot-chat-textarea";
var copilotChatSearchInputId = "copilot-chat-topic-search";
var reviewUserMessage = "Review";
var copilotChatHeaderButtonID = "copilot-chat-header-button";
var copilotChatPanelID = "copilot-chat-panel";
var copilotChatPanelInnerID = "copilot-chat-panel";
/**
* This module implements the uploadable assets flow. The process consists of three steps:
*
* 1. {@link createPolicy|Create a policy}.
* 2. {@link uploadFile|Upload the file}.
* 3. {@link complete|Complete the upload}.
*
* While similar to {@link app/assets/modules/github/upload/attachment-upload.ts|`AttachmentUpload`},
* this implementation differs by using fetch instead of XHR and is not tied to the file-attachment-element,
* as we implement a React-first upload flow.
*
* @module
*/
/**
* Creates a database entry and returns instructions for uploading the file through Memory Alpha.
*
* @param policyUrl You'd want to be calling UploadPoliciesController#create
*
* @returns A promise that resolves with the policy
*/
async function createPolicy(policyRequest, policyUrl, signal) {
	const res = await verifiedFetch(policyUrl, {
		method: "POST",
		body: formDataFromObject(policyRequest),
		signal
	});
	const json = await res.json();
	if (!res.ok) throw new GenericServerError("Error creating policy", json.errors);
	const policy = json;
	if (!policy.asset_upload_url) throw new Error("Unexpected error, missing asset upload URL");
	return policy;
}
/**
* Transfers the file to the relevant storage provider. A successful upload returns a 204 response.
*
* @param file The file to upload
* @param policy The policy returned from {@link createPolicy}
*
* @returns A promise that resolves when the upload is complete
*/
async function uploadFile(file, policy, signal) {
	const res = await fetch(policy.upload_url, {
		method: "POST",
		body: formDataFromObject({
			...policy.form,
			file
		}),
		signal,
		credentials: isEnterprise() ? "include" : "same-origin"
	});
	if (!res.ok) throw new Error(await res.text());
}
/**
* Marks the database entry as complete and returns the asset.
*
* @param policy The policy returned from {@link createPolicy}
*
* @returns A promise that resolves with the asset
*/
async function complete(policy, signal) {
	const res = await verifiedFetch(policy.asset_upload_url, {
		method: "PUT",
		signal
	});
	const json = await res.json();
	if (!res.ok) throw new GenericServerError("Error completing the upload", json.errors);
	return json;
}
var GenericServerError = class extends Error {
	errors;
	constructor(message, errors) {
		super(message);
		this.name = "GenericServerError";
		this.errors = errors;
	}
};
function formDataFromObject(o) {
	const formData = new FormData();
	const oCleaned = Object.entries(o).filter(([, value]) => value != null);
	for (const [key, value] of oCleaned) formData.append(key, value);
	return formData;
}
function resource(load) {
	let value;
	let promise = null;
	return {
		load() {
			if (!promise) promise = load().then((v) => {
				value = v;
				return value;
			});
			return promise;
		},
		read() {
			if (value) return value;
			throw this.load();
		}
	};
}
var POLICY_URL = "/upload/policies/copilot-chat-attachments";
async function calculateImageDimensions(file, attachment) {
	if (attachment.width !== void 0 && attachment.height !== void 0) return {
		width: attachment.width,
		height: attachment.height
	};
	if (!file.type.startsWith("image/")) return {
		width: void 0,
		height: void 0
	};
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = (loadedFileEvent) => {
			if (!loadedFileEvent.target?.result || typeof loadedFileEvent.target.result !== "string") {
				resolve({
					width: void 0,
					height: void 0
				});
				return;
			}
			const image = new Image();
			image.onload = () => {
				attachment.width = image.width;
				attachment.height = image.height;
				resolve({
					width: image.width,
					height: image.height
				});
			};
			image.onerror = () => reject(/* @__PURE__ */ new Error("Failed to load image for dimension extraction"));
			image.src = loadedFileEvent.target.result;
		};
		reader.readAsDataURL(file);
	});
}
var UploadableFileAttachment = class {
	file;
	width;
	height;
	#dimensions;
	#signal;
	abortController;
	key;
	threadID;
	isLoaded = false;
	hasError = false;
	constructor(key, file, forThreadID = null) {
		this.file = file;
		this.abortController = new AbortController();
		this.#signal = this.abortController.signal;
		this.key = key;
		this.#dimensions = this.getDimensions();
		this.threadID = forThreadID;
	}
	#resource = resource(async () => {
		const policy = await createPolicy({
			name: this.file.name,
			size: String(this.file.size),
			content_type: this.file.type,
			thread_id: this.threadID
		}, POLICY_URL, this.#signal);
		await uploadFile(this.file, policy, this.#signal);
		const asset = await complete(policy, this.#signal);
		const dimensions = await this.#dimensions;
		this.width = dimensions.width;
		this.height = dimensions.height;
		this.isLoaded = true;
		return asset;
	});
	prefetch() {
		return this.#resource.load();
	}
	get previewUrl() {
		return this.#resource.read().href;
	}
	/**
	* Gets the durable asset URL for the file.
	*
	* @returns A promise that resolves with the asset url
	*/
	async url() {
		return (await this.#resource.load()).href;
	}
	async getDimensions() {
		return calculateImageDimensions(this.file, this);
	}
};
var MAX_MESSAGES_PER_THREAD = 3e3;
var MAX_MESSAGES_FOR_THREAD_RENAMING = 8;
var multipleAgentsAttemptMessage = "Only one agent is allowed per thread, and their context can't be shared. If you want to interact with another agent, please start a new thread and @ mention the new agent.";
var modelsCache = null;
var CopilotChatManager = class {
	dispatch;
	traceDispatch;
	service;
	getChatState;
	hasCEorCBAccess;
	timings = { startTime: 0 };
	streamer;
	messageAbortController;
	reloadingThreadPromise;
	fetchingThreadID = null;
	afterThreadReloadCallback;
	isFirstMessageInNewThread = false;
	plugins;
	eventCustomInstructions;
	constructor(dispatch, apiURL, ssoOrganizations, getChatState, realIp, chatService, hasCEorCBAccess, plugins, apiVersion, traceDispatch) {
		this.dispatch = dispatch;
		this.traceDispatch = traceDispatch;
		this.service = chatService ?? new CopilotChatService(apiURL, ssoOrganizations, realIp, apiVersion);
		this.getChatState = getChatState;
		this.hasCEorCBAccess = !!hasCEorCBAccess;
		this.plugins = plugins;
	}
	/**
	* Helper to fetch repository for custom instructions.
	* Creates a RepositoryReference from the fetched repo.
	*/
	async fetchRepoForInstructions(repoID) {
		const res = await this.service.fetchRepo(repoID);
		if (res.ok) return makeRepositoryReference(res.payload);
		return null;
	}
	/**
	* Opens a new chat window
	* @param thread the thread to display (leave null to try to find an appropriate thread to open or start a new thread)
	* @param currentView
	* @param source what is triggering the open, e.g. 'search-bar' or 'header'
	* @param expectedReference a reference the thread should be relevant to, if the default one doesn't reference this, create a new thread.
	* @returns
	*/
	async openChat(thread, currentView, source, chatVisibleSettingPath, expectedReference, forceNewThread) {
		this.dispatch({
			type: "OPEN_COPILOT_CHAT",
			source
		});
		if (currentView === "thread") await this.findOrStartNewThread(thread, expectedReference, forceNewThread);
		copilotLocalStorage.setCollapsedState(false);
		setCopilotButtonAriaExpanded(this.getChatState().entryPointId ?? "copilot-chat-header-button", true);
		if (chatVisibleSettingPath) {
			const data = new FormData();
			data.set("copilot_chat_visible", "true");
			verifiedFetch(chatVisibleSettingPath, {
				method: "PUT",
				body: data
			});
		}
	}
	closeChat() {
		this.dispatch({ type: "CLOSE_COPILOT_CHAT" });
		copilotLocalStorage.setCollapsedState(true);
		setCopilotButtonAriaExpanded(this.getChatState().entryPointId ?? "copilot-chat-header-button", false);
	}
	hideChat(chatVisibleSettingPath) {
		this.dispatch({ type: "HIDE_COPILOT_CHAT" });
		this.closeChat();
		if (chatVisibleSettingPath) {
			const data = new FormData();
			data.set("copilot_chat_visible", "false");
			verifiedFetch(chatVisibleSettingPath, {
				method: "PUT",
				body: data
			});
		}
	}
	toggleRepoCustomInstructions(value) {
		this.dispatch({
			type: "TOGGLE_REPO_CUSTOM_INSTRUCTIONS",
			value
		});
		copilotLocalStorage.setRepoCustomInstructionsState(value);
	}
	viewAllThreads() {
		this.dispatch({ type: "VIEW_ALL_THREADS" });
	}
	viewCurrentThread() {
		this.dispatch({ type: "VIEW_CURRENT_THREAD" });
	}
	maxMessagesReached() {
		return this.getChatState().messages.length >= MAX_MESSAGES_PER_THREAD;
	}
	setShouldReplaceHistoryOnNavigation(value) {
		this.dispatch({
			type: "SET_SHOULD_REPLACE_HISTORY_ON_NAVIGATION",
			value
		});
	}
	/**
	* Emit first_message_rendered telemetry if this is the first message in a new thread.
	* Clears the flag so subsequent calls are no-ops.  Called from every terminal path
	* (first content token, success, error, stop, abort) so the metric captures ALL
	* visible UI responses — not just successful completions.
	*/
	emitFirstMessageRenderedIfNeeded() {
		if (!this.isFirstMessageInNewThread) return;
		this.isFirstMessageInNewThread = false;
		const { mode, model } = this.getChatState();
		sendEvent("dotcom_chat.first_message_rendered", {
			mode,
			model: model?.id
		});
		sendCustomMetric({
			name: "COPILOT_DOTCOM_CHAT_FIRST_MESSAGE_RENDERED",
			value: 1,
			tags: { mode }
		});
	}
	/**
	* Marks the next message completion as the first message in a new thread,
	* so that dotcom_chat.first_message_rendered is emitted when the stream finishes.
	* Used by the dashboard entrypoint flow as the normal `!thread` guard inside
	* sendChatMessage/sendNewMessage is never reached on the new manager instance
	*/
	markFirstMessageInNewThread() {
		this.isFirstMessageInNewThread = true;
	}
	async sendChatMessage({ thread, content, references, topic, context, confirmations, customInstructions, model, customCopilotId, intent, parentMessageId, modeOverride, skillOptions, noSend, mediaContent }) {
		const repo = topic;
		let threadToUse = thread;
		if (!threadToUse) {
			const pendingUserMessage = buildMessage({
				role: "user",
				content,
				mediaContent: [],
				references
			});
			this.dispatch({
				type: "SET_PENDING_FIRST_MESSAGE",
				message: pendingUserMessage
			});
			try {
				threadToUse = await this.createThread({ customCopilotId });
			} catch (e) {
				let errorMessage = "An unexpected error has occurred.";
				if (e instanceof Error) errorMessage = e.message;
				this.handleSendMessageError(threadToUse, makeBasicError(errorMessage), content, "ERROR_THREAD_CREATION", errorMessage);
				return null;
			}
		}
		mediaContent ||= references.length ? await Promise.all(references.filter((ref) => ref.type === "image").map(async (ref) => {
			const { attachment } = ref;
			if (!attachment.threadID) {
				attachment.threadID = threadToUse?.id || null;
				try {
					await attachment.prefetch();
				} catch {
					const errorMessage = "An error occurred uploading image attachments";
					this.handleSendMessageError(threadToUse, makeBasicError(errorMessage), content, "ERROR_IMAGE_UPLOAD", errorMessage);
				}
			}
			const url = await attachment.url();
			const file = attachment.file;
			return {
				mediaType: file.type,
				name: file.name,
				url,
				chatAttachmentUrl: url,
				width: attachment.width,
				height: attachment.height
			};
		})) : [];
		let filteredReferences = references.filter((ref) => ref.type !== "image");
		filteredReferences = filteredReferences.filter((ref) => ref.type !== "figma" || !ref.authenticationRequired);
		if (threadToUse != null) this.clearEditedReferencesFromSessionStorage(threadToUse.id);
		if (!thread) {
			const { mode: firstMessageMode } = this.getChatState();
			sendEvent("dotcom_chat.first_message_sent", {
				mode: firstMessageMode,
				model: model?.id
			});
			sendCustomMetric({
				name: "COPILOT_DOTCOM_CHAT_FIRST_MESSAGE_SENT",
				value: 1,
				tags: { mode: firstMessageMode }
			});
			this.isFirstMessageInNewThread = true;
		}
		if (noSend) return {
			thread: threadToUse,
			references: filteredReferences,
			mediaContent
		};
		await this.sendNewMessage(threadToUse, content, mediaContent, filteredReferences, intent, repo, context, confirmations, customInstructions, model, customCopilotId, parentMessageId, modeOverride, skillOptions);
		return null;
	}
	FindLastMessageID() {
		const activeMessages = getActiveMessages(this.getChatState().messages);
		return activeMessages[activeMessages.length - 1]?.id || "root";
	}
	async retryLastUnsuccessfulChatMessage(thread) {
		const { currentTopic, context, customInstructions, model } = this.getChatState();
		const repo = currentTopic;
		const lastUserMessage = getActiveMessages(this.getChatState().messages).findLast((m) => m.role === "user");
		if (!lastUserMessage?.content) return;
		const references = lastUserMessage.references?.length ? lastUserMessage.references : thread.currentReferences ?? [];
		const mediaContent = lastUserMessage.mediaContent || [];
		this.dispatch({ type: "MESSAGES_CLEAR_LAST_ERROR" });
		this.unselectPreviousChildMessage(lastUserMessage);
		let parentMessageID = "";
		if (lastUserMessage.clientSide) {
			const lastServerMessage = getActiveMessages(this.getChatState().messages).findLast((message) => !message.clientSide);
			if (lastServerMessage) if (lastServerMessage.role === "user") parentMessageID = lastServerMessage.parentMessageID || "root";
			else parentMessageID = lastServerMessage.id;
			else parentMessageID = "root";
		} else parentMessageID = lastUserMessage.id;
		return this.sendMessage(thread, lastUserMessage.content, mediaContent, references, lastUserMessage.intent, context, repo, customInstructions, model, void 0, parentMessageID);
	}
	/** Resends the user message that is a parent of an assistant message and creates a subthread
	* This supports the retry button in the assistant messages */
	async retryUserChatMessage(thread, message, selectedModel) {
		const { currentTopic, context, customInstructions, model } = this.getChatState();
		const repo = currentTopic;
		let parentMessage = void 0;
		if (message.parentMessageID) parentMessage = this.getChatState().messages.findLast((m) => m.id === message.parentMessageID);
		if (!parentMessage || !parentMessage.content) return;
		this.unselectPreviousChildMessage(parentMessage);
		const references = parentMessage.references || [];
		const mediaContent = parentMessage.mediaContent || [];
		return this.sendMessage(thread, parentMessage.content, mediaContent, references, message.intent, context, repo, customInstructions, selectedModel || model, void 0, parentMessage.id);
	}
	/** Edits the user message and creates a subthread */
	async editUserChatMessage(thread, message, content) {
		if (!content) return;
		const { currentTopic, context, customInstructions, messages, model } = this.getChatState();
		const repo = currentTopic;
		const parentMessage = getParentMessage(messages, message);
		if (!parentMessage) return;
		const parentMessageID = parentMessage?.id || "";
		const confirmationResponses = message.clientConfirmations ?? [];
		const references = message.references || [];
		const mediaContent = message.mediaContent || [];
		const userMessage = buildMessage({
			role: "user",
			content,
			mediaContent,
			references,
			thread,
			confirmationResponses,
			parentMessageID
		});
		const hasInstructions = copilotFeatureFlags.customInstructionsFileReferences ? await hasCustomInstructionsAsync(references, (repoID) => this.fetchRepoForInstructions(repoID)) : hasCustomInstructions(references);
		const instructionsOwners = copilotFeatureFlags.customInstructionsFileReferences ? await customInstructionsOwnersFromReferencesAsync(references, (repoID) => this.fetchRepoForInstructions(repoID)) : customInstructionsOwnersFromReferences(references);
		this.dispatch({
			type: "MESSAGE_ADDED",
			message: userMessage,
			repoHasCustomInstructions: Boolean(hasInstructions),
			usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
			customInstructionsOwners: instructionsOwners
		});
		if (this.reloadingThreadPromise) {
			this.dispatch({
				type: "WAITING_ON_COPILOT",
				loading: true
			});
			this.afterThreadReloadCallback = () => {
				this.dispatch({
					type: "MESSAGE_ADDED",
					message: userMessage,
					repoHasCustomInstructions: Boolean(hasInstructions),
					usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
					customInstructionsOwners: instructionsOwners
				});
			};
			if (!await this.reloadingThreadPromise) return;
		}
		let ancestor = parentMessage;
		while (ancestor) {
			if (!ancestor.clientSide) break;
			ancestor = getParentMessage(messages, ancestor);
		}
		return this.sendMessage(thread, content, mediaContent, references, message.intent, context, repo, customInstructions, model, void 0, ancestor?.id || "");
	}
	handleFeedback(message, feedback) {
		this.dispatch({
			type: "MESSAGE_FEEDBACK",
			message,
			feedback
		});
	}
	setSelectedMessage(message) {
		this.clearEditedReferencesFromSessionStorage(message.threadID);
		this.dispatch({
			type: "MESSAGES_SET_SELECTED_MESSAGE",
			message
		});
	}
	unselectPreviousChildMessage(message) {
		this.dispatch({
			type: "MESSAGES_UNSELECT_PREVIOUS_MESSAGE",
			message
		});
	}
	async stopStreaming() {
		if (this.streamer) {
			await this.streamer.stop();
			this.streamer = void 0;
		} else this.messageAbortController?.abort();
		this.emitFirstMessageRenderedIfNeeded();
		this.dispatch({
			type: "MESSAGE_STREAMING_STOPPED",
			timings: this.completeTiming()
		});
	}
	async getSystemPrompt() {
		const { mode } = this.getChatState();
		const effectiveMode = copilotFeatureFlags.immersiveEmbedded ? "immersive" : mode;
		return await this.systemPrompt(effectiveMode);
	}
	async createThread(opts) {
		const { customCopilotId, preventThreadSelection = false, scopeId, savedMessageSource = "immersive" } = opts || {};
		const res = await this.service.createThread(customCopilotId, scopeId);
		let thread;
		if (res.ok) {
			thread = res.payload;
			copilotLocalStorage.migrateNullThreadToNewThread(thread.id, savedMessageSource);
			this.dispatch({
				type: "THREAD_CREATED",
				thread,
				preventThreadSelection
			});
			return thread;
		} else throw new Error(res.error);
	}
	async sendNewMessage(thread, content, mediaContent, references, intent, repo, context, confirmations, customInstructions, model, customCopilotId, parentMessageID, modeOverride, skillOptions) {
		const { mode } = this.getChatState();
		const userMessage = buildMessage({
			role: "user",
			content,
			mediaContent,
			references,
			thread,
			confirmationResponses: confirmations ? [confirmations] : [],
			parentMessageID: parentMessageID || this.FindLastMessageID(),
			skillOptions
		});
		const hasInstructions = copilotFeatureFlags.customInstructionsFileReferences ? await hasCustomInstructionsAsync(references, (repoID) => this.fetchRepoForInstructions(repoID)) : hasCustomInstructions(references);
		const instructionsOwners = copilotFeatureFlags.customInstructionsFileReferences ? await customInstructionsOwnersFromReferencesAsync(references, (repoID) => this.fetchRepoForInstructions(repoID)) : customInstructionsOwnersFromReferences(references);
		this.dispatch({
			type: "MESSAGE_ADDED",
			message: userMessage,
			repoHasCustomInstructions: Boolean(hasInstructions),
			usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
			customInstructionsOwners: instructionsOwners
		});
		if (!thread) {
			sendEvent("dotcom_chat.first_message_sent", {
				mode,
				model: model?.id
			});
			sendCustomMetric({
				name: "COPILOT_DOTCOM_CHAT_FIRST_MESSAGE_SENT",
				value: 1,
				tags: { mode }
			});
			this.isFirstMessageInNewThread = true;
			try {
				thread = await this.createThread({ customCopilotId });
			} catch (e) {
				let errorMessage = "An unexpected error has occurred.";
				if (e instanceof Error) errorMessage = e.message;
				this.handleSendMessageError(thread, makeBasicError(errorMessage), content, "ERROR_THREAD_CREATION", errorMessage);
				return;
			}
		}
		this.dispatch({
			type: "THREAD_UPDATED",
			thread: {
				id: thread.id,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			}
		});
		this.dispatch({ type: "CLEAR_CURRENT_REFERENCES" });
		if (model && (mode !== "assistive" || copilotFeatureFlags.immersiveEmbedded)) copilotLocalStorage.setModel(thread.id, model, false);
		let overrideParentMessageID = "";
		if (!parentMessageID) {
			const activeMessages = getActiveMessages(this.getChatState().messages);
			const lastMessage = activeMessages[activeMessages.length - 1];
			if (lastMessage) if (lastMessage.clientSide) parentMessageID = activeMessages.findLast((message) => !message.clientSide && message.role === "assistant")?.id || "root";
			else parentMessageID = lastMessage.id;
			else parentMessageID = "root";
			if (this.reloadingThreadPromise) {
				this.dispatch({
					type: "WAITING_ON_COPILOT",
					loading: true
				});
				this.afterThreadReloadCallback = (messages) => {
					if (messages.length === 0) return;
					const reloadedLastMessage = messages[messages.length - 1];
					if (!reloadedLastMessage) return;
					overrideParentMessageID = reloadedLastMessage.id;
					userMessage.parentMessageID = overrideParentMessageID;
					this.dispatch({
						type: "MESSAGE_ADDED",
						message: userMessage,
						repoHasCustomInstructions: Boolean(hasInstructions),
						usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
						customInstructionsOwners: instructionsOwners
					});
				};
				if (!await this.reloadingThreadPromise) return;
			}
		}
		return this.sendMessage(thread, content, mediaContent, references, intent, context, repo, customInstructions, model, confirmations, overrideParentMessageID || parentMessageID, modeOverride, skillOptions);
	}
	async sendMessage(thread, content, mediaContent, references, intent, context, repo, customInstructions, model, confirmations, parentMessageID, modeOverride, skillOptions) {
		intent ??= CopilotChatIntents.conversation;
		const confirmationsArray = confirmations ? [confirmations] : [];
		const streamingMessage = buildMessage({
			role: "assistant",
			content: "",
			mediaContent: [],
			thread,
			parentMessageID
		});
		streamingMessage.messageIndex = -1;
		this.dispatch({
			type: "WAITING_ON_COPILOT",
			loading: true
		});
		const implicitContext = !references.length || references.length === 1 && references[0]?.type === "repository" ? context : void 0;
		sendEvent("copilot.implicit_context", {
			usedImplicitContext: !!implicitContext,
			type: implicitContext?.[0]?.type,
			count: implicitContext?.length
		});
		if (!references.length && repo) references = [makeRepositoryReference(repo)];
		const messageCustomInstructions = [];
		if (this.repoInstructionsEnabled()) {
			const instructionsFromReferences = copilotFeatureFlags.customInstructionsFileReferences ? await getCustomInstructionsFromReferencesAsync(references, (repoID) => this.fetchRepoForInstructions(repoID)) : getCustomInstructionsFromReferences(references);
			messageCustomInstructions.push(...instructionsFromReferences);
		}
		if (customInstructions?.type === "Organization" && !messageCustomInstructions.find((i) => i.type === "Organization")) messageCustomInstructions.push(customInstructions);
		const effectiveCustomInstructions = customInstructions ?? this.eventCustomInstructions;
		if (effectiveCustomInstructions?.type === "Assistant") messageCustomInstructions.push(effectiveCustomInstructions);
		const orgInstructions = messageCustomInstructions.find((i) => i.type === "Organization");
		if (orgInstructions) references.push(makeOrgInstructionsReference(orgInstructions.owner));
		const customInstructionsArray = messageCustomInstructions.map((i) => i.prompt);
		const { mode } = this.getChatState();
		this.timings = { startTime: Date.now() };
		this.streamer = void 0;
		this.messageAbortController = new AbortController();
		try {
			const defaultOptions = {
				threadID: thread.id,
				messageID: streamingMessage.id,
				content,
				mediaContent,
				intent,
				mode: modeOverride || mode,
				references,
				context: implicitContext ?? [],
				confirmations: confirmationsArray,
				customInstructions: customInstructionsArray,
				model: model?.id,
				customCopilotID: copilotSpaceIdFromThread(thread),
				parentMessageID,
				signal: this.messageAbortController.signal,
				skillOptions
			};
			const options = this.activePlugin?.overrideCreateMessageOptions ? await this.activePlugin.overrideCreateMessageOptions(defaultOptions) : defaultOptions;
			const res = await this.service.createMessageStreaming(options);
			if (!res.ok) {
				if (this.messageAbortController.signal.aborted) {
					this.emitFirstMessageRenderedIfNeeded();
					return;
				}
				this.handleSendMessageError(thread, makeBasicError(res.error), content, "ERROR_MESSAGE_STREAMING", res.error);
			} else {
				const reader = res.response.body?.getReader();
				if (!reader) {
					this.handleSendMessageError(thread, makeBasicError(ERROR_MSG), content, "ERROR_STREAM_READER", ERROR_MSG);
					return;
				}
				streamingMessage.requestID = res.response.headers.get("x-github-request-id") || void 0;
				const streamer = new CopilotChatMessageStreamer(reader);
				this.streamer = streamer;
				this.dispatch({
					type: "MESSAGE_STREAMING_STARTED",
					message: streamingMessage
				});
				await this.handleStreamingMessage(thread, streamer);
				await this.generateThreadName(thread);
			}
		} finally {
			this.streamer = void 0;
			this.messageAbortController = void 0;
		}
	}
	repoInstructionsEnabled() {
		return !!copilotLocalStorage.getRepoCustomInstructionsState();
	}
	async populateReferenceLanguage(reference) {
		const response = await this.service.fetchLanguageForFileReference(reference);
		if (response.ok && response.payload.language) {
			const { languageName, languageId } = response.payload.language;
			this.replaceReference(reference, {
				...reference,
				languageName,
				languageId
			});
		}
	}
	clearEditedReferencesFromSessionStorage(threadID) {
		clearSessionStorageByKeyPrefix(`edited-${threadID}-`);
	}
	addReference(reference, source, opts = {}) {
		this.dispatch({
			type: "ADD_REFERENCE",
			reference,
			source,
			implicit: !!opts.implicit
		});
		if (isFileReference(reference) && (reference.languageId === void 0 || reference.languageName === void 0)) this.populateReferenceLanguage(reference);
	}
	removeReference(reference) {
		if (reference) {
			abortInProcessImageDownloads([reference]);
			this.dispatch({
				type: "REMOVE_REFERENCES",
				references: [reference]
			});
		}
	}
	removeReferences(references) {
		abortInProcessImageDownloads(references);
		this.dispatch({
			type: "REMOVE_REFERENCES",
			references
		});
	}
	clearCurrentReferences = (keepTypes) => {
		if (!keepTypes || !keepTypes.includes("image")) abortInProcessImageDownloads(this.getChatState().currentReferences);
		this.dispatch({
			type: "CLEAR_CURRENT_REFERENCES",
			keepTypes
		});
	};
	clearAllReferences = () => {
		abortInProcessImageDownloads(this.getChatState().currentReferences);
		this.dispatch({ type: "CLEAR_ALL_REFERENCES" });
	};
	clearImplicitReferences() {
		this.dispatch({ type: "CLEAR_IMPLICIT_REFERENCES" });
	}
	promoteImplicitReference(reference) {
		this.dispatch({
			type: "PROMOTE_IMPLICIT_REFERENCE",
			reference
		});
	}
	/**
	* Replace the given reference in `currentReferences`. The reference to delete will be matched based on ID, and if
	* it is not found the operation will be a no-op.
	*/
	replaceReference(referenceToDelete, referenceToInsert) {
		this.dispatch({
			type: "REPLACE_REFERENCE",
			referenceToDelete,
			referenceToInsert
		});
	}
	setImageAttachmentUploaded(referenceId, dotcomAttachment) {
		this.dispatch({
			type: "IMAGE_UPLOADED",
			referenceId,
			dotcomAttachment
		});
	}
	selectModel(model, updateLocalStorage = true, updateDefault = true) {
		this.dispatch({
			type: "SELECT_MODEL",
			model
		});
		if (updateLocalStorage) copilotLocalStorage.setModel(this.getChatState().selectedThreadID, model, updateDefault);
	}
	get activePlugin() {
		return getActivePluginFromLocation(location, this.plugins);
	}
	setCopilotSettings(settings) {
		copilotLocalStorage.settings = settings;
	}
	async selectThread(thread, options) {
		const { clearTopic, includeThreads = true } = options ?? {};
		await this.fetchModels();
		await this.stopStreaming();
		this.dispatch({ type: "CLEAR_SHARED_THREAD_CHANNEL" });
		this.dispatch({
			type: "SELECT_THREAD",
			thread,
			clearTopic
		});
		const thingsToFetch = [];
		thingsToFetch.push(this.fetchMessages(thread?.id || null));
		if (includeThreads) thingsToFetch.push(this.fetchThreads());
		await Promise.all(thingsToFetch);
	}
	addMessage(role, thread, content, mediaContent, references, clientConfirmations, clientSkillConfirmations) {
		const message = buildMessage({
			role,
			content,
			mediaContent,
			references,
			thread,
			confirmationResponses: clientConfirmations,
			clientSkillConfirmations,
			parentMessageID: this.FindLastMessageID()
		});
		this.dispatch({
			type: "MESSAGE_ADDED",
			message
		});
	}
	async renameThread(thread, newName) {
		if ((await this.service.renameThread(thread.id, newName)).ok) this.dispatch({
			type: "THREAD_UPDATED",
			thread: {
				id: thread.id,
				name: newName
			}
		});
	}
	async generateThreadName(thread) {
		if (!thread.id || thread.id.trim() === "") return;
		const messages = this.getChatState().messages;
		if (thread.name !== "" && messages.length > MAX_MESSAGES_FOR_THREAD_RENAMING) return;
		const res = await this.service.generateThreadName(thread.id);
		if (res.ok) this.dispatch({
			type: "THREAD_UPDATED",
			thread: {
				id: thread.id,
				name: res.payload
			}
		});
	}
	dismissAmbientError() {
		this.dispatch({ type: "DISMISS_AMBIENT_ERROR" });
	}
	addAmbientError(message) {
		this.dispatch({
			type: "ADD_AMBIENT_ERROR",
			message
		});
		const { mode } = this.getChatState();
		sendEvent("dotcom_chat.activate.error", {
			target: "ERROR_AMBIENT",
			mode,
			message
		});
	}
	async clearThread(thread) {
		if ((await this.service.clearThread(thread.id)).ok) this.dispatch({
			type: "CLEAR_THREAD",
			threadID: thread.id
		});
	}
	async deleteThreadKeepSelection(thread) {
		this.dispatch({
			type: "DELETE_THREAD_KEEP_SELECTION",
			thread
		});
		const res = await this.service.deleteThread(thread.id);
		if (!res.ok) this.dispatch({
			type: "DELETE_THREAD_ERROR",
			thread,
			error: res.error
		});
	}
	async deleteAllThreadKeepSelection(threads) {
		this.dispatch({
			type: "DELETE_ALL_THREADS_KEEP_SELECTION",
			threads
		});
		const threadIds = threads.map((thread) => thread.id);
		const batchSize = 100;
		for (let i = 0; i < threadIds.length; i += batchSize) {
			const batch = threadIds.slice(i, i + batchSize);
			const res = await this.service.deleteAllThreads({ threadIDs: batch });
			if (!res.ok) this.dispatch({
				type: "DELETE_ALL_THREADS_ERROR",
				threads,
				error: res.error
			});
		}
	}
	async deleteThread(thread) {
		this.clearEditedReferencesFromSessionStorage(thread.id);
		this.dispatch({
			type: "DELETE_THREAD",
			thread
		});
		const res = await this.service.deleteThread(thread.id);
		if (!res.ok) this.dispatch({
			type: "DELETE_THREAD_ERROR",
			thread,
			error: res.error
		});
	}
	generateSuggestions(context) {
		const suggestions = getThreadStaticSuggestions(context);
		this.dispatch({
			type: "SUGGESTIONS_GENERATED",
			suggestions
		});
	}
	clearSuggestions() {
		this.dispatch({ type: "CLEAR_SUGGESTIONS" });
	}
	async handleOpenPanelEvent(thread, e, chatIsOpen, topic, model) {
		const payload = e.payload;
		const newThreadIsOpen = !thread && chatIsOpen;
		const activeThreadIsOpen = thread && chatIsOpen;
		if (payloadIsIcebreaker(payload) || payloadIsNewThread(payload)) {
			await this.selectThread(null);
			thread = null;
		} else if (payloadHasIntent(payload, [CopilotChatIntents.reviewPr])) {
			this.addMessage("user", payload.thread, reviewUserMessage, [], payload.references);
			this.addMessage("assistant", payload.thread, payload.completion, [], payload.references);
			this.selectThread(payload.thread, { includeThreads: false });
		} else if (newThreadIsOpen) {} else if (copilotFeatureFlags.copilotChatOpeningThreadSwitch) if (payloadIsAttachToThread(payload) && !chatIsOpen || activeThreadIsOpen) thread = await this.findOrStartNewThread(thread);
		else {
			await this.selectThread(null);
			thread = null;
		}
		else thread = await this.findOrStartNewThread(thread);
		copilotLocalStorage.setCollapsedState(false);
		const eventCustomInstructions = "customInstructions" in payload ? payload.customInstructions : void 0;
		this.eventCustomInstructions = eventCustomInstructions;
		this.dispatch({
			type: "HANDLE_EVENT_START",
			references: payload.references,
			id: payload.id,
			suggestionsContext: "suggestionsContext" in payload ? payload.suggestionsContext : void 0,
			customInstructions: eventCustomInstructions
		});
		if (payloadHasIntent(payload, [
			CopilotChatIntents.conversation,
			CopilotChatIntents.discussFileDiff,
			CopilotChatIntents.reviewPr
		]) && !payloadIsIcebreaker(payload)) return;
		let source = `blob ${payload.intent}`;
		if (payload.id) source = `element ${e.payload.id}`;
		sendEvent("copilot.open_copilot_chat", { source });
		await this.sendNewMessage(thread, payload.content, [], payload.references ?? [], payload.intent, isRepository(topic) ? topic : void 0, void 0, void 0, void 0, model, void 0);
	}
	async handleSearchCopilotEvent(e, model) {
		const topic = await this.fetchCurrentRepo(e.repoNwo);
		const ref = topic ? [{
			type: "repository",
			...topic
		}] : [];
		if (copilotFeatureFlags.copilotSearchBarRedirect) {
			const url = new URL("/copilot", window.location.origin);
			if (e.content) {
				const promptContent = e.content.replace(/\b\w+:[^\s]+/g, "").replace(/\s+/g, " ").trim();
				if (promptContent) url.searchParams.set("prompt", promptContent);
			}
			window.location.href = url.toString();
			sendEvent("dotcom_chat.activate", {
				target: `MAIN_NAVIGATION_SEARCH_BAR_TO_IMMERSIVE`,
				mode: "search-bar"
			});
		} else {
			this.openChat(null, "thread", "search-bar");
			await this.sendNewMessage(null, e.content, [], ref, CopilotChatIntents.conversation, void 0, void 0, void 0, void 0, model);
			sendEvent("copilot.open_copilot_chat", { source: "search-bar" });
		}
	}
	handleAddReferenceEvent(e) {
		this.addReference(e.reference, "event");
		if (e.openPanel) this.dispatch({
			type: "OPEN_COPILOT_CHAT",
			source: "event",
			id: e.id
		});
	}
	handleSymbolChangedEvent(e) {
		const symbolContext = e.context;
		this.dispatch({
			type: "IMPLICIT_CONTEXT_UPDATED",
			context: [symbolContext]
		});
	}
	sortAndFilterThreads(threads, filter = () => true) {
		return Array.from(threads.values()).filter((thread) => filter(thread) && !thread.scopeID).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
	}
	async sendMessageToNewThread(prevThreadID, message, refs, context, model, source = "immersive") {
		if (message.trim() === "") {
			const [inferred, newMessage] = this.tryInferMessage(refs);
			if (!inferred || !newMessage) return;
			else message = newMessage;
		}
		if (prevThreadID) {
			copilotLocalStorage.setSavedMessageFast(prevThreadID, source, null);
			copilotLocalStorage.clearCurrentReferences(prevThreadID);
		}
		await this.sendNewMessage(null, message, [], refs, void 0, void 0, context, void 0, void 0, model);
	}
	resolvePromise = () => {};
	startThreadReload() {
		this.reloadingThreadPromise = new Promise((resolve) => {
			this.resolvePromise = resolve;
		});
	}
	cancelThreadReload() {
		this.resolvePromise(false);
		this.resolvePromise = () => {};
		this.reloadingThreadPromise = void 0;
		this.afterThreadReloadCallback = void 0;
		this.fetchingThreadID = null;
	}
	async fetchMessages(threadID, reloadThread = false, expectNewMessages = false) {
		const refs = copilotLocalStorage.getCurrentReferences(threadID);
		if (!threadID) {
			this.threadDataLoaded(threadID, [], refs || []);
			return () => {};
		}
		if (!reloadThread) this.dispatch({
			type: "MESSAGES_UPDATED",
			state: "loading"
		});
		const originalMessages = this.getChatState().messages;
		this.fetchingThreadID = threadID;
		const getMessages = async (shouldExpectNewMessages) => {
			const res = await this.service.listMessages(threadID);
			if (reloadThread && this.fetchingThreadID !== threadID) return false;
			if (res.ok) if (shouldExpectNewMessages && res.payload.messages.length === originalMessages.length) return getMessages(false);
			else {
				const thread = res.payload.thread;
				this.threadDataLoaded(threadID, res.payload.messages, refs || thread.currentReferences || []);
				if (this.afterThreadReloadCallback) {
					this.afterThreadReloadCallback(res.payload.messages);
					this.afterThreadReloadCallback = void 0;
				}
				return true;
			}
			else {
				this.setMessageUpdatedError(res.status, res.payload?.missingOrgIds);
				this.afterThreadReloadCallback = void 0;
				return false;
			}
		};
		const result = await getMessages(expectNewMessages);
		return () => {
			this.resolvePromise(result);
			this.resolvePromise = () => {};
			this.reloadingThreadPromise = void 0;
		};
	}
	async fetchSharedThreadMessages(threadID) {
		if (!threadID) return;
		this.dispatch({
			type: "MESSAGES_UPDATED",
			state: "loading"
		});
		const res = await this.service.listSharedThreadMessages(threadID);
		this.dispatch({
			type: "FETCH_SHARED_THREAD_MESSAGES",
			ok: res.ok,
			status: res.status,
			shareId: threadID,
			originalThreadId: res.ok ? res.payload.thread.id : void 0
		});
		if (res.ok) {
			this.threadDataLoaded(threadID, res.payload.messages, []);
			await this.fetchModels();
			const lastModelID = res.payload.messages?.at(-1)?.model;
			const lastModel = lastModelID && this.getChatState().availableModels?.find((m) => m.id === lastModelID);
			if (lastModel) this.selectModel(lastModel);
		} else this.setMessageUpdatedError(res.status, res.payload?.missingOrgIds);
	}
	setMessageUpdatedError(status, missingOrgIds) {
		this.dispatch({
			type: "MESSAGES_UPDATED",
			state: "error",
			...status === 404 ? {
				notFound: true,
				missingOrgIds
			} : {}
		});
	}
	selectReference(reference) {
		this.dispatch({
			type: "SELECT_REFERENCE",
			reference
		});
	}
	setTopRepositoryTopics(topics) {
		this.dispatch({
			type: "SET_TOP_REPOSITORIES",
			topics
		});
	}
	async handleStreamingMessage(thread, streamer) {
		try {
			for await (const message of streamer.stream()) this.processStreamingMessage(thread, message);
		} catch (e) {
			let error;
			if (this.isWrappedStreamingResponseError(e)) error = this.getStreamingErrorMessage(e.error);
			else {
				error = makeBasicError(ERROR_MSG);
				const { mode } = this.getChatState();
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_STREAMING_GENERIC",
					mode,
					message: "An unexpected error occurred during message streaming."
				});
			}
			this.handleSendMessageError(thread, error);
			return;
		}
	}
	isWrappedStreamingResponseError(e) {
		return !!e && typeof e === "object" && "error" in e && !!e.error && typeof e.error === "object" && "errorType" in e.error && typeof e.error.errorType === "string" && MESSAGE_STREAMING_ERROR_TYPES.includes(e.error.errorType);
	}
	processStreamingMessage(thread, messageResponse) {
		this.timings.firstByte ??= Date.now();
		switch (messageResponse.type) {
			case "content":
				this.timings.firstToken ??= Date.now();
				this.emitFirstMessageRenderedIfNeeded();
				this.dispatch({
					type: "MESSAGE_STREAMING_TOKEN_ADDED",
					token: messageResponse.body
				});
				break;
			case "functionCall":
				if (functionIsSupported(messageResponse.name)) this.dispatch({
					type: "MESSAGE_STREAMING_FUNCTION_CALLED",
					name: messageResponse.name,
					status: messageResponse.status,
					arguments: messageResponse.arguments,
					errorMessage: messageResponse.errorMessage,
					references: messageResponse.references,
					statusMessage: messageResponse.statusMessage,
					callId: messageResponse.callId
				});
				break;
			case "confirmation":
				this.dispatch({
					type: "MESSAGE_STREAMING_CONFIRMATION",
					title: messageResponse.title,
					message: messageResponse.message,
					confirmation: messageResponse.confirmation
				});
				break;
			case "threadTitle":
				this.dispatch({
					type: "THREAD_UPDATED",
					thread: {
						...thread,
						name: messageResponse.title
					}
				});
				break;
			case "complete":
				messageResponse.references = filterOutCustomCopilotReferences(messageResponse.references);
				this.dispatch({
					type: "MESSAGE_STREAMING_COMPLETED",
					messageResponse,
					timings: this.completeTiming()
				});
				this.handleSendMessageSuccess(thread);
				break;
			case "error": {
				const errMsg = this.getStreamingErrorMessage(messageResponse);
				this.handleSendMessageError(thread, errMsg);
				break;
			}
			case "debug":
				console.log("Prompt Body:", messageResponse.body);
				break;
			case "trace": {
				const streamingMessageId = this.getChatState().streamingMessage?.createdAt;
				try {
					if (!messageResponse.traceId) {
						console.error("Received trace data without trace ID from backend, ignoring trace");
						break;
					}
					const rootNodes = processTraceData(messageResponse.spans);
					if (rootNodes[0]) {
						const messageId = streamingMessageId || messageResponse.traceId;
						this.traceDispatch?.({
							type: "SET_TRACE_INFO",
							traceInfo: {
								spanNode: rootNodes[0],
								messageId,
								threadId: thread.id,
								actualTraceId: messageResponse.traceId
							}
						});
					}
				} catch (e) {
					console.error("Failed to process trace info:", e);
				}
				break;
			}
			case "agentError":
				this.dispatch({
					type: "AGENT_ERROR",
					error: {
						type: messageResponse.agentErrorType,
						code: messageResponse.code,
						message: messageResponse.message,
						identifier: messageResponse.identifier
					}
				});
				break;
		}
	}
	getStreamingErrorMessage(res) {
		const { mode } = this.getChatState();
		switch (res.errorType) {
			case "publicCode": {
				let docsURL = "https://docs.github.com/en/copilot/managing-copilot/managing-copilot-as-an-individual-subscriber/managing-copilot-policies-as-an-individual-subscriber";
				let message = /* @__PURE__ */ jsxs(Fragment$1, { children: [
					"This response cannot be shown because it references public code, which is restricted by",
					" ",
					/* @__PURE__ */ jsx("a", {
						href: docsURL,
						children: "your Copilot settings"
					}),
					"."
				] });
				if (this.hasCEorCBAccess) {
					docsURL = "https://docs.github.com/en/enterprise-cloud@latest/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-policies-for-copilot-in-your-organization";
					message = /* @__PURE__ */ jsxs(Fragment$1, { children: [
						"This response cannot be shown because it references public code, which is restricted by",
						" ",
						/* @__PURE__ */ jsx("a", {
							href: docsURL,
							children: "your organization's Copilot settings"
						}),
						"."
					] });
				}
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_PUBLIC_CODE",
					mode,
					message: "This response cannot be shown because it references public code, which is restricted by your Copilot settings."
				});
				return {
					type: "publicCode",
					isError: true,
					message,
					retryable: true
				};
			}
			case "filtered": {
				const message = /* @__PURE__ */ jsxs(Fragment$1, { children: [
					"This response has been filtered because it violates ",
					/* @__PURE__ */ jsx("a", {
						href: "https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#github-copilot",
						children: "GitHub's safety policies"
					}),
					"."
				] });
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_FILTERED_RESPONSE",
					mode,
					message: "This response has been filtered because it violates GitHub's safety policies."
				});
				return {
					type: "filtered",
					isError: true,
					message,
					retryable: false
				};
			}
			case "contentTooLarge":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_CONTENT_TOO_LARGE",
					mode,
					message: ERRORS_BY_STATUS[413] || "I'm sorry but there was an error. Please try again."
				});
				return makeNonRetryableError(ERRORS_BY_STATUS[413] || "I'm sorry but there was an error. Please try again.");
			case "rateLimit":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_RATE_LIMIT",
					mode,
					message: ERRORS_BY_STATUS[429] || "I'm sorry but there was an error. Please try again."
				});
				return makeBasicError(ERRORS_BY_STATUS[429] || "I'm sorry but there was an error. Please try again.");
			case "agentUnauthorized": {
				const details = JSON.parse(res.description);
				const authorizeURL = `You haven't authorized ${details.name} to access your account. You can do that by going here: ${window.location.origin}/login/oauth/authorize?client_id=${details.client_id}`;
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_AGENT_UNAUTHORIZED",
					mode,
					message: authorizeURL
				});
				return {
					type: "agentUnauthorized",
					isError: true,
					message: authorizeURL,
					details
				};
			}
			case "agentRequest": {
				const details = JSON.parse(res.description);
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_AGENT_REQUEST",
					mode,
					message: details.message
				});
				return {
					type: "agentRequest",
					isError: true,
					message: details.message,
					details
				};
			}
			case "multipleAgentsAttempt":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_MULTIPLE_AGENTS_ATTEMPT",
					mode,
					message: multipleAgentsAttemptMessage
				});
				return makeBasicError(multipleAgentsAttemptMessage);
			case "networkError":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_NETWORK",
					mode,
					message: ERRORS_BY_STATUS[408] || "I'm sorry but there was an error. Please try again."
				});
				return makeBasicError(ERRORS_BY_STATUS[408] || "I'm sorry but there was an error. Please try again.");
			case "quotaExceeded":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_QUOTA_EXCEEDED",
					mode,
					message: res.description || ERRORS_BY_STATUS[402] || "I'm sorry but there was an error. Please try again."
				});
				return makeNonRetryableError(res.description || ERRORS_BY_STATUS[402] || "I'm sorry but there was an error. Please try again.");
			case "billingNotConfigured":
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_BILLING_NOT_CONFIGURED",
					mode,
					message: res.description || ERRORS_BY_STATUS[402] || "I'm sorry but there was an error. Please try again."
				});
				return makeBillingNotConfiguredError();
			default:
				sendEvent("dotcom_chat.activate.error", {
					target: "ERROR_EXCEPTION",
					mode,
					message: ERRORS_BY_TYPE[res.errorType] || "I'm sorry but there was an error. Please try again."
				});
				return makeBasicError(ERRORS_BY_TYPE[res.errorType] || "I'm sorry but there was an error. Please try again.");
		}
	}
	handleSendMessageSuccess(thread) {
		copilotLocalStorage.clearCurrentReferences(thread.id);
		this.emitFirstMessageRenderedIfNeeded();
		this.dispatch({
			type: "WAITING_ON_COPILOT",
			loading: false
		});
	}
	handleSendMessageError(thread, error, submittedInput, telemetryTarget, errorMessage = ERROR_MSG) {
		this.emitFirstMessageRenderedIfNeeded();
		if (thread && submittedInput) copilotLocalStorage.setSavedUserMessageOnError(thread.id, submittedInput);
		const message = buildMessage({
			role: "assistant",
			content: "",
			mediaContent: [],
			error,
			thread,
			parentMessageID: getActiveMessages(this.getChatState().messages).findLast((m) => m.role === "user")?.id || "root"
		});
		this.dispatch({
			type: "MESSAGE_ADDED",
			message
		});
		this.dispatch({
			type: "WAITING_ON_COPILOT",
			loading: false
		});
		this.dispatch({
			type: "MESSAGE_STREAMING_FAILED",
			timings: this.completeTiming()
		});
		if (telemetryTarget) {
			const { mode } = this.getChatState();
			sendEvent("dotcom_chat.activate.error", {
				target: telemetryTarget,
				mode,
				message: errorMessage
			});
		}
	}
	async fetchModels() {
		if (modelsCache) {
			const { availableModels } = this.getChatState();
			if (!availableModels || modelsCache.length > availableModels.length) this.dispatch({
				type: "MODELS_LOADED",
				models: modelsCache
			});
			return;
		}
		this.dispatch({ type: "MODELS_LOADING" });
		const res = await this.service.listModels();
		if (res.ok) {
			const models = toCopilotChatModels(res.payload);
			modelsCache = models;
			this.dispatch({
				type: "MODELS_LOADED",
				models
			});
			const storedModelID = copilotLocalStorage.getModel(this.getChatState().selectedThreadID)?.id;
			const model = models.find((m) => m.id === storedModelID) || models.find((m) => m.is_chat_default);
			if (model) this.dispatch({
				type: "SELECT_MODEL",
				model
			});
		} else this.dispatch({
			type: "MODELS_LOADING_ERROR",
			error: res.error
		});
	}
	fetchThreadsPromise = null;
	async fetchThreads() {
		if (!this.fetchThreadsPromise) try {
			this.fetchThreadsPromise = this.fetchThreadsImpl();
			return await this.fetchThreadsPromise;
		} finally {
			this.fetchThreadsPromise = null;
		}
		return this.fetchThreadsPromise;
	}
	async fetchThreadsImpl() {
		this.dispatch({ type: "THREADS_LOADING" });
		const res = await this.service.fetchThreads();
		if (!res.ok) {
			setTimeout(() => this.dispatch({
				type: "THREADS_LOADING_ERROR",
				message: res.error,
				status: res.status
			}), 100);
			return null;
		}
		const { threads, threadsHidden } = res.payload;
		setTimeout(() => this.dispatch({
			type: "THREADS_LOADED",
			threads,
			threadsHidden
		}), 100);
		return threads;
	}
	async fetchSharedThreads() {
		this.dispatch({ type: "SHARED_THREADS_LOADING" });
		const res = await this.service.fetchSharedThreads();
		if (!res.ok) {
			setTimeout(() => this.dispatch({
				type: "SHARED_THREADS_LOADING_ERROR",
				message: res.error
			}), 100);
			return null;
		}
		setTimeout(() => this.dispatch({ type: "SHARED_THREADS_LOADED" }), 100);
		return res.payload;
	}
	async fetchLatestThread(threadId) {
		const res = await this.service.fetchLatestThread(threadId);
		if (!res.ok) return null;
		if (res.payload) this.dispatch({
			type: "LATEST_THREAD_LOADED",
			latestThread: res.payload
		});
		return res.payload;
	}
	async continueSharedThread(sharedID) {
		if (!sharedID) {
			this.dispatch({ type: "THREAD_CONTINUED_FAILED" });
			return null;
		}
		this.dispatch({
			type: "MESSAGES_UPDATED",
			state: "loading"
		});
		const res = await this.service.continueSharedThread(sharedID);
		if (res.ok) {
			const { thread, messages } = res.payload;
			this.dispatch({
				type: "THREAD_CONTINUED",
				thread
			});
			this.dispatch({
				type: "MESSAGES_UPDATED",
				state: "loaded",
				messages
			});
		} else return null;
		return res.payload;
	}
	async unshareAllThreads() {
		const res = await this.service.unshareAllThreads();
		if (res.ok) {
			const threads = Array.from(this.getChatState().threads.values());
			for (const thread of threads) if (thread.sharedAt) this.dispatch({
				type: "THREAD_UPDATED",
				thread: {
					id: thread.id,
					sharedAt: void 0,
					sharedID: void 0
				}
			});
			return res;
		} else {
			this.dispatch({
				type: "ADD_AMBIENT_ERROR",
				message: res.error || "Failed to unshare all threads"
			});
			return res;
		}
	}
	/**
	* Finds a thread to show to the user in a new chat, or starts a new thread if none are found.
	* @param currentThread The current thread to show to the user.
	* @param expectedReference A reference the thread should be relevant to, if the default one doesn't reference this, create a new thread.
	*/
	async findOrStartNewThread(currentThread, expectedReference, forceNewThread) {
		let thread = null;
		if (currentThread) thread = currentThread;
		else if (!forceNewThread) {
			const previouslySelectedThreadID = copilotLocalStorage.selectedThreadID || void 0;
			thread = await this.fetchLatestThread(previouslySelectedThreadID);
		}
		if (thread && (isThreadOlderThan4Hours(thread) || !!thread.customCopilotID)) thread = null;
		if (thread && expectedReference) {
			const response = await this.service.listMessages(thread.id);
			if (response.ok) {
				const messages = response.payload.messages;
				const len = messages?.length;
				if (len >= 2 && !messages[len - 2]?.references?.find((ref) => referencesAreEqual(ref, expectedReference))) thread = null;
			}
		}
		await this.selectThread(thread, { includeThreads: false });
		return thread;
	}
	async systemPrompt(mode) {
		const res = await this.service.getSystemPrompt(mode);
		return res.ok ? res.payload.prompt : "";
	}
	async fetchAgents(agentsPath) {
		const res = await this.service.listAgents(agentsPath);
		let agents = [];
		if (res.ok) {
			agents = res.payload;
			this.dispatch({
				type: "SET_AGENTS",
				agents
			});
		}
		return agents;
	}
	async fetchCopilotSpace(customCopilotID) {
		const res = await this.service.fetchCopilotSpace(customCopilotID);
		let customCopilot = {};
		if (res.ok) customCopilot = res.payload;
		return customCopilot;
	}
	async fetchCurrentRepo(repoID) {
		const res = await this.service.fetchRepo(repoID);
		if (res.ok) {
			this.dispatch({
				type: "ADD_REFERENCE",
				reference: makeRepositoryReference(res.payload),
				source: "currentRepo"
			});
			return res.payload;
		}
	}
	async fetchImplicitContext(url, owner, repo, addAsVisibleReferences = true) {
		const res = await this.service.fetchImplicitContext(url, owner, repo);
		if (res.ok) {
			const context = !res.payload ? void 0 : Array.isArray(res.payload) ? res.payload : [res.payload];
			this.dispatch({
				type: "IMPLICIT_CONTEXT_UPDATED",
				context
			});
			const state = this.getChatState();
			if (addAsVisibleReferences && state.mode === "immersive" && context && context.length > 0) {
				const refsToAdd = copilotFeatureFlags.immersiveEmbeddedImplicitReferences ? context : context.filter((ref) => ref?.type === "repository");
				if (refsToAdd.length > 0) {
					const hydratedRefs = await Promise.all(refsToAdd.map(async (ref) => {
						if (!ref) return ref;
						if (ref.type === "pull-request" || ref.type === "issue" || ref.type === "discussion") {
							const typeParam = ref.type === "pull-request" ? "pull_request" : ref.type;
							const hydratedRes = await this.service.fetchReferenceDetails(owner, repo, typeParam, ref.number);
							if (hydratedRes.ok && hydratedRes.payload) return hydratedRes.payload;
						}
						return ref;
					}));
					for (const ref of hydratedRefs) if (ref) {
						const existingRef = this.getChatState().currentReferences?.find((existing) => referencesAreEqual(existing, ref));
						if (existingRef) this.replaceReference(existingRef, ref);
						else this.addReference(ref, "implicit-context", { implicit: true });
					}
				}
			}
			if (context && context.length > 0 && context[0] !== void 0) this.generateSuggestions(context[0]);
		} else return;
	}
	clearCurrentTopic = () => {
		this.dispatch({
			type: "CURRENT_TOPIC_UPDATED",
			topic: void 0,
			state: "loaded"
		});
	};
	showTopicPicker = (value = true) => {
		this.dispatch({
			type: "SHOW_TOPIC_PICKER",
			show: value
		});
	};
	startEditingMessage = (messageId) => this.dispatch({
		type: "START_EDITING_MESSAGE",
		messageId
	});
	cancelEditingMessage = () => this.dispatch({ type: "CANCEL_EDITING_MESSAGE" });
	threadDataLoaded(threadId, messages, references) {
		this.dispatch({
			type: "MESSAGES_UPDATED",
			messages,
			state: "loaded"
		});
		this.dispatch({
			type: "REFERENCES_LOADED",
			references
		});
	}
	dismissEditorUpsellBanner() {
		const data = new FormData();
		data.set("copilot_editor_upsell_banner_dismissed", "true");
		verifiedFetch("/github-copilot/preferences", {
			method: "PUT",
			body: data
		});
		this.dispatch({ type: "DISMISS_EDITOR_UPSELL_BANNER" });
	}
	tryInferMessage(references) {
		if (references) {
			if (references.find((ref) => ref.type === "image")) return [true, "Describe this image"];
		}
		return [false, void 0];
	}
	setWrapCodeLines(value) {
		this.dispatch({
			type: "SET_WRAP_CODE_LINES",
			value
		});
		copilotLocalStorage.setWrapCodeLines(value);
	}
	clearDefaultRecipient() {
		this.dispatch({ type: "CLEAR_DEFAULT_RECIPIENT" });
	}
	completeTiming() {
		return {
			...this.timings,
			endTime: Date.now()
		};
	}
	/**
	* Generates a unique key for a custom copilot based on its ID.
	* This is used to manage pending threads for different custom copilots.
	* @param customCopilotId - The ID of the custom copilot, or null for the default copilot
	* @returns A string key representing the custom copilot
	*/
	getCustomCopilotKey(customCopilotId) {
		return customCopilotId ? `${customCopilotId.owner}:${customCopilotId.id}` : "default";
	}
	/**
	* Retrieves a thread by its ID
	* @param threadId - The ID of the thread to retrieve
	* @returns The thread with the specified ID, or null if not found
	*/
	getThreadById(threadId) {
		if (!threadId) return null;
		return this.getChatState().threads.get(threadId) || null;
	}
};
function payloadIsAttachToThread(payload) {
	return payloadHasIntent(payload, [CopilotChatIntents.conversation]) && "attachThread" in payload && payload.attachThread;
}
function payloadIsNewThread(payload) {
	return payloadHasIntent(payload, [CopilotChatIntents.conversation]) && "newThread" in payload && payload.newThread;
}
function payloadIsIcebreaker(payload) {
	return payloadHasIntent(payload, [CopilotChatIntents.explain, CopilotChatIntents.suggest]) || payloadHasIntent(payload, [CopilotChatIntents.conversation]) && payloadHasContent(payload);
}
function payloadHasContent(payload) {
	return "content" in payload && typeof payload.content == "string";
}
function payloadHasIntent(payload, intents) {
	return new Set(intents).has(payload.intent);
}
function functionIsSupported(name) {
	return SUPPORTED_FUNCTIONS.includes(name);
}
function makeBasicError(message) {
	return {
		isError: true,
		message,
		type: "basic",
		retryable: true
	};
}
function makeBillingNotConfiguredError() {
	return {
		isError: true,
		message: /* @__PURE__ */ jsxs(Fragment$1, { children: [
			"You have Copilot licenses from multiple organizations or enterprises. To use premium requests, please select a billing entity in your ",
			/* @__PURE__ */ jsx("a", {
				href: COPILOT_BILLING_SETTINGS_URL,
				children: "Copilot billing settings"
			}),
			"."
		] }),
		type: "basic",
		retryable: false
	};
}
function makeNonRetryableError(message, type) {
	return {
		isError: true,
		message,
		type: type || "basic",
		retryable: false
	};
}
function setCopilotButtonAriaExpanded(entryPointId, ariaExpanded) {
	document.getElementById(entryPointId)?.setAttribute("aria-expanded", ariaExpanded ? "true" : "false");
}
/**
* Used to abort any active downloads when references are dropped.
* @param removedReferences - references that were removed from the current references
*/
function abortInProcessImageDownloads(removedReferences) {
	for (const ref of removedReferences) if (ref.type === "image") {
		const attachment = ref.attachment;
		if (attachment instanceof UploadableFileAttachment) attachment.abortController.abort("Reference removed before upload completed");
	}
}
var ObservableChatStateContext = createContext(null);
ObservableChatStateContext.displayName = "ObservableChatStateContext";
function ObservableChatStateProvider({ children, value }) {
	return /* @__PURE__ */ jsx(ObservableChatStateContext, {
		value,
		children
	});
}
/**
* Returns a constant reference to a function that can be used inside a callback to get the current version of the chat state.
*
* The returned `getChatState()` function should only be used inside an event handler or callback. If it is used in a render
* method, it may return outdated state.
*/
ObservableChatStateProvider.displayName = "ObservableChatStateProvider";
function useGetChatState() {
	const o = use(ObservableChatStateContext);
	if (!o || !o.current) throw new Error("useGetChatState can only be used inside a CopilotChatProvider");
	return useCallback(() => o.current.value, [o]);
}
function useObservableChatStateContext() {
	return use(ObservableChatStateContext);
}
var CopilotChatManagerContext = createContext(null);
CopilotChatManagerContext.displayName = "CopilotChatManagerContext";
function CopilotChatManagerProvider(t0) {
	const $ = c(24);
	const { apiURL, state, dispatch, ssoOrganizations, children, realIp, hasCEorCBAccess, apiVersion } = t0;
	const getChatState = useGetChatState();
	const plugins = usePlugins();
	const traceDispatch = useTraceDispatchMaybe();
	let t1;
	if ($[0] !== apiURL || $[1] !== apiVersion || $[2] !== dispatch || $[3] !== getChatState || $[4] !== hasCEorCBAccess || $[5] !== plugins || $[6] !== realIp || $[7] !== ssoOrganizations || $[8] !== traceDispatch) {
		t1 = new CopilotChatManager(dispatch, apiURL, ssoOrganizations, getChatState, realIp, void 0, hasCEorCBAccess, plugins, apiVersion, traceDispatch);
		$[0] = apiURL;
		$[1] = apiVersion;
		$[2] = dispatch;
		$[3] = getChatState;
		$[4] = hasCEorCBAccess;
		$[5] = plugins;
		$[6] = realIp;
		$[7] = ssoOrganizations;
		$[8] = traceDispatch;
		$[9] = t1;
	} else t1 = $[9];
	const manager = t1;
	const { licenseType } = useEntitlement();
	const currentReferencesLengthRef = useRef(state.currentReferences.length);
	let t2;
	if ($[10] !== state.currentReferences.length) {
		t2 = () => {
			currentReferencesLengthRef.current = state.currentReferences.length;
		};
		$[10] = state.currentReferences.length;
		$[11] = t2;
	} else t2 = $[11];
	useEffect(t2);
	let t3;
	if ($[12] !== manager || $[13] !== state.chatIsOpen || $[14] !== state.mode) {
		t3 = () => {
			const controller = new AbortController();
			const isEmbeddedImmersive = copilotFeatureFlags.immersiveEmbedded && state.mode === "immersive";
			const fetchContextPage = async (addAsVisibleReferences) => {
				const hash = window.location.hash;
				const pathName = window.location.pathname;
				const url = window.location.hash ? `${pathName}${hash}` : pathName;
				const urlParts = url.slice(1).split("/");
				if (urlParts.length < 2) return;
				const owner = urlParts[0];
				const repo = urlParts[1];
				if (!owner || !repo) return;
				await manager.fetchImplicitContext(url, owner, repo, addAsVisibleReferences);
			};
			const voidFetch = (addAsVisibleReferences_0) => {
				fetchContextPage(addAsVisibleReferences_0);
			};
			const debouncedFetch = debounce(() => voidFetch(!isEmbeddedImmersive), 500);
			const watchHistoryEvents = function watchHistoryEvents() {
				const { replaceState, pushState } = window.history;
				window.history.replaceState = function(...t4) {
					const args = t4;
					replaceState.apply(window.history, args);
					manager.clearSuggestions();
					window.dispatchEvent(new Event("replaceState"));
				};
				window.history.pushState = function(...t5) {
					const args_0 = t5;
					pushState.apply(window.history, args_0);
					manager.clearSuggestions();
					window.dispatchEvent(new Event("pushState"));
				};
				window.addEventListener("popstate", debouncedFetch, { signal: controller.signal });
				window.addEventListener("replaceState", debouncedFetch, { signal: controller.signal });
				window.addEventListener("pushState", debouncedFetch, { signal: controller.signal });
			};
			if (state.chatIsOpen) {
				voidFetch(true);
				watchHistoryEvents();
			}
			return () => {
				controller.abort();
			};
		};
		$[12] = manager;
		$[13] = state.chatIsOpen;
		$[14] = state.mode;
		$[15] = t3;
	} else t3 = $[15];
	let t4;
	if ($[16] !== licenseType || $[17] !== manager || $[18] !== state.chatIsOpen || $[19] !== state.mode) {
		t4 = [
			manager,
			state.chatIsOpen,
			state.mode,
			licenseType
		];
		$[16] = licenseType;
		$[17] = manager;
		$[18] = state.chatIsOpen;
		$[19] = state.mode;
		$[20] = t4;
	} else t4 = $[20];
	useEffect(t3, t4);
	let t5;
	if ($[21] !== children || $[22] !== manager) {
		t5 = jsx(CopilotChatManagerContext, {
			value: manager,
			children
		});
		$[21] = children;
		$[22] = manager;
		$[23] = t5;
	} else t5 = $[23];
	return t5;
}
CopilotChatManagerProvider.displayName = "CopilotChatManagerProvider";
function useChatManager() {
	const context = use(CopilotChatManagerContext);
	if (!context) throw new Error("useChatManager must be used within a CopilotChatManagerProvider");
	return context;
}
var CopilotChatDispatchContext = createContext(null);
CopilotChatDispatchContext.displayName = "CopilotChatDispatchContext";
var emptySet = /* @__PURE__ */ new Set();
function CopilotChatProvider(t0) {
	const $ = c(63);
	const { children, topic, workerPath, threadId, refs, selectedReference, mode, ssoOrganizations, chatIsOpen, chatIsVisible, chatVisibleSettingPath, agents, customCopilots, messages, testReducerState, realIp, currentView, copilotChatPayload } = t0;
	const restoredChatState = useRestoredChatState(threadId, mode);
	let restoredMessages = restoredChatState.restoredMessages;
	const restoredThreadTitle = restoredChatState.restoredThreadTitle;
	if (restoredMessages) {
		let t1;
		if ($[0] !== restoredMessages) {
			t1 = constructMessagesHierarchy(restoredMessages);
			$[0] = restoredMessages;
			$[1] = t1;
		} else t1 = $[1];
		restoredMessages = t1;
	}
	let t1;
	if ($[2] !== topic) {
		t1 = topic ? makeRepositoryReference(topic) : void 0;
		$[2] = topic;
		$[3] = t1;
	} else t1 = $[3];
	const topicAsReference = t1;
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = getDefaultModel(null, null);
		$[4] = t2;
	} else t2 = $[4];
	const defaultModel = t2;
	let t3;
	if ($[5] !== agents || $[6] !== chatIsOpen || $[7] !== chatIsVisible || $[8] !== chatVisibleSettingPath || $[9] !== copilotChatPayload.agentsEnabled || $[10] !== copilotChatPayload.agentsPath || $[11] !== copilotChatPayload.apiURL || $[12] !== copilotChatPayload.autoSubmit || $[13] !== copilotChatPayload.currentUserLogin || $[14] !== copilotChatPayload.customCopilotsEnabled || $[15] !== copilotChatPayload.customCopilotsIndividualAccessEnabled || $[16] !== copilotChatPayload.customInstructions || $[17] !== copilotChatPayload.hasCEorCBAccess || $[18] !== copilotChatPayload.optedInToPreviewFeatures || $[19] !== copilotChatPayload.optedInToUserFeedback || $[20] !== copilotChatPayload.personalInstructions || $[21] !== copilotChatPayload.plan || $[22] !== copilotChatPayload.renderBetaLabel || $[23] !== copilotChatPayload.reviewLab || $[24] !== copilotChatPayload.sharedThreadChannel || $[25] !== copilotChatPayload.showCopilotSpacesMcpBanner || $[26] !== copilotChatPayload.showDecoupledPRModeBanner || $[27] !== currentView || $[28] !== customCopilots || $[29] !== messages || $[30] !== mode || $[31] !== refs || $[32] !== restoredMessages || $[33] !== restoredThreadTitle || $[34] !== selectedReference || $[35] !== ssoOrganizations || $[36] !== testReducerState || $[37] !== threadId || $[38] !== topic || $[39] !== topicAsReference || $[40] !== workerPath) {
		t3 = testReducerState || {
			threadSelectedAt: /* @__PURE__ */ new Date(),
			threadsLoading: {
				state: "pending",
				error: null
			},
			messagesLoading: {
				state: "pending",
				error: null
			},
			messagesRestored: !!restoredMessages,
			slashCommandLoading: {
				state: "pending",
				error: null
			},
			showTopicPicker: mode !== "immersive" && (!threadId || mode === "assistive") && !topic,
			topicLoading: {
				state: "pending",
				error: null
			},
			threads: /* @__PURE__ */ new Map(),
			restoredThreadTitle,
			model: defaultModel,
			availableModels: [defaultModel],
			modelsLoading: {
				state: "pending",
				error: null
			},
			messages: messages ?? restoredMessages ?? [],
			streamingMessage: null,
			selectedThreadID: threadId,
			currentTopic: void 0,
			chatIsOpen: Boolean(chatIsOpen),
			isWaitingOnCopilot: false,
			isWaitingOnAttachment: false,
			attachmentProcessingType: null,
			currentUserLogin: copilotChatPayload.currentUserLogin,
			apiUrl: copilotChatPayload.apiURL,
			currentReferences: topicAsReference ? [topicAsReference, ...refs] : refs,
			implicitReferences: emptySet,
			findFileWorkerPath: workerPath,
			currentView: currentView || "thread",
			selectedReference: selectedReference ?? null,
			mode,
			currentRepository: topic,
			ssoOrganizations,
			context: void 0,
			customInstructions: copilotChatPayload.customInstructions,
			chatIsVisible,
			chatVisibleSettingPath,
			renderBetaLabel: copilotChatPayload.renderBetaLabel,
			topRepositoriesCache: void 0,
			agentsPath: copilotChatPayload.agentsPath,
			customCopilotsEnabled: copilotChatPayload.customCopilotsEnabled ?? false,
			customCopilotsIndividualAccessEnabled: copilotChatPayload.customCopilotsIndividualAccessEnabled ?? true,
			optedInToPreviewFeatures: copilotChatPayload.optedInToPreviewFeatures,
			optedInToUserFeedback: copilotChatPayload.optedInToUserFeedback,
			agents,
			customCopilots,
			reviewLab: copilotChatPayload.reviewLab,
			repoCustomInstructionsEnabled: copilotLocalStorage.getRepoCustomInstructionsState(),
			ambientError: void 0,
			personalInstructions: copilotChatPayload.personalInstructions ?? null,
			threadHasNewMessages: false,
			sharedThreadsLoading: {
				state: "pending",
				error: null
			},
			skillOptions: { deepCodeSearch: false },
			wrapCodeLines: copilotLocalStorage.getWrapCodeLines(),
			showCopilotSpacesMcpBanner: copilotChatPayload.showCopilotSpacesMcpBanner ?? false,
			sharedThreadChannel: copilotChatPayload.sharedThreadChannel,
			autoSubmit: copilotChatPayload.autoSubmit ?? false,
			plan: copilotChatPayload.plan,
			hasCEorCBAccess: copilotChatPayload.hasCEorCBAccess,
			agentsEnabled: copilotChatPayload.agentsEnabled,
			showDecoupledPRModeBanner: copilotChatPayload.showDecoupledPRModeBanner
		};
		$[5] = agents;
		$[6] = chatIsOpen;
		$[7] = chatIsVisible;
		$[8] = chatVisibleSettingPath;
		$[9] = copilotChatPayload.agentsEnabled;
		$[10] = copilotChatPayload.agentsPath;
		$[11] = copilotChatPayload.apiURL;
		$[12] = copilotChatPayload.autoSubmit;
		$[13] = copilotChatPayload.currentUserLogin;
		$[14] = copilotChatPayload.customCopilotsEnabled;
		$[15] = copilotChatPayload.customCopilotsIndividualAccessEnabled;
		$[16] = copilotChatPayload.customInstructions;
		$[17] = copilotChatPayload.hasCEorCBAccess;
		$[18] = copilotChatPayload.optedInToPreviewFeatures;
		$[19] = copilotChatPayload.optedInToUserFeedback;
		$[20] = copilotChatPayload.personalInstructions;
		$[21] = copilotChatPayload.plan;
		$[22] = copilotChatPayload.renderBetaLabel;
		$[23] = copilotChatPayload.reviewLab;
		$[24] = copilotChatPayload.sharedThreadChannel;
		$[25] = copilotChatPayload.showCopilotSpacesMcpBanner;
		$[26] = copilotChatPayload.showDecoupledPRModeBanner;
		$[27] = currentView;
		$[28] = customCopilots;
		$[29] = messages;
		$[30] = mode;
		$[31] = refs;
		$[32] = restoredMessages;
		$[33] = restoredThreadTitle;
		$[34] = selectedReference;
		$[35] = ssoOrganizations;
		$[36] = testReducerState;
		$[37] = threadId;
		$[38] = topic;
		$[39] = topicAsReference;
		$[40] = workerPath;
		$[41] = t3;
	} else t3 = $[41];
	const [state, dispatch] = useReducer(copilotChatReducer, t3);
	useSaveChatState(state.messages, state.selectedThreadID, state.threads, state.mode);
	let t4;
	if ($[42] !== state.chatIsOpen || $[43] !== state.currentReferences || $[44] !== state.currentRepository?.id || $[45] !== state.selectedThreadID) {
		t4 = function saveCurrentReferences() {
			if (!state.chatIsOpen) return;
			const referencesWithoutCurrentRepo = state.currentReferences.filter((r) => r.type !== "repository" || r.id !== state.currentRepository?.id);
			copilotLocalStorage.setCurrentReferences(state.selectedThreadID, referencesWithoutCurrentRepo);
		};
		$[42] = state.chatIsOpen;
		$[43] = state.currentReferences;
		$[44] = state.currentRepository?.id;
		$[45] = state.selectedThreadID;
		$[46] = t4;
	} else t4 = $[46];
	let t5;
	if ($[47] !== state.chatIsOpen || $[48] !== state.currentReferences || $[49] !== state.currentRepository || $[50] !== state.selectedThreadID) {
		t5 = [
			state.selectedThreadID,
			state.currentReferences,
			state.currentRepository,
			state.chatIsOpen
		];
		$[47] = state.chatIsOpen;
		$[48] = state.currentReferences;
		$[49] = state.currentRepository;
		$[50] = state.selectedThreadID;
		$[51] = t5;
	} else t5 = $[51];
	useEffect(t4, t5);
	let t6;
	if ($[52] !== children || $[53] !== copilotChatPayload.apiURL || $[54] !== copilotChatPayload.apiVersion || $[55] !== copilotChatPayload.hasCEorCBAccess || $[56] !== copilotChatPayload.licenseType || $[57] !== copilotChatPayload.plan || $[58] !== copilotChatPayload.quotas || $[59] !== realIp || $[60] !== ssoOrganizations || $[61] !== state) {
		t6 = jsx(EntitlementProvider, {
			initialLicenseType: copilotChatPayload.licenseType,
			initialPlan: copilotChatPayload.plan,
			initialQuotas: copilotChatPayload.quotas,
			children: jsx(ChatStateProvider, {
				state,
				children: jsx(CopilotChatDispatchContext, {
					value: dispatch,
					children: jsx(CopilotChatManagerProvider, {
						apiURL: copilotChatPayload.apiURL,
						apiVersion: copilotChatPayload.apiVersion,
						state,
						dispatch,
						ssoOrganizations,
						realIp,
						hasCEorCBAccess: copilotChatPayload.hasCEorCBAccess,
						children: jsx(CopilotSpaceSelectionProvider, {
							selectedThreadId: state.selectedThreadID,
							children
						})
					})
				})
			})
		});
		$[52] = children;
		$[53] = copilotChatPayload.apiURL;
		$[54] = copilotChatPayload.apiVersion;
		$[55] = copilotChatPayload.hasCEorCBAccess;
		$[56] = copilotChatPayload.licenseType;
		$[57] = copilotChatPayload.plan;
		$[58] = copilotChatPayload.quotas;
		$[59] = realIp;
		$[60] = ssoOrganizations;
		$[61] = state;
		$[62] = t6;
	} else t6 = $[62];
	return t6;
}
CopilotChatProvider.displayName = "CopilotChatProvider";
var ChatStateContext = createContext(null);
ChatStateContext.displayName = "ChatStateContext";
function ChatStateProvider(t0) {
	const $ = c(12);
	const { state, children } = t0;
	const [stateObservable, setStateObservable] = useObservableValueRef(state);
	let t1;
	if ($[0] !== setStateObservable || $[1] !== state || $[2] !== stateObservable.current.value) {
		t1 = () => {
			if (state !== stateObservable.current.value) setStateObservable(state);
		};
		$[0] = setStateObservable;
		$[1] = state;
		$[2] = stateObservable.current.value;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== setStateObservable || $[5] !== state || $[6] !== stateObservable) {
		t2 = [
			state,
			stateObservable,
			setStateObservable
		];
		$[4] = setStateObservable;
		$[5] = state;
		$[6] = stateObservable;
		$[7] = t2;
	} else t2 = $[7];
	useLayoutEffect(t1, t2);
	let t3;
	if ($[8] !== children || $[9] !== state || $[10] !== stateObservable) {
		t3 = jsx(ObservableChatStateProvider, {
			value: stateObservable,
			children: jsx(ChatStateContext, {
				value: state,
				children
			})
		});
		$[8] = children;
		$[9] = state;
		$[10] = stateObservable;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
/**
* Returns the current version of the chat state.
* This causes the component to re-render any time there is an update to any part of the state.
* Our goal is to deprecate and remove this hook.
*
* @example
* ```ts
* const {messages, customInstructions} = useChatState()
* ```
*/
ChatStateProvider.displayName = "ChatStateProvider";
function useChatState() {
	const chatState = use(ChatStateContext);
	if (!chatState) throw new Error("useChatState can only be used inside a CopilotChatProvider");
	return chatState;
}
/**
* Returns the current version of the chat state or undefined if not within a CopilotChatProvider.
* This is a safe version of useChatState that won't throw an error when used outside
* of a chat context. Useful for components that may or may not be rendered within
* Copilot Chat.
*
* @example
* ```ts
* const chatState = useSafeChatState()
* const isImmersiveChat = chatState?.mode === 'immersive'
* ```
*/
function useSafeChatState() {
	return use(ChatStateContext) ?? void 0;
}
/**
* Returns the result of the lens function applied to the chat state.
* This causes the component to re-render whenever the given function results in a new value.
* The lens function must always be pure.
*
* @example
* ```ts
* const hasMessages = useChatStateLens(s => s.messages.length > 0)
* ```
*/
function useChatStateLens(lens) {
	const o = useObservableChatStateContext();
	if (!o || !o.current) throw new Error("useChatStateLens can only be used inside a CopilotChatProvider");
	return useObservedState(useDerivedObservable(o.current, lens));
}
/**
* Returns the current value of `state[key]` on the `CopilotChatState`.
* This causes the component to re-render whenever that property has a new value.
*
* @example
* ```ts
* const model = useChatStateValue('model')
* ```
*/
function useChatStateValue(key) {
	const $ = c(2);
	let t0;
	if ($[0] !== key) {
		t0 = (s) => s[key];
		$[0] = key;
		$[1] = t0;
	} else t0 = $[1];
	return useChatStateLens(t0);
}
/**
* Returns a subset of the `CopilotChatState` containing only the specified keys.
* This causes the component to re-render whenever a property corresponding to one of those keys has a new value.
*
* @example
* ```ts
* const {model, availableModels} = useChatStateValues('model', 'availableModels')
* ```
*/
function useChatStateValues(...t0) {
	const $ = c(2);
	const keys = t0;
	let t1;
	if ($[0] !== keys) {
		t1 = (s) => getSubsetFromState(s, keys);
		$[0] = keys;
		$[1] = t1;
	} else t1 = $[1];
	return useChatStateLens(t1);
}
function getSubsetFromState(state, keys) {
	const out = {};
	for (const key of keys) out[key] = state[key];
	return out;
}
export { useTraceManager as A, useChatStateValues as C, useGetChatState as D, useEntitlement as E, usePlugins as O, useChatStateValue as S, useDefaultModel as T, isCustomModel as _, TraceProvider as a, useChatState as b, copilotChatPanelID as c, copilotChatTextAreaId as d, copilotSpaceIdFromThread as f, getParentMessage as g, getDefaultModel as h, ImmersivePluginsProvider as i, useTraceState as j, useSafeChatState as k, copilotChatPanelInnerID as l, getActivePluginFromLocation as m, CopilotChatService as n, UploadableFileAttachment as o, getActiveMessages as p, EntitlementProvider as r, copilotChatHeaderButtonID as s, CopilotChatProvider as t, copilotChatSearchInputId as u, isPaidUser as v, useCopilotSpaceSelection as w, useChatStateLens as x, useChatManager as y };
