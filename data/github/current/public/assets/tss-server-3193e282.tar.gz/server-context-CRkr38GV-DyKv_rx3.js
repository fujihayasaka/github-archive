import { createContext } from "react";
var AnalyticsContext = createContext(null);
AnalyticsContext.displayName = "AnalyticsContext";
export { AnalyticsContext as t };
