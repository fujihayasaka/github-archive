performance.mark("js-parse-end:server-tree-BtNOExGF-Cdj2tTla.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:tree-BtNOExGF.js");
var codeViewTreeServerFn_createServerFn_handler = createServerRpc({
	id: "ad0a48c2e16c9d6dc580cf6e1f28842ad0acd3d852e622e196513c14d28b6462",
	name: "codeViewTreeServerFn",
	filename: "src/routes/code-view/tree.tsx"
}, (opts) => codeViewTreeServerFn.__executeServer(opts));
var codeViewTreeServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(codeViewTreeServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom",
		params: data.searchParams
	}, "codeViewTreeRoute");
});
export { codeViewTreeServerFn_createServerFn_handler };
