var forceServer = typeof FORCE_SERVER_ENV !== "undefined" ? FORCE_SERVER_ENV : false;
var ssrSafeDocument = typeof document === "undefined" || forceServer ? void 0 : document;
var ssrSafeWindow = typeof window === "undefined" || forceServer ? void 0 : window;
var ssrSafeHistory = typeof history === "undefined" || forceServer ? void 0 : history;
var fallbackLocation = {
	pathname: "",
	origin: "",
	search: "",
	hash: "",
	href: ""
};
var getServerLocation = null;
function createSSRSafeLocation() {
	return {
		get pathname() {
			return (getServerLocation ? getServerLocation() : void 0)?.pathname ?? fallbackLocation.pathname;
		},
		get origin() {
			return (getServerLocation ? getServerLocation() : void 0)?.origin ?? fallbackLocation.origin;
		},
		get search() {
			return (getServerLocation ? getServerLocation() : void 0)?.search ?? fallbackLocation.search;
		},
		get hash() {
			return (getServerLocation ? getServerLocation() : void 0)?.hash ?? fallbackLocation.hash;
		},
		get href() {
			return (getServerLocation ? getServerLocation() : void 0)?.href ?? fallbackLocation.href;
		}
	};
}
var ssrSafeLocation = typeof location === "undefined" || forceServer ? createSSRSafeLocation() : location;
function setServerLocationGetter(getter) {
	getServerLocation = getter;
}
export { ssrSafeWindow as a, ssrSafeLocation as i, ssrSafeDocument as n, ssrSafeHistory as r, setServerLocationGetter as t };
