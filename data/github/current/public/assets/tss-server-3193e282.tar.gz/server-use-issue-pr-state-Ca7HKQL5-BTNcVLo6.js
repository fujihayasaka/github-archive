import { t as __commonJSMin } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import { B as CircleSlashIcon, D as CheckCircleIcon, Ir as SkipIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { b as useTheme } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { k as useSafeChatState } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { _ as require_useSubscribeToInvalidationState, a as require_loadQuery, c as require_useEntryPointLoader, d as require_useMutation, f as require_usePaginationFragment, g as require_useRelayEnvironment, h as require_useRefetchableFragment, i as require_loadEntryPoint, l as require_useFragment, m as require_useQueryLoader, n as require_ProfilerContext, p as require_usePreloadedQuery, r as require_RelayEnvironmentProvider, s as require_relay_runtime, t as require_EntryPointContainer_react, u as require_useLazyLoadQuery, v as require_useSubscription } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { n as PullRequestStateIcons, t as IssueStateIcons } from "./server-Icons-BGcf3kco-Dw59hRar.js";
import { useCallback, useMemo } from "react";
import { c } from "react/compiler-runtime";
var require_hooks$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EntryPointContainer = require_EntryPointContainer_react();
	var loadEntryPoint = require_loadEntryPoint();
	var loadQuery = require_loadQuery().loadQuery;
	var ProfilerContext = require_ProfilerContext();
	var RelayEnvironmentProvider = require_RelayEnvironmentProvider();
	var useEntryPointLoader = require_useEntryPointLoader();
	var useFragment = require_useFragment();
	var useLazyLoadQuery = require_useLazyLoadQuery();
	var useMutation = require_useMutation();
	var usePaginationFragment = require_usePaginationFragment();
	var usePreloadedQuery = require_usePreloadedQuery();
	var useQueryLoader = require_useQueryLoader();
	var useRefetchableFragment = require_useRefetchableFragment();
	var useRelayEnvironment = require_useRelayEnvironment();
	var useSubscribeToInvalidationState = require_useSubscribeToInvalidationState();
	var useSubscription = require_useSubscription();
	var RelayRuntime = require_relay_runtime();
	module.exports = {
		ConnectionHandler: RelayRuntime.ConnectionHandler,
		applyOptimisticMutation: RelayRuntime.applyOptimisticMutation,
		commitLocalUpdate: RelayRuntime.commitLocalUpdate,
		commitMutation: RelayRuntime.commitMutation,
		graphql: RelayRuntime.graphql,
		readInlineData: RelayRuntime.readInlineData,
		requestSubscription: RelayRuntime.requestSubscription,
		EntryPointContainer,
		RelayEnvironmentProvider,
		ProfilerContext,
		fetchQuery: RelayRuntime.fetchQuery,
		loadQuery,
		loadEntryPoint,
		useFragment,
		useLazyLoadQuery,
		useEntryPointLoader,
		useQueryLoader,
		useMutation,
		usePaginationFragment,
		usePreloadedQuery,
		useRefetchableFragment,
		useRelayEnvironment,
		useSubscribeToInvalidationState,
		useSubscription
	};
}));
var require_hooks = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Relay v20.1.1
	*
	* Copyright (c) Meta Platforms, Inc. and affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	module.exports = require_hooks$1();
}));
var VALUES = {
	repositoriesPreloadCount: 5,
	localStorageMetadataKeys: {
		issueLabels: (prefix) => `${prefix}.create-issue-labels`,
		issueAssignees: (prefix) => `${prefix}.create-issue-assignees`,
		issueMilestone: (prefix) => `${prefix}.create-issue-milestone`,
		issueProjects: (prefix) => `${prefix}.create-issue-projects`,
		issueIssueType: (prefix) => `${prefix}.create-issue-type`,
		issueIssueFields: (prefix) => `${prefix}.create-issue-fields`
	},
	localStorageKeys: {
		issueCreateMore: (prefix) => `${prefix}.create-issue-create-more`,
		issueRepoId: (prefix) => `${prefix}.create-issue-repo-id`,
		issueTemplateId: (prefix) => `${prefix}.create-issue-template-id`
	},
	localTitleAndBodyStorageKeys: {
		issueTitle: (prefix) => `${prefix}.create-issue-title`,
		issueBody: (prefix) => `${prefix}.create-issue-body`
	},
	storageKeyPrefixes: {
		defaultFallback: "hyperlist",
		globalAdd: "issue-global-add"
	}
};
function storageKeys(prefix) {
	return Object.values({
		...VALUES.localStorageKeys,
		...VALUES.localStorageMetadataKeys,
		...VALUES.localTitleAndBodyStorageKeys
	}).map((s) => s(prefix));
}
function storageMetadataKeys(prefix) {
	return Object.values(VALUES.localStorageMetadataKeys).map((s) => s(prefix));
}
function storageTitleAndBodyKeys(prefix) {
	return Object.values(VALUES.localTitleAndBodyStorageKeys).map((s) => s(prefix));
}
var discardConfirmationStorageKeys = {
	title: VALUES.localTitleAndBodyStorageKeys.issueTitle,
	body: VALUES.localTitleAndBodyStorageKeys.issueBody
};
function discardStorageKeys(prefix) {
	return Object.values(discardConfirmationStorageKeys).map((s) => s(prefix));
}
var TEMP_SUB_ISSUE_ID_PREFIX = "temp-sub-issue-";
function useShouldShowCopilotFunctionalityInIssues(t0) {
	const $ = c(4);
	const { additionalConditions: t1, repositoryVisibility, userCanPushToRepo } = t0;
	let t2;
	if ($[0] !== t1) {
		t2 = t1 === void 0 ? [] : t1;
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const additionalConditions = t2;
	const chatState = useSafeChatState();
	const appPayload = useAppPayload();
	if (chatState?.mode === "immersive") return false;
	if (!appPayload?.current_user_settings?.copilot_show_functionality) return false;
	if (repositoryVisibility === "PUBLIC" && !userCanPushToRepo) return false;
	let t3;
	if ($[2] !== additionalConditions) {
		t3 = additionalConditions.every(_temp);
		$[2] = additionalConditions;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
}
function _temp(condition) {
	return condition;
}
var colorNames = [
	"GRAY",
	"BLUE",
	"GREEN",
	"YELLOW",
	"ORANGE",
	"RED",
	"PINK",
	"PURPLE"
];
var colorNamesToRoles = {
	BLUE: "accent",
	GREEN: "success",
	YELLOW: "attention",
	ORANGE: "severe",
	RED: "danger",
	PINK: "sponsors",
	PURPLE: "done"
};
/** Use theme colors by presentational (rather than semantic) names. */
var useNamedColor = (t0) => {
	const $ = c(3);
	const name = t0 === void 0 ? "GRAY" : t0;
	const { getPresentationalColor } = useGetPresentationalColor();
	let t1;
	if ($[0] !== getPresentationalColor || $[1] !== name) {
		t1 = getPresentationalColor(name);
		$[0] = getPresentationalColor;
		$[1] = name;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
var useGetPresentationalColor = () => {
	const $ = c(5);
	const { theme, resolvedColorScheme: t0 } = useTheme();
	const resolvedColorScheme = t0 === void 0 ? "light" : t0;
	let t1;
	if ($[0] !== resolvedColorScheme || $[1] !== theme?.colorSchemes) {
		t1 = (t2) => {
			const name = t2 === void 0 ? "GRAY" : t2;
			const scheme = ignoreColorblindSchemes(resolvedColorScheme);
			const colors = theme?.colorSchemes?.[scheme]?.colors;
			if (name === "GRAY") return {
				bg: colors?.canvas?.subtle,
				fg: colors?.fg?.muted,
				border: colors?.border?.default,
				accent: colors?.fg?.subtle
			};
			else {
				const base = colors?.[colorNamesToRoles[name]];
				return {
					bg: base?.subtle,
					fg: base?.fg,
					border: base?.muted,
					accent: base?.emphasis
				};
			}
		};
		$[0] = resolvedColorScheme;
		$[1] = theme?.colorSchemes;
		$[2] = t1;
	} else t1 = $[2];
	const getPresentationalColor = t1;
	let t2;
	if ($[3] !== getPresentationalColor) {
		t2 = { getPresentationalColor };
		$[3] = getPresentationalColor;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
/** Helper to validate if a string is an acceptable color name (case sensitive). */
var isColorName = (str) => colorNames.includes(str);
/**
* Colorblind schemes mutate the color scale, ie by making the success color blue instead
* of green. They even mutate the Primer 'scale' colors, so `green.5` becomes blue. So
* we have to just ignore them. See: https://github.com/github/primer/issues/1679
*/
var ignoreColorblindSchemes = (scheme) => scheme === "light_colorblind" || scheme === "light_tritanopia" ? "light" : scheme === "dark_colorblind" || scheme === "dark_tritanopia" ? "dark" : scheme;
var IssueStateReason = {
	COMPLETED: "COMPLETED",
	NOT_PLANNED: "NOT_PLANNED",
	DUPLICATE: "DUPLICATE",
	REOPENED: "REOPENED"
};
var IssueState = {
	OPEN: "OPEN",
	CLOSED: "CLOSED"
};
var IssueStateReasonStrings = {
	COMPLETED: "completed",
	NOT_PLANNED: "not planned",
	DUPLICATE: "duplicate",
	REOPENED: "reopened"
};
var IssueStateChangeQuery = {
	COMPLETED: "is:issue state:closed archived:false reason:completed",
	NOT_PLANNED: "is:issue state:closed archived:false reason:not-planned",
	DUPLICATE: "is:issue state:closed archived:false reason:duplicate",
	REOPENED: ""
};
function useIssueState(t0) {
	const $ = c(12);
	const { state, stateReason, options } = t0;
	options?.longText;
	let t1;
	bb0: switch (`${state}${options?.longText ? " long" : ""}`) {
		case "OPEN":
		case "OPEN long":
			t1 = "Open";
			break bb0;
		case "CLOSED long":
			t1 = stateReason === "NOT_PLANNED" ? "Closed as not planned" : stateReason === "DUPLICATE" ? "Closed as duplicate" : "Closed";
			break bb0;
		case "CLOSED":
			t1 = stateReason === "NOT_PLANNED" ? "Not planned" : stateReason === "DUPLICATE" ? "Duplicate" : "Closed";
			break bb0;
		default: t1 = "";
	}
	const stateString = t1;
	let t2;
	bb1: switch (state) {
		case "OPEN":
			t2 = "issueOpened";
			break bb1;
		case "CLOSED":
			t2 = stateReason === "NOT_PLANNED" || stateReason === "DUPLICATE" ? "issueClosedNotPlanned" : "issueClosed";
			break bb1;
		default: t2 = "issueClosed";
	}
	const stateStatus = t2;
	let t3;
	if ($[0] !== stateReason) {
		t3 = () => {
			const result = {
				stateChangeQuery: "",
				stateReasonString: ""
			};
			if (stateReason) {
				if (stateReason in IssueStateChangeQuery) result.stateChangeQuery = IssueStateChangeQuery[stateReason];
				else throw new Error(`Invalid state change: ${stateReason}`);
				if (stateReason in IssueStateReasonStrings) result.stateReasonString = IssueStateReasonStrings[stateReason];
				else throw new Error(`Invalid state change: ${stateReason}`);
			}
			return result;
		};
		$[0] = stateReason;
		$[1] = t3;
	} else t3 = $[1];
	const getStateQuery = t3;
	const issueStateColor = stateReason === IssueStateReason.NOT_PLANNED || stateReason === IssueStateReason.DUPLICATE ? "var(--fgColor-muted)" : "var(--fgColor-done)";
	const issueStateTimelineIcon = stateReason === IssueStateReason.NOT_PLANNED || stateReason === IssueStateReason.DUPLICATE ? CircleSlashIcon : CheckCircleIcon;
	let t4;
	if ($[2] !== state || $[3] !== stateReason) {
		t4 = (subjectType, isDraft, isInMergeQueue) => {
			if (subjectType === "Issue") {
				if (state === "CLOSED" && (stateReason === null || stateReason === void 0)) return IssueStateIcons.COMPLETED;
				if (stateReason === null || stateReason === void 0 || stateReason === "REOPENED") return IssueStateIcons.OPEN;
				if (stateReason in IssueStateIcons) return IssueStateIcons[stateReason];
				return SkipIcon;
			} else {
				if (isDraft && state === "OPEN") return PullRequestStateIcons.DRAFT;
				if (isInMergeQueue) return PullRequestStateIcons.IN_MERGE_QUEUE;
				if (state === void 0 || state === null) return PullRequestStateIcons.OPEN;
				if (state in PullRequestStateIcons) return PullRequestStateIcons[state];
				return SkipIcon;
			}
		};
		$[2] = state;
		$[3] = stateReason;
		$[4] = t4;
	} else t4 = $[4];
	const sourceIcon = t4;
	let t5;
	if ($[5] !== getStateQuery || $[6] !== issueStateColor || $[7] !== issueStateTimelineIcon || $[8] !== sourceIcon || $[9] !== stateStatus || $[10] !== stateString) {
		t5 = {
			stateString,
			stateStatus,
			getStateQuery,
			issueStateColor,
			issueStateTimelineIcon,
			sourceIcon
		};
		$[5] = getStateQuery;
		$[6] = issueStateColor;
		$[7] = issueStateTimelineIcon;
		$[8] = sourceIcon;
		$[9] = stateStatus;
		$[10] = stateString;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
}
export { colorNames as a, require_hooks as c, storageTitleAndBodyKeys as d, useIssueState as f, VALUES as i, storageKeys as l, useShouldShowCopilotFunctionalityInIssues as m, IssueStateReason as n, discardStorageKeys as o, useNamedColor as p, TEMP_SUB_ISSUE_ID_PREFIX as r, isColorName as s, IssueState as t, storageMetadataKeys as u };
