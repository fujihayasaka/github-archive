performance.mark("js-parse-end:server-blob-CZnmQb8j-Dzz3HFWO.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { Z as useCurrentBlob } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { r as useCodeNav } from "./server-CodeNavContext-B-HlTATD-BC-PDvfx.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { t as codeViewBlobLayoutRoute } from "./server-code-view-blob-layout-route-dhoYwhPV-CcMKI0YH.js";
import { n as BlobBanners } from "./server-CodeViewBanners-D01K_nCP-X3Rsq57I.js";
import { t as BlobViewContent } from "./server-BlobViewContent-DYReMUfE-DA6d3Mwh.js";
import { t as CodeView } from "./server-CodeView-CCvwX-NJ-CNmyXFpi.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:blob-CZnmQb8j.js");
function CodeViewBlobEntrypoint() {
	const $ = c(11);
	const { data: blobLayoutPayload } = useRouteQuery(codeViewBlobLayoutRoute, "mainQuery");
	const { data: layoutPayload } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { isTreeExpanded, treeToggleElement } = useTreePaneContext();
	const { validCodeNav, setValidCodeNav } = useCodeNav();
	const blob = useCurrentBlob();
	let t0;
	if ($[0] !== blob || $[1] !== blobLayoutPayload || $[2] !== isTreeExpanded || $[3] !== layoutPayload || $[4] !== setValidCodeNav || $[5] !== treeToggleElement || $[6] !== validCodeNav) {
		t0 = () => jsxs(Fragment, { children: [jsx("div", {
			className: "react-code-view-bottom-padding",
			children: jsx(BlobBanners, {})
		}), jsx(BlobViewContent, {
			blob,
			symbolsExpanded: layoutPayload.symbolsExpanded,
			setValidCodeNav,
			showTree: isTreeExpanded,
			treeToggleElement,
			validCodeNav,
			copilotInfo: blobLayoutPayload.copilotInfo
		})] });
		$[0] = blob;
		$[1] = blobLayoutPayload;
		$[2] = isTreeExpanded;
		$[3] = layoutPayload;
		$[4] = setValidCodeNav;
		$[5] = treeToggleElement;
		$[6] = validCodeNav;
		$[7] = t0;
	} else t0 = $[7];
	let t1;
	if ($[8] !== blobLayoutPayload || $[9] !== t0) {
		t1 = jsx(CodeView, {
			payload: blobLayoutPayload,
			action: "blob",
			children: t0
		});
		$[8] = blobLayoutPayload;
		$[9] = t0;
		$[10] = t1;
	} else t1 = $[10];
	return t1;
}
CodeViewBlobEntrypoint.displayName = "CodeViewBlobEntrypoint";
var SplitComponent = CodeViewBlobEntrypoint;
export { SplitComponent as component };
