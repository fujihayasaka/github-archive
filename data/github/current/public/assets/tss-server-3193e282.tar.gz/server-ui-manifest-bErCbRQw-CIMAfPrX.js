import { n as isDev } from "./server-env-CmF5Q86i-CMsKyIar.js";
function getUIVersion() {
	if (isDev()) return "development";
	if (!process.env.UI_VERSION) throw new Error("UI_VERSION environment variable must be set in production");
	return process.env.UI_VERSION;
}
async function getUIManifestFromDevServer() {
	try {
		const response = await fetch("http://localhost:3014/ui-manifest.json");
		if (response.ok) return await response.json();
		throw new Error(`Failed to fetch UI manifest: ${response.status} ${response.statusText}`);
	} catch (error) {
		console.error("Failed to fetch UI manifest from dev server:", error);
		throw error;
	}
}
var productionUIManifest = null;
async function getUIManifest() {
	if (productionUIManifest) return productionUIManifest;
	if (isDev()) return getUIManifestFromDevServer();
	const uiManifestPath = process.env.UI_MANIFEST_PATH;
	if (!uiManifestPath) throw new Error("UI_MANIFEST_PATH environment variable must be set in production");
	const imported = await import(
		/* @vite-ignore */
		uiManifestPath,
		{ with: { type: "json" } }
);
	productionUIManifest = imported.default ?? imported;
	return productionUIManifest;
}
/**
* Return the `src` for a given entry name, using the manifest's defaultBundler
* preference with fallbacks: defaultBundler → rspack → vite.
*/
async function getEntrySrc(entryName) {
	const manifest = await getUIManifest();
	const bundler = manifest.defaultBundler ?? "rspack";
	const bundlerSrc = manifest[bundler]?.[entryName]?.src;
	if (bundlerSrc) return bundlerSrc;
	if (bundler !== "rspack") {
		const rspackSrc = manifest.rspack?.[entryName]?.src;
		if (rspackSrc) return rspackSrc;
	}
	return manifest.vite?.[entryName]?.src ?? null;
}
export { getUIVersion as n, getEntrySrc as t };
