import { jsx } from "react/jsx-runtime";
var ScrollMarksContainer_module_default = { scrollMarksContainer: "ScrollMarksContainer-module_6RuZuG_scrollMarksContainer" };
var scrollMarksContainerID = "find-result-marks-container";
function ScrollMarksContainer() {
	return /* @__PURE__ */ jsx("div", {
		className: ScrollMarksContainer_module_default.scrollMarksContainer,
		id: scrollMarksContainerID
	});
}
ScrollMarksContainer.displayName = "ScrollMarksContainer";
export { scrollMarksContainerID as n, ScrollMarksContainer as t };
