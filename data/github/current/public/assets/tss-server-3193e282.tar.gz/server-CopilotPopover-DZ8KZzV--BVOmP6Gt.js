import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { bn as Link, et as CopilotIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { o as useCurrentUser } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { i as useFeatureRequest, r as RequestFeature, t as CancelFeatureRequest } from "./server-FeatureRequest-BkET-vSV-lmJnXnOw.js";
import { useCallback, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
var CopilotPopover_module_default = {
	copilotButton: "CopilotPopover-module_KFihzq_copilotButton",
	dismissLink: "CopilotPopover-module_KFihzq_dismissLink",
	dismissLinkNoMargin: "CopilotPopover-module_KFihzq_dismissLinkNoMargin",
	learnMoreLink: "CopilotPopover-module_KFihzq_learnMoreLink",
	popoverActionsContainer: "CopilotPopover-module_KFihzq_popoverActionsContainer",
	popoverBodyText: "CopilotPopover-module_KFihzq_popoverBodyText",
	PopoverContent: "CopilotPopover-module_KFihzq_PopoverContent",
	popoverHeading: "CopilotPopover-module_KFihzq_popoverHeading"
};
var PopoverMessage = {
	ORG_ADMIN: `For an organization, developers writing less boilerplate code means more productivity, while learning
  new technologies means delivering better customers solutions. Try it in Codespaces or your file editor.`,
	ORG_MEMBER: `We noticed that you're personally paying for GitHub Copilot. Instead, ask your organization admin
  to purchase the business version of GitHub Copilot.`,
	STANDARD: `Spend less time creating boilerplate and repetitive code patterns, and more time building great software.
  Try it in Codespaces or your favorite file editor.`
};
var FeatureRequest = ({ featureRequestInfo, inProgress, toggleFeatureRequest, requested }) => {
	if (!featureRequestInfo?.showFeatureRequest) return null;
	return requested ? /* @__PURE__ */ jsx(CancelFeatureRequest, {
		inProgress,
		toggleFeatureRequest
	}) : /* @__PURE__ */ jsx(RequestFeature, {
		inProgress,
		toggleFeatureRequest,
		featureName: featureRequestInfo?.featureName
	});
};
FeatureRequest.displayName = "FeatureRequest";
var CopilotPopover = ({ view, copilotInfo, className }) => {
	const { documentationUrl, notices, userAccess } = copilotInfo ?? {};
	const { business, orgHasCFBAccess, userHasCFIAccess, userHasOrgs, userIsOrgAdmin, userIsOrgMember, featureRequestInfo } = userAccess ?? {};
	const { codeViewPopover: codeViewPopoverNotice } = notices ?? {};
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const currentUser = useCurrentUser();
	const { isOrgOwned: repoIsOrgOwned, ownerLogin } = useCurrentRepository();
	const { inProgress, requested, dismissed, dismissedAt, toggleFeatureRequest } = useFeatureRequest(featureRequestInfo);
	const [isOpen, setIsOpen] = useState(false);
	const [popoverHidden, setPopoverHidden] = useState(false);
	const openPopover = useCallback(() => setIsOpen(true), [setIsOpen]);
	const closePopover = useCallback(() => setIsOpen(false), [setIsOpen]);
	const buttonText = useCallback(() => {
		if (userAccess && repoIsOrgOwned) {
			if (userIsOrgMember && !userIsOrgAdmin && (!orgHasCFBAccess || userHasCFIAccess)) return "Your organization can pay for GitHub Copilot";
		}
		return "Code 55% faster with GitHub Copilot";
	}, [
		orgHasCFBAccess,
		repoIsOrgOwned,
		userAccess,
		userHasCFIAccess,
		userIsOrgAdmin,
		userIsOrgMember
	]);
	const bodyText = () => {
		if (dismissed) return "";
		if (userAccess && repoIsOrgOwned) {
			if (userIsOrgAdmin) return PopoverMessage.ORG_ADMIN;
			else if (userIsOrgMember && userHasCFIAccess) return PopoverMessage.ORG_MEMBER;
		}
		return PopoverMessage.STANDARD;
	};
	const dismissedMessage = () => {
		return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("p", { children: [
			"Your request for Copilot Business was declined by an admin on ",
			dismissedAt,
			"."
		] }), /* @__PURE__ */ jsxs("p", {
			className: "mb-0",
			children: [
				/* @__PURE__ */ jsx(Link, {
					...testIdProps("contact-admin-link"),
					"aria-label": `Click this link to contact your admin.`,
					target: "_blank",
					href: `/orgs/${ownerLogin}/people?query=role:owner`,
					onClick: () => sendAnalyticsClickLearnMore(),
					children: "Contact your admin"
				}),
				"",
				" for more details around their decision."
			]
		})] });
	};
	const getUserRepoRelationship = () => {
		if (currentUser && ownerLogin === currentUser.login) return "owner";
		else if (userIsOrgAdmin) return "admin";
		else if (userIsOrgMember) return "member";
		else return "personal";
	};
	const sendAnalyticsClickOpenPopover = () => {
		if (currentUser) sendClickAnalyticsEvent({
			category: "copilot_popover_code_view",
			action: `click_to_open_popover_${view}`,
			label: `ref_cta:open_copilot_popover;owner:${ownerLogin};relationship:${getUserRepoRelationship()}`
		});
	};
	const sendAnalyticsClickPopoverCTA = (action, ctaText) => {
		sendClickAnalyticsEvent({
			category: "copilot_popover_code_view",
			action,
			label: `ref_cta:${ctaText};ref_loc:code_view_${view}`
		});
	};
	const sendAnalyticsDismissPopover = () => {
		sendClickAnalyticsEvent({
			category: "copilot_popover_code_view",
			action: `click_to_dismiss_copilot_popover_forever`,
			label: `ref_cta:dont_show_again;ref_loc:${`${repoIsOrgOwned ? "org_" : ""}code_view_${view}${userIsOrgAdmin ? "_org_admin" : ""}`}`
		});
	};
	const sendAnalyticsClickLearnMore = () => {
		sendClickAnalyticsEvent({
			category: "copilot_popover_code_view",
			action: `click_to_go_to_copilot_for_${userAccess?.userHasOrgs ?? false ? "business" : "individuals"}_info`,
			label: "ref_cta:learn_more;ref_loc:code_view"
		});
	};
	const bodyCTA = () => {
		if (!(!!business || userHasCFIAccess) && (!repoIsOrgOwned || repoIsOrgOwned && !userIsOrgMember)) return userHasOrgs ? /* @__PURE__ */ jsx(LinkButton, {
			type: "button",
			href: "/settings/copilot",
			onClick: () => sendAnalyticsClickPopoverCTA("click_to_go_to_copilot_settings", "get_github_copilot"),
			children: "Get GitHub Copilot"
		}) : /* @__PURE__ */ jsx(LinkButton, {
			type: "button",
			href: "/github-copilot/signup",
			onClick: () => sendAnalyticsClickPopoverCTA("click_to_go_to_copilot_trial_signup", "start_a_free_trial"),
			children: "Start a free trial"
		});
		if (userIsOrgMember && !orgHasCFBAccess) {
			if (userIsOrgAdmin) return /* @__PURE__ */ jsx(LinkButton, {
				type: "button",
				href: `/github-copilot/business_signup/organization/payment?org=${ownerLogin}`,
				onClick: () => sendAnalyticsClickPopoverCTA("click_to_buy_copilot_for_business", "get_github_copilot"),
				children: "Get GitHub Copilot"
			});
		}
		if (featureRequestInfo && !dismissed) return /* @__PURE__ */ jsx(FeatureRequest, {
			requested,
			featureRequestInfo,
			inProgress,
			toggleFeatureRequest
		});
		return null;
	};
	const onDismissPopover = () => {
		if (codeViewPopoverNotice) {
			verifiedFetch(codeViewPopoverNotice.dismissPath, { method: userIsOrgMember ? "DELETE" : "POST" });
			sendAnalyticsDismissPopover();
			setPopoverHidden(true);
		}
	};
	const learnMoreLink = () => {
		return /* @__PURE__ */ jsx(Link, {
			...testIdProps("copilot-popover-content-learn-more"),
			"aria-label": `Click this link to learn more about copilot. This action opens in a new tab.`,
			target: "_blank",
			href: documentationUrl,
			onClick: () => sendAnalyticsClickLearnMore(),
			className: CopilotPopover_module_default.learnMoreLink,
			children: "Learn more"
		});
	};
	const hideCopilotPopover = () => popoverHidden || !copilotInfo;
	if (hideCopilotPopover()) return null;
	return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsx(AnchoredOverlay, {
			onOpen: openPopover,
			onClose: closePopover,
			open: isOpen,
			overlayProps: {
				role: "dialog",
				style: { overflow: "inherit" }
			},
			focusZoneSettings: { disabled: true },
			renderAnchor: (anchorProps) => /* @__PURE__ */ jsx(ButtonComponent, {
				...anchorProps,
				...testIdProps("copilot-popover-button"),
				leadingVisual: CopilotIcon,
				"aria-label": buttonText(),
				onClick: () => {
					setIsOpen(!isOpen);
					sendAnalyticsClickOpenPopover();
				},
				size: "small",
				className: CopilotPopover_module_default.copilotButton,
				variant: "invisible"
			}),
			children: /* @__PURE__ */ jsx(Popover_default, {
				"aria-label": "GitHub Copilot",
				open: isOpen,
				...testIdProps("copilot-popover-content"),
				caret: "top",
				children: /* @__PURE__ */ jsxs(Popover_default.Content, {
					className: CopilotPopover_module_default.PopoverContent,
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: CopilotPopover_module_default.popoverHeading,
							children: "Code 55% faster with GitHub Copilot"
						}),
						/* @__PURE__ */ jsxs("div", {
							className: CopilotPopover_module_default.popoverBodyText,
							children: [/* @__PURE__ */ jsx("span", {
								...testIdProps("copilot-popover-body-text"),
								children: bodyText()
							}), dismissed ? dismissedMessage() : learnMoreLink()]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: CopilotPopover_module_default.popoverActionsContainer,
							children: [bodyCTA(), /* @__PURE__ */ jsx(Link, {
								...testIdProps("copilot-popover-dismiss-button"),
								onClick: onDismissPopover,
								className: clsx(dismissed ? CopilotPopover_module_default.dismissLinkNoMargin : CopilotPopover_module_default.dismissLink),
								children: "Don't show again"
							})]
						})
					]
				})
			})
		})
	});
};
CopilotPopover.displayName = "CopilotPopover";
export { CopilotPopover as t };
