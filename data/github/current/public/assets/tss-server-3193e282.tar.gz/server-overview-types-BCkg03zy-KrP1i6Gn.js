function isFileOverviewPayload(payload) {
	return "overview" in payload;
}
var PreferredFileTypes = {
	README: "readme",
	CODE_OF_CONDUCT: "code_of_conduct",
	CONTRIBUTING: "contributing",
	LICENSE: "license",
	SECURITY: "security"
};
export { isFileOverviewPayload as n, PreferredFileTypes as t };
