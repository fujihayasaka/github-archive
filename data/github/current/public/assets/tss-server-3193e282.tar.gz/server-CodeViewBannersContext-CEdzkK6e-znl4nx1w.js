import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { createContext, use, useCallback, useEffect, useEffectEvent, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CodeViewBannersContext = createContext({
	banners: [],
	addBanner: () => void 0,
	addQueuedBanner: () => void 0
});
CodeViewBannersContext.displayName = "CodeViewBannersContext";
function useCodeViewBanners() {
	return use(CodeViewBannersContext).banners;
}
/**
* Gets a function to add a banner. This function never changes and is thus useful for code in useEffect().
*/
function useCodeViewAddBanner() {
	return use(CodeViewBannersContext).addBanner;
}
/**
* Gets a function to add a banner to the banner queue to make it appear on the next navigate
* This function never changes and is thus useful for code in useEffect().
*/
function useCodeViewAddQueuedBanner() {
	return use(CodeViewBannersContext).addQueuedBanner;
}
function CodeViewBannersProvider(t0) {
	const $ = c(15);
	const { children } = t0;
	const location = useLocation$1();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [banners, setBanners] = useState(t1);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[1] = t2;
	} else t2 = $[1];
	const [queuedBanners, setQueuedBanners] = useState(t2);
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (b) => setBanners((current) => [...current, b]);
		$[2] = t3;
	} else t3 = $[2];
	const addBanner = t3;
	let t4;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (b_0) => setQueuedBanners((current_0) => [...current_0, b_0]);
		$[3] = t4;
	} else t4 = $[3];
	const addQueuedBanner = t4;
	let t5;
	if ($[4] !== banners) {
		t5 = {
			banners,
			addBanner,
			addQueuedBanner
		};
		$[4] = banners;
		$[5] = t5;
	} else t5 = $[5];
	const value = t5;
	let t6;
	if ($[6] !== queuedBanners) {
		t6 = () => {
			setBanners(queuedBanners);
			setQueuedBanners([]);
		};
		$[6] = queuedBanners;
		$[7] = t6;
	} else t6 = $[7];
	const clearBanners = useEffectEvent(t6);
	let t7;
	if ($[8] !== clearBanners) {
		t7 = () => {
			clearBanners();
		};
		$[8] = clearBanners;
		$[9] = t7;
	} else t7 = $[9];
	let t8;
	if ($[10] !== location.key) {
		t8 = [location.key];
		$[10] = location.key;
		$[11] = t8;
	} else t8 = $[11];
	useEffect(t7, t8);
	let t9;
	if ($[12] !== children || $[13] !== value) {
		t9 = jsx(CodeViewBannersContext, {
			value,
			children
		});
		$[12] = children;
		$[13] = value;
		$[14] = t9;
	} else t9 = $[14];
	return t9;
}
CodeViewBannersProvider.displayName = "CodeViewBannersProvider";
export { useCodeViewBanners as i, useCodeViewAddBanner as n, useCodeViewAddQueuedBanner as r, CodeViewBannersProvider as t };
