import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { n as queryFnFetch, r as queryFnFetchWithSafeHTMLNonce } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as QueryRouteQueryType, r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { n as treeCommitInfoQuery, t as latestCommitQuery } from "./server-tree-commit-info-query-Bp7ncbtC-DjEhc-v4.js";
function railsPartialQuery({ partialName, queryDeps, type, navigationBehavior, ...opts }) {
	return (routeId) => {
		const queryName = `${routeId}.${partialName || "RailsPartial"}`;
		return {
			queryName,
			queryDeps: queryDeps ? queryDeps : ({ pathname }) => {
				return { pathname: `${pathname}/partial` };
			},
			queryFn: async (queryKey) => {
				const html = (await queryFnFetchWithSafeHTMLNonce(queryKey)).payload?.[queryName];
				if (html === void 0 || html === null) throw new Error(`Unable to find payload for query: ${queryName}`);
				return html;
			},
			type: type || QueryRouteQueryType.Blocking,
			navigationBehavior: navigationBehavior || "network-first",
			...opts
		};
	};
}
var codeViewRepoRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewRepoRoute", {
	path: "/:owner/:repo",
	index: true,
	queries: [
		mainQuery(),
		railsPartialQuery({
			partialName: "Header",
			queryDeps: ({ pathname }) => {
				return { pathname: `${pathname}/partials/header` };
			}
		}),
		railsPartialQuery({
			partialName: "Sidebar",
			queryDeps: ({ pathname }) => {
				return { pathname: `${pathname}/partials/sidebar` };
			},
			enabled: () => !isFeatureEnabled("react_data_router_code_view_sidebar")
		}),
		latestCommitQuery,
		treeCommitInfoQuery,
		{
			queryName: "recentlyTouchedBranches",
			queryDeps: ({ params }) => ({ pathname: `/${params.owner}/${params.repo}/recently-touched-branches` }),
			queryFn: async (queryKey) => queryFnFetch(queryKey),
			type: QueryRouteQueryType.Deferred
		},
		{
			queryName: "branchAndTagCount",
			queryDeps: ({ params }) => ({ pathname: `/${params.owner}/${params.repo}/branch-and-tag-count` }),
			queryFn: async (queryKey) => queryFnFetch(queryKey),
			type: QueryRouteQueryType.Deferred
		},
		{
			queryName: "sidebarAbout",
			enabled: () => isFeatureEnabled("react_data_router_code_view_sidebar"),
			queryDeps: ({ pathname }) => ({ pathname: `${pathname}/_sidebar/about` }),
			queryFn: async (queryKey) => queryFnFetch(queryKey),
			type: QueryRouteQueryType.Blocking
		}
	]
});
export { codeViewRepoRoute as t };
