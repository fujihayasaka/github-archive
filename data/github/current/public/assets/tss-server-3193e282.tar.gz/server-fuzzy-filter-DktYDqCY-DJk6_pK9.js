function fuzzyScore(string, query, prefixBonusWeight = .1) {
	let score = stringScore(string, query, prefixBonusWeight);
	if (score && query.indexOf("/") === -1) {
		const basename = string.substring(string.lastIndexOf("/") + 1);
		score += stringScore(basename, query, prefixBonusWeight);
	}
	return score;
}
var wordSeparators = new Set([
	" ",
	"-",
	"_"
]);
function stringScore(originalString, abbreviation, prefixBonusWeight = .1) {
	let string = originalString;
	if (string === abbreviation) return 1;
	const stringLength = string.length;
	let totalCharacterScore = 0;
	let shouldAwardCommonPrefixBonus = 0;
	let firstChar = true;
	for (const char of abbreviation) {
		const indexCLowercase = string.indexOf(char.toLowerCase());
		const indexCUppercase = string.indexOf(char.toUpperCase());
		const minIndex = Math.min(indexCLowercase, indexCUppercase);
		const indexInString = minIndex > -1 ? minIndex : Math.max(indexCLowercase, indexCUppercase);
		if (indexInString === -1) return 0;
		totalCharacterScore += .1;
		if (string[indexInString] === char) totalCharacterScore += .1;
		if (indexInString === 0) {
			totalCharacterScore += .9 - prefixBonusWeight;
			if (firstChar) shouldAwardCommonPrefixBonus = 1;
		}
		if (wordSeparators.has(string.charAt(indexInString - 1))) totalCharacterScore += .9 - prefixBonusWeight;
		string = string.substring(indexInString + 1, stringLength);
		firstChar = false;
	}
	const abbreviationLength = abbreviation.length;
	const abbreviationScore = totalCharacterScore / abbreviationLength;
	let finalScore = (abbreviationScore * (abbreviationLength / stringLength) + abbreviationScore) / 2;
	if (shouldAwardCommonPrefixBonus && finalScore + prefixBonusWeight < 1) finalScore += prefixBonusWeight;
	return finalScore;
}
function compare(a, b) {
	if (a.score > b.score) return -1;
	else if (a.score < b.score) return 1;
	else if (a.text < b.text) return -1;
	else if (a.text > b.text) return 1;
	else return 0;
}
export { fuzzyScore as n, compare as t };
