import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
function truncateLines(text, maxCharsPerLine = 50, lines = 2) {
	const maxChars = maxCharsPerLine * lines;
	if (text.length <= maxChars) return text;
	return `${text.substring(0, maxChars).trim()}...`;
}
var TaskCreationFailedBanner_module_default = { bannerList: "TaskCreationFailedBanner-module_hHfY4a_bannerList" };
var COPILOT_SETTINGS_PATH = "/settings/copilot/features";
var CUSTOMER_SELECTION_REQUIRED_DESCRIPTION = "Before you can use Copilot coding agent, you need to pick a \"Usage billed to\" option in your Copilot settings.";
function isCustomerSelectionRequiredError(errorMessage) {
	return errorMessage?.toLowerCase().includes("customer selection required") ?? false;
}
/**
* Extracts task creation parameters from a failed API task attempt,
* removing the error-specific fields (errorMessage, timestamp) and clientGeneratedId
* so that a new ID will be generated for the retry.
*/
function getAPITaskParamsFromAttempt(attempt) {
	const { errorMessage, timestamp, clientGeneratedId, ...taskParams } = attempt;
	return taskParams;
}
function TaskCreationFailedBanner({ problemStatement, errorMessage, handleRetry, handleDismiss }) {
	if (isCustomerSelectionRequiredError(errorMessage)) return /* @__PURE__ */ jsx(Banner, {
		variant: "critical",
		title: "Task Creation Failed",
		hideTitle: true,
		description: CUSTOMER_SELECTION_REQUIRED_DESCRIPTION,
		primaryAction: /* @__PURE__ */ jsx(Banner.PrimaryAction, {
			as: "a",
			href: COPILOT_SETTINGS_PATH,
			children: "Settings"
		}),
		secondaryAction: /* @__PURE__ */ jsx(Banner.SecondaryAction, {
			onClick: handleDismiss,
			children: "Dismiss"
		})
	});
	const baseMessage = `Unable to start task for '${truncateLines(problemStatement ?? "", 20, 1)}'`;
	return /* @__PURE__ */ jsx(Banner, {
		variant: "critical",
		title: "Task Creation Failed",
		hideTitle: true,
		description: errorMessage ? `${baseMessage}: ${errorMessage}` : `${baseMessage}. Please try again.`,
		secondaryAction: /* @__PURE__ */ jsx(Banner.SecondaryAction, {
			onClick: handleDismiss,
			children: "Dismiss"
		}),
		primaryAction: /* @__PURE__ */ jsx(Banner.PrimaryAction, {
			onClick: handleRetry,
			children: "Retry"
		})
	});
}
TaskCreationFailedBanner.displayName = "TaskCreationFailedBanner";
function TaskCreationFailedBannerList({ attempts, onRetry, onDismiss, className }) {
	if (attempts.length === 0) return null;
	return /* @__PURE__ */ jsx("div", {
		className: clsx(TaskCreationFailedBanner_module_default.bannerList, className),
		children: attempts.map((attempt, index) => /* @__PURE__ */ jsx(TaskCreationFailedBanner, {
			problemStatement: attempt.problemStatement,
			errorMessage: attempt.errorMessage,
			handleRetry: () => onRetry(index),
			handleDismiss: () => onDismiss(index)
		}, `${attempt.problemStatement}-${attempt.timestamp}`))
	});
}
TaskCreationFailedBannerList.displayName = "TaskCreationFailedBannerList";
export { getAPITaskParamsFromAttempt as n, TaskCreationFailedBannerList as t };
