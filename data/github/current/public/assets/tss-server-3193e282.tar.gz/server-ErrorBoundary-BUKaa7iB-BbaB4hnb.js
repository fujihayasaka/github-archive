import { Qt as Heading$2 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnalyticsContext } from "./server-context-CRkr38GV-DyKv_rx3.js";
import React from "react";
import { jsx, jsxs } from "react/jsx-runtime";
var ErrorPage_module_default = {
	Heading: "ErrorPage-module_nBc0FG_Heading",
	Message: "ErrorPage-module_nBc0FG_Message",
	Status: "ErrorPage-module_nBc0FG_Status"
};
var errorMessages = {
	404: "Didn’t find anything here!",
	500: "Looks like something went wrong!"
};
function ErrorPage({ httpStatus, type }) {
	const message = type === "fetchError" ? "Looks like network is down!" : errorMessages[httpStatus || 500];
	return /* @__PURE__ */ jsxs(Heading$2, {
		as: "h1",
		tabIndex: -1,
		className: ErrorPage_module_default.Heading,
		children: [
			"Error",
			httpStatus ? /* @__PURE__ */ jsx("div", {
				className: ErrorPage_module_default.Status,
				children: httpStatus
			}) : null,
			/* @__PURE__ */ jsx("div", {
				className: ErrorPage_module_default.Message,
				children: message
			})
		]
	});
}
ErrorPage.displayName = "ErrorPage";
/**
* Symbol used to attach error boundary metadata to errors.
* This metadata is read by React 19's onCaughtError callback in ReactBaseElement.
*/
var ERROR_BOUNDARY_METADATA = Symbol.for("errorBoundaryMetadata");
var BasicErrorBoundary = class extends React.Component {
	constructor(props) {
		super(props);
		this.state = { error: null };
	}
	/**
	* Invoked when an error is thrown in the child component,
	* and used to update state in a concurrent friendly manner
	*/
	static getDerivedStateFromError(error) {
		return { error };
	}
	/**
	* Called _after_ the re-render, used for performing side-effects such as logging.
	*
	* Error reporting is handled centrally via React 19's `onCaughtError` callback
	* on `hydrateRoot`/`createRoot` in ReactBaseElement.
	* This method attaches metadata to the error so the root can read critical/boundaryName info.
	*/
	componentDidCatch(error) {
		const context = {
			critical: this.props.critical || false,
			reactAppName: this.props.appName,
			reactErrorBoundaryName: this.props.boundaryName
		};
		error[ERROR_BOUNDARY_METADATA] = {
			critical: this.props.critical,
			boundaryName: this.props.boundaryName,
			hasCustomHandler: typeof this.props.onError === "function"
		};
		if (typeof this.props.onError === "function") this.props.onError(error, context);
	}
	render() {
		if (!this.state.error) return this.props.children;
		return this.props.fallback === void 0 ? /* @__PURE__ */ jsx(ErrorPage, { type: "httpError" }) : this.props.fallback;
	}
};
function ErrorBoundary(props) {
	const context = React.use(AnalyticsContext);
	const appName = props.appName || context?.appName;
	return /* @__PURE__ */ jsx(BasicErrorBoundary, {
		...props,
		appName
	});
}
ErrorBoundary.displayName = "ErrorBoundary";
export { ErrorBoundary as n, ERROR_BOUNDARY_METADATA as t };
