import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { n as LabelWithLink, t as FeedbackLink } from "./server-LabelWithLink-B6_1EdmD-Ce_5nDOi.js";
import { jsx } from "react/jsx-runtime";
/**
* Indicates a feature that is available to some, but not all, external (non-staff) users. The beta lifecycle can be
* private, limited, or public (the type of beta does not need to be indicated in this label).
*/
var BetaLabel = ({ children = "Preview", feedbackUrl, className }) => /* @__PURE__ */ jsx(LabelWithLink, {
	className,
	label: /* @__PURE__ */ jsx(Label, {
		variant: "success",
		children
	}),
	link: feedbackUrl ? /* @__PURE__ */ jsx(FeedbackLink, { feedbackUrl }) : void 0
});
BetaLabel.displayName = "BetaLabel";
export { BetaLabel as t };
