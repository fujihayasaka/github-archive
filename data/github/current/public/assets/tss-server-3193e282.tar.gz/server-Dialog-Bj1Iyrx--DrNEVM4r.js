import { m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Mi as XIcon, Vi as useOnEscapePress, an as IconButton } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import React, { forwardRef, useEffect, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var noop$1 = () => null;
function visible(el) {
	return !el.hidden && (!el.type || el.type !== "hidden") && (el.offsetWidth > 0 || el.offsetHeight > 0);
}
function focusable(el) {
	const inputEl = el;
	return inputEl.tabIndex >= 0 && !inputEl.disabled && visible(inputEl);
}
function useDialog(t0) {
	const $ = c(27);
	const { modalRef, overlayRef, isOpen, onDismiss: t1, initialFocusRef, closeButtonRef } = t0;
	const onDismiss = t1 === void 0 ? noop$1 : t1;
	let t2;
	if ($[0] !== modalRef || $[1] !== onDismiss || $[2] !== overlayRef) {
		t2 = (e) => {
			if (modalRef.current && overlayRef.current && e.target instanceof Node && !modalRef.current.contains(e.target) && overlayRef.current.contains(e.target)) onDismiss();
		};
		$[0] = modalRef;
		$[1] = onDismiss;
		$[2] = overlayRef;
		$[3] = t2;
	} else t2 = $[3];
	const onClickOutside = t2;
	let t3;
	let t4;
	if ($[4] !== isOpen || $[5] !== onClickOutside) {
		t3 = () => {
			if (isOpen) {
				document.addEventListener("click", onClickOutside);
				return () => {
					document.removeEventListener("click", onClickOutside);
				};
			}
		};
		t4 = [isOpen, onClickOutside];
		$[4] = isOpen;
		$[5] = onClickOutside;
		$[6] = t3;
		$[7] = t4;
	} else {
		t3 = $[6];
		t4 = $[7];
	}
	useEffect(t3, t4);
	let t5;
	let t6;
	if ($[8] !== closeButtonRef || $[9] !== initialFocusRef || $[10] !== isOpen) {
		t5 = () => {
			if (isOpen) {
				if (initialFocusRef && initialFocusRef.current) initialFocusRef.current.focus();
				else if (closeButtonRef && closeButtonRef.current) closeButtonRef.current.focus();
			}
		};
		t6 = [
			isOpen,
			initialFocusRef,
			closeButtonRef
		];
		$[8] = closeButtonRef;
		$[9] = initialFocusRef;
		$[10] = isOpen;
		$[11] = t5;
		$[12] = t6;
	} else {
		t5 = $[11];
		t6 = $[12];
	}
	useEffect(t5, t6);
	let t7;
	if ($[13] !== modalRef) {
		t7 = (e_0, movement) => {
			if (modalRef.current) {
				const items = Array.from(modalRef.current.querySelectorAll("*")).filter(focusable);
				if (items.length === 0) return;
				e_0.preventDefault();
				const focusedElement = document.activeElement;
				if (!focusedElement) return;
				const offsetIndex = items.indexOf(focusedElement) + movement;
				const fallbackIndex = movement === 1 ? 0 : items.length - 1;
				return items[offsetIndex] || items[fallbackIndex];
			}
		};
		$[13] = modalRef;
		$[14] = t7;
	} else t7 = $[14];
	const getFocusableItem = t7;
	let t8;
	if ($[15] !== getFocusableItem) {
		t8 = (e_1) => {
			const focusableItem_0 = getFocusableItem(e_1, e_1.shiftKey ? -1 : 1);
			if (!focusableItem_0) return;
			focusableItem_0.focus();
		};
		$[15] = getFocusableItem;
		$[16] = t8;
	} else t8 = $[16];
	const handleTab = t8;
	let t9;
	if ($[17] !== handleTab) {
		t9 = (event) => {
			switch (event.key) {
				case "Tab": handleTab(event);
			}
		};
		$[17] = handleTab;
		$[18] = t9;
	} else t9 = $[18];
	const onKeyDown = t9;
	let t10;
	if ($[19] !== onKeyDown) {
		t10 = () => ({ onKeyDown });
		$[19] = onKeyDown;
		$[20] = t10;
	} else t10 = $[20];
	const getDialogProps = t10;
	let t11;
	let t12;
	if ($[21] !== isOpen || $[22] !== onDismiss) {
		t11 = (event_0) => {
			if (isOpen) {
				onDismiss();
				event_0.preventDefault();
			}
		};
		t12 = [isOpen, onDismiss];
		$[21] = isOpen;
		$[22] = onDismiss;
		$[23] = t11;
		$[24] = t12;
	} else {
		t11 = $[23];
		t12 = $[24];
	}
	useOnEscapePress(t11, t12);
	let t13;
	if ($[25] !== getDialogProps) {
		t13 = { getDialogProps };
		$[25] = getDialogProps;
		$[26] = t13;
	} else t13 = $[26];
	return t13;
}
var classes = {
	"Overlay": "prc-DialogV1-Overlay-nYh-4",
	"CloseIcon": "prc-DialogV1-CloseIcon-NbiwR",
	"Dialog": "prc-DialogV1-Dialog-XiEJf",
	"Header": "prc-DialogV1-Header-r20Rf",
	"HeaderChild": "prc-DialogV1-HeaderChild-tk8Zn"
};
var noop = () => null;
function DialogHeader(t0) {
	const $ = c(14);
	let children;
	let className;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({children, className, as: t1, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = t1;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		t1 = $[4];
	}
	const Component = t1 === void 0 ? "div" : t1;
	if (React.Children.toArray(children).every(_temp)) {
		let t2;
		if ($[5] !== children) {
			t2 = /* @__PURE__ */ jsx("span", {
				className: classes.HeaderChild,
				children
			});
			$[5] = children;
			$[6] = t2;
		} else t2 = $[6];
		children = t2;
	}
	const t2 = rest;
	let t3;
	if ($[7] !== className) {
		t3 = clsx(classes.Header, className);
		$[7] = className;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== Component || $[10] !== children || $[11] !== rest || $[12] !== t3) {
		t4 = /* @__PURE__ */ jsx(Component, {
			...t2,
			className: t3,
			children
		});
		$[9] = Component;
		$[10] = children;
		$[11] = rest;
		$[12] = t3;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
}
function _temp(ch) {
	return typeof ch === "string";
}
var Dialog = /* @__PURE__ */ forwardRef((t0, forwardedRef) => {
	const $ = c(25);
	let children;
	let className;
	let initialFocusRef;
	let isOpen;
	let props;
	let returnFocusRef;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({children, onDismiss: t1, isOpen, initialFocusRef, returnFocusRef, className, as: t2, ...props} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = initialFocusRef;
		$[4] = isOpen;
		$[5] = props;
		$[6] = returnFocusRef;
		$[7] = t1;
		$[8] = t2;
	} else {
		children = $[1];
		className = $[2];
		initialFocusRef = $[3];
		isOpen = $[4];
		props = $[5];
		returnFocusRef = $[6];
		t1 = $[7];
		t2 = $[8];
	}
	const onDismiss = t1 === void 0 ? noop : t1;
	const Component = t2 === void 0 ? "div" : t2;
	const overlayRef = useRef(null);
	const modalRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, modalRef);
	const closeButtonRef = useRef(null);
	let t3;
	if ($[9] !== onDismiss || $[10] !== returnFocusRef) {
		t3 = () => {
			onDismiss();
			if (returnFocusRef && returnFocusRef.current) returnFocusRef.current.focus();
		};
		$[9] = onDismiss;
		$[10] = returnFocusRef;
		$[11] = t3;
	} else t3 = $[11];
	const onCloseClick = t3;
	let t4;
	if ($[12] !== initialFocusRef || $[13] !== isOpen || $[14] !== onCloseClick || $[15] !== returnFocusRef) {
		t4 = {
			modalRef,
			onDismiss: onCloseClick,
			isOpen,
			initialFocusRef,
			closeButtonRef,
			returnFocusRef,
			overlayRef
		};
		$[12] = initialFocusRef;
		$[13] = isOpen;
		$[14] = onCloseClick;
		$[15] = returnFocusRef;
		$[16] = t4;
	} else t4 = $[16];
	const { getDialogProps } = useDialog(t4);
	let t5;
	if ($[17] !== Component || $[18] !== children || $[19] !== className || $[20] !== getDialogProps || $[21] !== isOpen || $[22] !== onCloseClick || $[23] !== props) {
		t5 = isOpen ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
			className: classes.Overlay,
			ref: overlayRef
		}), /* @__PURE__ */ jsxs(Component, {
			tabIndex: -1,
			ref: modalRef,
			role: "dialog",
			"aria-modal": "true",
			...props,
			...getDialogProps(),
			className: clsx(classes.Dialog, className),
			"data-width": props.wide ? "wide" : props.narrow ? "narrow" : "default",
			children: [/* @__PURE__ */ jsx(IconButton, {
				icon: XIcon,
				ref: closeButtonRef,
				onClick: onCloseClick,
				"aria-label": "Close",
				variant: "invisible",
				className: classes.CloseIcon
			}), children]
		})] }) : null;
		$[17] = Component;
		$[18] = children;
		$[19] = className;
		$[20] = getDialogProps;
		$[21] = isOpen;
		$[22] = onCloseClick;
		$[23] = props;
		$[24] = t5;
	} else t5 = $[24];
	return t5;
});
DialogHeader.displayName = "Dialog.Header";
Dialog.displayName = "Dialog";
var Dialog_default = Object.assign(Dialog, { Header: DialogHeader });
export { Dialog_default as t };
