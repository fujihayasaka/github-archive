import { Mr as SidebarCollapseIcon, Nr as SidebarExpandIcon, an as IconButton } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import React from "react";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
var ExpandButton = ({ ref, expanded, testid, ariaLabel, ariaControls, onToggleExpanded, alignment, dataHotkey, className, size, tooltipDirection, variant }) => /* @__PURE__ */ jsx(IconButton, {
	"aria-label": ariaLabel,
	tooltipDirection,
	ref,
	"data-testid": expanded ? `collapse-${testid}` : `expand-${testid}`,
	"aria-expanded": expanded,
	"aria-controls": ariaControls,
	icon: expanded ? alignment === "left" ? SidebarExpandIcon : SidebarCollapseIcon : alignment === "left" ? SidebarCollapseIcon : SidebarExpandIcon,
	"data-hotkey": dataHotkey,
	onClick: (e) => {
		onToggleExpanded(e);
	},
	variant: variant ?? "invisible",
	size,
	className: clsx(className, "fgColor-muted")
});
ExpandButton.displayName = "ExpandButton";
ExpandButton.displayName = "ExpandButton";
export { ExpandButton as t };
