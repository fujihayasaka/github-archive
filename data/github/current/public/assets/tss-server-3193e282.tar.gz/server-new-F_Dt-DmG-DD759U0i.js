performance.mark("js-parse-end:server-new-F_Dt-DmG-DD759U0i.js");
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as CodeView } from "./server-CodeView-CCvwX-NJ-CNmyXFpi.js";
import { t as CodeViewEditor } from "./server-CodeViewEditor-g9_clWqC-Bcy7Tk3_.js";
import { t as codeViewNewRoute } from "./server-code-view-new-route-CPa0iN_Q-Rsso1z4C.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:new-F_Dt-DmG.js");
function CodeViewNewEntrypoint() {
	const $ = c(2);
	const { data: payload } = useRouteQuery(codeViewNewRoute, "mainQuery");
	let t0;
	if ($[0] !== payload) {
		t0 = jsx("div", {
			className: "tmp-pt-3",
			children: jsx(CodeView, {
				payload,
				action: "new",
				children: () => jsx(CodeViewEditor, {
					editInfo: payload.editInfo,
					path: payload.path,
					webCommitInfo: payload.webCommitInfo,
					copilotInfo: payload.copilotInfo,
					copilotGenerateCommitMessageAuthInfo: payload.copilotGenerateCommitMessageAuthInfo
				})
			})
		});
		$[0] = payload;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
CodeViewNewEntrypoint.displayName = "CodeViewNewEntrypoint";
var SplitComponent = CodeViewNewEntrypoint;
export { SplitComponent as component };
