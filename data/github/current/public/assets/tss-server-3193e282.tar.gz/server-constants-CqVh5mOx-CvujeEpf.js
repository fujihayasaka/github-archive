var analyticsCategory = "GLOBAL_NAV_USER_MENU";
export { analyticsCategory as t };
