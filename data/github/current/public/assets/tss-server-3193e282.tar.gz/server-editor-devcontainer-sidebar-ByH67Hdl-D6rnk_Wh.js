performance.mark("js-parse-end:server-editor-devcontainer-sidebar-ByH67Hdl-D6rnk_Wh.js");
import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
performance.mark("js-parse-end:editor-devcontainer-sidebar-ByH67Hdl.js");
function listOfFeatures() {
	return ssrSafeDocument?.querySelector("#js-devcontainer-editor-sidebar-content-complete");
}
function showAllFeatures() {
	const allFeatures = listOfFeatures()?.querySelectorAll(".js-devcontainer-editor-sidebar-feature") || [];
	for (const feature of allFeatures) feature.hidden = false;
}
ssrSafeDocument?.addEventListener("DOMContentLoaded", () => {
	showAllFeatures();
});
export {};
