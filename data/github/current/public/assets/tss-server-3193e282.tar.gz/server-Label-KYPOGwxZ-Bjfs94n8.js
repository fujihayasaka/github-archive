import React from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var classes = { "Label": "prc-Label-Label-qG-Zu" };
var Label = /* @__PURE__ */ React.forwardRef(function Label(t0, ref) {
	const $ = c(15);
	let className;
	let rest;
	let t1;
	let t2;
	let t3;
	if ($[0] !== t0) {
		({as: t1, size: t2, variant: t3, className, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = rest;
		$[3] = t1;
		$[4] = t2;
		$[5] = t3;
	} else {
		className = $[1];
		rest = $[2];
		t1 = $[3];
		t2 = $[4];
		t3 = $[5];
	}
	const Component = t1 === void 0 ? "span" : t1;
	const size = t2 === void 0 ? "small" : t2;
	const variant = t3 === void 0 ? "default" : t3;
	let t4;
	if ($[6] !== className) {
		t4 = clsx(className, classes.Label);
		$[6] = className;
		$[7] = t4;
	} else t4 = $[7];
	let t5;
	if ($[8] !== Component || $[9] !== ref || $[10] !== rest || $[11] !== size || $[12] !== t4 || $[13] !== variant) {
		t5 = /* @__PURE__ */ jsx(Component, {
			className: t4,
			"data-size": size,
			"data-variant": variant,
			ref,
			...rest
		});
		$[8] = Component;
		$[9] = ref;
		$[10] = rest;
		$[11] = size;
		$[12] = t4;
		$[13] = variant;
		$[14] = t5;
	} else t5 = $[14];
	return t5;
});
export { Label as t };
