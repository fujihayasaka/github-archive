import React, { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var EditPermissionsContext = React.createContext({
	canEdit: false,
	canEditOnDefaultBranch: false,
	fileExistsOnDefault: false
});
EditPermissionsContext.displayName = "EditPermissionsContext";
function EditPermissionsProvider(t0) {
	const $ = c(7);
	const { children, canEdit: t1, canEditOnDefaultBranch: t2, fileExistsOnDefault: t3 } = t0;
	const canEdit = t1 === void 0 ? false : t1;
	const canEditOnDefaultBranch = t2 === void 0 ? false : t2;
	const fileExistsOnDefault = t3 === void 0 ? false : t3;
	let t4;
	if ($[0] !== canEdit || $[1] !== canEditOnDefaultBranch || $[2] !== fileExistsOnDefault) {
		t4 = {
			canEdit,
			canEditOnDefaultBranch,
			fileExistsOnDefault
		};
		$[0] = canEdit;
		$[1] = canEditOnDefaultBranch;
		$[2] = fileExistsOnDefault;
		$[3] = t4;
	} else t4 = $[3];
	const value = t4;
	let t5;
	if ($[4] !== children || $[5] !== value) {
		t5 = jsx(EditPermissionsContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t5;
	} else t5 = $[6];
	return t5;
}
EditPermissionsProvider.displayName = "EditPermissionsProvider";
function useEditPermissions() {
	return React.use(EditPermissionsContext);
}
export { useEditPermissions as n, EditPermissionsProvider as t };
