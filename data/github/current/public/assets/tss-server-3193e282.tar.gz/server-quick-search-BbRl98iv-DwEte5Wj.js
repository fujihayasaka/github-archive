performance.mark("js-parse-end:server-quick-search-BbRl98iv-DwEte5Wj.js");
import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { Ai as XCircleFillIcon, Bt as GiftIcon, Dr as ShieldCheckIcon, G as CodeSquareIcon, J as CodespacesIcon, Kn as PackageIcon, Tr as ServerIcon, V as ClockIcon, W as CodeReviewIcon, Wn as OrganizationIcon, X as CommentDiscussionIcon, Yt as GlobeIcon, Z as CommentIcon, b as BookIcon, ct as DeviceMobileIcon, en as HeartIcon, et as CopilotIcon, fn as IssueOpenedIcon, gr as RepoIcon, ki as WorkflowIcon, nt as CreditCardIcon, rr as PlayIcon, st as DeviceDesktopIcon, wr as SearchIcon, xr as RocketIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { d as FilterValueType, j as defaultFilterConfig, n as BlockType, u as FilterQueryParser } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { n as OrgFilterProvider, r as RepositoryFilterProvider } from "./server-repository-CE0zbnIG-CI4ka2FT.js";
import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
import { AnimatePresence, motion } from "framer-motion";
performance.mark("js-parse-end:quick-search-BbRl98iv.js");
var ExplorePages = [
	{
		title: "GitHub Actions",
		url: "/features/actions",
		octicon: "workflow"
	},
	{
		title: "Blog",
		url: "https://github.blog",
		octicon: "book"
	},
	{
		title: "CI/CD",
		url: "/solutions/ci-cd/",
		octicon: "workflow"
	},
	{
		title: "Code review",
		url: "/features/code-review",
		octicon: "code-review"
	},
	{
		title: "Codespaces",
		url: "/features/codespaces",
		octicon: "codespaces"
	},
	{
		title: "Copilot",
		url: "/features/copilot",
		octicon: "copilot"
	},
	{
		title: "Customer stories",
		url: "/customer-stories",
		octicon: "comment"
	},
	{
		title: "Discussions",
		url: "/features/discussions",
		octicon: "comment-discussion"
	},
	{
		title: "Documentation",
		url: "https://docs.github.com",
		octicon: "book"
	},
	{
		title: "Enterprise",
		url: "/enterprise",
		octicon: "organization"
	},
	{
		title: "Features",
		url: "/features",
		octicon: "rocket"
	},
	{
		title: "GitHub Security",
		url: "/security",
		octicon: "shield-check"
	},
	{
		title: "GitHub Sponsors",
		url: "/sponsors",
		octicon: "heart"
	},
	{
		title: "GitHub Pages",
		url: "https://pages.github.com",
		octicon: "server"
	},
	{
		title: "Integrations",
		url: "/features/integrations",
		octicon: "globe"
	},
	{
		title: "Issues",
		url: "/features/issues",
		octicon: "issue-opened"
	},
	{
		title: "GitHub Mobile",
		url: "/mobile",
		octicon: "device-mobile"
	},
	{
		title: "GitHub Packages",
		url: "/features/packages",
		octicon: "package"
	},
	{
		title: "Pricing",
		url: "/pricing",
		octicon: "credit-card"
	},
	{
		title: "Resources",
		url: "https://resources.github.com",
		octicon: "book"
	},
	{
		title: "Secure your code",
		url: "/features/security/code-scanning",
		octicon: "shield-check"
	},
	{
		title: "Security features",
		url: "/features/security",
		octicon: "shield-check"
	},
	{
		title: "Software supply chain",
		url: "/features/security/software-supply-chain",
		octicon: "shield-check"
	},
	{
		title: "Startups",
		url: "/enterprise/startups",
		octicon: "rocket"
	},
	{
		title: "Team",
		url: "/team",
		octicon: "organization"
	},
	{
		title: "The ReadME Project",
		url: "/readme",
		octicon: "book"
	},
	{
		title: "The ReadME Podcast",
		url: "/readme/podcast",
		octicon: "play"
	},
	{
		title: "Feature Previews",
		url: "/features/preview",
		octicon: "gift"
	},
	{
		title: "Code Search",
		url: "/features/code-search",
		octicon: "code-square"
	},
	{
		title: "GitHub Changelog",
		url: "https://github.blog/changelog",
		octicon: "book"
	},
	{
		title: "GitHub Shop",
		url: "https://www.thegithubshop.com/",
		octicon: "gift"
	},
	{
		title: "GitHub Desktop",
		url: "https://desktop.github.com",
		octicon: "device-desktop"
	}
];
var quick_search_module_default = {
	actionLabel: "quick-search-module_hXjSfq_actionLabel",
	footer: "quick-search-module_hXjSfq_footer",
	footerLink: "quick-search-module_hXjSfq_footerLink",
	input: "quick-search-module_hXjSfq_input",
	quickSearchDialog: "quick-search-module_hXjSfq_quickSearchDialog",
	searchContainer: "quick-search-module_hXjSfq_searchContainer",
	skeletonIcon: "quick-search-module_hXjSfq_skeletonIcon",
	skeletonItem: "quick-search-module_hXjSfq_skeletonItem",
	skeletonList: "quick-search-module_hXjSfq_skeletonList",
	skeletonRow: "quick-search-module_hXjSfq_skeletonRow",
	skeletonText: "quick-search-module_hXjSfq_skeletonText",
	srOnly: "quick-search-module_hXjSfq_srOnly",
	suggestionAvatar: "quick-search-module_hXjSfq_suggestionAvatar",
	suggestionButton: "quick-search-module_hXjSfq_suggestionButton",
	suggestionGroupHeader: "quick-search-module_hXjSfq_suggestionGroupHeader",
	suggestionGroupLabel: "quick-search-module_hXjSfq_suggestionGroupLabel",
	suggestionGroupList: "quick-search-module_hXjSfq_suggestionGroupList",
	suggestionIcon: "quick-search-module_hXjSfq_suggestionIcon",
	suggestionItem: "quick-search-module_hXjSfq_suggestionItem",
	suggestionItemActive: "quick-search-module_hXjSfq_suggestionItemActive",
	suggestionLink: "quick-search-module_hXjSfq_suggestionLink",
	suggestionList: "quick-search-module_hXjSfq_suggestionList",
	suggestionName: "quick-search-module_hXjSfq_suggestionName"
};
var MAX_SUGGESTIONS_PER_TYPE = 5;
var MAX_INITIAL_PER_TYPE = 3;
var RECENT_SEARCHES_KEY = "github-quicksearch-recent";
var MAX_RECENT_SEARCHES = 5;
var MAX_LOGGED_OUT_SUGGESTIONS = 4;
var FILTER_PROVIDER_OPTIONS = { filterTypes: {
	exclusive: false,
	valueless: false,
	hasValue: false
} };
var prewarmOrgProvider = new OrgFilterProvider(FILTER_PROVIDER_OPTIONS);
var prewarmRepoProvider = new RepositoryFilterProvider(FILTER_PROVIDER_OPTIONS);
var prewarmParser = new FilterQueryParser([prewarmOrgProvider, prewarmRepoProvider], defaultFilterConfig);
var suggestionsCache = /* @__PURE__ */ new Map();
var EXPLORE_ICON_MAP = {
	organization: OrganizationIcon,
	"shield-check": ShieldCheckIcon,
	copilot: CopilotIcon,
	"credit-card": CreditCardIcon,
	workflow: WorkflowIcon,
	book: BookIcon,
	"code-review": CodeReviewIcon,
	codespaces: CodespacesIcon,
	comment: CommentIcon,
	"comment-discussion": CommentDiscussionIcon,
	rocket: RocketIcon,
	heart: HeartIcon,
	server: ServerIcon,
	globe: GlobeIcon,
	"issue-opened": IssueOpenedIcon,
	"device-mobile": DeviceMobileIcon,
	package: PackageIcon,
	play: PlayIcon,
	gift: GiftIcon,
	"code-square": CodeSquareIcon,
	"device-desktop": DeviceDesktopIcon
};
function getCacheKey(lastSegment, isLoggedOut) {
	return isLoggedOut ? `logged-out:${lastSegment}` : lastSegment;
}
function getExploreIcon(octicon) {
	return EXPLORE_ICON_MAP[octicon] ?? SearchIcon;
}
function mapExplorePage(page) {
	return {
		id: `explore-${page.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}`,
		icon: getExploreIcon(page.octicon),
		displayName: page.title,
		href: page.url,
		ariaLabel: `Explore ${page.title}`,
		action: "jump-to",
		group: "suggestions"
	};
}
function buildExploreSuggestions(pages) {
	return pages.map(mapExplorePage);
}
function filterExplorePages(query) {
	const normalized = query.trim().toLowerCase();
	if (!normalized) return buildExploreSuggestions(ExplorePages).slice(0, MAX_LOGGED_OUT_SUGGESTIONS);
	return buildExploreSuggestions(ExplorePages.filter((page) => page.title.toLowerCase().includes(normalized))).slice(0, MAX_LOGGED_OUT_SUGGESTIONS);
}
/**
* Returns the segment currently being typed — the part after the last space.
* An empty string means either the query is empty or the user just inserted a
* space (completed a filter token), so we should show initial suggestions.
*/
function getLastSegment(query) {
	if (!query || query.endsWith(" ")) return "";
	const parts = query.split(" ");
	return parts[parts.length - 1] ?? "";
}
/**
* Inspects the completed (space-separated) filter tokens that precede the
* currently-typed segment to detect already-applied org:/repo: scopes.
*/
function extractPrecedingFilters(query) {
	const completed = query.split(" ").slice(0, -1);
	return {
		hasOrgFilter: completed.some((s) => /^org:/i.test(s)),
		hasRepoFilter: completed.some((s) => /^repo:/i.test(s))
	};
}
function loadRecentSearches() {
	try {
		const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
		return stored ? JSON.parse(stored) : [];
	} catch {
		return [];
	}
}
function saveRecentSearch(query) {
	try {
		const deduped = loadRecentSearches().filter((q) => q !== query);
		localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify([query, ...deduped].slice(0, MAX_RECENT_SEARCHES)));
	} catch {}
}
/**
* @param filterMode When true the suggestion represents narrowing the filter
*   scope (e.g. typing `org:github` → autocomplete to `org:github `) rather
*   than navigating directly to the org profile.
*/
function mapOrgSuggestion(s, filterMode = false) {
	const value = typeof s.value === "string" ? s.value : s.value();
	const displayName = s.displayName ?? value;
	if (filterMode) return {
		id: `org-${value}`,
		icon: OrganizationIcon,
		displayName,
		insertValue: `org:${value} `,
		ariaLabel: `Autocomplete org:${value} scope, organization`,
		action: "autocomplete",
		avatarUrl: s.avatar?.url,
		group: "organizations"
	};
	return {
		id: `org-${value}`,
		icon: OrganizationIcon,
		displayName,
		href: `/${value}`,
		ariaLabel: `Jump to ${displayName}, organization`,
		action: "jump-to",
		avatarUrl: s.avatar?.url,
		group: "organizations"
	};
}
function mapRepoSuggestion(s, filterMode = false) {
	const value = typeof s.value === "string" ? s.value : s.value();
	const displayName = s.displayName ?? value;
	if (filterMode) return {
		id: `repo-${value}`,
		icon: RepoIcon,
		displayName,
		insertValue: `repo:${value} `,
		ariaLabel: `Autocomplete repo:${value} scope, repository`,
		action: "autocomplete",
		group: "repositories"
	};
	return {
		id: `repo-${value}`,
		icon: RepoIcon,
		displayName,
		href: `/${value}`,
		ariaLabel: `Jump to ${displayName}, repository`,
		action: "jump-to",
		avatarUrl: s.avatar?.url,
		group: "repositories"
	};
}
function isValueSuggestion(s) {
	return s.type === FilterValueType.Value;
}
var GROUP_ORDER = [
	"contextual",
	"recent",
	"repositories",
	"organizations",
	"suggestions"
];
var GROUP_LABELS = {
	recent: "Recent",
	repositories: "Repositories",
	organizations: "Organizations",
	suggestions: "Suggestions",
	contextual: ""
};
function getGroupLabels(isLoggedOut) {
	if (!isLoggedOut) return GROUP_LABELS;
	return {
		...GROUP_LABELS,
		suggestions: "Explore"
	};
}
function buildRenderedGroups(suggestions, isLoggedOut, showEmptyGroups, persistentGroups) {
	const buckets = /* @__PURE__ */ new Map();
	for (const s of suggestions) {
		const bucket = buckets.get(s.group) ?? [];
		bucket.push(s);
		buckets.set(s.group, bucket);
	}
	const groups = [];
	let flatIndex = 0;
	const groupLabels = getGroupLabels(isLoggedOut);
	for (const groupKey of GROUP_ORDER) {
		const items = buckets.get(groupKey);
		const hasItems = !!items && items.length > 0;
		const shouldRenderEmpty = showEmptyGroups && persistentGroups.has(groupKey);
		if (hasItems || shouldRenderEmpty) groups.push({
			label: groupLabels[groupKey],
			items: (items ?? []).map((suggestion) => ({
				suggestion,
				flatIndex: flatIndex++
			}))
		});
	}
	return groups;
}
function SuggestionLeadingVisual(t0) {
	const $ = c(5);
	const { suggestion } = t0;
	const [imgFailed, setImgFailed] = useState(false);
	const IconComponent = suggestion.icon;
	if (suggestion.avatarUrl && !imgFailed) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = () => setImgFailed(true);
			$[0] = t1;
		} else t1 = $[0];
		let t2;
		if ($[1] !== suggestion.avatarUrl) {
			t2 = jsx("img", {
				src: suggestion.avatarUrl,
				alt: "",
				className: quick_search_module_default.suggestionAvatar,
				width: 16,
				height: 16,
				onError: t1
			});
			$[1] = suggestion.avatarUrl;
			$[2] = t2;
		} else t2 = $[2];
		return t2;
	}
	let t1;
	if ($[3] !== IconComponent) {
		t1 = jsx(IconComponent, {
			size: 16,
			className: quick_search_module_default.suggestionIcon
		});
		$[3] = IconComponent;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
SuggestionLeadingVisual.displayName = "SuggestionLeadingVisual";
async function buildInitialSuggestions(orgProvider, repoProvider, parser, additionalSuggestions) {
	if (!isLoggedIn()) return filterExplorePages("");
	const emptyFq = parser.parse("", void 0, 0);
	const orgBlock = {
		id: 0,
		type: BlockType.Filter,
		raw: "org:",
		key: {
			value: "org",
			valid: true
		},
		value: {
			raw: "",
			values: []
		},
		provider: orgProvider
	};
	const repoBlock = {
		id: 0,
		type: BlockType.Filter,
		raw: "repo:",
		key: {
			value: "repo",
			valid: true
		},
		value: {
			raw: "",
			values: []
		},
		provider: repoProvider
	};
	const [orgSuggestions, repoSuggestions] = await Promise.all([orgProvider.getSuggestions(emptyFq, orgBlock, defaultFilterConfig, null), repoProvider.getSuggestions(emptyFq, repoBlock, defaultFilterConfig, null)]);
	const topOrgs = (orgSuggestions ?? []).filter(isValueSuggestion).slice(0, MAX_INITIAL_PER_TYPE);
	const topRepos = (repoSuggestions ?? []).filter(isValueSuggestion).slice(0, MAX_INITIAL_PER_TYPE);
	return [
		...loadRecentSearches().map((q) => ({
			id: `recent-${q}`,
			icon: ClockIcon,
			displayName: q,
			href: `/search?q=${encodeURIComponent(q)}`,
			ariaLabel: `Recent search: ${q}`,
			action: "search",
			group: "recent"
		})),
		...topRepos.map((s) => mapRepoSuggestion(s)),
		...topOrgs.map((s) => mapOrgSuggestion(s)),
		...additionalSuggestions ?? [],
		{
			id: "copilot-chat",
			icon: CopilotIcon,
			displayName: "Chat with Copilot",
			href: "/copilot",
			ariaLabel: "Open Copilot chat",
			action: "jump-to",
			group: "suggestions"
		}
	];
}
function preloadQuickSearch() {
	(async () => {
		try {
			const initial = await buildInitialSuggestions(prewarmOrgProvider, prewarmRepoProvider, prewarmParser);
			const cacheKey = getCacheKey("", !isLoggedIn());
			if (!suggestionsCache.has(cacheKey)) suggestionsCache.set(cacheKey, initial);
		} catch {}
	})();
}
if (typeof document !== "undefined") preloadQuickSearch();
function getActionLabel(suggestion) {
	if (suggestion?.customActionLabel) return suggestion.customActionLabel;
	if (suggestion.id === "copilot-chat") return "Start a new Copilot thread";
	if (suggestion.action === "jump-to") return "Jump to";
	if (suggestion.action === "autocomplete") return "Autocomplete";
	return null;
}
var SKELETON_WIDTHS = [
	52,
	38,
	45,
	60
];
function SuggestionSkeletons() {
	return /* @__PURE__ */ jsx("ul", {
		"aria-hidden": "true",
		className: quick_search_module_default.skeletonList,
		children: SKELETON_WIDTHS.map((width, i) => /* @__PURE__ */ jsx("li", {
			className: quick_search_module_default.skeletonItem,
			children: /* @__PURE__ */ jsxs("span", {
				className: quick_search_module_default.skeletonRow,
				children: [/* @__PURE__ */ jsx("span", { className: quick_search_module_default.skeletonIcon }), /* @__PURE__ */ jsx("span", {
					className: quick_search_module_default.skeletonText,
					style: { width: `${width}%` }
				})]
			})
		}, i))
	});
}
SuggestionSkeletons.displayName = "SuggestionSkeletons";
function QuickSearch({ isOpen, onClose, returnFocusRef, additionalSuggestions, footerLinks, searchContext }) {
	const searchInputRef = useRef(null);
	const listboxId = useId();
	const [query, setQuery] = useState("");
	const isLoggedOut = !isLoggedIn();
	const emptyCacheKey = getCacheKey("", isLoggedOut);
	const [suggestions, setSuggestions] = useState(() => suggestionsCache.get(emptyCacheKey) ?? []);
	const [activeIndex, setActiveIndex] = useState(-1);
	const [isLoading, setIsLoading] = useState(() => !suggestionsCache.has(emptyCacheKey));
	const suggestionIdsRef = useRef("");
	const [persistentGroups, setPersistentGroups] = useState(() => /* @__PURE__ */ new Set());
	const { orgProvider, repoProvider, parser } = useMemo(() => {
		const org = new OrgFilterProvider(FILTER_PROVIDER_OPTIONS);
		const repo = new RepositoryFilterProvider(FILTER_PROVIDER_OPTIONS);
		return {
			orgProvider: org,
			repoProvider: repo,
			parser: new FilterQueryParser([org, repo], defaultFilterConfig)
		};
	}, []);
	const handleClose = useCallback(() => {
		setQuery("");
		setActiveIndex(-1);
		suggestionIdsRef.current = "";
		onClose();
	}, [onClose]);
	useEffect(() => {
		if (!isOpen) return;
		let cancelled = false;
		async function fetchSuggestions() {
			const lastSegment = getLastSegment(query);
			const cacheKey = getCacheKey(lastSegment, isLoggedOut);
			const config = defaultFilterConfig;
			const cachedSuggestions = suggestionsCache.get(cacheKey);
			if (cachedSuggestions && !cancelled) {
				setSuggestions(cachedSuggestions);
				setIsLoading(false);
				setPersistentGroups(new Set(cachedSuggestions.map((s) => s.group)));
			}
			function commitSuggestions(next) {
				const ids = next.map((s_0) => s_0.id).join(",");
				setSuggestions(next);
				setIsLoading(false);
				setPersistentGroups(new Set(next.map((s_1) => s_1.group)));
				if (ids !== suggestionIdsRef.current) {
					setActiveIndex(-1);
					suggestionIdsRef.current = ids;
				}
			}
			if (isLoggedOut) {
				const exploreSuggestions = filterExplorePages(lastSegment).slice(0, MAX_LOGGED_OUT_SUGGESTIONS);
				suggestionsCache.set(cacheKey, exploreSuggestions);
				if (!cancelled) commitSuggestions(exploreSuggestions);
				return;
			}
			if (!lastSegment) {
				const { hasOrgFilter, hasRepoFilter } = extractPrecedingFilters(query);
				const initial = await buildInitialSuggestions(orgProvider, repoProvider, parser, additionalSuggestions);
				if (cancelled) return;
				const filtered = initial.filter((s_2) => {
					if (hasOrgFilter && s_2.group === "organizations" && s_2.action === "jump-to") return false;
					if (hasRepoFilter && s_2.group === "repositories" && s_2.action === "jump-to") return false;
					return true;
				});
				suggestionsCache.set(cacheKey, filtered);
				if (!cancelled) commitSuggestions(filtered);
				return;
			}
			const isOrgQuery = /^org:/i.test(lastSegment);
			const isRepoQuery = /^repo:/i.test(lastSegment);
			let orgResults = [];
			let repoResults = [];
			const getContextualSuggestions = () => {
				const searchContextSuggestions = [];
				const basicSuggestion = {
					id: `search-${query.trim()}`,
					icon: SearchIcon,
					displayName: `${query.trim()}`,
					searchQuery: query.trim(),
					href: `/search?q=${encodeURIComponent(query.trim())}`,
					ariaLabel: `Search GitHub for ${query.trim()}`,
					action: "search",
					group: "contextual",
					insertValue: query.trim(),
					customActionLabel: "Search All of GitHub"
				};
				searchContextSuggestions.push(basicSuggestion);
				if (searchContext?.current_repo_nwo) {
					const repoSuggestion = {
						id: `current-repo-nwo-search-${query.trim()}`,
						icon: SearchIcon,
						displayName: `repo:${searchContext.current_repo_nwo} ${query.trim()}`,
						searchQuery: query.trim(),
						href: `/search?q=${encodeURIComponent(`repo:${searchContext.current_repo_nwo} ${query.trim()}`)}`,
						ariaLabel: `Search ${searchContext.current_repo_nwo} for ${query.trim()}`,
						action: "search",
						group: "contextual",
						customActionLabel: "Search in this repository"
					};
					searchContextSuggestions.push(repoSuggestion);
				}
				if (searchContext?.current_repo_org) {
					const orgSuggestion = {
						id: `current-org-search-${query.trim()}`,
						icon: SearchIcon,
						displayName: `org:${searchContext.current_repo_org} ${query.trim()}`,
						searchQuery: query.trim(),
						href: `/search?q=${encodeURIComponent(`org:${searchContext.current_repo_org} ${query.trim()}`)}`,
						ariaLabel: `Search Organization ${searchContext.current_repo_org} for ${query.trim()}`,
						action: "search",
						group: "contextual",
						customActionLabel: "Search in this organization"
					};
					searchContextSuggestions.push(orgSuggestion);
				}
				if (searchContext?.current_business) {
					const businessSuggestion = {
						id: `current-enterprise-search-${query.trim()}`,
						icon: SearchIcon,
						displayName: `enterprise:${searchContext.current_business} ${query.trim()}`,
						searchQuery: query.trim(),
						href: `/search?q=${encodeURIComponent(`enterprise:${searchContext.current_business} ${query.trim()}`)}`,
						ariaLabel: `Search Enterprise ${searchContext.current_business} for ${query.trim()}`,
						action: "search",
						group: "contextual",
						customActionLabel: "Search in this enterprise"
					};
					searchContextSuggestions.push(businessSuggestion);
				}
				if (searchContext?.user_id && !searchContext?.current_repo_org) {
					const userSuggestion = {
						id: `current-user-search-${query.trim()}`,
						icon: SearchIcon,
						displayName: `user:${searchContext.user_id} ${query.trim()}`,
						searchQuery: query.trim(),
						href: `/search?q=${encodeURIComponent(`user:${searchContext.user_id} ${query.trim()}`)}`,
						ariaLabel: `Search User ${searchContext.user_id} for ${query.trim()}`,
						action: "search",
						group: "contextual",
						customActionLabel: "Search in this organization"
					};
					searchContextSuggestions.push(userSuggestion);
				}
				return searchContextSuggestions;
			};
			if (isOrgQuery) {
				const value = lastSegment.slice(4);
				if (!value) {
					const result = [
						...(suggestionsCache.get(getCacheKey("", false)) ?? []).filter((s_3) => s_3.group === "organizations"),
						...additionalSuggestions ?? [],
						...getContextualSuggestions()
					];
					suggestionsCache.set(cacheKey, result);
					if (!cancelled) commitSuggestions(result);
					return;
				}
				const fq = parser.parse("", void 0, 0);
				const block = {
					id: 0,
					type: BlockType.Filter,
					raw: lastSegment,
					key: {
						value: "org",
						valid: true
					},
					provider: orgProvider,
					value: {
						raw: value,
						values: [{ value }]
					}
				};
				orgResults = (await orgProvider.getSuggestions(fq, block, config, null) ?? []).filter(isValueSuggestion).slice(0, MAX_SUGGESTIONS_PER_TYPE);
			} else if (isRepoQuery) {
				const value_0 = lastSegment.slice(5);
				if (!value_0) {
					const result_0 = [
						...(suggestionsCache.get(getCacheKey("", false)) ?? []).filter((s_4) => s_4.group === "repositories"),
						...additionalSuggestions ?? [],
						...getContextualSuggestions()
					];
					suggestionsCache.set(cacheKey, result_0);
					if (!cancelled) commitSuggestions(result_0);
					return;
				}
				const fq_0 = parser.parse("", void 0, 0);
				const block_0 = {
					id: 0,
					type: BlockType.Filter,
					raw: lastSegment,
					key: {
						value: "repo",
						valid: true
					},
					provider: repoProvider,
					value: {
						raw: value_0,
						values: [{ value: value_0 }]
					}
				};
				repoResults = (await repoProvider.getSuggestions(fq_0, block_0, config, null) ?? []).filter(isValueSuggestion).slice(0, MAX_SUGGESTIONS_PER_TYPE);
			} else {
				const orgQueryStr = `org:${lastSegment}`;
				const repoQueryStr = `repo:${lastSegment}`;
				const orgFq = parser.parse(orgQueryStr, void 0, orgQueryStr.length);
				const repoFq = parser.parse(repoQueryStr, void 0, repoQueryStr.length);
				const [orgGroups, repoGroups] = await Promise.all([orgFq.getSuggestions(orgQueryStr.length, { org: orgProvider }, config), repoFq.getSuggestions(repoQueryStr.length, { repo: repoProvider }, config)]);
				orgResults = orgGroups.flatMap((g) => g.suggestions).filter(isValueSuggestion).slice(0, MAX_SUGGESTIONS_PER_TYPE);
				repoResults = repoGroups.flatMap((g_0) => g_0.suggestions).filter(isValueSuggestion).slice(0, MAX_SUGGESTIONS_PER_TYPE);
			}
			if (cancelled) return;
			const newSuggestions = [
				...repoResults.map((s_5) => mapRepoSuggestion(s_5, isRepoQuery)),
				...orgResults.map((s_6) => mapOrgSuggestion(s_6, isOrgQuery)),
				...additionalSuggestions ?? [],
				...getContextualSuggestions()
			];
			suggestionsCache.set(cacheKey, newSuggestions);
			if (!cancelled) commitSuggestions(newSuggestions);
		}
		fetchSuggestions();
		return () => {
			cancelled = true;
		};
	}, [
		query,
		orgProvider,
		repoProvider,
		parser,
		additionalSuggestions,
		searchContext,
		isLoggedOut,
		isOpen
	]);
	const navigate = useCallback((direction) => {
		if (suggestions.length === 0) return;
		setActiveIndex((i) => {
			if (direction === "down") return Math.min(i + 1, suggestions.length - 1);
			return Math.max(i - 1, -1);
		});
	}, [suggestions.length]);
	const selectActive = useCallback(() => {
		const suggestion = suggestions[activeIndex];
		if (suggestion) {
			if (suggestion.action === "autocomplete" && suggestion.insertValue !== void 0) {
				setQuery(suggestion.insertValue);
				setActiveIndex(-1);
				searchInputRef.current?.focus();
			} else if (suggestion.href) {
				if (suggestion.action === "search") saveRecentSearch(suggestion.searchQuery ?? suggestion.displayName);
				window.location.assign(suggestion.href);
				handleClose();
			}
		} else if (query.trim()) {
			saveRecentSearch(query.trim());
			window.location.assign(`/search?q=${encodeURIComponent(query.trim())}`);
			handleClose();
		}
	}, [
		suggestions,
		activeIndex,
		query,
		handleClose
	]);
	const activeOptionId = activeIndex >= 0 ? `${listboxId}-option-${activeIndex}` : void 0;
	const hasResults = suggestions.length > 0;
	const showSkeletons = isLoading && !hasResults;
	const canSelect = activeIndex >= 0 || query.trim().length > 0;
	const deferFocusSearchInput = useCallback(() => {
		const input = searchInputRef.current;
		if (!input) return;
		requestAnimationFrame(() => input.focus());
	}, []);
	if (!isOpen) return null;
	const renderedGroups = buildRenderedGroups(suggestions, isLoggedOut, isLoading, persistentGroups);
	return /* @__PURE__ */ jsx(ScopedCommands, {
		commands: hasResults ? {
			"github:up": () => navigate("up"),
			"github:down": () => navigate("down"),
			...canSelect ? { "github:select": () => selectActive() } : {},
			"github:cancel": () => handleClose()
		} : {},
		children: /* @__PURE__ */ jsx(Dialog, {
			onClose: handleClose,
			initialFocusRef: searchInputRef,
			returnFocusRef,
			renderHeader: ({ dialogLabelId }) => /* @__PURE__ */ jsx("h1", {
				id: dialogLabelId,
				className: quick_search_module_default.srOnly,
				children: "Quick search"
			}),
			className: quick_search_module_default.quickSearchDialog,
			children: /* @__PURE__ */ jsxs(Dialog.Body, {
				className: "d-flex p-2 flex-column",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: quick_search_module_default.searchContainer,
						children: /* @__PURE__ */ jsx(TextInput$1, {
							className: quick_search_module_default.input,
							ref: searchInputRef,
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Search or jump to...",
							role: "combobox",
							"aria-haspopup": "listbox",
							"aria-expanded": hasResults,
							"aria-controls": listboxId,
							"aria-autocomplete": "list",
							"aria-activedescendant": activeOptionId,
							trailingAction: query ? /* @__PURE__ */ jsx(TextInput$1.Action, {
								icon: XCircleFillIcon,
								"aria-label": "Clear search",
								onClick: () => {
									setQuery("");
									deferFocusSearchInput();
								}
							}) : void 0
						})
					}),
					/* @__PURE__ */ jsx("ul", {
						id: listboxId,
						role: "listbox",
						"aria-label": "Search suggestions",
						className: quick_search_module_default.suggestionList,
						children: showSkeletons ? null : /* @__PURE__ */ jsx(AnimatePresence, {
							initial: false,
							children: renderedGroups.map((group) => /* @__PURE__ */ jsxs(motion.li, {
								role: "presentation",
								className: quick_search_module_default.suggestionGroupHeader,
								initial: { opacity: 0 },
								animate: { opacity: 1 },
								exit: { opacity: 0 },
								transition: { duration: .12 },
								children: [/* @__PURE__ */ jsx("span", {
									className: quick_search_module_default.suggestionGroupLabel,
									children: group.label
								}), /* @__PURE__ */ jsx("ul", {
									role: "presentation",
									className: quick_search_module_default.suggestionGroupList,
									children: /* @__PURE__ */ jsx(AnimatePresence, {
										initial: false,
										children: group.items.map(({ suggestion: suggestion_0, flatIndex }) => {
											const isActive = flatIndex === activeIndex;
											return /* @__PURE__ */ jsx(motion.li, {
												layout: true,
												id: `${listboxId}-option-${flatIndex}`,
												role: "option",
												"aria-selected": isActive,
												"aria-label": suggestion_0.ariaLabel,
												className: `${quick_search_module_default.suggestionItem} ${isActive ? quick_search_module_default.suggestionItemActive : ""}`,
												initial: { opacity: 0 },
												animate: { opacity: 1 },
												exit: { opacity: 0 },
												transition: {
													duration: .12,
													exit: { duration: 0 },
													layout: {
														duration: .15,
														ease: "easeOut"
													}
												},
												onClick: () => {
													if (suggestion_0.action === "autocomplete") {
														if (suggestion_0.insertValue !== void 0) {
															setQuery(suggestion_0.insertValue);
															deferFocusSearchInput();
														}
													} else {
														if (suggestion_0.action === "search") saveRecentSearch(suggestion_0.searchQuery ?? suggestion_0.displayName);
														if (suggestion_0.href) window.location.assign(suggestion_0.href);
														handleClose();
													}
												},
												children: suggestion_0.action === "autocomplete" ? /* @__PURE__ */ jsxs("button", {
													type: "button",
													className: `${quick_search_module_default.suggestionLink} ${quick_search_module_default.suggestionButton}`,
													tabIndex: -1,
													children: [
														/* @__PURE__ */ jsx(SuggestionLeadingVisual, { suggestion: suggestion_0 }),
														/* @__PURE__ */ jsx("span", {
															className: quick_search_module_default.suggestionName,
															children: suggestion_0.displayName
														}),
														getActionLabel(suggestion_0) && /* @__PURE__ */ jsx("span", {
															className: quick_search_module_default.actionLabel,
															children: getActionLabel(suggestion_0)
														})
													]
												}) : /* @__PURE__ */ jsxs("a", {
													href: suggestion_0.href,
													className: quick_search_module_default.suggestionLink,
													tabIndex: -1,
													onClick: (e_0) => e_0.preventDefault(),
													children: [
														/* @__PURE__ */ jsx(SuggestionLeadingVisual, { suggestion: suggestion_0 }),
														/* @__PURE__ */ jsx("span", {
															className: quick_search_module_default.suggestionName,
															children: suggestion_0.displayName
														}),
														getActionLabel(suggestion_0) && /* @__PURE__ */ jsx("span", {
															className: quick_search_module_default.actionLabel,
															children: getActionLabel(suggestion_0)
														})
													]
												})
											}, suggestion_0.id);
										})
									})
								})]
							}, `group-${group.label}`))
						})
					}),
					showSkeletons && /* @__PURE__ */ jsx(SuggestionSkeletons, {}),
					!showSkeletons && footerLinks && /* @__PURE__ */ jsxs("div", {
						className: quick_search_module_default.footer,
						children: [footerLinks.searchSyntaxTips ? /* @__PURE__ */ jsx("a", {
							href: footerLinks.searchSyntaxTips,
							className: quick_search_module_default.footerLink,
							children: "Search syntax tips"
						}) : /* @__PURE__ */ jsx("span", {}), footerLinks.feedback && /* @__PURE__ */ jsx("a", {
							href: footerLinks.feedback,
							className: quick_search_module_default.footerLink,
							children: "Give feedback"
						})]
					})
				]
			})
		})
	});
}
QuickSearch.displayName = "QuickSearch";
export { QuickSearch, preloadQuickSearch };
