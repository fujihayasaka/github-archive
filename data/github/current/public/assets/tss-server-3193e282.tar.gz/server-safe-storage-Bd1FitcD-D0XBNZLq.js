import { a as ssrSafeWindow, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled, n as IS_SERVER, o as wasServerRendered } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { n as throttle } from "./server-dist-CJwx2KGE.js";
import memoize from "@github/memoize";
import { isbot } from "isbot";
var SOFT_NAV_STATE = Object.freeze({
	INITIAL: "soft-nav:initial",
	START: "soft-nav:start",
	REPLACE_MECHANISM: "soft-nav:replace-mechanism",
	SUCCESS: "soft-nav:success",
	ERROR: "soft-nav:error",
	FRAME_UPDATE: "soft-nav:frame-update",
	END: "soft-nav:end",
	RENDER: "soft-nav:render",
	REACT_DONE: "soft-nav:react-done",
	PROGRESS_BAR: {
		START: "soft-nav:progress-bar:start",
		END: "soft-nav:progress-bar:end"
	}
});
var ready = (function() {
	if (ssrSafeDocument?.readyState === "interactive" || ssrSafeDocument?.readyState === "complete") return Promise.resolve();
	else return new Promise((resolve) => {
		ssrSafeDocument?.addEventListener("DOMContentLoaded", () => {
			resolve();
		});
	});
})();
var loaded = (function() {
	if (ssrSafeDocument?.readyState === "complete") return Promise.resolve();
	else return new Promise((resolve) => {
		ssrSafeWindow?.addEventListener("load", resolve);
	});
})();
var runtimeEnvironment = memoize(githubEnvironment);
function githubEnvironment() {
	return ssrSafeDocument?.head?.querySelector("meta[name=\"runtime-environment\"]")?.content || "";
}
var isEnterprise = memoize(isEnterpriseEnvironment);
function isEnterpriseEnvironment() {
	return runtimeEnvironment() === "enterprise";
}
var bundler = "vite-tss";
var isUIService = bundler === "vite-tss";
var SYNTHETIC_PERF_UA_REGEX = /GitHubSyntheticPerf/i;
var _isSyntheticPerfTest;
/**
* Detects if the current session is a GitHub synthetic performance test.
* Requires BOTH conditions to prevent spoofing from regular browsers:
*   1. `navigator.webdriver === true` — only set by real automation frameworks
*   2. User-agent contains 'GitHubSyntheticPerf' — our specific benchmark signature
*
* The actual `<meta name="synthetic-test">` injection is handled by
* `web-vitals/setup.ts` — this function only performs detection.
*
* Feature flag: synthetic_perf_vitals (kill switch — disable to stop bypass)
*/
function isSyntheticPerfTest() {
	if (_isSyntheticPerfTest !== void 0) return _isSyntheticPerfTest;
	if (typeof navigator === "undefined") _isSyntheticPerfTest = false;
	else if (!isFeatureEnabled("synthetic_perf_vitals")) _isSyntheticPerfTest = false;
	else _isSyntheticPerfTest = navigator.webdriver === true && SYNTHETIC_PERF_UA_REGEX.test(navigator.userAgent);
	return _isSyntheticPerfTest;
}
var _isAutomatedBrowser;
/**
* Detects if the current browser is automated (bot, crawler, or testing framework).
*/
function isAutomatedBrowser$1() {
	if (_isAutomatedBrowser !== void 0) return _isAutomatedBrowser;
	if (typeof navigator === "undefined") {
		_isAutomatedBrowser = false;
		return _isAutomatedBrowser;
	}
	_isAutomatedBrowser = navigator.webdriver || isbot(navigator.userAgent);
	return _isAutomatedBrowser;
}
var CUSTOM_METRIC_REGISTRY = {
	PRS_COMMENT_BOX_INP: {
		name: "pull_requests.comment_box.inp",
		hash: "070a85f091c124d118031ed374badf58df0cd9c2902f9aa4f9e09f6fdcbb91d0",
		type: "distribution"
	},
	PULL_REQUESTS_FILES_JS_HEAP: {
		name: "pull_requests.files.js_heap",
		hash: "7c5d986de8ccbfd17ae58e0da85158912cf65aeb256aecf28c35ddeb794cd2d3",
		type: "distribution"
	},
	PRS_ADD_COMMENT_BUTTON_CLICK: {
		name: "pull_requests.add_comment_button.inp",
		hash: "872209fcee2ac679a3222260dbc7eb24c73ec3d6b41e635aaf761e61a5c26ccf",
		type: "distribution"
	},
	PULL_REQUESTS_FILE_TREE_DIFF_FILE_CLICK: {
		name: "pull_requests.file_tree_diff_file_click.inp",
		hash: "876809d762329dac08e4e44288005e102b33e6adebbc46e6f0a115bba2b8aa5e",
		type: "distribution"
	},
	PULL_REQUESTS_FILE_TREE_DIFF_FILE_KEYBOARD_SELECTION: {
		name: "pull_requests.file_tree_diff_file_keyboard_selection.inp",
		hash: "24f3088df0d2fcde21ee1c271b6c3d10a9e819afc581e7740bc6c79a3bec925a",
		type: "distribution"
	},
	PULL_REQUESTS_DIFF_LINE_NUMBER_CLICK: {
		name: "pull_requests.diff_line_number_click.inp",
		hash: "df84c70a71715d434bc8784f6f9f6d53c94ed0ab9e4992aa8d4fed0f94b64ec3",
		type: "distribution"
	},
	BROWSER_MEMORY_DIST_HEAP_USED: {
		name: "browser.memory.dist.heap_used",
		hash: "fdb6e6ee4c8789822429ad902990d5750938634f17838370c79e1abd14875d86",
		type: "distribution"
	},
	BROWSER_MEMORY_DIST_HEAP_UTILIZATION: {
		name: "browser.memory.dist.heap_utilization",
		hash: "962a4cd9cec8fd04bfe4c49e90f70725e6c3c8cbe2c23f7c96be44d9e99fe090",
		type: "distribution"
	},
	BROWSER_MEMORY_DIST_SESSION_GROWTH: {
		name: "browser.memory.dist.session_growth",
		hash: "bcc4dcdd2464d0a48e1478928740dfb341ca58d509cdd87d6405e97db3518988",
		type: "distribution"
	},
	BROWSER_MEMORY_DIST_SESSION_MAX: {
		name: "browser.memory.dist.session_max",
		hash: "c61522ce6a8197750684b38d43bd495f8c8208ff945f274743711f47f577079a",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_APP_ACTUAL_DURATION: {
		name: "browser.react.profiler.app.actual_duration",
		hash: "0c82ee3933bf3b484f6aaa3e9ff4b53c7281e23747d3aa23d1c2967073dc989a",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_APP_BASE_DURATION: {
		name: "browser.react.profiler.app.base_duration",
		hash: "71c768070b707947eebff7086f64b92d0a07dc4149e7d4e05a0641c4dad6bb63",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_APP_COMMIT_LAG: {
		name: "browser.react.profiler.app.commit_lag",
		hash: "1640ce88b596f4bd472a0920aab28fc3a19fa159ce73e24d85749412068c8057",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_ROUTE_ACTUAL_DURATION: {
		name: "browser.react.profiler.route.actual_duration",
		hash: "20a2fd38da8dc5afa74167e694d394c91fbed208c2cf002872f11550cd35fbab",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_ROUTE_BASE_DURATION: {
		name: "browser.react.profiler.route.base_duration",
		hash: "1a0cc657855391adcd36b98829d0c83991b8eef57c93564bf9bf1a1ee0f7036c",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_ROUTE_COMMIT_LAG: {
		name: "browser.react.profiler.route.commit_lag",
		hash: "1bb160294f50714704b572b8cf928a2401845250032d0983d7938278f382737f",
		type: "distribution"
	},
	BROWSER_REACT_HYDRATION_DURATION: {
		name: "browser.react.hydration.duration",
		hash: "82c79908e1a129f357f84b61e17741c540b1b31979f0162318250ef2449646fe",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_ROUTE_RENDER_EFFICIENCY: {
		name: "browser.react.profiler.route.render_efficiency",
		hash: "beef377799cdd79641899e0a78b2c5002494e02ebe125eb0c0d3920eb8623a1e",
		type: "distribution"
	},
	BROWSER_REACT_PROFILER_APP_RENDER_EFFICIENCY: {
		name: "browser.react.profiler.app.render_efficiency",
		hash: "b22af24d9571ad02d8dc59c8778fee9505bcd909d5558dd5243521d2b4796a1d",
		type: "distribution"
	},
	BROWSER_VITALS_DIST_INP_INPUT_DELAY: {
		name: "browser.vitals.dist.inp.input_delay",
		hash: "f8b3556c61cefdd20a76119f6d07eda34630fe54e3ba3f39606ace136d7e375e",
		type: "distribution"
	},
	BROWSER_VITALS_DIST_INP_PROCESSING: {
		name: "browser.vitals.dist.inp.processing",
		hash: "99440bcc187f689ff36aa9ec2e217ad70ee254143b467f4d156c241102d26b28",
		type: "distribution"
	},
	BROWSER_VITALS_DIST_INP_PRESENTATION: {
		name: "browser.vitals.dist.inp.presentation",
		hash: "5cae05a9e69973623a8cfd82f64689b017be8c1d04c9bf873960767c246f1247",
		type: "distribution"
	},
	ISSUES_SHOW_HPC: {
		name: "issues.show.hpc",
		hash: "c759e7a27c38442130f055911b544bce97789db5b8b390f57d35386f6f234b7f",
		type: "distribution"
	},
	BROWSER_VITALS_SUPPRESSED: {
		name: "browser.vitals.suppressed",
		hash: "537aa3499772d75ec67b59e3e5a6065af1212ecfe594c522939d0fa02147fb1b",
		type: "count"
	},
	BROWSER_VITALS_SESSION: {
		name: "browser.vitals.session",
		hash: "467ac7d28cdbf4c8a7c33ccc8dd1986b474115bb57db3f0504b490d3e30455e3",
		type: "count"
	},
	LANDING_PAGES_VITALS_HPC: {
		name: "landing_pages.vitals.hpc",
		hash: "104639e052e30bca541c4acbc2374b70c80ab5de8571a20254a0f61e04180f11",
		type: "distribution"
	},
	LANDING_PAGES_VITALS_CLS: {
		name: "landing_pages.vitals.cls",
		hash: "ee1b16995cee9f07c6cc0e26d6408cea02baface4b562d934394311ac22559cd",
		type: "distribution"
	},
	LANDING_PAGES_VITALS_LCP: {
		name: "landing_pages.vitals.lcp",
		hash: "24f158c0b36f58a0edcb60eab9b0477f3b635f67bd5202e65e80bb17982a8b00",
		type: "distribution"
	},
	LANDING_PAGES_VITALS_INP: {
		name: "landing_pages.vitals.inp",
		hash: "203b2f53cf07984b95d893c21fb643bff3e494eeec63360d9d4189340e7c5fd6",
		type: "distribution"
	},
	TURBO_ERROR_RESPONSE_NOT_HTML: {
		name: "turbo.error.response.not_html",
		hash: "f1b17addcb274c9155f3bb858bfbc8a43e80f718ed0df653e355d0d57c188517",
		type: "increment"
	},
	CODE_VIEW_REPO_OVERVIEW_HPC: {
		name: "code-view.repo-overview.hpc",
		hash: "cd3bc78d2aece4879ae103bd22362fd031ea7144e2658d3a5bc7f475819dfdea",
		type: "distribution"
	},
	CODE_VIEW_TREE_HPC: {
		name: "code-view.tree.hpc",
		hash: "f22a7626ef638ad3492f13c84a79ae4fe199006ca0729b4d189e25a78c67b0f2",
		type: "distribution"
	},
	CODE_VIEW_TREE_INP: {
		name: "code_view.tree.inp",
		hash: "bcb586ccdc889f22fa01ec8b6090373b03b39f1bea96a17f6684c6df573d3ebb",
		type: "distribution"
	},
	CODE_VIEW_REPO_OVERVIEW_INP: {
		name: "code_view.repo_overview.inp",
		hash: "677d3d81e569656264d5e628a09d0217bbc7652befb675bd11bbaf64e340e2c2",
		type: "distribution"
	},
	BROWSER_VITALS_COUNT_RAGE_CLICK: {
		name: "browser.vitals.count.rage_click",
		hash: "6ff467b20e178da44592fcb783e3840254df979c1f37ea6020ec85e50cecd76e",
		type: "count"
	},
	BROWSER_VITALS_COUNT_DEAD_CLICK: {
		name: "browser.vitals.count.dead_click",
		hash: "831d247836ee640be6cae794e527741c02fed8ac0eb70ce358e9d83a4cf73774",
		type: "count"
	},
	BROWSER_VITALS_COUNT_ERROR_CLICK: {
		name: "browser.vitals.count.error_click",
		hash: "d3eaba67324c0c92c2665a3de5f7932c5d2a64d8e0e6a09259bac8518bfd4c1e",
		type: "count"
	},
	BROWSER_VITALS_DIST_TYPING_AVG_INPUT_DELAY: {
		name: "browser.vitals.dist.typing.avg_input_delay",
		hash: "324ec3b8bbe07371113cfe81f76e79c94d13bba651c3e6f0e6f01445d040411d",
		type: "distribution"
	},
	BROWSER_VITALS_DIST_TYPING_MAX_INPUT_DELAY: {
		name: "browser.vitals.dist.typing.max_input_delay",
		hash: "197e0245622487316d8958889da4666fb3c4b10a86aa7240c6aa902f12766d51",
		type: "distribution"
	},
	BROWSER_VITALS_DIST_TYPING_TOTAL_INPUT_DELAY: {
		name: "browser.vitals.dist.typing.total_input_delay",
		hash: "37451a318e75d9a7d87bc0da6a0691a6313b67c74c98216a4d9faa4fb2c42ab3",
		type: "distribution"
	},
	BROWSER_VITALS_ICV: {
		name: "browser.vitals.icv",
		hash: "1cc9ea5c3ce983ede65ce4ed243fef0dd4da584bc8058eb0ea8912e3c74e47cf",
		type: "distribution"
	},
	COPILOT_DOTCOM_CHAT_FIRST_MESSAGE_SENT: {
		name: "copilot.dotcom_chat.first_message_sent",
		hash: "38290751a89248e85e91b29b3917953b9cd55c23f3fab0fa04c5f9bd4191bbf0",
		type: "count"
	},
	COPILOT_DOTCOM_CHAT_FIRST_MESSAGE_RENDERED: {
		name: "copilot.dotcom_chat.first_message_rendered",
		hash: "bc8fb91e82598ab9d25e085b42656ed707a55358acd8343ceb3644ac2e4695d2",
		type: "count"
	}
};
function getCurrentReactAppName() {
	if (ssrSafeDocument?.querySelector("projects-v2")) return "memex";
	if (ssrSafeDocument?.querySelector("react-partial[partial-name=\"repos-overview\"]")) return "repos-overview";
	return ssrSafeDocument?.querySelector("react-app")?.getAttribute("app-name");
}
var STATS_BADGE_STYLE = "background: #1f6feb; color: #fff; padding: 2px 6px; border-radius: 3px; font-weight: bold; font-size: 11px;";
var LABEL_STYLE = "font-weight: bold; font-size: 12px;";
function formatDuration(ms) {
	if (ms === void 0 || ms === null) return "—";
	const rounded = Math.round(ms);
	if (rounded < 1e3) return `${rounded}ms`;
	return `${(rounded / 1e3).toFixed(2)}s`;
}
function durationStyle(ms) {
	if (ms < 200) return "color: #3fb950; font-weight: bold; font-size: 12px;";
	if (ms < 1e3) return "color: #d29922; font-weight: bold; font-size: 12px;";
	return "color: #f85149; font-weight: bold; font-size: 12px;";
}
/**
* Log a sendStats call with a styled collapsed console group.
*/
function logSendStats(stat) {
	const { category, summary } = getStatSummary(stat);
	console.groupCollapsed(`%cstat%c ${category}${summary ? ` ${summary}` : ""}`, STATS_BADGE_STYLE, LABEL_STYLE);
	if (stat.webVitalTimings?.length) for (const timing of stat.webVitalTimings) {
		const vitalName = timing.lcp !== void 0 ? "LCP" : timing.fcp !== void 0 ? "FCP" : timing.ttfb !== void 0 ? "TTFB" : timing.cls !== void 0 ? "CLS" : timing.inp !== void 0 ? "INP" : timing.hpc !== void 0 ? "HPC" : timing.elementtiming !== void 0 ? "ElementTiming" : "Unknown";
		const value = timing.lcp ?? timing.fcp ?? timing.ttfb ?? timing.cls ?? timing.inp ?? timing.hpc ?? timing.elementtiming ?? 0;
		console.log(`%c${vitalName}: %c${formatDuration(value)}`, LABEL_STYLE, durationStyle(value));
		console.table({
			Name: { value: timing.name ?? "—" },
			CPU: { value: timing.cpu ?? "—" },
			SSR: { value: timing.ssr ?? "—" },
			App: { value: timing.app ?? stat.app ?? "—" },
			Soft: { value: timing.soft !== void 0 ? String(timing.soft) : "—" },
			Mechanism: { value: timing.mechanism ?? "—" },
			"DOM Nodes": { value: timing.domNodes ?? "—" },
			Synthetic: { value: timing.synthetic ? "yes" : "no" },
			...timing.inpInteractionType ? {
				"INP Interaction": { value: timing.inpInteractionType },
				"INP Event": { value: timing.inpEventType ?? "—" },
				"INP Bottleneck": { value: timing.inpBottleneck ?? "—" }
			} : {},
			...timing.lcpBreakdown ? {
				"LCP TTFB": { value: formatDuration(timing.lcpBreakdown.ttfb) },
				"LCP FCP": { value: formatDuration(timing.lcpBreakdown.fcp) },
				"LCP Element Render Delay": { value: formatDuration(timing.lcpBreakdown.elementRenderDelay) }
			} : {}
		});
	}
	if (stat.navigationTimings?.length) console.table(stat.navigationTimings.map((t) => ({
		Name: t.name,
		Duration: formatDuration(t.duration),
		"DOM Interactive": formatDuration(t.domInteractive),
		"DOM Complete": formatDuration(t.domComplete),
		"Load Event": formatDuration(t.loadEventEnd),
		Type: t.type ?? "—"
	})));
	if (stat.resourceTimings?.length) console.table(stat.resourceTimings.map((t) => ({
		Name: t.name,
		Duration: formatDuration(t.duration),
		Type: t.initiatorType ?? "—",
		Size: t.transferSize ?? "—"
	})));
	if (stat.longAnimationFrames?.length) console.table(stat.longAnimationFrames.map((t) => ({
		Name: t.name,
		Duration: formatDuration(t.duration),
		"Blocking Duration": formatDuration(t.blockingDuration)
	})));
	if (stat.longTasks?.length) console.table(stat.longTasks.map((t) => ({
		Name: t.name,
		Duration: formatDuration(t.duration)
	})));
	if (stat.customMetric) console.table({
		Name: { value: stat.customMetric.name },
		Value: { value: stat.customMetric.value },
		Type: { value: stat.customMetric.type ?? "—" },
		...stat.customMetric.tags ? Object.fromEntries(Object.entries(stat.customMetric.tags).map(([k, v]) => [k, { value: v }])) : {}
	});
	if (stat.incrementKey) console.table({
		Key: { value: stat.incrementKey },
		...stat.incrementTags ? Object.fromEntries(Object.entries(stat.incrementTags).map(([k, v]) => [k, { value: v }])) : {}
	});
	if (stat.distributionKey) console.table({
		Key: { value: stat.distributionKey },
		Value: { value: stat.distributionValue ?? "—" },
		...stat.distributionTags ? Object.fromEntries(stat.distributionTags.map((t) => [t, { value: t }])) : {}
	});
	console.groupEnd();
}
function getStatSummary(stat) {
	if (stat.webVitalTimings?.length) return {
		category: "webVitalTimings",
		summary: ""
	};
	if (stat.navigationTimings?.length) return {
		category: "navigationTimings",
		summary: ""
	};
	if (stat.resourceTimings?.length) return {
		category: `resourceTimings (${stat.resourceTimings.length})`,
		summary: ""
	};
	if (stat.longAnimationFrames?.length) return {
		category: "longAnimationFrames",
		summary: ""
	};
	if (stat.longTasks?.length) return {
		category: "longTasks",
		summary: ""
	};
	if (stat.customMetric) return {
		category: `customMetric:${stat.customMetric.name}`,
		summary: String(Math.round(stat.customMetric.value))
	};
	if (stat.incrementKey) return {
		category: `increment:${stat.incrementKey}`,
		summary: ""
	};
	if (stat.distributionKey) return {
		category: `distribution:${stat.distributionKey}`,
		summary: stat.distributionValue !== void 0 ? String(Math.round(stat.distributionValue)) : ""
	};
	return {
		category: "stat",
		summary: ""
	};
}
var _automatedSession;
var _sessionSampledForDatadog;
/**
* Detects if the current browser is automated (bot, crawler, or testing framework).
* Automated browsers produce non-representative metrics.
*
* Feature flag: suppress_automated_browser_vitals
*/
function isAutomatedBrowser() {
	if (!isFeatureEnabled("suppress_automated_browser_vitals")) return false;
	return isAutomatedBrowser$1();
}
function isAutomatedSession() {
	if (_automatedSession === void 0) _automatedSession = isAutomatedBrowser();
	return _automatedSession;
}
function isSessionSampledForDatadog() {
	if (_sessionSampledForDatadog === void 0) if (isSyntheticPerfTest()) _sessionSampledForDatadog = true;
	else _sessionSampledForDatadog = !isAutomatedSession() && (isStaff() || Math.random() < .5);
	return _sessionSampledForDatadog;
}
var stats = [];
var chunkSize = 64 * 1024;
function currentReactAppName(override) {
	return override || getCurrentReactAppName() || "rails";
}
var appName = currentReactAppName();
var renderIsSSR = wasServerRendered();
ssrSafeDocument?.addEventListener(SOFT_NAV_STATE.RENDER, () => {
	appName = currentReactAppName();
	renderIsSSR = wasServerRendered();
});
function sendCustomMetric({ name, value, tags, requestUrl }, flushImmediately, samplingProbability) {
	const customMetric = CUSTOM_METRIC_REGISTRY[name];
	sendStats({
		requestUrl,
		customMetric: {
			...customMetric,
			value,
			tags
		},
		ui: true
	}, flushImmediately, samplingProbability);
}
function sendStats(stat, flushImmediately = false, samplingProbability) {
	if (IS_SERVER || isFeatureEnabled("browser_stats_disabled") === true) return;
	const effectiveProbability = samplingProbability ?? (isSessionSampledForDatadog() ? 1 : 0);
	if (effectiveProbability < 0 || effectiveProbability > 1) throw new RangeError("Sampling probability must be between 0 and 1");
	if (stat.timestamp === void 0) stat.timestamp = Date.now();
	stat.loggedIn = isLoggedIn();
	stat.staff = isStaff();
	stat.bundler = bundler;
	stat.ui = true;
	stat.app = appName;
	stat.ssr = String(renderIsSSR);
	if (isDevLoggerEnabled()) logSendStats(stat);
	if (Math.random() < effectiveProbability) stats.push(stat);
	if (flushImmediately) flushStats();
	else throttledScheduleSendStats();
}
var queued = null;
var throttledScheduleSendStats = throttle(async function scheduleSendStats() {
	await loaded;
	if (queued == null) queued = window.requestIdleCallback(flushStats);
}, 5e3);
function flushStats() {
	queued = null;
	if (!stats.length) return;
	const url = ssrSafeDocument?.head?.querySelector("meta[name=\"browser-stats-url\"]")?.content;
	if (!url) return;
	const batches = getBatches(stats);
	for (const batch of batches) safeSend(url, `{"stats": [${batch.join(",")}], "target": "${getUITarget()}"}`);
	stats = [];
}
function getBatches(items) {
	const batches = [];
	const itemStrings = items.map((item) => JSON.stringify(item));
	while (itemStrings.length > 0) batches.push(makeBatch(itemStrings));
	return batches;
}
function makeBatch(itemStrings) {
	const firstItem = itemStrings.shift();
	const batch = [firstItem];
	let size = firstItem.length;
	while (itemStrings.length > 0 && size <= chunkSize) {
		const nextItemSize = itemStrings[0].length;
		if (size + nextItemSize <= chunkSize) {
			const itemString = itemStrings.shift();
			batch.push(itemString);
			size += nextItemSize;
		} else break;
	}
	return batch;
}
function safeSend(url, data) {
	try {
		if (navigator.sendBeacon) navigator.sendBeacon(url, data);
	} catch {}
}
function isStaff() {
	return !!ssrSafeDocument?.head?.querySelector("meta[name=\"user-staff\"]")?.content;
}
function getUITarget() {
	return ssrSafeDocument?.head?.querySelector("meta[name=\"ui-target\"]")?.content || "full";
}
function isDevLoggerEnabled() {
	try {
		return globalThis.localStorage?.getItem("stats-dev-logger") === "true";
	} catch {
		return false;
	}
}
ssrSafeDocument?.addEventListener("pagehide", flushStats);
ssrSafeDocument?.addEventListener("visibilitychange", flushStats);
/**
* An implementation of the Storage API that throws away all data.  Used in
* cases when the requested Storage backend is not available.
*/
var NoOpStorage = class {
	getItem() {
		return null;
	}
	setItem() {}
	removeItem() {}
	clear() {}
	key() {
		return null;
	}
	get length() {
		return 0;
	}
};
/**
* Safely access Storage items by wrapping a Storage instance
* (localStorage or sessionStorage) with safe versions of its API
* methods.  Callers may opt not to suppress quota errors thrown on
* set in case they rely on recieving them.
*/
function safeStorage(storageKey, options = { throwQuotaErrorsOnSet: false }, global = ssrSafeWindow, deserialize = (value) => value, serialize = (value) => value) {
	let storage;
	try {
		if (!global) throw new Error();
		storage = global[storageKey] || new NoOpStorage();
	} catch {
		storage = new NoOpStorage();
	}
	const { throwQuotaErrorsOnSet } = options;
	function emitStats(key) {
		if (options.sendCacheStats) sendStats({ incrementKey: key });
	}
	/**  Safely get storage item. Returns `null` if the item is older than the provided ttl */
	function getItem(key, now = Date.now()) {
		try {
			const value = storage.getItem(key);
			if (!value) return null;
			const expiryKey = `${key}:expiry`;
			const expiry = Number(storage.getItem(expiryKey));
			if (expiry && now > expiry) {
				removeItem(key);
				removeItem(expiryKey);
				emitStats("SAFE_STORAGE_VALUE_EXPIRED");
				return null;
			} else {
				emitStats("SAFE_STORAGE_VALUE_WITHIN_TTL");
				return deserialize(value);
			}
		} catch {
			return null;
		}
	}
	/**
	* Safely set storage item.
	* If `ttl` is provided, set an expiry time for the item under the key `${key}:expiry`
	* This function will be called
	*/
	function setItem(key, value, now = Date.now()) {
		try {
			storage.setItem(key, serialize(value));
			if (options.ttl) {
				const expiryKey = `${key}:expiry`;
				const expiry = now + options.ttl;
				storage.setItem(expiryKey, expiry.toString());
			}
		} catch (error) {
			if (throwQuotaErrorsOnSet && error instanceof Error && error.message.toLowerCase().includes("quota")) throw error;
		}
	}
	function removeItem(key) {
		try {
			storage.removeItem(key);
			if (options.ttl) {
				const expiryKey = `${key}:expiry`;
				storage.removeItem(expiryKey);
			}
		} catch {}
	}
	function getKeys() {
		return Object.keys(storage);
	}
	return {
		getItem,
		setItem,
		removeItem,
		clear: () => storage.clear(),
		getKeys,
		get length() {
			return storage.length;
		}
	};
}
function jsonSafeStorage(storageBackend) {
	return safeStorage(storageBackend, { throwQuotaErrorsOnSet: false }, ssrSafeWindow, JSON.parse, JSON.stringify);
}
export { isEnterprise as a, jsonSafeStorage as c, sendCustomMetric as d, sendStats as f, isAutomatedBrowser$1 as i, ready as l, bundler as n, isStaff as o, getCurrentReactAppName as r, isUIService as s, SOFT_NAV_STATE as t, safeStorage as u };
