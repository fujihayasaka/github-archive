import { Fr as SingleSelectIcon, T as CalendarIcon, Un as NumberIcon, vi as TypographyIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { c } from "react/compiler-runtime";
var KnownTypes = {
	text: {
		type: "text",
		displayName: "Text",
		icon: TypographyIcon,
		valueField: "textValue"
	},
	single_select: {
		type: "single_select",
		displayName: "Single Select",
		icon: SingleSelectIcon,
		valueField: "singleSelectOptionId"
	},
	date: {
		type: "date",
		displayName: "Date",
		icon: CalendarIcon,
		valueField: "dateValue"
	},
	number: {
		type: "number",
		displayName: "Number",
		icon: NumberIcon,
		valueField: "numberValue"
	}
};
Object.values(KnownTypes);
function getIssueFieldValue(fieldType, value) {
	switch (fieldType) {
		case "text": return { textValue: value };
		case "single_select": return { singleSelectOptionId: value };
		case "date": return { dateValue: value };
		case "number": {
			const number = Number(value);
			return isNaN(number) ? {} : { numberValue: number };
		}
	}
}
function asIssueFieldSelection(issueField) {
	return {
		...issueField,
		dataType: toIssueFieldType(issueField.dataType)
	};
}
function toIssueFieldType(fieldType) {
	switch (fieldType) {
		case "TEXT": return "text";
		case "SINGLE_SELECT": return "single_select";
		case "DATE": return "date";
		case "text": return "text";
		case "single_select": return "single_select";
		case "date": return "date";
		case "number": return "number";
		case "NUMBER": return "number";
		default: throw new Error(`Unsupported field type: ${fieldType}`);
	}
}
var ISSUE_FIELD_SINGLE_SELECT_VALUE_TYPE = "IssueFieldSingleSelectValue";
var ISSUE_FIELD_TEXT_VALUE_TYPE = "IssueFieldTextValue";
var ISSUE_FIELD_DATE_VALUE_TYPE = "IssueFieldDateValue";
var ISSUE_FIELD_NUMBER_VALUE_TYPE = "IssueFieldNumberValue";
function clearFieldValue(node, type) {
	if (!node) return;
	switch (type) {
		case ISSUE_FIELD_SINGLE_SELECT_VALUE_TYPE:
			node.setValue(null, "name");
			node.setValue(null, "color");
			node.setValue(null, "description");
			break;
		case ISSUE_FIELD_DATE_VALUE_TYPE:
		case ISSUE_FIELD_TEXT_VALUE_TYPE:
		case ISSUE_FIELD_NUMBER_VALUE_TYPE:
			node.setValue(null, "value");
			break;
		default: return type;
	}
}
function getFieldTypeOcticon(fieldType) {
	return KnownTypes[fieldType].icon;
}
/**
* Converts an array of pinned issue field nodes from GraphQL to IssueFieldSelection objects.
* Filters out null/undefined nodes
*
* This is used by both issue metadata and issue creation flows to parse
* organization-level and issue-type-level pinned fields.
*
* @param nodes - Array of field nodes from GraphQL (may contain nulls)
* @returns Array of IssueFieldSelection objects, or null if no valid fields
*/
function parsePinnedIssueFields(nodes) {
	if (!nodes || nodes.length === 0) return null;
	const filteredFields = [];
	for (const field of nodes) if (field && field.id && field.name && field.dataType) filteredFields.push(asIssueFieldSelection(field));
	return filteredFields.length > 0 ? filteredFields : null;
}
var useUser = () => {
	const $ = c(2);
	const payload = useAppPayload();
	const currentUser = payload && payload.current_user ? payload.current_user : null;
	let t0;
	if ($[0] !== currentUser) {
		t0 = { currentUser };
		$[0] = currentUser;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
};
export { KnownTypes as a, getFieldTypeOcticon as c, toIssueFieldType as d, useUser as f, ISSUE_FIELD_TEXT_VALUE_TYPE as i, getIssueFieldValue as l, ISSUE_FIELD_NUMBER_VALUE_TYPE as n, asIssueFieldSelection as o, ISSUE_FIELD_SINGLE_SELECT_VALUE_TYPE as r, clearFieldValue as s, ISSUE_FIELD_DATE_VALUE_TYPE as t, parsePinnedIssueFields as u };
