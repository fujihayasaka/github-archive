import { Ai as XCircleFillIcon, Br as SortDescIcon, D as CheckCircleIcon, Dt as FileIcon, E as CheckCircleFillIcon, Gt as GitMergeQueueIcon, H as CodeIcon, Hn as NoteIcon, Ht as GitBranchIcon, Ir as SkipIcon, J as CodespacesIcon, Jt as GitPullRequestIcon, Kt as GitPullRequestClosedIcon, Nn as MilestoneIcon, Qn as PeopleIcon, Qr as StopIcon, Rr as SmileyIcon, Si as UnlockIcon, T as CalendarIcon, Tn as LockIcon, V as ClockIcon, Wn as OrganizationIcon, Wt as GitMergeIcon, X as CommentDiscussionIcon, Z as CommentIcon, c as ArchiveIcon, dn as IssueDraftIcon, er as PersonIcon, f as ArrowSwitchIcon, fn as IssueOpenedIcon, gr as RepoIcon, ii as TagIcon, ir as PlusCircleIcon, jn as MentionIcon, mn as IssueTrackedByIcon, pt as DotFillIcon, qt as GitPullRequestDraftIcon, ri as TableIcon, rr as PlayIcon, s as AppsIcon, un as IssueClosedIcon, v as BlockedIcon, vi as TypographyIcon, zn as NoEntryIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as hasMatch } from "./server-fzy.js-7qhjn37q.js";
import { r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import cloneDeep from "lodash-es/cloneDeep.js";
import memoize from "lodash-es/memoize.js";
var FilterValueType = {
	Key: "key",
	Value: "value",
	NoValue: "",
	HasValue: "*"
};
var AvatarType = {
	User: "user",
	Org: "org",
	Team: "team"
};
var FilterProviderType = {
	Select: "select",
	User: "user",
	Text: "text",
	Date: "date",
	Number: "number",
	DecimalNumber: "decimal",
	Boolean: "boolean",
	RawText: "rawText",
	Unknown: "unknown"
};
var ProviderSupportStatus = {
	Unsupported: "unsupported",
	Supported: "supported",
	Deprecated: "deprecated"
};
var SubmitEvent = {
	SuggestionSelected: "suggestion-selected",
	DialogSubmit: "dialog-submit",
	ExplicitSubmit: "explicit-submit",
	Clear: "clear"
};
var ValidationTypes = {
	EmptyValue: "empty-value",
	InvalidValue: "invalid-value",
	MultiValueUnsupported: "multi-value-unsupported",
	FilterProviderDeprecated: "filter-provider-deprecated",
	FilterProviderUnsupported: "filter-provider-unsupported",
	FilterProviderTopLevel: "filter-provider-top-level",
	UnbalancedQuotations: "unbalanced-quotations",
	UnbalancedParentheses: "unbalanced-parentheses",
	MaxNestedGroups: "max-nested-groups",
	SsoRequired: "sso-required"
};
var BlockType = {
	Filter: "filter",
	Text: "text",
	Space: "space",
	Keyword: "keyword",
	Group: "group",
	UnmatchedOpenParen: "unmatched-open-paren",
	UnmatchedCloseParen: "unmatched-close-paren"
};
var FilterOperator = {
	IsOneOf: "IsOneOf",
	IsNotOneOf: "IsNotOneOf",
	Is: "Is",
	IsNot: "IsNot",
	GreaterThan: "GreaterThan",
	LessThan: "LessThan",
	GreaterThanOrEqualTo: "GreaterThanOrEqualTo",
	LessThanOrEqualTo: "LessThanOrEqualTo",
	EqualTo: "EqualTo",
	Before: "Before",
	After: "After",
	BeforeAndIncluding: "BeforeAndIncluding",
	AfterAndIncluding: "AfterAndIncluding",
	Between: "Between"
};
function getCurrentDate() {
	return (/* @__PURE__ */ new Date()).toLocaleDateString("en-us", {
		year: "numeric",
		month: "long",
		day: "numeric"
	});
}
var TIME_RANGE_VALUES = [
	{
		value: "@today",
		displayName: "Today",
		priority: 1,
		icon: ArrowSwitchIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	},
	{
		value: "@today-1d",
		displayName: "Yesterday",
		priority: 2,
		icon: ArrowSwitchIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	},
	{
		value: ">@today-1w",
		displayName: "Past 7 days",
		priority: 3,
		icon: ArrowSwitchIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	},
	{
		value: ">@today-30d",
		displayName: "Past 30 days",
		priority: 4,
		icon: ArrowSwitchIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	},
	{
		value: ">@today-1y",
		displayName: "Past year",
		priority: 5,
		icon: ArrowSwitchIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	},
	{
		value: () => {
			const now = /* @__PURE__ */ new Date();
			return `${now.getFullYear()}-${`0${now.getMonth() + 1}`.slice(-2)}-${`0${now.getDate()}`.slice(-2)}`;
		},
		displayName: getCurrentDate(),
		priority: 6,
		icon: CalendarIcon
	}
];
var NUMBER_COUNT_VALUE = [
	{
		value: "<10",
		displayName: "Less than 10",
		priority: 1
	},
	{
		value: ">10",
		displayName: "More than 10",
		priority: 2
	},
	{
		value: "10..100",
		displayName: "Between 10 and 100",
		priority: 3
	},
	{
		value: "100",
		displayName: "100",
		priority: 4
	}
];
var INDETERMINANT = "#INDETERMINANT#";
var FILTER_KEYS = {
	archived: {
		displayName: "Archived",
		key: "archived",
		priority: 10,
		icon: ArchiveIcon,
		description: "Specify archived or non-archived items only"
	},
	base: {
		displayName: "Base",
		key: "base",
		priority: 10,
		icon: GitBranchIcon,
		description: "Pull Request base branch"
	},
	closed: {
		displayName: "Closed date",
		key: "closed",
		priority: 10,
		icon: CalendarIcon,
		description: "Closing date"
	},
	comments: {
		displayName: "Comment count",
		key: "comments",
		priority: 10,
		icon: CommentIcon,
		description: "Item comment count"
	},
	created: {
		displayName: "Creation date",
		key: "created",
		priority: 10,
		icon: CalendarIcon,
		description: "Creation date"
	},
	draft: {
		displayName: "Draft",
		key: "draft",
		priority: 10,
		icon: IssueDraftIcon,
		description: "Search for draft items"
	},
	has: {
		key: "has",
		displayName: "Has",
		description: "Filter by items with a specific metadata value",
		priority: 10,
		icon: PlusCircleIcon
	},
	head: {
		displayName: "Head",
		key: "head",
		priority: 10,
		icon: GitBranchIcon,
		description: "Head branch commit sha"
	},
	inBody: {
		displayName: "In body",
		key: "in-body",
		priority: 10,
		icon: NoteIcon,
		description: "Search for text only inside the body of an item"
	},
	inComments: {
		displayName: "In comments",
		key: "in-comments",
		priority: 10,
		icon: CommentDiscussionIcon,
		description: "Search for text only inside the comments of an item"
	},
	interactions: {
		displayName: "Interactions count",
		key: "interactions",
		priority: 10,
		icon: CommentDiscussionIcon,
		description: "Interaction count"
	},
	inTitle: {
		displayName: "In title",
		key: "in-title",
		priority: 10,
		icon: TypographyIcon,
		description: "Search for text only inside the title of an item"
	},
	is: {
		displayName: "Is",
		key: "is",
		icon: AppsIcon,
		description: "Filter only \"issues\", \"pulls\", \"open\", \"closed\", or \"draft\"",
		priority: 3
	},
	in: {
		displayName: "In",
		key: "in",
		priority: 10,
		icon: AppsIcon,
		description: "Limit text search to the title, body, or comments of an item or a combination of them"
	},
	language: {
		displayName: "Language",
		key: "language",
		priority: 10,
		icon: CodeIcon,
		description: "Language"
	},
	linked: {
		displayName: "Linked",
		key: "linked",
		icon: GitPullRequestIcon,
		description: "Items linked to an issue or pull request",
		priority: 10
	},
	memexState: {
		displayName: "State",
		key: "state",
		priority: 3,
		icon: IssueDraftIcon,
		description: "Look for open, closed, or draft issues"
	},
	merged: {
		displayName: "Merge date",
		key: "merged",
		priority: 10,
		icon: CalendarIcon,
		description: "Merge date"
	},
	milestone: {
		displayName: "Milestone",
		key: "milestone",
		priority: 10,
		icon: MilestoneIcon,
		description: "Milestone"
	},
	no: {
		key: "no",
		displayName: "No",
		description: "Filter by items without a specific metadata value",
		priority: 10,
		icon: NoEntryIcon
	},
	parentIssue: {
		displayName: "Parent issue",
		key: "parent-issue",
		priority: 5,
		icon: IssueTrackedByIcon,
		description: "Parent issue"
	},
	prState: {
		displayName: "State",
		key: "state",
		priority: 3,
		icon: IssueDraftIcon,
		description: "State of Pull Requests"
	},
	reactions: {
		displayName: "Reaction count",
		key: "reactions",
		priority: 10,
		icon: SmileyIcon,
		description: "Reactions count"
	},
	reason: {
		displayName: "Closed reason",
		key: "reason",
		priority: 10,
		icon: MentionIcon,
		description: "Filter by item closed reason"
	},
	review: {
		displayName: "Review state",
		key: "review",
		priority: 10,
		icon: GitPullRequestIcon,
		description: "Specify a review state"
	},
	sha: {
		displayName: "Commit SHA",
		key: "sha",
		priority: 10,
		icon: FileIcon,
		description: "Commit SHA"
	},
	sort: {
		displayName: "Sort",
		key: "sort",
		priority: 10,
		icon: SortDescIcon,
		description: "Sort results"
	},
	state: {
		displayName: "State",
		key: "state",
		priority: 3,
		icon: IssueDraftIcon,
		description: "Look for open / closed items"
	},
	status: {
		displayName: "Status",
		key: "status",
		priority: 10,
		icon: IssueDraftIcon,
		description: "Commit status: pending | success | failure"
	},
	team: {
		displayName: "Team",
		key: "team",
		priority: 10,
		icon: PeopleIcon,
		description: "Team name"
	},
	teamReviewRequested: {
		displayName: "Team review requested",
		key: "team-review-requested",
		priority: 10,
		icon: PeopleIcon,
		description: "Review requested from team"
	},
	updated: {
		displayName: "Update date",
		key: "updated",
		priority: 10,
		icon: CalendarIcon,
		description: "Updated date"
	},
	repo: {
		displayName: "Repository",
		key: "repo",
		priority: 1,
		icon: RepoIcon,
		description: "Filter by repository"
	},
	org: {
		displayName: "Organization",
		key: "org",
		aliases: ["organization"],
		priority: 2,
		icon: OrganizationIcon,
		description: "Filter by organization"
	},
	label: {
		displayName: "Label",
		key: "label",
		priority: 3,
		icon: TagIcon,
		description: "Filter by label"
	},
	project: {
		displayName: "Project",
		key: "project",
		priority: 3,
		icon: TableIcon,
		description: "Filter by project"
	},
	blockedBy: {
		displayName: "Blocked by",
		key: "blocked-by",
		priority: 5,
		icon: BlockedIcon,
		description: "Issues blocked by another issue"
	},
	blocking: {
		displayName: "Blocking",
		key: "blocking",
		priority: 5,
		icon: StopIcon,
		description: "Issues blocking another issue"
	}
};
var USER_FILTERS = {
	assignee: {
		displayName: "Assignee",
		key: "assignee",
		icon: PersonIcon,
		description: "The assignee of the item",
		priority: 3
	},
	author: {
		displayName: "Author",
		key: "author",
		icon: PersonIcon,
		description: "The author of the item",
		priority: 3
	},
	commenter: {
		displayName: "Commenter",
		key: "commenter",
		icon: PersonIcon,
		description: "Items commented on by the user",
		priority: 10
	},
	involves: {
		displayName: "Involves",
		key: "involves",
		icon: PersonIcon,
		description: "The user involved in the item",
		priority: 10
	},
	mentions: {
		displayName: "Mentions",
		key: "mentions",
		icon: MentionIcon,
		description: "The user mentioned in the item",
		priority: 10
	},
	reviewedBy: {
		displayName: "Reviewed by",
		key: "reviewed-by",
		icon: PersonIcon,
		description: "Items reviewed by the user",
		priority: 10
	},
	reviewRequested: {
		displayName: "Review requested",
		key: "review-requested",
		icon: PersonIcon,
		description: "Items with review requested for the user",
		priority: 10
	},
	user: {
		displayName: "User",
		key: "user",
		icon: PersonIcon,
		description: "Items in repositories owned by the user",
		priority: 10
	},
	userReviewRequested: {
		displayName: "User review requested",
		key: "user-review-requested",
		icon: MentionIcon,
		description: "Items with review requested for the user explicitly",
		priority: 10
	}
};
Object.values(USER_FILTERS);
var TRUE_FALSE_FILTER_VALUES = [{
	value: "true",
	displayName: "True",
	priority: 1,
	aliases: ["yes"]
}, {
	value: "false",
	displayName: "False",
	priority: 2,
	aliases: ["no"]
}];
var FILTER_VALUES = {
	archived: TRUE_FALSE_FILTER_VALUES,
	closed: TIME_RANGE_VALUES,
	comments: NUMBER_COUNT_VALUE,
	created: TIME_RANGE_VALUES,
	draft: TRUE_FALSE_FILTER_VALUES,
	interactions: NUMBER_COUNT_VALUE,
	is: [{
		value: "issue",
		displayName: "Issue",
		priority: 1,
		icon: IssueOpenedIcon
	}, {
		value: "pr",
		displayName: "Pull Request",
		priority: 2,
		icon: GitPullRequestIcon
	}],
	in: [
		{
			value: "title",
			displayName: "Title",
			priority: 1,
			icon: TypographyIcon
		},
		{
			value: "body",
			displayName: "Body",
			priority: 2,
			icon: NoteIcon
		},
		{
			value: "comments",
			displayName: "Comments",
			priority: 3,
			icon: CommentDiscussionIcon
		}
	],
	linked: [{
		value: "issue",
		displayName: "Issue",
		priority: 1,
		icon: IssueOpenedIcon
	}, {
		value: "pr",
		displayName: "Pull Request",
		priority: 2,
		icon: GitPullRequestIcon
	}],
	sort: [],
	memexState: [
		{
			value: "open",
			displayName: "Open",
			priority: 1,
			icon: IssueOpenedIcon,
			iconColor: "var(--fgColor-success, var(--color-success-fg))"
		},
		{
			value: "closed",
			displayName: "Closed",
			priority: 2,
			icon: IssueClosedIcon,
			iconColor: "var(--fgColor-done, var(--color-done-fg))"
		},
		{
			value: "draft",
			displayName: "Draft",
			priority: 3,
			icon: IssueDraftIcon,
			iconColor: "var(-fgColor-muted, var(--color-neutral-emphasis))"
		}
	],
	merged: TIME_RANGE_VALUES,
	prState: [
		{
			value: "open",
			displayName: "Open",
			icon: GitPullRequestIcon,
			priority: 1,
			iconColor: "var(--fgColor-open, var(--color-open-fg))"
		},
		{
			value: "merged",
			displayName: "Merged",
			icon: GitMergeIcon,
			priority: 2,
			iconColor: "var(--fgColor-done, var(--color-done-fg))"
		},
		{
			value: "draft",
			displayName: "Draft",
			icon: GitPullRequestDraftIcon,
			priority: 3,
			iconColor: "var(--fgColor-draft)"
		},
		{
			value: "closed",
			displayName: "Closed",
			icon: GitPullRequestClosedIcon,
			priority: 4,
			iconColor: "var(--fgColor-closed, var(--color-closed-fg))"
		}
	],
	reactions: NUMBER_COUNT_VALUE,
	reason: [
		{
			value: "completed",
			displayName: "Completed",
			priority: 1,
			icon: CheckCircleIcon,
			iconColor: "var(--fgColor-done, var(--color-done-fg))"
		},
		{
			value: "not-planned",
			displayName: "Not planned",
			priority: 2,
			icon: SkipIcon,
			iconColor: "var(--fgColor-muted, var(--color-neutral-emphasis))"
		},
		{
			value: "duplicate",
			displayName: "Duplicate",
			priority: 3,
			icon: SkipIcon,
			iconColor: "var(--fgColor-muted, var(--color-neutral-emphasis))"
		}
	],
	review: [
		{
			value: "none",
			displayName: "No reviews",
			priority: 1
		},
		{
			value: "required",
			displayName: "Review required",
			priority: 2
		},
		{
			value: "approved",
			displayName: "Approved",
			priority: 3
		},
		{
			value: "changes_requested",
			displayName: "Changes requested",
			priority: 4
		}
	],
	state: [{
		value: "open",
		displayName: "Open",
		priority: 1,
		icon: IssueOpenedIcon,
		iconColor: "var(--fgColor-success, var(--color-success-fg))"
	}, {
		value: "closed",
		displayName: "Closed",
		priority: 2,
		icon: IssueClosedIcon,
		iconColor: "var(--fgColor-done, var(--color-done-fg))"
	}],
	status: [
		{
			value: "pending",
			displayName: "Pending",
			priority: 1,
			icon: DotFillIcon,
			iconColor: "var(--fgColor-attention, var(--color-attention-fg))"
		},
		{
			value: "success",
			displayName: "Success",
			priority: 2,
			icon: CheckCircleFillIcon,
			iconColor: "var(--fgColor-success, var(--color-success-fg))"
		},
		{
			value: "failure",
			displayName: "Failure",
			priority: 3,
			icon: XCircleFillIcon,
			iconColor: "var(--fgColor-danger, var(--color-danger-fg))"
		},
		{
			value: "queued",
			displayName: "Queued",
			priority: 4,
			icon: IssueOpenedIcon,
			iconColor: "var(--fgColor-muted, var(--color-fg-subtle))"
		},
		{
			value: "waiting",
			displayName: "Waiting",
			priority: 4,
			icon: ClockIcon,
			iconColor: "var(--fgColor-muted, var(--color-fg-subtle))"
		},
		{
			value: "cancelled",
			displayName: "Cancelled",
			priority: 4,
			icon: StopIcon,
			iconColor: "var(--fgColor-muted, var(--color-fg-subtle))"
		},
		{
			value: "skipped",
			displayName: "Skipped",
			priority: 4,
			icon: SkipIcon,
			iconColor: "var(--fgColor-muted, var(--color-fg-subtle))"
		}
	],
	updated: TIME_RANGE_VALUES
};
FILTER_KEYS.team, FILTER_KEYS.teamReviewRequested;
var IS_FILTER_PROVIDER_VALUES = {
	action: {
		value: "action",
		displayName: "Action",
		priority: 3,
		icon: PlayIcon
	},
	closed: {
		value: "closed",
		displayName: "Closed",
		priority: 2,
		icon: IssueClosedIcon
	},
	codespace: {
		value: "codespace",
		displayName: "Codespace",
		priority: 3,
		icon: CodespacesIcon
	},
	discussion: {
		value: "discussion",
		displayName: "Discussion",
		priority: 4,
		icon: CommentDiscussionIcon
	},
	draft: {
		value: "draft",
		displayName: "Draft",
		priority: 3,
		icon: GitPullRequestDraftIcon
	},
	issue: {
		value: "issue",
		displayName: "Issue",
		priority: 1,
		icon: IssueOpenedIcon
	},
	locked: {
		value: "locked",
		displayName: "Locked",
		priority: 4,
		icon: LockIcon
	},
	merged: {
		value: "merged",
		displayName: "Merged",
		priority: 3,
		icon: GitMergeIcon
	},
	unmerged: {
		value: "unmerged",
		displayName: "Unmerged",
		priority: 3,
		icon: GitMergeIcon
	},
	open: {
		value: "open",
		displayName: "Open",
		priority: 1,
		icon: IssueOpenedIcon
	},
	pr: {
		value: "pr",
		displayName: "Pull Request",
		priority: 1,
		icon: GitPullRequestIcon
	},
	private: {
		value: "private",
		displayName: "Private",
		priority: 3,
		icon: LockIcon
	},
	public: {
		value: "public",
		displayName: "Public",
		priority: 3,
		icon: UnlockIcon
	},
	repository: {
		value: "repository",
		displayName: "Repository",
		priority: 2,
		icon: RepoIcon
	},
	unlocked: {
		value: "unlocked",
		displayName: "Unlocked",
		priority: 4,
		icon: UnlockIcon
	},
	blocked: {
		value: "blocked",
		displayName: "Blocked",
		priority: 4,
		icon: BlockedIcon
	},
	blocking: {
		value: "blocking",
		displayName: "Blocking",
		priority: 4,
		icon: StopIcon
	},
	queued: {
		value: "queued",
		displayName: "Queued",
		priority: 4,
		icon: GitMergeQueueIcon
	}
};
var IN_FILTER_PROVIDER_VALUES = {
	title: {
		value: "title",
		displayName: "Title",
		priority: 1,
		icon: TypographyIcon
	},
	body: {
		value: "body",
		displayName: "Body",
		priority: 2,
		icon: NoteIcon
	},
	comments: {
		value: "comments",
		displayName: "Comments",
		priority: 3,
		icon: CommentDiscussionIcon
	}
};
var SORT_FILTER_PROVIDER_VALUES = {
	created: [{
		value: "created-desc",
		displayName: "Newest",
		priority: 0,
		aliases: ["created"]
	}, {
		value: "created-asc",
		displayName: "Oldest",
		priority: 1
	}],
	updated: [{
		value: "updated-desc",
		displayName: "Recently updated",
		priority: 2,
		aliases: ["updated"]
	}, {
		value: "updated-asc",
		displayName: "Least recently updated",
		priority: 3
	}],
	comments: [{
		value: "comments-desc",
		displayName: "Most commented",
		priority: 4,
		aliases: [
			"interactions",
			"interactions-desc",
			"comments"
		]
	}, {
		value: "comments-asc",
		displayName: "Least commented",
		priority: 5,
		aliases: ["interactions-asc"]
	}],
	reactions: [{
		value: "reactions-desc",
		displayName: "Most reactions",
		priority: 6,
		aliases: ["reactions"]
	}, {
		value: "reactions-asc",
		displayName: "Least reactions",
		priority: 7
	}],
	"committer-date": [{
		value: "committer-date-desc",
		displayName: "Most recent committer date",
		priority: 8,
		aliases: ["committer-date"]
	}, {
		value: "committer-date-asc",
		displayName: "Least recent committer date",
		priority: 9
	}],
	"author-date": [{
		value: "author-date-desc",
		displayName: "Most recent author date",
		priority: 9,
		aliases: ["author-date"]
	}, {
		value: "author-date-asc",
		displayName: "Least recent author date",
		priority: 9
	}],
	relevance: [{
		value: "relevance",
		displayName: "Best match",
		priority: 10,
		aliases: ["relevance-desc"]
	}]
};
var SORT_REACTIONS_FILTER_PROVIDER_VALUES = [
	{
		value: "reactions-+1",
		displayName: "Most thumbs up (👍) reactions",
		priority: 10,
		aliases: ["reactions-+1-desc"]
	},
	{
		value: "reactions-+1-asc",
		displayName: "Least thumbs up (👍) reactions",
		priority: 10
	},
	{
		value: "reactions--1",
		displayName: "Most thumbs down (👎) reactions",
		priority: 10,
		aliases: ["reactions--1-desc"]
	},
	{
		value: "reactions--1-asc",
		displayName: "Least thumbs down (👎) reactions",
		priority: 10
	},
	{
		value: "reactions-smile",
		displayName: "Most laugh (😄) reactions",
		priority: 10,
		aliases: ["reactions-smile-desc"]
	},
	{
		value: "reactions-smile-asc",
		displayName: "Least laugh (😄) reactions",
		priority: 10
	},
	{
		value: "reactions-thinking_face",
		displayName: "Most confused (😕) reactions",
		priority: 10,
		aliases: ["reactions-thinking_face-desc"]
	},
	{
		value: "reactions-thinking_face-asc",
		displayName: "Least confused (😕) reactions",
		priority: 10
	},
	{
		value: "reactions-tada",
		displayName: "Most tada (🎉) reactions",
		priority: 10,
		aliases: ["reactions-tada-desc"]
	},
	{
		value: "reactions-tada-asc",
		displayName: "Least tada (🎉) reactions",
		priority: 10
	},
	{
		value: "reactions-heart",
		displayName: "Most heart (❤️) reactions",
		priority: 10,
		aliases: ["reactions-heart-desc"]
	},
	{
		value: "reactions-heart-asc",
		displayName: "Least heart (❤️) reactions",
		priority: 10
	},
	{
		value: "reactions-eyes",
		displayName: "Most eyes (👀) reactions",
		priority: 10,
		aliases: ["reactions-eyes-desc"]
	},
	{
		value: "reactions-eyes-asc",
		displayName: "Least eyes (👀) reactions",
		priority: 10
	},
	{
		value: "reactions-rocket",
		displayName: "Most rocket (🚀) reactions",
		priority: 10,
		aliases: ["reactions-rocket-desc"]
	},
	{
		value: "reactions-rocket-asc",
		displayName: "Least rocket (🚀) reactions",
		priority: 10
	}
];
var KEYWORDS = ["AND", "OR"];
var LINKED_FILTER_PROVIDER_VALUES = {
	issue: {
		value: "issue",
		displayName: "Issue",
		priority: 1,
		icon: IssueOpenedIcon
	},
	pr: {
		value: "pr",
		displayName: "Pull Request",
		priority: 2,
		icon: GitPullRequestIcon
	}
};
var TOP_LEVEL_FILTERS = ["sort"];
var DYNAMIC_VALUE_CHARS = ["@"];
var FilterOperators = {
	IsOneOf: "is one of",
	IsNotOneOf: "is not one of",
	Is: "is",
	IsNot: "is not",
	GreaterThan: "greater than",
	LessThan: "less than",
	GreaterThanOrEqualTo: "greater than or equal to",
	LessThanOrEqualTo: "less than or equal to",
	EqualTo: "equal to",
	Before: "before",
	After: "after",
	BeforeAndIncluding: "before and including",
	AfterAndIncluding: "after and including",
	Between: "between"
};
var ValueOperators = [
	FilterOperator.GreaterThan,
	FilterOperator.LessThan,
	FilterOperator.GreaterThanOrEqualTo,
	FilterOperator.LessThanOrEqualTo,
	FilterOperator.Before,
	FilterOperator.After,
	FilterOperator.Between
];
var FilterTypeOperators = {
	select: {
		single: [FilterOperator.Is, FilterOperator.IsNot],
		multi: [FilterOperator.IsOneOf, FilterOperator.IsNotOneOf]
	},
	user: {
		single: [FilterOperator.Is, FilterOperator.IsNot],
		multi: [FilterOperator.IsOneOf, FilterOperator.IsNotOneOf]
	},
	text: {
		single: [FilterOperator.Is, FilterOperator.IsNot],
		multi: [FilterOperator.IsOneOf, FilterOperator.IsNotOneOf]
	},
	date: [
		FilterOperator.Before,
		FilterOperator.After,
		FilterOperator.BeforeAndIncluding,
		FilterOperator.AfterAndIncluding,
		FilterOperator.Between,
		FilterOperator.IsOneOf,
		FilterOperator.IsNotOneOf
	],
	number: [
		FilterOperator.EqualTo,
		FilterOperator.GreaterThan,
		FilterOperator.GreaterThanOrEqualTo,
		FilterOperator.LessThan,
		FilterOperator.LessThanOrEqualTo,
		FilterOperator.Between
	],
	decimal: [
		FilterOperator.EqualTo,
		FilterOperator.GreaterThan,
		FilterOperator.GreaterThanOrEqualTo,
		FilterOperator.LessThan,
		FilterOperator.LessThanOrEqualTo,
		FilterOperator.Between
	],
	boolean: [FilterOperator.Is, FilterOperator.IsNot],
	rawText: [FilterOperator.Is],
	unknown: [FilterOperator.Is, FilterOperator.IsNot]
};
var defaultFilterConfig = {
	filterDelimiter: ":",
	valueDelimiter: ",",
	variant: "full"
};
var defaultFilterProviderOptions = {
	priority: 10,
	renderValueVisual: void 0,
	filterTypes: {
		inclusive: true,
		exclusive: true,
		valueless: true,
		hasValue: true,
		multiKey: true,
		multiValue: true
	},
	support: { status: ProviderSupportStatus.Supported }
};
var defaultFilterSettings = {
	aliasMatching: false,
	disableAdvancedTextFilter: false
};
var Strings = {
	filterInvalid: (number) => `Filter contains ${number} issue${number === 1 ? "" : "s"}:`,
	filterBlockInvalid: (block) => `${block} is invalid`,
	filterValuesUnsupported: (filterName) => `Filter values are not supported for <pre>${filterName}</pre>`,
	filterProviderNotSupported: (filterName) => `Filter '${filterName}' not supported`,
	filterProviderDeprecated: (filterName) => `Filter '${filterName}' is deprecated and will be removed in the future`,
	filterValueEmpty: (provider) => `Empty value for <pre>${provider}</pre>`,
	filterMultiValueFalse: (provider) => `Only one value allowed for <pre>${provider}</pre>`,
	filterInvalidValue: (provider, value) => `Invalid value <pre>${value}</pre> for <pre>${provider}</pre>`,
	filterProviderTopLevel: (provider) => `Filter <pre>${provider}</pre> cannot be used within groups`,
	unbalancedQuotations: "Unbalanced quotation marks",
	unbalancedParentheses: "Unbalanced parentheses",
	maxNestedGroups: `Maximum nested groups of 5 exceeded`,
	advancedFilterDialogCloseConfirmation: {
		title: "Discard changes?",
		content: "You have unsaved changes. Are you sure you want to discard them?",
		cancelButtonContent: "Keep editing",
		confirmButtonContent: "Close and discard"
	},
	filterSsoRequired: (provider, value, orgOrEnterprise) => `Authenticate with ${orgOrEnterprise} to access <pre>${value}</pre> for <pre>${provider}</pre>`,
	exclude: "Exclude",
	dividerValue: "%%DIVIDER%%"
};
var RawTextProvider = {
	type: FilterProviderType.RawText,
	icon: TypographyIcon,
	options: defaultFilterProviderOptions,
	key: "text",
	priority: 5,
	displayName: "Text",
	getSuggestions: () => [],
	validateFilterBlockValues: () => [],
	getValueRowProps: () => ({ text: "" })
};
var capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);
var specialCharacters = [
	" ",
	"(",
	")",
	"\"",
	"'",
	","
];
var doubleQuotedStringRegex = /^"[^"]*"$/gi;
var internalDoubleQuoteRegex = /\\?"/gi;
var escapeString = (str) => {
	if (!str) return str;
	if (specialCharacters.every((char) => str.indexOf(char) < 0)) return str;
	let result = str.trim();
	const exclusive = result.startsWith("-");
	if (exclusive) result = result.substring(1).trim();
	if (doubleQuotedStringRegex.test(result)) result = result.substring(1, result.length - 1);
	result = result.replace(internalDoubleQuoteRegex, "\\\"");
	return `${exclusive ? "-" : ""}"${result}"`;
};
var unescapeString = (str) => {
	if (!str || str.replaceAll("\"", "").length < 1) return str;
	let result = str;
	if (result.startsWith("\"") && str.endsWith("\"")) result = result.substring(1);
	if (result.endsWith("\"") && str.startsWith("\"")) result = result.substring(0, result.length - 1);
	return result;
};
var caseInsensitiveStringCompare = (str1, str2) => {
	return !!str1 && !!str2 && str1.toLocaleLowerCase() === str2.toLocaleLowerCase();
};
var getFilterValueByCaretIndex = (values, caretIndex = -1) => {
	if (caretIndex === null || caretIndex < 0) return getFilterValue(values.at(-1)?.value);
	for (const value of values) if (isBetweenInclusive(caretIndex, value.startIndex, value.endIndex)) return getFilterValue(value.value);
	return null;
};
var getProviderKey = (key) => {
	return key.startsWith("-") ? key.slice(1) : key;
};
var getUniqueReactKey = (context, id, fallback) => {
	return `${context}-${id ?? fallback}`;
};
var getFilterValue = (value) => {
	if (!value) return null;
	if (typeof value === "string") return value;
	return value();
};
var getDefaultValueVisualDescriptors = (value, providerIcon, squareIcon = false) => {
	const visuals = [];
	if (value.avatar?.url) visuals.push({
		kind: "avatar",
		url: value.avatar.url,
		alt: getFilterValue(value.value) ?? "User Avatar",
		square: squareIcon
	});
	if (value.iconColor && !value.icon) visuals.push({
		kind: "color-swatch",
		color: value.iconColor
	});
	if (value.icon) visuals.push({
		kind: "octicon",
		icon: value.icon,
		color: value.iconColor
	});
	if (providerIcon) visuals.push({
		kind: "provider-icon",
		icon: providerIcon
	});
	return visuals.length > 0 ? visuals : null;
};
var getUnescapedFilterValue = (value) => {
	const val = getFilterValue(value);
	return val ? unescapeString(val) : val;
};
var getEscapedFilterValue = (value) => {
	const val = getFilterValue(value);
	return val ? escapeString(val) : val;
};
var promiseTimeout = (ms) => {
	return new Promise((resolve) => setTimeout(resolve, ms));
};
var checkFilterQuerySync = (filterQuery, rawString) => {
	return filterQuery.blocks.map(({ raw }) => raw).join("").trim() === (rawString !== void 0 ? rawString : filterQuery.raw).trim();
};
var isBetweenInclusive = (index, start, end) => {
	return index >= 0 && index >= start && index <= end;
};
var isNestedFilterProvider = (filterProvider) => {
	return filterProvider !== void 0 && filterProvider.filterProviders !== void 0;
};
var isFilterBlock = (filterBlock) => {
	return filterBlock !== void 0 && filterBlock.type === BlockType.Filter && filterBlock.key !== void 0 && filterBlock.value !== void 0;
};
var isIndexedAnyBlock = (filterBlock) => {
	return filterBlock.startIndex !== void 0 && filterBlock.endIndex !== void 0;
};
var isIndexedGroupBlock = (filterBlock) => {
	return filterBlock.type === BlockType.Group && filterBlock.blocks !== void 0 && filterBlock.startIndex !== void 0 && filterBlock.endIndex !== void 0;
};
var isIndexedFilterBlock = (filterBlock) => {
	return isFilterBlock(filterBlock) && isIndexedAnyBlock(filterBlock);
};
var isIndexedTextBlock = (textBlock) => {
	return textBlock.type === BlockType.Text && textBlock.startIndex !== void 0 && textBlock.endIndex !== void 0;
};
var isIndexedUnmatchedOpenParenBlock = (unmatchedOpenParenBlock) => {
	return unmatchedOpenParenBlock.type === BlockType.UnmatchedOpenParen && unmatchedOpenParenBlock.startIndex !== void 0 && unmatchedOpenParenBlock.endIndex !== void 0;
};
var isIndexedUnmatchedCloseParenBlock = (unmatchedCloseParenBlock) => {
	return unmatchedCloseParenBlock.type === BlockType.UnmatchedCloseParen && unmatchedCloseParenBlock.startIndex !== void 0 && unmatchedCloseParenBlock.endIndex !== void 0;
};
var isMutableFilterBlock = (filterBlock) => {
	return filterBlock.type === BlockType.Filter;
};
var isComplexFilterOperator = (operator) => {
	return operator.single !== void 0;
};
var findExistingValueUsage = (filterQuery, key, value) => {
	if (!value) return [];
	return filterQuery.blocks.filter((f) => isFilterBlock(f) && f.provider.key === key && f.value.values.findIndex((v) => v.value === value) > -1);
};
var getAllFilterOperators = (provider) => {
	const operator = FilterTypeOperators[provider?.type ?? FilterProviderType.Unknown];
	const multiValue = provider?.options?.filterTypes.multiValue;
	let operatorList = isComplexFilterOperator(operator) ? operator[multiValue ? "multi" : "single"] : operator;
	if (provider?.options?.filterTypes.inclusive === false) operatorList = operatorList.filter((o) => o !== FilterOperator.Is && o !== FilterOperator.IsOneOf);
	if (provider?.options?.filterTypes.exclusive === false) operatorList = operatorList.filter((o) => o !== FilterOperator.IsNot && o !== FilterOperator.IsNotOneOf);
	return operatorList;
};
var getBlockKey = (provider) => provider.type === FilterProviderType.RawText ? void 0 : {
	value: provider.key,
	valid: true
};
var getFilterOperator = (provider, filterKey, filterValue) => {
	const operators = getAllFilterOperators(provider);
	const multiValue = provider?.options?.filterTypes.multiValue;
	if (operators[0]) {
		if (filterKey?.startsWith("-")) return operators.find((m) => multiValue ? m === FilterOperator.IsNotOneOf : m === FilterOperator.IsNot) ?? operators[0];
		const betweenMatch = filterValue?.includes("..") && filterValue?.indexOf("..") === filterValue?.lastIndexOf("..");
		if (provider?.type === FilterProviderType.Number || provider?.type === FilterProviderType.DecimalNumber) {
			if (betweenMatch) return operators.find((m) => m === FilterOperator.Between) ?? operators[0];
			else if (filterValue?.startsWith("<=")) return operators.find((m) => m === FilterOperator.LessThanOrEqualTo) ?? operators[0];
			else if (filterValue?.startsWith("<")) return operators.find((m) => m === FilterOperator.LessThan) ?? operators[0];
			else if (filterValue?.startsWith(">=")) return operators.find((m) => m === FilterOperator.GreaterThanOrEqualTo) ?? operators[0];
			else if (filterValue?.startsWith(">")) return operators.find((m) => m === FilterOperator.GreaterThan) ?? operators[0];
		} else if (provider?.type === FilterProviderType.Date) {
			if (betweenMatch && filterValue !== "*..*") return operators.find((m) => m === FilterOperator.Between) ?? operators[0];
			else if (filterValue?.startsWith("<=")) return operators.find((m) => m === FilterOperator.BeforeAndIncluding) ?? operators[0];
			else if (filterValue?.startsWith("<")) return operators.find((m) => m === FilterOperator.Before) ?? operators[0];
			else if (filterValue?.startsWith(">=")) return operators.find((m) => m === FilterOperator.AfterAndIncluding) ?? operators[0];
			else if (filterValue?.startsWith(">")) return operators.find((m) => m === FilterOperator.After) ?? operators[0];
		}
		return operators.find((m) => multiValue ? m === FilterOperator.IsOneOf : m === FilterOperator.Is) ?? operators[0];
	}
	return FilterOperator.Is;
};
var buildRawBlockString = (filterBlock, config) => {
	const delimitedKey = filterBlock.key ? `${filterBlock.key.value}:` : "";
	switch (filterBlock.operator) {
		case FilterOperator.IsNot:
		case FilterOperator.IsNotOneOf: return `${delimitedKey.startsWith("-") ? delimitedKey : `-${delimitedKey}`}${filterBlock.value?.values.map((v) => getEscapedFilterValue(v.value)).join(config.valueDelimiter)}`;
		case FilterOperator.Before:
		case FilterOperator.LessThan: return `${delimitedKey}<${filterBlock.value?.raw ?? ""}`;
		case FilterOperator.After:
		case FilterOperator.GreaterThan: return `${delimitedKey}>${!filterBlock.value?.raw ? "" : filterBlock.value?.raw}`;
		case FilterOperator.LessThanOrEqualTo: return `${delimitedKey}<=${!filterBlock.value?.raw ? "" : filterBlock.value?.raw}`;
		case FilterOperator.GreaterThanOrEqualTo: return `${delimitedKey}>=${!filterBlock.value?.raw ? "" : filterBlock.value?.raw}`;
		case FilterOperator.Between: return `${delimitedKey}${getFilterValue(filterBlock.value?.values[0]?.value)}..${getFilterValue(filterBlock.value?.values[1]?.value)}`;
		default: return `${delimitedKey.startsWith("-") ? delimitedKey.substring(1) : delimitedKey}${filterBlock.value?.values.map((v) => getEscapedFilterValue(v.value)).join(config.valueDelimiter)}`;
	}
};
var getHasValueSuggestion = (displayName, icon = PlusCircleIcon, priority = 0) => {
	return {
		displayName: `Has ${displayName.toLocaleLowerCase()}`,
		ariaLabel: `Has ${displayName}, ${displayName}`,
		icon,
		value: "*",
		type: FilterValueType.HasValue,
		priority
	};
};
var getNoValueSuggestion = (displayName, icon = NoEntryIcon, priority = 0) => {
	return {
		displayName: `No ${displayName.toLocaleLowerCase()}`,
		ariaLabel: `No ${displayName}, ${displayName}`,
		icon,
		value: "",
		type: FilterValueType.NoValue,
		priority
	};
};
var getExcludeKeySuggestion = (value) => {
	return {
		displayName: value ? `Exclude ${value.toLocaleLowerCase()}` : "Exclude",
		ariaLabel: value ? `Exclude ${value.toLocaleLowerCase()}` : "Exclude",
		value: value ? `-${value}` : "-",
		type: FilterValueType.Key,
		priority: 1,
		icon: NoEntryIcon
	};
};
var getAndKeySuggestion = () => {
	return {
		ariaLabel: "And",
		value: "AND",
		type: "keyword",
		priority: 1,
		icon: PlusCircleIcon
	};
};
var getOrKeySuggestion = () => {
	return {
		ariaLabel: "Or",
		value: "OR",
		type: "keyword",
		priority: 1,
		icon: SkipIcon
	};
};
var getFlatSuggestionsList = (suggestions) => {
	const flatSuggestions = [];
	for (const suggestion of suggestions) if ("suggestions" in suggestion) flatSuggestions.push(...suggestion.suggestions);
	else flatSuggestions.push(suggestion);
	return flatSuggestions;
};
/**
* Given an array of blocks, returns the blocks in a flattened array. This is useful if you have nested blocks within groups but you want to access properties of all blocks.
*
* @param blocks Array of blocks, including nested groups, that should be flattened
* @returns Array of all blocks, flattened, filtering out `undefined` blocks
*/
var getFlattenedBlocks = (blocks) => {
	const flattenedBlocks = [];
	const stack = [...blocks];
	while (stack.length) {
		const block = stack.pop();
		if (block) {
			flattenedBlocks.push(block);
			if (isIndexedGroupBlock(block)) stack.push(...block.blocks);
		}
	}
	return flattenedBlocks;
};
var getMutableFilterBlocks = (filteredBlocks) => {
	const blocks = [];
	for (let i = 0; i < filteredBlocks.length; i++) {
		const block = filteredBlocks[i];
		if (!block) continue;
		else if (block.type === BlockType.Space) continue;
		else if (block.type === BlockType.Text && filteredBlocks[i - 2]?.type === BlockType.Text) {
			const prevBlock = blocks.pop();
			if (prevBlock) {
				prevBlock.raw += ` ${block.raw}`;
				prevBlock.value = {
					raw: prevBlock.raw,
					values: [{
						value: prevBlock.raw,
						valid: true
					}]
				};
				blocks.push(prevBlock);
			}
		} else if (isMutableFilterBlock(block)) {
			const safeBlock = cloneDeep(block);
			if (safeBlock.operator === FilterOperator.Between) {
				const joinedValue = getFilterValue(safeBlock.value?.values[0]?.value) ?? "";
				const values = joinedValue?.split("..");
				const validity = !!values[0] && values[0] !== "" && !!values[1] && values[1] !== "";
				if (values?.length === 2) safeBlock.value = {
					raw: joinedValue,
					values: [{
						value: values[0] ?? "",
						valid: validity
					}, {
						value: values[1] ?? "",
						valid: validity
					}]
				};
			} else {
				let raw = "";
				safeBlock.value?.values.map((v) => {
					raw += `,${(getFilterValue(v.value) ?? "").replaceAll(/[>|<|>=|<=]/g, "") ?? ""}`;
				});
				raw = raw.slice(1);
				safeBlock.value = {
					values: safeBlock.value?.values ?? [],
					raw
				};
			}
			safeBlock.id = blocks.length;
			blocks.push(safeBlock);
		} else blocks.push({
			type: BlockType.Filter,
			id: blocks.length,
			provider: RawTextProvider,
			raw: block.raw ?? "",
			value: {
				raw: block.raw ?? "",
				values: [{
					value: block.raw ?? "",
					valid: true
				}]
			}
		});
	}
	return blocks;
};
var getLastFilterBlockValue = (filterBlock, caretIndex) => {
	let lastValue;
	if (isIndexedFilterBlock(filterBlock) && filterBlock.value?.values) lastValue = getFilterValueByCaretIndex(filterBlock.value.values, caretIndex) ?? "";
	else if (isFilterBlock(filterBlock) && filterBlock.value?.values) lastValue = getFilterValue(filterBlock.value.values[0]?.value) ?? "";
	else lastValue = filterBlock.raw;
	if (lastValue.startsWith("\"")) lastValue = lastValue.substring(1);
	if (lastValue.endsWith("\"")) lastValue = lastValue.substring(0, lastValue.length - 1);
	return lastValue;
};
var isEmptyFilterBlockValue = (filterBlock) => {
	const filterBlockValues = isFilterBlock(filterBlock) && filterBlock.value?.values ? filterBlock.value.values : [];
	if (filterBlockValues.length > 1) return false;
	return filterBlockValues.length === 1 ? filterBlockValues[0]?.value === "" : true;
};
var shouldProviderShowSuggestions = (filterBlock, isMultiValue = true) => isFilterBlock(filterBlock) && (isMultiValue || filterBlock.value.values.length <= 1);
var getFilterBlockChunkByCaret = (filterBlock, caretIndex) => {
	if (filterBlock.startIndex > caretIndex || filterBlock.endIndex < caretIndex) return [null, null];
	if (isBetweenInclusive(caretIndex, filterBlock.key.startIndex, filterBlock.key.endIndex)) return ["key", filterBlock.key];
	const currentValue = filterBlock.value.values.find((v) => isBetweenInclusive(caretIndex, v.startIndex, v.endIndex));
	return currentValue ? ["value", currentValue] : [null, null];
};
var getFilterValuesByStateType = (type = "mixed") => {
	let values = [];
	if (type === "mixed") {
		const uniqueValues = {};
		for (const value of [
			...FILTER_VALUES.memexState,
			...FILTER_VALUES.state,
			...FILTER_VALUES.prState
		]) {
			const extractedValue = getFilterValue(value.value);
			const { icon, iconColor, ...keepAttrs } = value;
			if (extractedValue && !uniqueValues[extractedValue]) uniqueValues[extractedValue] = { ...keepAttrs };
		}
		values = Object.values(uniqueValues);
	} else if (type === "issues") values = FILTER_VALUES.state;
	else if (type === "memex") values = FILTER_VALUES.memexState;
	else values = FILTER_VALUES.prState;
	return values;
};
function sanitizeOperators(raw) {
	return raw ? raw.replaceAll("<", "&lt;")?.replaceAll(">", "&gt;") : raw;
}
/**
* Given a string, return a map of the indices of balanced opening quotation to the index of its closing quotation
*
* @param queryString The string to search for parentheses
* @returns Map of matched quotations
*/
var findMatchedQuotes = (queryString) => {
	if (queryString.length === 0) return /* @__PURE__ */ new Map();
	let startIndex = 0;
	let index;
	const quoteIndices = [];
	while ((index = queryString.indexOf("\"", startIndex)) > -1) {
		quoteIndices.push(index);
		startIndex = index + 1;
	}
	let openQuote = null;
	const matchedQuotes = /* @__PURE__ */ new Map();
	for (const quoteIndex of quoteIndices) if (openQuote) {
		matchedQuotes.set(openQuote, quoteIndex);
		openQuote = null;
	} else openQuote = quoteIndex;
	return matchedQuotes;
};
var singleFilterProviderOptions = { filterTypes: {
	multiKey: false,
	multiValue: false,
	valueless: false
} };
/**
* Given a filterProvider and a key, return whether the key is a match for the filterProvider
*
* @param filterProvider The filter provider to test against
* @param key The string to check for a match
* @param startsWith Whether to accept startsWith partial matches
* @returns boolean
*/
var isKeyForFilterProvider = (filterProvider, key, startsWith = false) => {
	const isMatch = (providerKey) => {
		if (startsWith) return providerKey.split(".").some((p) => p.toLocaleLowerCase().startsWith(key.toLocaleLowerCase())) || providerKey.toLocaleLowerCase().startsWith(key.toLocaleLowerCase());
		return escapeString(providerKey.toLocaleLowerCase()) === key.toLocaleLowerCase();
	};
	return isMatch(filterProvider.key) || filterProvider.aliases?.some((a) => isMatch(a)) || filterProvider.options?.filterTypes.exclusive && (isMatch(`-${filterProvider.key}`) || filterProvider.aliases?.some((a) => isMatch(`-${a}`))) || false;
};
var FilterQuery = class {
	cachedFilterCount = 0;
	cachedFiltersUsed = [];
	cachedNestedGroupCount = 0;
	config;
	isValidated = false;
	#activeBlock;
	#blocks;
	#staticContext = {};
	#additionalParams = {};
	#errors = [];
	#unFocusedErrors = [];
	#raw;
	constructor(raw = "", blocks = [], config, activeBlock, instanceContext, isValidated = false) {
		this.#blocks = blocks;
		this.#raw = raw;
		this.#activeBlock = activeBlock;
		this.isValidated = isValidated;
		if (instanceContext) {
			this.#staticContext = instanceContext.staticContext;
			this.cachedFilterCount = instanceContext.cachedFilterCount ?? 0;
			this.cachedFiltersUsed = instanceContext.cachedFiltersUsed ?? [];
			this.cachedNestedGroupCount = instanceContext.cachedNestedGroupCount ?? 0;
		}
		this.config = config ?? defaultFilterConfig;
		this.#processErrorBlocks(blocks);
	}
	get activeBlock() {
		return this.#activeBlock;
	}
	get activeBlockId() {
		return this.#activeBlock?.id ?? -1;
	}
	get blocks() {
		return this.#blocks;
	}
	clearActiveBlock() {
		this.#activeBlock = void 0;
	}
	get context() {
		const context = {
			...this.#staticContext ?? {},
			...this.#additionalParams ?? {}
		};
		if (!this.#staticContext?.["repo"]) {
			const repos = this.#blocks.filter((b) => isFilterBlock(b) && b.provider.key === "repo").map((r) => r.value.values.map((v) => v.valid !== false ? getUnescapedFilterValue(v.value) ?? "" : "")).flat();
			if (repos.length > 0) context["repo"] = repos.join(",");
			if (!this.#staticContext?.["org"]) {
				const orgs = this.#blocks.filter((b) => isFilterBlock(b) && b.provider.key === "org").map((r) => r.value.values.map((v) => v.valid !== false ? getUnescapedFilterValue(v.value) ?? "" : "")).flat();
				if (orgs.length > 0) context["org"] = orgs.join(",");
			}
		}
		return context;
	}
	get contextURLParams() {
		return new URLSearchParams(this.context);
	}
	get errors() {
		return this.#errors ? Array.from(this.#errors) : [];
	}
	getErrors(allErrors = false) {
		return !allErrors ? this.#errors : [...this.#errors, ...this.#unFocusedErrors];
	}
	get filterCount() {
		if (!this.isValidated || !checkFilterQuerySync(this)) return this.cachedFilterCount;
		const updatedCount = this.blocks.filter((b) => isFilterBlock(b) && b.value.values.some((v) => v.valid)).length;
		this.cachedFilterCount = updatedCount;
		return updatedCount;
	}
	get filtersUsed() {
		if (!checkFilterQuerySync(this)) return this.cachedFiltersUsed;
		const filters = getFlattenedBlocks(this.blocks).filter((block) => isFilterBlock(block)).map((block) => block.provider?.key);
		this.cachedFiltersUsed = filters;
		return filters;
	}
	get instanceContext() {
		return {
			cachedFilterCount: this.cachedFilterCount,
			cachedFiltersUsed: this.cachedFiltersUsed,
			cachedNestedGroupCount: this.cachedNestedGroupCount,
			staticContext: this.#staticContext
		};
	}
	get nestedGroupCount() {
		if (!checkFilterQuerySync(this)) return this.cachedNestedGroupCount;
		const maxGroupDepth = getFlattenedBlocks(this.blocks).filter((block) => isIndexedGroupBlock(block)).reduce((maxDepth, block) => Math.max(maxDepth, block.groupDepth || 0), 0);
		this.cachedNestedGroupCount = maxGroupDepth;
		return maxGroupDepth;
	}
	get raw() {
		return this.#raw;
	}
	get staticContext() {
		return this.#staticContext;
	}
	set staticContext(staticContext) {
		this.#staticContext = staticContext;
	}
	set additionalParams(params) {
		this.#additionalParams = params;
	}
	addQueryParam(key, value) {
		if (!this.#additionalParams) this.#additionalParams = {};
		this.#additionalParams[key] = value;
	}
	async getSuggestions(caretIndex, filterProviders, filterConfig) {
		const activeBlock = this.activeBlock;
		let aggregatedSuggestionGroups = [];
		/** FIRST CASE: Show recommended providers
		* If there is no active block and the query is empty
		* If the active block is a space
		* If the active block is an unmatched `(`, or within an empty group `()`
		*/
		if (!activeBlock && this.raw === "" || activeBlock?.type === BlockType.Space || activeBlock?.type === BlockType.UnmatchedOpenParen || activeBlock?.type === BlockType.Group && (activeBlock?.raw.endsWith("(") || activeBlock?.raw === "()")) {
			aggregatedSuggestionGroups = [{
				id: "providers-suggestion-group",
				suggestions: Object.values(filterProviders).filter((provider) => {
					return this.#canSuggestProviderPerMultiKey(provider) && provider.options.support.status === ProviderSupportStatus.Supported;
				}).filter((provider) => provider.priority <= 5).sort((a, b) => a.priority - b.priority).map((provider) => ({
					type: FilterValueType.Key,
					displayName: provider.displayName,
					ariaLabel: `${provider.displayName}, Filter${provider.description ? `, ${provider.description}` : ""}`,
					priority: provider.priority,
					icon: provider.icon,
					value: provider.key
				}))
			}];
			const utilitySuggestions = [];
			if (filterConfig.groupAndKeywordSupport) {
				utilitySuggestions.push(getAndKeySuggestion());
				utilitySuggestions.push(getOrKeySuggestion());
			}
			const showExcludeSuggestions = (provider) => {
				return provider.options.filterTypes.exclusive === true && this.#canSuggestProviderPerMultiKey(provider);
			};
			if (Object.values(filterProviders).filter(showExcludeSuggestions).length > 0) utilitySuggestions.push(getExcludeKeySuggestion());
			aggregatedSuggestionGroups.push({
				id: "utility-suggestion-group",
				suggestions: utilitySuggestions
			});
		} else if (activeBlock?.type === BlockType.Text && activeBlock.raw === "-") {
			/** SECOND CASE: Show providers that support exclusions
			* If the active block is a text block and the raw value is a dash (indicating a potential exclusive filter)
			*/
			const providers = Object.values(filterProviders).filter((provider) => {
				return provider.options.filterTypes.exclusive && this.#canSuggestProviderPerMultiKey(provider) && provider.options.support.status === ProviderSupportStatus.Supported;
			}).filter((provider) => provider.priority <= 5).sort((a, b) => a.priority - b.priority).map((provider) => ({
				type: FilterValueType.Key,
				displayName: provider.displayName,
				ariaLabel: `${provider.displayName}, Filter${provider.description ? `, ${provider.description}` : ""}`,
				priority: provider.priority,
				icon: provider.icon,
				value: `-${provider.key}`
			}));
			aggregatedSuggestionGroups = [{
				id: "exclude-providers",
				title: Strings.exclude,
				suggestions: providers
			}];
		} else if (activeBlock?.type === BlockType.Text) {
			/** THIRD CASE: Show filtered providers
			* If the active block is a text block
			*/
			const matches = [];
			const textBlock = isIndexedTextBlock(activeBlock) ? activeBlock : null;
			const matchFilterTo = textBlock && caretIndex - textBlock.startIndex <= textBlock.raw.indexOf(filterConfig.filterDelimiter) ? textBlock.raw.substring(0, caretIndex - textBlock.startIndex) : activeBlock.raw;
			Object.values(filterProviders).map((provider) => {
				/**
				* If the activeBlock raw text partially matches the providers key
				* If the activeBlock raw text partially matches the providers display name, if it's available
				* If alias matching is turned on and it matches one of the provider's aliases
				* If the provider supports exclusive and the raw text partially matches the provider key with a dash
				* If the provider supports exclusive and the raw text partially matches one of the provider's aliases with a dash
				* If the provider supports multikey
				* If the provider doesn't support multikey and there is not already a block with this key in the query
				* If the provider is supported
				*/
				if ((isKeyForFilterProvider(provider, matchFilterTo, true) || provider.displayName && provider.displayName.startsWith(matchFilterTo)) && this.#canSuggestProviderPerMultiKey(provider) && provider.options.support.status === ProviderSupportStatus.Supported) {
					let value = provider.key;
					if (value === matchFilterTo && value.endsWith(".")) return;
					if (activeBlock.raw.startsWith("-") && provider.options.filterTypes.exclusive) value = `-${provider.key}`;
					matches.push({
						type: FilterValueType.Key,
						displayName: provider.displayName,
						ariaLabel: `${provider.displayName}, Filter${provider.description ? `, ${provider.description}` : ""}`,
						priority: provider.priority - fuzzyScore(matchFilterTo, provider.key),
						icon: provider.icon,
						value
					});
				}
			});
			matches.sort((a, b) => a.priority - b.priority);
			aggregatedSuggestionGroups = [{
				id: "providers-suggestion-group",
				suggestions: matches
			}];
			const utilitySuggestions = [];
			if (filterConfig.groupAndKeywordSupport) {
				if ("and".startsWith(matchFilterTo.toLocaleLowerCase())) utilitySuggestions.push(getAndKeySuggestion());
				if ("or".startsWith(matchFilterTo.toLocaleLowerCase())) utilitySuggestions.push(getOrKeySuggestion());
			}
			aggregatedSuggestionGroups.push({
				id: "utility-suggestion-group",
				suggestions: utilitySuggestions
			});
		} else if (isFilterBlock(activeBlock)) {
			let filteredSuggestions = [];
			const filterKey = getProviderKey(activeBlock.key.value);
			if (isIndexedFilterBlock(activeBlock)) {
				const [type, chunk] = getFilterBlockChunkByCaret(activeBlock, caretIndex);
				if (type === "key") {
					const matches = [];
					Object.values(filterProviders).map((provider) => {
						if ((hasMatch(chunk.value, provider.key) || provider.options.filterTypes.exclusive && hasMatch(chunk.value, `-${provider.key}`)) && this.#canSuggestProviderPerMultiKey(provider)) matches.push({
							type: FilterValueType.Key,
							displayName: provider.displayName,
							ariaLabel: `${provider.displayName}, Filter${provider.description ? `, ${provider.description}` : ""}`,
							priority: provider.priority - fuzzyScore(chunk.value, provider.key),
							icon: provider.icon,
							value: provider.key
						});
					});
					matches.sort((a, b) => a.priority - b.priority);
					aggregatedSuggestionGroups = [{
						id: "providers-suggestion-group",
						suggestions: matches
					}];
				} else if (type === "value") filteredSuggestions = (await Object.values(filterProviders).find((p) => isKeyForFilterProvider(p, filterKey))?.getSuggestions(this, activeBlock, filterConfig, caretIndex))?.filter((suggestion) => activeBlock.value.values.findIndex((value) => getUnescapedFilterValue(value.value) === suggestion.value && !value.hasCaret) < 0).sort((a, b) => a.priority - b.priority) ?? [];
			}
			aggregatedSuggestionGroups = [{
				id: "values-suggestion-group",
				suggestions: filteredSuggestions
			}];
		}
		return aggregatedSuggestionGroups;
	}
	#canSuggestProviderPerMultiKey(provider) {
		if (provider.options.filterTypes?.multiKey !== false) return true;
		return this.blocks.filter((block) => isFilterBlock(block) && block.key.value === provider.key).length < 1;
	}
	#processErrorBlocks(blocks) {
		const errorSet = /* @__PURE__ */ new Set();
		const unFocusedErrorSet = /* @__PURE__ */ new Set();
		const processBlocks = (allBlocks) => {
			for (const block of allBlocks) if (isIndexedGroupBlock(block)) {
				if (!block.valid) {
					for (const v of block.validations ?? []) if (v.message) errorSet.add(v.message);
				}
				processBlocks(block.blocks);
			} else if (isFilterBlock(block) && block.valid === false && this.activeBlockId !== block.id) {
				if (block.validationMessage) errorSet.add(block.validationMessage ?? "");
				if (!block.key.valid) {
					for (const v of block.key.validations ?? []) if (v.message) errorSet.add(v.message);
				}
				for (const value of block.value.values) {
					if (value.valid !== false) continue;
					if (value.validations) {
						for (const v of value.validations ?? []) if (v.message) errorSet.add(v.message);
					} else errorSet.add(Strings.filterInvalidValue(block.key.value, sanitizeOperators(getFilterValue(value.value)) ?? ""));
				}
			} else if ((isIndexedUnmatchedOpenParenBlock(block) || isIndexedUnmatchedCloseParenBlock(block)) && block.validations) unFocusedErrorSet.add(Strings.unbalancedParentheses);
			else if (isIndexedTextBlock(block)) {
				for (const v of block.validations ?? []) if (v.message) unFocusedErrorSet.add(v.message);
			}
		};
		if ((this.#raw.match(/"/g) ?? []).length % 2 !== 0) unFocusedErrorSet.add(Strings.unbalancedQuotations);
		processBlocks(blocks);
		this.#errors = Array.from(errorSet);
		this.#unFocusedErrors = Array.from(unFocusedErrorSet);
	}
};
var getLastDelimiterRegex = memoize((valueDelimiter, groupAndKeywordSupport) => {
	const basePattern = `([\\s${valueDelimiter}"]*?)((?:>|<|>=|<=)*[\\w\\d\\-_"'?/\\.=+!@#$%^&*`;
	const specificPattern = groupAndKeywordSupport ? `);:\\p{Extended_Pictographic}]*)$` : `();:\\p{Extended_Pictographic}]*)$`;
	return new RegExp(basePattern + specificPattern, "gu");
});
/**
* Given a string, return an array of blocks that represent the string. A block can be text, space, or group of blocks.
*
* @param queryString The string to generate blocks from
* @param caretIndex The index of the caret in the string
* @param groupAndKeywordSupport Whether or not to support groups and keywords
* @returns An array of blocks that represent the string
*/
function generateBlocksFromQueryString(queryString, groupAndKeywordSupport, caretIndex = -1) {
	const { matchedParens, unmatchedOpenParens, unmatchedCloseParens } = matchOpeningAndClosingParentheses(queryString);
	let currentIndex = 0;
	let currentBlockId = 0;
	let groupDepth = 0;
	/**
	* Recursive function to generate the blocks within a query string
	* and grouping of blocks contained within parentheses
	*
	* @param endIndex The index to stop processing the group at
	*
	**/
	function processGroup(endIndex = queryString.length) {
		const groupBlocks = [];
		const querySubstring = queryString.substring(0, endIndex);
		while (currentIndex < endIndex) if (groupAndKeywordSupport && matchedParens.get(currentIndex) !== void 0) {
			const groupStartIndex = currentIndex;
			const groupEndIndex = matchedParens.get(currentIndex);
			if (groupEndIndex === void 0) {
				currentIndex += 1;
				continue;
			}
			currentIndex += 1;
			groupDepth += 1;
			const isMaxDepth = groupDepth > 5;
			groupBlocks.push({
				id: currentBlockId,
				type: BlockType.Group,
				raw: queryString.substring(groupStartIndex, groupEndIndex + 1),
				blocks: processGroup(groupEndIndex),
				groupDepth,
				startIndex: groupStartIndex,
				endIndex: groupEndIndex,
				hasCaret: isBetweenInclusive(caretIndex, groupStartIndex, groupEndIndex),
				valid: !isMaxDepth,
				validations: isMaxDepth ? [{
					type: ValidationTypes.MaxNestedGroups,
					message: Strings.maxNestedGroups
				}] : []
			});
			groupDepth -= 1;
			currentIndex = groupEndIndex + 1;
		} else if (groupAndKeywordSupport && querySubstring[currentIndex] === "(") {
			groupBlocks.push({
				id: currentBlockId,
				type: BlockType.UnmatchedOpenParen,
				raw: "(",
				startIndex: currentIndex,
				endIndex: currentIndex + 1,
				hasCaret: isBetweenInclusive(caretIndex, currentIndex + 1, currentIndex + 1),
				valid: false,
				validations: [{
					type: ValidationTypes.UnbalancedParentheses,
					message: Strings.unbalancedParentheses
				}]
			});
			currentBlockId += 1;
			currentIndex += 1;
		} else if (groupAndKeywordSupport && querySubstring[currentIndex] === ")") {
			groupBlocks.push({
				id: currentBlockId,
				type: BlockType.UnmatchedCloseParen,
				raw: ")",
				startIndex: currentIndex,
				endIndex: currentIndex + 1,
				hasCaret: isBetweenInclusive(caretIndex, currentIndex + 1, currentIndex + 1),
				valid: false,
				validations: [{
					type: ValidationTypes.UnbalancedParentheses,
					message: Strings.unbalancedParentheses
				}]
			});
			currentBlockId += 1;
			currentIndex += 1;
		} else if (querySubstring[currentIndex]?.search(/\s/) === 0) {
			let spaceBlockContent = querySubstring[currentIndex] ?? "";
			for (let i = currentIndex + 1; i < endIndex; i++) if (querySubstring[i]?.search(/\s/) === 0) spaceBlockContent += querySubstring[i] ?? "";
			else break;
			groupBlocks.push({
				id: currentBlockId,
				type: BlockType.Space,
				raw: spaceBlockContent,
				startIndex: currentIndex,
				endIndex: currentIndex + spaceBlockContent?.length,
				hasCaret: isBetweenInclusive(caretIndex, currentIndex + 1, currentIndex + spaceBlockContent?.length)
			});
			currentBlockId += 1;
			currentIndex = currentIndex + spaceBlockContent?.length;
		} else {
			const nextSeparatorNotInQuotesIndex = getNextSeparatorIndex(querySubstring, currentIndex, groupAndKeywordSupport);
			let trimIndex = void 0;
			if (nextSeparatorNotInQuotesIndex > -1) trimIndex = nextSeparatorNotInQuotesIndex > -1 && querySubstring[nextSeparatorNotInQuotesIndex]?.match(/\s/) ? nextSeparatorNotInQuotesIndex + 1 : nextSeparatorNotInQuotesIndex;
			const leadingString = querySubstring.substring(currentIndex, trimIndex).trimEnd();
			groupBlocks.push({
				id: currentBlockId,
				type: BlockType.Text,
				raw: leadingString,
				startIndex: currentIndex,
				endIndex: currentIndex + leadingString.length,
				hasCaret: isBetweenInclusive(caretIndex, currentIndex, currentIndex + leadingString.length),
				valid: unmatchedOpenParens.size === 0 && unmatchedCloseParens.size === 0,
				validations: []
			});
			currentBlockId += 1;
			currentIndex = currentIndex + leadingString.length;
		}
		return groupBlocks;
	}
	return processGroup();
}
/**
* Given a string, return three data structures describing the nature of its parentheses:
* A Map of the indices of balanced opening parentheses to the index of its closed
parenthesis
* A Set of indices of unmatched opening parentheses
* A Set of indices of unmatched closing parentheses
*
* @param queryString The string to search for parentheses
* @returns [Map of matched parens, Set of unmatched parens, Set of unmatched parens]
*/
function matchOpeningAndClosingParentheses(queryString) {
	const openParens = [];
	const matchingParens = [];
	let inQuotes = false;
	const unmatchedOpenParens = /* @__PURE__ */ new Set();
	const unmatchedCloseParens = /* @__PURE__ */ new Set();
	for (let i = 0; i < queryString.length; i++) {
		if (queryString[i] === "\"") inQuotes = !inQuotes;
		if (queryString[i] === "(" && !inQuotes) openParens.push(i);
		else if (queryString[i] === ")" && !inQuotes && openParens.length > 0) {
			const openParenIndex = openParens.pop();
			if (openParenIndex !== void 0) matchingParens.push([openParenIndex, i]);
		} else if (queryString[i] === ")" && !inQuotes) unmatchedCloseParens.add(i);
	}
	const matchedParens = /* @__PURE__ */ new Map();
	for (const [open, close] of matchingParens) matchedParens.set(open, close);
	for (const open of openParens) unmatchedOpenParens.add(open);
	return {
		matchedParens,
		unmatchedOpenParens,
		unmatchedCloseParens
	};
}
/**
*
* Given a query string and a current index, return the index of the next separator character (i.e. space or parenthesis)
* that is not within a quoted string.
*
* @param queryString The query string to search for the next character
* @param currentIndex The current index to start searching from
* @returns The index of the next separator character
*/
function getNextSeparatorIndex(queryString, currentIndex, groupAndKeywordSupport) {
	let quoteCount = 0;
	let nextSeparatorIndex = null;
	do {
		const startIndex = nextSeparatorIndex ? nextSeparatorIndex + 1 : currentIndex;
		const relativeIndex = groupAndKeywordSupport ? queryString.slice(startIndex).search(/\s|\(|\)/) : queryString.slice(startIndex).search(/\s/);
		nextSeparatorIndex = relativeIndex === -1 ? -1 : startIndex + relativeIndex;
		quoteCount = 0;
		for (let i = 0; i < nextSeparatorIndex; i++) if (queryString[i] === "\"") quoteCount += 1;
	} while (quoteCount % 2 === 1);
	return nextSeparatorIndex;
}
var getNextDelimiterRegex = memoize((valueDelimiter, groupAndKeywordSupport) => new RegExp(`[\\s${valueDelimiter}${groupAndKeywordSupport ? ")" : ""}](?=(?:[^"]*"[^"]*")*[^"]*$)`, "g"));
var getBlockValuesRegex = memoize((valueDelimiter) => new RegExp(`${valueDelimiter}(?=(?:[^"]*"[^"]*")*[^"]*$)`, "g"));
var FilterQueryParser = class {
	filterProviders = [];
	config;
	#parsingCache = {};
	#validationCache;
	NEXT_DELIMITER_REGEX;
	ITEMS_REGEX;
	LAST_DELIMITER_REGEX;
	constructor(filterProviders = [], config) {
		this.filterProviders = filterProviders;
		this.config = config ?? defaultFilterConfig;
		this.#validationCache = /* @__PURE__ */ new Set();
		this.NEXT_DELIMITER_REGEX = getNextDelimiterRegex(this.config.valueDelimiter, this.config.groupAndKeywordSupport ?? false);
		this.ITEMS_REGEX = getBlockValuesRegex(this.config.valueDelimiter);
		this.LAST_DELIMITER_REGEX = getLastDelimiterRegex(this.config.valueDelimiter, this.config.groupAndKeywordSupport ?? false);
	}
	parse(inputValue, filterQuery = new FilterQuery("", [], this.config), caretIndex = -1) {
		let blocks = generateBlocksFromQueryString(inputValue, this.config.groupAndKeywordSupport ?? false, caretIndex);
		let activeBlock;
		const parseBlocks = (recursiveBlocks) => {
			for (const [index, block] of recursiveBlocks.entries()) if (block.type !== BlockType.Space && block.type !== BlockType.UnmatchedOpenParen && block.type !== BlockType.UnmatchedCloseParen) if (this.config.groupAndKeywordSupport && isIndexedGroupBlock(block)) {
				block.blocks = parseBlocks(block.blocks);
				if (!block.blocks.length && block.hasCaret) activeBlock = block;
			} else {
				let currentBlock = block;
				if (this.config.groupAndKeywordSupport && KEYWORDS.includes(currentBlock.raw)) currentBlock.type = BlockType.Keyword;
				else {
					const query = currentBlock.raw;
					const filterDelimiterIndex = query.indexOf(this.config.filterDelimiter);
					const key = query.substring(0, filterDelimiterIndex);
					const filterProvider = this.filterProviders.find((f) => isKeyForFilterProvider(f, key));
					if (filterProvider) {
						currentBlock = this.processFilterBlock(currentBlock, filterProvider, filterDelimiterIndex, caretIndex);
						recursiveBlocks[index] = currentBlock;
					}
				}
				if (currentBlock.hasCaret) activeBlock = currentBlock;
			}
			else if (block.type === BlockType.Space && block.hasCaret) activeBlock = block;
			else if (block.type === BlockType.UnmatchedOpenParen && block.hasCaret) activeBlock = block;
			else if (block.type === BlockType.UnmatchedCloseParen && block.hasCaret) activeBlock = block;
			return recursiveBlocks;
		};
		blocks = parseBlocks(blocks);
		return new FilterQuery(inputValue, blocks, this.config, activeBlock, filterQuery.instanceContext);
	}
	replaceActiveBlockWithPresenceBlock(filterQuery, blockType) {
		let newRaw;
		let updatedCaretIndex = 0;
		const activeBlock = filterQuery.activeBlock;
		if (activeBlock && isIndexedFilterBlock(activeBlock)) {
			const rawBefore = filterQuery.raw.substring(0, activeBlock.startIndex);
			const rawAfter = filterQuery.raw.substring(activeBlock.endIndex);
			newRaw = `${rawBefore}${blockType}${this.config.filterDelimiter}${activeBlock.key.value}`;
			updatedCaretIndex = newRaw.length;
			newRaw += rawAfter && !(rawAfter[0]?.search(/\s/) === 0) ? ` ${rawAfter}` : rawAfter;
			return [newRaw, updatedCaretIndex];
		} else return [filterQuery.raw, filterQuery.raw.length];
	}
	insertSuggestion(filterBarQuery, suggestion, caretIndex) {
		let newRaw;
		let updatedCaretIndex = 0;
		const activeBlock = filterBarQuery.activeBlock;
		if (activeBlock && isIndexedFilterBlock(activeBlock)) {
			const rawBefore = filterBarQuery.raw.substring(0, activeBlock.startIndex);
			const rawAfter = filterBarQuery.raw.substring(activeBlock.endIndex);
			const updateValues = [];
			let keyValue = activeBlock.key.value;
			if (suggestion.startsWith("-")) {
				keyValue = suggestion;
				newRaw = `${rawBefore}${keyValue}${this.config.filterDelimiter}`;
				updatedCaretIndex = newRaw.length;
			} else {
				for (const value of activeBlock.value.values) if (isBetweenInclusive(caretIndex, value.startIndex, value.endIndex)) {
					updatedCaretIndex = value.startIndex + suggestion.length;
					updateValues.push(suggestion);
				} else updateValues.push(getFilterValue(value.value) ?? "");
				newRaw = `${rawBefore}${keyValue}${this.config.filterDelimiter}${updateValues.join(this.config.valueDelimiter)}`;
			}
			newRaw += rawAfter;
		} else if (activeBlock && isIndexedTextBlock(activeBlock) && caretIndex - activeBlock.startIndex <= activeBlock.raw.indexOf(this.config.filterDelimiter)) {
			const rawBefore = filterBarQuery.raw.substring(0, activeBlock.startIndex);
			const rawAfter = filterBarQuery.raw.substring(activeBlock.endIndex);
			const delimiterIndex = activeBlock.raw.indexOf(this.config.filterDelimiter);
			newRaw = `${rawBefore}${suggestion}${activeBlock.raw.substring(delimiterIndex + 1)}${rawAfter}`;
			updatedCaretIndex = rawBefore.length + suggestion.length;
		} else if (caretIndex >= 0) {
			let rawBefore = filterBarQuery.raw.substring(0, caretIndex);
			let rawAfter = filterBarQuery.raw.substring(caretIndex);
			this.NEXT_DELIMITER_REGEX.lastIndex = 0;
			const match = this.NEXT_DELIMITER_REGEX.exec(rawAfter);
			if (match) rawAfter = rawAfter.substring(match.index);
			else rawAfter = "";
			rawBefore = rawBefore.replace(this.LAST_DELIMITER_REGEX, `$1`) + suggestion;
			newRaw = rawBefore + rawAfter;
			updatedCaretIndex = rawBefore.length;
		} else {
			newRaw = filterBarQuery.raw + suggestion;
			updatedCaretIndex = newRaw.length;
		}
		return [newRaw, updatedCaretIndex];
	}
	getRaw(filterBarQuery) {
		let raw = "";
		for (const block of filterBarQuery.blocks) if (isFilterBlock(block)) {
			raw += block.key.value;
			raw += block.value.raw ? `${filterBarQuery.config.filterDelimiter}${block.value.raw}` : "";
		} else raw += block.raw;
		return raw;
	}
	validateFilterProvider(filterProvider, isTopLevel = false) {
		if (filterProvider.options.support.status === ProviderSupportStatus.Unsupported) return [false, {
			type: ValidationTypes.FilterProviderUnsupported,
			message: filterProvider.options.support.message ?? Strings.filterProviderNotSupported(filterProvider.key)
		}];
		else if (filterProvider.options.support.status === ProviderSupportStatus.Deprecated) return [false, {
			type: ValidationTypes.FilterProviderDeprecated,
			message: filterProvider.options.support.message ?? Strings.filterProviderDeprecated(filterProvider.key)
		}];
		else if (!isTopLevel && TOP_LEVEL_FILTERS.includes(filterProvider.key)) return [false, {
			type: ValidationTypes.FilterProviderTopLevel,
			message: Strings.filterProviderTopLevel(filterProvider.key)
		}];
		return [true, void 0];
	}
	processFilterBlock(block, filterProvider, filterDelimiterIndex, caretIndex) {
		const startIndex = block.startIndex;
		const keyValue = block.raw.substring(0, filterDelimiterIndex);
		const valueString = block.raw.substring(filterDelimiterIndex + 1);
		const operator = getFilterOperator(filterProvider, keyValue, valueString) ?? FilterOperator.Is;
		let runningIndex = startIndex + filterDelimiterIndex + 1;
		let blockValueItems = valueString.split(this.ITEMS_REGEX);
		if (operator === FilterOperator.Between) {
			let splitValues = [];
			blockValueItems.map((n) => {
				let vals = n.split("..").filter((v) => v);
				if (vals.length < 2) if (n.startsWith("..")) vals = ["", ...vals];
				else vals.push("");
				splitValues = [...splitValues, ...vals];
			});
			blockValueItems = splitValues;
		}
		const values = blockValueItems.map((v) => {
			const valueObject = {
				startIndex: runningIndex,
				endIndex: runningIndex + v.length,
				hasCaret: isBetweenInclusive(caretIndex, runningIndex, runningIndex + v.length),
				value: v,
				valid: this.#validationCache.has(`${keyValue}${this.config.filterDelimiter}${getFilterValue(v)}`) ? true : void 0
			};
			if (filterProvider.filterValues && valueObject.valid === void 0) filterProvider.filterValues?.find((fv) => {
				if (getFilterValue(fv.value) === v || fv.aliases?.includes(v)) {
					valueObject.valid = true;
					return true;
				}
				return false;
			});
			const valueDelimiterSize = operator === FilterOperator.Between ? 2 : 1;
			runningIndex = runningIndex + v.length + valueDelimiterSize;
			return valueObject;
		});
		return {
			...block,
			type: BlockType.Filter,
			provider: filterProvider,
			operator,
			valid: this.#validationCache.has(block.raw) ? true : void 0,
			key: {
				startIndex,
				endIndex: startIndex + filterDelimiterIndex,
				hasCaret: isBetweenInclusive(caretIndex, startIndex, startIndex + filterDelimiterIndex),
				value: keyValue
			},
			value: {
				startIndex: startIndex + filterDelimiterIndex + 1,
				endIndex: startIndex + block.raw.length,
				hasCaret: isBetweenInclusive(caretIndex, startIndex + filterDelimiterIndex + 1, startIndex + block.raw.length),
				values,
				raw: valueString
			}
		};
	}
	async validateQueryBlock(block, filterQuery, isTopLevel = false) {
		if (isIndexedFilterBlock(block)) {
			const [providerValid, providerValidationMessage] = this.validateFilterProvider(block.provider, isTopLevel);
			const values = await block.provider.validateFilterBlockValues?.(filterQuery, block, block.value.values, this.config);
			values.map((v) => {
				if (v.valid) this.#validationCache.add(`${block.provider.key}${this.config.filterDelimiter}${getFilterValue(v.value)}`);
			});
			const isBlockValid = values.every((v) => v.valid) && providerValid;
			if (isBlockValid) this.#validationCache.add(block.raw);
			return {
				...block,
				valid: isBlockValid,
				key: {
					...block.key,
					valid: providerValid,
					validations: providerValidationMessage ? [providerValidationMessage] : void 0
				},
				value: {
					...block.value,
					values
				}
			};
		}
		return block;
	}
	async validateGroupBlock(block, filterQuery) {
		const blocks = await Promise.all(block.blocks.map((b) => {
			if (isIndexedGroupBlock(b)) return this.validateGroupBlock(b, filterQuery);
			return this.validateQueryBlock(b, filterQuery);
		}));
		return {
			...block,
			blocks
		};
	}
	async validateFilterQuery(filterQuery) {
		const blockPromises = [];
		filterQuery.blocks.map((block) => {
			if (isIndexedGroupBlock(block)) blockPromises.push(this.validateGroupBlock(block, filterQuery));
			else if (isIndexedAnyBlock(block)) blockPromises.push(this.validateQueryBlock(block, filterQuery, true));
		});
		const blocks = await Promise.all(blockPromises);
		if (!this.#parsingCache[filterQuery.raw] && checkFilterQuerySync(filterQuery)) this.#parsingCache[filterQuery.raw] = filterQuery;
		return new FilterQuery(filterQuery.raw, blocks, this.config, filterQuery.activeBlock, filterQuery.instanceContext, true);
	}
};
export { isFilterBlock as $, checkFilterQuerySync as A, getEscapedFilterValue as B, TRUE_FALSE_FILTER_VALUES as C, buildRawBlockString as D, ValueOperators as E, findExistingValueUsage as F, getFlatSuggestionsList as G, getFilterBlockChunkByCaret as H, findMatchedQuotes as I, getMutableFilterBlocks as J, getHasValueSuggestion as K, getAllFilterOperators as L, defaultFilterProviderOptions as M, defaultFilterSettings as N, capitalize as O, escapeString as P, isEmptyFilterBlockValue as Q, getBlockKey as R, TIME_RANGE_VALUES as S, ValidationTypes as T, getFilterValue as U, getExcludeKeySuggestion as V, getFilterValuesByStateType as W, getUnescapedFilterValue as X, getNoValueSuggestion as Y, getUniqueReactKey as Z, RawTextProvider as _, FILTER_VALUES as a, sanitizeOperators as at, Strings as b, FilterProviderType as c, FilterValueType as d, isIndexedFilterBlock as et, INDETERMINANT as f, ProviderSupportStatus as g, LINKED_FILTER_PROVIDER_VALUES as h, FILTER_KEYS as i, promiseTimeout as it, defaultFilterConfig as j, caseInsensitiveStringCompare as k, FilterQuery as l, IS_FILTER_PROVIDER_VALUES as m, BlockType as n, isMutableFilterBlock as nt, FilterOperator as o, shouldProviderShowSuggestions as ot, IN_FILTER_PROVIDER_VALUES as p, getLastFilterBlockValue as q, DYNAMIC_VALUE_CHARS as r, isNestedFilterProvider as rt, FilterOperators as s, singleFilterProviderOptions as st, AvatarType as t, isIndexedGroupBlock as tt, FilterQueryParser as u, SORT_FILTER_PROVIDER_VALUES as v, USER_FILTERS as w, SubmitEvent as x, SORT_REACTIONS_FILTER_PROVIDER_VALUES as y, getDefaultValueVisualDescriptors as z };
