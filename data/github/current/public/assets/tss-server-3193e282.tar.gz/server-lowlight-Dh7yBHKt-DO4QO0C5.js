function rehype() {
	return function() {};
}
var all = {};
export { rehype as n, all as t };
