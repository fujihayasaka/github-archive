import React, { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CopilotSettingsContext = React.createContext({
	copilotAccessAllowed: false,
	copilotSpacesEnabled: false,
	modelsAccessAllowed: false,
	modelsRepoIntegrationEnabled: false
});
CopilotSettingsContext.displayName = "CopilotSettingsContext";
function CopilotSettingsProvider(t0) {
	const $ = c(8);
	const { children, copilotAccessAllowed: t1, copilotSpacesEnabled: t2, modelsAccessAllowed: t3, modelsRepoIntegrationEnabled: t4 } = t0;
	const copilotAccessAllowed = t1 === void 0 ? false : t1;
	const copilotSpacesEnabled = t2 === void 0 ? false : t2;
	const modelsAccessAllowed = t3 === void 0 ? false : t3;
	const modelsRepoIntegrationEnabled = t4 === void 0 ? false : t4;
	let t5;
	if ($[0] !== copilotAccessAllowed || $[1] !== copilotSpacesEnabled || $[2] !== modelsAccessAllowed || $[3] !== modelsRepoIntegrationEnabled) {
		t5 = {
			copilotAccessAllowed,
			copilotSpacesEnabled,
			modelsAccessAllowed,
			modelsRepoIntegrationEnabled
		};
		$[0] = copilotAccessAllowed;
		$[1] = copilotSpacesEnabled;
		$[2] = modelsAccessAllowed;
		$[3] = modelsRepoIntegrationEnabled;
		$[4] = t5;
	} else t5 = $[4];
	const value = t5;
	let t6;
	if ($[5] !== children || $[6] !== value) {
		t6 = jsx(CopilotSettingsContext, {
			value,
			children
		});
		$[5] = children;
		$[6] = value;
		$[7] = t6;
	} else t6 = $[7];
	return t6;
}
CopilotSettingsProvider.displayName = "CopilotSettingsProvider";
function useCopilotSettings() {
	return React.use(CopilotSettingsContext);
}
export { useCopilotSettings as n, CopilotSettingsProvider as t };
