import { redirect } from "@tanstack/react-router";
var DOTCOM_PASS_THROUGH_HEADER = "x-ui-route-dotcom-pass-through";
function getRouteIdFromPassThroughResponse(response) {
	const routeId = response.headers.get(DOTCOM_PASS_THROUGH_HEADER);
	if (routeId) return routeId;
}
function throwDotcomPassThrough(routeId) {
	const response = redirect({ reloadDocument: true });
	response.headers.set(DOTCOM_PASS_THROUGH_HEADER, routeId);
	throw response;
}
export { throwDotcomPassThrough as n, getRouteIdFromPassThroughResponse as t };
