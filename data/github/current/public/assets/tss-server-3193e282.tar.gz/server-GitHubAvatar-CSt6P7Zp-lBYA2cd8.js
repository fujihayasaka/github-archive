import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { t as Avatar } from "./server-Avatar-BF6zDnYR-B1jqD34k.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
function GitHubAvatar({ ref, src, size = 20, ...otherProps }) {
	return /* @__PURE__ */ jsx(Avatar, {
		src: useMemo(() => {
			const url = new URL(src, ssrSafeLocation.origin);
			if (!url.searchParams.has("size") && !url.searchParams.has("s")) url.searchParams.set("size", String(Number(size) * 2));
			return url.toString();
		}, [src, size]),
		size,
		"data-testid": "github-avatar",
		...otherProps,
		ref
	});
}
GitHubAvatar.displayName = "GitHubAvatar";
export { GitHubAvatar as t };
