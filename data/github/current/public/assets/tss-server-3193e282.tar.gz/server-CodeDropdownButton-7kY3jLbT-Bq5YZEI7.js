import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { H as CodeIcon, Mt as FileZipIcon, Qt as Heading$2, bn as Link, hi as TriangleDownIcon, lr as QuestionIcon, n as ActionList, ot as DesktopDownloadIcon, pi as Tooltip$1, si as TerminalIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { o as verifiedFetch, r as reactFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { r as UnderlineNav } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { f as useSuspenseQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as PathProvider } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo, t as RefInfoProvider } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { t as ActionProvider } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as TabNav_default } from "./server-TabNav-ChmPEmaf-BGcvB88p.js";
import { t as CopilotSettingsProvider } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { t as EditPermissionsProvider } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { t as useIsPlatform } from "./server-use-is-platform-BI7nkjWR-DIY2sQH4.js";
import { t as createPersister } from "./server-react-query-persister-D24LKcxB-BQe2u09x.js";
import { n as Type, t as Compile } from "./server-typebox-DK1Y6Tz8-C4QyQJfa.js";
import { n as isCachingEnabled, r as isReactCodespacesTabEnabled, s as usePrefetchCodespacesData, t as buildCodespacesPath } from "./server-use-codespaces-data-B_J5e7_J-CHke9Nch.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { i as usePageDataUrl, t as PageData } from "./server-use-page-data-url-DgRUryAI-B7V9LWvy.js";
import { Suspense, lazy, useCallback, useEffect, useEffectEvent, useMemo, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var CodeDropdownButton_module_default = {
	CodespacesSkeletonWrapper: "CodeDropdownButton-module_igt33q_CodespacesSkeletonWrapper",
	NavItem: "CodeDropdownButton-module_igt33q_NavItem",
	SkeletonLoaderWrapper: "CodeDropdownButton-module_igt33q_SkeletonLoaderWrapper",
	TabNav: "CodeDropdownButton-module_igt33q_TabNav"
};
var safeLocalStorage$1 = safeStorage("localStorage");
var CodespacesContentValidator = Compile(Type.String());
async function fetchCodespacesContent(codespacesPath) {
	if (!codespacesPath) return "";
	const result = await reactFetch(codespacesPath);
	if (result.status >= 400 && result.status <= 499) return "";
	else if (!result.ok) throw new Error(`HTTP ${result.status}`);
	return await result.text();
}
var useCodespaceTabContentQueryOptions = (codespacesPathProp) => {
	const $ = c(13);
	const repo = useCurrentRepository();
	const refInfo = useRefInfo();
	let t0;
	if ($[0] !== codespacesPathProp || $[1] !== refInfo || $[2] !== repo) {
		t0 = codespacesPathProp || (repo && refInfo ? buildCodespacesPath(repo.id, refInfo.name) : void 0);
		$[0] = codespacesPathProp;
		$[1] = refInfo;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	const codespacesPath = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	let t2;
	if ($[4] !== codespacesPath) {
		t1 = ["CodespacesTabContent.content", codespacesPath];
		t2 = () => fetchCodespacesContent(codespacesPath);
		$[4] = codespacesPath;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	let t3;
	if ($[7] !== sendAnalyticsEvent) {
		t3 = createPersister({
			validator: CodespacesContentValidator,
			sendAnalyticsEvent,
			enabled: isCachingEnabled()
		});
		$[7] = sendAnalyticsEvent;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== t1 || $[10] !== t2 || $[11] !== t3) {
		t4 = {
			queryKey: t1,
			queryFn: t2,
			persister: t3
		};
		$[9] = t1;
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
};
function usePrefetchCodespacesQuery(codespacesPath) {
	const $ = c(3);
	const queryClient = useQueryClient();
	const codespaceQueryOptions = useCodespaceTabContentQueryOptions(codespacesPath);
	let t0;
	if ($[0] !== codespaceQueryOptions || $[1] !== queryClient) {
		t0 = () => {
			const isEnabled = isCachingEnabled();
			const defaultTab = safeLocalStorage$1.getItem("code-button-default-tab");
			if (!isEnabled || defaultTab !== "cloud") return;
			return queryClient.prefetchQuery(codespaceQueryOptions);
		};
		$[0] = codespaceQueryOptions;
		$[1] = queryClient;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
function useCodespaceContent(codespacesPath) {
	return useSuspenseQuery(useCodespaceTabContentQueryOptions(codespacesPath));
}
async function loadCodespacesTabReact() {
	return { default: (await import("./server-CodespacesTabReact-D2DpwdLq-VTKQ6o5K.js")).CodespacesTabReact };
}
var LazyCodespacesTabReact = lazy(loadCodespacesTabReact);
LazyCodespacesTabReact.displayName = "LazyCodespacesTabReact";
function preloadCodespacesTabReact() {
	loadCodespacesTabReact();
}
function defaultErrorMessage(contactPath) {
	return /* @__PURE__ */ jsxs("span", { children: [
		"An unexpected error occurred. Please",
		" ",
		/* @__PURE__ */ jsx(Link, {
			inline: true,
			href: contactPath,
			children: "contact support"
		}),
		" ",
		"for more information."
	] });
}
function ErrorMessage({ header, message }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "blankslate",
		children: [/* @__PURE__ */ jsx("p", {
			className: "fgColor-default text-bold mb-1",
			children: header
		}), /* @__PURE__ */ jsx("p", {
			className: "mt-2 tmp-mx-4",
			children: message
		})]
	});
}
ErrorMessage.displayName = "ErrorMessage";
function CodespacesTabWrapper({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-justify-center",
		children: /* @__PURE__ */ jsx(ErrorBoundary, {
			fallback: /* @__PURE__ */ jsx(ErrorMessage, {
				header: "Codespaces data failed to load.",
				message: "Refresh the page and try again."
			}),
			children: /* @__PURE__ */ jsx(Suspense, {
				fallback: /* @__PURE__ */ jsxs("div", {
					role: "status",
					className: CodeDropdownButton_module_default.CodespacesSkeletonWrapper,
					"aria-busy": true,
					"aria-label": "Loading Codespaces",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: CodeDropdownButton_module_default.SkeletonLoaderWrapper,
							children: /* @__PURE__ */ jsx(SkeletonBox, {
								width: "100%",
								height: "var(--base-size-32)"
							})
						}),
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsx("div", {
							className: CodeDropdownButton_module_default.SkeletonLoaderWrapper,
							children: /* @__PURE__ */ jsx(SkeletonBox, {
								width: "100%",
								height: "var(--base-size-64)"
							})
						}),
						/* @__PURE__ */ jsx(ActionList.Divider, {}),
						/* @__PURE__ */ jsx("div", {
							className: CodeDropdownButton_module_default.SkeletonLoaderWrapper,
							children: /* @__PURE__ */ jsx(SkeletonBox, {
								width: "100%",
								height: "var(--base-size-32)"
							})
						})
					]
				}),
				children
			})
		})
	});
}
CodespacesTabWrapper.displayName = "CodespacesTabWrapper";
function ServerRenderedCodespacesTabContent(t0) {
	const $ = c(2);
	const { codespacesPath } = t0;
	const { data: content } = useCodespaceContent(codespacesPath);
	let t1;
	if ($[0] !== content) {
		t1 = jsx(VerifiedHTMLBox, {
			className: "width-full",
			html: content
		});
		$[0] = content;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
/**
* Checks access and renders error states. Returns null if access is granted
* and the caller should proceed to render the codespaces content.
*/
ServerRenderedCodespacesTabContent.displayName = "ServerRenderedCodespacesTabContent";
function AccessGate(props) {
	const { hasAccessToCodespaces, repoPolicyInfo, contactPath, currentUserIsEnterpriseManaged, enterpriseManagedBusinessName, newCodespacePath, isLoggedIn } = props;
	if (!hasAccessToCodespaces) {
		if (!isLoggedIn) return /* @__PURE__ */ jsx(ErrorMessage, {
			header: "Sign in required",
			message: /* @__PURE__ */ jsxs("span", { children: [
				"Please",
				" ",
				/* @__PURE__ */ jsx(Link, {
					inline: true,
					href: newCodespacePath,
					children: "sign in"
				}),
				" ",
				"to use Codespaces."
			] })
		});
		if (!repoPolicyInfo?.allowed) {
			let message = null;
			if (!repoPolicyInfo?.canBill && currentUserIsEnterpriseManaged) message = /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx(Link, {
				href: "https://docs.github.com/enterprise-cloud@latest/admin/identity-and-access-management/using-enterprise-managed-users-for-iam/about-enterprise-managed-users",
				children: "Enterprise-managed users"
			}), ` must have their Codespaces usage paid for by ${enterpriseManagedBusinessName || "their enterprise"}.`] });
			else if (repoPolicyInfo?.hasIpAllowLists) message = /* @__PURE__ */ jsxs("span", { children: [
				"Your organization or enterprise enforces",
				" ",
				/* @__PURE__ */ jsx(Link, {
					inline: true,
					href: "https://docs.github.com/enterprise-cloud@latest/organizations/keeping-your-organization-secure/managing-security-settings-for-your-organization/managing-allowed-ip-addresses-for-your-organization",
					children: "IP allow lists"
				}),
				" ",
				"which are unsupported by Codespaces at this time."
			] });
			else if (repoPolicyInfo?.disabledByBusiness) message = /* @__PURE__ */ jsx("span", { children: "Your enterprise has disabled Codespaces at this time. Please contact your enterprise administrator for more information." });
			else if (repoPolicyInfo?.disabledByOrganization) message = /* @__PURE__ */ jsx("span", { children: "Your organization has disabled Codespaces on this repository. Please contact your organization administrator for more information." });
			else message = defaultErrorMessage(contactPath);
			return /* @__PURE__ */ jsx(ErrorMessage, {
				header: "Codespace access limited",
				message
			});
		} else if (!repoPolicyInfo?.changesWouldBeSafe) return /* @__PURE__ */ jsx(ErrorMessage, {
			header: "Repository access limited",
			message: /* @__PURE__ */ jsx("span", { children: "You do not have access to push to this repository and its owner has disabled forking." })
		});
		else return /* @__PURE__ */ jsx(ErrorMessage, {
			header: "Codespace access limited",
			message: defaultErrorMessage(contactPath)
		});
	}
	return null;
}
AccessGate.displayName = "AccessGate";
function CodespacesTabContent(props) {
	const { codespacesPath, currentBranchName, createRef, hasAccessToCodespaces, useReactVersion } = props;
	const accessError = AccessGate(props);
	if (accessError) return accessError;
	if (hasAccessToCodespaces && (useReactVersion || isReactCodespacesTabEnabled())) return /* @__PURE__ */ jsx(LazyCodespacesTabReact, {
		codespacesPath,
		currentBranchName,
		createRef
	});
	return /* @__PURE__ */ jsx(ServerRenderedCodespacesTabContent, { codespacesPath });
}
CodespacesTabContent.displayName = "CodespacesTabContent";
function CodespacesTab(props) {
	return /* @__PURE__ */ jsx(CodespacesTabWrapper, { children: /* @__PURE__ */ jsx(CodespacesTabContent, { ...props }) });
}
CodespacesTab.displayName = "CodespacesTab";
var LocalTab_module_default = {
	CloneContainer: "LocalTab-module_6eqmsq_CloneContainer",
	CopyToClipboardButton: "LocalTab-module_6eqmsq_CopyToClipboardButton",
	PlatformContents: "LocalTab-module_6eqmsq_PlatformContents",
	UnderlineNav: "LocalTab-module_6eqmsq_UnderlineNav"
};
function LocalTab(props) {
	const { httpAvailable, sshAvailable, httpUrl, showCloneWarning, sshUrl, sshCertificatesRequired, sshCertificatesAvailable, ghCliUrl, newSshKeyUrl, setProtocolPath } = props.protocolInfo;
	const { defaultProtocol } = props.protocolInfo;
	const [activeLocalTab, setActiveLocalTab] = useState(defaultProtocol);
	const [openingPlatform, setOpeningPlatform] = useState("");
	const { cloneUrl, visualStudioCloneUrl, showVisualStudioCloneButton, showXcodeCloneButton, xcodeCloneUrl, zipballUrl } = props.platformInfo;
	const isMacOrWindows = useIsPlatform(["windows", "mac"]);
	const isMac = useIsPlatform(["mac"]);
	const navigate = useNavigate$1();
	const localProtocolClassName = "mt-2 fgColor-muted text-normal";
	const onProtocolTabClick = useCallback((protocol) => {
		if (activeLocalTab !== protocol) {
			setActiveLocalTab(protocol);
			const formData = new FormData();
			formData.set("protocol_selector", protocol);
			verifiedFetch(setProtocolPath, {
				method: "post",
				body: formData
			});
		}
	}, [
		activeLocalTab,
		setActiveLocalTab,
		setProtocolPath
	]);
	const tabs = useMemo(() => {
		const result = [];
		const handleHttpClick = () => onProtocolTabClick("http");
		const handleSshClick = () => onProtocolTabClick("ssh");
		const handleCliClick = () => onProtocolTabClick("gh_cli");
		if (httpAvailable) result.push({
			protocol: "http",
			displayName: "HTTPS",
			ariaLabel: "Clone with HTTPS",
			handler: handleHttpClick
		});
		if (sshAvailable) result.push({
			protocol: "ssh",
			displayName: "SSH",
			ariaLabel: "Clone with SSH",
			handler: handleSshClick
		});
		result.push({
			protocol: "gh_cli",
			displayName: "GitHub CLI",
			ariaLabel: "Clone with GitHub CLI",
			handler: handleCliClick
		});
		return result;
	}, [
		httpAvailable,
		onProtocolTabClick,
		sshAvailable
	]);
	const platforms = useMemo(() => {
		const result_0 = [];
		if (isMacOrWindows) result_0.push({
			name: "githubDesktop",
			text: "Open with GitHub Desktop",
			url: cloneUrl,
			icon: DesktopDownloadIcon
		});
		if (isMacOrWindows && showVisualStudioCloneButton) result_0.push({
			name: "visualStudio",
			text: "Open with Visual Studio",
			url: visualStudioCloneUrl
		});
		if (isMac && showXcodeCloneButton) result_0.push({
			name: "xcode",
			text: "Open with Xcode",
			url: xcodeCloneUrl
		});
		result_0.push({
			name: "zip",
			text: "Download ZIP",
			url: zipballUrl,
			icon: FileZipIcon
		});
		return result_0;
	}, [
		cloneUrl,
		isMac,
		isMacOrWindows,
		showVisualStudioCloneButton,
		showXcodeCloneButton,
		visualStudioCloneUrl,
		xcodeCloneUrl,
		zipballUrl
	]);
	return /* @__PURE__ */ jsx("div", { children: openingPlatform === "githubDesktop" ? /* @__PURE__ */ jsx(LaunchingPlatformContents, {
		platform: "GitHub Desktop",
		href: "https://desktop.github.com/"
	}) : openingPlatform === "visualStudio" ? /* @__PURE__ */ jsx(LaunchingPlatformContents, { platform: "Visual Studio" }) : openingPlatform === "xcode" ? /* @__PURE__ */ jsx(LaunchingPlatformContents, {
		platform: "Xcode",
		href: "https://developer.apple.com/xcode/"
	}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
		className: "tmp-m-3",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "d-flex flex-items-center",
				children: [
					/* @__PURE__ */ jsx(TerminalIcon, { className: "mr-2" }),
					/* @__PURE__ */ jsx("p", {
						className: "flex-1 text-bold mb-0",
						children: "Clone"
					}),
					/* @__PURE__ */ jsx(Tooltip$1, {
						text: "Which remote URL should I use?",
						type: "label",
						direction: "w",
						children: /* @__PURE__ */ jsx(Link, {
							muted: true,
							href: `${props.helpUrl}/articles/which-remote-url-should-i-use`,
							children: /* @__PURE__ */ jsx(QuestionIcon, { className: "mr-1" })
						})
					})
				]
			}),
			/* @__PURE__ */ jsx(UnderlineNav, {
				"aria-label": "Remote URL selector",
				className: LocalTab_module_default.UnderlineNav,
				children: tabs.map((tab) => /* @__PURE__ */ jsx(UnderlineNav.Item, {
					"aria-current": activeLocalTab === tab.protocol ? "page" : void 0,
					"aria-label": tab.ariaLabel,
					onClick: tab.handler,
					children: tab.displayName
				}, tab.protocol))
			}),
			activeLocalTab === "http" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CloneUrl, {
				inputId: "clone-with-https",
				inputLabel: "Clone with HTTPS url",
				url: httpUrl
			}), /* @__PURE__ */ jsx("p", {
				className: localProtocolClassName,
				children: "Clone using the web URL."
			})] }) : activeLocalTab === "ssh" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
				showCloneWarning && /* @__PURE__ */ jsxs(Flash, {
					className: "mb-2",
					variant: "warning",
					children: [
						"You don't have any public SSH keys in your GitHub account. ",
						"You can",
						" ",
						/* @__PURE__ */ jsx(Link, {
							inline: true,
							href: newSshKeyUrl,
							children: "add a new public key"
						}),
						", or try cloning this repository via HTTPS."
					]
				}),
				/* @__PURE__ */ jsx(CloneUrl, {
					inputId: "clone-with-ssh",
					inputLabel: "Clone with SSH url",
					url: sshUrl
				}),
				/* @__PURE__ */ jsx("p", {
					className: localProtocolClassName,
					children: sshCertificatesRequired ? "Use a password-protected SSH certificate." : sshCertificatesAvailable ? "Use a password-protected SSH key or certificate." : "Use a password-protected SSH key."
				})
			] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CloneUrl, {
				buttonAriaLabel: "Copy command to clipboard",
				inputId: "clone-with-gh-cli",
				inputLabel: "Clone with GitHub CLI command",
				url: ghCliUrl
			}), /* @__PURE__ */ jsxs("p", {
				className: localProtocolClassName,
				children: [
					"Work fast with our official CLI.",
					" ",
					/* @__PURE__ */ jsx(Link, {
						inline: true,
						href: "https://cli.github.com",
						target: "_blank",
						"aria-label": "Learn more about the GitHub CLI",
						children: "Learn more"
					})
				]
			})] })
		]
	}), /* @__PURE__ */ jsx(ActionList, {
		variant: "inset",
		className: "border-top",
		children: platforms.map((platform) => platform.name === "zip" ? /* @__PURE__ */ jsxs(ActionList.LinkItem, {
			"data-turbo": "false",
			href: platform.url,
			rel: "nofollow",
			children: [platform.icon && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(platform.icon, {}) }), platform.text]
		}, platform.name) : /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: (ev) => {
				setOpeningPlatform(platform.name);
				ev.preventDefault();
				let isCustomProtocol = false;
				try {
					const { protocol: protocol_0 } = new URL(platform.url, window.location.origin);
					isCustomProtocol = protocol_0 !== "http:" && protocol_0 !== "https:";
				} catch {
					isCustomProtocol = false;
				}
				if (isCustomProtocol) navigate(platform.url, { preventTurbo: true });
				else navigate(platform.url);
			},
			children: [platform.icon && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(platform.icon, {}) }), platform.text]
		}, platform.name))
	})] }) });
}
LocalTab.displayName = "LocalTab";
function LaunchingPlatformContents({ platform, href }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("tmp-p-3", LocalTab_module_default.PlatformContents),
		children: [/* @__PURE__ */ jsx(Heading$2, {
			as: "h4",
			variant: "small",
			className: "tmp-mb-3 text-center",
			children: `Launching ${platform}`
		}), href && /* @__PURE__ */ jsxs("p", {
			className: "tmp-mb-3",
			children: [
				"If nothing happens, ",
				/* @__PURE__ */ jsx(Link, {
					inline: true,
					href,
					children: `download ${platform}`
				}),
				" and try again."
			]
		})]
	});
}
LaunchingPlatformContents.displayName = "LaunchingPlatformContents";
function CloneUrl({ buttonAriaLabel = "Copy URL to clipboard", inputId, inputLabel, url }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("d-flex mb-2", LocalTab_module_default.CloneContainer),
		children: [
			/* @__PURE__ */ jsx("label", {
				htmlFor: inputId,
				className: "sr-only",
				children: inputLabel
			}),
			/* @__PURE__ */ jsx("input", {
				id: inputId,
				type: "text",
				className: "form-control input-monospace input-sm color-bg-subtle",
				"data-autoselect": true,
				value: url,
				readOnly: true,
				style: { flexGrow: 1 }
			}),
			/* @__PURE__ */ jsx(CopyToClipboardButton, {
				className: clsx("ml-1 mr-0", LocalTab_module_default.CopyToClipboardButton),
				textToCopy: url,
				ariaLabel: buttonAriaLabel,
				tooltipProps: { direction: "nw" }
			})
		]
	});
}
CloneUrl.displayName = "CloneUrl";
function useCodeButtonData(initialData) {
	const $ = c(7);
	const apiURL = usePageDataUrl(PageData.codeButton);
	let t0;
	let t1;
	if ($[0] !== apiURL) {
		t0 = [PageData.codeButton, apiURL];
		t1 = async () => {
			const result = await reactFetch(apiURL);
			if (!result.ok) throw new Error(`HTTP ${result.status}`);
			return await result.json();
		};
		$[0] = apiURL;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	let t2;
	if ($[3] !== initialData || $[4] !== t0 || $[5] !== t1) {
		t2 = {
			queryKey: t0,
			queryFn: t1,
			initialData,
			staleTime: Infinity
		};
		$[3] = initialData;
		$[4] = t0;
		$[5] = t1;
		$[6] = t2;
	} else t2 = $[6];
	return useSuspenseQuery(t2);
}
var CodeMenuButton = (t0) => {
	const $ = c(22);
	const { isPrimary, children, className, size, onOpenChange, codespacesPath, shouldPrefetchCodespaces: t1 } = t0;
	const shouldPrefetchCodespaces = t1 === void 0 ? false : t1;
	const [showPopover, setShowPopover] = useState(false);
	const prefetchHtml = usePrefetchCodespacesQuery(codespacesPath);
	const prefetchJson = usePrefetchCodespacesData(codespacesPath);
	let t2;
	if ($[0] !== prefetchHtml || $[1] !== prefetchJson || $[2] !== shouldPrefetchCodespaces) {
		t2 = () => {
			if (!shouldPrefetchCodespaces) return;
			if (isReactCodespacesTabEnabled()) {
				preloadCodespacesTabReact();
				prefetchJson();
			} else prefetchHtml();
		};
		$[0] = prefetchHtml;
		$[1] = prefetchJson;
		$[2] = shouldPrefetchCodespaces;
		$[3] = t2;
	} else t2 = $[3];
	const prefetch = t2;
	let t3;
	if ($[4] !== children || $[5] !== className || $[6] !== isPrimary || $[7] !== onOpenChange || $[8] !== prefetch || $[9] !== showPopover || $[10] !== size) {
		let t4;
		if ($[12] !== onOpenChange || $[13] !== prefetch) {
			t4 = () => {
				prefetch();
				setShowPopover(true);
				onOpenChange?.(true);
			};
			$[12] = onOpenChange;
			$[13] = prefetch;
			$[14] = t4;
		} else t4 = $[14];
		let t5;
		if ($[15] !== onOpenChange) {
			t5 = () => {
				setShowPopover(false);
				onOpenChange?.(false);
			};
			$[15] = onOpenChange;
			$[16] = t5;
		} else t5 = $[16];
		let t6;
		if ($[17] !== className || $[18] !== isPrimary || $[19] !== prefetch || $[20] !== size) {
			t6 = (buttonProps) => jsx(ButtonComponent, {
				...buttonProps,
				className,
				variant: isPrimary ? "primary" : void 0,
				leadingVisual: _temp,
				trailingVisual: _temp2,
				size: size ? size : "medium",
				onMouseEnter: prefetch,
				onFocus: prefetch,
				children: "Code"
			});
			$[17] = className;
			$[18] = isPrimary;
			$[19] = prefetch;
			$[20] = size;
			$[21] = t6;
		} else t6 = $[21];
		t3 = jsx(AnchoredOverlay, {
			align: "end",
			focusZoneSettings: { disabled: true },
			open: showPopover,
			onOpen: t4,
			onClose: t5,
			renderAnchor: t6,
			children
		});
		$[4] = children;
		$[5] = className;
		$[6] = isPrimary;
		$[7] = onOpenChange;
		$[8] = prefetch;
		$[9] = showPopover;
		$[10] = size;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
};
CodeMenuButton.displayName = "CodeMenuButton";
function _temp() {
	return jsx(CodeIcon, { className: "hide-sm" });
}
function _temp2() {
	return jsx(TriangleDownIcon, {});
}
var safeLocalStorage = safeStorage("localStorage");
var ActiveTab = {
	Local: "local",
	Codespaces: "cloud",
	Copilot: "copilot"
};
function CodeDropdownButton(props) {
	const $ = c(7);
	const { primary, className, size, showCodespacesTab, isEnterprise, localTab, codespacesTab, localTabProps, codespacesPath, refName, refType, currentBranchName, createRef } = props;
	const [activeTab, setActiveTab] = useState(ActiveTab.Local);
	const refInfo = {
		name: refName,
		listCacheKey: refName,
		refType: refType ?? "branch",
		currentOid: "",
		canEdit: false,
		canEditOnDefaultBranch: false,
		fileExistsOnDefault: false
	};
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (ev) => {
			setActiveTab(ActiveTab.Codespaces);
			safeLocalStorage.setItem("code-button-default-tab", ActiveTab.Codespaces);
			ev?.preventDefault();
		};
		$[0] = t0;
	} else t0 = $[0];
	const onCodespacesTabClick = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (ev_0) => {
			setActiveTab(ActiveTab.Local);
			safeLocalStorage.setItem("code-button-default-tab", ActiveTab.Local);
			ev_0?.preventDefault();
		};
		$[1] = t1;
	} else t1 = $[1];
	const onLocalTabClick = t1;
	let t2;
	if ($[2] !== showCodespacesTab) {
		t2 = () => {
			if (safeLocalStorage.getItem("code-button-default-tab") === ActiveTab.Codespaces && showCodespacesTab) onCodespacesTabClick();
		};
		$[2] = showCodespacesTab;
		$[3] = t2;
	} else t2 = $[3];
	const handleInitialTabSelect = useEffectEvent(t2);
	let t3;
	if ($[4] !== handleInitialTabSelect) {
		t3 = () => {
			handleInitialTabSelect();
		};
		$[4] = handleInitialTabSelect;
		$[5] = t3;
	} else t3 = $[5];
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = [];
		$[6] = t4;
	} else t4 = $[6];
	useEffect(t3, t4);
	const showTabNav = !isEnterprise && showCodespacesTab;
	return jsx(PathProvider, {
		path: "",
		children: jsx(ActionProvider, {
			action: "tree",
			children: jsx(CopilotSettingsProvider, {
				copilotAccessAllowed: false,
				children: jsx(RefInfoProvider, {
					refInfo,
					children: jsx(EditPermissionsProvider, {
						canEdit: false,
						canEditOnDefaultBranch: false,
						fileExistsOnDefault: false,
						children: jsxs(CodeMenuButton, {
							size,
							isPrimary: primary,
							className,
							codespacesPath,
							shouldPrefetchCodespaces: Boolean(showCodespacesTab),
							children: [showTabNav && jsxs(TabNav_default, {
								className: CodeDropdownButton_module_default.TabNav,
								children: [jsx(TabNav_default.Link, {
									as: ButtonComponent,
									selected: activeTab === ActiveTab.Local,
									onClick: onLocalTabClick,
									className: CodeDropdownButton_module_default.NavItem,
									children: "Local"
								}), !isEnterprise && showCodespacesTab && jsx(TabNav_default.Link, {
									as: ButtonComponent,
									selected: activeTab === ActiveTab.Codespaces,
									onClick: onCodespacesTabClick,
									className: CodeDropdownButton_module_default.NavItem,
									children: "Codespaces"
								})]
							}), jsxs("div", {
								className: "react-overview-code-button-action-list py-0",
								children: [activeTab === ActiveTab.Local && (localTab || renderLocalTab(localTabProps)), activeTab === ActiveTab.Codespaces && (codespacesTab || renderCodespacesTab(codespacesPath, currentBranchName, createRef))]
							})]
						})
					})
				})
			})
		})
	});
}
CodeDropdownButton.displayName = "CodeDropdownButton";
function renderLocalTab(localTabProps) {
	if (!localTabProps) return null;
	return /* @__PURE__ */ jsx(LocalTab, { ...localTabProps });
}
function renderCodespacesTab(codespacesPath, currentBranchName, createRef) {
	return /* @__PURE__ */ jsx(CodespacesTabWrapper, { children: /* @__PURE__ */ jsx(SuspendedCodespacesTab, {
		codespacesPath,
		currentBranchName,
		createRef
	}) });
}
function SuspendedCodespacesTab(t0) {
	const $ = c(5);
	const { codespacesPath, currentBranchName, createRef } = t0;
	const data = useCodeButtonData().data;
	let t1;
	if ($[0] !== codespacesPath || $[1] !== createRef || $[2] !== currentBranchName || $[3] !== data) {
		t1 = jsx(CodespacesTabContent, {
			...data,
			codespacesPath,
			currentBranchName,
			createRef
		});
		$[0] = codespacesPath;
		$[1] = createRef;
		$[2] = currentBranchName;
		$[3] = data;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
SuspendedCodespacesTab.displayName = "SuspendedCodespacesTab";
export { LocalTab as i, CodeDropdownButton as n, CodespacesTab as r, CloneUrl as t };
