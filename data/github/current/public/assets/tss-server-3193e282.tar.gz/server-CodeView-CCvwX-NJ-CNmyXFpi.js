import { t as PathProvider } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { t as RefInfoProvider } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { t as ActionProvider } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as CopilotSettingsProvider } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { t as EditPermissionsProvider } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { x as MarketplaceEnabledProvider } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { n as SearchTermProvider, t as FindInFileOpenProvider } from "./server-FindInFileOpenContext-ugtnUwTQ-CmcTU3Zx.js";
import { t as CodeViewError } from "./server-CodeViewError-DTMNTptz-DKXztgzD.js";
import { n as useUpdateRefInfoAndPath, t as useCanonicalObject } from "./server-use-update-ref-info-and-path-CakYhmiE-CuwmSmVs.js";
import React, { useEffect } from "react";
import { Fragment as Fragment$1, jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CodeView_module_default = { contentWrapper: "CodeView-module_OCWcnq_contentWrapper" };
function CodeView(t0) {
	const $ = c(14);
	const { payload, action, isBlame: t1, children } = t0;
	const isBlame = t1 === void 0 ? false : t1;
	const { path } = payload;
	const refInfo = useCanonicalObject(payload.refInfo);
	useUpdateRefInfoAndPath(refInfo, path);
	let t2;
	if ($[0] !== payload.path) {
		t2 = [payload.path];
		$[0] = payload.path;
		$[1] = t2;
	} else t2 = $[1];
	useEffect(_temp, t2);
	let t3;
	if ($[2] !== action || $[3] !== children || $[4] !== isBlame || $[5] !== path || $[6] !== payload.copilotAccessAllowed || $[7] !== payload.copilotSpacesEnabled || $[8] !== payload.error || $[9] !== payload.isMarketplaceEnabled || $[10] !== payload.modelsAccessAllowed || $[11] !== payload.modelsRepoIntegrationEnabled || $[12] !== refInfo) {
		t3 = jsx(PathProvider, {
			path,
			children: jsx(ActionProvider, {
				action,
				children: jsx(MarketplaceEnabledProvider, {
					isMarketplaceEnabled: payload.isMarketplaceEnabled,
					children: jsx(CopilotSettingsProvider, {
						copilotAccessAllowed: payload.copilotAccessAllowed ?? false,
						copilotSpacesEnabled: payload.copilotSpacesEnabled ?? false,
						modelsAccessAllowed: payload.modelsAccessAllowed ?? false,
						modelsRepoIntegrationEnabled: payload.modelsRepoIntegrationEnabled ?? false,
						children: jsx(RefInfoProvider, {
							refInfo,
							children: jsx(EditPermissionsProvider, {
								canEdit: refInfo.canEdit,
								canEditOnDefaultBranch: refInfo.canEditOnDefaultBranch,
								fileExistsOnDefault: refInfo.fileExistsOnDefault,
								children: jsx(SearchTermProvider, { children: jsx(FindInFileOpenProvider, {
									isBlame,
									children: payload.error ? jsx(CodeViewError, { ...payload.error }) : jsx(Fragment$1, { children: jsx("div", {
										className: CodeView_module_default.contentWrapper,
										children: children()
									}) })
								}) })
							})
						})
					})
				})
			})
		});
		$[2] = action;
		$[3] = children;
		$[4] = isBlame;
		$[5] = path;
		$[6] = payload.copilotAccessAllowed;
		$[7] = payload.copilotSpacesEnabled;
		$[8] = payload.error;
		$[9] = payload.isMarketplaceEnabled;
		$[10] = payload.modelsAccessAllowed;
		$[11] = payload.modelsRepoIntegrationEnabled;
		$[12] = refInfo;
		$[13] = t3;
	} else t3 = $[13];
	return t3;
}
CodeView.displayName = "CodeView";
function _temp() {
	let frameId;
	if (!window.location.hash && window.scrollY > 0) {
		const codeViewHeader = document.querySelector("#StickyHeader");
		if (codeViewHeader) {
			codeViewHeader.style.position = "relative";
			codeViewHeader.scrollIntoView();
			frameId = requestAnimationFrame(() => {
				codeViewHeader.style.position = "sticky";
			});
		}
	}
	return () => {
		if (frameId !== void 0) cancelAnimationFrame(frameId);
	};
}
export { CodeView as t };
