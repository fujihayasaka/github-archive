performance.mark("js-parse-end:server-CodespacesTabReact-D2DpwdLq-VTKQ6o5K.js");
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { $ as ContainerIcon, Er as ShareIcon, Ht as GitBranchIcon, J as CodespacesIcon, Jt as GitPullRequestIcon, Kt as GitPullRequestClosedIcon, Ni as ZapIcon, O as CheckIcon, Qr as StopIcon, V as ClockIcon, Wt as GitMergeIcon, Yt as GlobeIcon, Zn as PencilIcon, _i as Truncate, _n as KebabHorizontalIcon, an as IconButton, ar as PlusIcon, bn as Link, d as ArrowRightIcon, dr as Radio, fr as RadioGroup_default, lr as QuestionIcon, mi as TrashIcon, n as ActionList, o as AlertIcon, pi as Tooltip$1, pt as DotFillIcon, st as DeviceDesktopIcon, x as BookmarkIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as BranchName_default } from "./server-BranchName-HKnig0CO-C3hpegKL.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { a as useCodespacesData, i as useCodespacesAlive, o as useInvalidateCodespacesData } from "./server-use-codespaces-data-B_J5e7_J-CHke9Nch.js";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:CodespacesTabReact-D2DpwdLq.js");
function buildBadgeUrl() {
	return new URL("/codespaces/badge.svg", globalThis.location?.origin ?? "https://github.com").toString();
}
function buildSnippets(url, badgeUrl) {
	const badgeAlt = "Open in GitHub Codespaces";
	return {
		url,
		html: `<a href="${url}"><img src="${badgeUrl}" alt="${badgeAlt}" /></a>`,
		markdown: `[![${badgeAlt}](${badgeUrl})](${url})`
	};
}
function ShareDeepLinkDialog(t0) {
	const $ = c(15);
	const { isOpen, onClose, shareUrl } = t0;
	const [quickStart, setQuickStart] = useState(false);
	const [activeTab, setActiveTab] = useState("url");
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = buildBadgeUrl();
		$[0] = t1;
	} else t1 = $[0];
	const badgeUrl = t1;
	const effectiveUrl = quickStart ? `${shareUrl}?quickstart=1` : shareUrl;
	let t2;
	if ($[1] !== effectiveUrl) {
		t2 = buildSnippets(effectiveUrl, badgeUrl);
		$[1] = effectiveUrl;
		$[2] = t2;
	} else t2 = $[2];
	const snippets = t2;
	if (!isOpen) return null;
	let t3;
	if ($[3] !== activeTab || $[4] !== onClose || $[5] !== quickStart || $[6] !== sendAnalyticsEvent || $[7] !== snippets) {
		const tabItems = [
			{
				id: "url",
				label: "URL"
			},
			{
				id: "html",
				label: "HTML"
			},
			{
				id: "markdown",
				label: "Markdown"
			}
		];
		let t4;
		if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
			t4 = (e) => setQuickStart(e.target.checked);
			$[9] = t4;
		} else t4 = $[9];
		const t5 = jsx("div", {
			className: "border-bottom color-border-muted tmp-pb-3 tmp-mb-3",
			children: jsxs(FormControl$1, { children: [
				jsx(Checkbox, {
					checked: quickStart,
					onChange: t4
				}),
				jsx(FormControl$1.Label, { children: "Quick start" }),
				jsxs(FormControl$1.Caption, { children: [
					"Automatically create or reuse the most recent matching codespace.",
					" ",
					jsx(Link, {
						inline: true,
						href: "https://docs.github.com/codespaces/setting-up-your-project-for-codespaces/setting-up-your-repository/facilitating-quick-creation-and-resumption-of-codespaces#creating-a-link-to-resume-a-codespace",
						target: "_blank",
						children: "Read more about creating a link."
					})
				] })
			] })
		});
		const t6 = jsx("div", {
			className: "text-bold mb-1",
			children: "Snippets"
		});
		const t7 = jsx("div", {
			className: "text-small color-fg-muted mb-2",
			children: "Use the following snippets to embed an “Open in Codespaces” button for this configuration in your own page or README."
		});
		const t8 = jsx("div", {
			className: "UnderlineNav mb-2",
			role: "tablist",
			"aria-label": "Snippet format",
			style: { justifyContent: "flex-start" },
			children: tabItems.map((tab) => jsx("button", {
				type: "button",
				role: "tab",
				"aria-selected": activeTab === tab.id,
				"aria-controls": "snippet-tabpanel",
				className: `UnderlineNav-item ${activeTab === tab.id ? "selected" : ""}`,
				onClick: () => setActiveTab(tab.id),
				children: tab.label
			}, tab.id))
		});
		const t9 = snippets[activeTab];
		let t10;
		if ($[10] !== activeTab) {
			t10 = activeTab.toUpperCase();
			$[10] = activeTab;
			$[11] = t10;
		} else t10 = $[11];
		let t11;
		if ($[12] !== activeTab || $[13] !== sendAnalyticsEvent) {
			t11 = () => sendAnalyticsEvent("codespace_share.click", activeTab.toUpperCase());
			$[12] = activeTab;
			$[13] = sendAnalyticsEvent;
			$[14] = t11;
		} else t11 = $[14];
		t3 = jsx(Dialog, {
			title: "Share codespace configuration",
			subtitle: "Choose which settings from this configuration to include when sharing",
			onClose,
			width: "xlarge",
			children: jsxs(Dialog.Body, { children: [
				t5,
				t6,
				t7,
				t8,
				jsxs("div", {
					id: "snippet-tabpanel",
					role: "tabpanel",
					children: [(activeTab === "html" || activeTab === "markdown") && jsx("div", {
						className: "border color-border-muted rounded-2 tmp-p-3 mb-2 d-flex flex-justify-center",
						children: jsx("img", {
							src: badgeUrl,
							alt: "Open in GitHub Codespaces"
						})
					}), jsx(TextInput$1, {
						readOnly: true,
						value: t9,
						"aria-label": `${t10} snippet`,
						block: true,
						trailingAction: jsx(CopyToClipboardButton, {
							textToCopy: snippets[activeTab],
							ariaLabel: "Copy to clipboard",
							onCopy: t11
						})
					})]
				})
			] })
		});
		$[3] = activeTab;
		$[4] = onClose;
		$[5] = quickStart;
		$[6] = sendAnalyticsEvent;
		$[7] = snippets;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
}
ShareDeepLinkDialog.displayName = "ShareDeepLinkDialog";
function ConcurrencyLimitDialog({ isOpen, onClose, manageUrl }) {
	if (!isOpen) return null;
	return /* @__PURE__ */ jsx(Dialog, {
		title: "Maximum running codespaces reached",
		onClose,
		children: /* @__PURE__ */ jsxs(Dialog.Body, { children: [/* @__PURE__ */ jsx("p", { children: "You have too many running codespaces. You'll need to stop some before you start a new codespace." }), /* @__PURE__ */ jsxs(Link, {
			href: manageUrl,
			className: "d-flex flex-items-center flex-justify-between no-underline tmp-mt-3",
			children: [/* @__PURE__ */ jsxs("span", {
				className: "d-flex flex-items-center",
				style: { gap: "var(--base-size-8)" },
				children: [/* @__PURE__ */ jsx(CodespacesIcon, { size: 16 }), "Manage all codespaces"]
			}), /* @__PURE__ */ jsx(ArrowRightIcon, { size: 16 })]
		})] })
	});
}
ConcurrencyLimitDialog.displayName = "ConcurrencyLimitDialog";
function CodespacesCreateButton({ header, createAction }) {
	if (!header.canCreate) return null;
	if (header.disableOneClickCreation) return /* @__PURE__ */ jsx(IconButton, {
		as: "a",
		href: createAction.newWithOptionsUrl,
		target: "_blank",
		rel: "noopener noreferrer",
		icon: PlusIcon,
		"aria-label": "Configure and create a codespace",
		variant: "invisible"
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [createAction.isCreating ? /* @__PURE__ */ jsx("span", {
		className: "d-flex flex-items-center flex-justify-center",
		style: {
			width: 32,
			height: 32
		},
		role: "status",
		"aria-label": "Creating codespace",
		children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
	}) : /* @__PURE__ */ jsx(IconButton, {
		onClick: createAction.handleCreate,
		icon: PlusIcon,
		"aria-label": `Create a codespace on ${createAction.displayCreateRef ?? "default branch"}`,
		variant: "invisible"
	}), /* @__PURE__ */ jsx(ConcurrencyLimitDialog, {
		isOpen: createAction.showConcurrencyDialog,
		onClose: createAction.closeConcurrencyDialog,
		manageUrl: header.manageUrl
	})] });
}
CodespacesCreateButton.displayName = "CodespacesCreateButton";
var GENERIC_CREATE_ERROR = "Could not create a codespace. Try again.";
function resolveCreateRef(fields, createRef) {
	if (fields.pullRequestId != null) return void 0;
	return createRef;
}
function withRefQueryParam(urlString, createRef) {
	if (!createRef) return urlString;
	const url = new URL(urlString, "https://github.local");
	url.searchParams.set("ref", createRef);
	return `${url.pathname}${url.search}${url.hash}`;
}
function buildCreateFormData(fields, resolvedCreateRef) {
	const formData = new FormData();
	if (fields.repositoryId != null) formData.set("codespace[repository_id]", String(fields.repositoryId));
	if (resolvedCreateRef != null) formData.set("codespace[ref]", resolvedCreateRef);
	if (fields.pullRequestId != null) formData.set("codespace[pull_request_id]", String(fields.pullRequestId));
	if (fields.expectedBillableOwnerId != null) formData.set("expected_billable_owner_id", String(fields.expectedBillableOwnerId));
	if (fields.openInDeeplink) formData.set("open_in_deeplink", "true");
	if (fields.devcontainerPath != null) formData.set("codespace[devcontainer_path]", fields.devcontainerPath);
	return formData;
}
async function readCreateResponse(response) {
	try {
		return await response.json();
	} catch {
		return null;
	}
}
function CodespacesHeaderComponent(t0) {
	const { header, createRef, createAction } = t0;
	const newWithOptionsUrl = withRefQueryParam(header.newWithOptionsUrl, createRef);
	const [showShareDialog, setShowShareDialog] = useState(false);
	return jsxs(Fragment$1, { children: [jsxs("div", {
		className: "color-border-muted border-bottom",
		children: [jsxs("div", {
			className: "tmp-p-3 d-flex flex-items-center flex-justify-between",
			children: [jsxs("div", { children: [
				jsx("span", {
					className: "text-bold",
					children: "Codespaces"
				}),
				jsx("br", {}),
				jsx("span", {
					className: "text-small color-fg-subtle",
					children: "Your workspaces in the cloud"
				})
			] }), jsxs("div", {
				className: "d-flex flex-items-center",
				style: { gap: "var(--base-size-4)" },
				children: [jsx(CodespacesCreateButton, {
					header,
					createAction
				}), jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
					icon: KebabHorizontalIcon,
					"aria-label": "Codespace repository configuration",
					variant: "invisible"
				}) }), jsx(ActionMenu.Overlay, {
					align: "end",
					children: jsxs(ActionList, { children: [
						header.canCreate && jsxs(ActionList.LinkItem, {
							href: newWithOptionsUrl,
							target: "_blank",
							rel: "noopener noreferrer",
							children: [jsx(ActionList.LeadingVisual, { children: jsx(PlusIcon, {}) }), "New with options..."]
						}),
						header.configureDevContainerUrl && jsxs(ActionList.LinkItem, {
							href: header.configureDevContainerUrl,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(ContainerIcon, {}) }), "Configure dev container"]
						}),
						header.prebuildsUrl && jsxs(ActionList.LinkItem, {
							href: header.prebuildsUrl,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(ZapIcon, {}) }), "Set up prebuilds"]
						}),
						jsx(ActionList.Divider, {}),
						jsxs(ActionList.LinkItem, {
							href: header.manageUrl,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(CodespacesIcon, {}) }), "Manage codespaces"]
						}),
						header.shareUrl && jsxs(ActionList.Item, {
							onSelect: () => setShowShareDialog(true),
							children: [jsx(ActionList.LeadingVisual, { children: jsx(ShareIcon, {}) }), "Share a deep link"]
						}),
						jsxs(ActionList.LinkItem, {
							href: header.helpUrl,
							children: [jsx(ActionList.LeadingVisual, { children: jsx(QuestionIcon, {}) }), "What are codespaces?"]
						})
					] })
				})] })]
			})]
		}), createAction.createError && jsx(Banner, {
			hideTitle: true,
			title: "Create error",
			variant: "critical",
			layout: "compact",
			description: createAction.createError,
			className: "tmp-mx-3 tmp-mb-3"
		})]
	}), header.shareUrl && jsx(ShareDeepLinkDialog, {
		isOpen: showShareDialog,
		onClose: () => setShowShareDialog(false),
		shareUrl: header.shareUrl
	})] });
}
CodespacesHeaderComponent.displayName = "CodespacesHeaderComponent";
function getExportLabel(codespace) {
	if (codespace.isUnpublished) return "Publish to a new repository";
	if (codespace.needsForkToPush) return "Export changes to a fork";
	return "Export changes to a branch";
}
function getEditorIcon(icon) {
	return icon === "globe" ? GlobeIcon : DeviceDesktopIcon;
}
function useCodespaceActionMenuState(codespace, onActionComplete) {
	const [isStopping, setIsStopping] = useState(false);
	const [autoDeleteEnabled, setAutoDeleteEnabled] = useState(codespace.keepEnabled);
	const { sendAnalyticsEvent } = useAnalytics();
	useEffect(() => {
		setAutoDeleteEnabled(codespace.keepEnabled);
	}, [codespace.id, codespace.keepEnabled]);
	return {
		isStopping,
		autoDeleteEnabled,
		handleStop: useCallback(async () => {
			setIsStopping(true);
			sendAnalyticsEvent("codespace_suspend.click", "CODESPACES_PAGE");
			try {
				if ((await verifiedFetchJSON(codespace.paths.suspend, { method: "POST" })).ok) onActionComplete?.();
			} finally {
				setIsStopping(false);
			}
		}, [
			codespace.paths.suspend,
			onActionComplete,
			sendAnalyticsEvent
		]),
		handleAutoDeleteToggle: useCallback(async (event) => {
			event.preventDefault();
			const newValue = !autoDeleteEnabled;
			setAutoDeleteEnabled(newValue);
			try {
				const response = await verifiedFetch(codespace.paths.codespace, {
					method: "PATCH",
					headers: {
						Accept: "application/json",
						"Content-Type": "application/x-www-form-urlencoded"
					},
					body: new URLSearchParams({ "codespace[keep]": newValue ? "false" : "true" })
				});
				if (!response.ok) throw new Error(`HTTP ${response.status}`);
			} catch {
				setAutoDeleteEnabled(!newValue);
			}
		}, [codespace.paths.codespace, autoDeleteEnabled]),
		sendAnalyticsEvent
	};
}
function CodespaceActionMenu(t0) {
	const $ = c(20);
	const { codespace, showActions, onDeleteClick, onChangeMachineType, onRenameClick, onExportClick, onActionComplete } = t0;
	const { isStopping, autoDeleteEnabled, handleStop, handleAutoDeleteToggle, sendAnalyticsEvent } = useCodespaceActionMenuState(codespace, onActionComplete);
	if (!showActions) return null;
	const exportDisabled = codespace.isFailed || codespace.isBlocking;
	const canOpenInEditors = !codespace.linkDisabled && !codespace.startDisabled;
	let t1;
	if ($[0] !== autoDeleteEnabled || $[1] !== canOpenInEditors || $[2] !== codespace || $[3] !== exportDisabled || $[4] !== handleAutoDeleteToggle || $[5] !== handleStop || $[6] !== isStopping || $[7] !== onChangeMachineType || $[8] !== onDeleteClick || $[9] !== onExportClick || $[10] !== onRenameClick || $[11] !== sendAnalyticsEvent) {
		let t2;
		if ($[13] !== codespace || $[14] !== onRenameClick) {
			t2 = () => onRenameClick(codespace);
			$[13] = codespace;
			$[14] = onRenameClick;
			$[15] = t2;
		} else t2 = $[15];
		let t3;
		if ($[16] !== canOpenInEditors || $[17] !== codespace.blockingOperationText || $[18] !== codespace.isBlocking) {
			t3 = (editor) => {
				const EditorIcon = getEditorIcon(editor.icon);
				if (canOpenInEditors) return jsxs(ActionList.LinkItem, {
					href: editor.url,
					target: "_blank",
					rel: "noopener noreferrer",
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(EditorIcon, {}) }),
						editor.label,
						editor.beta && jsx(ActionList.TrailingVisual, { children: jsx(Label, {
							variant: "success",
							children: "Preview"
						}) })
					]
				}, editor.id);
				return jsxs(ActionList.Item, {
					disabled: true,
					children: [
						jsx(ActionList.LeadingVisual, { children: codespace.isBlocking ? jsx(Spinner, { size: "small" }) : jsx(AlertIcon, {}) }),
						editor.label,
						jsx(ActionList.Description, { children: codespace.isBlocking ? codespace.blockingOperationText : "Start is temporarily disabled" }),
						editor.beta && jsx(ActionList.TrailingVisual, { children: jsx(Label, {
							variant: "success",
							children: "Preview"
						}) })
					]
				}, editor.id);
			};
			$[16] = canOpenInEditors;
			$[17] = codespace.blockingOperationText;
			$[18] = codespace.isBlocking;
			$[19] = t3;
		} else t3 = $[19];
		t1 = jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
			icon: KebabHorizontalIcon,
			"aria-label": `More actions for ${codespace.displayName}`,
			variant: "invisible",
			size: "small"
		}) }), jsx(ActionMenu.Overlay, {
			align: "end",
			children: jsxs(ActionList, { children: [
				jsxs(ActionList.Item, {
					onSelect: t2,
					children: [jsx(ActionList.LeadingVisual, { children: jsx(PencilIcon, {}) }), "Rename"]
				}),
				exportDisabled ? jsxs(ActionList.Item, {
					disabled: true,
					children: [
						jsx(ActionList.LeadingVisual, { children: codespace.isBlocking ? jsx(Spinner, { size: "small" }) : jsx(GitBranchIcon, {}) }),
						getExportLabel(codespace),
						codespace.isBlocking && codespace.blockingOperationText && jsx(ActionList.Description, { children: codespace.blockingOperationText })
					]
				}) : jsxs(ActionList.Item, {
					onSelect: () => onExportClick(codespace),
					children: [jsx(ActionList.LeadingVisual, { children: jsx(GitBranchIcon, {}) }), getExportLabel(codespace)]
				}),
				codespace.allowChangeMachineType && jsxs(ActionList.Item, {
					disabled: codespace.isFailed || codespace.isBlocking,
					onSelect: () => onChangeMachineType(codespace),
					children: [
						jsx(ActionList.LeadingVisual, { children: codespace.isBlocking ? jsx(Spinner, { size: "small" }) : jsx(PencilIcon, {}) }),
						"Change machine type",
						codespace.isBlocking && codespace.blockingOperationText && jsx(ActionList.Description, { children: codespace.blockingOperationText })
					]
				}),
				codespace.suspendable && (codespace.isBlocking || isStopping ? jsxs(ActionList.Item, {
					disabled: true,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(Spinner, { size: "small" }) }),
						jsx("span", { children: isStopping ? "Stopping..." : "Stop codespace" }),
						codespace.blockingOperationText && jsx(ActionList.Description, { children: codespace.blockingOperationText })
					]
				}) : jsxs(ActionList.Item, {
					onSelect: handleStop,
					children: [jsx(ActionList.LeadingVisual, { children: jsx(StopIcon, {}) }), "Stop codespace"]
				})),
				codespace.retentionPeriodDays != null && jsxs(Fragment$1, { children: [jsx(ActionList.Divider, {}), codespace.keepDisabled ? jsxs(ActionList.Item, {
					disabled: true,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(BookmarkIcon, {}) }),
						"Auto-delete codespace",
						jsx(ActionList.Description, { children: "Action disabled by your organization" }),
						jsx(ActionList.TrailingVisual, { children: jsx(CheckIcon, {}) })
					]
				}) : jsxs(ActionList.Item, {
					onSelect: handleAutoDeleteToggle,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(BookmarkIcon, {}) }),
						"Auto-delete codespace",
						autoDeleteEnabled && jsx(ActionList.TrailingVisual, { children: jsx(CheckIcon, {}) })
					]
				})] }),
				jsx(ActionList.Divider, {}),
				codespace.editors.map(t3),
				codespace.deletable && jsxs(Fragment$1, { children: [jsx(ActionList.Divider, {}), jsxs(ActionList.Item, {
					variant: "danger",
					onSelect: () => {
						sendAnalyticsEvent("codespace_destroy.click", "CODESPACES_PAGE");
						onDeleteClick(codespace);
					},
					children: [jsx(ActionList.LeadingVisual, { children: jsx(TrashIcon, {}) }), "Delete"]
				})] })
			] })
		})] });
		$[0] = autoDeleteEnabled;
		$[1] = canOpenInEditors;
		$[2] = codespace;
		$[3] = exportDisabled;
		$[4] = handleAutoDeleteToggle;
		$[5] = handleStop;
		$[6] = isStopping;
		$[7] = onChangeMachineType;
		$[8] = onDeleteClick;
		$[9] = onExportClick;
		$[10] = onRenameClick;
		$[11] = sendAnalyticsEvent;
		$[12] = t1;
	} else t1 = $[12];
	return t1;
}
CodespaceActionMenu.displayName = "CodespaceActionMenu";
function StatusIndicator({ codespace }) {
	if (codespace.needsMachineTypeChange) return /* @__PURE__ */ jsx("span", {
		className: "text-small color-fg-muted",
		children: "Machine type disallowed"
	});
	if (codespace.needsBaseImageChange) return /* @__PURE__ */ jsx("span", {
		className: "text-small color-fg-muted",
		children: "Image disallowed"
	});
	if (codespace.isFailed) return /* @__PURE__ */ jsxs("span", {
		className: "d-flex flex-items-center text-small color-fg-muted",
		children: [/* @__PURE__ */ jsx(DotFillIcon, {
			className: "color-fg-danger",
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsx("span", { children: "Failed" })]
	});
	if (codespace.isBlocking && codespace.blockingOperationText) return /* @__PURE__ */ jsx("span", {
		className: "text-small color-fg-muted",
		children: codespace.blockingOperationText
	});
	if (codespace.isActive) return /* @__PURE__ */ jsxs("span", {
		className: "d-flex flex-items-center text-small color-fg-muted",
		children: [/* @__PURE__ */ jsx(DotFillIcon, {
			className: "color-fg-success",
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsx("span", { children: "Active" })]
	});
	if (codespace.autoDeleteSoon && codespace.retentionExpiresAt) return /* @__PURE__ */ jsxs("span", {
		className: "d-flex flex-items-center text-small color-fg-muted",
		children: [/* @__PURE__ */ jsx(ClockIcon, {
			className: "color-fg-attention mr-1",
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsxs("span", { children: ["Auto-deletes ", /* @__PURE__ */ jsx(RelativeTime, { datetime: codespace.retentionExpiresAt })] })]
	});
	if (codespace.lastUsedAt) return /* @__PURE__ */ jsx("span", {
		className: "text-small color-fg-muted",
		children: /* @__PURE__ */ jsx(RelativeTime, {
			datetime: codespace.lastUsedAt,
			tense: "past",
			format: "micro"
		})
	});
	return null;
}
StatusIndicator.displayName = "StatusIndicator";
function PullRequestInfo({ codespace }) {
	if (!codespace.pullRequest) return null;
	return /* @__PURE__ */ jsxs("span", {
		className: "text-small color-fg-muted",
		children: [
			/* @__PURE__ */ jsx(codespace.pullRequest.state === "merged" ? GitMergeIcon : codespace.pullRequest.state === "closed" ? GitPullRequestClosedIcon : GitPullRequestIcon, {
				size: 14,
				className: "mr-1 v-align-text-top"
			}),
			"#",
			codespace.pullRequest.number
		]
	});
}
PullRequestInfo.displayName = "PullRequestInfo";
function GitStatusText({ codespace }) {
	const commitsText = codespace.commitsAhead > 0 ? `${codespace.commitsAhead} commit${codespace.commitsAhead !== 1 ? "s" : ""} ahead` : null;
	if (commitsText && codespace.hasUncommittedChanges) return /* @__PURE__ */ jsx("span", { children: `${commitsText}, uncommitted changes` });
	if (commitsText) return /* @__PURE__ */ jsx("span", { children: commitsText });
	if (codespace.hasUncommittedChanges) return /* @__PURE__ */ jsx("span", { children: "Uncommitted changes" });
	if (codespace.hasUnpushedChanges) return /* @__PURE__ */ jsx("span", { children: "Unpushed changes" });
	return null;
}
GitStatusText.displayName = "GitStatusText";
function CodespaceItem(t0) {
	const $ = c(12);
	const { codespace, showActions, onDeleteClick, onChangeMachineType, onRenameClick, onExportClick, onActionComplete } = t0;
	const nameId = `codespace-name-${codespace.id}`;
	const linkDisabled = codespace.linkDisabled;
	const displayNameMuted = codespace.isBlocking || codespace.needsMachineTypeChange;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== codespace || $[1] !== displayNameMuted || $[2] !== linkDisabled || $[3] !== nameId || $[4] !== onActionComplete || $[5] !== onChangeMachineType || $[6] !== onDeleteClick || $[7] !== onExportClick || $[8] !== onRenameClick || $[9] !== sendAnalyticsEvent || $[10] !== showActions) {
		t1 = jsx("li", {
			className: "d-flex flex-column",
			children: jsxs("div", {
				className: "flex-1 lh-condensed pt-2 pb-2",
				style: { minWidth: 0 },
				children: [jsxs("div", {
					className: "d-flex flex-wrap flex-items-center",
					children: [
						jsx("div", {
							className: "d-flex mr-2 flex-1",
							children: linkDisabled ? jsx("span", {
								className: "d-block",
								id: nameId,
								children: jsx(Truncate, {
									title: codespace.displayName,
									maxWidth: 250,
									className: `text-bold ${displayNameMuted ? "color-fg-muted" : "color-fg-default"} pb-1`,
									children: codespace.displayName
								})
							}) : jsx(Tooltip$1, {
								text: `Open ${codespace.displayName} in editor`,
								direction: "n",
								type: "description",
								children: jsx("a", {
									className: "d-block p-0 mt-0 color-fg-muted Link--muted no-underline",
									href: codespace.openUrl,
									"data-turbo": "false",
									id: nameId,
									onClick: () => sendAnalyticsEvent("codespace_open.click", "REPO_PAGE_DROPDOWN"),
									children: jsx(Truncate, {
										title: codespace.displayName,
										maxWidth: 250,
										className: `text-bold ${displayNameMuted ? "color-fg-muted" : "color-fg-default"} pb-1`,
										children: codespace.displayName
									})
								})
							})
						}),
						jsx("div", {
							className: "text-small color-fg-muted",
							children: jsx(StatusIndicator, { codespace })
						}),
						jsx("div", {
							className: "ml-1",
							children: jsx(CodespaceActionMenu, {
								codespace,
								showActions,
								onDeleteClick,
								onChangeMachineType,
								onRenameClick,
								onExportClick,
								onActionComplete
							})
						})
					]
				}), jsxs("div", {
					className: "d-flex flex-row flex-wrap flex-items-baseline text-small color-fg-muted",
					style: { gap: "var(--base-size-4) var(--base-size-8)" },
					children: [
						!codespace.isUnpublished && jsxs(Fragment$1, { children: [jsx(BranchName_default, {
							className: "mr-1",
							children: jsx(Truncate, {
								title: codespace.branch,
								maxWidth: 200,
								children: codespace.branch
							})
						}), jsx(GitStatusText, { codespace })] }),
						codespace.pullRequest && jsxs(Fragment$1, { children: [jsx("span", {
							className: "text-small color-fg-muted",
							children: "•"
						}), jsx(PullRequestInfo, { codespace })] }),
						!codespace.pullRequest && codespace.isReadOnly && jsxs(Fragment$1, { children: [jsx("span", {
							className: "text-small color-fg-muted",
							children: "•"
						}), jsx("span", { children: "You don't have push permissions" })] }),
						!codespace.pullRequest && !codespace.isReadOnly && codespace.isForFork && jsxs(Fragment$1, { children: [jsx("span", {
							className: "text-small color-fg-muted",
							children: "•"
						}), jsxs("span", { children: [
							jsx("span", { children: codespace.isOwnersFork ? "From your fork" : "From fork" }),
							" ",
							codespace.forkNwo && jsx("span", {
								className: "text-bold",
								children: codespace.forkNwo
							})
						] })] })
					]
				})]
			})
		});
		$[0] = codespace;
		$[1] = displayNameMuted;
		$[2] = linkDisabled;
		$[3] = nameId;
		$[4] = onActionComplete;
		$[5] = onChangeMachineType;
		$[6] = onDeleteClick;
		$[7] = onExportClick;
		$[8] = onRenameClick;
		$[9] = sendAnalyticsEvent;
		$[10] = showActions;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
CodespaceItem.displayName = "CodespaceItem";
function CodespacesEmptyState({ header, createAction }) {
	return /* @__PURE__ */ jsxs(BlankslateContainer, {
		narrow: true,
		children: [
			/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: "No codespaces" }),
			/* @__PURE__ */ jsx(BlankslateContainer.Description, { children: "You don't have any codespaces with this repository checked out" }),
			header.canCreate && (header.disableOneClickCreation ? /* @__PURE__ */ jsx(BlankslateContainer.PrimaryAction, {
				href: createAction.newWithOptionsUrl,
				children: createAction.label
			}) : /* @__PURE__ */ jsx("div", {
				className: "tmp-mt-4 tmp-mb-3",
				children: /* @__PURE__ */ jsx(ButtonComponent, {
					onClick: createAction.handleCreate,
					variant: "primary",
					disabled: createAction.isCreating,
					children: createAction.isCreating ? "Creating codespace..." : createAction.label
				})
			})),
			/* @__PURE__ */ jsx(BlankslateContainer.SecondaryAction, {
				href: header.helpUrl,
				children: "Learn more about codespaces..."
			})
		]
	});
}
CodespacesEmptyState.displayName = "CodespacesEmptyState";
var CodespacesTabReact_module_default = { CodespaceList: "CodespacesTabReact-module_rqd3yq_CodespaceList" };
function CodespacesSection({ title, codespaces, showActions, onDeleteClick, onChangeMachineType, onRenameClick, onExportClick, onActionComplete }) {
	return /* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsx("h4", {
		className: "text-small color-fg-muted pb-1 mb-0",
		children: title
	}), /* @__PURE__ */ jsx("ul", {
		className: "list-style-none m-0 p-0",
		children: codespaces.map((codespace) => /* @__PURE__ */ jsx(CodespaceItem, {
			codespace,
			showActions,
			onDeleteClick,
			onChangeMachineType,
			onRenameClick,
			onExportClick,
			onActionComplete
		}, codespace.id))
	})] });
}
CodespacesSection.displayName = "CodespacesSection";
function CodespacesList({ data, currentBranchName, createAction, onDeleteClick, onChangeMachineType, onRenameClick, onExportClick, onActionComplete }) {
	const currentBranch = currentBranchName ? data.codespaces.filter((codespace) => codespace.isForCurrentRepository && codespace.branch === currentBranchName) : data.codespaces;
	const otherBranches = currentBranchName ? data.codespaces.filter((codespace) => !codespace.isForCurrentRepository || codespace.branch !== currentBranchName).sort((a, b) => {
		if (a.isForCurrentRepository !== b.isForCurrentRepository) return a.isForCurrentRepository ? -1 : 1;
		return 0;
	}) : [];
	if (data.codespaces.length === 0) return /* @__PURE__ */ jsx(CodespacesEmptyState, {
		header: data.header,
		createAction
	});
	return /* @__PURE__ */ jsxs("div", {
		className: `${CodespacesTabReact_module_default.CodespaceList} overflow-x-auto tmp-p-3`,
		children: [
			(currentBranch.length > 0 || otherBranches.length > 0) && /* @__PURE__ */ jsx(CodespacesSection, {
				title: "On current branch",
				codespaces: currentBranch,
				showActions: data.showActions,
				onDeleteClick,
				onChangeMachineType,
				onRenameClick,
				onExportClick,
				onActionComplete
			}),
			currentBranch.length === 0 && otherBranches.length > 0 && /* @__PURE__ */ jsx(BlankslateContainer, {
				narrow: true,
				children: /* @__PURE__ */ jsx(BlankslateContainer.Description, { children: "No codespaces on current branch" })
			}),
			otherBranches.length > 0 && /* @__PURE__ */ jsx("div", {
				className: "border-top color-border-muted tmp-mt-3 tmp-pt-3",
				children: /* @__PURE__ */ jsx(CodespacesSection, {
					title: "On other branches",
					codespaces: otherBranches,
					showActions: data.showActions,
					onDeleteClick,
					onChangeMachineType,
					onRenameClick,
					onExportClick,
					onActionComplete
				})
			})
		]
	});
}
CodespacesList.displayName = "CodespacesList";
function DeleteCodespaceDialog(t0) {
	const $ = c(9);
	const { codespace, onClose, onDeleted, onDeleteConfirmed, onError } = t0;
	let t1;
	if ($[0] !== codespace || $[1] !== onClose || $[2] !== onDeleteConfirmed || $[3] !== onDeleted || $[4] !== onError) {
		t1 = (gesture) => {
			if (!codespace) return;
			if (gesture === "confirm") {
				onDeleted(codespace);
				onClose();
				(async () => {
					try {
						if (!(await verifiedFetch(codespace.paths.codespace, {
							method: "DELETE",
							headers: { Accept: "application/json" }
						})).ok) onError(codespace);
						else onDeleteConfirmed(codespace);
					} catch {
						onError(codespace);
					}
				})();
			} else onClose();
		};
		$[0] = codespace;
		$[1] = onClose;
		$[2] = onDeleteConfirmed;
		$[3] = onDeleted;
		$[4] = onError;
		$[5] = t1;
	} else t1 = $[5];
	const handleClose = t1;
	if (!codespace) return null;
	let t2;
	if ($[6] !== codespace.deleteConfirmationMessage || $[7] !== handleClose) {
		t2 = jsx(ConfirmationDialog, {
			title: "Are you sure?",
			onClose: handleClose,
			confirmButtonContent: "Delete",
			confirmButtonType: "danger",
			children: codespace.deleteConfirmationMessage
		});
		$[6] = codespace.deleteConfirmationMessage;
		$[7] = handleClose;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
DeleteCodespaceDialog.displayName = "DeleteCodespaceDialog";
function ChangeMachineTypeDialog({ codespace, onClose, onUpdated }) {
	const [skuData, setSkuData] = useState(null);
	const [loading, setLoading] = useState(true);
	const [selectedSku, setSelectedSku] = useState(null);
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState(null);
	useEffect(() => {
		if (!codespace) return;
		let cancelled = false;
		setLoading(true);
		setError(null);
		setSkuData(null);
		setSelectedSku(null);
		setSaving(false);
		const currentCodespace = codespace;
		async function fetchSkus() {
			try {
				const response = await verifiedFetch(currentCodespace.paths.changeMachineType, { headers: { Accept: "application/json" } });
				if (cancelled) return;
				if (!response.ok) throw new Error("Failed to load machine types");
				const data = await response.json();
				setSkuData(data);
				setSelectedSku(data.currentSku);
			} catch {
				if (!cancelled) setError("Failed to load machine types");
			} finally {
				if (!cancelled) setLoading(false);
			}
		}
		fetchSkus();
		return () => {
			cancelled = true;
		};
	}, [codespace]);
	const handleSave = useCallback(async () => {
		if (!codespace || !selectedSku) return;
		setSaving(true);
		setError(null);
		try {
			if (!(await verifiedFetch(codespace.paths.codespace, {
				method: "PATCH",
				headers: {
					Accept: "application/json",
					"Content-Type": "application/x-www-form-urlencoded"
				},
				body: new URLSearchParams({ "codespace[sku_name]": selectedSku })
			})).ok) throw new Error("Failed to update machine type");
			onUpdated();
			onClose();
		} catch {
			setError("Failed to update machine type. Please try again.");
		} finally {
			setSaving(false);
		}
	}, [
		codespace,
		selectedSku,
		onUpdated,
		onClose
	]);
	if (!codespace) return null;
	const hasChanged = selectedSku !== skuData?.currentSku;
	const isSelectedDisabled = skuData?.skus.some((s) => s.name === selectedSku && !s.enabled);
	return /* @__PURE__ */ jsx(Dialog, {
		title: "Change codespace machine type",
		onClose,
		width: "large",
		footerButtons: [{
			content: "Cancel",
			onClick: onClose
		}, {
			content: saving ? "Updating…" : "Update codespace",
			buttonType: "primary",
			onClick: handleSave,
			disabled: !(!saving && !loading && hasChanged && !isSelectedDisabled && !!selectedSku)
		}],
		children: /* @__PURE__ */ jsxs(Dialog.Body, { children: [
			loading && /* @__PURE__ */ jsx("div", {
				className: "d-flex flex-justify-center tmp-p-3",
				children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
			}),
			error && /* @__PURE__ */ jsx(Banner, {
				hideTitle: true,
				title: "Error",
				variant: "critical",
				description: error,
				className: "mb-2"
			}),
			skuData && /* @__PURE__ */ jsxs(RadioGroup_default, {
				name: "sku",
				onChange: (value) => {
					if (value) setSelectedSku(value);
				},
				children: [/* @__PURE__ */ jsx(RadioGroup_default.Label, {
					visuallyHidden: true,
					children: "Machine type"
				}), /* @__PURE__ */ jsx("div", {
					className: "border rounded-2 color-border-muted",
					children: skuData.skus.map((sku, index) => /* @__PURE__ */ jsx("div", {
						className: `tmp-p-3${index > 0 ? " border-top color-border-muted" : ""}`,
						children: /* @__PURE__ */ jsxs(FormControl$1, {
							disabled: !sku.enabled || saving,
							children: [
								/* @__PURE__ */ jsx(Radio, {
									value: sku.name,
									checked: selectedSku === sku.name
								}),
								/* @__PURE__ */ jsxs(FormControl$1.Label, { children: [
									sku.cpus,
									"-core",
									/* @__PURE__ */ jsxs("span", {
										className: "text-small color-fg-muted d-block",
										children: [
											sku.memoryGb,
											"GB RAM · ",
											sku.storageGb,
											"GB"
										]
									})
								] }),
								sku.note && /* @__PURE__ */ jsx(FormControl$1.Caption, { children: sku.note })
							]
						})
					}, sku.name))
				})]
			})
		] })
	});
}
ChangeMachineTypeDialog.displayName = "ChangeMachineTypeDialog";
function RenameCodespaceDialog({ codespace, onClose, onRenamed }) {
	const [displayName, setDisplayName] = useState("");
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState(null);
	useEffect(() => {
		if (codespace) {
			setDisplayName(codespace.displayName ?? "");
			setError(null);
			setSaving(false);
		}
	}, [codespace]);
	const handleSave = useCallback(async () => {
		if (!codespace) return;
		setSaving(true);
		setError(null);
		try {
			if (!(await verifiedFetch(codespace.paths.rename, {
				method: "PATCH",
				headers: {
					Accept: "application/json",
					"Content-Type": "application/x-www-form-urlencoded"
				},
				body: new URLSearchParams({ "codespace[display_name]": displayName })
			})).ok) throw new Error("Failed to rename codespace");
			onRenamed();
			onClose();
		} catch {
			setError("Failed to rename codespace. Please try again.");
		} finally {
			setSaving(false);
		}
	}, [
		codespace,
		displayName,
		onRenamed,
		onClose
	]);
	if (!codespace) return null;
	return /* @__PURE__ */ jsx(Dialog, {
		title: "Rename codespace",
		onClose,
		footerButtons: [{
			content: "Cancel",
			onClick: onClose
		}, {
			content: saving ? "Saving..." : "Save",
			buttonType: "primary",
			onClick: handleSave,
			disabled: saving || !displayName.trim()
		}],
		children: /* @__PURE__ */ jsxs(Dialog.Body, { children: [error && /* @__PURE__ */ jsx(Banner, {
			hideTitle: true,
			title: "Error",
			variant: "critical",
			description: error,
			className: "mb-2"
		}), /* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Display name" }), /* @__PURE__ */ jsx(TextInput$1, {
			value: displayName,
			onChange: (e) => setDisplayName(e.target.value),
			autoFocus: true,
			block: true
		})] })] })
	});
}
RenameCodespaceDialog.displayName = "RenameCodespaceDialog";
var POLL_INITIAL_MS = 1e3;
var POLL_BACKOFF = 1.5;
var POLL_MAX_MS = 5e3;
function getDialogTitle(codespace) {
	if (codespace.isUnpublished) return "Publish to a new repository";
	if (codespace.needsForkToPush) return "Export changes to a fork";
	return "Export changes to a branch";
}
function getCheckingMessage(codespace) {
	if (codespace.isUnpublished) return "Checking repository status";
	if (codespace.needsForkToPush) return "Checking fork status";
	return "Checking branch status";
}
function getSuccessMessage(target) {
	if (target === "repository") return "Your changes have been published to a new repository.";
	if (target === "fork") return "Your changes have been exported to a new fork.";
	return "Your changes have been exported to a new branch.";
}
function getCreateLabel(target) {
	return `Create ${target}`;
}
function getViewLabel(target) {
	return `See ${target}`;
}
function slugifyDisplayName(displayName) {
	return displayName.trim().replace(/\s+/g, "-").slice(0, 100);
}
function ExportCodespaceDialog({ codespace, onClose, onExported }) {
	if (!codespace) return null;
	return /* @__PURE__ */ jsx(ExportCodespaceDialogInner, {
		codespace,
		onClose,
		onExported
	});
}
ExportCodespaceDialog.displayName = "ExportCodespaceDialog";
function ExportCodespaceDialogInner({ codespace, onClose, onExported }) {
	const repository = useCurrentRepository();
	const [state, setState] = useState("checking");
	const [error, setError] = useState(null);
	const [exportControl, setExportControl] = useState(null);
	const [publishName, setPublishName] = useState("");
	const [visibility, setVisibility] = useState("private");
	const pollRef = useRef(null);
	const codespaceRef = useRef(codespace);
	const onExportedRef = useRef(onExported);
	const exportControlRef = useRef(null);
	useEffect(() => {
		codespaceRef.current = codespace;
		onExportedRef.current = onExported;
	}, [codespace, onExported]);
	useEffect(() => {
		exportControlRef.current = exportControl;
	}, [exportControl]);
	useEffect(() => {
		return () => {
			if (pollRef.current) clearTimeout(pollRef.current);
		};
	}, []);
	const fallbackControl = useCallback(() => {
		const exportTarget = codespace.isUnpublished ? "repository" : codespace.needsForkToPush ? "fork" : "branch";
		return {
			exportTarget,
			exportTargetUrl: exportTarget === "branch" ? codespace.exportBranchUrl ?? codespace.paths.codespace : codespace.paths.codespace,
			exportStatus: "exportable",
			existingForkNwo: null
		};
	}, [codespace]);
	const startPolling = useCallback((control) => {
		function poll(delayMs) {
			pollRef.current = setTimeout(async () => {
				const cs = codespaceRef.current;
				if (!cs) return;
				try {
					const response = await verifiedFetchJSON(cs.paths.exported);
					if (response.status === 200) {
						setExportControl(control);
						setState("done");
						onExportedRef.current();
						return;
					}
					if (response.status === 202 || response.status === 404) {
						poll(Math.min(delayMs * POLL_BACKOFF, POLL_MAX_MS));
						return;
					}
					setState("ready");
					setError(response.status === 408 ? "Your codespace export did not complete. Please try again." : "Your codespace does not appear to be exporting. Please try again.");
				} catch {
					setState("ready");
					setError("Failed to check export status.");
				}
			}, delayMs);
		}
		poll(POLL_INITIAL_MS);
	}, []);
	useEffect(() => {
		setState("checking");
		setError(null);
		setExportControl(null);
		setPublishName(slugifyDisplayName(codespace.displayName || codespace.name));
		setVisibility("private");
		let cancelled = false;
		(async () => {
			try {
				const url = new URL(codespace.paths.exportControl, window.location.origin);
				if (codespace.needsForkToPush) url.searchParams.set("needs_fork", "true");
				const response_0 = await verifiedFetchJSON(url.toString());
				if (!response_0.ok) throw new Error("Failed to load export control");
				const control_1 = await response_0.json();
				if (cancelled) return;
				setExportControl(control_1);
				if (control_1.exportStatus === "exporting") {
					setState("exporting");
					startPolling(control_1);
				} else if (control_1.exportStatus === "exported") setState("done");
				else setState("ready");
			} catch {
				if (cancelled) return;
				const control_0 = fallbackControl();
				setExportControl(control_0);
				setState(control_0.exportStatus === "exported" ? "done" : "ready");
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [
		codespace,
		fallbackControl,
		startPolling
	]);
	const handleExport = useCallback(async () => {
		const control_2 = exportControlRef.current ?? fallbackControl();
		setState("exporting");
		setError(null);
		try {
			const url_0 = new URL(codespace.paths.export, window.location.origin);
			if (codespace.needsForkToPush) url_0.searchParams.set("fork", "true");
			if (codespace.isUnpublished) {
				url_0.searchParams.set("name", publishName.trim());
				url_0.searchParams.set("visibility", visibility);
			}
			if ((await verifiedFetchJSON(url_0.toString(), { method: "POST" })).status === 202) startPolling(control_2);
			else {
				setState("ready");
				setError("Failed to start export. Please try again.");
			}
		} catch {
			setState("ready");
			setError("Failed to start export.");
		}
	}, [
		codespace,
		publishName,
		visibility,
		startPolling,
		fallbackControl
	]);
	const target = exportControl?.exportTarget ?? fallbackControl().exportTarget;
	const targetUrl = exportControl?.exportTargetUrl ?? fallbackControl().exportTargetUrl;
	const existingForkNwo = exportControl?.existingForkNwo ?? null;
	const currentRepoNwo = repository?.ownerLogin && repository?.name ? `${repository.ownerLogin}/${repository.name}` : "this repository";
	const canSubmitPublish = publishName.trim().length > 0;
	const closeButton = {
		content: state === "done" ? "Close" : "Cancel",
		onClick: onClose
	};
	const primaryButton = state === "checking" ? {
		content: /* @__PURE__ */ jsxs("span", {
			className: "d-flex flex-items-center",
			style: { gap: "var(--base-size-8)" },
			children: [/* @__PURE__ */ jsx(Spinner, { size: "small" }), /* @__PURE__ */ jsx("span", { children: getCheckingMessage(codespace) })]
		}),
		buttonType: "primary",
		disabled: true,
		onClick: () => {}
	} : state === "done" ? {
		content: getViewLabel(target),
		buttonType: "primary",
		onClick: () => {
			window.open(targetUrl, "_blank");
			onClose();
		}
	} : state === "exporting" ? {
		content: /* @__PURE__ */ jsxs("span", {
			className: "d-flex flex-items-center",
			style: { gap: "var(--base-size-8)" },
			children: [/* @__PURE__ */ jsx(Spinner, { size: "small" }), /* @__PURE__ */ jsx("span", { children: `Creating ${target}...` })]
		}),
		buttonType: "primary",
		disabled: true,
		onClick: () => {}
	} : {
		content: getCreateLabel(target),
		buttonType: "primary",
		onClick: handleExport,
		disabled: codespace.isUnpublished ? !canSubmitPublish : false
	};
	const renderReadyBody = () => {
		if (codespace.isUnpublished) return /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx("p", {
				className: "tmp-mb-3",
				children: "This will create a new repository and push up your work."
			}),
			/* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Name" }), /* @__PURE__ */ jsx(TextInput$1, {
				value: publishName,
				onChange: (e) => setPublishName(e.target.value),
				autoFocus: true,
				block: true,
				maxLength: 100
			})] }),
			/* @__PURE__ */ jsx("div", {
				className: "border-top color-border-muted tmp-mt-3 tmp-pt-3",
				children: /* @__PURE__ */ jsxs(RadioGroup_default, {
					name: "visibility",
					onChange: (value) => {
						if (value === "public" || value === "private") setVisibility(value);
					},
					children: [
						/* @__PURE__ */ jsx(RadioGroup_default.Label, { children: "Visibility" }),
						/* @__PURE__ */ jsxs(FormControl$1, { children: [
							/* @__PURE__ */ jsx(Radio, {
								value: "public",
								checked: visibility === "public"
							}),
							/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Public" }),
							/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Anyone on the internet can see this repository. You choose who can commit." })
						] }),
						/* @__PURE__ */ jsxs(FormControl$1, { children: [
							/* @__PURE__ */ jsx(Radio, {
								value: "private",
								checked: visibility === "private"
							}),
							/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Private" }),
							/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "You choose who can see and commit to this repository." })
						] })
					]
				})
			})
		] });
		if (codespace.needsForkToPush) return existingForkNwo ? /* @__PURE__ */ jsxs("p", { children: [
			"You do not have write access to this codespace's repository. This will reassign your codespace to your existing fork of this repository, ",
			/* @__PURE__ */ jsx("strong", { children: existingForkNwo }),
			", and export your changes to a new branch."
		] }) : /* @__PURE__ */ jsxs("p", { children: [
			"You do not have write access to this codespace's repository. This will create a new fork of",
			" ",
			/* @__PURE__ */ jsx("strong", { children: currentRepoNwo }),
			", reassign your codespace to that fork, and export your changes to a new branch."
		] });
		return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("p", {
			className: "tmp-mb-3",
			children: "This will create a new branch with any unpushed changes"
		}), /* @__PURE__ */ jsxs(BranchName_default, { children: [/* @__PURE__ */ jsx(GitBranchIcon, {
			size: 12,
			className: "v-align-middle"
		}), /* @__PURE__ */ jsx("span", { children: codespace.exportBranchName })] })] });
	};
	return /* @__PURE__ */ jsx(Dialog, {
		title: getDialogTitle(codespace),
		onClose,
		footerButtons: [closeButton, primaryButton],
		children: /* @__PURE__ */ jsxs(Dialog.Body, { children: [error && /* @__PURE__ */ jsx(Banner, {
			hideTitle: true,
			title: "Error",
			variant: "critical",
			description: error,
			className: "tmp-mb-3"
		}), state === "checking" ? /* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-items-center",
			style: { gap: "var(--base-size-8)" },
			children: [/* @__PURE__ */ jsx(Spinner, { size: "small" }), /* @__PURE__ */ jsx("span", { children: getCheckingMessage(codespace) })]
		}) : state === "done" ? /* @__PURE__ */ jsx("p", { children: getSuccessMessage(target) }) : renderReadyBody()] })
	});
}
ExportCodespaceDialogInner.displayName = "ExportCodespaceDialogInner";
var POLL_INTERVAL_MS = 2e3;
var MAX_POLL_ATTEMPTS = 60;
async function pollForVscodeReady(loadingUrl) {
	for (let attempt = 0; attempt < MAX_POLL_ATTEMPTS; attempt++) {
		await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
		const response = await verifiedFetch(loadingUrl, { headers: { Accept: "text/html" } });
		if (response.status === 200) {
			const match = (await response.text()).match(/data-codespace-url="([^"]+)"/);
			if (match?.[1]) return match[1];
			break;
		}
		if (response.status === 503) throw new Error("Codespace failed to provision");
	}
	throw new Error("Codespace provisioning timed out");
}
function getCreateErrorMessage(error) {
	if (error instanceof Error && error.message === "Codespace failed to provision") return error.message;
	if (error instanceof Error && error.message === "Codespace provisioning timed out") return error.message;
	return GENERIC_CREATE_ERROR;
}
function useCodespacesCreateAction(header, createRef, onCreated) {
	const fields = header?.createFormFields;
	const resolvedCreateRef = fields ? resolveCreateRef(fields, createRef) : void 0;
	const displayCreateRef = createRef;
	const label = displayCreateRef ? `Create codespace on ${displayCreateRef}` : "Create codespace";
	const newWithOptionsUrl = header ? withRefQueryParam(header.newWithOptionsUrl, displayCreateRef) : "";
	const [isCreating, setIsCreating] = useState(false);
	const [createError, setCreateError] = useState(null);
	const [showConcurrencyDialog, setShowConcurrencyDialog] = useState(false);
	const { sendAnalyticsEvent } = useAnalytics();
	const fireAnalytics = () => {
		if (!fields) return;
		sendAnalyticsEvent("codespace_create.click", fields.pullRequestId != null ? "PULL_REQUEST_PAGE_DROPDOWN" : "REPO_PAGE_DROPDOWN");
	};
	const handleCreate = async () => {
		if (!header || !fields) return;
		setIsCreating(true);
		setCreateError(null);
		fireAnalytics();
		try {
			const response = await verifiedFetch(header.createPath, {
				method: "POST",
				body: buildCreateFormData(fields, resolvedCreateRef),
				headers: { Accept: "application/json" }
			});
			if (!response.ok) {
				const body = await readCreateResponse(response);
				if (response.status === 422 && body?.error_type === "concurrency_limit_error") {
					setShowConcurrencyDialog(true);
					return;
				}
				setCreateError(body?.error ?? "Could not create a codespace. Try again.");
				return;
			}
			const json = await readCreateResponse(response);
			if (json?.codespace_url) {
				onCreated?.();
				window.open(json.codespace_url, fields.openInDeeplink ? "_self" : "_blank");
				return;
			}
			if (json?.loading_url) {
				const codespaceUrl = await pollForVscodeReady(json.loading_url);
				onCreated?.();
				window.open(codespaceUrl, fields.openInDeeplink ? "_self" : "_blank");
				return;
			}
			setCreateError(GENERIC_CREATE_ERROR);
		} catch (error) {
			setCreateError(getCreateErrorMessage(error));
		} finally {
			setIsCreating(false);
		}
	};
	return {
		displayCreateRef,
		label,
		newWithOptionsUrl,
		isCreating,
		createError,
		showConcurrencyDialog,
		clearCreateError: () => setCreateError(null),
		closeConcurrencyDialog: () => setShowConcurrencyDialog(false),
		handleCreate
	};
}
function CodespacesTabReact(t0) {
	const $ = c(25);
	const { codespacesPath, currentBranchName, createRef } = t0;
	const { data } = useCodespacesData(codespacesPath);
	const invalidate = useInvalidateCodespacesData(codespacesPath);
	const createAction = useCodespacesCreateAction(data?.header, createRef, invalidate);
	const [deletingCodespace, setDeletingCodespace] = useState(null);
	const [changingMachineType, setChangingMachineType] = useState(null);
	const [renamingCodespace, setRenamingCodespace] = useState(null);
	const [exportingCodespace, setExportingCodespace] = useState(null);
	const [optimisticallyRemoved, setOptimisticallyRemoved] = useState(_temp);
	useCodespacesAlive(data?.aliveChannel, codespacesPath);
	let t1;
	if ($[0] !== invalidate) {
		t1 = async (codespace) => {
			await invalidate();
			setOptimisticallyRemoved((prev) => {
				const next = new Set(prev);
				next.delete(codespace.id);
				return next;
			});
		};
		$[0] = invalidate;
		$[1] = t1;
	} else t1 = $[1];
	const handleDeleteSettled = t1;
	const maintenanceNotice = data?.header.maintenanceNotice ?? null;
	const [dismissedMaintenancePath, setDismissedMaintenancePath] = useState(null);
	const maintenanceDismissed = maintenanceNotice !== null && dismissedMaintenancePath === maintenanceNotice.dismissPath;
	let t2;
	if ($[2] !== maintenanceNotice) {
		t2 = async () => {
			if (!maintenanceNotice) return;
			setDismissedMaintenancePath(maintenanceNotice.dismissPath);
			try {
				await verifiedFetchJSON(maintenanceNotice.dismissPath, { method: "POST" });
			} catch {}
		};
		$[2] = maintenanceNotice;
		$[3] = t2;
	} else t2 = $[3];
	const dismissMaintenanceNotice = t2;
	if (!data) return null;
	let t3;
	if ($[4] !== changingMachineType || $[5] !== createAction || $[6] !== createRef || $[7] !== currentBranchName || $[8] !== data || $[9] !== deletingCodespace || $[10] !== dismissMaintenanceNotice || $[11] !== exportingCodespace || $[12] !== handleDeleteSettled || $[13] !== invalidate || $[14] !== maintenanceDismissed || $[15] !== optimisticallyRemoved || $[16] !== renamingCodespace) {
		let t4;
		if ($[18] !== optimisticallyRemoved) {
			t4 = (cs) => !optimisticallyRemoved.has(cs.id);
			$[18] = optimisticallyRemoved;
			$[19] = t4;
		} else t4 = $[19];
		const filteredCodespaces = data.codespaces.filter(t4);
		const filteredData = {
			...data,
			codespaces: filteredCodespaces
		};
		const { header } = filteredData;
		const { createNotice } = header;
		let t5;
		let t6;
		if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
			t5 = () => setDeletingCodespace(null);
			t6 = (codespace_0) => setOptimisticallyRemoved((prev_0) => new Set(prev_0).add(codespace_0.id));
			$[20] = t5;
			$[21] = t6;
		} else {
			t5 = $[20];
			t6 = $[21];
		}
		let t7;
		if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setChangingMachineType(null);
			$[22] = t7;
		} else t7 = $[22];
		let t8;
		if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
			t8 = () => setRenamingCodespace(null);
			$[23] = t8;
		} else t8 = $[23];
		let t9;
		if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
			t9 = () => setExportingCodespace(null);
			$[24] = t9;
		} else t9 = $[24];
		t3 = jsxs("div", {
			className: "width-full",
			children: [
				jsx(CodespacesHeaderComponent, {
					header,
					createRef,
					createAction
				}),
				header.maintenanceNotice && !maintenanceDismissed && jsx(Banner, {
					hideTitle: true,
					title: "Codespaces maintenance notice",
					variant: "warning",
					description: jsxs("span", { children: [
						header.maintenanceNotice.message,
						" ",
						jsx(Link, {
							inline: true,
							href: header.maintenanceNotice.linkUrl,
							children: header.maintenanceNotice.linkText
						}),
						"."
					] }),
					onDismiss: dismissMaintenanceNotice,
					className: "mx-2 mt-2"
				}),
				filteredData.ssoWarning && jsx(Banner, {
					hideTitle: true,
					title: "SSO warning",
					variant: "warning",
					description: filteredData.ssoWarning.message,
					className: "mx-2 mt-2"
				}),
				filteredData.pullRequestWarning && jsx(Banner, {
					hideTitle: true,
					title: "Pull request warning",
					variant: "critical",
					description: jsxs("span", { children: [filteredData.pullRequestWarning.message, filteredData.pullRequestWarning.linkUrl && filteredData.pullRequestWarning.linkText && jsxs(Fragment$1, { children: [
						" You may be able to ",
						jsx(Link, {
							inline: true,
							href: filteredData.pullRequestWarning.linkUrl,
							children: filteredData.pullRequestWarning.linkText
						}),
						"."
					] })] }),
					className: "mx-2 mt-2"
				}),
				createNotice && jsx(Banner, {
					hideTitle: true,
					title: "Create notice",
					variant: "critical",
					description: jsxs("span", { children: [createNotice.message, createNotice.linkUrl && createNotice.linkText && jsxs(Fragment$1, { children: [" ", jsx(Link, {
						inline: true,
						href: createNotice.linkUrl,
						children: createNotice.linkText
					})] })] }),
					className: "mx-2 mt-2"
				}),
				jsx(CodespacesList, {
					data: filteredData,
					currentBranchName,
					createAction,
					onDeleteClick: setDeletingCodespace,
					onChangeMachineType: setChangingMachineType,
					onRenameClick: setRenamingCodespace,
					onExportClick: setExportingCodespace,
					onActionComplete: invalidate
				}),
				!createNotice && header.billableOwnerName && jsxs("div", {
					className: "tmp-p-3 mb-0 text-small color-fg-subtle border-top color-border-muted",
					children: [
						"Codespace usage for this repository is paid for by",
						" ",
						jsx("span", {
							className: "text-bold",
							children: header.billableOwnerName
						}),
						"."
					]
				}),
				jsx(DeleteCodespaceDialog, {
					codespace: deletingCodespace,
					onClose: t5,
					onDeleted: t6,
					onDeleteConfirmed: handleDeleteSettled,
					onError: handleDeleteSettled
				}),
				jsx(ChangeMachineTypeDialog, {
					codespace: changingMachineType,
					onClose: t7,
					onUpdated: invalidate
				}),
				jsx(RenameCodespaceDialog, {
					codespace: renamingCodespace,
					onClose: t8,
					onRenamed: invalidate
				}),
				jsx(ExportCodespaceDialog, {
					codespace: exportingCodespace,
					onClose: t9,
					onExported: invalidate
				})
			]
		});
		$[4] = changingMachineType;
		$[5] = createAction;
		$[6] = createRef;
		$[7] = currentBranchName;
		$[8] = data;
		$[9] = deletingCodespace;
		$[10] = dismissMaintenanceNotice;
		$[11] = exportingCodespace;
		$[12] = handleDeleteSettled;
		$[13] = invalidate;
		$[14] = maintenanceDismissed;
		$[15] = optimisticallyRemoved;
		$[16] = renamingCodespace;
		$[17] = t3;
	} else t3 = $[17];
	return t3;
}
CodespacesTabReact.displayName = "CodespacesTabReact";
function _temp() {
	return /* @__PURE__ */ new Set();
}
export { CodespacesTabReact };
