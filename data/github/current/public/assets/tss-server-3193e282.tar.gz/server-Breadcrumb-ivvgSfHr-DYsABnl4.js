import { Qt as Heading$2, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as useIsDataRouterEnabled } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var Breadcrumb_module_default = {
	container: "Breadcrumb-module_pL74Jq_container",
	directoryLink: "Breadcrumb-module_pL74Jq_directoryLink",
	filename: "Breadcrumb-module_pL74Jq_filename",
	filenameHeading: "Breadcrumb-module_pL74Jq_filenameHeading",
	lg: "Breadcrumb-module_pL74Jq_lg",
	list: "Breadcrumb-module_pL74Jq_list",
	listItem: "Breadcrumb-module_pL74Jq_listItem",
	md: "Breadcrumb-module_pL74Jq_md",
	nav: "Breadcrumb-module_pL74Jq_nav",
	repoLink: "Breadcrumb-module_pL74Jq_repoLink",
	separator: "Breadcrumb-module_pL74Jq_separator"
};
var separatorCharacter = "/";
function Breadcrumb(t0) {
	const $ = c(20);
	const { id: t1, fileNameId, path, repo, commitish, isFolder, size: t2, showCopyPathButton } = t0;
	const id = t1 === void 0 ? "breadcrumb" : t1;
	const size = t2 === void 0 ? "lg" : t2;
	let t3;
	if ($[0] !== path) {
		t3 = getPathSegmentData(path);
		$[0] = path;
		$[1] = t3;
	} else t3 = $[1];
	const { fileName, segments } = t3;
	const isRoot = !path;
	const useRepoNameAsH1 = isFolder && path === "/";
	const sizeClass = size === "md" ? Breadcrumb_module_default.md : Breadcrumb_module_default.lg;
	const t4 = `${Breadcrumb_module_default.container} ${sizeClass}`;
	let t5;
	if ($[2] !== commitish || $[3] !== fileName || $[4] !== fileNameId || $[5] !== id || $[6] !== isFolder || $[7] !== isRoot || $[8] !== path || $[9] !== repo || $[10] !== segments || $[11] !== showCopyPathButton || $[12] !== size || $[13] !== t4 || $[14] !== useRepoNameAsH1) {
		let t6;
		if ($[16] !== commitish || $[17] !== repo || $[18] !== size) {
			t6 = (t7) => {
				const { directoryName, directoryPath } = t7;
				return jsxs("li", {
					className: Breadcrumb_module_default.listItem,
					children: [jsx(Separator, { size }), directoryName ? jsx(DirectoryLink, {
						path: directoryPath,
						directoryName,
						repo,
						commitish
					}) : null]
				}, directoryPath);
			};
			$[16] = commitish;
			$[17] = repo;
			$[18] = size;
			$[19] = t6;
		} else t6 = $[19];
		t5 = jsxs("div", {
			className: t4,
			children: [
				jsxs("nav", {
					"data-testid": "breadcrumbs",
					"aria-labelledby": `${id}-heading`,
					id,
					className: Breadcrumb_module_default.nav,
					children: [jsx(ScreenReaderHeading, {
						id: `${id}-heading`,
						as: "h2",
						text: "Breadcrumbs"
					}), jsxs("ol", {
						className: Breadcrumb_module_default.list,
						children: [jsxs("li", {
							className: Breadcrumb_module_default.listItem,
							children: [jsx(RepoLink, {
								repo,
								commitish
							}), useRepoNameAsH1 && jsx(ScreenReaderHeading, {
								as: "h1",
								text: repo.name
							})]
						}), segments.map(t6)]
					})]
				}),
				fileName && jsxs("div", {
					"data-testid": "breadcrumbs-filename",
					className: Breadcrumb_module_default.filename,
					children: [
						jsx(Separator, { size }),
						jsx(FileName, {
							value: fileName,
							id: fileNameId,
							size
						}),
						!isRoot && isFolder && jsx(Separator, { size })
					]
				}, fileName),
				showCopyPathButton && jsx(CopyToClipboardButton, {
					ariaLabel: "Copy path",
					textToCopy: path,
					tooltipProps: { direction: "nw" },
					size: "small",
					className: "ml-2"
				})
			]
		});
		$[2] = commitish;
		$[3] = fileName;
		$[4] = fileNameId;
		$[5] = id;
		$[6] = isFolder;
		$[7] = isRoot;
		$[8] = path;
		$[9] = repo;
		$[10] = segments;
		$[11] = showCopyPathButton;
		$[12] = size;
		$[13] = t4;
		$[14] = useRepoNameAsH1;
		$[15] = t5;
	} else t5 = $[15];
	return t5;
}
Breadcrumb.displayName = "Breadcrumb";
function RepoLink(t0) {
	const $ = c(4);
	const { repo, commitish } = t0;
	const isDataRouterEnabled = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== commitish || $[1] !== isDataRouterEnabled || $[2] !== repo) {
		t1 = jsx(Link, {
			as: Link$1,
			className: Breadcrumb_module_default.repoLink,
			to: repositoryTreePath({
				repo,
				commitish,
				action: "tree"
			}),
			"data-testid": "breadcrumbs-repo-link",
			reloadDocument: !isDataRouterEnabled,
			children: repo.name
		});
		$[0] = commitish;
		$[1] = isDataRouterEnabled;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
RepoLink.displayName = "RepoLink";
function DirectoryLink({ directoryName, path, repo, commitish }) {
	return /* @__PURE__ */ jsx(Link, {
		as: Link$1,
		to: repositoryTreePath({
			repo,
			commitish,
			path,
			action: "tree"
		}),
		className: Breadcrumb_module_default.directoryLink,
		children: directoryName
	});
}
DirectoryLink.displayName = "DirectoryLink";
function Separator({ size = "lg" }) {
	const sizeClass = size === "md" ? Breadcrumb_module_default.md : Breadcrumb_module_default.lg;
	return /* @__PURE__ */ jsx("span", {
		className: `${Breadcrumb_module_default.separator} ${sizeClass}`,
		"aria-hidden": "true",
		children: "/"
	});
}
Separator.displayName = "Separator";
function FileName({ value, id, size = "lg" }) {
	const sizeClass = size === "md" ? Breadcrumb_module_default.md : Breadcrumb_module_default.lg;
	return /* @__PURE__ */ jsx(Heading$2, {
		as: "h1",
		tabIndex: -1,
		className: `${Breadcrumb_module_default.filenameHeading} ${sizeClass}`,
		id,
		children: value
	});
}
FileName.displayName = "FileName";
function getPathSegmentData(path) {
	const segments = path.split(separatorCharacter);
	return {
		fileName: segments.pop() || "",
		segments: segments.map((segment, i) => ({
			directoryName: segment,
			directoryPath: segments.slice(0, i + 1).join(separatorCharacter)
		}))
	};
}
export { Separator as n, Breadcrumb as t };
