import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Hi as useProvidedRefOrCreate, Mi as XIcon, ar as PlusIcon, n as ActionList, yn as LightBulbIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { b as copilotFeatureFlags } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { C as useChatStateValues, O as usePlugins, b as useChatState, m as getActivePluginFromLocation, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { i as grinIcon, n as frownIcon, o as smileIcon, r as frustratedIcon, t as UserFeedback } from "./server-UserFeedback-kIRVi6Wu-D1dZx8ou.js";
import { createContext, use, useCallback, useEffect, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { flushSync } from "react-dom";
import { c } from "react/compiler-runtime";
var ChatScrollContainer_module_default = { container: "ChatScrollContainer-module_ZmB92W_container" };
var ChatScrollContext = createContext(null);
/**
* Functional container that handles auto-scroll on load and when new messages arrive. Provides context for
* `useChatScroll`.
*/
ChatScrollContext.displayName = "ChatScrollContext";
function ChatScrollContainer({ children, disabled, containerRef: _containerRef, ...props }) {
	const containerRef = useProvidedRefOrCreate(_containerRef);
	const endRef = useRef(null);
	const [isScrolledUp, setIsScrolledUp] = useState(false);
	useEffect(() => {
		const scrollObserver = new IntersectionObserver(([entry]) => setIsScrolledUp(!entry?.isIntersecting), {
			root: containerRef.current,
			threshold: 0,
			rootMargin: "50px"
		});
		scrollObserver.observe(endRef.current);
		return () => scrollObserver.disconnect();
	}, [containerRef]);
	const [scrollContainerHeight, setScrollContainerHeight] = useState();
	useEffect(() => {
		const handleResize = () => {
			if (!containerRef.current) return;
			const computedStyles = getComputedStyle(containerRef.current);
			setScrollContainerHeight(`calc(${containerRef.current.clientHeight}px - ${computedStyles.paddingTop} - ${computedStyles.paddingBottom})`);
		};
		const resizeObserver = new ResizeObserver(handleResize);
		handleResize();
		resizeObserver.observe(containerRef.current);
		return () => resizeObserver.disconnect();
	}, [containerRef]);
	const scrollToBottom = useCallback((behavior) => {
		if (disabled) return;
		endRef.current?.scrollIntoView({
			behavior,
			block: "end"
		});
	}, [disabled]);
	return /* @__PURE__ */ jsx(ChatScrollContext, {
		value: useMemo(() => ({
			isScrolledUp,
			scrollToBottom,
			scrollContainerHeight
		}), [
			isScrolledUp,
			scrollToBottom,
			scrollContainerHeight
		]),
		children: /* @__PURE__ */ jsxs("div", {
			ref: containerRef,
			...props,
			className: clsx(ChatScrollContainer_module_default.container, props.className),
			children: [children, /* @__PURE__ */ jsx("div", {
				ref: endRef,
				style: {
					height: "1px",
					marginTop: "-1px"
				}
			})]
		})
	});
}
/** Get scroll state & controls for the chat scroll container. If used outside of a container, will be a noop. */
ChatScrollContainer.displayName = "ChatScrollContainer";
var useChatScroll = () => {
	const context = use(ChatScrollContext);
	if (!context) throw new Error("useChatScroll may only be called in a descendant of ChatScrollContainer");
	return context;
};
var ChatMessageContext = createContext(void 0);
ChatMessageContext.displayName = "ChatMessageContext";
var ChatMessageProvider = (t0) => {
	const $ = c(5);
	const { message, children } = t0;
	let t1;
	if ($[0] !== message) {
		t1 = { message };
		$[0] = message;
		$[1] = t1;
	} else t1 = $[1];
	const providerData = t1;
	let t2;
	if ($[2] !== children || $[3] !== providerData) {
		t2 = jsx(ChatMessageContext, {
			value: providerData,
			children
		});
		$[2] = children;
		$[3] = providerData;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
ChatMessageProvider.displayName = "ChatMessageProvider";
var useChatMessage = () => {
	const context = use(ChatMessageContext);
	if (!context) throw new Error("useChatMessage must be used with ChatMessageProvider.");
	return context;
};
var InterviewSurveyDialog_module_default = {
	body: "InterviewSurveyDialog-module_BhOGsW_body",
	dialog: "InterviewSurveyDialog-module_BhOGsW_dialog",
	noThanksButton: "InterviewSurveyDialog-module_BhOGsW_noThanksButton",
	primaryText: "InterviewSurveyDialog-module_BhOGsW_primaryText InterviewSurveyDialog-module_BhOGsW_text",
	secondaryText: "InterviewSurveyDialog-module_BhOGsW_secondaryText InterviewSurveyDialog-module_BhOGsW_text",
	surveyLink: "InterviewSurveyDialog-module_BhOGsW_surveyLink",
	text: "InterviewSurveyDialog-module_BhOGsW_text"
};
var imageSrc = "/images/modules/copilot-chat/mona-copilot-hubot-spaceship.png";
var imageSrc2x = "/images/modules/copilot-chat/mona-copilot-hubot-spaceship@2x.png";
function InterviewSurveyDialog(t0) {
	const $ = c(11);
	const { title: t1, onClose, ref } = t0;
	const title = t1 === void 0 ? "Give feedback" : t1;
	const [isOpen, setIsOpen] = useState(false);
	const { currentUserLogin } = useChatStateValues("currentUserLogin");
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => ({ openDialog: () => setIsOpen(true) });
		$[0] = t2;
	} else t2 = $[0];
	useImperativeHandle(ref, t2);
	let t3;
	if ($[1] !== onClose) {
		t3 = (reason) => {
			setIsOpen(false);
			onClose?.(reason);
		};
		$[1] = onClose;
		$[2] = t3;
	} else t3 = $[2];
	const handleClose = t3;
	let t4;
	if ($[3] !== currentUserLogin || $[4] !== handleClose) {
		t4 = () => jsxs("div", {
			className: InterviewSurveyDialog_module_default.body,
			children: [
				jsx("img", {
					alt: "Mona and Copilot flying a Hubot-themed spaceship",
					src: imageSrc,
					srcSet: `${imageSrc2x} 2x`
				}),
				jsx("span", {
					className: InterviewSurveyDialog_module_default.primaryText,
					children: "Would you like to participate in our research?"
				}),
				jsx("span", {
					className: InterviewSurveyDialog_module_default.secondaryText,
					children: "You will be compensated for your time"
				}),
				jsx(LinkButton, {
					variant: "primary",
					className: InterviewSurveyDialog_module_default.surveyLink,
					href: `https://gh.io/copilot-feedback-interview-survey?UID=${encodeURIComponent(currentUserLogin)}`,
					target: "_blank",
					children: "Book a session"
				}),
				jsx(ButtonComponent, {
					variant: "link",
					className: InterviewSurveyDialog_module_default.noThanksButton,
					onClick: () => handleClose("no-thanks"),
					children: "No, thanks"
				})
			]
		});
		$[3] = currentUserLogin;
		$[4] = handleClose;
		$[5] = t4;
	} else t4 = $[5];
	const renderBody = t4;
	let t5;
	if ($[6] !== handleClose || $[7] !== isOpen || $[8] !== renderBody || $[9] !== title) {
		t5 = isOpen && jsx(Dialog, {
			className: InterviewSurveyDialog_module_default.dialog,
			onClose: () => handleClose("close"),
			title,
			renderBody
		});
		$[6] = handleClose;
		$[7] = isOpen;
		$[8] = renderBody;
		$[9] = title;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
}
InterviewSurveyDialog.displayName = "InterviewSurveyDialog";
function useActivePlugin() {
	const $ = c(3);
	const plugins = usePlugins();
	const location = useLocation$1();
	let t0;
	if ($[0] !== location || $[1] !== plugins) {
		t0 = getActivePluginFromLocation(location, plugins);
		$[0] = location;
		$[1] = plugins;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
var ratingOptions = [
	{
		name: "Hate it",
		value: "VERY_NEGATIVE",
		icon: frustratedIcon,
		color: "veryDissatisfied"
	},
	{
		name: "Not great",
		value: "NEGATIVE",
		icon: frownIcon,
		color: "dissatisfied"
	},
	{
		name: "It’s ok",
		value: "POSITIVE",
		icon: smileIcon,
		color: "satisfied"
	},
	{
		name: "Love it",
		value: "VERY_POSITIVE",
		icon: grinIcon,
		color: "verySatisfied"
	}
];
function ConversationFeedbackDialog({ ref, mode, returnFocusRef }) {
	const surveyDialogRef = useRef(null);
	const feedbackDialogRef = useRef(null);
	const initialRatingRef = useRef(void 0);
	useImperativeHandle(ref, () => ({ openDialog: (rating) => {
		initialRatingRef.current = rating;
		if (copilotFeatureFlags.copilotChatInterviewSurvey) surveyDialogRef.current?.openDialog();
		else feedbackDialogRef.current?.openDialog(rating);
	} }));
	const onSubmit = async (rating_0, text) => {
		const errors = [];
		if (rating_0 == null) errors.push("Please select a rating.");
		const limit = 2e3;
		if (text.length > limit) errors.push(`Please keep your feedback within ${limit} characters or less.`);
		if (errors.length > 0) return errors;
		const body = {
			rating: rating_0,
			content: text,
			hostname: window.location.hostname,
			path: window.location.pathname,
			mode
		};
		try {
			if (!(await verifiedFetchJSON("/github-copilot/feedback", {
				method: "POST",
				body
			})).ok) errors.push("An error occurred while submitting your feedback.");
		} catch {
			errors.push("An error occurred while submitting your feedback.");
		}
		return errors;
	};
	const onSurveyClose = (reason) => {
		if (reason === "no-thanks") feedbackDialogRef.current?.openDialog(initialRatingRef.current);
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(InterviewSurveyDialog, {
		ref: surveyDialogRef,
		onClose: onSurveyClose
	}), /* @__PURE__ */ jsx(UserFeedback, {
		ref: feedbackDialogRef,
		options: ratingOptions,
		onSubmit,
		returnFocusRef
	})] });
}
ConversationFeedbackDialog.displayName = "ConversationFeedbackDialog";
ConversationFeedbackDialog.displayName = "ConversationFeedbackDialog";
var PersonalInstructionsDialog_module_default = { footerContainer: "PersonalInstructionsDialog-module_vgtxgG_footerContainer" };
var suggestedPersonalInstructions = {
	Role: {
		tooltip: "Role, domain, style, and focus areas",
		body: `Your role:\n- {role_type} expert in {domain}\n- Focus on {key_skill_area}\n`
	},
	Communication: {
		tooltip: "Language, tone and format",
		body: `Communication:\n- Write in {tone/language}\n- Reference {source_type} documentation\n- Structure responses as {format}\n`
	},
	"Code preferences": {
		tooltip: "Code style, patterns, and conventions",
		body: `Code guidelines:\n- Use {language} conventions\n- Follow {pattern/code_guidelines}\n- Optimize for {goal}\n`
	}
};
function PersonalInstructionsTemplates({ ref, ...props }) {
	const { onSelect } = props;
	const [showTemplates, setShowTemplates] = useState(false);
	const toggleShowTemplates = () => setShowTemplates(!showTemplates);
	return /* @__PURE__ */ jsxs("div", {
		ref,
		className: "d-inline-flex flex-justify-between position-absolute bgColor-default right-0 left-0 bottom-0 ml-2 tmp-mr-3",
		style: { marginBottom: "1px" },
		children: [/* @__PURE__ */ jsx(ActionList, {
			className: "d-inline-flex flex-wrap gap-2 rounded-2",
			children: showTemplates && Object.entries(suggestedPersonalInstructions)?.map(([key, value]) => /* @__PURE__ */ jsxs(ActionList.Item, {
				"aria-label": `${value.tooltip}`,
				className: `mx-0 border fgColor-muted d-inline-block width-auto`,
				onSelect: () => onSelect(key, value.body),
				children: [/* @__PURE__ */ jsx(PlusIcon, {}), key]
			}, key))
		}), /* @__PURE__ */ jsx(ActionList, {
			className: "d-flex flex-column flex-justify-end",
			children: /* @__PURE__ */ jsx(ActionList.Item, {
				"aria-label": showTemplates ? "Hide templates" : "Show templates",
				"data-testid": "toggle-templates",
				className: `fgColor-muted d-inline-block width-auto flex-justify-end mx-0`,
				style: { border: "1px solid transparent" },
				onSelect: toggleShowTemplates,
				children: showTemplates ? /* @__PURE__ */ jsx(XIcon, {}) : /* @__PURE__ */ jsx(LightBulbIcon, {})
			})
		})]
	});
}
PersonalInstructionsTemplates.displayName = "PersonalInstructionsTemplates";
var useElementHeight = (element, t0) => {
	const $ = c(4);
	const wait = t0 === void 0 ? 500 : t0;
	const [height, setHeight] = useState(48);
	let t1;
	let t2;
	if ($[0] !== element || $[1] !== wait) {
		t1 = () => {
			const handleResize = debounce(() => {
				if (element?.current) setHeight(element.current.clientHeight ?? 48);
			}, wait);
			const resizeObserver = new ResizeObserver(handleResize);
			if (element?.current) resizeObserver.observe(element.current);
			return () => {
				handleResize.cancel();
				resizeObserver?.disconnect?.();
			};
		};
		t2 = [element, wait];
		$[0] = element;
		$[1] = wait;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	return height;
};
var PersonalInstructionsDialog = ({ onDismiss, returnFocusRef }) => {
	const state = useChatState();
	const manager = useChatManager();
	const [prompt, setPrompt] = useState(state.personalInstructions ?? "");
	const [errorMessage, setErrorMessage] = useState(void 0);
	const [isSaving, setIsSaving] = useState(false);
	const maxCharLimit = 4e3;
	const textAreaRef = useRef(null);
	const actionListRef = useRef(null);
	const [lastSelectedTemplate, setLastSelectedTemplate] = useState("");
	const templatesHeight = useElementHeight(actionListRef);
	useLayoutEffect(() => {
		if (textAreaRef?.current) textAreaRef.current.scrollTop = textAreaRef.current.scrollHeight;
	}, [prompt]);
	const savePersonalInstructions = useCallback(async () => {
		if (isSaving) return;
		setIsSaving(true);
		if (lastSelectedTemplate) sendEvent("copilot_personal_instruction_template_usage", { content: lastSelectedTemplate });
		try {
			const resp = await verifiedFetchJSON("/copilot/personal_instructions", {
				method: "POST",
				body: { prompt }
			});
			if (resp.ok) {
				sendEvent("dotcom_chat.activate", {
					target: "PERSONAL_INSTRUCTIONS_SAVE",
					mode: "immersive"
				});
				manager.dispatch({
					type: "SET_PERSONAL_INSTRUCTIONS",
					personalInstructions: prompt
				});
				flushSync(() => onDismiss());
			} else {
				const errorData = await resp.json();
				setErrorMessage(String(errorData.errorMessage));
			}
		} catch {
			setErrorMessage("An error occurred while saving your personal instructions.");
		} finally {
			setIsSaving(false);
		}
	}, [
		isSaving,
		prompt,
		manager,
		onDismiss,
		lastSelectedTemplate
	]);
	const appendPrompt = (templateName, template) => {
		if (!template) return;
		setPrompt(prompt ? `${prompt}\n${template}` : template);
		setLastSelectedTemplate(templateName);
		textAreaRef?.current?.focus();
	};
	const onSubmit = () => {
		savePersonalInstructions();
	};
	const handleDismiss = useCallback(() => {
		sendEvent("dotcom_chat.dismiss", {
			target: "PERSONAL_INSTRUCTIONS_DISMISS",
			mode: "immersive"
		});
		flushSync(() => onDismiss());
	}, [onDismiss]);
	return /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx(Dialog, {
		onClose: handleDismiss,
		title: "Personal instructions",
		subtitle: "Set up Copilot to align with your workflows and preferences. These instructions will only impact your personal conversation.",
		width: "large",
		returnFocusRef,
		renderBody: () => /* @__PURE__ */ jsx(Dialog.Body, { children: /* @__PURE__ */ jsx("form", {
			onSubmit: savePersonalInstructions,
			children: /* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, {
					visuallyHidden: true,
					children: "Instructions"
				}),
				/* @__PURE__ */ jsx("div", {
					className: "width-full position-relative",
					children: /* @__PURE__ */ jsxs(ScopedCommands, {
						commands: { "github:submit-form": onSubmit },
						children: [/* @__PURE__ */ jsx(Textarea, {
							ref: textAreaRef,
							className: "width-full",
							style: { paddingBottom: `${templatesHeight}px` },
							"aria-label": "Prompt",
							rows: 7,
							name: "prompt",
							placeholder: "Your instructions",
							value: prompt,
							validationStatus: errorMessage || prompt.length > maxCharLimit ? "error" : void 0,
							...testIdProps("prompt-input"),
							onChange: (e) => {
								setPrompt(e.target.value);
								setErrorMessage(void 0);
							}
						}), /* @__PURE__ */ jsx(PersonalInstructionsTemplates, {
							ref: actionListRef,
							onSelect: appendPrompt
						})]
					})
				}),
				/* @__PURE__ */ jsx(CharacterCount, {
					text: prompt,
					promptCharLimit: maxCharLimit
				}),
				errorMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: /* @__PURE__ */ jsx("span", {
						...testIdProps("error-message"),
						children: errorMessage
					})
				})
			] })
		}) }),
		renderFooter: () => /* @__PURE__ */ jsxs("div", {
			className: PersonalInstructionsDialog_module_default.footerContainer,
			children: [/* @__PURE__ */ jsx(ButtonComponent, {
				variant: "default",
				onClick: handleDismiss,
				children: "Cancel"
			}), /* @__PURE__ */ jsx(ButtonComponent, {
				loading: isSaving,
				loadingAnnouncement: "Saving personal instructions",
				variant: "primary",
				onClick: savePersonalInstructions,
				children: "Save"
			})]
		})
	}) });
};
PersonalInstructionsDialog.displayName = "PersonalInstructionsDialog";
function CharacterCount({ text, promptCharLimit }) {
	const currentCount = /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("span", {
			className: "text-tabular-nums",
			...testIdProps("current-character-count"),
			children: text.length
		}),
		" ",
		"/ ",
		promptCharLimit,
		" characters"
	] });
	return /* @__PURE__ */ jsx(Fragment$1, { children: text.length > promptCharLimit ? /* @__PURE__ */ jsx(FormControl$1.Validation, {
		variant: "error",
		children: currentCount
	}) : /* @__PURE__ */ jsx(FormControl$1.Caption, { children: currentCount }) });
}
CharacterCount.displayName = "CharacterCount";
export { PersonalInstructionsDialog as a, useChatScroll as c, InterviewSurveyDialog as i, ChatScrollContainer as n, useActivePlugin as o, ConversationFeedbackDialog as r, useChatMessage as s, ChatMessageProvider as t };
