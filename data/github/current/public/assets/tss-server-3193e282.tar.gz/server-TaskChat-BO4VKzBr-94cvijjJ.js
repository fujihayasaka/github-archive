performance.mark("js-parse-end:server-TaskChat-BO4VKzBr-94cvijjJ.js");
import { k as TaskChat } from "./server-TaskChat-CtDXk6Za-BcxdUxem.js";
performance.mark("js-parse-end:TaskChat-BO4VKzBr.js");
export { TaskChat };
