import { t as SOFT_NAV_STATE } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import memoize from "@github/memoize";
import { useEffect, useState } from "react";
import { c } from "react/compiler-runtime";
async function fetchJSON(url) {
	const response = await verifiedFetchJSON(url);
	if (response.ok) return await response.json();
	else return;
}
var memoizeCache = /* @__PURE__ */ new Map();
var memoizeFetchJSON = memoize(fetchJSON, { cache: memoizeCache });
function resetMemoizeFetchJSON() {
	memoizeCache.clear();
}
/**
* Retrieve information of latest commit of current blob or ref and path
* If we have a current blob payload and it has latest commit, it will be returned immediately
* Otherwise, we will fetch the latest commit from the server with the ref and path
* Tree commits are always fetched from the server using the ref and path
*
* returns an array with latest commit, loading state and error
* while loading returns [undefined, true, false]
* if cannot retrieve latest commit, returns [undefined, false, true]
*/
function useLatestCommit(repoOwner, repoName, commitish, path) {
	const $ = c(15);
	const [latestCommit, setLatestCommit] = useState();
	const [error, setError] = useState(false);
	const [loading, setLoading] = useState(true);
	let t0;
	if ($[0] !== commitish || $[1] !== path || $[2] !== repoName || $[3] !== repoOwner) {
		t0 = repoName && repoOwner && commitish && path ? repositoryTreePath({
			repo: {
				name: repoName,
				ownerLogin: repoOwner
			},
			commitish,
			action: "latest-commit",
			path
		}) : null;
		$[0] = commitish;
		$[1] = path;
		$[2] = repoName;
		$[3] = repoOwner;
		$[4] = t0;
	} else t0 = $[4];
	const commitInfoPath = t0;
	let t1;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[5] = t1;
	} else t1 = $[5];
	useEffect(_temp, t1);
	let t2;
	if ($[6] !== commitInfoPath) {
		t2 = () => {
			let cancelled = false;
			const update = async () => {
				if (!commitInfoPath) return;
				setError(false);
				setLoading(true);
				setLatestCommit(void 0);
				const commit = await memoizeFetchJSON(commitInfoPath);
				if (cancelled) return;
				try {
					if (commit) setLatestCommit(commit);
					else setError(true);
				} catch {
					setError(true);
				}
				setLoading(false);
			};
			update();
			return function cancel() {
				cancelled = true;
			};
		};
		$[6] = commitInfoPath;
		$[7] = t2;
	} else t2 = $[7];
	let t3;
	if ($[8] !== commitInfoPath || $[9] !== commitish) {
		t3 = [commitInfoPath, commitish];
		$[8] = commitInfoPath;
		$[9] = commitish;
		$[10] = t3;
	} else t3 = $[10];
	useEffect(t2, t3);
	let t4;
	if ($[11] !== error || $[12] !== latestCommit || $[13] !== loading) {
		t4 = [
			latestCommit,
			loading,
			error
		];
		$[11] = error;
		$[12] = latestCommit;
		$[13] = loading;
		$[14] = t4;
	} else t4 = $[14];
	return t4;
}
function _temp() {
	const abortController = new AbortController();
	document.addEventListener(SOFT_NAV_STATE.START, resetMemoizeFetchJSON, { signal: abortController.signal });
	return () => {
		abortController.abort();
	};
}
export { useLatestCommit as n, resetMemoizeFetchJSON as t };
