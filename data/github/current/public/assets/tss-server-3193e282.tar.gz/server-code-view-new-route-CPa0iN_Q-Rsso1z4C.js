import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewNewRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewNewRoute", {
	path: "/:owner/:repo/new/:branch/*",
	queries: [mainQuery({ encodeFetchPath: true })]
});
export { codeViewNewRoute as t };
