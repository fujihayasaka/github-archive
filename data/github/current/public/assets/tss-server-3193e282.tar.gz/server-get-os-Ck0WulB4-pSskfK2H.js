import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
var OS = {
	Android: "Android",
	iOS: "iOS",
	macOS: "macOS",
	Windows: "Windows",
	Linux: "Linux",
	Unknown: "Unknown"
};
function getOS() {
	let os = OS.Unknown;
	let isMobileOS = false;
	if (ssrSafeWindow) {
		const navigator = ssrSafeWindow.navigator;
		let userAgent = "";
		try {
			userAgent = navigator.userAgent;
		} catch {}
		let platform = "";
		try {
			platform = navigator?.userAgentData?.platform || navigator.platform;
		} catch {}
		const macosPlatforms = [
			"Macintosh",
			"MacIntel",
			"MacPPC",
			"Mac68K",
			"macOS"
		];
		const windowsPlatforms = [
			"Win32",
			"Win64",
			"Windows",
			"WinCE"
		];
		const iosPlatforms = [
			"iPhone",
			"iPad",
			"iPod"
		];
		if (macosPlatforms.indexOf(platform) !== -1) os = OS.macOS;
		else if (iosPlatforms.indexOf(platform) !== -1) os = OS.iOS;
		else if (windowsPlatforms.indexOf(platform) !== -1) os = OS.Windows;
		else if (/Android/.test(userAgent)) os = OS.Android;
		else if (/Linux/.test(platform)) os = OS.Linux;
		isMobileOS = navigator?.userAgentData?.mobile ?? (os === OS.Android || os === OS.iOS);
	}
	return {
		os,
		isAndroid: os === OS.Android,
		isIOS: os === OS.iOS,
		isMacOS: os === OS.macOS,
		isWindows: os === OS.Windows,
		isLinux: os === OS.Linux,
		isDesktop: os === OS.macOS || os === OS.Windows || os === OS.Linux,
		isMobile: isMobileOS
	};
}
function isMobile() {
	return getOS().isMobile;
}
function isMacOS() {
	return getOS().isMacOS;
}
export { isMobile as n, isMacOS as t };
