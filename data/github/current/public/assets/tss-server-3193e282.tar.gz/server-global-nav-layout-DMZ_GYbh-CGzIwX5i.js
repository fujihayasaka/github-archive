performance.mark("js-parse-end:server-global-nav-layout-DMZ_GYbh-CGzIwX5i.js");
import { o as setCopilotApiOverrideUrl } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:global-nav-layout-DMZ_GYbh.js");
var globalNavLayoutLoader_createServerFn_handler = createServerRpc({
	id: "97b2c57eea454ae235ed19f793122279887e262457fa282a73f7366119742801",
	name: "globalNavLayoutLoader",
	filename: "src/routes/root/global-nav-layout.tsx"
}, (opts) => globalNavLayoutLoader.__executeServer(opts));
var globalNavLayoutLoader = createServerFn().handler(globalNavLayoutLoader_createServerFn_handler, async () => {
	try {
		const { payload: json } = await fetchDataRouterMainQuery({
			path: "/_shell/layout",
			service: "dotcom"
		}, "appShellLayoutRoute");
		const copilotApiUrl = json.globalNavigation?.copilot?.copilotApiUrl;
		setCopilotApiOverrideUrl(copilotApiUrl);
		return json;
	} catch {
		console.warn("Using mock global nav layout data");
		return mockPayload;
	}
});
var mockPayload = {
	globalNavigation: {
		userMenu: { owner: {
			login: "monalisa",
			name: "Mona Lisa",
			avatarUrl: "/u/2"
		} },
		headerLogo: {
			href: "/",
			hotkey: "g d",
			"aria-label": "Homepage "
		},
		issues: {
			href: "/issues",
			hotkey: "g i"
		},
		pulls: {
			href: "/pulls",
			hotkey: "g p"
		},
		contributedRepos: { show: false },
		copilot: {
			show: true,
			showAgentsButton: false
		},
		search: {
			show: true,
			searchHotkey: "s,/",
			showCommandPalette: false,
			isSearchPage: false
		},
		enterpriseBanner: { show: false }
	},
	globalBanners: { flashMessages: [] }
};
export { globalNavLayoutLoader_createServerFn_handler };
