var FETCH_NONCE_HEADER = "X-Fetch-Nonce";
var FETCH_NONCE_TO_VALIDATE_HEADER = "X-Fetch-Nonce-To-Validate";
var fetchNonces = /* @__PURE__ */ new Set();
function getFetchNonce() {
	return fetchNonces.values().next().value || "";
}
function getFetchNonceHeaders(nonceToValidate) {
	const headers = {};
	if (nonceToValidate !== void 0) headers[FETCH_NONCE_TO_VALIDATE_HEADER] = nonceToValidate;
	if (nonceToValidate === void 0) headers[FETCH_NONCE_HEADER] = getFetchNonce();
	else if (fetchNonces.has(nonceToValidate)) headers[FETCH_NONCE_HEADER] = nonceToValidate;
	else headers[FETCH_NONCE_HEADER] = Array.from(fetchNonces).join(",");
	return headers;
}
export { getFetchNonce as n, getFetchNonceHeaders as r, FETCH_NONCE_HEADER as t };
