performance.mark("js-parse-end:server-GlobalSsoBanner-DmRvabMe-BzVFNYw3.js");
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { bn as Link, hi as TriangleDownIcon, n as ActionList, qr as Stack } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { f as sendStats } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as ANALYTICS_CATEGORY } from "./server-constants-xMVBIU7B-COI4NwYP.js";
import { i as storeDismissedOrgIds, n as getDefaultDurationIndex, t as DISMISSAL_DURATION_OPTIONS } from "./server-cookie-fghC_FiA-DZjQG69M.js";
import { t as CoreSsoBanner } from "./server-CoreSsoBanner-BLGiDntO-CUANB3R8.js";
import { t as generateSSOUrl } from "./server-generate-sso-url-dCuQbgAx-DWoF3ZxN.js";
import React from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:GlobalSsoBanner-DmRvabMe.js");
var GlobalSSOBanner_module_default = {
	bannerInnerWrapper: "GlobalSSOBanner-module_FMi-Iq_bannerInnerWrapper",
	bannerOuterWrapper: "GlobalSSOBanner-module_FMi-Iq_bannerOuterWrapper",
	dismissedOrgList: "GlobalSSOBanner-module_FMi-Iq_dismissedOrgList",
	durationSelector: "GlobalSSOBanner-module_FMi-Iq_durationSelector"
};
function DismissalSummary({ ssoOrgs }) {
	if (ssoOrgs.length === 1) {
		const org = ssoOrgs[0];
		return /* @__PURE__ */ jsxs("p", { children: [
			"You are dismissing single sign-on prompts for the ",
			org?.name,
			" organization on this device."
		] });
	}
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("p", { children: "You are dismissing single sign-on prompts for the following organizations on this device:" }), /* @__PURE__ */ jsx("ul", {
		className: GlobalSSOBanner_module_default.dismissedOrgList,
		children: ssoOrgs.map((org) => /* @__PURE__ */ jsx("li", { children: org.name }, org.id))
	})] });
}
DismissalSummary.displayName = "DismissalSummary";
function DurationMenu({ selectedDurationIndex, onDurationChange }) {
	const selectedDuration = DISMISSAL_DURATION_OPTIONS[selectedDurationIndex];
	return /* @__PURE__ */ jsxs(Stack, {
		align: "center",
		direction: "horizontal",
		className: GlobalSSOBanner_module_default.durationSelector,
		children: [/* @__PURE__ */ jsx("span", {
			id: "dismissal-duration-label",
			children: "Remind me again in"
		}), /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Button, {
			trailingAction: TriangleDownIcon,
			"aria-labelledby": "dismissal-duration-label",
			children: selectedDuration?.text || "Pick duration"
		}), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, {
			selectionVariant: "single",
			role: "menu",
			"aria-labelledby": "dismissal-duration-label",
			children: DISMISSAL_DURATION_OPTIONS.map((option, index) => /* @__PURE__ */ jsx(ActionList.Item, {
				role: "menuitemradio",
				selected: index === selectedDurationIndex,
				"aria-checked": index === selectedDurationIndex,
				onSelect: () => onDurationChange(index),
				children: option.text
			}, option.id))
		}) })] })]
	});
}
DurationMenu.displayName = "DurationMenu";
function ConfirmationDialog(t0) {
	const $ = c(11);
	const { isOpen, onClose, onConfirm, ssoOrgs } = t0;
	const [selectedDurationIndex, setSelectedDurationIndex] = React.useState(getDefaultDurationIndex);
	let t1;
	let t2;
	if ($[0] !== isOpen) {
		t1 = () => {
			if (isOpen) setSelectedDurationIndex(getDefaultDurationIndex());
		};
		t2 = [isOpen];
		$[0] = isOpen;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	React.useEffect(t1, t2);
	let t3;
	if ($[3] !== onConfirm || $[4] !== selectedDurationIndex) {
		t3 = () => {
			const selectedDuration = DISMISSAL_DURATION_OPTIONS[selectedDurationIndex];
			onConfirm(selectedDuration?.days ?? 30);
		};
		$[3] = onConfirm;
		$[4] = selectedDurationIndex;
		$[5] = t3;
	} else t3 = $[5];
	const handleConfirm = t3;
	if (!isOpen) return null;
	let t4;
	if ($[6] !== handleConfirm || $[7] !== onClose || $[8] !== selectedDurationIndex || $[9] !== ssoOrgs) {
		t4 = jsxs(Dialog, {
			title: "Dismiss SSO Banner",
			width: "medium",
			height: "auto",
			onClose,
			footerButtons: [{
				buttonType: "default",
				content: "Cancel",
				onClick: onClose
			}, {
				buttonType: "primary",
				content: "Confirm",
				onClick: handleConfirm
			}],
			children: [
				jsx(DismissalSummary, { ssoOrgs }),
				jsx(DurationMenu, {
					selectedDurationIndex,
					onDurationChange: setSelectedDurationIndex
				}),
				jsxs("p", { children: [
					"To sign into any of your SSO organizations, visit the",
					" ",
					jsx(Link, {
						href: "/settings/organizations",
						inline: true,
						children: "SSO settings page."
					})
				] })
			]
		});
		$[6] = handleConfirm;
		$[7] = onClose;
		$[8] = selectedDurationIndex;
		$[9] = ssoOrgs;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
ConfirmationDialog.displayName = "ConfirmationDialog";
var ANIMATION_DURATION = 300;
function SlideDismiss({ children, hidden }) {
	const [visibilityState, setVisibilityState] = React.useState("visible");
	const outerWrapperRef = React.useRef(null);
	const bannerHeightRef = React.useRef(void 0);
	React.useEffect(() => {
		if (hidden && visibilityState === "visible") {
			setVisibilityState("collapsing");
			const wrapper = outerWrapperRef.current;
			if (wrapper) {
				const height = wrapper.getBoundingClientRect().height;
				bannerHeightRef.current = height;
				wrapper.style.height = `${height}px`;
			}
		} else if (visibilityState === "collapsing") {
			const timer = setTimeout(() => {
				setVisibilityState("hidden");
			}, ANIMATION_DURATION);
			return () => {
				clearTimeout(timer);
			};
		}
	}, [hidden, visibilityState]);
	if (visibilityState === "hidden") return null;
	return /* @__PURE__ */ jsx("div", {
		ref: outerWrapperRef,
		style: { height: visibilityState === "visible" ? bannerHeightRef.current ?? "auto" : 0 },
		className: GlobalSSOBanner_module_default.bannerOuterWrapper,
		children: /* @__PURE__ */ jsx("div", {
			className: GlobalSSOBanner_module_default.bannerInnerWrapper,
			style: { transform: visibilityState === "visible" ? void 0 : `translateY(-${bannerHeightRef.current ?? 0}px)` },
			children
		})
	});
}
SlideDismiss.displayName = "SlideDismiss";
function SSOActionMenu(t0) {
	const $ = c(15);
	const { ssoOrgs, redirectLocation } = t0;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	if (ssoOrgs.length === 0) return null;
	let t1;
	if ($[0] !== sendClickAnalyticsEvent) {
		t1 = () => {
			sendClickAnalyticsEvent({
				category: ANALYTICS_CATEGORY,
				action: "click_single_sso_button",
				label: "sso_authentication"
			});
		};
		$[0] = sendClickAnalyticsEvent;
		$[1] = t1;
	} else t1 = $[1];
	const handleSingleSsoClick = t1;
	let t2;
	if ($[2] !== sendClickAnalyticsEvent) {
		t2 = (orgName) => {
			sendClickAnalyticsEvent({
				category: ANALYTICS_CATEGORY,
				action: "click_sso_dropdown_item",
				label: `org:${orgName}`
			});
		};
		$[2] = sendClickAnalyticsEvent;
		$[3] = t2;
	} else t2 = $[3];
	const handleSsoDropdownItemClick = t2;
	if (ssoOrgs.length === 1) {
		const org = ssoOrgs[0];
		if (org === void 0) return null;
		let t3;
		if ($[4] !== handleSingleSsoClick || $[5] !== org.login || $[6] !== redirectLocation) {
			t3 = jsx(ButtonComponent, {
				as: "a",
				href: generateSSOUrl(org.login, redirectLocation),
				onClick: handleSingleSsoClick,
				children: "Single sign-on"
			});
			$[4] = handleSingleSsoClick;
			$[5] = org.login;
			$[6] = redirectLocation;
			$[7] = t3;
		} else t3 = $[7];
		return t3;
	}
	let t3;
	if ($[8] !== handleSsoDropdownItemClick || $[9] !== redirectLocation || $[10] !== ssoOrgs) {
		let t4;
		if ($[12] !== handleSsoDropdownItemClick || $[13] !== redirectLocation) {
			t4 = (org_0) => jsxs(ActionList.LinkItem, {
				href: generateSSOUrl(org_0.login, redirectLocation),
				onClick: () => handleSsoDropdownItemClick(org_0.name),
				children: [org_0.avatar_url && jsx(ActionList.LeadingVisual, { children: jsx(GitHubAvatar, {
					square: true,
					size: 20,
					src: org_0.avatar_url
				}) }), org_0.name]
			}, org_0.login);
			$[12] = handleSsoDropdownItemClick;
			$[13] = redirectLocation;
			$[14] = t4;
		} else t4 = $[14];
		t3 = jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
			size: "small",
			children: "Single sign-on"
		}), jsx(ActionMenu.Overlay, { children: jsx(ActionList, { children: ssoOrgs.map(t4) }) })] });
		$[8] = handleSsoDropdownItemClick;
		$[9] = redirectLocation;
		$[10] = ssoOrgs;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
SSOActionMenu.displayName = "SSOActionMenu";
function GlobalSsoBanner(t0) {
	const $ = c(19);
	const { ssoOrgs, onConfirm } = t0;
	const location = useLocation$1();
	const [bannerState, setBannerState] = React.useState("visible");
	const [dialogIsOpen, setDialogIsOpen] = React.useState(false);
	const hasSentMetricRef = React.useRef(false);
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t1;
	if ($[0] !== ssoOrgs.length) {
		t1 = () => {
			if (!hasSentMetricRef.current && ssoOrgs.length > 0) {
				sendStats({
					incrementKey: "GLOBAL_SSO_BANNER_DISPLAYED",
					requestUrl: window.location.href
				});
				hasSentMetricRef.current = true;
			}
		};
		$[0] = ssoOrgs.length;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== ssoOrgs) {
		t2 = [ssoOrgs];
		$[2] = ssoOrgs;
		$[3] = t2;
	} else t2 = $[3];
	React.useEffect(t1, t2);
	if (ssoOrgs.length === 0) return null;
	let t3;
	if ($[4] !== ssoOrgs) {
		t3 = (t4) => {
			const durationDays = t4 === void 0 ? 30 : t4;
			setBannerState("hidden");
			storeDismissedOrgIds(ssoOrgs, durationDays);
		};
		$[4] = ssoOrgs;
		$[5] = t3;
	} else t3 = $[5];
	const dismissSsoOrganizations = t3;
	let t4;
	if ($[6] !== sendClickAnalyticsEvent) {
		t4 = () => {
			sendClickAnalyticsEvent({
				category: ANALYTICS_CATEGORY,
				action: "click_dismiss_button",
				label: "banner_dismissed"
			});
			setDialogIsOpen(true);
		};
		$[6] = sendClickAnalyticsEvent;
		$[7] = t4;
	} else t4 = $[7];
	const handleDismiss = t4;
	let t5;
	if ($[8] !== dismissSsoOrganizations || $[9] !== onConfirm) {
		t5 = (durationDays_0) => {
			onConfirm?.();
			dismissSsoOrganizations(durationDays_0);
			setDialogIsOpen(false);
		};
		$[8] = dismissSsoOrganizations;
		$[9] = onConfirm;
		$[10] = t5;
	} else t5 = $[10];
	const handleDialogDismiss = t5;
	let t6;
	if ($[11] !== bannerState || $[12] !== dialogIsOpen || $[13] !== handleDialogDismiss || $[14] !== handleDismiss || $[15] !== location || $[16] !== ssoOrgs) {
		let t7;
		if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setDialogIsOpen(false);
			$[18] = t7;
		} else t7 = $[18];
		t6 = jsxs(Fragment$1, { children: [jsx(SlideDismiss, {
			hidden: bannerState !== "visible",
			children: jsx(CoreSsoBanner, {
				ssoOrgs,
				onDismiss: handleDismiss,
				primaryAction: jsx(SSOActionMenu, {
					ssoOrgs,
					redirectLocation: location
				})
			})
		}), jsx(ConfirmationDialog, {
			isOpen: dialogIsOpen,
			onClose: t7,
			onConfirm: handleDialogDismiss,
			ssoOrgs
		})] });
		$[11] = bannerState;
		$[12] = dialogIsOpen;
		$[13] = handleDialogDismiss;
		$[14] = handleDismiss;
		$[15] = location;
		$[16] = ssoOrgs;
		$[17] = t6;
	} else t6 = $[17];
	return t6;
}
GlobalSsoBanner.displayName = "GlobalSsoBanner";
export { GlobalSsoBanner };
