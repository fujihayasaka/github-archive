/**
* Shared document URI state for the workflow/action editor.
* This is a separate module to avoid circular dependencies between
* editor.ts, language-service.ts, and inlay-hints.ts.
*/
/**
* Document URI used for the language service.
* This determines whether the language service treats the file as a workflow or action.
* Set by workflowEditor() and accessed by language service functions.
*/
var currentDocumentUri = ".github/workflows/workflow.yml";
function getDocumentUri() {
	return currentDocumentUri;
}
function setDocumentUri(uri) {
	currentDocumentUri = uri;
}
export { setDocumentUri as n, getDocumentUri as t };
