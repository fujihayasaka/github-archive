import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { a as useAction, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { n as RefSelector } from "./server-RefSelector-unHqlV3G-DIJhjGu-.js";
import { a as useShortcut } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { useCallback } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
function useRefCreateErrorHandling() {
	const $ = c(2);
	const { addToast } = useToastContext();
	let t0;
	if ($[0] !== addToast) {
		t0 = (error) => addToast({
			type: "error",
			message: error
		});
		$[0] = addToast;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function ReposHeaderRefSelector(t0) {
	const $ = c(25);
	const { size, buttonClassName, allowResizing, idEnding } = t0;
	const repo = useCurrentRepository();
	const path = usePath();
	const action = useAction();
	const refInfo = useRefInfo();
	const onCreateError = useRefCreateErrorHandling();
	const { sendRepoClickEvent } = useReposAnalytics();
	const { refSelectorShortcut } = useShortcut();
	let t1;
	if ($[0] !== action || $[1] !== path || $[2] !== repo) {
		t1 = (refName) => `${repositoryTreePath({
			repo,
			commitish: refName,
			action,
			path
		})}${window.location.search}`;
		$[0] = action;
		$[1] = path;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== sendRepoClickEvent) {
		t2 = (refName_0) => sendRepoClickEvent("REF_SELECTOR_MENU.CREATE_BRANCH", { "ref_name": refName_0 });
		$[4] = sendRepoClickEvent;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== sendRepoClickEvent) {
		t3 = (open) => open && sendRepoClickEvent("REF_SELECTOR_MENU");
		$[6] = sendRepoClickEvent;
		$[7] = t3;
	} else t3 = $[7];
	const t4 = idEnding || "repos-header-ref-selector";
	let t5;
	if ($[8] !== allowResizing || $[9] !== buttonClassName || $[10] !== onCreateError || $[11] !== refInfo.listCacheKey || $[12] !== refInfo.name || $[13] !== refInfo.refType || $[14] !== refSelectorShortcut.hotkey || $[15] !== repo.currentUserCanPush || $[16] !== repo.defaultBranch || $[17] !== repo.name || $[18] !== repo.ownerLogin || $[19] !== size || $[20] !== t1 || $[21] !== t2 || $[22] !== t3 || $[23] !== t4) {
		t5 = jsx(RefSelector, {
			currentCommitish: refInfo.name,
			defaultBranch: repo.defaultBranch,
			owner: repo.ownerLogin,
			repo: repo.name,
			canCreate: repo.currentUserCanPush,
			cacheKey: refInfo.listCacheKey,
			selectedRefType: refInfo.refType,
			getHref: t1,
			hotKey: refSelectorShortcut.hotkey,
			onBeforeCreate: t2,
			onCreateError,
			onOpenChange: t3,
			size,
			buttonClassName,
			allowResizing,
			idEnding: t4,
			useFocusZone: true
		});
		$[8] = allowResizing;
		$[9] = buttonClassName;
		$[10] = onCreateError;
		$[11] = refInfo.listCacheKey;
		$[12] = refInfo.name;
		$[13] = refInfo.refType;
		$[14] = refSelectorShortcut.hotkey;
		$[15] = repo.currentUserCanPush;
		$[16] = repo.defaultBranch;
		$[17] = repo.name;
		$[18] = repo.ownerLogin;
		$[19] = size;
		$[20] = t1;
		$[21] = t2;
		$[22] = t3;
		$[23] = t4;
		$[24] = t5;
	} else t5 = $[24];
	return t5;
}
ReposHeaderRefSelector.displayName = "ReposHeaderRefSelector";
export { ReposHeaderRefSelector as t };
