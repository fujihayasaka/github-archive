import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { At as FileSubmoduleIcon, Dt as FileIcon, I as ChevronLeftIcon, Qt as Heading$2, Wi as useSafeTimeout, a as AlertFillIcon, an as IconButton, ar as PlusIcon, u as ArrowLeftIcon, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { n as useIsDataRouterEnabled, t as SplitPageLayout } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { n as TreeView } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { i as useFileQueryContext } from "./server-find-file-BEBNNIhZ-BiOBklr2.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { c as useUrlCreator, o as useCurrentUser, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as PortalTooltip } from "./server-PortalTooltip-DECeLuvi-BZbUqJOn.js";
import { t as useFileTreeTooltip } from "./server-use-file-tree-tooltip-DhTyi11E-CX1wlHJi.js";
import { n as useEditPermissions } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { i as useScreenSize, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { n as FileResultsList, r as isSearchUrl } from "./server-FileResultsList-DizJJtxZ-C9rZpyL_.js";
import { n as getCookie, r as setCookie } from "./server-cookies-DndQO37X-vNR87gG9.js";
import { a as useShortcut, i as useCodeViewOptions } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { t as ExpandButton } from "./server-ExpandButton-H4onZNiH-BPmYbDb_.js";
import { t as ReposHeaderRefSelector } from "./server-ReposHeaderRefSelector-D_1tuOMj-sntynq8H.js";
import { t as fetchTree } from "./server-fetch-tree-DW-GjGy--LIDHmmgR.js";
import * as React$1 from "react";
import React, { createContext, use, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { scrollIntoView } from "@primer/behaviors";
import * as ReactDOM$1 from "react-dom";
import { c } from "react/compiler-runtime";
var ELEMENT_TYPE_HTML = "html";
var ELEMENT_TYPE_SVG = "svg";
var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
var validateElementType = (domElement, elementType) => {
	var _a, _b, _c;
	const ownerDocument = (_a = domElement.ownerDocument) !== null && _a !== void 0 ? _a : document;
	const ownerWindow = (_c = (_b = ownerDocument.defaultView) !== null && _b !== void 0 ? _b : ownerDocument.parentWindow) !== null && _c !== void 0 ? _c : window;
	switch (elementType) {
		case ELEMENT_TYPE_HTML: return domElement instanceof ownerWindow.HTMLElement;
		case ELEMENT_TYPE_SVG: return domElement instanceof ownerWindow.SVGElement;
		default: throw new Error(`Unrecognized element type "${elementType}" for validateElementType.`);
	}
};
var createPortalNode = (elementType, options) => {
	var _a, _b;
	let initialProps = {};
	let parent;
	let lastPlaceholder;
	let element;
	switch (elementType) {
		case ELEMENT_TYPE_HTML:
			element = document.createElement((_a = options === null || options === void 0 ? void 0 : options.containerElement) !== null && _a !== void 0 ? _a : "div");
			break;
		case ELEMENT_TYPE_SVG:
			element = document.createElementNS(SVG_NAMESPACE, (_b = options === null || options === void 0 ? void 0 : options.containerElement) !== null && _b !== void 0 ? _b : "g");
			break;
		default: throw new Error(`Invalid element type "${elementType}" for createPortalNode: must be "html" or "svg".`);
	}
	if (options && typeof options === "object" && options.attributes) for (const [key, value] of Object.entries(options.attributes)) element.setAttribute(key, value);
	const portalNode = {
		element,
		elementType,
		setPortalProps: (props) => {
			initialProps = props;
		},
		getInitialPortalProps: () => {
			return initialProps;
		},
		mount: (newParent, newPlaceholder) => {
			if (newPlaceholder === lastPlaceholder) return;
			portalNode.unmount();
			if (newParent !== parent) {
				if (!validateElementType(newParent, elementType)) throw new Error(`Invalid element type for portal: "${elementType}" portalNodes must be used with ${elementType} elements, but OutPortal is within <${newParent.tagName}>.`);
			}
			newParent.replaceChild(portalNode.element, newPlaceholder);
			parent = newParent;
			lastPlaceholder = newPlaceholder;
		},
		unmount: (expectedPlaceholder) => {
			if (expectedPlaceholder && expectedPlaceholder !== lastPlaceholder) return;
			if (parent && lastPlaceholder) {
				parent.replaceChild(lastPlaceholder, portalNode.element);
				parent = void 0;
				lastPlaceholder = void 0;
			}
		}
	};
	return portalNode;
};
var InPortal = class extends React$1.PureComponent {
	constructor(props) {
		super(props);
		this.addPropsChannel = () => {
			Object.assign(this.props.node, { setPortalProps: (props) => {
				this.setState({ nodeProps: props });
			} });
		};
		this.state = { nodeProps: this.props.node.getInitialPortalProps() };
	}
	componentDidMount() {
		this.addPropsChannel();
	}
	componentDidUpdate() {
		this.addPropsChannel();
	}
	render() {
		const { children, node } = this.props;
		return ReactDOM$1.createPortal(React$1.Children.map(children, (child) => {
			if (!React$1.isValidElement(child)) return child;
			return React$1.cloneElement(child, this.state.nodeProps);
		}), node.element);
	}
};
var OutPortal = class extends React$1.PureComponent {
	constructor(props) {
		super(props);
		this.placeholderNode = React$1.createRef();
		this.passPropsThroughPortal();
	}
	passPropsThroughPortal() {
		const propsForTarget = Object.assign({}, this.props, { node: void 0 });
		this.props.node.setPortalProps(propsForTarget);
	}
	componentDidMount() {
		const node = this.props.node;
		this.currentPortalNode = node;
		const placeholder = this.placeholderNode.current;
		const parent = placeholder.parentNode;
		node.mount(parent, placeholder);
		this.passPropsThroughPortal();
	}
	componentDidUpdate() {
		const node = this.props.node;
		if (this.currentPortalNode && node !== this.currentPortalNode) {
			this.currentPortalNode.unmount(this.placeholderNode.current);
			this.currentPortalNode.setPortalProps({});
			this.currentPortalNode = node;
		}
		const placeholder = this.placeholderNode.current;
		const parent = placeholder.parentNode;
		node.mount(parent, placeholder);
		this.passPropsThroughPortal();
	}
	componentWillUnmount() {
		const node = this.props.node;
		node.unmount(this.placeholderNode.current);
		node.setPortalProps({});
	}
	render() {
		const tagName = this.props.node.element.tagName;
		const type = this.props.node.elementType === ELEMENT_TYPE_HTML ? tagName.toLowerCase() : tagName;
		return React$1.createElement(type, { ref: this.placeholderNode });
	}
};
var createHtmlPortalNode = createPortalNode.bind(null, ELEMENT_TYPE_HTML);
createPortalNode.bind(null, ELEMENT_TYPE_SVG);
function isTreePayload(payload) {
	return "tree" in payload;
}
var safeLocalStorage = safeStorage("localStorage");
var OpenPanelStateContext = createContext(void 0);
OpenPanelStateContext.displayName = "OpenPanelStateContext";
var OpenPanelDispatchContext = createContext(() => void 0);
/** @deprecated Use OpenPanelStateContext and OpenPanelDispatchContext directly */
OpenPanelDispatchContext.displayName = "OpenPanelDispatchContext";
var OpenPanelContext = createContext({
	openPanel: void 0,
	setOpenPanel: () => void 0
});
/**
* This is equivalent to a simple setState, except we will not show the
* state as 'codeNav' or allow it to be set to 'codeNav' when on the blame page.
* This also adds a listener to hide the panel on smaller viewports
*/
OpenPanelContext.displayName = "OpenPanelContext";
function OpenPanelProvider({ children, payload, openPanelRef, action }) {
	const isDataRouter = useIsDataRouterEnabled();
	const hasBlameFromPayload = "blame" in payload;
	const isTreeViewFromPayload = isTreePayload(payload);
	const hasBlame = isDataRouter ? action === "blame" : hasBlameFromPayload;
	const isTreeView = isDataRouter ? action === "tree" : isTreeViewFromPayload;
	const hasBlameRef = useRef(hasBlame);
	const isTreeViewRef = useRef(isTreeView);
	useLayoutEffect(() => {
		hasBlameRef.current = hasBlame;
		isTreeViewRef.current = isTreeView;
	});
	const currentUser = useCurrentUser();
	const returnFocusTargetRef = useRef(void 0);
	const [rawOpenPanel, setRawOpenPanel] = useState(() => {
		const storedSetting = safeLocalStorage.getItem("codeNavOpen");
		if (!currentUser && storedSetting !== "" && storedSetting !== null) return "codeNav";
		if (currentUser && payload.symbolsExpanded) return "codeNav";
	});
	const openPanel = (hasBlame || isTreeView) && rawOpenPanel === "codeNav" ? void 0 : rawOpenPanel;
	React.useEffect(() => {
		openPanelRef.current = openPanel;
	}, [openPanel, openPanelRef]);
	const setOpenPanel = useCallback((panelType, returnFocusTarget) => {
		setRawOpenPanel((currentPanel) => {
			if (currentPanel && returnFocusTargetRef.current) returnFocusTargetRef.current.focus();
			returnFocusTargetRef.current = returnFocusTarget;
			return hasBlameRef.current || isTreeViewRef.current && panelType === "codeNav" ? void 0 : panelType;
		});
	}, []);
	useHandlePanelScreenResize(setOpenPanel);
	return /* @__PURE__ */ jsx(OpenPanelStateContext, {
		value: openPanel,
		children: /* @__PURE__ */ jsx(OpenPanelDispatchContext, {
			value: setOpenPanel,
			children
		})
	});
}
OpenPanelProvider.displayName = "OpenPanelProvider";
function useHandlePanelScreenResize(setOpenPanel) {
	const $ = c(4);
	const { screenSize } = useScreenSize();
	const previousScreenSize = useRef(screenSize);
	let t0;
	let t1;
	if ($[0] !== screenSize || $[1] !== setOpenPanel) {
		t0 = () => {
			const isChangingToSmallViewport = previousScreenSize.current >= ScreenSize.large;
			const isInitialLoad = previousScreenSize.current === screenSize;
			if (screenSize < ScreenSize.large && (isChangingToSmallViewport || isInitialLoad)) setOpenPanel(void 0);
			previousScreenSize.current = screenSize;
		};
		t1 = [screenSize, setOpenPanel];
		$[0] = screenSize;
		$[1] = setOpenPanel;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
}
function useOpenPanel() {
	return {
		openPanel: use(OpenPanelStateContext),
		setOpenPanel: use(OpenPanelDispatchContext)
	};
}
/** Use when you only need the current panel state (will re-render when panel changes) */
function useOpenPanelState() {
	return use(OpenPanelStateContext);
}
/** Use when you only need to set the panel (won't re-render when panel changes) */
function useSetOpenPanel() {
	return use(OpenPanelDispatchContext);
}
/**
*
* This component is used to take hotkeys that are tied to hidden buttons and duplicate them to work
* when the user has the hidden text area focused. This is done because the hotkeys library we use
* does not support hotkeys that work both when a text area is focused and when it is not.
*/
function DuplicateOnKeydownButton({ buttonFocusId, buttonHotkey, onButtonClick, buttonTestLabel, onlyAddHotkeyScopeButton }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("button", {
		hidden: true,
		"data-testid": buttonTestLabel ? buttonTestLabel : "",
		"data-hotkey": buttonHotkey,
		onClick: onButtonClick,
		"data-hotkey-scope": buttonFocusId
	}), !onlyAddHotkeyScopeButton && /* @__PURE__ */ jsx("button", {
		hidden: true,
		"data-hotkey": buttonHotkey,
		onClick: onButtonClick
	})] });
}
DuplicateOnKeydownButton.displayName = "DuplicateOnKeydownButton";
var ExpandFileTreeButton_module_default = {
	Button_1: "ExpandFileTreeButton-module_VVrvBa_Button_1",
	expandButton: "ExpandFileTreeButton-module_VVrvBa_expandButton",
	filesButtonBreakpoint: "ExpandFileTreeButton-module_VVrvBa_filesButtonBreakpoint"
};
var ExpandFileTreeButton = ({ ref, expanded, onToggleExpanded, className, ariaControls, textAreaId, useFilesButtonBreakpoint = true, variant, getTooltipDirection }) => {
	const { toggleTreeShortcut } = useShortcut();
	const { isServer: isSSR } = useRuntimeEnvironment();
	const tooltipDirection = getTooltipDirection?.(expanded) ?? "se";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		useFilesButtonBreakpoint && (!expanded || isSSR) && /* @__PURE__ */ jsx(ButtonComponent, {
			"aria-label": "Expand file tree",
			leadingVisual: ArrowLeftIcon,
			"data-hotkey": toggleTreeShortcut.hotkey,
			"data-testid": "expand-file-tree-button-mobile",
			ref,
			onClick: onToggleExpanded,
			variant: variant ?? "invisible",
			className: ExpandFileTreeButton_module_default.Button_1,
			children: "Files"
		}),
		/* @__PURE__ */ jsx(ExpandButton, {
			dataHotkey: toggleTreeShortcut.hotkey,
			className: clsx(className, "position-relative", ExpandFileTreeButton_module_default.expandButton, { [ExpandFileTreeButton_module_default.filesButtonBreakpoint]: useFilesButtonBreakpoint && (!expanded || isSSR) }),
			expanded,
			alignment: "left",
			ariaLabel: expanded ? "Collapse file tree" : "Expand file tree",
			tooltipDirection,
			testid: "file-tree-button",
			ariaControls,
			ref,
			variant,
			onToggleExpanded
		}),
		/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: toggleTreeShortcut.hotkey,
			onButtonClick: onToggleExpanded,
			onlyAddHotkeyScopeButton: true
		})
	] });
};
ExpandFileTreeButton.displayName = "ExpandFileTreeButton";
ExpandFileTreeButton.displayName = "ExpandFileTreeButton";
function FindFilesShortcut({ inputRef, onFindFilesShortcut, textAreaId }) {
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const { findFilesShortcut } = useShortcut();
	return /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
		buttonFocusId: textAreaId,
		buttonHotkey: findFilesShortcut.hotkey,
		onButtonClick: () => {
			onFindFilesShortcut?.();
			inputRef?.current?.focus();
			sendRepoKeyDownEvent("GO_TO_FILE");
		}
	});
}
FindFilesShortcut.displayName = "FindFilesShortcut";
var FileTreeContext = createContext({
	knownFolders: /* @__PURE__ */ new Map(),
	dispatchKnownFolders: () => {}
});
FileTreeContext.displayName = "FileTreeContext";
function useFileTreeContext() {
	return use(FileTreeContext);
}
var ReposFileTreePane_module_default = {
	Box_1: "ReposFileTreePane-module_WBqv_q_Box_1",
	Box_2: "ReposFileTreePane-module_WBqv_q_Box_2",
	Box_3: "ReposFileTreePane-module_WBqv_q_Box_3",
	Box_4: "ReposFileTreePane-module_WBqv_q_Box_4",
	Box_5: "ReposFileTreePane-module_WBqv_q_Box_5",
	Box_6: "ReposFileTreePane-module_WBqv_q_Box_6",
	Box_7: "ReposFileTreePane-module_WBqv_q_Box_7",
	Box_8: "ReposFileTreePane-module_WBqv_q_Box_8",
	FileResultsList: "ReposFileTreePane-module_WBqv_q_FileResultsList",
	FullWidthButtonGroup: "ReposFileTreePane-module_WBqv_q_FullWidthButtonGroup",
	HidePane: "ReposFileTreePane-module_WBqv_q_HidePane",
	HidePaneWithTreeOverlay: "ReposFileTreePane-module_WBqv_q_HidePaneWithTreeOverlay",
	HideTree: "ReposFileTreePane-module_WBqv_q_HideTree",
	IconButton: "ReposFileTreePane-module_WBqv_q_IconButton",
	Overlay: "ReposFileTreePane-module_WBqv_q_Overlay",
	Pane: "ReposFileTreePane-module_WBqv_q_Pane",
	PaneContents: "ReposFileTreePane-module_WBqv_q_PaneContents",
	PaneContentsHiddenOnNarrow: "ReposFileTreePane-module_WBqv_q_PaneContentsHiddenOnNarrow",
	SearchButtonWithLeftBorder: "ReposFileTreePane-module_WBqv_q_SearchButtonWithLeftBorder"
};
var FileTreeControlContext = createContext({});
FileTreeControlContext.displayName = "FileTreeControlContext";
function FileTreeControlProvider({ children }) {
	const expandAllFolders = useRef(false);
	const refreshTree = useRef(false);
	const shouldFetchFolders = useRef(true);
	const setExpandAllFolders = useCallback((value) => {
		expandAllFolders.current = value;
	}, []);
	const setRefreshTree = useCallback((value_0) => {
		refreshTree.current = value_0;
	}, []);
	const setShouldFetchFolders = useCallback((value_1) => {
		shouldFetchFolders.current = value_1;
	}, []);
	return /* @__PURE__ */ jsx(FileTreeControlContext, {
		value: useMemo(() => ({
			expandAllFolders,
			refreshTree,
			shouldFetchFolders,
			setExpandAllFolders,
			setRefreshTree,
			setShouldFetchFolders
		}), [
			setExpandAllFolders,
			setRefreshTree,
			setShouldFetchFolders
		]),
		children
	});
}
FileTreeControlProvider.displayName = "FileTreeControlProvider";
function useFileTreeControlContext() {
	return use(FileTreeControlContext);
}
/**
* Given a list of file paths that only exist on the client, returns a list of TreeItem<DirectoryItem> objects that represent
* the client-only files and directories.
*/
function getClientItemsToInsert(currentPath, clientOnlyFilePaths, existingItems) {
	const clientOnlyItemsToInsert = [];
	for (const filePath of clientOnlyFilePaths) if (filePath.startsWith(currentPath)) {
		const relativePath = filePath.slice(currentPath.length + 1);
		const nextDirectoryIndex = relativePath.indexOf("/");
		const name = nextDirectoryIndex > 0 ? relativePath.slice(0, nextDirectoryIndex) : relativePath;
		const path = `${currentPath}/${name}`;
		if (existingItems && existingItems.some((item) => item.path === path)) continue;
		const clientOnlyItem = {
			items: [],
			data: {
				contentType: path === filePath ? "file" : "directory",
				name,
				path,
				isClientOnly: true
			}
		};
		clientOnlyItemsToInsert.push(clientOnlyItem);
	}
	return clientOnlyItemsToInsert;
}
function useFetchFolder(directory, dispatchKnownFolders, getItemUrl) {
	const [items, setItems] = React.useState(directory.items);
	const [totalCount, setTotalCount] = React.useState(directory.data.totalCount || 0);
	const [loading, setLoading] = React.useState(false);
	const [error, setError] = React.useState(false);
	const { safeSetTimeout } = useSafeTimeout();
	React.useEffect(() => {
		setItems(directory.items);
	}, [directory.items]);
	React.useEffect(() => {
		if (directory.data.totalCount !== void 0) setTotalCount(directory.data.totalCount);
	}, [directory.data.totalCount]);
	const clearError = React.useCallback(() => {
		setError(false);
	}, []);
	const incrementallyShowItems = React.useCallback((folderItems, newTotalCount) => {
		const newItems = folderItems || [...items];
		setItems(newItems.slice(0, 100));
		safeSetTimeout(() => {
			setItems(newItems);
			if (newTotalCount !== void 0) setTotalCount(newTotalCount);
		}, 1);
	}, [items, safeSetTimeout]);
	return [
		React.useCallback(async (clientOnlyFilePaths) => {
			const newKnownFolders = /* @__PURE__ */ new Map();
			if (!directory.data.isClientOnly) {
				const contentUrl = getItemUrl(directory.data);
				setError(false);
				setLoading(true);
				const start = Date.now();
				try {
					const folderPayload = await fetchTree(contentUrl);
					const folderItems_0 = folderPayload.tree.items.map((payloadItem) => {
						const treeItem = {
							items: [],
							data: { ...payloadItem },
							autoExpand: payloadItem.contentType === "directory" && folderPayload.tree.items.length === 1
						};
						newKnownFolders.set(payloadItem.path, treeItem);
						if (payloadItem.hasSimplifiedPath) return splitSimplifiedTreeItem(treeItem, payloadItem, newKnownFolders);
						return treeItem;
					});
					if (clientOnlyFilePaths) {
						const currentPath = directory.data.path;
						const clientOnlyItemsToInsert = getClientItemsToInsert(currentPath, clientOnlyFilePaths, folderPayload.tree.items);
						folderItems_0.push(...clientOnlyItemsToInsert);
						for (const item of clientOnlyItemsToInsert) newKnownFolders.set(item.data.path, item);
					}
					dispatchKnownFolders({
						type: "add",
						folders: newKnownFolders,
						processingTime: Date.now() - start
					});
					directory.items = folderItems_0;
					directory.data.totalCount = folderPayload.tree.totalCount;
					if (folderItems_0.length > 100) incrementallyShowItems(folderItems_0, folderPayload.tree.totalCount);
					else {
						setItems(folderItems_0);
						setTotalCount(folderPayload.tree.totalCount);
					}
				} catch {
					setError(true);
				}
			} else if (clientOnlyFilePaths) {
				const currentPath_0 = directory.data.path;
				const clientOnlyItemsToInsert_0 = getClientItemsToInsert(currentPath_0, clientOnlyFilePaths);
				for (const item_0 of clientOnlyItemsToInsert_0) newKnownFolders.set(item_0.data.path, item_0);
				dispatchKnownFolders({
					type: "add",
					folders: newKnownFolders,
					processingTime: 0
				});
				if (clientOnlyItemsToInsert_0.length > 100) incrementallyShowItems(clientOnlyItemsToInsert_0, clientOnlyItemsToInsert_0.length);
				else {
					setItems(clientOnlyItemsToInsert_0);
					setTotalCount(clientOnlyItemsToInsert_0.length);
				}
			}
			setLoading(false);
		}, [
			getItemUrl,
			directory,
			dispatchKnownFolders,
			incrementallyShowItems
		]),
		incrementallyShowItems,
		items,
		loading,
		error,
		clearError,
		totalCount
	];
}
function splitSimplifiedTreeItem(treeItem, payloadItem, knownFolders) {
	treeItem.data.name = treeItem.data.name.slice(treeItem.data.name.lastIndexOf("/") + 1, treeItem.data.name.length);
	const topItemName = payloadItem.name.slice(0, payloadItem.name.lastIndexOf("/"));
	const hasSimplifiedPath = topItemName.indexOf("/") > -1;
	const topItem = {
		path: payloadItem.path.slice(0, payloadItem.path.lastIndexOf("/")),
		contentType: payloadItem.contentType,
		name: topItemName,
		hasSimplifiedPath
	};
	const topTreeItem = {
		items: [treeItem],
		data: topItem
	};
	knownFolders.set(topItem.path, topTreeItem);
	if (hasSimplifiedPath) return splitSimplifiedTreeItem(topTreeItem, { ...topItem }, knownFolders);
	else return topTreeItem;
}
var ReposFileTreeView_module_default = {
	Box: "ReposFileTreeView-module_cmiWrG_Box",
	Box_1: "ReposFileTreeView-module_cmiWrG_Box_1",
	Box_2: "ReposFileTreeView-module_cmiWrG_Box_2",
	Octicon: "ReposFileTreeView-module_cmiWrG_Octicon"
};
function buildReposFileTree(folders, knownFolders, rootItems, sortDirectoryItems, isDataRouterEnabled = false) {
	if (!folders) return {
		newRootItems: rootItems,
		rootItemsUpdated: false,
		itemsAdded: false
	};
	const rootItemsUpdated = folders[""] ? addFolder("", knownFolders, rootItems, folders[""].items) : false;
	sortDirectoryItems?.(rootItems);
	let itemsAdded = rootItemsUpdated;
	for (const path of Object.keys(folders).sort()) if (path) {
		const parent = knownFolders.get(path);
		if (parent) {
			const prevLength = parent.items.length;
			addFolder(path, knownFolders, parent.items, folders[path].items, sortDirectoryItems);
			parent.data.totalCount = folders[path].totalCount;
			if (parent.items.length > prevLength) itemsAdded = true;
			if (isDataRouterEnabled && parent.items.length > prevLength) {
				const newParent = {
					...parent,
					items: [...parent.items]
				};
				knownFolders.set(path, newParent);
				updateTreeItemReference(knownFolders, rootItems, path, newParent);
			}
		}
	}
	return {
		newRootItems: rootItems,
		rootItemsUpdated,
		itemsAdded
	};
}
/**
* Updates the reference to a TreeItem in its parent's items array.
* This is needed because React.memo compares object references.
*/
function updateTreeItemReference(knownFolders, rootItems, path, newItem) {
	const lastSlash = path.lastIndexOf("/");
	if (lastSlash === -1) {
		const index = rootItems.findIndex((item) => item.data.path === path);
		if (index !== -1) rootItems[index] = newItem;
	} else {
		const parentPath = path.substring(0, lastSlash);
		const parent = knownFolders.get(parentPath);
		if (parent) {
			const index = parent.items.findIndex((item) => item.data.path === path);
			if (index !== -1) parent.items[index] = newItem;
		}
	}
}
function addFolder(path, knownFolders, parentItems, items, sortDirectoryItems) {
	let parentItemsUpdated = false;
	for (const item of items) {
		const fullPath = path ? `${path}/${item.name}` : item.name;
		if (!knownFolders.get(fullPath)) {
			const treeItem = {
				items: [],
				data: { ...item }
			};
			knownFolders.set(fullPath, treeItem);
			if (item.hasSimplifiedPath) {
				const topTreeItem = splitSimplifiedTreeItem(treeItem, item, knownFolders);
				const existingItemIndex = parentItems.findIndex((parentItem) => parentItem.data.path === topTreeItem.data.path);
				if (existingItemIndex !== -1) {
					if (topTreeItem.items.length > parentItems[existingItemIndex].items.length) {
						parentItems[existingItemIndex] = topTreeItem;
						parentItemsUpdated = true;
					}
				} else {
					parentItems.push(topTreeItem);
					sortDirectoryItems?.(parentItems);
				}
			} else {
				parentItems.push(treeItem);
				sortDirectoryItems?.(parentItems);
			}
		}
	}
	return parentItemsUpdated;
}
function WrappedFileTreeRow({ isActive, file, onItemSelected, getItemUrl, selectedItemRef, navigate, onRenderRow, getFileTrailingVisual, getFileIcon }) {
	const { sendRepoClickEvent } = useReposAnalytics();
	const rowRef = React.useRef(null);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: rowRef,
		mouseRowRef: rowRef
	});
	const isSubModule = file.data.contentType === "submodule";
	const trailingVisualData = getFileTrailingVisual?.(file.data);
	const onSelect = React.useCallback((e) => {
		if (isSubModule) {
			e.preventDefault();
			if (file.data.submoduleUrl) window.location.href = file.data.submoduleUrl;
		} else if (e.metaKey || e.ctrlKey || e.button === 1) {
			window.open(getItemUrl(file.data), "_blank");
			e.preventDefault();
		} else if (isActive) e.preventDefault();
		else {
			onItemSelected?.();
			sendRepoClickEvent("FILES_TREE.ITEM", { ["item_path"]: file.data.path });
			navigate(getItemUrl(file.data));
			e.stopPropagation();
		}
	}, [
		file.data,
		getItemUrl,
		isActive,
		isSubModule,
		navigate,
		onItemSelected,
		sendRepoClickEvent
	]);
	onRenderRow?.();
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		ref: rowRef,
		onSelect,
		current: isActive,
		id: `${file.data.path}-item`,
		containIntrinsicSize: !isActive ? "auto 2rem" : void 0,
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: getFileIcon ? getFileIcon(file.data) : isSubModule ? /* @__PURE__ */ jsx(FileSubmoduleIcon, {}) : /* @__PURE__ */ jsx(FileIcon, {}) }),
			/* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
				ref: selectedItemRef,
				style: { color: isSubModule ? "var(--fgColor-accent, var(--color-accent-fg))" : void 0 },
				children: file.data.name
			}), showTooltip && /* @__PURE__ */ jsx(PortalTooltip, {
				"data-testid": `${file.data.name}-item-tooltip`,
				id: `${file.data.name}-item-tooltip`,
				contentRef: rowRef,
				"aria-label": file.data.name,
				open: true,
				direction: "ne"
			})] }),
			!!trailingVisualData?.screenReaderText && /* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: trailingVisualData.screenReaderText
			}),
			!!trailingVisualData?.trailingVisual && /* @__PURE__ */ jsx(TreeView.TrailingVisual, { children: trailingVisualData.trailingVisual })
		]
	});
}
WrappedFileTreeRow.displayName = "WrappedFileTreeRow";
var FileTreeRow = React.memo(WrappedFileTreeRow);
FileTreeRow.displayName = "FileTreeRow";
function WrappedDirectoryTreeRow({ clientOnlyFilePaths, directory, isActive, isAncestorOfActive, leadingPath = "", onItemSelected, dispatchKnownFolders, getItemUrl, getFetchUrl, selectedItemRef, navigate, onRenderRow, getFileTrailingVisual, getFileIcon, navigateOnClick = true, treeName }) {
	const { expandAllFolders, shouldFetchFolders } = useFileTreeControlContext();
	const [isExpanded, setExpanded] = useState(expandAllFolders?.current || isAncestorOfActive);
	const { sendRepoClickEvent } = useReposAnalytics();
	const rowRef = React.useRef(null);
	const listItemRef = React.useRef(null);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: listItemRef,
		mouseRowRef: rowRef
	});
	const [fetchFolder, incrementallyShowItems, items, loading, error, clearError, totalCount] = useFetchFolder(directory, dispatchKnownFolders, getFetchUrl);
	const truncatedRows = totalCount - items.length;
	const pathPrefix = leadingPath ? `${leadingPath}/` : "";
	useEffect(() => {
		if (expandAllFolders?.current && !isExpanded) setExpanded(true);
	}, [
		directory,
		expandAllFolders,
		isExpanded
	]);
	const onToggleExpanded = React.useCallback((expanded) => {
		if (expandAllFolders?.current) expandAllFolders.current = false;
		if (expanded && !isExpanded && !loading && !error) {
			if (directory.items.length > 100) incrementallyShowItems();
			else if (directory.items.length === 0 && !isActive && !isAncestorOfActive && shouldFetchFolders?.current !== false) fetchFolder(clientOnlyFilePaths);
		}
		if (expanded !== isExpanded) setExpanded(expanded);
	}, [
		expandAllFolders,
		isExpanded,
		loading,
		error,
		directory.items.length,
		isActive,
		isAncestorOfActive,
		shouldFetchFolders,
		incrementallyShowItems,
		fetchFolder,
		clientOnlyFilePaths
	]);
	const onClick = React.useCallback((e) => {
		if (e.metaKey || e.ctrlKey || e.button === 1 && navigateOnClick) {
			window.open(getItemUrl(directory.data), "_blank");
			e.preventDefault();
		} else if (isActive) e.preventDefault();
		else {
			onItemSelected?.();
			sendRepoClickEvent("FILES_TREE.ITEM", { ["item_path"]: directory.data.path });
			if (navigateOnClick) navigate(getItemUrl(directory.data));
			else onToggleExpanded?.(!isExpanded);
			e.stopPropagation();
		}
	}, [
		directory.data,
		getItemUrl,
		isActive,
		isExpanded,
		navigate,
		navigateOnClick,
		onItemSelected,
		onToggleExpanded,
		sendRepoClickEvent
	]);
	React.useEffect(() => {
		if (isAncestorOfActive && !isExpanded) onToggleExpanded?.(true);
	}, [isAncestorOfActive]);
	React.useEffect(() => {
		if (directory.items.length === 0 && isExpanded) onToggleExpanded?.(false);
		else if (!isExpanded && directory.autoExpand) onToggleExpanded?.(true);
	}, [directory.items.length]);
	const setRowRef = React.useCallback((refElem) => {
		if (selectedItemRef && isActive) selectedItemRef(refElem);
		rowRef.current = refElem;
	}, [selectedItemRef, isActive]);
	if (directory.items.length === 1 && directory.items[0].data.contentType === "directory") return /* @__PURE__ */ jsx(DirectoryContents, {
		clientOnlyFilePaths,
		directoryItems: directory.items,
		leadingPath: pathPrefix + directory.data.name,
		inheritsActive: isActive,
		dispatchKnownFolders,
		onItemSelected,
		selectedItemRef,
		getItemUrl,
		directoryNavigateOnClick: navigateOnClick,
		getFileTrailingVisual,
		getFileIcon,
		treeName
	});
	onRenderRow?.();
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		ref: listItemRef,
		expanded: isExpanded,
		onExpandedChange: onToggleExpanded,
		current: isActive,
		onSelect: onClick,
		id: `${directory.data.path}-item`,
		containIntrinsicSize: !isActive ? "auto 2rem" : void 0,
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(TreeView.DirectoryIcon, {}) }),
			/* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("span", {
				ref: setRowRef,
				children: [pathPrefix, directory.data.name]
			}), showTooltip && /* @__PURE__ */ jsx(PortalTooltip, {
				"data-testid": `${directory.data.name}-directory-item-tooltip`,
				id: `${directory.data.name}-directory-item-tooltip`,
				contentRef: listItemRef,
				"aria-label": `${pathPrefix}${directory.data.name}`,
				open: true,
				direction: "ne"
			})] }),
			/* @__PURE__ */ jsx(TreeView.SubTree, {
				state: loading ? "loading" : error ? "error" : "done",
				children: error ? /* @__PURE__ */ jsx(TreeView.ErrorDialog, {
					onRetry: fetchFolder,
					onDismiss: clearError,
					children: "There was an error loading the folder contents."
				}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DirectoryContents, {
					clientOnlyFilePaths,
					directoryItems: items,
					dispatchKnownFolders,
					onItemSelected,
					selectedItemRef,
					getItemUrl,
					directoryNavigateOnClick: navigateOnClick,
					getFileTrailingVisual,
					getFileIcon,
					treeName
				}), truncatedRows > 0 && /* @__PURE__ */ jsx(ErrorTreeRow, { message: `${truncatedRows} entries not shown` })] })
			})
		]
	});
}
WrappedDirectoryTreeRow.displayName = "WrappedDirectoryTreeRow";
var DirectoryTreeRow = React.memo(WrappedDirectoryTreeRow);
DirectoryTreeRow.displayName = "DirectoryTreeRow";
function WrappedDirectoryContents({ clientOnlyFilePaths, directoryItems, leadingPath, inheritsActive, onItemSelected, dispatchKnownFolders, selectedItemRef, onRenderRow, getItemUrl, getFileTrailingVisual, getFileIcon, directoryNavigateOnClick = true, treeName }) {
	const path = usePath();
	const urlCreator = useUrlCreator();
	const navigate = useNavigate$1();
	const navigateRef = React.useRef(navigate);
	return /* @__PURE__ */ jsx(Fragment$1, { children: directoryItems.map((item) => {
		const isActive = path === item.data.path;
		const isAncestorOfActive = isActive || path.startsWith(`${item.data.path}/`);
		return item.data.contentType === "directory" ? /* @__PURE__ */ jsx(DirectoryTreeRow, {
			clientOnlyFilePaths,
			isActive: inheritsActive || isActive,
			isAncestorOfActive,
			onItemSelected,
			leadingPath,
			directory: item,
			dispatchKnownFolders,
			getItemUrl,
			getFetchUrl: urlCreator.getItemUrl,
			selectedItemRef: isAncestorOfActive ? selectedItemRef : void 0,
			navigate: navigateRef.current,
			onRenderRow,
			navigateOnClick: directoryNavigateOnClick,
			getFileTrailingVisual,
			getFileIcon,
			itemCount: item.items.length,
			treeName
		}, item.data.name) : /* @__PURE__ */ jsx(FileTreeRow, {
			onItemSelected,
			file: item,
			isActive,
			getItemUrl,
			selectedItemRef: isActive ? selectedItemRef : void 0,
			navigate: navigateRef.current,
			onRenderRow,
			getFileTrailingVisual,
			getFileIcon,
			treeName
		}, item.data.name);
	}) });
}
WrappedDirectoryContents.displayName = "WrappedDirectoryContents";
var DirectoryContents = React.memo(WrappedDirectoryContents);
DirectoryContents.displayName = "DirectoryContents";
function ReposFileTreeView(props) {
	const { clientOnlyFilePaths, data, rootItems, setRootItems, fetchError, incompleteFileTree, processingTime, loading, onRenderRow, getItemUrl, getFileTrailingVisual, getFileIcon, sortDirectoryItems, treeName } = props;
	const { knownFolders, dispatchKnownFolders } = useFileTreeContext();
	const { refreshTree } = useFileTreeControlContext();
	const isDataRouterEnabled = useIsDataRouterEnabled();
	React.useEffect(() => {
		if (loading) return;
		let newKnownFolders = /* @__PURE__ */ new Map();
		let newKnownRootItems = [];
		if (!refreshTree?.current) {
			newKnownFolders = new Map(knownFolders);
			newKnownRootItems = rootItems.slice();
		}
		const { newRootItems, rootItemsUpdated, itemsAdded } = buildReposFileTree(data, newKnownFolders, newKnownRootItems, sortDirectoryItems, isDataRouterEnabled);
		const shouldUpdateForDataRouter = isDataRouterEnabled && itemsAdded;
		if (newRootItems.length > rootItems.length || rootItemsUpdated || shouldUpdateForDataRouter || refreshTree?.current) setRootItems(newRootItems);
		if (newKnownFolders.size > knownFolders.size || shouldUpdateForDataRouter || refreshTree?.current) dispatchKnownFolders({
			type: "set",
			folders: newKnownFolders,
			processingTime
		});
		if (refreshTree?.current) refreshTree.current = false;
	}, [data, loading]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx("div", {
		onMouseDown: React.useCallback((event) => {
			if (event.button === 1) event.preventDefault();
		}, []),
		className: clsx(props.className, ReposFileTreeView_module_default.Box),
		"data-testid": "repos-file-tree-container",
		children: loading ? /* @__PURE__ */ jsx("div", {
			className: ReposFileTreeView_module_default.Box_1,
			children: /* @__PURE__ */ jsx(Spinner, { "aria-label": "Loading file tree" })
		}) : /* @__PURE__ */ jsx("nav", {
			"aria-label": "File Tree Navigation",
			children: /* @__PURE__ */ jsxs(TreeView, {
				"aria-label": "Files",
				children: [
					fetchError && /* @__PURE__ */ jsx(ErrorTreeRow, { message: "Some files could not be loaded." }),
					incompleteFileTree && /* @__PURE__ */ jsx(ErrorTreeRow, { message: "Sign in to see the full file tree." }),
					/* @__PURE__ */ jsx(DirectoryContents, {
						clientOnlyFilePaths,
						directoryItems: rootItems,
						onItemSelected: props.onItemSelected,
						dispatchKnownFolders,
						selectedItemRef: props.selectedItemRef,
						onRenderRow,
						directoryNavigateOnClick: props.directoryNavigateOnClick,
						getItemUrl,
						getFileTrailingVisual,
						getFileIcon,
						treeName
					})
				]
			})
		})
	}) });
}
ReposFileTreeView.displayName = "ReposFileTreeView";
function ErrorTreeRow({ message }) {
	const errorMessage = message || "Couldn't load.";
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		id: "error-tree-row",
		children: [/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, {
			icon: AlertFillIcon,
			className: ReposFileTreeView_module_default.Octicon
		}) }), /* @__PURE__ */ jsx("div", {
			className: ReposFileTreeView_module_default.Box_2,
			children: errorMessage
		})]
	});
}
ErrorTreeRow.displayName = "ErrorTreeRow";
var appendAndFocusEvent = "blackbird_monolith_append_and_focus_input";
function appendAndFocusSearchBar({ appendQuery, retainScrollPosition, returnTarget }) {
	window.dispatchEvent(new CustomEvent(appendAndFocusEvent, { detail: {
		appendQuery,
		retainScrollPosition,
		returnTarget
	} }));
}
var SearchButton_module_default = { IconButton: "SearchButton-module_51dpRG_IconButton" };
function SearchButton(t0) {
	const $ = c(10);
	const { className, onClick, textAreaId } = t0;
	const { searchShortcut } = useShortcut();
	let t1;
	if ($[0] !== className || $[1] !== onClick || $[2] !== searchShortcut.hotkey || $[3] !== textAreaId) {
		let t2;
		if ($[5] !== onClick) {
			t2 = (e) => {
				onClick?.();
				appendAndFocusSearchBar({
					retainScrollPosition: true,
					returnTarget: e.target.closest("button")
				});
			};
			$[5] = onClick;
			$[6] = t2;
		} else t2 = $[6];
		let t3;
		if ($[7] !== onClick || $[8] !== textAreaId) {
			t3 = () => {
				const textArea = document.getElementById(textAreaId);
				onClick?.();
				appendAndFocusSearchBar({
					retainScrollPosition: true,
					returnTarget: textArea ?? void 0
				});
			};
			$[7] = onClick;
			$[8] = textAreaId;
			$[9] = t3;
		} else t3 = $[9];
		t1 = jsxs(Fragment$1, { children: [jsx(IconButton, {
			"aria-label": "Search this repository",
			tooltipDirection: "nw",
			icon: SearchIcon,
			"data-hotkey": searchShortcut.hotkey,
			size: "medium",
			onClick: t2,
			className: clsx(SearchButton_module_default.IconButton, className)
		}), jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: searchShortcut.hotkey,
			onButtonClick: t3,
			onlyAddHotkeyScopeButton: true
		})] });
		$[0] = className;
		$[1] = onClick;
		$[2] = searchShortcut.hotkey;
		$[3] = textAreaId;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
SearchButton.displayName = "SearchButton";
var TreeOverlayBreakpoint = ScreenSize.xxxlarge;
function ReposFileTreePane({ clientOnlyFilePaths, collapseTree, showTree, fileTree, treeToggleElement, treeToggleRef, onItemSelected, processingTime, searchBoxRef, repo, path, refInfo, isFilePath, foldersToFetch, incompleteFileTree, id, onFindFilesShortcut, textAreaId, getItemUrlOverride, headerClassName, paneClassName, paneContentsClassName, treeContainerClassName, findFileWorkerPath, headerContent, getFileTrailingVisual, getFileIcon, sortDirectoryItems, showFindFile = true, directoryNavigateOnClick = true, showRefSelectorRow = true, paneResizable = true }) {
	if (showFindFile && findFileWorkerPath === void 0) throw new Error("findFileWorkerPath must be provided when showFindFile is true");
	const openPanel = useOpenPanelState();
	const { canEdit, fileExistsOnDefault } = useEditPermissions();
	const [treeLoading, setTreeLoading] = React.useState(foldersToFetch.length > 0);
	const [fetchError, setFetchError] = React.useState(false);
	const fetchedFoldersRef = React.useRef([]);
	const pendingFetchCountRef = React.useRef(0);
	const scrollingRef = React.useRef(null);
	const treeBorderSentinelRef = React.useRef(null);
	const ignoreNextScrollRef = React.useRef(false);
	const selectedElementRef = React.useRef(null);
	const { query } = useFileQueryContext();
	const queryRef = React.useRef(query);
	queryRef.current = query;
	const { codeCenterOption } = useCodeViewOptions();
	const lastOpenPanelRef = React.useRef(openPanel);
	const { isServer: isSSR } = useRuntimeEnvironment();
	const { defaultBranch } = useCurrentRepository();
	const { getItemUrl } = useUrlCreator();
	const getTreeItemUrl = getItemUrlOverride || getItemUrl;
	let initialRenderRootItems = [];
	const newKnownFolders = /* @__PURE__ */ new Map();
	const hasDoneInitialRenderRef = React.useRef(treeLoading);
	if (!hasDoneInitialRenderRef.current && fileTree) initialRenderRootItems = buildReposFileTree(fileTree, newKnownFolders, [], sortDirectoryItems).newRootItems;
	hasDoneInitialRenderRef.current = true;
	const [knownFolders, dispatchKnownFolders] = React.useReducer(knownFolderReducer, newKnownFolders);
	const [rootItems, setRootItems] = React.useState(initialRenderRootItems);
	React.useEffect(() => {
		if (!showTree || !(!query || window.matchMedia(`(min-width: ${ScreenSize.large}px)`).matches)) selectedElementRef.current = null;
	}, [showTree, query]);
	React.useEffect(() => {
		if (openPanel && lastOpenPanelRef.current !== openPanel && window.matchMedia(`(max-width: ${TreeOverlayBreakpoint - 1}px)`).matches) collapseTree({ setPreference: false });
		lastOpenPanelRef.current = openPanel;
	}, [collapseTree, openPanel]);
	const fetchFolder = React.useCallback(async (folderPath) => {
		const contentUrl = getItemUrl({
			contentType: "directory",
			path: folderPath,
			name: folderPath
		});
		try {
			const folderPayload = await fetchTree(contentUrl);
			fileTree[folderPath] = {
				items: folderPayload.tree.items,
				totalCount: folderPayload.tree.totalCount
			};
		} catch {
			setFetchError(true);
		}
		fetchedFoldersRef.current.push(folderPath);
		pendingFetchCountRef.current -= 1;
		if (pendingFetchCountRef.current === 0) setTreeLoading(false);
	}, [fileTree, getItemUrl]);
	React.useEffect(() => {
		if (incompleteFileTree) {
			setTreeLoading(false);
			return;
		}
		if (!foldersToFetch || foldersToFetch.length === 0) return;
		const foldersToFetchNow = foldersToFetch.filter((folder_0) => !fetchedFoldersRef.current.includes(folder_0));
		if (foldersToFetchNow.length > 0) {
			pendingFetchCountRef.current += foldersToFetchNow.length;
			setTreeLoading(true);
			for (const folder_1 of foldersToFetchNow) fetchFolder(folder_1);
		}
	}, [
		fetchFolder,
		foldersToFetch,
		incompleteFileTree
	]);
	const focusActiveItem = React.useCallback((selectedItemElement) => {
		if (showTree && (!queryRef.current || window.matchMedia(`(min-width: ${ScreenSize.large}px)`).matches) && scrollingRef.current && selectedItemElement) {
			const visibleHeight = scrollingRef.current.clientHeight;
			scrollIntoView(selectedItemElement, scrollingRef.current, {
				endMargin: visibleHeight / 2,
				startMargin: visibleHeight / 2,
				behavior: "auto"
			});
		}
	}, [showTree]);
	const setSelectedItemRef = React.useCallback((selectedItemElement_0) => {
		if (selectedItemElement_0 && ignoreNextScrollRef.current) ignoreNextScrollRef.current = false;
		else if (selectedElementRef.current !== selectedItemElement_0) focusActiveItem(selectedItemElement_0);
		selectedElementRef.current = selectedItemElement_0;
	}, [focusActiveItem]);
	const setScrollingRef = React.useCallback((element) => {
		scrollingRef.current = element;
		if (window.matchMedia(`(min-width: ${TreeOverlayBreakpoint}px)`).matches) focusActiveItem(selectedElementRef.current);
	}, [focusActiveItem]);
	const setOverlayRef = React.useCallback((element_0) => {
		if (element_0) focusActiveItem(selectedElementRef.current);
	}, [focusActiveItem]);
	const { screenSize } = useScreenSize();
	const showTreeOverlay = !isSSR && (openPanel && screenSize < TreeOverlayBreakpoint || screenSize < ScreenSize.xlarge) && screenSize >= ScreenSize.large;
	const onTreeItemSelected = React.useCallback(() => {
		if (!showTreeOverlay) onItemSelected();
		ignoreNextScrollRef.current = true;
	}, [onItemSelected, showTreeOverlay]);
	const parentDirPath = isFilePath ? path.substring(0, path.lastIndexOf("/")) : path;
	const fileTreeContextValue = useMemo(() => {
		return {
			knownFolders,
			dispatchKnownFolders
		};
	}, [knownFolders]);
	const portalNode = React.useMemo(() => {
		if (isSSR) return null;
		return createHtmlPortalNode();
	}, [isSSR]);
	const exitOverlay = React.useCallback(() => {
		if (window.matchMedia(`(min-width: ${ScreenSize.large + 1}px) and (max-width: ${ScreenSize.xxxxlarge - 1}px)`).matches) collapseTree({ setPreference: false });
	}, [collapseTree]);
	const onDefaultBranch = refInfo.name === defaultBranch;
	const paneContents = /* @__PURE__ */ jsxs("div", {
		id,
		className: clsx(ReposFileTreePane_module_default.PaneContents, isSSR && ReposFileTreePane_module_default.PaneContentsHiddenOnNarrow, paneContentsClassName),
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: clsx(headerClassName, ReposFileTreePane_module_default.Box_1),
				children: [headerContent, showRefSelectorRow && /* @__PURE__ */ jsxs("div", {
					className: ReposFileTreePane_module_default.Box_2,
					children: [/* @__PURE__ */ jsx("div", {
						className: ReposFileTreePane_module_default.Box_3,
						children: !onDefaultBranch && fileExistsOnDefault !== void 0 ? /* @__PURE__ */ jsxs(ButtonGroup, {
							className: ReposFileTreePane_module_default.FullWidthButtonGroup,
							children: [fileExistsOnDefault ? /* @__PURE__ */ jsx(IconButton, {
								icon: ChevronLeftIcon,
								"aria-label": "View file on default branch",
								as: Link$1,
								to: repositoryTreePath({
									repo,
									commitish: defaultBranch,
									action: "blob",
									path
								})
							}) : /* @__PURE__ */ jsx(IconButton, {
								icon: ChevronLeftIcon,
								"aria-label": "View file on default branch",
								description: "File does not exist on default branch",
								"aria-disabled": true,
								inactive: true
							}), /* @__PURE__ */ jsx(ReposHeaderRefSelector, {
								buttonClassName: "react-repos-tree-pane-ref-selector width-full ref-selector-class",
								allowResizing: true
							})]
						}) : /* @__PURE__ */ jsx(ReposHeaderRefSelector, {
							buttonClassName: "react-repos-tree-pane-ref-selector width-full ref-selector-class",
							allowResizing: true
						})
					}), /* @__PURE__ */ jsxs("div", {
						className: ReposFileTreePane_module_default.Box_4,
						children: [canEdit && /* @__PURE__ */ jsx(IconButton, {
							"aria-label": "Add file",
							tooltipDirection: "n",
							as: Link$1,
							icon: PlusIcon,
							to: repositoryTreePath({
								repo,
								path: parentDirPath,
								commitish: refInfo.name,
								action: "new"
							}),
							onClick: onTreeItemSelected,
							className: ReposFileTreePane_module_default.IconButton
						}), /* @__PURE__ */ jsx(SearchButton, {
							className: canEdit ? ReposFileTreePane_module_default.SearchButtonWithLeftBorder : void 0,
							onClick: exitOverlay,
							textAreaId
						})]
					})]
				})]
			}),
			refInfo.currentOid && showFindFile && findFileWorkerPath && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(FileResultsList, {
				commitOid: refInfo.currentOid,
				findFileWorkerPath,
				onItemSelected,
				searchBoxRef,
				className: clsx(ReposFileTreePane_module_default.FileResultsList, isSSR && ReposFileTreePane_module_default.PaneContentsHiddenOnNarrow)
			}), /* @__PURE__ */ jsx(FindFilesShortcut, {
				inputRef: searchBoxRef,
				onFindFilesShortcut,
				textAreaId
			})] }),
			/* @__PURE__ */ jsx(TreeBorder, {
				scrollingRef,
				sentinelRef: treeBorderSentinelRef
			}),
			/* @__PURE__ */ jsxs("div", {
				ref: setScrollingRef,
				className: clsx(ReposFileTreePane_module_default.Box_5, isSSR && ReposFileTreePane_module_default.PaneContentsHiddenOnNarrow),
				children: [
					/* @__PURE__ */ jsx("div", {
						ref: treeBorderSentinelRef,
						style: {
							height: 1,
							marginTop: -1,
							width: "100%",
							flexShrink: 0
						}
					}),
					isSSR ? refInfo.currentOid && /* @__PURE__ */ jsx("div", {
						className: !query ? "react-tree-show-tree-items" : "react-tree-show-tree-items-on-large-screen",
						children: /* @__PURE__ */ jsx(ReposFileTreeView, {
							clientOnlyFilePaths,
							data: fileTree,
							rootItems,
							selectedItemRef: setSelectedItemRef,
							setRootItems,
							onItemSelected: onTreeItemSelected,
							processingTime,
							loading: treeLoading,
							fetchError,
							incompleteFileTree,
							directoryNavigateOnClick,
							getItemUrl: getTreeItemUrl,
							className: treeContainerClassName,
							getFileTrailingVisual,
							getFileIcon,
							sortDirectoryItems,
							treeName: refInfo.name
						})
					}) : portalNode && /* @__PURE__ */ jsx(OutPortal, { node: portalNode }),
					!refInfo.currentOid && !repo.isEmpty && /* @__PURE__ */ jsxs("div", {
						className: ReposFileTreePane_module_default.Box_6,
						children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertFillIcon }), "\xA0Ref is invalid"]
					})
				]
			})
		]
	});
	return /* @__PURE__ */ jsxs(FileTreeContext, {
		value: fileTreeContextValue,
		children: [
			portalNode && /* @__PURE__ */ jsx(InPortal, {
				node: portalNode,
				children: refInfo.currentOid && /* @__PURE__ */ jsx("div", {
					className: !query ? "react-tree-show-tree-items" : "react-tree-show-tree-items-on-large-screen",
					children: /* @__PURE__ */ jsx(ReposFileTreeView, {
						clientOnlyFilePaths,
						data: fileTree,
						directoryNavigateOnClick,
						rootItems,
						selectedItemRef: setSelectedItemRef,
						setRootItems,
						onItemSelected: onTreeItemSelected,
						processingTime,
						loading: treeLoading,
						fetchError,
						incompleteFileTree,
						getItemUrl: getTreeItemUrl,
						className: treeContainerClassName,
						getFileTrailingVisual,
						getFileIcon,
						sortDirectoryItems,
						treeName: refInfo.name
					})
				})
			}),
			!showTree && codeCenterOption.enabled && treeToggleElement && /* @__PURE__ */ jsx("div", {
				className: ReposFileTreePane_module_default.Box_7,
				children: treeToggleElement
			}),
			/* @__PURE__ */ jsx(SplitPageLayout.Pane, {
				position: "start",
				sticky: true,
				padding: "none",
				width: "large",
				resizable: paneResizable ? true : false,
				widthStorageKey: "codeView.tree-pane-width",
				divider: {
					regular: "none",
					narrow: "none"
				},
				className: clsx(ReposFileTreePane_module_default.Pane, !showTree && ReposFileTreePane_module_default.HideTree, showTreeOverlay || openPanel ? ReposFileTreePane_module_default.HidePaneWithTreeOverlay : ReposFileTreePane_module_default.HidePane, paneClassName),
				children: showTree && !showTreeOverlay && /* @__PURE__ */ jsx("div", {
					className: isSSR ? openPanel ? "react-tree-pane-contents-3-panel" : "react-tree-pane-contents" : void 0,
					children: paneContents
				})
			}),
			showTree && showTreeOverlay && lastOpenPanelRef.current === openPanel && /* @__PURE__ */ jsx(Overlay, {
				className: clsx(isSSR ? openPanel ? "react-tree-pane-overlay-3-panel" : "react-tree-pane-overlay" : void 0, ReposFileTreePane_module_default.Overlay, !showTree && ReposFileTreePane_module_default.HideTree),
				ref: setOverlayRef,
				returnFocusRef: treeToggleRef,
				onClickOutside: exitOverlay,
				onEscape: exitOverlay,
				top: 0,
				position: "fixed",
				children: /* @__PURE__ */ jsx(Fragment$1, { children: paneContents })
			})
		]
	});
}
ReposFileTreePane.displayName = "ReposFileTreePane";
function knownFolderReducer(state, action) {
	switch (action.type) {
		case "set": {
			const stateInitialized = state?.size > 0;
			sendEvent("file-tree", {
				"fetch-count": stateInitialized ? action.folders.size - state.size : action.folders.size,
				"file-count": action.folders.size,
				"nav-type": stateInitialized ? "soft" : "hard",
				"processing-time": action.processingTime
			});
			return action.folders;
		}
		case "add": {
			const newState = new Map([...state, ...action.folders]);
			sendEvent("file-tree", {
				"fetch-count": action.folders.size,
				"file-count": newState.size,
				"nav-type": "fetch",
				"processing-time": action.processingTime
			});
			return newState;
		}
		default: throw new Error(`Unknown action type: ${action.type}`);
	}
}
function TreeBorder(t0) {
	const $ = c(6);
	const { scrollingRef, sentinelRef } = t0;
	const [visible, setVisible] = React.useState(false);
	let t1;
	let t2;
	if ($[0] !== scrollingRef || $[1] !== sentinelRef) {
		t1 = () => {
			const sentinel = sentinelRef.current;
			if (!sentinel || !scrollingRef.current) return;
			const observer = new IntersectionObserver((t3) => {
				const [entry] = t3;
				setVisible(!entry.isIntersecting);
			}, {
				root: scrollingRef.current,
				threshold: 0
			});
			observer.observe(sentinel);
			return () => observer.disconnect();
		};
		t2 = [scrollingRef, sentinelRef];
		$[0] = scrollingRef;
		$[1] = sentinelRef;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	React.useEffect(t1, t2);
	let t3;
	if ($[4] !== visible) {
		t3 = visible ? jsx("div", { className: ReposFileTreePane_module_default.Box_8 }) : null;
		$[4] = visible;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
TreeBorder.displayName = "TreeBorder";
var use_tree_pane_module_default = { Heading: "use-tree-pane-module_fQeoWW_Heading" };
function useTreePane(reposFileTreeId, openPanelRef, treeExpanded, textAreaId, updateExpandPreferences, cookieName = "fileTreeExpanded", expandFileTreeButtonProps) {
	const { sendRepoClickEvent } = useReposAnalytics();
	const currentUser = useCurrentUser();
	const fileTreeExpandedCookie = cookieName ? getCookie(cookieName) : void 0;
	const isSSR = !!(typeof ssrSafeDocument === "undefined");
	let initiallyExpanded = !currentUser && fileTreeExpandedCookie && fileTreeExpandedCookie.value !== "false" || currentUser && treeExpanded;
	if (initiallyExpanded === void 0) initiallyExpanded = false;
	const treeToggleRef = useRef(null);
	const searchBoxRef = useRef(null);
	const { screenSize } = useScreenSize();
	const [isTreeExpanded, setIsTreeExpanded] = useState(initiallyExpanded);
	const lastStateIsExpanded = useRef(initiallyExpanded);
	const expandTreeCookieExpiration = 720 * 60 * 60 * 1e3;
	const expandedAsOverlay = useRef(false);
	const hasManuallyCollapsed = useRef(false);
	const showAsOverlay = useCallback(() => {
		return !(openPanelRef.current && window.matchMedia(`(min-width: ${TreeOverlayBreakpoint}px)`).matches || !openPanelRef.current && window.matchMedia(`(min-width: ${ScreenSize.xlarge}px)`).matches);
	}, [openPanelRef]);
	/**
	* With SSR, we need to make sure we get the correct initial state for the tree
	*/
	useLayoutEffect(() => {
		const showingAsOverlay = showAsOverlay();
		if (!showingAsOverlay) expandedAsOverlay.current = false;
		setIsTreeExpanded(isSearchUrl() && screenSize < ScreenSize.large && !hasManuallyCollapsed.current || (!showingAsOverlay || expandedAsOverlay.current) && (currentUser && isTreeExpanded || !currentUser && fileTreeExpandedCookie?.value !== "false"));
	}, [
		expandedAsOverlay,
		fileTreeExpandedCookie?.value,
		screenSize,
		openPanelRef,
		showAsOverlay,
		currentUser
	]);
	const isTreeExpandedRef = useRef(isTreeExpanded);
	useLayoutEffect(() => {
		isTreeExpandedRef.current = isTreeExpanded;
	});
	/**
	* When the screen size shrinks below medium, collapse the tree if it is expanded.
	* When the screen size grows beyond medium, return the tree to its last state.
	*
	* When the screen size shrinks below large, collapse the tree if it is expanded.
	* When the screen size grows beyond large, return the tree to its last state.
	*/
	useLayoutEffect(() => {
		const breakpoint = !!openPanelRef.current ? TreeOverlayBreakpoint : ScreenSize.xlarge;
		const shouldClose = screenSize < breakpoint;
		const shouldOpen = screenSize >= breakpoint;
		if (shouldClose && lastStateIsExpanded.current && !isSearchUrl() && isTreeExpandedRef.current) setIsTreeExpanded(false);
		if (shouldOpen && lastStateIsExpanded.current && !isTreeExpandedRef.current) setIsTreeExpanded(true);
	}, [openPanelRef, screenSize]);
	const expandTree = useCallback((options) => {
		setIsTreeExpanded(true);
		if (showAsOverlay()) expandedAsOverlay.current = true;
		if (options?.setPreference) {
			updateExpandPreferences?.(true);
			lastStateIsExpanded.current = true;
			if (cookieName) setCookie(cookieName, "true", new Date(Date.now() + expandTreeCookieExpiration).toUTCString());
		}
		if (options?.focus === "toggleButton") requestAnimationFrame(() => treeToggleRef.current?.focus());
		else if (options?.focus === "search") requestAnimationFrame(() => searchBoxRef.current?.focus());
	}, [
		cookieName,
		expandTreeCookieExpiration,
		showAsOverlay,
		updateExpandPreferences
	]);
	const collapseTree = useCallback((options) => {
		setIsTreeExpanded(false);
		expandedAsOverlay.current = false;
		hasManuallyCollapsed.current = true;
		if (options?.setPreference) {
			updateExpandPreferences?.(false);
			lastStateIsExpanded.current = false;
			if (cookieName) setCookie(cookieName, "false", new Date(Date.now() + expandTreeCookieExpiration).toUTCString());
		}
		if (options?.focus === "toggleButton") requestAnimationFrame(() => treeToggleRef.current?.focus());
	}, [
		cookieName,
		expandTreeCookieExpiration,
		updateExpandPreferences
	]);
	const shouldSetPreference = useCallback((openPanel) => {
		return openPanel && window.matchMedia(`(min-width: ${TreeOverlayBreakpoint}px)`).matches || !openPanelRef.current && window.matchMedia(`(min-width: ${ScreenSize.xlarge}px)`).matches;
	}, [openPanelRef]);
	const onToggleExpanded = useCallback(() => {
		sendRepoClickEvent(isTreeExpandedRef.current ? "FILES_TREE.HIDE" : "FILES_TREE.SHOW");
		if (isTreeExpandedRef.current) collapseTree({
			focus: "toggleButton",
			setPreference: shouldSetPreference(openPanelRef.current)
		});
		else expandTree({
			focus: "toggleButton",
			setPreference: shouldSetPreference(openPanelRef.current)
		});
	}, [
		sendRepoClickEvent,
		collapseTree,
		shouldSetPreference,
		openPanelRef,
		expandTree
	]);
	const toggleButtonClassName = fileTreeExpandedCookie === void 0 && !isTreeExpanded && !isSSR ? "react-tree-toggle-button-with-indicator" : void 0;
	return {
		isTreeExpanded,
		expandTree,
		collapseTree,
		treeToggleElement: useMemo(() => /* @__PURE__ */ jsx(Heading$2, {
			as: "h2",
			className: use_tree_pane_module_default.Heading,
			children: /* @__PURE__ */ jsx(ExpandFileTreeButton, {
				expanded: isTreeExpanded,
				ariaControls: reposFileTreeId,
				onToggleExpanded,
				className: toggleButtonClassName,
				ref: treeToggleRef,
				textAreaId,
				...expandFileTreeButtonProps
			})
		}), [
			isTreeExpanded,
			reposFileTreeId,
			onToggleExpanded,
			toggleButtonClassName,
			textAreaId,
			expandFileTreeButtonProps
		]),
		treeToggleRef,
		searchBoxRef
	};
}
export { ReposFileTreePane as a, useFileTreeControlContext as c, useTreePane as d, OpenPanelProvider as i, useOpenPanel as l, FileTreeControlProvider as n, appendAndFocusSearchBar as o, FindFilesShortcut as r, isTreePayload as s, DuplicateOnKeydownButton as t, useSetOpenPanel as u };
