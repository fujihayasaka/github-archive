import React from "react";
import { jsx } from "react/jsx-runtime";
var PathContext = React.createContext("");
PathContext.displayName = "PathContext";
function PathProvider({ children, path }) {
	return /* @__PURE__ */ jsx(PathContext, {
		value: path,
		children
	});
}
PathProvider.displayName = "PathProvider";
function usePath() {
	return React.use(PathContext);
}
export { usePath as n, PathProvider as t };
