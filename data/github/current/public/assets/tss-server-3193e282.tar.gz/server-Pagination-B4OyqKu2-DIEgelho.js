import { I as ChevronLeftIcon, L as ChevronRightIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as viewportRanges } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { n as buildPaginationModel, t as buildComponentData } from "./server-model-C1V5yRLd-cRkMt6Ep.js";
import React from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
var classes = {
	"Page": "prc-Pagination-Page-Etgqf",
	"PaginationContainer": "prc-Pagination-PaginationContainer-HEhGo",
	"TablePaginationSteps": "prc-Pagination-TablePaginationSteps-cAXs3"
};
var getViewportRangesToHidePages = (showPages) => {
	if (showPages && typeof showPages !== "boolean") return Object.keys(showPages).filter((key) => !showPages[key]);
	if (showPages) return [];
	else return Object.keys(viewportRanges);
};
var PageLabel = ({ children, direction }) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
	direction === "page-prev" ? /* @__PURE__ */ jsx(ChevronLeftIcon, {}) : null,
	children,
	direction === "page-next" ? /* @__PURE__ */ jsx(ChevronRightIcon, {}) : null
] });
function usePaginationPages({ pageCount, currentPage, onPageChange, hrefBuilder, marginPageCount, showPages, surroundingPageCount, renderPage }) {
	const pageChange = React.useCallback((n) => (e) => onPageChange(e, n), [onPageChange]);
	const model = React.useMemo(() => {
		return buildPaginationModel(pageCount, currentPage, !!showPages, marginPageCount, surroundingPageCount);
	}, [
		pageCount,
		currentPage,
		showPages,
		marginPageCount,
		surroundingPageCount
	]);
	return React.useMemo(() => {
		return model.map((page) => {
			const { props, key, content } = buildComponentData(page, hrefBuilder, pageChange(page.num));
			if (renderPage && props.as !== "span") return renderPage({
				key,
				children: /* @__PURE__ */ jsx(PageLabel, {
					direction: key,
					children: content
				}),
				number: page.num,
				className: classes.Page,
				...props
			});
			return /* @__PURE__ */ jsx(props.as || "a", {
				className: clsx(classes.Page),
				...props,
				children: /* @__PURE__ */ jsx(PageLabel, {
					direction: key,
					children: content
				})
			}, key);
		});
	}, [
		model,
		hrefBuilder,
		pageChange,
		renderPage
	]);
}
function Pagination({ className, pageCount, currentPage, onPageChange = noop, hrefBuilder = defaultHrefBuilder, marginPageCount = 1, showPages = true, surroundingPageCount = 2, renderPage, ...rest }) {
	const pageElements = usePaginationPages({
		pageCount,
		currentPage,
		onPageChange,
		hrefBuilder,
		marginPageCount,
		showPages,
		surroundingPageCount,
		renderPage
	});
	return /* @__PURE__ */ jsx("nav", {
		className: clsx(classes.PaginationContainer, className),
		"aria-label": "Pagination",
		...rest,
		children: /* @__PURE__ */ jsx("div", {
			className: classes.TablePaginationSteps,
			"data-hidden-viewport-ranges": getViewportRangesToHidePages(showPages).join(" "),
			children: pageElements
		})
	});
}
Pagination.displayName = "Pagination";
function defaultHrefBuilder(pageNum) {
	return `#${pageNum}`;
}
function noop() {}
export { Pagination as t };
