performance.mark("js-parse-end:server-IssueCommentComposer-C7OS5NcZ-CRrUuQ5-.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, n as AriaStatus } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ir as SkipIcon, Qt as Heading$2, Tn as LockIcon, Wi as useSafeTimeout, an as IconButton, bn as Link, d as ArrowRightIcon, fi as Tooltip, hi as TriangleDownIcon, n as ActionList, pn as IssueReopenedIcon, un as IssueClosedIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as useResizeObserver } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { t as areCharacterKeyShortcutsEnabled } from "./server-keyboard-shortcuts-helper-BRqP2m0f-DOsDhPIe.js";
import { i as useSessionStorage } from "./server-use-session-storage-C2f28u9L-cHRWNGhU.js";
import { l as useItemPickersContext, u as useKeyPress } from "./server-ItemPicker-ILw4RsMA-BLDIejLk.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as Octicon } from "./server-deprecated-NWt92s1C-CJVCDSxf.js";
import { n as md2html, t as canBeOptimisticallyParsed } from "./server-md2html-TgcTyYQC-DzwxtslQ.js";
import { p as validateComment, t as CommentBox } from "./server-validators-DpH9Vi4K-BgoqazXb.js";
import { n as decrementIssuesTabCounter, r as incrementIssuesTabCounter, t as ContributorFooter } from "./server-issues-tab-counter-CnxY27eB-Dsxgdp-i.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { r as RepositoryAndIssuePicker } from "./server-RepositoryAndIssuePicker-pJUBAgRS-Bhe6Vlwu.js";
import { a as TEST_IDS, c as withClassSelector, i as LABELS$1, n as ERRORS$1, r as IDS, s as selectQuoteFromComment, t as CLASS_NAMES } from "./server-quotes-Biwbbu-B-YKXYFdbk.js";
import { n as commitUpdateIssueSubscriptionMutation, t as VALUES } from "./server-values-LsOIychd-B-d_qZOV.js";
import { t as useFeatureFlag } from "./server-use-feature-flag-CDC46uBu-B9UHPW6C.js";
import { t as addReactionMutation } from "./server-add-reaction-mutation-B36mKh3K-Co_JID-q.js";
import { t as BUTTON_LABELS } from "./server-button-labels-DIxotQxx-Dixtm-9B.js";
import React, { createContext, startTransition, use, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:IssueCommentComposer-C7OS5NcZ.js");
var node$7 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IssueCommentComposer",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "locked",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerCanComment",
				"storageKey": null
			},
			v1,
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v0,
					v1,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "isArchived",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameWithOwner",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerCanInteract",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerInteractionLimitReasonHTML",
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "IssueActions"
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$7.hash = "9618823da54ffd247d5aeb642a0298e9";
var node$6 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueCommentComposerSecondary",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanReopen",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerCanClose",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "authorAssociation",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "viewerThreadSubscriptionFormAction",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "ReactionGroup",
			"kind": "LinkedField",
			"name": "reactionGroups",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "content",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "viewerHasReacted",
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Discussion",
			"kind": "LinkedField",
			"name": "discussion",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "isLocked",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "slashCommandsEnabled",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "codeOfConductFileUrl",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "securityPolicyUrl",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "contributingFileUrl",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "supportFileUrl",
					"storageKey": null
				}
			],
			"storageKey": null
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$6.hash = "5fda94cf39b1af0910d722acc31e77cc";
var node$5 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueCommentComposerViewer",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "login",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "name",
			"storageKey": null
		},
		{
			"alias": null,
			"args": [{
				"kind": "Literal",
				"name": "size",
				"value": 64
			}],
			"kind": "ScalarField",
			"name": "avatarUrl",
			"storageKey": "avatarUrl(size:64)"
		}
	],
	"type": "User",
	"abstractKey": null
};
node$5.hash = "b7d45f1ec02fa8f1ac270b43aa300237";
var readonly_comment_box_module_default = { reason: "readonly-comment-box-module_2v106q_reason" };
var ReadonlyCommentBox_module_default = {
	centeredContent: "ReadonlyCommentBox-module_e7K82q_centeredContent",
	ReadonlyCommentBoxContainer: "ReadonlyCommentBox-module_e7K82q_ReadonlyCommentBoxContainer"
};
function ReadonlyCommentBox({ reason, icon: Icon, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx("blankslate", ReadonlyCommentBox_module_default.ReadonlyCommentBoxContainer),
		...props,
		children: /* @__PURE__ */ jsxs("div", {
			className: ReadonlyCommentBox_module_default.centeredContent,
			children: [Icon && /* @__PURE__ */ jsx(Icon, { size: 24 }), /* @__PURE__ */ jsx("div", {
				className: readonly_comment_box_module_default.reason,
				children: reason
			})]
		})
	});
}
ReadonlyCommentBox.displayName = "ReadonlyCommentBox";
var node$4 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "IssueActions",
	"selections": [{
		"args": null,
		"kind": "FragmentSpread",
		"name": "IssueActionsState"
	}],
	"type": "Issue",
	"abstractKey": null
};
node$4.hash = "2d5dba4e9b26988ef6d02616663b6de0";
var node$3 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IssueActionsState",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "state",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "stateReason",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameWithOwner",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						}],
						"storageKey": null
					}
				],
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$3.hash = "59e7d1237bf5f5d0300e9b0bd885478e";
var FocusTrapManagementContext = createContext(null);
FocusTrapManagementContext.displayName = "FocusTrapManagementContext";
function FocusTrapManagementContextProvider({ children }) {
	const [disableFocusTrap, setDisableFocusTrap] = useState(false);
	return /* @__PURE__ */ jsx(FocusTrapManagementContext, {
		value: useMemo(() => {
			return {
				disableFocusTrap,
				setDisableFocusTrap
			};
		}, [disableFocusTrap, setDisableFocusTrap]),
		children
	});
}
FocusTrapManagementContextProvider.displayName = "FocusTrapManagementContextProvider";
var useFocusTrapManagementContext = () => {
	const context = use(FocusTrapManagementContext);
	if (!context) return {
		disableFocusTrap: false,
		setDisableFocusTrap: noop
	};
	return context;
};
var import_react_relay = require_react_relay();
var ERRORS = {
	couldNotCloseIssue: "Could not close issue",
	couldNotReOpenIssue: "Could not reopen issue",
	missingReopenPermission: "You do not have permissions to reopen this issue",
	missingClosePermission: "You do not have permissions to close this issue"
};
var LABELS = {
	actionListCompletedDescription: "Done, closed, fixed, resolved",
	actionListNotPlannedDescription: "Won't fix, can't repro, stale",
	actionListNotPlannedNewDescription: "Won't fix, can't repro, stale",
	actionListDuplicateDescription: "Duplicate of another issue",
	closeIssue: "Close issue",
	closeIssueWithComment: "Close with comment",
	closeAsCompleted: "Close as completed",
	closeAsNotPlanned: "Close as not planned",
	closeAsDuplicate: "Close as duplicate",
	closeAsDuplicateOf: (issueNumber) => `Close as duplicate of #${issueNumber}`,
	moreOptions: "More options",
	reOpenIssue: "Reopen issue",
	updateIssueRoleDescription: "update issue state options menu",
	closedIssueSuccess: "The issue has been closed.",
	reopenedIssueSuccess: "The issue has been reopened."
};
var IssueActions_module_default = {
	closeCompletedIssueIcon: "IssueActions-module_Y7gVgW_closeCompletedIssueIcon",
	IssueActionsButtonGroup: "IssueActions-module_Y7gVgW_IssueActionsButtonGroup",
	issueStateOptionsMenu: "IssueActions-module_Y7gVgW_issueStateOptionsMenu",
	reopenIssueIcon: "IssueActions-module_Y7gVgW_reopenIssueIcon"
};
var node$2 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "duplicateIssueId"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}, v2 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "newStateReason"
	}, v3 = [{
		"fields": [
			{
				"kind": "Variable",
				"name": "duplicateIssueId",
				"variableName": "duplicateIssueId"
			},
			{
				"kind": "Variable",
				"name": "issueId",
				"variableName": "id"
			},
			{
				"kind": "Variable",
				"name": "stateReason",
				"variableName": "newStateReason"
			}
		],
		"kind": "ObjectValue",
		"name": "input"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "state",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "stateReason",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [
				v0,
				v1,
				v2
			],
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueStateMutationCloseMutation",
			"selections": [{
				"alias": null,
				"args": v3,
				"concreteType": "CloseIssuePayload",
				"kind": "LinkedField",
				"name": "closeIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v4,
						v5,
						v6,
						{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "duplicateOf",
							"plural": false,
							"selections": [v7, v8],
							"storageKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [
				v1,
				v2,
				v0
			],
			"kind": "Operation",
			"name": "updateIssueStateMutationCloseMutation",
			"selections": [{
				"alias": null,
				"args": v3,
				"concreteType": "CloseIssuePayload",
				"kind": "LinkedField",
				"name": "closeIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v4,
						v5,
						v6,
						{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "duplicateOf",
							"plural": false,
							"selections": [
								v7,
								v8,
								v4
							],
							"storageKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "73f1d13c27e76443f6a9a809ccb4f6e6",
			"metadata": {},
			"name": "updateIssueStateMutationCloseMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$2.hash = "c91cc5cb207d648613a5084fb7c34420";
var node$1 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"fields": [{
			"kind": "Variable",
			"name": "issueId",
			"variableName": "id"
		}],
		"kind": "ObjectValue",
		"name": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "state",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueStateMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReopenIssuePayload",
				"kind": "LinkedField",
				"name": "reopenIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v2,
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "duplicateOf",
							"plural": false,
							"selections": [v4, v5],
							"storageKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueStateMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReopenIssuePayload",
				"kind": "LinkedField",
				"name": "reopenIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v2,
						v3,
						{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "duplicateOf",
							"plural": false,
							"selections": [
								v4,
								v5,
								v2
							],
							"storageKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "a6677fa25f66fdc23d4dbe44f4e62757",
			"metadata": {},
			"name": "updateIssueStateMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$1.hash = "ca935e60ecf589dc4afd48ce97e1708b";
var import_relay_runtime = require_relay_runtime();
var retainedEntries = /* @__PURE__ */ new Map();
/**
* Adjust open/closed counts in the Relay store for every retained search query.
*
* @param store - Relay store proxy from the updater callback
* @param delta - +1 for reopen, -1 for close
*/
function adjustOpenClosedCounts(store, delta) {
	if (retainedEntries.size === 0) return;
	for (const { searchInfo } of retainedEntries.values()) {
		const repo = store.get(searchInfo.repoDataId);
		if (!repo) continue;
		const search = repo.getLinkedRecord("search", searchInfo.queryArgs);
		if (!search) continue;
		const openCount = search.getValue("openIssueCount") ?? 0;
		const closedCount = search.getValue("closedIssueCount") ?? 0;
		search.setValue(Math.max(0, openCount + delta), "openIssueCount");
		search.setValue(Math.max(0, closedCount - delta), "closedIssueCount");
	}
}
function commitCloseIssueMutation({ environment, input: { issueId, newStateReason, duplicateIssue }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$2,
		variables: {
			id: issueId,
			newStateReason,
			duplicateIssueId: duplicateIssue?.id
		},
		optimisticResponse: { closeIssue: { issue: {
			id: issueId,
			state: "CLOSED",
			stateReason: newStateReason,
			duplicateOf: duplicateIssue ? {
				id: duplicateIssue.id,
				number: duplicateIssue.number,
				url: duplicateIssue.url
			} : null
		} } },
		optimisticUpdater: (store) => adjustOpenClosedCounts(store, -1),
		updater: (store) => adjustOpenClosedCounts(store, -1),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => {
			if (onCompleted) onCompleted(response);
			decrementIssuesTabCounter();
		}
	});
}
function commitReopenIssueMutation({ environment, input: { issueId }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$1,
		variables: { id: issueId },
		optimisticResponse: { reopenIssue: { issue: {
			id: issueId,
			state: "OPEN",
			duplicateOf: null
		} } },
		optimisticUpdater: (store) => adjustOpenClosedCounts(store, 1),
		updater: (store) => adjustOpenClosedCounts(store, 1),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => {
			if (onCompleted) onCompleted(response);
			incrementIssuesTabCounter();
		}
	});
}
var MENU_THRESHOLD = 200;
function IssueActions(t0) {
	const { actionRef, ...rest } = t0;
	return jsx(IssueActionsInternal, {
		actionStateRef: (0, import_react_relay.useFragment)(node$4, actionRef),
		...rest
	});
}
IssueActions.displayName = "IssueActions";
function IssueActionsInternal({ actionStateRef, disabled = false, onAction, hasComment, viewerCanClose, viewerCanReopen, buttonSize, closeButtonState, setCloseButtonState, onStateChange }) {
	const { addToast } = useToastContext();
	const [duplicateIssue, setDuplicateIssue] = useState(null);
	const [anchorBottomOffset, setAnchorBottomOffset] = useState(0);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { setDisableFocusTrap } = useFocusTrapManagementContext();
	const data = (0, import_react_relay.useFragment)(node$3, actionStateRef);
	const closeIssue = useCallback((newStateReason) => {
		if (data && data.id) return commitCloseIssueMutation({
			environment,
			input: {
				issueId: data.id,
				newStateReason,
				duplicateIssue: duplicateIssue ? {
					id: duplicateIssue.id,
					number: duplicateIssue.number,
					url: duplicateIssue.url
				} : void 0
			},
			onCompleted: () => {
				setDuplicateIssue(null);
				announce$1(LABELS.closedIssueSuccess);
				onStateChange?.();
			},
			onError: () => addToast({
				type: "error",
				message: ERRORS.couldNotCloseIssue
			})
		});
	}, [
		data,
		environment,
		duplicateIssue,
		addToast,
		onStateChange
	]);
	const reopenIssue = useCallback(() => {
		if (data.id) commitReopenIssueMutation({
			environment,
			input: { issueId: data.id },
			onCompleted: () => {
				announce$1(LABELS.reopenedIssueSuccess);
				onStateChange?.();
			},
			onError: () => addToast({
				type: "error",
				message: ERRORS.couldNotReOpenIssue
			})
		});
	}, [
		data,
		environment,
		addToast,
		onStateChange
	]);
	useEffect(() => setCloseButtonState(getInitialButtonState(data.state)), [
		data.state,
		data.stateReason,
		data.id,
		setCloseButtonState
	]);
	const [open, setOpen] = useState(false);
	const viewerCanChange = data.state === "OPEN" ? viewerCanClose : viewerCanReopen;
	const [pickerType, setPickerType] = useState(null);
	const duplicateIssueSelected = useCallback((issue) => {
		setDuplicateIssue(issue);
		setPickerType(null);
		setCloseButtonState(issue ? "DUPLICATE" : "CLOSED");
	}, [setCloseButtonState]);
	const anchorRef = useRef(null);
	const returnFocusRef = useRef(null);
	const onPickerTypeChange = useCallback((type) => {
		if (type === null && returnFocusRef?.current) returnFocusRef.current.focus();
		setPickerType(type);
	}, [setPickerType]);
	const actionMenuOpenChange = useCallback((newValue) => {
		setOpen(newValue);
		if (newValue) setPickerType(null);
	}, [setOpen, setPickerType]);
	useEffect(() => {
		setDisableFocusTrap(pickerType !== null);
	}, [pickerType, setDisableFocusTrap]);
	useEffect(() => {
		const anchor = anchorRef.current;
		if (!anchor) return;
		const updateBottomPosition = () => {
			const rect = anchor.getBoundingClientRect();
			setAnchorBottomOffset(window.innerHeight - rect.bottom);
		};
		updateBottomPosition();
		const observer = new IntersectionObserver(() => {
			updateBottomPosition();
		}, { threshold: [
			0,
			.1,
			.5,
			.9,
			1
		] });
		observer.observe(anchor);
		const resizeObserver = new ResizeObserver(() => {
			updateBottomPosition();
		});
		resizeObserver.observe(document.body);
		return () => {
			observer.disconnect();
			resizeObserver.disconnect();
		};
	}, []);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(ButtonGroup, {
		className: IssueActions_module_default.IssueActionsButtonGroup,
		children: [/* @__PURE__ */ jsx(UpdateStateButton, {
			disabled,
			issueState: data.state,
			buttonState: closeButtonState,
			onClose: closeIssue,
			onReopen: reopenIssue,
			onAction,
			hasComment,
			size: buttonSize,
			viewerCanReopen,
			viewerCanClose,
			duplicateIssue: duplicateIssue ?? void 0
		}), /* @__PURE__ */ jsxs(ActionMenu, {
			anchorRef,
			open,
			onOpenChange: actionMenuOpenChange,
			children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
				icon: TriangleDownIcon,
				"aria-label": LABELS.moreOptions,
				size: buttonSize,
				disabled: disabled || !viewerCanChange
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "medium",
				side: anchorBottomOffset < MENU_THRESHOLD ? "outside-top" : void 0,
				children: /* @__PURE__ */ jsx(UpdateStateButtonOptions, {
					buttonState: closeButtonState,
					setButtonState: setCloseButtonState,
					canClose: closeIssue !== void 0,
					canReopen: reopenIssue !== void 0,
					viewerCanClose,
					viewerCanReopen,
					issueState: data.state,
					issueStateReason: data.stateReason,
					duplicateIssueSelected,
					setIsDuplicateDialogOpen: () => setPickerType("Issue")
				})
			})]
		})]
	}), /* @__PURE__ */ jsx(RepositoryAndIssuePicker, {
		issuePickerProps: {
			insidePortal: true,
			responsiveOnNarrow: true
		},
		repositoryPickerProps: {
			responsiveOnNarrow: true,
			insidePortal: true,
			hideContainer: true
		},
		selectedIssueIds: duplicateIssue ? [duplicateIssue.id] : [],
		hiddenIssueIds: [data.id],
		onPickerTypeChange,
		onIssueSelection: (issues) => duplicateIssueSelected(issues.length > 0 && issues[0] ? issues[0] : null),
		defaultRepositoryNameWithOwner: data.repository.nameWithOwner,
		organization: data.repository.owner.login,
		pickerType,
		anchorElement: (props) => {
			const { ref } = props;
			if (ref) ref.current = anchorRef.current;
			return /* @__PURE__ */ jsx(Fragment$1, {});
		}
	})] });
}
IssueActionsInternal.displayName = "IssueActionsInternal";
var UpdateStateButton = ({ disabled = false, issueState, buttonState, onClose, onReopen, onAction, hasComment = false, size = "medium", viewerCanReopen, viewerCanClose, duplicateIssue }) => {
	if (issueState !== "OPEN" && issueState !== "CLOSED") return null;
	const reason = getReason(issueState, buttonState);
	const viewerCanPerformAction = getViewerCanPerformAction(issueState, buttonState, viewerCanReopen, viewerCanClose);
	return createUpdateStatusButton(disabled, hasComment, issueState, reason, onAction, getOnStateChange(issueState, buttonState, reason, onClose, onReopen), viewerCanPerformAction, size, duplicateIssue);
};
UpdateStateButton.displayName = "UpdateStateButton";
var UpdateStateButtonOptions = (t0) => {
	const $ = c(13);
	const { buttonState, setButtonState, issueState, issueStateReason, canClose, canReopen, viewerCanClose, viewerCanReopen, setIsDuplicateDialogOpen } = t0;
	let t1;
	if ($[0] !== setButtonState || $[1] !== setIsDuplicateDialogOpen) {
		t1 = () => {
			setButtonState("DUPLICATE");
			setIsDuplicateDialogOpen(true);
		};
		$[0] = setButtonState;
		$[1] = setIsDuplicateDialogOpen;
		$[2] = t1;
	} else t1 = $[2];
	const onCloseAsDuplicateSelected = t1;
	let t2;
	if ($[3] !== buttonState || $[4] !== canClose || $[5] !== canReopen || $[6] !== issueState || $[7] !== issueStateReason || $[8] !== onCloseAsDuplicateSelected || $[9] !== setButtonState || $[10] !== viewerCanClose || $[11] !== viewerCanReopen) {
		t2 = jsxs(ActionList, {
			showDividers: true,
			selectionVariant: "single",
			"aria-roledescription": LABELS.updateIssueRoleDescription,
			className: IssueActions_module_default.issueStateOptionsMenu,
			children: [
				issueState === "CLOSED" && (viewerCanReopen || viewerCanReopen === void 0) && jsxs(ActionList.Item, {
					onSelect: () => setButtonState("OPEN"),
					selected: buttonState === "OPEN",
					disabled: !canReopen || !viewerCanReopen,
					children: [jsx(ActionList.LeadingVisual, {
						className: IssueActions_module_default.reopenIssueIcon,
						children: jsx(IssueReopenedIcon, {})
					}), LABELS.reOpenIssue]
				}, "reopen-issue-option"),
				(issueState === "OPEN" || issueStateReason === "NOT_PLANNED") && (viewerCanClose || viewerCanClose === void 0) && jsxs(ActionList.Item, {
					onSelect: () => setButtonState("CLOSED"),
					selected: buttonState === "CLOSED",
					disabled: !canClose || !viewerCanClose,
					children: [
						jsx(ActionList.LeadingVisual, {
							className: IssueActions_module_default.closeCompletedIssueIcon,
							children: jsx(IssueClosedIcon, {})
						}),
						LABELS.closeAsCompleted,
						jsx(ActionList.Description, {
							variant: "block",
							children: LABELS.actionListCompletedDescription
						})
					]
				}, "close-issue-option"),
				(issueState === "OPEN" || issueState === "CLOSED" && issueStateReason !== "NOT_PLANNED") && viewerCanClose && jsxs(ActionList.Item, {
					onSelect: () => setButtonState("NOT_PLANNED"),
					selected: buttonState === "NOT_PLANNED",
					disabled: !canClose,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(SkipIcon, {}) }),
						LABELS.closeAsNotPlanned,
						jsx(ActionList.Description, {
							variant: "block",
							children: LABELS.actionListNotPlannedNewDescription
						})
					]
				}, "skip-issue-option"),
				(issueState === "OPEN" || issueState === "CLOSED" && issueStateReason !== "DUPLICATE") && viewerCanClose && jsxs(ActionList.Item, {
					onSelect: onCloseAsDuplicateSelected,
					selected: buttonState === "DUPLICATE",
					disabled: !canClose,
					children: [
						jsx(ActionList.LeadingVisual, { children: jsx(SkipIcon, {}) }),
						jsx(ActionList.TrailingVisual, { children: jsx(ArrowRightIcon, {}) }),
						LABELS.closeAsDuplicate,
						jsx(ActionList.Description, {
							variant: "block",
							children: LABELS.actionListDuplicateDescription
						})
					]
				}, "close-duplicate-issue-option")
			]
		});
		$[3] = buttonState;
		$[4] = canClose;
		$[5] = canReopen;
		$[6] = issueState;
		$[7] = issueStateReason;
		$[8] = onCloseAsDuplicateSelected;
		$[9] = setButtonState;
		$[10] = viewerCanClose;
		$[11] = viewerCanReopen;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
};
UpdateStateButtonOptions.displayName = "UpdateStateButtonOptions";
var getInitialButtonState = (state) => {
	return state === "CLOSED" ? "OPEN" : "CLOSED";
};
function createUpdateStatusButton(disabled = false, hasComment, issueState, reason, onAction, onStateChange, viewerCanPerformAction, size, duplicateIssue) {
	const color = getColorForReason(reason);
	const icon = getIconForReason(reason);
	const label = getLabelForReason(issueState, hasComment, reason, duplicateIssue);
	const tooltipText = getTooltipTextForReason(reason);
	const tooltipId = getTooltipIdForReason(reason);
	const button = /* @__PURE__ */ jsx(ButtonComponent, {
		onClick: () => {
			onAction?.();
			onStateChange?.();
		},
		leadingVisual: () => /* @__PURE__ */ jsx(Octicon, {
			icon,
			sx: { color }
		}),
		disabled: disabled || !onStateChange || !viewerCanPerformAction,
		size,
		children: label
	});
	return viewerCanPerformAction ? button : /* @__PURE__ */ jsx(Tooltip, {
		text: tooltipText,
		direction: "w",
		"data-testid": tooltipId,
		children: button
	});
}
function getTooltipIdForReason(reason) {
	if (reason) return "close-button-tooltip";
	return "reopen-button-tooltip";
}
function getTooltipTextForReason(reason) {
	if (reason) return ERRORS.missingClosePermission;
	return ERRORS.missingReopenPermission;
}
function getColorForReason(reason) {
	switch (reason) {
		case "COMPLETED": return "done.fg";
		case "NOT_PLANNED": return "fg.muted";
		case "DUPLICATE": return "fg.muted";
		case void 0: return "open.fg";
		default: return "fg.default";
	}
}
function getIconForReason(reason) {
	switch (reason) {
		case "COMPLETED": return IssueClosedIcon;
		case "NOT_PLANNED": return SkipIcon;
		case "DUPLICATE": return SkipIcon;
		case void 0: return IssueReopenedIcon;
		default: return IssueClosedIcon;
	}
}
function getLabelForReason(issueState, hasComment, reason, duplicateIssue) {
	if (issueState === "OPEN") {
		if (reason === "DUPLICATE") return duplicateIssue ? LABELS.closeAsDuplicateOf(duplicateIssue.number) : LABELS.closeAsDuplicate;
		return hasComment ? LABELS.closeIssueWithComment : LABELS.closeIssue;
	}
	if (reason === "NOT_PLANNED") return LABELS.closeAsNotPlanned;
	if (reason === "DUPLICATE") return duplicateIssue ? LABELS.closeAsDuplicateOf(duplicateIssue.number) : LABELS.closeAsDuplicate;
	if (reason === void 0) return LABELS.reOpenIssue;
	return LABELS.closeAsCompleted;
}
function getReason(issueState, buttonState) {
	if (buttonState === "NOT_PLANNED") return "NOT_PLANNED";
	if (buttonState === "DUPLICATE") return "DUPLICATE";
	if (issueState === "OPEN") return "COMPLETED";
	if (buttonState === "CLOSED") return "COMPLETED";
}
function getViewerCanPerformAction(issueState, buttonState, viewerCanReopen, viewerCanClose) {
	return issueState === "CLOSED" && buttonState === "OPEN" ? viewerCanReopen : viewerCanClose;
}
function getOnStateChange(issueState, buttonState, reason, onClose, onReopen) {
	return issueState === "CLOSED" && buttonState === "OPEN" ? () => onReopen?.() : () => reason && onClose?.(reason);
}
/**
* GraphQL enum value constants used across the commenting package.
* These are subsets of the full GraphQL enums - only the values we need are defined here.
*/
/** Subset of ReactionContent enum values */
var REACTION_CONTENT = { THUMBS_UP: "THUMBS_UP" };
/** Subset of SubscriptionState enum values */
var SUBSCRIPTION_STATE = {
	SUBSCRIBED: "SUBSCRIBED",
	UNSUBSCRIBED: "UNSUBSCRIBED"
};
/** Subset of ThreadSubscriptionFormAction enum values */
var SUBSCRIPTION_FORM_ACTION = { UNSUBSCRIBE: "UNSUBSCRIBE" };
var LowQualityWarningBanner_module_default = {
	banner: "LowQualityWarningBanner-module_hMW08W_banner",
	bannerFading: "LowQualityWarningBanner-module_hMW08W_bannerFading",
	bannerOverlay: "LowQualityWarningBanner-module_hMW08W_bannerOverlay",
	bannerPadding: "LowQualityWarningBanner-module_hMW08W_bannerPadding",
	buttonContent: "LowQualityWarningBanner-module_hMW08W_buttonContent"
};
function LowQualityWarningBanner({ state, onDismiss, onLikeIssue, onSubscribe, onUnsubscribe, isFading = false }) {
	const labels = LABELS$1.lowQualityCommentWarning;
	const config = getBannerConfig(state);
	const action = {
		like: {
			label: labels.likeAction,
			onClick: onLikeIssue
		},
		subscribe: {
			label: labels.subscribeAction,
			onClick: onSubscribe
		},
		unsubscribe: {
			label: labels.unsubscribeAction,
			onClick: onUnsubscribe
		},
		none: null
	}[config.actionType];
	return /* @__PURE__ */ jsx("div", {
		className: clsx(LowQualityWarningBanner_module_default.bannerOverlay, isFading && LowQualityWarningBanner_module_default.bannerFading),
		inert: isFading ? true : void 0,
		children: /* @__PURE__ */ jsx(Banner, {
			hideTitle: true,
			variant: config.variant,
			layout: "compact",
			title: config.title,
			description: /* @__PURE__ */ jsx(AriaStatus, {
				announceOnShow: true,
				children: config.message
			}),
			secondaryAction: action && /* @__PURE__ */ jsx(Banner.SecondaryAction, {
				onClick: action.onClick,
				disabled: config.isLoading,
				children: /* @__PURE__ */ jsxs("span", {
					className: LowQualityWarningBanner_module_default.buttonContent,
					children: [config.isLoading && /* @__PURE__ */ jsx(Spinner, { size: "small" }), action.label]
				})
			}),
			onDismiss,
			flush: true,
			className: LowQualityWarningBanner_module_default.banner
		})
	});
}
LowQualityWarningBanner.displayName = "LowQualityWarningBanner";
function getBannerConfig(state) {
	const labels = LABELS$1.lowQualityCommentWarning;
	switch (state) {
		case LowQualityWarningState.ShowingLikeAction: return {
			variant: "warning",
			title: labels.title,
			message: labels.message,
			actionType: "like",
			isLoading: false
		};
		case LowQualityWarningState.ShowingSubscribeAction: return {
			variant: "warning",
			title: labels.title,
			message: labels.message,
			actionType: "subscribe",
			isLoading: false
		};
		case LowQualityWarningState.ShowingNoAction: return {
			variant: "warning",
			title: labels.title,
			message: labels.noActionsMessage,
			actionType: "none",
			isLoading: false
		};
		case LowQualityWarningState.Reacting:
		case LowQualityWarningState.LikedAutoSubscribing: return {
			variant: "warning",
			title: labels.title,
			message: labels.message,
			actionType: "like",
			isLoading: true
		};
		case LowQualityWarningState.Subscribing: return {
			variant: "warning",
			title: labels.title,
			message: labels.message,
			actionType: "subscribe",
			isLoading: true
		};
		case LowQualityWarningState.Unsubscribing: return {
			variant: "success",
			title: labels.subscribedTitle,
			message: labels.subscribedMessage,
			actionType: "unsubscribe",
			isLoading: true
		};
		case LowQualityWarningState.LikedOnly: return {
			variant: "success",
			title: labels.reactedTitle,
			message: labels.reactedMessage,
			actionType: "none",
			isLoading: false
		};
		case LowQualityWarningState.LikedAndSubscribed: return {
			variant: "success",
			title: labels.subscribedTitle,
			message: labels.likedAndSubscribedMessage,
			actionType: "unsubscribe",
			isLoading: false
		};
		case LowQualityWarningState.Subscribed: return {
			variant: "success",
			title: labels.subscribedTitle,
			message: labels.subscribedMessage,
			actionType: "unsubscribe",
			isLoading: false
		};
		case LowQualityWarningState.Unsubscribed: return {
			variant: "success",
			title: labels.unsubscribedTitle,
			message: labels.unsubscribedMessage,
			actionType: "subscribe",
			isLoading: false
		};
		case LowQualityWarningState.Resubscribing: return {
			variant: "success",
			title: labels.unsubscribedTitle,
			message: labels.unsubscribedMessage,
			actionType: "subscribe",
			isLoading: true
		};
		default: return {
			variant: "warning",
			title: labels.title,
			message: labels.message,
			actionType: "none",
			isLoading: false
		};
	}
}
/**
* Detects low-quality comments that could be replaced with emoji reactions.
*
* Based on https://github.com/refined-github/refined-github/blob/main/source/helpers/is-low-quality-comment.ts
*/
/** Multi-word phrases that indicate low-quality comments.
* These are matched first before single words to handle phrases like "me too" correctly.
*/
var LOW_QUALITY_PHRASES = [
	"me too",
	"same here",
	"same issue",
	"i agree"
];
/** Single words that indicate low-quality comments on their own.
* This is intentionally a narrow, high-confidence list to avoid false positives.
*/
var LOW_QUALITY_WORDS = [
	"bump",
	"ditto",
	"following",
	"same",
	"subscribe",
	"subscribed"
];
var lowQualityPhrasesRegex = new RegExp(String.raw`\b(${[...LOW_QUALITY_PHRASES].sort((a, b) => b.length - a.length).join("|")})\b`, "gi");
var lowQualityWordsRegex = new RegExp(String.raw`\b(${LOW_QUALITY_WORDS.join("|")})\b`, "gi");
/** GitHub shortcode emoji that represent simple reactions (e.g., :+1:, :thumbsup:). */
var REACTION_SHORTCODES = [
	":+1:",
	":-1:",
	":thumbsup:",
	":thumbsdown:",
	":clap:",
	":pray:",
	":ok_hand:",
	":raised_hands:",
	":100:",
	":fire:",
	":heart:",
	":eyes:",
	":rocket:",
	":tada:"
];
/** Escapes special regex characters in a string. */
var escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var shortcodeEmojiRegex = new RegExp(REACTION_SHORTCODES.map(escapeRegex).join("|"), "gi");
/**
* Reaction emoji that can be used as simple reactions (used for low-quality detection).
* Using an array instead of a string because some emoji like ⬆️ are multi-codepoint sequences
* (U+2B06 + U+FE0F) that would be split incorrectly in a character class.
* Includes both ⬆️ (with VS16) and ⬆ (without) to handle both input methods.
*/
var REACTION_EMOJI = [
	"👍",
	"👎",
	"👌",
	"🙏",
	"⬆️",
	"⬆",
	"💯"
];
var reactionEmojiRegex = new RegExp(REACTION_EMOJI.map(escapeRegex).join("|"), "gu");
/** Matches vote patterns like +1, -1, +100 */
var VOTE_PATTERN = "[+-]\\d+";
var votePatternRegex = new RegExp(VOTE_PATTERN, "g");
/**
* Negative reaction patterns (subset of above) - used to skip "like issue" action.
* Note: 👎 intentionally appears in both REACTION_EMOJI (for detection) and here (for action selection).
*/
var NEGATIVE_REACTION_SHORTCODES = [":-1:", ":thumbsdown:"];
var NEGATIVE_REACTION_EMOJI = ["👎"];
/** Pre-compiled patterns for negative reaction detection (no global flag = no lastIndex issues) */
var negativeShortcodePattern = new RegExp(NEGATIVE_REACTION_SHORTCODES.map(escapeRegex).join("|"), "i");
var negativeEmojiPattern = new RegExp(NEGATIVE_REACTION_EMOJI.map(escapeRegex).join("|"), "u");
/** Matches standalone negative vote patterns like -1, -100. Uses whitespace/start/end boundaries to avoid matching GH-123, RFC-1, dates, or CSS values like -1px. */
var negativeVotePatternRegex = /(?:^|\s)-\d+(?:\s|$)/;
/** Matches whitespace, punctuation, reaction emoji, skin tone modifiers, vote patterns (+1/-1) */
var nonSubstantiveContentRegex = new RegExp(`[\\s,.!?]+|${REACTION_EMOJI.map(escapeRegex).join("|")}|[\\u{1F3FB}-\\u{1F3FF}]|${VOTE_PATTERN}`, "gu");
/**
* Returns true if a comment could be replaced with a reaction (e.g., "+1", "me too", "👍").
*/
function isLowQualityComment(text) {
	if (!text || text.trim() === "") return false;
	return text.replaceAll(lowQualityPhrasesRegex, "").replaceAll(lowQualityWordsRegex, "").replaceAll(shortcodeEmojiRegex, "").replaceAll(nonSubstantiveContentRegex, "") === "";
}
/**
* Returns the fragments that triggered low-quality detection.
*/
function getLowQualityFragments(text) {
	if (!text || text.trim() === "") return [];
	const fragments = [];
	const lowerText = text.toLowerCase();
	for (const phrase of LOW_QUALITY_PHRASES) if (lowerText.includes(phrase)) fragments.push(phrase);
	const words = text.match(lowQualityWordsRegex) ?? [];
	fragments.push(...words.map((w) => w.toLowerCase()));
	const shortcodes = text.match(shortcodeEmojiRegex) ?? [];
	fragments.push(...shortcodes.map((s) => s.toLowerCase()));
	const votes = text.match(votePatternRegex) ?? [];
	fragments.push(...votes);
	const emoji = text.match(reactionEmojiRegex) ?? [];
	fragments.push(...emoji);
	return [...new Set(fragments)];
}
/**
* Returns true if a comment contains a negative reaction pattern (e.g., "-1", "👎", ":-1:").
* Used to determine if the "like issue" action should be skipped in favor of "subscribe".
*/
function isNegativeReactionComment(text) {
	if (!text || text.trim() === "") return false;
	return negativeShortcodePattern.test(text) || negativeEmojiPattern.test(text) || negativeVotePatternRegex.test(text);
}
var ANALYTICS_TARGET = "LOW_QUALITY_COMMENT_WARNING";
var AnalyticsEvent = {
	Shown: "comments.low_quality_warning.shown",
	Dismissed: "comments.low_quality_warning.dismissed",
	Liked: "comments.low_quality_warning.liked",
	LikeFailed: "comments.low_quality_warning.like_failed",
	Subscribed: "comments.low_quality_warning.subscribed",
	Unsubscribed: "comments.low_quality_warning.unsubscribed",
	SubmittedWithWarning: "comments.low_quality_warning.submitted_with_warning",
	CommentImproved: "comments.low_quality_warning.comment_improved"
};
var AutoSubscribeOutcome = {
	Skipped: "skipped",
	Success: "success",
	Failed: "failed"
};
var LowQualityWarningState = {
	Idle: "idle",
	ShowingLikeAction: "showing-like-action",
	ShowingSubscribeAction: "showing-subscribe-action",
	ShowingNoAction: "showing-no-action",
	Reacting: "reacting",
	LikedAutoSubscribing: "liked-auto-subscribing",
	LikedAndSubscribed: "liked-and-subscribed",
	LikedOnly: "liked-only",
	Subscribing: "subscribing",
	Subscribed: "subscribed",
	Unsubscribing: "unsubscribing",
	Unsubscribed: "unsubscribed",
	Resubscribing: "resubscribing",
	Dismissed: "dismissed"
};
/** States where the warning banner is actively showing */
var SHOWING_STATES = new Set([
	LowQualityWarningState.ShowingLikeAction,
	LowQualityWarningState.ShowingSubscribeAction,
	LowQualityWarningState.ShowingNoAction
]);
/** Minimum length to check for low-quality comments. Shortest realistic low-quality comment is 2 chars (e.g., "+1", "ok"). */
var MIN_LENGTH_FOR_LOW_QUALITY_CHECK = 2;
/** Debounce delay for low-quality comment detection (ms) */
var LOW_QUALITY_CHECK_DEBOUNCE_MS = 1e3;
/** Delay before starting fade-out after the comment quality improves (ms) */
var AUTO_DISMISS_DELAY = 2e3;
/**
* Determines the initial warning state based on viewer's existing like/subscribe status.
*
* The logic prioritizes showing the most useful action:
* - If viewer hasn't liked AND comment isn't negative → show "Like" action
* - If viewer has liked OR comment is negative (liking doesn't make sense) →
*   - If not subscribed → show "Subscribe" action
*   - If already subscribed → show message only (no actions)
*/
function getInitialWarningState({ viewerHasLiked, viewerIsSubscribed, isNegativeReaction }) {
	if (!(viewerHasLiked || isNegativeReaction)) return LowQualityWarningState.ShowingLikeAction;
	if (!viewerIsSubscribed) return LowQualityWarningState.ShowingSubscribeAction;
	return LowQualityWarningState.ShowingNoAction;
}
/**
* Hook that detects low-quality comments and returns a warning banner.
*
* The banner actions depend on the viewer's existing state:
* - Not liked + Not subscribed: Like → Auto-subscribe → Show Unsubscribe
* - Not liked + Subscribed: Like only → Done
* - Liked + Not subscribed: Subscribe → Show Unsubscribe
* - Liked + Subscribed: No actions, just message
*
* @example
* ```tsx
* const { banner } = useLowQualityWarning({
*   markdownBody,
*   issueId: issue.id,
*   viewerHasLiked,
*   viewerIsSubscribed,
*   onDismiss: () => commentBoxRef.current?.focus(),
* })
*
* return <CommentBox infoBanner={banner} ... />
* ```
*/
function useLowQualityWarning({ markdownBody, issueId, viewerHasLiked, viewerIsSubscribed, isViewerDataLoaded = true, onDismiss }) {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { sendAnalyticsEvent } = useAnalytics();
	const { addToast } = useToastContext();
	const sendLowQualityAnalytics = useCallback((event, payload) => {
		sendAnalyticsEvent(event, ANALYTICS_TARGET, payload);
	}, [sendAnalyticsEvent]);
	const lowQualityWarningEnabled = useFeatureFlag("issues_react_low_quality_comment_warning");
	const [state, setState] = useState(LowQualityWarningState.Idle);
	const [isFading, setIsFading] = useState(false);
	const shownRef = useRef(false);
	const triggeringFragmentsRef = useRef([]);
	const stateBeforeUnsubscribingRef = useRef(LowQualityWarningState.Idle);
	const viewerIsSubscribedRef = useRef(viewerIsSubscribed);
	const stateRef = useRef(state);
	const onDismissRef = useRef(onDismiss);
	useEffect(() => {
		viewerIsSubscribedRef.current = viewerIsSubscribed;
		stateRef.current = state;
		onDismissRef.current = onDismiss;
	}, [
		viewerIsSubscribed,
		state,
		onDismiss
	]);
	const checkLowQualityComment = useDebounce(useCallback((text) => {
		if (lowQualityWarningEnabled && text.trim().length >= MIN_LENGTH_FOR_LOW_QUALITY_CHECK && isLowQualityComment(text)) {
			triggeringFragmentsRef.current = getLowQualityFragments(text);
			const initialState = getInitialWarningState({
				viewerHasLiked,
				viewerIsSubscribed,
				isNegativeReaction: isNegativeReactionComment(text)
			});
			startTransition(() => setState(initialState));
		}
	}, [
		lowQualityWarningEnabled,
		viewerHasLiked,
		viewerIsSubscribed
	]), LOW_QUALITY_CHECK_DEBOUNCE_MS, {
		leading: false,
		trailing: true
	});
	useEffect(() => {
		if (state === LowQualityWarningState.Idle && markdownBody.trim().length > 0 && isViewerDataLoaded) checkLowQualityComment(markdownBody);
	}, [
		markdownBody,
		state,
		isViewerDataLoaded,
		checkLowQualityComment
	]);
	const { safeSetTimeout, safeClearTimeout } = useSafeTimeout();
	const fadeTimerRef = useRef(0);
	const dismissTimerRef = useRef(0);
	const isAutoDismissingRef = useRef(false);
	const hasReportedImprovementRef = useRef(false);
	const startAutoDismiss = useCallback(() => {
		safeClearTimeout(fadeTimerRef.current);
		safeClearTimeout(dismissTimerRef.current);
		isAutoDismissingRef.current = true;
		fadeTimerRef.current = safeSetTimeout(() => setIsFading(true), AUTO_DISMISS_DELAY);
		dismissTimerRef.current = safeSetTimeout(() => {
			setState(LowQualityWarningState.Dismissed);
			setIsFading(false);
			isAutoDismissingRef.current = false;
			onDismissRef.current?.();
		}, AUTO_DISMISS_DELAY + 200);
	}, [safeSetTimeout, safeClearTimeout]);
	const cancelAutoDismiss = useCallback(() => {
		safeClearTimeout(fadeTimerRef.current);
		safeClearTimeout(dismissTimerRef.current);
		isAutoDismissingRef.current = false;
		setIsFading(false);
	}, [safeClearTimeout]);
	const recheckQuality = useDebounce(useCallback((text_0) => {
		const currentState = stateRef.current;
		if (!SHOWING_STATES.has(currentState)) return;
		if (!(text_0.trim().length >= MIN_LENGTH_FOR_LOW_QUALITY_CHECK)) return;
		const isStillLowQuality = isLowQualityComment(text_0);
		if (!isStillLowQuality && !isAutoDismissingRef.current) {
			if (!hasReportedImprovementRef.current) {
				sendLowQualityAnalytics(AnalyticsEvent.CommentImproved);
				hasReportedImprovementRef.current = true;
			}
			startAutoDismiss();
		}
		if (isStillLowQuality && isAutoDismissingRef.current) cancelAutoDismiss();
	}, [
		sendLowQualityAnalytics,
		startAutoDismiss,
		cancelAutoDismiss
	]), 500, {
		leading: false,
		trailing: true
	});
	useEffect(() => {
		if (SHOWING_STATES.has(state)) recheckQuality(markdownBody);
	}, [
		markdownBody,
		state,
		recheckQuality
	]);
	const isShowingState = SHOWING_STATES.has(state);
	useEffect(() => {
		if (isShowingState && !shownRef.current) {
			shownRef.current = true;
			sendLowQualityAnalytics(AnalyticsEvent.Shown);
		}
	}, [isShowingState, sendLowQualityAnalytics]);
	const handleDismiss = useCallback(() => {
		sendLowQualityAnalytics(AnalyticsEvent.Dismissed);
		setState(LowQualityWarningState.Dismissed);
		onDismiss?.();
	}, [sendLowQualityAnalytics, onDismiss]);
	const trackSubmittedWithWarning = useCallback((currentBody) => {
		if (shownRef.current && triggeringFragmentsRef.current.length > 0) sendLowQualityAnalytics(AnalyticsEvent.SubmittedWithWarning, {
			triggering_fragments: triggeringFragmentsRef.current.join(","),
			is_still_low_quality: isLowQualityComment(currentBody)
		});
	}, [sendLowQualityAnalytics]);
	const handleLikeIssue = useCallback(() => {
		setState(LowQualityWarningState.Reacting);
		addReactionMutation({
			environment,
			input: {
				subject: issueId,
				content: REACTION_CONTENT.THUMBS_UP
			},
			onCompleted: () => {
				if (viewerIsSubscribedRef.current) {
					setState(LowQualityWarningState.LikedOnly);
					sendLowQualityAnalytics(AnalyticsEvent.Liked, { autoSubscribeOutcome: AutoSubscribeOutcome.Skipped });
				} else {
					setState(LowQualityWarningState.LikedAutoSubscribing);
					commitUpdateIssueSubscriptionMutation({
						environment,
						input: {
							subscribableId: issueId,
							state: SUBSCRIPTION_STATE.SUBSCRIBED
						},
						onCompleted: () => {
							setState(LowQualityWarningState.LikedAndSubscribed);
							sendLowQualityAnalytics(AnalyticsEvent.Liked, { autoSubscribeOutcome: AutoSubscribeOutcome.Success });
						},
						onError: () => {
							setState(LowQualityWarningState.LikedOnly);
							sendLowQualityAnalytics(AnalyticsEvent.Liked, { autoSubscribeOutcome: AutoSubscribeOutcome.Failed });
							addToast({
								type: "error",
								message: ERRORS$1.couldNotSubscribe
							});
						}
					});
				}
			},
			onError: () => {
				setState(LowQualityWarningState.ShowingLikeAction);
				sendLowQualityAnalytics(AnalyticsEvent.LikeFailed);
				addToast({
					type: "error",
					message: ERRORS$1.couldNotReact
				});
			}
		});
	}, [
		issueId,
		environment,
		sendLowQualityAnalytics,
		addToast
	]);
	const handleSubscribe = useCallback(() => {
		const isResubscribing = state === LowQualityWarningState.Unsubscribed;
		setState(isResubscribing ? LowQualityWarningState.Resubscribing : LowQualityWarningState.Subscribing);
		commitUpdateIssueSubscriptionMutation({
			environment,
			input: {
				subscribableId: issueId,
				state: SUBSCRIPTION_STATE.SUBSCRIBED
			},
			onCompleted: () => {
				setState(LowQualityWarningState.Subscribed);
				sendLowQualityAnalytics(AnalyticsEvent.Subscribed);
			},
			onError: () => {
				setState(isResubscribing ? LowQualityWarningState.Unsubscribed : LowQualityWarningState.ShowingSubscribeAction);
				addToast({
					type: "error",
					message: ERRORS$1.couldNotSubscribe
				});
			}
		});
	}, [
		issueId,
		environment,
		state,
		sendLowQualityAnalytics,
		addToast
	]);
	const handleUnsubscribe = useCallback(() => {
		stateBeforeUnsubscribingRef.current = state;
		setState(LowQualityWarningState.Unsubscribing);
		commitUpdateIssueSubscriptionMutation({
			environment,
			input: {
				subscribableId: issueId,
				state: SUBSCRIPTION_STATE.UNSUBSCRIBED
			},
			onCompleted: () => {
				sendLowQualityAnalytics(AnalyticsEvent.Unsubscribed);
				setState(LowQualityWarningState.Unsubscribed);
			},
			onError: () => {
				setState(stateBeforeUnsubscribingRef.current);
				addToast({
					type: "error",
					message: ERRORS$1.couldNotUnsubscribe
				});
			}
		});
	}, [
		issueId,
		environment,
		state,
		sendLowQualityAnalytics,
		addToast
	]);
	const showBanner = state !== LowQualityWarningState.Idle && state !== LowQualityWarningState.Dismissed;
	return {
		banner: showBanner ? /* @__PURE__ */ jsx(LowQualityWarningBanner, {
			state,
			onDismiss: isFading ? () => {} : handleDismiss,
			onLikeIssue: handleLikeIssue,
			onSubscribe: handleSubscribe,
			onUnsubscribe: handleUnsubscribe,
			isFading
		}) : void 0,
		bannerPaddingClassName: showBanner ? LowQualityWarningBanner_module_default.bannerPadding : void 0,
		isBannerVisible: showBanner && !isFading,
		trackSubmittedWithWarning
	};
}
var HOTKEYS = { focusCommentComposer: "r" };
function useMarkdownBody(t0) {
	const $ = c(31);
	const { commentBoxRef, markdownComposerRef, onChange, onCancel, referenceId, insidePortal } = t0;
	let t1;
	if ($[0] !== referenceId) {
		t1 = VALUES.localStorageKeys.issueNewComment("viewer", referenceId);
		$[0] = referenceId;
		$[1] = t1;
	} else t1 = $[1];
	const [presavedComment, setPresavedComment, resetPresavedComment] = useSessionStorage(t1, "");
	const [markdownBody, setMarkdownBody] = useState(presavedComment);
	let t2;
	if ($[2] !== markdownBody) {
		t2 = validateComment(markdownBody);
		$[2] = markdownBody;
		$[3] = t2;
	} else t2 = $[3];
	const markdownValidationResult = t2;
	const { anyItemPickerOpen } = useItemPickersContext();
	let t3;
	if ($[4] !== setPresavedComment) {
		t3 = (newMarkdown) => {
			setMarkdownBody(newMarkdown);
			setPresavedComment(newMarkdown);
		};
		$[4] = setPresavedComment;
		$[5] = t3;
	} else t3 = $[5];
	const changeMarkdownBody = t3;
	let t4;
	if ($[6] !== changeMarkdownBody || $[7] !== onCancel || $[8] !== onChange) {
		t4 = (newMarkdown_0) => {
			changeMarkdownBody(newMarkdown_0);
			onChange();
			if (newMarkdown_0 === "") onCancel();
		};
		$[6] = changeMarkdownBody;
		$[7] = onCancel;
		$[8] = onChange;
		$[9] = t4;
	} else t4 = $[9];
	const handleMarkdownBodyChanged = t4;
	let t5;
	let t6;
	if ($[10] !== commentBoxRef || $[11] !== handleMarkdownBodyChanged || $[12] !== markdownBody) {
		t5 = () => ({
			appendText: (text) => {
				handleMarkdownBodyChanged(`${markdownBody}\n\n${text}`);
			},
			setText: (text_0) => {
				handleMarkdownBodyChanged(text_0);
			},
			focus: () => {
				commentBoxRef.current?.focus();
			}
		});
		t6 = [
			handleMarkdownBodyChanged,
			markdownBody,
			commentBoxRef
		];
		$[10] = commentBoxRef;
		$[11] = handleMarkdownBodyChanged;
		$[12] = markdownBody;
		$[13] = t5;
		$[14] = t6;
	} else {
		t5 = $[13];
		t6 = $[14];
	}
	useImperativeHandle(markdownComposerRef, t5, t6);
	let t7;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = areCharacterKeyShortcutsEnabled();
		$[15] = t7;
	} else t7 = $[15];
	const singleKeyShortcutIsEnabled = t7;
	let t8;
	if ($[16] !== anyItemPickerOpen || $[17] !== changeMarkdownBody || $[18] !== commentBoxRef) {
		t8 = (e) => {
			if (!singleKeyShortcutIsEnabled || anyItemPickerOpen()) return;
			if (commentBoxRef && commentBoxRef.current) {
				e.preventDefault();
				const current = window.getSelection();
				if (current && current.anchorNode) {
					const selectionContext = {
						anchorNode: current.anchorNode,
						range: current.getRangeAt(0)
					};
					const container = current.anchorNode.parentElement;
					const quotedItem = container?.closest(withClassSelector(CLASS_NAMES.issueComment)) ?? container?.closest(withClassSelector(CLASS_NAMES.issueBody));
					if (quotedItem && quotedItem instanceof HTMLDivElement) changeMarkdownBody(`${selectQuoteFromComment(quotedItem, selectionContext)}`);
				}
				commentBoxRef.current.scrollIntoView();
				commentBoxRef.current.focus();
			}
		};
		$[16] = anyItemPickerOpen;
		$[17] = changeMarkdownBody;
		$[18] = commentBoxRef;
		$[19] = t8;
	} else t8 = $[19];
	const onFocusShortcutActivated = t8;
	let t9;
	if ($[20] !== commentBoxRef || $[21] !== resetPresavedComment) {
		t9 = () => {
			if (commentBoxRef.current) commentBoxRef.current.reset();
			else setMarkdownBody("");
			resetPresavedComment();
		};
		$[20] = commentBoxRef;
		$[21] = resetPresavedComment;
		$[22] = t9;
	} else t9 = $[22];
	const resetMarkdownBody = t9;
	let t10;
	if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = [HOTKEYS.focusCommentComposer];
		$[23] = t10;
	} else t10 = $[23];
	let t11;
	if ($[24] !== insidePortal) {
		t11 = {
			triggerWhenInputElementHasFocus: false,
			triggerWhenPortalIsActive: insidePortal
		};
		$[24] = insidePortal;
		$[25] = t11;
	} else t11 = $[25];
	useKeyPress(t10, onFocusShortcutActivated, t11);
	let t12;
	if ($[26] !== handleMarkdownBodyChanged || $[27] !== markdownBody || $[28] !== markdownValidationResult || $[29] !== resetMarkdownBody) {
		t12 = {
			handleMarkdownBodyChanged,
			markdownValidationResult,
			markdownBody,
			resetMarkdownBody
		};
		$[26] = handleMarkdownBodyChanged;
		$[27] = markdownBody;
		$[28] = markdownValidationResult;
		$[29] = resetMarkdownBody;
		$[30] = t12;
	} else t12 = $[30];
	return t12;
}
var MAX_CONDENSED_WIDTH = 768;
function useMarkdownStyles(composerRef) {
	const [condensed, setCondensed] = useState(false);
	const updateCondensedState = useCallback(() => {
		setCondensed((composerRef?.current?.clientWidth || MAX_CONDENSED_WIDTH) < MAX_CONDENSED_WIDTH);
	}, [composerRef]);
	useResizeObserver(() => {
		updateCondensedState();
	}, composerRef);
	useEffect(() => {
		updateCondensedState();
	}, []);
	return { condensed };
}
function useMetaAndShiftKeys() {
	const $ = c(4);
	const [metaAndShiftKeysPressed, setMetaAndShiftKeysPressed] = useState(false);
	let t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			const handleKeyDown = (e) => setMetaAndShiftKeysPressed((e.ctrlKey || e.metaKey) && e.shiftKey);
			const handleKeyUp = () => setMetaAndShiftKeysPressed(false);
			window.addEventListener("keydown", handleKeyDown);
			window.addEventListener("keyup", handleKeyUp);
			window.addEventListener("blur", handleKeyUp);
			return () => {
				window.removeEventListener("keydown", handleKeyDown);
				window.removeEventListener("keyup", handleKeyUp);
				window.removeEventListener("blur", handleKeyUp);
			};
		};
		t1 = [];
		$[0] = t0;
		$[1] = t1;
	} else {
		t0 = $[0];
		t1 = $[1];
	}
	useEffect(t0, t1);
	let t2;
	if ($[2] !== metaAndShiftKeysPressed) {
		t2 = { metaAndShiftKeysPressed };
		$[2] = metaAndShiftKeysPressed;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "connections"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [v2], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "createdAt",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v10 = [v8], v11 = [v9], v12 = {
		"kind": "InlineFragment",
		"selections": v3,
		"type": "Node",
		"abstractKey": "__isNode"
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "addCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddCommentPayload",
				"kind": "LinkedField",
				"name": "addComment",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "IssueTimelineItemEdge",
					"kind": "LinkedField",
					"name": "timelineEdge",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "node",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "IssueCommentViewerCommentRow"
						}, {
							"args": null,
							"kind": "FragmentSpread",
							"name": "IssueComment_issueComment"
						}],
						"storageKey": null
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subject",
					"plural": false,
					"selections": v3,
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "addCommentMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddCommentPayload",
				"kind": "LinkedField",
				"name": "addComment",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"concreteType": "IssueTimelineItemEdge",
						"kind": "LinkedField",
						"name": "timelineEdge",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "node",
							"plural": false,
							"selections": [
								v4,
								{
									"kind": "InlineFragment",
									"selections": [
										v2,
										v5,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "body",
											"storageKey": null
										},
										{
											"alias": null,
											"args": [{
												"kind": "Literal",
												"name": "unfurlReferences",
												"value": true
											}],
											"kind": "ScalarField",
											"name": "bodyHTML",
											"storageKey": "bodyHTML(unfurlReferences:true)"
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "bodyVersion",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanUpdate",
											"storageKey": null
										},
										v6,
										v7,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "authorAssociation",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanDelete",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanMinimize",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanUnminimize",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanReport",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanReportToMaintainer",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanBlockFromOrg",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanUnblockFromOrg",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanPin",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerCanUnpin",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "App",
											"kind": "LinkedField",
											"name": "viaApp",
											"plural": false,
											"selections": [
												v8,
												v6,
												v2
											],
											"storageKey": null
										},
										{
											"alias": "isHidden",
											"args": null,
											"kind": "ScalarField",
											"name": "isMinimized",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "minimizedReason",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "showSpammyBadge",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "createdViaEmail",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "viewerDidAuthor",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "Sponsorship",
											"kind": "LinkedField",
											"name": "authorToRepoOwnerSponsorship",
											"plural": false,
											"selections": [
												v7,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "isActive",
													"storageKey": null
												},
												v2
											],
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "author",
											"plural": false,
											"selections": [
												v4,
												v2,
												v9,
												{
													"kind": "InlineFragment",
													"selections": v10,
													"type": "User",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": v10,
													"type": "EnterpriseUserAccount",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": v10,
													"type": "Mannequin",
													"abstractKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "avatarUrl",
													"storageKey": null
												}
											],
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "Repository",
											"kind": "LinkedField",
											"name": "repository",
											"plural": false,
											"selections": [
												v2,
												v8,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "owner",
													"plural": false,
													"selections": [
														v4,
														v2,
														v9,
														v6
													],
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "isPrivate",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "slashCommandsEnabled",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "nameWithOwner",
													"storageKey": null
												},
												v5
											],
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "Issue",
											"kind": "LinkedField",
											"name": "issue",
											"plural": false,
											"selections": [
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "number",
													"storageKey": null
												},
												v2,
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "locked",
													"storageKey": null
												},
												v5,
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "author",
													"plural": false,
													"selections": [
														v4,
														v9,
														v2
													],
													"storageKey": null
												}
											],
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "User",
											"kind": "LinkedField",
											"name": "pinnedBy",
											"plural": false,
											"selections": [v9, v2],
											"storageKey": null
										},
										{
											"kind": "InlineFragment",
											"selections": [
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "viewerCanReadUserContentEdits",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "lastEditedAt",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"concreteType": "UserContentEdit",
													"kind": "LinkedField",
													"name": "lastUserContentEdit",
													"plural": false,
													"selections": [{
														"alias": null,
														"args": null,
														"concreteType": null,
														"kind": "LinkedField",
														"name": "editor",
														"plural": false,
														"selections": [
															v4,
															v6,
															v9,
															v2
														],
														"storageKey": null
													}, v2],
													"storageKey": null
												}
											],
											"type": "Comment",
											"abstractKey": "__isComment"
										},
										{
											"kind": "ClientExtension",
											"selections": [
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "pendingMinimizeReason",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "pendingBlock",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "pendingUnblock",
													"storageKey": null
												}
											]
										},
										{
											"kind": "InlineFragment",
											"selections": [{
												"alias": null,
												"args": null,
												"concreteType": "ReactionGroup",
												"kind": "LinkedField",
												"name": "reactionGroups",
												"plural": true,
												"selections": [
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "content",
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "viewerHasReacted",
														"storageKey": null
													},
													{
														"alias": null,
														"args": [{
															"kind": "Literal",
															"name": "first",
															"value": 5
														}],
														"concreteType": "ReactorConnection",
														"kind": "LinkedField",
														"name": "reactors",
														"plural": false,
														"selections": [{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "totalCount",
															"storageKey": null
														}, {
															"alias": null,
															"args": null,
															"concreteType": null,
															"kind": "LinkedField",
															"name": "nodes",
															"plural": true,
															"selections": [
																v4,
																{
																	"kind": "InlineFragment",
																	"selections": v11,
																	"type": "User",
																	"abstractKey": null
																},
																{
																	"kind": "InlineFragment",
																	"selections": [
																		v9,
																		{
																			"alias": null,
																			"args": null,
																			"kind": "ScalarField",
																			"name": "isCopilot",
																			"storageKey": null
																		},
																		{
																			"alias": null,
																			"args": null,
																			"kind": "ScalarField",
																			"name": "isAgent",
																			"storageKey": null
																		},
																		{
																			"alias": null,
																			"args": null,
																			"kind": "ScalarField",
																			"name": "displayName",
																			"storageKey": null
																		}
																	],
																	"type": "Bot",
																	"abstractKey": null
																},
																{
																	"kind": "InlineFragment",
																	"selections": v11,
																	"type": "Organization",
																	"abstractKey": null
																},
																{
																	"kind": "InlineFragment",
																	"selections": v11,
																	"type": "Mannequin",
																	"abstractKey": null
																},
																v12
															],
															"storageKey": null
														}],
														"storageKey": "reactors(first:5)"
													}
												],
												"storageKey": null
											}],
											"type": "Reactable",
											"abstractKey": "__isReactable"
										}
									],
									"type": "IssueComment",
									"abstractKey": null
								},
								v12
							],
							"storageKey": null
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"filters": null,
						"handle": "appendEdge",
						"key": "",
						"kind": "LinkedHandle",
						"name": "timelineEdge",
						"handleArgs": [{
							"kind": "Variable",
							"name": "connections",
							"variableName": "connections"
						}]
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "subject",
						"plural": false,
						"selections": [v4, v2],
						"storageKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "edafa18ab5734f05c9893cbc92d0dfb1",
			"metadata": {},
			"name": "addCommentMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "1b7d8e14670bb26b4f6889905fe612c7";
function getOptimisticResponse(optimisticInput, withOptimisticResponse, body, subject, environment) {
	if (!optimisticInput || !withOptimisticResponse) return;
	const store = environment.getStore().getSource();
	const repositoryRecord = store.get(optimisticInput.repositoryId);
	const issueRecord = store.get(subject);
	if (!repositoryRecord || !issueRecord) return;
	const repository = repositoryRecord;
	const issue = issueRecord;
	const ownerRef = repository.owner;
	const authorRef = issue.author;
	const ownerRecord = ownerRef ? store.get(ownerRef.__ref) : void 0;
	const authorRecord = authorRef ? store.get(authorRef.__ref) : void 0;
	if (!ownerRecord || !authorRecord) return;
	const owner = ownerRecord;
	const author = authorRecord;
	if (!owner || !author) return;
	return withOptimisticResponse && optimisticInput ? { addComment: {
		timelineEdge: { node: {
			__typename: "IssueComment",
			__isComment: "IssueComment",
			__isNode: "IssueComment",
			__isReactable: "IssueComment",
			id: `temp-comment-${Date.now()}`,
			body: body ? body : "",
			bodyHTML: md2html(body),
			bodyVersion: "1",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			lastEditedAt: null,
			viewerCanReadUserContentEdits: true,
			lastUserContentEdit: null,
			author: {
				__typename: "User",
				id: optimisticInput.commentAuthor.id,
				avatarUrl: optimisticInput.commentAuthor.avatarUrl,
				login: optimisticInput.commentAuthor.login,
				name: optimisticInput.commentAuthor.name
			},
			authorAssociation: optimisticInput.authorAssociation,
			authorToRepoOwnerSponsorship: null,
			createdViaEmail: false,
			viaApp: null,
			databaseId: null,
			isHidden: false,
			issue: {
				id: subject,
				databaseId: issue.databaseId,
				locked: issue.locked,
				number: issue.number,
				author: {
					__typename: author.__typename,
					id: author.id,
					login: author.login
				}
			},
			minimizedReason: null,
			pendingMinimizeReason: null,
			pendingBlock: null,
			pendingUnblock: null,
			reactionGroups: [],
			repository: {
				id: repository.id,
				databaseId: repository.databaseId,
				isPrivate: repository.isPrivate,
				name: repository.name,
				nameWithOwner: repository.nameWithOwner,
				slashCommandsEnabled: repository.slashCommandsEnabled,
				owner: {
					__typename: owner.__typename,
					id: owner.id,
					login: owner.login,
					url: owner.url
				}
			},
			showSpammyBadge: false,
			url: "",
			viewerCanBlockFromOrg: false,
			viewerCanDelete: false,
			viewerCanMinimize: false,
			viewerCanUnminimize: false,
			viewerCanReport: false,
			viewerCanReportToMaintainer: false,
			viewerCanUnblockFromOrg: false,
			viewerCanUpdate: false,
			viewerDidAuthor: true,
			viewerCanPin: false,
			viewerCanUnpin: false,
			pinnedBy: null
		} },
		subject: {
			__typename: "Issue",
			id: subject
		}
	} } : void 0;
}
function addCommentMutation({ environment, input: { subject, body, connectionId }, onError, onCompleted, withOptimisticResponse = false, optimisticInput }) {
	const inputHash = {
		subjectId: subject,
		body: body ? body : ""
	};
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		optimisticResponse: getOptimisticResponse(optimisticInput, withOptimisticResponse, body, subject, environment),
		variables: {
			input: inputHash,
			connections: [connectionId]
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => {
			if (!response.addComment) onError?.();
			else onCompleted?.();
		}
	});
}
function blockedCommentingReason(isRepoArchived, isReferenceLocked, customReason = null, subjectType = "issue", isRepoLocked = false) {
	if (isRepoArchived) return LABELS$1.repoArchived;
	if (isRepoLocked) return LABELS$1.repoLockedForMigration;
	if (isReferenceLocked) return LABELS$1.issueLockedToCollaborators;
	if (customReason) return customReason;
	return LABELS$1.canNotComment(subjectType);
}
var Shared_module_default = {
	CommentBox: "Shared-module_7E_81a_CommentBox",
	Condensed: "Shared-module_7E_81a_Condensed"
};
var IssueCommentComposer_module_default = {
	avatarLink: "IssueCommentComposer-module_oo8otq_avatarLink",
	commentBoxWrapper: "IssueCommentComposer-module_oo8otq_commentBoxWrapper",
	commentComposer: "IssueCommentComposer-module_oo8otq_commentComposer",
	commentComposerWrapper: "IssueCommentComposer-module_oo8otq_commentComposerWrapper",
	ContributorFooter: "IssueCommentComposer-module_oo8otq_ContributorFooter",
	heading: "IssueCommentComposer-module_oo8otq_heading"
};
var IssueCommentComposer = ({ ref, onChange, onSave, onCancel, onNewIssueComment, onStateChange, issue, issueSecondary, viewer, fileUploadsEnabled, insideSidePanel, relayConnectionId }) => {
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const data = (0, import_react_relay.useFragment)(node$7, issue);
	const secondaryData = (0, import_react_relay.useFragment)(node$6, issueSecondary);
	const slashCommandsEnabled = secondaryData?.repository.slashCommandsEnabled ?? false;
	const viewerData = (0, import_react_relay.useFragment)(node$5, viewer);
	const { id: issueId } = data;
	const commentBoxRef = useRef(null);
	const commentComposerRef = useRef(null);
	const repositoryDatabaseId = data.repository.databaseId;
	const isRepoArchived = data.repository.isArchived;
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [closeButtonState, setCloseButtonState] = useState("OPEN");
	const { condensed } = useMarkdownStyles(commentComposerRef);
	const cantCommentReason = blockedCommentingReason(isRepoArchived, data.locked, !data.repository.viewerCanInteract ? data.repository.viewerInteractionLimitReasonHTML : null, "issue", secondaryData?.repository?.isLocked ?? false);
	const { metaAndShiftKeysPressed } = useMetaAndShiftKeys();
	const { markdownBody, resetMarkdownBody, markdownValidationResult, handleMarkdownBodyChanged } = useMarkdownBody({
		commentBoxRef,
		markdownComposerRef: ref ?? null,
		onChange,
		onCancel,
		referenceId: issueId,
		insidePortal: insideSidePanel
	});
	const viewerHasLiked = (secondaryData?.reactionGroups?.find((group) => group.content === REACTION_CONTENT.THUMBS_UP))?.viewerHasReacted ?? false;
	const viewerIsSubscribed = secondaryData?.viewerThreadSubscriptionFormAction === SUBSCRIPTION_FORM_ACTION.UNSUBSCRIBE;
	const { banner: lowQualityWarningBanner, bannerPaddingClassName, trackSubmittedWithWarning } = useLowQualityWarning({
		markdownBody,
		issueId: data.id,
		viewerHasLiked,
		viewerIsSubscribed,
		isViewerDataLoaded: !!secondaryData,
		onDismiss: useCallback(() => commentBoxRef.current?.focus(), [])
	});
	const onCommentSave = useCallback((subject, skipStateChange = false) => {
		const withOptimisticResponse = canBeOptimisticallyParsed(markdownBody);
		setIsSubmitting(true);
		if (markdownBody?.length > 0) {
			trackSubmittedWithWarning(markdownBody);
			const originalMarkdownBody = markdownBody;
			resetMarkdownBody();
			addCommentMutation({
				environment,
				input: {
					subject,
					body: originalMarkdownBody,
					connectionId: relayConnectionId ?? import_relay_runtime.ConnectionHandler.getConnectionID(data.id, "Issue__backTimelineItems", { visibleEventsOnly: true })
				},
				onError: () => {
					setIsSubmitting(false);
					handleMarkdownBodyChanged(originalMarkdownBody);
					addToast({
						type: "error",
						message: ERRORS$1.couldNotComment
					});
				},
				onCompleted: () => {
					setIsSubmitting(false);
					onNewIssueComment?.();
				},
				withOptimisticResponse,
				optimisticInput: secondaryData ? {
					commentAuthor: {
						id: viewerData.id,
						login: viewerData.login,
						avatarUrl: viewerData.avatarUrl,
						name: viewerData.name
					},
					repositoryId: data.repository.id,
					authorAssociation: secondaryData.authorAssociation
				} : void 0
			});
		}
		if (metaAndShiftKeysPressed && !skipStateChange) {
			if (closeButtonState === "CLOSED" && secondaryData?.viewerCanClose) commitCloseIssueMutation({
				environment,
				input: {
					issueId: data?.id,
					newStateReason: "COMPLETED"
				},
				onError: () => addToast({
					type: "error",
					message: ERRORS$1.couldNotCloseIssue
				}),
				onCompleted: () => {
					onNewIssueComment?.();
					onStateChange?.();
				}
			});
			else if (closeButtonState === "NOT_PLANNED" && secondaryData?.viewerCanClose) commitCloseIssueMutation({
				environment,
				input: {
					issueId: data?.id,
					newStateReason: "NOT_PLANNED"
				},
				onError: () => addToast({
					type: "error",
					message: ERRORS$1.couldNotCloseIssue
				}),
				onCompleted: () => {
					onNewIssueComment?.();
					onStateChange?.();
				}
			});
			else if (closeButtonState === "OPEN" && secondaryData?.viewerCanReopen) commitReopenIssueMutation({
				environment,
				input: { issueId: data?.id },
				onError: () => addToast({
					type: "error",
					message: ERRORS$1.couldNotCloseIssue
				}),
				onCompleted: () => {
					onNewIssueComment?.();
					onStateChange?.();
				}
			});
		}
		onSave();
	}, [
		markdownBody,
		metaAndShiftKeysPressed,
		onSave,
		data.id,
		data.repository.id,
		environment,
		viewerData.id,
		viewerData.login,
		viewerData.avatarUrl,
		viewerData.name,
		secondaryData,
		addToast,
		resetMarkdownBody,
		handleMarkdownBodyChanged,
		onNewIssueComment,
		onStateChange,
		closeButtonState,
		trackSubmittedWithWarning,
		relayConnectionId
	]);
	const subject_0 = useMemo(() => {
		return {
			type: "issue_comment",
			id: {
				id: data.id,
				databaseId: data.databaseId
			},
			repository: {
				databaseId: repositoryDatabaseId,
				nwo: data.repository.nameWithOwner,
				slashCommandsEnabled
			}
		};
	}, [
		data.databaseId,
		data.id,
		data.repository.nameWithOwner,
		repositoryDatabaseId,
		slashCommandsEnabled
	]);
	const actions = /* @__PURE__ */ jsx(IssueActions, {
		actionRef: data,
		onAction: useCallback(() => {
			if (markdownValidationResult && markdownValidationResult.isValid) onCommentSave(issueId, true);
		}, [
			issueId,
			onCommentSave,
			markdownValidationResult
		]),
		hasComment: markdownBody.length > 0,
		buttonSize: "medium",
		closeButtonState,
		setCloseButtonState,
		viewerCanReopen: secondaryData?.viewerCanReopen,
		viewerCanClose: secondaryData?.viewerCanClose,
		onStateChange
	});
	const issuesReactLazyLoad = isFeatureEnabled("issues_lazy_load_comment_box_suggestions");
	const contributingFileUrl = secondaryData?.repository.contributingFileUrl || void 0;
	const codeOfConductFileUrl = secondaryData?.repository.codeOfConductFileUrl || void 0;
	const securityPolicyUrl = secondaryData?.repository.securityPolicyUrl || void 0;
	const supportFileUrl = secondaryData?.repository.supportFileUrl || void 0;
	const renderContributorFooter = !!secondaryData?.repository;
	const { isBrowser } = useRuntimeEnvironment();
	return /* @__PURE__ */ jsx("div", {
		"data-testid": TEST_IDS.commentComposer,
		className: IssueCommentComposer_module_default.commentComposerWrapper,
		ref: commentComposerRef,
		"data-inside-side-panel": insideSidePanel,
		id: IDS.issueCommentComposer,
		children: /* @__PURE__ */ jsxs("div", {
			className: IssueCommentComposer_module_default.commentComposer,
			children: [
				/* @__PURE__ */ jsx(Link, {
					href: `/${viewerData.login}`,
					...getHovercardAttributesForType("user", { login: viewerData.login }),
					"aria-label": `@${viewerData.login}'s profile`,
					className: IssueCommentComposer_module_default.avatarLink,
					children: /* @__PURE__ */ jsx(GitHubAvatar, {
						size: 40,
						src: viewerData.avatarUrl,
						alt: viewerData.login
					})
				}),
				/* @__PURE__ */ jsx(Heading$2, {
					"data-jump-to-bottom-target": true,
					tabIndex: -1,
					id: "comment-composer-heading",
					as: "h2",
					className: IssueCommentComposer_module_default.heading,
					children: "Add a comment"
				}),
				/* @__PURE__ */ jsxs("div", {
					className: clsx(IssueCommentComposer_module_default.commentBoxWrapper, bannerPaddingClassName),
					children: [isBrowser && (!data.viewerCanComment || !data.repository.viewerCanInteract || secondaryData?.discussion ? /* @__PURE__ */ jsx(ReadonlyCommentBox, {
						reason: secondaryData?.discussion ? /* @__PURE__ */ jsx(CommentDisabledDueToDiscussion, { discussionUrl: secondaryData?.discussion?.url ?? "" }) : cantCommentReason,
						icon: LockIcon,
						...testIdProps(TEST_IDS.readonlyCommentBox(TEST_IDS.commentComposer))
					}) : /* @__PURE__ */ jsx(CommentBox, {
						ref: commentBoxRef,
						placeholder: LABELS$1.newCommentPlaceholder,
						label: LABELS$1.newComment,
						disabled: isSubmitting,
						subject: subject_0,
						infoBanner: lowQualityWarningBanner,
						value: markdownBody,
						onChange: handleMarkdownBodyChanged,
						actions,
						validationResult: markdownValidationResult,
						saveButtonText: BUTTON_LABELS.comment,
						saveButtonTrailingIcon: false,
						onSave: () => onCommentSave(issueId),
						fileUploadsEnabled,
						buttonSize: "medium",
						labelledBy: "comment-composer-heading",
						teamHovercardsEnabled: true,
						markdownSuggestionsFetchMethod: issuesReactLazyLoad ? "lazy" : "eager",
						className: clsx(Shared_module_default.CommentBox, condensed && Shared_module_default.Condensed),
						...testIdProps(TEST_IDS.commentBox(TEST_IDS.commentComposer))
					})), renderContributorFooter && /* @__PURE__ */ jsx(ContributorFooter, {
						contributingFileUrl,
						codeOfConductFileUrl,
						securityPolicyUrl,
						supportFileUrl,
						className: IssueCommentComposer_module_default.ContributorFooter
					})]
				})
			]
		})
	});
};
IssueCommentComposer.displayName = "IssueCommentComposer";
IssueCommentComposer.displayName = "CommentComposer";
var CommentDisabledDueToDiscussion = ({ discussionUrl }) => /* @__PURE__ */ jsxs("div", { children: [
	LABELS$1.issueConvertedToDiscussion,
	"\xA0",
	/* @__PURE__ */ jsx(Link, {
		href: discussionUrl,
		inline: true,
		children: "discussion"
	})
] });
CommentDisabledDueToDiscussion.displayName = "CommentDisabledDueToDiscussion";
export { IssueCommentComposer };
