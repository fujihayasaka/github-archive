import React, { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var RefInfoContext = React.createContext(null);
RefInfoContext.displayName = "RefInfoContext";
function RefInfoProvider(t0) {
	const $ = c(8);
	const { children, refInfo } = t0;
	refInfo?.name;
	refInfo?.listCacheKey;
	refInfo?.refType;
	refInfo?.currentOid;
	const t1 = refInfo?.name ?? "";
	const t2 = refInfo?.listCacheKey ?? "";
	const t3 = refInfo?.refType;
	const t4 = refInfo?.currentOid ?? "";
	let t5;
	if ($[0] !== t1 || $[1] !== t2 || $[2] !== t3 || $[3] !== t4) {
		t5 = {
			name: t1,
			listCacheKey: t2,
			refType: t3,
			currentOid: t4
		};
		$[0] = t1;
		$[1] = t2;
		$[2] = t3;
		$[3] = t4;
		$[4] = t5;
	} else t5 = $[4];
	const value = t5;
	let t6;
	if ($[5] !== children || $[6] !== value) {
		t6 = jsx(RefInfoContext, {
			value,
			children
		});
		$[5] = children;
		$[6] = value;
		$[7] = t6;
	} else t6 = $[7];
	return t6;
}
RefInfoProvider.displayName = "RefInfoProvider";
function useRefInfo() {
	const context = React.use(RefInfoContext);
	if (context === null) throw new Error("useRefInfo must be used within a RefInfoProvider");
	return context;
}
export { useRefInfo as n, RefInfoProvider as t };
