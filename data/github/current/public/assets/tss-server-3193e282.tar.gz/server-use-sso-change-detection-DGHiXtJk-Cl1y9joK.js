import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ur as SparklesFillIcon, et as CopilotIcon, hi as TriangleDownIcon, i as AgentIcon, n as ActionList, on as ImageIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { S as useSearchParams } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { i as queryOptions$1, l as useQuery, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { J as makeSnippetReference, U as makeFileReference, b as copilotFeatureFlags, m as ModeSupportName, o as CopilotPlan } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { n as usePasteFileSelect } from "./server-use-unified-file-select-CEU56QFm-CLNiWm9V.js";
import { t as ToggleSwitch } from "./server-ToggleSwitch-ouBLvY5S-LRpaQ39O.js";
import { a as useCAPIQuery, i as getAgentSessionsTokenProvider, r as fetchCAPI } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { E as useEntitlement, S as useChatStateValue, b as useChatState, t as CopilotChatProvider, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { C as useLocalStorageCache, S as useLastSelectedAgent, b as isCopilotOrCustomAgent, g as TaskChatInputToolbar, t as ACCEPTED_IMAGE_FILE_TYPES, v as extractImageUrls, w as useMarkdownImageUpload, x as queryForRepos } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { E as useLastUsedRepository, n as ChatInput } from "./server-ChatInput-DNU7qLKC-DqztNW8O.js";
import { _ as transformAPITasksToUnhydrated, d as repoTasksApiPath, f as sortTasksByDate, g as transformAPITaskToUnhydrated, h as tasksApiPathWithParams, s as mergeServerTasksWithOptimistic, v as useAgentSessionsAlive, y as useRepoInfo } from "./server-TaskLeadingVisual-DlKGcMc6-CLgHXns0.js";
import { A as useLatestAgentModel, O as useAgentInfo, g as MAX_AGENT_TASK_PROMPT_LENGTH, h as CopilotCodingAgentQuotaBanner, k as useAgentModels, v as ModelPicker } from "./server-CopilotCodingAgentQuotaBanner-W2Ye6Fax-B_w68npu.js";
import { createContext, use, useCallback, useDeferredValue, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var IntentDetectionEnabledContext = createContext({ isUsingIntentDetection: false });
IntentDetectionEnabledContext.displayName = "IntentDetectionEnabledContext";
function IntentDetectionEnabledProvider(t0) {
	const $ = c(5);
	const { isUsingIntentDetection, children } = t0;
	let t1;
	if ($[0] !== isUsingIntentDetection) {
		t1 = { isUsingIntentDetection };
		$[0] = isUsingIntentDetection;
		$[1] = t1;
	} else t1 = $[1];
	const value = t1;
	let t2;
	if ($[2] !== children || $[3] !== value) {
		t2 = jsx(IntentDetectionEnabledContext, {
			value,
			children
		});
		$[2] = children;
		$[3] = value;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
IntentDetectionEnabledProvider.displayName = "IntentDetectionEnabledProvider";
function useIntentDetectionEnabled() {
	return use(IntentDetectionEnabledContext);
}
function useIntentDetection(t0) {
	const $ = c(3);
	const session = t0 === void 0 ? null : t0;
	const { isUsingIntentDetection } = useIntentDetectionEnabled();
	const isChatSession = isUsingIntentDetection && session?.event_type === "chat";
	let t1;
	if ($[0] !== isChatSession || $[1] !== isUsingIntentDetection) {
		t1 = {
			isChatSession,
			isUsingIntentDetection
		};
		$[0] = isChatSession;
		$[1] = isUsingIntentDetection;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
function uuid() {
	return crypto.randomUUID();
}
function intentDetectionHeaders(intentDetectionMode) {
	const additionalHeaders = {};
	if (intentDetectionMode === "ask") additionalHeaders["X-Copilot-Pinned-Intent"] = "sync_llm";
	else if (intentDetectionMode === "task") additionalHeaders["X-Copilot-Pinned-Intent"] = "async_agent";
	else if (intentDetectionMode === "auto") additionalHeaders["X-Copilot-Pinned-Intent"] = "auto";
	return additionalHeaders;
}
function useCreateAPITask(t0) {
	const $ = c(34);
	const { onError, queryKey, getFlatTaskList, setFlatTaskList, pageSize, decoupledModeEnabled } = t0;
	const queryClient = useQueryClient();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = ["createAPITask"];
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== getFlatTaskList || $[2] !== queryClient || $[3] !== queryKey || $[4] !== setFlatTaskList) {
		t2 = async (params) => {
			await queryClient.cancelQueries({ queryKey });
			const previousTasks = queryClient.getQueryData(queryKey);
			const newTasks = setFlatTaskList(previousTasks, [createOptimisticTask(params), ...getFlatTaskList(previousTasks) ?? []]);
			queryClient.setQueryData(queryKey, newTasks);
			return { previousTasks };
		};
		$[1] = getFlatTaskList;
		$[2] = queryClient;
		$[3] = queryKey;
		$[4] = setFlatTaskList;
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== decoupledModeEnabled) {
		t3 = async (params_0) => {
			const imageCount = isFeatureEnabled("copilot_agent_image_upload") ? extractImageUrls(params_0.problemStatement).length : 0;
			sendEvent("copilot.agent_session.job_creation_requested", {
				event_identifiers: params_0.clientGeneratedId,
				event_type: params_0.eventType,
				nwo: params_0.nwo,
				image_count: imageCount
			});
			if (decoupledModeEnabled && params_0.createPullRequest === void 0) params_0.createPullRequest = false;
			const response = await createTask(params_0);
			if (!response.ok) {
				sendEvent("copilot.agent_session.job_creation_failed", {
					event_identifiers: params_0.clientGeneratedId,
					event_type: params_0.eventType,
					nwo: params_0.nwo,
					status: response.status,
					error: response.statusText,
					image_count: imageCount
				});
				throw new Error(`Failed to create task: ${params_0.clientGeneratedId}`);
			}
			const data = await response.json();
			const task = data.task ? {
				...data.task,
				name: data.name
			} : data;
			sendEvent("copilot.agent_session.job_creation_completed", {
				event_identifiers: params_0.clientGeneratedId,
				event_type: params_0.eventType,
				nwo: params_0.nwo,
				task_id: task.id,
				image_count: imageCount
			});
			return {
				task,
				clientGeneratedId: params_0.clientGeneratedId
			};
		};
		$[6] = decoupledModeEnabled;
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== getFlatTaskList || $[9] !== onError || $[10] !== queryClient || $[11] !== queryKey || $[12] !== setFlatTaskList) {
		t4 = (error, variables) => {
			const currentTasks = queryClient.getQueryData(queryKey);
			const tasksWithoutFailed = setFlatTaskList(currentTasks, (getFlatTaskList(currentTasks) ?? []).filter((task_0) => task_0.clientGeneratedId !== variables.clientGeneratedId));
			queryClient.setQueryData(queryKey, tasksWithoutFailed);
			onError?.(error, variables);
		};
		$[8] = getFlatTaskList;
		$[9] = onError;
		$[10] = queryClient;
		$[11] = queryKey;
		$[12] = setFlatTaskList;
		$[13] = t4;
	} else t4 = $[13];
	let t5;
	if ($[14] !== getFlatTaskList || $[15] !== pageSize || $[16] !== queryClient || $[17] !== queryKey || $[18] !== setFlatTaskList) {
		t5 = (t6) => {
			const { task: task_1, clientGeneratedId } = t6;
			const transformedTask = transformAPITaskToUnhydrated(task_1);
			queryClient.setQueryData(queryKey, (oldData) => {
				const withoutOptimistic = (getFlatTaskList(oldData) ?? []).filter((t) => t.clientGeneratedId !== clientGeneratedId);
				return setFlatTaskList(oldData, (transformedTask ? sortTasksByDate([transformedTask, ...withoutOptimistic]) : withoutOptimistic).slice(0, pageSize));
			});
			queryClient.invalidateQueries({
				queryKey,
				exact: true
			});
		};
		$[14] = getFlatTaskList;
		$[15] = pageSize;
		$[16] = queryClient;
		$[17] = queryKey;
		$[18] = setFlatTaskList;
		$[19] = t5;
	} else t5 = $[19];
	let t6;
	if ($[20] !== t2 || $[21] !== t3 || $[22] !== t4 || $[23] !== t5) {
		t6 = {
			mutationKey: t1,
			onMutate: t2,
			mutationFn: t3,
			onError: t4,
			onSuccess: t5
		};
		$[20] = t2;
		$[21] = t3;
		$[22] = t4;
		$[23] = t5;
		$[24] = t6;
	} else t6 = $[24];
	const createTaskMutation = useMutation(t6);
	let t7;
	if ($[25] !== createTaskMutation) {
		t7 = (params_1, clientTaskId) => {
			const clientGeneratedId_0 = clientTaskId ?? uuid();
			createTaskMutation.mutate({
				...params_1,
				clientGeneratedId: clientGeneratedId_0
			});
		};
		$[25] = createTaskMutation;
		$[26] = t7;
	} else t7 = $[26];
	const createAPITask = t7;
	let t8;
	if ($[27] !== createTaskMutation) {
		t8 = async (params_2, clientTaskId_0) => {
			const clientGeneratedId_1 = clientTaskId_0 ?? uuid();
			return createTaskMutation.mutateAsync({
				...params_2,
				clientGeneratedId: clientGeneratedId_1
			});
		};
		$[27] = createTaskMutation;
		$[28] = t8;
	} else t8 = $[28];
	const createAPITaskAsync = t8;
	let t9;
	if ($[29] !== createAPITask || $[30] !== createAPITaskAsync || $[31] !== createTaskMutation.error || $[32] !== createTaskMutation.isPending) {
		t9 = {
			createTask: createAPITask,
			createTaskAsync: createAPITaskAsync,
			isCreating: createTaskMutation.isPending,
			createError: createTaskMutation.error
		};
		$[29] = createAPITask;
		$[30] = createAPITaskAsync;
		$[31] = createTaskMutation.error;
		$[32] = createTaskMutation.isPending;
		$[33] = t9;
	} else t9 = $[33];
	return t9;
}
/**
* Helper function to create task via the Tasks API
*/
async function createTask({ nwo, problemStatement, model, agentId, customAgent, baseRef, createPullRequest, intentDetectionMode, eventType, eventContent, eventIdentifiers, clientGeneratedId }) {
	const endpoint = repoTasksApiPath(nwo);
	let agentIdNumber = void 0;
	if (agentId !== void 0 && agentId !== null) {
		agentIdNumber = parseInt(agentId, 10);
		if (isNaN(agentIdNumber)) throw new Error(`Invalid agentId: "${agentId}". agentId must be a valid numeric string.`);
	}
	const allEventIdentifiers = [...eventIdentifiers || [], clientGeneratedId];
	return await fetchCAPI({
		path: endpoint,
		method: "POST",
		additionalHeaders: intentDetectionHeaders(intentDetectionMode),
		body: {
			problem_statement: problemStatement,
			event_identifiers: allEventIdentifiers,
			...model && { model },
			...agentIdNumber && { agent_id: agentIdNumber },
			...customAgent && { custom_agent: customAgent },
			...baseRef && { base_ref: baseRef },
			...createPullRequest !== void 0 && { create_pull_request: createPullRequest },
			...eventType && { event_type: eventType },
			...eventContent && { event_content: eventContent }
		}
	});
}
function createOptimisticTask({ clientGeneratedId, nwo, problemStatement, customAgent, agentId }) {
	return {
		resource_type: "pull",
		resource_id: -1,
		resource_global_id: "",
		session_count: 1,
		latest_session_updated_at: (/* @__PURE__ */ new Date()).toISOString(),
		latest_session_state: "in_progress",
		isOptimistic: true,
		clientGeneratedId,
		nwo,
		problemStatement,
		name: problemStatement,
		custom_agent: customAgent,
		agentId: agentId?.toString()
	};
}
var PR_MAP_STORAGE_KEY = "AGENT_SESSIONS_PR_MAP";
function getSortedResourceIds(tasks) {
	const ids = tasks ? tasks.map((task) => task.resource_id) : [];
	return Array.from(new Set(ids)).sort((a, b) => Number(a) - Number(b)).join(",");
}
var fetchPullRequests = async (tasks, setCachedPRMap) => {
	const pullRequestIds = getSortedResourceIds(tasks);
	if (!pullRequestIds) return {};
	const response = await fetch(`/copilot/agent-sessions/pull-requests?pull_request_ids=${encodeURIComponent(pullRequestIds)}`, { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error("Failed to fetch pull requests");
	const pullRequests = (await response.json()).pull_requests;
	setCachedPRMap(pullRequests);
	return pullRequests;
};
function usePullRequests({ tasks, initialPullRequestsMap, refetchOnMount = false }) {
	const pullRequestIds = getSortedResourceIds(tasks);
	const { value: cachedPRMap, setValue: setCachedPRMap } = useLocalStorageCache(PR_MAP_STORAGE_KEY);
	const cumulativePullsRef = useRef(initialPullRequestsMap ?? {});
	const query = useQuery({
		queryKey: ["agent-sessions-pull-requests", pullRequestIds],
		queryFn: async () => await fetchPullRequests(tasks, setCachedPRMap),
		initialData: initialPullRequestsMap ?? cachedPRMap,
		staleTime: refetchOnMount ? 0 : void 0,
		refetchInterval: false,
		enabled: pullRequestIds.length > 0
	});
	if (query.data) {
		const requestedIds = new Set(tasks.map((t) => String(t.resource_id)));
		const returnedIds = new Set(Object.keys(query.data));
		cumulativePullsRef.current = {
			...Object.fromEntries(Object.entries(cumulativePullsRef.current).filter(([id]) => {
				return !requestedIds.has(id) || returnedIds.has(id);
			})),
			...query.data
		};
	}
	const finalMap = useMemo(() => {
		return cumulativePullsRef.current;
	}, [query.data]);
	return {
		...query,
		data: finalMap
	};
}
/**
* Parses a Link header to determine if a "next" page exists.
*
* The new Task API returns pagination via a Link header like:
*   <https://api.githubcopilot.com/agents/tasks?page=2&per_page=10>; rel="next"
*
* @param linkHeader - The raw Link header value, or null if not present.
* @returns true if a rel="next" link is present, false if the header exists
*          but has no next link, or null if the header is absent.
*/
function parseLinkHeader(linkHeader) {
	if (!linkHeader) return null;
	return /rel="next"/.test(linkHeader);
}
var agentTasksQueryKey = ["agent-tasks"];
/**
* Get the query key for agent tasks with pagination parameters.
*
* **Note:** pageSize is intentionally NOT included in the query key so that all views
* (regardless of their pageSize setting) share the same cache. This allows optimistic
* updates from task creation to appear in all views.
* @param page - Page number
* @param taskFilter - Which tasks to fetch: 'active', 'completed', or 'all'
*
*/
function getAgentTasksQueryKey(page, taskFilter) {
	return [
		...agentTasksQueryKey,
		page,
		taskFilter
	];
}
/**
* Get the query key for agent tasks to be used for mutations to ensure optimistic tasks are always added to the correct view.
*/
function getAgentTasksQueryKeyForMutation() {
	return [
		...agentTasksQueryKey,
		1,
		"active"
	];
}
/**
* Extract the flat task list from the FetchTasksResponse tuple.
* Used with useCreateAPITask for optimistic updates.
*/
function getFlatTaskList(data) {
	return data?.[0];
}
/**
* Create a new FetchTasksResponse with an updated task list.
* Used with useCreateAPITask for optimistic updates.
*/
function setFlatTaskList(oldData, newList) {
	return [
		newList,
		oldData?.[1] ?? false,
		oldData?.[2]
	];
}
var fetchTasks = async ({ queryClient, copilotApiUrl, queryParams, queryKey }) => {
	const response = await fetchCAPI({
		path: tasksApiPathWithParams(queryParams),
		copilotApiUrl
	});
	const data = await response.json();
	const apiTasks = data.tasks;
	const mergedTasks = mergeServerTasksWithOptimistic(transformAPITasksToUnhydrated(apiTasks), (queryClient.getQueryData(queryKey ?? agentTasksQueryKey)?.[0] || []).filter((task) => task.isOptimistic === true));
	const hasNextPage = parseLinkHeader(response.headers?.get("Link")) ?? !!data.has_next_page;
	let taskCounts;
	if (typeof data.total_active_count === "number" && typeof data.total_archived_count === "number") taskCounts = {
		open: data.total_active_count,
		closed: data.total_archived_count
	};
	return [
		mergedTasks,
		hasNextPage,
		taskCounts
	];
};
/**
* Convert TaskFilter to the API's archived parameter.
* 'active' -> false, 'completed' -> true, 'all' -> undefined
*/
function taskFilterToArchived(taskFilter) {
	if (taskFilter === "all") return void 0;
	return taskFilter === "completed";
}
function useTasks(t0) {
	const $ = c(59);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { sessionsPollingInterval: t2, initialTasks, initialPullRequestsMap, taskFilter: t3, includeCounts, currentPage: t4, pageSize: t5 } = t1;
	const sessionsPollingInterval = t2 === void 0 ? 3e3 : t2;
	const taskFilter = t3 === void 0 ? "active" : t3;
	const currentPage = t4 === void 0 ? 1 : t4;
	const pageSize = t5 === void 0 ? 10 : t5;
	const queryClient = useQueryClient();
	let t6;
	if ($[2] !== queryClient) {
		t6 = () => {
			queryClient.invalidateQueries({ queryKey: agentTasksQueryKey });
			queryClient.invalidateQueries({ queryKey: ["agent-sessions-pull-requests"] });
		};
		$[2] = queryClient;
		$[3] = t6;
	} else t6 = $[3];
	const handleAliveUpdate = t6;
	const shouldSubscribeToAlive = sessionsPollingInterval !== false;
	let t7;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = { maxWait: 1e4 };
		$[4] = t7;
	} else t7 = $[4];
	const debouncedHandleAliveUpdate = useDebounce(handleAliveUpdate, typeof sessionsPollingInterval === "number" ? sessionsPollingInterval : 3e3, t7);
	let t8;
	if ($[5] !== debouncedHandleAliveUpdate || $[6] !== shouldSubscribeToAlive) {
		t8 = shouldSubscribeToAlive ? debouncedHandleAliveUpdate : _temp$3;
		$[5] = debouncedHandleAliveUpdate;
		$[6] = shouldSubscribeToAlive;
		$[7] = t8;
	} else t8 = $[7];
	let t9;
	if ($[8] !== shouldSubscribeToAlive || $[9] !== t8) {
		t9 = {
			onEvent: t8,
			enableCreateEvents: false,
			enableUpdateEvents: shouldSubscribeToAlive,
			enableLogUpdates: false,
			enabled: shouldSubscribeToAlive
		};
		$[8] = shouldSubscribeToAlive;
		$[9] = t8;
		$[10] = t9;
	} else t9 = $[10];
	useAgentSessionsAlive(t9);
	let t10;
	if ($[11] !== taskFilter) {
		t10 = taskFilterToArchived(taskFilter);
		$[11] = taskFilter;
		$[12] = t10;
	} else t10 = $[12];
	let t11;
	if ($[13] !== currentPage || $[14] !== includeCounts || $[15] !== pageSize || $[16] !== t10) {
		t11 = {
			archived: t10,
			includeCounts,
			page: currentPage,
			pageSize
		};
		$[13] = currentPage;
		$[14] = includeCounts;
		$[15] = pageSize;
		$[16] = t10;
		$[17] = t11;
	} else t11 = $[17];
	const queryParams = t11;
	let t12;
	if ($[18] !== currentPage || $[19] !== taskFilter) {
		t12 = getAgentTasksQueryKey(currentPage, taskFilter);
		$[18] = currentPage;
		$[19] = taskFilter;
		$[20] = t12;
	} else t12 = $[20];
	const queryKey = t12;
	let t13;
	if ($[21] !== queryClient || $[22] !== queryKey || $[23] !== queryParams) {
		t13 = async () => await fetchTasks({
			queryClient,
			queryParams,
			queryKey
		});
		$[21] = queryClient;
		$[22] = queryKey;
		$[23] = queryParams;
		$[24] = t13;
	} else t13 = $[24];
	let t14;
	if ($[25] !== initialTasks) {
		t14 = initialTasks ? [
			initialTasks,
			false,
			void 0
		] : void 0;
		$[25] = initialTasks;
		$[26] = t14;
	} else t14 = $[26];
	let t15;
	if ($[27] !== queryKey || $[28] !== t13 || $[29] !== t14) {
		t15 = {
			queryKey,
			queryFn: t13,
			initialData: t14,
			refetchInterval: false
		};
		$[27] = queryKey;
		$[28] = t13;
		$[29] = t14;
		$[30] = t15;
	} else t15 = $[30];
	const query = useCAPIQuery(t15);
	const prevPageSizeRef = useRef(pageSize);
	let t16;
	let t17;
	if ($[31] !== pageSize || $[32] !== query) {
		t16 = () => {
			if (prevPageSizeRef.current !== pageSize) {
				prevPageSizeRef.current = pageSize;
				query.refetch();
			}
		};
		t17 = [pageSize, query];
		$[31] = pageSize;
		$[32] = query;
		$[33] = t16;
		$[34] = t17;
	} else {
		t16 = $[33];
		t17 = $[34];
	}
	useEffect(t16, t17);
	let t18;
	if ($[35] !== query.data?.[0]) {
		t18 = query.data?.[0] || [];
		$[35] = query.data?.[0];
		$[36] = t18;
	} else t18 = $[36];
	const allTasks = t18;
	const hasNextPage = query.data?.[1] ?? false;
	const counts = query.data?.[2];
	let t19;
	if ($[37] !== allTasks) {
		t19 = allTasks.filter(_temp2$1);
		$[37] = allTasks;
		$[38] = t19;
	} else t19 = $[38];
	const tasksWithResourceIds = t19;
	let t20;
	if ($[39] !== initialPullRequestsMap || $[40] !== tasksWithResourceIds) {
		t20 = {
			tasks: tasksWithResourceIds,
			initialPullRequestsMap
		};
		$[39] = initialPullRequestsMap;
		$[40] = tasksWithResourceIds;
		$[41] = t20;
	} else t20 = $[41];
	const { data: idToPullRequestMap, isError: isErrorPullRequests, isFetching: isFetchingPullRequests, isLoading: isLoadingPullRequests } = usePullRequests(t20);
	const prMap = initialPullRequestsMap ?? idToPullRequestMap;
	let ids;
	if ($[42] !== allTasks || $[43] !== prMap) {
		ids = [];
		for (const task_0 of allTasks) {
			if (task_0.isOptimistic) continue;
			if (task_0.resource_id && prMap[task_0.resource_id]) continue;
			if (task_0.repo_id) ids.push(task_0.repo_id);
		}
		$[42] = allTasks;
		$[43] = prMap;
		$[44] = ids;
	} else ids = $[44];
	const repoIdsNeedingFetch = ids;
	const { data: repoMap, isLoading: isLoadingRepoInfo, isError: isErrorRepoInfo } = useRepoInfo(repoIdsNeedingFetch);
	let t21;
	if ($[45] !== allTasks || $[46] !== idToPullRequestMap || $[47] !== repoMap) {
		let t22;
		if ($[49] !== idToPullRequestMap || $[50] !== repoMap) {
			t22 = (task_1) => {
				const pull = task_1.resource_id ? idToPullRequestMap[task_1.resource_id] : void 0;
				if (pull) return {
					...task_1,
					isOptimistic: false,
					pull,
					nwo: pull.repository_nwo
				};
				else {
					const repo = task_1.repo_id ? repoMap[task_1.repo_id] : void 0;
					return {
						...task_1,
						pull: void 0,
						nwo: repo ? `${repo.ownerLogin}/${repo.name}` : task_1.nwo
					};
				}
			};
			$[49] = idToPullRequestMap;
			$[50] = repoMap;
			$[51] = t22;
		} else t22 = $[51];
		t21 = allTasks.map(t22).filter(_temp3);
		$[45] = allTasks;
		$[46] = idToPullRequestMap;
		$[47] = repoMap;
		$[48] = t21;
	} else t21 = $[48];
	const returnTasks = t21;
	const isLoading = query.isLoading && !query.data || isLoadingPullRequests && !initialPullRequestsMap && allTasks.length > 0 || isLoadingRepoInfo && repoIdsNeedingFetch.length > 0 && allTasks.length > 0;
	const isError = query.isError || isErrorPullRequests || isErrorRepoInfo;
	const isFetching = query.isFetching || isFetchingPullRequests && allTasks.length > 0;
	let t22;
	if ($[52] !== counts || $[53] !== hasNextPage || $[54] !== isError || $[55] !== isFetching || $[56] !== isLoading || $[57] !== returnTasks) {
		t22 = {
			tasks: returnTasks,
			isLoading,
			isFetching,
			isError,
			hasNextPage,
			counts
		};
		$[52] = counts;
		$[53] = hasNextPage;
		$[54] = isError;
		$[55] = isFetching;
		$[56] = isLoading;
		$[57] = returnTasks;
		$[58] = t22;
	} else t22 = $[58];
	return t22;
}
function _temp3(task_2) {
	if (task_2.isOptimistic === true) return true;
	return task_2.pull !== void 0 || task_2.nwo !== void 0;
}
function _temp2$1(task) {
	return task.resource_id !== void 0 && task.resource_id !== -1;
}
function _temp$3() {}
var NewAgentTaskForm_module_default = {
	content: "NewAgentTaskForm-module_83CrQq_content",
	header: "NewAgentTaskForm-module_83CrQq_header",
	skeleton: "NewAgentTaskForm-module_83CrQq_skeleton"
};
var DISABLED_DROP_TARGET_PROPS = {
	onDragEnter: () => {},
	onDragOver: () => {},
	onDragLeave: () => {},
	onDrop: () => {}
};
/**
* A hook that provides `onPaste` and drag and drop handlers for a text area, implementing the
* paste/drop → upload → markdown-inline lifecycle for images.
*
* Images are uploaded to dotcom's asset storage and inserted as standard markdown
* `![filename](url)` syntax directly into the textarea text.
*
* The core upload logic is shared with `ImageAttachButton` via `useMarkdownImageUpload`.
*
* Usage:
* ```tsx
* const {onPaste, dropTargetProps, isUploading} = useMarkdownImageHandling({textAreaRef, repositoryId})
* <textarea onPaste={onPaste} {...dropTargetProps} ref={textAreaRef} ... />
* ```
*/
function useMarkdownImageHandling(t0) {
	const $ = c(17);
	const { textAreaRef, repositoryId, enabled } = t0;
	let t1;
	if ($[0] !== repositoryId || $[1] !== textAreaRef) {
		t1 = {
			textAreaRef,
			repositoryId
		};
		$[0] = repositoryId;
		$[1] = textAreaRef;
		$[2] = t1;
	} else t1 = $[2];
	const { processFiles, isUploading } = useMarkdownImageUpload(t1);
	let t2;
	if ($[3] !== processFiles) {
		t2 = {
			onSelect: (accepted) => processFiles(accepted),
			multi: true,
			acceptedFileTypes: ACCEPTED_IMAGE_FILE_TYPES
		};
		$[3] = processFiles;
		$[4] = t2;
	} else t2 = $[4];
	const pasteTargetProps = usePasteFileSelect(t2);
	let t3;
	if ($[5] !== pasteTargetProps) {
		t3 = (event) => {
			pasteTargetProps.onPaste(event);
		};
		$[5] = pasteTargetProps;
		$[6] = t3;
	} else t3 = $[6];
	const onPaste = t3;
	const [isDraggedOver, setIsDraggedOver] = useState(false);
	const dragCounterRef = useRef(0);
	let t4;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (event_0) => {
			if (!event_0.dataTransfer.types.includes("Files")) return;
			event_0.preventDefault();
			event_0.stopPropagation();
			dragCounterRef.current = dragCounterRef.current + 1;
			if (dragCounterRef.current === 1) setIsDraggedOver(true);
		};
		$[7] = t4;
	} else t4 = $[7];
	let t5;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = (event_2) => {
			event_2.preventDefault();
			event_2.stopPropagation();
			dragCounterRef.current = dragCounterRef.current - 1;
			if (dragCounterRef.current <= 0) {
				dragCounterRef.current = 0;
				setIsDraggedOver(false);
			}
		};
		$[8] = t5;
	} else t5 = $[8];
	let t6;
	if ($[9] !== processFiles) {
		t6 = {
			onDragEnter: t4,
			onDragOver: _temp$2,
			onDragLeave: t5,
			onDrop: (event_3) => {
				event_3.preventDefault();
				event_3.stopPropagation();
				dragCounterRef.current = 0;
				setIsDraggedOver(false);
				if (event_3.dataTransfer.files.length > 0) processFiles(event_3.dataTransfer.files);
			}
		};
		$[9] = processFiles;
		$[10] = t6;
	} else t6 = $[10];
	const dropTargetProps = t6;
	if (!enabled) {
		let t7;
		if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = {
				onPaste: _temp2,
				dropTargetProps: DISABLED_DROP_TARGET_PROPS,
				isDraggedOver: false,
				isUploading: false
			};
			$[11] = t7;
		} else t7 = $[11];
		return t7;
	}
	let t7;
	if ($[12] !== dropTargetProps || $[13] !== isDraggedOver || $[14] !== isUploading || $[15] !== onPaste) {
		t7 = {
			onPaste,
			dropTargetProps,
			isDraggedOver,
			isUploading
		};
		$[12] = dropTargetProps;
		$[13] = isDraggedOver;
		$[14] = isUploading;
		$[15] = onPaste;
		$[16] = t7;
	} else t7 = $[16];
	return t7;
}
function _temp2() {}
function _temp$2(event_1) {
	if (!event_1.dataTransfer.types.includes("Files")) return;
	event_1.preventDefault();
	event_1.stopPropagation();
	event_1.dataTransfer.dropEffect = "copy";
}
var ImageReferenceToken_module_default = {
	dialogImage: "ImageReferenceToken-module_Z3DRGG_dialogImage",
	dialogImageContainer: "ImageReferenceToken-module_Z3DRGG_dialogImageContainer",
	errorState: "ImageReferenceToken-module_Z3DRGG_errorState",
	fullWidth: "ImageReferenceToken-module_Z3DRGG_fullWidth",
	hidden: "ImageReferenceToken-module_Z3DRGG_hidden",
	imageReferenceToken: "ImageReferenceToken-module_Z3DRGG_imageReferenceToken",
	loadingState: "ImageReferenceToken-module_Z3DRGG_loadingState",
	name: "ImageReferenceToken-module_Z3DRGG_name",
	small: "ImageReferenceToken-module_Z3DRGG_small",
	thumbnail: "ImageReferenceToken-module_Z3DRGG_thumbnail",
	thumbnailContainer: "ImageReferenceToken-module_Z3DRGG_thumbnailContainer"
};
/**
* A specialized reference token that displays a thumbnail preview for image references.
* Opens a dialog with the full image when clicked.
* Used as a custom TokenComponent for markdown-detected images.
*/
function ImageReferenceToken(t0) {
	const $ = c(14);
	const { reference, size, fullWidth, tokenRef } = t0;
	const imageRef = reference;
	const [loaded, setLoaded] = useState(false);
	const [error, setError] = useState(false);
	const [dialogOpen, setDialogOpen] = useState(false);
	const [resolvedUrl, setResolvedUrl] = useState(imageRef.imageUrl);
	let t1;
	let t2;
	if ($[0] !== imageRef.attachment || $[1] !== imageRef.imageUrl) {
		t1 = () => {
			const attachment = imageRef.attachment;
			if (!imageRef.imageUrl && attachment?.url) {
				const resolveUrl = async () => {
					try {
						setResolvedUrl(await attachment.url());
					} catch {
						setError(true);
					}
				};
				resolveUrl();
			}
		};
		t2 = [imageRef.imageUrl, imageRef.attachment];
		$[0] = imageRef.attachment;
		$[1] = imageRef.imageUrl;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			setDialogOpen(true);
		};
		$[4] = t3;
	} else t3 = $[4];
	const handleClick = t3;
	let t4;
	if ($[5] !== dialogOpen || $[6] !== error || $[7] !== fullWidth || $[8] !== imageRef.name || $[9] !== loaded || $[10] !== resolvedUrl || $[11] !== size || $[12] !== tokenRef) {
		t4 = jsxs(Fragment$1, { children: [jsxs("button", {
			ref: tokenRef,
			type: "button",
			className: clsx(ImageReferenceToken_module_default.imageReferenceToken, size === "small" && ImageReferenceToken_module_default.small, fullWidth && ImageReferenceToken_module_default.fullWidth),
			onClick: handleClick,
			"aria-label": `Image: ${imageRef.name}`,
			children: [jsxs("div", {
				className: ImageReferenceToken_module_default.thumbnailContainer,
				children: [!loaded && !error && jsx("div", {
					className: ImageReferenceToken_module_default.loadingState,
					children: jsx(Spinner, { size: "small" })
				}), error ? jsx("div", {
					className: ImageReferenceToken_module_default.errorState,
					children: jsx(ImageIcon, { size: 16 })
				}) : resolvedUrl && jsx("img", {
					src: resolvedUrl,
					alt: imageRef.name,
					onLoad: () => setLoaded(true),
					onError: () => setError(true),
					className: clsx(ImageReferenceToken_module_default.thumbnail, !loaded && ImageReferenceToken_module_default.hidden)
				})]
			}), jsx("span", {
				className: ImageReferenceToken_module_default.name,
				children: imageRef.name
			})]
		}), dialogOpen && resolvedUrl && jsx(Dialog, {
			onClose: () => setDialogOpen(false),
			title: imageRef.name,
			width: "xlarge",
			children: jsx("div", {
				className: ImageReferenceToken_module_default.dialogImageContainer,
				children: jsx("img", {
					src: resolvedUrl,
					alt: imageRef.name,
					className: ImageReferenceToken_module_default.dialogImage
				})
			})
		})] });
		$[5] = dialogOpen;
		$[6] = error;
		$[7] = fullWidth;
		$[8] = imageRef.name;
		$[9] = loaded;
		$[10] = resolvedUrl;
		$[11] = size;
		$[12] = tokenRef;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
}
ImageReferenceToken.displayName = "ImageReferenceToken";
/**
* Legacy attachment path pattern: /<org>/<repo>/assets/<id>/<guid>
* The guid should be alphanumeric/hyphens without a file extension.
*/
var LEGACY_ASSET_PATH_PATTERN = /^\/[\w.-]+\/[\w.-]+\/assets\/\d+\/[^.]+$/;
/**
* Creates a minimal DotcomFileAttachment for URL-only image references.
* Used when we detect an image URL in markdown that's already uploaded to GitHub,
* so no actual upload is needed - we just wrap the existing URL.
*/
function createUrlAttachment(url, name) {
	return {
		key: url,
		file: new File([], name, { type: "image/*" }),
		previewUrl: url,
		url: async () => url,
		prefetch: async () => {},
		isLoaded: true,
		hasError: false,
		threadID: null,
		getDimensions: async () => ({
			width: void 0,
			height: void 0
		})
	};
}
/**
* Check if a URL is a GitHub asset image URL that sweagentd can resolve.
* Matches both user attachments and legacy attachments.
*
* Supported patterns:
* - User attachments: ${origin}/user-attachments/assets/...
* - Legacy attachments: ${origin}/<org>/<repo>/assets/<id>/<guid>
*/
function isGitHubAssetUrl(urlString) {
	let url;
	try {
		url = new URL(urlString, window.location.origin);
	} catch {
		return false;
	}
	if (url.origin !== window.location.origin) return false;
	if (url.pathname.startsWith("/user-attachments/assets/")) return true;
	return LEGACY_ASSET_PATH_PATTERN.test(url.pathname);
}
/**
* Extract image URLs that are already tracked as references in the current
* reference list.
*/
function getExistingImageUrls(references) {
	const urls = /* @__PURE__ */ new Set();
	for (const ref of references) if (ref.type === "image") {
		const imageUrl = ref.imageUrl;
		if (imageUrl) urls.add(imageUrl);
	}
	return urls;
}
/**
* Syncs image references in textarea text with CopilotChatManager references.
*
* When a GitHub asset image URL is detected in markdown `![alt](url)` or HTML `<img src="url">`:
* - Creates an ImageReference and adds it via manager.addReference()
* - Removes the reference when the image is deleted from text
*
* Also tracks whether the image count has reached MAX_TASK_IMAGES so callers
* can disable further image attachment UI without extra parsing.
*/
function useImageReferenceSync(t0) {
	const $ = c(13);
	const { text, manager, currentReferences, enabled: t1 } = t0;
	const enabled = t1 === void 0 ? true : t1;
	const deferredText = useDeferredValue(text);
	let t2;
	if ($[0] !== currentReferences) {
		t2 = getExistingImageUrls(currentReferences);
		$[0] = currentReferences;
		$[1] = t2;
	} else t2 = $[1];
	const previousUrlsRef = useRef(t2);
	let t3;
	bb0: {
		if (!enabled) {
			let t4;
			if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
				t4 = [];
				$[2] = t4;
			} else t4 = $[2];
			t3 = t4;
			break bb0;
		}
		let t4;
		if ($[3] !== deferredText) {
			t4 = extractImageUrls(deferredText).filter(_temp$1);
			$[3] = deferredText;
			$[4] = t4;
		} else t4 = $[4];
		t3 = t4;
	}
	const githubImages = t3;
	const isAtImageLimit = githubImages.length >= 4;
	let t4;
	let t5;
	if ($[5] !== currentReferences || $[6] !== enabled || $[7] !== githubImages || $[8] !== manager) {
		t4 = () => {
			if (!enabled) return;
			const currentUrls = /* @__PURE__ */ new Set();
			for (const { url: url_0, alt } of githubImages) {
				currentUrls.add(url_0);
				if (!previousUrlsRef.current.has(url_0)) {
					const name = alt || "Image";
					const imageRef = {
						type: "image",
						id: `image:${url_0}`,
						name,
						imageUrl: url_0,
						attachment: createUrlAttachment(url_0, name),
						TokenComponent: ImageReferenceToken
					};
					manager.addReference(imageRef, "markdown-detection");
				}
			}
			for (const url_1 of previousUrlsRef.current) if (!currentUrls.has(url_1)) {
				const refToRemove = currentReferences.find((ref) => ref.type === "image" && ref.id === `image:${url_1}`);
				if (refToRemove) manager.removeReference(refToRemove);
			}
			previousUrlsRef.current = currentUrls;
		};
		t5 = [
			githubImages,
			manager,
			currentReferences,
			enabled
		];
		$[5] = currentReferences;
		$[6] = enabled;
		$[7] = githubImages;
		$[8] = manager;
		$[9] = t4;
		$[10] = t5;
	} else {
		t4 = $[9];
		t5 = $[10];
	}
	useEffect(t4, t5);
	let t6;
	if ($[11] !== isAtImageLimit) {
		t6 = { isAtImageLimit };
		$[11] = isAtImageLimit;
		$[12] = t6;
	} else t6 = $[12];
	return t6;
}
function _temp$1(t0) {
	const { url } = t0;
	return isGitHubAssetUrl(url);
}
var PullRequestToggleAddon_module_default = {
	container: "PullRequestToggleAddon-module_MSqsIG_container",
	label: "PullRequestToggleAddon-module_MSqsIG_label"
};
function PullRequestToggleAddon({ checked, onChange }) {
	return /* @__PURE__ */ jsxs("div", {
		className: PullRequestToggleAddon_module_default.container,
		children: [/* @__PURE__ */ jsx("span", {
			id: "create-pull-request-toggle-label",
			className: PullRequestToggleAddon_module_default.label,
			children: "Create a pull request"
		}), /* @__PURE__ */ jsx(ToggleSwitch, {
			size: "small",
			"aria-labelledby": "create-pull-request-toggle-label",
			checked,
			onClick: () => onChange(!checked),
			statusLabelPosition: "end"
		})]
	});
}
PullRequestToggleAddon.displayName = "PullRequestToggleAddon";
var NewTaskChatInput_module_default = {
	extraToolbarActions: "NewTaskChatInput-module_89dfBa_extraToolbarActions",
	isDraggedOver: "NewTaskChatInput-module_89dfBa_isDraggedOver",
	reposSelectorButton: "NewTaskChatInput-module_89dfBa_reposSelectorButton"
};
var ModeSelector_module_default = { selectorButton: "ModeSelector-module_UiyNnW_selectorButton" };
var DISPLAY_INFO = {
	auto: {
		icon: SparklesFillIcon,
		label: "Auto"
	},
	ask: {
		icon: CopilotIcon,
		label: "Ask"
	},
	task: {
		icon: AgentIcon,
		label: "Task"
	}
};
function ModeItem({ selectedMode, mode, setMode }) {
	const info = DISPLAY_INFO[mode];
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		selected: mode === selectedMode,
		onSelect: () => setMode(mode),
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(info.icon, {}) }), info.label]
	});
}
ModeItem.displayName = "ModeItem";
function ModeSelector({ selectedMode, setMode }) {
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(ButtonComponent, {
		leadingVisual: DISPLAY_INFO[selectedMode].icon,
		trailingAction: TriangleDownIcon,
		"aria-label": "Select how Copilot detects your intent",
		className: ModeSelector_module_default.selectorButton,
		children: DISPLAY_INFO[selectedMode].label
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		width: "auto",
		children: /* @__PURE__ */ jsxs(ActionList, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsxs(ActionList.Group, {
			selectionVariant: false,
			children: [
				/* @__PURE__ */ jsx(ModeItem, {
					mode: "auto",
					selectedMode,
					setMode
				}),
				/* @__PURE__ */ jsx(ModeItem, {
					mode: "ask",
					selectedMode,
					setMode
				}),
				/* @__PURE__ */ jsx(ModeItem, {
					mode: "task",
					selectedMode,
					setMode
				})
			]
		})] })
	})] });
}
ModeSelector.displayName = "ModeSelector";
var IntentDetectionContext = createContext({
	taskCreationRequest: null,
	setTaskCreationRequest: () => {},
	mode: "task",
	setMode: () => {}
});
IntentDetectionContext.displayName = "IntentDetectionContext";
function IntentDetectionProvider(t0) {
	const $ = c(6);
	const { children } = t0;
	const [taskCreationRequest, setTaskCreationRequest] = useState(null);
	const [mode, setMode] = useState("auto");
	let t1;
	if ($[0] !== mode || $[1] !== taskCreationRequest) {
		t1 = {
			taskCreationRequest,
			setTaskCreationRequest,
			mode,
			setMode
		};
		$[0] = mode;
		$[1] = taskCreationRequest;
		$[2] = t1;
	} else t1 = $[2];
	const value = t1;
	let t2;
	if ($[3] !== children || $[4] !== value) {
		t2 = jsx(IntentDetectionContext, {
			value,
			children
		});
		$[3] = children;
		$[4] = value;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
IntentDetectionProvider.displayName = "IntentDetectionProvider";
function useIntentDetectionContext() {
	return use(IntentDetectionContext);
}
function makeFileOrSnippetReference({ referenceRepo, reference }) {
	if (reference.range) return makeSnippetReference(reference.path, reference.range, referenceRepo);
	else return makeFileReference(reference.path, referenceRepo);
}
/**
* Unified hook for all image-related concerns in the new-task chat input:
* paste/drop upload handling, markdown→reference syncing, and image-limit tracking.
*/
function useMarkdownImages(t0) {
	const $ = c(14);
	const { textAreaRef, repositoryId } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("copilot_agent_image_upload");
		$[0] = t1;
	} else t1 = $[0];
	const isImageUploadEnabled = t1;
	let t2;
	if ($[1] !== repositoryId || $[2] !== textAreaRef) {
		t2 = {
			textAreaRef,
			repositoryId,
			enabled: isImageUploadEnabled
		};
		$[1] = repositoryId;
		$[2] = textAreaRef;
		$[3] = t2;
	} else t2 = $[3];
	const { onPaste, dropTargetProps, isDraggedOver, isUploading } = useMarkdownImageHandling(t2);
	const manager = useChatManager();
	const currentReferences = useChatStateValue("currentReferences");
	const [inputText, setInputText] = useState("");
	let t3;
	if ($[4] !== currentReferences || $[5] !== inputText || $[6] !== manager) {
		t3 = {
			text: inputText,
			manager,
			currentReferences,
			enabled: isImageUploadEnabled
		};
		$[4] = currentReferences;
		$[5] = inputText;
		$[6] = manager;
		$[7] = t3;
	} else t3 = $[7];
	const { isAtImageLimit } = useImageReferenceSync(t3);
	let t4;
	if ($[8] !== dropTargetProps || $[9] !== isAtImageLimit || $[10] !== isDraggedOver || $[11] !== isUploading || $[12] !== onPaste) {
		t4 = {
			onPaste,
			dropTargetProps,
			isDraggedOver,
			isUploading,
			isAtImageLimit,
			onTextChange: setInputText
		};
		$[8] = dropTargetProps;
		$[9] = isAtImageLimit;
		$[10] = isDraggedOver;
		$[11] = isUploading;
		$[12] = onPaste;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
}
function NewTaskChatInput({ handleUserSubmit, initialRepo, initialReference, hideRepoSelector, isInPortal, chatInputRef, textAreaRef: textAreaRefFromProps, size = "large", className, eventType, shouldClearTextOnSubmit = true, initialText, initialBranch, isQuotaExhausted = false, isNewConversation, maxTextareaHeight, submitWithModifier = true, decoupledModeEnabled }) {
	const manager = useChatManager();
	const { plan } = useEntitlement();
	const { models: availableModels } = useAgentModels();
	const [selectedModelId, setSelectedModelId] = useLatestAgentModel();
	const [lastUsedRepo, setLastUsedRepo] = useLastUsedRepository();
	const [selectedRepo, setSelectedRepo] = useState(null);
	const textAreaRef = useRef(null);
	useImperativeHandle(textAreaRefFromProps ?? null, () => textAreaRef.current);
	const { onPaste, dropTargetProps, isDraggedOver, isUploading: isImageUploading, isAtImageLimit, onTextChange } = useMarkdownImages({
		textAreaRef,
		repositoryId: selectedRepo?.id?.toString()
	});
	const [currentPrompt, setCurrentPrompt] = useState(initialText || "");
	const handleTextChange = useCallback((text) => {
		onTextChange(text);
		setCurrentPrompt(text);
	}, [onTextChange]);
	const [referenceRepo, setReferenceRepo] = useState(null);
	const [selectedBranch, setSelectedBranch] = useState(initialBranch || "");
	const [selectedAgent, setSelectedAgent] = useLastSelectedAgent();
	const { isUsingIntentDetection } = useIntentDetection();
	const { mode: selectedMode, setMode: setSelectedMode } = useIntentDetectionContext();
	const { data: agentInfo } = useAgentInfo(selectedAgent.topLevelAgentId ? Number(selectedAgent.topLevelAgentId) : null);
	const shouldShowModelPicker = copilotFeatureFlags.codingAgentModelSelection && (copilotFeatureFlags.codingAgentModelSelectionAllSkus || plan === CopilotPlan.IndividualPro || plan === CopilotPlan.IndividualProPlus || plan === CopilotPlan.IndividualStudent) && isCopilotOrCustomAgent(selectedAgent, agentInfo?.slug);
	const [reference, setReference] = useState(initialReference || null);
	const chatReference = useMemo(() => referenceRepo && reference ? makeFileOrSnippetReference({
		reference,
		referenceRepo
	}) : void 0, [referenceRepo, reference]);
	const [createPullRequest, setCreatePullRequest] = useState(!decoupledModeEnabled);
	const [searchParams] = useSearchParams();
	const branchParam = searchParams.get("branch");
	const isImageUploadEnabled = isFeatureEnabled("copilot_agent_image_upload");
	const isSubAgentsEnabled = isFeatureEnabled("copilot_swe_agent_use_subagents");
	const isValidRepo = initialRepo && Object.keys(initialRepo).length > 0;
	const nwoParam = searchParams.get("repo");
	let initialNameWithOwner = "";
	if (isValidRepo) initialNameWithOwner = `${initialRepo.ownerLogin}/${initialRepo.name}`;
	else if (nwoParam) initialNameWithOwner = nwoParam;
	else if (lastUsedRepo) initialNameWithOwner = `${lastUsedRepo.ownerLogin}/${lastUsedRepo.name}`;
	const onSubmit = useCallback(async (content) => {
		sendEvent("agent_sessions.task_view", {
			target: "NEW_TASK_SUBMIT",
			defaultToTask: copilotFeatureFlags.defaultToAgentInput,
			defaultToTaskControl: copilotFeatureFlags.defaultToAgentControl,
			askModeDropdown: copilotFeatureFlags.askModeDropdown
		});
		if (selectedRepo?.id != null) {
			const result = await manager.service.fetchRepo(selectedRepo.id);
			if (result.ok && result.payload) setLastUsedRepo(result.payload);
		}
		return handleUserSubmit(content, selectedRepo, selectedBranch, selectedAgent, selectedMode, selectedModelId ?? availableModels?.find((m) => m.is_chat_default)?.id ?? availableModels?.[0]?.id, createPullRequest);
	}, [
		selectedRepo,
		selectedModelId,
		availableModels,
		handleUserSubmit,
		selectedBranch,
		selectedAgent,
		selectedMode,
		createPullRequest,
		manager.service,
		setLastUsedRepo
	]);
	const handleRepoSelect = useCallback((repo) => {
		if (!repo) return;
		setSelectedRepo(repo);
		setSelectedBranch(repo.defaultBranch || "");
	}, []);
	useEffect(() => {
		if (initialRepo?.id != null) (async () => {
			const repoResponse = await manager.service.fetchRepo(initialRepo.id);
			if (repoResponse.payload) setReferenceRepo(repoResponse.payload);
		})();
	}, [initialRepo, manager]);
	useEffect(() => {
		if (hideRepoSelector && initialNameWithOwner) {
			const fetchInitialRepo = async () => {
				try {
					const repo = (await queryForRepos(initialNameWithOwner)).find((repoData) => repoData.nameWithOwner === initialNameWithOwner);
					if (repo && repo.enabled) {
						setSelectedRepo(repo);
						setSelectedBranch(initialBranch ?? branchParam ?? repo.defaultBranch);
						return;
					}
				} catch {}
			};
			fetchInitialRepo();
		}
	}, []);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ChatInput, {
		initialText,
		className: clsx(className, { [NewTaskChatInput_module_default.isDraggedOver]: isDraggedOver }),
		modes: [{
			name: ModeSupportName.Agent,
			icon: AgentIcon,
			submitLabel: isUsingIntentDetection ? "Send now" : "Start task",
			placeholder: isUsingIntentDetection ? "Ask anything with intent" : decoupledModeEnabled ? "Give Copilot a background task to work on" : "Describe a coding task to work on",
			textAreaAriaLabel: isUsingIntentDetection ? "Ask anything with intent" : "Coding task prompt",
			supportsAttachments: false,
			supportsReferenceAttachments: isImageUploadEnabled,
			supportedReferenceTypes: isImageUploadEnabled ? ["image"] : void 0,
			supportsModelSwitching: shouldShowModelPicker,
			supportsAttachmentsMenu: isImageUploadEnabled ? false : void 0
		}],
		size,
		onSubmit,
		shouldSubmitWithModifier: submitWithModifier,
		isNewConversation,
		initialReference: chatReference,
		extraToolbar: /* @__PURE__ */ jsxs(Fragment$1, { children: [isUsingIntentDetection && /* @__PURE__ */ jsx(ModeSelector, {
			selectedMode,
			setMode: setSelectedMode
		}), /* @__PURE__ */ jsx(TaskChatInputToolbar, {
			hideRepoSelector,
			initialRepoNWO: initialNameWithOwner,
			initialBranch: initialBranch ?? branchParam ?? void 0,
			selectedRepo: selectedRepo || void 0,
			selectedBranch,
			selectedAgent,
			onRepoSelect: handleRepoSelect,
			onBranchSelect: (branch) => setSelectedBranch(branch || ""),
			onAgentSelect: (agent) => setSelectedAgent(agent),
			agentSelectionEnabled: isSubAgentsEnabled,
			textAreaRef,
			isAtImageLimit,
			currentPrompt
		})] }),
		submitDisabled: !selectedRepo || isQuotaExhausted || isImageUploading,
		onRemoveReference: () => {
			setReference(null);
		},
		isInPortal,
		textAreaRef,
		chatInputRef,
		onPaste,
		dropTargetProps,
		onTextChange: handleTextChange,
		onNewThreadSelected: async () => {},
		customModelPicker: shouldShowModelPicker ? () => /* @__PURE__ */ jsx(ModelPicker, {
			selectedModelId,
			onUpdateModel: setSelectedModelId
		}) : void 0,
		storageKeySuffix: eventType,
		source: "task",
		showStartTaskButton: copilotFeatureFlags.defaultToAgentInput,
		shouldClearTextOnSubmit,
		maxTextareaHeight,
		maxPromptLength: MAX_AGENT_TASK_PROMPT_LENGTH,
		enableAutoCorrect: true
	}), !isUsingIntentDetection && copilotFeatureFlags.codingAgentPullRequestToggle && /* @__PURE__ */ jsx(PullRequestToggleAddon, {
		checked: createPullRequest,
		onChange: setCreatePullRequest
	})] });
}
NewTaskChatInput.displayName = "NewTaskChatInput";
var copilotChatPayloadQueryOptions = queryOptions$1({
	queryKey: ["copilot-chat-payload"],
	queryFn: async () => {
		const resp = await verifiedFetchJSON("/github-copilot/chat");
		if (!resp.ok) throw new Error(`Failed to fetch chat provider: ${resp.statusText}`);
		return await resp.json();
	}
});
function useCopilotChatPayloadQuery() {
	const { data: t0 } = useQuery(copilotChatPayloadQueryOptions);
	return t0 === void 0 ? null : t0;
}
function NewAgentTaskForm(t0) {
	const $ = c(20);
	const { createTask, currentRepo, currentReference, onCreate, showHeader: t1, hideRepoSelector, eventType, isInPortal, textAreaRef, className, initialText, initialBranch, maxTextareaHeight, decoupledModeEnabled } = t0;
	const showHeader = t1 === void 0 ? true : t1;
	const [isQuotaExhausted, setIsQuotaExhausted] = useState(false);
	const copilotChatPayload = useCopilotChatPayloadQuery();
	const currentRepoFromContext = useCurrentRepository();
	const initialRepo = currentRepo || currentRepoFromContext;
	let t2;
	if ($[0] !== createTask || $[1] !== eventType || $[2] !== onCreate) {
		t2 = async (content, selectedRepo, selectedBranch, selectedAgent, _selectedMode, modelId, createPullRequest) => {
			const trimmedContent = content.trim();
			if (trimmedContent === "") return;
			if (!selectedRepo) return;
			createTask({
				nwo: selectedRepo.nameWithOwner,
				problemStatement: trimmedContent,
				baseRef: selectedBranch || selectedRepo.defaultBranch,
				eventType,
				eventContent: trimmedContent,
				intentDetectionMode: "task",
				createPullRequest,
				model: modelId,
				customAgent: selectedAgent?.subAgentSlug,
				agentId: selectedAgent?.topLevelAgentId
			});
			onCreate?.();
		};
		$[0] = createTask;
		$[1] = eventType;
		$[2] = onCreate;
		$[3] = t2;
	} else t2 = $[3];
	const handleUserSubmit = t2;
	let t3;
	if ($[4] !== className || $[5] !== copilotChatPayload || $[6] !== currentReference || $[7] !== decoupledModeEnabled || $[8] !== eventType || $[9] !== handleUserSubmit || $[10] !== hideRepoSelector || $[11] !== initialBranch || $[12] !== initialRepo || $[13] !== initialText || $[14] !== isInPortal || $[15] !== isQuotaExhausted || $[16] !== maxTextareaHeight || $[17] !== showHeader || $[18] !== textAreaRef) {
		t3 = jsxs(Fragment$1, { children: [showHeader && jsx("div", {
			className: NewAgentTaskForm_module_default.header,
			children: jsx("h2", {
				className: "f5",
				children: "New agent session"
			})
		}), jsx("div", {
			className: clsx(NewAgentTaskForm_module_default.content, !showHeader && "tmp-pt-3", className),
			children: copilotChatPayload ? jsx(CopilotChatProvider, {
				workerPath: copilotChatPayload.findFileWorkerPath,
				threadId: null,
				refs: copilotChatPayload.refs || [],
				mode: "immersive",
				ssoOrganizations: copilotChatPayload.ssoOrganizations || [],
				copilotChatPayload,
				children: jsxs(IntentDetectionProvider, { children: [jsx(CopilotCodingAgentQuotaBanner, {
					onQuotaExhaustedChange: setIsQuotaExhausted,
					entrypointLocation: "NEW_AGENT_TASK_FORM"
				}), jsx(NewTaskChatInput, {
					handleUserSubmit,
					initialRepo,
					initialReference: currentReference,
					hideRepoSelector,
					isInPortal,
					textAreaRef,
					size: "small",
					eventType,
					initialText,
					initialBranch,
					isQuotaExhausted,
					maxTextareaHeight,
					decoupledModeEnabled
				})] })
			}) : jsx(SkeletonBox, { className: NewAgentTaskForm_module_default.skeleton })
		})] });
		$[4] = className;
		$[5] = copilotChatPayload;
		$[6] = currentReference;
		$[7] = decoupledModeEnabled;
		$[8] = eventType;
		$[9] = handleUserSubmit;
		$[10] = hideRepoSelector;
		$[11] = initialBranch;
		$[12] = initialRepo;
		$[13] = initialText;
		$[14] = isInPortal;
		$[15] = isQuotaExhausted;
		$[16] = maxTextareaHeight;
		$[17] = showHeader;
		$[18] = textAreaRef;
		$[19] = t3;
	} else t3 = $[19];
	return t3;
}
NewAgentTaskForm.displayName = "NewAgentTaskForm";
/**
* Generates a task path for a given pull request global ID.
* @param globalId - The global ID of the pull request.
* @param sessionId - The ID of the session to be focused on page load.
* @returns The task path URL, or an empty string if globalId is empty.
*/
var generateTaskPath = (globalId, sessionId) => {
	if (!globalId) return "";
	let taskPath = `/copilot/tasks/pull/${encodeURIComponent(globalId)}`;
	if (sessionId) taskPath += `?session_id=${encodeURIComponent(sessionId)}`;
	return taskPath;
};
/**
* Generates a task path within a specific repository context.
* @param options - The options for generating the task path.
* @returns The task path URL, or an empty string if repository data is unavailable.
*/
var generateTaskPathForRepo = ({ repositoryNwo, pullRequestNumber, sessionId, taskId, isUsingIntentDetection = false }) => {
	if (isUsingIntentDetection && repositoryNwo && taskId) return `/copilot/t/${repositoryNwo}/${encodeURIComponent(taskId)}`;
	let taskPath = "";
	if (repositoryNwo) {
		if (taskId) taskPath = `/${repositoryNwo}/tasks/${encodeURIComponent(taskId)}`;
		else if (pullRequestNumber) taskPath = `/${repositoryNwo}/agents/pull/${encodeURIComponent(pullRequestNumber)}`;
	}
	if (taskPath && sessionId) taskPath += `?session_id=${encodeURIComponent(sessionId)}`;
	return taskPath;
};
var PROTECTED_ORGS_CACHE_KEY = "PROTECTED_ORGS";
/**
* Custom hook to detect SSO changes and clear relevant cache.
*
* When a user logs in or out of SSO orgs we should:
* - Clear auth token from localStorage
* - Clear cached tasks from localStorage
* - Invalidate React Query cache to force a refetch
*/
function useSSOChangeDetection() {
	const $ = c(5);
	const { ssoOrganizations } = useChatState();
	let t0;
	if ($[0] !== ssoOrganizations) {
		t0 = (ssoOrganizations ?? []).map(_temp).sort();
		$[0] = ssoOrganizations;
		$[1] = t0;
	} else t0 = $[1];
	const ssoOrgIDs = t0;
	let t1;
	let t2;
	if ($[2] !== ssoOrgIDs) {
		t1 = () => {
			const tokenProvider = getAgentSessionsTokenProvider();
			tokenProvider.ssoOrgIDs = ssoOrgIDs;
			const currentOrgsString = JSON.stringify(ssoOrgIDs);
			const prevOrgsString = sessionStorage.getItem(PROTECTED_ORGS_CACHE_KEY);
			if (prevOrgsString === null || prevOrgsString === "[]" && ssoOrgIDs.length > 0) {
				sessionStorage.setItem(PROTECTED_ORGS_CACHE_KEY, currentOrgsString);
				return;
			}
			if (currentOrgsString === prevOrgsString) return;
			tokenProvider.removeLocalStorageAuthToken();
			sessionStorage.setItem(PROTECTED_ORGS_CACHE_KEY, currentOrgsString);
		};
		t2 = [ssoOrgIDs];
		$[2] = ssoOrgIDs;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
}
function _temp(org) {
	return org.id;
}
export { useIntentDetectionEnabled as C, uuid as D, useTasks as E, useIntentDetectionContext as S, useSSOChangeDetection as T, intentDetectionHeaders as _, NewTaskChatInput as a, useCreateAPITask as b, createTask as c, generateTaskPath as d, generateTaskPathForRepo as f, getSortedResourceIds as g, getFlatTaskList as h, NewAgentTaskForm as i, fetchPullRequests as l, getAgentTasksQueryKeyForMutation as m, IntentDetectionProvider as n, PR_MAP_STORAGE_KEY as o, getAgentTasksQueryKey as p, ModeSelector as r, copilotChatPayloadQueryOptions as s, IntentDetectionEnabledProvider as t, fetchTasks as u, setFlatTaskList as v, useMarkdownImageHandling as w, useIntentDetection as x, useCopilotChatPayloadQuery as y };
