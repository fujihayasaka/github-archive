import { _i as Truncate, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
var Ago_module_default = {
	AgoTimestampLink: "Ago-module_T5YIXW_AgoTimestampLink",
	timestampText: "Ago-module_T5YIXW_timestampText"
};
var second = 1 * 1e3;
var minute = second * 60;
var hour = minute * 60;
var day = hour * 24;
var timeIntervals = [
	{
		unit: "month",
		ms: day * 30
	},
	{
		unit: "day",
		ms: day
	},
	{
		unit: "hour",
		ms: hour
	},
	{
		unit: "minute",
		ms: minute
	},
	{
		unit: "second",
		ms: second
	}
];
var fullDateFormatter = new Intl.DateTimeFormat(void 0, {
	year: "numeric",
	month: "short",
	day: "numeric",
	hour: "numeric",
	minute: "numeric",
	second: void 0,
	timeZoneName: "short"
});
var longDateFormatter = new Intl.DateTimeFormat(void 0, {
	year: "numeric",
	month: "short",
	day: "numeric"
});
var shortDateFormatter = new Intl.DateTimeFormat(void 0, {
	month: "short",
	day: "numeric"
});
function agoString(timestamp, usePreposition = true) {
	let timeString = "";
	const now = /* @__PURE__ */ new Date();
	const difference = now.getTime() - timestamp.getTime();
	const interval = timeIntervals.find((i) => i.ms < difference);
	if (interval && interval.unit !== "month") {
		const ago = Math.floor(difference / interval.ms);
		if (interval.unit === "day" && ago === 1) timeString = `yesterday`;
		else timeString = `${ago} ${interval.unit}${ago > 1 ? "s" : ""} ago`;
	} else {
		const formatter = timestamp.getFullYear() === now.getFullYear() ? shortDateFormatter : longDateFormatter;
		timeString = `${usePreposition ? "on " : ""}${formatter.format(timestamp)}`;
	}
	return timeString;
}
/**
* @deprecated
* use Primer's `RelativeTime` element instead
*/
function Ago({ timestamp, usePreposition = true, linkUrl, className }) {
	const timeString = agoString(timestamp, usePreposition);
	const fullDateString = fullDateFormatter.format(timestamp);
	if (!linkUrl) return /* @__PURE__ */ jsx(Truncate, {
		inline: true,
		title: fullDateString,
		children: /* @__PURE__ */ jsx("span", {
			title: fullDateString,
			className,
			children: timeString
		})
	});
	return /* @__PURE__ */ jsx(Link, {
		href: linkUrl,
		target: "_blank",
		className: clsx(Ago_module_default.AgoTimestampLink, className),
		children: /* @__PURE__ */ jsx(Truncate, {
			inline: true,
			title: fullDateString,
			children: /* @__PURE__ */ jsx("span", {
				title: fullDateString,
				className: Ago_module_default.timestampText,
				children: timeString
			})
		})
	});
}
Ago.displayName = "Ago";
function CircleOcticon(props) {
	const { size = 32, as, icon: IconComponent, bg, "aria-label": ariaLabel, style, className, ...rest } = props;
	return /* @__PURE__ */ jsx("div", {
		style: {
			backgroundColor: bg,
			overflow: "hidden",
			borderWidth: 0,
			borderRadius: "50%",
			borderStyle: "solid",
			borderColor: "var(--borderColor-default)",
			width: size,
			height: size
		},
		children: /* @__PURE__ */ jsx("div", {
			style: {
				display: "flex",
				width: size,
				height: size,
				alignItems: "center",
				justifyContent: "center",
				...style
			},
			className,
			...rest,
			children: /* @__PURE__ */ jsx(IconComponent, {
				size,
				"aria-label": ariaLabel
			})
		})
	});
}
CircleOcticon.displayName = "CircleOcticon";
export { agoString as n, CircleOcticon as t };
