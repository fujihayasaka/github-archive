import { createContext, use } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
var UserNameDisplayContext = createContext("handle");
UserNameDisplayContext.displayName = "UserNameDisplayContext";
var GRAPHQL_TO_CONTEXT_MAP = {
	NAME_HANDLE: "name_handle",
	NAME_AND_HANDLE: "name_handle",
	HANDLE: "handle"
};
function UserNameDisplayContextProvider({ value, children }) {
	return /* @__PURE__ */ jsx(UserNameDisplayContext, {
		value: value && GRAPHQL_TO_CONTEXT_MAP[value.toUpperCase()] || "handle",
		children
	});
}
UserNameDisplayContextProvider.displayName = "UserNameDisplayContextProvider";
function ProfileReference({ login, profileName, isAgent }) {
	const displayMode = use(UserNameDisplayContext);
	if (isAgent) return /* @__PURE__ */ jsx(Fragment$1, { children: login });
	if (displayMode === "name_handle" && profileName?.trim()) return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		profileName,
		" (",
		login,
		")"
	] });
	return /* @__PURE__ */ jsx(Fragment$1, { children: login });
}
ProfileReference.displayName = "ProfileReference";
export { UserNameDisplayContextProvider as n, ProfileReference as t };
