import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { ar as PlusIcon, hi as TriangleDownIcon, n as ActionList, wi as UploadIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as registerPortalRoot } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { n as useEditPermissions } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { useEffect, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
var AddFileDropdownButton_module_default = {
	ActionMenu_Overlay: "AddFileDropdownButton-module_EB5o9G_ActionMenu_Overlay",
	addFileButton: "AddFileDropdownButton-module_EB5o9G_addFileButton",
	addFileIcon: "AddFileDropdownButton-module_EB5o9G_addFileIcon"
};
var PORTAL_CONTAINER_NAME = "add-file-dropdown-portal-root";
function AddFileDropdownButton({ useDynamicSizing }) {
	const path = usePath();
	const refInfo = useRefInfo();
	const { canEdit } = useEditPermissions();
	const repo = useCurrentRepository();
	const { sendRepoClickEvent } = useReposAnalytics();
	const containerRef = useRef(null);
	useEffect(() => {
		if (containerRef.current) registerPortalRoot(containerRef.current, PORTAL_CONTAINER_NAME);
	});
	if (!canEdit) return null;
	return /* @__PURE__ */ jsxs("div", {
		ref: containerRef,
		children: [/* @__PURE__ */ jsx(ScreenReaderHeading, {
			as: "h2",
			text: "Add file"
		}), /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs(ButtonComponent, {
			"aria-label": "Add file",
			children: [/* @__PURE__ */ jsxs("span", {
				className: useDynamicSizing ? AddFileDropdownButton_module_default.addFileButton : void 0,
				children: ["Add file", /* @__PURE__ */ jsx(TriangleDownIcon, {})]
			}), useDynamicSizing && /* @__PURE__ */ jsx(PlusIcon, { className: AddFileDropdownButton_module_default.addFileIcon })]
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			className: AddFileDropdownButton_module_default.ActionMenu_Overlay,
			portalContainerName: PORTAL_CONTAINER_NAME,
			children: /* @__PURE__ */ jsxs(ActionList, { children: [/* @__PURE__ */ jsxs(ActionList.LinkItem, {
				as: Link$1,
				onClick: () => sendRepoClickEvent("NEW_FILE_BUTTON"),
				to: repositoryTreePath({
					repo,
					path,
					commitish: refInfo.name,
					action: "new"
				}),
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PlusIcon, {}) }), "Create new file"]
			}), /* @__PURE__ */ jsxs(ActionList.LinkItem, {
				onClick: () => sendRepoClickEvent("UPLOAD_FILES_BUTTON"),
				href: repositoryTreePath({
					repo,
					path,
					commitish: refInfo.name,
					action: "upload"
				}),
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(UploadIcon, {}) }), "Upload files"]
			})] })
		})] })]
	});
}
AddFileDropdownButton.displayName = "AddFileDropdownButton";
export { AddFileDropdownButton as t };
