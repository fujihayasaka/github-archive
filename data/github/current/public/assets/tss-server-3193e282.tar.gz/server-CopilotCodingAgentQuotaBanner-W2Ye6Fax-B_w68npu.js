import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as reactFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { _ as UPGRADE_PLAN_URL, b as copilotFeatureFlags } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { r as fetchCAPI } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { E as useEntitlement } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { m as ModelPickerDesign } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var AGENTS_PLUGIN_ID = "agents";
var AGENTS_PLUGIN_NAME = "Agents";
var AGENTS_PATH = "/copilot/agents";
var TASKS_PLUGIN_ID = "tasks";
var TASKS_PLUGIN_NAME = "Tasks";
var TASK_VIEW_COMPONENT_ID = "task-view";
var TASKS_IN_CHAT_COMPONENT_ID = "tasks-in-chat-view";
var COPILOT_INSTRUCTIONS_MAX_LENGTH = 1e4;
var COPILOT_ASSIGNMENT_API_ENDPOINT = "/issues/agent_assignments";
var MAX_AGENT_TASK_PROMPT_LENGTH = 3e4;
var buildEnterpriseCopilotCodingAgentPolicyUrl = (enterpriseSlug) => `/enterprises/${encodeURIComponent(enterpriseSlug)}/ai-controls/agents/policies`;
var COPILOT_ASSIGNMENT_BRANCH_CAPTION = "Pick the starting point that Copilot will use when it creates a new branch";
var COPILOT_ASSIGNMENT_REPO_LABEL = "Target repository";
var COPILOT_ASSIGNMENT_BRANCH_LABEL = "Base branch";
var COPILOT_ASSIGNMENT_PROMPT_LABEL = "Optional prompt";
var COPILOT_ASSIGNMENT_SELECT_BRANCH_HEADING = "Select base branch";
var AGENT_ASSIGNMENT_BRANCH_CAPTION = "Pick the starting point that the agent will use when it creates a new branch";
var COPILOT_CHAT_SPEC_TASK_EVENT_TYPE = "copilot-chat-spec-task";
var MISSION_CONTROL_EVENT_TYPES = [
	"activity_panel",
	"agents_page",
	"agents_panel",
	"api_call_received",
	"repo_agents",
	"repo_agents_sidebar"
];
var SWEAGENT_CAPI_MODEL_PREFIX = "sweagent-capi:";
var AGENT_TASKS_SELECTED_MODEL_KEY = `AGENT_TASKS_SELECTED_MODEL_v1`;
var AVATAR_FALLBACK_COLORS = [
	"var(--fgColor-done)",
	"var(--fgColor-accent)",
	"var(--fgColor-success)",
	"var(--fgColor-attention)",
	"var(--fgColor-severe)",
	"var(--fgColor-danger)",
	"var(--fgColor-sponsors)"
];
function createMockPull(id, global_relay_id, number, state, title, reviewable_state, labels, comments, assignees_count, author, created_days_ago, updated_days_ago = 0, inMergeQueue = false) {
	const baseDate = /* @__PURE__ */ new Date("2025-06-04T20:00:00.000Z");
	const createdAt = /* @__PURE__ */ new Date(baseDate.getTime() - created_days_ago * 24 * 60 * 60 * 1e3);
	const updatedAt = /* @__PURE__ */ new Date(baseDate.getTime() - updated_days_ago * 24 * 60 * 60 * 1e3);
	return {
		id,
		global_relay_id,
		number,
		state,
		title,
		reviewable_state,
		url: `http://github.localhost:80/monalisa/smile/pull/${number}`,
		labels,
		comments,
		assignees_avatar_urls: Array.from({ length: assignees_count }, (_, i) => `https://avatars.githubusercontent.com/u/${id + i}?v=4`),
		created_at: createdAt.toISOString(),
		updated_at: updatedAt.toISOString(),
		merged_at: state === "merged" ? updatedAt.toISOString() : void 0,
		closed_at: state === "closed" || state === "merged" ? updatedAt.toISOString() : void 0,
		author,
		head_sha: `${title.toLowerCase().replace(/\s+/g, "")}123456789abcdef0123456789abcdef01234567`.substring(0, 40),
		repository_nwo: "monalisa/smile",
		inMergeQueue,
		repository_id: 1,
		head_ref_name: "feature-branch",
		base_ref_name: "main",
		pr_diff_summary: {
			lines_added: Math.floor(Math.random() * 4) + 1,
			lines_changed: Math.floor(Math.random() * 3) + 1,
			lines_deleted: Math.floor(Math.random() * 2) + 1
		}
	};
}
function createMockSession(id, name, user_id, agent_id, state, resource_id, resource_global_id, created_hours_ago, updated_hours_ago = 0, premium_requests = 0, error_message, model) {
	const baseDate = /* @__PURE__ */ new Date("2025-06-04T20:00:00.000Z");
	const createdAt = /* @__PURE__ */ new Date(baseDate.getTime() - created_hours_ago * 60 * 60 * 1e3);
	const updatedAt = /* @__PURE__ */ new Date(baseDate.getTime() - updated_hours_ago * 60 * 60 * 1e3);
	const isCompleted = state === "completed" || state === "failed";
	return {
		id,
		name,
		user_id,
		agent_id,
		state,
		owner_id: 9919,
		repo_id: 4,
		resource_type: "pull",
		resource_id,
		resource_global_id,
		created_at: createdAt.toISOString(),
		last_updated_at: updatedAt.toISOString(),
		updated_at: updatedAt.toISOString(),
		completed_at: isCompleted ? updatedAt.toISOString() : void 0,
		workflow_run_id: 12340 + Math.floor(Math.random() * 30),
		log_entries: [],
		error: error_message ? { message: error_message } : null,
		premium_requests,
		event_identifiers: null,
		event_type: "api_call_received",
		event_url: null,
		event_content: name || null,
		model: model ?? ""
	};
}
function createTask(pull, session) {
	return {
		resource_type: "pull",
		resource_id: pull.id,
		resource_global_id: pull.global_relay_id,
		session_count: 1,
		latest_session_updated_at: session.updated_at ?? session.last_updated_at,
		latest_session_state: session.state,
		pull
	};
}
(() => {
	const pullStates = [
		"open",
		"closed",
		"merged"
	];
	const sessionStates = [
		"cancelled",
		"idle",
		"in_progress",
		"waiting_for_user",
		"completed",
		"failed",
		"timed_out"
	];
	const mockData = {
		titles: [
			"Refactor database queries for performance",
			"Implement dark mode theme",
			"Optimize API response times",
			"Add mobile responsive design",
			"Implement caching layer",
			"Add internationalization support",
			"Update documentation and README",
			"Fix critical security vulnerability",
			"Add user authentication system",
			"Initial project setup and configuration",
			"Implement real-time notifications",
			"Add search functionality",
			"Optimize bundle size",
			"Add unit tests coverage",
			"Implement error handling",
			"Add accessibility features",
			"Optimize database connections",
			"Implement feature flags",
			"Migrate to TypeScript",
			"Implement CI/CD pipeline",
			"Add monitoring and alerts"
		],
		authors: [
			"alice-dev",
			"bob-backend",
			"charlie-frontend",
			"diana-fullstack",
			"eve-designer",
			"frank-security"
		],
		labels: [
			["performance", "database"],
			[
				"ui",
				"theme",
				"enhancement"
			],
			["performance", "api"],
			[
				"mobile",
				"responsive",
				"ui"
			],
			[
				"performance",
				"caching",
				"backend"
			],
			[
				"i18n",
				"feature",
				"localization"
			]
		],
		errorMessages: [
			"timeout",
			"validation error",
			"resource conflict",
			"permission denied"
		]
	};
	let id = 1;
	let globalId = "";
	return [...pullStates.flatMap((pullState) => sessionStates.map((sessionState) => {
		globalId = `PR_${id}`;
		const titleIndex = (id - 1) % mockData.titles.length;
		const title = mockData.titles[titleIndex];
		const author = mockData.authors[(id - 1) % mockData.authors.length];
		const labels = mockData.labels[titleIndex % mockData.labels.length];
		const result = createTask(createMockPull(id, globalId, id, pullState, title, Math.random() > .7 ? "draft" : "ready", labels, Math.floor(Math.random() * 15) + 1, Math.floor(Math.random() * 3), author, id, id), createMockSession(`session-${id.toString().padStart(3, "0")}`, `${title.split(" ").slice(0, 3).join(" ")} - ${sessionState}`, 10053400 + id, 1143300 + id, sessionState, id, globalId, id, id, Math.floor(Math.random() * 10), sessionState === "failed" ? `Operation failed due to ${mockData.errorMessages[Math.floor(Math.random() * 4)]}` : void 0));
		id++;
		return result;
	})), createTask(createMockPull(id, globalId, id, "open", "Add feature flags support (in merge queue)", "ready", ["feature", "flags"], 5, 1, "alice-dev", 21, 0, true), createMockSession(`session-${id.toString().padStart(3, "0")}`, "Add feature flags support - in_progress", 10053400 + id, 1143300 + id, "in_progress", id, globalId, 1, 0, 2, void 0))];
})();
var CLI_AGENT_ID_PROD = 1693627;
/**
* Checks if an agent ID belongs to the Copilot CLI.
* In development mode, also checks for the dev environment ID.
*/
function isCLIAgentId(agentId) {
	if (agentId === void 0) return false;
	if ((typeof agentId === "string" ? parseInt(agentId, 10) : agentId) === CLI_AGENT_ID_PROD) return true;
	return false;
}
/**
* Checks if a session was created by the Copilot CLI.
*/
function isCLISession(session) {
	if (!session) return false;
	return isCLIAgentId(session.agent_id);
}
/**
* Checks if a task was created by the Copilot CLI.
* Uses the agentId field which contains the first collaborator's agent_id.
*/
function isTaskFromCLI(task) {
	if (!task) return false;
	return isCLIAgentId(task.agentId);
}
/**
* Checks if an API task was created by the Copilot CLI.
* Uses the first agent_collaborator's agent_id.
*/
function isAPITaskFromCLI(task) {
	if (!task) return false;
	return task.agent_collaborators?.some((c) => isCLIAgentId(c.agent_id)) ?? false;
}
function generateAgentInfoQueryKey(agentId, isCliAgent) {
	return [
		"agent-info",
		agentId,
		isCliAgent
	];
}
var CLI_AGENT_INFO = {
	display_name: "Copilot CLI",
	slug: "copilot-cli",
	avatar_url: "",
	doc_url: ""
};
/**
*
* This hook fetches agent metadata (name, avatar, etc.) from the monolith
* for agents that are returned from CAPI sessions but don't include
* full agent information.
*
* For CLI sessions, returns hardcoded info since the CLI agent isn't
* registered in the monolith's agent registry.
*/
function useAgentInfo(agentId) {
	const $ = c(11);
	let isCliAgent;
	let t0;
	let t1;
	if ($[0] !== agentId) {
		isCliAgent = isCLIAgentId(agentId ?? void 0);
		t1 = useQuery;
		t0 = generateAgentInfoQueryKey(agentId, isCliAgent);
		$[0] = agentId;
		$[1] = isCliAgent;
		$[2] = t0;
		$[3] = t1;
	} else {
		isCliAgent = $[1];
		t0 = $[2];
		t1 = $[3];
	}
	let t2;
	if ($[4] !== agentId || $[5] !== isCliAgent) {
		t2 = async () => {
			if (isCliAgent) return CLI_AGENT_INFO;
			const response = await reactFetchJSON(`/copilot/agent-sessions/agents/${agentId}`);
			if (!response.ok) {
				if (response.status >= 500) throw new Error(`Failed to fetch agent info for agent ${agentId}: ${response.status}`);
				return null;
			}
			return (await response.json()).agent_info;
		};
		$[4] = agentId;
		$[5] = isCliAgent;
		$[6] = t2;
	} else t2 = $[6];
	const t3 = !!agentId;
	let t4;
	if ($[7] !== t0 || $[8] !== t2 || $[9] !== t3) {
		t4 = {
			queryKey: t0,
			queryFn: t2,
			enabled: t3,
			staleTime: Infinity,
			retry: 3
		};
		$[7] = t0;
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	return t1(t4);
}
var betaLabels = ["(Beta)", "(Preview)"];
var getDisplayName = (modelName, modelId) => {
	const name = modelName || modelId;
	for (const suffix of betaLabels) if (name.endsWith(suffix)) return name.replace(suffix, "").trim();
	return name;
};
var OPEN_AI_LOGO = "/images/modules/marketplace/models/families/openai-logo.svg";
var ANTHROPIC_LOGO = "/images/modules/marketplace/models/families/anthropic.svg";
var GEMINI_LOGO = "/images/modules/marketplace/models/families/gemini.svg";
var XAI_LOGO = "/images/modules/marketplace/models/families/xai.svg";
var XAI_LOGO_DARK = "/images/modules/marketplace/models/families/xai-dark.svg";
var LOGO_BY_VENDOR = new Map([
	["Azure OpenAI", OPEN_AI_LOGO],
	["OpenAI", OPEN_AI_LOGO],
	["Anthropic", ANTHROPIC_LOGO],
	["Google", GEMINI_LOGO],
	["xAI", XAI_LOGO]
]);
var cachedModels = null;
var cachePromise = null;
function useAgentModels() {
	const [models, setModels] = useState(cachedModels || []);
	const [isLoading, setIsLoading] = useState(!cachedModels);
	const [error, setError] = useState(null);
	useEffect(() => {
		if (cachedModels) {
			setModels(cachedModels);
			setIsLoading(false);
			return;
		}
		if (cachePromise) {
			(async () => {
				try {
					setModels(await cachePromise);
					setIsLoading(false);
				} catch (err) {
					setError(err instanceof Error ? err : /* @__PURE__ */ new Error("An unexpected error occurred while loading models."));
					setIsLoading(false);
				}
			})();
			return;
		}
		async function fetchModels() {
			try {
				setIsLoading(true);
				setError(null);
				const data = await (await listModels()).json();
				const isDarkMode = document.querySelector("[data-color-mode=\"dark\"]") !== null;
				const transformedModels_0 = (data.data || []).map((model) => {
					let logoUrl = LOGO_BY_VENDOR.get(model.vendor);
					if (model.vendor === "xAI" && isDarkMode) logoUrl = XAI_LOGO_DARK;
					return {
						...model,
						displayName: getDisplayName(model.name, model.id),
						logoURL: logoUrl,
						hasLimitedCapabilities: !model.capabilities.supports.tool_calls,
						isThirdParty: model.vendor !== "Azure OpenAI"
					};
				});
				cachedModels = transformedModels_0;
				cachePromise = null;
				return transformedModels_0;
			} catch (err_0) {
				cachePromise = null;
				const modelsError = err_0 instanceof Error ? err_0 : /* @__PURE__ */ new Error("An unexpected error occurred while loading models.");
				setError(modelsError);
				throw modelsError;
			} finally {
				setIsLoading(false);
			}
		}
		if (!cachePromise) cachePromise = fetchModels();
		(async () => {
			try {
				setModels(await cachePromise);
				setIsLoading(false);
			} catch (err_1) {
				setError(err_1 instanceof Error ? err_1 : /* @__PURE__ */ new Error("An unexpected error occurred while loading models."));
				setIsLoading(false);
			}
		})();
	}, []);
	return {
		models,
		isLoading,
		error
	};
}
async function listModels() {
	return await fetchCAPI({
		path: "/agents/swe/models",
		method: "GET"
	});
}
function createPlaceholderModel(invalidModelId) {
	return {
		id: invalidModelId,
		name: `${invalidModelId} (unavailable)`,
		displayName: `${invalidModelId} (unavailable)`,
		hasLimitedCapabilities: true,
		isThirdParty: false,
		version: "",
		vendor: "",
		preview: false,
		model_picker_enabled: false,
		capabilities: {
			type: "chat",
			family: "",
			limits: { max_prompt_tokens: 0 },
			supports: {},
			tokenizer: ""
		}
	};
}
function ModelPicker(t0) {
	const $ = c(8);
	const { onUpdateModel, selectedModelId } = t0;
	const { models: availableModels, isLoading } = useAgentModels();
	let t1;
	if ($[0] !== onUpdateModel) {
		t1 = (model) => {
			onUpdateModel(model.id);
		};
		$[0] = onUpdateModel;
		$[1] = t1;
	} else t1 = $[1];
	const handleUpdateModel = t1;
	let t2;
	let t3;
	if ($[2] !== availableModels || $[3] !== handleUpdateModel || $[4] !== isLoading || $[5] !== selectedModelId) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const foundModel = availableModels?.find((model_0) => model_0.id === selectedModelId);
			const defaultModel = availableModels?.find(_temp) ?? availableModels?.[0];
			const selectedModel = selectedModelId ? foundModel ?? createPlaceholderModel(selectedModelId) : defaultModel;
			const isOnlyAutoModel = copilotFeatureFlags.codingAgentHideModelPickerIfOnlyAuto && availableModels?.length === 1 && availableModels[0]?.id === "auto";
			if (isLoading || !availableModels || !selectedModel || isOnlyAutoModel) {
				t3 = null;
				break bb0;
			}
			t2 = jsx(ModelPickerDesign, {
				models: availableModels,
				selectedModel,
				onModelPicked: handleUpdateModel,
				disabled: false,
				type: "global",
				variant: "invisible",
				showCategories: false,
				showMultipliers: true,
				showPreviewModelsSeparately: false
			});
		}
		$[2] = availableModels;
		$[3] = handleUpdateModel;
		$[4] = isLoading;
		$[5] = selectedModelId;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
ModelPicker.displayName = "ModelPicker";
function _temp(m) {
	return m.is_chat_default;
}
/**
* Hook for managing the latest selected agent model as a plain string in localStorage.
* Uses useSyncExternalStore to properly subscribe to localStorage changes across tabs.
*/
function useLatestAgentModel() {
	return [useSyncExternalStore(useCallback((callback) => {
		const handleStorageChange = (e) => {
			if (e.key === AGENT_TASKS_SELECTED_MODEL_KEY) callback();
		};
		window.addEventListener("storage", handleStorageChange);
		return () => window.removeEventListener("storage", handleStorageChange);
	}, []), useCallback(() => {
		try {
			return localStorage.getItem(AGENT_TASKS_SELECTED_MODEL_KEY) ?? void 0;
		} catch {
			return;
		}
	}, []), useCallback(() => void 0, [])), useCallback((newValue) => {
		try {
			if (newValue === void 0) localStorage.removeItem(AGENT_TASKS_SELECTED_MODEL_KEY);
			else localStorage.setItem(AGENT_TASKS_SELECTED_MODEL_KEY, newValue);
			window.dispatchEvent(new StorageEvent("storage", {
				key: AGENT_TASKS_SELECTED_MODEL_KEY,
				newValue: newValue ?? null,
				oldValue: localStorage.getItem(AGENT_TASKS_SELECTED_MODEL_KEY)
			}));
		} catch {}
	}, [])];
}
var CopilotCodingAgentQuotaBanner_module_default = { container: "CopilotCodingAgentQuotaBanner-module_PBaEYG_container" };
/**
* Hook to determine if the CopilotCodingAgentQuotaBanner should be shown.
* Use this to conditionally render the banner wrapper to avoid unnecessary DOM elements.
*/
function useShouldShowCodingAgentQuotaBanner() {
	const $ = c(3);
	const { chatQuotaRemaining, isLicensedLimited, chatQuotaExceeded, resetDate } = useEntitlement();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("copilot_coding_agent_free_users_exp");
		$[0] = t0;
	} else t0 = $[0];
	const shouldShowBanners = t0 && isLicensedLimited;
	let t1;
	if ($[1] !== resetDate) {
		t1 = () => resetDate ? copilotLocalStorage.getCodingAgentQuotaBannerDismissed(resetDate) : false;
		$[1] = resetDate;
		$[2] = t1;
	} else t1 = $[2];
	const [isApproachingBannerDismissed] = useState(t1);
	return shouldShowBanners && !chatQuotaExceeded && chatQuotaRemaining <= 50 && !isApproachingBannerDismissed || shouldShowBanners && chatQuotaExceeded;
}
/**
* Displays upgrade banners for free Copilot users based on their quota usage.
*
* - Shows an "info" variant dismissible banner when 50-99% of quota is used
* - Shows an "upsell" variant non-dismissible banner when 100% of quota is used
*/
function CopilotCodingAgentQuotaBanner(t0) {
	const $ = c(17);
	const { onQuotaExhaustedChange, entrypointLocation } = t0;
	const { chatQuotaRemaining, isLicensedLimited, chatQuotaExceeded, resetDate } = useEntitlement();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("copilot_coding_agent_free_users_exp");
		$[0] = t1;
	} else t1 = $[0];
	const isFreeUserExperimentEnabled = t1;
	const percentageUsed = 100 - chatQuotaRemaining;
	const shouldShowBanners = isFreeUserExperimentEnabled && isLicensedLimited;
	let t2;
	if ($[1] !== entrypointLocation) {
		t2 = () => {
			sendEvent("copilot_growth.free_cca", { target: `QUOTA_UPSELL_CLICK_${entrypointLocation}` });
		};
		$[1] = entrypointLocation;
		$[2] = t2;
	} else t2 = $[2];
	const handleUpgradeClick = t2;
	let t3;
	if ($[3] !== resetDate) {
		t3 = () => resetDate ? copilotLocalStorage.getCodingAgentQuotaBannerDismissed(resetDate) : false;
		$[3] = resetDate;
		$[4] = t3;
	} else t3 = $[4];
	const [isApproachingBannerDismissed, setIsApproachingBannerDismissed] = useState(t3);
	const showApproachingBanner = shouldShowBanners && !chatQuotaExceeded && chatQuotaRemaining <= 50 && !isApproachingBannerDismissed;
	const showExhaustedBanner = shouldShowBanners && chatQuotaExceeded;
	let t4;
	let t5;
	if ($[5] !== onQuotaExhaustedChange || $[6] !== showExhaustedBanner) {
		t4 = () => {
			onQuotaExhaustedChange?.(showExhaustedBanner);
		};
		t5 = [showExhaustedBanner, onQuotaExhaustedChange];
		$[5] = onQuotaExhaustedChange;
		$[6] = showExhaustedBanner;
		$[7] = t4;
		$[8] = t5;
	} else {
		t4 = $[7];
		t5 = $[8];
	}
	useEffect(t4, t5);
	let t6;
	if ($[9] !== resetDate) {
		t6 = () => {
			if (resetDate) {
				copilotLocalStorage.setCodingAgentQuotaBannerDismissed(resetDate);
				setIsApproachingBannerDismissed(true);
			}
		};
		$[9] = resetDate;
		$[10] = t6;
	} else t6 = $[10];
	const handleDismissApproachingBanner = t6;
	if (!showApproachingBanner && !showExhaustedBanner) return null;
	let t7;
	if ($[11] !== handleDismissApproachingBanner || $[12] !== handleUpgradeClick || $[13] !== percentageUsed || $[14] !== resetDate || $[15] !== showExhaustedBanner) {
		const bannerConfig = showExhaustedBanner ? {
			variant: "upsell",
			title: "Limit reached",
			testId: "coding-agent-quota-exhausted-banner",
			message: `You have reached your free plan limit. Limit resets on ${resetDate}.`,
			onDismiss: void 0
		} : {
			variant: "info",
			title: "Quota approaching",
			testId: "coding-agent-quota-approaching-banner",
			message: `You've used ${percentageUsed}% of your free requests this month.`,
			onDismiss: handleDismissApproachingBanner
		};
		t7 = jsx("div", {
			className: CopilotCodingAgentQuotaBanner_module_default.container,
			"data-testid": bannerConfig.testId,
			children: jsx(Banner, {
				variant: bannerConfig.variant,
				title: bannerConfig.title,
				hideTitle: true,
				primaryAction: jsx(Banner.PrimaryAction, {
					as: "a",
					href: UPGRADE_PLAN_URL,
					onClick: handleUpgradeClick,
					children: "Upgrade To Copilot Pro"
				}),
				onDismiss: bannerConfig.onDismiss,
				children: bannerConfig.message
			})
		});
		$[11] = handleDismissApproachingBanner;
		$[12] = handleUpgradeClick;
		$[13] = percentageUsed;
		$[14] = resetDate;
		$[15] = showExhaustedBanner;
		$[16] = t7;
	} else t7 = $[16];
	return t7;
}
CopilotCodingAgentQuotaBanner.displayName = "CopilotCodingAgentQuotaBanner";
export { useLatestAgentModel as A, TASK_VIEW_COMPONENT_ID as C, isTaskFromCLI as D, isCLISession as E, useAgentInfo as O, TASKS_PLUGIN_NAME as S, isAPITaskFromCLI as T, MISSION_CONTROL_EVENT_TYPES as _, AGENT_TASKS_SELECTED_MODEL_KEY as a, TASKS_IN_CHAT_COMPONENT_ID as b, COPILOT_ASSIGNMENT_BRANCH_CAPTION as c, COPILOT_ASSIGNMENT_REPO_LABEL as d, COPILOT_ASSIGNMENT_SELECT_BRANCH_HEADING as f, MAX_AGENT_TASK_PROMPT_LENGTH as g, CopilotCodingAgentQuotaBanner as h, AGENT_ASSIGNMENT_BRANCH_CAPTION as i, useShouldShowCodingAgentQuotaBanner as j, useAgentModels as k, COPILOT_ASSIGNMENT_BRANCH_LABEL as l, COPILOT_INSTRUCTIONS_MAX_LENGTH as m, AGENTS_PLUGIN_ID as n, AVATAR_FALLBACK_COLORS as o, COPILOT_CHAT_SPEC_TASK_EVENT_TYPE as p, AGENTS_PLUGIN_NAME as r, COPILOT_ASSIGNMENT_API_ENDPOINT as s, AGENTS_PATH as t, COPILOT_ASSIGNMENT_PROMPT_LABEL as u, ModelPicker as v, buildEnterpriseCopilotCodingAgentPolicyUrl as w, TASKS_PLUGIN_ID as x, SWEAGENT_CAPI_MODEL_PREFIX as y };
