import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { useEffect, useState } from "react";
import { c } from "react/compiler-runtime";
/**
* Retrieve information of contributors of current path
*
* returns an object with contributors, loading state and error
* while loading returns {loading: true}
* if cannot retrieve contributor , returns {error: true}
*/
function useContributors(repoOwner, repoName, commitish, path) {
	const $ = c(9);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { loading: true };
		$[0] = t0;
	} else t0 = $[0];
	const [state, setState] = useState(t0);
	let t1;
	if ($[1] !== commitish || $[2] !== path || $[3] !== repoName || $[4] !== repoOwner) {
		t1 = repoName && repoOwner && commitish && path ? repositoryTreePath({
			repo: {
				name: repoName,
				ownerLogin: repoOwner
			},
			commitish,
			action: "file-contributors",
			path
		}) : null;
		$[1] = commitish;
		$[2] = path;
		$[3] = repoName;
		$[4] = repoOwner;
		$[5] = t1;
	} else t1 = $[5];
	const fileContributorsPath = t1;
	let t2;
	let t3;
	if ($[6] !== fileContributorsPath) {
		t2 = () => {
			if (!fileContributorsPath) return;
			let cancelled = false;
			const update = async () => {
				setState({ loading: true });
				const response = await verifiedFetchJSON(fileContributorsPath);
				if (cancelled) return;
				try {
					if (response.ok) setState({ contributors: await response.json() });
					else setState({ error: true });
				} catch {
					setState({ error: true });
				}
			};
			update();
			return function cancel() {
				cancelled = true;
			};
		};
		t3 = [fileContributorsPath];
		$[6] = fileContributorsPath;
		$[7] = t2;
		$[8] = t3;
	} else {
		t2 = $[7];
		t3 = $[8];
	}
	useEffect(t2, t3);
	return state;
}
export { useContributors as t };
