import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { Gt as GitMergeQueueIcon, Ir as SkipIcon, Kt as GitPullRequestClosedIcon, O as CheckIcon, Qr as StopIcon, V as ClockIcon, Wt as GitMergeIcon, c as ArchiveIcon, pt as DotFillIcon, si as TerminalIcon, z as CircleIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { c as useQueries, l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as useIsMounted } from "./server-use-is-mounted-BP8yEjoH-CZJ4mOOX.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { createElement, memo, useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* Generates the API path for repository tasks endpoint
* @param nwo - Repository name with owner (e.g., "github/github")
* @returns API path for the repo tasks endpoint
*/
function repoTasksApiPath(nwo) {
	const [owner, repo] = nwo.split("/");
	return `/agents/repos/${owner}/${repo}/tasks`;
}
/**
* Generates the API path for creating a session for a specific task
* @param nwo - Repository name with owner (e.g., "github/github")
* @param taskId - The task ID
* @returns API path for the task sessions endpoint
*/
function repoTaskSessionsApiPath(nwo, taskId) {
	const [owner, repo] = nwo.split("/");
	return `/agents/repos/${owner}/${repo}/tasks/${taskId}/sessions`;
}
/**
* Generates query parameters for tasks endpoints.
* When copilot_task_api_github_rest_style is enabled, uses GitHub REST API-style param names:
*   page (instead of page_number), per_page (instead of page_size)
* @param params Query parameters
* @returns Query string for tasks endpoint
*/
var generateTasksQueryParams = (params) => {
	const useRestStyle = isFeatureEnabled("copilot_task_api_github_rest_style");
	const searchParams = new URLSearchParams();
	if (params.creatorId !== void 0) searchParams.set("creator_id", String(params.creatorId));
	if (params.page !== void 0) searchParams.set(useRestStyle ? "page" : "page_number", String(params.page));
	if (params.archived !== void 0) searchParams.set("archived", String(params.archived));
	if (params.includeCounts !== void 0) searchParams.set("include_counts", String(params.includeCounts));
	if (params.pageSize !== void 0) searchParams.set(useRestStyle ? "per_page" : "page_size", String(params.pageSize));
	const query = searchParams.toString();
	return query ? `?${query}` : "";
};
/**
* Generates the API path for the tasks endpoint with query parameters
* @param params - Optional query parameters
* @returns API path for the tasks endpoint with query string
*/
function tasksApiPathWithParams(params) {
	const basePath = `/agents/tasks`;
	const query = params ? generateTasksQueryParams(params) : "";
	return query ? `${basePath}${query}` : basePath;
}
/**
* Generates the API path for task endpoint
* @param owner - Repository owner
* @param repo - Repository name
* @param taskId - Task ID
* @returns API path for the task endpoint
*/
function taskApiPath(owner, repo, taskId) {
	return `/agents/repos/${owner}/${repo}/tasks/${taskId}`;
}
/**
* Generates the API path for pull request sessions endpoint
* @param pullId - Pull request ID
* @returns API path for the pull sessions endpoint
*/
function pullSessionsApiPath(pullId) {
	return `/agents/sessions/resource/pull/${pullId}`;
}
/**
* Generates the API path for task inactive logs endpoint
* @param owner - Repository owner
* @param repo - Repository name
* @param taskId - Task ID
* @returns API path for the task inactive logs endpoint
*/
function taskInactiveLogsApiPath(owner, repo, taskId) {
	return `/agents/repos/${owner}/${repo}/tasks/${taskId}/inactive_logs`;
}
/**
* Generates the API path for pull request inactive logs endpoint
* @param pullId - Pull request ID
* @returns API path for the pull inactive logs endpoint
*/
function pullInactiveLogsApiPath(pullId) {
	return `/agents/sessions/resource/pull/${pullId}/inactive_logs`;
}
/**
* Hook that subscribes to agent session alive updates and triggers callback when events are received.
*
* @param options.onEvent - Callback triggered when session events occur
* @param options.enableCreateEvents - Whether to subscribe to create events (default: true)
* @param options.enableUpdateEvents - Whether to subscribe to update events (default: true)
* @param options.enableLogUpdates - Whether to subscribe to log_update events (default: false)
* @param options.enableTaskUpdates - Whether to subscribe to task_update events (default: false)
* @param options.enabled - Whether the hook is enabled (default: true)
* @returns Object with connection status: isConnected, isLoading, isError
*/
function useAgentSessionsAlive(options) {
	const $ = c(10);
	const { onEvent, enableCreateEvents: t0, enableUpdateEvents: t1, enableLogUpdates: t2, enableTaskUpdates: t3, enabled } = options;
	const enableCreateEvents = t0 === void 0 ? true : t0;
	const enableUpdateEvents = t1 === void 0 ? true : t1;
	const enableLogUpdates = t2 === void 0 ? false : t2;
	const enableTaskUpdates = t3 === void 0 ? false : t3;
	const isMounted = useIsMounted();
	let t4;
	if ($[0] !== isMounted || $[1] !== onEvent) {
		t4 = (payload) => {
			if (isMounted()) onEvent(payload);
		};
		$[0] = isMounted;
		$[1] = onEvent;
		$[2] = t4;
	} else t4 = $[2];
	const handleAliveEvent = t4;
	let t5;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = ["agent-session-alive-channels"];
		$[3] = t5;
	} else t5 = $[3];
	const t6 = enabled ?? true;
	let t7;
	if ($[4] !== t6) {
		t7 = {
			queryKey: t5,
			queryFn: _temp$1,
			staleTime: Infinity,
			enabled: t6
		};
		$[4] = t6;
		$[5] = t7;
	} else t7 = $[5];
	const { data: channels, isLoading, isError, isSuccess } = useQuery(t7);
	useAlive(enableCreateEvents ? channels?.viewerCopilotAgentCreatesChannel : void 0, handleAliveEvent);
	useAlive(enableUpdateEvents ? channels?.viewerCopilotAgentUpdatesChannel : void 0, handleAliveEvent);
	useAlive(enableLogUpdates ? channels?.viewerCopilotAgentLogUpdatesChannel : void 0, handleAliveEvent);
	useAlive(enableTaskUpdates ? channels?.viewerCopilotAgentTaskUpdatesChannel : void 0, handleAliveEvent);
	const isConnected = isSuccess && !!(channels?.viewerCopilotAgentCreatesChannel || channels?.viewerCopilotAgentUpdatesChannel || channels?.viewerCopilotAgentLogUpdatesChannel || channels?.viewerCopilotAgentTaskUpdatesChannel);
	let t8;
	if ($[6] !== isConnected || $[7] !== isError || $[8] !== isLoading) {
		t8 = {
			isConnected,
			isLoading,
			isError
		};
		$[6] = isConnected;
		$[7] = isError;
		$[8] = isLoading;
		$[9] = t8;
	} else t8 = $[9];
	return t8;
}
async function _temp$1() {
	const response = await fetch("/copilot/agent-sessions/alive-channels", { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error("Failed to fetch Alive channels");
	const result = await response.json();
	return {
		viewerCopilotAgentCreatesChannel: result.creates_channel,
		viewerCopilotAgentUpdatesChannel: result.updates_channel,
		viewerCopilotAgentLogUpdatesChannel: result.log_updates_channel,
		viewerCopilotAgentTaskUpdatesChannel: result.task_updates_channel
	};
}
/**
* Type guard to check if an artifact is a branch artifact.
*/
function isBranchArtifact(artifact) {
	return artifact.type === "branch" && artifact.provider === "github";
}
/**
* Type guard to check if an artifact is a GitHub resource artifact.
*/
function isGitHubResourceArtifact(artifact) {
	return artifact.type === "github_resource" && artifact.provider === "github";
}
var getBranchArtifactData = (artifacts) => {
	return (artifacts?.find(isBranchArtifact))?.data;
};
var getGitHubArtifactData = (artifacts) => {
	return (artifacts?.find(isGitHubResourceArtifact))?.data;
};
/**
* Extracts the updated_at timestamp from an API task, supporting both
* the new `updated_at` field (copilot_task_api_github_rest_style) and
* the legacy `last_updated_at` field.
*/
function getAPITaskUpdatedAt(apiTask) {
	return apiTask.updated_at ?? apiTask.last_updated_at;
}
/**
* Extracts the task state from an API task, supporting both
* the new `state` field (copilot_task_api_github_rest_style) and
* the legacy `status` field.
*/
function getAPITaskState(apiTask) {
	return apiTask.state ?? apiTask.status;
}
/**
* Gets the display title for a task.
*
* @param task - The task to get the title for
* @param pullTitle - Optional pull request title to use as fallback
* @returns The display title for the task
*/
function getTaskTitle(task, pullTitle) {
	if (isFeatureEnabled("copilot_mission_control_use_task_name")) {
		if (task?.name) return task.name;
		if (pullTitle) return pullTitle;
	} else {
		if (pullTitle) return pullTitle;
		if (task?.name) return task.name;
	}
	return "New task";
}
/**
* Transforms a single API Task to UnhydratedTask format.
* Used by the mutation to insert the real task into the cache after creation.
* Returns null if the task has no GitHub artifact (can't be displayed).
*/
function transformAPITaskToUnhydrated(apiTask) {
	const githubArtifact = getGitHubArtifactData(apiTask.artifacts);
	const agentId = apiTask.agent_collaborators?.[0]?.agent_id?.toString();
	return {
		id: apiTask.id,
		resource_type: githubArtifact?.type,
		resource_id: githubArtifact?.id,
		resource_global_id: githubArtifact?.global_id,
		session_count: apiTask.session_count,
		latest_session_state: getAPITaskState(apiTask),
		latest_session_updated_at: getAPITaskUpdatedAt(apiTask),
		agentId,
		name: apiTask.name,
		task_id: apiTask.id,
		archived_at: apiTask.archived_at,
		creator_id: apiTask.creator?.id,
		repo_id: apiTask.repository?.id
	};
}
/**
* Transforms an array of API Tasks to UnhydratedTask format.
* Filters out tasks that have no GitHub artifact.
*/
function transformAPITasksToUnhydrated(apiTasks) {
	return apiTasks.map(transformAPITaskToUnhydrated).filter((task) => task !== null);
}
/**
* Merges server-fetched tasks with existing optimistic tasks from the cache.
*
* This function handles the transition from optimistic tasks (created client-side before
* server confirmation) to server tasks:
* 1. Identifies server tasks that match optimistic tasks via event_identifiers
* 2. Preserves display metadata from optimistic tasks on their server counterparts
* 3. Filters out optimistic tasks that now have server equivalents
* 4. Returns a sorted array of all tasks (newest first)
*
* @param serverTasks - Tasks fetched from the server
* @param optimisticTasks - Optimistic tasks from the local cache
* @returns Merged and sorted array of tasks
*/
function mergeServerTasksWithOptimistic(serverTasks, optimisticTasks) {
	const serverTasksWithOptimistic = serverTasks.map((serverTask) => {
		const matchingOptimisticTask = optimisticTasks.find((optimisticTask) => serverTask.event_identifiers?.includes(optimisticTask.clientGeneratedId));
		return {
			...serverTask,
			isOptimistic: !!matchingOptimisticTask,
			...matchingOptimisticTask && {
				problemStatement: matchingOptimisticTask.problemStatement,
				nwo: matchingOptimisticTask.nwo,
				baseRef: matchingOptimisticTask.baseRef,
				clientGeneratedId: matchingOptimisticTask.clientGeneratedId,
				name: serverTask.name ?? matchingOptimisticTask.name
			}
		};
	});
	const remainingOptimisticTasks = optimisticTasks.filter((optimisticTask) => !serverTasksWithOptimistic.some((serverTask) => serverTask.event_identifiers?.includes(optimisticTask.clientGeneratedId)));
	return sortTasksByDate([...serverTasksWithOptimistic, ...remainingOptimisticTasks]);
}
/**
* Sorts tasks by latest_session_updated_at (newest first).
* This is a generic utility that works with any task type that has a timestamp.
*
* @param tasks - Array of tasks to sort
* @returns Sorted array (does not mutate the original)
*/
function sortTasksByDate(tasks) {
	return [...tasks].sort((a, b) => new Date(b.latest_session_updated_at).getTime() - new Date(a.latest_session_updated_at).getTime());
}
async function fetchRepoInfo(repoID) {
	try {
		const res = await verifiedFetchJSON(`/github-copilot/chat/repositories/${repoID}`, { method: "GET" });
		if (!res.ok) return null;
		const payload = await res.json();
		return {
			id: payload.id,
			name: payload.name,
			ownerLogin: payload.owner?.login ?? payload.ownerLogin
		};
	} catch {
		return null;
	}
}
/**
* Hook to fetch repository info for a set of repository IDs.
* Returns a map of repository ID to RepoInfo, loading state, and error state.
*/
function useRepoInfo(repoIds) {
	const $ = c(19);
	let t0;
	if ($[0] !== repoIds) {
		t0 = [...new Set(repoIds)].sort(_temp);
		$[0] = repoIds;
		$[1] = t0;
	} else t0 = $[1];
	const uniqueIds = t0;
	let t1;
	if ($[2] !== uniqueIds) {
		t1 = uniqueIds.map(_temp2);
		$[2] = uniqueIds;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== t1) {
		t2 = { queries: t1 };
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	const queries = useQueries(t2);
	let t3;
	if ($[6] !== queries) {
		t3 = queries.map(_temp3);
		$[6] = queries;
		$[7] = t3;
	} else t3 = $[7];
	const queryData = t3;
	let map;
	if ($[8] !== queryData || $[9] !== uniqueIds) {
		map = {};
		for (const [index, data] of queryData.entries()) {
			const repoId_0 = uniqueIds[index];
			if (data && repoId_0 !== void 0) map[repoId_0] = data;
		}
		$[8] = queryData;
		$[9] = uniqueIds;
		$[10] = map;
	} else map = $[10];
	const repoMap = map;
	let t4;
	if ($[11] !== queries) {
		t4 = queries.some(_temp4);
		$[11] = queries;
		$[12] = t4;
	} else t4 = $[12];
	const isLoading = t4;
	let t5;
	if ($[13] !== queries) {
		t5 = queries.some(_temp5);
		$[13] = queries;
		$[14] = t5;
	} else t5 = $[14];
	const isError = t5;
	let t6;
	if ($[15] !== isError || $[16] !== isLoading || $[17] !== repoMap) {
		t6 = {
			data: repoMap,
			isLoading,
			isError
		};
		$[15] = isError;
		$[16] = isLoading;
		$[17] = repoMap;
		$[18] = t6;
	} else t6 = $[18];
	return t6;
}
function _temp5(q_1) {
	return q_1.isError;
}
function _temp4(q_0) {
	return q_0.isLoading;
}
function _temp3(q) {
	return q.data;
}
function _temp2(repoId) {
	return {
		queryKey: ["repo-info", repoId],
		queryFn: () => fetchRepoInfo(repoId),
		staleTime: Infinity
	};
}
function _temp(a, b) {
	return a - b;
}
var CheckSpinner_module_default = {
	checksSpinnerWrapper: "CheckSpinner-module_c5Q6Pa_checksSpinnerWrapper",
	spinnerInner: "CheckSpinner-module_c5Q6Pa_spinnerInner",
	spinnerWrapper: "CheckSpinner-module_c5Q6Pa_spinnerWrapper",
	staticSpinner: "CheckSpinner-module_c5Q6Pa_staticSpinner"
};
function CheckSpinner({ animated = true }) {
	return /* @__PURE__ */ jsxs("div", {
		className: CheckSpinner_module_default.checksSpinnerWrapper,
		children: [animated ? /* @__PURE__ */ jsx(Spinner, { size: "small" }) : /* @__PURE__ */ jsx(CircleIcon, {
			size: "small",
			className: CheckSpinner_module_default.staticSpinner
		}), /* @__PURE__ */ jsx("div", {
			className: CheckSpinner_module_default.spinnerWrapper,
			children: /* @__PURE__ */ jsx("div", { className: CheckSpinner_module_default.spinnerInner })
		})]
	});
}
CheckSpinner.displayName = "CheckSpinner";
function getLeadingVisualIconAttributes(prState = "open", prInMergeQueue = false, state, isArchived, isCLI) {
	if (isCLI) return {
		icon: TerminalIcon,
		color: "var(--fgColor-muted)",
		"data-testid": "icon-terminal"
	};
	if (prState === "merged") return {
		icon: GitMergeIcon,
		color: "var(--fgColor-done)",
		"data-testid": "icon-git-merge"
	};
	if (prState === "closed") return {
		icon: GitPullRequestClosedIcon,
		color: "var(--fgColor-danger)",
		"data-testid": "icon-git-pull-request-closed"
	};
	if (prInMergeQueue) return {
		icon: GitMergeQueueIcon,
		color: "var(--fgColor-attention)",
		"data-testid": "icon-git-merge-queue"
	};
	if (isArchived) return {
		icon: ArchiveIcon,
		color: "var(--fgColor-muted)",
		"data-testid": "icon-archive"
	};
	if (state === "queued") return {
		icon: ClockIcon,
		color: "var(--fgColor-attention)",
		"data-testid": "icon-clock"
	};
	if (state === "waiting_for_user" || state === "completed") return {
		icon: CheckIcon,
		color: "var(--fgColor-success)",
		"data-testid": "icon-check"
	};
	if (state === "failed" || state === "timed_out") return {
		icon: StopIcon,
		color: "var(--fgColor-danger)",
		"data-testid": "icon-stop"
	};
	if (state === "in_progress") return {
		icon: () => createElement(CheckSpinner, { animated: true }),
		color: "attention.fg",
		"data-testid": "icon-spinning-circle"
	};
	if (state === "idle") return {
		icon: DotFillIcon,
		color: "var(--fgColor-muted)",
		"data-testid": "icon-dot"
	};
	if (state === "cancelled") return {
		icon: SkipIcon,
		color: "var(--fgColor-muted)",
		"data-testid": "icon-skip"
	};
	return {
		icon: DotFillIcon,
		color: "var(--fgColor-muted)",
		"data-testid": "icon-idle"
	};
}
/**
* Displays a leading visual icon for a task/session based on its current state.
*
* This component is memoized to prevent animated icons (like CheckSpinner) from resetting
* when other tasks in a list update.
*/
var TaskLeadingVisual = memo(function TaskLeadingVisual({ isOptimistic = false, prState, prInMergeQueue, sessionState, isArchived, isCLI, className }) {
	const iconAttributes = isOptimistic ? {
		icon: DotFillIcon,
		color: "var(--fgColor-attention)",
		"data-testid": "icon-dot"
	} : getLeadingVisualIconAttributes(prState, prInMergeQueue, sessionState, isArchived, isCLI);
	const Icon = iconAttributes.icon;
	return /* @__PURE__ */ jsx("div", {
		className,
		style: {
			color: iconAttributes.color,
			marginTop: sessionState === "in_progress" && !isOptimistic && !isCLI ? "3px" : void 0
		},
		"data-testid": iconAttributes["data-testid"],
		children: /* @__PURE__ */ jsx(Icon, {})
	});
});
TaskLeadingVisual.displayName = "TaskLeadingVisual";
export { transformAPITasksToUnhydrated as _, getLeadingVisualIconAttributes as a, pullInactiveLogsApiPath as c, repoTasksApiPath as d, sortTasksByDate as f, transformAPITaskToUnhydrated as g, tasksApiPathWithParams as h, getGitHubArtifactData as i, pullSessionsApiPath as l, taskInactiveLogsApiPath as m, TaskLeadingVisual as n, getTaskTitle as o, taskApiPath as p, getBranchArtifactData as r, mergeServerTasksWithOptimistic as s, CheckSpinner as t, repoTaskSessionsApiPath as u, useAgentSessionsAlive as v, useRepoInfo as y };
