performance.mark("js-parse-end:server-react-sandbox-future-layout-CRlr6E95-BiaRO73G.js");
import { o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { t as PageLayout } from "./server-PageLayout-CYFdz829-BD84oh7w.js";
import { t as NavList } from "./server-NavList-D8uWdChJ-BgWGw1cA.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Outlet, createLink, getRouteApi } from "@tanstack/react-router";
performance.mark("js-parse-end:react-sandbox-future-layout-CRlr6E95.js");
var layout_module_default = {
	content: "layout-module_zN28eG_content",
	section: "layout-module_zN28eG_section",
	"section-content": "layout-module_zN28eG_section-content"
};
function ReactSandboxFutureLayout() {
	const { tabCounts } = getRouteApi("/_nav/_react_sandbox_future").useLoaderData();
	return /* @__PURE__ */ jsxs(PageLayout, { children: [/* @__PURE__ */ jsx(PageLayout.Pane, {
		position: "start",
		children: /* @__PURE__ */ jsx(NavList, { children: /* @__PURE__ */ jsxs(NavList.Group, {
			title: "React navigation",
			children: [
				/* @__PURE__ */ jsx(NavItemLinkWrapper, {
					to: "/react_sandbox_future",
					children: "/react_sandbox_future"
				}),
				/* @__PURE__ */ jsx(NavItemLinkWrapper, {
					to: "/react_sandbox_future/$id",
					params: { id: "1" },
					count: tabCounts["1"],
					children: "/react_sandbox_future/1"
				}),
				/* @__PURE__ */ jsx(NavItemLinkWrapper, {
					to: "/react_sandbox_future/$id",
					params: { id: "2" },
					count: tabCounts["2"],
					children: "/react_sandbox_future/2"
				}),
				/* @__PURE__ */ jsx(NavItemLinkWrapper, {
					to: "/repos",
					children: "/repos"
				})
			]
		}) })
	}), /* @__PURE__ */ jsxs(PageLayout.Content, {
		as: "div",
		className: layout_module_default.content,
		children: [/* @__PURE__ */ jsx("h1", { children: "Data router sandbox" }), /* @__PURE__ */ jsx("div", {
			className: layout_module_default["section-content"],
			children: /* @__PURE__ */ jsxs("section", {
				className: layout_module_default.section,
				children: ["Child route data", /* @__PURE__ */ jsx(Outlet, {})]
			})
		})]
	})] });
}
ReactSandboxFutureLayout.displayName = "ReactSandboxFutureLayout";
var NavItemLinkComponent = ({ ref, count, children, ...props }) => {
	return /* @__PURE__ */ jsxs(NavList.Item, {
		ref,
		...props,
		children: [children, count !== void 0 && /* @__PURE__ */ jsx(NavList.TrailingVisual, { children: /* @__PURE__ */ jsx(CounterLabel, { children: count }) })]
	});
};
NavItemLinkComponent.displayName = "NavItemLinkComponent";
var NavItemLink = createLink(NavItemLinkComponent);
function NavItemLinkWrapper({ to, params, count, children }) {
	return /* @__PURE__ */ jsx(NavItemLink, {
		to,
		params,
		count,
		activeOptions: { exact: true },
		children
	});
}
NavItemLinkWrapper.displayName = "NavItemLinkWrapper";
var SplitComponent = ReactSandboxFutureLayout;
export { SplitComponent as component };
