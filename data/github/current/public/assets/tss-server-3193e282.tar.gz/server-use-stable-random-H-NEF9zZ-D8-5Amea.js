import { useId, useMemo } from "react";
import { c } from "react/compiler-runtime";
function useStableRandom(t0) {
	const $ = c(6);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { max, min } = t1;
	const id = useId();
	let t2;
	if ($[2] !== id || $[3] !== max || $[4] !== min) {
		t2 = randFromId({
			id,
			max,
			min
		});
		$[2] = id;
		$[3] = max;
		$[4] = min;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
/**
* Creates a seeded random number generator from a seed string.
* Returns a function (index, max) => number that produces deterministic
* values in [0, max) for each (seed, index) pair.
* Use with `useId()` as the seed for SSR-safe randomness.
*/
function createSeededRandom(seed) {
	return (index, max) => {
		if (max <= 0) return 0;
		const str = `${seed}:${index}`;
		let hash = 5381;
		for (const char of str) hash = (hash << 5) + hash + char.charCodeAt(0) | 0;
		return (hash >>> 0) % max;
	};
}
function randFromId({ max, min, id }) {
	let rand = hashId(id);
	if (min && rand < min) rand = min;
	if (max) rand = rand % max;
	return rand;
}
function hashId(id) {
	let hash = 0;
	for (const char of id) hash = (hash * 31 + char.charCodeAt(0)) % 100;
	return hash % 40 + 40;
}
export { useStableRandom as n, createSeededRandom as t };
