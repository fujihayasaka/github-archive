var OpenCopilotChatEvent = class extends Event {
	payload;
	constructor(payload) {
		super("open-copilot-chat", {
			bubbles: false,
			cancelable: true
		});
		this.payload = payload;
	}
};
var AddCopilotChatReferenceEvent = class extends Event {
	reference;
	openPanel;
	id;
	constructor(reference, openPanel = false, id) {
		super("add-copilot-chat-reference", {
			bubbles: false,
			cancelable: true
		});
		this.reference = reference;
		this.openPanel = openPanel;
		this.id = id;
	}
};
var SymbolChangedEvent = class extends Event {
	context;
	constructor(context) {
		super("symbol-changed", {
			bubbles: false,
			cancelable: true
		});
		this.context = context;
	}
};
function publishOpenCopilotChat(payload) {
	window.dispatchEvent(new OpenCopilotChatEvent(payload));
}
function publishAddCopilotChatReference(payload, openPanel = false, id) {
	window.dispatchEvent(new AddCopilotChatReferenceEvent(payload, openPanel, id));
}
function subscribeOpenCopilotChat(listener) {
	window.addEventListener("open-copilot-chat", listener);
	return () => {
		window.removeEventListener("open-copilot-chat", listener);
	};
}
function subscribeAddCopilotChatReference(listener) {
	window.addEventListener("add-copilot-chat-reference", listener);
	return () => {
		window.removeEventListener("add-copilot-chat-reference", listener);
	};
}
function subscribeSearchCopilot(listener) {
	window.addEventListener("search-copilot-chat", listener);
	return () => {
		window.removeEventListener("search-copilot-chat", listener);
	};
}
function subscribeSymbolChanged(listener) {
	window.addEventListener("symbol-changed", listener);
	return () => {
		window.removeEventListener("symbol-changed", listener);
	};
}
export { subscribeAddCopilotChatReference as a, subscribeSymbolChanged as c, publishOpenCopilotChat as i, SymbolChangedEvent as n, subscribeOpenCopilotChat as o, publishAddCopilotChatReference as r, subscribeSearchCopilot as s, OpenCopilotChatEvent as t };
