import { Hi as useProvidedRefOrCreate } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import React, { useState } from "react";
import { c } from "react-compiler-runtime";
import { iterateFocusableElements } from "@primer/behaviors/utils";
/**
* There are some situations where we want to give users the option to control state externally with their own state handlers
* or default to using internal state handlers. Because of the 'rules-of-hooks', we cannot conditionally make a call to `React.useState`
* only in the situations where the state is not provided as a prop.
* This hook aims to encapsulate that logic, so the consumer doesn't need to be concerned with violating `rules-of-hooks`.
* @param externalState The state to use - if undefined, will use the state from a call to React.useState
* @param setExternalState The setState to use - if undefined, will use the setState from a call to React.useState
* @param defaultState The defaultState to use, if using internal state.
*/
function useProvidedStateOrCreate(externalState, setExternalState, defaultState) {
	const $ = c(5);
	const [internalState, setInternalState] = useState(defaultState);
	const state = externalState !== null && externalState !== void 0 ? externalState : internalState;
	let t0;
	if ($[0] !== setExternalState) {
		t0 = (s) => {
			setInternalState(s);
			if (setExternalState) setExternalState(s);
		};
		$[0] = setExternalState;
		$[1] = t0;
	} else t0 = $[1];
	const setState = t0;
	let t1;
	if ($[2] !== setState || $[3] !== state) {
		t1 = [state, setState];
		$[2] = setState;
		$[3] = state;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
var useMnemonics = (open, providedRef) => {
	const $ = c(10);
	const containerRef = useProvidedRefOrCreate(providedRef);
	let t0;
	let t1;
	if ($[0] !== containerRef || $[1] !== open) {
		t0 = function addAriaKeyshortcuts() {
			if (!open || !containerRef.current) return;
			const container = containerRef.current;
			[...iterateFocusableElements(container)].map(_temp);
		};
		t1 = [open, containerRef];
		$[0] = containerRef;
		$[1] = open;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	React.useEffect(t0, t1);
	let t2;
	let t3;
	if ($[4] !== containerRef || $[5] !== open) {
		t2 = function handleKeyDown() {
			if (!open || !containerRef.current) return;
			const container_0 = containerRef.current;
			const handler = (event) => {
				var _elementToFocus;
				const activeElement = document.activeElement;
				if (activeElement.tagName === "INPUT" || activeElement.tagName === "TEXTAREA") return;
				if (event.ctrlKey || event.altKey || event.metaKey) return;
				if (!isAlphabetKey(event)) return;
				event.stopPropagation();
				const query = event.key.toLowerCase();
				let elementToFocus;
				const itemsMatchingKey = [...iterateFocusableElements(container_0)].filter((item_0) => {
					var _item_0$getAttribute;
					const keyshortcuts = (_item_0$getAttribute = item_0.getAttribute("aria-keyshortcuts")) === null || _item_0$getAttribute === void 0 ? void 0 : _item_0$getAttribute.split(" ").map(_temp2);
					return keyshortcuts && keyshortcuts.includes(query);
				});
				const currentActiveIndex = itemsMatchingKey.indexOf(activeElement);
				if (currentActiveIndex === itemsMatchingKey.length - 1) elementToFocus = itemsMatchingKey[0];
				else elementToFocus = itemsMatchingKey.find((item_1, index) => index > currentActiveIndex);
				(_elementToFocus = elementToFocus) === null || _elementToFocus === void 0 || _elementToFocus.focus();
			};
			container_0.addEventListener("keydown", handler);
			return () => container_0.removeEventListener("keydown", handler);
		};
		t3 = [open, containerRef];
		$[4] = containerRef;
		$[5] = open;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	React.useEffect(t2, t3);
	let t4;
	if ($[8] !== containerRef) {
		t4 = { containerRef };
		$[8] = containerRef;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
};
var isAlphabetKey = (event) => {
	return event.key.length === 1 && /[a-z\d]/i.test(event.key);
};
function _temp(item) {
	if (item.getAttribute("aria-keyshortcuts")) return;
	const firstLetter = item.textContent.toLowerCase()[0];
	if (firstLetter) item.setAttribute("aria-keyshortcuts", firstLetter);
}
function _temp2(shortcut) {
	return shortcut.toLowerCase();
}
export { useMnemonics as n, useProvidedStateOrCreate as r, isAlphabetKey as t };
