import { AsyncLocalStorage } from "async_hooks";
var env;
var getServerEnv = null;
function getEnv() {
	const targetEnv = (getServerEnv ? getServerEnv() : void 0) ?? env;
	if (!targetEnv) throw new Error("Client env was requested before it was loaded. This likely means you are attempting to use client env at the module level in SSR, which is not supported. Please move your client env usage into a function.");
	return targetEnv;
}
function getLocale() {
	return getEnv().locale ?? "en-US";
}
function isLoggedIn() {
	return !!getEnv().login;
}
function getCurrentUserLogin() {
	return getEnv().login;
}
function loadEnv() {
	if (typeof document !== "undefined") {
		const envTag = document.getElementById("client-env");
		if (envTag) try {
			env = JSON.parse(envTag.textContent || "");
		} catch (error) {
			console.error("Error parsing client-env", error);
		}
	}
}
loadEnv();
function setServerEnvGetter(getter) {
	getServerEnv = getter;
}
var envAsyncLocalStorage = new AsyncLocalStorage();
function setClientEnvAsyncLocalStorage(clientEnv, fn) {
	return envAsyncLocalStorage.run(clientEnv, fn);
}
function setCopilotApiOverrideUrl(copilotApiOverrideUrl) {
	const store = envAsyncLocalStorage.getStore();
	if (!store) return;
	if (store.copilotApiOverrideUrl === copilotApiOverrideUrl) return;
	store.copilotApiOverrideUrl = copilotApiOverrideUrl;
}
setServerEnvGetter(() => {
	return envAsyncLocalStorage.getStore();
});
export { setClientEnvAsyncLocalStorage as a, isLoggedIn as i, getEnv as n, setCopilotApiOverrideUrl as o, getLocale as r, getCurrentUserLogin as t };
