import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { a as isEnterprise } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { useCallback } from "react";
import { c } from "react/compiler-runtime";
function getUploadCredentials() {
	return isEnterprise() ? "include" : "same-origin";
}
var parseResponseHeaders = (rawHeaders) => {
	const headers = new Headers();
	for (const line of rawHeaders.trim().split(/\r?\n/)) {
		if (!line) continue;
		const separatorIndex = line.indexOf(":");
		if (separatorIndex === -1) continue;
		const name = line.slice(0, separatorIndex).trim();
		const value = line.slice(separatorIndex + 1).trim();
		if (name) headers.append(name, value);
	}
	return headers;
};
var postWithProgress = ({ url, formData, headers, onProgress }) => new Promise((resolve, reject) => {
	const xhr = new XMLHttpRequest();
	xhr.addEventListener("loadstart", () => onProgress(0));
	xhr.upload.addEventListener("progress", (event) => onProgress(event.loaded));
	xhr.addEventListener("loadend", () => {
		if (xhr.status === 0) {
			reject(/* @__PURE__ */ new TypeError("Network request failed"));
			return;
		}
		try {
			resolve(new Response(xhr.response || void 0, {
				status: xhr.status,
				statusText: xhr.statusText,
				headers: parseResponseHeaders(xhr.getAllResponseHeaders() ?? "")
			}));
		} catch (error) {
			reject(error);
		}
	});
	xhr.open("POST", url);
	if (isEnterprise()) xhr.withCredentials = true;
	xhr.responseType = "text";
	for (const [key, value] of Object.entries(headers)) if (value !== void 0) xhr.setRequestHeader(key, value);
	xhr.send(formData);
});
/**
* File types that are acceptable in any context.
* Source: `Storage::Uplodable::CONTENT_TYPES`
*/
var REPOLESS_ACCEPTED_FILE_TYPES = [
	".svg",
	".gif",
	".jpg",
	".jpeg",
	".png",
	".mov",
	".mp4",
	".webm"
];
/**
* Baseline file types that are always acceptable when there is a target repo to upload to.
* Source: `ApplicationRecord::Domain::AssetObjects::RepositoryFile::baseline_content_types`
*/
var REPO_BASELINE_FILE_TYPES = [
	".pdf",
	".docx",
	".odt",
	".fodt",
	".pptx",
	".odp",
	".fodp",
	".xlsx",
	".ods",
	".fods",
	".xls",
	".csv",
	".odg",
	".fodg",
	".odf",
	".zip",
	".gz",
	".tgz",
	".patch",
	".txt",
	".log",
	".md",
	".json",
	".jsonc",
	".cpuprofile",
	".dmp"
];
/**
* Expanded file types that are only acceptable when the feature flag is enabled.
* Source: `ApplicationRecord::Domain::AssetObjects::RepositoryFile::expanded_content_types`
*/
var REPO_EXPANDED_FILE_TYPES = [
	".debug",
	".rtf",
	".msg",
	".doc",
	".eml",
	".xlsm",
	".tsv",
	".py",
	".yaml",
	".yml",
	".css",
	".xml",
	".html",
	".htm",
	".js",
	".sql",
	".java",
	".c",
	".cpp",
	".ipynb",
	".sh",
	".php",
	".ts",
	".tsx",
	".cs",
	".pdb",
	".drawio",
	".copilotmd",
	".bmp",
	".tif",
	".tiff",
	".mp3",
	".wav"
];
var REPO_WEBP_SUPPORT = [".webp"];
async function getPolicy(file, repositoryId, projectId) {
	const formData = new FormData();
	const { name, size, type } = file;
	if (repositoryId) formData.append("repository_id", repositoryId);
	if (projectId) {
		formData.append("upload_container_type", "project");
		formData.append("upload_container_id", projectId);
	}
	formData.append("name", name);
	formData.append("size", size.toString());
	formData.append("content_type", type);
	return await verifiedFetch("/upload/policies/assets", {
		body: formData,
		method: "POST"
	});
}
async function uploadFileToStorage(policy, file, onProgress) {
	const { upload_authenticity_token, upload_url, header, form, same_origin } = policy;
	const uploadFormData = new FormData();
	if (same_origin) uploadFormData.append("authenticity_token", upload_authenticity_token);
	for (const key in form) uploadFormData.append(key, form[key]);
	uploadFormData.append("file", file);
	return onProgress ? await postWithProgress({
		url: upload_url,
		formData: uploadFormData,
		headers: header,
		onProgress
	}) : await fetch(upload_url, {
		headers: { ...header },
		method: "post",
		body: uploadFormData,
		credentials: getUploadCredentials()
	});
}
async function markUploadComplete(policy, uploadResponse) {
	const assetUploadUrl = typeof policy.asset_upload_url === "string" ? policy.asset_upload_url : null;
	const token = typeof policy.asset_upload_authenticity_token == "string" ? policy.asset_upload_authenticity_token : null;
	if (assetUploadUrl && token) {
		const putForm = new FormData();
		putForm.append("authenticity_token", token);
		return await fetch(assetUploadUrl, {
			method: "PUT",
			body: putForm,
			credentials: getUploadCredentials(),
			headers: {
				Accept: "application/json",
				...getBaseFetchHeaders()
			}
		});
	}
	return uploadResponse;
}
async function uploadFile(file, repositoryId, projectId, onProgress) {
	const policyResponse = await getPolicy(file, repositoryId, projectId);
	if (!policyResponse.ok) throw new Error("Failed to obtain asset policy");
	const policy = await policyResponse.json();
	const uploadResponse = await uploadFileToStorage(policy, file, onProgress);
	if (!uploadResponse.ok) throw new Error("Failed to upload file to storage");
	const putResponse = await markUploadComplete(policy, uploadResponse);
	if (!putResponse.ok) throw new Error("Failed to register file upload completion");
	const { href: url } = await putResponse.json();
	if (typeof url !== "string") throw new Error("Received invalid file URL");
	onProgress?.(file.size);
	return {
		url,
		file
	};
}
function acceptedFileTypes(hasRepository) {
	/**
	* File types that are acceptable when there is a target repo to upload to.
	* Source: `ApplicationRecord::Domain::AssetObjects::RepositoryFile`
	*/
	const repoAcceptedFileTypes = [
		...REPOLESS_ACCEPTED_FILE_TYPES,
		...isFeatureEnabled("webp_support") ? REPO_WEBP_SUPPORT : [],
		...REPO_BASELINE_FILE_TYPES,
		...isFeatureEnabled("issues_expanded_file_types") ? REPO_EXPANDED_FILE_TYPES : []
	];
	const repoLessAcceptedFileTypes = [...REPOLESS_ACCEPTED_FILE_TYPES, ...isFeatureEnabled("webp_support") ? REPO_WEBP_SUPPORT : []];
	return hasRepository ? repoAcceptedFileTypes : repoLessAcceptedFileTypes;
}
function useUploadFile(repositoryId, projectId) {
	const $ = c(3);
	let t0;
	if ($[0] !== projectId || $[1] !== repositoryId) {
		t0 = async (file, onProgress) => uploadFile(file, repositoryId, projectId, onProgress);
		$[0] = projectId;
		$[1] = repositoryId;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
export { uploadFile as n, useUploadFile as r, acceptedFileTypes as t };
