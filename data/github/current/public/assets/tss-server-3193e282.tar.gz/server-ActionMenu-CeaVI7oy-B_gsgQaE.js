import { a as useFeatureFlag, o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Hi as useProvidedRefOrCreate, L as ChevronRightIcon, Ri as isSlot, ft as Divider, hi as TriangleDownIcon, pi as Tooltip$1, r as ActionListContainerContext } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { n as DialogContext } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { n as useMnemonics, r as useProvidedStateOrCreate } from "./server-useMnemonics-D3ntHtHT-ctYxUroX.js";
import React, { useCallback, useContext, useEffect, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { iterateFocusableElements } from "@primer/behaviors/utils";
var styles = { "ActionMenuContainer": "prc-ActionMenu-ActionMenuContainer-Om1Qz" };
var useMenuInitialFocus = (open, containerRef, anchorRef) => {
	/**
	* We need to pick the first element to focus based on how the menu was opened,
	* however, we need to wait for the menu to be open to set focus.
	* This is why we use set openingKey in state and have 2 effects
	*/
	const [openingGesture, setOpeningGesture] = React.useState(void 0);
	React.useEffect(function inferOpeningKey() {
		const anchorElement = anchorRef === null || anchorRef === void 0 ? void 0 : anchorRef.current;
		const clickHandler = (event) => {
			if (event.detail !== 0) setOpeningGesture("mouse-click");
		};
		const keydownHandler = (event) => {
			if ([
				"Space",
				"Enter",
				"ArrowDown",
				"ArrowUp"
			].includes(event.code)) setOpeningGesture(event.code);
		};
		anchorElement === null || anchorElement === void 0 || anchorElement.addEventListener("click", clickHandler);
		anchorElement === null || anchorElement === void 0 || anchorElement.addEventListener("keydown", keydownHandler);
		return () => {
			anchorElement === null || anchorElement === void 0 || anchorElement.removeEventListener("click", clickHandler);
			anchorElement === null || anchorElement === void 0 || anchorElement.removeEventListener("keydown", keydownHandler);
		};
	}, [anchorRef]);
	/**
	* Pick the first element to focus based on the key used to open the Menu
	* Click: anchor
	* ArrowDown | Space | Enter: first element
	* ArrowUp: last element
	*/
	React.useEffect(function moveFocusOnOpen() {
		if (!open || !(containerRef !== null && containerRef !== void 0 && containerRef.current)) return;
		const iterable = iterateFocusableElements(containerRef.current);
		if (openingGesture === "mouse-click") if (anchorRef !== null && anchorRef !== void 0 && anchorRef.current) anchorRef.current.focus();
		else throw new Error("For focus management, please attach anchorRef");
		else if (openingGesture && [
			"ArrowDown",
			"Space",
			"Enter"
		].includes(openingGesture)) {
			const firstElement = iterable.next().value;
			/** We push imperative focus to the next tick to prevent React's batching */
			setTimeout(() => firstElement === null || firstElement === void 0 ? void 0 : firstElement.focus());
		} else if ("ArrowUp" === openingGesture) {
			const elements = [...iterable];
			const lastElement = elements[elements.length - 1];
			setTimeout(() => lastElement.focus());
		} else {
			/** if the menu was not opened with the anchor, we default to the first element
			*  for example: with keyboard shortcut (see stories/fixtures)
			*/
			const firstElement = iterable.next().value;
			setTimeout(() => firstElement === null || firstElement === void 0 ? void 0 : firstElement.focus());
		}
	}, [
		open,
		openingGesture,
		anchorRef
	]);
};
/**
* Keyboard navigation is a mix of 4 hooks
* 1. useMenuInitialFocus
* 2. useTypeaheadFocus
* 3. useCloseMenuOnTab
* 4. useMoveFocusToMenuItem
*/
var useMenuKeyboardNavigation = (open, onClose, containerRef, anchorRef, t0) => {
	const isSubmenu = t0 === void 0 ? false : t0;
	useMenuInitialFocus(open, containerRef, anchorRef);
	useMnemonics(open, containerRef);
	useCloseMenuOnTab(open, onClose, containerRef, anchorRef);
	useMoveFocusToMenuItem(open, containerRef, anchorRef);
	useCloseSubmenuOnArrow(open, isSubmenu, onClose, containerRef);
};
/**
* When Tab or Shift+Tab is pressed, the menu should close
* and the focus should naturally move to the next item
*/
var useCloseMenuOnTab = (open, onClose, containerRef, anchorRef) => {
	const $ = c(6);
	let t0;
	let t1;
	if ($[0] !== anchorRef || $[1] !== containerRef || $[2] !== onClose || $[3] !== open) {
		t0 = () => {
			const container = containerRef === null || containerRef === void 0 ? void 0 : containerRef.current;
			const anchor = anchorRef === null || anchorRef === void 0 ? void 0 : anchorRef.current;
			const handler = (event) => {
				if (open && event.key === "Tab") onClose === null || onClose === void 0 || onClose("tab");
			};
			container === null || container === void 0 || container.addEventListener("keydown", handler);
			anchor === null || anchor === void 0 || anchor.addEventListener("keydown", handler);
			return () => {
				container === null || container === void 0 || container.removeEventListener("keydown", handler);
				anchor === null || anchor === void 0 || anchor.removeEventListener("keydown", handler);
			};
		};
		t1 = [
			open,
			onClose,
			containerRef,
			anchorRef
		];
		$[0] = anchorRef;
		$[1] = containerRef;
		$[2] = onClose;
		$[3] = open;
		$[4] = t0;
		$[5] = t1;
	} else {
		t0 = $[4];
		t1 = $[5];
	}
	React.useEffect(t0, t1);
};
/**
* Close submenu when left arrow key is pressed
*/
var useCloseSubmenuOnArrow = (open, isSubmenu, onClose, containerRef) => {
	const $ = c(6);
	let t0;
	let t1;
	if ($[0] !== containerRef || $[1] !== isSubmenu || $[2] !== onClose || $[3] !== open) {
		t0 = () => {
			const container = containerRef === null || containerRef === void 0 ? void 0 : containerRef.current;
			const handler = (event) => {
				if (open && isSubmenu && event.key === "ArrowLeft") onClose === null || onClose === void 0 || onClose("arrow-left");
			};
			container === null || container === void 0 || container.addEventListener("keydown", handler);
			return () => {
				container === null || container === void 0 || container.removeEventListener("keydown", handler);
			};
		};
		t1 = [
			open,
			onClose,
			containerRef,
			isSubmenu
		];
		$[0] = containerRef;
		$[1] = isSubmenu;
		$[2] = onClose;
		$[3] = open;
		$[4] = t0;
		$[5] = t1;
	} else {
		t0 = $[4];
		t1 = $[5];
	}
	React.useEffect(t0, t1);
};
/**
* When Arrow Keys are pressed and the focus is on the anchor,
* focus should move to a menu item
*/
var useMoveFocusToMenuItem = (open, containerRef, anchorRef) => {
	const $ = c(5);
	let t0;
	let t1;
	if ($[0] !== anchorRef || $[1] !== containerRef || $[2] !== open) {
		t0 = () => {
			const container = containerRef === null || containerRef === void 0 ? void 0 : containerRef.current;
			const anchor = anchorRef === null || anchorRef === void 0 ? void 0 : anchorRef.current;
			const handler = (event) => {
				if (!open || !container) return;
				const iterable = iterateFocusableElements(container);
				if (event.key === "ArrowDown") {
					const firstElement = iterable.next().value;
					setTimeout(() => firstElement === null || firstElement === void 0 ? void 0 : firstElement.focus());
				} else if (event.key === "ArrowUp") {
					const elements = [...iterable];
					const lastElement = elements[elements.length - 1];
					setTimeout(() => lastElement.focus());
				}
			};
			anchor === null || anchor === void 0 || anchor.addEventListener("keydown", handler);
			return () => anchor === null || anchor === void 0 ? void 0 : anchor.addEventListener("keydown", handler);
		};
		t1 = [
			open,
			containerRef,
			anchorRef
		];
		$[0] = anchorRef;
		$[1] = containerRef;
		$[2] = open;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	React.useEffect(t0, t1);
};
var MenuContext = /* @__PURE__ */ React.createContext({
	renderAnchor: null,
	open: false
});
var mergeAnchorHandlers = (anchorProps, buttonProps) => {
	const mergedAnchorProps = { ...anchorProps };
	if (typeof buttonProps.onClick === "function") {
		const anchorOnClick = anchorProps.onClick;
		const mergedOnClick = (event) => {
			var _buttonProps$onClick;
			(_buttonProps$onClick = buttonProps.onClick) === null || _buttonProps$onClick === void 0 || _buttonProps$onClick.call(buttonProps, event);
			anchorOnClick === null || anchorOnClick === void 0 || anchorOnClick(event);
		};
		mergedAnchorProps.onClick = mergedOnClick;
	}
	if (typeof buttonProps.onKeyDown === "function") {
		const anchorOnKeyDown = anchorProps.onKeyDown;
		const mergedOnAnchorKeyDown = (event) => {
			var _buttonProps$onKeyDow;
			(_buttonProps$onKeyDow = buttonProps.onKeyDown) === null || _buttonProps$onKeyDow === void 0 || _buttonProps$onKeyDow.call(buttonProps, event);
			anchorOnKeyDown === null || anchorOnKeyDown === void 0 || anchorOnKeyDown(event);
		};
		mergedAnchorProps.onKeyDown = mergedOnAnchorKeyDown;
	}
	if (buttonProps.className) mergedAnchorProps.className = clsx(anchorProps.className, buttonProps.className);
	return mergedAnchorProps;
};
var Menu = ({ anchorRef: externalAnchorRef, open, onOpenChange, children }) => {
	const parentMenuContext = useContext(MenuContext);
	const [combinedOpenState, setCombinedOpenState] = useProvidedStateOrCreate(open, onOpenChange, false);
	const onOpen = React.useCallback(() => setCombinedOpenState(true), [setCombinedOpenState]);
	const isNarrow = useResponsiveValue({ narrow: true }, false);
	const onClose = React.useCallback((gesture) => {
		var _parentMenuContext$on;
		if (isNarrow && open && gesture === "tab") return;
		setCombinedOpenState(false);
		switch (gesture) {
			case "tab":
			case "item-select": (_parentMenuContext$on = parentMenuContext.onClose) === null || _parentMenuContext$on === void 0 || _parentMenuContext$on.call(parentMenuContext, gesture);
		}
	}, [
		setCombinedOpenState,
		parentMenuContext,
		open,
		isNarrow
	]);
	const menuButtonChild = React.Children.toArray(children).find((child) => /* @__PURE__ */ React.isValidElement(child) && (child.type === MenuButton || child.type === Anchor || isSlot(child, Anchor) || isSlot(child, MenuButton)));
	const menuButtonChildId = /* @__PURE__ */ React.isValidElement(menuButtonChild) ? menuButtonChild.props.id : void 0;
	const anchorRef = useProvidedRefOrCreate(externalAnchorRef);
	const anchorId = useId$1(menuButtonChildId);
	let renderAnchor = null;
	const contents = React.Children.map(children, (child) => {
		if (child.type === Tooltip$1 || isSlot(child, Tooltip$1)) {
			const anchorChildren = child.props.children;
			if (anchorChildren.type === MenuButton || isSlot(anchorChildren, MenuButton)) renderAnchor = (anchorProps) => {
				const triggerButton = /* @__PURE__ */ React.cloneElement(anchorChildren, mergeAnchorHandlers({ ...anchorProps }, anchorChildren.props));
				return /* @__PURE__ */ React.cloneElement(child, {
					children: triggerButton,
					ref: anchorRef
				});
			};
			return null;
		} else if (child.type === Anchor || isSlot(child, Anchor)) {
			const anchorChildren = child.props.children;
			if (anchorChildren !== void 0 ? anchorChildren.type === Tooltip$1 || isSlot(anchorChildren, Tooltip$1) : false) {
				if (anchorChildren.props.children !== null) renderAnchor = (anchorProps) => {
					const tooltipTrigger = anchorChildren.props.children;
					const tooltipTriggerEl = /* @__PURE__ */ React.cloneElement(tooltipTrigger, mergeAnchorHandlers({ ...anchorProps }, tooltipTrigger.props));
					const tooltip = /* @__PURE__ */ React.cloneElement(anchorChildren, { children: tooltipTriggerEl });
					return /* @__PURE__ */ React.cloneElement(child, {
						children: tooltip,
						ref: anchorRef
					});
				};
			} else renderAnchor = (anchorProps) => /* @__PURE__ */ React.cloneElement(child, {
				...anchorProps,
				className: clsx(anchorProps.className, child.props.className)
			});
			return null;
		} else if (child.type === MenuButton || isSlot(child, MenuButton)) {
			renderAnchor = (anchorProps) => /* @__PURE__ */ React.cloneElement(child, mergeAnchorHandlers(anchorProps, child.props));
			return null;
		} else return child;
	});
	return /* @__PURE__ */ jsx(MenuContext.Provider, {
		value: {
			anchorRef,
			renderAnchor,
			anchorId,
			open: combinedOpenState,
			onOpen,
			onClose,
			isSubmenu: parentMenuContext.isSubmenu !== void 0
		},
		children: contents
	});
};
Menu.displayName = "Menu";
var Anchor = /* @__PURE__ */ React.forwardRef(({ children: child, ...anchorProps }, anchorRef) => {
	const { onOpen, isSubmenu } = React.useContext(MenuContext);
	const openSubmenuOnRightArrow = useCallback((event) => {
		if (isSubmenu && event.key === "ArrowRight" && !event.defaultPrevented) onOpen === null || onOpen === void 0 || onOpen("anchor-key-press");
	}, [isSubmenu, onOpen]);
	const onButtonClick = (event) => {
		var _child$props$onClick, _child$props, _anchorProps$onClick;
		(_child$props$onClick = (_child$props = child.props).onClick) === null || _child$props$onClick === void 0 || _child$props$onClick.call(_child$props, event);
		(_anchorProps$onClick = anchorProps.onClick) === null || _anchorProps$onClick === void 0 || _anchorProps$onClick.call(anchorProps, event);
	};
	const onButtonKeyDown = (event) => {
		var _child$props$onKeyDow, _child$props2, _anchorProps$onKeyDow;
		(_child$props$onKeyDow = (_child$props2 = child.props).onKeyDown) === null || _child$props$onKeyDow === void 0 || _child$props$onKeyDow.call(_child$props2, event);
		openSubmenuOnRightArrow(event);
		(_anchorProps$onKeyDow = anchorProps.onKeyDown) === null || _anchorProps$onKeyDow === void 0 || _anchorProps$onKeyDow.call(anchorProps, event);
	};
	const parentActionListContext = useContext(ActionListContainerContext);
	const thisActionListContext = useMemo(() => isSubmenu ? {
		...parentActionListContext,
		defaultTrailingVisual: /* @__PURE__ */ jsx(ChevronRightIcon, {}),
		afterSelect: () => onOpen === null || onOpen === void 0 ? void 0 : onOpen("anchor-click")
	} : parentActionListContext, [
		isSubmenu,
		onOpen,
		parentActionListContext
	]);
	return /* @__PURE__ */ jsx(ActionListContainerContext.Provider, {
		value: thisActionListContext,
		children: /* @__PURE__ */ React.cloneElement(child, {
			...anchorProps,
			ref: anchorRef,
			className: clsx(anchorProps.className, child.props.className),
			onClick: onButtonClick,
			onKeyDown: onButtonKeyDown
		})
	});
});
/** this component is syntactical sugar 🍭 */
var MenuButton = /* @__PURE__ */ React.forwardRef(({ ...props }, anchorRef) => {
	return /* @__PURE__ */ jsx(Anchor, {
		ref: anchorRef,
		children: /* @__PURE__ */ jsx(ButtonComponent, {
			type: "button",
			trailingAction: TriangleDownIcon,
			...props
		})
	});
});
var defaultVariant = {
	regular: "anchored",
	narrow: "anchored"
};
var Overlay = ({ children, align = "start", side, onPositionChange, displayInViewport, "aria-labelledby": ariaLabelledby, variant = defaultVariant, ...overlayProps }) => {
	const { anchorRef, renderAnchor, anchorId, open, onOpen, onClose, isSubmenu = false } = React.useContext(MenuContext);
	const containerRef = React.useRef(null);
	const isNarrowFullscreen = !!useResponsiveValue({ narrow: true }, false) && variant.narrow === "fullscreen";
	const handleClose = React.useCallback((gesture) => {
		if (isNarrowFullscreen && gesture === "tab") return;
		onClose === null || onClose === void 0 || onClose(gesture);
	}, [isNarrowFullscreen, onClose]);
	useMenuKeyboardNavigation(open, handleClose, containerRef, anchorRef, isSubmenu);
	const responsiveVariant = useResponsiveValue(variant, {
		regular: "anchored",
		narrow: "anchored"
	});
	const [anchorAriaLabelledby, setAnchorAriaLabelledby] = useState(null);
	useEffect(() => {
		if (anchorRef !== null && anchorRef !== void 0 && anchorRef.current) {
			const ariaLabelledby = anchorRef.current.getAttribute("aria-labelledby");
			if (ariaLabelledby) setAnchorAriaLabelledby(ariaLabelledby);
		}
	}, [anchorRef]);
	const featureFlagDisplayInViewportInsideDialog = useFeatureFlag("primer_react_action_menu_display_in_viewport_inside_dialog");
	const isInsideDialog = useContext(DialogContext) !== void 0;
	return /* @__PURE__ */ jsx(AnchoredOverlay, {
		anchorRef,
		renderAnchor,
		anchorId,
		open,
		onOpen,
		onClose: handleClose,
		align,
		side: side !== null && side !== void 0 ? side : isSubmenu ? "outside-right" : "outside-bottom",
		overlayProps,
		focusZoneSettings: isNarrowFullscreen ? { disabled: true } : { focusOutBehavior: "wrap" },
		onPositionChange,
		variant,
		displayInViewport: displayInViewport !== void 0 ? displayInViewport : featureFlagDisplayInViewportInsideDialog && isInsideDialog,
		children: /* @__PURE__ */ jsx("div", {
			ref: containerRef,
			className: styles.ActionMenuContainer,
			"data-variant": responsiveVariant,
			...overlayProps.overflow ? { [`data-overflow-${overlayProps.overflow}`]: "" } : {},
			...overlayProps.maxHeight ? { [`data-max-height-${overlayProps.maxHeight}`]: "" } : {},
			children: /* @__PURE__ */ jsx(ActionListContainerContext.Provider, {
				value: {
					container: "ActionMenu",
					listRole: "menu",
					listLabelledBy: ariaLabelledby || anchorAriaLabelledby || anchorId,
					selectionAttribute: "aria-checked",
					afterSelect: () => onClose === null || onClose === void 0 ? void 0 : onClose("item-select"),
					enableFocusZone: isNarrowFullscreen
				},
				children
			})
		})
	});
};
Overlay.displayName = "Overlay";
Menu.displayName = "ActionMenu";
Menu.__SLOT__ = Symbol("ActionMenu");
MenuButton.__SLOT__ = Symbol("ActionMenu.Button");
Anchor.__SLOT__ = Symbol("ActionMenu.Anchor");
Overlay.__SLOT__ = Symbol("ActionMenu.Overlay");
var ActionMenu = Object.assign(Menu, {
	Button: MenuButton,
	Anchor,
	Overlay,
	Divider
});
export { ActionMenu as t };
