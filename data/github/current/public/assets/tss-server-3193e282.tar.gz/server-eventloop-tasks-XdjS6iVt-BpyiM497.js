async function wait(ms, signal) {
	let id;
	const done = new Promise((resolve) => {
		id = self.setTimeout(resolve, ms);
	});
	if (!signal) return done;
	try {
		await Promise.race([done, whenAborted(signal)]);
	} catch (e) {
		self.clearTimeout(id);
		throw e;
	}
}
function whenAborted(signal) {
	return new Promise((resolve, reject) => {
		const error = /* @__PURE__ */ new Error("aborted");
		error.name = "AbortError";
		if (signal.aborted) reject(error);
		else signal.addEventListener("abort", () => reject(error));
	});
}
function taskQueue(fn) {
	const queue = [];
	return function(value) {
		queue.push(value);
		if (queue.length === 1) queueMicrotask(() => {
			const values = queue.slice(0);
			queue.length = 0;
			fn(values);
		});
	};
}
export { wait as n, taskQueue as t };
