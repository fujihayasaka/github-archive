import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { $t as HeadingIcon, Cn as ListOrderedIcon, Ct as FileDiffIcon, Gi as useSlots, H as CodeIcon, Sn as LinkIcon, Yn as PaperclipIcon, a as AlertFillIcon, ai as TasklistIcon, an as IconButton, bn as Link, fi as Tooltip, gn as ItalicIcon, jn as MentionIcon, lt as DiffIgnoredIcon, pr as ReplyIcon, rt as CrossReferenceIcon, ur as QuoteIcon, wn as ListUnorderedIcon, y as BoldIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { i as reactFetchJSON, o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { a as SelectPanel } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { i as Textarea } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { t as useIsMounted } from "./server-use-is-mounted-BP8yEjoH-CZJ4mOOX.js";
import { n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as isMacOS } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as noop$1 } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { t as ActionBar } from "./server-ActionBar-DNCrmOcX-Dfop-h7_.js";
import { a as useEmojiSuggestions, i as useAutocompleteTriggersAndSuggestions, o as useMentionSuggestions } from "./server-use-mention-suggestions-CJBNKUGO-wdkkDgZ6.js";
import { J as useReferenceSuggestions, a as Header, c as Toolbar$1, i as FileUploadButton$1, l as ToolbarContext, n as ErrorBanner, o as HybridEditorTelemetryProvider, q as useHybridEditorTelemetry, r as ErrorFallback, s as HybridMarkdownEditor_module_default, u as ViewSwitch, v as getImageSizeFromFile$1 } from "./server-use-reference-suggestions-Ixpw3mar-CrD64Jy4.js";
import { i as useUnifiedFileSelect, r as useSafeAsyncCallback } from "./server-use-unified-file-select-CEU56QFm-CLNiWm9V.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { s as useIgnoreKeyboardActionsWhileComposing } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { n as useSyntheticChange, t as InlineAutocomplete } from "./server-InlineAutocomplete-ByKImo4X-BNUEsRr4.js";
import { r as useUploadFile, t as acceptedFileTypes } from "./server-file-upload-hzKYHhKF-aHtqJYP7.js";
import { t as reportError } from "./server-failbot-DcTQsQvG-1jpM1RlB.js";
import { t as useLocalStorage } from "./server-use-local-storage-CXtv8Nou-C7yzA4lh.js";
import { t as useEmojisQuery } from "./server-use-emojis-query-C5iJFZbs-B6tC0vOQ.js";
import React, { Children, Fragment, Suspense, cloneElement, createContext, isValidElement, lazy, memo, use, useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { flushSync } from "react-dom";
import { c } from "react/compiler-runtime";
import { subscribe } from "@github/paste-markdown";
var MarkdownEditorContext = createContext({
	disabled: false,
	required: false,
	formattingToolsRef: { current: null },
	uploadButtonProps: null,
	fileDraggedOver: false,
	previewMode: false
});
MarkdownEditorContext.displayName = "MarkdownEditorContext";
var Actions = ({ children }) => /* @__PURE__ */ jsx(Fragment$1, { children });
Actions.displayName = "Actions";
Actions.displayName = "MarkdownEditor.Actions";
var ActionButton = ({ ref, ...props }) => {
	const { disabled } = use(MarkdownEditorContext);
	return /* @__PURE__ */ jsx(ButtonComponent, {
		disabled,
		...props,
		ref
	});
};
ActionButton.displayName = "ActionButton";
ActionButton.displayName = "MarkdownEditor.ActionButton";
var Footer_module_default = {
	childrenStyling: "Footer-module_q_A6Qa_childrenStyling",
	condensed: "Footer-module_q_A6Qa_condensed",
	footer: "Footer-module_q_A6Qa_footer",
	footerButton: "Footer-module_q_A6Qa_footerButton",
	footerButtonWrapper: "Footer-module_q_A6Qa_footerButtonWrapper",
	footerWrapper: "Footer-module_q_A6Qa_footerWrapper",
	spacious: "Footer-module_q_A6Qa_spacious"
};
var CoreFooter = (t0) => {
	const $ = c(4);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { footerButtons: FooterButton };
		$[0] = t1;
	} else t1 = $[0];
	const [slots, childrenWithoutSlots] = useSlots(children, t1);
	let t2;
	if ($[1] !== childrenWithoutSlots || $[2] !== slots.footerButtons) {
		t2 = jsxs("div", {
			className: Footer_module_default.footer,
			"data-testid": "markdown-editor-footer",
			children: [jsxs("div", {
				className: Footer_module_default.footerWrapper,
				children: [jsx(DefaultFooterButtons, {}), slots.footerButtons && jsx("div", {
					className: Footer_module_default.footerButtonWrapper,
					children: slots.footerButtons
				})]
			}), jsx("div", {
				className: Footer_module_default.childrenStyling,
				children: childrenWithoutSlots
			})]
		});
		$[1] = childrenWithoutSlots;
		$[2] = slots.footerButtons;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
CoreFooter.displayName = "CoreFooter";
var Footer = ({ children }) => /* @__PURE__ */ jsx(CoreFooter, { children });
Footer.displayName = "Footer";
Footer.displayName = "MarkdownEditor.Footer";
var FooterButton = ({ ref, ...props }) => {
	const { disabled } = use(MarkdownEditorContext);
	return /* @__PURE__ */ jsx(ButtonComponent, {
		size: "small",
		disabled,
		...props,
		ref
	});
};
FooterButton.displayName = "FooterButton";
FooterButton.displayName = "MarkdownEditor.FooterButton";
var DefaultFooterButtons = memo(() => {
	const { uploadButtonProps, fileDraggedOver } = use(MarkdownEditorContext);
	return uploadButtonProps ? /* @__PURE__ */ jsx(FileUploadButton, {
		fileDraggedOver,
		...uploadButtonProps
	}) : null;
});
DefaultFooterButtons.displayName = "MarkdownEditor.DefaultFooterButtons";
var FileUploadButton = memo(({ fileDraggedOver, ...props }) => {
	const { disabled, fileUploadProgress } = use(MarkdownEditorContext);
	const currentFileUpload = fileUploadProgress?.[0];
	const totalFileUploads = fileUploadProgress?.[1];
	const isUploading = Boolean(totalFileUploads);
	const fileUploadProgressString = totalFileUploads === 1 ? "Uploading your file..." : `Uploading your files... (${currentFileUpload}/${totalFileUploads})`;
	return /* @__PURE__ */ jsxs(ButtonComponent, {
		variant: "invisible",
		loadingAnnouncement: isUploading ? fileUploadProgressString : void 0,
		leadingVisual: PaperclipIcon,
		loading: isUploading,
		size: "small",
		className: Footer_module_default.footerButton,
		onMouseDown: (e) => {
			e.preventDefault();
		},
		disabled,
		...props,
		children: [/* @__PURE__ */ jsx("span", {
			className: Footer_module_default.condensed,
			children: "Add Files"
		}), /* @__PURE__ */ jsx("span", {
			className: Footer_module_default.spacious,
			children: fileDraggedOver ? "Drop to add files" : "Paste, drop, or click to add files"
		})]
	});
});
FileUploadButton.displayName = "MarkdownEditor.FileUploadButton";
var InputLabel_module_default = {
	disabled: "InputLabel-module_LNJ-IW_disabled",
	InputLabel: "InputLabel-module_LNJ-IW_InputLabel",
	requiredContent: "InputLabel-module_LNJ-IW_requiredContent",
	requiredWrapper: "InputLabel-module_LNJ-IW_requiredWrapper"
};
/**
* Primer-styled input label for forms; can also be rendered as a fieldset `legend`.
* Copied from `primer/react/src/internal/components/InputLabel.tsx`.
*/
var InputLabel = ({ children, disabled, required, visuallyHidden, as: Component = "label", className, ...props }) => {
	return /* @__PURE__ */ jsx(Component, {
		className: clsx(InputLabel_module_default.InputLabel, disabled && InputLabel_module_default.disabled, visuallyHidden && "sr-only", className),
		...props,
		children: required ? /* @__PURE__ */ jsxs("span", {
			className: InputLabel_module_default.requiredWrapper,
			children: [/* @__PURE__ */ jsx("div", {
				className: InputLabel_module_default.requiredContent,
				children
			}), /* @__PURE__ */ jsx("span", { children: "*" })]
		}) : children
	});
};
InputLabel.displayName = "InputLabel";
var Label_module_default = { inputLabel: "Label-module_Th441a_inputLabel" };
var Legend = ({ ...props }) => {
	const { disabled, required } = use(MarkdownEditorContext);
	return /* @__PURE__ */ jsx(InputLabel, {
		as: "legend",
		disabled,
		required,
		className: Label_module_default.inputLabel,
		...props
	});
};
Legend.displayName = "MarkdownEditor.Label";
var Label = (props) => /* @__PURE__ */ jsx(Legend, { ...props });
Label.displayName = "Label";
var SuspenseFallback_module_default = {
	container: "SuspenseFallback-module_9fi4ra_container",
	placeholder: "SuspenseFallback-module_9fi4ra_placeholder"
};
function SuspenseFallback({ value, placeholder }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Header, {
		selectedView: "hybrid",
		children: /* @__PURE__ */ jsx(Toolbar$1, {
			view: null,
			selectedNodes: [],
			fileUploadButton: /* @__PURE__ */ jsx(FileUploadButton$1, { disabled: true })
		})
	}), /* @__PURE__ */ jsx("div", {
		className: clsx("cm-editor", "cm-content", SuspenseFallback_module_default.container),
		children: value || /* @__PURE__ */ jsx("div", {
			className: SuspenseFallback_module_default.placeholder,
			children: placeholder
		})
	})] });
}
SuspenseFallback.displayName = "SuspenseFallback";
function CustomToolbarButton({ icon, ["aria-label"]: ariaLabel, disabled, keybindingHint, onClick: onClickCommand, telemetryId }) {
	const { view } = use(ToolbarContext);
	const telemetry = useHybridEditorTelemetry();
	const onClick = () => {
		if (!view) return;
		if (!view.hasFocus) view.focus();
		const handled = onClickCommand(view);
		telemetry.trackToolbarInteraction({
			control: telemetryId ?? ariaLabel ?? "unknown",
			action: telemetryId ?? ariaLabel ?? "unknown",
			trigger: "toolbar",
			isActive: false,
			keybinding: keybindingHint,
			handled
		});
	};
	return /* @__PURE__ */ jsx(ActionBar.IconButton, {
		variant: "invisible",
		onMouseDown: (e) => e.preventDefault(),
		disabled: !view || disabled,
		onClick,
		icon,
		"aria-label": ariaLabel,
		keybindingHint
	});
}
CustomToolbarButton.displayName = "CustomToolbarButton";
var CodeMirrorEditor = lazy(async () => {
	return { default: (await import("./server-CodeMirrorEditor-LlCAjUWP-DDXGnBUp.js")).CodeMirrorEditor };
});
CodeMirrorEditor.displayName = "CodeMirrorEditor";
function HybridMarkdownEditorComponent({ onChangeViewMode, value, placeholder, ref, isGenerating, ...restProps }) {
	return /* @__PURE__ */ jsx("div", {
		className: HybridMarkdownEditor_module_default.container,
		children: /* @__PURE__ */ jsx(ErrorBoundary, {
			fallback: /* @__PURE__ */ jsx(ErrorFallback, { onChangeViewMode }),
			children: /* @__PURE__ */ jsx(HybridEditorTelemetryProvider, {
				options: useMemo(() => ({ featureFlagEnabled: isFeatureEnabled("markdown_experience_hybrid_editor") }), []),
				children: /* @__PURE__ */ jsx(Suspense, {
					fallback: /* @__PURE__ */ jsx(SuspenseFallback, {
						value,
						placeholder
					}),
					children: /* @__PURE__ */ jsx(CodeMirrorEditor, {
						ref,
						onChangeViewMode,
						value,
						placeholder,
						isGenerating,
						...restProps
					})
				})
			})
		})
	});
}
HybridMarkdownEditorComponent.displayName = "HybridMarkdownEditorComponent";
var HybridMarkdownEditor = Object.assign(HybridMarkdownEditorComponent, { ToolbarButton: CustomToolbarButton });
/**
* Updates all links in the container to open a new tab and call `onLinkClick` on click.
*/
var useLinkInterception = (t0) => {
	const $ = c(6);
	const { htmlContainerRef, htmlContainer, onLinkClick, openLinksInNewTab } = t0;
	let t1;
	let t2;
	if ($[0] !== htmlContainer || $[1] !== htmlContainerRef || $[2] !== onLinkClick || $[3] !== openLinksInNewTab) {
		t1 = () => {
			const theref = htmlContainerRef?.current || htmlContainer;
			if (!theref) return;
			const clickHandler = (event) => {
				const link = event.target.closest("a");
				if (!link) return;
				onLinkClick?.(event);
				if (!event.defaultPrevented && openLinksInNewTab && link.href) {
					window.open(link.href, "_blank", "noopener noreferrer");
					event.preventDefault();
				}
			};
			theref.addEventListener("click", clickHandler);
			return () => {
				theref?.removeEventListener("click", clickHandler);
			};
		};
		t2 = [
			htmlContainer,
			htmlContainerRef,
			onLinkClick,
			openLinksInNewTab
		];
		$[0] = htmlContainer;
		$[1] = htmlContainerRef;
		$[2] = onLinkClick;
		$[3] = openLinksInNewTab;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
};
var getSelectedLineRange = (textarea) => {
	const start = textarea.value.lastIndexOf("\n", textarea.selectionStart - 1) + 1;
	let end = textarea.value.indexOf("\n", textarea.selectionEnd);
	if (end === -1) end = textarea.value.length;
	return [start, end];
};
/**
* Generate a markdown HTML comment with escaped dashes
*/
var markdownComment = (text) => `<!-- ${text.replaceAll("--", "\\-\\-")} -->`;
/**
* Generate markdown link text with escaped brackets and parentheses
*/
var markdownLink = (text, url) => `[${text.replaceAll("[", "\\[").replaceAll("]", "\\]")}](${url.replaceAll("(", "\\(").replaceAll(")", "\\)")})`;
var isModifierKey = (event) => isMacOS() ? event.metaKey : event.ctrlKey;
var getImageSizeFromFile = async (file) => {
	const result = await getImageSizeFromFile$1(file);
	if (!result) return null;
	return {
		width: result.width,
		height: result.height,
		ppi: result.pixelsPerInch
	};
};
var escapeHtml = (unsafe) => unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
/**
* Generate markdown image tag with dimensions, accounting for retina displays
* Handles HTML escaping of alt text and src URLs
*/
var markdownImageTag = (dimensions, src, alt = "Image") => {
	const safeAlt = escapeHtml(alt);
	const safeSrc = escapeHtml(src);
	if (dimensions.ppi === 144) return `<img width="${Math.round(dimensions.width / 2)}" height="${Math.round(dimensions.height / 2)}" alt="${safeAlt}" src="${safeSrc}" />`;
	if (dimensions && dimensions.width > 0 && dimensions.height > 0) return `<img width="${dimensions.width}" height="${dimensions.height}" alt="${safeAlt}" src="${safeSrc}" />`;
	return `![${safeAlt}](${safeSrc})`;
};
var calculateNextListItemStarter = ({ leadingWhitespace = "", delimeter, taskBox, text }) => {
	if (!text) return null;
	return `\n${leadingWhitespace}${typeof delimeter === "number" ? `${delimeter + 1}.` : delimeter}${taskBox ? " [ ]" : ""} `;
};
var calculatePreviousListItemStarter = ({ leadingWhitespace = "", delimeter, taskBox }) => {
	return `${typeof delimeter === "number" ? `${delimeter}.` : delimeter}${leadingWhitespace}${taskBox ? " [ ]" : " "}\n`;
};
/**
* Adapted from: https://github.com/github/github/blob/ef649172de6802a699638e22798396ca78d61dc8/app/assets/modules/github/behaviors/task-list.ts#L404
*
* Groups:
*  0. Leading whitespace
*  1. Delimeter
*  2. Item number (optional)
*     - Note that we don't have item letter - we don't do autocomplete for lettered lists like (a, b, c) or (i, ii, iii) because it's too complex
*  3. Task box (optional)
*  4. Everything following
*
* This part of the regex ^(\s*(?:>\s*)*(?:[*-]\s{1,4})*) defines the allowed leading content for a list item.
* It allows for:
* - unlimited whitespace (at the start of the line)
* - any number of (">" followed by unlimited spaces) (for blockquotes)
* - any number of ("*" or "-" followed by 1-4 spaces) (for nested lists)
*/
var listItemRegex = /^(\s*(?:>\s*)*(?:[*-]\s{1,4})*)([*-]|(\d+)\.)(\s{1,4})(?:(\[[\sx]\])\s)?(.*)/i;
var isNumericListItem = (item) => typeof item?.delimeter === "number";
var parseListItem = (line) => {
	const result = listItemRegex.exec(line);
	if (!result) return null;
	const [, leadingWhitespace = "", fullDelimeter, itemNumberStr = "", middleWhitespace, taskBox = null, text] = result;
	const itemNumber = Number.parseInt(itemNumberStr, 10);
	return {
		leadingWhitespace,
		text,
		delimeter: Number.isNaN(itemNumber) ? fullDelimeter : itemNumber,
		middleWhitespace,
		taskBox
	};
};
var listItemToString = (item) => typeof item.delimeter === "number" ? `${item.leadingWhitespace}${item.delimeter}.${item.middleWhitespace}${item.taskBox ? `${item.taskBox} ` : ""}${item.text}` : `${item.leadingWhitespace}${item.delimeter}${item.middleWhitespace}${item.taskBox || ""} ${item.text}`;
/**
* Provides support for list editing in the Markdown editor. This includes inserting new
* list items and auto-incrementing numeric lists.
*/
var useListEditing = (t0) => {
	const $ = c(7);
	const { emitChange } = t0;
	let t1;
	if ($[0] !== emitChange) {
		t1 = (textarea, lineRange) => {
			const [currentLineStart, currentLineEnd] = lineRange || getSelectedLineRange(textarea);
			const currentLineItem = parseListItem(textarea.value.slice(currentLineStart, currentLineEnd));
			if (!isNumericListItem(currentLineItem)) return;
			const followingLines = textarea.value.slice(currentLineEnd + 1).split(/\r?\n/);
			const followingNumericListItems = [];
			let prevItemNumber = currentLineItem.delimeter;
			for (const line of followingLines) {
				const listItem = parseListItem(line);
				if (!isNumericListItem(listItem) || listItem.delimeter !== prevItemNumber) break;
				followingNumericListItems.push(listItem);
				prevItemNumber++;
			}
			if (followingNumericListItems.length === 0) return;
			const updatedItems = `\n${followingNumericListItems.map(_temp$2).join("\n")}`;
			emitChange(updatedItems, [currentLineEnd, currentLineEnd + updatedItems.length + 1], textarea.selectionStart);
		};
		$[0] = emitChange;
		$[1] = t1;
	} else t1 = $[1];
	const incrementFollowingNumericLines = t1;
	let t2;
	if ($[2] !== emitChange || $[3] !== incrementFollowingNumericLines) {
		t2 = (event) => {
			if (event.key === "Enter" && !event.shiftKey && !event.defaultPrevented) {
				const textarea_0 = event.currentTarget;
				const [activeLineStart, activeLineEnd] = getSelectedLineRange(textarea_0);
				const listItem_0 = parseListItem(textarea_0.value.slice(activeLineStart, textarea_0.selectionStart) + textarea_0.value.slice(textarea_0.selectionEnd, activeLineEnd));
				if (!listItem_0) return;
				event.preventDefault();
				if (textarea_0.selectionStart === activeLineStart) {
					const previousItemStarter = calculatePreviousListItemStarter(listItem_0);
					if (previousItemStarter === null) emitChange("", [activeLineStart, textarea_0.selectionEnd]);
					else {
						emitChange(previousItemStarter);
						incrementFollowingNumericLines(textarea_0, [activeLineStart, activeLineStart + previousItemStarter.length - 1]);
					}
				} else {
					const nextItemStarter = calculateNextListItemStarter(listItem_0);
					if (nextItemStarter === null) emitChange("", [activeLineStart, textarea_0.selectionEnd]);
					else {
						emitChange(nextItemStarter);
						incrementFollowingNumericLines(textarea_0);
					}
				}
			}
		};
		$[2] = emitChange;
		$[3] = incrementFollowingNumericLines;
		$[4] = t2;
	} else t2 = $[4];
	const onKeyDown = t2;
	let t3;
	if ($[5] !== onKeyDown) {
		t3 = { onKeyDown };
		$[5] = onKeyDown;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
};
function _temp$2(item) {
	return listItemToString({
		...item,
		delimeter: item.delimeter + 1
	});
}
var parseCodeFenceBegin = (line) => {
	const match = line.match(/^ {0,3}(`{3,}|~{3,})[^`]*$/);
	return match ? match[1] : null;
};
var isCodeFenceEnd = (line, fence) => {
	return new RegExp(`^ {0,3}${fence}${fence[0]}* *$`).test(line);
};
var isTaskListItem = (item) => typeof item?.taskBox === "string";
var toggleTaskListItem = (item) => ({
	...item,
	taskBox: item.taskBox === "[ ]" ? "[x]" : "[ ]"
});
/**
* Adds support for list interaction to rendered Markdown.
*
* Currently only supports checking / unchecking list items - reordering and task-item to
* issue conversion are not supported yet.
*/
var useListInteraction = ({ htmlContainer, markdownValue, onChange, disabled = false, dependencies = [] }) => {
	const markdownRef = useRef(markdownValue);
	useIsomorphicLayoutEffect(() => {
		markdownRef.current = markdownValue;
	}, [markdownValue]);
	const onToggleItem = useCallback((toggledItemIndex) => () => {
		const lines = markdownRef.current.split(/\r?\n/);
		let currentCodeFence = null;
		for (let lineIndex = 0, taskIndex = 0; lineIndex < lines.length; lineIndex++) {
			const line = lines[lineIndex];
			if (!currentCodeFence) currentCodeFence = parseCodeFenceBegin(line);
			else if (isCodeFenceEnd(line, currentCodeFence)) {
				currentCodeFence = null;
				continue;
			}
			if (currentCodeFence) continue;
			const parsedLine = parseListItem(line);
			if (!isTaskListItem(parsedLine)) continue;
			if (taskIndex === toggledItemIndex) {
				const updatedLine = listItemToString(toggleTaskListItem(parsedLine));
				lines.splice(lineIndex, 1, updatedLine);
				const updatedMarkdown = lines.join("\n");
				markdownRef.current = updatedMarkdown;
				onChange(updatedMarkdown);
				return;
			}
			taskIndex++;
		}
	}, [onChange]);
	const [checkboxElements, setCheckboxElements] = useState([]);
	useEffect(() => {
		setCheckboxElements(Array.from(htmlContainer?.querySelectorAll("input[type=checkbox].task-list-item-checkbox") ?? []));
	}, [htmlContainer, ...dependencies]);
	useEffect(function enableOrDisableCheckboxes() {
		const cleanupFns = checkboxElements.map((el) => {
			const previouslyDisabled = el.disabled;
			el.disabled = disabled;
			return () => {
				el.disabled = previouslyDisabled;
			};
		});
		return () => {
			for (const fn of cleanupFns) fn();
		};
	}, [checkboxElements, disabled]);
	useEffect(function bindEventListeners() {
		const abortController = new AbortController();
		for (const [i, el] of checkboxElements.entries()) {
			const toggleHandler = onToggleItem(i);
			el.addEventListener("change", toggleHandler, { signal: abortController.signal });
		}
		return () => {
			abortController.abort();
		};
	}, [checkboxElements, onToggleItem]);
};
var MarkdownViewer_module_default = { MarkdownViewerContainer: "MarkdownViewer-module_X7kXJG_MarkdownViewerContainer" };
function MarkdownViewer({ ref = null, verifiedHTML, loading = false, markdownValue = "", onChange: externalOnChange, disabled = false, onLinkClick, openLinksInNewTab = false, teamHovercardsEnabled = false, className }) {
	const [htmlContainer, setHtmlContainer] = useState(null);
	const htmlContainerRefObject = useRef(null);
	useRefObjectAsForwardedRef(ref, htmlContainerRefObject);
	const htmlContainerRef = useCallback((el) => {
		htmlContainerRefObject.current = el;
		setHtmlContainer(el);
	}, []);
	useListInteraction({
		onChange: useCallback(async (value) => {
			try {
				await externalOnChange?.(value);
			} catch {
				if (htmlContainer) htmlContainer.innerHTML = verifiedHTML;
			}
		}, [
			externalOnChange,
			htmlContainer,
			verifiedHTML
		]),
		disabled: disabled || !externalOnChange,
		htmlContainer: htmlContainer ?? void 0,
		markdownValue,
		dependencies: [verifiedHTML]
	});
	useLinkInterception({
		htmlContainer: htmlContainer ?? void 0,
		onLinkClick,
		openLinksInNewTab
	});
	return useMemo(() => loading ? /* @__PURE__ */ jsx("div", {
		className: MarkdownViewer_module_default.MarkdownViewerContainer,
		children: /* @__PURE__ */ jsx(Spinner, { "aria-label": "Loading content..." })
	}) : /* @__PURE__ */ jsx(VerifiedHTMLBox, {
		ref: htmlContainerRef,
		className: clsx("markdown-body", className),
		sx: className ? {} : {
			fontSize: 1,
			maxWidth: "100%",
			"& > div > :last-child": { mb: 0 }
		},
		html: verifiedHTML,
		...teamHovercardsEnabled ? { "data-team-hovercards-enabled": true } : {}
	}), [
		className,
		loading,
		teamHovercardsEnabled,
		verifiedHTML,
		htmlContainerRef
	]);
}
MarkdownViewer.displayName = "MarkdownViewer";
var sendFormatEvent = (tool) => sendEvent(`markdown_editor.format`, { tool });
/**
* Renders an invisible `markdown-toolbar-element` that provides formatting actions to the
* editor. This is a hacky way of using the library, but it allows us to use the built-in
* behavior without having to actually display the inflexible toolbar element. It also means
* we can still use the formatting tools even if the consumer hides the default toolbar
* buttons (ie, by keyboard shortcut).
*/
var FormattingTools = ({ ref: forwadedRef, forInputId }) => {
	useEffect(() => {
		import("@github/markdown-toolbar-element");
	}, []);
	const headerRef = useRef(null);
	const boldRef = useRef(null);
	const italicRef = useRef(null);
	const quoteRef = useRef(null);
	const codeRef = useRef(null);
	const linkRef = useRef(null);
	const unorderedListRef = useRef(null);
	const orderedListRef = useRef(null);
	const taskListRef = useRef(null);
	const mentionRef = useRef(null);
	const referenceRef = useRef(null);
	useImperativeHandle(forwadedRef, () => ({
		header: () => {
			headerRef.current?.click();
			sendFormatEvent("header");
		},
		bold: () => {
			boldRef.current?.click();
			sendFormatEvent("bold");
		},
		italic: () => {
			italicRef.current?.click();
			sendFormatEvent("italic");
		},
		quote: () => {
			quoteRef.current?.click();
			sendFormatEvent("quote");
		},
		code: () => {
			codeRef.current?.click();
			sendFormatEvent("code");
		},
		link: () => {
			linkRef.current?.click();
			sendFormatEvent("link");
		},
		unorderedList: () => {
			unorderedListRef.current?.click();
			sendFormatEvent("unorderedList");
		},
		orderedList: () => {
			orderedListRef.current?.click();
			sendFormatEvent("orderedList");
		},
		taskList: () => {
			taskListRef.current?.click();
			sendFormatEvent("taskList");
		},
		mention: () => {
			mentionRef.current?.click();
			sendFormatEvent("mention");
		},
		reference: () => {
			referenceRef.current?.click();
			sendFormatEvent("reference");
		}
	}));
	return /* @__PURE__ */ jsxs("markdown-toolbar", {
		for: forInputId,
		style: { display: "none" },
		children: [
			/* @__PURE__ */ jsx("md-header", { ref: headerRef }),
			/* @__PURE__ */ jsx("md-bold", { ref: boldRef }),
			/* @__PURE__ */ jsx("md-italic", { ref: italicRef }),
			/* @__PURE__ */ jsx("md-quote", { ref: quoteRef }),
			/* @__PURE__ */ jsx("md-code", { ref: codeRef }),
			/* @__PURE__ */ jsx("md-link", { ref: linkRef }),
			/* @__PURE__ */ jsx("md-unordered-list", { ref: unorderedListRef }),
			/* @__PURE__ */ jsx("md-ordered-list", { ref: orderedListRef }),
			/* @__PURE__ */ jsx("md-task-list", { ref: taskListRef }),
			/* @__PURE__ */ jsx("md-mention", { ref: mentionRef }),
			/* @__PURE__ */ jsx("md-ref", { ref: referenceRef })
		]
	});
};
FormattingTools.displayName = "FormattingTools";
FormattingTools.displayName = "MarkdownEditor.FormattingTools";
var MarkdownEditor_module_default = {
	container: "MarkdownEditor-module_SfIgyG_container",
	disabled: "MarkdownEditor-module_SfIgyG_disabled",
	fieldSet: "MarkdownEditor-module_SfIgyG_fieldSet",
	fullHeight: "MarkdownEditor-module_SfIgyG_fullHeight",
	header: "MarkdownEditor-module_SfIgyG_header",
	hidden: "MarkdownEditor-module_SfIgyG_hidden",
	inputWrapper: "MarkdownEditor-module_SfIgyG_inputWrapper",
	previewHeader: "MarkdownEditor-module_SfIgyG_previewHeader",
	previewViewerWrapper: "MarkdownEditor-module_SfIgyG_previewViewerWrapper",
	previewWrapper: "MarkdownEditor-module_SfIgyG_previewWrapper",
	redesignedViewSwitchWrapper: "MarkdownEditor-module_SfIgyG_redesignedViewSwitchWrapper",
	viewSwitchWrapper: "MarkdownEditor-module_SfIgyG_viewSwitchWrapper"
};
/**
* Calculates the optimal height of the textarea according to its content, automatically
* resizing it as the user types. If the user manually resizes the textarea, their setting
* will be respected.
*
* Returns an object to spread to the component's `style` prop. If you are using `Textarea`,
* apply this to the child `textarea` element: `<Textarea style={{resultOfThisHook}} />`.
*
* NOTE: for the most accurate results, be sure that the `lineHeight` of the element is
* explicitly set in CSS.
*/
var useDynamicTextareaHeight = ({ disabled, minHeightLines, maxHeightLines, elementRef, value }) => {
	const [height, setHeight] = useState(void 0);
	const { isBrowser } = useRuntimeEnvironment();
	const supportsFieldSizingContent = useMemo(() => {
		try {
			return isBrowser ? CSS.supports("field-sizing", "content") : true;
		} catch {
			return false;
		}
	}, [isBrowser]);
	const refreshHeight = useCallback(() => {
		if (disabled) return;
		const element = elementRef.current;
		if (!element) return;
		if (supportsFieldSizingContent) return;
		if (!value) return;
		const computedStyles = getComputedStyle(element);
		setHeight(`calc(${element.scrollHeight}px - ${computedStyles.paddingTop} - ${computedStyles.paddingBottom})`);
	}, [
		disabled,
		elementRef,
		supportsFieldSizingContent,
		value
	]);
	useLayoutEffect(refreshHeight, [refreshHeight]);
	useEffect(refreshHeight, []);
	return {
		height,
		minHeight: minHeightLines ? `${minHeightLines}lh` : void 0,
		maxHeight: maxHeightLines ? `${maxHeightLines}lh` : void 0,
		boxSizing: "content-box",
		fieldSizing: "content",
		overflowWrap: "anywhere"
	};
};
var MarkdownInput_module_default = {
	displayNone: "MarkdownInput-module_RcaUFq_displayNone",
	fullHeight: "MarkdownInput-module_RcaUFq_fullHeight",
	generatingText: "MarkdownInput-module_RcaUFq_generatingText",
	inputWrapper: "MarkdownInput-module_RcaUFq_inputWrapper",
	isDraggedOver: "MarkdownInput-module_RcaUFq_isDraggedOver",
	monospace: "MarkdownInput-module_RcaUFq_monospace",
	skeletonOverlay: "MarkdownInput-module_RcaUFq_skeletonOverlay",
	textArea: "MarkdownInput-module_RcaUFq_textArea"
};
var emptyArray = [];
var MarkdownInput = ({ ref: forwardedRef, value, onChange, onInput, disabled, placeholder, id, maxLength, onKeyDown, fullHeight, isDraggedOver, emojiSuggestions, emojiTone, mentionSuggestions, referenceSuggestions, labelledBy, minHeightLines, maxHeightLines, visible, monospace, pasteUrlsAsPlainText, className, generatingText, ...props }) => {
	const emojiConfig = useMemo(() => ({ tone: emojiTone }), [emojiTone]);
	const { trigger: emojiTrigger, calculateSuggestions: calculateEmojiSuggestions } = useEmojiSuggestions(emojiSuggestions ?? emptyArray, emojiConfig);
	const { trigger: mentionsTrigger, calculateSuggestions: calculateMentionSuggestions } = useMentionSuggestions(mentionSuggestions ?? emptyArray);
	const { trigger: referencesTrigger, calculateSuggestions: calculateReferenceSuggestions } = useReferenceSuggestions(referenceSuggestions ?? emptyArray);
	const { triggers, suggestions, setSuggestionEvent } = useAutocompleteTriggersAndSuggestions(useMemo(() => [
		{
			trigger: emojiTrigger,
			suggestionsCalculator: calculateEmojiSuggestions
		},
		{
			trigger: mentionsTrigger,
			suggestionsCalculator: calculateMentionSuggestions
		},
		{
			trigger: referencesTrigger,
			suggestionsCalculator: calculateReferenceSuggestions
		}
	], [
		calculateEmojiSuggestions,
		calculateMentionSuggestions,
		calculateReferenceSuggestions,
		emojiTrigger,
		mentionsTrigger,
		referencesTrigger
	]));
	const ref = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, ref);
	useEffect(() => {
		return (ref.current && subscribe(ref.current, { defaultPlainTextPaste: { urlLinks: pasteUrlsAsPlainText } }))?.unsubscribe;
	}, [pasteUrlsAsPlainText]);
	const heightStyles = useDynamicTextareaHeight({
		disabled: fullHeight || !visible,
		maxHeightLines,
		minHeightLines,
		elementRef: ref,
		value
	});
	useEffect(() => {
		if (ref.current) ref.current.value = value;
	});
	return /* @__PURE__ */ jsxs("div", {
		className: MarkdownInput_module_default.inputWrapper,
		children: [/* @__PURE__ */ jsx(InlineAutocomplete, {
			triggers,
			suggestions,
			onShowSuggestions: (event) => {
				if (!suggestions) sendEvent("markdown_editor.show_autocomplete_suggestions", { trigger: event.trigger.triggerChar });
				setSuggestionEvent(event);
			},
			onHideSuggestions: () => setSuggestionEvent(null),
			style: { flex: "auto" },
			tabInsertsSuggestions: true,
			children: /* @__PURE__ */ jsx(Textarea, {
				id,
				ref,
				placeholder,
				maxLength,
				onKeyDown,
				disabled,
				"aria-label": labelledBy ? void 0 : "Markdown value",
				"aria-labelledby": labelledBy,
				onChange,
				onInput,
				value,
				className: clsx(className, MarkdownInput_module_default.textArea, !visible && MarkdownInput_module_default.displayNone, fullHeight && MarkdownInput_module_default.fullHeight, monospace && MarkdownInput_module_default.monospace, isDraggedOver && MarkdownInput_module_default.isDraggedOver, generatingText && MarkdownInput_module_default.generatingText),
				rows: minHeightLines,
				style: heightStyles,
				...props
			})
		}), generatingText && visible && /* @__PURE__ */ jsx("div", {
			className: MarkdownInput_module_default.skeletonOverlay,
			children: /* @__PURE__ */ jsx(SkeletonText, {
				lines: 5,
				"aria-label": "Generating text"
			})
		})]
	});
};
MarkdownInput.displayName = "MarkdownInput";
MarkdownInput.displayName = "MarkdownInput";
var SavedReplies_module_default = { SavedReplies: "SavedReplies-module_1dVJwq_SavedReplies" };
var SavedRepliesContext = createContext(null);
SavedRepliesContext.displayName = "SavedRepliesContext";
var SavedRepliesButton = () => {
	const $ = c(9);
	const context = use(SavedRepliesContext);
	const [open, setOpen] = useState(false);
	const [filter, setFilter] = useState("");
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => ({ openMenu: () => {
			setOpen(true);
		} });
		$[0] = t0;
	} else t0 = $[0];
	useImperativeHandle(context?.ref, t0);
	let t1;
	if ($[1] !== context || $[2] !== filter || $[3] !== open) {
		const items = context?.savedReplies.filter((t2) => {
			const { name } = t2;
			return name.toLowerCase().includes(filter.toLowerCase());
		}).map(_temp$1);
		let t3;
		if ($[5] !== context) {
			t3 = (item) => {
				setOpen(false);
				const reply_0 = context?.savedReplies.find((t4) => {
					const { name: name_0 } = t4;
					return name_0 === item?.text;
				});
				if (reply_0) context?.onSelect(reply_0);
			};
			$[5] = context;
			$[6] = t3;
		} else t3 = $[6];
		const onSelectItem = t3;
		const onKeyDown = (event) => {
			const keyInt = parseInt(event.key, 10);
			if (items && event.ctrlKey && !Number.isNaN(keyInt) && keyInt >= 1 && keyInt <= 9) {
				event.stopPropagation();
				event.preventDefault();
				onSelectItem(items[keyInt - 1]);
			}
		};
		let t4;
		if ($[7] !== context) {
			t4 = (openState) => {
				setOpen(openState);
				if (!openState) setFilter("");
				else {
					sendEvent("markdown_editor.open_saved_replies");
					context?.onOpen();
				}
			};
			$[7] = context;
			$[8] = t4;
		} else t4 = $[8];
		t1 = items ? jsx(SelectPanel, {
			renderAnchor: _temp2,
			open,
			onOpenChange: t4,
			items,
			filterValue: filter,
			onFilterChange: setFilter,
			placeholderText: "Search saved replies",
			selected: void 0,
			onSelectedChange: (selection) => {
				onSelectItem(Array.isArray(selection) ? selection[0] : selection);
			},
			overlayProps: {
				width: "small",
				maxHeight: "small",
				anchorSide: "outside-right",
				onKeyDown
			},
			secondaryAction: jsx(SelectPanel.SecondaryActionLink, {
				href: getSavedRepliesLink(),
				children: "Create new"
			})
		}) : jsx(Fragment$1, {});
		$[1] = context;
		$[2] = filter;
		$[3] = open;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
SavedRepliesButton.displayName = "SavedRepliesButton";
function getSavedRepliesLink() {
	return `${ssrSafeLocation.origin}/settings/replies`;
}
function _temp$1(reply, i) {
	return {
		id: i,
		text: reply.name,
		description: reply.content,
		descriptionVariant: "block",
		trailingVisual: i < 9 ? `Ctrl + ${i + 1}` : void 0,
		className: SavedReplies_module_default.SavedReplies
	};
}
function _temp2(props) {
	return jsx(IconButton, {
		...props,
		variant: "invisible",
		icon: ReplyIcon,
		"aria-label": "Saved replies"
	});
}
var Toolbar_module_default = {
	actionBar: "Toolbar-module_QUe7Ja_actionBar",
	toolbar: "Toolbar-module_QUe7Ja_toolbar"
};
var ToolbarButton_module_default = { iconButton: "ToolbarButton-module_wKY2lq_iconButton" };
var ToolbarButton = ({ ref, ...props }) => {
	const { disabled } = use(MarkdownEditorContext);
	return /* @__PURE__ */ jsx(ActionBar.IconButton, {
		ref,
		variant: "invisible",
		disabled,
		onMouseDown: (e) => e.preventDefault(),
		...props,
		className: ToolbarButton_module_default.iconButton
	});
};
ToolbarButton.displayName = "ToolbarButton";
ToolbarButton.displayName = "MarkdownEditor.ToolbarButton";
var DefaultToolbarButtons = memo(() => {
	const { formattingToolsRef } = use(MarkdownEditorContext);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.header(),
			icon: HeadingIcon,
			"aria-label": "Heading"
		}),
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.bold(),
			icon: BoldIcon,
			"aria-label": "Bold"
		}),
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.italic(),
			icon: ItalicIcon,
			"aria-label": "Italic"
		}),
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.quote(),
			icon: QuoteIcon,
			"aria-label": "Quote"
		}),
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.code(),
			icon: CodeIcon,
			"aria-label": "Code"
		}),
		/* @__PURE__ */ jsx(ToolbarButton, {
			onClick: () => formattingToolsRef.current?.link(),
			icon: LinkIcon,
			"aria-label": "Link"
		}),
		/* @__PURE__ */ jsxs(ActionBar.Group, { children: [
			/* @__PURE__ */ jsx(ActionBar.Divider, {}),
			/* @__PURE__ */ jsx(ToolbarButton, {
				onClick: () => formattingToolsRef.current?.unorderedList(),
				icon: ListUnorderedIcon,
				"aria-label": "Unordered list"
			}),
			/* @__PURE__ */ jsx(ToolbarButton, {
				onClick: () => formattingToolsRef.current?.orderedList(),
				icon: ListOrderedIcon,
				"aria-label": "Numbered list"
			}),
			/* @__PURE__ */ jsx(ToolbarButton, {
				onClick: () => formattingToolsRef.current?.taskList(),
				icon: TasklistIcon,
				"aria-label": "Task list"
			})
		] }),
		/* @__PURE__ */ jsxs(ActionBar.Group, { children: [
			/* @__PURE__ */ jsx(ActionBar.Divider, {}),
			/* @__PURE__ */ jsx(ToolbarButton, {
				onClick: () => formattingToolsRef.current?.mention(),
				icon: MentionIcon,
				"aria-label": "Mention"
			}),
			/* @__PURE__ */ jsx(ToolbarButton, {
				onClick: () => formattingToolsRef.current?.reference(),
				icon: CrossReferenceIcon,
				"aria-label": "Reference"
			})
		] })
	] });
});
DefaultToolbarButtons.displayName = "DefaultToolbarButtons";
DefaultToolbarButtons.displayName = "MarkdownEditor.DefaultToolbarButtons";
var CoreToolbar = ({ children }) => {
	return /* @__PURE__ */ jsxs("div", {
		className: Toolbar_module_default.toolbar,
		children: [/* @__PURE__ */ jsx(ActionBar, {
			"aria-label": "Formatting tools",
			className: Toolbar_module_default.actionBar,
			gap: "none",
			children
		}), /* @__PURE__ */ jsx(SavedRepliesButton, {})]
	});
};
CoreToolbar.displayName = "CoreToolbar";
var Toolbar = ({ children }) => /* @__PURE__ */ jsx(CoreToolbar, { children });
Toolbar.displayName = "Toolbar";
Toolbar.displayName = "MarkdownEditor.Toolbar";
var indentationRegex = /^(?:\t| ? ?)(.*)/;
var dedent = (line) => indentationRegex.exec(line)?.[1] ?? "";
var indent = (line) => `  ${line}`;
/**
* Provides functionality for indenting and dedenting selected lines in the Markdown editor.
*/
var useIndenting = (t0) => {
	const $ = c(4);
	const { emitChange } = t0;
	let t1;
	if ($[0] !== emitChange) {
		t1 = (event) => {
			const textarea = event.currentTarget;
			if (event.defaultPrevented || event.key !== "Tab" || textarea.selectionEnd - textarea.selectionStart === 0) return;
			event.preventDefault();
			const [start, end] = getSelectedLineRange(textarea);
			const updatedLines = textarea.value.slice(start, end).split(/\r?\n/).map((line) => event.shiftKey ? dedent(line) : indent(line)).join("\n");
			emitChange(updatedLines, [start, end], [start, start + updatedLines.length]);
		};
		$[0] = emitChange;
		$[1] = t1;
	} else t1 = $[1];
	const onKeyDown = t1;
	let t2;
	if ($[2] !== onKeyDown) {
		t2 = { onKeyDown };
		$[2] = onKeyDown;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
function useInputManagement(onChange) {
	const $ = c(11);
	const inputRef = useRef(null);
	const [inputKey, setInputKey] = useState(1);
	let t0;
	if ($[0] !== onChange) {
		t0 = (e) => {
			onChange(e.target.value);
		};
		$[0] = onChange;
		$[1] = t0;
	} else t0 = $[1];
	const onInputChange = t0;
	let t1;
	if ($[2] !== onChange) {
		t1 = () => {
			onChange("");
			setInputKey(_temp);
		};
		$[2] = onChange;
		$[3] = t1;
	} else t1 = $[3];
	const reset = t1;
	let t2;
	if ($[4] !== onInputChange) {
		t2 = {
			inputRef,
			fallbackEventHandler: onInputChange
		};
		$[4] = onInputChange;
		$[5] = t2;
	} else t2 = $[5];
	const emitChange = useSyntheticChange(t2);
	let t3;
	if ($[6] !== emitChange || $[7] !== inputKey || $[8] !== onInputChange || $[9] !== reset) {
		t3 = {
			inputRef,
			inputKey,
			onInputChange,
			reset,
			emitChange
		};
		$[6] = emitChange;
		$[7] = inputKey;
		$[8] = onInputChange;
		$[9] = reset;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
function _temp(key) {
	return key + 1;
}
var markdownPrefix$1 = "```suggestion";
var markdownSuffix$1 = "```";
var markdownPrefixRegex = new RegExp(`${markdownPrefix$1}(?:.*)\n`, "i");
var markdownSuffixRegex = new RegExp(`${markdownSuffix$1}(\n|$)`);
function findNextOccurrenceOf(regex, input, cursor = 0) {
	const str = input.substring(cursor, input.length);
	const match = regex.exec(str);
	if (match) return match.index + cursor;
	else return -1;
}
function lineAtIndex(input, index) {
	const lines = input.slice(0, index).split("\n");
	return input.split("\n")[lines.length - 1];
}
function leadingWhitespace(line) {
	const match = /^(\s+)/.exec(line);
	return match && match[0] || "";
}
function cursorInSuggestionBlock(input, cursorIndex) {
	const ranges = [];
	let cursor = 0;
	let startIndex = -1;
	while ((startIndex = findNextOccurrenceOf(markdownPrefixRegex, input, cursor)) > -1) {
		cursor = startIndex + 13;
		const endIndex = findNextOccurrenceOf(markdownSuffixRegex, input, cursor);
		if (endIndex === -1) return false;
		cursor = endIndex + 3;
		ranges.push([startIndex, endIndex]);
	}
	return ranges.some((range) => {
		return cursorIndex > range[0] && cursorIndex < range[1];
	});
}
function buildNewSuggestionLine(textarea) {
	const cursorIndex = textarea.selectionStart;
	if (!cursorInSuggestionBlock(textarea.value, cursorIndex)) return {
		output: "",
		newCursorIndex: 0
	};
	const value = textarea.value;
	const currentLine = lineAtIndex(value, cursorIndex);
	if (currentLine === null) return {
		output: "",
		newCursorIndex: 0
	};
	const lineToInsert = `\n${leadingWhitespace(currentLine)}`;
	return {
		output: lineToInsert,
		newCursorIndex: cursorIndex + lineToInsert.length
	};
}
var usePreserveSpacingIfWithinSuggestedChange = (t0) => {
	const $ = c(4);
	const { emitChange } = t0;
	let t1;
	if ($[0] !== emitChange) {
		t1 = (event) => {
			if (event.key === "Enter") {
				const textarea = event.currentTarget;
				const start = textarea.selectionStart;
				if (start !== textarea.selectionEnd) return;
				const { output, newCursorIndex } = buildNewSuggestionLine(textarea);
				if (output !== "") {
					event.preventDefault();
					emitChange(output, [start, start], [newCursorIndex, newCursorIndex]);
				}
			}
		};
		$[0] = emitChange;
		$[1] = t1;
	} else t1 = $[1];
	const onKeyDown = t1;
	let t2;
	if ($[2] !== onKeyDown) {
		t2 = { onKeyDown };
		$[2] = onKeyDown;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
function usePreview(value, onRenderPreview) {
	const $ = c(10);
	const [html, setHtml] = useState(null);
	const safeSetHtml = useSafeAsyncCallback(setHtml);
	const previewStale = useRef(true);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			previewStale.current = true;
		};
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== value) {
		t1 = [value];
		$[1] = value;
		$[2] = t1;
	} else t1 = $[2];
	useEffect(t0, t1);
	let t2;
	if ($[3] !== onRenderPreview || $[4] !== safeSetHtml || $[5] !== value) {
		t2 = async () => {
			if (!previewStale.current) return;
			previewStale.current = false;
			safeSetHtml(null);
			safeSetHtml(await onRenderPreview(value));
		};
		$[3] = onRenderPreview;
		$[4] = safeSetHtml;
		$[5] = value;
		$[6] = t2;
	} else t2 = $[6];
	const loadPreview = t2;
	let t3;
	if ($[7] !== html || $[8] !== loadPreview) {
		t3 = {
			html,
			setHtml,
			loadPreview,
			previewStale
		};
		$[7] = html;
		$[8] = loadPreview;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
var placeholder = (file) => markdownComment(`Uploading "${file.name}"...`);
var markdown = (file, url, dimensions) => {
	if (!url) return markdownComment(`Failed to upload "${file.name}"`);
	if (file.type.startsWith("video/")) return url;
	if (file.type.startsWith("image/") && !["image/bmp", "image/tiff"].includes(file.type)) return markdownImageTag(dimensions || {
		width: 0,
		height: 0,
		ppi: 1
	}, url, "Image");
	return markdownLink(file.name, url);
};
var UnsupportedFilesErrorMessage = ({ types }) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
	"File type",
	types.size > 1 ? "s" : "",
	" ",
	[...types].join(", "),
	" not supported. See the",
	" ",
	/* @__PURE__ */ jsx(Link, {
		inline: true,
		href: "https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/attaching-files",
		children: "documentation"
	}),
	" ",
	"for supported file types."
] });
UnsupportedFilesErrorMessage.displayName = "UnsupportedFilesErrorMessage";
var noop = () => {};
var useFileHandling = ({ emitChange, value, inputRef, disabled, onUploadFile, acceptedFileTypes, onFilesRejected }) => {
	const [errorMessage, setErrorMessage] = useState(void 0);
	const errorVisibleForEnoughTimeRef = useRef(false);
	useEffect(() => {
		if (errorMessage) {
			errorVisibleForEnoughTimeRef.current = false;
			const id = setTimeout(() => errorVisibleForEnoughTimeRef.current = true, 1e3);
			return () => clearTimeout(id);
		}
	}, [errorMessage]);
	useEffect(() => {
		if (errorVisibleForEnoughTimeRef.current) setErrorMessage(void 0);
	}, [value]);
	const safeSetRejectedFiles = useSafeAsyncCallback((files) => {
		const types = new Set(files.map(({ name }) => {
			const parts = name.split(".");
			return parts.length > 1 ? `.${parts.at(-1)}` : "";
		}).filter((s) => s !== ""));
		if (types.size > 0) {
			setErrorMessage(/* @__PURE__ */ jsx(UnsupportedFilesErrorMessage, { types }));
			onFilesRejected?.(files);
		}
	});
	const [uploadProgress, setUploadProgress] = useState(void 0);
	const safeClearUploadProgress = useSafeAsyncCallback(() => setUploadProgress(void 0));
	const insertPlaceholder = useCallback((files_0) => {
		if (!inputRef?.current) return;
		const newLinePrefix = getNewlinePrefix(inputRef.current.value, inputRef.current.selectionStart);
		const newLineSuffix = getNewlineSuffix(inputRef.current.value, inputRef.current.selectionEnd);
		emitChange(`${newLinePrefix}${files_0.map(placeholder).join("\n")}${newLineSuffix}`);
	}, [inputRef, emitChange]);
	const replacePlaceholderWithMarkdown = (file, url, dimensions) => {
		if (!inputRef?.current) return;
		const placeholderStr = placeholder(file);
		const placeholderIndex = inputRef.current.value.indexOf(placeholderStr);
		if (placeholderIndex === -1) return;
		emitChange(markdown(file, url, dimensions), [placeholderIndex, placeholderIndex + placeholderStr.length]);
	};
	const safeHandleCompletedFileUpload = useSafeAsyncCallback(({ file: file_0, url: url_0 }, dimensions_0) => {
		setUploadProgress((progress) => progress && [progress[0] + 1, progress[1]]);
		replacePlaceholderWithMarkdown(file_0, url_0, dimensions_0);
	});
	const uploadFiles = useCallback((files_1) => files_1.map(async (file_1) => {
		let result = {
			url: null,
			file: file_1
		};
		let dimensions_1 = null;
		try {
			result = await onUploadFile?.(file_1) ?? {
				file: file_1,
				url: null
			};
		} catch {
			result = {
				file: file_1,
				url: null
			};
		}
		if (result.url) try {
			dimensions_1 = await getImageSizeFromFile(file_1);
		} catch {
			dimensions_1 = {
				width: 0,
				height: 0,
				ppi: 1
			};
			reportError("Failed to get image size from file", {
				message: "Failed to get image size from file",
				reactAppName: "markdown-editor"
			});
		}
		safeHandleCompletedFileUpload(result, dimensions_1);
	}), [onUploadFile, safeHandleCompletedFileUpload]);
	let fileSelect = useUnifiedFileSelect({
		acceptedFileTypes,
		multi: true,
		onSelect: useCallback(async (accepted, rejected) => {
			if (accepted.length > 0) {
				setUploadProgress([1, accepted.length]);
				insertPlaceholder(accepted);
				await Promise.all(uploadFiles(accepted));
				safeClearUploadProgress();
			}
			safeSetRejectedFiles(rejected);
		}, [
			safeSetRejectedFiles,
			insertPlaceholder,
			uploadFiles,
			safeClearUploadProgress
		])
	});
	if (disabled) fileSelect = {
		clickTargetProps: { onClick: noop },
		dropTargetProps: {
			onDragEnter: noop,
			onDragLeave: noop,
			onDrop: noop,
			onDragOver: noop
		},
		pasteTargetProps: { onPaste: noop },
		isDraggedOver: false
	};
	return onUploadFile ? {
		...fileSelect,
		errorMessage,
		uploadProgress
	} : null;
};
function getNewlinePrefix(input, selectionStart) {
	if (selectionStart === 0) return "";
	if (input[selectionStart - 1] === "\n") {
		if (selectionStart === 1 || input[selectionStart - 2] === "\n") return "";
	}
	const previousNewlineIndex = input.lastIndexOf("\n", selectionStart - 1);
	if (/\S/.test(input.substring(previousNewlineIndex, selectionStart))) return "\n\n";
	return "\n";
}
function getNewlineSuffix(input, selectionEnd) {
	if (input.length === selectionEnd) return "";
	if (input[selectionEnd] === "\n") {
		if (selectionEnd === input.length - 1 || input[selectionEnd + 1] === "\n") return "";
	}
	const nextNewlineIndex = input.indexOf("\n", selectionEnd);
	if (/\S/.test(input.substring(selectionEnd, nextNewlineIndex))) return "\n\n";
	return "\n";
}
var handleBrand = Symbol();
function getEditorType(viewMode) {
	const hybridEditorEnabled = isFeatureEnabled("markdown_experience_hybrid_editor");
	return viewMode === "hybrid" && hybridEditorEnabled ? "hybrid" : "classic";
}
/**
* We want to switch editors from preview mode on cmd/ctrl+shift+P. But in preview mode,
* there's no input to focus so we have to bind the event to the document. If there are
* multiple editors, we want the most recent one to switch to preview mode to be the one
* that we switch back to edit mode, so we maintain a LIFO stack of IDs of editors in
* preview mode.
*/
var editorsInPreviewMode = [];
/**
* Markdown textarea with controls & keyboard shortcuts.
*/
var ClassicMarkdownEditor = ({ ref, value, onInputFocus, disabled = false, placeholder, maxLength, "aria-describedby": describedBy, labelledBy, fullHeight, onRenderPreview, className, onPrimaryAction, viewMode, onChangeViewMode, minHeightLines = 5, maxHeightLines = 35, emojiSuggestions, emojiTone, mentionSuggestions, referenceSuggestions, monospace = false, required = false, name, children, savedReplies, pasteUrlsAsPlainText = false, teamHovercardsEnabled = false, onSavedRepliesOpen = noop$1, banner, containerRef, onChange, onUploadFile, acceptedFileTypes, onFilesRejected, footer, generatingText }) => {
	const [slots] = useSlots(children, { toolbar: Toolbar });
	const id = useId();
	const useOnInput = isFeatureEnabled("mardown_editor_use_on_input");
	const hybridEditorEnabled = isFeatureEnabled("markdown_experience_hybrid_editor");
	const toolbarRedesignEnabled = isFeatureEnabled("markdown_experience_toolbar_redesign");
	const { inputRef, inputKey, reset, emitChange, onInputChange } = useInputManagement(onChange);
	const { html, loadPreview, previewStale } = usePreview(value, onRenderPreview);
	useEffect(() => {
		if (viewMode === "preview" && previewStale.current) loadPreview();
	});
	const [inputHeight, setInputHeight] = useState(0);
	useLayoutEffect(() => {
		const input = inputRef.current;
		if (!input || viewMode !== "edit") return;
		setInputHeight(input.offsetHeight);
		const observer = new ResizeObserver(([entry]) => {
			if (entry) setInputHeight(entry.contentRect.height);
		});
		observer.observe(input);
		return () => observer.disconnect();
	}, [inputRef, viewMode]);
	useImperativeHandle(ref, () => ({
		focus: (opts) => inputRef.current?.focus(opts),
		moveCursorToEnd: () => {
			if (inputRef.current) {
				const length = inputRef.current.value.length;
				inputRef.current.setSelectionRange(length, length);
			}
		},
		scrollIntoView: (opts_0) => containerRef.current?.scrollIntoView(opts_0),
		reset: () => reset(),
		inputRef,
		[handleBrand]: void 0
	}), [
		containerRef,
		inputRef,
		reset
	]);
	const fileHandler = useFileHandling({
		emitChange,
		value,
		inputRef,
		disabled,
		onUploadFile,
		acceptedFileTypes,
		onFilesRejected: useCallback((rejectedFiles) => {
			const extensions = [];
			for (const file of rejectedFiles) {
				const fileExtension = file.name.includes(".") ? `.${file.name.split(".").pop()}` : "no-extension";
				sendEvent("markdown_editor.file_upload.rejected_file_type", {
					rejected_file_type: fileExtension,
					mime_type: file.type || "unknown"
				});
				extensions.push(fileExtension);
			}
			onFilesRejected?.(rejectedFiles, extensions);
		}, [onFilesRejected])
	});
	const isUploadingFiles = fileHandler?.uploadProgress !== void 0;
	const listEditor = useListEditing({ emitChange });
	const indenter = useIndenting({ emitChange });
	const preserveSpacingIfWithinSuggestedChange = usePreserveSpacingIfWithinSuggestedChange({ emitChange });
	const savedRepliesRef = useRef(null);
	const savedRepliesContext = useMemo(() => savedReplies ? {
		savedReplies,
		onSelect: (reply) => {
			requestAnimationFrame(() => emitChange(reply.content));
		},
		onOpen: onSavedRepliesOpen,
		ref: savedRepliesRef
	} : null, [
		emitChange,
		onSavedRepliesOpen,
		savedReplies
	]);
	const inputCompositionProps = useIgnoreKeyboardActionsWhileComposing((e) => {
		const format = formattingToolsRef.current;
		if (disabled) return;
		if (e.ctrlKey && e.key === ".") {
			savedRepliesRef.current?.openMenu();
			e.preventDefault();
			e.stopPropagation();
		} else if (isModifierKey(e)) {
			if (e.key === "Enter" && !isUploadingFiles) onPrimaryAction?.();
			else if (e.key === "b") format?.bold();
			else if (e.key === "i") format?.italic();
			else if (e.shiftKey && e.key === ".") format?.quote();
			else if (e.key === "e") format?.code();
			else if (e.key === "k") format?.link();
			else if (e.key === "8") format?.unorderedList();
			else if (e.shiftKey && e.key === "7") format?.orderedList();
			else if (e.shiftKey && ["l", "L"].includes(e.key)) format?.taskList();
			else if (e.shiftKey && ["p", "P"].includes(e.key)) onChangeViewMode?.("preview");
			else return;
			e.preventDefault();
			e.stopPropagation();
		} else {
			listEditor.onKeyDown(e);
			indenter.onKeyDown(e);
			preserveSpacingIfWithinSuggestedChange.onKeyDown(e);
		}
	});
	const onChangeViewModeRef = useRef(onChangeViewMode);
	useEffect(() => {
		onChangeViewModeRef.current = onChangeViewMode;
	});
	useEffect(() => {
		if (viewMode === "preview") {
			editorsInPreviewMode.push(id);
			const handler = (e_0) => {
				if (!e_0.defaultPrevented && editorsInPreviewMode.at(-1) === id && isModifierKey(e_0) && e_0.shiftKey && e_0.key === "p") {
					onChangeViewModeRef.current?.("edit");
					setTimeout(() => inputRef.current?.focus());
					e_0.preventDefault();
				}
			};
			document.addEventListener("keydown", handler);
			return () => {
				document.removeEventListener("keydown", handler);
				editorsInPreviewMode = editorsInPreviewMode.filter((id_) => id_ !== id);
			};
		}
	}, [
		viewMode,
		id,
		inputRef
	]);
	const formattingToolsRef = useRef(null);
	const context = useMemo(() => ({
		disabled,
		formattingToolsRef,
		required,
		fileDraggedOver: fileHandler?.isDraggedOver ?? false,
		fileUploadProgress: fileHandler?.uploadProgress,
		uploadButtonProps: fileHandler?.clickTargetProps ?? null,
		errorMessage: fileHandler?.errorMessage,
		previewMode: viewMode === "preview"
	}), [
		disabled,
		required,
		fileHandler?.isDraggedOver,
		fileHandler?.uploadProgress,
		fileHandler?.clickTargetProps,
		fileHandler?.errorMessage,
		viewMode
	]);
	const onViewSelect = (mode) => {
		sendEvent(`markdown_editor.select_view`, {
			mode,
			["from_mode"]: viewMode,
			["trigger"]: "view_switcher",
			["did_change"]: viewMode !== mode,
			["feature_flag_markdown_experience_hybrid_editor"]: hybridEditorEnabled
		});
		onChangeViewMode?.(mode);
	};
	const viewSwitch = /* @__PURE__ */ jsx(ViewSwitch, {
		selectedView: viewMode,
		onViewSelect,
		disabled: fileHandler?.uploadProgress !== void 0,
		onLoadPreview: loadPreview
	});
	return /* @__PURE__ */ jsxs(MarkdownEditorContext, {
		value: context,
		children: [
			/* @__PURE__ */ jsx(FormattingTools, {
				ref: formattingToolsRef,
				forInputId: id
			}),
			/* @__PURE__ */ jsxs("div", {
				className: clsx(className, viewMode === "edit" ? MarkdownEditor_module_default.inputWrapper : MarkdownEditor_module_default.previewWrapper, disabled && MarkdownEditor_module_default.disabled, fullHeight && MarkdownEditor_module_default.fullHeight),
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: MarkdownEditor_module_default.header,
						children: [
							!toolbarRedesignEnabled && /* @__PURE__ */ jsx("div", {
								className: MarkdownEditor_module_default.viewSwitchWrapper,
								children: viewSwitch
							}),
							/* @__PURE__ */ jsx(SavedRepliesContext, {
								value: savedRepliesContext,
								children: viewMode === "edit" ? slots.toolbar ?? /* @__PURE__ */ jsx(CoreToolbar, { children: /* @__PURE__ */ jsx(DefaultToolbarButtons, {}) }) : /* @__PURE__ */ jsx("div", { style: { flex: 1 } })
							}),
							toolbarRedesignEnabled && /* @__PURE__ */ jsx("div", {
								className: MarkdownEditor_module_default.redesignedViewSwitchWrapper,
								children: viewSwitch
							})
						]
					}),
					/* @__PURE__ */ jsx(MarkdownInput, {
						value,
						onChange: !useOnInput ? onInputChange : void 0,
						onInput: useOnInput ? onInputChange : void 0,
						onFocus: onInputFocus,
						emojiSuggestions,
						emojiTone,
						mentionSuggestions,
						referenceSuggestions,
						disabled,
						placeholder,
						labelledBy,
						"aria-describedby": describedBy,
						id,
						maxLength,
						ref: inputRef,
						fullHeight,
						isDraggedOver: fileHandler?.isDraggedOver ?? false,
						minHeightLines,
						maxHeightLines,
						visible: viewMode === "edit",
						monospace,
						required,
						name,
						pasteUrlsAsPlainText,
						generatingText,
						...inputCompositionProps,
						...fileHandler?.pasteTargetProps,
						...fileHandler?.dropTargetProps
					}, inputKey),
					viewMode === "edit" && fileHandler?.errorMessage ? /* @__PURE__ */ jsx(ErrorBanner, { children: fileHandler.errorMessage }) : banner,
					viewMode === "preview" && /* @__PURE__ */ jsxs("div", {
						"aria-live": "polite",
						tabIndex: -1,
						className: clsx(MarkdownEditor_module_default.previewViewerWrapper, fullHeight && MarkdownEditor_module_default.fullHeight),
						style: { minHeight: inputHeight },
						children: [/* @__PURE__ */ jsx("h2", {
							className: MarkdownEditor_module_default.previewHeader,
							children: "Rendered Markdown Preview"
						}), /* @__PURE__ */ jsx(MarkdownViewer, {
							verifiedHTML: html || "Nothing to preview",
							loading: html === null,
							teamHovercardsEnabled,
							openLinksInNewTab: true
						})]
					})
				]
			}),
			footer
		]
	});
};
ClassicMarkdownEditor.displayName = "ClassicMarkdownEditor";
var HybridMarkdownEditorWithFooter = ({ ref, hybridEditorProps, ...props }) => {
	const { footer, banner, generatingText, ...markdownEditorProps } = props;
	const context = useMemo(() => ({
		disabled: props.disabled ?? false,
		required: props.required ?? false,
		formattingToolsRef: { current: null },
		uploadButtonProps: null,
		fileDraggedOver: false,
		previewMode: false
	}), [props.disabled, props.required]);
	const hybridEditorRef = useRef(null);
	useImperativeHandle(ref, () => ({
		focus: () => hybridEditorRef.current?.focus(),
		moveCursorToEnd: () => hybridEditorRef.current?.moveCursorToEnd(),
		reset: () => hybridEditorRef.current?.reset(),
		scrollIntoView: (opts) => hybridEditorRef.current?.scrollIntoView(opts),
		get inputRef() {
			return hybridEditorRef.current?.containerRef ?? { current: null };
		},
		[handleBrand]: void 0
	}));
	return /* @__PURE__ */ jsxs(MarkdownEditorContext, {
		value: context,
		children: [/* @__PURE__ */ jsx(HybridMarkdownEditor, {
			ref: hybridEditorRef,
			...markdownEditorProps,
			...hybridEditorProps,
			isGenerating: generatingText,
			banner
		}), footer]
	});
};
HybridMarkdownEditorWithFooter.displayName = "HybridMarkdownEditorWithFooter";
var MarkdownEditor$1 = ({ ref, ...props }) => {
	const { disabled = false, "aria-describedby": describedBy, fullHeight, viewMode: controlledViewMode, onChangeViewMode: controlledSetViewMode, children } = props;
	const [slots, childrenWithoutSlots] = useSlots(children, {
		toolbar: Toolbar,
		actions: Actions,
		label: Label,
		footer: Footer
	});
	const [uncontrolledViewMode, setUncontrolledViewMode] = useState("edit");
	const [viewMode, onChangeViewMode] = controlledViewMode === void 0 ? [uncontrolledViewMode, setUncontrolledViewMode] : [controlledViewMode, controlledSetViewMode];
	const editorType = getEditorType(viewMode);
	const descriptionId = useId();
	const commonProps = {
		footer: slots.footer ?? /* @__PURE__ */ jsx(CoreFooter, { children: isValidElement(slots.actions) && slots.actions.props.children }),
		"aria-describedby": describedBy ? `${descriptionId} ${describedBy}` : descriptionId
	};
	useEffect(() => sendEvent("markdown_editor.mount", {
		editorType,
		["feature_flag_markdown_experience_hybrid_editor"]: isFeatureEnabled("markdown_experience_hybrid_editor")
	}), [editorType]);
	const containerRef = useRef(null);
	const editor = editorType === "hybrid" ? /* @__PURE__ */ jsx(HybridMarkdownEditorWithFooter, {
		...props,
		ref,
		onChangeViewMode,
		...commonProps
	}) : /* @__PURE__ */ jsx(ClassicMarkdownEditor, {
		...props,
		viewMode: viewMode === "hybrid" ? "edit" : viewMode,
		onChangeViewMode,
		ref,
		containerRef,
		...commonProps,
		children: slots.toolbar
	});
	return /* @__PURE__ */ jsxs("fieldset", {
		"aria-disabled": disabled,
		className: clsx(MarkdownEditor_module_default.fieldSet, fullHeight && MarkdownEditor_module_default.fullHeight),
		children: [
			/* @__PURE__ */ jsx("div", {
				className: MarkdownEditor_module_default.hidden,
				children: childrenWithoutSlots
			}),
			slots.label,
			/* @__PURE__ */ jsxs("div", {
				ref: containerRef,
				className: MarkdownEditor_module_default.container,
				children: [/* @__PURE__ */ jsx("span", {
					className: "sr-only",
					id: descriptionId,
					"aria-live": "polite",
					children: `Markdown input: ${viewMode === "hybrid" ? "hybrid mode selected." : viewMode === "preview" ? " preview mode selected." : " edit mode selected."}`
				}), editor]
			})
		]
	});
};
MarkdownEditor$1.displayName = "MarkdownEditor";
var MarkdownEditor = Object.assign(MarkdownEditor$1, {
	Label,
	Toolbar,
	ToolbarButton,
	DefaultToolbarButtons,
	Footer,
	FooterButton,
	Actions,
	ActionButton,
	ErrorBanner,
	MarkdownEditorContext
});
var DEFAULT_VIEWER_SETTINGS = {
	emojiTone: 0,
	pasteUrlsAsPlainText: false,
	useMonospaceFont: false
};
var globalCache = /* @__PURE__ */ new Map();
var STORAGE_KEY = "user.preferences.viewer-settings";
/**
* If you get an error like
*
* [MSW] Warning: intercepted a request without a matching request handler:
*   • GET /settings/appearance/viewer-settings
*
* in a test that renders the markdown editor, rather than adding an msw handler
* for this URL, you may want to consider just mocking the `useViewerSettings` hook
* altogether, unless you're looking to test its actual functionality.
* Due to the module-level cache, and the local storage in this implementation,
* coming up with a mock, and properly waiting for the fetch to complete led
* to complexity in the tests, so the recommended solution is to just mock the hook:
*
* vi.mock('@github-ui/use-viewer-settings', () => ({
*   useViewerSettings: vi.fn(),
* }))
*
* const mockUseViewerSettings = vi.mocked(useViewerSettings)
* ...
* mockUseViewerSettings.mockReturnValue({
*   settings: {
*     emojiTone: 0,
*     pasteUrlsAsPlainText: false,
*     useMonospaceFont: false,
*   },
*   loading: false,
*   error: false,
* })
*/
var VIEWER_SETTINGS_ENDPOINT = "/settings/appearance/viewer-settings";
/**
* Validates and extracts viewer settings from a response payload
*/
function extractViewerSettings(payload) {
	if (!payload || typeof payload !== "object") return null;
	const data = payload;
	const emojiTone = typeof data.emojiTone === "number" ? data.emojiTone : DEFAULT_VIEWER_SETTINGS.emojiTone;
	const pasteUrlsAsPlainText = typeof data.pasteUrlsAsPlainText === "boolean" ? data.pasteUrlsAsPlainText : DEFAULT_VIEWER_SETTINGS.pasteUrlsAsPlainText;
	const useMonospaceFont = typeof data.useMonospaceFont === "boolean" ? data.useMonospaceFont : DEFAULT_VIEWER_SETTINGS.useMonospaceFont;
	if (data.emojiTone !== void 0 || data.pasteUrlsAsPlainText !== void 0 || data.useMonospaceFont !== void 0) return {
		emojiTone,
		pasteUrlsAsPlainText,
		useMonospaceFont
	};
	return null;
}
/**
* Fetches viewer settings from the server
*/
async function fetchViewerSettings() {
	try {
		const response = await reactFetchJSON(VIEWER_SETTINGS_ENDPOINT);
		if (!response.ok) throw new Error(`HTTP ${response.status}`);
		const extractedSettings = extractViewerSettings(await response.json());
		if (!extractedSettings) throw new Error("Invalid response payload");
		return extractedSettings;
	} catch (error) {
		throw error;
	}
}
/**
* Hook to retrieve viewer settings with caching and local storage persistence
*
* Features:
* - Makes only one network request for the entire app lifetime
* - Persists settings in local storage
* - Returns cached data on subsequent calls
* - Falls back to cached data or defaults on network failures
*/
function useViewerSettings(clearGlobalCache = false) {
	const [cachedSettings, setCachedSettings] = useLocalStorage(STORAGE_KEY, null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(false);
	const hasFetchedRef = useRef(false);
	if (clearGlobalCache) {
		globalCache.clear();
		hasFetchedRef.current = false;
	}
	const fetchData = useCallback(async () => {
		let fetchPromise = globalCache.get(VIEWER_SETTINGS_ENDPOINT);
		try {
			if (!fetchPromise) {
				fetchPromise = fetchViewerSettings();
				globalCache.set(VIEWER_SETTINGS_ENDPOINT, fetchPromise);
			}
			setCachedSettings(await fetchPromise);
			setError(false);
		} catch {
			setError(true);
		} finally {
			setLoading(false);
		}
	}, [setCachedSettings]);
	useEffect(() => {
		if (!hasFetchedRef.current) {
			hasFetchedRef.current = true;
			fetchData();
		} else setLoading(false);
	}, [fetchData]);
	return {
		settings: cachedSettings || DEFAULT_VIEWER_SETTINGS,
		loading,
		error: error && !cachedSettings
	};
}
var markdownPrefix = "```suggestion";
var markdownSuffix = "```";
/**
* Inserts the suggested change backticks + original line into the comment box's markdown editor
* Moves cursor to end of suggested change line
*
* @param onChange - function that changes the body of the comment box's markdown editor
* @param inputValue - the current value of the comment box markdown editor, used to determine where to insert the suggestion
* @param sourceContentFromDiffLines - the lines from the diff to insert as a suggestion
* @param onInsertSuggestedChange - function called when the suggestion block is inserted
* @param shouldInsertSuggestionOnRender - boolean indicating whether to auto insert the suggested change lines (invoked by context menu)
* @param editorRef - ref to the markdown editor's input
*/
function AddSuggestionButton({ onChange, inputValue, sourceContentFromDiffLines, onInsertSuggestedChange, shouldInsertSuggestionOnRender, editorRef }) {
	const suggestion = `${markdownPrefix}\n${sourceContentFromDiffLines ?? ""}\n${markdownSuffix}`;
	const insertSuggestion = () => {
		onInsertSuggestedChange();
		editorRef.current?.focus();
		const updatedMarkdownBody = inputValue === "" ? suggestion : `${inputValue}\n${suggestion}`;
		flushSync(() => {
			onChange(updatedMarkdownBody);
		});
		const activeElement = document.activeElement;
		if (!activeElement || !(activeElement instanceof HTMLTextAreaElement)) return;
		const endOfSuggestedChangeLine = updatedMarkdownBody.length - 3;
		activeElement.selectionStart = endOfSuggestedChangeLine - 1;
		activeElement.selectionEnd = endOfSuggestedChangeLine - 1;
	};
	useEffect(() => {
		if (shouldInsertSuggestionOnRender) {
			const timeout = window.setTimeout(() => insertSuggestion());
			return () => {
				window.clearTimeout(timeout);
			};
		}
	}, []);
	return /* @__PURE__ */ jsx(MarkdownEditor.ToolbarButton, {
		icon: FileDiffIcon,
		"aria-label": "Add a suggestion",
		onClick: insertSuggestion
	});
}
/**
* Create a config object for a custom toolbar button in the hybrid editor (this must be separate because the
* hybrid editor uses the CodeMirror API and also doesn't support slots).
*
* NOTE: In the hybrid editor, we do not currently support auto-adding the suggestion on render.
*/
AddSuggestionButton.displayName = "AddSuggestionButton";
function HybridAddSuggestionButton(props) {
	const { sourceContentFromDiffLines } = props;
	return /* @__PURE__ */ jsx(HybridMarkdownEditor.ToolbarButton, {
		telemetryId: "add_suggestion",
		icon: FileDiffIcon,
		"aria-label": "Add a suggestion",
		onClick: (view) => {
			const suggestion = `${markdownPrefix}\n${sourceContentFromDiffLines ?? ""}\n${markdownSuffix}`;
			const insertion = view.state.doc.length === 0 ? suggestion : `\n${suggestion}`;
			view.dispatch({
				changes: [{
					from: view.state.doc.length,
					insert: insertion
				}],
				selection: { anchor: view.state.doc.length + insertion.length - 3 - 1 }
			});
			return true;
		}
	});
}
HybridAddSuggestionButton.displayName = "HybridAddSuggestionButton";
/**
* Fetches a markdown preview for the given text.
* We can brand the returned html as a SafeHTMLString because it is generated
* by GitHub and we trust it.
*/
async function tryGetPreview({ text, issue, repository, project, subjectType, path, lineNumber, startCommitOid, endCommitOid, baseCommitOid, subject, startLineNumber }) {
	const formData = new FormData();
	formData.append("text", text);
	formData.append("issue", issue);
	formData.append("repository", repository);
	formData.append("project", project);
	if (path) formData.append("path", path);
	if (lineNumber) formData.append("line_number", lineNumber.toString());
	if (startCommitOid) formData.append("start_commit_oid", startCommitOid);
	if (endCommitOid) formData.append("end_commit_oid", endCommitOid);
	if (baseCommitOid) formData.append("base_commit_oid", baseCommitOid);
	if (subject) formData.append("subject", subject.toString());
	if (startLineNumber) formData.append("start_line_number", startLineNumber.toString());
	if (subjectType) formData.append("subject_type", subjectType);
	const response = await verifiedFetch("/preview", {
		body: formData,
		method: "POST"
	});
	if (!response.ok) return Promise.resolve("Markdown preview unavailable");
	const htmlText = await response.text();
	return Promise.resolve(htmlText);
}
function useGetPreview(t0) {
	const $ = c(11);
	const { subjectId, subjectType, subject, subjectRepoId, lineNumber, path, startCommitOid, startLineNumber, endCommitOid, baseCommitOid } = t0;
	let t1;
	if ($[0] !== baseCommitOid || $[1] !== endCommitOid || $[2] !== lineNumber || $[3] !== path || $[4] !== startCommitOid || $[5] !== startLineNumber || $[6] !== subject || $[7] !== subjectId || $[8] !== subjectRepoId || $[9] !== subjectType) {
		t1 = async (body) => tryGetPreview({
			text: body,
			issue: subjectId?.toString() ?? "",
			repository: subjectRepoId?.toString() ?? "",
			project: subjectId?.toString() ?? "",
			subjectType: resolvePreviewSubjectType(subjectType),
			subject,
			lineNumber,
			path,
			startCommitOid,
			endCommitOid,
			baseCommitOid,
			startLineNumber
		});
		$[0] = baseCommitOid;
		$[1] = endCommitOid;
		$[2] = lineNumber;
		$[3] = path;
		$[4] = startCommitOid;
		$[5] = startLineNumber;
		$[6] = subject;
		$[7] = subjectId;
		$[8] = subjectRepoId;
		$[9] = subjectType;
		$[10] = t1;
	} else t1 = $[10];
	return t1;
}
function resolvePreviewSubjectType(subjectType) {
	switch (subjectType) {
		case "issue": return "Issue";
		case "pull_request": return "PullRequest";
		case "project": return "Project";
		default: return;
	}
}
var ApiMarkdownSubject = { fromPropsSubject: (subject) => {
	if (!subject) return {};
	if (subject.type === "project") return {
		subjectId: subject.id?.databaseId?.toString(),
		subjectType: subject.type
	};
	return {
		subjectId: subject.id?.databaseId?.toString() ?? subject.id?.id,
		subjectRepoId: subject.repository.databaseId,
		subjectType: subject.type === "issue_comment" ? "issue" : subject.type
	};
} };
var CommentBox_module_default = {
	commentBoxContainer: "CommentBox-module_RbCuaa_commentBoxContainer",
	staleContentWarning: "CommentBox-module_RbCuaa_staleContentWarning"
};
var CommentBoxButton$1 = MarkdownEditor.ActionButton;
function SaveButton({ onSave, validationResult, children, trailingIcon, disabled, size }) {
	const button = /* @__PURE__ */ jsx(CommentBoxButton$1, {
		variant: "primary",
		size,
		onClick: onSave,
		disabled: disabled || !validationResult.isValid,
		trailingVisual: trailingIcon && disabled ? AlertFillIcon : null,
		children
	});
	return validationResult.isValid ? button : /* @__PURE__ */ jsx(Tooltip, {
		text: validationResult.errorMessage,
		direction: "w",
		"data-testid": "save-button-tooltip",
		children: button
	});
}
SaveButton.displayName = "SaveButton";
var SlashCommandsProvider_module_default = { slashCommandContainer: "SlashCommandsProvider-module_PL_iaq_slashCommandContainer" };
var SlashCommandButtonContext = createContext(null);
SlashCommandButtonContext.displayName = "SlashCommandButtonContext";
function getSurface(subjectType) {
	switch (subjectType) {
		case "issue_comment": return "issue_comment";
		case "issue": return "issue_body";
		case "pull_request": return "pull_request";
		case "commit": return "commit";
	}
}
var buildSlashCommandsUrl = (subject) => {
	let url = `/${subject.repository.nwo}/slash_apps?surface=${getSurface(subject.type)}`;
	if (subject.id) url += `&subject_gid=${subject.id.id}`;
	return url;
};
var SlashCommandsProvider = ({ children, subject, onInsertText, onSave }) => {
	const containerRef = useRef(null);
	const expanderRef = useRef(null);
	const [{ top, left }, setPosition] = useState({
		top: 0,
		left: 0
	});
	useEffect(() => {
		const container = containerRef.current;
		if (!container) return;
		let target = container?.querySelector("textarea");
		const position = {
			top: 0,
			left: 0
		};
		while (target !== container) {
			if (target === null) return;
			position.top += target.offsetTop;
			position.left += target.offsetLeft;
			target = target.offsetParent instanceof HTMLElement ? target.offsetParent : null;
		}
		setPosition(position);
	}, []);
	useEffect(() => {
		const expander = expanderRef.current;
		if (!expander) return;
		if (containerRef.current?.querySelector("textarea")) expander.reconnect?.();
		const handleFocus = () => {
			if (!expander.querySelector(".js-slash-command-menu:not(.d-none)")) expander.reconnect?.();
		};
		const textarea = containerRef.current?.querySelector("textarea");
		textarea?.addEventListener("focus", handleFocus);
		return () => {
			textarea?.removeEventListener("focus", handleFocus);
		};
	}, []);
	useEffect(() => {
		const expander_0 = expanderRef.current;
		if (!expander_0) return;
		let lastTextarea = containerRef.current?.querySelector("textarea") || null;
		const observer = new MutationObserver(() => {
			const currentTextarea = containerRef.current?.querySelector("textarea");
			if (currentTextarea && currentTextarea !== lastTextarea) {
				lastTextarea = currentTextarea;
				if (!expander_0.querySelector(".js-slash-command-menu:not(.d-none)")) expander_0.reconnect?.();
			}
		});
		if (containerRef.current) observer.observe(containerRef.current, {
			childList: true,
			subtree: true
		});
		return () => {
			observer.disconnect();
		};
	}, []);
	useEffect(() => {
		if (!onSave) return;
		const expander_1 = expanderRef.current;
		if (!expander_1) return;
		expander_1.addEventListener("request-submit", onSave);
		return () => {
			expander_1.removeEventListener("request-submit", onSave);
		};
	}, [onSave]);
	const contextValue = useMemo(() => ({ onInsertText }), [onInsertText]);
	return /* @__PURE__ */ jsx(Box, {
		ref: containerRef,
		sx: { "& .js-slash-command-menu": {
			mt: `${top}px`,
			ml: `${left}px`
		} },
		className: clsx("js-slash-command-surface", SlashCommandsProvider_module_default.slashCommandContainer),
		children: /* @__PURE__ */ jsx("slash-command-expander", {
			ref: expanderRef,
			keys: "/",
			"data-slash-command-url": buildSlashCommandsUrl(subject),
			children: /* @__PURE__ */ jsx(SlashCommandButtonContext, {
				value: contextValue,
				children
			})
		})
	});
};
SlashCommandsProvider.displayName = "SlashCommandsProvider";
var SlashCommandsButton = () => {
	const context = use(SlashCommandButtonContext);
	return context ? /* @__PURE__ */ jsx(MarkdownEditor.ToolbarButton, {
		icon: DiffIgnoredIcon,
		"aria-label": "Slash commands",
		onClick: () => context.onInsertText("/")
	}) : null;
};
SlashCommandsButton.displayName = "SlashCommandsButton";
var REGEX_STRINGS = { isFileUploading: /<!-- Uploading[\s\S]*?-->/ };
var strings_default = {
	staleContentError: "The content you are editing has changed. Please copy your edits and exit the editor.",
	leaveCommentLabel: "Leave a comment"
};
/**
* Given an async callback function, cache the results until the function reference changes.
* IMPORTANT: The function must be wrapped with `useCallback`.
*/
function useCachedRequest(request) {
	const $ = c(5);
	const promise = useRef(void 0);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			if (promise.current) promise.current = void 0;
		};
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== request) {
		t1 = [request];
		$[1] = request;
		$[2] = t1;
	} else t1 = $[2];
	useEffect(t0, t1);
	let t2;
	if ($[3] !== request) {
		t2 = () => {
			if (!promise.current) promise.current = request();
			return promise.current;
		};
		$[3] = request;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
async function tryGetSavedReplies(savedRepliesContext) {
	try {
		return (await (await verifiedFetchJSON(`/settings/replies${savedRepliesContext ? `?context=${savedRepliesContext}` : ""}`)).json()).map((reply) => ({
			name: reply.title,
			content: reply.body
		}));
	} catch {
		return [];
	}
}
function useGetSavedReplies(t0) {
	const $ = c(2);
	const { subjectType } = t0;
	let t1;
	if ($[0] !== subjectType) {
		t1 = () => {
			return tryGetSavedReplies(subjectType === "issue" || subjectType === "pull_request" ? subjectType : void 0);
		};
		$[0] = subjectType;
		$[1] = t1;
	} else t1 = $[1];
	return useCachedRequest(t1);
}
async function getSuggestedMentions({ subjectId, subjectType, subjectRepoId }) {
	const subjectIdParam = subjectId ? `/${subjectId}` : "";
	let queryParams = `?mention_suggester=1&user_avatar=1`;
	queryParams = subjectRepoId ? `${queryParams}&repository_id=${subjectRepoId}` : queryParams;
	return await (await verifiedFetchJSON(`/suggestions/${subjectType}${subjectIdParam}${queryParams}`, { method: "GET" })).json();
}
function isUserMention(mention) {
	return "login" in mention;
}
async function tryGetMentions(request) {
	try {
		return (await getSuggestedMentions(request)).map((mention) => {
			if (isUserMention(mention)) return {
				description: mention.name,
				identifier: mention.login,
				avatarUrl: mention.avatarUrl,
				participant: mention.participant
			};
			else return {
				description: mention.description,
				identifier: mention.name,
				avatarUrl: mention.avatarUrl,
				participant: mention.participant
			};
		});
	} catch {
		return [];
	}
}
function useGetMentionSuggestions(t0) {
	const $ = c(4);
	const { subjectId, subjectType, subjectRepoId } = t0;
	let t1;
	if ($[0] !== subjectId || $[1] !== subjectRepoId || $[2] !== subjectType) {
		t1 = () => {
			if (!subjectType || subjectType !== "project" && !subjectRepoId) return Promise.resolve([]);
			return tryGetMentions({
				subjectId,
				subjectType,
				subjectRepoId
			});
		};
		$[0] = subjectId;
		$[1] = subjectRepoId;
		$[2] = subjectType;
		$[3] = t1;
	} else t1 = $[3];
	return useCachedRequest(t1);
}
async function getSuggestedReferences({ subjectId, subjectType, subjectRepoId }) {
	return await (await verifiedFetchJSON(`/suggestions/${subjectType}${subjectId ? `/${subjectId}` : ""}?issue_suggester=1&repository_id=${subjectRepoId}`, { method: "GET" })).json();
}
async function tryGetReferences(request) {
	try {
		const referenceData = await getSuggestedReferences(request);
		const iconMap = referenceData.icons;
		return referenceData.suggestions.map((reference) => ({
			id: reference.number.toString(),
			titleText: reference.title,
			titleHtml: reference.title,
			iconHtml: iconMap[reference.type]
		}));
	} catch {
		return [];
	}
}
function useGetReferenceSuggestions(t0) {
	const $ = c(4);
	const { subjectId, subjectType, subjectRepoId } = t0;
	let t1;
	if ($[0] !== subjectId || $[1] !== subjectRepoId || $[2] !== subjectType) {
		t1 = async () => {
			if (!subjectType || !subjectRepoId) return Promise.resolve([]);
			return tryGetReferences({
				subjectId,
				subjectType,
				subjectRepoId
			});
		};
		$[0] = subjectId;
		$[1] = subjectRepoId;
		$[2] = subjectType;
		$[3] = t1;
	} else t1 = $[3];
	return useCachedRequest(t1);
}
var emptySuggestionData = {
	mentions: "loading",
	references: "loading",
	savedReplies: []
};
function useMarkdownSuggestions(t0, loadSuggestions) {
	const $ = c(12);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const apiSubject = t1;
	const isMounted = useIsMounted();
	const getMentionSuggestions = useGetMentionSuggestions(apiSubject);
	const getReferenceSuggestions = useGetReferenceSuggestions(apiSubject);
	const getSavedReplies = useGetSavedReplies(apiSubject);
	const [data, setData] = useState(emptySuggestionData);
	let t2;
	let t3;
	if ($[2] !== getMentionSuggestions || $[3] !== getReferenceSuggestions || $[4] !== getSavedReplies || $[5] !== isMounted || $[6] !== loadSuggestions) {
		t2 = () => {
			const fetchSuggestions = async () => {
				const [mentions, references, savedReplies] = await Promise.all([
					getMentionSuggestions(),
					getReferenceSuggestions(),
					getSavedReplies()
				]);
				if (isMounted() && (mentions.length || references.length || savedReplies.length)) setData({
					mentions,
					references,
					savedReplies
				});
			};
			if (!loadSuggestions) return;
			fetchSuggestions();
		};
		t3 = [
			getMentionSuggestions,
			getReferenceSuggestions,
			getSavedReplies,
			isMounted,
			loadSuggestions
		];
		$[2] = getMentionSuggestions;
		$[3] = getReferenceSuggestions;
		$[4] = getSavedReplies;
		$[5] = isMounted;
		$[6] = loadSuggestions;
		$[7] = t2;
		$[8] = t3;
	} else {
		t2 = $[7];
		t3 = $[8];
	}
	useEffect(t2, t3);
	const emojiSuggestionsQuery = useEmojisQuery(loadSuggestions);
	const t4 = emojiSuggestionsQuery.isPending ? "loading" : emojiSuggestionsQuery.data ?? defaultEmojisData;
	let t5;
	if ($[9] !== data || $[10] !== t4) {
		t5 = {
			...data,
			emojis: t4
		};
		$[9] = data;
		$[10] = t4;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
}
var defaultEmojisData = [];
var CommentBoxButton = MarkdownEditor.ActionButton;
var DEFAULT_VIEW_KEY = "comment_box_last_view_mode";
var getMarkdownEditorDefaultViewMode = () => {
	const safeLocalStorage = safeStorage("localStorage");
	if (isFeatureEnabled("markdown_experience_hybrid_editor")) return safeLocalStorage.getItem(DEFAULT_VIEW_KEY) ?? "hybrid";
	return "edit";
};
var safeLocalStorage = safeStorage("localStorage");
var extractActionsFromFragment = (actionNode) => {
	if (isValidElement(actionNode) && typeof actionNode === "object" && typeof actionNode.type === "symbol" && String(actionNode.type) === "Symbol(react.fragment)") {
		const fragmentNode = actionNode;
		return Children.toArray(fragmentNode.props.children);
	}
	return Children.toArray(actionNode);
};
var CommentBox = ({ ref: forwardedRef, ["aria-describedby"]: ariaDescribedby, ["data-testid"]: testId, label, labelledBy, showLabel, disabled = false, subject, viewMode, onChangeViewMode, value, placeholder, onChange, onSave, onCancel, validationResult, saveButtonText = "Save", saveButtonTrailingIcon = true, actions, footerButtons, toolbarButtons, contentIsStale, fileUploadsEnabled = true, minHeightLines, maxHeightLines, className, onPrimaryAction, buttonSize, suggestedChangesConfig, markdownErrorMessage, infoBanner, teamHovercardsEnabled, setIsFileUploading, markdownSuggestionsFetchMethod = "lazy", lineNumber, filePath, startLineNumber, onInputFocus, generatingText }) => {
	const apiSubject = ApiMarkdownSubject.fromPropsSubject(subject);
	const projectId = subject?.type === "project" ? subject?.id?.databaseId.toString() : void 0;
	const [fetchSuggestions, setFetchSuggestions] = useState(markdownSuggestionsFetchMethod === "eager");
	const { mentions, references, emojis, savedReplies } = useMarkdownSuggestions(apiSubject, fetchSuggestions);
	const renderPreview = useGetPreview({
		...apiSubject,
		path: filePath,
		lineNumber,
		startCommitOid: subject?.type === "project" ? "" : subject?.comparison?.startCommitOid,
		startLineNumber,
		endCommitOid: subject?.type === "project" ? "" : subject?.comparison?.endCommitOid,
		baseCommitOid: subject?.type === "project" ? "" : subject?.comparison?.startCommitOid,
		subject: subject?.type === "project" ? void 0 : subject?.pullRequestNumber
	});
	const uploadFile = useUploadFile(apiSubject.subjectRepoId?.toString(), projectId);
	const { isBrowser } = useRuntimeEnvironment();
	const defaultViewMode = useMemo(() => isBrowser ? getMarkdownEditorDefaultViewMode() : "edit", [isBrowser]);
	const [currentViewMode, setCurrentViewMode] = useState(viewMode ?? defaultViewMode);
	const [showContentIsStaleWarning, setShowContentIsStaleWarning] = useState(false);
	const ref = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef ?? null, ref);
	const warningRef = useRef(null);
	const isRepoSubject = subject !== void 0 && "repository" in subject && subject.repository !== void 0;
	const isRepoSlashCommandEnabled = isRepoSubject && subject.repository.slashCommandsEnabled;
	const [shouldInsertSuggestedChangeOnRender, setShouldInsertSuggestedChangeOnRender] = useState(suggestedChangesConfig?.shouldInsertSuggestedChange ?? false);
	useEffect(() => {
		setShowContentIsStaleWarning(contentIsStale ?? false);
		return () => {
			setShowContentIsStaleWarning(false);
		};
	}, [contentIsStale]);
	const onSaveAction = useMemo(() => {
		if (showContentIsStaleWarning) return noop$1;
		return () => {
			onSave?.();
			setCurrentViewMode(defaultViewMode);
		};
	}, [
		onSave,
		showContentIsStaleWarning,
		defaultViewMode
	]);
	useEffect(() => {
		setCurrentViewMode(defaultViewMode);
	}, [
		apiSubject.subjectRepoId,
		apiSubject.subjectId,
		defaultViewMode
	]);
	useEffect(() => {
		if (viewMode) setCurrentViewMode(viewMode);
	}, [viewMode]);
	const onChangeViewModeInternal = useCallback((v) => {
		setCurrentViewMode(v);
		if (isFeatureEnabled("markdown_experience_hybrid_editor")) safeLocalStorage.setItem(DEFAULT_VIEW_KEY, v === "preview" ? "edit" : v);
		onChangeViewMode?.(v);
	}, [onChangeViewMode]);
	const onInsertText = useCallback((text) => {
		ref.current?.focus();
		try {
			document.execCommand("insertText", false, text);
		} catch {}
	}, [ref]);
	const onActive = useCallback(() => {
		if (markdownSuggestionsFetchMethod === "lazy" && !fetchSuggestions) setFetchSuggestions(true);
		onInputFocus?.();
	}, [
		fetchSuggestions,
		markdownSuggestionsFetchMethod,
		onInputFocus
	]);
	if (showContentIsStaleWarning && warningRef.current !== null && window.scrollY > 173) warningRef.current.scrollIntoView();
	const isUploadingFiles = useMemo(() => REGEX_STRINGS.isFileUploading.test(value), [value]);
	useEffect(() => {
		if (setIsFileUploading) setIsFileUploading(isUploadingFiles);
	}, [isUploadingFiles, setIsFileUploading]);
	const addDisabledPropToActions = useMemo(() => (actionsNode) => {
		return extractActionsFromFragment(actionsNode).map((action, index) => isValidElement(action) ? cloneElement(action, {
			key: index,
			disabled: disabled || isUploadingFiles
		}) : action);
	}, [disabled, isUploadingFiles]);
	const viewerSettings = useViewerSettings(false);
	const editor = /* @__PURE__ */ jsxs(Fragment$1, { children: [showContentIsStaleWarning && /* @__PURE__ */ jsx(Flash, {
		ref: warningRef,
		variant: "danger",
		className: CommentBox_module_default.staleContentWarning,
		children: strings_default.staleContentError
	}), /* @__PURE__ */ jsxs(MarkdownEditor, {
		"aria-describedby": ariaDescribedby,
		labelledBy,
		disabled,
		value,
		placeholder: placeholder !== void 0 ? placeholder : strings_default.leaveCommentLabel,
		emojiSuggestions: emojis,
		emojiTone: viewerSettings.settings.emojiTone,
		mentionSuggestions: mentions,
		referenceSuggestions: references,
		viewMode: currentViewMode,
		onChangeViewMode: onChangeViewModeInternal,
		onChange,
		onInputFocus: onActive,
		onRenderPreview: renderPreview,
		onUploadFile: fileUploadsEnabled ? uploadFile : void 0,
		acceptedFileTypes: fileUploadsEnabled ? acceptedFileTypes(isRepoSubject) : void 0,
		onPrimaryAction: () => {
			onSaveAction();
			onPrimaryAction?.();
		},
		ref,
		pasteUrlsAsPlainText: viewerSettings.settings.pasteUrlsAsPlainText,
		savedReplies,
		monospace: viewerSettings.settings.useMonospaceFont,
		minHeightLines,
		maxHeightLines,
		className,
		teamHovercardsEnabled,
		onSavedRepliesOpen: onActive,
		banner: markdownErrorMessage ? /* @__PURE__ */ jsx(MarkdownEditor.ErrorBanner, { children: markdownErrorMessage }) : infoBanner,
		generatingText,
		hybridEditorProps: suggestedChangesConfig?.showSuggestChangesButton || toolbarButtons ? { customToolbarButtons: /* @__PURE__ */ jsxs(Fragment$1, { children: [toolbarButtons, suggestedChangesConfig?.showSuggestChangesButton && /* @__PURE__ */ jsx(HybridAddSuggestionButton, { sourceContentFromDiffLines: suggestedChangesConfig?.sourceContentFromDiffLines })] }) } : void 0,
		children: [
			/* @__PURE__ */ jsx(MarkdownEditor.Label, {
				visuallyHidden: !showLabel,
				children: label ?? "Markdown Editor"
			}),
			/* @__PURE__ */ jsxs(MarkdownEditor.Actions, { children: [
				addDisabledPropToActions(actions),
				onCancel && /* @__PURE__ */ jsx(MarkdownEditor.ActionButton, {
					variant: "default",
					size: buttonSize,
					onClick: onCancel,
					value: "Cancel",
					children: "Cancel"
				}),
				onSaveAction && validationResult && /* @__PURE__ */ jsx(SaveButton, {
					onSave: onSaveAction,
					validationResult,
					trailingIcon: saveButtonTrailingIcon,
					disabled: disabled || isUploadingFiles,
					size: buttonSize,
					children: saveButtonText
				})
			] }),
			/* @__PURE__ */ jsxs(MarkdownEditor.Toolbar, { children: [
				suggestedChangesConfig?.showSuggestChangesButton && /* @__PURE__ */ jsx(AddSuggestionButton, {
					shouldInsertSuggestionOnRender: shouldInsertSuggestedChangeOnRender,
					inputValue: value,
					onChange,
					sourceContentFromDiffLines: suggestedChangesConfig?.sourceContentFromDiffLines,
					editorRef: ref,
					onInsertSuggestedChange: () => {
						suggestedChangesConfig?.onInsertSuggestedChange();
						setShouldInsertSuggestedChangeOnRender(false);
					}
				}),
				toolbarButtons,
				/* @__PURE__ */ jsx(MarkdownEditor.DefaultToolbarButtons, {}),
				/* @__PURE__ */ jsx(SlashCommandsButton, {})
			] }),
			footerButtons && /* @__PURE__ */ jsx(MarkdownEditor.Footer, { children: footerButtons })
		]
	})] });
	return /* @__PURE__ */ jsx("div", {
		"data-testid": testId,
		className: CommentBox_module_default.commentBoxContainer,
		children: isRepoSlashCommandEnabled ? /* @__PURE__ */ jsx(SlashCommandsProvider, {
			subject,
			onInsertText,
			onSave: onSaveAction,
			children: editor
		}) : editor
	});
};
CommentBox.displayName = "CommentBox";
CommentBox.displayName = "CommentBox";
var VALIDATOR_VALUES = {
	maxBodyLength: 65536,
	maxIssueTitleLength: 256,
	maxViewTitleLength: 1024
};
var VALIDATORS = {
	...VALIDATOR_VALUES,
	titleCanNotBeEmpty: "Title can not be empty",
	fieldCanNotBeEmpty: "Field can not be empty",
	fieldRequired: "This field is required",
	issueTitleExceedsMaxLength: `Title can not be longer than ${VALIDATOR_VALUES.maxIssueTitleLength} characters`,
	viewTitleExceedsMaxLength: `Title can not be longer than ${VALIDATOR_VALUES.maxViewTitleLength} characters`,
	issueBodyExceedsMaxLength: `Body can not be longer than ${VALIDATOR_VALUES.maxBodyLength} characters`,
	fieldExceedsMaxLength: `Field can not be longer than ${VALIDATOR_VALUES.maxBodyLength} characters`,
	commentBodyEmpty: "Comment can not be empty",
	checkboxInAGroupMustBeSelected: "A required checkbox is missing",
	missingDropdownSelection: "An option must be selected",
	noChangesToSave: "No changes to save"
};
function validateIssueTitle(title) {
	if (title.trim().length === 0) return {
		isValid: false,
		errorMessage: VALIDATORS.titleCanNotBeEmpty
	};
	else if (title.length > VALIDATORS.maxIssueTitleLength) return {
		isValid: false,
		errorMessage: VALIDATORS.issueTitleExceedsMaxLength
	};
	return { isValid: true };
}
function validateTextField(text, textEnforced) {
	if (text.trim().length === 0 && textEnforced) return {
		isValid: false,
		errorMessage: VALIDATORS.fieldCanNotBeEmpty
	};
	else if (text.length > VALIDATORS.maxBodyLength) return {
		isValid: false,
		errorMessage: VALIDATORS.fieldExceedsMaxLength
	};
	return { isValid: true };
}
function validateIssueBody(body) {
	if (body.length > VALIDATORS.maxBodyLength) return {
		isValid: false,
		errorMessage: VALIDATORS.issueBodyExceedsMaxLength
	};
	return { isValid: true };
}
function validateComment(body) {
	if (body.length === 0) return {
		isValid: false,
		errorMessage: VALIDATORS.commentBodyEmpty
	};
	return { isValid: true };
}
export { MarkdownEditor as a, listItemToString as c, useLinkInterception as d, useViewerSettings as f, validateTextField as g, validateIssueTitle as h, InputLabel as i, parseListItem as l, validateIssueBody as m, CommentBoxButton as n, MarkdownViewer as o, validateComment as p, CommentBoxButton$1 as r, VALIDATORS as s, CommentBox as t, useDynamicTextareaHeight as u };
