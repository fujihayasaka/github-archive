performance.mark("js-parse-end:server-repo-overview-CO-iH8G4-CeTaMz_z.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:repo-overview-CO-iH8G4.js");
var codeViewRepoOverviewServerFn_createServerFn_handler = createServerRpc({
	id: "5570a6dfaea5b5a8291c280a1b6bf2d11d3943232fdcb95f6ef940f99f19a782",
	name: "codeViewRepoOverviewServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => codeViewRepoOverviewServerFn.__executeServer(opts));
var codeViewRepoOverviewServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewRepoOverviewServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewRepoRoute");
});
var headerPartialServerFn_createServerFn_handler = createServerRpc({
	id: "11ecefba7033308c84e7125a569cd4e43612780a5a95ae1b856cf272e4dc792f",
	name: "headerPartialServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => headerPartialServerFn.__executeServer(opts));
var headerPartialServerFn = createServerFn().inputValidator(queryValidator.base).handler(headerPartialServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_codeViewRepoRoute.Header"
	});
});
var sidebarPartialServerFn_createServerFn_handler = createServerRpc({
	id: "7f955aae96327dca072e229ce256f7a4e6ffe65004b0cbf55e83efea5d9f703e",
	name: "sidebarPartialServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => sidebarPartialServerFn.__executeServer(opts));
var sidebarPartialServerFn = createServerFn().inputValidator(queryValidator.base).handler(sidebarPartialServerFn_createServerFn_handler, async ({ data }) => {
	if (isFeatureEnabled("react_data_router_code_view_sidebar")) return null;
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_codeViewRepoRoute.Sidebar"
	});
});
var recentlyTouchedBranchesServerFn_createServerFn_handler = createServerRpc({
	id: "209ee1152b7c97b2cb4358ec3ed1101afbfb79eb8d7415a7869d6e9ccacb308f",
	name: "recentlyTouchedBranchesServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => recentlyTouchedBranchesServerFn.__executeServer(opts));
var recentlyTouchedBranchesServerFn = createServerFn().inputValidator(queryValidator.base).handler(recentlyTouchedBranchesServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_recentlyTouchedBranches"
	});
});
var branchAndTagCountServerFn_createServerFn_handler = createServerRpc({
	id: "02b53bedb79ffba7123f46f6683fd076943a6c59c1fbc50fb98f29e4762fdce5",
	name: "branchAndTagCountServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => branchAndTagCountServerFn.__executeServer(opts));
var branchAndTagCountServerFn = createServerFn().inputValidator(queryValidator.base).handler(branchAndTagCountServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_branchAndTagCount"
	});
});
var aboutQueryServerFn_createServerFn_handler = createServerRpc({
	id: "ede11af01410f853c6f30f37d655e27965917c49dbbfa223a0a0f02152b2112c",
	name: "aboutQueryServerFn",
	filename: "src/routes/code-view/repo-overview.tsx"
}, (opts) => aboutQueryServerFn.__executeServer(opts));
var aboutQueryServerFn = createServerFn().inputValidator(queryValidator.base).handler(aboutQueryServerFn_createServerFn_handler, async ({ data }) => {
	if (isFeatureEnabled("react_data_router_code_view_sidebar")) return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_sidebarAbout"
	});
	return null;
});
export { aboutQueryServerFn_createServerFn_handler, branchAndTagCountServerFn_createServerFn_handler, codeViewRepoOverviewServerFn_createServerFn_handler, headerPartialServerFn_createServerFn_handler, recentlyTouchedBranchesServerFn_createServerFn_handler, sidebarPartialServerFn_createServerFn_handler };
