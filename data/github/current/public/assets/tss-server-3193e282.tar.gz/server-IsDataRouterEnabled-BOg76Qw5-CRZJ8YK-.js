import { createContext } from "react";
import { jsx } from "react/jsx-runtime";
var IsDataRouterEnabledContext = createContext(false);
IsDataRouterEnabledContext.displayName = "IsDataRouterEnabledContext";
function IsDataRouterEnabledContextProvider({ enabled, children }) {
	return /* @__PURE__ */ jsx(IsDataRouterEnabledContext, {
		value: enabled,
		children
	});
}
IsDataRouterEnabledContextProvider.displayName = "IsDataRouterEnabledContextProvider";
export { IsDataRouterEnabledContextProvider as n, IsDataRouterEnabledContext as t };
