performance.mark("js-parse-end:server-blame-YlGLOaEO-BTd4YQMo.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:blame-YlGLOaEO.js");
var codeViewBlameServerFn_createServerFn_handler = createServerRpc({
	id: "114d5388eb2fca2a18c6c57a9d2b1ab96be2fc0e35d9bde5632d3e85f658dcf2",
	name: "codeViewBlameServerFn",
	filename: "src/routes/code-view/blame.tsx"
}, (opts) => codeViewBlameServerFn.__executeServer(opts));
var codeViewBlameServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewBlameServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewBlameRoute");
});
var contributorsServerFn_createServerFn_handler = createServerRpc({
	id: "54cf7fcad24fb13d72cc3a43b3d405c09019149320a1716f6dbbc03c570651e7",
	name: "contributorsServerFn",
	filename: "src/routes/code-view/blame.tsx"
}, (opts) => contributorsServerFn.__executeServer(opts));
var contributorsServerFn = createServerFn().inputValidator(queryValidator.base).handler(contributorsServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_contributors"
	});
});
export { codeViewBlameServerFn_createServerFn_handler, contributorsServerFn_createServerFn_handler };
