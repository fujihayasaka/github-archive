import { r as notifyManager } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as createSafeIndexedDbPersister } from "./server-create-safe-indexed-db-storage-kOvHR5D8-Cy-3slle.js";
/**
* Fast deep equality comparison optimized for analytics use cases.
* Compares two values for deep structural equality with early exit optimizations.
*
* Performance characteristics:
* - O(1) for primitive equality (same reference, primitives)
* - O(n) for objects/arrays where n is the total number of nested properties
* - Fails fast on size mismatches and type differences
* - Handles circular references by tracking visited object pairs
*
* Circular references: Two objects with identical circular structure (e.g., obj1.self = obj1
* and obj2.self = obj2) are considered equal if their non-circular properties match.
*/
function fastDeepEqual(a, b) {
	return deepEqualWithTracking(a, b, /* @__PURE__ */ new Map());
}
function deepEqualWithTracking(a, b, visited) {
	if (a === b) return true;
	if (typeof a !== typeof b || a == null || b == null) return false;
	if (a instanceof Date && b instanceof Date) return a.getTime() === b.getTime();
	if (Array.isArray(a) && Array.isArray(b)) {
		if (visited.has(a)) {
			const visitedSet = visited.get(a);
			return visitedSet ? visitedSet.has(b) : false;
		}
		let visitedSet = visited.get(a);
		if (!visitedSet) {
			visitedSet = /* @__PURE__ */ new Set();
			visited.set(a, visitedSet);
		}
		visitedSet.add(b);
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) if (!deepEqualWithTracking(a[i], b[i], visited)) return false;
		return true;
	}
	if (typeof a === "object" && typeof b === "object") {
		if (!isPlainObject(a) || !isPlainObject(b)) return false;
		if (visited.has(a)) {
			const visitedSet = visited.get(a);
			return visitedSet ? visitedSet.has(b) : false;
		}
		let visitedSet = visited.get(a);
		if (!visitedSet) {
			visitedSet = /* @__PURE__ */ new Set();
			visited.set(a, visitedSet);
		}
		visitedSet.add(b);
		const keysA = Object.keys(a);
		const keysB = Object.keys(b);
		if (keysA.length !== keysB.length) return false;
		for (const key of keysA) {
			if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
			if (!deepEqualWithTracking(a[key], b[key], visited)) return false;
		}
		return true;
	}
	return false;
}
/**
* Check if a value is a plain object (not a class instance, array, etc.)
* Modified from: https://github.com/jonschlinkert/is-plain-object
*/
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const ctor = o.constructor;
	if (typeof ctor === "undefined") return true;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot) || !hasConstructorObjectSpecificMethod(prot)) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function hasConstructorObjectSpecificMethod(o) {
	return Object.prototype.hasOwnProperty.call(o, "isPrototypeOf");
}
var PERSISTER_KEY_PREFIX = "tanstack-query";
/**
* This utility function enables fine-grained query persistence.
* Simple add it as a `persister` parameter to `useQuery` or `defaultOptions` on `queryClient`.
*/
function createQueryPersister({ storage, sendAnalyticsEvent, maxAgeMs = 1e3 * 60 * 60 * 24, prefix = PERSISTER_KEY_PREFIX, refetchOnRestore = true }) {
	async function retrieveQuery(queryHash, afterRestoreMacroTask) {
		if (storage != null) {
			const storageKey = `${prefix}-${queryHash}`;
			try {
				const persistedQuery = await storage.getItem(storageKey);
				if (persistedQuery) {
					if (afterRestoreMacroTask) notifyManager.schedule(() => afterRestoreMacroTask(persistedQuery));
					return persistedQuery.state.data;
				}
			} catch {
				await storage.removeItem(storageKey);
			}
		}
	}
	async function persistQueryByKey(queryKey, queryClient) {
		if (storage != null) {
			const query = queryClient.getQueryCache().find({ queryKey });
			if (query) await persistQuery(query);
		}
	}
	async function persistQuery(query) {
		if (storage != null) {
			const storageKey = `${prefix}-${query.queryHash}`;
			storage.setItem(storageKey, {
				state: query.state,
				queryKey: query.queryKey,
				queryHash: query.queryHash
			}, query.state.dataUpdatedAt, maxAgeMs);
		}
	}
	async function persisterFn(queryFn, ctx, query) {
		const storageKey = `${prefix}-${query.queryHash}`;
		const isBackgroundRefresh = query.state.data !== void 0;
		const indexedDbStartTime = performance.now();
		if (query.state.data === void 0 && storage != null) {
			const restoredData = await retrieveQuery(query.queryHash, (persistedQuery) => {
				const indexedDbEndTime = performance.now();
				const indexeddb_duration_ms = Math.round(indexedDbEndTime - indexedDbStartTime);
				query.setState({ dataUpdatedAt: persistedQuery.state.dataUpdatedAt });
				const is_always_restore = refetchOnRestore === "always";
				const is_stale_data = refetchOnRestore === true && query.isStale();
				const analyticsPayload = {
					is_always_restore,
					is_stale_data,
					indexeddb_duration_ms
				};
				if (is_always_restore || is_stale_data) {
					const timedFetch = async () => {
						const cachedData = persistedQuery.state.data;
						const apiStartTime = performance.now();
						await query.fetch();
						const apiEndTime = performance.now();
						const serverData = query.state.data;
						let cached_data_matches_server;
						try {
							cached_data_matches_server = fastDeepEqual(cachedData, serverData);
						} catch {
							cached_data_matches_server = false;
						}
						sendAnalyticsEvent?.("offline_cache.stale_while_revalidate", storageKey, {
							...analyticsPayload,
							stale_visible_ms: Math.round(apiEndTime - indexedDbEndTime),
							api_duration_ms: Math.round(apiEndTime - apiStartTime),
							total_ms: Math.round(apiEndTime - indexedDbStartTime),
							cached_data_matches_server
						});
					};
					timedFetch();
				} else sendAnalyticsEvent?.("offline_cache.cache_hit", storageKey, analyticsPayload);
			});
			if (restoredData !== void 0) return Promise.resolve(restoredData);
		}
		const apiStartTime = performance.now();
		const queryFnResult = await queryFn(ctx);
		const api_duration_ms = Math.round(performance.now() - apiStartTime);
		if (!isBackgroundRefresh) sendAnalyticsEvent?.("offline_cache.cache_miss", storageKey, {
			api_duration_ms,
			total_ms: Math.round(performance.now() - indexedDbStartTime)
		});
		if (storage != null) notifyManager.schedule(() => {
			persistQuery(query);
		});
		return Promise.resolve(queryFnResult);
	}
	async function persisterGc() {
		if (storage?.entries) {
			const entries = await storage.entries();
			for (const [key, value] of entries) if (key.startsWith(prefix)) {
				const persistedQuery = value;
				if (storage.isBustedOrExpired(persistedQuery)) await storage.removeItem(key);
			}
		}
	}
	async function restoreQueries(queryClient) {
		if (storage?.entries) {
			const entries = await storage.entries();
			for (const [key, value] of entries) if (key.startsWith(prefix)) {
				const persistedQuery = value;
				if (storage.isBustedOrExpired(persistedQuery)) {
					await storage.removeItem(key);
					continue;
				}
				queryClient.setQueryData(persistedQuery.queryKey, persistedQuery.state.data, { updatedAt: persistedQuery.state.dataUpdatedAt });
			}
		}
	}
	return {
		persisterFn,
		persistQuery,
		persistQueryByKey,
		retrieveQuery,
		persisterGc,
		restoreQueries
	};
}
var THREE_DAYS = 1e3 * 60 * 60 * 24 * 3;
var noOpPersister = async (queryFn, context) => await queryFn(context);
var createPersister = ({ validator, sendAnalyticsEvent, prefix = "key", maxAgeMs = THREE_DAYS, alwaysRefetch = true, enabled = true }) => {
	if (!enabled) return noOpPersister;
	return createQueryPersister({
		storage: createSafeIndexedDbPersister({
			validator,
			sendAnalyticsEvent
		}),
		sendAnalyticsEvent,
		prefix,
		maxAgeMs,
		refetchOnRestore: alwaysRefetch ? "always" : true
	}).persisterFn;
};
export { createPersister as t };
