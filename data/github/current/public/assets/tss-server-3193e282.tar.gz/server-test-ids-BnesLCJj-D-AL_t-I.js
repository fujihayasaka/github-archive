import { n as getEnv } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Gr as SquareFillIcon, Jn as PaperAirplaneIcon, Mi as XIcon, O as CheckIcon, an as IconButton, et as CopilotIcon, ni as SyncIcon, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as isStaff } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { i as Textarea } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { n as useConfirm } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { s as useMutation } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { r as CopilotAuthTokenProvider } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as CopilotAnimationType, t as CopilotAnimation } from "./server-CopilotAnimation-DOXbbPXC-CqTp-mSh.js";
import { t as WithShimmerEffect } from "./server-WithShimmerEffect-C6EPOEv6-DHTqBfIK.js";
import { u as useDynamicTextareaHeight } from "./server-validators-DpH9Vi4K-BgoqazXb.js";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var LABELS = {
	copilotPanelInitialMessage: "How can I help you write your issue?",
	copilotPanelInputPlaceholder: "Type your message here...",
	copilotPanelSendButton: "Send",
	copilotPanelUpdatedMessage: "I've updated the issue title and description above.",
	copilotPanelLoadingMessage: "Writing…",
	copilotPanelAcceptButton: "Accept",
	copilotPanelDiscardButton: "Discard",
	copilotPanelTryAgainButton: "Try again",
	copilotGenerateError: "Failed to generate content with Copilot. Please try again.",
	copilotDiscardConfirmDialog: {
		title: "Discard changes?",
		content: "You have made edits to the generated content. Discarding will lose your changes.",
		confirm: "Discard",
		cancel: "Cancel"
	},
	copilotTryAgainConfirmDialog: {
		title: "Try again?",
		content: "You have made edits to the generated content. Trying again will replace your changes with new generated content.",
		confirm: "Try again",
		cancel: "Cancel"
	}
};
var CopilotGenerateDescriptionPanel_module_default = {
	actionButton: "CopilotGenerateDescriptionPanel-module_Yq2VbW_actionButton",
	actionButtons: "CopilotGenerateDescriptionPanel-module_Yq2VbW_actionButtons",
	anchorBottom: "CopilotGenerateDescriptionPanel-module_Yq2VbW_anchorBottom",
	anchorTop: "CopilotGenerateDescriptionPanel-module_Yq2VbW_anchorTop",
	closeButtonContainer: "CopilotGenerateDescriptionPanel-module_Yq2VbW_closeButtonContainer",
	container: "CopilotGenerateDescriptionPanel-module_Yq2VbW_container",
	errorContainer: "CopilotGenerateDescriptionPanel-module_Yq2VbW_errorContainer",
	iconContainer: "CopilotGenerateDescriptionPanel-module_Yq2VbW_iconContainer",
	inputArea: "CopilotGenerateDescriptionPanel-module_Yq2VbW_inputArea",
	loadingContainer: "CopilotGenerateDescriptionPanel-module_Yq2VbW_loadingContainer",
	loadingLabel: "CopilotGenerateDescriptionPanel-module_Yq2VbW_loadingLabel",
	loadingText: "CopilotGenerateDescriptionPanel-module_Yq2VbW_loadingText",
	messageContent: "CopilotGenerateDescriptionPanel-module_Yq2VbW_messageContent",
	messageLabel: "CopilotGenerateDescriptionPanel-module_Yq2VbW_messageLabel",
	messageRow: "CopilotGenerateDescriptionPanel-module_Yq2VbW_messageRow",
	messageText: "CopilotGenerateDescriptionPanel-module_Yq2VbW_messageText",
	sendButton: "CopilotGenerateDescriptionPanel-module_Yq2VbW_sendButton",
	staffPillLink: "CopilotGenerateDescriptionPanel-module_Yq2VbW_staffPillLink",
	textarea: "CopilotGenerateDescriptionPanel-module_Yq2VbW_textarea"
};
var PANEL_MARGIN_TOP = 16;
var BODY_INSTRUCTIONS = `- Provide a clear, comprehensive issue body in markdown format that explains the problem, context, and any relevant details. Keep it clear and concise.
- If there is an existing body that has a structure (template), work with the template. DO NOT change the template unless instructed.
- Return the body in a markdown format, unwrapped by \`\`\`markdown tags.
- Only work with information you have. The length of the issue should be proportional to the information provided.
- Try to focus updates on the portions of the body that are relevant to the user's request.
- When the user should be directed to edit portions of the returned body, explicitly put areas to edit [inside brackets with instructions]. Do not add meta instructions outside the main body content.`;
var SYSTEM_PROMPT = `You are a helpful assistant that helps users create and refine GitHub issue titles and descriptions.
Your task is to take the user's input and the current issue title and body, and create or improve them.

For the issue body:

${BODY_INSTRUCTIONS}

For the issue title:
- Only update the title if it reflects incorrect or incomplete information based on the user's request.

Return your response as a JSON object with "title" and "body" fields.`;
var SYSTEM_PROMPT_BODY_ONLY = `You are a helpful assistant that helps users refine GitHub issue descriptions.
Your task is to take the user's input and the current issue body, and improve it.

For the issue body:

${BODY_INSTRUCTIONS}

Return your response as a JSON object with "title" and "body" fields. The "title" field should be the same as the current title provided in the context.`;
function CopilotGenerateDescriptionPanel({ isOpen, onClose, onGenerate, repoOwner, repoName, title, body, className, onPendingChange, onStateChange, anchorPosition = "top", onHeightChange, editorRef, generateTitle = true }) {
	const [userInput, setUserInput] = useState("");
	const [panelState, setPanelState] = useState("initial");
	const [lastUserMessage, setLastUserMessage] = useState("");
	const initialTitleRef = useRef(title);
	const initialBodyRef = useRef(body);
	const prevIsOpenRef = useRef(isOpen);
	const lastSentTitleRef = useRef(title);
	const lastSentBodyRef = useRef(body);
	const generatedTitleRef = useRef(null);
	const generatedBodyRef = useRef(null);
	const authTokenProviderRef = useRef(new CopilotAuthTokenProvider([]));
	const confirm = useConfirm();
	const abortControllerRef = useRef(null);
	const { sendAnalyticsEvent } = useAnalytics();
	const textareaRef = useRef(null);
	const panelRef = useRef(null);
	const userIsStaff = useMemo(() => isStaff(), []);
	const heightStyles = useDynamicTextareaHeight({
		minHeightLines: 1,
		maxHeightLines: 10,
		elementRef: textareaRef,
		value: userInput
	});
	const [positionOffset, setPositionOffset] = useState(void 0);
	useLayoutEffect(() => {
		if (!isOpen) return;
		const inputElement = editorRef?.current?.inputRef.current;
		if (!inputElement) return;
		const calculateOffset = () => {
			const panelContainer = panelRef.current?.offsetParent;
			if (!panelContainer) return;
			const inputRect = inputElement.getBoundingClientRect();
			const containerRect = panelContainer.getBoundingClientRect();
			if (anchorPosition === "top") setPositionOffset(inputRect.top - containerRect.top);
			else {
				const inputStyles = getComputedStyle(inputElement);
				const inputPaddingBottom = parseFloat(inputStyles.paddingBottom) || 0;
				setPositionOffset(inputRect.bottom - containerRect.top - inputPaddingBottom - PANEL_MARGIN_TOP);
			}
		};
		calculateOffset();
		const resizeObserver = new ResizeObserver(() => {
			calculateOffset();
		});
		if (inputElement.parentElement) resizeObserver.observe(inputElement.parentElement);
		if (panelRef.current) resizeObserver.observe(panelRef.current);
		return () => {
			resizeObserver.disconnect();
		};
	}, [
		anchorPosition,
		editorRef,
		isOpen
	]);
	useEffect(() => {
		if (isOpen && !prevIsOpenRef.current) {
			initialTitleRef.current = title;
			initialBodyRef.current = body;
		}
		prevIsOpenRef.current = isOpen;
	}, [
		isOpen,
		title,
		body
	]);
	useEffect(() => {
		onStateChange?.(panelState);
	}, [panelState, onStateChange]);
	const currentMessage = useMemo(() => {
		switch (panelState) {
			case "initial": return LABELS.copilotPanelInitialMessage;
			case "suggested": return LABELS.copilotPanelUpdatedMessage;
			case "error": return LABELS.copilotGenerateError;
			case "loading": return "";
			default: return "";
		}
	}, [panelState]);
	const { mutate, isPending } = useMutation({
		mutationFn: async (userMessage) => {
			abortControllerRef.current = new AbortController();
			const apiUrl = `${getEnv().copilotApiOverrideUrl || "https://api.githubcopilot.com"}/chat/completions`;
			const headers = {
				Authorization: (await authTokenProviderRef.current.getAuthToken()).authorizationHeaderValue,
				"copilot-integration-id": "copilot-embedded-experience",
				"Content-Type": "application/json"
			};
			const userContext = `Current title: ${title || "(empty)"}
Current body: ${body || "(empty)"}

User's request: ${userMessage}`;
			if (userContext.length > 5e4) throw new Error("Input is too large. Please reduce the length of your title, description, or request.");
			const requestBody = {
				messages: [{
					role: "system",
					content: generateTitle ? SYSTEM_PROMPT : SYSTEM_PROMPT_BODY_ONLY
				}, {
					role: "user",
					content: userContext
				}],
				model: "gpt-4o-mini",
				stream: false,
				temperature: .3,
				response_format: {
					type: "json_schema",
					json_schema: {
						name: "issue_content",
						strict: true,
						schema: {
							type: "object",
							properties: {
								title: {
									type: "string",
									description: "The improved or generated issue title"
								},
								body: {
									type: "string",
									description: "The improved or generated issue body/description"
								}
							},
							required: ["title", "body"],
							additionalProperties: false
						}
					}
				}
			};
			const response = await fetch(apiUrl, {
				method: "POST",
				headers,
				body: JSON.stringify(requestBody),
				signal: abortControllerRef.current.signal
			});
			if (!response.ok) throw new Error(`API request failed with status ${response.status}`);
			const content = (await response.json()).choices?.[0]?.message?.content;
			if (!content) throw new Error("No content in response");
			const parsed = JSON.parse(content);
			if (!parsed.body) throw new Error("Invalid response structure");
			return parsed;
		},
		onSuccess: (data, _userMessage) => {
			setPanelState("suggested");
			generatedTitleRef.current = data.title;
			generatedBodyRef.current = data.body;
			onGenerate(data.title, data.body);
			setUserInput("");
			sendAnalyticsEvent("analytics.click", "ISSUE_CREATE_GENERATE_DESCRIPTION_WITH_COPILOT_PANEL", {
				repoNWO: `${repoOwner}/${repoName}`,
				hasTitle: !!title,
				hasExistingDescription: !!body,
				success: true
			});
			sendGenerateDescriptionEvent();
		},
		onError: (error, _userMessage) => {
			if (error.name === "AbortError") {
				setPanelState("initial");
				return;
			}
			setPanelState("error");
			sendAnalyticsEvent("analytics.click", "ISSUE_CREATE_GENERATE_DESCRIPTION_WITH_COPILOT_PANEL", {
				repoNWO: `${repoOwner}/${repoName}`,
				hasTitle: !!title,
				hasExistingDescription: !!body,
				success: false,
				error: error.message
			});
			sendGenerateDescriptionEvent(error.message);
		}
	});
	const handleClose = useCallback((action) => {
		if (action === "accepted") sendPanelAnalyticsEvent("accepted");
		else if (action === "discarded") sendPanelAnalyticsEvent("discarded");
		else if (generatedTitleRef.current !== null || generatedBodyRef.current !== null) sendPanelAnalyticsEvent("closed_with_changes");
		else sendPanelAnalyticsEvent("closed_without_changes");
		setUserInput("");
		setPanelState("initial");
		setLastUserMessage("");
		lastSentTitleRef.current = title;
		lastSentBodyRef.current = body;
		generatedTitleRef.current = null;
		generatedBodyRef.current = null;
		onClose();
	}, [
		onClose,
		title,
		body
	]);
	const handleCancel = useCallback(() => {
		abortControllerRef.current?.abort();
	}, []);
	const handleSend = useCallback(() => {
		if (!userInput.trim() || isPending) return;
		lastSentTitleRef.current = title;
		lastSentBodyRef.current = body;
		setLastUserMessage(userInput);
		setPanelState("loading");
		mutate(userInput);
	}, [
		userInput,
		isPending,
		mutate,
		title,
		body
	]);
	const handleDiscard = useCallback(async () => {
		if (generatedTitleRef.current !== null && generatedBodyRef.current !== null && (title !== generatedTitleRef.current || body !== generatedBodyRef.current)) {
			if (!await confirm({
				title: LABELS.copilotDiscardConfirmDialog.title,
				content: LABELS.copilotDiscardConfirmDialog.content,
				confirmButtonContent: LABELS.copilotDiscardConfirmDialog.confirm,
				confirmButtonType: "danger",
				cancelButtonContent: LABELS.copilotDiscardConfirmDialog.cancel
			})) return;
		}
		onGenerate(initialTitleRef.current, initialBodyRef.current);
		handleClose("discarded");
	}, [
		onGenerate,
		handleClose,
		title,
		body,
		confirm
	]);
	const handleTryAgain = useCallback(async () => {
		if (!lastUserMessage) return;
		if (generatedTitleRef.current !== null && generatedBodyRef.current !== null && (title !== generatedTitleRef.current || body !== generatedBodyRef.current)) {
			if (!await confirm({
				title: LABELS.copilotTryAgainConfirmDialog.title,
				content: LABELS.copilotTryAgainConfirmDialog.content,
				confirmButtonContent: LABELS.copilotTryAgainConfirmDialog.confirm,
				confirmButtonType: "danger",
				cancelButtonContent: LABELS.copilotTryAgainConfirmDialog.cancel
			})) return;
		}
		sendPanelAnalyticsEvent("retried");
		onGenerate(lastSentTitleRef.current, lastSentBodyRef.current);
		setPanelState("loading");
		mutate(lastUserMessage);
	}, [
		lastUserMessage,
		mutate,
		onGenerate,
		title,
		body,
		confirm
	]);
	const handleKeyPress = useCallback((e) => {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			handleSend();
		}
	}, [handleSend]);
	useEffect(() => {
		if (isOpen && textareaRef.current) textareaRef.current.focus();
	}, [isOpen]);
	useEffect(() => {
		onPendingChange?.(isPending);
	}, [isPending, onPendingChange]);
	useEffect(() => {
		return () => {
			onPendingChange?.(false);
		};
	}, []);
	useEffect(() => {
		return () => {
			abortControllerRef.current?.abort();
		};
	}, []);
	useLayoutEffect(() => {
		if (!isOpen || !panelRef.current || !onHeightChange) return;
		const initialHeight = panelRef.current.getBoundingClientRect().height;
		onHeightChange(initialHeight + 16);
		const observer = new ResizeObserver((entries) => {
			for (const entry of entries) onHeightChange((entry.borderBoxSize?.[0]?.blockSize ?? entry.target.getBoundingClientRect().height) + 16);
		});
		observer.observe(panelRef.current);
		return () => {
			observer.disconnect();
			onHeightChange(0);
		};
	}, [isOpen, onHeightChange]);
	if (!isOpen) return null;
	return /* @__PURE__ */ jsxs("div", {
		ref: panelRef,
		className: clsx(CopilotGenerateDescriptionPanel_module_default.container, anchorPosition === "top" ? CopilotGenerateDescriptionPanel_module_default.anchorTop : anchorPosition === "bottom" ? CopilotGenerateDescriptionPanel_module_default.anchorBottom : void 0, className),
		style: positionOffset !== void 0 ? { top: `${positionOffset}px` } : void 0,
		role: "region",
		"aria-label": "Generate with Copilot",
		children: [
			!isPending && /* @__PURE__ */ jsxs("div", {
				className: CopilotGenerateDescriptionPanel_module_default.closeButtonContainer,
				children: [userIsStaff && /* @__PURE__ */ jsx("a", {
					href: "https://gh.io/write-with-copilot-feedback",
					target: "_blank",
					rel: "noopener noreferrer",
					className: CopilotGenerateDescriptionPanel_module_default.staffPillLink,
					children: /* @__PURE__ */ jsx(Label, {
						variant: "accent",
						children: "Staff"
					})
				}), /* @__PURE__ */ jsx(IconButton, {
					"aria-label": "Close",
					icon: XIcon,
					variant: "invisible",
					onClick: () => handleClose()
				})]
			}),
			currentMessage && /* @__PURE__ */ jsxs("div", {
				className: CopilotGenerateDescriptionPanel_module_default.messageRow,
				children: [/* @__PURE__ */ jsx("div", {
					className: CopilotGenerateDescriptionPanel_module_default.iconContainer,
					children: /* @__PURE__ */ jsx(CopilotIcon, { size: 16 })
				}), /* @__PURE__ */ jsxs("div", {
					className: CopilotGenerateDescriptionPanel_module_default.messageContent,
					children: [/* @__PURE__ */ jsx("div", {
						className: CopilotGenerateDescriptionPanel_module_default.messageLabel,
						children: /* @__PURE__ */ jsx("span", { children: "Copilot" })
					}), currentMessage === LABELS.copilotGenerateError ? /* @__PURE__ */ jsx("div", {
						className: CopilotGenerateDescriptionPanel_module_default.errorContainer,
						children: /* @__PURE__ */ jsxs(Flash, {
							variant: "danger",
							children: [/* @__PURE__ */ jsx(AlertIcon, {}), currentMessage]
						})
					}) : /* @__PURE__ */ jsx("div", {
						className: CopilotGenerateDescriptionPanel_module_default.messageText,
						children: /* @__PURE__ */ jsx("span", { children: currentMessage })
					})]
				})]
			}),
			isPending && /* @__PURE__ */ jsxs("div", {
				className: CopilotGenerateDescriptionPanel_module_default.loadingContainer,
				"aria-live": "polite",
				"aria-atomic": "true",
				role: "status",
				children: [
					/* @__PURE__ */ jsx(CopilotAnimation, {
						animationType: CopilotAnimationType.Thinking,
						loopAnimation: true,
						size: 20
					}),
					/* @__PURE__ */ jsx("span", {
						className: CopilotGenerateDescriptionPanel_module_default.loadingLabel,
						children: "Copilot"
					}),
					/* @__PURE__ */ jsx(WithShimmerEffect, {
						className: CopilotGenerateDescriptionPanel_module_default.loadingText,
						children: LABELS.copilotPanelLoadingMessage
					}),
					/* @__PURE__ */ jsx(IconButton, {
						"aria-label": "Stop generation",
						icon: SquareFillIcon,
						size: "small",
						onClick: handleCancel
					})
				]
			}),
			panelState === "suggested" && !isPending && /* @__PURE__ */ jsxs("div", {
				className: CopilotGenerateDescriptionPanel_module_default.actionButtons,
				children: [
					/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						variant: "invisible",
						className: CopilotGenerateDescriptionPanel_module_default.actionButton,
						leadingVisual: CheckIcon,
						onClick: () => handleClose("accepted"),
						children: LABELS.copilotPanelAcceptButton
					}),
					/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						variant: "invisible",
						className: CopilotGenerateDescriptionPanel_module_default.actionButton,
						leadingVisual: XIcon,
						onClick: handleDiscard,
						children: LABELS.copilotPanelDiscardButton
					}),
					/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						variant: "invisible",
						className: CopilotGenerateDescriptionPanel_module_default.actionButton,
						leadingVisual: SyncIcon,
						onClick: handleTryAgain,
						children: LABELS.copilotPanelTryAgainButton
					})
				]
			}),
			!isPending && /* @__PURE__ */ jsxs("div", {
				className: CopilotGenerateDescriptionPanel_module_default.inputArea,
				children: [/* @__PURE__ */ jsx(Textarea, {
					ref: textareaRef,
					value: userInput,
					onChange: (e) => setUserInput(e.target.value),
					onKeyPress: handleKeyPress,
					placeholder: LABELS.copilotPanelInputPlaceholder,
					rows: 1,
					resize: "none",
					block: true,
					className: CopilotGenerateDescriptionPanel_module_default.textarea,
					style: heightStyles
				}), /* @__PURE__ */ jsx(IconButton, {
					className: CopilotGenerateDescriptionPanel_module_default.sendButton,
					"aria-label": LABELS.copilotPanelSendButton,
					icon: PaperAirplaneIcon,
					variant: "invisible",
					onClick: handleSend,
					disabled: userInput.trim() === ""
				})]
			})
		]
	});
}
CopilotGenerateDescriptionPanel.displayName = "CopilotGenerateDescriptionPanel";
function sendPanelAnalyticsEvent(action) {
	sendEvent("copilot.create_issue_description_panel", { action });
}
function sendGenerateDescriptionEvent(error) {
	sendEvent("copilot.create_issue_description_panel", { error });
}
var DEFAULT_COMMAND_ID = "copilot-panel:toggle";
/**
* Hook to manage the state and behavior of the CopilotGenerateDescriptionPanel.
* Encapsulates panel open/close state, generating state, height tracking,
* keyboard commands, and computed props for the panel component.
*/
function useCopilotGeneratePanel(t0) {
	const $ = c(48);
	const { editorRef, body, onChange, shouldShowCopilotFunctionality: t1, repoOwner: t2, repoName: t3, title: t4, generateTitle: t5, commandId: t6, canToggle: t7 } = t0;
	const shouldShowCopilotFunctionality = t1 === void 0 ? false : t1;
	const repoOwner = t2 === void 0 ? "" : t2;
	const repoName = t3 === void 0 ? "" : t3;
	const title = t4 === void 0 ? "" : t4;
	const generateTitle = t5 === void 0 ? false : t5;
	const commandId = t6 === void 0 ? DEFAULT_COMMAND_ID : t6;
	const canToggle = t7 === void 0 ? true : t7;
	const [isPanelOpen, setIsPanelOpen] = useState(false);
	const [isGenerating, setIsGenerating] = useState(false);
	const [panelHeight, setPanelHeight] = useState(0);
	let t8;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = isFeatureEnabled("write_issue_body_with_copilot");
		$[0] = t8;
	} else t8 = $[0];
	const shouldShowCopilot = t8 && shouldShowCopilotFunctionality && Boolean(repoOwner) && Boolean(repoName);
	let t9;
	if ($[1] !== editorRef) {
		t9 = () => {
			setIsPanelOpen(false);
			editorRef.current?.focus();
		};
		$[1] = editorRef;
		$[2] = t9;
	} else t9 = $[2];
	const closePanel = t9;
	let t10;
	if ($[3] !== canToggle || $[4] !== closePanel || $[5] !== isGenerating || $[6] !== isPanelOpen || $[7] !== shouldShowCopilot) {
		t10 = () => {
			if (!shouldShowCopilot || isGenerating || !canToggle) return;
			if (isPanelOpen) closePanel();
			else setIsPanelOpen(true);
		};
		$[3] = canToggle;
		$[4] = closePanel;
		$[5] = isGenerating;
		$[6] = isPanelOpen;
		$[7] = shouldShowCopilot;
		$[8] = t10;
	} else t10 = $[8];
	const togglePanel = t10;
	let t11;
	if ($[9] !== generateTitle || $[10] !== onChange) {
		t11 = (generatedTitle, generatedDescription) => {
			onChange(generatedDescription, generateTitle ? generatedTitle : void 0);
		};
		$[9] = generateTitle;
		$[10] = onChange;
		$[11] = t11;
	} else t11 = $[11];
	const handleGenerate = t11;
	let t12;
	if ($[12] !== body || $[13] !== isPanelOpen) {
		t12 = () => {
			if (isPanelOpen && !body.trim()) setIsPanelOpen(false);
		};
		$[12] = body;
		$[13] = isPanelOpen;
		$[14] = t12;
	} else t12 = $[14];
	const handleInputFocus = t12;
	let t13;
	if ($[15] !== commandId || $[16] !== togglePanel) {
		t13 = { [commandId]: togglePanel };
		$[15] = commandId;
		$[16] = togglePanel;
		$[17] = t13;
	} else t13 = $[17];
	const commands = t13;
	const anchorPosition = body.trim() || isGenerating ? "bottom" : "top";
	let t14;
	bb0: {
		if (isPanelOpen) {
			let t15;
			if ($[18] !== body || $[19] !== isGenerating || $[20] !== panelHeight) {
				t15 = body.trim() || isGenerating ? `${panelHeight}px` : void 0;
				$[18] = body;
				$[19] = isGenerating;
				$[20] = panelHeight;
				$[21] = t15;
			} else t15 = $[21];
			const t16 = `${panelHeight + 100}px`;
			let t17;
			if ($[22] !== t15 || $[23] !== t16) {
				t17 = {
					"--markdown-input-bottom-padding": t15,
					"--markdown-editor-min-height": t16
				};
				$[22] = t15;
				$[23] = t16;
				$[24] = t17;
			} else t17 = $[24];
			t14 = t17;
			break bb0;
		}
		t14 = void 0;
	}
	const containerStyle = t14;
	let t15;
	if ($[25] !== anchorPosition || $[26] !== body || $[27] !== closePanel || $[28] !== editorRef || $[29] !== generateTitle || $[30] !== handleGenerate || $[31] !== isPanelOpen || $[32] !== repoName || $[33] !== repoOwner || $[34] !== title) {
		t15 = {
			isOpen: isPanelOpen,
			onClose: closePanel,
			onGenerate: handleGenerate,
			repoOwner,
			repoName,
			title,
			body,
			onPendingChange: setIsGenerating,
			anchorPosition,
			onHeightChange: setPanelHeight,
			editorRef,
			generateTitle
		};
		$[25] = anchorPosition;
		$[26] = body;
		$[27] = closePanel;
		$[28] = editorRef;
		$[29] = generateTitle;
		$[30] = handleGenerate;
		$[31] = isPanelOpen;
		$[32] = repoName;
		$[33] = repoOwner;
		$[34] = title;
		$[35] = t15;
	} else t15 = $[35];
	const panelProps = t15;
	let t16;
	if ($[36] !== closePanel || $[37] !== commands || $[38] !== containerStyle || $[39] !== handleGenerate || $[40] !== handleInputFocus || $[41] !== isGenerating || $[42] !== isPanelOpen || $[43] !== panelHeight || $[44] !== panelProps || $[45] !== shouldShowCopilot || $[46] !== togglePanel) {
		t16 = {
			isPanelOpen,
			isGenerating,
			panelHeight,
			shouldShowCopilot,
			togglePanel,
			closePanel,
			handleGenerate,
			handleInputFocus,
			commands,
			panelProps,
			containerStyle,
			setIsGenerating,
			setPanelHeight
		};
		$[36] = closePanel;
		$[37] = commands;
		$[38] = containerStyle;
		$[39] = handleGenerate;
		$[40] = handleInputFocus;
		$[41] = isGenerating;
		$[42] = isPanelOpen;
		$[43] = panelHeight;
		$[44] = panelProps;
		$[45] = shouldShowCopilot;
		$[46] = togglePanel;
		$[47] = t16;
	} else t16 = $[47];
	return t16;
}
var TEST_IDS = {
	issueBody: "issue-body",
	bodyLoading: "body-loading",
	commentBox: (postFix = "") => `markdown-editor-${postFix}`,
	projectTitle: "project-title"
};
export { TEST_IDS as n, useCopilotGeneratePanel as r, CopilotGenerateDescriptionPanel as t };
