performance.mark("js-parse-end:server-SubIssuesList-OyBRwG7W-DSKcdQXm.js");
import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { bn as Link, er as PersonIcon, gi as TriangleRightIcon, mi as TrashIcon, n as ActionList, tt as CopyIcon, z as CircleIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { a as Token } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as copyText } from "./server-copy-ByVwvIP0-X47hrvCx.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as AvatarStack } from "./server-AvatarStack-DOkoT87C-BbROVIWO.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { f as useIssueState, p as useNamedColor, r as TEMP_SUB_ISSUE_ID_PREFIX, s as isColorName, t as IssueState } from "./server-use-issue-pr-state-Ca7HKQL5-BTNcVLo6.js";
import { A as useSubIssuesSummary, D as useNestedListViewSelection, E as useNestedListItemLeadingBadge, O as useStickyHeader, S as getIssueTitle, T as useNestedListItemCompletion, a as NestedListItem, c as NestedListItemLeadingVisual, d as NestedListViewHeader, f as NestedListViewHeaderTitle, j as useSuppressActions, l as NestedListItemTitle, n as ClosedByPullRequestsReferences, o as NestedListItemActionBar, p as ProgressCircle, s as NestedListItemLeadingContent, t as AddSubIssueButtonGroup, u as NestedListView, v as commitRemoveSubIssueMutation, w as useCachePreheatQuery } from "./server-ClosedByPullRequestsReferences-BU5RVLsf-DaEMWV24.js";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { renderToString } from "react-dom/server";
performance.mark("js-parse-end:SubIssuesList-OyBRwG7W.js");
var node$11 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "SubIssuesList",
	"selections": [{
		"args": null,
		"kind": "FragmentSpread",
		"name": "SubIssuesListView"
	}, {
		"args": [{
			"kind": "Literal",
			"name": "fetchSubIssues",
			"value": true
		}],
		"kind": "FragmentSpread",
		"name": "AddSubIssueButtonGroup"
	}],
	"type": "Issue",
	"abstractKey": null
};
node$11.hash = "5392781363d352b5a0f552def559897f";
var import_react_relay = require_react_relay();
require_relay_runtime();
var node$10 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "SubIssuesListView",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "login",
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": [{
					"kind": "Literal",
					"name": "first",
					"value": 100
				}],
				"concreteType": "IssueConnection",
				"kind": "LinkedField",
				"name": "subIssues",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "nodes",
					"plural": true,
					"selections": [v0, {
						"args": null,
						"kind": "FragmentSpread",
						"name": "SubIssuesListItem"
					}],
					"storageKey": null
				}],
				"storageKey": "subIssues(first:100)"
			},
			{
				"args": [{
					"kind": "Literal",
					"name": "fetchSubIssues",
					"value": true
				}],
				"kind": "FragmentSpread",
				"name": "useSubIssuesSummary"
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$10.hash = "6a5e26b8bec2269872e5e2a9597f5c2a";
var CompletionPill_module_default = {
	completionPill: "CompletionPill-module_PEEU1W_completionPill",
	expandOnHover: "CompletionPill-module_PEEU1W_expandOnHover",
	hoverExpandIcon: "CompletionPill-module_PEEU1W_hoverExpandIcon",
	progressIcon: "CompletionPill-module_PEEU1W_progressIcon"
};
function NestedListViewCompletionPill(t0) {
	const $ = c(6);
	const { progress: t1, ...tokenProps } = t0;
	const { total, completed, percentCompleted } = t1;
	const { pluralUnits } = useNestedListViewSelection();
	const completionContext = useNestedListItemCompletion();
	const expandOnHover = tokenProps.href;
	const label = `${completed} of ${total} ${pluralUnits} completed`;
	let t2;
	let t3;
	if ($[0] !== completionContext || $[1] !== label) {
		t2 = () => {
			if (completionContext) completionContext.setCompletion(label);
		};
		t3 = [completionContext, label];
		$[0] = completionContext;
		$[1] = label;
		$[2] = t2;
		$[3] = t3;
	} else {
		t2 = $[2];
		t3 = $[3];
	}
	useEffect(t2, t3);
	let t4;
	if ($[4] !== percentCompleted) {
		t4 = () => jsx(ProgressCircle, {
			percentCompleted,
			size: 14,
			svgClassName: CompletionPill_module_default.progressIcon
		});
		$[4] = percentCompleted;
		$[5] = t4;
	} else t4 = $[5];
	return jsx(Token, {
		leadingVisual: t4,
		...testIdProps("nested-list-view-completion-pill"),
		text: jsxs(Fragment$1, { children: [
			jsx("span", {
				...testIdProps("nested-list-view-completion-text"),
				"aria-hidden": "true",
				children: `${completed} of ${total}`
			}),
			jsx("span", {
				...testIdProps("nested-list-view-completion-text-sr"),
				className: "sr-only",
				children: label
			}),
			expandOnHover && jsx(Octicon, {
				icon: TriangleRightIcon,
				className: CompletionPill_module_default.hoverExpandIcon,
				"aria-hidden": "true",
				...testIdProps("nested-list-view-clickable-svg")
			})
		] }),
		...tokenProps,
		as: tokenProps.href ? "a" : "span",
		className: clsx(CompletionPill_module_default.completionPill, expandOnHover && CompletionPill_module_default.expandOnHover, tokenProps.className)
	});
}
NestedListViewCompletionPill.displayName = "NestedListViewCompletionPill";
var node$9 = (function() {
	var v0 = [{
		"defaultValue": false,
		"kind": "LocalArgument",
		"name": "fetchSubIssues"
	}, {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"concreteType": "Repository",
		"kind": "LinkedField",
		"name": "repository",
		"plural": false,
		"selections": [
			v7,
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [
					v2,
					v8,
					v3
				],
				"storageKey": null
			},
			v3
		],
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "state",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "stateReason",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueType",
		"kind": "LinkedField",
		"name": "issueType",
		"plural": false,
		"selections": [
			v3,
			v7,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "color",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"concreteType": "SubIssuesSummary",
		"kind": "LinkedField",
		"name": "subIssuesSummary",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "total",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "completed",
			"storageKey": null
		}],
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v17 = [v16];
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "SubIssuesListItem_NestedSubIssuesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"args": [{
						"kind": "Variable",
						"name": "fetchSubIssues",
						"variableName": "fetchSubIssues"
					}],
					"kind": "FragmentSpread",
					"name": "SubIssuesListItem_NestedSubIssues"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "SubIssuesListItem_NestedSubIssuesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					v3,
					{
						"kind": "InlineFragment",
						"selections": [
							v4,
							v5,
							v6,
							v9,
							v10,
							v11,
							v12,
							v13,
							v14,
							{
								"condition": "fetchSubIssues",
								"kind": "Condition",
								"passingValue": false,
								"selections": [v15]
							},
							{
								"condition": "fetchSubIssues",
								"kind": "Condition",
								"passingValue": true,
								"selections": [{
									"alias": "subIssuesConnection",
									"args": null,
									"concreteType": "IssueConnection",
									"kind": "LinkedField",
									"name": "subIssues",
									"plural": false,
									"selections": v17,
									"storageKey": null
								}, {
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 100
									}],
									"concreteType": "IssueConnection",
									"kind": "LinkedField",
									"name": "subIssues",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": "Issue",
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											{
												"alias": null,
												"args": null,
												"kind": "ScalarField",
												"name": "closed",
												"storageKey": null
											},
											v3,
											v10,
											v11,
											{
												"alias": null,
												"args": null,
												"concreteType": "IssueDependenciesSummary",
												"kind": "LinkedField",
												"name": "issueDependenciesSummary",
												"plural": false,
												"selections": [{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "blockedBy",
													"storageKey": null
												}],
												"storageKey": null
											},
											{
												"alias": null,
												"args": [{
													"kind": "Literal",
													"name": "first",
													"value": 10
												}],
												"concreteType": "UserConnection",
												"kind": "LinkedField",
												"name": "assignees",
												"plural": false,
												"selections": [v16, {
													"alias": null,
													"args": null,
													"concreteType": "UserEdge",
													"kind": "LinkedField",
													"name": "edges",
													"plural": true,
													"selections": [{
														"alias": null,
														"args": null,
														"concreteType": "User",
														"kind": "LinkedField",
														"name": "node",
														"plural": false,
														"selections": [
															v3,
															v8,
															{
																"alias": null,
																"args": null,
																"kind": "ScalarField",
																"name": "avatarUrl",
																"storageKey": null
															}
														],
														"storageKey": null
													}],
													"storageKey": null
												}],
												"storageKey": "assignees(first:10)"
											},
											v4,
											v9,
											v5,
											v6,
											v12,
											v13,
											v14,
											v15,
											{
												"alias": null,
												"args": [{
													"kind": "Literal",
													"name": "first",
													"value": 0
												}, {
													"kind": "Literal",
													"name": "includeClosedPrs",
													"value": true
												}],
												"concreteType": "PullRequestConnection",
												"kind": "LinkedField",
												"name": "closedByPullRequestsReferences",
												"plural": false,
												"selections": v17,
												"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
											}
										],
										"storageKey": null
									}],
									"storageKey": "subIssues(first:100)"
								}]
							}
						],
						"type": "Issue",
						"abstractKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "9943e59acbe11bcc2f2fe3ff92232141",
			"metadata": {},
			"name": "SubIssuesListItem_NestedSubIssuesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$9.hash = "f55cabab95316ca4ae20ff30393a32eb";
var node$8 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [{
			"defaultValue": false,
			"kind": "LocalArgument",
			"name": "fetchSubIssues"
		}],
		"kind": "Fragment",
		"metadata": { "refetch": {
			"connection": null,
			"fragmentPathInResult": ["node"],
			"operation": node$9,
			"identifierInfo": {
				"identifierField": "id",
				"identifierQueryVariableName": "id"
			}
		} },
		"name": "SubIssuesListItem_NestedSubIssues",
		"selections": [
			{
				"args": [{
					"kind": "Variable",
					"name": "fetchSubIssues",
					"variableName": "fetchSubIssues"
				}],
				"kind": "FragmentSpread",
				"name": "SubIssueTitle"
			},
			{
				"condition": "fetchSubIssues",
				"kind": "Condition",
				"passingValue": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "SubIssuesSummary",
					"kind": "LinkedField",
					"name": "subIssuesSummary",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "total",
						"storageKey": null
					}],
					"storageKey": null
				}]
			},
			{
				"condition": "fetchSubIssues",
				"kind": "Condition",
				"passingValue": true,
				"selections": [{
					"alias": "subIssuesConnection",
					"args": null,
					"concreteType": "IssueConnection",
					"kind": "LinkedField",
					"name": "subIssues",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "totalCount",
						"storageKey": null
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": [{
						"kind": "Literal",
						"name": "first",
						"value": 100
					}],
					"concreteType": "IssueConnection",
					"kind": "LinkedField",
					"name": "subIssues",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [v0, {
							"args": null,
							"kind": "FragmentSpread",
							"name": "SubIssuesListItem"
						}],
						"storageKey": null
					}],
					"storageKey": "subIssues(first:100)"
				}]
			},
			v0
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$8.hash = "f55cabab95316ca4ae20ff30393a32eb";
var node$7 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "SubIssuesListItem",
		"selections": [
			v0,
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "SubIssueStateIcon"
			},
			{
				"alias": null,
				"args": [{
					"kind": "Literal",
					"name": "first",
					"value": 10
				}],
				"concreteType": "UserConnection",
				"kind": "LinkedField",
				"name": "assignees",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "totalCount",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": "UserEdge",
					"kind": "LinkedField",
					"name": "edges",
					"plural": true,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "User",
						"kind": "LinkedField",
						"name": "node",
						"plural": false,
						"selections": [
							v0,
							v1,
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "avatarUrl",
								"storageKey": null
							}
						],
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": "assignees(first:10)"
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "name",
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [v1],
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"args": [{
					"kind": "Literal",
					"name": "fetchSubIssues",
					"value": false
				}],
				"kind": "FragmentSpread",
				"name": "SubIssuesListItem_NestedSubIssues"
			},
			{
				"args": null,
				"kind": "FragmentSpread",
				"name": "ClosedByPullRequestsReferences"
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$7.hash = "952243a95ff6bb14a888fc60d18a1134";
var Metadata_module_default = {
	alignRight: "Metadata-module_rUBCWa_alignRight",
	container: "Metadata-module_rUBCWa_container",
	primary: "Metadata-module_rUBCWa_primary",
	secondary: "Metadata-module_rUBCWa_secondary"
};
var NestedListItemMetadata = ({ children, alignment, variant, className, ...props }) => /* @__PURE__ */ jsx("div", {
	className: clsx("listitem-metadata", Metadata_module_default.container, variant === "primary" ? Metadata_module_default.primary : Metadata_module_default.secondary, alignment === "right" && Metadata_module_default.alignRight, className),
	...testIdProps("nested-list-view-item-metadata-item"),
	...props,
	children
});
NestedListItemMetadata.displayName = "NestedListItemMetadata";
function ActionListItemCopyToClipboard(t0) {
	const $ = c(4);
	let t1;
	if ($[0] !== t0) {
		const { textToCopy, children, ...props } = t0;
		let t2;
		if ($[2] !== textToCopy) {
			t2 = async () => {
				await copyText(textToCopy);
			};
			$[2] = textToCopy;
			$[3] = t2;
		} else t2 = $[3];
		const onSelect = t2;
		t1 = jsxs(ActionList.Item, {
			onSelect,
			...props,
			children: [jsx(ActionList.LeadingVisual, { children: jsx(CopyIcon, {}) }), children]
		});
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
ActionListItemCopyToClipboard.displayName = "ActionListItemCopyToClipboard";
function SubIssuesActionBar(t0) {
	const $ = c(12);
	const { issueId, subIssueId, subIssueUrl } = t0;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	let t1;
	if ($[0] !== addToast || $[1] !== environment || $[2] !== issueId || $[3] !== subIssueId) {
		t1 = () => {
			commitRemoveSubIssueMutation({
				environment,
				input: {
					issueId,
					subIssueId
				},
				onError: (error) => {
					addToast({
						type: "error",
						message: error.message
					});
				}
			});
		};
		$[0] = addToast;
		$[1] = environment;
		$[2] = issueId;
		$[3] = subIssueId;
		$[4] = t1;
	} else t1 = $[4];
	const removeSubIssue = t1;
	let t2;
	if ($[5] !== subIssueUrl) {
		t2 = () => jsx(ActionListItemCopyToClipboard, {
			textToCopy: subIssueUrl,
			children: "Copy link"
		});
		$[5] = subIssueUrl;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== removeSubIssue || $[8] !== t2) {
		let t4;
		if ($[10] !== removeSubIssue) {
			t4 = () => jsxs(ActionList.Item, {
				role: "menuitem",
				as: "button",
				variant: "danger",
				"aria-label": "Remove sub-issue",
				onSelect: removeSubIssue,
				children: [jsx(ActionList.LeadingVisual, { children: jsx(TrashIcon, {}) }), "Remove sub-issue"]
			});
			$[10] = removeSubIssue;
			$[11] = t4;
		} else t4 = $[11];
		t3 = jsx(NestedListItemActionBar, { staticMenuActions: [{
			key: "copy",
			render: t2
		}, {
			key: "remove",
			render: t4
		}] });
		$[7] = removeSubIssue;
		$[8] = t2;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
SubIssuesActionBar.displayName = "SubIssuesActionBar";
var getIssueSearchURL = ({ owner, repo }, field, value) => {
	if (!owner || !repo) return "";
	const baseUrl = `/${owner}/${repo}/issues`;
	if (!field || !value) return baseUrl;
	value = value.includes(" ") ? `"${value}"` : value;
	return `${baseUrl}?q=${encodeURIComponent(`${field}:${value}`)}`;
};
var node$6 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "SubIssueStateIcon",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "state",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "stateReason",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "IssueDependenciesSummary",
			"kind": "LinkedField",
			"name": "issueDependenciesSummary",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "blockedBy",
				"storageKey": null
			}],
			"storageKey": null
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$6.hash = "98b73e2943e6e0438220762134149de5";
var SubIssueStateIcon_module_default = {
	blockedIcon: "SubIssueStateIcon-module_S1kcXa_blockedIcon",
	blockedIssueIconWrapper: "SubIssueStateIcon-module_S1kcXa_blockedIssueIconWrapper",
	issueIcon: "SubIssueStateIcon-module_S1kcXa_issueIcon"
};
var stateIconFragment = node$6;
var OutlineBlockedIcon = () => /* @__PURE__ */ jsxs("svg", {
	"aria-hidden": "true",
	className: SubIssueStateIcon_module_default.blockedIcon,
	width: "12",
	height: "12",
	viewBox: "0 0 12 12",
	fill: "none",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M3.79164 1.13729C3.87955 1.04939 3.99877 1 4.12309 1L7.87691 1C8.00123 1 8.12045 1.04939 8.20836 1.13729L10.8627 3.79164C10.9506 3.87955 11 3.99877 11 4.12309V7.87691C11 8.00123 10.9506 8.12045 10.8627 8.20836L8.20836 10.8627C8.12045 10.9506 8.00123 11 7.87691 11H4.1231C3.99877 11 3.87955 10.9506 3.79164 10.8627L1.13729 8.20836C1.04939 8.12045 1 8.00123 1 7.87691L1 4.1231C1 3.99877 1.04939 3.87955 1.13729 3.79164L3.79164 1.13729ZM4.31726 1.9375L1.9375 4.31726L1.9375 7.68274L4.31726 10.0625H7.68274L10.0625 7.68274V4.31726L7.68274 1.9375L4.31726 1.9375Z",
			fill: "#CF222E"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M3.79164 5.67178C3.79164 5.46467 3.95953 5.29678 4.16664 5.29678H7.82984C8.03692 5.29678 8.20484 5.46467 8.20484 5.67178V6.35012C8.20484 6.55723 8.03692 6.72512 7.82984 6.72512H4.16664C3.95953 6.72512 3.79164 6.55723 3.79164 6.35012V5.67178Z",
			fill: "#CF222E"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M3.79164 1.13729C3.87955 1.04939 3.99877 1 4.12309 1L7.87691 1C8.00123 1 8.12045 1.04939 8.20836 1.13729L10.8627 3.79164C10.9506 3.87955 11 3.99877 11 4.12309V7.87691C11 8.00123 10.9506 8.12045 10.8627 8.20836L8.20836 10.8627C8.12045 10.9506 8.00123 11 7.87691 11H4.1231C3.99877 11 3.87955 10.9506 3.79164 10.8627L1.13729 8.20836C1.04939 8.12045 1 8.00123 1 7.87691L1 4.1231C1 3.99877 1.04939 3.87955 1.13729 3.79164L3.79164 1.13729ZM4.31726 1.9375L1.9375 4.31726L1.9375 7.68274L4.31726 10.0625H7.68274L10.0625 7.68274V4.31726L7.68274 1.9375L4.31726 1.9375Z",
			stroke: "#CF222E",
			strokeWidth: "0.45",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M3.79164 5.67178C3.79164 5.46467 3.95953 5.29678 4.16664 5.29678H7.82984C8.03692 5.29678 8.20484 5.46467 8.20484 5.67178V6.35012C8.20484 6.55723 8.03692 6.72512 7.82984 6.72512H4.16664C3.95953 6.72512 3.79164 6.55723 3.79164 6.35012V5.67178Z",
			stroke: "#CF222E",
			strokeWidth: "0.45",
			strokeLinejoin: "round"
		})
	]
});
OutlineBlockedIcon.displayName = "OutlineBlockedIcon";
function SubIssueStateIcon(t0) {
	const $ = c(8);
	const { dataKey } = t0;
	const { state, stateReason, issueDependenciesSummary } = (0, import_react_relay.useFragment)(stateIconFragment, dataKey);
	let t1;
	if ($[0] !== state || $[1] !== stateReason) {
		t1 = {
			state,
			stateReason
		};
		$[0] = state;
		$[1] = stateReason;
		$[2] = t1;
	} else t1 = $[2];
	const { sourceIcon } = useIssueState(t1);
	let t2;
	let t3;
	if ($[3] !== issueDependenciesSummary?.blockedBy || $[4] !== sourceIcon || $[5] !== state) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const SubIssueIcon = sourceIcon("Issue");
			if (state !== IssueState.CLOSED && issueDependenciesSummary?.blockedBy > 0) {
				const stateIconWithBlockedStatus = jsxs("div", {
					className: SubIssueStateIcon_module_default.blockedIssueIconWrapper,
					children: [jsx(OutlineBlockedIcon, {}), jsx(SubIssueIcon, { className: SubIssueStateIcon_module_default.issueIcon })]
				});
				t3 = jsx(NestedListItemLeadingVisual, {
					"data-testid": "nested-list-item-state-icon",
					children: stateIconWithBlockedStatus
				});
				break bb0;
			}
			t2 = jsx(NestedListItemLeadingVisual, {
				icon: SubIssueIcon,
				"data-testid": "nested-list-item-state-icon"
			});
		}
		$[3] = issueDependenciesSummary?.blockedBy;
		$[4] = sourceIcon;
		$[5] = state;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
SubIssueStateIcon.displayName = "SubIssueStateIcon";
var SubIssuesListItem_module_default = {
	Box_0: "SubIssuesListItem-module_qqJFMG_Box_0",
	Box_1: "SubIssuesListItem-module_qqJFMG_Box_1",
	Box_2: "SubIssuesListItem-module_qqJFMG_Box_2",
	itemMetadataContainer: "SubIssuesListItem-module_qqJFMG_itemMetadataContainer",
	Link_0: "SubIssuesListItem-module_qqJFMG_Link_0",
	metadataContainer: "SubIssuesListItem-module_qqJFMG_metadataContainer",
	NestedListItemMetadata_0: "SubIssuesListItem-module_qqJFMG_NestedListItemMetadata_0",
	Octicon_0: "SubIssuesListItem-module_qqJFMG_Octicon_0",
	Octicon_1: "SubIssuesListItem-module_qqJFMG_Octicon_1"
};
var node$5 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "fetchSubIssues"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "issueId"
	}, v2 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "issueId"
	}], v3 = [{
		"kind": "Variable",
		"name": "fetchSubIssues",
		"variableName": "fetchSubIssues"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "state",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "stateReason",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueDependenciesSummary",
		"kind": "LinkedField",
		"name": "issueDependenciesSummary",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "blockedBy",
			"storageKey": null
		}],
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "closed",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueType",
		"kind": "LinkedField",
		"name": "issueType",
		"plural": false,
		"selections": [
			v6,
			v12,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "color",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"concreteType": "Repository",
		"kind": "LinkedField",
		"name": "repository",
		"plural": false,
		"selections": [
			v12,
			{
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					},
					v14,
					v6
				],
				"storageKey": null
			},
			v6
		],
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 10
		}],
		"concreteType": "UserConnection",
		"kind": "LinkedField",
		"name": "assignees",
		"plural": false,
		"selections": [v16, {
			"alias": null,
			"args": null,
			"concreteType": "UserEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v6,
					v14,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "avatarUrl",
						"storageKey": null
					}
				],
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "assignees(first:10)"
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": null,
		"concreteType": "SubIssuesSummary",
		"kind": "LinkedField",
		"name": "subIssuesSummary",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "total",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "completed",
			"storageKey": null
		}],
		"storageKey": null
	}, v21 = [v16], v22 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 0
		}, {
			"kind": "Literal",
			"name": "includeClosedPrs",
			"value": true
		}],
		"concreteType": "PullRequestConnection",
		"kind": "LinkedField",
		"name": "closedByPullRequestsReferences",
		"plural": false,
		"selections": v21,
		"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "subIssueSubscription",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "IssueUpdatedPayload",
				"kind": "LinkedField",
				"name": "issueUpdated",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueTitleUpdated",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SubIssueTitle_TitleValue"
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueStateUpdated",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SubIssueStateIcon"
						}, {
							"args": null,
							"kind": "FragmentSpread",
							"name": "useSubIssuesSummary_issueState"
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueTypeUpdated",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SubIssueTypeIndicator"
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueMetadataUpdated",
						"plural": false,
						"selections": [{
							"args": null,
							"kind": "FragmentSpread",
							"name": "SubIssuesListItem"
						}],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "subIssuesUpdated",
						"plural": false,
						"selections": [{
							"args": v3,
							"kind": "FragmentSpread",
							"name": "SubIssuesCompletionPill"
						}, {
							"args": v3,
							"kind": "FragmentSpread",
							"name": "SubIssuesListItem_NestedSubIssues"
						}],
						"storageKey": null
					},
					{
						"condition": "fetchSubIssues",
						"kind": "Condition",
						"passingValue": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "subIssuesSummaryUpdated",
							"plural": false,
							"selections": [{
								"args": [{
									"kind": "Literal",
									"name": "fetchSubIssues",
									"value": false
								}],
								"kind": "FragmentSpread",
								"name": "useSubIssuesSummary"
							}],
							"storageKey": null
						}]
					}
				],
				"storageKey": null
			}],
			"type": "EventSubscription",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "subIssueSubscription",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "IssueUpdatedPayload",
				"kind": "LinkedField",
				"name": "issueUpdated",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueTitleUpdated",
						"plural": false,
						"selections": [
							v4,
							v5,
							v6
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueStateUpdated",
						"plural": false,
						"selections": [
							v7,
							v8,
							v9,
							v10,
							v6
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueTypeUpdated",
						"plural": false,
						"selections": [
							v11,
							v13,
							v15,
							v6
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "issueMetadataUpdated",
						"plural": false,
						"selections": [
							v6,
							v7,
							v8,
							v9,
							v17,
							v18,
							v15,
							v19,
							v11,
							v4,
							v5,
							v13,
							v20,
							v22
						],
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "subIssuesUpdated",
						"plural": false,
						"selections": [
							{
								"condition": "fetchSubIssues",
								"kind": "Condition",
								"passingValue": false,
								"selections": [v20]
							},
							{
								"condition": "fetchSubIssues",
								"kind": "Condition",
								"passingValue": true,
								"selections": [{
									"alias": "subIssuesConnection",
									"args": null,
									"concreteType": "IssueConnection",
									"kind": "LinkedField",
									"name": "subIssues",
									"plural": false,
									"selections": v21,
									"storageKey": null
								}, {
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 100
									}],
									"concreteType": "IssueConnection",
									"kind": "LinkedField",
									"name": "subIssues",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"concreteType": "Issue",
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											v10,
											v6,
											v7,
											v8,
											v9,
											v17,
											v18,
											v15,
											v19,
											v11,
											v4,
											v5,
											v13,
											v20,
											v22
										],
										"storageKey": null
									}],
									"storageKey": "subIssues(first:100)"
								}]
							},
							v18,
							v19,
							v11,
							v15,
							v7,
							v8,
							v4,
							v5,
							v13,
							v6
						],
						"storageKey": null
					},
					{
						"condition": "fetchSubIssues",
						"kind": "Condition",
						"passingValue": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "Issue",
							"kind": "LinkedField",
							"name": "subIssuesSummaryUpdated",
							"plural": false,
							"selections": [v20, v6],
							"storageKey": null
						}]
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "e5c84b39a86c226d0e08a054ff93845d",
			"metadata": {},
			"name": "subIssueSubscription",
			"operationKind": "subscription",
			"text": null
		}
	};
})();
node$5.hash = "a24cb8da732ab12e814044ad323e83e9";
var subscription = node$5;
var useSubIssueSubscription = (issueId, t0) => {
	const $ = c(3);
	const { fetchSubIssues } = t0;
	let t1;
	if ($[0] !== fetchSubIssues || $[1] !== issueId) {
		t1 = {
			variables: {
				issueId,
				fetchSubIssues
			},
			subscription
		};
		$[0] = fetchSubIssues;
		$[1] = issueId;
		$[2] = t1;
	} else t1 = $[2];
	(0, import_react_relay.useSubscription)(t1);
};
var node$4 = {
	"argumentDefinitions": [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "fetchSubIssues"
	}],
	"kind": "Fragment",
	"metadata": null,
	"name": "SubIssueTitle",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "url",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "databaseId",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "number",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "login",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "state",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "stateReason",
			"storageKey": null
		},
		{
			"args": null,
			"kind": "FragmentSpread",
			"name": "SubIssueTitle_TitleValue"
		},
		{
			"args": null,
			"kind": "FragmentSpread",
			"name": "SubIssueTypeIndicator"
		},
		{
			"args": [{
				"kind": "Variable",
				"name": "fetchSubIssues",
				"variableName": "fetchSubIssues"
			}],
			"kind": "FragmentSpread",
			"name": "SubIssuesCompletionPill"
		}
	],
	"type": "Issue",
	"abstractKey": null
};
node$4.hash = "0fadc40faceaf46e58836010333f80f0";
var node$3 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "SubIssueTitle_TitleValue",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "titleHTML",
		"storageKey": null
	}],
	"type": "Issue",
	"abstractKey": null
};
node$3.hash = "e376c37263bb0bff11cb5ab377b21c80";
var node$2 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "SubIssueTypeIndicator",
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "number",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "IssueType",
				"kind": "LinkedField",
				"name": "issueType",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "id",
						"storageKey": null
					},
					v0,
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "color",
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [v0, {
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "owner",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "login",
						"storageKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$2.hash = "c8e44f514d979b1f8816f991e03767d0";
var LeadingBadge_module_default = {
	container: "LeadingBadge-module_rwvvNW_container",
	titleLabel: "LeadingBadge-module_rwvvNW_titleLabel",
	titleText: "LeadingBadge-module_rwvvNW_titleText"
};
function NestedListItemLeadingBadge(t0) {
	const $ = c(4);
	const { title, href, className, color, ...props } = t0;
	const { setLeadingBadge } = useNestedListItemLeadingBadge();
	let t1;
	let t2;
	if ($[0] !== setLeadingBadge || $[1] !== title) {
		t1 = () => setLeadingBadge(title);
		t2 = [setLeadingBadge, title];
		$[0] = setLeadingBadge;
		$[1] = title;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	const { fg, bg, border } = useNamedColor(color);
	const content = jsxs(Fragment$1, { children: [jsx(Label, {
		className: LeadingBadge_module_default.titleLabel,
		...testIdProps("nested-list-view-item-leading-badge-label"),
		style: {
			color: fg,
			backgroundColor: bg,
			borderColor: border
		},
		...props,
		children: jsx("span", {
			className: LeadingBadge_module_default.titleText,
			children: title
		})
	}), jsx("span", {
		className: "sr-only",
		children: ": "
	})] });
	if (href) return jsx(Link, {
		href,
		...testIdProps("nested-list-view-item-leading-badge"),
		className: clsx(LeadingBadge_module_default.container, className),
		"aria-hidden": true,
		tabIndex: -1,
		children: content
	});
	else return jsx("span", {
		...testIdProps("nested-list-view-item-leading-badge"),
		className: clsx(LeadingBadge_module_default.container, className),
		children: content
	});
}
NestedListItemLeadingBadge.displayName = "NestedListItemLeadingBadge";
var SubIssueTypeIndicator_module_default = { container: "SubIssueTypeIndicator-module_yzSQua_container" };
var subIssueTypeQuery = node$2;
var SubIssueTypeIndicator = (t0) => {
	const $ = c(16);
	const { dataKey, onRender } = t0;
	const { issueType, number, repository } = (0, import_react_relay.useFragment)(subIssueTypeQuery, dataKey);
	const shouldNotRender = !issueType?.id || !issueType?.name;
	let t1;
	let t2;
	if ($[0] !== onRender || $[1] !== shouldNotRender) {
		t1 = () => {
			if (!shouldNotRender && onRender) onRender?.(true);
		};
		t2 = [onRender, shouldNotRender];
		$[0] = onRender;
		$[1] = shouldNotRender;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	if (shouldNotRender) return null;
	let t3;
	if ($[4] !== issueType.name) {
		let t4;
		if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
			t4 = /\s/g;
			$[6] = t4;
		} else t4 = $[6];
		t3 = issueType.name.replace(t4, "-");
		$[4] = issueType.name;
		$[5] = t3;
	} else t3 = $[5];
	const t4 = `${number}-sub-issue-type-indicator-${t3}`;
	let t5;
	if ($[7] !== issueType.color) {
		t5 = isColorName(issueType.color) ? issueType.color : void 0;
		$[7] = issueType.color;
		$[8] = t5;
	} else t5 = $[8];
	let t6;
	if ($[9] !== issueType.id || $[10] !== issueType.name || $[11] !== repository.name || $[12] !== repository.owner.login || $[13] !== t4 || $[14] !== t5) {
		t6 = jsx(NestedListItemLeadingBadge, {
			"data-testid": t4,
			className: SubIssueTypeIndicator_module_default.container,
			size: "small",
			variant: "secondary",
			title: issueType.name,
			color: t5,
			href: getIssueSearchURL({
				owner: repository.owner.login,
				repo: repository.name
			}, "type", issueType.name)
		}, issueType.id);
		$[9] = issueType.id;
		$[10] = issueType.name;
		$[11] = repository.name;
		$[12] = repository.owner.login;
		$[13] = t4;
		$[14] = t5;
		$[15] = t6;
	} else t6 = $[15];
	return t6;
};
SubIssueTypeIndicator.displayName = "SubIssueTypeIndicator";
var TrailingBadge_module_default = {
	container: "TrailingBadge-module_c0w6Ea_container",
	label: "TrailingBadge-module_c0w6Ea_label",
	title: "TrailingBadge-module_c0w6Ea_title"
};
var NestedListItemTrailingBadge = ({ title, className, children, ...props }) => {
	const trailingBadgesContainerRef = useRef(null);
	useSuppressActions(trailingBadgesContainerRef);
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("nested-list-view-item-trailing-badge"),
		className: clsx(TrailingBadge_module_default.container, className),
		"aria-hidden": true,
		ref: trailingBadgesContainerRef,
		children: children || /* @__PURE__ */ jsx(Label, {
			className: TrailingBadge_module_default.label,
			...props,
			children: /* @__PURE__ */ jsx("span", {
				className: TrailingBadge_module_default.title,
				children: title
			})
		})
	});
};
NestedListItemTrailingBadge.displayName = "NestedListItemTrailingBadge";
var node$1 = {
	"argumentDefinitions": [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "fetchSubIssues"
	}],
	"kind": "Fragment",
	"metadata": null,
	"name": "SubIssuesCompletionPill",
	"selections": [{
		"args": [{
			"kind": "Variable",
			"name": "fetchSubIssues",
			"variableName": "fetchSubIssues"
		}],
		"kind": "FragmentSpread",
		"name": "useSubIssuesSummary"
	}, {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}],
	"type": "Issue",
	"abstractKey": null
};
node$1.hash = "a66950424aa6b94142e27c70813c0183";
function SubIssuesCompletionPill(t0) {
	const $ = c(4);
	const { issueKey, onClick } = t0;
	const node = (0, import_react_relay.useFragment)(node$1, issueKey);
	const { url } = node;
	const progress = useSubIssuesSummary(node);
	let t1;
	if ($[0] !== onClick || $[1] !== progress || $[2] !== url) {
		t1 = progress.total > 0 ? jsx(NestedListViewCompletionPill, {
			progress,
			href: url,
			onClick
		}) : null;
		$[0] = onClick;
		$[1] = progress;
		$[2] = url;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
SubIssuesCompletionPill.displayName = "SubIssuesCompletionPill";
var SubIssueTitle_module_default = {
	titleAnchor: "SubIssueTitle-module_ev8GBG_titleAnchor",
	titleNumber: "SubIssueTitle-module_ev8GBG_titleNumber"
};
function SubIssueTitle(t0) {
	const $ = c(37);
	const { issueKey, onClick: externalOnClick, parentRepoName, parentOwnerName, queryToPreheat } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const issueNode = (0, import_react_relay.useFragment)(node$4, issueKey);
	const { databaseId: id, state, stateReason, url, number, repository } = issueNode;
	const { title, titleHTML } = (0, import_react_relay.useFragment)(node$3, issueNode);
	let t1;
	let t2;
	if ($[0] !== externalOnClick || $[1] !== getHovercardAttributesForType || $[2] !== id || $[3] !== issueNode || $[4] !== number || $[5] !== parentOwnerName || $[6] !== parentRepoName || $[7] !== queryToPreheat || $[8] !== repository || $[9] !== state || $[10] !== stateReason || $[11] !== title || $[12] !== titleHTML || $[13] !== url) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const hovercardAttributes = getHovercardAttributesForType("issue", {
				issueNumber: number,
				repo: repository.name,
				owner: repository.owner.login
			});
			let t3;
			if ($[16] !== externalOnClick || $[17] !== id || $[18] !== number || $[19] !== repository.name || $[20] !== repository.owner.login || $[21] !== state || $[22] !== stateReason || $[23] !== title || $[24] !== url) {
				t3 = (event) => {
					if (event.button === 1 || event.shiftKey || event.ctrlKey || event.metaKey) return;
					if (externalOnClick) {
						event.preventDefault();
						externalOnClick({
							id: id ?? 0,
							number,
							owner: repository.owner.login,
							repo: repository.name,
							state,
							stateReason,
							title,
							url
						});
					}
				};
				$[16] = externalOnClick;
				$[17] = id;
				$[18] = number;
				$[19] = repository.name;
				$[20] = repository.owner.login;
				$[21] = state;
				$[22] = stateReason;
				$[23] = title;
				$[24] = url;
				$[25] = t3;
			} else t3 = $[25];
			const onClick = t3;
			let t4;
			bb1: {
				let t5;
				if ($[26] !== issueNode || $[27] !== onClick) {
					const completionPill = jsx(SubIssuesCompletionPill, {
						onClick,
						issueKey: issueNode
					});
					t5 = completionPill ? jsx(NestedListItemTrailingBadge, {
						title: "Sub-issues",
						children: completionPill
					}, 0) : null;
					$[26] = issueNode;
					$[27] = onClick;
					$[28] = t5;
				} else t5 = $[28];
				const completionMetadata = t5;
				if (completionMetadata) {
					let t6;
					if ($[29] !== completionMetadata) {
						t6 = [completionMetadata];
						$[29] = completionMetadata;
						$[30] = t6;
					} else t6 = $[30];
					t4 = t6;
					break bb1;
				}
				t4 = void 0;
			}
			const trailingBadges = t4;
			let repoTitle = "";
			if (parentOwnerName && parentOwnerName !== repository.owner.login) repoTitle = `${repository.owner.login}/${repository.name}`;
			else if (parentRepoName && parentRepoName !== repository.name) repoTitle = repository.name;
			let t5;
			if ($[31] !== title || $[32] !== titleHTML) {
				t5 = getIssueTitle(title, titleHTML);
				$[31] = title;
				$[32] = titleHTML;
				$[33] = t5;
			} else t5 = $[33];
			let t6;
			if ($[34] !== number || $[35] !== repoTitle) {
				t6 = renderToString(jsxs("span", {
					className: SubIssueTitle_module_default.titleNumber,
					children: [
						repoTitle,
						"#",
						number
					]
				}));
				$[34] = number;
				$[35] = repoTitle;
				$[36] = t6;
			} else t6 = $[36];
			const titleWithNumber = `${t5} ${t6}`;
			if (issueNode.number !== void 0 && queryToPreheat) {
				t2 = jsx(NestedListItemTitleWithPreheat, {
					value: titleWithNumber,
					href: url,
					additionalLinkProps: hovercardAttributes,
					leadingBadge: jsx(SubIssueTypeIndicator, { dataKey: issueNode }),
					onClick,
					trailingBadges,
					anchorClassName: clsx(SubIssueTitle_module_default.titleAnchor, "markdown-title"),
					issueNode,
					queryToPreheat
				});
				break bb0;
			}
			t1 = jsx(NestedListItemTitle, {
				value: titleWithNumber,
				href: url,
				additionalLinkProps: hovercardAttributes,
				leadingBadge: jsx(SubIssueTypeIndicator, { dataKey: issueNode }),
				onClick,
				trailingBadges,
				anchorClassName: clsx(SubIssueTitle_module_default.titleAnchor, "markdown-title")
			});
		}
		$[0] = externalOnClick;
		$[1] = getHovercardAttributesForType;
		$[2] = id;
		$[3] = issueNode;
		$[4] = number;
		$[5] = parentOwnerName;
		$[6] = parentRepoName;
		$[7] = queryToPreheat;
		$[8] = repository;
		$[9] = state;
		$[10] = stateReason;
		$[11] = title;
		$[12] = titleHTML;
		$[13] = url;
		$[14] = t1;
		$[15] = t2;
	} else {
		t1 = $[14];
		t2 = $[15];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
SubIssueTitle.displayName = "SubIssueTitle";
function NestedListItemTitleWithPreheat(t0) {
	const $ = c(7);
	const { issueNode, queryToPreheat, ...titleProps } = t0;
	let t1;
	if ($[0] !== issueNode.number || $[1] !== issueNode.repository.name || $[2] !== issueNode.repository.owner.login) {
		t1 = {
			owner: issueNode.repository.owner.login,
			repo: issueNode.repository.name,
			number: issueNode.number,
			count: 15
		};
		$[0] = issueNode.number;
		$[1] = issueNode.repository.name;
		$[2] = issueNode.repository.owner.login;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== queryToPreheat || $[5] !== t1) {
		t2 = {
			query: queryToPreheat,
			variables: t1,
			source: "SubIssueTitle",
			highPriority: true
		};
		$[4] = queryToPreheat;
		$[5] = t1;
		$[6] = t2;
	} else t2 = $[6];
	useCachePreheatQuery(t2);
	return jsx(NestedListItemTitle, { ...titleProps });
}
NestedListItemTitleWithPreheat.displayName = "NestedListItemTitleWithPreheat";
var SubIssuesListItem_NestedSubIssues = node$8;
var SubIssuesListItemFragment = node$7;
function SubIssuesListItem({ parentIssueId, parentRepoName, parentOwnerName, issueKey, onSubIssueClick, dnd = false, isDragOverlay = false, readonly = false, queryToPreheat }) {
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const issueNode = (0, import_react_relay.useFragment)(SubIssuesListItemFragment, issueKey);
	const [subIssuesData, refetch] = (0, import_react_relay.useRefetchableFragment)(SubIssuesListItem_NestedSubIssues, issueNode);
	const subItems = useMemo(() => {
		const elements = subIssuesData?.subIssues?.nodes?.reduce((arr, subIssueNode) => {
			if (subIssueNode) arr.push(/* @__PURE__ */ jsx(SubIssuesListItem, {
				issueKey: subIssueNode,
				parentRepoName,
				parentOwnerName,
				parentIssueId: issueNode.id,
				onSubIssueClick,
				readonly,
				queryToPreheat
			}, subIssueNode.id));
			return arr;
		}, []);
		if (!elements || elements.length === 0) return void 0;
		return elements;
	}, [
		subIssuesData?.subIssues?.nodes,
		parentRepoName,
		parentOwnerName,
		issueNode.id,
		onSubIssueClick,
		readonly,
		queryToPreheat
	]);
	const isTempSubIssue = issueNode.id.startsWith(TEMP_SUB_ISSUE_ID_PREFIX);
	if (isLoggedIn() && !isTempSubIssue) useSubIssueSubscription(issueNode.id, { fetchSubIssues: subItems !== void 0 });
	const subItemsCount = subIssuesData.subIssuesConnection?.totalCount || subIssuesData.subIssuesSummary?.total || 0;
	if (!issueNode) return null;
	return /* @__PURE__ */ jsx(NestedListItem, {
		className: SubIssuesListItem_module_default.metadataContainer,
		metadataContainerClassName: SubIssuesListItem_module_default.itemMetadataContainer,
		dragAndDropProps: {
			isOverlay: isDragOverlay,
			showTrigger: dnd,
			itemId: issueNode.id
		},
		title: /* @__PURE__ */ jsx(SubIssueTitle, {
			issueKey: subIssuesData,
			onClick: isTempSubIssue ? noop : onSubIssueClick,
			parentRepoName,
			parentOwnerName,
			queryToPreheat
		}),
		secondaryActions: readonly ? void 0 : /* @__PURE__ */ jsx(SubIssuesActionBar, {
			issueId: parentIssueId,
			subIssueId: issueNode.id,
			subIssueUrl: issueNode.url
		}),
		metadata: /* @__PURE__ */ jsxs(NestedListItemMetadata, {
			alignment: "right",
			className: SubIssuesListItem_module_default.NestedListItemMetadata_0,
			children: [/* @__PURE__ */ jsx("div", {
				className: SubIssuesListItem_module_default.Box_0,
				children: /* @__PURE__ */ jsx(ClosedByPullRequestsReferences, {
					issueId: issueNode.id,
					closedByPullRequestsReferencesKey: issueNode
				})
			}), /* @__PURE__ */ jsx("div", {
				className: SubIssuesListItem_module_default.Box_1,
				children: issueNode.assignees.totalCount === 0 ? /* @__PURE__ */ jsxs("div", {
					className: SubIssuesListItem_module_default.Box_2,
					children: [/* @__PURE__ */ jsx(Octicon, {
						icon: PersonIcon,
						className: SubIssuesListItem_module_default.Octicon_0
					}), /* @__PURE__ */ jsx(Octicon, {
						size: 24,
						icon: CircleIcon,
						className: SubIssuesListItem_module_default.Octicon_1
					})]
				}) : /* @__PURE__ */ jsx(AvatarStack, {
					alignRight: true,
					children: issueNode.assignees.edges?.map((assigneeEdge) => {
						if (!assigneeEdge?.node) return null;
						return /* @__PURE__ */ jsx(Link, {
							href: getIssueSearchURL({
								owner: issueNode.repository.owner.login,
								repo: issueNode.repository.name
							}, "assignee", assigneeEdge.node.login),
							...getHovercardAttributesForType("user", { login: assigneeEdge.node.login }),
							className: SubIssuesListItem_module_default.Link_0,
							children: /* @__PURE__ */ jsx(GitHubAvatar, {
								alt: assigneeEdge.node.login,
								src: assigneeEdge.node.avatarUrl
							}, assigneeEdge.node.id)
						}, assigneeEdge.node.id);
					})
				})
			})]
		}),
		subItemsCount,
		loadSubItems: async () => {
			refetch({ fetchSubIssues: true });
		},
		subItems,
		children: /* @__PURE__ */ jsx(NestedListItemLeadingContent, { children: /* @__PURE__ */ jsx(SubIssueStateIcon, { dataKey: issueNode }) })
	}, issueNode.id);
}
SubIssuesListItem.displayName = "SubIssuesListItem";
var SubIssuesListView_module_default = {
	observableBox: "SubIssuesListView-module_L-7TwW_observableBox",
	stickyHeader: "SubIssuesListView-module_L-7TwW_stickyHeader"
};
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 100
		}],
		"concreteType": "IssueConnection",
		"kind": "LinkedField",
		"name": "subIssues",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "nodes",
			"plural": true,
			"selections": [v2],
			"storageKey": null
		}],
		"storageKey": "subIssues(first:100)"
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "reprioritizeSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReprioritizeSubIssuePayload",
				"kind": "LinkedField",
				"name": "reprioritizeSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "SubIssuesListItem"
					}, v3],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "reprioritizeSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "ReprioritizeSubIssuePayload",
				"kind": "LinkedField",
				"name": "reprioritizeSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v2,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "state",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "stateReason",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueDependenciesSummary",
							"kind": "LinkedField",
							"name": "issueDependenciesSummary",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "blockedBy",
								"storageKey": null
							}],
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 10
							}],
							"concreteType": "UserConnection",
							"kind": "LinkedField",
							"name": "assignees",
							"plural": false,
							"selections": [v4, {
								"alias": null,
								"args": null,
								"concreteType": "UserEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "User",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v2,
										v5,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "avatarUrl",
											"storageKey": null
										}
									],
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "assignees(first:10)"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "url",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "repository",
							"plural": false,
							"selections": [
								v6,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "__typename",
											"storageKey": null
										},
										v5,
										v2
									],
									"storageKey": null
								},
								v2
							],
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "databaseId",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "number",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "title",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "titleHTML",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueType",
							"kind": "LinkedField",
							"name": "issueType",
							"plural": false,
							"selections": [
								v2,
								v6,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "color",
									"storageKey": null
								}
							],
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "SubIssuesSummary",
							"kind": "LinkedField",
							"name": "subIssuesSummary",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "total",
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "completed",
								"storageKey": null
							}],
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 0
							}, {
								"kind": "Literal",
								"name": "includeClosedPrs",
								"value": true
							}],
							"concreteType": "PullRequestConnection",
							"kind": "LinkedField",
							"name": "closedByPullRequestsReferences",
							"plural": false,
							"selections": [v4],
							"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
						},
						v3
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "91b29e713cceb0b2ed4b0544ec4394d2",
			"metadata": {},
			"name": "reprioritizeSubIssueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "df88a2e7bb24a566ac0feaace455b2f1";
function reprioritizeSubIssueMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		variables: { input },
		optimisticUpdater: (store) => {
			const subIssues = store.get(input.issueId)?.getLinkedRecord("subIssues(first:100)");
			if (!subIssues) return;
			const nodes = subIssues.getLinkedRecords("nodes");
			if (!nodes) return;
			const reorderedNodes = [...nodes];
			const dragIssueIndex = reorderedNodes.findIndex((node) => node.getDataID() === input.subIssueId);
			const dropIssueIndex = reorderedNodes.findIndex((node) => node.getDataID() === (input.beforeId || input.afterId));
			const draggedIssue = reorderedNodes[dragIssueIndex];
			if (draggedIssue) {
				reorderedNodes.splice(dragIssueIndex, 1);
				reorderedNodes.splice(dropIssueIndex, 0, draggedIssue);
			}
			subIssues.setLinkedRecords(reorderedNodes, "nodes");
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var SubIssuesListLoadingSkeleton_module_default = {
	Box: "SubIssuesListLoadingSkeleton-module_Q4NQiq_Box",
	Heading: "SubIssuesListLoadingSkeleton-module_Q4NQiq_Heading",
	LoadingBox: "SubIssuesListLoadingSkeleton-module_Q4NQiq_LoadingBox"
};
function SubIssuesListLoadingSkeleton() {
	return /* @__PURE__ */ jsxs("div", {
		"data-testid": "sub-issues-loading-skeleton",
		children: [/* @__PURE__ */ jsx("div", {
			className: SubIssuesListLoadingSkeleton_module_default.Box,
			children: /* @__PURE__ */ jsx("h3", {
				className: SubIssuesListLoadingSkeleton_module_default.Heading,
				children: "Sub-issues"
			})
		}), /* @__PURE__ */ jsx("div", {
			className: SubIssuesListLoadingSkeleton_module_default.LoadingBox,
			children: /* @__PURE__ */ jsx(LoadingSkeleton, {})
		})]
	});
}
SubIssuesListLoadingSkeleton.displayName = "SubIssuesListLoadingSkeleton";
var SubIssuesListViewGraphQLFragment = node$10;
function SubIssuesListView({ onSubIssueClick, issueKey, readonly = false, queryToPreheat }) {
	const data = (0, import_react_relay.useFragment)(SubIssuesListViewGraphQLFragment, issueKey);
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const { addToast } = useToastContext();
	const reprioritizeSubIssue = useCallback(({ issueId, dragIssueId, dropIssueId, isBefore }) => {
		reprioritizeSubIssueMutation({
			environment,
			input: {
				issueId,
				subIssueId: dragIssueId,
				[isBefore ? "beforeId" : "afterId"]: dropIssueId
			},
			onError: (error) => {
				addToast({
					type: "error",
					message: error.message
				});
			}
		});
	}, [environment, addToast]);
	const progress = useSubIssuesSummary(data ?? void 0);
	const { isSticky, hasRoots, sensorRef } = useStickyHeader();
	if (!data) return /* @__PURE__ */ jsx(SubIssuesListLoadingSkeleton, {});
	return /* @__PURE__ */ jsxs(NestedListView, {
		isReadOnly: readonly,
		title: "Sub-issues",
		singularUnits: "Issue",
		pluralUnits: "Issues",
		header: /* @__PURE__ */ jsx(NestedListViewHeader, {
			title: /* @__PURE__ */ jsx(NestedListViewHeaderTitle, {
				title: "Sub-issues",
				scrollToOnCollapseOffset: isSticky ? -52 : void 0
			}),
			className: clsx(isSticky && hasRoots && SubIssuesListView_module_default.stickyHeader),
			completionPill: /* @__PURE__ */ jsx(NestedListViewCompletionPill, { progress })
		}),
		isCollapsible: true,
		dragAndDropProps: {
			onDrop: ({ dragMetadata, dropMetadata, isBefore: isBefore_0 }) => {
				if (dragMetadata.id === dropMetadata.id) return;
				reprioritizeSubIssue({
					issueId: data.id,
					dragIssueId: dragMetadata.id,
					dropIssueId: dropMetadata.id,
					isBefore: isBefore_0
				});
			},
			renderOverlay: ({ id }) => {
				const issueNode = data?.subIssues?.nodes?.find((issue) => issue?.id === id);
				if (!issueNode) return /* @__PURE__ */ jsx(Fragment$1, {});
				if (!data?.id) return /* @__PURE__ */ jsx(Fragment$1, {});
				return /* @__PURE__ */ jsx(NestedListView, {
					title: "overlay",
					isReadOnly: readonly,
					children: /* @__PURE__ */ jsx(SubIssuesListItem, {
						issueKey: issueNode,
						parentRepoName: data?.repository?.name,
						parentOwnerName: data?.repository?.owner?.login,
						parentIssueId: data?.id,
						onSubIssueClick,
						dnd: true,
						isDragOverlay: true,
						readonly,
						queryToPreheat
					}, issueNode.id)
				});
			},
			items: data.subIssues?.nodes?.map((issueNode_0) => {
				if (!issueNode_0 || !issueNode_0?.id) return {
					id: "",
					title: "",
					node: null
				};
				return {
					id: issueNode_0.id,
					title: issueNode_0.id,
					node: issueNode_0
				};
			}) || []
		},
		children: [/* @__PURE__ */ jsx("div", {
			ref: sensorRef,
			className: SubIssuesListView_module_default.observableBox
		}), data.subIssues.nodes?.map((issueNode_1) => {
			if (!issueNode_1) return null;
			if (!data.id) return null;
			return /* @__PURE__ */ jsx(SubIssuesListItem, {
				issueKey: issueNode_1,
				parentIssueId: data.id,
				parentRepoName: data?.repository?.name,
				parentOwnerName: data?.repository?.owner?.login,
				onSubIssueClick,
				dnd: true,
				readonly,
				queryToPreheat
			}, issueNode_1.id);
		})]
	});
}
SubIssuesListView.displayName = "SubIssuesListView";
var SubIssuesList_module_default = {
	Box: "SubIssuesList-module_QGcnXq_Box",
	ButtonGroup: "SubIssuesList-module_QGcnXq_ButtonGroup"
};
function SubIssuesList(t0) {
	const $ = c(6);
	const { issueKey, onSubIssueClick, insideSidePanel, readonly: t1, queryToPreheat } = t0;
	const readonly = t1 === void 0 ? false : t1;
	const subIssuesListData = (0, import_react_relay.useFragment)(node$11, issueKey);
	let t2;
	if ($[0] !== insideSidePanel || $[1] !== onSubIssueClick || $[2] !== queryToPreheat || $[3] !== readonly || $[4] !== subIssuesListData) {
		t2 = jsxs("div", {
			className: SubIssuesList_module_default.Box,
			children: [jsx(SubIssuesListView, {
				onSubIssueClick,
				issueKey: subIssuesListData ?? void 0,
				readonly,
				queryToPreheat
			}), subIssuesListData && !readonly && jsx("div", {
				className: SubIssuesList_module_default.ButtonGroup,
				children: jsx(AddSubIssueButtonGroup, {
					issue: subIssuesListData,
					insideSidePanel
				})
			})]
		});
		$[0] = insideSidePanel;
		$[1] = onSubIssueClick;
		$[2] = queryToPreheat;
		$[3] = readonly;
		$[4] = subIssuesListData;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
SubIssuesList.displayName = "SubIssuesList";
export { SubIssuesList };
