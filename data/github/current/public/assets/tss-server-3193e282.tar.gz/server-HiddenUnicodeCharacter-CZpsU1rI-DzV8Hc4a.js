import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { _n as KebabHorizontalIcon, an as IconButton, pt as DotFillIcon, w as BugIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { b as codeownersErrorPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { createContext, use, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
function useIsSafari() {
	return useSyncExternalStore(subscribe, isSafariInBrowser, isSafariOnServer);
}
function isSafariInBrowser() {
	return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}
function isSafariOnServer() {
	return false;
}
function subscribe() {
	return () => {};
}
var SplitCodeownersErrorsContext = createContext([]);
SplitCodeownersErrorsContext.displayName = "SplitCodeownersErrorsContext";
function useSplitCodeownersErrorsContext() {
	return use(SplitCodeownersErrorsContext);
}
var CodeownersValidationBanner_module_default = {
	Box: "CodeownersValidationBanner-module_SKxWYW_Box",
	Box_1: "CodeownersValidationBanner-module_SKxWYW_Box_1",
	Box_2: "CodeownersValidationBanner-module_SKxWYW_Box_2",
	Box_3: "CodeownersValidationBanner-module_SKxWYW_Box_3",
	Dialog: "CodeownersValidationBanner-module_SKxWYW_Dialog",
	ErrorCodeBlock: "CodeownersValidationBanner-module_SKxWYW_ErrorCodeBlock",
	Flash: "CodeownersValidationBanner-module_SKxWYW_Flash",
	Flash_1: "CodeownersValidationBanner-module_SKxWYW_Flash_1",
	IconButton: "CodeownersValidationBanner-module_SKxWYW_IconButton",
	Octicon: "CodeownersValidationBanner-module_SKxWYW_Octicon"
};
var VALID_CODEOWNERS_FILEPATHS = ["CODEOWNERS", "/CODEOWNERS"];
var CodeownersValidationState = {
	ERROR: "ERROR",
	LOADING: "LOADING",
	VALIDATED: "VALIDATED"
};
function CodeownersValidationBanner(t0) {
	const $ = c(14);
	const { filePath, forceRender, full, refName, repo } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [validationErrors, setValidationErrors] = useState(t1);
	const [validationState, setValidationState] = useState(CodeownersValidationState.LOADING);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = isFeatureEnabled("codeowners_validation_in_diff");
		$[1] = t2;
	} else t2 = $[1];
	const isCodeownersValidationInDiffEnabled = t2;
	let t3;
	if ($[2] !== filePath) {
		t3 = VALID_CODEOWNERS_FILEPATHS.includes(filePath);
		$[2] = filePath;
		$[3] = t3;
	} else t3 = $[3];
	const showBanner = forceRender || isCodeownersValidationInDiffEnabled && t3;
	const fetchingDataRef = useRef(false);
	let t4;
	let t5;
	if ($[4] !== filePath || $[5] !== refName || $[6] !== repo || $[7] !== showBanner) {
		t4 = () => {
			if (!showBanner) return;
			if (fetchingDataRef.current) return;
			const getCodeownersValidity = async () => {
				fetchingDataRef.current = true;
				try {
					const response = await fetchCodeownersValidity(repo, { name: refName }, filePath);
					if (response.ok) {
						setValidationErrors((await response.json()).map(buildSplitCodeownersError));
						setValidationState(CodeownersValidationState.VALIDATED);
					} else setValidationState(CodeownersValidationState.ERROR);
				} catch {
					setValidationState(CodeownersValidationState.ERROR);
				}
			};
			getCodeownersValidity();
		};
		t5 = [
			filePath,
			refName,
			repo,
			showBanner
		];
		$[4] = filePath;
		$[5] = refName;
		$[6] = repo;
		$[7] = showBanner;
		$[8] = t4;
		$[9] = t5;
	} else {
		t4 = $[8];
		t5 = $[9];
	}
	useEffect(t4, t5);
	if (!showBanner) return null;
	let t6;
	if ($[10] !== full || $[11] !== validationErrors || $[12] !== validationState) {
		t6 = jsx(SplitCodeownersErrorsContext, {
			value: validationErrors,
			children: jsx(CodeownersValidationBannerInner, {
				validationErrors,
				validationState,
				full
			})
		});
		$[10] = full;
		$[11] = validationErrors;
		$[12] = validationState;
		$[13] = t6;
	} else t6 = $[13];
	return t6;
}
CodeownersValidationBanner.displayName = "CodeownersValidationBanner";
function CodeownersValidationBannerInner({ full, validationErrors, validationState }) {
	const [open, setOpen] = useState(false);
	const expandErrorButtonRef = useRef(null);
	if (validationState === CodeownersValidationState.ERROR) return /* @__PURE__ */ jsx(Flash, {
		variant: "warning",
		className: CodeownersValidationBanner_module_default.Flash,
		full,
		children: "Failed to validate this CODEOWNERS file"
	});
	if (validationState === CodeownersValidationState.LOADING) return /* @__PURE__ */ jsx(Flash, {
		variant: "default",
		className: CodeownersValidationBanner_module_default.Flash,
		full,
		children: "Validating CODEOWNERS rules..."
	});
	if (validationErrors.length === 0) return /* @__PURE__ */ jsx(Flash, {
		variant: "success",
		className: CodeownersValidationBanner_module_default.Flash,
		full,
		children: "This CODEOWNERS file is valid."
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className: CodeownersValidationBanner_module_default.Flash_1,
		full,
		children: [/* @__PURE__ */ jsx(Octicon, { icon: BugIcon }), /* @__PURE__ */ jsxs("div", {
			onClick: () => setOpen(!open),
			className: CodeownersValidationBanner_module_default.Box,
			children: ["This CODEOWNERS file contains errors", /* @__PURE__ */ jsx(IconButton, {
				"aria-label": "View CODEOWNERS errors",
				tooltipDirection: "s",
				ref: expandErrorButtonRef,
				size: "small",
				icon: KebabHorizontalIcon,
				className: CodeownersValidationBanner_module_default.IconButton
			})]
		})]
	}), /* @__PURE__ */ jsxs(Dialog_default, {
		isOpen: open,
		onDismiss: () => setOpen(false),
		returnFocusRef: expandErrorButtonRef,
		className: CodeownersValidationBanner_module_default.Dialog,
		children: [/* @__PURE__ */ jsx(Dialog_default.Header, { children: "CODEOWNERS errors" }), /* @__PURE__ */ jsx("div", {
			className: CodeownersValidationBanner_module_default.Box_1,
			children: validationErrors.map((error, index) => {
				return /* @__PURE__ */ jsx(CodeownersErrorDetails, { error }, index);
			})
		})]
	})] });
}
CodeownersValidationBannerInner.displayName = "CodeownersValidationBannerInner";
function CodeownersErrorDetails({ error }) {
	return /* @__PURE__ */ jsxs("div", {
		className: CodeownersValidationBanner_module_default.Box_2,
		children: [`${error.kind} on line ${error.line}${error.suggestion ? `: ${error.suggestion}` : ""}`, /* @__PURE__ */ jsx("pre", {
			className: clsx(CodeownersValidationBanner_module_default.Flash, CodeownersValidationBanner_module_default.ErrorCodeBlock),
			children: /* @__PURE__ */ jsxs("code", { children: [
				error.linePrefix,
				/* @__PURE__ */ jsx("b", {
					className: CodeownersValidationBanner_module_default.Box_3,
					children: error.lineError
				}),
				error.lineSuffix
			] })
		})]
	});
}
CodeownersErrorDetails.displayName = "CodeownersErrorDetails";
var MAX_ERROR_OFFSET = 30;
var TRUNCATED_LINE_PREFIX = "…";
function buildSplitCodeownersError(error) {
	let line = error.source.trim();
	let errorOffset = error.column - 1;
	let endOffset = calculateEndOffset(errorOffset, error.end_column, line);
	if (errorOffset > MAX_ERROR_OFFSET) {
		const trimmedCharacters = errorOffset - MAX_ERROR_OFFSET;
		line = TRUNCATED_LINE_PREFIX + line.slice(trimmedCharacters);
		errorOffset -= trimmedCharacters - 1;
		endOffset -= trimmedCharacters - 1;
	}
	return {
		...error,
		linePrefix: line.substring(0, errorOffset),
		lineError: line.substring(errorOffset, endOffset),
		lineSuffix: line.substring(endOffset)
	};
}
function calculateEndOffset(errorOffset, endColumn, line) {
	if (endColumn) return endColumn;
	else if (line.substring(errorOffset).indexOf(" ") > 0) return line.indexOf(" ", errorOffset);
	else return line.length;
}
function CodeownersErrorLineIndicator() {
	return /* @__PURE__ */ jsx(Octicon, {
		icon: DotFillIcon,
		"aria-label": "This line contains CODEOWNERS errors",
		className: CodeownersValidationBanner_module_default.Octicon
	});
}
CodeownersErrorLineIndicator.displayName = "CodeownersErrorLineIndicator";
function fetchCodeownersValidity(repo, refInfo, path) {
	return verifiedFetchJSON(codeownersErrorPath({
		owner: repo.ownerLogin,
		repo: repo.name,
		commitish: refInfo.name,
		filePath: path
	}), { method: "GET" });
}
var hiddenUnicodeRegex = /[\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F}/u;
var hiddenUnicodeRegexG = /[\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F}/gu;
var hiddenUnicodeBoundaryRegex = /([\u202A-\u202E]|[\u2066-\u2069]|\u{E0001}|\u{E007F})/gu;
var hiddenUnicodeReplacementMap = new Map(Object.entries({
	"‪": "U+202A",
	"‫": "U+202B",
	"‬": "U+202C",
	"‭": "U+202D",
	"‮": "U+202E",
	"⁦": "U+2066",
	"⁧": "U+2067",
	"⁨": "U+2068",
	"⁩": "U+2069",
	"󠀁": "U+E0001",
	"󠁿": "U+E007F"
}));
function hiddenUnicodeCharacterHTMLString(hiddenUnicodeReplacementString) {
	return `<span class="hidden-unicode-replacement" data-code-text="${hiddenUnicodeReplacementString}"></span>`;
}
/**
* Split the given text into an array of strings and hidden Unicode control characters.
*/
function splitAroundHiddenUnicodeCharacters(text) {
	return text.split(hiddenUnicodeBoundaryRegex);
}
function showHiddenUnicodeCharactersRaw(text) {
	if (!hasHiddenUnicodeCharacters(text)) return text;
	return text.replaceAll(hiddenUnicodeRegexG, (char) => hiddenUnicodeReplacementMap.get(char) ?? "");
}
function hasHiddenUnicodeCharacters(text) {
	return hiddenUnicodeRegex.test(text);
}
function getHiddenUnicodeReplacement(char) {
	return hiddenUnicodeReplacementMap.get(char);
}
function HiddenUnicodeCharacter({ char }) {
	return /* @__PURE__ */ jsx("span", {
		className: "hidden-unicode-replacement padded",
		children: char
	});
}
HiddenUnicodeCharacter.displayName = "HiddenUnicodeCharacter";
function hiddenUnicodeCharacterHtmlString(hiddenUnicodeReplacementString) {
	return `<span class="hidden-unicode-replacement">${hiddenUnicodeReplacementString}</span>`;
}
function showHiddenUnicodeCharactersHTML(text) {
	if (!hasHiddenUnicodeCharacters(text)) return null;
	return splitAroundHiddenUnicodeCharacters(text).map((segment) => {
		const replacement = hiddenUnicodeReplacementMap.get(segment);
		if (!replacement) return segment;
		return hiddenUnicodeCharacterHtmlString(replacement);
	}).join("");
}
export { hiddenUnicodeCharacterHTMLString as a, splitAroundHiddenUnicodeCharacters as c, hasHiddenUnicodeCharacters as i, useIsSafari as l, CodeownersValidationBanner as n, showHiddenUnicodeCharactersHTML as o, getHiddenUnicodeReplacement as r, showHiddenUnicodeCharactersRaw as s, CodeownersErrorLineIndicator as t, useSplitCodeownersErrorsContext as u };
