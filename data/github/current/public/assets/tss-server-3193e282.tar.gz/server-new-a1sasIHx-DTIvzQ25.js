performance.mark("js-parse-end:server-new-a1sasIHx-DTIvzQ25.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:new-a1sasIHx.js");
var codeViewNewServerFn_createServerFn_handler = createServerRpc({
	id: "485aab9949f91d6ded9cd342ed5bbfe78020f1699252653dea689a9897608303",
	name: "codeViewNewServerFn",
	filename: "src/routes/code-view/new.tsx"
}, (opts) => codeViewNewServerFn.__executeServer(opts));
var codeViewNewServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewNewServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewNewRoute");
});
export { codeViewNewServerFn_createServerFn_handler };
