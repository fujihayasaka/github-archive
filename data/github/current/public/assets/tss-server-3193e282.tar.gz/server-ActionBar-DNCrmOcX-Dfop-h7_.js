import { m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, _n as KebabHorizontalIcon, an as IconButton, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { o as useResizeObserver } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import React, { createContext, forwardRef, useCallback, useContext, useEffect, useId, useMemo, useReducer, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
var styles = {
	"List": "prc-ActionBar-List-9uz46",
	"Divider": "prc-ActionBar-Divider-6V8yH",
	"Nav": "prc-ActionBar-Nav-9spON",
	"Group": "prc-ActionBar-Group-peNCk"
};
/**
* Create a "descendant registry" for a component. This allows a parent to store and track an ordered registry of
* child components, even if they are deeply nested in the tree. For example, a menu component can use this to track
* every menu item inside of it, including menu items inside of fragments and subcomponents. The order of the resulting
* `Map` will match the render order in the React tree.
*
* Usage:
* 1. Create a registry at the file level in a similar manner to creating a new React context. Set `T` to the data type
*    of the registry - this can be anything **except** a function.
* 2. In the parent component, instantiate the registry state via `useRegistryState`. Then wrap `children` in the
*    registry context `Provider` with `setRegistry` set to the state setter function.
* 3. Register child components via `useRegisterDescendant` or `useRegisterDescendantCallback`.
* 4. Access the registered data using the value from `useRegistryState`. This will be a map of `string` to `T`, where
*    the string key is a unique and stable identifier for each component which can be used as a `key` if necessary.
*
* @note Note that this pattern is not SSR compatible. It won't raise errors or hydration mismatches, but the
* registry will not be available during SSR. The registry is built during the effect phase, so it will be populated
* after hydration on the client. The initial `undefined` value can be used to safely show loading UI during SSR/initial
* render if necessary.
*/
function createDescendantRegistry() {
	const Context = /* @__PURE__ */ createContext({
		register: () => () => {},
		updateValue: () => {},
		key: -1
	});
	/**
	* Instantiate descendant registry state. The initial value will be `undefined`, indicating that the registry hasn't
	* been built yet.
	*/
	function useRegistryState() {
		return useState();
	}
	/** Register a descendant component with the registry. */
	function useRegisterDescendant(value) {
		const $ = c(16);
		const { register, updateValue, key } = useContext(Context);
		const id = useId();
		let t0;
		if ($[0] !== id || $[1] !== register) {
			t0 = () => register(id);
			$[0] = id;
			$[1] = register;
			$[2] = t0;
		} else t0 = $[2];
		let t1;
		if ($[3] !== id || $[4] !== key || $[5] !== register) {
			t1 = [
				register,
				id,
				key
			];
			$[3] = id;
			$[4] = key;
			$[5] = register;
			$[6] = t1;
		} else t1 = $[6];
		useEffect(t0, t1);
		let t2;
		if ($[7] !== id || $[8] !== updateValue || $[9] !== value) {
			t2 = () => updateValue(id, value);
			$[7] = id;
			$[8] = updateValue;
			$[9] = value;
			$[10] = t2;
		} else t2 = $[10];
		let t3;
		if ($[11] !== id || $[12] !== key || $[13] !== updateValue || $[14] !== value) {
			t3 = [
				updateValue,
				id,
				value,
				key
			];
			$[11] = id;
			$[12] = key;
			$[13] = updateValue;
			$[14] = value;
			$[15] = t3;
		} else t3 = $[15];
		useEffect(t2, t3);
		return id;
	}
	const unsetValue = Symbol("unset");
	/** Provide context for registering descendant components. This only needs to wrap `children`. */
	function Provider(t0) {
		const $ = c(14);
		const { children, setRegistry } = t0;
		const workingRegistryRef = useRef("queued");
		const [key, rebuildRegistry] = useReducer(_temp, 0);
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = function instantiateNewRegistry() {
				if (workingRegistryRef.current === "queued") workingRegistryRef.current = /* @__PURE__ */ new Map();
			};
			$[0] = t1;
		} else t1 = $[0];
		useIsomorphicLayoutEffect(t1);
		let t2;
		if ($[1] !== setRegistry) {
			t2 = (id) => {
				if (workingRegistryRef.current instanceof Map) workingRegistryRef.current.set(id, unsetValue);
				else if (workingRegistryRef.current === "idle") {
					workingRegistryRef.current = "queued";
					rebuildRegistry();
				}
				return function unregister() {
					if (workingRegistryRef.current instanceof Map) workingRegistryRef.current.delete(id);
					else if (workingRegistryRef.current === "idle") setRegistry((prev_0) => {
						const copy = new Map(prev_0);
						copy.delete(id);
						return copy;
					});
				};
			};
			$[1] = setRegistry;
			$[2] = t2;
		} else t2 = $[2];
		const register = t2;
		let t3;
		if ($[3] !== setRegistry) {
			t3 = (id_0, value) => {
				if (workingRegistryRef.current instanceof Map) workingRegistryRef.current.set(id_0, value);
				else if (workingRegistryRef.current === "idle") setRegistry((prev_1) => new Map(prev_1).set(id_0, value));
			};
			$[3] = setRegistry;
			$[4] = t3;
		} else t3 = $[4];
		const updateValue = t3;
		let t4;
		if ($[5] !== setRegistry) {
			t4 = function commitWorkingRegistry() {
				if (workingRegistryRef.current instanceof Map) {
					const setEntries = Array.from(workingRegistryRef.current.entries()).filter(_temp2);
					setRegistry(new Map(setEntries));
					workingRegistryRef.current = "idle";
				}
			};
			$[5] = setRegistry;
			$[6] = t4;
		} else t4 = $[6];
		useEffect(t4);
		let t5;
		if ($[7] !== key || $[8] !== register || $[9] !== updateValue) {
			t5 = {
				register,
				updateValue,
				key
			};
			$[7] = key;
			$[8] = register;
			$[9] = updateValue;
			$[10] = t5;
		} else t5 = $[10];
		const contextValue = t5;
		let t6;
		if ($[11] !== children || $[12] !== contextValue) {
			t6 = /* @__PURE__ */ jsx(Context.Provider, {
				value: contextValue,
				children
			});
			$[11] = children;
			$[12] = contextValue;
			$[13] = t6;
		} else t6 = $[13];
		return t6;
	}
	function _temp2(entry) {
		return entry[1] !== unsetValue;
	}
	function _temp(prev) {
		return prev + 1;
	}
	return {
		Provider,
		useRegistryState,
		useRegisterDescendant
	};
}
var ACTIONBAR_ITEM_GAP = 8;
/**
* Registry of descendants to render in the list or menu. To preserve insertion order across updates, children are
* set to `null` when unregistered rather than fully dropped from the map.
*/
var ActionBarContext = /* @__PURE__ */ React.createContext({
	size: "medium",
	isVisibleChild: () => true,
	groupId: void 0
});
var MORE_BTN_WIDTH = 32;
var ActionBarItemsRegistry = createDescendantRegistry();
var calculatePossibleItems = (registryEntries, navWidth, gap, moreMenuWidth = 0) => {
	const widthToFit = navWidth - moreMenuWidth;
	let breakpoint = registryEntries.length;
	let sumsOfChildWidth = 0;
	for (const [index, [, child]] of registryEntries.entries()) {
		sumsOfChildWidth += index > 0 ? child.width + gap : child.width;
		if (sumsOfChildWidth > widthToFit) {
			breakpoint = index;
			break;
		} else continue;
	}
	return breakpoint;
};
var renderMenuItem = (item, index) => {
	if (item.type === "divider") return /* @__PURE__ */ jsx(ActionList.Divider, {}, index);
	const { label, onClick, disabled, trailingVisual: TrailingIcon, leadingVisual: LeadingIcon, items, variant } = item;
	if (items && items.length > 0) return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs(ActionList.Item, {
		disabled,
		variant,
		children: [
			LeadingIcon ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LeadingIcon, {}) }) : null,
			label,
			TrailingIcon ? /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: typeof TrailingIcon === "string" ? /* @__PURE__ */ jsx("span", { children: TrailingIcon }) : /* @__PURE__ */ jsx(TrailingIcon, {}) }) : null
		]
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, { children: items.map((subItem, subIndex) => renderMenuItem(subItem, subIndex)) }) })] }, label);
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		onSelect: onClick,
		disabled,
		variant,
		children: [
			LeadingIcon ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LeadingIcon, {}) }) : null,
			label,
			TrailingIcon ? /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: typeof TrailingIcon === "string" ? /* @__PURE__ */ jsx("span", { children: TrailingIcon }) : /* @__PURE__ */ jsx(TrailingIcon, {}) }) : null
		]
	}, label);
};
renderMenuItem.displayName = "renderMenuItem";
var getMenuItems = (navWidth, moreMenuWidth, childRegistry, hasActiveMenu, gap) => {
	var _childRegistry$entrie;
	const registryEntries = Array.from((_childRegistry$entrie = childRegistry === null || childRegistry === void 0 ? void 0 : childRegistry.entries()) !== null && _childRegistry$entrie !== void 0 ? _childRegistry$entrie : []).filter((entry) => entry[1] !== null && (entry[1].type !== "action" || entry[1].groupId === void 0));
	if (registryEntries.length === 0) return /* @__PURE__ */ new Set();
	const numberOfItemsPossible = calculatePossibleItems(registryEntries, navWidth, gap);
	const numberOfItemsPossibleWithMoreMenu = calculatePossibleItems(registryEntries, navWidth, gap, moreMenuWidth || MORE_BTN_WIDTH);
	const menuItems = /* @__PURE__ */ new Set();
	if (registryEntries.length >= numberOfItemsPossible) {
		const numberOfListItems = registryEntries.length - numberOfItemsPossibleWithMoreMenu === 1 ? numberOfItemsPossibleWithMoreMenu - 1 : numberOfItemsPossibleWithMoreMenu;
		for (const [index, [id, child]] of registryEntries.entries()) if (index < numberOfListItems) continue;
		else if (child.type === "divider") if (index === numberOfListItems - 1 || index === numberOfListItems) continue;
		else menuItems.add(id);
		else menuItems.add(id);
		return menuItems;
	} else if (numberOfItemsPossible > registryEntries.length && hasActiveMenu) return /* @__PURE__ */ new Set();
};
var ActionBar$1 = (props) => {
	const $ = c(38);
	const { size: t0, children, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, flush: t1, className, gap: t2 } = props;
	const size = t0 === void 0 ? "medium" : t0;
	const flush = t1 === void 0 ? false : t1;
	const gap = t2 === void 0 ? "condensed" : t2;
	const listRef = useRef(null);
	const [computedGap, setComputedGap] = useState(ACTIONBAR_ITEM_GAP);
	const [childRegistry, setChildRegistry] = ActionBarItemsRegistry.useRegistryState();
	const [menuItemIds, setMenuItemIds] = useState(_temp);
	const navRef = useRef(null);
	let t3;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			if (!listRef.current) return;
			const g = window.getComputedStyle(listRef.current).gap;
			const parsed = parseFloat(g);
			if (!Number.isNaN(parsed)) setComputedGap(parsed);
		};
		$[0] = t3;
	} else t3 = $[0];
	let t4;
	if ($[1] !== gap) {
		t4 = [gap];
		$[1] = gap;
		$[2] = t4;
	} else t4 = $[2];
	useIsomorphicLayoutEffect(t3, t4);
	const moreMenuRef = useRef(null);
	let t5;
	if ($[3] !== childRegistry || $[4] !== computedGap || $[5] !== menuItemIds.size) {
		t5 = (resizeObserverEntries) => {
			var _moreMenuRef$current$, _moreMenuRef$current;
			const navWidth = resizeObserverEntries[0].contentRect.width;
			const moreMenuWidth = (_moreMenuRef$current$ = (_moreMenuRef$current = moreMenuRef.current) === null || _moreMenuRef$current === void 0 ? void 0 : _moreMenuRef$current.getBoundingClientRect().width) !== null && _moreMenuRef$current$ !== void 0 ? _moreMenuRef$current$ : 0;
			const hasActiveMenu = menuItemIds.size > 0;
			if (navWidth > 0) {
				const newMenuItemIds = getMenuItems(navWidth, moreMenuWidth, childRegistry, hasActiveMenu, computedGap);
				if (newMenuItemIds) setMenuItemIds(newMenuItemIds);
			}
		};
		$[3] = childRegistry;
		$[4] = computedGap;
		$[5] = menuItemIds.size;
		$[6] = t5;
	} else t5 = $[6];
	useResizeObserver(t5, navRef);
	let t6;
	if ($[7] !== menuItemIds) {
		t6 = (id) => !menuItemIds.has(id);
		$[7] = menuItemIds;
		$[8] = t6;
	} else t6 = $[8];
	const isVisibleChild = t6;
	let t7;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = {
			containerRef: listRef,
			bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd,
			focusOutBehavior: "wrap"
		};
		$[9] = t7;
	} else t7 = $[9];
	useFocusZone(t7);
	let groupedItemsMap;
	if ($[10] !== childRegistry) {
		groupedItemsMap = /* @__PURE__ */ new Map();
		for (const [key, childProps] of childRegistry !== null && childRegistry !== void 0 ? childRegistry : []) if (childProps.type === "action" && childProps.groupId) {
			const existingGroup = groupedItemsMap.get(childProps.groupId) || [];
			existingGroup.push([key, childProps]);
			groupedItemsMap.set(childProps.groupId, existingGroup);
		}
		$[10] = childRegistry;
		$[11] = groupedItemsMap;
	} else groupedItemsMap = $[11];
	const groupedItems = groupedItemsMap;
	let t8;
	if ($[12] !== isVisibleChild || $[13] !== size) {
		t8 = {
			size,
			isVisibleChild
		};
		$[12] = isVisibleChild;
		$[13] = size;
		$[14] = t8;
	} else t8 = $[14];
	let t9;
	if ($[15] !== className) {
		t9 = clsx(className, styles.Nav);
		$[15] = className;
		$[16] = t9;
	} else t9 = $[16];
	let t10;
	if ($[17] !== children || $[18] !== setChildRegistry) {
		t10 = /* @__PURE__ */ jsx(ActionBarItemsRegistry.Provider, {
			setRegistry: setChildRegistry,
			children
		});
		$[17] = children;
		$[18] = setChildRegistry;
		$[19] = t10;
	} else t10 = $[19];
	let t11;
	if ($[20] !== ariaLabel || $[21] !== childRegistry || $[22] !== groupedItems || $[23] !== menuItemIds) {
		t11 = menuItemIds.size > 0 && /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			variant: "invisible",
			"aria-label": `More ${ariaLabel} items`,
			icon: KebabHorizontalIcon
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, { children: Array.from(menuItemIds).map((id_0) => {
			const menuItem = childRegistry === null || childRegistry === void 0 ? void 0 : childRegistry.get(id_0);
			if (!menuItem) return null;
			if (menuItem.type === "divider") return /* @__PURE__ */ jsx(ActionList.Divider, {}, id_0);
			else if (menuItem.type === "action") {
				const { onClick, icon: Icon, label, disabled } = menuItem;
				return /* @__PURE__ */ jsxs(ActionList.Item, {
					onSelect: (event) => {
						typeof onClick === "function" && onClick(event);
					},
					disabled,
					children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }), label]
				}, label);
			}
			if (menuItem.type === "menu") {
				const menuItems = menuItem.items;
				const { icon: Icon_0, label: label_0, returnFocusRef } = menuItem;
				return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs(ActionList.Item, { children: [Icon_0 !== "none" ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon_0, {}) }) : null, label_0] }) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
					...returnFocusRef && { returnFocusRef },
					children: /* @__PURE__ */ jsx(ActionList, { children: menuItems.map(_temp2) })
				})] }, id_0);
			}
			const groupedMenuItems = groupedItems.get(id_0) || [];
			if (menuItem.type === "group") return /* @__PURE__ */ jsx(React.Fragment, { children: groupedMenuItems.map(_temp3) }, id_0);
		}) }) })] });
		$[20] = ariaLabel;
		$[21] = childRegistry;
		$[22] = groupedItems;
		$[23] = menuItemIds;
		$[24] = t11;
	} else t11 = $[24];
	let t12;
	if ($[25] !== ariaLabel || $[26] !== ariaLabelledBy || $[27] !== gap || $[28] !== t10 || $[29] !== t11) {
		t12 = /* @__PURE__ */ jsxs("div", {
			ref: listRef,
			role: "toolbar",
			className: styles.List,
			"aria-label": ariaLabel,
			"aria-labelledby": ariaLabelledBy,
			"data-gap": gap,
			children: [t10, t11]
		});
		$[25] = ariaLabel;
		$[26] = ariaLabelledBy;
		$[27] = gap;
		$[28] = t10;
		$[29] = t11;
		$[30] = t12;
	} else t12 = $[30];
	let t13;
	if ($[31] !== flush || $[32] !== t12 || $[33] !== t9) {
		t13 = /* @__PURE__ */ jsx("div", {
			ref: navRef,
			className: t9,
			"data-flush": flush,
			children: t12
		});
		$[31] = flush;
		$[32] = t12;
		$[33] = t9;
		$[34] = t13;
	} else t13 = $[34];
	let t14;
	if ($[35] !== t13 || $[36] !== t8) {
		t14 = /* @__PURE__ */ jsx(ActionBarContext.Provider, {
			value: t8,
			children: t13
		});
		$[35] = t13;
		$[36] = t8;
		$[37] = t14;
	} else t14 = $[37];
	return t14;
};
function useWidth(ref) {
	const $ = c(3);
	const [width, setWidth] = useState(-1);
	let t0;
	let t1;
	if ($[0] !== ref) {
		t0 = () => {
			var _ref$current$getBound, _ref$current;
			return setWidth((_ref$current$getBound = (_ref$current = ref.current) === null || _ref$current === void 0 ? void 0 : _ref$current.getBoundingClientRect().width) !== null && _ref$current$getBound !== void 0 ? _ref$current$getBound : -1);
		};
		t1 = [ref];
		$[0] = ref;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useIsomorphicLayoutEffect(t0, t1);
	return width;
}
var ActionBarIconButton = /* @__PURE__ */ forwardRef(({ disabled, onClick, ...props }, forwardedRef) => {
	const ref = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, ref);
	const { size, isVisibleChild } = React.useContext(ActionBarContext);
	const { groupId } = React.useContext(ActionBarGroupContext);
	const width = useWidth(ref);
	const { ["aria-label"]: ariaLabel, icon } = props;
	const registryProps = useMemo(() => ({
		type: "action",
		label: ariaLabel !== null && ariaLabel !== void 0 ? ariaLabel : "",
		icon,
		disabled: !!disabled,
		onClick,
		width,
		groupId: groupId !== null && groupId !== void 0 ? groupId : void 0
	}), [
		ariaLabel,
		icon,
		disabled,
		onClick,
		groupId,
		width
	]);
	const id = ActionBarItemsRegistry.useRegisterDescendant(registryProps);
	const clickHandler = useCallback((event) => {
		if (disabled) return;
		onClick === null || onClick === void 0 || onClick(event);
	}, [disabled, onClick]);
	if (!isVisibleChild(id) || groupId && !isVisibleChild(groupId)) return null;
	return /* @__PURE__ */ jsx(IconButton, {
		"aria-disabled": disabled,
		ref,
		size,
		onClick: clickHandler,
		...props,
		variant: "invisible"
	});
});
var ActionBarGroupContext = /* @__PURE__ */ React.createContext({ groupId: null });
var ActionBarGroup = /* @__PURE__ */ forwardRef((t0, forwardedRef) => {
	const $ = c(10);
	const { children } = t0;
	const backupRef = useRef(null);
	const ref = forwardedRef !== null && forwardedRef !== void 0 ? forwardedRef : backupRef;
	const width = useWidth(ref);
	let t1;
	if ($[0] !== width) {
		t1 = {
			type: "group",
			width
		};
		$[0] = width;
		$[1] = t1;
	} else t1 = $[1];
	const registryProps = t1;
	const id = ActionBarItemsRegistry.useRegisterDescendant(registryProps);
	let t2;
	if ($[2] !== id) {
		t2 = { groupId: id };
		$[2] = id;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== children || $[5] !== ref) {
		t3 = /* @__PURE__ */ jsx("div", {
			className: styles.Group,
			ref,
			children
		});
		$[4] = children;
		$[5] = ref;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== t2 || $[8] !== t3) {
		t4 = /* @__PURE__ */ jsx(ActionBarGroupContext.Provider, {
			value: t2,
			children: t3
		});
		$[7] = t2;
		$[8] = t3;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
});
var ActionBarMenu = /* @__PURE__ */ forwardRef((t0, forwardedRef) => {
	const $ = c(31);
	let ariaLabel;
	let icon;
	let items;
	let overflowIcon;
	let props;
	let returnFocusRef;
	if ($[0] !== t0) {
		({"aria-label": ariaLabel, icon, overflowIcon, items, returnFocusRef, ...props} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = icon;
		$[3] = items;
		$[4] = overflowIcon;
		$[5] = props;
		$[6] = returnFocusRef;
	} else {
		ariaLabel = $[1];
		icon = $[2];
		items = $[3];
		overflowIcon = $[4];
		props = $[5];
		returnFocusRef = $[6];
	}
	const backupRef = useRef(null);
	const ref = forwardedRef !== null && forwardedRef !== void 0 ? forwardedRef : backupRef;
	const { isVisibleChild } = React.useContext(ActionBarContext);
	const [menuOpen, setMenuOpen] = useState(false);
	const width = useWidth(ref);
	const t1 = overflowIcon ? overflowIcon : icon;
	let t2;
	if ($[7] !== ariaLabel || $[8] !== items || $[9] !== returnFocusRef || $[10] !== t1 || $[11] !== width) {
		t2 = {
			type: "menu",
			width,
			label: ariaLabel,
			icon: t1,
			returnFocusRef,
			items
		};
		$[7] = ariaLabel;
		$[8] = items;
		$[9] = returnFocusRef;
		$[10] = t1;
		$[11] = width;
		$[12] = t2;
	} else t2 = $[12];
	const registryProps = t2;
	if (!isVisibleChild(ActionBarItemsRegistry.useRegisterDescendant(registryProps))) return null;
	let t3;
	if ($[13] !== ariaLabel || $[14] !== icon || $[15] !== props) {
		t3 = /* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			variant: "invisible",
			"aria-label": ariaLabel,
			icon,
			...props
		}) });
		$[13] = ariaLabel;
		$[14] = icon;
		$[15] = props;
		$[16] = t3;
	} else t3 = $[16];
	let t4;
	if ($[17] !== returnFocusRef) {
		t4 = returnFocusRef && { returnFocusRef };
		$[17] = returnFocusRef;
		$[18] = t4;
	} else t4 = $[18];
	let t5;
	if ($[19] !== items) {
		t5 = items.map(_temp4);
		$[19] = items;
		$[20] = t5;
	} else t5 = $[20];
	let t6;
	if ($[21] !== t5) {
		t6 = /* @__PURE__ */ jsx(ActionList, { children: t5 });
		$[21] = t5;
		$[22] = t6;
	} else t6 = $[22];
	let t7;
	if ($[23] !== t4 || $[24] !== t6) {
		t7 = /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			...t4,
			children: t6
		});
		$[23] = t4;
		$[24] = t6;
		$[25] = t7;
	} else t7 = $[25];
	let t8;
	if ($[26] !== menuOpen || $[27] !== ref || $[28] !== t3 || $[29] !== t7) {
		t8 = /* @__PURE__ */ jsxs(ActionMenu, {
			anchorRef: ref,
			open: menuOpen,
			onOpenChange: setMenuOpen,
			children: [t3, t7]
		});
		$[26] = menuOpen;
		$[27] = ref;
		$[28] = t3;
		$[29] = t7;
		$[30] = t8;
	} else t8 = $[30];
	return t8;
});
var VerticalDivider = () => {
	const $ = c(3);
	const ref = useRef(null);
	const { isVisibleChild } = React.useContext(ActionBarContext);
	const width = useWidth(ref);
	let t0;
	if ($[0] !== width) {
		t0 = {
			type: "divider",
			width
		};
		$[0] = width;
		$[1] = t0;
	} else t0 = $[1];
	const registryProps = t0;
	if (!isVisibleChild(ActionBarItemsRegistry.useRegisterDescendant(registryProps))) return null;
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ jsx("div", {
			ref,
			"data-component": "ActionBar.VerticalDivider",
			"aria-hidden": "true",
			className: styles.Divider
		});
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
function _temp() {
	return /* @__PURE__ */ new Set();
}
function _temp2(item, index) {
	return renderMenuItem(item, index);
}
function _temp3(t0) {
	const [key_0, childProps_0] = t0;
	if (childProps_0.type === "action") {
		const { onClick: onClick_0, icon: Icon_1, label: label_1, disabled: disabled_0 } = childProps_0;
		return /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: (event_0) => {
				typeof onClick_0 === "function" && onClick_0(event_0);
			},
			disabled: disabled_0,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon_1, {}) }), label_1]
		}, key_0);
	}
	return null;
}
function _temp4(item, index) {
	return renderMenuItem(item, index);
}
var ActionBar = Object.assign(ActionBar$1, {
	IconButton: ActionBarIconButton,
	Divider: VerticalDivider,
	Group: ActionBarGroup,
	Menu: ActionBarMenu
});
export { ActionBar as t };
