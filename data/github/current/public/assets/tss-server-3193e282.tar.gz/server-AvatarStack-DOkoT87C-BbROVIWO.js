import { t as isResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import React, { useEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
var classes = {
	"AvatarStack": "prc-AvatarStack-AvatarStack-vkIK2",
	"AvatarItem": "prc-AvatarStack-AvatarItem-70eW3",
	"AvatarStackBody": "prc-AvatarStack-AvatarStackBody-JFK4u"
};
var nonValidSelectors = {
	disabled: "[disabled]",
	hidden: "[hidden]",
	inert: "[inert]",
	negativeTabIndex: "[tabindex=\"-1\"]"
};
var interactiveSelector = [
	`a[href]`,
	`button`,
	"summary",
	"select",
	"input:not([type=hidden])",
	"textarea",
	"[tabindex=\"0\"]",
	`audio[controls]`,
	`video[controls]`,
	`[contenteditable]`
].map((selector) => `${selector}:not(${Object.values(nonValidSelectors).join("):not(")})`).join(", ");
/**
* Finds interactive nodes within the passed node.
* If the node itself is interactive, or children within are, it will return true.
*
* @param node - The HTML element to search for interactive nodes in.
* @param ignoreSelectors - A string of selectors to ignore when searching for interactive nodes. This is useful for
* ignoring nodes that are conditionally interactive based on the return value of the function.
* @returns {boolean | undefined}
*/
function hasInteractiveNodes(node, ignoreNodes) {
	if (!node || isNonValidInteractiveNode(node)) return false;
	const nodesToIgnore = [node];
	const candidates = node.querySelectorAll(interactiveSelector);
	for (const candidate of candidates) if (!nodesToIgnore.includes(candidate) && !isNonValidInteractiveNode(candidate)) return true;
	return false;
}
function isNonValidInteractiveNode(node) {
	if (node.matches("[disabled], [hidden], [inert]")) return true;
	const nodeStyle = getComputedStyle(node);
	return nodeStyle.display === "none" || nodeStyle.visibility === "hidden";
}
var transformChildren = (children, shape) => {
	return React.Children.map(children, (child) => {
		if (!/* @__PURE__ */ React.isValidElement(child)) return child;
		return /* @__PURE__ */ React.cloneElement(child, {
			...child.props,
			square: (shape === "square" ? true : void 0) || child.props.square,
			className: clsx(child.props.className, "pc-AvatarItem", classes.AvatarItem)
		});
	});
};
var AvatarStackBody = ({ disableExpand, hasInteractiveChildren, stackContainer, children }) => {
	return /* @__PURE__ */ jsx("div", {
		"data-disable-expand": disableExpand ? "" : void 0,
		className: clsx({ "pc-AvatarStack--disableExpand": disableExpand }, "pc-AvatarStackBody", classes.AvatarStackBody),
		tabIndex: !hasInteractiveChildren && !disableExpand ? 0 : void 0,
		ref: stackContainer,
		children
	});
};
AvatarStackBody.displayName = "AvatarStackBody";
var AvatarStack = ({ children, variant = "cascade", shape = "circle", alignRight, disableExpand, size, className, style }) => {
	const [hasInteractiveChildren, setHasInteractiveChildren] = useState(false);
	const stackContainer = useRef(null);
	const count = React.Children.count(children);
	const getAvatarChildSizes = () => {
		const avatarSizeMap = {
			narrow: [],
			regular: [],
			wide: []
		};
		return React.Children.toArray(children).reduce((acc, child) => {
			if (!/* @__PURE__ */ React.isValidElement(child)) return acc;
			for (const responsiveKey of Object.keys(avatarSizeMap)) {
				if (isResponsiveValue(child.props.size)) avatarSizeMap[responsiveKey].push(child.props.size[responsiveKey] || 20);
				else avatarSizeMap[responsiveKey].push(child.props.size || 20);
				acc[responsiveKey] = Math.min(...avatarSizeMap[responsiveKey]);
			}
			return acc;
		}, {
			narrow: 20,
			regular: 20,
			wide: 20
		});
	};
	const childSizes = getAvatarChildSizes();
	useEffect(() => {
		if (stackContainer.current) {
			const interactiveChildren = () => {
				setHasInteractiveChildren(hasInteractiveNodes(stackContainer.current));
			};
			const observer = new MutationObserver(interactiveChildren);
			observer.observe(stackContainer.current, { childList: true });
			interactiveChildren();
			return () => {
				observer.disconnect();
			};
		}
	}, []);
	const getResponsiveAvatarSizeStyles = () => {
		if (!size) return {
			"--stackSize-narrow": `${childSizes.narrow}px`,
			"--stackSize-regular": `${childSizes.regular}px`,
			"--stackSize-wide": `${childSizes.wide}px`
		};
		if (isResponsiveValue(size)) return {
			"--stackSize-narrow": `${size.narrow || 20}px`,
			"--stackSize-regular": `${size.regular || 20}px`,
			"--stackSize-wide": `${size.wide || 20}px`
		};
		return { "--avatar-stack-size": `${size}px` };
	};
	return /* @__PURE__ */ jsx("span", {
		"data-variant": variant,
		"data-shape": shape,
		"data-avatar-count": count > 3 ? "3+" : count,
		"data-align-right": alignRight ? "" : void 0,
		"data-responsive": !size || isResponsiveValue(size) ? "" : void 0,
		className: clsx({
			"pc-AvatarStack--variant": variant,
			"pc-AvatarStack--shape": shape,
			"pc-AvatarStack--two": count === 2,
			"pc-AvatarStack--three": count === 3,
			"pc-AvatarStack--three-plus": count > 3,
			"pc-AvatarStack--right": alignRight
		}, className, classes.AvatarStack),
		style: {
			...getResponsiveAvatarSizeStyles(),
			...style
		},
		children: /* @__PURE__ */ jsxs(AvatarStackBody, {
			disableExpand,
			hasInteractiveChildren,
			stackContainer,
			children: [" ", transformChildren(children, shape)]
		})
	});
};
AvatarStack.displayName = "AvatarStack";
export { AvatarStack as t };
