import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerThreadSubscriptionFormAction",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCustomSubscriptionEvents",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "updateIssueSubscriptionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateSubscriptionPayload",
				"kind": "LinkedField",
				"name": "updateSubscription",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subscribable",
					"plural": false,
					"selections": [{
						"kind": "InlineFragment",
						"selections": [
							v2,
							v3,
							v4
						],
						"type": "Issue",
						"abstractKey": null
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "updateIssueSubscriptionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "UpdateSubscriptionPayload",
				"kind": "LinkedField",
				"name": "updateSubscription",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subscribable",
					"plural": false,
					"selections": [
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "__typename",
							"storageKey": null
						},
						v2,
						{
							"kind": "InlineFragment",
							"selections": [v3, v4],
							"type": "Issue",
							"abstractKey": null
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d0752b2e49295017f67c84f21bfe41a3",
			"metadata": {},
			"name": "updateIssueSubscriptionMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "27627c886a77b2b26e6d72dcc5d7bf40";
var import_react_relay = require_react_relay();
function commitUpdateIssueSubscriptionMutation({ environment, input, onCompleted, onError }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		variables: { input },
		optimisticResponse: { updateSubscription: { subscribable: {
			id: input.subscribableId,
			viewerThreadSubscriptionFormAction: input.state === "SUBSCRIBED" || input.state === "CUSTOM" ? "UNSUBSCRIBE" : "SUBSCRIBE",
			viewerCustomSubscriptionEvents: input.events,
			__typename: "Issue"
		} } },
		onCompleted: () => onCompleted && onCompleted(),
		onError: (error) => onError && onError(error)
	});
}
var VALUES = {
	ghostUser: {
		displayName: "Ghost",
		login: "ghost",
		avatarUrl: "https://avatars.githubusercontent.com/ghost",
		path: "/ghost",
		url: "/ghost"
	},
	localStorageKeys: {
		issueComment: (prefix, issueId, commentId) => `${prefix}-i${issueId}-c${commentId}.view-issue-comment`,
		issueNewComment: (prefix, issueId) => `${prefix}-i${issueId}.view-issue-comment-new`
	}
};
export { commitUpdateIssueSubscriptionMutation as n, VALUES as t };
