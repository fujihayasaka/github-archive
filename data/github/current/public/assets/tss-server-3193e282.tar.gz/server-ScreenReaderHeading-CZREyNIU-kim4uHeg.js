import { Qt as Heading$2 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { jsx } from "react/jsx-runtime";
var ScreenReaderHeading_module_default = { userSelectNone: "ScreenReaderHeading-module_JpekQq_userSelectNone" };
function ScreenReaderHeading({ as, text, ...props }) {
	return /* @__PURE__ */ jsx(Heading$2, {
		as,
		className: `sr-only ${ScreenReaderHeading_module_default.userSelectNone}`,
		"data-testid": "screen-reader-heading",
		...props,
		children: text
	});
}
ScreenReaderHeading.displayName = "ScreenReaderHeading";
export { ScreenReaderHeading as t };
