import { o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { c as Text$1, l as VisuallyHidden, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Gi as useSlots, M as CheckboxOrRadioGroupContext, Mi as XIcon, Ri as isSlot, Ti as ValidationAnimationContainer, Wi as useSafeTimeout, a as AlertFillIcon, ar as PlusIcon, dr as Radio, ln as InputValidation, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { a as useAnchoredPosition, r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { a as TextInputWrapper, i as TextInputInnerVisualSlot, n as TextInput$1, o as UnstyledTextInput, r as TextInputBaseWrapper, t as CharacterCounter } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, r as FormControlContextProvider, s as useFormControlContext, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import React, { createContext, forwardRef, useCallback, useContext, useDeferredValue, useEffect, useId, useMemo, useReducer, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isFocusable } from "@primer/behaviors/utils";
import { isElement, isValidElementType } from "react-is";
import { announce } from "@primer/live-region-element";
import { FocusKeys, scrollIntoView } from "@primer/behaviors";
var classes$11 = { "TokenBase": "prc-Token-TokenBase-te5-F" };
var defaultTokenSize = "medium";
var isTokenInteractive = ({ as = "span", onClick, onFocus, tabIndex = -1, disabled }) => {
	if (disabled) return false;
	return Boolean(onFocus || onClick || tabIndex > -1 || ["a", "button"].includes(as));
};
var TokenBase = /* @__PURE__ */ React.forwardRef((t0, forwardedRef) => {
	const $ = c(25);
	let Component;
	let T0;
	let id;
	let rest;
	let size;
	let t1;
	let t2;
	let t3;
	if ($[0] !== t0) {
		const { onRemove, onKeyDown, id: t4, className, size: t5, isSelected: _isSelected, as: t6, ...t7 } = t0;
		id = t4;
		rest = t7;
		size = t5 === void 0 ? defaultTokenSize : t5;
		Component = t6 === void 0 ? "span" : t6;
		T0 = Component;
		if ($[9] !== onKeyDown || $[10] !== onRemove) {
			t1 = (event) => {
				onKeyDown && onKeyDown(event);
				if ((event.key === "Backspace" || event.key === "Delete") && onRemove) onRemove();
			};
			$[9] = onKeyDown;
			$[10] = onRemove;
			$[11] = t1;
		} else t1 = $[11];
		if ($[12] !== className) {
			t2 = clsx(classes$11.TokenBase, className);
			$[12] = className;
			$[13] = t2;
		} else t2 = $[13];
		t3 = isTokenInteractive({
			as: Component,
			onClick: rest.onClick,
			onFocus: rest.onFocus,
			tabIndex: rest.tabIndex,
			disabled: rest.disabled
		});
		$[0] = t0;
		$[1] = Component;
		$[2] = T0;
		$[3] = id;
		$[4] = rest;
		$[5] = size;
		$[6] = t1;
		$[7] = t2;
		$[8] = t3;
	} else {
		Component = $[1];
		T0 = $[2];
		id = $[3];
		rest = $[4];
		size = $[5];
		t1 = $[6];
		t2 = $[7];
		t3 = $[8];
	}
	let t4;
	if ($[14] !== id) {
		var _id;
		t4 = (_id = id) === null || _id === void 0 ? void 0 : _id.toString();
		$[14] = id;
		$[15] = t4;
	} else t4 = $[15];
	const t5 = Component === "button" ? rest : Component === "a" ? rest : rest;
	const t6 = forwardedRef;
	let t7;
	if ($[16] !== T0 || $[17] !== size || $[18] !== t1 || $[19] !== t2 || $[20] !== t3 || $[21] !== t4 || $[22] !== t5 || $[23] !== t6) {
		t7 = /* @__PURE__ */ jsx(T0, {
			onKeyDown: t1,
			className: t2,
			"data-cursor-is-interactive": t3,
			"data-size": size,
			id: t4,
			...t5,
			ref: t6
		});
		$[16] = T0;
		$[17] = size;
		$[18] = t1;
		$[19] = t2;
		$[20] = t3;
		$[21] = t4;
		$[22] = t5;
		$[23] = t6;
		$[24] = t7;
	} else t7 = $[24];
	return t7;
});
var classes$10 = { "TokenButton": "prc-Token-TokenButton-L3DuN" };
var RemoveTokenButton = ({ "aria-label": ariaLabel, isParentInteractive, size = defaultTokenSize, className, borderOffset = 0, as: _as, children: _children, ...rest }) => {
	if (isParentInteractive) return /* @__PURE__ */ jsx("span", {
		...rest,
		tabIndex: -1,
		"aria-label": ariaLabel,
		"data-size": size,
		className: clsx(classes$10.TokenButton, className),
		style: { transform: `translate(${borderOffset}px, -${borderOffset}px)` },
		children: /* @__PURE__ */ jsx(XIcon, { size: size === "small" || size === "medium" ? 12 : 16 })
	});
	return /* @__PURE__ */ jsx("button", {
		...rest,
		"aria-label": "Remove token",
		"data-size": size,
		className: clsx(classes$10.TokenButton, className),
		style: { transform: `translate(${borderOffset}px, -${borderOffset}px)` },
		ref: rest.ref,
		type: "button",
		children: /* @__PURE__ */ jsx(XIcon, { size: size === "small" || size === "medium" ? 12 : 16 })
	});
};
RemoveTokenButton.displayName = "RemoveTokenButton";
var classes$9 = { "TokenTextContainer": "prc-Token-TokenTextContainer-cOUaD" };
var TokenTextContainer = (t0) => {
	const $ = c(13);
	let children;
	let id;
	let props;
	let t1;
	if ($[0] !== t0) {
		({children, id, as: t1, ...props} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = id;
		$[3] = props;
		$[4] = t1;
	} else {
		children = $[1];
		id = $[2];
		props = $[3];
		t1 = $[4];
	}
	const Component = t1 === void 0 ? "span" : t1;
	let t2;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = clsx(classes$9.TokenTextContainer);
		$[5] = t2;
	} else t2 = $[5];
	let t3;
	if ($[6] !== id) {
		var _id;
		t3 = (_id = id) === null || _id === void 0 ? void 0 : _id.toString();
		$[6] = id;
		$[7] = t3;
	} else t3 = $[7];
	const t4 = Component === "button" ? props : Component === "a" ? props : props;
	let t5;
	if ($[8] !== Component || $[9] !== children || $[10] !== t3 || $[11] !== t4) {
		t5 = /* @__PURE__ */ jsx(Component, {
			className: t2,
			id: t3,
			...t4,
			children
		});
		$[8] = Component;
		$[9] = children;
		$[10] = t3;
		$[11] = t4;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
};
var classes$8 = {
	"Token": "prc-Token-Token-A5-r7",
	"LeadingVisualContainer": "prc-Token-LeadingVisualContainer-z-WxM",
	"LargeLeadingVisual": "prc-Token-LargeLeadingVisual-foRMf"
};
var tokenBorderWidthPx = 1;
var LeadingVisualContainer = (t0) => {
	const $ = c(7);
	const { children, size } = t0;
	let t1;
	if ($[0] !== size) {
		t1 = size && ["large", "xlarge"].includes(size);
		$[0] = size;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t1) {
		t2 = clsx(classes$8.LeadingVisualContainer, { [classes$8.LargeLeadingVisual]: t1 });
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	let t3;
	if ($[4] !== children || $[5] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			className: t2,
			children
		});
		$[4] = children;
		$[5] = t2;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
};
var Token = /* @__PURE__ */ forwardRef((props, forwardedRef) => {
	const $ = c(66);
	let LeadingVisual;
	let as;
	let className;
	let hideRemoveButton;
	let href;
	let id;
	let onClick;
	let onRemove;
	let rest;
	let style;
	let t0;
	let text;
	if ($[0] !== props) {
		({as, onRemove, id, leadingVisual: LeadingVisual, text, size: t0, hideRemoveButton, href, onClick, className, style, ...rest} = props);
		$[0] = props;
		$[1] = LeadingVisual;
		$[2] = as;
		$[3] = className;
		$[4] = hideRemoveButton;
		$[5] = href;
		$[6] = id;
		$[7] = onClick;
		$[8] = onRemove;
		$[9] = rest;
		$[10] = style;
		$[11] = t0;
		$[12] = text;
	} else {
		LeadingVisual = $[1];
		as = $[2];
		className = $[3];
		hideRemoveButton = $[4];
		href = $[5];
		id = $[6];
		onClick = $[7];
		onRemove = $[8];
		rest = $[9];
		style = $[10];
		t0 = $[11];
		text = $[12];
	}
	const size = t0 === void 0 ? defaultTokenSize : t0;
	let t1;
	if ($[13] !== hideRemoveButton || $[14] !== onRemove || $[15] !== props) {
		t1 = isTokenInteractive(props) && Boolean(onRemove) && !hideRemoveButton;
		$[13] = hideRemoveButton;
		$[14] = onRemove;
		$[15] = props;
		$[16] = t1;
	} else t1 = $[16];
	const hasMultipleActionTargets = t1;
	let t2;
	if ($[17] !== onRemove) {
		t2 = (e) => {
			e.stopPropagation();
			onRemove && onRemove();
		};
		$[17] = onRemove;
		$[18] = t2;
	} else t2 = $[18];
	const onRemoveClick = t2;
	let t3;
	if ($[19] !== as || $[20] !== href || $[21] !== onClick) {
		t3 = {
			as,
			href,
			onClick
		};
		$[19] = as;
		$[20] = href;
		$[21] = onClick;
		$[22] = t3;
	} else t3 = $[22];
	const interactiveTokenProps = t3;
	let t4;
	if ($[23] !== id) {
		var _id;
		t4 = (_id = id) === null || _id === void 0 ? void 0 : _id.toString();
		$[23] = id;
		$[24] = t4;
	} else t4 = $[24];
	let t5;
	if ($[25] !== className) {
		t5 = clsx(className, classes$8.Token);
		$[25] = className;
		$[26] = t5;
	} else t5 = $[26];
	const t6 = !(hideRemoveButton || !onRemove);
	let t7;
	if ($[27] !== hasMultipleActionTargets || $[28] !== interactiveTokenProps) {
		t7 = !hasMultipleActionTargets ? interactiveTokenProps : {};
		$[27] = hasMultipleActionTargets;
		$[28] = interactiveTokenProps;
		$[29] = t7;
	} else t7 = $[29];
	let t8;
	if ($[30] !== style) {
		t8 = {
			borderWidth: `${tokenBorderWidthPx}px`,
			...style
		};
		$[30] = style;
		$[31] = t8;
	} else t8 = $[31];
	let t9;
	if ($[32] !== LeadingVisual || $[33] !== size) {
		t9 = LeadingVisual && size !== "small" ? /* @__PURE__ */ jsx(LeadingVisualContainer, {
			size,
			children: /* @__PURE__ */ jsx(LeadingVisual, {})
		}) : null;
		$[32] = LeadingVisual;
		$[33] = size;
		$[34] = t9;
	} else t9 = $[34];
	let t10;
	if ($[35] !== hasMultipleActionTargets || $[36] !== interactiveTokenProps) {
		t10 = hasMultipleActionTargets ? interactiveTokenProps : {};
		$[35] = hasMultipleActionTargets;
		$[36] = interactiveTokenProps;
		$[37] = t10;
	} else t10 = $[37];
	let t11;
	if ($[38] !== onRemove) {
		t11 = onRemove && /* @__PURE__ */ jsx(VisuallyHidden, { children: " (press backspace or delete to remove)" });
		$[38] = onRemove;
		$[39] = t11;
	} else t11 = $[39];
	let t12;
	if ($[40] !== t10 || $[41] !== t11 || $[42] !== text) {
		t12 = /* @__PURE__ */ jsxs(TokenTextContainer, {
			...t10,
			children: [text, t11]
		});
		$[40] = t10;
		$[41] = t11;
		$[42] = text;
		$[43] = t12;
	} else t12 = $[43];
	let t13;
	if ($[44] !== hasMultipleActionTargets || $[45] !== hideRemoveButton || $[46] !== onRemove || $[47] !== onRemoveClick || $[48] !== props || $[49] !== size) {
		t13 = !hideRemoveButton && onRemove ? /* @__PURE__ */ jsx(RemoveTokenButton, {
			borderOffset: tokenBorderWidthPx,
			onClick: onRemoveClick,
			size,
			isParentInteractive: isTokenInteractive(props),
			"aria-hidden": hasMultipleActionTargets ? "true" : "false"
		}) : null;
		$[44] = hasMultipleActionTargets;
		$[45] = hideRemoveButton;
		$[46] = onRemove;
		$[47] = onRemoveClick;
		$[48] = props;
		$[49] = size;
		$[50] = t13;
	} else t13 = $[50];
	let t14;
	if ($[51] !== forwardedRef || $[52] !== onRemove || $[53] !== props.isSelected || $[54] !== rest || $[55] !== size || $[56] !== t12 || $[57] !== t13 || $[58] !== t4 || $[59] !== t5 || $[60] !== t6 || $[61] !== t7 || $[62] !== t8 || $[63] !== t9 || $[64] !== text) {
		t14 = /* @__PURE__ */ jsxs(TokenBase, {
			onRemove,
			id: t4,
			className: t5,
			text,
			size,
			"data-is-selected": props.isSelected,
			"data-is-remove-btn": t6,
			...t7,
			...rest,
			ref: forwardedRef,
			style: t8,
			children: [
				t9,
				t12,
				t13
			]
		});
		$[51] = forwardedRef;
		$[52] = onRemove;
		$[53] = props.isSelected;
		$[54] = rest;
		$[55] = size;
		$[56] = t12;
		$[57] = t13;
		$[58] = t4;
		$[59] = t5;
		$[60] = t6;
		$[61] = t7;
		$[62] = t8;
		$[63] = t9;
		$[64] = text;
		$[65] = t14;
	} else t14 = $[65];
	return t14;
});
Token.displayName = "Token";
var styles = {
	"TextInputWrapper": "prc-TextInputWithTokens-TextInputWrapper-HAIfc",
	"UnstyledTextInput": "prc-TextInputWithTokens-UnstyledTextInput-XwhBc",
	"InputWrapper": "prc-TextInputWithTokens-InputWrapper-1lXK5",
	"Container": "prc-TextInputWithTokens-Container-dPCL7",
	"OverflowCountSmall": "prc-TextInputWithTokens-OverflowCountSmall-HJUP6",
	"OverflowCountLarge": "prc-TextInputWithTokens-OverflowCountLarge-caBt8",
	"OverflowCountMedium": "prc-TextInputWithTokens-OverflowCountMedium-uq-gt",
	"OverflowCountXLarge": "prc-TextInputWithTokens-OverflowCountXLarge-A-rpJ"
};
var overflowCountClassMap = {
	small: styles.OverflowCountSmall,
	medium: styles.OverflowCountMedium,
	large: styles.OverflowCountLarge,
	xlarge: styles.OverflowCountXLarge
};
function TextInputWithTokensInnerComponent(t0, forwardedRef) {
	const $ = c(151);
	let IconComponent;
	let LeadingVisual;
	let TrailingVisual;
	let block;
	let className;
	let contrast;
	let disabled;
	let loading;
	let maxHeight;
	let maxWidthProp;
	let minWidthProp;
	let onTokenRemove;
	let rest;
	let style;
	let t1;
	let t2;
	let t3;
	let t4;
	let t5;
	let tokens;
	let validationStatus;
	let variantProp;
	let visibleTokenCount;
	let widthProp;
	if ($[0] !== t0) {
		({icon: IconComponent, leadingVisual: LeadingVisual, trailingVisual: TrailingVisual, loading, loaderPosition: t1, contrast, className, block, disabled, tokens, onTokenRemove, tokenComponent: t2, preventTokenWrapping: t3, size: t4, hideTokenRemoveButtons: t5, maxHeight, width: widthProp, minWidth: minWidthProp, maxWidth: maxWidthProp, validationStatus, variant: variantProp, visibleTokenCount, style, ...rest} = t0);
		$[0] = t0;
		$[1] = IconComponent;
		$[2] = LeadingVisual;
		$[3] = TrailingVisual;
		$[4] = block;
		$[5] = className;
		$[6] = contrast;
		$[7] = disabled;
		$[8] = loading;
		$[9] = maxHeight;
		$[10] = maxWidthProp;
		$[11] = minWidthProp;
		$[12] = onTokenRemove;
		$[13] = rest;
		$[14] = style;
		$[15] = t1;
		$[16] = t2;
		$[17] = t3;
		$[18] = t4;
		$[19] = t5;
		$[20] = tokens;
		$[21] = validationStatus;
		$[22] = variantProp;
		$[23] = visibleTokenCount;
		$[24] = widthProp;
	} else {
		IconComponent = $[1];
		LeadingVisual = $[2];
		TrailingVisual = $[3];
		block = $[4];
		className = $[5];
		contrast = $[6];
		disabled = $[7];
		loading = $[8];
		maxHeight = $[9];
		maxWidthProp = $[10];
		minWidthProp = $[11];
		onTokenRemove = $[12];
		rest = $[13];
		style = $[14];
		t1 = $[15];
		t2 = $[16];
		t3 = $[17];
		t4 = $[18];
		t5 = $[19];
		tokens = $[20];
		validationStatus = $[21];
		variantProp = $[22];
		visibleTokenCount = $[23];
		widthProp = $[24];
	}
	const loaderPosition = t1 === void 0 ? "auto" : t1;
	const TokenComponent = t2 === void 0 ? Token : t2;
	const preventTokenWrapping = t3 === void 0 ? false : t3;
	const size = t4 === void 0 ? "xlarge" : t4;
	const hideTokenRemoveButtons = t5 === void 0 ? false : t5;
	let ariaDescribedByProp;
	let inputPropsRest;
	let onBlur;
	let onFocus;
	let onKeyDown;
	let role;
	if ($[25] !== rest) {
		({onBlur, onFocus, onKeyDown, "aria-describedby": ariaDescribedByProp, role, ...inputPropsRest} = rest);
		$[25] = rest;
		$[26] = ariaDescribedByProp;
		$[27] = inputPropsRest;
		$[28] = onBlur;
		$[29] = onFocus;
		$[30] = onKeyDown;
		$[31] = role;
	} else {
		ariaDescribedByProp = $[26];
		inputPropsRest = $[27];
		onBlur = $[28];
		onFocus = $[29];
		onKeyDown = $[30];
		role = $[31];
	}
	const ref = useRef(null);
	const selectedValuesDescriptionId = useId$1();
	useRefObjectAsForwardedRef(forwardedRef, ref);
	const [selectedTokenIndex, setSelectedTokenIndex] = useState();
	const [tokensAreTruncated, setTokensAreTruncated] = useState(Boolean(visibleTokenCount));
	let t6;
	if ($[32] !== tokens) {
		const selectedTokenTexts = tokens.map(_temp).filter(_temp2$1);
		t6 = selectedTokenTexts.length ? `Selected: ${selectedTokenTexts.join(", ")}` : "";
		$[32] = tokens;
		$[33] = t6;
	} else t6 = $[33];
	const selectedValuesDescription = t6;
	const shouldExposeSelectedValuesDescription = role === "combobox" && Boolean(selectedValuesDescription);
	const t7 = shouldExposeSelectedValuesDescription ? selectedValuesDescriptionId : void 0;
	let t8;
	if ($[34] !== ariaDescribedByProp || $[35] !== t7) {
		t8 = [ariaDescribedByProp, t7].filter(Boolean);
		$[34] = ariaDescribedByProp;
		$[35] = t7;
		$[36] = t8;
	} else t8 = $[36];
	const ariaDescribedBy = t8.join(" ");
	let t9;
	if ($[37] !== selectedTokenIndex) {
		t9 = [selectedTokenIndex];
		$[37] = selectedTokenIndex;
		$[38] = t9;
	} else t9 = $[38];
	const { containerRef: t10 } = useFocusZone({
		focusOutBehavior: "wrap",
		bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd,
		focusableElementFilter: _temp3,
		getNextFocusable: (direction) => {
			var _containerRef$current;
			if (!selectedTokenIndex && selectedTokenIndex !== 0) return;
			let nextIndex = selectedTokenIndex + 1;
			if (direction === "next") nextIndex = nextIndex + 1;
			if (direction === "previous") nextIndex = nextIndex - 1;
			if (nextIndex > tokens.length || nextIndex < 1) return ref.current || void 0;
			return (_containerRef$current = containerRef.current) === null || _containerRef$current === void 0 ? void 0 : _containerRef$current.children[nextIndex];
		}
	}, t9);
	const containerRef = t10;
	let t11;
	if ($[39] !== containerRef || $[40] !== onTokenRemove || $[41] !== selectedTokenIndex) {
		t11 = (tokenId) => {
			onTokenRemove(tokenId);
			setTimeout(() => {
				var _containerRef$current2, _containerRef$current3;
				const nextElementToFocus = (_containerRef$current2 = containerRef.current) === null || _containerRef$current2 === void 0 ? void 0 : _containerRef$current2.children[selectedTokenIndex || 0];
				const firstFocusable = nextElementToFocus && isFocusable(nextElementToFocus) ? nextElementToFocus : Array.from(((_containerRef$current3 = containerRef.current) === null || _containerRef$current3 === void 0 ? void 0 : _containerRef$current3.children) || []).find(_temp4);
				if (firstFocusable) firstFocusable.focus();
				else {
					var _ref$current;
					(_ref$current = ref.current) === null || _ref$current === void 0 || _ref$current.focus();
				}
			}, 0);
		};
		$[39] = containerRef;
		$[40] = onTokenRemove;
		$[41] = selectedTokenIndex;
		$[42] = t11;
	} else t11 = $[42];
	const handleTokenRemove = t11;
	let t12;
	if ($[43] !== disabled) {
		t12 = (tokenIndex) => () => {
			if (!disabled) setSelectedTokenIndex(tokenIndex);
		};
		$[43] = disabled;
		$[44] = t12;
	} else t12 = $[44];
	const handleTokenFocus = t12;
	let t13;
	if ($[45] !== containerRef || $[46] !== visibleTokenCount) {
		t13 = () => {
			setSelectedTokenIndex(void 0);
			setTimeout(() => {
				var _containerRef$current4;
				if (!((_containerRef$current4 = containerRef.current) !== null && _containerRef$current4 !== void 0 && _containerRef$current4.contains(document.activeElement)) && visibleTokenCount) setTokensAreTruncated(true);
			}, 0);
		};
		$[45] = containerRef;
		$[46] = visibleTokenCount;
		$[47] = t13;
	} else t13 = $[47];
	const handleTokenBlur = t13;
	let t14;
	if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
		t14 = (event) => {
			if (event.key === "Escape") {
				var _ref$current2;
				(_ref$current2 = ref.current) === null || _ref$current2 === void 0 || _ref$current2.focus();
			}
		};
		$[48] = t14;
	} else t14 = $[48];
	const handleTokenKeyUp = t14;
	let t15;
	if ($[49] !== onFocus || $[50] !== visibleTokenCount) {
		t15 = (event_0) => {
			onFocus && onFocus(event_0);
			setSelectedTokenIndex(void 0);
			visibleTokenCount && setTokensAreTruncated(false);
		};
		$[49] = onFocus;
		$[50] = visibleTokenCount;
		$[51] = t15;
	} else t15 = $[51];
	const handleInputFocus = t15;
	let t16;
	if ($[52] !== containerRef || $[53] !== onBlur || $[54] !== visibleTokenCount) {
		t16 = (event_1) => {
			onBlur && onBlur(event_1);
			setTimeout(() => {
				var _containerRef$current5;
				if (!((_containerRef$current5 = containerRef.current) !== null && _containerRef$current5 !== void 0 && _containerRef$current5.contains(document.activeElement)) && visibleTokenCount) setTokensAreTruncated(true);
			}, 0);
		};
		$[52] = containerRef;
		$[53] = onBlur;
		$[54] = visibleTokenCount;
		$[55] = t16;
	} else t16 = $[55];
	const handleInputBlur = t16;
	let t17;
	if ($[56] !== handleTokenRemove || $[57] !== onKeyDown || $[58] !== tokens) {
		t17 = (e) => {
			var _ref$current3;
			if (onKeyDown) onKeyDown(e);
			if ((_ref$current3 = ref.current) !== null && _ref$current3 !== void 0 && _ref$current3.value) return;
			const lastToken = tokens[tokens.length - 1];
			if (e.key === "Backspace" && lastToken) {
				handleTokenRemove(lastToken.id);
				if (ref.current) ref.current.value = `${lastToken.text} `;
				setTimeout(() => {
					var _ref$current4;
					(_ref$current4 = ref.current) === null || _ref$current4 === void 0 || _ref$current4.select();
				}, 0);
			}
		};
		$[56] = handleTokenRemove;
		$[57] = onKeyDown;
		$[58] = tokens;
		$[59] = t17;
	} else t17 = $[59];
	const handleInputKeyDown = t17;
	let t18;
	if ($[60] === Symbol.for("react.memo_cache_sentinel")) {
		t18 = () => {
			var _ref$current5;
			(_ref$current5 = ref.current) === null || _ref$current5 === void 0 || _ref$current5.focus();
		};
		$[60] = t18;
	} else t18 = $[60];
	const focusInput = t18;
	const preventTokenClickPropagation = _temp5;
	let t19;
	if ($[61] !== tokens || $[62] !== tokensAreTruncated || $[63] !== visibleTokenCount) {
		t19 = tokensAreTruncated ? tokens.slice(0, visibleTokenCount) : tokens;
		$[61] = tokens;
		$[62] = tokensAreTruncated;
		$[63] = visibleTokenCount;
		$[64] = t19;
	} else t19 = $[64];
	const visibleTokens = t19;
	let t20;
	if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
		t20 = {
			small: "small",
			medium: "small",
			large: "medium",
			xlarge: "medium"
		};
		$[65] = t20;
	} else t20 = $[65];
	const inputSizeMap = t20;
	const showLeadingLoadingIndicator = loading && (loaderPosition === "leading" || Boolean(LeadingVisual && loaderPosition !== "trailing"));
	const showTrailingLoadingIndicator = loading && (loaderPosition === "trailing" || loaderPosition === "auto" && !LeadingVisual);
	const t21 = Boolean(LeadingVisual || showLeadingLoadingIndicator);
	const t22 = Boolean(TrailingVisual || showTrailingLoadingIndicator);
	const t23 = inputSizeMap[size];
	const t24 = Boolean(preventTokenWrapping || maxHeight) || void 0;
	let t25;
	if ($[66] !== className) {
		t25 = clsx(className, styles.TextInputWrapper);
		$[66] = className;
		$[67] = t25;
	} else t25 = $[67];
	let t26;
	if ($[68] !== maxHeight || $[69] !== style) {
		t26 = maxHeight ? {
			maxHeight,
			...style
		} : style;
		$[68] = maxHeight;
		$[69] = style;
		$[70] = t26;
	} else t26 = $[70];
	let t27;
	if ($[71] !== IconComponent || $[72] !== LeadingVisual) {
		t27 = IconComponent && !LeadingVisual && /* @__PURE__ */ jsx(IconComponent, { className: "TextInput-icon" });
		$[71] = IconComponent;
		$[72] = LeadingVisual;
		$[73] = t27;
	} else t27 = $[73];
	const t28 = typeof loading === "boolean";
	let t29;
	if ($[74] !== LeadingVisual) {
		t29 = typeof LeadingVisual !== "string" && isValidElementType(LeadingVisual) ? /* @__PURE__ */ jsx(LeadingVisual, {}) : LeadingVisual;
		$[74] = LeadingVisual;
		$[75] = t29;
	} else t29 = $[75];
	let t30;
	if ($[76] !== showLeadingLoadingIndicator || $[77] !== t28 || $[78] !== t29) {
		t30 = /* @__PURE__ */ jsx(TextInputInnerVisualSlot, {
			hasLoadingIndicator: t28,
			visualPosition: "leading",
			showLoadingIndicator: showLeadingLoadingIndicator,
			children: t29
		});
		$[76] = showLeadingLoadingIndicator;
		$[77] = t28;
		$[78] = t29;
		$[79] = t30;
	} else t30 = $[79];
	const t31 = containerRef;
	const t32 = validationStatus === "error" ? "true" : "false";
	const t33 = ariaDescribedBy || void 0;
	let t34;
	if ($[80] !== disabled || $[81] !== handleInputBlur || $[82] !== handleInputFocus || $[83] !== handleInputKeyDown || $[84] !== inputPropsRest || $[85] !== role || $[86] !== t32 || $[87] !== t33) {
		t34 = /* @__PURE__ */ jsx(UnstyledTextInput, {
			ref,
			disabled,
			onFocus: handleInputFocus,
			onBlur: handleInputBlur,
			onKeyDown: handleInputKeyDown,
			type: "text",
			className: styles.UnstyledTextInput,
			"aria-invalid": t32,
			role,
			"aria-describedby": t33,
			...inputPropsRest
		});
		$[80] = disabled;
		$[81] = handleInputBlur;
		$[82] = handleInputFocus;
		$[83] = handleInputKeyDown;
		$[84] = inputPropsRest;
		$[85] = role;
		$[86] = t32;
		$[87] = t33;
		$[88] = t34;
	} else t34 = $[88];
	let t35;
	if ($[89] !== selectedValuesDescription || $[90] !== selectedValuesDescriptionId || $[91] !== shouldExposeSelectedValuesDescription) {
		t35 = shouldExposeSelectedValuesDescription ? /* @__PURE__ */ jsx(VisuallyHidden, {
			id: selectedValuesDescriptionId,
			children: selectedValuesDescription
		}) : null;
		$[89] = selectedValuesDescription;
		$[90] = selectedValuesDescriptionId;
		$[91] = shouldExposeSelectedValuesDescription;
		$[92] = t35;
	} else t35 = $[92];
	let t36;
	if ($[93] !== t34 || $[94] !== t35) {
		t36 = /* @__PURE__ */ jsxs("div", {
			className: styles.InputWrapper,
			children: [t34, t35]
		});
		$[93] = t34;
		$[94] = t35;
		$[95] = t36;
	} else t36 = $[95];
	let t37;
	if ($[96] !== TokenComponent || $[97] !== disabled || $[98] !== handleTokenBlur || $[99] !== handleTokenFocus || $[100] !== handleTokenRemove || $[101] !== hideTokenRemoveButtons || $[102] !== selectedTokenIndex || $[103] !== size || $[104] !== visibleTokens) {
		let t38;
		if ($[106] !== TokenComponent || $[107] !== disabled || $[108] !== handleTokenBlur || $[109] !== handleTokenFocus || $[110] !== handleTokenRemove || $[111] !== hideTokenRemoveButtons || $[112] !== selectedTokenIndex || $[113] !== size) {
			t38 = (t39, i) => {
				const { id, ...tokenRest } = t39;
				return /* @__PURE__ */ jsx(TokenComponent, {
					disabled,
					onFocus: handleTokenFocus(i),
					onBlur: handleTokenBlur,
					onKeyUp: handleTokenKeyUp,
					onClick: preventTokenClickPropagation,
					isSelected: selectedTokenIndex === i,
					onRemove: () => {
						handleTokenRemove(id);
					},
					hideRemoveButton: disabled || hideTokenRemoveButtons,
					size,
					tabIndex: 0,
					...tokenRest
				}, id);
			};
			$[106] = TokenComponent;
			$[107] = disabled;
			$[108] = handleTokenBlur;
			$[109] = handleTokenFocus;
			$[110] = handleTokenRemove;
			$[111] = hideTokenRemoveButtons;
			$[112] = selectedTokenIndex;
			$[113] = size;
			$[114] = t38;
		} else t38 = $[114];
		t37 = visibleTokens.map(t38);
		$[96] = TokenComponent;
		$[97] = disabled;
		$[98] = handleTokenBlur;
		$[99] = handleTokenFocus;
		$[100] = handleTokenRemove;
		$[101] = hideTokenRemoveButtons;
		$[102] = selectedTokenIndex;
		$[103] = size;
		$[104] = visibleTokens;
		$[105] = t37;
	} else t37 = $[105];
	let t38;
	if ($[115] !== size || $[116] !== tokens.length || $[117] !== tokensAreTruncated || $[118] !== visibleTokens.length) {
		t38 = tokensAreTruncated && tokens.length - visibleTokens.length ? /* @__PURE__ */ jsxs(Text$1, {
			className: overflowCountClassMap[size],
			children: ["+", tokens.length - visibleTokens.length]
		}) : null;
		$[115] = size;
		$[116] = tokens.length;
		$[117] = tokensAreTruncated;
		$[118] = visibleTokens.length;
		$[119] = t38;
	} else t38 = $[119];
	let t39;
	if ($[120] !== preventTokenWrapping || $[121] !== t31 || $[122] !== t36 || $[123] !== t37 || $[124] !== t38) {
		t39 = /* @__PURE__ */ jsxs("div", {
			ref: t31,
			className: styles.Container,
			"data-prevent-token-wrapping": preventTokenWrapping,
			children: [
				t36,
				t37,
				t38
			]
		});
		$[120] = preventTokenWrapping;
		$[121] = t31;
		$[122] = t36;
		$[123] = t37;
		$[124] = t38;
		$[125] = t39;
	} else t39 = $[125];
	const t40 = typeof loading === "boolean";
	let t41;
	if ($[126] !== TrailingVisual) {
		t41 = typeof TrailingVisual !== "string" && isValidElementType(TrailingVisual) ? /* @__PURE__ */ jsx(TrailingVisual, {}) : TrailingVisual;
		$[126] = TrailingVisual;
		$[127] = t41;
	} else t41 = $[127];
	let t42;
	if ($[128] !== showTrailingLoadingIndicator || $[129] !== t40 || $[130] !== t41) {
		t42 = /* @__PURE__ */ jsx(TextInputInnerVisualSlot, {
			hasLoadingIndicator: t40,
			visualPosition: "trailing",
			showLoadingIndicator: showTrailingLoadingIndicator,
			children: t41
		});
		$[128] = showTrailingLoadingIndicator;
		$[129] = t40;
		$[130] = t41;
		$[131] = t42;
	} else t42 = $[131];
	let t43;
	if ($[132] !== block || $[133] !== contrast || $[134] !== disabled || $[135] !== maxWidthProp || $[136] !== minWidthProp || $[137] !== t21 || $[138] !== t22 || $[139] !== t23 || $[140] !== t24 || $[141] !== t25 || $[142] !== t26 || $[143] !== t27 || $[144] !== t30 || $[145] !== t39 || $[146] !== t42 || $[147] !== validationStatus || $[148] !== variantProp || $[149] !== widthProp) {
		t43 = /* @__PURE__ */ jsxs(TextInputWrapper, {
			block,
			contrast,
			disabled,
			hasLeadingVisual: t21,
			hasTrailingVisual: t22,
			width: widthProp,
			minWidth: minWidthProp,
			maxWidth: maxWidthProp,
			size: t23,
			validationStatus,
			variant: variantProp,
			onClick: focusInput,
			"data-token-wrapping": t24,
			className: t25,
			style: t26,
			children: [
				t27,
				t30,
				t39,
				t42
			]
		});
		$[132] = block;
		$[133] = contrast;
		$[134] = disabled;
		$[135] = maxWidthProp;
		$[136] = minWidthProp;
		$[137] = t21;
		$[138] = t22;
		$[139] = t23;
		$[140] = t24;
		$[141] = t25;
		$[142] = t26;
		$[143] = t27;
		$[144] = t30;
		$[145] = t39;
		$[146] = t42;
		$[147] = validationStatus;
		$[148] = variantProp;
		$[149] = widthProp;
		$[150] = t43;
	} else t43 = $[150];
	return t43;
}
function _temp5(event_2) {
	event_2.stopPropagation();
}
function _temp4(el) {
	return isFocusable(el);
}
function _temp3(element) {
	return !element.getAttributeNames().includes("aria-hidden");
}
function _temp2$1(tokenText) {
	return tokenText !== null;
}
function _temp(token) {
	if ("text" in token && typeof token.text === "string" && token.text.trim().length) return token.text;
	return null;
}
var TextInputWithTokens = /* @__PURE__ */ React.forwardRef(TextInputWithTokensInnerComponent);
TextInputWithTokens.displayName = "TextInputWithTokens";
TextInputWithTokens.__SLOT__ = Symbol("TextInputWithTokens");
var classes$7 = {
	"TextArea": "prc-Textarea-TextArea-snlco",
	"CharacterCounter": "prc-Textarea-CharacterCounter-qnOXd",
	"CharacterCounter--error": "prc-Textarea-CharacterCounter--error-eewrs"
};
var DEFAULT_TEXTAREA_RESIZE = "both";
/**
* An accessible, native textarea component that supports validation states.
* This component accepts all native HTML <textarea> attributes as props.
*/
var Textarea = /* @__PURE__ */ React.forwardRef((t0, ref) => {
	const $ = c(68);
	let block;
	let characterLimit;
	let className;
	let contrast;
	let defaultValue;
	let disabled;
	let maxHeight;
	let minHeight;
	let onChange;
	let required;
	let rest;
	let style;
	let t1;
	let t2;
	let t3;
	let validationStatus;
	let value;
	if ($[0] !== t0) {
		({value, disabled, required, validationStatus, rows: t1, cols: t2, resize: t3, block, contrast, className, minHeight, maxHeight, style, characterLimit, onChange, defaultValue, ...rest} = t0);
		$[0] = t0;
		$[1] = block;
		$[2] = characterLimit;
		$[3] = className;
		$[4] = contrast;
		$[5] = defaultValue;
		$[6] = disabled;
		$[7] = maxHeight;
		$[8] = minHeight;
		$[9] = onChange;
		$[10] = required;
		$[11] = rest;
		$[12] = style;
		$[13] = t1;
		$[14] = t2;
		$[15] = t3;
		$[16] = validationStatus;
		$[17] = value;
	} else {
		block = $[1];
		characterLimit = $[2];
		className = $[3];
		contrast = $[4];
		defaultValue = $[5];
		disabled = $[6];
		maxHeight = $[7];
		minHeight = $[8];
		onChange = $[9];
		required = $[10];
		rest = $[11];
		style = $[12];
		t1 = $[13];
		t2 = $[14];
		t3 = $[15];
		validationStatus = $[16];
		value = $[17];
	}
	const rows = t1 === void 0 ? 7 : t1;
	const cols = t2 === void 0 ? 30 : t2;
	const resize = t3 === void 0 ? DEFAULT_TEXTAREA_RESIZE : t3;
	const [characterCount, setCharacterCount] = React.useState("");
	const [isOverLimit, setIsOverLimit] = React.useState(false);
	const [screenReaderMessage, setScreenReaderMessage] = React.useState("");
	const characterCounterRef = useRef(null);
	const characterCountId = useId();
	const characterCountStaticMessageId = useId();
	let t4;
	let t5;
	if ($[18] !== characterLimit) {
		t4 = () => {
			if (characterLimit) {
				characterCounterRef.current = new CharacterCounter({
					onCountUpdate: (count, overLimit, message) => {
						setCharacterCount(message);
						setIsOverLimit(overLimit);
					},
					onScreenReaderAnnounce: (message_0) => {
						setScreenReaderMessage(message_0);
					}
				});
				return () => {
					var _characterCounterRef$;
					(_characterCounterRef$ = characterCounterRef.current) === null || _characterCounterRef$ === void 0 || _characterCounterRef$.cleanup();
				};
			}
		};
		t5 = [characterLimit];
		$[18] = characterLimit;
		$[19] = t4;
		$[20] = t5;
	} else {
		t4 = $[19];
		t5 = $[20];
	}
	useEffect(t4, t5);
	let t6;
	let t7;
	if ($[21] !== characterLimit || $[22] !== defaultValue || $[23] !== value) {
		t6 = () => {
			if (characterLimit && characterCounterRef.current) {
				const currentValue = value !== void 0 ? String(value) : defaultValue !== void 0 ? String(defaultValue) : "";
				characterCounterRef.current.updateCharacterCount(currentValue.length, characterLimit);
			}
		};
		t7 = [
			value,
			defaultValue,
			characterLimit
		];
		$[21] = characterLimit;
		$[22] = defaultValue;
		$[23] = value;
		$[24] = t6;
		$[25] = t7;
	} else {
		t6 = $[24];
		t7 = $[25];
	}
	useEffect(t6, t7);
	let t8;
	if ($[26] !== characterLimit || $[27] !== onChange) {
		t8 = (e) => {
			var _onChange;
			if (characterLimit && characterCounterRef.current) characterCounterRef.current.updateCharacterCount(e.target.value.length, characterLimit);
			(_onChange = onChange) === null || _onChange === void 0 || _onChange(e);
		};
		$[26] = characterLimit;
		$[27] = onChange;
		$[28] = t8;
	} else t8 = $[28];
	const handleTextareaChange = t8;
	const isValid = isOverLimit ? "error" : validationStatus;
	const t9 = isValid === "error" ? "true" : "false";
	let t10;
	if ($[29] !== maxHeight || $[30] !== minHeight || $[31] !== style) {
		t10 = {
			minHeight,
			maxHeight,
			...style
		};
		$[29] = maxHeight;
		$[30] = minHeight;
		$[31] = style;
		$[32] = t10;
	} else t10 = $[32];
	let t11;
	if ($[33] !== characterCountStaticMessageId || $[34] !== characterLimit || $[35] !== rest) {
		t11 = characterLimit ? [characterCountStaticMessageId, rest["aria-describedby"]].filter(Boolean).join(" ") || void 0 : rest["aria-describedby"];
		$[33] = characterCountStaticMessageId;
		$[34] = characterLimit;
		$[35] = rest;
		$[36] = t11;
	} else t11 = $[36];
	let t12;
	if ($[37] !== cols || $[38] !== defaultValue || $[39] !== disabled || $[40] !== handleTextareaChange || $[41] !== ref || $[42] !== required || $[43] !== resize || $[44] !== rest || $[45] !== rows || $[46] !== t10 || $[47] !== t11 || $[48] !== t9 || $[49] !== value) {
		t12 = /* @__PURE__ */ jsx("textarea", {
			value,
			defaultValue,
			"data-resize": resize,
			"aria-required": required,
			"aria-invalid": t9,
			ref,
			disabled,
			rows,
			cols,
			className: classes$7.TextArea,
			onChange: handleTextareaChange,
			style: t10,
			...rest,
			"aria-describedby": t11
		});
		$[37] = cols;
		$[38] = defaultValue;
		$[39] = disabled;
		$[40] = handleTextareaChange;
		$[41] = ref;
		$[42] = required;
		$[43] = resize;
		$[44] = rest;
		$[45] = rows;
		$[46] = t10;
		$[47] = t11;
		$[48] = t9;
		$[49] = value;
		$[50] = t12;
	} else t12 = $[50];
	let t13;
	if ($[51] !== block || $[52] !== className || $[53] !== contrast || $[54] !== disabled || $[55] !== isValid || $[56] !== t12) {
		t13 = /* @__PURE__ */ jsx(TextInputBaseWrapper, {
			validationStatus: isValid,
			disabled,
			block,
			contrast,
			className,
			children: t12
		});
		$[51] = block;
		$[52] = className;
		$[53] = contrast;
		$[54] = disabled;
		$[55] = isValid;
		$[56] = t12;
		$[57] = t13;
	} else t13 = $[57];
	let t14;
	if ($[58] !== characterCount || $[59] !== characterCountId || $[60] !== characterCountStaticMessageId || $[61] !== characterLimit || $[62] !== isOverLimit || $[63] !== screenReaderMessage) {
		t14 = characterLimit && /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(VisuallyHidden, {
				"aria-live": "polite",
				role: "status",
				children: screenReaderMessage
			}),
			/* @__PURE__ */ jsxs(VisuallyHidden, {
				id: characterCountStaticMessageId,
				children: [
					"You can enter up to ",
					characterLimit,
					" ",
					characterLimit === 1 ? "character" : "characters"
				]
			}),
			/* @__PURE__ */ jsxs(Text$1, {
				"aria-hidden": "true",
				id: characterCountId,
				size: "small",
				className: clsx(classes$7.CharacterCounter, isOverLimit && classes$7["CharacterCounter--error"]),
				children: [isOverLimit && /* @__PURE__ */ jsx(AlertFillIcon, { size: 16 }), characterCount]
			})
		] });
		$[58] = characterCount;
		$[59] = characterCountId;
		$[60] = characterCountStaticMessageId;
		$[61] = characterLimit;
		$[62] = isOverLimit;
		$[63] = screenReaderMessage;
		$[64] = t14;
	} else t14 = $[64];
	let t15;
	if ($[65] !== t13 || $[66] !== t14) {
		t15 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t13, t14] });
		$[65] = t13;
		$[66] = t14;
		$[67] = t15;
	} else t15 = $[67];
	return t15;
});
Textarea.displayName = "Textarea";
Textarea.__SLOT__ = Symbol("Textarea");
/**
* Base context containing refs, stable IDs, menu visibility state, and callbacks.
* This context changes when menu opens/closes or selection changes, but NOT on every keystroke.
* Consumers like AutocompleteOverlay that don't need input text should use only this context.
*/
var AutocompleteContext = /* @__PURE__ */ createContext(null);
/**
* Input-related state that changes on every keystroke.
* Only AutocompleteInput needs this for immediate text display and suggestion highlighting.
*/
var AutocompleteInputContext = /* @__PURE__ */ createContext(null);
/**
* Deferred input value for expensive operations like filtering.
* Uses React's useDeferredValue to allow typing to remain responsive while
* filtering large lists at lower priority.
* AutocompleteMenu uses this to avoid blocking keystrokes during filtering.
*/
var AutocompleteDeferredInputContext = /* @__PURE__ */ createContext(null);
var ARROW_KEYS_NAV = new Set(["ArrowUp", "ArrowDown"]);
var AutocompleteInput = /* @__PURE__ */ React.forwardRef(({ as: Component = TextInput$1, onFocus, onBlur, onChange, onKeyDown, onKeyUp, onKeyPress, value, openOnFocus = false, ...props }, forwardedRef) => {
	const autocompleteContext = useContext(AutocompleteContext);
	const inputContext = useContext(AutocompleteInputContext);
	if (autocompleteContext === null || inputContext === null) throw new Error("AutocompleteContext returned null values");
	const { activeDescendantRef, id, inputRef, setInputValue, setShowMenu, showMenu } = autocompleteContext;
	const { autocompleteSuggestion = "", inputValue = "", isMenuDirectlyActivated } = inputContext;
	useRefObjectAsForwardedRef(forwardedRef, inputRef);
	const [highlightRemainingText, setHighlightRemainingText] = useState(true);
	const { safeSetTimeout } = useSafeTimeout();
	const handleInputFocus = (event) => {
		onFocus === null || onFocus === void 0 || onFocus(event);
		if (openOnFocus) setShowMenu(true);
	};
	const handleInputBlur = useCallback((event) => {
		onBlur && onBlur(event);
		safeSetTimeout(() => {
			if (document.activeElement !== inputRef.current) setShowMenu(false);
		}, 0);
	}, [
		onBlur,
		setShowMenu,
		inputRef,
		safeSetTimeout
	]);
	const handleInputChange = (event) => {
		onChange && onChange(event);
		setInputValue(event.currentTarget.value);
		if (!showMenu) setShowMenu(true);
	};
	const handleInputKeyDown = useCallback((event) => {
		var _inputRef$current;
		onKeyDown && onKeyDown(event);
		if (event.key === "Backspace") setHighlightRemainingText(false);
		if (event.key === "Escape" && (_inputRef$current = inputRef.current) !== null && _inputRef$current !== void 0 && _inputRef$current.value) {
			setInputValue("");
			inputRef.current.value = "";
		}
		if (!showMenu && ARROW_KEYS_NAV.has(event.key) && !event.altKey) setShowMenu(true);
	}, [
		inputRef,
		setInputValue,
		setHighlightRemainingText,
		onKeyDown,
		showMenu,
		setShowMenu
	]);
	const handleInputKeyUp = useCallback((event) => {
		onKeyUp && onKeyUp(event);
		if (event.key === "Backspace") setHighlightRemainingText(true);
	}, [setHighlightRemainingText, onKeyUp]);
	const onInputKeyPress = useCallback((event) => {
		onKeyPress && onKeyPress(event);
		if (showMenu && event.key === "Enter" && activeDescendantRef.current) {
			event.preventDefault();
			event.nativeEvent.stopImmediatePropagation();
			const activeDescendantEvent = new KeyboardEvent(event.type, event.nativeEvent);
			activeDescendantRef.current.dispatchEvent(activeDescendantEvent);
		}
	}, [
		activeDescendantRef,
		showMenu,
		onKeyPress
	]);
	useEffect(() => {
		if (!inputRef.current) return;
		if (!autocompleteSuggestion) inputRef.current.value = inputValue;
		if (highlightRemainingText && autocompleteSuggestion && (inputValue || isMenuDirectlyActivated)) {
			inputRef.current.value = autocompleteSuggestion;
			if (autocompleteSuggestion.toLowerCase().indexOf(inputValue.toLowerCase()) === 0) inputRef.current.setSelectionRange(inputValue.length, autocompleteSuggestion.length);
		}
	}, [
		autocompleteSuggestion,
		inputValue,
		inputRef,
		isMenuDirectlyActivated
	]);
	useEffect(() => {
		setInputValue(typeof value !== "undefined" ? value.toString() : "");
	}, [value, setInputValue]);
	return /* @__PURE__ */ jsx(Component, {
		onFocus: handleInputFocus,
		onBlur: handleInputBlur,
		onChange: handleInputChange,
		onKeyDown: handleInputKeyDown,
		onKeyPress: onInputKeyPress,
		onKeyUp: handleInputKeyUp,
		ref: inputRef,
		"aria-controls": `${id}-listbox`,
		"aria-autocomplete": "both",
		role: "combobox",
		"aria-expanded": showMenu,
		"aria-haspopup": "listbox",
		"aria-owns": `${id}-listbox`,
		autoComplete: "off",
		id,
		...props
	});
});
AutocompleteInput.displayName = "AutocompleteInput";
AutocompleteInput.__SLOT__ = Symbol("Autocomplete.Input");
var classes$6 = {
	"SpinnerWrapper": "prc-Autocomplete-SpinnerWrapper-DJN3d",
	"EmptyStateWrapper": "prc-Autocomplete-EmptyStateWrapper-OoIjW"
};
var getDefaultSortFn = (isItemSelectedFn) => (itemIdA, itemIdB) => isItemSelectedFn(itemIdA) === isItemSelectedFn(itemIdB) ? 0 : isItemSelectedFn(itemIdA) ? -1 : 1;
var menuScrollMargins = {
	startMargin: 0,
	endMargin: 8
};
function getDefaultItemFilter(filterValue) {
	return function(item, _i) {
		var _item$text;
		return Boolean((_item$text = item.text) === null || _item$text === void 0 ? void 0 : _item$text.toLowerCase().startsWith(filterValue.toLowerCase()));
	};
}
function getdefaultCheckedSelectionChange(setInputValueFn) {
	return function(itemOrItems) {
		const { text = "" } = Array.isArray(itemOrItems) ? itemOrItems.slice(-1)[0] : itemOrItems;
		setInputValueFn(text);
	};
}
var isItemSelected = (itemId, selectedItemIds) => selectedItemIds.includes(itemId);
function getItemById(itemId, items) {
	return items.find((item) => item.id === itemId);
}
/**
* Announces a message to screen readers at a slowed-down rate. This is useful when you want to announce don't want to
* overwhelm the user with too many announcements in rapid succession.
*/
var debounceAnnouncement = debounce((announcement) => {
	announce(announcement);
}, 250);
function AutocompleteMenu(props) {
	const autocompleteContext = useContext(AutocompleteContext);
	const deferredInputContext = useContext(AutocompleteDeferredInputContext);
	if (autocompleteContext === null || deferredInputContext === null) throw new Error("AutocompleteContext returned null values");
	const { activeDescendantRef, id, inputRef, scrollContainerRef, setAutocompleteSuggestion, setShowMenu, setInputValue, setIsMenuDirectlyActivated, setSelectedItemLength, showMenu } = autocompleteContext;
	const { deferredInputValue } = deferredInputContext;
	const { items, selectedItemIds, sortOnCloseFn, emptyStateText = "No selectable options", addNewItem, loading, selectionVariant = "single", filterFn, "aria-labelledby": ariaLabelledBy, onOpenChange, onSelectedChange, customScrollContainerRef } = props;
	const listContainerRef = useRef(null);
	const allItemsToRenderRef = useRef([]);
	const [highlightedItem, setHighlightedItem] = useState();
	const [sortedItemIds, setSortedItemIds] = useState(items.map(({ id: itemId }) => itemId));
	const generatedUniqueId = useId$1(id);
	const selectableItems = useMemo(() => items.map((selectableItem) => {
		return {
			...selectableItem,
			role: "option",
			id: selectableItem.id,
			active: (highlightedItem === null || highlightedItem === void 0 ? void 0 : highlightedItem.id) === selectableItem.id,
			selected: selectionVariant === "multiple" ? selectedItemIds.includes(selectableItem.id) : void 0,
			onAction: (item) => {
				const otherSelectedItemIds = selectedItemIds.filter((selectedItemId) => selectedItemId !== item.id);
				const newSelectedItemIds = selectedItemIds.includes(item.id) ? otherSelectedItemIds : [...otherSelectedItemIds, item.id];
				(onSelectedChange ? onSelectedChange : getdefaultCheckedSelectionChange(setInputValue))(newSelectedItemIds.map((newSelectedItemId) => getItemById(newSelectedItemId, items)));
				if (selectionVariant === "multiple") {
					setInputValue("");
					setAutocompleteSuggestion("");
				} else {
					var _inputRef$current;
					setShowMenu(false);
					(_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 || _inputRef$current.setSelectionRange(inputRef.current.value.length, inputRef.current.value.length);
				}
			}
		};
	}), [
		highlightedItem,
		items,
		selectedItemIds,
		inputRef,
		onSelectedChange,
		selectionVariant,
		setAutocompleteSuggestion,
		setInputValue,
		setShowMenu
	]);
	const itemSortOrderData = useMemo(() => sortedItemIds.reduce((acc, curr, i) => {
		acc[curr] = i;
		return acc;
	}, {}), [sortedItemIds]);
	const sortedAndFilteredItemsToRender = useMemo(() => selectableItems.filter(filterFn ? filterFn : getDefaultItemFilter(deferredInputValue)).sort((a, b) => itemSortOrderData[a.id] - itemSortOrderData[b.id]), [
		selectableItems,
		itemSortOrderData,
		filterFn,
		deferredInputValue
	]);
	const allItemsToRender = useMemo(() => [...sortedAndFilteredItemsToRender, ...addNewItem ? [{
		...addNewItem,
		role: "option",
		key: addNewItem.id,
		active: (highlightedItem === null || highlightedItem === void 0 ? void 0 : highlightedItem.id) === addNewItem.id,
		selected: selectionVariant === "multiple" ? selectedItemIds.includes(addNewItem.id) : void 0,
		leadingVisual: () => /* @__PURE__ */ jsx(PlusIcon, {}),
		onAction: (item) => {
			addNewItem.handleAddItem({
				...item,
				id: item.id || generatedUniqueId,
				leadingVisual: void 0
			});
			if (selectionVariant === "multiple") {
				setInputValue("");
				setAutocompleteSuggestion("");
			}
		}
	}] : []], [
		sortedAndFilteredItemsToRender,
		addNewItem,
		setAutocompleteSuggestion,
		selectionVariant,
		setInputValue,
		generatedUniqueId,
		highlightedItem,
		selectedItemIds
	]);
	React.useEffect(() => {
		allItemsToRenderRef.current = allItemsToRender;
	});
	React.useEffect(() => {
		if (allItemsToRender.length === 0) debounceAnnouncement(emptyStateText);
	}, [allItemsToRender, emptyStateText]);
	useFocusZone({
		containerRef: listContainerRef,
		focusOutBehavior: "wrap",
		focusableElementFilter: (element) => {
			return !(element instanceof HTMLInputElement);
		},
		activeDescendantFocus: inputRef,
		onActiveDescendantChanged: (current, _previous, directlyActivated) => {
			activeDescendantRef.current = current || null;
			if (current) {
				setHighlightedItem(allItemsToRenderRef.current.find((item) => {
					var _current$closest;
					return item.id === ((_current$closest = current.closest("li")) === null || _current$closest === void 0 ? void 0 : _current$closest.getAttribute("data-id"));
				}));
				setIsMenuDirectlyActivated(directlyActivated);
			}
			if (current && customScrollContainerRef && customScrollContainerRef.current && directlyActivated) scrollIntoView(current, customScrollContainerRef.current, menuScrollMargins);
			else if (current && scrollContainerRef.current && directlyActivated) scrollIntoView(current, scrollContainerRef.current, menuScrollMargins);
		}
	}, [loading]);
	useEffect(() => {
		var _highlightedItem$text;
		if (highlightedItem !== null && highlightedItem !== void 0 && (_highlightedItem$text = highlightedItem.text) !== null && _highlightedItem$text !== void 0 && _highlightedItem$text.startsWith(deferredInputValue) && !selectedItemIds.includes(highlightedItem.id)) setAutocompleteSuggestion(highlightedItem.text);
		else setAutocompleteSuggestion("");
	}, [
		highlightedItem,
		deferredInputValue,
		selectedItemIds,
		setAutocompleteSuggestion
	]);
	useEffect(() => {
		const itemIdSortResult = [...sortedItemIds].sort(sortOnCloseFn ? sortOnCloseFn : getDefaultSortFn((itemId) => isItemSelected(itemId, selectedItemIds)));
		const sortResultMatchesState = itemIdSortResult.length === sortedItemIds.length && itemIdSortResult.every((element, index) => element === sortedItemIds[index]);
		if (showMenu === false && !sortResultMatchesState) setSortedItemIds(itemIdSortResult);
		onOpenChange && onOpenChange(Boolean(showMenu));
	}, [
		showMenu,
		onOpenChange,
		selectedItemIds,
		sortOnCloseFn,
		sortedItemIds
	]);
	useEffect(() => {
		if (selectedItemIds.length) setSelectedItemLength(selectedItemIds.length);
	}, [selectedItemIds, setSelectedItemLength]);
	if (selectionVariant === "single" && selectedItemIds.length > 1) throw new Error("Autocomplete: selectionVariant \"single\" cannot be used with multiple selected items");
	return /* @__PURE__ */ jsx(VisuallyHidden, {
		isVisible: showMenu,
		children: loading ? /* @__PURE__ */ jsx("div", {
			className: classes$6.SpinnerWrapper,
			children: /* @__PURE__ */ jsx(Spinner, {})
		}) : /* @__PURE__ */ jsx("div", {
			ref: listContainerRef,
			children: allItemsToRender.length ? /* @__PURE__ */ jsx(ActionList, {
				selectionVariant,
				role: "listbox",
				id: `${id}-listbox`,
				"aria-labelledby": ariaLabelledBy,
				children: allItemsToRender.map((item) => {
					const { id, onAction, children, text, leadingVisual: LeadingVisual, trailingVisual: TrailingVisual, key, role, ...itemProps } = item;
					return /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => onAction(item),
						...itemProps,
						id,
						"data-id": id,
						role,
						children: [
							LeadingVisual && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: isElement(LeadingVisual) ? LeadingVisual : /* @__PURE__ */ jsx(LeadingVisual, {}) }),
							children !== null && children !== void 0 ? children : text,
							TrailingVisual && /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: isElement(TrailingVisual) ? TrailingVisual : /* @__PURE__ */ jsx(TrailingVisual, {}) })
						]
					}, key !== null && key !== void 0 ? key : id);
				})
			}) : emptyStateText !== false && emptyStateText !== null ? /* @__PURE__ */ jsx("div", {
				className: classes$6.EmptyStateWrapper,
				children: emptyStateText
			}) : null
		})
	});
}
AutocompleteMenu.displayName = "AutocompleteMenu";
AutocompleteMenu.displayName = "AutocompleteMenu";
AutocompleteMenu.__SLOT__ = Symbol("Autocomplete.Menu");
var classes$5 = { "Overlay": "prc-Autocomplete-Overlay-bwNcB" };
function AutocompleteOverlay({ menuAnchorRef, overlayProps: oldOverlayProps, children, className, ...newOverlayProps }) {
	const autocompleteContext = useContext(AutocompleteContext);
	if (autocompleteContext === null) throw new Error("AutocompleteContext returned null values");
	const overlayProps = {
		...oldOverlayProps,
		...newOverlayProps
	};
	const { inputRef, scrollContainerRef, selectedItemLength, setShowMenu, showMenu = false } = autocompleteContext;
	const computedAnchorRef = useRef(null);
	useEffect(() => {
		var _menuAnchorRef$curren, _tokensContainer$pare, _ref;
		const explicit = (_menuAnchorRef$curren = menuAnchorRef === null || menuAnchorRef === void 0 ? void 0 : menuAnchorRef.current) !== null && _menuAnchorRef$curren !== void 0 ? _menuAnchorRef$curren : null;
		const tokensContainer = inputRef.current ? inputRef.current.closest("[data-prevent-token-wrapping]") : null;
		const tokensRoot = (_tokensContainer$pare = tokensContainer === null || tokensContainer === void 0 ? void 0 : tokensContainer.parentElement) !== null && _tokensContainer$pare !== void 0 ? _tokensContainer$pare : null;
		computedAnchorRef.current = (_ref = explicit !== null && explicit !== void 0 ? explicit : tokensRoot) !== null && _ref !== void 0 ? _ref : inputRef.current;
	}, [menuAnchorRef, inputRef]);
	const { floatingElementRef, position } = useAnchoredPosition({
		side: "outside-bottom",
		align: "start",
		anchorElementRef: computedAnchorRef
	}, [showMenu, selectedItemLength]);
	useRefObjectAsForwardedRef(scrollContainerRef, floatingElementRef);
	const closeOptionList = useCallback(() => {
		setShowMenu(false);
	}, [setShowMenu]);
	if (typeof window === "undefined") return null;
	return showMenu ? /* @__PURE__ */ jsx(Overlay, {
		returnFocusRef: inputRef,
		preventFocusOnOpen: true,
		onClickOutside: closeOptionList,
		onEscape: closeOptionList,
		ref: floatingElementRef,
		top: position === null || position === void 0 ? void 0 : position.top,
		left: position === null || position === void 0 ? void 0 : position.left,
		className: clsx(classes$5.Overlay, className),
		...overlayProps,
		children
	}) : /* @__PURE__ */ jsx(VisuallyHidden, {
		"aria-hidden": "true",
		children
	});
}
AutocompleteOverlay.displayName = "AutocompleteOverlay";
AutocompleteOverlay.__SLOT__ = Symbol("Autocomplete.Overlay");
var initialState = {
	inputValue: "",
	showMenu: false,
	isMenuDirectlyActivated: false,
	autocompleteSuggestion: "",
	selectedItemLength: 0
};
var reducer = (state, action) => {
	const { type, payload } = action;
	switch (type) {
		case "inputValue": return {
			...state,
			inputValue: payload
		};
		case "showMenu": return {
			...state,
			showMenu: payload
		};
		case "isMenuDirectlyActivated": return {
			...state,
			isMenuDirectlyActivated: payload
		};
		case "autocompleteSuggestion": return {
			...state,
			autocompleteSuggestion: payload
		};
		case "selectedItemLength": return {
			...state,
			selectedItemLength: payload
		};
		default: return state;
	}
};
var Autocomplete = ({ children, id: idProp }) => {
	const activeDescendantRef = useRef(null);
	const scrollContainerRef = useRef(null);
	const inputRef = useRef(null);
	const [state, dispatch] = useReducer(reducer, initialState);
	const { inputValue, showMenu, autocompleteSuggestion, isMenuDirectlyActivated, selectedItemLength } = state;
	const setInputValue = useCallback((value) => {
		dispatch({
			type: "inputValue",
			payload: value
		});
	}, []);
	const setShowMenu = useCallback((value) => {
		dispatch({
			type: "showMenu",
			payload: value
		});
	}, []);
	const setAutocompleteSuggestion = useCallback((value) => {
		dispatch({
			type: "autocompleteSuggestion",
			payload: value
		});
	}, []);
	const setIsMenuDirectlyActivated = useCallback((value) => {
		dispatch({
			type: "isMenuDirectlyActivated",
			payload: value
		});
	}, []);
	const setSelectedItemLength = useCallback((value) => {
		dispatch({
			type: "selectedItemLength",
			payload: value
		});
	}, []);
	const id = useId$1(idProp);
	const autocompleteContextValue = useMemo(() => ({
		activeDescendantRef,
		id,
		inputRef,
		scrollContainerRef,
		selectedItemLength,
		setAutocompleteSuggestion,
		setInputValue,
		setIsMenuDirectlyActivated,
		setShowMenu,
		setSelectedItemLength,
		showMenu
	}), [
		id,
		selectedItemLength,
		setAutocompleteSuggestion,
		setInputValue,
		setIsMenuDirectlyActivated,
		setShowMenu,
		setSelectedItemLength,
		showMenu
	]);
	const autocompleteInputContextValue = useMemo(() => ({
		autocompleteSuggestion,
		inputValue,
		isMenuDirectlyActivated
	}), [
		autocompleteSuggestion,
		inputValue,
		isMenuDirectlyActivated
	]);
	const deferredInputValue = useDeferredValue(inputValue);
	const autocompleteDeferredInputContextValue = useMemo(() => ({ deferredInputValue }), [deferredInputValue]);
	return /* @__PURE__ */ jsx(AutocompleteContext.Provider, {
		value: autocompleteContextValue,
		children: /* @__PURE__ */ jsx(AutocompleteInputContext.Provider, {
			value: autocompleteInputContextValue,
			children: /* @__PURE__ */ jsx(AutocompleteDeferredInputContext.Provider, {
				value: autocompleteDeferredInputContextValue,
				children
			})
		})
	});
};
Autocomplete.displayName = "Autocomplete";
var Autocomplete$1 = Object.assign(Autocomplete, {
	__SLOT__: Symbol("Autocomplete"),
	Context: AutocompleteContext,
	Input: AutocompleteInput,
	Menu: AutocompleteMenu,
	Overlay: AutocompleteOverlay
});
var classes$4 = {
	"Select": "prc-Select-Select-dJWwD",
	"TextInputWrapper": "prc-Select-TextInputWrapper-5NYFF",
	"Disabled": "prc-Select-Disabled-56BAq",
	"ArrowIndicator": "prc-Select-ArrowIndicator-WjH-8"
};
var ArrowIndicatorSVG = (t0) => {
	const $ = c(3);
	const { className } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ jsx("path", { d: "m4.074 9.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.043 9H4.251a.25.25 0 0 0-.177.427ZM4.074 7.47 7.47 4.073a.25.25 0 0 1 .354 0L11.22 7.47a.25.25 0 0 1-.177.426H4.251a.25.25 0 0 1-.177-.426Z" });
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== className) {
		t2 = /* @__PURE__ */ jsx("svg", {
			"aria-hidden": "true",
			width: "16",
			height: "16",
			fill: "currentColor",
			xmlns: "http://www.w3.org/2000/svg",
			className,
			children: t1
		});
		$[1] = className;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
};
var ArrowIndicator = (t0) => {
	const $ = c(4);
	const { className } = t0;
	let t1;
	if ($[0] !== className) {
		t1 = clsx(classes$4.ArrowIndicator, className);
		$[0] = className;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t1) {
		t2 = /* @__PURE__ */ jsx(ArrowIndicatorSVG, { className: t1 });
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
var Select = /* @__PURE__ */ React.forwardRef((t0, ref) => {
	var _ref, _defaultValue;
	const $ = c(37);
	let block;
	let children;
	let className;
	let defaultValue;
	let disabled;
	let placeholder;
	let required;
	let rest;
	let size;
	let validationStatus;
	if ($[0] !== t0) {
		({block, children, className, defaultValue, disabled, placeholder, size, required, validationStatus, ...rest} = t0);
		$[0] = t0;
		$[1] = block;
		$[2] = children;
		$[3] = className;
		$[4] = defaultValue;
		$[5] = disabled;
		$[6] = placeholder;
		$[7] = required;
		$[8] = rest;
		$[9] = size;
		$[10] = validationStatus;
	} else {
		block = $[1];
		children = $[2];
		className = $[3];
		defaultValue = $[4];
		disabled = $[5];
		placeholder = $[6];
		required = $[7];
		rest = $[8];
		size = $[9];
		validationStatus = $[10];
	}
	let t1;
	if ($[11] !== className) {
		t1 = clsx(classes$4.TextInputWrapper, className);
		$[11] = className;
		$[12] = t1;
	} else t1 = $[12];
	const t2 = validationStatus === "error" ? "true" : "false";
	const t3 = disabled && classes$4.Disabled;
	let t4;
	if ($[13] !== t3) {
		t4 = clsx(classes$4.Select, t3);
		$[13] = t3;
		$[14] = t4;
	} else t4 = $[14];
	const t5 = Boolean(placeholder);
	const t6 = (_ref = (_defaultValue = defaultValue) !== null && _defaultValue !== void 0 ? _defaultValue : placeholder) !== null && _ref !== void 0 ? _ref : void 0;
	let t7;
	if ($[15] !== placeholder || $[16] !== required) {
		t7 = placeholder && /* @__PURE__ */ jsx("option", {
			value: "",
			disabled: required,
			hidden: required,
			children: placeholder
		});
		$[15] = placeholder;
		$[16] = required;
		$[17] = t7;
	} else t7 = $[17];
	let t8;
	if ($[18] !== children || $[19] !== disabled || $[20] !== ref || $[21] !== required || $[22] !== rest || $[23] !== t2 || $[24] !== t4 || $[25] !== t5 || $[26] !== t6 || $[27] !== t7) {
		t8 = /* @__PURE__ */ jsxs("select", {
			...rest,
			ref,
			required,
			disabled,
			"aria-invalid": t2,
			className: t4,
			"data-hasplaceholder": t5,
			defaultValue: t6,
			children: [t7, children]
		});
		$[18] = children;
		$[19] = disabled;
		$[20] = ref;
		$[21] = required;
		$[22] = rest;
		$[23] = t2;
		$[24] = t4;
		$[25] = t5;
		$[26] = t6;
		$[27] = t7;
		$[28] = t8;
	} else t8 = $[28];
	let t9;
	if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = /* @__PURE__ */ jsx(ArrowIndicator, { className: classes$4.ArrowIndicator });
		$[29] = t9;
	} else t9 = $[29];
	let t10;
	if ($[30] !== block || $[31] !== disabled || $[32] !== size || $[33] !== t1 || $[34] !== t8 || $[35] !== validationStatus) {
		t10 = /* @__PURE__ */ jsxs(TextInputWrapper, {
			block,
			disabled,
			size,
			validationStatus,
			className: t1,
			children: [t8, t9]
		});
		$[30] = block;
		$[31] = disabled;
		$[32] = size;
		$[33] = t1;
		$[34] = t8;
		$[35] = validationStatus;
		$[36] = t10;
	} else t10 = $[36];
	return t10;
});
var Option = (props) => {
	const $ = c(2);
	let t0;
	if ($[0] !== props) {
		t0 = /* @__PURE__ */ jsx("option", { ...props });
		$[0] = props;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
};
var OptGroup = (props) => {
	const $ = c(2);
	let t0;
	if ($[0] !== props) {
		t0 = /* @__PURE__ */ jsx("optgroup", { ...props });
		$[0] = props;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
};
var Select$1 = Object.assign(Select, {
	__SLOT__: Symbol("Select"),
	Option,
	OptGroup
});
var classes$3 = { "Caption": "prc-FormControl-Caption-GNJPU" };
function FormControlCaption(t0) {
	const $ = c(8);
	const { id, children, className, style } = t0;
	const { captionId, disabled } = useFormControlContext();
	const t1 = id !== null && id !== void 0 ? id : captionId;
	let t2;
	if ($[0] !== className) {
		t2 = clsx(className, classes$3.Caption);
		$[0] = className;
		$[1] = t2;
	} else t2 = $[1];
	const t3 = disabled ? "" : void 0;
	let t4;
	if ($[2] !== children || $[3] !== style || $[4] !== t1 || $[5] !== t2 || $[6] !== t3) {
		t4 = /* @__PURE__ */ jsx(Text$1, {
			id: t1,
			className: t2,
			"data-control-disabled": t3,
			style,
			children
		});
		$[2] = children;
		$[3] = style;
		$[4] = t1;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
}
FormControlCaption.__SLOT__ = Symbol("FormControl.Caption");
var classes$2 = {
	"Label": "prc-components-Label-2mrqP",
	"RequiredText": "prc-components-RequiredText-7UsHS"
};
function InputLabel(t0) {
	const $ = c(28);
	let children;
	let className;
	let disabled;
	let htmlFor;
	let id;
	let props;
	let required;
	let requiredIndicator;
	let requiredText;
	let t1;
	let visuallyHidden;
	if ($[0] !== t0) {
		({children, disabled, htmlFor, id, required, requiredText, requiredIndicator, visuallyHidden, as: t1, className, ...props} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = disabled;
		$[4] = htmlFor;
		$[5] = id;
		$[6] = props;
		$[7] = required;
		$[8] = requiredIndicator;
		$[9] = requiredText;
		$[10] = t1;
		$[11] = visuallyHidden;
	} else {
		children = $[1];
		className = $[2];
		disabled = $[3];
		htmlFor = $[4];
		id = $[5];
		props = $[6];
		required = $[7];
		requiredIndicator = $[8];
		requiredText = $[9];
		t1 = $[10];
		visuallyHidden = $[11];
	}
	const Component = t1 === void 0 ? "label" : t1;
	const t2 = disabled ? "" : void 0;
	const t3 = visuallyHidden ? "" : void 0;
	let t4;
	if ($[12] !== className) {
		t4 = clsx(className, classes$2.Label);
		$[12] = className;
		$[13] = t4;
	} else t4 = $[13];
	let t5;
	if ($[14] !== children || $[15] !== required || $[16] !== requiredIndicator || $[17] !== requiredText) {
		var _requiredText;
		t5 = required || requiredText ? /* @__PURE__ */ jsxs("span", {
			className: classes$2.RequiredText,
			children: [/* @__PURE__ */ jsx("span", { children }), /* @__PURE__ */ jsx("span", {
				"aria-hidden": requiredIndicator ? void 0 : true,
				children: (_requiredText = requiredText) !== null && _requiredText !== void 0 ? _requiredText : "*"
			})]
		}) : children;
		$[14] = children;
		$[15] = required;
		$[16] = requiredIndicator;
		$[17] = requiredText;
		$[18] = t5;
	} else t5 = $[18];
	let t6;
	if ($[19] !== Component || $[20] !== htmlFor || $[21] !== id || $[22] !== props || $[23] !== t2 || $[24] !== t3 || $[25] !== t4 || $[26] !== t5) {
		t6 = /* @__PURE__ */ jsx(Component, {
			"data-control-disabled": t2,
			"data-visually-hidden": t3,
			htmlFor,
			id,
			className: t4,
			...props,
			children: t5
		});
		$[19] = Component;
		$[20] = htmlFor;
		$[21] = id;
		$[22] = props;
		$[23] = t2;
		$[24] = t3;
		$[25] = t4;
		$[26] = t5;
		$[27] = t6;
	} else t6 = $[27];
	return t6;
}
var FormControlLabel = (t0) => {
	var _id;
	const $ = c(26);
	let as;
	let children;
	let className;
	let htmlFor;
	let id;
	let props;
	let requiredText;
	let t1;
	let visuallyHidden;
	if ($[0] !== t0) {
		({as, children, htmlFor, id, visuallyHidden, requiredIndicator: t1, requiredText, className, ...props} = t0);
		$[0] = t0;
		$[1] = as;
		$[2] = children;
		$[3] = className;
		$[4] = htmlFor;
		$[5] = id;
		$[6] = props;
		$[7] = requiredText;
		$[8] = t1;
		$[9] = visuallyHidden;
	} else {
		as = $[1];
		children = $[2];
		className = $[3];
		htmlFor = $[4];
		id = $[5];
		props = $[6];
		requiredText = $[7];
		t1 = $[8];
		visuallyHidden = $[9];
	}
	const requiredIndicator = t1 === void 0 ? true : t1;
	const { disabled, id: formControlId, required, isReferenced, labelId } = useFormControlContext();
	const resolvedId = (_id = id) !== null && _id !== void 0 ? _id : labelId;
	let t2;
	if ($[10] !== as || $[11] !== className || $[12] !== disabled || $[13] !== formControlId || $[14] !== htmlFor || $[15] !== isReferenced || $[16] !== props || $[17] !== required || $[18] !== requiredIndicator || $[19] !== requiredText || $[20] !== resolvedId || $[21] !== visuallyHidden) {
		t2 = as === "legend" || as === "span" ? {
			as,
			id: resolvedId,
			className,
			visuallyHidden,
			required,
			requiredText,
			requiredIndicator,
			disabled,
			...props
		} : {
			as,
			id: resolvedId,
			className,
			visuallyHidden,
			htmlFor: isReferenced === false ? void 0 : htmlFor || formControlId,
			required,
			requiredText,
			requiredIndicator,
			disabled,
			...props
		};
		$[10] = as;
		$[11] = className;
		$[12] = disabled;
		$[13] = formControlId;
		$[14] = htmlFor;
		$[15] = isReferenced;
		$[16] = props;
		$[17] = required;
		$[18] = requiredIndicator;
		$[19] = requiredText;
		$[20] = resolvedId;
		$[21] = visuallyHidden;
		$[22] = t2;
	} else t2 = $[22];
	const labelProps = t2;
	let t3;
	if ($[23] !== children || $[24] !== labelProps) {
		t3 = /* @__PURE__ */ jsx(InputLabel, {
			...labelProps,
			children
		});
		$[23] = children;
		$[24] = labelProps;
		$[25] = t3;
	} else t3 = $[25];
	return t3;
};
FormControlLabel.__SLOT__ = Symbol("FormControl.Label");
var classes$1 = { "LeadingVisual": "prc-FormControl-LeadingVisual-AAfW7" };
var FormControlLeadingVisual = (t0) => {
	const $ = c(5);
	const { children, style } = t0;
	const { disabled, captionId } = useFormControlContext();
	const t1 = disabled ? "" : void 0;
	const t2 = captionId ? "" : void 0;
	let t3;
	if ($[0] !== children || $[1] !== style || $[2] !== t1 || $[3] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			className: classes$1.LeadingVisual,
			"data-control-disabled": t1,
			style,
			"data-has-caption": t2,
			children
		});
		$[0] = children;
		$[1] = style;
		$[2] = t1;
		$[3] = t2;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
};
FormControlLeadingVisual.__SLOT__ = Symbol("FormControl.LeadingVisual");
var FormControlValidation = (t0) => {
	const $ = c(6);
	const { children, className, variant, id, style } = t0;
	const { validationMessageId } = useFormControlContext();
	const t1 = id || validationMessageId || "";
	let t2;
	if ($[0] !== children || $[1] !== className || $[2] !== style || $[3] !== t1 || $[4] !== variant) {
		t2 = /* @__PURE__ */ jsx(InputValidation, {
			className,
			validationStatus: variant,
			id: t1,
			style,
			children
		});
		$[0] = children;
		$[1] = className;
		$[2] = style;
		$[3] = t1;
		$[4] = variant;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
};
FormControlValidation.__SLOT__ = Symbol("FormControl.Validation");
var classes = {
	"ControlHorizontalLayout": "prc-FormControl-ControlHorizontalLayout-0XQ-8",
	"ControlVerticalLayout": "prc-FormControl-ControlVerticalLayout-8YotI",
	"ControlChoiceInputs": "prc-FormControl-ControlChoiceInputs--r3lG",
	"LabelContainer": "prc-FormControl-LabelContainer-M-FSK",
	"LeadingVisual": "prc-FormControl-LeadingVisual-IcFhb"
};
var FormControl = /* @__PURE__ */ React.forwardRef((t0, ref) => {
	var _slots$validation, _slots$label;
	const $ = c(32);
	const { children, disabled: disabledProp, layout: t1, id: idProp, required, className, style } = t0;
	const layout = t1 === void 0 ? "vertical" : t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = {
			caption: FormControlCaption,
			label: FormControlLabel,
			leadingVisual: FormControlLeadingVisual,
			validation: FormControlValidation
		};
		$[0] = t2;
	} else t2 = $[0];
	const [slots, childrenWithoutSlots] = useSlots(children, t2);
	const expectedInputComponents = [
		Autocomplete$1,
		Checkbox,
		Radio,
		Select$1,
		TextInput$1,
		TextInputWithTokens,
		Textarea,
		SelectPanel
	];
	const disabled = useContext(CheckboxOrRadioGroupContext).disabled || disabledProp;
	const id = useId$1(idProp);
	const validationMessageId = slots.validation ? `${id}-validationMessage` : void 0;
	const captionId = slots.caption ? `${id}-caption` : void 0;
	const validationStatus = (_slots$validation = slots.validation) === null || _slots$validation === void 0 ? void 0 : _slots$validation.props.variant;
	const InputComponent = childrenWithoutSlots.find((child) => expectedInputComponents.some((inputComponent) => /* @__PURE__ */ React.isValidElement(child) && (child.type === inputComponent || isSlot(child, inputComponent))));
	/* @__PURE__ */ React.isValidElement(InputComponent) && InputComponent.props;
	const isChoiceInput = /* @__PURE__ */ React.isValidElement(InputComponent) && (InputComponent.type === Checkbox || InputComponent.type === Radio || isSlot(InputComponent, Checkbox) || isSlot(InputComponent, Radio));
	const isRadioInput = /* @__PURE__ */ React.isValidElement(InputComponent) && (InputComponent.type === Radio || isSlot(InputComponent, Radio));
	const isSelectPanelInput = /* @__PURE__ */ React.isValidElement(InputComponent) && (InputComponent.type === SelectPanel || isSlot(InputComponent, SelectPanel));
	let t3;
	if ($[1] !== id || $[2] !== slots.label) {
		var _ref;
		t3 = slots.label ? (_ref = /* @__PURE__ */ React.isValidElement(slots.label) ? slots.label.props.id : void 0) !== null && _ref !== void 0 ? _ref : `${id}-label` : void 0;
		$[1] = id;
		$[2] = slots.label;
		$[3] = t3;
	} else t3 = $[3];
	const labelId = t3;
	if (InputComponent) {}
	if (!slots.label) console.error(`The input field with the id ${id} MUST have a FormControl.Label child.\n\nIf you want to hide the label, pass the 'visuallyHidden' prop to the FormControl.Label component.`);
	if (isChoiceInput) {}
	const isLabelHidden = (_slots$label = slots.label) === null || _slots$label === void 0 ? void 0 : _slots$label.props.visuallyHidden;
	const t4 = /* @__PURE__ */ React.isValidElement(InputComponent) ? /* @__PURE__ */ React.cloneElement(InputComponent, {
		id,
		disabled,
		required: required && !isRadioInput,
		"aria-describedby": captionId
	}) : null;
	let t5;
	if ($[4] !== childrenWithoutSlots) {
		t5 = childrenWithoutSlots.filter(_temp2);
		$[4] = childrenWithoutSlots;
		$[5] = t5;
	} else t5 = $[5];
	let t6;
	if ($[6] !== t4 || $[7] !== t5) {
		t6 = /* @__PURE__ */ jsxs("div", {
			className: classes.ControlChoiceInputs,
			children: [t4, t5]
		});
		$[6] = t4;
		$[7] = t5;
		$[8] = t6;
	} else t6 = $[8];
	let t7;
	if ($[9] !== disabled || $[10] !== slots.caption || $[11] !== slots.leadingVisual) {
		t7 = slots.leadingVisual ? /* @__PURE__ */ jsx("div", {
			className: classes.LeadingVisual,
			"data-disabled": disabled ? "" : void 0,
			"data-has-caption": slots.caption ? "" : void 0,
			children: slots.leadingVisual
		}) : null;
		$[9] = disabled;
		$[10] = slots.caption;
		$[11] = slots.leadingVisual;
		$[12] = t7;
	} else t7 = $[12];
	let t8;
	if ($[13] !== slots.caption || $[14] !== slots.label) {
		t8 = /* @__PURE__ */ jsxs("div", {
			className: classes.LabelContainer,
			children: [slots.label, slots.caption]
		});
		$[13] = slots.caption;
		$[14] = slots.label;
		$[15] = t8;
	} else t8 = $[15];
	let t9;
	if ($[16] !== t6 || $[17] !== t7 || $[18] !== t8) {
		t9 = /* @__PURE__ */ jsxs(Fragment$1, { children: [
			t6,
			t7,
			t8
		] });
		$[16] = t6;
		$[17] = t7;
		$[18] = t8;
		$[19] = t9;
	} else t9 = $[19];
	const InputChildren = t9;
	const T0 = FormControlContextProvider;
	const t10 = !isSelectPanelInput;
	let t11;
	if ($[20] !== captionId || $[21] !== disabled || $[22] !== id || $[23] !== labelId || $[24] !== required || $[25] !== t10 || $[26] !== validationMessageId) {
		t11 = {
			captionId,
			disabled,
			id,
			required,
			validationMessageId,
			isReferenced: t10,
			labelId
		};
		$[20] = captionId;
		$[21] = disabled;
		$[22] = id;
		$[23] = labelId;
		$[24] = required;
		$[25] = t10;
		$[26] = validationMessageId;
		$[27] = t11;
	} else t11 = $[27];
	const t12 = isChoiceInput || layout === "horizontal" ? /* @__PURE__ */ jsx("div", {
		ref,
		"data-has-leading-visual": slots.leadingVisual ? "" : void 0,
		className: clsx(className, classes.ControlHorizontalLayout),
		style,
		children: InputChildren
	}) : /* @__PURE__ */ jsxs("div", {
		ref,
		"data-has-label": !isLabelHidden ? "" : void 0,
		className: clsx(className, classes.ControlVerticalLayout),
		style,
		children: [
			slots.label,
			/* @__PURE__ */ React.isValidElement(InputComponent) && /* @__PURE__ */ React.cloneElement(InputComponent, Object.assign({
				id,
				required,
				disabled,
				validationStatus,
				"aria-describedby": [validationMessageId, captionId].filter(Boolean).join(" ")
			}, InputComponent.props)),
			childrenWithoutSlots.filter((child_2) => /* @__PURE__ */ React.isValidElement(child_2) && !expectedInputComponents.some((inputComponent_1) => child_2.type === inputComponent_1 || isSlot(child_2, inputComponent_1))),
			slots.validation ? /* @__PURE__ */ jsx(ValidationAnimationContainer, {
				show: true,
				children: slots.validation
			}) : null,
			slots.caption
		]
	});
	let t13;
	if ($[28] !== T0 || $[29] !== t11 || $[30] !== t12) {
		t13 = /* @__PURE__ */ jsx(T0, {
			value: t11,
			children: t12
		});
		$[28] = T0;
		$[29] = t11;
		$[30] = t12;
		$[31] = t13;
	} else t13 = $[31];
	return t13;
});
var FormControl$1 = Object.assign(FormControl, {
	__SLOT__: Symbol("FormControl"),
	Caption: FormControlCaption,
	Label: FormControlLabel,
	LeadingVisual: FormControlLeadingVisual,
	Validation: FormControlValidation
});
function _temp2(child_1) {
	return /* @__PURE__ */ React.isValidElement(child_1) && ![Checkbox, Radio].some((inputComponent_0) => child_1.type === inputComponent_0 || isSlot(child_1, inputComponent_0));
}
export { Token as a, Textarea as i, InputLabel as n, Select$1 as r, FormControl$1 as t };
