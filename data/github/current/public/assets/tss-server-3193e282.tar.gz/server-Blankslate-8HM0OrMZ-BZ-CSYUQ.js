import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var BlankslateContext = /* @__PURE__ */ createContext(null);
function useBlankslate() {
	const context = useContext(BlankslateContext);
	if (!context) throw new Error("useBlankslate must be used within a BlankslateProvider");
	return context;
}
var Provider = BlankslateContext.Provider;
var classes = {
	"Container": "prc-Blankslate-Container-Vr9Ce",
	"Blankslate": "prc-Blankslate-Blankslate-Eihy3",
	"Description": "prc-Blankslate-Description-nqiRV",
	"Heading": "prc-Blankslate-Heading-tVZsq",
	"Visual": "prc-Blankslate-Visual-10aPl",
	"Action": "prc-Blankslate-Action-RsgHG"
};
function Blankslate(t0) {
	const $ = c(25);
	let border;
	let children;
	let className;
	let narrow;
	let rest;
	let spacious;
	let t1;
	if ($[0] !== t0) {
		({border, children, narrow, spacious, className, size: t1, ...rest} = t0);
		$[0] = t0;
		$[1] = border;
		$[2] = children;
		$[3] = className;
		$[4] = narrow;
		$[5] = rest;
		$[6] = spacious;
		$[7] = t1;
	} else {
		border = $[1];
		children = $[2];
		className = $[3];
		narrow = $[4];
		rest = $[5];
		spacious = $[6];
		t1 = $[7];
	}
	const size = t1 === void 0 ? "medium" : t1;
	let t2;
	if ($[8] !== size) {
		t2 = { size };
		$[8] = size;
		$[9] = t2;
	} else t2 = $[9];
	const value = t2;
	let t3;
	if ($[10] !== className) {
		t3 = clsx(classes.Blankslate, className);
		$[10] = className;
		$[11] = t3;
	} else t3 = $[11];
	const t4 = border ? "" : void 0;
	const t5 = narrow ? "" : void 0;
	const t6 = spacious ? "" : void 0;
	let t7;
	if ($[12] !== children || $[13] !== size || $[14] !== t3 || $[15] !== t4 || $[16] !== t5 || $[17] !== t6) {
		t7 = /* @__PURE__ */ jsx("div", {
			className: t3,
			"data-border": t4,
			"data-narrow": t5,
			"data-spacious": t6,
			"data-size": size,
			children
		});
		$[12] = children;
		$[13] = size;
		$[14] = t3;
		$[15] = t4;
		$[16] = t5;
		$[17] = t6;
		$[18] = t7;
	} else t7 = $[18];
	let t8;
	if ($[19] !== rest || $[20] !== t7) {
		t8 = /* @__PURE__ */ jsx("div", {
			...rest,
			className: classes.Container,
			children: t7
		});
		$[19] = rest;
		$[20] = t7;
		$[21] = t8;
	} else t8 = $[21];
	let t9;
	if ($[22] !== t8 || $[23] !== value) {
		t9 = /* @__PURE__ */ jsx(Provider, {
			value,
			children: t8
		});
		$[22] = t8;
		$[23] = value;
		$[24] = t9;
	} else t9 = $[24];
	return t9;
}
function Visual(t0) {
	const $ = c(10);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx("Blankslate-Visual", classes.Visual, className);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== children || $[7] !== rest || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsx("span", {
			...rest,
			className: t1,
			children
		});
		$[6] = children;
		$[7] = rest;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
function Heading(t0) {
	const $ = c(12);
	let children;
	let className;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({as: t1, children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = t1;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		t1 = $[4];
	}
	const Component = t1 === void 0 ? "h2" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = clsx("Blankslate-Heading", classes.Heading, className);
		$[5] = className;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== Component || $[8] !== children || $[9] !== rest || $[10] !== t2) {
		t3 = /* @__PURE__ */ jsx(Component, {
			...rest,
			className: t2,
			children
		});
		$[7] = Component;
		$[8] = children;
		$[9] = rest;
		$[10] = t2;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
function Description(t0) {
	const $ = c(10);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx("Blankslate-Description", classes.Description, className);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== children || $[7] !== rest || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsx("p", {
			...rest,
			className: t1,
			children
		});
		$[6] = children;
		$[7] = rest;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
function PrimaryAction(t0) {
	const $ = c(11);
	let children;
	let href;
	let props;
	if ($[0] !== t0) {
		({children, href, ...props} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = href;
		$[3] = props;
	} else {
		children = $[1];
		href = $[2];
		props = $[3];
	}
	const { size } = useBlankslate();
	let t1;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("Blankslate-Action", classes.Action);
		$[4] = t1;
	} else t1 = $[4];
	const t2 = href ? "a" : "button";
	const t3 = size === "small" ? "small" : void 0;
	let t4;
	if ($[5] !== children || $[6] !== href || $[7] !== props || $[8] !== t2 || $[9] !== t3) {
		t4 = /* @__PURE__ */ jsx("div", {
			className: t1,
			children: /* @__PURE__ */ jsx(ButtonComponent, {
				...props,
				as: t2,
				href,
				variant: "primary",
				size: t3,
				children
			})
		});
		$[5] = children;
		$[6] = href;
		$[7] = props;
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
function SecondaryAction(t0) {
	const $ = c(4);
	const { children, href } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("Blankslate-Action", classes.Action);
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== children || $[2] !== href) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: t1,
			children: /* @__PURE__ */ jsx(Link, {
				href,
				children
			})
		});
		$[1] = children;
		$[2] = href;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
var BlankslateContainer = Object.assign(Blankslate, {
	Visual,
	Heading,
	Description,
	PrimaryAction,
	SecondaryAction
});
export { BlankslateContainer as t };
