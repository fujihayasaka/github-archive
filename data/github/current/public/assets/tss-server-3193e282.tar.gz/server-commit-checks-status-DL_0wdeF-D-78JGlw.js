import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { Ai as XCircleFillIcon, D as CheckCircleIcon, E as CheckCircleFillIcon, Gr as SquareFillIcon, Ir as SkipIcon, Mi as XIcon, O as CheckIcon, Qr as StopIcon, V as ClockIcon, _i as Truncate, bn as Link, fi as Tooltip, ji as XCircleIcon, lr as QuestionIcon, n as ActionList, o as AlertIcon, pi as Tooltip$1, pn as IssueReopenedIcon, pt as DotFillIcon, vr as RepoPushIcon, z as CircleIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { c as Link$1, n as ButtonComponent, o as IconButton, t as Box, u as Text, v as merge } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { T as commitsByAuthor, w as commitStatusDetailsPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as AvatarStack } from "./server-AvatarStack-DOkoT87C-BbROVIWO.js";
import { t as Octicon } from "./server-deprecated-NWt92s1C-CJVCDSxf.js";
import { t as ProfileReference } from "./server-ProfileReference-BiGysK1d-VyvZmlrw.js";
import { Fragment, createContext, use, useCallback, useId, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
function isBotOrApp(author) {
	const isApp = author.path?.startsWith("/apps/") ?? false;
	if (isApp && author.login?.toLowerCase() === "copilot-swe-agent") return false;
	return isApp;
}
function AuthorTooltip({ renderTooltip, author, children }) {
	if (renderTooltip === false) return /* @__PURE__ */ jsx(Fragment$1, { children });
	return /* @__PURE__ */ jsx(Tooltip$1, {
		text: `commits by ${author.login}`,
		direction: "se",
		children
	});
}
AuthorTooltip.displayName = "AuthorTooltip";
var defaultSettings = {
	fontWeight: "bold",
	fontColor: "fg.default",
	includeTooltip: false,
	avatarSize: void 0
};
var AuthorSettingsContext = createContext(defaultSettings);
AuthorSettingsContext.displayName = "AuthorSettingsContext";
function AuthorSettingsProvider({ authorSettings, children }) {
	return /* @__PURE__ */ jsx(AuthorSettingsContext, {
		value: merge(defaultSettings, authorSettings ?? {}),
		children
	});
}
AuthorSettingsProvider.displayName = "AuthorSettingsProvider";
function useAuthorSettings() {
	return use(AuthorSettingsContext) || defaultSettings;
}
var AuthorDisplayName_module_default = {
	Text: "AuthorDisplayName-module_Nj5xcq_Text",
	truncate: "AuthorDisplayName-module_Nj5xcq_truncate"
};
/**
* Renders the display name of an author. This happens when the author does not have a login.
*/
function AuthorDisplayName({ displayName, authorSettings }) {
	return /* @__PURE__ */ jsx(Truncate, {
		title: displayName,
		className: AuthorDisplayName_module_default.truncate,
		inline: true,
		children: /* @__PURE__ */ jsx(Text, {
			sx: {
				fontWeight: authorSettings.fontWeight,
				color: authorSettings.fontColor
			},
			className: AuthorDisplayName_module_default.Text,
			children: displayName
		})
	});
}
AuthorDisplayName.displayName = "AuthorDisplayName";
var AuthorAvatar_module_default = {
	AuthorAvatarContainer: "AuthorAvatar-module_NDYNrG_AuthorAvatarContainer",
	authorAvatarImage: "AuthorAvatar-module_NDYNrG_authorAvatarImage",
	authorHoverableLink: "AuthorAvatar-module_NDYNrG_authorHoverableLink"
};
/**
* Renders the author of a commit.
*/
function AuthorAvatar(t0) {
	const $ = c(7);
	const { author, repo, sx } = t0;
	const authorSettings = useAuthorSettings();
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	let t2;
	if ($[0] !== author || $[1] !== authorSettings || $[2] !== getHovercardAttributesForType || $[3] !== repo || $[4] !== sx) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const hovercardAttrs = getHovercardAttributesForType("user", { login: author?.login ?? "" });
			if (!author) {
				t2 = null;
				break bb0;
			}
			const avatar = jsx(GitHubAvatar, {
				"aria-label": `${author.login || "author"}`,
				src: author.avatarUrl,
				alt: `${author.login || "author"}`,
				size: authorSettings.avatarSize,
				square: isBotOrApp(author),
				className: AuthorAvatar_module_default.authorAvatarImage
			});
			t1 = jsxs(Box, {
				sx: { ...sx },
				"data-testid": "author-avatar",
				className: AuthorAvatar_module_default.AuthorAvatarContainer,
				children: [author.path ? jsx(Link$1, {
					href: author.path,
					"data-testid": "avatar-icon-link",
					...author.login ? hovercardAttrs : {},
					children: avatar
				}) : avatar, author.login ? jsx(AuthorTooltip, {
					author,
					renderTooltip: authorSettings.includeTooltip,
					children: jsx(Link$1, {
						muted: true,
						href: commitsByAuthor({
							repo,
							author: author.login
						}),
						"aria-label": `commits by ${author.login}`,
						...hovercardAttrs,
						sx: {
							fontWeight: authorSettings.fontWeight,
							color: authorSettings.fontColor,
							"&:hover": { color: authorSettings.fontColor }
						},
						className: AuthorAvatar_module_default.authorHoverableLink,
						children: jsx(ProfileReference, {
							login: author.login,
							profileName: author.profileName,
							isAgent: false
						})
					})
				}) : jsx(AuthorDisplayName, {
					displayName: author.displayName,
					authorSettings
				})]
			});
		}
		$[0] = author;
		$[1] = authorSettings;
		$[2] = getHovercardAttributesForType;
		$[3] = repo;
		$[4] = sx;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
AuthorAvatar.displayName = "AuthorAvatar";
var AuthorsDialog_module_default = {
	ActionList: "AuthorsDialog-module_rmfF7a_ActionList",
	ActionList_LinkItem: "AuthorsDialog-module_rmfF7a_ActionList_LinkItem",
	GitHubAvatar: "AuthorsDialog-module_rmfF7a_GitHubAvatar",
	PrimerLink: "AuthorsDialog-module_rmfF7a_PrimerLink"
};
function AuthorsDialog({ authors, repo }) {
	const authorCount = authors.length;
	const [isDialogOpen, setDialogOpen] = useState(false);
	const linkRef = useRef(null);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(Link, {
		as: "button",
		"aria-label": `Show ${authorCount} authors`,
		"data-testid": "authors-dialog-anchor",
		onClick: () => {
			setDialogOpen(true);
		},
		ref: linkRef,
		muted: true,
		className: AuthorsDialog_module_default.PrimerLink,
		children: [
			authorCount,
			" ",
			"people"
		]
	}), isDialogOpen && /* @__PURE__ */ jsx(Dialog, {
		title: `${authorCount} authors`,
		onClose: () => {
			setDialogOpen(false);
			setTimeout(() => linkRef.current?.focus(), 25);
		},
		width: "medium",
		height: authorCount >= 12 ? "small" : "auto",
		renderBody: () => {
			return /* @__PURE__ */ jsx(ActionList, {
				"data-testid": "contributor-dialog-list",
				className: AuthorsDialog_module_default.ActionList,
				children: authors.map((author, index) => /* @__PURE__ */ jsx(AuthorRow, {
					author,
					repo
				}, `${author.login}_${index}`))
			});
		}
	})] });
}
AuthorsDialog.displayName = "AuthorsDialog";
function AuthorRow({ author, repo }) {
	return /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		"data-testid": "contributor-dialog-row",
		href: commitsByAuthor({
			repo,
			author: author.login ?? ""
		}),
		className: AuthorsDialog_module_default.ActionList_LinkItem,
		children: [/* @__PURE__ */ jsx(GitHubAvatar, {
			src: author.avatarUrl,
			alt: author.login ?? author.displayName,
			"aria-hidden": "true",
			square: isBotOrApp(author),
			className: AuthorsDialog_module_default.GitHubAvatar
		}), /* @__PURE__ */ jsx(Truncate, {
			inline: true,
			title: author.login ?? author.displayName ?? "",
			children: author.login ?? author.displayName
		})]
	});
}
AuthorRow.displayName = "AuthorRow";
var maxAvatarCount = 5;
function AuthorAvatarItem(t0) {
	const { author, avatarSize, className, style, ...restProps } = t0;
	const hovercardAttrs = useGetHovercardAttributesForType()("user", { login: author.login ?? "" });
	return jsx(GitHubAvatar, {
		"data-testid": "commit-stack-avatar",
		src: author.avatarUrl,
		alt: author.login ?? author.displayName,
		...hovercardAttrs,
		square: isBotOrApp(author),
		size: avatarSize,
		className,
		style,
		...restProps
	});
}
AuthorAvatarItem.displayName = "AuthorAvatarItem";
function OnBehalfOfAvatar(t0) {
	const { onBehalfOf, avatarSize, className, style, ...restProps } = t0;
	const hovercardAttrs = useGetHovercardAttributesForType()("organization", { login: onBehalfOf.login ?? "" });
	return jsx(GitHubAvatar, {
		"data-testid": "commit-stack-avatar",
		src: onBehalfOf.avatarUrl,
		alt: onBehalfOf.login ?? onBehalfOf.displayName,
		...hovercardAttrs,
		square: true,
		size: avatarSize,
		className,
		style,
		...restProps
	});
}
OnBehalfOfAvatar.displayName = "OnBehalfOfAvatar";
function CommitAuthorStack(t0) {
	const $ = c(6);
	const { authors, onBehalfOf } = t0;
	const authorSettings = useAuthorSettings();
	let t1;
	if ($[0] !== authorSettings || $[1] !== authors || $[2] !== onBehalfOf) {
		let t2;
		if ($[4] !== authorSettings) {
			t2 = (author, index) => jsx(AuthorAvatarItem, {
				author,
				avatarSize: authorSettings.avatarSize
			}, `${author.login}_${index}`);
			$[4] = authorSettings;
			$[5] = t2;
		} else t2 = $[5];
		t1 = jsxs(AvatarStack, { children: [authors.slice(0, maxAvatarCount).map(t2), onBehalfOf && jsx(OnBehalfOfAvatar, {
			onBehalfOf,
			avatarSize: authorSettings.avatarSize
		}, `${onBehalfOf.login}_on_behalf_of`)] });
		$[0] = authorSettings;
		$[1] = authors;
		$[2] = onBehalfOf;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
CommitAuthorStack.displayName = "CommitAuthorStack";
var AuthorLink_module_default = {
	authorLinkContainer: "AuthorLink-module_O56hPq_authorLinkContainer",
	authorNameLink: "AuthorLink-module_O56hPq_authorNameLink"
};
/**
* Renders the author of a commit.
*/
function AuthorLink$1(t0) {
	const $ = c(7);
	const { author, repo, className } = t0;
	const authorSettings = useAuthorSettings();
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	let t2;
	if ($[0] !== author || $[1] !== authorSettings || $[2] !== className || $[3] !== getHovercardAttributesForType || $[4] !== repo) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const hovercardAttrs = getHovercardAttributesForType("user", { login: author?.login ?? "" });
			if (!author) {
				t2 = null;
				break bb0;
			}
			t1 = jsx("div", {
				"data-testid": "author-link",
				className: clsx(AuthorLink_module_default.authorLinkContainer, className),
				children: author.login ? jsx(AuthorTooltip, {
					author,
					renderTooltip: authorSettings.includeTooltip,
					children: jsx(Link$1, {
						muted: true,
						href: commitsByAuthor({
							repo,
							author: author.login
						}),
						"aria-label": `commits by ${author.login}`,
						...hovercardAttrs,
						sx: {
							fontWeight: authorSettings.fontWeight,
							color: authorSettings.fontColor,
							"&:hover": { color: authorSettings.fontColor }
						},
						className: AuthorLink_module_default.authorNameLink,
						children: jsx(ProfileReference, {
							login: author.login,
							profileName: author.profileName,
							isAgent: false
						})
					})
				}) : jsx(AuthorDisplayName, {
					displayName: author.displayName,
					authorSettings
				})
			});
		}
		$[0] = author;
		$[1] = authorSettings;
		$[2] = className;
		$[3] = getHovercardAttributesForType;
		$[4] = repo;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
AuthorLink$1.displayName = "AuthorLink";
var OrgLink_module_default = { orgLink: "OrgLink-module_hNIplq_orgLink" };
/**
* Renders the author of a commit.
*/
function OrgLink(t0) {
	const $ = c(5);
	const { org, className } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	let t2;
	if ($[0] !== className || $[1] !== getHovercardAttributesForType || $[2] !== org) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const hovercardAttrs = getHovercardAttributesForType("organization", { login: org?.login ?? "" });
			if (!org) {
				t2 = null;
				break bb0;
			}
			t1 = jsx("div", {
				className: clsx("d-flex flex-row flex-items-center", className),
				children: jsx(Link, {
					muted: true,
					href: org.path,
					"aria-label": `${org.login}'s org home page`,
					...hovercardAttrs,
					className: OrgLink_module_default.orgLink,
					children: org.login
				})
			});
		}
		$[0] = className;
		$[1] = getHovercardAttributesForType;
		$[2] = org;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
OrgLink.displayName = "OrgLink";
var CommitAttribution_module_default = {
	AuthorLink: "CommitAttribution-module__Th03W_AuthorLink",
	CommitAttributionContainer: "CommitAttribution-module__Th03W_CommitAttributionContainer"
};
function SingleAuthor({ author, repo }) {
	return /* @__PURE__ */ jsx(AuthorAvatar, {
		author,
		repo
	});
}
SingleAuthor.displayName = "SingleAuthor";
function AuthorByline({ author, committer, committerAttribution, onBehalfOf, repo }) {
	const authors = [author];
	if (committer && committerAttribution) authors.push(committer);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CommitAuthorStack, {
		authors,
		onBehalfOf
	}), /* @__PURE__ */ jsx(AuthorLink$1, {
		author,
		repo,
		className: CommitAttribution_module_default.AuthorLink
	})] });
}
AuthorByline.displayName = "AuthorByline";
function TwoAuthors({ authors, onBehalfOf, repo }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CommitAuthorStack, {
		authors,
		onBehalfOf
	}), authors.map((author, index) => /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(AuthorLink$1, {
		author,
		repo,
		className: CommitAttribution_module_default.AuthorLink
	}), index !== authors.length - 1 && /* @__PURE__ */ jsx("span", {
		className: "pl-1",
		children: "and"
	})] }, `${author.login}_${index}`))] });
}
TwoAuthors.displayName = "TwoAuthors";
function MultipleAuthors({ authors, onBehalfOf, repo }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CommitAuthorStack, {
		authors,
		onBehalfOf
	}), /* @__PURE__ */ jsx(AuthorsDialog, {
		authors,
		repo
	})] });
}
MultipleAuthors.displayName = "MultipleAuthors";
function CommitAttribution({ authors, committer, committerAttribution, onBehalfOf, repo, children, includeVerbs = true, authorSettings, textVariant = "default" }) {
	const singleAuthor = authors.length === 1 && !committerAttribution && !onBehalfOf;
	const authorAndCommitter = authors.length === 1 && (committerAttribution || onBehalfOf);
	const inlineAuthorNames = authors.length === 2 && !committerAttribution;
	const multipleAuthors = !singleAuthor && !authorAndCommitter && !inlineAuthorNames;
	const firstAuthor = authors[0];
	const verbClass = includeVerbs ? "pl-1" : "";
	return /* @__PURE__ */ jsx("div", {
		className: clsx(textVariant === "muted" ? "color-fg-muted" : "", CommitAttribution_module_default.CommitAttributionContainer),
		children: /* @__PURE__ */ jsxs(AuthorSettingsProvider, {
			authorSettings,
			children: [
				singleAuthor && firstAuthor && /* @__PURE__ */ jsx(SingleAuthor, {
					author: firstAuthor,
					repo
				}),
				authorAndCommitter && firstAuthor && /* @__PURE__ */ jsx(AuthorByline, {
					author: firstAuthor,
					committer,
					committerAttribution,
					onBehalfOf,
					repo
				}),
				inlineAuthorNames && /* @__PURE__ */ jsx(TwoAuthors, {
					authors,
					onBehalfOf,
					repo
				}),
				multipleAuthors && /* @__PURE__ */ jsx(MultipleAuthors, {
					authors,
					onBehalfOf,
					repo
				}),
				/* @__PURE__ */ jsx(AuthoredOrCommitted, {
					committer,
					committerAttribution: committerAttribution || false,
					includeVerbs,
					repo,
					verbClass
				}),
				onBehalfOf && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
					className: "pl-1",
					children: "on behalf of"
				}), /* @__PURE__ */ jsx(OrgLink, {
					org: onBehalfOf,
					className: "pl-1"
				})] }),
				children
			]
		})
	});
}
CommitAttribution.displayName = "CommitAttribution";
function AuthoredOrCommitted({ committer, committerAttribution, includeVerbs, repo, verbClass }) {
	if (committer && committer.isGitHub) return /* @__PURE__ */ jsx("span", {
		className: verbClass,
		children: includeVerbs && "authored"
	});
	else if (!committerAttribution) return /* @__PURE__ */ jsx("span", {
		className: verbClass,
		children: includeVerbs && "committed"
	});
	else return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("span", {
			className: "pl-1",
			children: includeVerbs ? "authored and" : "and"
		}),
		/* @__PURE__ */ jsx(AuthorLink$1, {
			author: committer,
			repo,
			className: CommitAttribution_module_default.AuthorLink
		}),
		/* @__PURE__ */ jsx("span", {
			className: verbClass,
			children: includeVerbs && "committed"
		})
	] });
}
AuthoredOrCommitted.displayName = "AuthoredOrCommitted";
function PushAttribution({ pusher, repo, children, textVariant = "default" }) {
	if (!pusher) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(textVariant === "muted" ? "color-fg-muted" : "", CommitAttribution_module_default.CommitAttributionContainer),
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "pl-1 pr-1",
				children: /* @__PURE__ */ jsx(RepoPushIcon, {
					className: "mr-1",
					size: "small"
				})
			}),
			/* @__PURE__ */ jsx(SingleAuthor, {
				author: pusher,
				repo
			}),
			/* @__PURE__ */ jsx("span", {
				className: "pl-1",
				children: "pushed"
			}),
			children
		]
	});
}
PushAttribution.displayName = "PushAttribution";
var CheckRunItem_module_default = {
	Box: "CheckRunItem-module_rX83TW_Box",
	Box_1: "CheckRunItem-module_rX83TW_Box_1",
	Box_2: "CheckRunItem-module_rX83TW_Box_2",
	Link: "CheckRunItem-module_rX83TW_Link",
	Link_1: "CheckRunItem-module_rX83TW_Link_1",
	Text: "CheckRunItem-module_rX83TW_Text",
	Text_1: "CheckRunItem-module_rX83TW_Text_1",
	Text_2: "CheckRunItem-module_rX83TW_Text_2"
};
function CheckRunItem({ checkRun }) {
	const iconJsx = getOcticonFromIconString(checkRun.icon);
	const inProgress = checkRun.state === "in_progress";
	return /* @__PURE__ */ jsxs("li", {
		"data-testid": "check-run-item",
		className: CheckRunItem_module_default.Box,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: CheckRunItem_module_default.Box_1,
				children: [inProgress ? getInProgressSpinner() : /* @__PURE__ */ jsx(Fragment$1, { children: iconJsx }), /* @__PURE__ */ jsx(Tooltip$1, {
					text: checkRun.avatarDescription,
					direction: "e",
					children: /* @__PURE__ */ jsx(Link, {
						href: checkRun.avatarUrl,
						"aria-label": "Avatar",
						className: CheckRunItem_module_default.Link,
						children: /* @__PURE__ */ jsx(GitHubAvatar, {
							square: true,
							src: checkRun.avatarLogo,
							style: { backgroundColor: checkRun.avatarBackgroundColor }
						})
					})
				})]
			}),
			/* @__PURE__ */ jsxs("span", {
				className: CheckRunItem_module_default.Text,
				children: [
					/* @__PURE__ */ jsxs("span", {
						className: CheckRunItem_module_default.Text_1,
						children: [checkRun.name, " "]
					}),
					checkRun.pending ? /* @__PURE__ */ jsx("span", {
						className: CheckRunItem_module_default.Text_2,
						children: checkRun.additionalContext
					}) : checkRun.additionalContext,
					checkRun.description && /* @__PURE__ */ jsxs("span", { children: [
						" ",
						"- ",
						checkRun.pending ? /* @__PURE__ */ jsx("span", {
							className: CheckRunItem_module_default.Text_2,
							children: checkRun.description
						}) : checkRun.description
					] })
				]
			}),
			/* @__PURE__ */ jsx(Link, {
				href: checkRun.targetUrl,
				className: CheckRunItem_module_default.Link_1,
				children: "Details"
			})
		]
	});
}
CheckRunItem.displayName = "CheckRunItem";
function getOcticonFromIconString(icon) {
	switch (icon) {
		case "check": return /* @__PURE__ */ jsx(CheckIcon, { className: "fgColor-success my-0 mx-2 flex-self-center" });
		case "dot-fill": return /* @__PURE__ */ jsx(DotFillIcon, { className: "fgColor-attention my-0 mx-2 flex-self-center" });
		case "stop": return /* @__PURE__ */ jsx(StopIcon, { className: "fgColor-muted my-0 mx-2 flex-self-center" });
		case "issue-reopened": return /* @__PURE__ */ jsx(IssueReopenedIcon, { className: "fgColor-muted my-0 mx-2 flex-self-center" });
		case "clock": return /* @__PURE__ */ jsx(ClockIcon, { className: "fgColor-attention my-0 mx-2 flex-self-center" });
		case "square-fill": return /* @__PURE__ */ jsx(SquareFillIcon, { className: "fgColor-default my-0 mx-2 flex-self-center" });
		case "skip": return /* @__PURE__ */ jsx(SkipIcon, { className: "fgColor-muted my-0 mx-2 flex-self-center" });
		case "alert": return /* @__PURE__ */ jsx(AlertIcon, { className: "fgColor-danger my-0 mx-2 flex-self-center" });
		default: return /* @__PURE__ */ jsx(XIcon, { className: "fgColor-danger my-0 mx-2 flex-self-center" });
	}
}
function getInProgressSpinner() {
	return /* @__PURE__ */ jsx("div", {
		className: CheckRunItem_module_default.Box_2,
		children: /* @__PURE__ */ jsxs("svg", {
			fill: "none",
			viewBox: "0 0 16 16",
			className: "anim-rotate",
			"aria-hidden": "true",
			role: "img",
			children: [
				/* @__PURE__ */ jsx("path", {
					opacity: ".5",
					d: "M8 15A7 7 0 108 1a7 7 0 000 14v0z",
					stroke: "var(--fgColor-attention)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M15 8a7 7 0 01-7 7",
					stroke: "var(--fgColor-attention)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ jsx("path", {
					d: "M8 12a4 4 0 100-8 4 4 0 000 8z",
					fill: "var(--fgColor-attention)"
				})
			]
		})
	});
}
var ChecksStatusBadgeFooter_module_default = { Box: "ChecksStatusBadgeFooter-module_Ghy3ia_Box" };
function ChecksStatusBadgeFooter({ checkRuns }) {
	return /* @__PURE__ */ jsx("ul", {
		className: ChecksStatusBadgeFooter_module_default.Box,
		children: checkRuns.map((checkRun, i) => /* @__PURE__ */ jsx(CheckRunItem, { checkRun }, i))
	});
}
ChecksStatusBadgeFooter.displayName = "ChecksStatusBadgeFooter";
var ChecksStatusBadgeHeader_module_default = {
	Text: "ChecksStatusBadgeHeader-module_WORJvG_Text",
	Text_1: "ChecksStatusBadgeHeader-module_WORJvG_Text_1",
	Text_2: "ChecksStatusBadgeHeader-module_WORJvG_Text_2"
};
function HeaderState({ checksHeaderState }) {
	switch (checksHeaderState) {
		case "SUCCEEDED": return /* @__PURE__ */ jsx("span", {
			className: ChecksStatusBadgeHeader_module_default.Text,
			children: "All checks have passed"
		});
		case "FAILED": return /* @__PURE__ */ jsx("span", {
			className: ChecksStatusBadgeHeader_module_default.Text_1,
			children: "All checks have failed"
		});
		case "PENDING": return /* @__PURE__ */ jsx("span", {
			className: ChecksStatusBadgeHeader_module_default.Text_2,
			children: "Some checks haven’t completed yet"
		});
		default: return /* @__PURE__ */ jsx("span", {
			className: ChecksStatusBadgeHeader_module_default.Text_1,
			children: "Some checks were not successful"
		});
	}
}
HeaderState.displayName = "HeaderState";
var CheckStatusDialog_module_default = {
	Box: "CheckStatusDialog-module_WCJldq_Box",
	Dialog: "CheckStatusDialog-module_WCJldq_Dialog",
	Dialog_Body: "CheckStatusDialog-module_WCJldq_Dialog_Body"
};
function CheckStatusDialog(props) {
	const { combinedStatus, isOpen, onDismiss } = props;
	const title = combinedStatus ? /* @__PURE__ */ jsx(HeaderState, { checksHeaderState: combinedStatus.checksHeaderState }) : "Loading...";
	return isOpen ? /* @__PURE__ */ jsx(Dialog, {
		onClose: onDismiss,
		title,
		subtitle: combinedStatus ? combinedStatus.checksStatusSummary : void 0,
		width: "xlarge",
		renderBody: () => /* @__PURE__ */ jsx(Dialog.Body, {
			className: CheckStatusDialog_module_default.Dialog_Body,
			children: combinedStatus ? /* @__PURE__ */ jsx(ChecksStatusBadgeFooter, { checkRuns: combinedStatus.checkRuns }) : /* @__PURE__ */ jsx("div", {
				className: CheckStatusDialog_module_default.Box,
				children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
			})
		}),
		className: CheckStatusDialog_module_default.Dialog
	}) : null;
}
CheckStatusDialog.displayName = "CheckStatusDialog";
var ChecksStatusBadge_module_default = {
	ChecksStatusBadgeButton: "ChecksStatusBadge-module_LYaQWW_ChecksStatusBadgeButton",
	ChecksStatusBadgeIconButton: "ChecksStatusBadge-module_LYaQWW_ChecksStatusBadgeIconButton"
};
var ICON_STYLE = {
	success: {
		circled: CheckCircleIcon,
		filled: CheckCircleFillIcon,
		default: CheckIcon,
		color: "var(--bgColor-success-emphasis, var(--color-success-emphasis))"
	},
	pending: {
		circled: CircleIcon,
		filled: DotFillIcon,
		default: DotFillIcon,
		color: "var(--bgColor-attention-emphasis, var(--color-scale-yellow-4))"
	},
	failure: {
		circled: XCircleIcon,
		filled: XCircleFillIcon,
		default: XIcon,
		color: "var(--bgColor-danger-emphasis, var(--color-scale-red-4))"
	},
	error: {
		circled: QuestionIcon,
		filled: QuestionIcon,
		default: QuestionIcon,
		color: "var(--fgColor-muted, var(--color-canvas-subtle))"
	}
};
function IconOnlyStatus(t0) {
	const $ = c(7);
	const { className, descriptionText, icon, iconColor, tooltipText } = t0;
	const tooltipId = useId();
	let t1;
	if ($[0] !== className || $[1] !== descriptionText || $[2] !== icon || $[3] !== iconColor || $[4] !== tooltipId || $[5] !== tooltipText) {
		let iconElement = jsx(Octicon, {
			"aria-labelledby": tooltipText ? tooltipId : void 0,
			icon,
			"aria-label": tooltipText ? void 0 : descriptionText ? descriptionText : "See all checks",
			sx: { color: iconColor }
		});
		if (tooltipText) iconElement = jsx(Tooltip, {
			id: tooltipId,
			"aria-label": tooltipText,
			direction: "e",
			children: iconElement
		});
		t1 = jsxs("span", {
			className: clsx(className, "d-flex flex-items-center gap-1"),
			"data-testid": "checks-status-badge-icon-only",
			children: [iconElement, descriptionText && jsxs("span", { children: [" ", descriptionText] })]
		});
		$[0] = className;
		$[1] = descriptionText;
		$[2] = icon;
		$[3] = iconColor;
		$[4] = tooltipId;
		$[5] = tooltipText;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
IconOnlyStatus.displayName = "IconOnlyStatus";
function ChecksStatusBadge(props) {
	const { statusRollup, combinedStatus, variant = "default", disablePopover, buttonClassName, buttonSx, size = "medium", descriptionText = "", onWillOpenPopup: fetchData } = props;
	const [isOpen, setIsOpen] = useState(false);
	const checkButtonRef = useRef(null);
	const iconStyle = ICON_STYLE[statusRollup];
	const { icon, iconColor } = {
		icon: iconStyle?.[variant] || ICON_STYLE.error[variant],
		iconColor: iconStyle?.color || ICON_STYLE.error.color
	};
	if (statusRollup === "error") return /* @__PURE__ */ jsx(IconOnlyStatus, {
		className: !disablePopover ? "p-1" : void 0,
		descriptionText: "?/?",
		icon,
		iconColor,
		tooltipText: "There was an error retrieving checks status"
	});
	if (disablePopover) return /* @__PURE__ */ jsx(IconOnlyStatus, {
		descriptionText,
		icon,
		iconColor
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [descriptionText ? /* @__PURE__ */ jsx(ButtonComponent, {
		"data-testid": "checks-status-badge-button",
		leadingVisual: icon,
		variant: "invisible",
		size,
		"aria-label": combinedStatus?.checksStatusSummary ?? `Status checks: ${statusRollup}`,
		sx: {
			svg: { color: iconColor },
			...buttonSx
		},
		ref: checkButtonRef,
		onClick: () => {
			fetchData?.();
			setIsOpen(true);
		},
		className: clsx(ChecksStatusBadge_module_default.ChecksStatusBadgeButton, buttonClassName),
		children: descriptionText
	}) : /* @__PURE__ */ jsx(IconButton, {
		"data-testid": "checks-status-badge-icon",
		tooltipDirection: "s",
		icon,
		variant: "invisible",
		size,
		"aria-label": combinedStatus?.checksStatusSummary ?? statusRollup,
		sx: {
			svg: { color: iconColor },
			...buttonSx
		},
		className: clsx(ChecksStatusBadge_module_default.ChecksStatusBadgeIconButton, buttonClassName),
		ref: checkButtonRef,
		onClick: () => {
			fetchData?.();
			setIsOpen(true);
		}
	}), isOpen && /* @__PURE__ */ jsx(CheckStatusDialog, {
		combinedStatus,
		isOpen,
		onDismiss: () => {
			setIsOpen(false);
			setTimeout(() => {
				checkButtonRef.current?.focus();
			}, 0);
		}
	})] });
}
ChecksStatusBadge.displayName = "ChecksStatusBadge";
function useCommitChecksStatusDetails(oid, repo) {
	const $ = c(7);
	const [details, setDetails] = useState();
	const [oidToFetch, setOidToFetch] = useState();
	let t0;
	if ($[0] !== oid || $[1] !== oidToFetch || $[2] !== repo) {
		t0 = async () => {
			if (oidToFetch !== oid) {
				setOidToFetch(oid);
				setDetails(void 0);
				if (oid) setDetails(await (await verifiedFetchJSON(commitStatusDetailsPath(repo, oid))).json());
			}
		};
		$[0] = oid;
		$[1] = oidToFetch;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	const fetchDetails = t0;
	let t1;
	if ($[4] !== details || $[5] !== fetchDetails) {
		t1 = [details, fetchDetails];
		$[4] = details;
		$[5] = fetchDetails;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
export { useCommitChecksStatusDetails as a, PushAttribution as i, ChecksStatusBadge as n, CommitAttribution as r, AuthorAvatar as t };
