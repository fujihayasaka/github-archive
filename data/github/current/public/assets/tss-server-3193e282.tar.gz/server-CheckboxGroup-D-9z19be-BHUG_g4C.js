import { A as CheckboxOrRadioGroup$1, N as CheckboxOrRadioGroupLabel, P as CheckboxOrRadioGroupValidation, Ri as isSlot, Ui as useRenderForcingRef, j as CheckboxOrRadioGroupCaption } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as CheckboxGroupContext, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import React from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
var CheckboxGroup = (t0) => {
	const $ = c(24);
	let children;
	let disabled;
	let onChange;
	let rest;
	if ($[0] !== t0) {
		({children, disabled, onChange, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = disabled;
		$[3] = onChange;
		$[4] = rest;
	} else {
		children = $[1];
		disabled = $[2];
		onChange = $[3];
		rest = $[4];
	}
	let t1;
	if ($[5] !== children) {
		const formControlComponentChildren = React.Children.toArray(children).filter(_temp).map(_temp2).flat();
		t1 = React.Children.toArray(formControlComponentChildren).filter(_temp3).map(_temp4).filter(Boolean);
		$[5] = children;
		$[6] = t1;
	} else t1 = $[6];
	const [selectedCheckboxValues, setSelectedCheckboxValues] = useRenderForcingRef(t1);
	let t2;
	if ($[7] !== selectedCheckboxValues || $[8] !== setSelectedCheckboxValues) {
		t2 = (e) => {
			const { value, checked } = e.currentTarget;
			if (checked) {
				setSelectedCheckboxValues([...selectedCheckboxValues.current || [], value]);
				return;
			}
			setSelectedCheckboxValues((selectedCheckboxValues.current || []).filter((selectedValue) => selectedValue !== value));
		};
		$[7] = selectedCheckboxValues;
		$[8] = setSelectedCheckboxValues;
		$[9] = t2;
	} else t2 = $[9];
	const updateSelectedCheckboxes = t2;
	let t3;
	if ($[10] !== onChange || $[11] !== selectedCheckboxValues || $[12] !== updateSelectedCheckboxes) {
		t3 = (e_0) => {
			if (onChange) {
				updateSelectedCheckboxes(e_0);
				onChange(selectedCheckboxValues.current || [], e_0);
			}
		};
		$[10] = onChange;
		$[11] = selectedCheckboxValues;
		$[12] = updateSelectedCheckboxes;
		$[13] = t3;
	} else t3 = $[13];
	let t4;
	if ($[14] !== disabled || $[15] !== t3) {
		t4 = {
			disabled,
			onChange: t3
		};
		$[14] = disabled;
		$[15] = t3;
		$[16] = t4;
	} else t4 = $[16];
	let t5;
	if ($[17] !== children || $[18] !== disabled || $[19] !== rest) {
		t5 = /* @__PURE__ */ jsx(CheckboxOrRadioGroup$1, {
			disabled,
			...rest,
			children
		});
		$[17] = children;
		$[18] = disabled;
		$[19] = rest;
		$[20] = t5;
	} else t5 = $[20];
	let t6;
	if ($[21] !== t4 || $[22] !== t5) {
		t6 = /* @__PURE__ */ jsx(CheckboxGroupContext.Provider, {
			value: t4,
			children: t5
		});
		$[21] = t4;
		$[22] = t5;
		$[23] = t6;
	} else t6 = $[23];
	return t6;
};
var CheckboxGroup_default = Object.assign(CheckboxGroup, {
	Caption: CheckboxOrRadioGroupCaption,
	Label: CheckboxOrRadioGroupLabel,
	Validation: CheckboxOrRadioGroupValidation
});
CheckboxGroup.__SLOT__ = Symbol("CheckboxGroup");
function _temp(child) {
	return /* @__PURE__ */ React.isValidElement(child) && (child.type === FormControl$1 || isSlot(child, FormControl$1));
}
function _temp2(formControlComponent) {
	return /* @__PURE__ */ React.isValidElement(formControlComponent) ? formControlComponent.props.children : [];
}
function _temp3(child_0) {
	return /* @__PURE__ */ React.isValidElement(child_0) && (child_0.type === Checkbox || isSlot(child_0, Checkbox));
}
function _temp4(checkbox) {
	return /* @__PURE__ */ React.isValidElement(checkbox) && (checkbox.props.checked || checkbox.props.defaultChecked) && checkbox.props.value;
}
export { CheckboxGroup_default as t };
