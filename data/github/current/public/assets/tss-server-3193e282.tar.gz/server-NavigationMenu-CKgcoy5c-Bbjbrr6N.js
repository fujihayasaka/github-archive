import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { _n as KebabHorizontalIcon, an as IconButton, ar as PlusIcon, bn as Link, n as ActionList, wi as UploadIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { g as useLocation$1, h as useLinkClickHandler, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { Dt as repoModelsPromptPath, It as repositoryTreePath, a as blobPath, r as blamePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { a as useAction, c as useUrlCreator, n as AllShortcutsEnabled, o as useCurrentUser, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as PortalTooltip } from "./server-PortalTooltip-DECeLuvi-BZbUqJOn.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { n as useCopilotSettings } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { n as useEditPermissions } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { t as NewAgentTaskButton } from "./server-NewAgentTaskButton-gbUWCBSY-Cu9_75w7.js";
import { n as FileResultsList } from "./server-FileResultsList-DizJJtxZ-C9rZpyL_.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { a as useShortcut, i as useCodeViewOptions } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { t as ReposHeaderRefSelector } from "./server-ReposHeaderRefSelector-D_1tuOMj-sntynq8H.js";
import { r as FindFilesShortcut, s as isTreePayload, t as DuplicateOnKeydownButton } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { t as Breadcrumb } from "./server-Breadcrumb-ivvgSfHr-DYsABnl4.js";
import { $ as useCursorEndLineNumber, F as getCopyStateUI, I as handleAddReference, O as copyText, U as parseFileAnchor, X as useCurrentBlame, Y as useCopyRawBlobContents, Z as useCurrentBlob, ot as useIsCursorEnabled, q as textAreaId, s as CurrentBlobProvider, tt as useCursorStartLineNumber } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { n as scrollLineIntoView, r as useCurrentStyledBlob } from "./server-use-scroll-line-into-view-DttIeP88-D69hX7MG.js";
import { r as useFindInFileOpen } from "./server-FindInFileOpenContext-ugtnUwTQ-CmcTU3Zx.js";
import { n as updateExpandPreferences, r as useCodeNav } from "./server-CodeNavContext-B-HlTATD-BC-PDvfx.js";
import { t as AddFileDropdownButton } from "./server-AddFileDropdownButton-B6k5ztd6-CTXTm663.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { Suspense, lazy, startTransition, useCallback, useEffect, useEffectEvent, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { createPortal } from "react-dom";
import { c } from "react/compiler-runtime";
function isBlobPayload(payload) {
	return "blob" in payload;
}
function isDeletePayload(payload) {
	return "deleteInfo" in payload && "webCommitInfo" in payload;
}
var BlobDisplayType = {
	FileRenderer: "FileRenderer",
	Image: "Image",
	TooLargeError: "TooLargeError",
	CSV: "CSV",
	Markdown: "Markdown",
	IssueTemplate: "IssueTemplate",
	Code: "Code"
};
function useBlobRendererType() {
	const payload = useCurrentBlob();
	const blame = useCurrentBlame();
	if (payload.renderedFileInfo && !payload.shortPath && !blame) return BlobDisplayType.FileRenderer;
	else if (payload.renderImageOrRaw) if (payload.image) return BlobDisplayType.Image;
	else return BlobDisplayType.TooLargeError;
	else if (payload.csv && !blame) return BlobDisplayType.CSV;
	else if (payload.richText && !blame) return BlobDisplayType.Markdown;
	else if ((payload.issueTemplate?.structured && payload.issueTemplate.valid || payload.discussionTemplate && payload.discussionTemplate.valid) && !blame && !payload.isPlain) return BlobDisplayType.IssueTemplate;
	else return BlobDisplayType.Code;
}
function useAlertTooltip(id, contentRef, portalTooltipProps) {
	const [message, setMessage] = useState("");
	const clearMessage = useCallback(() => {
		setMessage("");
	}, []);
	return [
		useCallback((newMessage) => {
			setMessage(newMessage);
			if (contentRef.current !== document.activeElement) setTimeout(clearMessage, 3e3);
		}, [clearMessage, contentRef]),
		clearMessage,
		/* @__PURE__ */ jsx(AlertTooltip, {
			message,
			id,
			contentRef,
			clearMessage,
			portalTooltipProps
		}, id)
	];
}
function AlertTooltip({ message, id, contentRef, clearMessage, portalTooltipProps }) {
	return message ? /* @__PURE__ */ jsx(PortalTooltip, {
		id,
		contentRef,
		"aria-label": message,
		open: !!message,
		onMouseLeave: clearMessage,
		"aria-live": "assertive",
		...portalTooltipProps
	}) : null;
}
AlertTooltip.displayName = "AlertTooltip";
function ReposHeaderBreadcrumb(t0) {
	const $ = c(9);
	const { fileNameId: t1, id, size, showCopyPathButton } = t0;
	const fileNameId = t1 === void 0 ? "file-name-id" : t1;
	const repo = useCurrentRepository();
	const path = usePath();
	const action = useAction();
	const refInfo = useRefInfo();
	const t2 = action === "tree";
	const t3 = showCopyPathButton && path !== "" && path !== "/";
	let t4;
	if ($[0] !== fileNameId || $[1] !== id || $[2] !== path || $[3] !== refInfo.name || $[4] !== repo || $[5] !== size || $[6] !== t2 || $[7] !== t3) {
		t4 = jsx(Breadcrumb, {
			path,
			repo,
			commitish: refInfo.name,
			isFolder: t2,
			fileNameId,
			id,
			size,
			showCopyPathButton: t3
		});
		$[0] = fileNameId;
		$[1] = id;
		$[2] = path;
		$[3] = refInfo.name;
		$[4] = repo;
		$[5] = size;
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
}
ReposHeaderBreadcrumb.displayName = "ReposHeaderBreadcrumb";
function KeyboardVisual({ shortcut }) {
	return /* @__PURE__ */ jsx("span", {
		className: "d-flex gap-1",
		children: shortcut.text?.split(" ").map((keyValue, idx) => /* @__PURE__ */ jsx("kbd", { children: keyValue }, `${keyValue}-${idx}`))
	});
}
KeyboardVisual.displayName = "KeyboardVisual";
var BlobNavigationButtons_module_default = {
	dialogBody: "BlobNavigationButtons-module_S4Pt_q_dialogBody",
	errorAlert: "BlobNavigationButtons-module_S4Pt_q_errorAlert",
	inputWrapper: "BlobNavigationButtons-module_S4Pt_q_inputWrapper",
	lineInput: "BlobNavigationButtons-module_S4Pt_q_lineInput"
};
function useWorkflowRedirectUrl() {
	return useCurrentBlob().workflowRedirectUrl;
}
function GoToLineDialog({ onBlamePage, onDismiss, maxLineNumber }) {
	const navigate = useNavigate$1();
	const shouldUseCursor = useIsCursorEnabled();
	const startLineNum = useCursorStartLineNumber();
	const endLineNum = useCursorEndLineNumber();
	const lineNumberRef = useRef(shouldUseCursor ? startLineNum : 1);
	const validRef = useRef(true);
	const [changeDescribeBy, setChangeDescribeBy] = useState(true);
	const secondLineNumberRef = useRef(startLineNum !== endLineNum && shouldUseCursor ? endLineNum : null);
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	const inputBoxRef = useRef(null);
	const hash = useRef(lineNumberRef.current ? `#L${lineNumberRef.current}${secondLineNumberRef.current ? `-L${secondLineNumberRef.current}` : ""}` : "");
	const href = onBlamePage ? blamePath({
		repo: repo.name,
		owner: repo.ownerLogin,
		filePath: path,
		commitish: refInfo.name
	}) : blobPath({
		repo: repo.name,
		owner: repo.ownerLogin,
		filePath: path,
		commitish: refInfo.name
	});
	const focusInputBoxRefOnLoad = useEffectEvent(() => {
		if (inputBoxRef && inputBoxRef.current) {
			inputBoxRef.current.value = shouldUseCursor ? `${startLineNum}${endLineNum !== startLineNum ? `-${endLineNum}` : ""}` : "1";
			inputBoxRef.current.focus();
		}
	});
	useEffect(() => {
		focusInputBoxRefOnLoad();
	}, []);
	function handleInputChange(inputValue) {
		let isValid = true;
		if (inputValue.trim() === "") lineNumberRef.current = 1;
		if (inputValue.startsWith("-") && maxLineNumber) {
			const intValue = parseInt(inputValue, 10);
			if (!Number.isNaN(intValue) && intValue < 0) {
				let numberToGoTo = maxLineNumber + intValue + 1;
				if (numberToGoTo <= 0) {
					numberToGoTo = 1;
					isValid = false;
				}
				lineNumberRef.current = numberToGoTo;
			}
		} else if (inputValue.includes("-")) {
			const [firstLine, secondLine] = inputValue.split("-");
			const firstIntValue = parseInt(firstLine, 10);
			const secondIntvalue = parseInt(secondLine, 10);
			if (!Number.isNaN(firstIntValue) && firstIntValue > 0) {
				lineNumberRef.current = maxLineNumber ? Math.min(firstIntValue, maxLineNumber) : firstIntValue;
				isValid = maxLineNumber !== void 0 && firstIntValue <= maxLineNumber;
			}
			if (!Number.isNaN(secondIntvalue) && secondIntvalue > 0) {
				secondLineNumberRef.current = maxLineNumber ? Math.min(secondIntvalue, maxLineNumber) : secondIntvalue;
				isValid = isValid && maxLineNumber !== void 0 && secondIntvalue <= maxLineNumber;
			}
		} else {
			const intValue_0 = parseInt(inputValue, 10);
			if (!Number.isNaN(intValue_0) && intValue_0 > 0) {
				lineNumberRef.current = maxLineNumber ? Math.min(intValue_0, maxLineNumber) : intValue_0;
				isValid = maxLineNumber !== void 0 && intValue_0 <= maxLineNumber;
			} else isValid = inputValue !== "" ? false : true;
		}
		validRef.current = isValid;
		if (isValid && !changeDescribeBy) setChangeDescribeBy(true);
		hash.current = `#L${lineNumberRef.current}${secondLineNumberRef.current ? `-L${secondLineNumberRef.current}` : ""}`;
	}
	const handleGoToLine = (url, newHash) => {
		navigate(`${url}${newHash}`);
		const anchInfo = parseFileAnchor(newHash);
		if (!anchInfo.blobRange?.start?.line || !validRef.current) {
			setChangeDescribeBy(validRef.current);
			setTimeout(() => {
				inputBoxRef.current?.focus();
			}, 25);
			return;
		}
		scrollLineIntoView({ line: anchInfo.blobRange.start.line });
		onDismiss();
	};
	return createPortal(/* @__PURE__ */ jsxs(Dialog_default, {
		isOpen: true,
		onDismiss,
		children: [
			/* @__PURE__ */ jsx(Dialog_default.Header, { children: "Jump to line" }),
			/* @__PURE__ */ jsxs("div", {
				className: BlobNavigationButtons_module_default.dialogBody,
				style: { paddingBottom: changeDescribeBy ? "16px" : 0 },
				children: [/* @__PURE__ */ jsx("div", {
					className: BlobNavigationButtons_module_default.inputWrapper,
					children: /* @__PURE__ */ jsx(TextInput$1, {
						ref: inputBoxRef,
						"aria-invalid": !changeDescribeBy,
						"aria-describedby": changeDescribeBy ? "" : "goToLineErrorValidation",
						className: BlobNavigationButtons_module_default.lineInput,
						placeholder: "Jump to line...",
						onChange: (e) => {
							const value = e.target.value;
							if (inputBoxRef && inputBoxRef.current) inputBoxRef.current.value = value;
							handleInputChange(value);
						},
						onFocus: () => {
							if (inputBoxRef && inputBoxRef.current) inputBoxRef.current.select();
						},
						onKeyDown: (e_0) => {
							if (e_0.key !== "Enter") return;
							if (e_0.key === "Enter" && !validRef.current) {
								setChangeDescribeBy(validRef.current);
								setTimeout(() => {
									inputBoxRef.current?.focus();
								}, 25);
								return;
							}
							handleGoToLine(href, hash.current);
						}
					})
				}), /* @__PURE__ */ jsx(LinkButton, {
					href: changeDescribeBy ? href + hash.current : void 0,
					onClick: (e_1) => {
						e_1.preventDefault();
						handleGoToLine(href, hash.current);
					},
					className: LinkButton_module_default.linkButton,
					children: "Go"
				})]
			}),
			!changeDescribeBy && /* @__PURE__ */ jsx("div", {
				role: "alert",
				id: "goToLineErrorValidation",
				className: BlobNavigationButtons_module_default.errorAlert,
				children: "Invalid line number"
			})
		]
	}), document.body);
}
GoToLineDialog.displayName = "GoToLineDialog";
function DeleteDirectoryItem() {
	const $ = c(4);
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { canEdit } = useEditPermissions();
	if (!canEdit) return null;
	let t0;
	if ($[0] !== path || $[1] !== refInfo.name || $[2] !== repo) {
		t0 = jsx(ActionList.LinkItem, {
			as: Link$1,
			to: repositoryTreePath({
				repo,
				path,
				commitish: refInfo.name,
				action: "tree/delete"
			}),
			children: jsx("span", {
				className: "color-fg-danger",
				children: "Delete directory"
			})
		});
		$[0] = path;
		$[1] = refInfo.name;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
DeleteDirectoryItem.displayName = "DeleteDirectoryItem";
var CodeViewHeader_module_default = {
	Box: "CodeViewHeader-module_jjsF6W_Box",
	Box_1: "CodeViewHeader-module_jjsF6W_Box_1",
	Box_2: "CodeViewHeader-module_jjsF6W_Box_2",
	Box_3: "CodeViewHeader-module_jjsF6W_Box_3",
	Box_5: "CodeViewHeader-module_jjsF6W_Box_5",
	Box_6: "CodeViewHeader-module_jjsF6W_Box_6",
	Box_7: "CodeViewHeader-module_jjsF6W_Box_7",
	FileResultsList: "CodeViewHeader-module_jjsF6W_FileResultsList",
	IconButton: "CodeViewHeader-module_jjsF6W_IconButton",
	StickyHeader: "CodeViewHeader-module_jjsF6W_StickyHeader",
	treeToggleWrapper: "CodeViewHeader-module_jjsF6W_treeToggleWrapper",
	treeToggleWrapperHideOnWide: "CodeViewHeader-module_jjsF6W_treeToggleWrapperHideOnWide"
};
var DeleteHeaderButtons_module_default = { Box: "DeleteHeaderButtons-module_rBL4aW_Box" };
var WebCommitDialog = lazy(() => import("./server-WebCommitDialog-CUOmvrJ4-CATAb5F-.js"));
WebCommitDialog.displayName = "WebCommitDialog";
function DeleteHeaderButtons({ webCommitInfo, isBlob }) {
	const [webCommitDialogState, setWebCommitDialogState] = useState("closed");
	const commitChangesOpen = webCommitDialogState === "pending" || webCommitDialogState === "saving";
	const returnFocusRef = useRef(null);
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { helpUrl } = useReposAppPayload();
	const cancelUrl = repositoryTreePath({
		repo,
		commitish: refInfo.name,
		action: isBlob ? "blob" : "tree",
		path
	});
	if (webCommitInfo.shouldFork || webCommitInfo.shouldUpdate || webCommitInfo.lockedOnMigration) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: DeleteHeaderButtons_module_default.Box,
		children: [
			/* @__PURE__ */ jsx(ButtonComponent, {
				as: Link$1,
				to: cancelUrl,
				children: "Cancel changes"
			}),
			/* @__PURE__ */ jsx(ButtonComponent, {
				variant: "primary",
				ref: returnFocusRef,
				onClick: () => {
					startTransition(() => {
						setWebCommitDialogState("pending");
					});
				},
				children: "Commit changes..."
			}),
			commitChangesOpen && /* @__PURE__ */ jsx(Suspense, {
				fallback: null,
				children: /* @__PURE__ */ jsx(WebCommitDialog, {
					isNewFile: false,
					isDelete: true,
					helpUrl,
					ownerName: repo.ownerLogin,
					dialogState: webCommitDialogState,
					setDialogState: setWebCommitDialogState,
					refName: refInfo.name,
					placeholderMessage: `Delete ${path}${isBlob ? "" : " directory"}`,
					webCommitInfo,
					returnFocusRef
				})
			})
		]
	});
}
DeleteHeaderButtons.displayName = "DeleteHeaderButtons";
var safeLocalStorage = safeStorage("localStorage");
function SettingsMenuItems(t0) {
	const $ = c(6);
	const { symbolsEnabled } = t0;
	const { codeFoldingOption, codeWrappingOption, codeCenterOption, openSymbolsOption } = useCodeViewOptions();
	let t1;
	if ($[0] !== codeCenterOption || $[1] !== codeFoldingOption || $[2] !== codeWrappingOption || $[3] !== openSymbolsOption || $[4] !== symbolsEnabled) {
		t1 = jsxs(Fragment$1, { children: [
			jsx(OptionsElement, { option: codeFoldingOption }),
			jsx(OptionsElement, { option: codeWrappingOption }),
			jsx(OptionsElement, { option: codeCenterOption }),
			symbolsEnabled && jsx(OptionsElement, { option: openSymbolsOption })
		] });
		$[0] = codeCenterOption;
		$[1] = codeFoldingOption;
		$[2] = codeWrappingOption;
		$[3] = openSymbolsOption;
		$[4] = symbolsEnabled;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
SettingsMenuItems.displayName = "SettingsMenuItems";
function OptionsElement(t0) {
	const $ = c(7);
	const { option } = t0;
	let t1;
	if ($[0] !== option) {
		t1 = () => {
			startTransition(() => option.setEnabled(!option.enabled));
			const newValue = String(!option.enabled);
			requestIdleCallback(() => safeLocalStorage.setItem(option.name, newValue));
			if (option.name === "codeView.codeWrapping") updateExpandPreferences(null, null, !option.enabled);
		};
		$[0] = option;
		$[1] = t1;
	} else t1 = $[1];
	const onSelect = t1;
	let t2;
	if ($[2] !== onSelect || $[3] !== option.enabled || $[4] !== option.label || $[5] !== option.name) {
		t2 = jsx(ActionList.Item, {
			selected: option.enabled,
			onSelect,
			children: option.label
		}, option.name);
		$[2] = onSelect;
		$[3] = option.enabled;
		$[4] = option.label;
		$[5] = option.name;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
OptionsElement.displayName = "OptionsElement";
function CodeViewHeaderDataRouter(t0) {
	const $ = c(9);
	const { wideActions, narrowActions, modelsRepoIntegrationEnabled, commitish, path } = t0;
	const { isTreeExpanded, treeToggleElement } = useTreePaneContext();
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== commitish || $[1] !== isTreeExpanded || $[2] !== modelsRepoIntegrationEnabled || $[3] !== narrowActions || $[4] !== path || $[5] !== repo || $[6] !== treeToggleElement || $[7] !== wideActions) {
		const modelsAction = modelsRepoIntegrationEnabled && path?.match(/\.prompt\.(yml|yaml)$/) ? jsx(Fragment$1, { children: jsx(ButtonComponent, {
			as: Link$1,
			to: repoModelsPromptPath({
				repo,
				path,
				commitish,
				action: "edit"
			}),
			children: "Edit prompt"
		}) }) : null;
		t1 = jsx(CodeViewHeaderWrapper, {
			showTree: isTreeExpanded,
			treeToggleElement,
			wideActions: jsxs(Fragment$1, { children: [wideActions, modelsAction] }),
			narrowActions: jsxs(Fragment$1, { children: [narrowActions, modelsAction] })
		});
		$[0] = commitish;
		$[1] = isTreeExpanded;
		$[2] = modelsRepoIntegrationEnabled;
		$[3] = narrowActions;
		$[4] = path;
		$[5] = repo;
		$[6] = treeToggleElement;
		$[7] = wideActions;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
CodeViewHeaderDataRouter.displayName = "CodeViewHeaderDataRouter";
function CodeViewHeaderWrapper(t0) {
	const $ = c(6);
	const { showTree, treeToggleElement, wideActions, narrowActions } = t0;
	const { codeCenterOption } = useCodeViewOptions();
	let t1;
	if ($[0] !== codeCenterOption || $[1] !== narrowActions || $[2] !== showTree || $[3] !== treeToggleElement || $[4] !== wideActions) {
		t1 = jsx("div", {
			className: clsx("container", CodeViewHeader_module_default.Box),
			children: jsx("div", {
				className: CodeViewHeader_module_default.StickyHeader,
				id: "StickyHeader",
				children: jsx("div", {
					className: CodeViewHeader_module_default.Box_1,
					children: jsxs("div", {
						className: CodeViewHeader_module_default.Box_2,
						children: [
							!showTree ? jsxs("div", {
								className: clsx("react-code-view-header-wrap--narrow", CodeViewHeader_module_default.Box_3),
								children: [
									jsx("div", {
										className: clsx(CodeViewHeader_module_default.treeToggleWrapper, codeCenterOption.enabled && CodeViewHeader_module_default.treeToggleWrapperHideOnWide),
										children: treeToggleElement
									}),
									jsx("div", {
										className: "react-code-view-header-mb--narrow mr-2",
										children: jsx(ReposHeaderRefSelector, {
											buttonClassName: "ref-selector-class",
											idEnding: "repos-header-ref-selector-wide"
										})
									}),
									jsx("div", {
										className: clsx("react-code-view-header-mb--narrow", CodeViewHeader_module_default.Box_5),
										children: jsx(ReposHeaderBreadcrumb, {
											id: "repos-header-breadcrumb",
											fileNameId: "file-name-id",
											showCopyPathButton: true
										})
									})
								]
							}) : jsx("div", {
								className: CodeViewHeader_module_default.Box_6,
								children: jsx(ReposHeaderBreadcrumb, {
									id: "repos-header-breadcrumb--wide",
									fileNameId: "file-name-id-wide",
									showCopyPathButton: true
								})
							}),
							jsx("div", {
								className: "react-code-view-header-element--wide",
								children: jsx("div", {
									className: CodeViewHeader_module_default.Box_7,
									children: jsx("div", {
										className: "d-flex gap-2",
										children: wideActions
									})
								})
							}),
							jsx("div", {
								className: "react-code-view-header-element--narrow",
								children: jsx("div", {
									className: CodeViewHeader_module_default.Box_7,
									children: jsx("div", {
										className: "d-flex gap-2",
										children: narrowActions
									})
								})
							})
						]
					})
				})
			})
		});
		$[0] = codeCenterOption;
		$[1] = narrowActions;
		$[2] = showTree;
		$[3] = treeToggleElement;
		$[4] = wideActions;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
CodeViewHeaderWrapper.displayName = "CodeViewHeaderWrapper";
function CodeViewHeader({ payload, showTree, treeToggleElement, validCodeNav, onFindFilesShortcut }) {
	return /* @__PURE__ */ jsx(CodeViewHeaderWrapper, {
		showTree,
		treeToggleElement,
		wideActions: /* @__PURE__ */ jsx(PageActions, {
			payload,
			onFindFilesShortcut,
			narrow: false,
			showTree,
			validCodeNav
		}),
		narrowActions: /* @__PURE__ */ jsx(PageActions, {
			payload,
			onFindFilesShortcut,
			narrow: true,
			showTree,
			validCodeNav
		})
	});
}
CodeViewHeader.displayName = "CodeViewHeader";
function PageActions({ payload, onFindFilesShortcut, narrow, showTree, validCodeNav }) {
	const onCopy = useCopyRawBlobContents();
	const { findFileWorkerPath, githubDevUrl } = useReposAppPayload();
	const repo = useCurrentRepository();
	const path = usePath();
	const { modelsRepoIntegrationEnabled } = useCopilotSettings();
	const refInfo = useRefInfo();
	const { openWithGitHubDevShortcut, openWithGitHubDevInNewWindowShortcut } = useShortcut();
	const inputRef = useRef(null);
	const showAgentTaskButton = payload.copilotSWEAgentEnabled ?? false;
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const goToFileInput = !showTree && /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(FileResultsList, {
		commitOid: refInfo.currentOid,
		findFileWorkerPath,
		searchBoxRef: inputRef,
		config: { enableOverlay: true },
		className: CodeViewHeader_module_default.FileResultsList
	}), /* @__PURE__ */ jsx(FindFilesShortcut, {
		inputRef,
		onFindFilesShortcut,
		textAreaId: "read-only-cursor-text-area"
	})] });
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		isBlobPayload(payload) && /* @__PURE__ */ jsxs(CurrentBlobProvider, {
			blob: payload.blob,
			children: [!narrow && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ViewRunsButton, {}), goToFileInput] }), /* @__PURE__ */ jsx(NavigationMenu, {
				onCopy,
				narrow,
				validCodeNav,
				copilotAccessAllowed: payload.copilotAccessAllowed ?? false
			})]
		}),
		modelsRepoIntegrationEnabled && payload.path?.match(/\.prompt\.(yml|yaml)$/) && /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(ButtonComponent, {
			as: Link$1,
			to: repoModelsPromptPath({
				repo,
				path: payload.path,
				commitish: refInfo.name,
				action: "edit"
			}),
			children: "Edit prompt"
		}) }),
		isTreePayload(payload) && /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(ScreenReaderHeading, {
				as: "h2",
				text: "Directory actions"
			}),
			!narrow && /* @__PURE__ */ jsxs(Fragment$1, { children: [
				goToFileInput,
				/* @__PURE__ */ jsx(AddFileDropdownButton, {}),
				showAgentTaskButton && /* @__PURE__ */ jsx(NewAgentTaskButton, {
					isIconButton: true,
					currentRepo: repo,
					currentReference: { path },
					hideRepoSelector: true,
					eventType: "new_agent_task_button_codenav",
					decoupledModeEnabled
				})
			] }),
			/* @__PURE__ */ jsx(TreeOverflowMenu, { narrow }),
			/* @__PURE__ */ jsx(Link, {
				className: "js-github-dev-shortcut d-none",
				"data-hotkey": openWithGitHubDevShortcut.hotkey,
				href: githubDevUrl
			}),
			/* @__PURE__ */ jsx(Link, {
				className: "js-github-dev-new-tab-shortcut d-none",
				"data-hotkey": openWithGitHubDevInNewWindowShortcut.hotkey,
				href: githubDevUrl,
				target: "_blank"
			})
		] }),
		isDeletePayload(payload) && /* @__PURE__ */ jsx(DeleteHeaderButtons, {
			webCommitInfo: payload.webCommitInfo,
			isBlob: payload.deleteInfo.isBlob
		})
	] });
}
PageActions.displayName = "PageActions";
function TreeOverflowMenu({ narrow }) {
	const path = usePath();
	const refInfo = useRefInfo();
	const { canEdit } = useEditPermissions();
	const repo = useCurrentRepository();
	const { sendRepoClickEvent } = useReposAnalytics();
	const { addToast } = useToastContext();
	const { createPermalink } = useUrlCreator();
	const { copyFilePathShortcut, copyPermalinkShortcut } = useShortcut();
	const { codeCenterOption } = useCodeViewOptions();
	const moreOptionsButtonRef = useRef(null);
	const [updateMessage, clearMessage, portalTooltip] = useAlertTooltip("raw-copy-message-tooltip", moreOptionsButtonRef, { direction: "nw" });
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		copyFilePathShortcut.hotkey && /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: copyFilePathShortcut.hotkey,
			onButtonClick: () => {
				copyText(path);
				addToast({
					type: "success",
					message: "Path copied!"
				});
			}
		}),
		copyPermalinkShortcut.hotkey && /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: copyPermalinkShortcut.hotkey,
			onButtonClick: () => {
				copyText(createPermalink({ absolute: true }));
				addToast({
					type: "success",
					message: "Permalink copied!"
				});
			}
		}),
		/* @__PURE__ */ jsx(ScreenReaderHeading, {
			as: "h2",
			text: "More options"
		}),
		portalTooltip,
		/* @__PURE__ */ jsxs(ActionMenu, {
			onOpenChange: (open) => open && sendRepoClickEvent("MORE_OPTIONS_DROPDOWN"),
			anchorRef: moreOptionsButtonRef,
			children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
				icon: KebabHorizontalIcon,
				"aria-label": "More options",
				size: "medium",
				title: "More options",
				"data-testid": "tree-overflow-menu-anchor",
				onBlur: clearMessage,
				className: CodeViewHeader_module_default.IconButton
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "small",
				children: /* @__PURE__ */ jsxs(ActionList, { children: [
					narrow && canEdit && /* @__PURE__ */ jsxs(Fragment$1, { children: [
						/* @__PURE__ */ jsxs(ActionList.LinkItem, {
							as: Link$1,
							onClick: () => sendRepoClickEvent("NEW_FILE_BUTTON"),
							to: repositoryTreePath({
								repo,
								path,
								commitish: refInfo.name,
								action: "new"
							}),
							children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PlusIcon, {}) }), "Create new file"]
						}),
						/* @__PURE__ */ jsxs(ActionList.LinkItem, {
							onClick: () => sendRepoClickEvent("UPLOAD_FILES_BUTTON"),
							href: repositoryTreePath({
								repo,
								path,
								commitish: refInfo.name,
								action: "upload"
							}),
							children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(UploadIcon, {}) }), "Upload files"]
						}),
						/* @__PURE__ */ jsx(ActionList.Divider, {})
					] }),
					/* @__PURE__ */ jsx(CopyPathsActionItems, {
						path,
						updateTooltipMessage: updateMessage
					}),
					canEdit && /* @__PURE__ */ jsx(ActionList.Divider, {}),
					/* @__PURE__ */ jsx(DeleteDirectoryItem, {}),
					/* @__PURE__ */ jsx(ActionList.Divider, {}),
					/* @__PURE__ */ jsxs(ActionList.Group, {
						selectionVariant: "multiple",
						children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, { children: "View options" }), /* @__PURE__ */ jsx(OptionsElement, { option: codeCenterOption })]
					})
				] })
			})]
		})
	] });
}
TreeOverflowMenu.displayName = "TreeOverflowMenu";
function CopyPathsActionItems(t0) {
	const $ = c(15);
	const { path, updateTooltipMessage } = t0;
	const { copyFilePathShortcut } = useShortcut();
	const { copyPermalinkShortcut } = useShortcut();
	const { sendRepoClickEvent } = useReposAnalytics();
	const { createPermalink } = useUrlCreator();
	let t1;
	if ($[0] !== copyFilePathShortcut || $[1] !== copyPermalinkShortcut || $[2] !== createPermalink || $[3] !== path || $[4] !== sendRepoClickEvent || $[5] !== updateTooltipMessage) {
		let t2;
		if ($[7] !== path || $[8] !== sendRepoClickEvent || $[9] !== updateTooltipMessage) {
			t2 = () => {
				sendRepoClickEvent("MORE_OPTIONS_DROPDOWN.COPY_PATH");
				copyText(path);
				updateTooltipMessage("Path copied!");
			};
			$[7] = path;
			$[8] = sendRepoClickEvent;
			$[9] = updateTooltipMessage;
			$[10] = t2;
		} else t2 = $[10];
		let t3;
		if ($[11] !== createPermalink || $[12] !== sendRepoClickEvent || $[13] !== updateTooltipMessage) {
			t3 = () => {
				sendRepoClickEvent("MORE_OPTIONS_DROPDOWN.COPY_PERMALINK");
				copyText(createPermalink({ absolute: true }));
				updateTooltipMessage("Permalink copied!");
			};
			$[11] = createPermalink;
			$[12] = sendRepoClickEvent;
			$[13] = updateTooltipMessage;
			$[14] = t3;
		} else t3 = $[14];
		t1 = jsxs(Fragment$1, { children: [jsxs(ActionList.Item, {
			onSelect: t2,
			children: ["Copy path", copyFilePathShortcut.hotkey && jsx(ActionList.TrailingVisual, {
				"aria-hidden": "true",
				className: "d-flex",
				children: jsx(KeyboardVisual, { shortcut: copyFilePathShortcut })
			})]
		}), jsxs(ActionList.Item, {
			onSelect: t3,
			children: ["Copy permalink", copyPermalinkShortcut.hotkey && jsx(ActionList.TrailingVisual, {
				"aria-hidden": "true",
				className: "d-flex",
				children: jsx(KeyboardVisual, { shortcut: copyPermalinkShortcut })
			})]
		})] });
		$[0] = copyFilePathShortcut;
		$[1] = copyPermalinkShortcut;
		$[2] = createPermalink;
		$[3] = path;
		$[4] = sendRepoClickEvent;
		$[5] = updateTooltipMessage;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
CopyPathsActionItems.displayName = "CopyPathsActionItems";
function ViewRunsButton() {
	const $ = c(2);
	const redirectUrl = useWorkflowRedirectUrl();
	if (!redirectUrl) return null;
	let t0;
	if ($[0] !== redirectUrl) {
		t0 = jsx(ButtonComponent, {
			as: Link$1,
			to: redirectUrl,
			children: "View Runs"
		});
		$[0] = redirectUrl;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
ViewRunsButton.displayName = "ViewRunsButton";
function GoToFileInput({ payload }) {
	const { isTreeExpanded, onFindFilesShortcut } = useTreePaneContext();
	const { findFileWorkerPath } = useReposAppPayload();
	const inputRef = useRef(null);
	if (isTreeExpanded) return null;
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(FileResultsList, {
		commitOid: payload.refInfo.currentOid,
		findFileWorkerPath,
		searchBoxRef: inputRef,
		config: { enableOverlay: true },
		className: CodeViewHeader_module_default.FileResultsList
	}), /* @__PURE__ */ jsx(FindFilesShortcut, {
		inputRef,
		onFindFilesShortcut,
		textAreaId
	})] });
}
GoToFileInput.displayName = "GoToFileInput";
function BlobHeaderActions(t0) {
	const $ = c(5);
	const { payload, narrow } = t0;
	const onCopy = useCopyRawBlobContents();
	const { validCodeNav } = useCodeNav();
	let t1;
	if ($[0] !== narrow || $[1] !== onCopy || $[2] !== payload || $[3] !== validCodeNav) {
		t1 = jsxs(Fragment$1, { children: [!narrow && jsxs(Fragment$1, { children: [jsx(ViewRunsButton, {}), jsx(GoToFileInput, { payload })] }), jsx(NavigationMenu, {
			onCopy,
			narrow,
			validCodeNav,
			copilotAccessAllowed: payload.copilotAccessAllowed ?? false
		})] });
		$[0] = narrow;
		$[1] = onCopy;
		$[2] = payload;
		$[3] = validCodeNav;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
BlobHeaderActions.displayName = "BlobHeaderActions";
function TreeHeaderActions(t0) {
	const $ = c(9);
	const { narrow, payload, path } = t0;
	const { githubDevUrl } = useReposAppPayload();
	const repo = useCurrentRepository();
	const showAgentTaskButton = payload.copilotSWEAgentEnabled ?? false;
	const { openWithGitHubDevShortcut, openWithGitHubDevInNewWindowShortcut } = useShortcut();
	let t1;
	if ($[0] !== githubDevUrl || $[1] !== narrow || $[2] !== openWithGitHubDevInNewWindowShortcut.hotkey || $[3] !== openWithGitHubDevShortcut.hotkey || $[4] !== path || $[5] !== payload || $[6] !== repo || $[7] !== showAgentTaskButton) {
		const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		t1 = jsxs(Fragment$1, { children: [
			jsx(ScreenReaderHeading, {
				as: "h2",
				text: "Directory actions"
			}),
			!narrow && jsxs(Fragment$1, { children: [
				jsx(GoToFileInput, { payload }),
				jsx(AddFileDropdownButton, {}),
				showAgentTaskButton && jsx(NewAgentTaskButton, {
					isIconButton: true,
					currentRepo: repo,
					currentReference: { path },
					hideRepoSelector: true,
					eventType: "new_agent_task_button_codenav",
					decoupledModeEnabled
				})
			] }),
			jsx(TreeOverflowMenu, { narrow }),
			jsx(Link, {
				className: "js-github-dev-shortcut d-none",
				"data-hotkey": openWithGitHubDevShortcut.hotkey,
				href: githubDevUrl
			}),
			jsx(Link, {
				className: "js-github-dev-new-tab-shortcut d-none",
				"data-hotkey": openWithGitHubDevInNewWindowShortcut.hotkey,
				href: githubDevUrl,
				target: "_blank"
			})
		] });
		$[0] = githubDevUrl;
		$[1] = narrow;
		$[2] = openWithGitHubDevInNewWindowShortcut.hotkey;
		$[3] = openWithGitHubDevShortcut.hotkey;
		$[4] = path;
		$[5] = payload;
		$[6] = repo;
		$[7] = showAgentTaskButton;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
TreeHeaderActions.displayName = "TreeHeaderActions";
function CopilotMenuItems({ fileReference }) {
	return /* @__PURE__ */ jsx(ActionList.Item, {
		"data-testid": "copilot-menu-items",
		onSelect: () => handleAddReference(fileReference),
		children: "Ask about this file"
	});
}
CopilotMenuItems.displayName = "CopilotMenuItems";
var NavigationMenu_module_default = {
	ActionMenu_Overlay: "NavigationMenu-module_6f676a_ActionMenu_Overlay",
	Button: "NavigationMenu-module_6f676a_Button",
	IconButton: "NavigationMenu-module_6f676a_IconButton"
};
function RawMenuActionItems(t0) {
	const $ = c(12);
	const { viewable, onCopy, name, updateTooltipMessage, all } = t0;
	const { sendRepoClickEvent } = useReposAnalytics();
	const { rawBlobUrl } = useCurrentBlob();
	const { downloadRawContentShortcut } = useShortcut();
	let t1;
	if ($[0] !== name || $[1] !== rawBlobUrl) {
		t1 = async () => await downloadFile(rawBlobUrl, name);
		$[0] = name;
		$[1] = rawBlobUrl;
		$[2] = t1;
	} else t1 = $[2];
	const downloadFileCallback = t1;
	let t2;
	if ($[3] !== all || $[4] !== downloadFileCallback || $[5] !== downloadRawContentShortcut || $[6] !== onCopy || $[7] !== rawBlobUrl || $[8] !== sendRepoClickEvent || $[9] !== updateTooltipMessage || $[10] !== viewable) {
		t2 = jsxs(ActionList.Group, { children: [
			jsx(ActionList.GroupHeading, { children: "Raw file content" }),
			all && jsx(CopyActionItem, {
				viewable,
				onCopy,
				updateTooltipMessage
			}),
			all && jsx(RawActionItem, {
				onClick: () => sendRepoClickEvent("BLOB_RAW_DROPDOWN.VIEW"),
				rawHref: rawBlobUrl
			}),
			jsxs(ActionList.LinkItem, {
				onClick: downloadFileCallback,
				children: ["Download", downloadRawContentShortcut.text && jsx(ActionList.TrailingVisual, {
					"aria-hidden": "true",
					className: "d-flex",
					children: jsx(KeyboardVisual, { shortcut: downloadRawContentShortcut })
				})]
			})
		] });
		$[3] = all;
		$[4] = downloadFileCallback;
		$[5] = downloadRawContentShortcut;
		$[6] = onCopy;
		$[7] = rawBlobUrl;
		$[8] = sendRepoClickEvent;
		$[9] = updateTooltipMessage;
		$[10] = viewable;
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
RawMenuActionItems.displayName = "RawMenuActionItems";
async function downloadFile(rawHref, name) {
	const blob = await (await fetch(rawHref, { method: "get" })).blob();
	const aElement = document.createElement("a");
	aElement.setAttribute("download", name);
	const href = URL.createObjectURL(blob);
	aElement.href = href;
	aElement.setAttribute("target", "_blank");
	aElement.click();
	URL.revokeObjectURL(href);
}
function CopyActionItem(t0) {
	const $ = c(5);
	const { viewable, onCopy, updateTooltipMessage } = t0;
	const { copyRawContentShortcut } = useShortcut();
	let t1;
	if ($[0] !== copyRawContentShortcut || $[1] !== onCopy || $[2] !== updateTooltipMessage || $[3] !== viewable) {
		t1 = viewable ? jsxs(ActionList.Item, {
			onSelect: async () => {
				const { ariaLabel } = getCopyStateUI(await onCopy());
				updateTooltipMessage(ariaLabel);
			},
			children: ["Copy", copyRawContentShortcut.text && jsx(ActionList.TrailingVisual, {
				"aria-hidden": "true",
				className: "d-flex",
				children: jsx(KeyboardVisual, { shortcut: copyRawContentShortcut })
			})]
		}) : null;
		$[0] = copyRawContentShortcut;
		$[1] = onCopy;
		$[2] = updateTooltipMessage;
		$[3] = viewable;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
CopyActionItem.displayName = "CopyActionItem";
function RawActionItem(t0) {
	const $ = c(4);
	const { onClick, rawHref } = t0;
	const { viewRawContentShortcut } = useShortcut();
	let t1;
	if ($[0] !== onClick || $[1] !== rawHref || $[2] !== viewRawContentShortcut) {
		t1 = jsxs(ActionList.LinkItem, {
			onClick,
			href: rawHref,
			children: ["View", viewRawContentShortcut.text && jsx(ActionList.TrailingVisual, {
				"aria-hidden": "true",
				className: "d-flex",
				children: jsx(KeyboardVisual, { shortcut: viewRawContentShortcut })
			})]
		});
		$[0] = onClick;
		$[1] = rawHref;
		$[2] = viewRawContentShortcut;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
RawActionItem.displayName = "RawActionItem";
function NavigationMenu({ onCopy, validCodeNav, narrow, copilotAccessAllowed }) {
	const payload = useCurrentBlob();
	const { rawLines } = useCurrentStyledBlob();
	const symbolsEnabled = payload.symbolsEnabled;
	const path = usePath();
	const action = useAction();
	const { currentOid, name, refType } = useRefInfo();
	const { canEdit } = useEditPermissions();
	const { githubDevUrl } = useReposAppPayload();
	const { sendRepoClickEvent } = useReposAnalytics();
	const [isGoToLineDialogOpen, setGoToLineDialogOpen] = useState(false);
	const redirectUrl = useWorkflowRedirectUrl();
	const shouldDisplayViewRuns = redirectUrl !== null;
	const { search } = useLocation$1();
	const urlParams = new URLSearchParams(search);
	const { setFindInFileOpen } = useFindInFileOpen();
	const cursorEnabled = useIsCursorEnabled();
	const shouldDisplayGoToLine = !(payload.richText && !(urlParams.get("plain") === "1") || payload.renderImageOrRaw || payload.renderedFileInfo && !urlParams.get("short_path") || payload.issueTemplate?.structured && payload.issueTemplate.valid);
	const { headerInfo: { deleteTooltip, onBranch, siteNavLoginPath, lineInfo: { truncatedLoc } }, viewable } = payload;
	const loggedIn = !!useCurrentUser();
	const { getUrl } = useUrlCreator();
	const displayType = useBlobRendererType();
	const blameUrl = useRef("");
	useEffect(() => {
		blameUrl.current = getUrl({ action: "blame" });
	}, [getUrl]);
	const { goToLineShortcut, findInFileShortcut, alternativeGoToLineShortcut } = useShortcut();
	const moreButtonRef = useRef(null);
	const [updateTooltipMessage, clearTooltipMessage, portalTooltip] = useAlertTooltip("raw-copy-message-tooltip", moreButtonRef, { direction: "nw" });
	const repository = useCurrentRepository();
	const blobUrl = getUrl();
	const { isBrowser } = useRuntimeEnvironment();
	const fileUrl = isBrowser ? (ssrSafeLocation?.origin ?? "") + blobUrl : blobUrl;
	const fileReference = useMemo(() => ({
		type: "file",
		url: fileUrl,
		path,
		repoID: repository.id,
		repoOwner: repository.ownerLogin,
		repoName: repository.name,
		ref: qualifyRef(name, refType ?? "branch"),
		commitOID: currentOid
	}), [
		fileUrl,
		path,
		repository.id,
		repository.ownerLogin,
		repository.name,
		name,
		refType,
		currentOid
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		shouldDisplayGoToLine && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: goToLineShortcut.hotkey,
			onButtonClick: () => setGoToLineDialogOpen(true)
		}), /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: alternativeGoToLineShortcut.hotkey,
			onButtonClick: () => setGoToLineDialogOpen(true)
		})] }),
		/* @__PURE__ */ jsx(BlameButton, {
			blameUrl: blameUrl.current,
			viewable,
			hidden: true
		}),
		portalTooltip,
		/* @__PURE__ */ jsxs(ActionMenu, {
			onOpenChange: (open) => open && sendRepoClickEvent("MORE_OPTIONS_DROPDOWN", {
				["edit_enabled"]: canEdit,
				["github_dev_enabled"]: !!githubDevUrl
			}),
			anchorRef: moreButtonRef,
			children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
				icon: KebabHorizontalIcon,
				"aria-label": "More file actions",
				tooltipDirection: "nw",
				className: clsx("js-blob-dropdown-click", NavigationMenu_module_default.IconButton),
				size: "medium",
				variant: "default",
				"data-testid": `more-file-actions-button-nav-menu-${narrow ? "narrow" : "wide"}`,
				onBlur: clearTooltipMessage
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "small",
				className: NavigationMenu_module_default.ActionMenu_Overlay,
				children: /* @__PURE__ */ jsxs(ActionList, { children: [
					narrow && shouldDisplayViewRuns && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.LinkItem, {
						href: redirectUrl,
						children: "View Runs"
					}), /* @__PURE__ */ jsx(ActionList.Divider, {})] }),
					/* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(RawMenuActionItems, {
						viewable,
						onCopy,
						name: payload.displayName,
						updateTooltipMessage
					}), /* @__PURE__ */ jsx(ActionList.Divider, {})] }),
					/* @__PURE__ */ jsxs(ActionList.Group, { children: [shouldDisplayGoToLine && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							sendRepoClickEvent("MORE_OPTIONS_DROPDOWN.GO_TO_LINE");
							setGoToLineDialogOpen(true);
						},
						"aria-keyshortcuts": goToLineShortcut.hotkey,
						children: ["Jump to line", /* @__PURE__ */ jsx(ActionList.TrailingVisual, {
							"aria-hidden": "true",
							children: /* @__PURE__ */ jsx(AllShortcutsEnabled, { children: /* @__PURE__ */ jsx("kbd", { children: goToLineShortcut.text }) })
						})]
					}), displayType === BlobDisplayType.Code && rawLines !== null && validCodeNav && !cursorEnabled && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							sendRepoClickEvent("BLOB_FIND_IN_FILE_MENU.OPEN");
							setFindInFileOpen(true);
						},
						"aria-keyshortcuts": findInFileShortcut.ariaKeyShortcuts,
						children: ["Find in file", /* @__PURE__ */ jsx(ActionList.TrailingVisual, {
							"aria-hidden": "true",
							className: "d-flex",
							children: /* @__PURE__ */ jsx(KeyboardVisual, { shortcut: findInFileShortcut })
						})]
					})] }),
					(shouldDisplayGoToLine || displayType === BlobDisplayType.Code && rawLines !== null && validCodeNav) && /* @__PURE__ */ jsx(ActionList.Divider, {}),
					/* @__PURE__ */ jsx(CopyPathsActionItems, {
						path,
						updateTooltipMessage
					}),
					/* @__PURE__ */ jsx(ActionList.Divider, {}),
					copilotAccessAllowed && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, { children: "Copilot" }), /* @__PURE__ */ jsx(CopilotMenuItems, { fileReference })] }), /* @__PURE__ */ jsx(ActionList.Divider, {})] }),
					/* @__PURE__ */ jsxs(ActionList.Group, {
						selectionVariant: "multiple",
						children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, { children: "View options" }), /* @__PURE__ */ jsx(SettingsMenuItems, { symbolsEnabled })]
					}),
					(canEdit && onBranch || !viewable && onBranch) && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsx(DeleteActionItem, {
						deleteTooltip,
						loggedIn,
						siteNavLoginPath
					})] })
				] })
			})]
		}),
		isGoToLineDialogOpen && /* @__PURE__ */ jsx(GoToLineDialog, {
			onBlamePage: action === "blame",
			onDismiss: () => {
				setGoToLineDialogOpen(false);
				setTimeout(() => {
					document.getElementById("read-only-cursor-text-area")?.focus();
				}, 0);
			},
			maxLineNumber: parseInt(truncatedLoc, 10) ?? void 0
		})
	] });
}
NavigationMenu.displayName = "NavigationMenu";
function BlameButton(t0) {
	const $ = c(5);
	const { blameUrl, viewable, hidden } = t0;
	const { hash } = useLocation$1();
	const onClick = useLinkClickHandler(blameUrl + hash);
	const { viewBlameShortcut } = useShortcut();
	let t1;
	if ($[0] !== hidden || $[1] !== onClick || $[2] !== viewBlameShortcut || $[3] !== viewable) {
		t1 = viewable ? jsxs(Fragment$1, { children: [jsx(ButtonComponent, {
			"data-hotkey": viewBlameShortcut.hotkey,
			style: hidden ? { display: "none" } : void 0,
			onClick,
			className: NavigationMenu_module_default.Button,
			children: "Blame"
		}), jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: viewBlameShortcut.hotkey,
			onButtonClick: onClick,
			onlyAddHotkeyScopeButton: true
		})] }) : null;
		$[0] = hidden;
		$[1] = onClick;
		$[2] = viewBlameShortcut;
		$[3] = viewable;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
BlameButton.displayName = "BlameButton";
function DeleteActionItem(t0) {
	const $ = c(5);
	const { deleteTooltip, loggedIn, siteNavLoginPath } = t0;
	const { getUrl } = useUrlCreator();
	let t1;
	if ($[0] !== deleteTooltip || $[1] !== getUrl || $[2] !== loggedIn || $[3] !== siteNavLoginPath) {
		t1 = jsx(ActionList.LinkItem, {
			as: Link$1,
			"aria-label": deleteTooltip,
			to: loggedIn ? getUrl({ action: "delete" }) : siteNavLoginPath,
			variant: "danger",
			children: "Delete file"
		});
		$[0] = deleteTooltip;
		$[1] = getUrl;
		$[2] = loggedIn;
		$[3] = siteNavLoginPath;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
DeleteActionItem.displayName = "DeleteActionItem";
var qualifyRef = (ref, refType) => {
	if (refType === "branch") return `refs/heads/${ref}`;
	if (refType === "tag") return `refs/tags/${ref}`;
	return ref;
};
export { RawMenuActionItems as a, downloadFile as c, useAlertTooltip as d, useBlobRendererType as f, DeleteHeaderButtons as i, isBlobPayload as l, BlobHeaderActions as n, ReposHeaderBreadcrumb as o, CodeViewHeaderDataRouter as r, TreeHeaderActions as s, BlobDisplayType as t, qualifyRef as u };
