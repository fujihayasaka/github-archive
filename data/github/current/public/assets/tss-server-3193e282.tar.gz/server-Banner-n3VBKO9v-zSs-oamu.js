import { i as VisuallyHidden, o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { D as CheckCircleIcon, Mi as XIcon, Qr as StopIcon, an as IconButton, cn as InfoIcon, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import React, { forwardRef, useCallback, useEffect } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
function useMergedRefs(...refs) {
	return useCallback((instance) => {
		for (const ref of refs) if (typeof ref === "function") ref(instance);
		else if (ref) ref.current = instance;
	}, refs);
}
var classes = {
	"Banner": "prc-Banner-Banner-IPLJ2",
	"BannerContainer": "prc-Banner-BannerContainer-T-Siu",
	"BannerActions": "prc-Banner-BannerActions-gvCLf",
	"BannerContent": "prc-Banner-BannerContent-LraS2",
	"BannerTitle": "prc-Banner-BannerTitle-T4z0L",
	"BannerIcon": "prc-Banner-BannerIcon-o4ayx",
	"BannerDismiss": "prc-Banner-BannerDismiss-b12FL",
	"BannerActionsContainer": "prc-Banner-BannerActionsContainer-PdBu1"
};
var BannerContext = /* @__PURE__ */ React.createContext(void 0);
var iconForVariant = {
	critical: /* @__PURE__ */ jsx(StopIcon, {}),
	info: /* @__PURE__ */ jsx(InfoIcon, {}),
	success: /* @__PURE__ */ jsx(CheckCircleIcon, {}),
	upsell: /* @__PURE__ */ jsx(InfoIcon, {}),
	warning: /* @__PURE__ */ jsx(AlertIcon, {})
};
var Banner$1 = /* @__PURE__ */ React.forwardRef(function Banner({ "aria-label": label, "aria-labelledby": labelledBy, children, className, description, hideTitle, icon, leadingVisual, onDismiss, primaryAction, secondaryAction, title, variant = "info", actionsLayout = "default", flush = false, ...rest }, forwardRef) {
	const dismissible = !!onDismiss;
	const hasActions = primaryAction || secondaryAction;
	const ref = useMergedRefs(forwardRef, React.useRef(null));
	const supportsCustomIcon = variant === "info" || variant === "upsell";
	const titleId = useId$1();
	const visual = leadingVisual !== null && leadingVisual !== void 0 ? leadingVisual : icon;
	return /* @__PURE__ */ jsx(BannerContext.Provider, {
		value: { titleId },
		children: /* @__PURE__ */ jsxs("section", {
			...rest,
			"aria-labelledby": labelledBy !== null && labelledBy !== void 0 ? labelledBy : label ? void 0 : titleId,
			"aria-label": labelledBy ? void 0 : label,
			className: clsx(className, classes.Banner),
			"data-dismissible": onDismiss ? "" : void 0,
			"data-has-actions": hasActions ? "" : void 0,
			"data-title-hidden": hideTitle ? "" : void 0,
			"data-variant": variant,
			"data-actions-layout": actionsLayout,
			tabIndex: -1,
			ref,
			"data-layout": rest.layout || "default",
			"data-flush": flush ? "" : void 0,
			children: [
				/* @__PURE__ */ jsx("div", {
					className: classes.BannerIcon,
					children: visual && supportsCustomIcon ? visual : iconForVariant[variant]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: classes.BannerContainer,
					children: [/* @__PURE__ */ jsxs("div", {
						className: classes.BannerContent,
						children: [
							title ? hideTitle ? /* @__PURE__ */ jsx(VisuallyHidden, { children: /* @__PURE__ */ jsx(BannerTitle, { children: title }) }) : /* @__PURE__ */ jsx(BannerTitle, { children: title }) : null,
							description ? /* @__PURE__ */ jsx(BannerDescription, { children: description }) : null,
							children
						]
					}), hasActions ? /* @__PURE__ */ jsx(BannerActions, {
						primaryAction,
						secondaryAction
					}) : null]
				}),
				dismissible ? /* @__PURE__ */ jsx(IconButton, {
					"aria-label": "Dismiss banner",
					onClick: onDismiss,
					className: classes.BannerDismiss,
					icon: XIcon,
					variant: "invisible"
				}) : null
			]
		})
	});
});
function BannerTitle(props) {
	const { as: Heading = "h2", className, children, id, ...rest } = props;
	const context = React.useContext(BannerContext);
	const titleId = id !== null && id !== void 0 ? id : context === null || context === void 0 ? void 0 : context.titleId;
	return /* @__PURE__ */ jsx(Heading, {
		...rest,
		id: titleId,
		className: clsx(className, classes.BannerTitle),
		"data-banner-title": "",
		children
	});
}
BannerTitle.displayName = "BannerTitle";
function BannerDescription({ children, className, ...rest }) {
	return /* @__PURE__ */ jsx("div", {
		...rest,
		className: clsx("BannerDescription", className),
		children
	});
}
BannerDescription.displayName = "BannerDescription";
function BannerActions({ primaryAction, secondaryAction }) {
	return /* @__PURE__ */ jsxs("div", {
		className: classes.BannerActions,
		children: [/* @__PURE__ */ jsxs("div", {
			className: classes.BannerActionsContainer,
			"data-primary-action": "trailing",
			children: [secondaryAction !== null && secondaryAction !== void 0 ? secondaryAction : null, primaryAction !== null && primaryAction !== void 0 ? primaryAction : null]
		}), /* @__PURE__ */ jsxs("div", {
			className: classes.BannerActionsContainer,
			"data-primary-action": "leading",
			children: [primaryAction !== null && primaryAction !== void 0 ? primaryAction : null, secondaryAction !== null && secondaryAction !== void 0 ? secondaryAction : null]
		})]
	});
}
BannerActions.displayName = "BannerActions";
var BannerPrimaryAction = /* @__PURE__ */ forwardRef(({ children, className, ...rest }, forwardedRef) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		ref: forwardedRef,
		className: clsx("BannerPrimaryAction", className),
		variant: "default",
		...rest,
		children
	});
});
BannerPrimaryAction.displayName = "BannerPrimaryAction";
var BannerSecondaryAction = /* @__PURE__ */ forwardRef(({ children, className, ...rest }, forwardedRef) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		ref: forwardedRef,
		className: clsx("BannerPrimaryAction", className),
		variant: "invisible",
		...rest,
		children
	});
});
BannerSecondaryAction.displayName = "BannerSecondaryAction";
var Banner = Object.assign(Banner$1, {
	Title: BannerTitle,
	Description: BannerDescription,
	PrimaryAction: BannerPrimaryAction,
	SecondaryAction: BannerSecondaryAction
});
export { useMergedRefs as n, Banner as t };
