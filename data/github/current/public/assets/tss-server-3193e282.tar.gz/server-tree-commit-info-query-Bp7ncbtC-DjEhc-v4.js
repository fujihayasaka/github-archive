import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as QueryRouteQueryType } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
var latestCommitQuery = {
	queryName: "latestCommit",
	queryDeps: ({ params: routeParams }) => {
		const params = routeParams;
		return { pathname: repositoryTreePath({
			repo: {
				ownerLogin: params.owner,
				name: params.repo
			},
			commitish: params.branch,
			path: params["*"],
			action: "latest-commit"
		}) };
	},
	queryFn: async (queryKey) => queryFnFetch(queryKey),
	type: QueryRouteQueryType.Deferred
};
var treeCommitInfoQuery = {
	queryName: "treeCommitInfo",
	queryDeps: ({ params: routeParams }) => {
		const params = routeParams;
		return { pathname: repositoryTreePath({
			repo: {
				ownerLogin: params.owner,
				name: params.repo
			},
			commitish: params.branch,
			path: params["*"],
			action: "tree-commit-info"
		}) };
	},
	queryFn: async (queryKey) => queryFnFetch(queryKey),
	type: QueryRouteQueryType.Deferred
};
export { treeCommitInfoQuery as n, latestCommitQuery as t };
