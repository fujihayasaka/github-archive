/**
* A function that always returns undefined and does nothing else.
*/
var noop = () => void 0;
export { noop as t };
