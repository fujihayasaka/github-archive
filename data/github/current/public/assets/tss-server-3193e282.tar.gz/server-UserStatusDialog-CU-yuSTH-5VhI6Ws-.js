performance.mark("js-parse-end:server-UserStatusDialog-CU-yuSTH-5VhI6Ws-.js");
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { Rr as SmileyIcon, an as IconButton, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { a as Token, r as Select$1, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { a as useEmojiSuggestions, i as useAutocompleteTriggersAndSuggestions, n as isUnicodeEmoji, o as useMentionSuggestions, t as getUnicodeEmojiContent } from "./server-use-mention-suggestions-CJBNKUGO-wdkkDgZ6.js";
import { t as InlineAutocomplete } from "./server-InlineAutocomplete-ByKImo4X-BNUEsRr4.js";
import { t as useExternalAnchor } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import { t as useEmojisQuery } from "./server-use-emojis-query-C5iJFZbs-B6tC0vOQ.js";
import { t as Emoji } from "./server-Emoji-BFUUoP8k-D2ScGNcm.js";
import React, { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { useVirtualizer } from "@tanstack/react-virtual";
performance.mark("js-parse-end:UserStatusDialog-CU-yuSTH.js");
/**
* Fetches mention suggestions for user status input.
* @param enabled - Whether to execute the query
* @param organization - Optional organization context to filter suggestions
* @returns Query result with formatted mentionable suggestions
*/
function useMentionsQuery(enabled, organization) {
	const $ = c(9);
	const pathname = organization?.globalRelayId ? `/suggestions?mention_suggester=1&global_id=${organization.globalRelayId}` : "/autocomplete/user-suggestions";
	let t0;
	if ($[0] !== organization || $[1] !== pathname) {
		t0 = organization?.globalRelayId ? [
			"autocomplete-user-mentions-for-status-dialog",
			organization.globalRelayId,
			pathname
		] : ["autocomplete-user-mentions-for-status-dialog", pathname];
		$[0] = organization;
		$[1] = pathname;
		$[2] = t0;
	} else t0 = $[2];
	const queryKey = t0;
	let t1;
	if ($[3] !== pathname) {
		t1 = () => queryFnFetch({ queryDeps: { pathname } });
		$[3] = pathname;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== enabled || $[6] !== queryKey || $[7] !== t1) {
		t2 = {
			queryKey,
			enabled,
			queryFn: t1,
			select: _temp3$1
		};
		$[5] = enabled;
		$[6] = queryKey;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return useQuery(t2);
}
function _temp3$1(data) {
	return data.filter(_temp$2).map(_temp2$1);
}
function _temp2$1(t0) {
	const { login, name } = t0;
	return {
		identifier: login,
		description: name ?? login
	};
}
function _temp$2(item) {
	return item.login;
}
var SUGGESTION_TYPES = {
	EMOJI: "emoji",
	MENTIONS: "mentions"
};
var emptyArray = [];
var EditStatusAutoComplete = ({ ref, defaultValue, organization, tone, setInputValue }) => {
	const [suggesting, setSuggesting] = useState(void 0);
	const emojiQuery = useEmojisQuery(suggesting === SUGGESTION_TYPES.EMOJI);
	const mentionSuggestions = useMentionsQuery(suggesting === SUGGESTION_TYPES.MENTIONS, organization);
	const { calculateSuggestions: calculateEmojiSuggestions, trigger: emojiTrigger } = useEmojiSuggestions(emojiQuery.isPending ? "loading" : emojiQuery.data ?? emptyArray, { tone });
	const { trigger: mentionsTrigger, calculateSuggestions: calculateMentionSuggestions } = useMentionSuggestions(mentionSuggestions.isPending ? "loading" : mentionSuggestions.data ?? emptyArray);
	const { triggers, suggestions, setSuggestionEvent } = useAutocompleteTriggersAndSuggestions(useMemo(() => [{
		trigger: emojiTrigger,
		suggestionsCalculator: calculateEmojiSuggestions
	}, {
		trigger: mentionsTrigger,
		suggestionsCalculator: calculateMentionSuggestions
	}], [
		emojiTrigger,
		calculateEmojiSuggestions,
		mentionsTrigger,
		calculateMentionSuggestions
	]));
	return /* @__PURE__ */ jsx(InlineAutocomplete, {
		inputRef: ref,
		fullWidth: true,
		triggers,
		suggestions,
		onShowSuggestions: (event) => {
			setSuggestionEvent(event);
			switch (event.trigger.triggerChar) {
				case emojiTrigger.triggerChar:
					setSuggesting(SUGGESTION_TYPES.EMOJI);
					break;
				case mentionsTrigger.triggerChar:
					setSuggesting(SUGGESTION_TYPES.MENTIONS);
					break;
				default:
					setSuggesting(void 0);
					break;
			}
		},
		onHideSuggestions: () => {
			setSuggestionEvent(null);
			setSuggesting(void 0);
		},
		children: /* @__PURE__ */ jsx(TextInput$1, {
			block: true,
			name: "message",
			defaultValue,
			characterLimit: 80,
			maxLength: 80,
			onChange: useCallback((e) => {
				setInputValue?.(e.target.value);
			}, [setInputValue]),
			"data-testid": "user-status-message-input"
		})
	});
};
EditStatusAutoComplete.displayName = "EditStatusAutoComplete";
EditStatusAutoComplete.displayName = "EditStatusAutoComplete";
/**
* Fetches status emojis for user status dialog.
* @returns Query result with formatted status emojis
*/
function useStatusEmojiQuery() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			queryKey: ["user-status-emojis-for-status-dialog"],
			refetchOnMount: false,
			refetchOnWindowFocus: false,
			refetchOnReconnect: false,
			staleTime: Infinity,
			queryFn: _temp$1,
			select: _temp3
		};
		$[0] = t0;
	} else t0 = $[0];
	return useQuery(t0);
}
function _temp3(data) {
	return data.map(_temp2);
}
function _temp2(emoji) {
	if (emoji.unicode_aliases.length > 0) return {
		name: emoji.name,
		character: emoji.unicode_aliases[0],
		url: emoji.image_url
	};
	return {
		name: emoji.name,
		url: emoji.image_url
	};
}
function _temp$1() {
	return queryFnFetch({ queryDeps: { pathname: "/users/status/emoji.json" } });
}
var UserStatusDialog_module_default = {
	emojiPickerButton: "UserStatusDialog-module_HQ81cG_emojiPickerButton",
	statusCaption: "UserStatusDialog-module_HQ81cG_statusCaption",
	statusContainer: "UserStatusDialog-module_HQ81cG_statusContainer",
	statusFormControl: "UserStatusDialog-module_HQ81cG_statusFormControl",
	suggestionChip: "UserStatusDialog-module_HQ81cG_suggestionChip",
	suggestionChipEmoji: "UserStatusDialog-module_HQ81cG_suggestionChipEmoji",
	suggestionChipsContainer: "UserStatusDialog-module_HQ81cG_suggestionChipsContainer",
	whatsHappeningHeading: "UserStatusDialog-module_HQ81cG_whatsHappeningHeading"
};
var DEFAULT_VIRTUAL_ITEM_HEIGHT = 32;
var createEmojiVisual = (emoji, tone) => {
	if (isUnicodeEmoji(emoji)) {
		const EmojiVisual = () => getUnicodeEmojiContent(emoji, tone);
		EmojiVisual.displayName = `UnicodeEmoji_${emoji.name}`;
		return EmojiVisual;
	}
	const { url, name } = emoji;
	const EmojiVisual = () => /* @__PURE__ */ jsx("img", {
		src: url,
		alt: `${name} emoji`,
		height: "16",
		width: "16"
	});
	EmojiVisual.displayName = `CustomEmoji_${name}`;
	return EmojiVisual;
};
var EmojiPicker = (props) => {
	const { tone, value, setValue } = props;
	const [open, setOpen] = useState(false);
	const [scrollContainer, setScrollContainer] = useState(null);
	const [_filter, setFilter] = useState(void 0);
	const emojisQuery = useStatusEmojiQuery();
	const items = useMemo(() => emojisQuery.isPending || !emojisQuery.data ? [] : emojisQuery.data.map((emoji) => ({
		text: emoji.name,
		id: emoji.name,
		leadingVisual: createEmojiVisual(emoji, tone)
	})), [
		emojisQuery.data,
		emojisQuery.isPending,
		tone
	]);
	const filteredItems = useMemo(() => {
		if (!_filter || _filter.trim() === "") return items;
		const lowerFilter = _filter.toLowerCase();
		return items.filter((item) => item.text?.toLowerCase().includes(lowerFilter));
	}, [_filter, items]);
	const virtualizer = useVirtualizer({
		count: filteredItems.length,
		getScrollElement: () => scrollContainer ?? null,
		estimateSize: () => DEFAULT_VIRTUAL_ITEM_HEIGHT,
		overscan: 10,
		getItemKey: (index) => filteredItems[index]?.id ?? index,
		measureElement: (el) => {
			return el.scrollHeight;
		}
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("input", {
		type: "hidden",
		name: "emoji",
		value: value?.id ? `:${value.id}:` : "",
		"data-testid": "user-status-emoji-input"
	}), /* @__PURE__ */ jsx(SelectPanel, {
		title: "Select an Emoji",
		initialLoadingType: "spinner",
		loading: emojisQuery.isPending,
		id: "user-status-emoji-picker-button",
		renderAnchor: ({ children, ...anchorProps }) => /* @__PURE__ */ jsx(IconButton, {
			...anchorProps,
			"aria-label": value?.text ? `Select an emoji: :${value?.text}:` : "Select an emoji",
			"aria-haspopup": "dialog",
			icon: value?.leadingVisual ?? SmileyIcon,
			"data-testid": "user-status-emoji-picker-button",
			className: UserStatusDialog_module_default.emojiPickerButton
		}),
		open,
		onOpenChange: setOpen,
		placeholderText: "Filter Emojis",
		items: virtualizer.getVirtualItems().map((virtualItem) => {
			const item_0 = filteredItems[virtualItem.index];
			return {
				...item_0,
				key: item_0?.id,
				"data-index": virtualItem.index,
				style: {
					position: "absolute",
					top: 0,
					left: 0,
					width: "calc(100% - 16px)",
					height: `${virtualItem.size}px`,
					transform: `translateY(${virtualItem.start}px)`
				},
				ref: (node) => {
					if (node && node.getAttribute("data-index")) virtualizer.measureElement(node);
				}
			};
		}),
		selected: value,
		onSelectedChange: setValue,
		onFilterChange: setFilter,
		focusOutBehavior: "stop",
		onActiveDescendantChanged: useCallback((newActiveDescendant) => {
			const index_0 = newActiveDescendant?.getAttribute("data-index");
			const range = virtualizer.range;
			if (index_0 && range && (Number(index_0) < range.startIndex || Number(index_0) >= range.endIndex)) virtualizer.scrollToIndex(Number(index_0), { align: "auto" });
		}, [virtualizer]),
		scrollContainerRef: (node_0) => setScrollContainer(node_0),
		actionListProps: { style: {
			maxHeight: 300,
			height: virtualizer.getTotalSize(),
			width: "100%",
			position: "relative"
		} },
		secondaryAction: /* @__PURE__ */ jsx(SelectPanel.SecondaryActionButton, {
			onClick: () => {
				setValue(void 0);
				setOpen(false);
			},
			"data-testid": "user-status-emoji-clear-button",
			children: "Clear emoji"
		})
	})] });
};
EmojiPicker.displayName = "EmojiPicker";
var NEVER_VALUE = " ";
var ExpirationSelect = (t0) => {
	const $ = c(10);
	let t1;
	if ($[0] !== t0) {
		const { expiresIn, expiresAt, expirationIntervals, ...rest } = t0;
		let t2;
		if ($[2] !== expirationIntervals || $[3] !== expiresIn) {
			t2 = expiresIn && expirationIntervals?.some((interval) => interval.label === expiresIn);
			$[2] = expirationIntervals;
			$[3] = expiresIn;
			$[4] = t2;
		} else t2 = $[4];
		const hasMatchingExpirationInterval = Boolean(t2);
		let t3;
		if ($[5] !== expirationIntervals || $[6] !== expiresAt || $[7] !== expiresIn || $[8] !== hasMatchingExpirationInterval) {
			t3 = hasMatchingExpirationInterval ? expirationIntervals?.find((interval_0) => interval_0.label === expiresIn)?.time : expiresAt || NEVER_VALUE;
			$[5] = expirationIntervals;
			$[6] = expiresAt;
			$[7] = expiresIn;
			$[8] = hasMatchingExpirationInterval;
			$[9] = t3;
		} else t3 = $[9];
		t1 = jsxs(Select$1, {
			block: true,
			name: "expires_at",
			defaultValue: t3,
			"data-testid": "user-status-expiration-select",
			...rest,
			children: [
				jsx(Select$1.Option, {
					value: NEVER_VALUE,
					children: "Never"
				}),
				expirationIntervals?.map(_temp),
				!hasMatchingExpirationInterval && expiresAt && expiresIn && jsx(Select$1.Option, {
					value: expiresAt,
					children: expiresIn.charAt(0).toUpperCase() + expiresIn.slice(1)
				})
			]
		});
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
};
ExpirationSelect.displayName = "ExpirationSelect";
ExpirationSelect.__SLOT__ = Select$1.__SLOT__;
function _temp(t0) {
	const { label, time } = t0;
	return jsx(Select$1.Option, {
		value: time,
		children: label.charAt(0).toUpperCase() + label.slice(1)
	}, time);
}
var EVERYONE_VALUE = " ";
var OrganizationSelect = ({ defaultValue, organizationOptions, ...rest }) => {
	return /* @__PURE__ */ jsxs(Select$1, {
		block: true,
		name: "organization_id",
		defaultValue: defaultValue ?? EVERYONE_VALUE,
		"data-testid": "user-status-organization-select",
		...rest,
		children: [/* @__PURE__ */ jsx(Select$1.Option, {
			value: EVERYONE_VALUE,
			children: "Everyone"
		}), organizationOptions.map(({ value, label }) => /* @__PURE__ */ jsx(Select$1.Option, {
			value,
			children: label
		}, value))]
	});
};
OrganizationSelect.displayName = "OrganizationSelect";
OrganizationSelect.__SLOT__ = Select$1.__SLOT__;
var defaultCategory$1 = "USER_STATUS_DIALOG";
var SuggestionChips = (props) => {
	const $ = c(13);
	const { updateInputs, suggestions, inputValue, emojiValue, tone } = props;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t0;
	if ($[0] !== emojiValue?.id || $[1] !== inputValue || $[2] !== sendClickAnalyticsEvent || $[3] !== suggestions || $[4] !== tone || $[5] !== updateInputs) {
		let t1;
		if ($[7] !== emojiValue?.id || $[8] !== inputValue || $[9] !== sendClickAnalyticsEvent || $[10] !== tone || $[11] !== updateInputs) {
			t1 = (suggestion) => {
				const classes = clsx(suggestion.emojiAttributes.attributes.class, UserStatusDialog_module_default.suggestionChipEmoji);
				return jsx(Token, {
					className: UserStatusDialog_module_default.suggestionChip,
					as: "button",
					type: "button",
					"aria-pressed": inputValue === suggestion.message && emojiValue?.id === suggestion.emojiAttributes.name,
					onClick: () => {
						sendClickAnalyticsEvent({
							category: defaultCategory$1,
							action: "SET_SUGGESTED_USER_STATUS",
							label: suggestion.message
						});
						updateInputs({
							emoji: suggestion.emojiAttributes,
							message: suggestion.message
						});
					},
					leadingVisual: () => jsx(Emoji, {
						...suggestion.emojiAttributes,
						attributes: {
							...suggestion.emojiAttributes.attributes,
							class: classes
						},
						tone
					}),
					text: suggestion.message
				}, suggestion.message);
			};
			$[7] = emojiValue?.id;
			$[8] = inputValue;
			$[9] = sendClickAnalyticsEvent;
			$[10] = tone;
			$[11] = updateInputs;
			$[12] = t1;
		} else t1 = $[12];
		t0 = jsx("div", {
			className: UserStatusDialog_module_default.suggestionChipsContainer,
			children: suggestions.map(t1)
		});
		$[0] = emojiValue?.id;
		$[1] = inputValue;
		$[2] = sendClickAnalyticsEvent;
		$[3] = suggestions;
		$[4] = tone;
		$[5] = updateInputs;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
};
SuggestionChips.displayName = "SuggestionChips";
var defaultCategory = "USER_STATUS_DIALOG";
async function saveUserStatus(body) {
	body.set("_method", "put");
	return (await verifiedFetch("/users/status", {
		method: "POST",
		headers: {
			...getBaseFetchHeaders(),
			Accept: "application/json"
		},
		body
	})).json();
}
function useFocus() {
	const $ = c(3);
	const [focusTarget, setFocusTarget] = useState(null);
	let t0;
	let t1;
	if ($[0] !== focusTarget) {
		t0 = () => {
			if (focusTarget === null) return;
			if (focusTarget.current) focusTarget.current.focus();
			setFocusTarget(null);
		};
		t1 = [focusTarget];
		$[0] = focusTarget;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	return setFocusTarget;
}
var getEmojiValue = (emojiAttributes, tone) => {
	if (!emojiAttributes) return;
	return {
		text: emojiAttributes.name,
		id: emojiAttributes.name,
		leadingVisual: () => /* @__PURE__ */ jsx(Emoji, {
			...emojiAttributes,
			tone
		})
	};
};
var UserStatusDialog = ({ ref, onClose, userPreferences, userStatusData, returnFocusRef }) => {
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const bannerRef = useRef(null);
	const [showBanner, setShowBanner] = useState(false);
	const [selectedOrganization, setSelectedOrganization] = useState(userStatusData?.organization);
	const [inputValue, setInputValue] = useState(userStatusData?.message || "");
	const inputRef = useRef(null);
	const [emojiValue, setEmojiValue] = useState(useMemo(() => getEmojiValue(userStatusData?.emojiAttributes, userPreferences?.tone), [userStatusData, userPreferences]));
	const formId = useId();
	const focus = useFocus();
	const formSubmissionCustomEventInternal = useCallback(async (statusResponse) => {
		if (statusResponse instanceof Promise) try {
			const response = await statusResponse;
			const eventDetail = {
				emojiAttributes: typeof response.emojiAttributes === "object" && response.emojiAttributes !== null ? response.emojiAttributes : "",
				message: response.message ?? ""
			};
			const event = new CustomEvent("react-user-status-dialog:submit", {
				bubbles: true,
				detail: eventDetail
			});
			document.querySelector(".js-user-status-container")?.dispatchEvent(event);
		} catch (error) {
			console.error("Failed to save user status:", error);
		}
		onClose(statusResponse);
	}, [onClose]);
	const onFormSubmit = useCallback((e) => {
		e.preventDefault();
		const data = new FormData(e.target);
		if ([...data.entries()].filter(([_, value]) => {
			if (typeof value === "string") return value.trim() !== "";
			return value;
		}).length && !data.get("emoji") && !data.get("message")) {
			setShowBanner(true);
			focus(bannerRef);
			return;
		}
		sendClickAnalyticsEvent({
			category: defaultCategory,
			action: "SET_USER_STATUS"
		});
		formSubmissionCustomEventInternal(saveUserStatus(data));
	}, [
		formSubmissionCustomEventInternal,
		sendClickAnalyticsEvent,
		focus,
		bannerRef
	]);
	const onClearStatus = useCallback(() => {
		sendClickAnalyticsEvent({
			category: defaultCategory,
			action: "CLEAR_USER_STATUS"
		});
		formSubmissionCustomEventInternal(Promise.resolve(saveUserStatus(new FormData())));
	}, [sendClickAnalyticsEvent, formSubmissionCustomEventInternal]);
	const selectSuggestion = useCallback(({ emoji, message }) => {
		setEmojiValue(getEmojiValue(emoji, userPreferences?.tone));
		if (inputRef.current) inputRef.current.value = message;
		setInputValue(message);
	}, [
		setEmojiValue,
		userPreferences,
		inputRef
	]);
	return /* @__PURE__ */ jsxs(Dialog, {
		width: "large",
		title: "Edit status",
		onClose,
		returnFocusRef,
		footerButtons: [{
			buttonType: "normal",
			content: "Clear status",
			onClick: onClearStatus
		}, {
			buttonType: "primary",
			type: "submit",
			content: "Set status",
			form: formId
		}],
		ref,
		children: [showBanner && /* @__PURE__ */ jsx(Banner, {
			variant: "critical",
			className: "tmp-mb-3",
			ref: bannerRef,
			...testIdProps("user-status-error-banner"),
			children: /* @__PURE__ */ jsxs(Banner.Title, { children: [
				"Either an",
				" ",
				/* @__PURE__ */ jsx(Link, {
					href: "#user-status-emoji-picker-button",
					inline: true,
					children: "Emoji"
				}),
				" ",
				"or a",
				" ",
				/* @__PURE__ */ jsx(Link, {
					href: "#user-status-status-input",
					inline: true,
					children: "Status"
				}),
				" ",
				"is required."
			] })
		}), /* @__PURE__ */ jsx("form", {
			id: formId,
			onSubmit: onFormSubmit,
			className: "user-status-dialog-fragment js-user-status-container",
			children: userStatusData !== void 0 ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
				/* @__PURE__ */ jsx("h2", {
					className: UserStatusDialog_module_default.whatsHappeningHeading,
					children: "What's happening"
				}),
				/* @__PURE__ */ jsxs("div", {
					className: UserStatusDialog_module_default.statusContainer,
					children: [/* @__PURE__ */ jsx(EmojiPicker, {
						tone: userPreferences?.tone || 0,
						value: emojiValue,
						setValue: setEmojiValue
					}), /* @__PURE__ */ jsxs(FormControl$1, {
						className: UserStatusDialog_module_default.statusFormControl,
						id: "user-status-status-input",
						children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
							visuallyHidden: true,
							children: "Status"
						}), /* @__PURE__ */ jsx(EditStatusAutoComplete, {
							ref: inputRef,
							setInputValue,
							defaultValue: userStatusData?.message || "",
							organization: selectedOrganization,
							tone: userPreferences?.tone || 0
						})]
					})]
				}),
				userStatusData?.suggestions && /* @__PURE__ */ jsx(SuggestionChips, {
					updateInputs: selectSuggestion,
					suggestions: userStatusData?.suggestions,
					inputValue,
					emojiValue,
					tone: userPreferences?.tone || 0
				}),
				/* @__PURE__ */ jsxs(FormControl$1, {
					className: "border-bottom tmp-pb-3 mb-2",
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Busy" }),
						/* @__PURE__ */ jsx(Checkbox, {
							value: "1",
							name: "limited_availability",
							defaultChecked: userStatusData?.limitedAvailability || false,
							...testIdProps("user-status-limited-availability-checkbox"),
							onChange: (e_0) => {
								sendClickAnalyticsEvent({
									category: defaultCategory,
									action: "SET_BUSY_USER_STATUS",
									label: e_0.target.checked ? "true" : "false"
								});
							}
						}),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "When others mention you, assign you, or request your review, GitHub will let them know that you have limited availability." })
					]
				}),
				/* @__PURE__ */ jsxs(FormControl$1, {
					className: "mb-2",
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Expiration" }),
						/* @__PURE__ */ jsx(ExpirationSelect, {
							expiresIn: userStatusData?.expiresIn,
							expiresAt: userStatusData?.expiresAt,
							expirationIntervals: userStatusData?.expirationIntervals
						}),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Your status will be cleared after the selected time." })
					]
				}),
				userStatusData?.organizationOptions !== void 0 && /* @__PURE__ */ jsxs(FormControl$1, { children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Visible to" }),
					/* @__PURE__ */ jsx(OrganizationSelect, {
						defaultValue: userStatusData?.organization?.id,
						organizationOptions: userStatusData?.organizationOptions,
						onChange: (e_1) => {
							const selectedOrg = userStatusData?.organizationOptions?.find((org) => org.value.toString() === e_1.target.value);
							setSelectedOrganization(selectedOrg ? {
								id: selectedOrg.value,
								globalRelayId: selectedOrg.globalRelayId
							} : void 0);
						}
					}),
					/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Limit status visibility to a single organization." })
				] })
			] }) : /* @__PURE__ */ jsx("p", {
				className: "text-center tmp-mt-3",
				children: /* @__PURE__ */ jsx(Spinner, {
					delay: true,
					srText: "Loading user status"
				})
			})
		})]
	});
};
UserStatusDialog.displayName = "UserStatusDialog";
UserStatusDialog.displayName = "UserStatusDialog";
function ExternallyAnchoredUserStatusDialog(props) {
	const $ = c(7);
	const { ref: anchorRef, open, setOpen } = useExternalAnchor(props.reactPartialAnchor);
	let t0;
	if ($[0] !== setOpen) {
		t0 = () => {
			setOpen(false);
		};
		$[0] = setOpen;
		$[1] = t0;
	} else t0 = $[1];
	const onClose = t0;
	let t1;
	if ($[2] !== anchorRef || $[3] !== onClose || $[4] !== open || $[5] !== props) {
		t1 = open ? jsx(UserStatusDialog, {
			returnFocusRef: anchorRef,
			onClose,
			...props
		}) : null;
		$[2] = anchorRef;
		$[3] = onClose;
		$[4] = open;
		$[5] = props;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
ExternallyAnchoredUserStatusDialog.displayName = "ExternallyAnchoredUserStatusDialog";
function UserStatusDialogPartial(props) {
	if (props.reactPartialAnchor) return /* @__PURE__ */ jsx(ExternallyAnchoredUserStatusDialog, {
		reactPartialAnchor: props.reactPartialAnchor,
		...props
	});
	return null;
}
UserStatusDialogPartial.displayName = "UserStatusDialogPartial";
export { UserStatusDialog };
