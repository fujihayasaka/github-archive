import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { r as fileTreeQuery } from "./server-file-tree-query-BoZ7HlYc-BElKzBR6.js";
import { n as treeCommitInfoQuery, t as latestCommitQuery } from "./server-tree-commit-info-query-Bp7ncbtC-DjEhc-v4.js";
var codeViewTreeRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewTreeRoute", {
	path: "/:owner/:repo/tree/:branch/*",
	queries: [
		mainQuery({
			queryDeps: ({ pathname, searchParams }) => ({
				pathname,
				searchParams: {
					search: searchParams.get("search"),
					files: searchParams.get("files")
				}
			}),
			encodeFetchPath: true
		}),
		fileTreeQuery,
		latestCommitQuery,
		treeCommitInfoQuery
	]
});
export { codeViewTreeRoute as t };
