import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { c } from "react/compiler-runtime";
var callbackCancelledResult = Symbol("callbackCancelledResult");
/**
* Making async callbacks within React components is risky and error-prone. It's easy to
* accidentally call an outdated reference to the function, or to call it after the
* component has unmounted.
*
* This hook solves these problems by returning a function that is referentially constant
* (it can never be outdated) and will have no effect if called after unmounting. If the
* callback is cancelled due to calling after unmounting, the returned value will be
* the unique symbol `callbackCancelledResult`.
*
* This callback is safe to call after `await`ing a `Promise` (or in the `.then` clause of a
* `Promise`) and in `setTimeout`.
*
* @param fn the function to call
* @param allowCallingAfterUnmount If the component is unmounted, should this be called?
* This should typically be `false` but may be desirable in cases where user's changes would
* not get saved unless the call is made, so the call can be made in the background after
* unmount. If this is `true`, it's very important not to set state in this callback!
*/
var useSafeAsyncCallback = (fn, t0) => {
	const $ = c(7);
	const allowCallingAfterUnmount = t0 === void 0 ? false : t0;
	const trackingRef = useRef(fn);
	let t1;
	let t2;
	if ($[0] !== fn) {
		t1 = () => {
			trackingRef.current = fn;
		};
		t2 = [fn];
		$[0] = fn;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useLayoutEffect(t1, t2);
	const isMountedRef = useRef(false);
	let t3;
	let t4;
	if ($[3] !== allowCallingAfterUnmount) {
		t3 = () => {
			isMountedRef.current = true;
			return () => {
				if (!allowCallingAfterUnmount) isMountedRef.current = false;
			};
		};
		t4 = [allowCallingAfterUnmount];
		$[3] = allowCallingAfterUnmount;
		$[4] = t3;
		$[5] = t4;
	} else {
		t3 = $[4];
		t4 = $[5];
	}
	useEffect(t3, t4);
	let t5;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = (...t6) => {
			const args = t6;
			return isMountedRef.current ? trackingRef.current(...args) : callbackCancelledResult;
		};
		$[6] = t5;
	} else t5 = $[6];
	return t5;
};
/** Matches a MIME type in `type/subtype` or `type/subtype;params` form (ignoring params). */
var mimeTypeRegex = /^([^/]+)\/([^;]+)/;
/** Returns a function that can check if a file matches the file type. */
var fileTypeMatcher = (fileType) => {
	if (fileType.startsWith(".")) return (file) => file.name.toLowerCase().endsWith(fileType.toLowerCase());
	else {
		const mimeTypeMatch = mimeTypeRegex.exec(fileType);
		if (mimeTypeMatch === null) return () => false;
		const [, targetType, targetSubtype] = mimeTypeMatch;
		return (file) => {
			const [, type, subType] = mimeTypeRegex.exec(file.type) ?? [];
			return targetType?.toLowerCase() === type?.toLowerCase() && (targetSubtype === "*" || targetSubtype?.toLowerCase() === subType?.toLowerCase());
		};
	}
};
function useOnSelectFiles(props) {
	const matchers = useMemo(() => props.acceptedFileTypes?.map(fileTypeMatcher), [props.acceptedFileTypes]);
	const isAcceptableFile = useCallback((file) => matchers?.some((m) => m(file)) ?? true, [matchers]);
	return useCallback(function onSelectFiles(files) {
		if (files.length === 0) return false;
		if (props.multi) {
			const accepted = [];
			const rejected = [];
			for (const file of files) if (isAcceptableFile(file)) accepted.push(file);
			else rejected.push(file);
			props.onSelect(accepted, rejected);
		} else {
			const file = files[0];
			if (file && isAcceptableFile(file)) props.onSelect(file, void 0);
			else props.onSelect(void 0, file);
		}
		return true;
	}, [
		isAcceptableFile,
		props.multi,
		props.onSelect
	]);
}
/**
* Provides event handlers for all types of file upload targets, unifying events into a
* single `onSelect` event. Does not manage its own state as far as which files are
* currently selected - this should be done in the parent component.
*/
function useUnifiedFileSelect(props) {
	const $ = c(5);
	const clickTargetProps = useClickFileSelect(props);
	const pasteTargetProps = usePasteFileSelect(props);
	const [isDraggedOver, dropTargetProps] = useDropFileSelect(props);
	let t0;
	if ($[0] !== clickTargetProps || $[1] !== dropTargetProps || $[2] !== isDraggedOver || $[3] !== pasteTargetProps) {
		t0 = {
			clickTargetProps,
			pasteTargetProps,
			dropTargetProps,
			isDraggedOver
		};
		$[0] = clickTargetProps;
		$[1] = dropTargetProps;
		$[2] = isDraggedOver;
		$[3] = pasteTargetProps;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
/**
* Provides a click event handler for opening a file select dialog. Calls `onSelect` upon
* completion.
*/
function useClickFileSelect(props) {
	const $ = c(6);
	const onSelectFiles = useOnSelectFiles(props);
	const { multi, acceptedFileTypes } = props;
	let t0;
	if ($[0] !== acceptedFileTypes || $[1] !== multi || $[2] !== onSelectFiles) {
		t0 = () => {
			const fileInput = document.createElement("input");
			fileInput.setAttribute("type", "file");
			fileInput.setAttribute("multiple", multi ? "true" : "false");
			if (acceptedFileTypes) fileInput.setAttribute("accept", acceptedFileTypes.join(", "));
			fileInput.addEventListener("change", (e) => {
				const target = e.target;
				if (target instanceof HTMLInputElement && target.files) onSelectFiles(target.files);
			}, { once: true });
			fileInput.click();
		};
		$[0] = acceptedFileTypes;
		$[1] = multi;
		$[2] = onSelectFiles;
		$[3] = t0;
	} else t0 = $[3];
	const onClick = t0;
	let t1;
	if ($[4] !== onClick) {
		t1 = { onClick };
		$[4] = onClick;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
var isFileDragEvent = (event) => event.dataTransfer.types.includes("Files") || Array.from(event.dataTransfer.items).some((item) => item.kind === "file");
/**
* Provides event handlers for a file drop region. Calls `onSelect` upon drop. Note that
* drop targets alone are not accessible - combine with a click target.
* @return Tuple of `[isDraggedOver, dropTargetProps]` where `isDraggedOver` is true if a valid item
* is dragged over the drop target and `dropTargetProps` should be spread to the drop
* target.
*/
function useDropFileSelect(props) {
	const $ = c(9);
	const onSelectFiles = useOnSelectFiles(props);
	const [isDraggedOver, setIsDraggedOver] = useState(false);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => setIsDraggedOver(false);
		$[0] = t0;
	} else t0 = $[0];
	const onDragLeave = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (event) => {
			if (!isFileDragEvent(event)) return;
			setIsDraggedOver(true);
			event.stopPropagation();
			event.preventDefault();
		};
		$[1] = t1;
	} else t1 = $[1];
	const onDragEnter = t1;
	const onDragOver = _temp;
	let t2;
	if ($[2] !== onSelectFiles) {
		t2 = (event_1) => {
			if (onSelectFiles(event_1.dataTransfer.files)) {
				event_1.preventDefault();
				setIsDraggedOver(false);
			}
		};
		$[2] = onSelectFiles;
		$[3] = t2;
	} else t2 = $[3];
	const onDrop = t2;
	let t3;
	if ($[4] !== onDrop) {
		t3 = {
			onDragEnter,
			onDragOver,
			onDragLeave,
			onDrop
		};
		$[4] = onDrop;
		$[5] = t3;
	} else t3 = $[5];
	const dropTargetProps = t3;
	let t4;
	if ($[6] !== dropTargetProps || $[7] !== isDraggedOver) {
		t4 = [isDraggedOver, dropTargetProps];
		$[6] = dropTargetProps;
		$[7] = isDraggedOver;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
}
/**
* Provides a paste event handler for pasting files. Props should be spread on an element
* with `contenteditable` or a text input/textarea.
*/
function _temp(event_0) {
	if (!isFileDragEvent(event_0)) return;
	event_0.stopPropagation();
	event_0.preventDefault();
	event_0.dataTransfer.dropEffect = "copy";
}
function usePasteFileSelect(props) {
	const $ = c(2);
	const onSelectFiles = useOnSelectFiles(props);
	let t0;
	if ($[0] !== onSelectFiles) {
		t0 = { onPaste: (event) => {
			if (onSelectFiles(event.clipboardData.files)) event.preventDefault();
		} };
		$[0] = onSelectFiles;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
export { useUnifiedFileSelect as i, usePasteFileSelect as n, useSafeAsyncCallback as r, useClickFileSelect as t };
