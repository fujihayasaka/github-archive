performance.mark("js-parse-end:server-latest-commit-query-DsvYyfXy-Dx-XjV7R.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
performance.mark("js-parse-end:latest-commit-query-DsvYyfXy.js");
var latestCommitServerFn_createServerFn_handler = createServerRpc({
	id: "c095f5f847e3e9e85a9cdbf02c3a0a9306f74ec8da2d4181dc43a5b337a1716b",
	name: "latestCommitServerFn",
	filename: "src/routes/code-view/queries/latest-commit-query.ts"
}, (opts) => latestCommitServerFn.__executeServer(opts));
var latestCommitServerFn = createServerFn().inputValidator(queryValidator.base).handler(latestCommitServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_latestCommit"
	});
});
export { latestCommitServerFn_createServerFn_handler };
