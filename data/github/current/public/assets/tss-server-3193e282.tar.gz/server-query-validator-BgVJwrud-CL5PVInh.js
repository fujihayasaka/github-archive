/**
* Pre-built input validators for data router server functions.
*
* Use these with createServerFn().inputValidator() to reduce boilerplate
* while maintaining type safety.
*
* @example
* // Without search params
* createServerFn()
*   .inputValidator(queryValidator.base)
*   .handler(({data}) => { // data.pathname is typed })
*
* @example
* // With search params
* createServerFn()
*   .inputValidator(queryValidator.withSearchParams<{q: string; page: string}>)
*   .handler(({data}) => { // data.pathname, data.searchParams.q are typed })
*/
var queryValidator = {
	base: (data) => data,
	withSearchParams: (data) => data
};
export { queryValidator as t };
