var mapRefType = (ref) => {
	if (!ref) return void 0;
	if (ref.startsWith("refs/tags/")) return "tag";
	if (ref.startsWith("refs/heads/")) return "branch";
};
var qualifyRef = (ref, refType) => {
	if (refType === "branch") return `refs/heads/${ref}`;
	if (refType === "tag") return `refs/tags/${ref}`;
	return ref;
};
var unqualifyRef = (ref) => {
	if (!ref) return void 0;
	if (!mapRefType(ref)) return ref;
	const [, , ...unqualifiedRef] = ref.split("/");
	return unqualifiedRef.join("/");
};
export { unqualifyRef as n, qualifyRef as t };
