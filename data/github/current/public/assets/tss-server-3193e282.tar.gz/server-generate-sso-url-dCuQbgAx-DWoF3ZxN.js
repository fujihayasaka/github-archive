function generateSSOUrl(id, location) {
	const baseUrl = `/orgs/${encodeURIComponent(id)}/sso`;
	const returnTo = location.pathname + location.search + location.hash;
	return `${baseUrl}?return_to=${encodeURIComponent(returnTo)}`;
}
export { generateSSOUrl as t };
