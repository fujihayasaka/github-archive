import { t as createStore } from "./server-create-store-Btv14ieb--F4JqKzo.js";
import { useCallback, useEffect, useRef, useSyncExternalStore } from "react";
import { c } from "react/compiler-runtime";
var { cache, readStorage, writeStorage, resetStorage, subscribe, clearKeys, clearKeysByPrefix, getItemsByPrefix, clearAll: clearAllSessionStorage } = createStore("sessionStorage");
/**
* Clears specified keys from sessionStorage and notifies subscribers
*/
function clearSessionStorage(keys) {
	clearKeys(keys);
}
/**
* Get all items whose keys start with a prefix
*/
function getSessionStorageItemsForKeyPrefix(prefix) {
	return getItemsByPrefix(prefix);
}
/**
* Clear all keys matching a prefix from sessionStorage
*/
function clearSessionStorageByKeyPrefix(prefix) {
	clearKeysByPrefix(prefix);
}
/**
* React hook for sessionStorage with cross-component synchronization.
* Returns [value, setValue, reset] tuple.
*/
function useSessionStorage(key, initialValue) {
	const $ = c(17);
	const initialValueRef = useRef(initialValue);
	let t0;
	if ($[0] !== initialValue) {
		t0 = () => {
			initialValueRef.current = initialValue;
		};
		$[0] = initialValue;
		$[1] = t0;
	} else t0 = $[1];
	useEffect(t0);
	let t1;
	if ($[2] !== initialValue || $[3] !== key) {
		t1 = () => {
			if (!cache.has(key)) readStorage(key, initialValue);
			return cache.get(key);
		};
		$[2] = initialValue;
		$[3] = key;
		$[4] = t1;
	} else t1 = $[4];
	const getSnapshot = t1;
	let t2;
	if ($[5] !== initialValue) {
		t2 = () => initialValue;
		$[5] = initialValue;
		$[6] = t2;
	} else t2 = $[6];
	const getServerSnapshot = t2;
	let t3;
	if ($[7] !== key) {
		t3 = (listener) => subscribe(key, listener);
		$[7] = key;
		$[8] = t3;
	} else t3 = $[8];
	const value = useSyncExternalStore(t3, getSnapshot, getServerSnapshot);
	let t4;
	if ($[9] !== key) {
		t4 = (next) => {
			const current = cache.has(key) ? cache.get(key) : initialValueRef.current;
			const resolved = typeof next === "function" ? next(current) : next;
			if (resolved === void 0) resetStorage(key, initialValueRef.current);
			else writeStorage(key, resolved);
		};
		$[9] = key;
		$[10] = t4;
	} else t4 = $[10];
	const setValue = t4;
	let t5;
	if ($[11] !== key) {
		t5 = () => {
			resetStorage(key, initialValueRef.current);
		};
		$[11] = key;
		$[12] = t5;
	} else t5 = $[12];
	const reset = t5;
	let t6;
	if ($[13] !== reset || $[14] !== setValue || $[15] !== value) {
		t6 = [
			value,
			setValue,
			reset
		];
		$[13] = reset;
		$[14] = setValue;
		$[15] = value;
		$[16] = t6;
	} else t6 = $[16];
	return t6;
}
export { useSessionStorage as i, clearSessionStorageByKeyPrefix as n, getSessionStorageItemsForKeyPrefix as r, clearSessionStorage as t };
