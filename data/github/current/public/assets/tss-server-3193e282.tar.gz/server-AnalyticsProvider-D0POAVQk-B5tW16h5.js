import { t as AnalyticsContext } from "./server-context-CRkr38GV-DyKv_rx3.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
function AnalyticsProvider(t0) {
	const $ = c(7);
	const { children, appName, category, metadata } = t0;
	let t1;
	if ($[0] !== appName || $[1] !== category || $[2] !== metadata) {
		t1 = {
			appName,
			category,
			metadata
		};
		$[0] = appName;
		$[1] = category;
		$[2] = metadata;
		$[3] = t1;
	} else t1 = $[3];
	const value = t1;
	let t2;
	if ($[4] !== children || $[5] !== value) {
		t2 = jsx(AnalyticsContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
AnalyticsProvider.displayName = "AnalyticsProvider";
export { AnalyticsProvider as t };
