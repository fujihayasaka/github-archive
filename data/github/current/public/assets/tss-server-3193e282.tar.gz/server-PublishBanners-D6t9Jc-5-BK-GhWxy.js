import { Mi as XIcon, Nt as FilterIcon, a as AlertFillIcon, an as IconButton, bn as Link, gt as EllipsisIcon, o as AlertIcon, pi as Tooltip$1, tn as HistoryIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { g as useLocation$1, s as isHashNavigation, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as useIsDataRouterEnabled } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { E as commitsPath, S as commitHovercardPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { i as VerifiedHTMLText, n as VerifiedHTMLBox } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { n as useLatestCommit } from "./server-use-latest-commit-CEaptRlH-Dq4wXeZZ.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as NavList } from "./server-NavList-D8uWdChJ-BgWGw1cA.js";
import { a as useCommitChecksStatusDetails, n as ChecksStatusBadge, r as CommitAttribution, t as AuthorAvatar } from "./server-commit-checks-status-DL_0wdeF-D-78JGlw.js";
import { n as useLatestCommitContext } from "./server-LatestCommitContext-D4oQqyj7-DHpYqCjL.js";
import React, { memo, useCallback, useDeferredValue, useEffect, useEffectEvent, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
function SkeletonText({ width, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		style: { width },
		className: "Skeleton Skeleton--text",
		...props,
		children: "\xA0"
	});
}
SkeletonText.displayName = "SkeletonText";
function ReposChecksStatusBadge(t0) {
	const $ = c(4);
	const { status, oid } = t0;
	const [details, fetchDetails] = useCommitChecksStatusDetails(oid, useCurrentRepository());
	let t1;
	if ($[0] !== details || $[1] !== fetchDetails || $[2] !== status) {
		t1 = status ? jsx(ChecksStatusBadge, {
			statusRollup: status,
			combinedStatus: details,
			onWillOpenPopup: fetchDetails,
			size: "small"
		}) : null;
		$[0] = details;
		$[1] = fetchDetails;
		$[2] = status;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
ReposChecksStatusBadge.displayName = "ReposChecksStatusBadge";
var LatestCommit_module_default = {
	Box: "LatestCommit-module_smRmyW_Box",
	Box_1: "LatestCommit-module_smRmyW_Box_1",
	Box_2: "LatestCommit-module_smRmyW_Box_2",
	Box_3: "LatestCommit-module_smRmyW_Box_3",
	IconButton: "LatestCommit-module_smRmyW_IconButton",
	VerifiedHTMLText: "LatestCommit-module_smRmyW_VerifiedHTMLText",
	VerifiedHTMLText_1: "LatestCommit-module_smRmyW_VerifiedHTMLText_1"
};
function LatestCommitSingleLine({ commitCount }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-column border rounded-2 tmp-mb-3 pl-1",
		children: /* @__PURE__ */ jsx(LatestCommitContent, { commitCount })
	});
}
LatestCommitSingleLine.displayName = "LatestCommitSingleLine";
function LatestCommitContent(t0) {
	const $ = c(3);
	const { commitCount } = t0;
	const isDataRouter = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== commitCount || $[1] !== isDataRouter) {
		t1 = isDataRouter ? jsx(LatestCommitContentWithProvider, { commitCount }) : jsx(LatestCommitContentWithFetch, { commitCount });
		$[0] = commitCount;
		$[1] = isDataRouter;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
LatestCommitContent.displayName = "LatestCommitContent";
function LatestCommitContentWithProvider(t0) {
	const $ = c(5);
	const { commitCount } = t0;
	const { latestCommit, isLoading, error } = useLatestCommitContext();
	const t1 = !!error;
	let t2;
	if ($[0] !== commitCount || $[1] !== isLoading || $[2] !== latestCommit || $[3] !== t1) {
		t2 = jsx(LatestCommitContentInternal, {
			latestCommit,
			loading: isLoading,
			error: t1,
			commitCount
		});
		$[0] = commitCount;
		$[1] = isLoading;
		$[2] = latestCommit;
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
LatestCommitContentWithProvider.displayName = "LatestCommitContentWithProvider";
function LatestCommitContentWithFetch(t0) {
	const $ = c(5);
	const { commitCount } = t0;
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const [latestCommit, loading, error] = useLatestCommit(repo.ownerLogin, repo.name, refInfo.name, path);
	let t1;
	if ($[0] !== commitCount || $[1] !== error || $[2] !== latestCommit || $[3] !== loading) {
		t1 = jsx(LatestCommitContentInternal, {
			latestCommit,
			loading,
			error,
			commitCount
		});
		$[0] = commitCount;
		$[1] = error;
		$[2] = latestCommit;
		$[3] = loading;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
LatestCommitContentWithFetch.displayName = "LatestCommitContentWithFetch";
function LatestCommitContentInternal(t0) {
	const $ = c(7);
	const { latestCommit, loading, error, commitCount } = t0;
	const repo = useCurrentRepository();
	const [detailsOpen, setDetailsOpen] = useState(false);
	let t1;
	if ($[0] !== commitCount || $[1] !== detailsOpen || $[2] !== error || $[3] !== latestCommit || $[4] !== loading || $[5] !== repo) {
		t1 = jsxs(Fragment$1, { children: [jsxs("div", {
			className: LatestCommit_module_default.Box,
			children: [
				jsx(ScreenReaderHeading, {
					as: "h2",
					text: "Latest commit"
				}),
				error ? jsx(CommitErrorMessage, {}) : loading ? jsx(SkeletonText, {
					width: 120,
					"data-testid": "loading"
				}) : latestCommit ? jsx(CommitSummary, {
					commit: latestCommit,
					detailsOpen,
					setDetailsOpen,
					repo
				}) : null,
				jsxs("div", {
					className: "d-flex flex-shrink-0 gap-2",
					children: [jsx(LastCommitTimestamp, {
						commit: latestCommit,
						repo
					}), jsx(HistoryLink, {
						commit: latestCommit,
						commitCount,
						detailsOpen,
						setDetailsOpen
					})]
				})
			]
		}), detailsOpen && latestCommit && jsx("div", {
			className: latestCommit.bodyMessageHtml ? "d-flex" : "d-flex d-sm-none",
			children: jsx(CommitDetails, {
				commit: latestCommit,
				repo
			})
		})] });
		$[0] = commitCount;
		$[1] = detailsOpen;
		$[2] = error;
		$[3] = latestCommit;
		$[4] = loading;
		$[5] = repo;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
LatestCommitContentInternal.displayName = "LatestCommitContentInternal";
function CommitErrorMessage() {
	return /* @__PURE__ */ jsxs("span", {
		className: "fgColor-attention",
		"data-testid": "latest-commit-error-message",
		children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertFillIcon }), "\xA0Cannot retrieve latest commit at this time."]
	});
}
CommitErrorMessage.displayName = "CommitErrorMessage";
function CommitSummary({ commit, detailsOpen, setDetailsOpen, repo }) {
	const dataUrl = `data-hovercard-url=${commitHovercardPath({
		owner: repo.ownerLogin,
		repo: repo.name,
		commitish: commit.oid
	})} `;
	const shortMessageHtmlLink = getProperHovercardsOnCommitMessage(commit.shortMessageHtmlLink, dataUrl);
	return /* @__PURE__ */ jsxs("div", {
		"data-testid": "latest-commit",
		className: LatestCommit_module_default.Box_1,
		children: [
			commit.authors && commit.authors.length > 0 ? /* @__PURE__ */ jsx(CommitAttribution, {
				authors: commit.authors,
				repo,
				includeVerbs: false,
				committer: commit.committer,
				committerAttribution: commit.committerAttribution
			}) : /* @__PURE__ */ jsx(AuthorAvatar, {
				author: commit.author,
				repo
			}),
			/* @__PURE__ */ jsxs("div", {
				className: clsx("d-none d-sm-flex", LatestCommit_module_default.Box_2),
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "Truncate flex-items-center f5",
						children: commit.shortMessageHtmlLink && /* @__PURE__ */ jsx(UnsafeHTMLText, {
							className: "Truncate-text",
							"data-testid": "latest-commit-html",
							html: shortMessageHtmlLink
						})
					}),
					commit.bodyMessageHtml && /* @__PURE__ */ jsx(CommitDetailsButton, {
						detailsOpen,
						setDetailsOpen
					}),
					/* @__PURE__ */ jsx(ReposChecksStatusBadge, {
						oid: commit.oid,
						status: commit.status
					})
				]
			}),
			!Number.isNaN(Date.parse(commit.date)) ? /* @__PURE__ */ jsx("span", {
				className: "d-flex d-sm-none fgColor-muted f6",
				children: /* @__PURE__ */ jsx(RelativeTime, {
					datetime: commit.date,
					tense: "past"
				})
			}) : null
		]
	});
}
CommitSummary.displayName = "CommitSummary";
var LastCommitTimestamp = memo(function LastCommitTimestamp(t0) {
	const $ = c(4);
	const { commit, repo } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	if ($[0] !== commit || $[1] !== getHovercardAttributesForType || $[2] !== repo) {
		const abbreviatedOid = commit?.oid.slice(0, 7);
		t1 = jsx("div", {
			"data-testid": "latest-commit-details",
			className: "d-none d-sm-flex flex-items-center",
			children: commit && jsxs("span", {
				className: "d-flex flex-nowrap fgColor-muted f6",
				children: [
					jsx(Link, {
						as: Link$1,
						to: commit.url,
						className: "Link--secondary",
						"aria-label": `Commit ${abbreviatedOid}`,
						...getHovercardAttributesForType("commit", {
							owner: repo.ownerLogin,
							repo: repo.name,
							commitish: commit.oid
						}),
						children: abbreviatedOid
					}),
					"\xA0·\xA0",
					!Number.isNaN(Date.parse(commit.date)) ? jsx(RelativeTime, {
						datetime: commit.date,
						tense: "past"
					}) : null
				]
			})
		});
		$[0] = commit;
		$[1] = getHovercardAttributesForType;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
});
LastCommitTimestamp.displayName = "LastCommitTimestamp";
function HistoryLink({ commit, commitCount, detailsOpen, setDetailsOpen }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "d-flex gap-2",
		children: [
			/* @__PURE__ */ jsx(ScreenReaderHeading, {
				as: "h2",
				text: "History"
			}),
			/* @__PURE__ */ jsx(HistoryLinkButton, {
				className: "d-none d-lg-flex",
				leadingVisual: HistoryIcon,
				children: /* @__PURE__ */ jsx("span", {
					className: "fgColor-default",
					children: commitCountLabel(commitCount)
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "d-sm-none",
				children: (commit?.shortMessageHtmlLink || commit?.bodyMessageHtml) && /* @__PURE__ */ jsx(CommitDetailsButton, {
					detailsOpen,
					setDetailsOpen
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "d-flex d-lg-none",
				children: /* @__PURE__ */ jsx(Tooltip$1, {
					text: commitCountLabel(commitCount),
					children: /* @__PURE__ */ jsx(HistoryLinkButton, {
						leadingVisual: HistoryIcon,
						"aria-label": "View commit history for this file."
					})
				})
			})
		]
	});
}
HistoryLink.displayName = "HistoryLink";
function commitCountLabel(commitCount) {
	if (!commitCount) return "History";
	return commitCount === "1" ? "1 Commit" : `${commitCount} Commits`;
}
function HistoryLinkButton({ children, className, leadingVisual, ref, ...props }) {
	const { sendRepoClickEvent } = useReposAnalytics();
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	return /* @__PURE__ */ jsx(LinkButton, {
		ref,
		...props,
		className: clsx(className, LinkButton_module_default.linkButton, "flex-items-center fgColor-default"),
		onClick: () => sendRepoClickEvent("HISTORY_BUTTON"),
		href: commitsPath({
			owner: repo.ownerLogin,
			repo: repo.name,
			ref: refInfo.name,
			path
		}),
		variant: "invisible",
		size: "small",
		leadingVisual,
		children
	});
}
HistoryLinkButton.displayName = "HistoryLinkButton";
function CommitDetailsButton({ detailsOpen, setDetailsOpen }) {
	return /* @__PURE__ */ jsx(IconButton, {
		"aria-label": "Open commit details",
		icon: EllipsisIcon,
		onClick: () => setDetailsOpen(!detailsOpen),
		variant: "invisible",
		"aria-pressed": detailsOpen,
		"aria-expanded": detailsOpen,
		"data-testid": "latest-commit-details-toggle",
		size: "small",
		className: LatestCommit_module_default.IconButton
	});
}
CommitDetailsButton.displayName = "CommitDetailsButton";
function CommitDetails(t0) {
	const $ = c(9);
	const { commit, repo } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	if ($[0] !== commit.bodyMessageHtml || $[1] !== commit.oid || $[2] !== commit.shortMessageHtmlLink || $[3] !== commit.status || $[4] !== commit.url || $[5] !== getHovercardAttributesForType || $[6] !== repo.name || $[7] !== repo.ownerLogin) {
		const abbreviatedOid = commit?.oid.slice(0, 7);
		t1 = jsxs("div", {
			className: "bgColor-muted border-top rounded-bottom-2 tmp-px-3 py-2 flex-1",
			children: [jsxs("div", {
				className: "d-flex d-sm-none flex-column",
				children: [
					jsxs("div", {
						className: LatestCommit_module_default.Box_3,
						children: [commit.shortMessageHtmlLink && jsx(VerifiedHTMLText, {
							className: clsx("Truncate-text", LatestCommit_module_default.VerifiedHTMLText),
							"data-testid": "latest-commit-html",
							html: commit.shortMessageHtmlLink
						}), jsx(ReposChecksStatusBadge, {
							oid: commit.oid,
							status: commit.status
						})]
					}),
					jsx(Link, {
						as: Link$1,
						to: commit.url,
						className: "Link--secondary",
						"aria-label": `Commit ${abbreviatedOid}`,
						...getHovercardAttributesForType("commit", {
							owner: repo.ownerLogin,
							repo: repo.name,
							commitish: commit.oid
						}),
						children: abbreviatedOid
					}),
					commit.bodyMessageHtml && jsx("br", {})
				]
			}), commit.bodyMessageHtml && jsx("div", {
				className: "mt-2 mt-sm-0 fgColor-muted",
				children: jsx(VerifiedHTMLText, {
					className: clsx("Truncate-text", LatestCommit_module_default.VerifiedHTMLText_1),
					"data-testid": "latest-commit-html",
					html: commit.bodyMessageHtml
				})
			})]
		});
		$[0] = commit.bodyMessageHtml;
		$[1] = commit.oid;
		$[2] = commit.shortMessageHtmlLink;
		$[3] = commit.status;
		$[4] = commit.url;
		$[5] = getHovercardAttributesForType;
		$[6] = repo.name;
		$[7] = repo.ownerLogin;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
CommitDetails.displayName = "CommitDetails";
function getProperHovercardsOnCommitMessage(shortMessageHtmlLink, dataUrl) {
	const separator = "<a ";
	let shortMessage = "";
	if (shortMessageHtmlLink) {
		const split = shortMessageHtmlLink.split(separator);
		for (const part of split) {
			if (part === "") continue;
			if (part.includes("data-hovercard-url")) {
				shortMessage = shortMessage.concat(separator, part);
				continue;
			}
			shortMessage = shortMessage.concat(...[
				separator,
				dataUrl,
				part
			]);
		}
	}
	return shortMessage;
}
function findElementByFragmentName(document, name) {
	if (name === "") return null;
	return document.getElementById(name) || document.getElementsByName(name)[0] || null;
}
function decodeFragmentValue(hash) {
	try {
		return decodeURIComponent(hash.slice(1));
	} catch {
		return "";
	}
}
var SharedMarkdownContent = memo(function SharedMarkdownContent({ ref, onAnchorClick, richText, stickyHeaderHeight, suppressHydrationWarning, className }) {
	const { hash } = useLocation$1();
	const currentRepo = useCurrentRepository();
	const navigate = useNavigate$1();
	const markdownContainerRef = useRef(null);
	useImperativeHandle(ref, () => markdownContainerRef.current);
	const handleHashChange = useEffectEvent(() => {
		onHashChange(window.location.hash, stickyHeaderHeight);
	});
	useEffect(() => {
		const hashChange = () => {
			handleHashChange();
		};
		window.addEventListener("load", hashChange);
		window.addEventListener("hashchange", hashChange);
		return () => {
			window.removeEventListener("load", hashChange);
			window.removeEventListener("hashchange", hashChange);
		};
	}, []);
	useLayoutEffect(() => {
		if (markdownContainerRef?.current) handleHashChange();
	}, [hash]);
	return /* @__PURE__ */ jsx(VerifiedHTMLBox, {
		ref: markdownContainerRef,
		className: `js-snippet-clipboard-copy-unpositioned ${className}`,
		html: richText,
		suppressHydrationWarning,
		"data-hpc": true,
		onClick: (event) => {
			const isCmdClick = event.metaKey || event.ctrlKey;
			const anchor = event.target.closest("a");
			if (anchor && anchor.href) {
				if (!isCmdClick) {
					const href = anchor.href;
					let url;
					try {
						url = new URL(href, window.location.origin);
					} catch {
						return;
					}
					if (isHashNavigation(window.location.href, href)) {
						onHashChange(url.hash, stickyHeaderHeight);
						if (window.location.hash === url.hash) event.preventDefault();
					} else if (href.startsWith(`${window.location.origin}/${currentRepo.ownerLogin}/${currentRepo.name}/`)) {
						navigate(url.pathname + url.search + url.hash);
						event.preventDefault();
					}
				}
				onAnchorClick?.(event);
			}
		}
	});
});
SharedMarkdownContent.displayName = "SharedMarkdownContent";
function onHashChange(hash, stickyHeaderHeight = 125) {
	if (!hash) return;
	const targetId = decodeFragmentValue(hash).toLowerCase();
	const normalizedTarget = targetId.startsWith("user-content-") ? targetId : `user-content-${targetId}`;
	const target = findElementByFragmentName(document, normalizedTarget);
	if (target && document && document.defaultView) setTimeout(() => {
		window.requestAnimationFrame(() => {
			const targetScroll = target.getBoundingClientRect().top - document.body.getBoundingClientRect().top - stickyHeaderHeight;
			window.scrollTo({ top: targetScroll });
			const focusElement = target.closest("h1,h2,h3,h4,h5,h6,li,span");
			if (focusElement) {
				focusElement.focus();
				focusElement.setAttribute("data-react-autofocus", "true");
			}
		});
	}, 1);
}
var TableOfContentsPanel_module_default = {
	Box: "TableOfContentsPanel-module_PClCcG_Box",
	NavList: "TableOfContentsPanel-module_PClCcG_NavList",
	TocLevel1: "TableOfContentsPanel-module_PClCcG_TocLevel1",
	TocLevel2: "TableOfContentsPanel-module_PClCcG_TocLevel2",
	TocLevel3: "TableOfContentsPanel-module_PClCcG_TocLevel3",
	TocLevel4: "TableOfContentsPanel-module_PClCcG_TocLevel4",
	TocLevel5: "TableOfContentsPanel-module_PClCcG_TocLevel5",
	TocLevel6: "TableOfContentsPanel-module_PClCcG_TocLevel6"
};
var levelClasses = {
	1: TableOfContentsPanel_module_default.TocLevel1,
	2: TableOfContentsPanel_module_default.TocLevel2,
	3: TableOfContentsPanel_module_default.TocLevel3,
	4: TableOfContentsPanel_module_default.TocLevel4,
	5: TableOfContentsPanel_module_default.TocLevel5,
	6: TableOfContentsPanel_module_default.TocLevel6
};
var TocItem = React.memo(function TocItem(t0) {
	const $ = c(11);
	const { htmlText, anchor, level, hash, index } = t0;
	const hashString = `#${anchor}`;
	const isCurrent = hash === hashString;
	const levelClass = levelClasses[Math.max(1, Math.min(6, level))];
	let t1;
	if ($[0] !== hashString || $[1] !== isCurrent) {
		t1 = (e) => {
			if (e.button === 1 || e.metaKey || e.ctrlKey) return;
			if (!isCurrent) location.href = hashString;
			onHashChange(hashString);
			e.preventDefault();
		};
		$[0] = hashString;
		$[1] = isCurrent;
		$[2] = t1;
	} else t1 = $[2];
	const handleClick = t1;
	const t2 = isCurrent ? "page" : void 0;
	let t3;
	if ($[3] !== anchor || $[4] !== handleClick || $[5] !== hashString || $[6] !== htmlText || $[7] !== index || $[8] !== levelClass || $[9] !== t2) {
		t3 = jsx(NavList.Item, {
			"aria-current": t2,
			href: hashString,
			onClick: handleClick,
			children: jsx(VerifiedHTMLBox, {
				className: levelClass,
				html: htmlText
			})
		}, `outline-${anchor}-${index}`);
		$[3] = anchor;
		$[4] = handleClick;
		$[5] = hashString;
		$[6] = htmlText;
		$[7] = index;
		$[8] = levelClass;
		$[9] = t2;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
});
TocItem.displayName = "TocItem";
function TableOfContentsPanel({ onClose, toc }) {
	const [filter, setFilter] = useState("");
	const deferredFilter = useDeferredValue(filter);
	const [hash, setHash] = useState("");
	const headingRef = useRef(null);
	useEffect(() => {
		headingRef.current?.focus();
	}, []);
	useEffect(() => {
		const hashChange = () => {
			if (window.location.hash) setHash(window.location.hash);
		};
		hashChange();
		window.addEventListener("hashchange", hashChange);
		return () => {
			window.removeEventListener("hashchange", hashChange);
		};
	}, []);
	const filteredToc = useMemo(() => {
		if (!toc) return [];
		if (!deferredFilter) return toc;
		const lowerFilter = deferredFilter.toLowerCase();
		return toc.filter(({ htmlText }) => htmlText && htmlText.toLowerCase().includes(lowerFilter));
	}, [toc, deferredFilter]);
	if (!toc) return null;
	return /* @__PURE__ */ jsxs("section", {
		"aria-labelledby": "outline-id",
		className: TableOfContentsPanel_module_default.Box,
		children: [
			onClose ? /* @__PURE__ */ jsxs("div", {
				className: "d-flex flex-justify-between flex-items-center",
				children: [/* @__PURE__ */ jsx("h3", {
					id: "outline-id",
					ref: headingRef,
					className: "d-flex flex-justify-between flex-items-center f5 text-bold px-2",
					tabIndex: -1,
					children: "Outline"
				}), /* @__PURE__ */ jsx(IconButton, {
					"aria-label": "Close outline",
					tooltipDirection: "sw",
					className: "fgColor-muted",
					icon: XIcon,
					onClick: onClose,
					variant: "invisible"
				})]
			}) : null,
			toc.length >= 8 ? /* @__PURE__ */ jsx("div", {
				className: "tmp-pt-3 px-2",
				children: /* @__PURE__ */ jsx(TextInput$1, {
					leadingVisual: FilterIcon,
					placeholder: "Filter headings",
					"aria-label": "Filter headings",
					className: "width-full",
					onChange: (e) => {
						setFilter(e.target.value);
					}
				})
			}) : null,
			/* @__PURE__ */ jsx(NavList, {
				className: TableOfContentsPanel_module_default.NavList,
				children: filteredToc.map((entry, index) => /* @__PURE__ */ jsx(TocItem, {
					anchor: entry.anchor,
					htmlText: entry.htmlText,
					level: entry.level,
					hash,
					index
				}, `outline-${entry.anchor}-${index}`))
			})
		]
	});
}
TableOfContentsPanel.displayName = "TableOfContentsPanel";
var SpoofedCommitWarning_module_default = { SpoofedCommitWarningBanner: "SpoofedCommitWarning-module_d2cFwa_SpoofedCommitWarningBanner" };
function SpoofedCommitWarning() {
	const $ = c(2);
	const isDataRouter = useIsDataRouterEnabled();
	let t0;
	if ($[0] !== isDataRouter) {
		t0 = isDataRouter ? jsx(SpoofedCommitWarningDataRouter, {}) : jsx(SpoofedCommitWarningInternal, {});
		$[0] = isDataRouter;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
SpoofedCommitWarning.displayName = "SpoofedCommitWarning";
function SpoofedCommitWarningDataRouter() {
	const $ = c(1);
	const { latestCommit } = useLatestCommitContext();
	if (!(latestCommit?.isSpoofed ?? false)) return null;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = jsx(SpoofedCommitWarningBanner, { className: SpoofedCommitWarning_module_default.SpoofedCommitWarningBanner });
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
SpoofedCommitWarningDataRouter.displayName = "SpoofedCommitWarningDataRouter";
function SpoofedCommitWarningInternal() {
	const $ = c(1);
	if (!useLatestCommitIsSpoofed()) return null;
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = jsx(SpoofedCommitWarningBanner, { className: SpoofedCommitWarning_module_default.SpoofedCommitWarningBanner });
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
SpoofedCommitWarningInternal.displayName = "SpoofedCommitWarningInternal";
function SpoofedCommitWarningBanner({ className }) {
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "warning",
		className,
		"data-testid": "spoofed-commit-warning-banner",
		children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), /* @__PURE__ */ jsx("span", { children: "This commit does not belong to any branch on this repository, and may belong to a fork outside of the repository." })]
	});
}
SpoofedCommitWarningBanner.displayName = "SpoofedCommitWarningBanner";
function useLatestCommitIsSpoofed() {
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const [latestCommit] = useLatestCommit(repo.ownerLogin, repo.name, refInfo.name, path);
	return latestCommit?.isSpoofed ?? false;
}
var TreeContext = React.createContext({});
TreeContext.displayName = "TreeContext";
function useCurrentTree() {
	return React.use(TreeContext);
}
function CurrentTreeProvider(t0) {
	const $ = c(9);
	const { payload, children } = t0;
	const { items, readme, totalCount, templateDirectorySuggestionUrl, showBranchInfobar } = payload;
	let t1;
	if ($[0] !== items || $[1] !== readme || $[2] !== showBranchInfobar || $[3] !== templateDirectorySuggestionUrl || $[4] !== totalCount) {
		t1 = {
			items,
			readme,
			totalCount,
			templateDirectorySuggestionUrl,
			showBranchInfobar
		};
		$[0] = items;
		$[1] = readme;
		$[2] = showBranchInfobar;
		$[3] = templateDirectorySuggestionUrl;
		$[4] = totalCount;
		$[5] = t1;
	} else t1 = $[5];
	const value = t1;
	let t2;
	if ($[6] !== children || $[7] !== value) {
		t2 = jsx(TreeContext, {
			value,
			children
		});
		$[6] = children;
		$[7] = value;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
CurrentTreeProvider.displayName = "CurrentTreeProvider";
var PublishBanners_module_default = { Flash: "PublishBanners-module_i8KjbG_Flash" };
function PublishBanners(t0) {
	const $ = c(8);
	const { showPublishActionBanner, releasePath, dismissActionNoticePath, className } = t0;
	const [hidden, setHidden] = useState(false);
	let t1;
	if ($[0] !== dismissActionNoticePath) {
		t1 = () => {
			verifiedFetch(dismissActionNoticePath, { method: "POST" });
			setHidden(true);
		};
		$[0] = dismissActionNoticePath;
		$[1] = t1;
	} else t1 = $[1];
	const onDismissPublishAction = t1;
	let t2;
	if ($[2] !== className || $[3] !== hidden || $[4] !== onDismissPublishAction || $[5] !== releasePath || $[6] !== showPublishActionBanner) {
		t2 = showPublishActionBanner ? jsxs(Flash, {
			hidden,
			className: clsx(className, PublishBanners_module_default.Flash),
			children: [
				showPublishActionBanner && jsx("div", {
					className: "flex-1",
					children: "You can publish this Action to the GitHub Marketplace"
				}),
				jsx(LinkButton, {
					href: releasePath,
					className: clsx(LinkButton_module_default.linkButton, "f6 mr-2"),
					children: "Draft a release"
				}),
				jsx(IconButton, {
					icon: XIcon,
					tooltipDirection: "s",
					"aria-label": "Dismiss",
					className: "bgColor-transparent border-0 pr-0",
					onClick: showPublishActionBanner ? onDismissPublishAction : _temp
				})
			]
		}) : null;
		$[2] = className;
		$[3] = hidden;
		$[4] = onDismissPublishAction;
		$[5] = releasePath;
		$[6] = showPublishActionBanner;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
PublishBanners.displayName = "PublishBanners";
function _temp() {}
export { SharedMarkdownContent as a, SpoofedCommitWarningBanner as c, useLatestCommitIsSpoofed as d, PublishBanners as i, TableOfContentsPanel as l, LatestCommitContent as n, SkeletonText as o, LatestCommitSingleLine as r, SpoofedCommitWarning as s, CurrentTreeProvider as t, useCurrentTree as u };
