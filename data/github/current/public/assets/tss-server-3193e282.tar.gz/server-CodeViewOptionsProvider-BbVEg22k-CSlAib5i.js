import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as useIsPlatform } from "./server-use-is-platform-BI7nkjWR-DIY2sQH4.js";
import { createContext, use, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var macShortcuts = {
	cursorNavigationHopWordLeft: {
		hotkey: "Alt+ArrowLeft,Ctrl+ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowLeft"],
		modifierRequired: true
	},
	cursorNavigationHopWordRight: {
		hotkey: "Alt+ArrowRight,Ctrl+ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowRight"],
		modifierRequired: true
	},
	cursorNavigationTopOfPage: {
		hotkey: "Meta+ArrowUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowUp"],
		modifierRequired: true
	},
	cursorNavigationBottomOfPage: {
		hotkey: "Meta+ArrowDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowDown"],
		modifierRequired: true
	},
	cursorNavigationEnd: {
		hotkey: "End,Meta+ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["End"]
	},
	cursorNavigationHome: {
		hotkey: "Home,Meta+ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["Home"]
	},
	cursorNavigationPageUp: {
		hotkey: "PageUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["PageUp"]
	},
	cursorNavigationPageDown: {
		hotkey: "PageDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["PageDown"]
	},
	cursorNavigationArrowDown: {
		hotkey: "ArrowDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowDown"]
	},
	cursorNavigationArrowUp: {
		hotkey: "ArrowUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowUp"]
	},
	cursorNavigationArrowLeft: {
		hotkey: "ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowLeft"]
	},
	cursorNavigationArrowRight: {
		hotkey: "ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowRight"]
	},
	cursorNavigationShiftHopWordLeft: {
		hotkey: "Alt+Shift+ArrowLeft,Ctrl+Shift+ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowLeft"],
		modifierRequired: true
	},
	cursorNavigationShiftHopWordRight: {
		hotkey: "Alt+Shift+ArrowRight,Ctrl+Shift+ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowRight"],
		modifierRequired: true
	},
	cursorNavigationShiftTopOfPage: {
		hotkey: "Meta+Shift+ArrowUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowUp"],
		modifierRequired: true
	},
	cursorNavigationShiftBottomOfPage: {
		hotkey: "Meta+Shift+ArrowDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowDown"],
		modifierRequired: true
	},
	cursorNavigationShiftEnd: {
		hotkey: "Shift+End,Meta+Shift+ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["End"],
		modifierRequired: true
	},
	cursorNavigationShiftHome: {
		hotkey: "Shift+Home,Meta+Shift+ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["Home"],
		modifierRequired: true
	},
	cursorNavigationShiftPageUp: {
		hotkey: "Shift+PageUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["PageUp"],
		modifierRequired: true
	},
	cursorNavigationShiftPageDown: {
		hotkey: "Shift+PageDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["PageDown"],
		modifierRequired: true
	},
	cursorNavigationShiftArrowDown: {
		hotkey: "Shift+ArrowDown",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowDown"],
		modifierRequired: true
	},
	cursorNavigationShiftArrowUp: {
		hotkey: "Shift+ArrowUp",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowUp"],
		modifierRequired: true
	},
	cursorNavigationShiftArrowLeft: {
		hotkey: "Shift+ArrowLeft",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowLeft"],
		modifierRequired: true
	},
	cursorNavigationShiftArrowRight: {
		hotkey: "Shift+ArrowRight",
		useWhileBlobFocused: true,
		noModifierHotkey: ["ArrowRight"],
		modifierRequired: true
	},
	cursorNavigationHighlightLine: {
		text: "J",
		hotkey: "Shift+J",
		useWhileBlobFocused: true,
		noModifierHotkey: ["J"],
		modifierRequired: true
	},
	cursorNavigationGoLineUp: {
		hotkey: "Ctrl+p",
		useWhileBlobFocused: true,
		noModifierHotkey: ["p"],
		modifierRequired: true
	},
	cursorNavigationOpenHelpDialog: {
		hotkey: "Alt+F1,Control+Alt+˙,Control+Alt+h",
		useWhileBlobFocused: true,
		noModifierHotkey: [
			"F1",
			"h",
			"˙"
		],
		modifierRequired: true
	},
	cursorNavigationGoLineDown: {
		hotkey: "Ctrl+n",
		useWhileBlobFocused: true,
		noModifierHotkey: ["n"],
		modifierRequired: true
	},
	cursorNavigationEnter: {
		text: "⌘ Enter",
		hotkey: "Meta+Enter",
		useWhileBlobFocused: true,
		noModifierHotkey: ["Enter"],
		modifierRequired: true
	},
	cursorNavigationSpace: {
		hotkey: " ",
		useWhileBlobFocused: true,
		noModifierHotkey: [" "],
		modifierRequired: false
	},
	cursorNavigationShiftSpace: {
		hotkey: "Shift+ ",
		useWhileBlobFocused: true,
		noModifierHotkey: [" "],
		modifierRequired: true
	},
	expandAndFocusLineContextMenu: {
		text: "Shift Alt C",
		hotkey: "Alt+Shift+C,Alt+Shift+Ç",
		useWhileBlobFocused: true,
		noModifierHotkey: ["C"],
		modifierRequired: true
	},
	copyFilePathShortcut: {
		text: "⌘ shift .",
		hotkey: "Meta+Shift+>",
		useWhileBlobFocused: true,
		noModifierHotkey: ["."],
		modifierRequired: true
	},
	copyPermalinkShortcut: {
		text: "⌘ shift ,",
		hotkey: "Meta+Shift+<",
		useWhileBlobFocused: true,
		noModifierHotkey: [","],
		modifierRequired: true
	},
	copyRawContentShortcut: {
		text: "⌘ shift c",
		hotkey: "Meta+Shift+C",
		useWhileBlobFocused: true,
		noModifierHotkey: ["c"],
		modifierRequired: true
	},
	downloadRawContentShortcut: {
		text: "⌘ shift s",
		hotkey: "Meta+Shift+S",
		useWhileBlobFocused: true,
		noModifierHotkey: ["s"],
		modifierRequired: true
	},
	editFileShortcut: {
		hotkey: "e,Shift+E",
		useWhileBlobFocused: true,
		noModifierHotkey: ["e", "E"]
	},
	goToLineShortcut: {
		text: "l",
		hotkey: "l,Shift+L",
		ariaKeyShortcuts: "l",
		useWhileBlobFocused: true,
		noModifierHotkey: ["l", "L"]
	},
	alternativeGoToLineShortcut: {
		hotkey: "Mod+Alt+g",
		ariaKeyShortcuts: "Mod+Alt+g",
		useWhileBlobFocused: true,
		noModifierHotkey: ["g", "G"]
	},
	findInFileShortcut: {
		hotkey: "Meta+f, F3",
		text: "⌘ f",
		ariaKeyShortcuts: "Meta+F",
		useWhileBlobFocused: true,
		noModifierHotkey: ["f", "F3"],
		modifierRequired: true
	},
	findFilesShortcut: {
		hotkey: "t,Shift+T",
		useWhileBlobFocused: true,
		noModifierHotkey: ["t", "T"]
	},
	findSelectionShortcut: {
		hotkey: "Meta+e",
		useWhileBlobFocused: true,
		noModifierHotkey: ["e"],
		modifierRequired: true
	},
	findNextShortcut: { hotkey: "Mod+g" },
	findPrevShortcut: { hotkey: "Mod+Shift+G" },
	openWithGitHubDevShortcut: {
		hotkey: "., Meta+Shift+/",
		useWhileBlobFocused: true,
		noModifierHotkey: ["."]
	},
	openWithGitHubDevInNewWindowShortcut: {
		hotkey: "Shift+.,Shift+>,>",
		useWhileBlobFocused: true,
		noModifierHotkey: [">"]
	},
	permalinkShortcut: {
		hotkey: "y,Shift+Y",
		useWhileBlobFocused: true,
		noModifierHotkey: ["y", "Y"]
	},
	searchShortcut: {
		hotkey: "/",
		useWhileBlobFocused: true,
		noModifierHotkey: ["/"]
	},
	selectAllShortcut: {
		hotkey: "Meta+a",
		useWhileBlobFocused: true,
		noModifierHotkey: ["a"],
		modifierRequired: true
	},
	selectEditTabShortcut: { hotkey: "Mod+Shift+P" },
	submitCommitDialogShortcut: { hotkey: "Mod+Enter" },
	refSelectorShortcut: {
		hotkey: "w",
		text: "w",
		useWhileBlobFocused: true,
		noModifierHotkey: ["w"]
	},
	escapeRightClickMenu: {
		hotkey: "Escape",
		useWhileBlobFocused: true,
		noModifierHotkey: ["Escape"]
	},
	toggleFocusedPaneShortcut: {
		hotkey: "Meta+F6,Meta+Shift+F6",
		useWhileBlobFocused: true,
		noModifierHotkey: ["F6"],
		modifierRequired: true
	},
	toggleSymbolsShortcut: {
		hotkey: "Meta+i",
		useWhileBlobFocused: true,
		noModifierHotkey: ["i"],
		modifierRequired: true
	},
	toggleTreeShortcut: {
		hotkey: "Meta+b",
		useWhileBlobFocused: true,
		noModifierHotkey: ["b"],
		modifierRequired: true
	},
	viewBlameShortcut: {
		hotkey: "b,Shift+B,Meta+/ Meta+b",
		useWhileBlobFocused: true,
		noModifierHotkey: ["b"]
	},
	viewCodeShortcut: {
		hotkey: "Meta+/ Meta+c",
		useWhileBlobFocused: true,
		modifierRequired: true
	},
	viewPreviewShortcut: { hotkey: "Meta+/ Meta+p" },
	viewRawContentShortcut: {
		text: "⌘ / ⌘ r",
		hotkey: "Meta+/ Meta+r",
		useWhileBlobFocused: true,
		noModifierHotkey: ["r"],
		modifierRequired: true
	},
	findSymbolShortcut: {
		hotkey: "r,Shift+R",
		useWhileBlobFocused: true,
		noModifierHotkey: ["r", "R"],
		modifierRequired: false
	}
};
function modifyForNonMac(shortcuts) {
	return Object.keys(shortcuts).reduce((acc, key) => {
		const shortcut = shortcuts[key];
		acc[key] = {
			hotkey: shortcut.hotkey?.replace(/Meta/g, "Control"),
			text: shortcut.text?.replace(/⌘/g, "Ctrl").replace(/⇧/g, "Shift"),
			ariaKeyShortcuts: shortcut.ariaKeyShortcuts?.replace(/Meta/g, "Control"),
			useWhileBlobFocused: shortcut.useWhileBlobFocused,
			modifierRequired: shortcut.modifierRequired,
			noModifierHotkey: shortcut.noModifierHotkey
		};
		return acc;
	}, {});
}
/***
This function is necessary in SSR because the data-hotkey attribute does not
recognize changes to hotkeys that happen during hydration. So we needed the
data-hotkey attribute to not exist until during hydration. We had
the useClientValue returning false on whether or not the user was using a mac,
so all hotkeys were being changed to have control in them instead of meta.
This was causing mac users to not be able to use any hotkeys that had Meta
in them if they got the SSR'd version of the blob page.
***/
function modifyForSSR(shortcuts) {
	return Object.keys(shortcuts).reduce((acc, key) => {
		const shortcut = shortcuts[key];
		acc[key] = {
			hotkey: void 0,
			text: shortcut.text?.replace(/⌘/g, "Ctrl").replace(/⇧/g, "Shift"),
			ariaKeyShortcuts: shortcut.ariaKeyShortcuts?.replace(/Meta/g, "Control"),
			useWhileBlobFocused: shortcut.useWhileBlobFocused,
			modifierRequired: shortcut.modifierRequired,
			noModifierHotkey: shortcut.noModifierHotkey
		};
		return acc;
	}, {});
}
var shortcutMemo = /* @__PURE__ */ new Map();
function useShortcut() {
	const $ = c(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["mac"];
		$[0] = t0;
	} else t0 = $[0];
	const isMac = useIsPlatform(t0);
	const { isServer: isSSR } = useRuntimeEnvironment();
	let key = 0;
	if (isMac) key = 1;
	else if (!isSSR) key = 2;
	if (!shortcutMemo.has(key)) {
		let shortcuts = macShortcuts;
		if (!isMac && !isSSR) shortcuts = modifyForNonMac(macShortcuts);
		if (isSSR) shortcuts = modifyForSSR(shortcuts);
		shortcutMemo.set(key, shortcuts);
	}
	let t1;
	if ($[1] !== key) {
		t1 = shortcutMemo.get(key);
		$[1] = key;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
function useBlobFocusedModifierShortcuts() {
	const $ = c(2);
	const shortcuts = useShortcut();
	let t0;
	if ($[0] !== shortcuts) {
		t0 = Object.keys(shortcuts).reduce((acc, key) => {
			const shortcut = shortcuts[key];
			if (shortcut.useWhileBlobFocused && shortcut.noModifierHotkey && shortcut.modifierRequired) {
				for (const alphaNumericHotkey of shortcut.noModifierHotkey) if (!acc.includes(alphaNumericHotkey)) acc.push(alphaNumericHotkey);
			}
			return acc;
		}, []);
		$[0] = shortcuts;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function useBlobFocusedShortcuts() {
	const $ = c(2);
	const shortcuts = useShortcut();
	let t0;
	if ($[0] !== shortcuts) {
		t0 = Object.keys(shortcuts).reduce((acc, key) => {
			const shortcut = shortcuts[key];
			if (shortcut.useWhileBlobFocused && shortcut.noModifierHotkey && !shortcut.modifierRequired) {
				for (const alphaNumericHotkey of shortcut.noModifierHotkey) if (!acc.includes(alphaNumericHotkey)) acc.push(alphaNumericHotkey);
			}
			return acc;
		}, []);
		$[0] = shortcuts;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
var safeLocalStorage = safeStorage("localStorage");
var codeFoldingName = "codeView.codeFolding";
var codeWrappingName = "codeView.codeWrapping";
var codeCenteredOption = "codeView.centerView";
var openSymbolsName = "codeView.openSymbolsOnClick";
var codeViewOptionLabels = new Map([
	[codeFoldingName, "Show code folding buttons"],
	[codeWrappingName, "Wrap lines"],
	[codeCenteredOption, "Center content"],
	[openSymbolsName, "Open symbols on click"]
]);
var CodeViewOptionsContext = createContext({
	codeFoldingOption: {},
	codeWrappingOption: {},
	codeCenterOption: {},
	openSymbolsOption: {}
});
CodeViewOptionsContext.displayName = "CodeViewOptionsContext";
var CodeViewOptionsProvider = (t0) => {
	const $ = c(8);
	const { children } = t0;
	const codeFoldingOption = useCodeViewOption(codeFoldingName, true);
	const codeWrappingOption = useCodeViewOption(codeWrappingName, false);
	const codeCenterOption = useCodeViewOption(codeCenteredOption, false);
	const openSymbolsOption = useCodeViewOption(openSymbolsName, true);
	let t1;
	if ($[0] !== codeCenterOption || $[1] !== codeFoldingOption || $[2] !== codeWrappingOption || $[3] !== openSymbolsOption) {
		t1 = {
			codeFoldingOption,
			codeWrappingOption,
			codeCenterOption,
			openSymbolsOption
		};
		$[0] = codeCenterOption;
		$[1] = codeFoldingOption;
		$[2] = codeWrappingOption;
		$[3] = openSymbolsOption;
		$[4] = t1;
	} else t1 = $[4];
	const providerValue = t1;
	let t2;
	if ($[5] !== children || $[6] !== providerValue) {
		t2 = jsx(CodeViewOptionsContext, {
			value: providerValue,
			children
		});
		$[5] = children;
		$[6] = providerValue;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
};
CodeViewOptionsProvider.displayName = "CodeViewOptionsProvider";
function useCodeViewOption(name, defaultValue) {
	const $ = c(11);
	let t0;
	if ($[0] !== name) {
		t0 = safeLocalStorage.getItem(name);
		$[0] = name;
		$[1] = t0;
	} else t0 = $[1];
	const localStorageValue = t0;
	let t1;
	if ($[2] !== defaultValue || $[3] !== localStorageValue) {
		t1 = () => localStorageValue ? localStorageValue === "true" : defaultValue;
		$[2] = defaultValue;
		$[3] = localStorageValue;
		$[4] = t1;
	} else t1 = $[4];
	const [enabled, setEnabled] = useState(t1);
	let t2;
	if ($[5] !== name) {
		t2 = codeViewOptionLabels.get(name) || "";
		$[5] = name;
		$[6] = t2;
	} else t2 = $[6];
	const label = t2;
	let t3;
	if ($[7] !== enabled || $[8] !== label || $[9] !== name) {
		t3 = {
			name,
			enabled,
			setEnabled,
			label
		};
		$[7] = enabled;
		$[8] = label;
		$[9] = name;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
function useCodeViewOptions() {
	return use(CodeViewOptionsContext);
}
export { useShortcut as a, useCodeViewOptions as i, useBlobFocusedModifierShortcuts as n, useBlobFocusedShortcuts as r, CodeViewOptionsProvider as t };
