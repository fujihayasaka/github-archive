function isDev() {
	return false;
}
function canAccessUIRuntimeStaging() {
	return process.env.HEAVEN_DEPLOYED_ENV === "production";
}
export { isDev as n, canAccessUIRuntimeStaging as t };
