import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { l as ready, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as useIsMounted } from "./server-use-is-mounted-BP8yEjoH-CZJ4mOOX.js";
import { t as taskQueue } from "./server-eventloop-tasks-XdjS6iVt-BpyiM497.js";
import { createContext, use, useEffect } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
import { AliveSession, PresenceMetadataSet, SubscriptionSet, Topic, isPresenceChannel } from "@github/alive-client";
import { isSafari } from "@braintree/browser-detection";
var AliveSession$1 = class extends AliveSession {
	#refreshUrl;
	constructor(url, refreshUrl, shared, notify, options) {
		super(url, () => this.#getUrlFromRefreshUrl(), shared, notify, void 0, options);
		this.#refreshUrl = refreshUrl;
	}
	#getUrlFromRefreshUrl() {
		return fetchRefreshUrl(this.#refreshUrl);
	}
};
async function fetchRefreshUrl(url) {
	const data = await fetchJSON(url);
	return data && data.url && data.token ? post(data.url, data.token) : null;
}
async function fetchJSON(url) {
	const response = await fetch(url, { headers: { Accept: "application/json" } });
	if (response.ok) return response.json();
	else if (response.status === 404) return null;
	else throw new Error("fetch error");
}
async function post(url, csrf) {
	const response = await fetch(url, {
		method: "POST",
		mode: "same-origin",
		headers: { "Scoped-CSRF-Token": csrf }
	});
	if (response.ok) return response.text();
	else throw new Error("fetch error");
}
function isSharedWorkerSupported() {
	if (isSafari()) return false;
	return "SharedWorker" in window && safeStorage("localStorage").getItem("bypassSharedWorker") !== "true";
}
function workerSrc() {
	const url = document.head.querySelector(`link[rel=shared-web-socket-src]`)?.getAttribute("href");
	if (!url || !url.startsWith("/")) return null;
	return url;
}
function socketUrl() {
	return document.head.querySelector("link[rel=shared-web-socket]")?.href ?? null;
}
function socketRefreshUrl() {
	return document.head.querySelector("link[rel=shared-web-socket]")?.getAttribute("data-refresh-url") ?? null;
}
function sessionIdentifier() {
	return document.head.querySelector("link[rel=shared-web-socket]")?.getAttribute("data-session-id") ?? null;
}
/**
* dispatches events of type: 'socket:message' | 'socket:presence'
*/
function notify(subscribers, { channel, type, data }) {
	for (const el of subscribers) el.dispatchEvent(new CustomEvent(`socket:${type}`, {
		bubbles: false,
		cancelable: false,
		detail: {
			name: channel,
			data
		}
	}));
}
var AliveSessionProxy = class {
	#worker;
	#subscriptions = new SubscriptionSet();
	#presenceMetadata = new PresenceMetadataSet();
	#notify;
	constructor(src, url, refreshUrl, sessionId, notifier, options) {
		this.#notify = notifier;
		this.#worker = new SharedWorker(`${src}?module=true`, {
			name: `github-socket-worker-v3-${sessionId}`,
			type: "module"
		});
		this.#worker.port.onmessage = ({ data }) => this.#receive(data);
		this.#worker.port.postMessage({ connect: {
			url,
			refreshUrl,
			options
		} });
	}
	subscribe(subs) {
		const added = this.#subscriptions.add(...subs);
		if (added.length) this.#worker.port.postMessage({ subscribe: added });
		const addedChannels = new Set(added.map((topic) => topic.name));
		const redundantPresenceChannels = subs.reduce((redundantChannels, subscription) => {
			const channel = subscription.topic.name;
			if (isPresenceChannel(channel) && !addedChannels.has(channel)) redundantChannels.add(channel);
			return redundantChannels;
		}, /* @__PURE__ */ new Set());
		if (redundantPresenceChannels.size) this.#worker.port.postMessage({ requestPresence: Array.from(redundantPresenceChannels) });
	}
	unsubscribeAll(...subscribers) {
		const removed = this.#subscriptions.drain(...subscribers);
		if (removed.length) this.#worker.port.postMessage({ unsubscribe: removed });
		const updatedPresenceChannels = this.#presenceMetadata.removeSubscribers(subscribers);
		this.sendPresenceMetadataUpdate(updatedPresenceChannels);
	}
	updatePresenceMetadata(metadataUpdates) {
		const updatedChannels = /* @__PURE__ */ new Set();
		for (const update of metadataUpdates) {
			this.#presenceMetadata.setMetadata(update);
			updatedChannels.add(update.channelName);
		}
		this.sendPresenceMetadataUpdate(updatedChannels);
	}
	sendPresenceMetadataUpdate(channelNames) {
		if (!channelNames.size) return;
		const updatesForSharedWorker = [];
		for (const channelName of channelNames) updatesForSharedWorker.push({
			channelName,
			metadata: this.#presenceMetadata.getChannelMetadata(channelName)
		});
		this.#worker.port.postMessage({ updatePresenceMetadata: updatesForSharedWorker });
	}
	online() {
		this.#worker.port.postMessage({ online: true });
	}
	offline() {
		this.#worker.port.postMessage({ online: false });
	}
	hangup() {
		this.#worker.port.postMessage({ hangup: true });
	}
	#notifyPresenceDebouncedByChannel = /* @__PURE__ */ new Map();
	#receive(event) {
		const { channel } = event;
		if (event.type === "presence") {
			let debouncedNotify = this.#notifyPresenceDebouncedByChannel.get(channel);
			if (!debouncedNotify) {
				debouncedNotify = debounce((subscribers, debouncedEvent) => {
					this.#notify(subscribers, debouncedEvent);
					this.#notifyPresenceDebouncedByChannel.delete(channel);
				}, 100);
				this.#notifyPresenceDebouncedByChannel.set(channel, debouncedNotify);
			}
			debouncedNotify(this.#subscriptions.subscribers(channel), event);
			return;
		}
		this.#notify(this.#subscriptions.subscribers(channel), event);
	}
};
async function connect() {
	const src = workerSrc();
	if (!src) return;
	const url = socketUrl();
	if (!url) return;
	const refreshUrl = socketRefreshUrl();
	if (!refreshUrl) return;
	const sessionId = sessionIdentifier();
	if (!sessionId) return;
	const createSession = () => {
		const options = {};
		if (isSharedWorkerSupported()) try {
			return new AliveSessionProxy(src, url, refreshUrl, sessionId, notify, options);
		} catch {}
		return new AliveSession$1(url, refreshUrl, false, notify, options);
	};
	const session = createSession();
	window.addEventListener("online", () => session.online());
	window.addEventListener("offline", () => session.offline());
	window.addEventListener("pagehide", () => {
		if ("hangup" in session) session.hangup();
	});
	return session;
}
async function connectWhenReady() {
	await ready;
	return connect();
}
var sessionPromise;
function getSession() {
	return sessionPromise ||= connectWhenReady();
}
var sessionTaskQueues = /* @__PURE__ */ new WeakMap();
function getSessionTaskQueues(session) {
	let queues = sessionTaskQueues.get(session);
	if (!queues) {
		queues = {
			subscribe: taskQueue((subs) => session.subscribe(subs.flat())),
			unsubscribeAll: taskQueue((els) => session.unsubscribeAll(...els))
		};
		sessionTaskQueues.set(session, queues);
	}
	return queues;
}
/**
* Connect to an Alive subscription
* @param aliveSession the Alive session
* @param channelName the signed channel name
* @param callback a callback to receive events from the alive channel. This callback should be memoized to avoid unnecessary resubscribes when React re-renders.
*/
function connectAliveSubscription(aliveSession, channelName, callback) {
	if (!aliveSession) throw new Error("Not connected to alive");
	if (!channelName) throw new Error("No channel name");
	const topic = Topic.parse(channelName);
	if (!topic) throw new Error("Invalid channel name");
	const aliveSubscription = {
		subscriber: { dispatchEvent: (event) => {
			if (event instanceof CustomEvent) {
				const subscriptionEvent = event.detail;
				callback(subscriptionEvent.data);
			}
		} },
		topic
	};
	const subscriptionTarget = getSessionTaskQueues(aliveSession);
	subscriptionTarget.subscribe([aliveSubscription]);
	return { unsubscribe: () => subscriptionTarget.unsubscribeAll(aliveSubscription.subscriber) };
}
var AliveTestContext = createContext(null);
AliveTestContext.displayName = "AliveTestContext";
var subscriptions = null;
/**
* Provides context required to dispatch mock alive messages via `dispatchAliveTestMessage`
*
*@example
* ```ts
* import {AliveTestProvider, dispatchAliveTestMessage, signChannel} from '@github-ui/use-alive/test-utils'
*
* render(<MyComponent aliveChannel={signChannel("channel-name")} />, {
*   wrapper: ({children}) => (
*     <AliveTestProvider
*       initialMessages={[["channel-name", {data: 1}]]}
*     >
*       {children}
*     </AliveTestProvider>
* )})
*
* // later in the test, you can send another message:
* dispatchAliveTestMessage("channel-name", {data: 2})
* ```
*/
function AliveTestProvider(t0) {
	const $ = c(4);
	const { children, initialMessages } = t0;
	let t1;
	if ($[0] !== initialMessages) {
		t1 = () => {
			const timeouts = [];
			if (initialMessages) for (const [channel, users] of initialMessages) {
				const timeout = window.setTimeout(() => {
					dispatchAliveTestMessage(channel, users);
				}, 0);
				timeouts.push(timeout);
			}
			return () => {
				subscriptions = null;
				for (const timeout_0 of timeouts) window.clearTimeout(timeout_0);
			};
		};
		$[0] = initialMessages;
		$[1] = t1;
	} else t1 = $[1];
	useEffect(t1);
	let t2;
	if ($[2] !== children) {
		t2 = jsx(AliveTestContext, {
			value: testSubscribeToAlive,
			children
		});
		$[2] = children;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
/**
* Send mock Alive messages for tests or storybook etc.
* Component under test **must** be wrapped in `AliveTestProvider` to enable Alive mocking.
*
* @see `AliveTestProvider`
*
* @param channel - an unsigned alive channel name: subscribers to this channel will be notified
* @param data - data to send to subscribers
*/
AliveTestProvider.displayName = "AliveTestProvider";
function dispatchAliveTestMessage(channel, data) {
	if (subscriptions === null) throw new Error("Test helper `dispatchAliveTestMessage` called outside `AliveTestProvider`. Please wrap your component under test in `AliveTestProvider` from \"@github-ui/use-alive/test-utils\".");
	const subscribers = Array.from(subscriptions.subscribers(channel));
	for (const subscriber of subscribers) subscriber(data);
}
/**
* Provides access to the `testSubscribeToAlive` mock if called from within a `AliveTestProvider` context
*/
function useTestSubscribeToAlive() {
	return use(AliveTestContext);
}
/**
* This function is private and is intended only to be consumable via `AliveTestProvider` / `useTestSubscribeToAlive`
* Furthermore it is only expected to be used in `use-alive.ts`
* @param signedChannel - A signed alive channel. You can use `signChannel` to generate a signed channel from a channel name.
* @param callback - this will be called with data provided via `dispatchAliveTestMessage` to simulate an alive message
* @private
*/
function testSubscribeToAlive(signedChannel, callback) {
	const topic = Topic.parse(signedChannel);
	if (!topic) throw new Error(`Invalid channel name. Did you forget to sign it with \`signChannel("${signedChannel}")\`?`);
	if (!subscriptions) subscriptions = new SubscriptionSet();
	subscriptions.add({
		topic,
		subscriber: callback
	});
	return { unsubscribe: () => {
		subscriptions?.delete({
			topic,
			subscriber: callback
		});
	} };
}
/**
* Subscribe to an alive channel with a signed channel name. Event data
* will be passed to the callback.
* @param signedChannel the signed channel name, provided from the server
* @param callback a callback to receive events from the alive channel. This callback should be memoized to avoid unnecessary resubscribes when React re-renders.
*/
function useAlive(signedChannel, callback) {
	const isMounted = useIsMounted();
	const testSubscribeToAlive = useTestSubscribeToAlive();
	useEffect(() => {
		let unsubscribeFromAlive = () => {};
		let closed = false;
		async function subscribeToAlive() {
			if (!signedChannel) return;
			if (typeof testSubscribeToAlive === "function") {
				const subs = await testSubscribeToAlive(signedChannel, callback);
				if (subs) unsubscribeFromAlive = subs.unsubscribe;
				return;
			}
			try {
				const aliveSession = await getSession();
				if (closed) return;
				const resp = connectAliveSubscription(aliveSession, signedChannel, callback);
				if (resp?.unsubscribe) if (isMounted()) unsubscribeFromAlive = resp.unsubscribe;
				else resp.unsubscribe();
			} catch (e) {
				console.error(e);
			}
		}
		subscribeToAlive();
		return () => {
			closed = true;
			unsubscribeFromAlive();
		};
	}, [
		signedChannel,
		callback,
		isMounted,
		testSubscribeToAlive
	]);
}
export { useAlive as t };
