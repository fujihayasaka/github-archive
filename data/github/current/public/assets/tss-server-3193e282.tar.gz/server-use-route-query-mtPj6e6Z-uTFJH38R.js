import { f as useSuspenseQuery, l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { t as assertHasUIServiceConfig } from "./server-register-route-with-ui-service-CMrESzAc-B6TtUNGU.js";
import { useLocation, useMatches, useParams } from "@tanstack/react-router";
import { c } from "react/compiler-runtime";
/**
* Reads the TSS config for a route query with a defensive error for malformed routes.
*/
function getTssQueryConfig(route, queryName) {
	const query = route.queries[queryName];
	if (!query) throw new Error(`No query config found for query "${queryName}"`);
	return query.tss;
}
/**
* Streaming queries should not render data on the server render pass.
*/
function useShouldSuppressStreamingDuringSSR(mode) {
	const { isServer } = useRuntimeEnvironment();
	return mode === "streaming" && isServer;
}
/**
* Normalizes useQuery result shape for suppressed streaming SSR renders.
*
* We construct a self-consistent "pending/loading" state and explicitly
* clear any success/error-related flags or metadata that may be present
* on the underlying result.
*/
function toStreamingQueryResult(result) {
	return {
		...result,
		data: void 0,
		status: "pending",
		fetchStatus: "fetching",
		isPending: true,
		isLoading: true,
		isFetching: true,
		isSuccess: false,
		isError: false,
		error: null,
		isFetched: false,
		isFetchedAfterMount: false,
		isRefetching: false,
		dataUpdatedAt: 0,
		errorUpdatedAt: 0,
		failureCount: 0,
		failureReason: null,
		fetchFailureReason: null
	};
}
/**
* useQuery-compatible path for streaming mode that suppresses SSR data rendering
* while preserving regular client behavior after hydration.
*/
function useStreamingCompatibleQuery(options, mode) {
	const $ = c(2);
	const shouldSuppress = useShouldSuppressStreamingDuringSSR(mode);
	const result = useQuery(options);
	if (shouldSuppress) {
		let t0;
		if ($[0] !== result) {
			t0 = toStreamingQueryResult(result);
			$[0] = result;
			$[1] = t0;
		} else t0 = $[1];
		return t0;
	}
	return result;
}
/**
* This is a shim for `@github-ui/react-core/future/use-route-query` package.
* In tss-server, we use TanStack Start's loader pattern instead of the query-based routing.
* This shim allows components that use `useRouteQuery` and `useSuspenseRouteQuery` to connect
* with query options that are used by the TanStack routes' loaders.
*/
/**
* Returns the search string that was used when the loader last ran for this route.
*
* The loader stores the searchStr it used in `loaderData` (via `registerRouteWithUIService`).
* Reading it from the committed match's `loaderData` — rather than from `useLocation()` —
* ensures that query keys in the shim stay aligned with what the loader cached, even while
* the browser location is already advancing to a new URL.
*
* Falls back to the current location's searchStr when loaderData is not yet available
* (e.g. during the initial SSR render, or for routes not registered with
* `registerRouteWithUIService`).
*/
function useCommittedSearchStr(route) {
	const $ = c(5);
	const matches = useMatches();
	const location = useLocation();
	let t0;
	if ($[0] !== matches || $[1] !== route) {
		let t1;
		if ($[3] !== route) {
			t1 = (m) => m.staticData?.queryRoute === route;
			$[3] = route;
			$[4] = t1;
		} else t1 = $[4];
		t0 = matches.find(t1);
		$[0] = matches;
		$[1] = route;
		$[2] = t0;
	} else t0 = $[2];
	return t0?.loaderData?.searchStr ?? location.searchStr;
}
function useRouteQuery(route, queryName, queryOverrides) {
	const $ = c(13);
	assertHasUIServiceConfig(route, queryName);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { strict: false };
		$[0] = t0;
	} else t0 = $[0];
	const params = useParams(t0);
	const searchStr = useCommittedSearchStr(route);
	let t1;
	let tssConfig;
	if ($[1] !== params || $[2] !== queryName || $[3] !== route || $[4] !== searchStr) {
		tssConfig = getTssQueryConfig(route, queryName);
		t1 = tssConfig.options({
			params,
			searchStr
		});
		$[1] = params;
		$[2] = queryName;
		$[3] = route;
		$[4] = searchStr;
		$[5] = t1;
		$[6] = tssConfig;
	} else {
		t1 = $[5];
		tssConfig = $[6];
	}
	const options = t1;
	let t2;
	if ($[7] !== options || $[8] !== queryOverrides) {
		t2 = {
			...options,
			...queryOverrides
		};
		$[7] = options;
		$[8] = queryOverrides;
		$[9] = t2;
	} else t2 = $[9];
	const t3 = useStreamingCompatibleQuery(t2, tssConfig.mode);
	let t4;
	if ($[10] !== options.queryKey || $[11] !== t3) {
		t4 = {
			...t3,
			queryKey: options.queryKey
		};
		$[10] = options.queryKey;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
}
function useSuspenseRouteQuery(route, queryName, queryOverrides) {
	const $ = c(12);
	assertHasUIServiceConfig(route, queryName);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { strict: false };
		$[0] = t0;
	} else t0 = $[0];
	const params = useParams(t0);
	const searchStr = useCommittedSearchStr(route);
	let t1;
	if ($[1] !== params || $[2] !== queryName || $[3] !== route || $[4] !== searchStr) {
		t1 = getTssQueryConfig(route, queryName).options({
			params,
			searchStr
		});
		$[1] = params;
		$[2] = queryName;
		$[3] = route;
		$[4] = searchStr;
		$[5] = t1;
	} else t1 = $[5];
	const options = t1;
	let t2;
	if ($[6] !== options || $[7] !== queryOverrides) {
		t2 = {
			...options,
			...queryOverrides
		};
		$[6] = options;
		$[7] = queryOverrides;
		$[8] = t2;
	} else t2 = $[8];
	const t3 = useSuspenseQuery(t2);
	let t4;
	if ($[9] !== options.queryKey || $[10] !== t3) {
		t4 = {
			...t3,
			queryKey: options.queryKey
		};
		$[9] = options.queryKey;
		$[10] = t3;
		$[11] = t4;
	} else t4 = $[11];
	return t4;
}
function useChildRouteQuery(route, queryName, queryOverrides) {
	const $ = c(13);
	assertHasUIServiceConfig(route, queryName);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { strict: false };
		$[0] = t0;
	} else t0 = $[0];
	const params = useParams(t0);
	const searchStr = useCommittedSearchStr(route);
	let t1;
	let tssConfig;
	if ($[1] !== params || $[2] !== queryName || $[3] !== route || $[4] !== searchStr) {
		tssConfig = getTssQueryConfig(route, queryName);
		t1 = tssConfig.options({
			params,
			searchStr
		});
		$[1] = params;
		$[2] = queryName;
		$[3] = route;
		$[4] = searchStr;
		$[5] = t1;
		$[6] = tssConfig;
	} else {
		t1 = $[5];
		tssConfig = $[6];
	}
	const options = t1;
	let t2;
	if ($[7] !== options || $[8] !== queryOverrides) {
		t2 = {
			...options,
			...queryOverrides
		};
		$[7] = options;
		$[8] = queryOverrides;
		$[9] = t2;
	} else t2 = $[9];
	const t3 = useStreamingCompatibleQuery(t2, tssConfig.mode);
	let t4;
	if ($[10] !== options.queryKey || $[11] !== t3) {
		t4 = {
			...t3,
			queryKey: options.queryKey
		};
		$[10] = options.queryKey;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
}
export { useRouteQuery as n, useSuspenseRouteQuery as r, useChildRouteQuery as t };
