import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { c } from "react/compiler-runtime";
function useChatPayload() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			queryKey: ["pull-request-side-panel", "chat-payload"],
			queryFn: _temp,
			staleTime: Infinity
		};
		$[0] = t0;
	} else t0 = $[0];
	return useQuery(t0);
}
async function _temp() {
	const resp = await verifiedFetchJSON("/github-copilot/chat");
	if (!resp.ok) throw new Error(`Failed to fetch chat provider: ${resp.statusText}`);
	return await resp.json();
}
export { useChatPayload as t };
