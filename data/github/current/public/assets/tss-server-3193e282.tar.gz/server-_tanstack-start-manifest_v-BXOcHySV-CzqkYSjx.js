performance.mark("js-parse-end:server-_tanstack-start-manifest_v-BXOcHySV-CzqkYSjx.js");
performance.mark("js-parse-end:_tanstack-start-manifest_v-BXOcHySV.js");
var tsrStartManifest = () => ({
	"routes": {
		"__root__": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/root.tsx",
			"children": [
				"/_nav",
				"/healthcheck",
				"/ui/version"
			],
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/main-Czp8eV6A.js"]
		},
		"/_nav": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/root/global-nav-layout.tsx",
			"children": [
				"/_nav/_pulls_layout",
				"/_nav/_react_sandbox_future",
				"/_nav/_repos_layout",
				"/_nav/$owner/$repo/_repo_layout"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/global-nav-layout-DXWYZGDv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/staffbar-C9lNBvIr.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/global-nav-layout-DXhIzCLs.js",
				"https://github.githubassets.com/assets/copilot-local-storage-CRuFAzgZ.js",
				"https://github.githubassets.com/assets/connect-alive-subscription-jiX06hF2.js",
				"https://github.githubassets.com/assets/Avatar-BCG4i2eC.js",
				"https://github.githubassets.com/assets/ButtonGroup-CTU7nL4I.js",
				"https://github.githubassets.com/assets/useQuery-RF5wujTO.js",
				"https://github.githubassets.com/assets/create-safe-indexed-db-storage-5hhTUnfm.js",
				"https://github.githubassets.com/assets/immer-B674F3WE.js",
				"https://github.githubassets.com/assets/typebox-_AYx4x8u.js",
				"https://github.githubassets.com/assets/cookies-CF80j-p_.js",
				"https://github.githubassets.com/assets/copilot-auth-token-Bft79XyC.js",
				"https://github.githubassets.com/assets/copilot-chat-events-CXqsQJJ1.js",
				"https://github.githubassets.com/assets/copilot-chat-helpers-B4dpPi2Z.js",
				"https://github.githubassets.com/assets/GitHubAvatar-DzBkkOPk.js",
				"https://github.githubassets.com/assets/global-navigation-D7kzuFAs.js",
				"https://github.githubassets.com/assets/constants-DvGZlDXI.js",
				"https://github.githubassets.com/assets/constants-BThHgcqt.js",
				"https://github.githubassets.com/assets/LazyGlobalSsoBanner-6WdN7BNg.js",
				"https://github.githubassets.com/assets/CoreSsoBanner-D8oSCJcW.js",
				"https://github.githubassets.com/assets/in-product-targeting-CudHY8_H.js",
				"https://github.githubassets.com/assets/IncludeFragment-5TinJI7H.js",
				"https://github.githubassets.com/assets/ItemPicker-C1mPZI7o.js",
				"https://github.githubassets.com/assets/strings-ByOzyJLS.js",
				"https://github.githubassets.com/assets/NavigableRef-Cj-O6lhb.js",
				"https://github.githubassets.com/assets/CustomIcon-Dwj8sDWf.js",
				"https://github.githubassets.com/assets/ErrorBoundary-IFb1nsby.js",
				"https://github.githubassets.com/assets/Link-Pur7V-h-.js",
				"https://github.githubassets.com/assets/lazy-with-preload-D6_Bt-7s.js",
				"https://github.githubassets.com/assets/react-partial-anchor-Dodfol_7.js",
				"https://github.githubassets.com/assets/react-query-persister-CX6EJNYw.js",
				"https://github.githubassets.com/assets/staffbar.module-y8m2bGwL.js",
				"https://github.githubassets.com/assets/use-route-query-BaBfKjNo.js",
				"https://github.githubassets.com/assets/use-alive-2ayi1EeE.js",
				"https://github.githubassets.com/assets/use-is-mounted-BiZOPfD3.js"
			]
		},
		"/_nav/_pulls_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/layout.tsx",
			"children": ["/_nav/_pulls_layout/pulls"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-DJFcgZlv.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposSelector-DzcPtoeR.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/UserFeedback-TRB_fcnh.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-DSbupe4U.js",
				"https://github.githubassets.com/assets/react-relay-DdqfyBwk.js",
				"https://github.githubassets.com/assets/dashboard-types-C7zpMbD-.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/PageLayout-BY7uZIEr.js",
				"https://github.githubassets.com/assets/Filter-CZww5h5P.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-B1Q5R849.js",
				"https://github.githubassets.com/assets/use-user-CpH6j0pI.js",
				"https://github.githubassets.com/assets/PreviewCard-BPiAcTct.js",
				"https://github.githubassets.com/assets/ReposSelector-DZTPXYK9.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-cTkZqH1O.js",
				"https://github.githubassets.com/assets/use-app-payload-kaB603Zk.js",
				"https://github.githubassets.com/assets/use-stable-random-CVs1QP4Z.js",
				"https://github.githubassets.com/assets/UserFeedback-N_ylHoHb.js"
			]
		},
		"/_nav/_react_sandbox_future": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-layout.tsx",
			"children": ["/_nav/_react_sandbox_future/react_sandbox_future/", "/_nav/_react_sandbox_future/react_sandbox_future/$id"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/react-sandbox-future-layout-CA3XD2Yu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-layout-ByW3VBkX.js", "https://github.githubassets.com/assets/PageLayout-BY7uZIEr.js"]
		},
		"/_nav/_repos_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/layout.tsx",
			"children": ["/_nav/_repos_layout/repos"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/layout-BYQps9c3.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Filter-DwaMWQwQ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CoreSsoBanner-BbqIAe9C.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LoadingSkeleton-Da6NX0pO.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-BY-dfG6K.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/PageLayout-BY7uZIEr.js",
				"https://github.githubassets.com/assets/Filter-CZww5h5P.js",
				"https://github.githubassets.com/assets/ContextualGlobalSsoBanner-B1Q5R849.js",
				"https://github.githubassets.com/assets/use-feature-flag-C-pIEELi.js",
				"https://github.githubassets.com/assets/ReposFinderStateContext-ChStMTN0.js",
				"https://github.githubassets.com/assets/LoadingSkeleton-cTkZqH1O.js",
				"https://github.githubassets.com/assets/use-app-payload-kaB603Zk.js",
				"https://github.githubassets.com/assets/use-stable-random-CVs1QP4Z.js"
			]
		},
		"/_nav/_pulls_layout/pulls": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/pulls/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/pulls-DyzpB9ty.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelToken-Cj_rz1dY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/pulls-D2CBCw7s.js",
				"https://github.githubassets.com/assets/Pagination-DMe3SjgS.js",
				"https://github.githubassets.com/assets/LabelToken--leXHIeY.js",
				"https://github.githubassets.com/assets/use-get-hovercard-attributes-for-type-D4avcmgl.js",
				"https://github.githubassets.com/assets/Icons-Bbsr9XUu.js",
				"https://github.githubassets.com/assets/ProfileReference-C2oPxYrb.js"
			]
		},
		"/_nav/_repos_layout/repos": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/repos/index.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Pagination-CWSVrxKT.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": ["https://github.githubassets.com/assets/repos-7h0DzH9B.js", "https://github.githubassets.com/assets/Pagination-DMe3SjgS.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-index.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-index-Dk7Uxq3k.js"]
		},
		"/_nav/_react_sandbox_future/react_sandbox_future/$id": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/react_sandbox_future/react-sandbox-future-id.tsx",
			"assets": [{
				"tag": "link",
				"attrs": {
					"rel": "stylesheet",
					"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
					"type": "text/css"
				}
			}],
			"preloads": ["https://github.githubassets.com/assets/react-sandbox-future-id--Sn6gVYy.js"]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScrollMarksContainer-jgZd6-5D.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/layout-CZWuJ0nj.js",
				"https://github.githubassets.com/assets/PageLayout-BY7uZIEr.js",
				"https://github.githubassets.com/assets/TreeView-CEde2ON2.js",
				"https://github.githubassets.com/assets/SkeletonText-DIgwfdCq.js",
				"https://github.githubassets.com/assets/use-is-data-router-enabled-B_Z0NMjW.js",
				"https://github.githubassets.com/assets/repos-file-tree-view-QV_UFxOm.js",
				"https://github.githubassets.com/assets/CodeLine-B1HxklZj.js",
				"https://github.githubassets.com/assets/AllShortcutsEnabled-Gl1k6mTp.js",
				"https://github.githubassets.com/assets/HiddenUnicodeCharacter-X-YqLRHn.js",
				"https://github.githubassets.com/assets/ReposHeaderRefSelector-DsYmQntu.js",
				"https://github.githubassets.com/assets/FileResultsList-ClHwTXyt.js",
				"https://github.githubassets.com/assets/CodeViewBannersContext-jONsmLTP.js",
				"https://github.githubassets.com/assets/CopilotSettingsContext-D_fV-bFB.js",
				"https://github.githubassets.com/assets/EditPermissionsContext-C0QLeqls.js",
				"https://github.githubassets.com/assets/find-file-CFLaItol.js",
				"https://github.githubassets.com/assets/FilesPageInfoContext-BbbOFrko.js",
				"https://github.githubassets.com/assets/CodeViewOptionsProvider-uXaUhce5.js",
				"https://github.githubassets.com/assets/CodeNavSymbolNavigation-DiFcBbLM.js",
				"https://github.githubassets.com/assets/ScrollMarksContainer-XUNp-6U3.js",
				"https://github.githubassets.com/assets/CodeNavContext-BPKiP1zT.js",
				"https://github.githubassets.com/assets/TreePaneContext-CWYfVTjQ.js",
				"https://github.githubassets.com/assets/ExpandButton-BggF6zDd.js",
				"https://github.githubassets.com/assets/history-C9gKFara.js",
				"https://github.githubassets.com/assets/NewAgentTaskButton-DkzdRQT1.js",
				"https://github.githubassets.com/assets/react-observable-B9b8ieQL.js",
				"https://github.githubassets.com/assets/PortalTooltip-EVUJjjtH.js",
				"https://github.githubassets.com/assets/use-route-payload-id7Mm77D.js",
				"https://github.githubassets.com/assets/RefSelector-CuKCg5HQ.js",
				"https://github.githubassets.com/assets/ScreenSize-Dedl8Le3.js",
				"https://github.githubassets.com/assets/use-app-payload-kaB603Zk.js",
				"https://github.githubassets.com/assets/use-file-tree-tooltip-C0k_9dXn.js",
				"https://github.githubassets.com/assets/use-is-platform-DKzVQFFN.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/repo-overview.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/repo-overview-DalKHsJR.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-DsH8sxGE.js",
				"https://github.githubassets.com/assets/CircleOcticon-wl0Kvay8.js",
				"https://github.githubassets.com/assets/use-codespaces-data-Y-fhnkX5.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-CA_OeLxY.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-YfRBBuc_.js",
				"https://github.githubassets.com/assets/PublishBanners-BJjUj8-0.js",
				"https://github.githubassets.com/assets/LatestCommitContext-DyAI7chM.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/SharedPageLayout-CZdb5iyI.js",
				"https://github.githubassets.com/assets/commit-checks-status-BZTrDMyr.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CC9ByIKm.js",
				"https://github.githubassets.com/assets/ProfileReference-C2oPxYrb.js",
				"https://github.githubassets.com/assets/use-page-data-url-BIWed2-F.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-BUxN8asD.js",
				"https://github.githubassets.com/assets/use-latest-commit-CanuO10T.js",
				"https://github.githubassets.com/assets/use-web-vitals-BjkDP7Le.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/file-tree-layout.tsx",
			"children": [
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$",
				"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$"
			],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/file-tree-layout-B2kVSyVy.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SharedPageLayout-kmFQ-Zzm.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/file-tree-layout-Z_RweuFy.js",
				"https://github.githubassets.com/assets/overview-types-iJX8LBpY.js",
				"https://github.githubassets.com/assets/SharedPageLayout-CZdb5iyI.js",
				"https://github.githubassets.com/assets/use-hide-footer-BGAo67Md.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob-layout.tsx",
			"children": ["/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$", "/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$"],
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-layout-v7tkwSpU.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-YfRBBuc_.js",
				"https://github.githubassets.com/assets/LatestCommitContext-DyAI7chM.js",
				"https://github.githubassets.com/assets/NavigationMenu-BjbbLdvu.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DDR7JjVF.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CC9ByIKm.js",
				"https://github.githubassets.com/assets/Breadcrumb-Dznu0ISZ.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-BUxN8asD.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/delete-CXUWQiRx.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-YfRBBuc_.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/NavigationMenu-BjbbLdvu.js",
				"https://github.githubassets.com/assets/EditIssues-g3ljbS4K.js",
				"https://github.githubassets.com/assets/DeleteViewContent-BtbKmhNM.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DDR7JjVF.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CC9ByIKm.js",
				"https://github.githubassets.com/assets/diff-parts-C_jTjV7e.js",
				"https://github.githubassets.com/assets/Breadcrumb-Dznu0ISZ.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-BUxN8asD.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/edit/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/edit.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/edit-BMuj3NOR.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/CodeViewEditor-DrIf9gkd.js",
				"https://github.githubassets.com/assets/SuspenseFallback-bEMiiGmh.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/new/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/new.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/new-BIuHHZSZ.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/CodeViewEditor-DrIf9gkd.js",
				"https://github.githubassets.com/assets/SuspenseFallback-bEMiiGmh.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/tree-CEjCnYpa.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ReposOverviewPage-D5emX-sZ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CircleOcticon-DT6ytCt5.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeDropdownButton-CQg1HOv0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/in-product-targeting-BcFL_OCS.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ErrorBoundary-BOXd9sG_.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-mjC0Je1X.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/ReposOverviewPage-DsH8sxGE.js",
				"https://github.githubassets.com/assets/CircleOcticon-wl0Kvay8.js",
				"https://github.githubassets.com/assets/use-codespaces-data-Y-fhnkX5.js",
				"https://github.githubassets.com/assets/CodeDropdownButton-CA_OeLxY.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-YfRBBuc_.js",
				"https://github.githubassets.com/assets/PublishBanners-BJjUj8-0.js",
				"https://github.githubassets.com/assets/LatestCommitContext-DyAI7chM.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/NavigationMenu-BjbbLdvu.js",
				"https://github.githubassets.com/assets/CodeViewBanners-0gWujYzp.js",
				"https://github.githubassets.com/assets/Panel-B7zQayB9.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DDR7JjVF.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js",
				"https://github.githubassets.com/assets/commit-checks-status-BZTrDMyr.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CC9ByIKm.js",
				"https://github.githubassets.com/assets/BetaLabel-DxdiCDpz.js",
				"https://github.githubassets.com/assets/LabelWithLink-CnlhcHXb.js",
				"https://github.githubassets.com/assets/ProfileReference-C2oPxYrb.js",
				"https://github.githubassets.com/assets/use-page-data-url-BIWed2-F.js",
				"https://github.githubassets.com/assets/Breadcrumb-Dznu0ISZ.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-BUxN8asD.js",
				"https://github.githubassets.com/assets/use-latest-commit-CanuO10T.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DqXnMCO8.js",
				"https://github.githubassets.com/assets/use-web-vitals-BjkDP7Le.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blame/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blame.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blame-m77oP1Mm.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/BlobViewContent-jVdTfdLK.js",
				"https://github.githubassets.com/assets/PublishBanners-BJjUj8-0.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/CodeViewBanners-0gWujYzp.js",
				"https://github.githubassets.com/assets/Panel-B7zQayB9.js",
				"https://github.githubassets.com/assets/SuspenseFallback-bEMiiGmh.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js",
				"https://github.githubassets.com/assets/commit-checks-status-BZTrDMyr.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-DX6pgesV.js",
				"https://github.githubassets.com/assets/CopilotPopover-NvIazUPD.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-G_rthWPg.js",
				"https://github.githubassets.com/assets/FeatureRequest-CkdfgSqr.js",
				"https://github.githubassets.com/assets/BetaLabel-DxdiCDpz.js",
				"https://github.githubassets.com/assets/LabelWithLink-CnlhcHXb.js",
				"https://github.githubassets.com/assets/ProfileReference-C2oPxYrb.js",
				"https://github.githubassets.com/assets/use-feature-flag-C-pIEELi.js",
				"https://github.githubassets.com/assets/use-contributors-D5ioX7JS.js",
				"https://github.githubassets.com/assets/use-latest-commit-CanuO10T.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DqXnMCO8.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/_blob_layout/blob/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/blob.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/BlobViewContent-1ErDkXYp.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeViewBanners-CozmumuW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PublishBanners-C5LqFoM4.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Panel-ErmkviJf.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeNavSymbolNavigation-DhfT6vUd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/commit-checks-status-BdegVRnJ.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AvatarStack-DC_gU9Bl.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopilotPopover-CDQJ7GnU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SpacesOwnerDropdown-UwSvB4-I.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/LabelWithLink-BRyloEbu.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/blob-DHwQIzln.js",
				"https://github.githubassets.com/assets/AvatarStack-Wte014P5.js",
				"https://github.githubassets.com/assets/BlobViewContent-jVdTfdLK.js",
				"https://github.githubassets.com/assets/PublishBanners-BJjUj8-0.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/CodeViewBanners-0gWujYzp.js",
				"https://github.githubassets.com/assets/Panel-B7zQayB9.js",
				"https://github.githubassets.com/assets/SuspenseFallback-bEMiiGmh.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js",
				"https://github.githubassets.com/assets/commit-checks-status-BZTrDMyr.js",
				"https://github.githubassets.com/assets/custom-copilots-helpers-DX6pgesV.js",
				"https://github.githubassets.com/assets/CopilotPopover-NvIazUPD.js",
				"https://github.githubassets.com/assets/SpacesOwnerDropdown-G_rthWPg.js",
				"https://github.githubassets.com/assets/FeatureRequest-CkdfgSqr.js",
				"https://github.githubassets.com/assets/BetaLabel-DxdiCDpz.js",
				"https://github.githubassets.com/assets/LabelWithLink-CnlhcHXb.js",
				"https://github.githubassets.com/assets/ProfileReference-C2oPxYrb.js",
				"https://github.githubassets.com/assets/use-feature-flag-C-pIEELi.js",
				"https://github.githubassets.com/assets/use-contributors-D5ioX7JS.js",
				"https://github.githubassets.com/assets/use-latest-commit-CanuO10T.js",
				"https://github.githubassets.com/assets/use-sticky-observer-DqXnMCO8.js"
			]
		},
		"/_nav/$owner/$repo/_repo_layout/_codeview_layout/_file_tree_layout/tree/delete/$branch/$": {
			"filePath": "/workspace/github-ui/packages/tss-server/src/routes/code-view/tree-delete.tsx",
			"assets": [
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Avatar-CeAuHgrE.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/NavigationMenu-DNugEJr0.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/repos-file-tree-view-iAHTpK4m.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/TreeView-DBtSRkGe.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/SkeletonText-BKnCJ1Y8.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/AddFileDropdownButton-Bok3wt5n.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/FileResultsList-B9UxEzc7.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/DeleteViewContent-BD3lPt44.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/EditIssues-C_-mLTkA.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeView-BI3vmOsV.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CodeLine-tUUaCiCX.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ButtonGroup-BR1aQ07o.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/HiddenUnicodeCharacter-DSEV8ykd.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/diff-parts-rbfnk_ra.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PortalTooltip-CnwyIXuU.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/RefSelector-C05F-h-N.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/Breadcrumb-zPCqvDAi.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/PageLayout-Ct5M7mP1.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/CopyToClipboardButton-CGQh9qCY.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/ScreenReaderHeading-mJ67QCUP.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				},
				{
					"tag": "link",
					"attrs": {
						"rel": "stylesheet",
						"href": "https://github.githubassets.com/assets/main-CB8eBnNW.css#",
						"type": "text/css"
					}
				}
			],
			"preloads": [
				"https://github.githubassets.com/assets/tree-delete-n3tUf4le.js",
				"https://github.githubassets.com/assets/AddFileDropdownButton-YfRBBuc_.js",
				"https://github.githubassets.com/assets/use-update-ref-info-and-path-C6W8a0Xu.js",
				"https://github.githubassets.com/assets/NavigationMenu-BjbbLdvu.js",
				"https://github.githubassets.com/assets/EditIssues-g3ljbS4K.js",
				"https://github.githubassets.com/assets/DeleteViewContent-BtbKmhNM.js",
				"https://github.githubassets.com/assets/FindInFileOpenContext-EnaAn9Lz.js",
				"https://github.githubassets.com/assets/use-scroll-line-into-view-DDR7JjVF.js",
				"https://github.githubassets.com/assets/CodeView-gaYx1gBH.js",
				"https://github.githubassets.com/assets/CopyToClipboardButton-CC9ByIKm.js",
				"https://github.githubassets.com/assets/diff-parts-C_jTjV7e.js",
				"https://github.githubassets.com/assets/Breadcrumb-Dznu0ISZ.js",
				"https://github.githubassets.com/assets/ScreenReaderHeading-BUxN8asD.js"
			]
		}
	},
	"clientEntry": "https://github.githubassets.com/assets/main-Czp8eV6A.js"
});
export { tsrStartManifest };
