import { EditorView, showPanel } from "@codemirror/view";
import { EditorSelection } from "@codemirror/state";
import { SearchCursor } from "@codemirror/search";
import { indentUnit } from "@codemirror/language";
var getCursor = (view) => {
	return view.state.selection.main;
};
var setCursor = (view, newPosition) => {
	view.dispatch({ selection: { anchor: newPosition } });
};
var somethingSelected = (view) => {
	return view.state.selection.ranges.some((r) => !r.empty);
};
var getSelection = (state) => {
	return state.sliceDoc(state.selection.main.from, state.selection.main.to);
};
var setSelection = (view, startPosition, endPosition) => {
	view.dispatch({ selection: {
		anchor: startPosition,
		head: endPosition
	} });
};
function posToOffset(view, pos) {
	return view.state.doc.line(pos.line + 1).from + pos.ch;
}
function offsetToPos(view, offset) {
	const line = view.state.doc.lineAt(offset);
	return {
		line: line.number - 1,
		ch: offset - line.from
	};
}
var getLine = (view, lineNumber) => {
	return view.state.doc.line(lineNumber);
};
var insertAtStartOfLine = (view, lineNumber, text) => {
	const line = getLine(view, lineNumber);
	replaceRange(view, line.from, line.from, text);
};
var removeFromStartOfLine = (view, lineNumber, text) => {
	const line = getLine(view, lineNumber);
	replaceRange(view, line.from, line.from + text.length, "");
};
var replaceSelection = (view, text) => {
	view.dispatch(view.state.replaceSelection(text));
};
var getRange = (state, from, to) => {
	return state.sliceDoc(from, to);
};
var replaceRange = (view, from, to, text) => {
	view.dispatch({ changes: {
		from,
		to,
		insert: text
	} });
};
var insertAtCursor = (view, text) => {
	const cursor = getCursor(view);
	replaceRange(view, cursor.from, cursor.to, text);
};
/**
* Find the first occurrence of search in the document
*/
var find = (view, search) => {
	return new SearchCursor(view.state.doc, search).next();
};
/**
* Find and replace the first occurrence of search in the document
*/
var findAndReplace = (view, search, replace) => {
	const match = new SearchCursor(view.state.doc, search).next();
	view.dispatch({ changes: {
		from: match.value.from,
		to: match.value.to,
		insert: replace
	} });
};
var moveCursorToPositionAndScroll = (view, startLine, endLine, startColumn, endColumn) => {
	if (endLine !== void 0) try {
		const startLineElement = getLine(view, startLine);
		const endLineElement = getLine(view, endLine);
		if (startLineElement && endLineElement) {
			view.focus();
			const selectionEnd = endColumn ? endLineElement.from + endColumn : endLineElement.to;
			setSelection(view, startLineElement.from + (startColumn ?? 0), selectionEnd);
			view.dispatch({ effects: [EditorView.scrollIntoView(EditorSelection.range(startLineElement.from, endLineElement.to), { y: "center" })] });
		}
	} catch {}
	else try {
		const lineElement = getLine(view, startLine);
		if (lineElement) {
			view.focus();
			setCursor(view, lineElement.from + (startColumn ?? 0));
			view.dispatch({ effects: [EditorView.scrollIntoView(lineElement.from, { y: "center" })] });
		}
	} catch {}
};
function getIndentationUnit(view) {
	return view.state.facet(indentUnit);
}
/**
* Compute minimal change between two strings to avoid scroll jitter.
* Uses a simple diff algorithm to find common prefixes and suffixes.
*
* @param oldText - The original text content
* @param newText - The new text content to replace with
* @returns Array containing a single change specification for CodeMirror, or empty array if no change needed
*/
function computeMinimalChange(oldText, newText) {
	if (oldText === newText) return [];
	let start = 0;
	const minLength = Math.min(oldText.length, newText.length);
	while (start < minLength && oldText[start] === newText[start]) start++;
	let oldEnd = oldText.length;
	let newEnd = newText.length;
	while (oldEnd > start && newEnd > start && oldText[oldEnd - 1] === newText[newEnd - 1]) {
		oldEnd--;
		newEnd--;
	}
	return [{
		from: start,
		to: oldEnd,
		insert: newText.slice(start, newEnd)
	}];
}
/**
* Creates a help panel extension from an HTMLElement
* @param panelDom help panel HTMLElement
* @param position position of the help panel, either 'top' or 'bottom'
* @returns help panel extension
*/
function helpPanelConstructor(panelDom = null, position = "bottom") {
	const panelConstructor = () => {
		return {
			dom: panelDom,
			top: position === "top"
		};
	};
	return [showPanel.of(panelConstructor)];
}
var autocompleteTheme = EditorView.baseTheme({
	".cm-tooltip.cm-tooltip-autocomplete": {
		border: 0,
		backgroundColor: "transparent"
	},
	".cm-tooltip.cm-tooltip-autocomplete > ul": {
		fontFamily: "var(--fontStack-monospace)",
		fontSize: "12px",
		backgroundColor: "var(--bgColor-default, var(--color-canvas-default))",
		border: "1px solid var(--borderColor-default, var(--color-border-default))",
		borderRadius: "var(--borderRadius-medium)",
		boxShadow: "var(--shadow-resting-medium, var(--color-shadow-medium))",
		minWidth: "auto"
	},
	".cm-tooltip.cm-tooltip-autocomplete li[role=\"option\"]": {
		padding: "2px 8px",
		margin: 0,
		color: "var(--fgColor-default, var(--color-fg-default))",
		whiteSpace: "pre"
	},
	".cm-tooltip.cm-tooltip-autocomplete li[role=\"option\"]:first-child": {
		borderTopLeftRadius: "var(--borderRadius-medium)",
		borderTopRightRadius: "var(--borderRadius-medium)"
	},
	".cm-tooltip.cm-tooltip-autocomplete li[role=\"option\"]:last-child": {
		borderBottomLeftRadius: "var(--borderRadius-medium)",
		borderBottomRightRadius: "var(--borderRadius-medium)"
	},
	".cm-tooltip.cm-tooltip-autocomplete ul li[aria-selected], .cm-tooltip.cm-tooltip-autocomplete ul li[aria-selected] .cm-completionDetail": {
		color: "var(--fgColor-onEmphasis, var(--color-fg-on-emphasis))",
		background: "var(--bgColor-accent-emphasis, var(--color-accent-emphasis))"
	},
	".cm-completionDetail": {
		paddingLeft: "8px",
		color: "var(--fgColor-muted, var(--color-fg-muted))",
		fontSize: "var(--fontSize-small)",
		fontStyle: "normal"
	}
});
export { replaceRange as _, getCursor as a, setSelection as b, getRange as c, insertAtCursor as d, insertAtStartOfLine as f, removeFromStartOfLine as g, posToOffset as h, findAndReplace as i, getSelection as l, offsetToPos as m, computeMinimalChange as n, getIndentationUnit as o, moveCursorToPositionAndScroll as p, find as r, getLine as s, autocompleteTheme as t, helpPanelConstructor as u, replaceSelection as v, somethingSelected as x, setCursor as y };
