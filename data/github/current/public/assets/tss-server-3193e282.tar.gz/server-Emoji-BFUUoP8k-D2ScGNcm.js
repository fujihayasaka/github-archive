import { createElement } from "react";
import { Fragment as Fragment$1, jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
var emoji_module_default = {
	emojiContainer: "emoji-module_aWQfxG_emojiContainer",
	emojiIcon: "emoji-module_aWQfxG_emojiIcon"
};
function Emoji(props) {
	const { class: classAttribute } = props.attributes;
	const classes = clsx(classAttribute, emoji_module_default.emojiIcon);
	const attributes = { ...props.attributes };
	delete attributes.class;
	switch (props.tag) {
		case "g-emoji": return createElement(props.tag, {
			...attributes,
			tone: props.tone,
			class: classes
		}, props.raw);
		case "img": return /* @__PURE__ */ jsx("img", {
			alt: "",
			src: props.imgPath,
			...attributes,
			className: classes
		});
	}
	return /* @__PURE__ */ jsx(Fragment$1, {});
}
Emoji.displayName = "Emoji";
export { Emoji as t };
