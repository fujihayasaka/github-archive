import { a as ssrSafeWindow, i as ssrSafeLocation, r as ssrSafeHistory } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
var lastState = null;
function currentState() {
	return ssrSafeHistory?.state || {};
}
function updateUrl(newUrl) {
	replaceStateWithEvent(currentState(), "", newUrl);
}
function addUrlToHistoryStack(newUrl) {
	ssrSafeHistory?.pushState({ appId: currentState().appId }, "", newUrl);
	dispatchStateChange();
}
function updateCurrentState(state) {
	const mergedState = {
		...currentState(),
		...state
	};
	if (lastState) lastState = mergedState;
	replaceStateWithEvent(mergedState, "", location.href);
}
function updateSearchParams(searchParams) {
	updateUrl(`?${searchParams.toString()}${ssrSafeLocation.hash}`);
}
function updateUrlHash(hash) {
	updateUrl(hash.startsWith("#") ? hash : `#${hash}`);
	lastState = currentState();
	if (!lastState) return;
	requestIdleCallback(() => {
		if (!history.state && lastState) {
			updateCurrentState(lastState);
			lastState = null;
		}
	});
}
function removeUrlHash() {
	updateUrl(ssrSafeLocation.pathname + ssrSafeLocation.search);
}
function goBack() {
	ssrSafeHistory?.back();
}
function goForward() {
	ssrSafeHistory?.forward();
}
function replaceStateWithEvent(data, unused, url) {
	ssrSafeHistory?.replaceState(data, unused, url);
	dispatchStateChange();
}
function dispatchStateChange() {
	ssrSafeWindow?.dispatchEvent(new CustomEvent("statechange", {
		bubbles: false,
		cancelable: false
	}));
}
export { updateSearchParams as a, removeUrlHash as i, goBack as n, updateUrl as o, goForward as r, updateUrlHash as s, addUrlToHistoryStack as t };
