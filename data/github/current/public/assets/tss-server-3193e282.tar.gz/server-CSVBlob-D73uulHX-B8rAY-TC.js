performance.mark("js-parse-end:server-CSVBlob-D73uulHX-B8rAY-TC.js");
import { wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as ScrollableRegion } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { G as showHiddenUnicodeCharacters, L as hasHiddenUnicodeCharacters, Q as useCurrentLineHeight, R as isHiddenUnicodeShown, U as parseFileAnchor, at as useHighlightedLinesInfo, f as HiddenUnicodeAlert, g as HighlightedLinesProvider, m as HighlightedLineMenuContainer, y as LineNumber, z as isLineInViewport } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import React, { useCallback, useEffect, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { useWindowVirtualizer } from "@tanstack/react-virtual";
performance.mark("js-parse-end:CSVBlob-D73uulHX.js");
var CSVBlob_module_default = {
	csvFilter: "CSVBlob-module_n9T_-G_csvFilter",
	csvTable: "CSVBlob-module_n9T_-G_csvTable"
};
function CSVBlob({ csv }) {
	const tableHandle = useRef(null);
	const [highlightedLines, setHighlightedLines] = useHighlightedLines();
	const csvRows = toCSVData(csv, highlightedLines);
	const showHiddenUnicodeAlert = csvRows.some((row) => row.hiddenUnicode);
	const { anchorPrefix } = parseFileAnchor(useLocation$1().hash);
	const onLineNumberClick = useCallback(() => {
		setHighlightedLines(parseFileAnchor(window.location.hash)?.blobRange);
	}, [setHighlightedLines]);
	useEffect(() => {
		const anchorInfo = parseFileAnchor(window.location.hash);
		const table = tableHandle.current;
		if (!highlightedLines || !table) return;
		if (isLineInViewport(anchorInfo.blobRange.start.line)) return;
		if (highlightedLines.start.line < 10) tableHandle.current?.scrollToTop();
		else tableHandle.current?.scrollToLine(anchorInfo.blobRange.start.line);
	}, [highlightedLines, anchorPrefix]);
	return /* @__PURE__ */ jsxs(HighlightedLinesProvider, {
		highlightedLines,
		children: [
			/* @__PURE__ */ jsx(CSVFilter, { onFilterChange: (query) => tableHandle.current?.setFilter(query) }),
			showHiddenUnicodeAlert && /* @__PURE__ */ jsx(HiddenUnicodeAlert, {}),
			/* @__PURE__ */ jsx(HighlightedLineMenuContainer, { children: /* @__PURE__ */ jsx(CSVTable, {
				ref: tableHandle,
				csvRows,
				onLineNumberClick
			}) })
		]
	});
}
CSVBlob.displayName = "CSVBlob";
function CSVFilter({ onFilterChange }) {
	return /* @__PURE__ */ jsx("div", {
		className: CSVBlob_module_default.csvFilter,
		children: /* @__PURE__ */ jsx(TextInput$1, {
			"aria-label": "Search this file",
			autoCapitalize: "off",
			leadingVisual: SearchIcon,
			onChange: (e) => {
				onFilterChange(e.target.value.toLowerCase());
			},
			block: true,
			name: "filter",
			placeholder: "Search this file",
			type: "text"
		})
	});
}
CSVFilter.displayName = "CSVFilter";
function CSVTable({ csvRows, onLineNumberClick, ref }) {
	"use no memo";
	const [filter, setFilter] = useState(null);
	const parentRef = useRef(null);
	const currentLineHeight = useCurrentLineHeight("react-csv-table-body", 35);
	const filteredCSVRows = useMemo(() => filter ? csvRows.slice(1).filter((row) => row.cells.join(" ").toLowerCase().includes(filter.toLowerCase())) : csvRows.slice(1), [csvRows, filter]);
	const [parentOffset, setParentOffset] = useState(0);
	useLayoutEffect(() => {
		setParentOffset(parentRef.current?.offsetTop ?? 0);
	}, []);
	const virtualizer = useWindowVirtualizer({
		count: filteredCSVRows.length,
		overscan: 200,
		estimateSize: useCallback(() => currentLineHeight, [currentLineHeight]),
		scrollMargin: parentOffset
	});
	useImperativeHandle(ref, () => ({
		scrollToTop: () => virtualizer.scrollToIndex(0, { align: "start" }),
		scrollToLine: (lineNumber) => {
			const index = filteredCSVRows.findIndex((row_0) => row_0.lineNumber === lineNumber);
			virtualizer.scrollToIndex(index, { align: "start" });
		},
		setFilter
	}));
	return /* @__PURE__ */ jsx(ScrollableRegion, {
		"aria-labelledby": "LC1",
		children: /* @__PURE__ */ jsx("table", {
			ref: parentRef,
			className: CSVBlob_module_default.csvTable,
			style: {
				height: virtualizer.getTotalSize() + currentLineHeight,
				paddingTop: `${virtualizer.getVirtualItems()[0]?.start ?? 0}px`
			},
			"data-hpc": true,
			"data-testid": "csv-table",
			children: csvRows.length > 0 && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CSVHeader, {
				hiddenUnicode: csvRows[0].hiddenUnicode,
				cells: csvRows[0].cells,
				onLineNumberClick
			}), /* @__PURE__ */ jsx("tbody", {
				className: "react-csv-table-body",
				children: virtualizer.getVirtualItems().map((virtualItem) => {
					const { cells, hiddenUnicode, lineNumber: lineNumber_0 } = filteredCSVRows[virtualItem.index];
					return /* @__PURE__ */ jsx(CSVRow, {
						lineNumber: lineNumber_0,
						cells,
						hiddenUnicode,
						onLineNumberClick
					}, lineNumber_0);
				})
			})] })
		})
	});
}
CSVTable.displayName = "CSVTable";
var CSVHeader = React.memo(CSVHeaderUnmemoized);
CSVHeader.displayName = "CSVHeader";
function CSVHeaderUnmemoized({ cells, hiddenUnicode, onLineNumberClick }) {
	return /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", {
		id: `LC1`,
		className: "react-csv-row",
		children: [/* @__PURE__ */ jsx("th", {
			className: "react-csv-line-number",
			children: /* @__PURE__ */ jsx(LineNumber, {
				codeLineData: {
					lineNumber: 1,
					hiddenUnicode
				},
				onClick: onLineNumberClick
			})
		}), cells.map((cellContents, columnIndex) => {
			return /* @__PURE__ */ jsx("th", {
				className: "react-csv-cell react-csv-cell--header",
				children: cellContents
			}, `0-${columnIndex}`);
		})]
	}) });
}
CSVHeaderUnmemoized.displayName = "CSVHeaderUnmemoized";
var CSVRow = React.memo(CSVRowUnmemoized);
CSVRow.displayName = "CSVRow";
function CSVRowUnmemoized(t0) {
	const $ = c(8);
	const { lineNumber, cells, hiddenUnicode, onLineNumberClick } = t0;
	const highlightedLines = useHighlightedLinesInfo(lineNumber);
	const highlighted = !!highlightedLines && lineNumber >= highlightedLines.start.line && lineNumber <= highlightedLines.end.line;
	let t1;
	if ($[0] !== cells || $[1] !== hiddenUnicode || $[2] !== highlighted || $[3] !== lineNumber || $[4] !== onLineNumberClick) {
		const className = clsx("react-csv-row", highlighted && "react-csv-row--highlighted");
		let t2;
		if ($[6] !== lineNumber) {
			t2 = (cellContents, columnIndex) => jsx("td", {
				className: "react-csv-cell",
				children: cellContents
			}, `${lineNumber}-${columnIndex}`);
			$[6] = lineNumber;
			$[7] = t2;
		} else t2 = $[7];
		t1 = jsxs("tr", {
			id: `LC${lineNumber}`,
			className,
			children: [jsx("td", {
				className: "react-csv-line-number",
				children: jsx(LineNumber, {
					codeLineData: {
						lineNumber,
						hiddenUnicode
					},
					onClick: onLineNumberClick
				})
			}), cells.map(t2)]
		});
		$[0] = cells;
		$[1] = hiddenUnicode;
		$[2] = highlighted;
		$[3] = lineNumber;
		$[4] = onLineNumberClick;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
CSVRowUnmemoized.displayName = "CSVRowUnmemoized";
function toCSVData(csv, highlightedLines) {
	return csv.map((row, rowIndex) => {
		const hiddenUnicodeShown = isHiddenUnicodeShown();
		const hiddenUnicode = hasHiddenUnicodeCharacters(row.join(""));
		const cells = hiddenUnicodeShown && hiddenUnicode ? row.map((cell) => cell ? showHiddenUnicodeCharacters(cell) ?? cell : cell) : row;
		const lineNumber = rowIndex + 1;
		return {
			lineNumber,
			cells,
			hiddenUnicode,
			highlighted: !!highlightedLines && lineNumber >= highlightedLines.start.line && lineNumber <= highlightedLines.end.line
		};
	});
}
function useHighlightedLines() {
	const { hash } = useLocation$1();
	const initialHighlightedLines = parseFileAnchor(hash).blobRange;
	const highlightedLinesRef = useRef(initialHighlightedLines);
	const [highlightedLines, setHighlightedLines] = useState(initialHighlightedLines);
	useEffect(() => {
		const newBlobRange = parseFileAnchor(window.location.hash).blobRange;
		if (newBlobRange?.start.line !== highlightedLinesRef.current?.start.line || newBlobRange?.end.line !== highlightedLinesRef.current?.end.line) {
			highlightedLinesRef.current = newBlobRange;
			setHighlightedLines(newBlobRange);
		}
	}, [hash]);
	return [highlightedLines, setHighlightedLines];
}
export { CSVBlob as default };
