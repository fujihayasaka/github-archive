import { t as createComponent$1 } from "./server-create-component-eMtUQH5E-CsgQJSWA.js";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { RelativeTimeElement } from "@github/relative-time-element";
var RelativeTimeComponent = createComponent$1(RelativeTimeElement, "relative-time");
var localeOptions = {
	month: "short",
	day: "numeric",
	year: "numeric"
};
function RelativeTime(t0) {
	const $ = c(16);
	let children;
	let date;
	let datetime;
	let noTitle;
	let props;
	if ($[0] !== t0) {
		({date, datetime, children, noTitle, ...props} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = date;
		$[3] = datetime;
		$[4] = noTitle;
		$[5] = props;
	} else {
		children = $[1];
		date = $[2];
		datetime = $[3];
		noTitle = $[4];
		props = $[5];
	}
	if (datetime) {
		let t1;
		if ($[6] !== datetime) {
			t1 = new Date(datetime);
			$[6] = datetime;
			$[7] = t1;
		} else t1 = $[7];
		date = t1;
	}
	const t1 = noTitle ? "" : void 0;
	let t2;
	if ($[8] !== children || $[9] !== date) {
		var _date;
		t2 = children || ((_date = date) === null || _date === void 0 ? void 0 : _date.toLocaleDateString("en", localeOptions)) || "";
		$[8] = children;
		$[9] = date;
		$[10] = t2;
	} else t2 = $[10];
	let t3;
	if ($[11] !== date || $[12] !== props || $[13] !== t1 || $[14] !== t2) {
		t3 = /* @__PURE__ */ jsx(RelativeTimeComponent, {
			...props,
			date,
			"no-title": t1,
			children: t2
		});
		$[11] = date;
		$[12] = props;
		$[13] = t1;
		$[14] = t2;
		$[15] = t3;
	} else t3 = $[15];
	return t3;
}
export { RelativeTime as t };
