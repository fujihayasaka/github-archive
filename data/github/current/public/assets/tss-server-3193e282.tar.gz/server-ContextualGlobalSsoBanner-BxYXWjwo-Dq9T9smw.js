import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { r as shouldCookieSuppressBanner } from "./server-cookie-fghC_FiA-DZjQG69M.js";
import { t as LazyGlobalSsoBanner } from "./server-LazyGlobalSsoBanner-BCV_e8ma-ZuaPMhBt.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* Hook to get the SSO payload from the app payload
*
* @description If the app payload is not available, this hook will still return
* an object with empty arrays for the SSO organizations and the default URLs
*
* @returns {SsoPayload} The SSO payload
*/
var useSso = () => {
	const $ = c(5);
	const payload = useAppPayload();
	payload?.sso_organizations;
	payload?.base_avatar_url;
	let t0;
	if ($[0] !== payload?.sso_organizations) {
		t0 = payload?.sso_organizations ?? [];
		$[0] = payload?.sso_organizations;
		$[1] = t0;
	} else t0 = $[1];
	const ssoOrgs = t0;
	const baseAvatarUrl = payload?.base_avatar_url ?? "https://avatars.githubusercontent.com";
	let t1;
	if ($[2] !== baseAvatarUrl || $[3] !== ssoOrgs) {
		t1 = {
			ssoOrgs,
			baseAvatarUrl
		};
		$[2] = baseAvatarUrl;
		$[3] = ssoOrgs;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
function isSSOOrgInfo(ssoOrg) {
	return typeof ssoOrg === "object" && ssoOrg !== null && "id" in ssoOrg && "name" in ssoOrg && "login" in ssoOrg;
}
function useGlobalBannerSSO() {
	const $ = c(12);
	const { ssoOrgs, baseAvatarUrl } = useSso();
	const { current_sso_orgs_match_dismissed_cookie } = useAppPayload() ?? {};
	let t0;
	if ($[0] !== baseAvatarUrl || $[1] !== ssoOrgs) {
		let t1;
		if ($[3] !== baseAvatarUrl) {
			t1 = (org) => ({
				...org,
				avatar_url: `${baseAvatarUrl}/u/${org.id}`
			});
			$[3] = baseAvatarUrl;
			$[4] = t1;
		} else t1 = $[4];
		t0 = ssoOrgs.filter(isSSOOrgInfo).map(t1);
		$[0] = baseAvatarUrl;
		$[1] = ssoOrgs;
		$[2] = t0;
	} else t0 = $[2];
	const ssoOrgsWithAvatars = t0;
	let t1;
	if ($[5] !== current_sso_orgs_match_dismissed_cookie || $[6] !== ssoOrgsWithAvatars) {
		t1 = current_sso_orgs_match_dismissed_cookie === true || shouldCookieSuppressBanner(ssoOrgsWithAvatars);
		$[5] = current_sso_orgs_match_dismissed_cookie;
		$[6] = ssoOrgsWithAvatars;
		$[7] = t1;
	} else t1 = $[7];
	let t2;
	if ($[8] !== baseAvatarUrl || $[9] !== ssoOrgsWithAvatars || $[10] !== t1) {
		t2 = {
			suppressBanner: t1,
			ssoOrgs: ssoOrgsWithAvatars,
			baseAvatarUrl
		};
		$[8] = baseAvatarUrl;
		$[9] = ssoOrgsWithAvatars;
		$[10] = t1;
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
/** Entry point for the GlobalSSOBanner when used in React pages */
function ContextualGlobalSsoBanner() {
	const $ = c(2);
	const { ssoOrgs, suppressBanner } = useGlobalBannerSSO();
	if (ssoOrgs.length === 0 || suppressBanner) return null;
	let t0;
	if ($[0] !== ssoOrgs) {
		t0 = jsx(LazyGlobalSsoBanner, { ssoOrgs });
		$[0] = ssoOrgs;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
ContextualGlobalSsoBanner.displayName = "ContextualGlobalSsoBanner";
export { ContextualGlobalSsoBanner as t };
