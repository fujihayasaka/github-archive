var MESSAGE_DELIMITER = "\n\n";
var MESSAGE_REGEXP = /^data:\s+/;
var MESSAGE_END = "[DONE]";
var CopilotStreamingError = class extends Error {
	error;
	constructor(error) {
		super(error.description);
		this.error = error;
		this.name = "CopilotStreamingError";
	}
};
var CopilotChatMessageStreamer = class {
	reader;
	constructor(reader) {
		this.reader = reader;
	}
	async *stream() {
		const utf8Decoder = new TextDecoder("utf-8");
		let partialMessage = "";
		for (;;) {
			let value;
			let done;
			try {
				({value, done} = await this.reader.read());
			} catch {
				throw new CopilotStreamingError({
					type: "error",
					errorType: "networkError",
					description: "NETWORK_CONNECTION_INTERRUPTED"
				});
			}
			if (done) break;
			partialMessage += utf8Decoder.decode(value);
			for (;;) {
				const messageEnd = partialMessage.indexOf(MESSAGE_DELIMITER);
				if (messageEnd === -1) break;
				const rawMessage = partialMessage.slice(0, messageEnd).replace(MESSAGE_REGEXP, "");
				if (rawMessage === MESSAGE_END) return;
				const parsedMessage = JSON.parse(rawMessage);
				yield parsedMessage;
				if (parsedMessage?.type === "complete") return;
				partialMessage = partialMessage.slice(messageEnd + 2);
			}
		}
	}
	async stop() {
		return this.reader.cancel();
	}
};
export { CopilotChatMessageStreamer as t };
