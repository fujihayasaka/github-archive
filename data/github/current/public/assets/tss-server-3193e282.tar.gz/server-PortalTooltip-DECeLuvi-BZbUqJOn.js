import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as getScrollableParent } from "./server-get-scrollable-parent-CYFmVGg0-DxdSiurz.js";
import { useCallback, useImperativeHandle, useRef, useSyncExternalStore } from "react";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
import { getAnchoredPosition } from "@primer/behaviors";
var ControlledTooltip_module_default = {
	fixedPosition: "ControlledTooltip-module_wSa8qW_fixedPosition",
	tooltipBase: "ControlledTooltip-module_wSa8qW_tooltipBase",
	tooltippedAlignLeft2: "ControlledTooltip-module_wSa8qW_tooltippedAlignLeft2",
	tooltippedAlignRight2: "ControlledTooltip-module_wSa8qW_tooltippedAlignRight2",
	tooltippedE: "ControlledTooltip-module_wSa8qW_tooltippedE",
	tooltippedMultiline: "ControlledTooltip-module_wSa8qW_tooltippedMultiline",
	tooltippedN: "ControlledTooltip-module_wSa8qW_tooltippedN",
	tooltippedNe: "ControlledTooltip-module_wSa8qW_tooltippedNe",
	tooltippedNoDelay: "ControlledTooltip-module_wSa8qW_tooltippedNoDelay",
	tooltippedNw: "ControlledTooltip-module_wSa8qW_tooltippedNw",
	tooltippedOpen: "ControlledTooltip-module_wSa8qW_tooltippedOpen",
	tooltippedS: "ControlledTooltip-module_wSa8qW_tooltippedS",
	tooltippedSe: "ControlledTooltip-module_wSa8qW_tooltippedSe",
	tooltippedSw: "ControlledTooltip-module_wSa8qW_tooltippedSw",
	tooltippedW: "ControlledTooltip-module_wSa8qW_tooltippedW"
};
var DIRECTION_CLASSES = {
	n: ControlledTooltip_module_default.tooltippedN,
	s: ControlledTooltip_module_default.tooltippedS,
	e: ControlledTooltip_module_default.tooltippedE,
	w: ControlledTooltip_module_default.tooltippedW,
	ne: ControlledTooltip_module_default.tooltippedNe,
	nw: ControlledTooltip_module_default.tooltippedNw,
	se: ControlledTooltip_module_default.tooltippedSe,
	sw: ControlledTooltip_module_default.tooltippedSw
};
var ALIGN_CLASSES = {
	left: ControlledTooltip_module_default.tooltippedAlignLeft2,
	right: ControlledTooltip_module_default.tooltippedAlignRight2
};
var noop = () => () => void 0;
var getServerSideState = () => false;
var getClientSideState = () => true;
/**
* An extended `@primer/react` tooltip (based on version 35.21 and prior) which allows for external control
* using an `open` prop
*/
function ControlledTooltip({ ref, direction = "n", className, text, noDelay, align, wrap, open = false, portalProps = {}, ...rest }) {
	const isClientRender = useSyncExternalStore(noop, getClientSideState, getServerSideState);
	const classes = clsx(ControlledTooltip_module_default.tooltipBase, DIRECTION_CLASSES[direction], align && ALIGN_CLASSES[align], noDelay && ControlledTooltip_module_default.tooltippedNoDelay, wrap && ControlledTooltip_module_default.tooltippedMultiline, open && ControlledTooltip_module_default.tooltippedOpen, ControlledTooltip_module_default.fixedPosition, className);
	if (!isClientRender) return null;
	return /* @__PURE__ */ jsx(Portal, {
		...portalProps,
		children: /* @__PURE__ */ jsx("span", {
			ref,
			role: "tooltip",
			"aria-label": text,
			"data-visible-text": text || rest["aria-label"],
			...rest,
			className: classes
		})
	});
}
ControlledTooltip.displayName = "ControlledTooltip";
/**
* A tooltip that portals an uses absolute positioning to position itself relative to the contentRef
*
* it tricks scroll in the nearest scrollable parent to the contentRef to reposition itself.
*
* For now this uses the aria-label prop similar to the primer tooltip, but a more complete implementation
* would allow for using children to tooltip rich content
*/
function PortalTooltip({ ref: forwardedRef, contentRef, open, anchoredPositionAlignment, anchorSide, anchorOffset, alignmentOffset, allowOutOfBounds, ...props }) {
	const ref = useRef(null);
	useImperativeHandle(forwardedRef, () => ref.current);
	const positionCache = useRef({
		left: 0,
		top: 0
	});
	const position = useSyncExternalStore(useCallback((notify) => {
		if (!ref.current || !contentRef.current || !open) return () => void 0;
		const scrollableParent = getScrollableParent(contentRef.current);
		scrollableParent?.addEventListener("scroll", notify);
		return () => {
			scrollableParent?.removeEventListener("scroll", notify);
		};
	}, [contentRef, open]), useCallback(() => {
		if (!ref.current || !contentRef.current) return positionCache.current;
		const nextPosition = getAnchoredPosition(ref.current, contentRef.current, {
			align: anchoredPositionAlignment ?? "center",
			side: anchorSide ?? "outside-top",
			alignmentOffset: alignmentOffset ?? 0,
			anchorOffset: anchorOffset ?? 0,
			allowOutOfBounds
		});
		if (nextPosition.left !== positionCache.current.left || nextPosition.top !== positionCache.current.top) positionCache.current = nextPosition;
		return positionCache.current;
	}, [
		contentRef,
		alignmentOffset,
		anchorOffset,
		anchoredPositionAlignment,
		anchorSide,
		allowOutOfBounds
	]), useCallback(() => positionCache.current, []));
	return /* @__PURE__ */ jsx(ControlledTooltip, {
		...props,
		ref,
		open,
		style: {
			position: "absolute",
			...position,
			...props.style
		}
	});
}
PortalTooltip.displayName = "PortalTooltip";
export { PortalTooltip as t };
