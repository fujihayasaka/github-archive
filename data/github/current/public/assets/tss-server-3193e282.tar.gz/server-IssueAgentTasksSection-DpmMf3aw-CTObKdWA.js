performance.mark("js-parse-end:server-IssueAgentTasksSection-DpmMf3aw-CTObKdWA.js");
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { Gi as useSlots, Mi as XIcon, an as IconButton, et as CopilotIcon, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useFocusTrap } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { d as copilotChatTextAreaId, t as CopilotChatProvider, u as copilotChatSearchInputId } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { b as isSessionState } from "./server-session-CpgPVfEW-Bkmi4-Or.js";
import { n as TaskLeadingVisual, o as getTaskTitle, y as useRepoInfo } from "./server-TaskLeadingVisual-DlKGcMc6-CLgHXns0.js";
import { n as CurrentUserProvider, o as useTask, t as ChatStreamProvider } from "./server-use-task-B-REuEVT-BE9pVUx2.js";
import { t as PullContextProvider } from "./server-PullContext-DdBViZCa-COCMY1Ix.js";
import { r as relayEnvironmentWithMissingFieldHandlerForNode, t as RelayEnvironmentProvider } from "./server-relay-environment-37zIk8_--Ci7dtWT_.js";
import { t as useIssueAgentTasks } from "./server-use-issue-agent-tasks-CHK8cdRW-CwhhCocr.js";
import { t as useChatPayload } from "./server-use-chat-payload-I_4Odglq-LaW0idPG.js";
import { Component, Suspense, lazy, memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:IssueAgentTasksSection-DpmMf3aw.js");
/**
* Fetches the task payload including permissions, pull request, sessions,
* current user, and session owners from the task endpoint.
*/
function useTaskPermissions(owner, repo, taskId) {
	const $ = c(9);
	let t0;
	let t1;
	if ($[0] !== owner || $[1] !== repo || $[2] !== taskId) {
		t0 = [
			"task-permissions",
			owner,
			repo,
			taskId
		];
		t1 = async () => {
			const resp = await verifiedFetchJSON(`/${owner}/${repo}/tasks/${taskId}.json`);
			if (!resp.ok) throw new Error(`Failed to fetch task permissions: ${resp.status} ${resp.statusText}`);
			const backendPayload = (await resp.json())?.payload?.repoTaskByIdRoute;
			if (!backendPayload || typeof backendPayload !== "object") throw new Error("Unexpected response shape: missing payload.repoTaskByIdRoute");
			return backendPayload;
		};
		$[0] = owner;
		$[1] = repo;
		$[2] = taskId;
		$[3] = t0;
		$[4] = t1;
	} else {
		t0 = $[3];
		t1 = $[4];
	}
	const t2 = !!owner && !!repo && !!taskId;
	let t3;
	if ($[5] !== t0 || $[6] !== t1 || $[7] !== t2) {
		t3 = {
			queryKey: t0,
			queryFn: t1,
			enabled: t2,
			staleTime: Infinity
		};
		$[5] = t0;
		$[6] = t1;
		$[7] = t2;
		$[8] = t3;
	} else t3 = $[8];
	return useQuery(t3);
}
var SidePanel_module_default = {
	Backdrop: "SidePanel-module_-72nsW_Backdrop",
	Box_2: "SidePanel-module_-72nsW_Box_2",
	IconButton: "SidePanel-module_-72nsW_IconButton",
	isVisible: "SidePanel-module_-72nsW_isVisible",
	openSidePanel: "SidePanel-module_-72nsW_openSidePanel",
	Overlay: "SidePanel-module_-72nsW_Overlay",
	sidePanel: "SidePanel-module_-72nsW_sidePanel"
};
var TRANSITION_DURATION_MS = 200;
var SidePanelBase = memo(({ children, initialFocusRef, returnFocusRef, open, onClose, onKeyDown, topOffset = 0, width, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, defaultCloseElement = "button", externalFocusTrapDisabled = false }) => {
	const containerWidth = useMemo(() => {
		if (Array.isArray(width)) return width;
		else if (typeof width === "string") return [
			"100%",
			"",
			width
		];
		else return ["100%"];
	}, [width]);
	const containerRef = useRef(null);
	const [focusTrapDisabled, setFocusTrapDisabled] = useState(containerRef.current === null || !open || externalFocusTrapDisabled);
	const { initialFocusRef: internalInitialFocusRef } = useFocusTrap({
		initialFocusRef,
		containerRef,
		disabled: externalFocusTrapDisabled || focusTrapDisabled
	});
	const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const [rendered, setRendered] = useState(open);
	const [visible, setVisible] = useState(open);
	const [slots, childrenWithoutSlots] = useSlots(children, { heading: Heading });
	useEffect(() => {
		let timeoutId;
		if (open) {
			setRendered(true);
			timeoutId = setTimeout(() => setVisible(true));
		} else {
			setVisible(false);
			timeoutId = setTimeout(() => setRendered(false), TRANSITION_DURATION_MS);
		}
		return () => clearTimeout(timeoutId);
	}, [open]);
	const onWindowClick = useCallback((e) => {
		const target = e.target;
		if (target.id === "copilot-chat-textarea" || target.id === "copilot-chat-topic-search") {
			setFocusTrapDisabled(true);
			window.setTimeout(() => target.focus());
		}
	}, []);
	const onPanelKeyDown = useCallback((e_0) => {
		const target_0 = e_0.target;
		if (target_0.tagName !== "INPUT" && target_0.tagName !== "TEXTAREA" && e_0.shiftKey && e_0.key === "C") {
			const input = document.querySelector(`#${copilotChatTextAreaId}, #${copilotChatSearchInputId}`);
			if (input) {
				setFocusTrapDisabled(true);
				window.setTimeout(() => input.focus());
			}
		}
		if (onKeyDown) onKeyDown(e_0);
	}, [onKeyDown]);
	useEffect(() => {
		window.addEventListener("click", onWindowClick);
		return () => {
			window.removeEventListener("click", onWindowClick);
		};
	}, [onWindowClick]);
	useEffect(() => {
		const bodyOverflowStyle = document.body.style.overflow || "";
		if (bodyOverflowStyle === "hidden") return;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = bodyOverflowStyle;
		};
	}, []);
	const onFocus = useCallback(() => {
		if (focusTrapDisabled) setFocusTrapDisabled(!open);
	}, [focusTrapDisabled, open]);
	if (!rendered) return null;
	const Backdrop = defaultCloseElement === "overlay" ? "button" : "div";
	return /* @__PURE__ */ jsxs(Overlay, {
		initialFocusRef: internalInitialFocusRef,
		returnFocusRef,
		onKeyDown: onPanelKeyDown,
		onEscape: onClose,
		onClickOutside: () => {},
		ref: containerRef,
		role: "dialog",
		"aria-modal": true,
		"aria-label": ariaLabel,
		"aria-labelledby": ariaLabelledBy,
		style: {
			"--transition-duration": `${TRANSITION_DURATION_MS}ms`,
			"--top-offset": `${topOffset}px`
		},
		onFocus,
		className: SidePanel_module_default.Overlay,
		children: [/* @__PURE__ */ jsx(Backdrop, {
			onClick: onClose,
			"aria-label": defaultCloseElement === "overlay" ? "Close" : void 0,
			className: SidePanel_module_default.Backdrop
		}), /* @__PURE__ */ jsxs(Box, {
			sx: { width: containerWidth },
			className: clsx(SidePanel_module_default.sidePanel, (visible || prefersReducedMotion) && SidePanel_module_default.openSidePanel, visible && SidePanel_module_default.isVisible),
			children: [/* @__PURE__ */ jsxs("div", {
				className: SidePanel_module_default.Box_2,
				children: [/* @__PURE__ */ jsx("div", { children: slots.heading }), /* @__PURE__ */ jsx("div", { children: defaultCloseElement === "button" && /* @__PURE__ */ jsx(IconButton, {
					variant: "invisible",
					icon: XIcon,
					"aria-label": "Close",
					onClick: onClose,
					className: SidePanel_module_default.IconButton
				}) })]
			}), childrenWithoutSlots]
		})]
	});
});
SidePanelBase.displayName = "SidePanel";
var Heading = ({ children }) => {
	return /* @__PURE__ */ jsx("div", { children });
};
Heading.displayName = "Heading";
var SidePanel = Object.assign(SidePanelBase, { Heading });
var AgentTaskSidePanel_module_default = {
	emptyState: "AgentTaskSidePanel-module_2jsQza_emptyState",
	headerSeparator: "AgentTaskSidePanel-module_2jsQza_headerSeparator",
	LoadingContainer: "AgentTaskSidePanel-module_2jsQza_LoadingContainer",
	Panel: "AgentTaskSidePanel-module_2jsQza_Panel"
};
var TaskSwitcher_module_default = {
	heading: "TaskSwitcher-module_j05Txa_heading",
	taskSwitcherButton: "TaskSwitcher-module_j05Txa_taskSwitcherButton"
};
function TaskSwitcher(t0) {
	const $ = c(11);
	const { tasks, selectedTask, onSelectTask } = t0;
	let t1;
	let t2;
	if ($[0] !== onSelectTask || $[1] !== selectedTask || $[2] !== tasks) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const selectedTitle = getTaskTitle(selectedTask);
			let t3;
			if ($[5] !== onSelectTask || $[6] !== selectedTask.id) {
				t3 = (task) => {
					if (task.id !== selectedTask.id) onSelectTask(task);
				};
				$[5] = onSelectTask;
				$[6] = selectedTask.id;
				$[7] = t3;
			} else t3 = $[7];
			const handleSelect = t3;
			if (tasks.length <= 1) {
				t2 = jsx("span", {
					className: TaskSwitcher_module_default.heading,
					children: selectedTitle
				});
				break bb0;
			}
			let t4;
			if ($[8] !== handleSelect || $[9] !== selectedTask.id) {
				t4 = (task_0) => jsx(ActionList.Item, {
					selected: task_0.id === selectedTask.id,
					onSelect: () => handleSelect(task_0),
					children: getTaskTitle(task_0)
				}, task_0.id);
				$[8] = handleSelect;
				$[9] = selectedTask.id;
				$[10] = t4;
			} else t4 = $[10];
			t1 = jsx("div", {
				className: TaskSwitcher_module_default.heading,
				children: jsxs(ActionMenu, { children: [jsx(ActionMenu.Button, {
					variant: "invisible",
					className: TaskSwitcher_module_default.taskSwitcherButton,
					children: selectedTitle
				}), jsx(ActionMenu.Overlay, {
					width: "medium",
					children: jsx(ActionList, {
						selectionVariant: "single",
						children: jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, { children: "Agent sessions" }), tasks.map(t4)] })
					})
				})] })
			});
		}
		$[0] = onSelectTask;
		$[1] = selectedTask;
		$[2] = tasks;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
TaskSwitcher.displayName = "TaskSwitcher";
var TaskChat = lazy(async () => {
	return { default: (await import("./server-TaskChat-BO4VKzBr-94cvijjJ.js")).TaskChat };
});
TaskChat.displayName = "TaskChat";
var relayEnvironment = relayEnvironmentWithMissingFieldHandlerForNode();
var TaskChatErrorBoundary = class extends Component {
	state = { error: null };
	static getDerivedStateFromError(error) {
		return { error };
	}
	render() {
		if (this.state.error) return /* @__PURE__ */ jsxs("div", {
			className: AgentTaskSidePanel_module_default.emptyState,
			role: "alert",
			children: ["Unable to load task chat: ", this.state.error.message]
		});
		return this.props.children;
	}
};
function AgentTaskSidePanel({ task, tasks, open, onClose, onSelectTask, returnFocusRef }) {
	const title = getTaskTitle(task);
	return /* @__PURE__ */ jsxs(SidePanel, {
		open,
		onClose,
		returnFocusRef,
		"aria-label": title,
		width: "40%",
		children: [
			/* @__PURE__ */ jsx(SidePanel.Heading, { children: /* @__PURE__ */ jsx(TaskSwitcher, {
				tasks,
				selectedTask: task,
				onSelectTask
			}) }),
			/* @__PURE__ */ jsx("div", { className: AgentTaskSidePanel_module_default.headerSeparator }),
			/* @__PURE__ */ jsx("div", {
				className: AgentTaskSidePanel_module_default.Panel,
				children: /* @__PURE__ */ jsx(ConsecutiveCAPI401sProvider, { children: /* @__PURE__ */ jsx(AgentTaskSidePanelContent, {
					taskId: task.id,
					repoId: task.repository?.id
				}) })
			})
		]
	});
}
AgentTaskSidePanel.displayName = "AgentTaskSidePanel";
function AgentTaskSidePanelContent(t0) {
	const $ = c(38);
	const { taskId, repoId } = t0;
	let t1;
	if ($[0] !== repoId) {
		t1 = [repoId];
		$[0] = repoId;
		$[1] = t1;
	} else t1 = $[1];
	const { data: repoMap, isLoading: isLoadingRepoInfo, isError: isRepoInfoError } = useRepoInfo(t1);
	const repoInfo = repoMap[repoId];
	const owner = repoInfo?.ownerLogin ?? "";
	const repo = repoInfo?.name ?? "";
	let t2;
	if ($[2] !== owner || $[3] !== repo || $[4] !== taskId) {
		t2 = {
			owner,
			repo,
			taskId
		};
		$[2] = owner;
		$[3] = repo;
		$[4] = taskId;
		$[5] = t2;
	} else t2 = $[5];
	const { data: taskData, isLoading: isLoadingTask, isError: isTaskError } = useTask(t2);
	const { data: chatPayload, isLoading: isLoadingChat, isError: isChatError } = useChatPayload();
	const { data: taskPermissions, isLoading: isLoadingPermissions } = useTaskPermissions(owner, repo, taskId);
	const currentUserCanPush = taskPermissions?.currentUserCanPush ?? false;
	const steeringEnabled = taskPermissions?.steeringEnabled ?? false;
	const pull = taskPermissions?.pull;
	const currentUser = taskPermissions?.currentUser;
	let t3;
	let t4;
	if ($[6] !== chatPayload || $[7] !== currentUser || $[8] !== currentUserCanPush || $[9] !== isChatError || $[10] !== isLoadingChat || $[11] !== isLoadingPermissions || $[12] !== isLoadingRepoInfo || $[13] !== isLoadingTask || $[14] !== isRepoInfoError || $[15] !== isTaskError || $[16] !== owner || $[17] !== pull || $[18] !== repo || $[19] !== repoId || $[20] !== repoInfo || $[21] !== steeringEnabled || $[22] !== taskData || $[23] !== taskId || $[24] !== taskPermissions?.sessionOwners) {
		t4 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const sessionOwners = taskPermissions?.sessionOwners ?? [];
			const sessions = taskData?.sessions ?? [];
			const currentUserIsSessionOwner = !!(currentUser && sessions.some((s) => s.user_id === currentUser.id));
			let t5;
			if ($[27] !== currentUserCanPush || $[28] !== owner || $[29] !== repo || $[30] !== repoId) {
				t5 = {
					id: repoId,
					name: repo,
					ownerLogin: owner,
					currentUserCanPush
				};
				$[27] = currentUserCanPush;
				$[28] = owner;
				$[29] = repo;
				$[30] = repoId;
				$[31] = t5;
			} else t5 = $[31];
			const repository = t5;
			if (isLoadingTask || isLoadingRepoInfo || isLoadingChat || isLoadingPermissions) {
				let t6;
				if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.LoadingContainer,
						children: jsx(Spinner, {
							size: "medium",
							srText: "Loading task chat"
						})
					});
					$[32] = t6;
				} else t6 = $[32];
				t4 = t6;
				break bb0;
			}
			if (isTaskError) {
				let t6;
				if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.emptyState,
						role: "alert",
						children: "Unable to load task data."
					});
					$[33] = t6;
				} else t6 = $[33];
				t4 = t6;
				break bb0;
			}
			if (isRepoInfoError) {
				let t6;
				if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.emptyState,
						role: "alert",
						children: "Unable to load repository information."
					});
					$[34] = t6;
				} else t6 = $[34];
				t4 = t6;
				break bb0;
			}
			if (!repoInfo) {
				let t6;
				if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.emptyState,
						role: "status",
						children: "Repository information not available."
					});
					$[35] = t6;
				} else t6 = $[35];
				t4 = t6;
				break bb0;
			}
			if (!taskData || sessions.length === 0) {
				let t6;
				if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.emptyState,
						role: "status",
						children: "No session information available."
					});
					$[36] = t6;
				} else t6 = $[36];
				t4 = t6;
				break bb0;
			}
			if (isChatError || !chatPayload) {
				let t6;
				if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
					t6 = jsx("div", {
						className: AgentTaskSidePanel_module_default.emptyState,
						role: "alert",
						children: "Unable to load Copilot Chat. Ensure Copilot is enabled."
					});
					$[37] = t6;
				} else t6 = $[37];
				t4 = t6;
				break bb0;
			}
			t3 = jsx(CurrentRepositoryProvider, {
				repository,
				children: jsx(CurrentUserProvider, {
					currentUser,
					currentUserIsSessionOwner,
					children: jsx(PullContextProvider, {
						pull,
						children: jsx(RelayEnvironmentProvider, {
							environment: relayEnvironment,
							children: jsx(CopilotChatProvider, {
								workerPath: chatPayload.findFileWorkerPath,
								threadId: null,
								refs: chatPayload.refs ?? [],
								mode: "assistive",
								ssoOrganizations: chatPayload.ssoOrganizations ?? [],
								copilotChatPayload: chatPayload,
								children: jsx(ChatStreamProvider, { children: jsx(TaskChatErrorBoundary, { children: jsx(Suspense, {
									fallback: jsx(Spinner, {
										size: "medium",
										srText: "Loading task chat"
									}),
									children: jsx(TaskChat, {
										taskId,
										sessions,
										currentUser,
										currentUserCanPush,
										steeringEnabled,
										sessionOwners,
										logsPollingInterval: 3e3,
										repoOwner: owner,
										repoName: repo,
										task: taskData
									})
								}) }) })
							})
						})
					})
				})
			});
		}
		$[6] = chatPayload;
		$[7] = currentUser;
		$[8] = currentUserCanPush;
		$[9] = isChatError;
		$[10] = isLoadingChat;
		$[11] = isLoadingPermissions;
		$[12] = isLoadingRepoInfo;
		$[13] = isLoadingTask;
		$[14] = isRepoInfoError;
		$[15] = isTaskError;
		$[16] = owner;
		$[17] = pull;
		$[18] = repo;
		$[19] = repoId;
		$[20] = repoInfo;
		$[21] = steeringEnabled;
		$[22] = taskData;
		$[23] = taskId;
		$[24] = taskPermissions?.sessionOwners;
		$[25] = t3;
		$[26] = t4;
	} else {
		t3 = $[25];
		t4 = $[26];
	}
	if (t4 !== Symbol.for("react.early_return_sentinel")) return t4;
	return t3;
}
AgentTaskSidePanelContent.displayName = "AgentTaskSidePanelContent";
var IssueAgentTasksSection_module_default = {
	agentIcon: "IssueAgentTasksSection-module_BDf3HW_agentIcon",
	container: "IssueAgentTasksSection-module_BDf3HW_container",
	statusIcon: "IssueAgentTasksSection-module_BDf3HW_statusIcon",
	taskControls: "IssueAgentTasksSection-module_BDf3HW_taskControls",
	taskItem: "IssueAgentTasksSection-module_BDf3HW_taskItem",
	taskList: "IssueAgentTasksSection-module_BDf3HW_taskList",
	taskStatus: "IssueAgentTasksSection-module_BDf3HW_taskStatus",
	taskTitle: "IssueAgentTasksSection-module_BDf3HW_taskTitle",
	taskTitleButton: "IssueAgentTasksSection-module_BDf3HW_taskTitleButton",
	taskTitleLink: "IssueAgentTasksSection-module_BDf3HW_taskTitleLink",
	taskTopRow: "IssueAgentTasksSection-module_BDf3HW_taskTopRow"
};
/**
* Renders a compact list of agent tasks for an issue.
* Placed between the issue body and the sub-issues list in the issue detail view.
* Only renders when there are tasks associated with the issue.
*/
function IssueAgentTasksSection({ owner, repo, issueNumber, className, testId }) {
	const tasksQuery = useIssueAgentTasks({
		owner,
		repo,
		issueNumber
	});
	const tasks = tasksQuery.data?.tasks ?? [];
	const [selectedTask, setSelectedTask] = useState(null);
	const sidePanelEnabled = isFeatureEnabled("issue_cca_task_side_panel");
	const returnFocusRef = useRef(null);
	if (!isFeatureEnabled("issue_cca_visualization_session_panel")) return null;
	if (tasksQuery.isLoading) return null;
	const containerClassName = clsx(IssueAgentTasksSection_module_default.container, className);
	if (tasksQuery.error) return /* @__PURE__ */ jsx("div", {
		className: containerClassName,
		"data-testid": testId ?? "issue-agent-tasks-section",
		children: /* @__PURE__ */ jsx("div", {
			className: IssueAgentTasksSection_module_default.taskStatus,
			children: "Unable to load Copilot coding agent tasks."
		})
	});
	if (tasks.length === 0) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: containerClassName,
		"data-testid": testId ?? "issue-agent-tasks-section",
		children: [/* @__PURE__ */ jsx("ul", {
			className: IssueAgentTasksSection_module_default.taskList,
			children: tasks.map((task) => /* @__PURE__ */ jsx(AgentTaskItem, {
				task,
				sidePanelEnabled,
				onSelectTask: setSelectedTask,
				returnFocusRef
			}, task.id))
		}), selectedTask && /* @__PURE__ */ jsx(AgentTaskSidePanel, {
			task: selectedTask,
			tasks,
			open: true,
			onClose: () => setSelectedTask(null),
			onSelectTask: setSelectedTask,
			returnFocusRef
		})]
	});
}
IssueAgentTasksSection.displayName = "IssueAgentTasksSection";
function AgentTaskItem({ task, sidePanelEnabled, onSelectTask, returnFocusRef }) {
	const taskState = task.state ?? task.status;
	const status = isSessionState(taskState) ? taskState : void 0;
	const title = getTaskTitle(task);
	const buttonRef = useRef(null);
	const handleClick = useCallback(() => {
		returnFocusRef.current = buttonRef.current;
		onSelectTask(task);
	}, [
		task,
		onSelectTask,
		returnFocusRef
	]);
	return /* @__PURE__ */ jsx("li", {
		className: IssueAgentTasksSection_module_default.taskItem,
		children: /* @__PURE__ */ jsxs("div", {
			className: IssueAgentTasksSection_module_default.taskTopRow,
			children: [/* @__PURE__ */ jsx("div", {
				className: IssueAgentTasksSection_module_default.taskTitle,
				children: sidePanelEnabled ? /* @__PURE__ */ jsx("button", {
					ref: buttonRef,
					type: "button",
					className: IssueAgentTasksSection_module_default.taskTitleButton,
					onClick: handleClick,
					children: title
				}) : task.url ? /* @__PURE__ */ jsx("a", {
					href: task.url,
					className: IssueAgentTasksSection_module_default.taskTitleLink,
					children: title
				}) : title
			}), /* @__PURE__ */ jsxs("div", {
				className: IssueAgentTasksSection_module_default.taskControls,
				children: [status && /* @__PURE__ */ jsx(TaskLeadingVisual, {
					sessionState: status,
					className: IssueAgentTasksSection_module_default.statusIcon
				}), /* @__PURE__ */ jsx(CopilotIcon, { className: IssueAgentTasksSection_module_default.agentIcon })]
			})]
		})
	});
}
AgentTaskItem.displayName = "AgentTaskItem";
export { IssueAgentTasksSection };
