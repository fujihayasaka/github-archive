performance.mark("js-parse-end:server-layout-C5NsFauo-Bcyo9dih.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:layout-C5NsFauo.js");
var pullsLayoutServerFn_createServerFn_handler = createServerRpc({
	id: "3e67a847c1db09f01c56541acdb4c043f45b7b244cc33e6b6fb6f26b114156df",
	name: "pullsLayoutServerFn",
	filename: "src/routes/pulls/layout.tsx"
}, (opts) => pullsLayoutServerFn.__executeServer(opts));
var pullsLayoutServerFn = createServerFn().inputValidator(queryValidator.base).handler(pullsLayoutServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "pullsDashboardSurfaceLayoutRoute");
});
export { pullsLayoutServerFn_createServerFn_handler };
