import { a as ssrSafeWindow, i as ssrSafeLocation, n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { a as __toESM, i as __require, t as __commonJSMin } from "./server-chunk-DPETvcc5-SoS15Jre.js";
import { c as Text$1, i as ButtonComponent$1, o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ai as XCircleFillIcon, An as McpIcon, Cr as ScreenFullIcon, Ct as FileDiffIcon, D as CheckCircleIcon, Dn as MarkGithubIcon, Dr as ShieldCheckIcon, Dt as FileIcon, E as CheckCircleFillIcon, F as ChevronDownIcon, Gi as useSlots, Gr as SquareFillIcon, H as CodeIcon, Hi as useProvidedRefOrCreate, Hn as NoteIcon, I as ChevronLeftIcon, Ii as index_esm_exports, Ir as SkipIcon, J as CodespacesIcon, Jn as PaperAirplaneIcon, Jt as GitPullRequestIcon, K as CodescanCheckmarkIcon, Kt as GitPullRequestClosedIcon, L as ChevronRightIcon, Lt as FoldIcon, Mi as XIcon, Mr as SidebarCollapseIcon, Nr as SidebarExpandIcon, Nt as FilterIcon, O as CheckIcon, Oi as VscodeIcon, On as MarkdownIcon, Or as ShieldIcon, Ot as FileMovedIcon, Q as ComposeIcon, Qr as StopIcon, Qt as Heading$2, R as ChevronUpIcon, Si as UnlockIcon, Sn as LinkIcon, Tn as LockIcon, Tt as FileDirectoryIcon, V as ClockIcon, Vi as useOnEscapePress, Wr as SquareCircleIcon, Wt as GitMergeIcon, X as CommentDiscussionIcon, Yt as GlobeIcon, Z as CommentIcon, Zn as PencilIcon, _i as Truncate, _n as KebabHorizontalIcon, ai as TasklistIcon, an as IconButton, ar as PlusIcon, at as DependabotIcon, bi as UnfoldIcon, bn as Link, bt as FileAddedIcon, c as ArchiveIcon, ci as ThreeBarsIcon, cn as InfoIcon, d as ArrowRightIcon, dn as IssueDraftIcon, er as PersonIcon, et as CopilotIcon, fn as IssueOpenedIcon, hi as TriangleDownIcon, i as AgentIcon, it as DashIcon, jt as FileSymlinkFileIcon, kn as MaximizeIcon, kr as ShieldLockIcon, kt as FileRemovedIcon, l as ArrowDownIcon, li as ThumbsdownIcon, lr as QuestionIcon, m as ArrowUpRightIcon, mi as TrashIcon, mt as DownloadIcon, n as ActionList, o as AlertIcon, ot as DesktopDownloadIcon, pi as Tooltip$1, pt as DotFillIcon, qr as Stack, qt as GitPullRequestDraftIcon, rr as PlayIcon, si as TerminalIcon, tn as HistoryIcon, tt as CopyIcon, ui as ThumbsupIcon, un as IssueClosedIcon, v as BlockedIcon, vn as LawIcon, wn as ListUnorderedIcon, wr as SearchIcon, xi as UnlinkIcon, xn as LinkExternalIcon, yn as LightBulbIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useFocusTrap } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { a as isEnterprise, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { S as useSearchParams, b as useParams$1, g as useLocation$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { i as reactFetchJSON, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner$1 } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { a as Token, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { l as PageHeader$1 } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { n as TreeView } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as useCurrentRepository, t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { n as useAppPayload } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { l as useQuery, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as AuthToken } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { a as blobPath, st as ownerAvatarPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { Q as referenceName, Z as referenceID, b as copilotFeatureFlags, ct as threadName, h as NullMessageId, m as ModeSupportName, n as COPILOT_PATH, o as CopilotPlan, r as COPILOT_SPACES_PATH, w as findAgentCorrespondents } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as copyText } from "./server-copy-ByVwvIP0-X47hrvCx.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { c as UnifiedDiffLines, i as DiffStats, u as getLineNumberWidth } from "./server-diff-parts-DKuV_5Kq-C34001QS.js";
import { c as useObservedState, o as useObservableValue } from "./server-react-observable-0DQDiDnT-BDNMoELa.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { o as useCurrentUser } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as PortalTooltip } from "./server-PortalTooltip-DECeLuvi-BZbUqJOn.js";
import { t as useFileTreeTooltip } from "./server-use-file-tree-tooltip-DhTyi11E-CX1wlHJi.js";
import { t as NewAgentTaskButton } from "./server-NewAgentTaskButton-gbUWCBSY-Cu9_75w7.js";
import { s as updateUrlHash, t as addUrlToHistoryStack } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { t as CopilotChatMessageStreamer } from "./server-copilot-chat-message-streamer-DwhhquJZ-Be7HnjXD.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { t as buildCodespacesPath } from "./server-use-codespaces-data-B_J5e7_J-CHke9Nch.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { n as getLanguageInfo, t as docLanguages } from "./server-language-info-CBuUUErk-BvCk1GBy.js";
import { a as useCAPIQuery, i as getAgentSessionsTokenProvider, n as FetchCAPIError, r as fetchCAPI, t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { c as useIsCopilotSpacesPage } from "./server-custom-copilots-helpers-DK-3dkih-DB1BoMiI.js";
import { r as getSessionStorageItemsForKeyPrefix } from "./server-use-session-storage-C2f28u9L-cHRWNGhU.js";
import { C as useChatStateValues, O as usePlugins, S as useChatStateValue, b as useChatState, n as CopilotChatService, p as getActiveMessages, x as useChatStateLens, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { E as useTopLevelAgents, u as ImageAttachButton, v as extractImageUrls, y as isCopilotCodingAgent } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { n as SpacesIcon, r as iconMapping } from "./server-CustomIcon-CTl7CX1Z-5XxrNXUA.js";
import { C as useCustomCopilotsEnabled, b as iconForReference, m as VersionName, n as ChatInput, r as ChatInputValidationError } from "./server-ChatInput-DNU7qLKC-DqztNW8O.js";
import { c as thumbsUpIcon, i as grinIcon, n as frownIcon, o as smileIcon, r as frustratedIcon, s as thumbsDownIcon, t as UserFeedback } from "./server-UserFeedback-kIRVi6Wu-D1dZx8ou.js";
import { a as PersonalInstructionsDialog, c as useChatScroll, i as InterviewSurveyDialog, n as ChatScrollContainer, o as useActivePlugin, r as ConversationFeedbackDialog, s as useChatMessage, t as ChatMessageProvider } from "./server-PersonalInstructionsDialog-31usJWBy-DGjuoNqn.js";
import { n as CopilotAnimationType, t as CopilotAnimation } from "./server-CopilotAnimation-DOXbbPXC-CqTp-mSh.js";
import { a as parseJsonAttribute, i as disableStreamingFadeIn, n as MarkdownRenderer, o as useFilteredCopilotAnnotations, r as dataAttrToPropName, t as CodeInsightsDialog$1 } from "./server-MarkdownRenderer-CWn3CeTy-lToasg6Z.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as WithShimmerEffect } from "./server-WithShimmerEffect-C6EPOEv6-DHTqBfIK.js";
import { t as AvatarStack } from "./server-AvatarStack-DOkoT87C-BbROVIWO.js";
import { C as isToolUserRequestedMessage, S as isToolOutputsMessage, _ as isPendingSession, a as isAskUserArguments, c as isCommandGroup, d as isCompletionChunk, f as isCompletionToolMessage, g as isFailedSession, h as isExitPlanModeArguments, i as isActiveSession, l as isCommandMessage, m as isElicitationAskUser, n as SessionState, o as isCancelledSession, p as isCompletionUserMessage, r as getReadableSessionState, s as isChatMessage, t as INTERACTIVE_PROMPT_TOOL_NAMES, u as isCompletedSession, v as isPermissionRequestArguments, w as isValidLogEntry, x as isToolExecutionStartMessage, y as isReadonlyAgent } from "./server-session-CpgPVfEW-Bkmi4-Or.js";
import { a as TableCell, c as TableRow, d as useTable, i as TableBody, l as TableSortHeader, n as Table, o as TableHead, r as Table$1, s as TableHeader, t as InProgressSpinner } from "./server-StatusIcon-HHc9xqXJ-i9XmT_r2.js";
import { a as getLeadingVisualIconAttributes, c as pullInactiveLogsApiPath, i as getGitHubArtifactData, l as pullSessionsApiPath, m as taskInactiveLogsApiPath, n as TaskLeadingVisual, o as getTaskTitle, p as taskApiPath, r as getBranchArtifactData, t as CheckSpinner, u as repoTaskSessionsApiPath, v as useAgentSessionsAlive } from "./server-TaskLeadingVisual-DlKGcMc6-CLgHXns0.js";
import { a as useCurrentUser$1, i as useChatStreamContext, n as CurrentUserProvider, o as useTask, t as ChatStreamProvider } from "./server-use-task-B-REuEVT-BE9pVUx2.js";
import { t as ContextualGlobalSsoBanner } from "./server-ContextualGlobalSsoBanner-BxYXWjwo-Dq9T9smw.js";
import { D as isTaskFromCLI, E as isCLISession, O as useAgentInfo, T as isAPITaskFromCLI, _ as MISSION_CONTROL_EVENT_TYPES, k as useAgentModels, o as AVATAR_FALLBACK_COLORS, p as COPILOT_CHAT_SPEC_TASK_EVENT_TYPE, y as SWEAGENT_CAPI_MODEL_PREFIX } from "./server-CopilotCodingAgentQuotaBanner-W2Ye6Fax-B_w68npu.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { C as useIntentDetectionEnabled, D as uuid, E as useTasks, S as useIntentDetectionContext, T as useSSOChangeDetection, _ as intentDetectionHeaders, b as useCreateAPITask, c as createTask, d as generateTaskPath, f as generateTaskPathForRepo, g as getSortedResourceIds, h as getFlatTaskList$1, i as NewAgentTaskForm, m as getAgentTasksQueryKeyForMutation, p as getAgentTasksQueryKey, r as ModeSelector, t as IntentDetectionEnabledProvider, v as setFlatTaskList$1, w as useMarkdownImageHandling, x as useIntentDetection } from "./server-use-sso-change-detection-DGHiXtJk-Cl1y9joK.js";
import { n as useNavigableRef } from "./server-NavigableRef-V_CJ6v-4-DI5O_E6T.js";
import { n as CodeDropdownButton, t as CloneUrl } from "./server-CodeDropdownButton-7kY3jLbT-Bq5YZEI7.js";
import { t as generateSSOUrl } from "./server-generate-sso-url-dCuQbgAx-DWoF3ZxN.js";
import React, { Children, Fragment, cloneElement, createContext, isValidElement, memo, startTransition, use, useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { flushSync } from "react-dom";
import { c as c$1 } from "react/compiler-runtime";
import { load, loadAll } from "js-yaml";
import { visit } from "unist-util-visit";
import throttle$1 from "lodash-es/throttle.js";
import merge from "lodash.merge";
import mergeWith from "lodash.mergewith";
import isEqual from "lodash-es/isEqual.js";
import sortBy from "lodash-es/sortBy.js";
import { toString } from "mdast-util-to-string";
import capitalize from "lodash-es/capitalize.js";
import { downloadZip } from "client-zip";
import snakeCase from "lodash-es/snakeCase.js";
import { FloatingPortal, autoPlacement, autoUpdate, offset, useDismiss, useFloating, useFocus, useHover, useInteractions, useMergeRefs, useRole } from "@floating-ui/react";
function defaultGetRowId(row) {
	return row.id;
}
function DataTable(t0) {
	const $ = c(27);
	const { "aria-labelledby": labelledby, "aria-describedby": describedby, cellPadding, columns, data, initialSortColumn, initialSortDirection, externalSorting, getRowId: t1, onToggleSort } = t0;
	const getRowId = t1 === void 0 ? defaultGetRowId : t1;
	let t2;
	if ($[0] !== columns || $[1] !== data || $[2] !== externalSorting || $[3] !== getRowId || $[4] !== initialSortColumn || $[5] !== initialSortDirection) {
		t2 = {
			data,
			columns,
			initialSortColumn,
			initialSortDirection,
			getRowId,
			externalSorting
		};
		$[0] = columns;
		$[1] = data;
		$[2] = externalSorting;
		$[3] = getRowId;
		$[4] = initialSortColumn;
		$[5] = initialSortDirection;
		$[6] = t2;
	} else t2 = $[6];
	const { headers, rows, actions, gridTemplateColumns } = useTable(t2);
	let t3;
	if ($[7] !== actions || $[8] !== headers || $[9] !== onToggleSort) {
		let t4;
		if ($[11] !== actions || $[12] !== onToggleSort) {
			t4 = (header) => {
				if (header.isSortable()) return /* @__PURE__ */ jsx(TableSortHeader, {
					align: header.column.align,
					direction: header.getSortDirection(),
					onToggleSort: () => {
						const nextDirection = header.getSortDirection() === "ASC" ? "DESC" : "ASC";
						actions.sortBy(header);
						onToggleSort === null || onToggleSort === void 0 || onToggleSort(header.id, nextDirection);
					},
					children: typeof header.column.header === "string" ? header.column.header : header.column.header()
				}, header.id);
				return /* @__PURE__ */ jsx(TableHeader, {
					align: header.column.align,
					children: typeof header.column.header === "string" ? header.column.header : header.column.header()
				}, header.id);
			};
			$[11] = actions;
			$[12] = onToggleSort;
			$[13] = t4;
		} else t4 = $[13];
		t3 = headers.map(t4);
		$[7] = actions;
		$[8] = headers;
		$[9] = onToggleSort;
		$[10] = t3;
	} else t3 = $[10];
	let t4;
	if ($[14] !== t3) {
		t4 = /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsx(TableRow, { children: t3 }) });
		$[14] = t3;
		$[15] = t4;
	} else t4 = $[15];
	let t5;
	if ($[16] !== rows) {
		t5 = rows.map(_temp$40);
		$[16] = rows;
		$[17] = t5;
	} else t5 = $[17];
	let t6;
	if ($[18] !== t5) {
		t6 = /* @__PURE__ */ jsx(TableBody, { children: t5 });
		$[18] = t5;
		$[19] = t6;
	} else t6 = $[19];
	let t7;
	if ($[20] !== cellPadding || $[21] !== describedby || $[22] !== gridTemplateColumns || $[23] !== labelledby || $[24] !== t4 || $[25] !== t6) {
		t7 = /* @__PURE__ */ jsxs(Table$1, {
			"aria-labelledby": labelledby,
			"aria-describedby": describedby,
			cellPadding,
			gridTemplateColumns,
			children: [t4, t6]
		});
		$[20] = cellPadding;
		$[21] = describedby;
		$[22] = gridTemplateColumns;
		$[23] = labelledby;
		$[24] = t4;
		$[25] = t6;
		$[26] = t7;
	} else t7 = $[26];
	return t7;
}
function _temp$40(row) {
	return /* @__PURE__ */ jsx(TableRow, { children: row.getCells().map((cell) => /* @__PURE__ */ jsx(TableCell, {
		scope: cell.rowHeader ? "row" : void 0,
		align: cell.column.align,
		children: cell.column.renderCell ? cell.column.renderCell(row.getValue()) : cell.getValue()
	}, cell.id)) }, row.id);
}
_temp$40.displayName = "_temp";
var Layout_module_default = {
	banner: "Layout-module_IdPeha_banner",
	columnLeft: "Layout-module_IdPeha_columnLeft",
	columnRight: "Layout-module_IdPeha_columnRight",
	container: "Layout-module_IdPeha_container",
	mainColumn: "Layout-module_IdPeha_mainColumn",
	mainColumnRight: "Layout-module_IdPeha_mainColumnRight",
	monoView: "Layout-module_IdPeha_monoView",
	panelView: "Layout-module_IdPeha_panelView",
	resizing: "Layout-module_IdPeha_resizing",
	resourcePanelOpen: "Layout-module_IdPeha_resourcePanelOpen",
	secondaryColumn: "Layout-module_IdPeha_secondaryColumn",
	secondaryColumnFullWidth: "Layout-module_IdPeha_secondaryColumnFullWidth",
	secondaryColumnHidden: "Layout-module_IdPeha_secondaryColumnHidden",
	secondaryColumnVisible: "Layout-module_IdPeha_secondaryColumnVisible",
	sidebar: "Layout-module_IdPeha_sidebar",
	sidebarCondensed: "Layout-module_IdPeha_sidebarCondensed",
	slimLineTopTabs: "Layout-module_IdPeha_slimLineTopTabs",
	splitView: "Layout-module_IdPeha_splitView",
	verticalSecondaryColumn: "Layout-module_IdPeha_verticalSecondaryColumn"
};
var Header_module_default = {
	column: "Header-module_GI0Axa_column",
	columnHeader: "Header-module_GI0Axa_columnHeader",
	header: "Header-module_GI0Axa_header",
	leftColumn: "Header-module_GI0Axa_leftColumn",
	rightColumn: "Header-module_GI0Axa_rightColumn",
	slimLineTopTabs: "Header-module_GI0Axa_slimLineTopTabs"
};
var LayoutContext = createContext(null);
LayoutContext.displayName = "LayoutContext";
function useLayoutContext() {
	const context = use(LayoutContext);
	if (!context) throw new Error("useLayoutContext must be used within a Layout component");
	return context;
}
var SidebarToggle_module_default = {
	sidebarToggleButton: "SidebarToggle-module_5rmY_a_sidebarToggleButton",
	slimLineTopTabs: "SidebarToggle-module_5rmY_a_slimLineTopTabs"
};
function SidebarToggle() {
	const $ = c$1(3);
	const layoutContext = useLayoutContext();
	const { toggleSidebar } = layoutContext;
	let t0;
	if ($[0] !== layoutContext.slimLineTopTabs || $[1] !== toggleSidebar) {
		t0 = jsx("div", {
			className: clsx(SidebarToggle_module_default.sidebarToggleButton, layoutContext.slimLineTopTabs && SidebarToggle_module_default.slimLineTopTabs),
			children: jsx(IconButton, {
				icon: ThreeBarsIcon,
				onClick: toggleSidebar,
				"aria-label": "Toggle sidebar"
			})
		});
		$[0] = layoutContext.slimLineTopTabs;
		$[1] = toggleSidebar;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
SidebarToggle.displayName = "SidebarToggle";
function HeaderLeft({ children, className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(Header_module_default.column, Header_module_default.leftColumn, className),
		...props,
		children
	});
}
HeaderLeft.displayName = "HeaderLeft";
function HeaderRight({ children, className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(Header_module_default.column, Header_module_default.rightColumn, className),
		...props,
		children
	});
}
HeaderRight.displayName = "HeaderRight";
function Header(t0) {
	const $ = c$1(1);
	const { children, className, ...props } = t0;
	const { slimLineTopTabs } = useLayoutContext();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			leftColumn: HeaderLeft,
			rightColumn: HeaderRight
		};
		$[0] = t1;
	} else t1 = $[0];
	const [slots] = useSlots(children, t1);
	if (slots.leftColumn && slots.rightColumn) return jsxs("header", {
		className: clsx(Header_module_default.columnHeader, slimLineTopTabs && Header_module_default.slimLineTopTabs, className),
		...props,
		children: [
			jsx(SidebarToggle, {}),
			slots.leftColumn,
			slots.rightColumn
		]
	});
	return jsxs("header", {
		className: clsx(Header_module_default.header, slimLineTopTabs && Header_module_default.slimLineTopTabs, className),
		...props,
		children: [jsx(SidebarToggle, {}), children]
	});
}
Header.displayName = "Header";
var HeaderToggleOnly_module_default = { headerToggleOnly: "HeaderToggleOnly-module_HfqSkW_headerToggleOnly" };
/**
* Minimal header component that only renders the SidebarToggle without any header styling or semantic structure.
*/
function HeaderToggleOnly() {
	return /* @__PURE__ */ jsx("div", {
		className: HeaderToggleOnly_module_default.headerToggleOnly,
		children: /* @__PURE__ */ jsx(SidebarToggle, {})
	});
}
HeaderToggleOnly.displayName = "HeaderToggleOnly";
var Sidebar_module_default = {
	container: "Sidebar-module_O45swq_container",
	githubLogo: "Sidebar-module_O45swq_githubLogo",
	header: "Sidebar-module_O45swq_header",
	isExpanded: "Sidebar-module_O45swq_isExpanded",
	sidebar: "Sidebar-module_O45swq_sidebar",
	sidebarDivider: "Sidebar-module_O45swq_sidebarDivider",
	toggleSidebarFloating: "Sidebar-module_O45swq_toggleSidebarFloating",
	toggleSidebarVertical: "Sidebar-module_O45swq_toggleSidebarVertical",
	visible: "Sidebar-module_O45swq_visible"
};
/**
* Default header for the Sidebar component with GitHub logo and close button.
*/
function SidebarHeader({ onToggle, labelId }) {
	return /* @__PURE__ */ jsxs("div", {
		className: Sidebar_module_default.header,
		children: [
			/* @__PURE__ */ jsx("h2", {
				id: labelId,
				className: "sr-only",
				children: "Copilot navigation"
			}),
			/* @__PURE__ */ jsx("a", {
				href: "/",
				target: "_self",
				className: Sidebar_module_default.githubLogo,
				"aria-label": "GitHub homepage",
				children: /* @__PURE__ */ jsx(MarkGithubIcon, { size: 32 })
			}),
			/* @__PURE__ */ jsx(IconButton, {
				icon: XIcon,
				variant: "invisible",
				"aria-label": "Close sidebar",
				onClick: onToggle,
				className: Sidebar_module_default.toggleSidebarFloating
			})
		]
	});
}
/**
* Generic sidebar component that can be used in various layouts.
*/
SidebarHeader.displayName = "SidebarHeader";
function Sidebar({ children, className, innerClassName, isVisible, isExpanded, isCondensable = true, sidebarRef, onToggle, "data-testid": dataTestId, header, "aria-labelledby": ariaLabelledBy }) {
	const ref = useProvidedRefOrCreate(sidebarRef);
	const contentRef = useRef(null);
	const defaultLabelId = `${useId()}-copilot-navigation`;
	const isDefaultHeader = header === void 0;
	const labelId = isDefaultHeader ? defaultLabelId : ariaLabelledBy;
	const headerElement = isDefaultHeader ? /* @__PURE__ */ jsx(SidebarHeader, {
		onToggle,
		labelId: defaultLabelId
	}) : header;
	useFocusTrap({
		containerRef: contentRef,
		disabled: !isVisible
	});
	return /* @__PURE__ */ jsxs("aside", {
		"aria-labelledby": labelId,
		ref,
		className: clsx(Sidebar_module_default.container, className, { [Sidebar_module_default.visible]: isVisible }),
		"data-testid": dataTestId,
		children: [/* @__PURE__ */ jsxs("div", {
			ref: contentRef,
			className: clsx(Sidebar_module_default.sidebar, innerClassName),
			children: [headerElement, children]
		}), isCondensable ? /* @__PURE__ */ jsx("button", {
			className: clsx(Sidebar_module_default.toggleSidebarVertical, { [Sidebar_module_default.isExpanded]: isExpanded }),
			onClick: onToggle,
			tabIndex: -1,
			children: /* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: isVisible || isExpanded ? "Condense sidebar" : "Expand sidebar"
			})
		}) : /* @__PURE__ */ jsx("div", { className: Sidebar_module_default.sidebarDivider })]
	});
}
Sidebar.displayName = "Sidebar";
function hasHeaderColumns(headerElement) {
	if (!headerElement || !isValidElement(headerElement)) return false;
	let hasLeft = false;
	let hasRight = false;
	const children = headerElement.props.children;
	for (const child of Children.toArray(children)) if (isValidElement(child)) {
		if (child.type === HeaderLeft) hasLeft = true;
		if (child.type === HeaderRight) hasRight = true;
	}
	return hasLeft && hasRight;
}
function LayoutSidebar(t0) {
	const $ = c$1(12);
	const { children, className, innerClassName, "data-testid": dataTestId, header, "aria-labelledby": ariaLabelledBy } = t0;
	const { sidebarExpanded, sidebarVisible, sidebarCondensable, toggleSidebar, sidebarRef } = useLayoutContext();
	let t1;
	if ($[0] !== ariaLabelledBy || $[1] !== children || $[2] !== className || $[3] !== dataTestId || $[4] !== header || $[5] !== innerClassName || $[6] !== sidebarCondensable || $[7] !== sidebarExpanded || $[8] !== sidebarRef || $[9] !== sidebarVisible || $[10] !== toggleSidebar) {
		const sidebarProps = header === void 0 ? { header } : {
			header,
			"aria-labelledby": ariaLabelledBy
		};
		t1 = jsx(Sidebar, {
			className: clsx(Layout_module_default.sidebar, className),
			innerClassName,
			isVisible: sidebarVisible,
			isExpanded: sidebarExpanded,
			isCondensable: sidebarCondensable,
			onToggle: toggleSidebar,
			sidebarRef,
			"data-testid": dataTestId,
			...sidebarProps,
			children
		});
		$[0] = ariaLabelledBy;
		$[1] = children;
		$[2] = className;
		$[3] = dataTestId;
		$[4] = header;
		$[5] = innerClassName;
		$[6] = sidebarCondensable;
		$[7] = sidebarExpanded;
		$[8] = sidebarRef;
		$[9] = sidebarVisible;
		$[10] = toggleSidebar;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
LayoutSidebar.displayName = "LayoutSidebar";
function ColumnLeft(t0) {
	const { children, className, ...props } = t0;
	const { mainColumn, slimLineTopTabs } = useLayoutContext();
	const isMain = mainColumn === "left";
	return jsx("div", {
		className: clsx(Layout_module_default.columnLeft, isMain ? Layout_module_default.mainColumn : Layout_module_default.secondaryColumn, !isMain && slimLineTopTabs && Layout_module_default.slimLineTopTabs, className),
		"data-column-position": "left",
		...props,
		children
	});
}
ColumnLeft.displayName = "ColumnLeft";
function ColumnRight(t0) {
	const { children, className, "data-testid": dataTestId, ...props } = t0;
	const { mainColumn, slimLineTopTabs } = useLayoutContext();
	const isMain = mainColumn === "right";
	return jsx("div", {
		className: clsx(Layout_module_default.columnRight, isMain ? Layout_module_default.mainColumn : Layout_module_default.secondaryColumn, !isMain && slimLineTopTabs && Layout_module_default.slimLineTopTabs, className),
		"data-testid": dataTestId,
		"data-column-position": "right",
		...props,
		children
	});
}
ColumnRight.displayName = "ColumnRight";
function Banner() {
	return /* @__PURE__ */ jsx("div", {
		className: Layout_module_default.banner,
		children: /* @__PURE__ */ jsx(ContextualGlobalSsoBanner, {})
	});
}
/**
* Define the breakpoint as a constant that can be shared.
* Has to match the media query used in CSS
*/
Banner.displayName = "Banner";
var LAYOUT_BREAKPOINT = "(max-width: 1024px)";
/**
* Custom hook for tracking media query state
* @param query - The media query string to match
* @returns boolean indicating if the media query matches
*/
function useMediaQuery(query, onChange) {
	const $ = c$1(6);
	let t0;
	if ($[0] !== query) {
		t0 = () => {
			if (typeof window === "undefined") return false;
			return window.matchMedia(query).matches;
		};
		$[0] = query;
		$[1] = t0;
	} else t0 = $[1];
	const [matches, setMatches] = useState(t0);
	let t1;
	let t2;
	if ($[2] !== onChange || $[3] !== query) {
		t1 = () => {
			const mediaQuery = window.matchMedia(query);
			const handleChange = (event) => {
				setMatches(event.matches);
				if (onChange) onChange(event.matches);
			};
			setMatches(mediaQuery.matches);
			mediaQuery.addEventListener("change", handleChange);
			return () => {
				mediaQuery.removeEventListener("change", handleChange);
			};
		};
		t2 = [query, onChange];
		$[2] = onChange;
		$[3] = query;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
	return matches;
}
/**
* Custom hook for tracking resize events using ResizeObserver
* @param target - The ref to the element to observe
* @param callback - Optional callback when resize events occur
* @returns boolean indicating if a resize is currently happening
*/
function useResizeObserver(target, callback) {
	const $ = c$1(6);
	const [isResizing, setIsResizing] = useState(false);
	const resizeTimeoutRef = useRef(void 0);
	let t0;
	if ($[0] !== callback || $[1] !== target.current) {
		t0 = () => {
			if (!target.current) return;
			const resizeObserver = new ResizeObserver((entries) => {
				setIsResizing(true);
				if (resizeTimeoutRef.current) clearTimeout(resizeTimeoutRef.current);
				resizeTimeoutRef.current = window.setTimeout(() => {
					setIsResizing(false);
				}, 150);
				if (callback && entries[0]) callback(entries[0]);
			});
			resizeObserver.observe(target.current);
			return () => {
				resizeObserver.disconnect();
				if (resizeTimeoutRef.current) clearTimeout(resizeTimeoutRef.current);
			};
		};
		$[0] = callback;
		$[1] = target.current;
		$[2] = t0;
	} else t0 = $[2];
	let t1;
	if ($[3] !== callback || $[4] !== target) {
		t1 = [target, callback];
		$[3] = callback;
		$[4] = target;
		$[5] = t1;
	} else t1 = $[5];
	useEffect(t0, t1);
	return isResizing;
}
var SIDEBAR_EXPANDED_KEY = "COPILOT_IMMERSIVE_SIDEBAR_COLLAPSED_STATE_KEY";
function getSidebarExpandedState() {
	if (typeof window === "undefined") return true;
	try {
		const value = localStorage.getItem(SIDEBAR_EXPANDED_KEY);
		return value === null ? true : JSON.parse(value);
	} catch {
		return true;
	}
}
function setSidebarExpandedState(expanded) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(SIDEBAR_EXPANDED_KEY, JSON.stringify(expanded));
	} catch {}
}
/**
* Custom hook for layout state management
* Handles sidebar visibility and expansion states, as well as secondary column visibility.
* Responsive behavior is handled via CSS media queries.
*/
function useLayoutState(mainColumn, secondaryColumnState, resourcePanelState, t0, t1) {
	const $ = c$1(41);
	const sidebarCondensable = t0 === void 0 ? true : t0;
	const slimLineTopTabs = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== sidebarCondensable) {
		t2 = () => sidebarCondensable ? getSidebarExpandedState() : true;
		$[0] = sidebarCondensable;
		$[1] = t2;
	} else t2 = $[1];
	const [sidebarExpanded, setSidebarExpanded] = useState(t2);
	const [sidebarVisible, setSidebarVisible] = useState(false);
	const internalSecondaryColumnState = useState(false);
	const internalResourcePanelState = useState(false);
	const [secondaryColumnVisible, setSecondaryColumnVisible] = secondaryColumnState ?? internalSecondaryColumnState;
	const [resourcePanelOpen, setResourcePanelOpen] = resourcePanelState ?? internalResourcePanelState;
	const [secondaryColumnFullWidth, setSecondaryColumnFullWidth] = useState(false);
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = {
			visible: false,
			resourcePanel: false,
			fullWidth: false
		};
		$[2] = t3;
	} else t3 = $[2];
	const desktopStateRef = useRef(t3);
	let t4;
	if ($[3] !== resourcePanelOpen || $[4] !== secondaryColumnFullWidth || $[5] !== secondaryColumnVisible || $[6] !== setResourcePanelOpen || $[7] !== setSecondaryColumnVisible) {
		t4 = (isMobile) => {
			if (isMobile) {
				desktopStateRef.current = {
					visible: secondaryColumnVisible,
					resourcePanel: resourcePanelOpen,
					fullWidth: secondaryColumnFullWidth
				};
				setSidebarVisible(false);
				if (!secondaryColumnFullWidth) setSecondaryColumnVisible(false);
			} else {
				setSecondaryColumnVisible(desktopStateRef.current.visible);
				setResourcePanelOpen(desktopStateRef.current.resourcePanel);
				setSecondaryColumnFullWidth(desktopStateRef.current.fullWidth);
			}
		};
		$[3] = resourcePanelOpen;
		$[4] = secondaryColumnFullWidth;
		$[5] = secondaryColumnVisible;
		$[6] = setResourcePanelOpen;
		$[7] = setSecondaryColumnVisible;
		$[8] = t4;
	} else t4 = $[8];
	const layoutBreakpoint = useMediaQuery(LAYOUT_BREAKPOINT, t4);
	const containerRef = useRef(null);
	const sidebarRef = useRef(null);
	let t5;
	if ($[9] !== layoutBreakpoint || $[10] !== sidebarCondensable || $[11] !== sidebarExpanded || $[12] !== sidebarVisible) {
		t5 = () => {
			if (layoutBreakpoint) setSidebarVisible(!sidebarVisible);
			else if (sidebarCondensable) {
				const newExpandedState = !sidebarExpanded;
				setSidebarExpanded(newExpandedState);
				setSidebarExpandedState(newExpandedState);
			}
		};
		$[9] = layoutBreakpoint;
		$[10] = sidebarCondensable;
		$[11] = sidebarExpanded;
		$[12] = sidebarVisible;
		$[13] = t5;
	} else t5 = $[13];
	const toggleSidebar = t5;
	let t6;
	if ($[14] !== secondaryColumnVisible || $[15] !== setResourcePanelOpen || $[16] !== setSecondaryColumnVisible) {
		t6 = () => {
			if (secondaryColumnVisible) setResourcePanelOpen(false);
			setSecondaryColumnVisible(!secondaryColumnVisible);
		};
		$[14] = secondaryColumnVisible;
		$[15] = setResourcePanelOpen;
		$[16] = setSecondaryColumnVisible;
		$[17] = t6;
	} else t6 = $[17];
	const toggleSecondaryColumn = t6;
	let t7;
	if ($[18] !== resourcePanelOpen || $[19] !== setResourcePanelOpen) {
		t7 = () => {
			setResourcePanelOpen(!resourcePanelOpen);
		};
		$[18] = resourcePanelOpen;
		$[19] = setResourcePanelOpen;
		$[20] = t7;
	} else t7 = $[20];
	const toggleResourcePanel = t7;
	let t8;
	if ($[21] !== secondaryColumnFullWidth) {
		t8 = () => {
			setSecondaryColumnFullWidth(!secondaryColumnFullWidth);
		};
		$[21] = secondaryColumnFullWidth;
		$[22] = t8;
	} else t8 = $[22];
	const toggleSecondaryColumnFullWidth = t8;
	let t9;
	if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = (updater) => {
			desktopStateRef.current = updater(desktopStateRef.current);
		};
		$[23] = t9;
	} else t9 = $[23];
	const setDesktopLayoutState = t9;
	let t10;
	let t11;
	if ($[24] !== sidebarVisible) {
		t10 = () => {
			if (sidebarVisible && sidebarRef.current) {
				const handleClickOutside = (event) => {
					if (sidebarRef.current && !sidebarRef.current.contains(event.target)) setSidebarVisible(false);
				};
				document.addEventListener("mousedown", handleClickOutside);
				document.addEventListener("touchstart", handleClickOutside, { passive: true });
				return () => {
					document.removeEventListener("mousedown", handleClickOutside);
					document.removeEventListener("touchstart", handleClickOutside);
				};
			}
		};
		t11 = [sidebarVisible];
		$[24] = sidebarVisible;
		$[25] = t10;
		$[26] = t11;
	} else {
		t10 = $[25];
		t11 = $[26];
	}
	useEffect(t10, t11);
	let t12;
	if ($[27] !== layoutBreakpoint || $[28] !== mainColumn || $[29] !== resourcePanelOpen || $[30] !== secondaryColumnFullWidth || $[31] !== secondaryColumnVisible || $[32] !== sidebarCondensable || $[33] !== sidebarExpanded || $[34] !== sidebarVisible || $[35] !== slimLineTopTabs || $[36] !== toggleResourcePanel || $[37] !== toggleSecondaryColumn || $[38] !== toggleSecondaryColumnFullWidth || $[39] !== toggleSidebar) {
		t12 = {
			sidebarExpanded,
			sidebarVisible,
			sidebarCondensable,
			toggleSidebar,
			secondaryColumnVisible,
			toggleSecondaryColumn,
			secondaryColumnFullWidth,
			toggleSecondaryColumnFullWidth,
			resourcePanelOpen,
			toggleResourcePanel,
			setDesktopLayoutState,
			layoutBreakpoint,
			mainColumn,
			slimLineTopTabs,
			containerRef,
			sidebarRef
		};
		$[27] = layoutBreakpoint;
		$[28] = mainColumn;
		$[29] = resourcePanelOpen;
		$[30] = secondaryColumnFullWidth;
		$[31] = secondaryColumnVisible;
		$[32] = sidebarCondensable;
		$[33] = sidebarExpanded;
		$[34] = sidebarVisible;
		$[35] = slimLineTopTabs;
		$[36] = toggleResourcePanel;
		$[37] = toggleSecondaryColumn;
		$[38] = toggleSecondaryColumnFullWidth;
		$[39] = toggleSidebar;
		$[40] = t12;
	} else t12 = $[40];
	return t12;
}
function LayoutRoot(t0) {
	const $ = c$1(1);
	const { children, className, mainColumn: t1, "data-testid": dataTestId, secondaryColumnState, resourcePanelState, faviconOverride, mobileSecondaryColumnDirection: t2, sidebarCondensable: t3, slimLineTopTabs: t4, ...props } = t0;
	const mainColumn = t1 === void 0 ? "left" : t1;
	const mobileSecondaryColumnDirection = t2 === void 0 ? "horizontal" : t2;
	const sidebarCondensable = t3 === void 0 ? true : t3;
	const slimLineTopTabs = t4 === void 0 ? false : t4;
	let t5;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = {
			banner: Banner,
			header: Header,
			sidebar: LayoutSidebar,
			columnLeft: ColumnLeft,
			columnRight: ColumnRight
		};
		$[0] = t5;
	} else t5 = $[0];
	const [slots] = useSlots(children, t5);
	const headerHasColumns = hasHeaderColumns(slots.header || null);
	const hasOnlyOneColumn = !!slots.columnLeft && !slots.columnRight || !slots.columnLeft && !!slots.columnRight;
	const hasTwoColumns = !!slots.columnLeft && !!slots.columnRight;
	const isSplitView = headerHasColumns;
	const isPanelView = !headerHasColumns && !hasOnlyOneColumn;
	const layoutState = useLayoutState(mainColumn, secondaryColumnState, resourcePanelState, sidebarCondensable, slimLineTopTabs);
	const { containerRef, secondaryColumnVisible, secondaryColumnFullWidth, sidebarExpanded, resourcePanelOpen } = layoutState;
	const isResizing = useResizeObserver(containerRef);
	return jsx(LayoutContext, {
		value: layoutState,
		children: jsxs("div", {
			className: clsx(Layout_module_default.container, slimLineTopTabs && Layout_module_default.slimLineTopTabs, isPanelView && Layout_module_default.panelView, isSplitView && Layout_module_default.splitView, isSplitView && mainColumn === "right" && Layout_module_default.mainColumnRight, secondaryColumnVisible && Layout_module_default.secondaryColumnVisible, !secondaryColumnVisible && hasTwoColumns && Layout_module_default.secondaryColumnHidden, secondaryColumnFullWidth && Layout_module_default.secondaryColumnFullWidth, resourcePanelOpen && Layout_module_default.resourcePanelOpen, hasOnlyOneColumn && Layout_module_default.monoView, !sidebarExpanded && Layout_module_default.sidebarCondensed, isResizing && Layout_module_default.resizing, mobileSecondaryColumnDirection === "vertical" && Layout_module_default.verticalSecondaryColumn, className),
			"data-testid": dataTestId,
			ref: containerRef,
			...props,
			children: [
				faviconOverride && jsx("span", {
					"data-favicon-override": faviconOverride,
					"data-testid": "favicon-override"
				}),
				jsx(Banner, {}),
				slots.sidebar,
				slots.header || jsx(HeaderToggleOnly, {}),
				slots.columnLeft,
				slots.columnRight
			]
		})
	});
}
LayoutRoot.displayName = "LayoutRoot";
var Layout = Object.assign(LayoutRoot, {
	Banner,
	Sidebar: LayoutSidebar,
	ColumnLeft,
	ColumnRight,
	Header,
	HeaderLeft,
	HeaderRight
});
var SessionContext = createContext(void 0);
SessionContext.displayName = "SessionContext";
function useSessionContext() {
	const context = use(SessionContext);
	if (!context) throw new Error("useSessionContext must be used within a SessionContextProvider");
	return context;
}
function SessionContextProvider(t0) {
	const $ = c$1(10);
	const { session, sessionOwner, logs, logsAreLoading, children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {};
		$[0] = t1;
	} else t1 = $[0];
	const [mcpToolNameMappings, setMcpToolNameMappings] = useState(t1);
	let t2;
	if ($[1] !== logs || $[2] !== logsAreLoading || $[3] !== mcpToolNameMappings || $[4] !== session || $[5] !== sessionOwner) {
		t2 = {
			session,
			sessionOwner,
			logs,
			logsAreLoading,
			mcpToolNameMappings,
			setMcpToolNameMappings
		};
		$[1] = logs;
		$[2] = logsAreLoading;
		$[3] = mcpToolNameMappings;
		$[4] = session;
		$[5] = sessionOwner;
		$[6] = t2;
	} else t2 = $[6];
	const value = t2;
	let t3;
	if ($[7] !== children || $[8] !== value) {
		t3 = jsx(SessionContext, {
			value,
			children
		});
		$[7] = children;
		$[8] = value;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
SessionContextProvider.displayName = "SessionContextProvider";
/**
* Initializes the auth token from SSR payload if provided.
*/
function useInitializeAuthToken(initialAuthToken) {
	if (!initialAuthToken) return;
	const tokenProvider = getAgentSessionsTokenProvider();
	tokenProvider.ssoOrgIDs = initialAuthToken.ssoOrgIDs ?? [];
	const existingToken = tokenProvider.getLocalStorageAuthToken();
	if (!existingToken || existingToken.isExpired || existingToken.value !== initialAuthToken.token) {
		const token = new AuthToken(initialAuthToken.token, initialAuthToken.expiration, initialAuthToken.ssoOrgIDs ?? []);
		tokenProvider.setLocalStorageAuthToken(token);
	}
}
async function fetchAppPayload(globalID, sessionId) {
	if (!globalID) throw new Error("No globalID provided");
	const url = new URL(`/copilot/tasks/pull/${globalID}`, window.location.origin);
	if (sessionId) url.searchParams.set("session_id", sessionId);
	const response = await fetch(url.toString(), { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error(`Failed to fetch task payload for ${globalID}`);
	return await response.json();
}
async function fetchAppPayloadByTask$1(taskID, owner, repo) {
	if (!taskID) throw new Error("No taskID provided");
	if (!owner) throw new Error("No owner provided");
	if (!repo) throw new Error("No repo provided");
	const url = new URL(`/copilot/t/${owner}/${repo}/${taskID}`, window.location.origin);
	const response = await fetch(url.toString(), { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error(`Failed to fetch task payload for ${taskID}`);
	return await response.json();
}
function hasExpectedKeys$1(data, keys) {
	return typeof data === "object" && data !== null && keys.every((key) => key in data);
}
var agentTaskKeys$1 = [
	"pull",
	"sessions",
	"currentUser",
	"currentUserCanPush",
	"steeringEnabled",
	"logsPollingInterval",
	"sessionsPollingInterval"
];
function isTaskAppPayload$1(payload) {
	return !!payload && hasExpectedKeys$1(payload, agentTaskKeys$1);
}
function useOrFetchTaskViewPayload() {
	const $ = c$1(14);
	const ssrPayload = useAppPayload();
	const { globalID, taskID, owner, repository } = useParams$1();
	const [searchParams] = useSearchParams();
	let t0;
	if ($[0] !== searchParams) {
		t0 = searchParams.get("session_id");
		$[0] = searchParams;
		$[1] = t0;
	} else t0 = $[1];
	const sessionId = t0;
	const validPayload = isTaskAppPayload$1(ssrPayload) && globalID && ssrPayload.pull && ssrPayload.pull.global_relay_id === globalID ? ssrPayload : void 0;
	useInitializeAuthToken(ssrPayload?.initialAuthToken);
	let t1;
	let t2;
	if ($[2] !== globalID || $[3] !== owner || $[4] !== repository || $[5] !== sessionId || $[6] !== taskID) {
		t1 = [
			"agent-task-payload",
			globalID,
			taskID,
			sessionId,
			owner,
			repository
		];
		t2 = () => globalID ? fetchAppPayload(globalID, sessionId) : fetchAppPayloadByTask$1(taskID, owner, repository);
		$[2] = globalID;
		$[3] = owner;
		$[4] = repository;
		$[5] = sessionId;
		$[6] = taskID;
		$[7] = t1;
		$[8] = t2;
	} else {
		t1 = $[7];
		t2 = $[8];
	}
	const t3 = (!!globalID || !!taskID) && !validPayload;
	let t4;
	if ($[9] !== t1 || $[10] !== t2 || $[11] !== t3 || $[12] !== validPayload) {
		t4 = {
			queryKey: t1,
			queryFn: t2,
			initialData: validPayload,
			enabled: t3,
			staleTime: Infinity
		};
		$[9] = t1;
		$[10] = t2;
		$[11] = t3;
		$[12] = validPayload;
		$[13] = t4;
	} else t4 = $[13];
	return useQuery(t4);
}
function useSessions({ pullId, taskId, initialData, sessionsPollingInterval, clearPendingChat }) {
	const repo = useCurrentRepository();
	const [consecutiveFailures, setConsecutiveFailures] = useState(0);
	const [timedOut, setHasTimedOut] = useState(false);
	const isRetrying = consecutiveFailures > 0 && !timedOut;
	const params = useParams$1();
	const [searchParams] = useSearchParams();
	const sessionIdInQueryParams = searchParams.get("session_id");
	const sessionIdFromUrl = params.session_id || sessionIdInQueryParams;
	const queryByTask = useRef(true);
	const previousSessionCount = useRef(null);
	const queryClient = useQueryClient();
	const queryIdentifier = taskId ?? pullId;
	const { isConnected: aliveIsConnected } = useAgentSessionsAlive({
		onEvent: useDebounce(useCallback(() => {
			queryClient.invalidateQueries({ queryKey: [
				"agent-sessions",
				repo.ownerLogin,
				repo.name,
				queryIdentifier
			] });
		}, [
			queryClient,
			repo.ownerLogin,
			repo.name,
			queryIdentifier
		]), sessionsPollingInterval, { maxWait: 1e4 }),
		enableCreateEvents: false,
		enableUpdateEvents: true,
		enableLogUpdates: false
	});
	return {
		...useCAPIQuery({
			queryKey: [
				"agent-sessions",
				repo.ownerLogin,
				repo.name,
				queryIdentifier
			],
			queryFn: async () => {
				try {
					let sessions = [];
					if (queryByTask.current) {
						let resourcePath;
						if (taskId) resourcePath = taskApiPath(repo.ownerLogin, repo.name, taskId);
						else if (pullId !== void 0) resourcePath = pullSessionsApiPath(pullId);
						else throw new Error("Either taskId or pullId must be provided to fetch sessions");
						sessions = (await (await fetchCAPI({ path: resourcePath })).json()).sessions;
						const urlSessionInQuery = sessions.some((session) => session.id === sessionIdFromUrl);
						if (sessions.length === 0 || sessionIdFromUrl && !urlSessionInQuery) queryByTask.current = false;
					}
					if (!queryByTask.current) {
						const sessionData = await (await fetchCAPI({ path: `/agents/sessions/${sessionIdFromUrl}` })).json();
						if (sessionData && sessionData.id) sessions = [sessionData];
					}
					setConsecutiveFailures(0);
					setHasTimedOut(false);
					if (previousSessionCount.current !== null && sessions.length !== previousSessionCount.current) clearPendingChat?.();
					previousSessionCount.current = sessions.length;
					return sessions.sort((a, b) => {
						return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
					});
				} catch (error) {
					setConsecutiveFailures((prev) => {
						const newCount = prev + 1;
						if (newCount >= 10) setHasTimedOut(true);
						return newCount;
					});
					throw error;
				}
			},
			initialData,
			refetchInterval: aliveIsConnected ? false : sessionsPollingInterval,
			enabled: consecutiveFailures < 10 && (pullId !== void 0 || !!taskId)
		}),
		timedOut,
		isRetrying
	};
}
var PLAN_STATE_APPROVED = "approved";
var PLAN_STATE_DISMISSED = "dismissed";
var PLAN_EVENT_APPROVED = "plan_approved";
var PLAN_EVENT_DISMISSED = "plan_dismissed";
var PLAN_STATE_TO_EVENT = {
	[PLAN_STATE_APPROVED]: PLAN_EVENT_APPROVED,
	[PLAN_STATE_DISMISSED]: PLAN_EVENT_DISMISSED
};
function usePatchSession(t0) {
	const $ = c$1(11);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { onSuccess, onError } = t1;
	const queryClient = useQueryClient();
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = ["patchSession"];
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== onSuccess || $[4] !== queryClient) {
		t3 = (data_0, variables) => {
			queryClient.invalidateQueries({ queryKey: ["agent-sessions"] });
			onSuccess?.(data_0, variables);
		};
		$[3] = onSuccess;
		$[4] = queryClient;
		$[5] = t3;
	} else t3 = $[5];
	let t4;
	if ($[6] !== onError) {
		t4 = (error, variables_0) => {
			onError?.(error, variables_0);
		};
		$[6] = onError;
		$[7] = t4;
	} else t4 = $[7];
	let t5;
	if ($[8] !== t3 || $[9] !== t4) {
		t5 = {
			mutationKey: t2,
			mutationFn: _temp$39,
			onSuccess: t3,
			onError: t4
		};
		$[8] = t3;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	return useMutation(t5);
}
async function _temp$39(patch) {
	const data = await (await fetchCAPI({
		path: "/agents/sessions",
		method: "PATCH",
		body: { patches: [patch] }
	})).json();
	if (data.failure_count > 0) throw new Error(data.failures[0]?.error ?? "Failed to patch session");
	return data;
}
/**
* Extracts the thread ID from a copilot-chat-spec-task event identifier.
* Format: "copilot-chat-spec-task::{threadId}::{taskTag}"
* Example: "copilot-chat-spec-task::thread-abc123::task-1" -> "thread-abc123"
*
* @param eventIdentifier - The event identifier string
* @returns The thread ID, or undefined if not found
*/
function extractSpecTaskThreadId(eventIdentifier) {
	const prefix = `${COPILOT_CHAT_SPEC_TASK_EVENT_TYPE}::`;
	const delimiter = "::";
	if (!eventIdentifier.startsWith(prefix)) return;
	const remainder = eventIdentifier.slice(prefix.length);
	const delimiterIndex = remainder.indexOf(delimiter);
	if (delimiterIndex === -1) return;
	return remainder.slice(0, delimiterIndex) || void 0;
}
/**
* Extracts thread ID from any event identifier in a session or task.
*
* @param eventIdentifiers - Array of event identifiers from a session or task
* @returns The thread ID, or undefined if not found
*/
function extractSpecTaskThreadIdFromEventIdentifiers(eventIdentifiers) {
	if (!eventIdentifiers || eventIdentifiers.length === 0) return;
	for (const identifier of eventIdentifiers) {
		const threadId = extractSpecTaskThreadId(identifier);
		if (threadId) return threadId;
	}
}
function generateLogsQueryKey(sessionId, repoOwner, repoName) {
	return [
		"agent-pr-session-logs",
		sessionId,
		repoOwner,
		repoName
	];
}
/**
* Fetches logs for a session via streaming API.
*/
async function fetchSessionLogs(sessionId) {
	const reader = (await fetchCAPI({
		path: `/agents/sessions/${sessionId}/logs`,
		streamingResponse: true
	})).body?.getReader();
	if (!reader) throw new Error("No reader found in response body");
	const logs = [];
	const streamer = new CopilotChatMessageStreamer(reader);
	for await (const message of streamer.stream()) if (isValidLogEntry(message)) logs.push(message);
	else throw new Error(`Invalid log entry received: ${JSON.stringify(message)}`);
	return logs;
}
/**
* Low-level hook for fetching session logs with react-query.
* Use this when you need direct control over the query, or when you're outside SessionContext.
*/
function useLogsQuery(t0) {
	const $ = c$1(11);
	const { sessionId, enabled: t1, refetchInterval: t2 } = t0;
	const enabled = t1 === void 0 ? true : t1;
	const refetchInterval = t2 === void 0 ? false : t2;
	const repo = useCurrentRepository();
	let t3;
	if ($[0] !== repo.name || $[1] !== repo.ownerLogin || $[2] !== sessionId) {
		t3 = generateLogsQueryKey(sessionId, repo.ownerLogin, repo.name);
		$[0] = repo.name;
		$[1] = repo.ownerLogin;
		$[2] = sessionId;
		$[3] = t3;
	} else t3 = $[3];
	let t4;
	if ($[4] !== sessionId) {
		t4 = async () => {
			if (!sessionId) throw new Error("No session ID provided");
			return fetchSessionLogs(sessionId);
		};
		$[4] = sessionId;
		$[5] = t4;
	} else t4 = $[5];
	const t5 = enabled && !!sessionId;
	let t6;
	if ($[6] !== refetchInterval || $[7] !== t3 || $[8] !== t4 || $[9] !== t5) {
		t6 = {
			queryKey: t3,
			queryFn: t4,
			refetchInterval,
			enabled: t5
		};
		$[6] = refetchInterval;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
		$[10] = t6;
	} else t6 = $[10];
	return useCAPIQuery(t6);
}
function useLogs(t0) {
	const $ = c$1(34);
	const { logsPollingInterval, batchCompletedSessions: t1, currentUserIsSessionOwner } = t0;
	const batchCompletedSessions = t1 === void 0 ? true : t1;
	const { session, logs: preQueriedLogs, logsAreLoading: inactiveLogsLoading } = useSessionContext();
	const repo = useCurrentRepository();
	const queryClient = useQueryClient();
	const [consecutiveFailures, setConsecutiveFailures] = useState(0);
	const activeSessionId = session.id;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [
			SessionState.Completed,
			SessionState.Failed,
			SessionState.Cancelled
		].map(_temp$38);
		$[0] = t2;
	} else t2 = $[0];
	const sessionCompleted = t2.includes(session.state);
	const useCachedLogs = batchCompletedSessions && currentUserIsSessionOwner && sessionCompleted;
	let t3;
	if ($[1] !== activeSessionId || $[2] !== queryClient || $[3] !== repo.name || $[4] !== repo.ownerLogin) {
		t3 = () => {
			queryClient.invalidateQueries({ queryKey: generateLogsQueryKey(activeSessionId, repo.ownerLogin, repo.name) });
		};
		$[1] = activeSessionId;
		$[2] = queryClient;
		$[3] = repo.name;
		$[4] = repo.ownerLogin;
		$[5] = t3;
	} else t3 = $[5];
	const handleLogUpdate = t3;
	let t4;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = { maxWait: 5e3 };
		$[6] = t4;
	} else t4 = $[6];
	const debouncedHandleLogUpdate = useDebounce(handleLogUpdate, logsPollingInterval, t4);
	let t5;
	if ($[7] !== debouncedHandleLogUpdate) {
		t5 = {
			onEvent: debouncedHandleLogUpdate,
			enableCreateEvents: false,
			enableUpdateEvents: false,
			enableLogUpdates: true
		};
		$[7] = debouncedHandleLogUpdate;
		$[8] = t5;
	} else t5 = $[8];
	const { isConnected: aliveIsConnected } = useAgentSessionsAlive(t5);
	let t6;
	if ($[9] !== activeSessionId || $[10] !== repo.name || $[11] !== repo.ownerLogin) {
		t6 = generateLogsQueryKey(activeSessionId, repo.ownerLogin, repo.name);
		$[9] = activeSessionId;
		$[10] = repo.name;
		$[11] = repo.ownerLogin;
		$[12] = t6;
	} else t6 = $[12];
	let t7;
	if ($[13] !== activeSessionId) {
		t7 = async () => {
			if (!activeSessionId) throw new Error("No session ID provided");
			try {
				const logs = await fetchSessionLogs(activeSessionId);
				setConsecutiveFailures(0);
				return logs;
			} catch (t8) {
				const error = t8;
				throw new Error(`Error while streaming logs. Error: ${error}`);
			}
		};
		$[13] = activeSessionId;
		$[14] = t7;
	} else t7 = $[14];
	const t8 = aliveIsConnected ? false : logsPollingInterval;
	let t9;
	if ($[15] !== consecutiveFailures || $[16] !== session || $[17] !== useCachedLogs) {
		t9 = !isPendingSession(session) && !useCachedLogs && consecutiveFailures < 10;
		$[15] = consecutiveFailures;
		$[16] = session;
		$[17] = useCachedLogs;
		$[18] = t9;
	} else t9 = $[18];
	let t10;
	if ($[19] !== t6 || $[20] !== t7 || $[21] !== t8 || $[22] !== t9) {
		t10 = {
			queryKey: t6,
			queryFn: t7,
			refetchInterval: t8,
			enabled: t9
		};
		$[19] = t6;
		$[20] = t7;
		$[21] = t8;
		$[22] = t9;
		$[23] = t10;
	} else t10 = $[23];
	const query = useCAPIQuery(t10);
	let t11;
	let t12;
	if ($[24] !== query.error) {
		t11 = () => {
			if (query.error) setConsecutiveFailures(_temp2$14);
		};
		t12 = [query.error];
		$[24] = query.error;
		$[25] = t11;
		$[26] = t12;
	} else {
		t11 = $[25];
		t12 = $[26];
	}
	useEffect(t11, t12);
	const showPollingError = query.error && consecutiveFailures >= 10;
	if (useCachedLogs && (preQueriedLogs?.length || inactiveLogsLoading)) {
		let t13;
		if ($[27] !== inactiveLogsLoading || $[28] !== preQueriedLogs || $[29] !== showPollingError) {
			t13 = {
				data: preQueriedLogs,
				isLoading: inactiveLogsLoading,
				error: false,
				showPollingError
			};
			$[27] = inactiveLogsLoading;
			$[28] = preQueriedLogs;
			$[29] = showPollingError;
			$[30] = t13;
		} else t13 = $[30];
		return t13;
	} else {
		let t13;
		if ($[31] !== query || $[32] !== showPollingError) {
			t13 = {
				...query,
				showPollingError
			};
			$[31] = query;
			$[32] = showPollingError;
			$[33] = t13;
		} else t13 = $[33];
		return t13;
	}
}
function _temp2$14(prev) {
	return prev + 1;
}
function _temp$38(state) {
	return state.toLowerCase();
}
var AgentAvatar_module_default = { avatarWrapper: "AgentAvatar-module_JJNSGW_avatarWrapper" };
/**
* Component that displays the agent's avatar if available,
* otherwise falls back to the Copilot animation.
*
*/
function AgentAvatar(t0) {
	const $ = c$1(8);
	const { size: t1, animationType: t2, loopAnimation: t3, agentId } = t0;
	const size = t1 === void 0 ? 32 : t1;
	const animationType = t2 === void 0 ? "static" : t2;
	const loopAnimation = t3 === void 0 ? false : t3;
	const { data: agentInfo } = useAgentInfo(agentId ?? null);
	const agentAvatarUrl = agentInfo?.avatar_url;
	const agentDisplayName = agentInfo?.display_name || "Agent";
	if (agentDisplayName.toLowerCase() === "copilot" || !agentAvatarUrl) {
		let t4;
		if ($[0] !== animationType || $[1] !== loopAnimation || $[2] !== size) {
			t4 = jsx("span", {
				className: AgentAvatar_module_default.avatarWrapper,
				children: jsx(CopilotAnimation, {
					size,
					animationType,
					loopAnimation
				})
			});
			$[0] = animationType;
			$[1] = loopAnimation;
			$[2] = size;
			$[3] = t4;
		} else t4 = $[3];
		return t4;
	}
	let t4;
	if ($[4] !== agentAvatarUrl || $[5] !== agentDisplayName || $[6] !== size) {
		t4 = jsx("span", {
			className: AgentAvatar_module_default.avatarWrapper,
			children: jsx(GitHubAvatar, {
				src: agentAvatarUrl,
				size,
				alt: agentDisplayName,
				square: true
			})
		});
		$[4] = agentAvatarUrl;
		$[5] = agentDisplayName;
		$[6] = size;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
}
AgentAvatar.displayName = "AgentAvatar";
var LegacyCopilotMessage_module_default = {
	container: "LegacyCopilotMessage-module_QlTXrG_container",
	icon: "LegacyCopilotMessage-module_QlTXrG_icon",
	loadingText: "LegacyCopilotMessage-module_QlTXrG_loadingText",
	message: "LegacyCopilotMessage-module_QlTXrG_message",
	text: "LegacyCopilotMessage-module_QlTXrG_text"
};
function CopilotMessageBubble({ markdown, showAvatar = true }) {
	return /* @__PURE__ */ jsxs("div", {
		className: LegacyCopilotMessage_module_default.message,
		children: [/* @__PURE__ */ jsx("div", {
			className: LegacyCopilotMessage_module_default.icon,
			children: showAvatar && /* @__PURE__ */ jsx(AgentAvatar, {
				size: 32,
				animationType: "static",
				loopAnimation: false
			})
		}), /* @__PURE__ */ jsx(MarkdownRenderer, {
			className: LegacyCopilotMessage_module_default.text,
			markdown
		})]
	});
}
CopilotMessageBubble.displayName = "CopilotMessageBubble";
function CopilotMessageContainer({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: LegacyCopilotMessage_module_default.container,
		children
	});
}
CopilotMessageContainer.displayName = "CopilotMessageContainer";
function CopilotMessageLoading() {
	return /* @__PURE__ */ jsx("div", {
		className: LegacyCopilotMessage_module_default.container,
		children: /* @__PURE__ */ jsxs("div", {
			className: LegacyCopilotMessage_module_default.message,
			children: [/* @__PURE__ */ jsx("div", {
				className: LegacyCopilotMessage_module_default.icon,
				children: /* @__PURE__ */ jsx(LoadingSkeleton, {
					variant: "elliptical",
					height: "32px",
					width: "32px"
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: clsx(LegacyCopilotMessage_module_default.text, LegacyCopilotMessage_module_default.loadingText),
				children: [
					/* @__PURE__ */ jsx(LoadingSkeleton, {
						variant: "rounded",
						height: "sm",
						width: "100%"
					}),
					/* @__PURE__ */ jsx(LoadingSkeleton, {
						variant: "rounded",
						height: "sm",
						width: "100%"
					}),
					/* @__PURE__ */ jsx(LoadingSkeleton, {
						variant: "rounded",
						height: "sm",
						width: "70%"
					})
				]
			})]
		})
	});
}
CopilotMessageLoading.displayName = "CopilotMessageLoading";
var PlanApprovalDisplay_module_default = {
	dialogActions: "PlanApprovalDisplay-module_wM9Rlq_dialogActions",
	dialogContent: "PlanApprovalDisplay-module_wM9Rlq_dialogContent",
	scrolledTop: "PlanApprovalDisplay-module_wM9Rlq_scrolledTop",
	summary: "PlanApprovalDisplay-module_wM9Rlq_summary",
	summaryContainer: "PlanApprovalDisplay-module_wM9Rlq_summaryContainer",
	summaryGradient: "PlanApprovalDisplay-module_wM9Rlq_summaryGradient",
	summaryGradientTop: "PlanApprovalDisplay-module_wM9Rlq_summaryGradientTop"
};
var UserChoiceCard_module_default = {
	card: "UserChoiceCard-module_QXjGbq_card",
	choices: "UserChoiceCard-module_QXjGbq_choices",
	collapseButton: "UserChoiceCard-module_QXjGbq_collapseButton",
	content: "UserChoiceCard-module_QXjGbq_content",
	embedded: "UserChoiceCard-module_QXjGbq_embedded",
	footerButtons: "UserChoiceCard-module_QXjGbq_footerButtons",
	header: "UserChoiceCard-module_QXjGbq_header",
	headerActions: "UserChoiceCard-module_QXjGbq_headerActions",
	headerText: "UserChoiceCard-module_QXjGbq_headerText",
	previewContent: "UserChoiceCard-module_QXjGbq_previewContent",
	subtitle: "UserChoiceCard-module_QXjGbq_subtitle",
	title: "UserChoiceCard-module_QXjGbq_title"
};
/** Shared card wrapper for active interactive user prompts */
function UserChoiceCard(t0) {
	const $ = c$1(13);
	const { title, subtitle, headerButtons, previewContent, children, footerButtons, embedded: t1, isExpanded: isExpandedProp, onToggle } = t0;
	const embedded = t1 === void 0 ? false : t1;
	const [isExpandedInternal, setIsExpandedInternal] = useState(true);
	const isControlled = isExpandedProp !== void 0;
	const isExpanded = isControlled ? isExpandedProp : isExpandedInternal;
	let t2;
	if ($[0] !== isControlled || $[1] !== onToggle) {
		t2 = () => {
			if (!isControlled) setIsExpandedInternal(_temp$37);
			onToggle?.();
		};
		$[0] = isControlled;
		$[1] = onToggle;
		$[2] = t2;
	} else t2 = $[2];
	const handleToggle = t2;
	let t3;
	if ($[3] !== children || $[4] !== embedded || $[5] !== footerButtons || $[6] !== handleToggle || $[7] !== headerButtons || $[8] !== isExpanded || $[9] !== previewContent || $[10] !== subtitle || $[11] !== title) {
		t3 = jsxs("div", {
			className: clsx(UserChoiceCard_module_default.card, embedded && UserChoiceCard_module_default.embedded),
			children: [!embedded && jsxs("div", {
				className: UserChoiceCard_module_default.header,
				children: [jsxs("div", {
					className: UserChoiceCard_module_default.headerText,
					children: [jsx("div", {
						className: UserChoiceCard_module_default.title,
						children: title
					}), subtitle ? jsx("div", {
						className: UserChoiceCard_module_default.subtitle,
						children: subtitle
					}) : null]
				}), jsxs("div", {
					className: UserChoiceCard_module_default.headerActions,
					children: [headerButtons, jsx("button", {
						type: "button",
						className: UserChoiceCard_module_default.collapseButton,
						onClick: handleToggle,
						"aria-label": isExpanded ? "Collapse" : "Expand",
						"aria-expanded": isExpanded,
						children: isExpanded ? jsx(DashIcon, { size: 16 }) : jsx(ChevronRightIcon, { size: 16 })
					})]
				})]
			}), isExpanded && jsxs("div", {
				className: UserChoiceCard_module_default.content,
				children: [
					previewContent ? jsx("div", {
						className: UserChoiceCard_module_default.previewContent,
						children: previewContent
					}) : null,
					children ? jsx("div", {
						className: UserChoiceCard_module_default.choices,
						children
					}) : null,
					footerButtons ? jsx("div", {
						className: UserChoiceCard_module_default.footerButtons,
						children: footerButtons
					}) : null
				]
			})]
		});
		$[3] = children;
		$[4] = embedded;
		$[5] = footerButtons;
		$[6] = handleToggle;
		$[7] = headerButtons;
		$[8] = isExpanded;
		$[9] = previewContent;
		$[10] = subtitle;
		$[11] = title;
		$[12] = t3;
	} else t3 = $[12];
	return t3;
}
UserChoiceCard.displayName = "UserChoiceCard";
function _temp$37(prev) {
	return !prev;
}
var ChoiceButton_module_default = {
	checkbox: "ChoiceButton-module_XXu_FG_checkbox",
	checkboxChecked: "ChoiceButton-module_XXu_FG_checkboxChecked",
	description: "ChoiceButton-module_XXu_FG_description",
	group: "ChoiceButton-module_XXu_FG_group",
	input: "ChoiceButton-module_XXu_FG_input",
	inputRow: "ChoiceButton-module_XXu_FG_inputRow",
	kbd: "ChoiceButton-module_XXu_FG_kbd",
	keybindingHint: "ChoiceButton-module_XXu_FG_keybindingHint",
	numberBadge: "ChoiceButton-module_XXu_FG_numberBadge",
	row: "ChoiceButton-module_XXu_FG_row",
	text: "ChoiceButton-module_XXu_FG_text",
	title: "ChoiceButton-module_XXu_FG_title"
};
/** A numbered choice row used in interactive prompts */
function ChoiceButton({ number, label, description, showCheckbox = false, checked = false, isRecommended = false, disabled = false, onClick, children }) {
	return /* @__PURE__ */ jsxs("button", {
		type: "button",
		className: clsx(ChoiceButton_module_default.row, isRecommended && ChoiceButton_module_default.recommended),
		onClick,
		disabled,
		"aria-pressed": showCheckbox ? checked : void 0,
		children: [
			/* @__PURE__ */ jsx(NumberBadge, { value: number }),
			showCheckbox && /* @__PURE__ */ jsx("span", {
				className: clsx(ChoiceButton_module_default.checkbox, checked && ChoiceButton_module_default.checkboxChecked),
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ jsx("div", {
				className: ChoiceButton_module_default.text,
				children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
					className: ChoiceButton_module_default.title,
					children: label
				}), description ? /* @__PURE__ */ jsx("div", {
					className: ChoiceButton_module_default.description,
					children: description
				}) : null] })
			}),
			isRecommended ? /* @__PURE__ */ jsx("span", {
				className: ChoiceButton_module_default.keybindingHint,
				children: /* @__PURE__ */ jsx("kbd", {
					className: ChoiceButton_module_default.kbd,
					children: "↵"
				})
			}) : null
		]
	});
}
/** Input variant of ChoiceButton — renders a text field instead of a label */
ChoiceButton.displayName = "ChoiceButton";
function ChoiceButtonInput({ number, placeholder, value, onChange, onSubmit, disabled = false }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(ChoiceButton_module_default.row, ChoiceButton_module_default.inputRow),
		children: [/* @__PURE__ */ jsx(NumberBadge, { value: number }), /* @__PURE__ */ jsx("input", {
			type: "text",
			className: ChoiceButton_module_default.input,
			placeholder,
			value,
			onChange: (e) => onChange(e.target.value),
			onKeyDown: (e) => {
				if (e.key === "Enter" && onSubmit) {
					e.preventDefault();
					onSubmit();
				}
			},
			disabled,
			autoFocus: true
		})]
	});
}
/** Container that wraps ChoiceButton rows in a flush bordered group */
ChoiceButtonInput.displayName = "ChoiceButtonInput";
function ChoiceButtonGroup({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: ChoiceButton_module_default.group,
		children
	});
}
ChoiceButtonGroup.displayName = "ChoiceButtonGroup";
function NumberBadge({ value }) {
	return /* @__PURE__ */ jsx("span", {
		className: ChoiceButton_module_default.numberBadge,
		children: value
	});
}
NumberBadge.displayName = "NumberBadge";
var ACTION_LABELS = {
	implement: "Approve plan and start work",
	autopilot: "Accept plan and build on autopilot",
	interactive: "Accept plan and build interactively",
	exit_only: "Exit plan mode and I will prompt myself",
	autopilot_fleet: "Accept plan and build on autopilot fleet"
};
var ACTION_DESCRIPTIONS = {
	implement: "Copilot will implement the plan end-to-end",
	autopilot: "Copilot will implement the plan autonomously",
	interactive: "Copilot will ask for confirmation at each step",
	exit_only: "You will take over and prompt Copilot yourself",
	autopilot_fleet: "Run plan across multiple agents in parallel"
};
var DEFAULT_ACTIONS = [
	"implement",
	"autopilot",
	"interactive",
	"exit_only"
];
/** Display a plan approval prompt with action choices and feedback input */
function PlanApprovalDisplay(t0) {
	const $ = c$1(26);
	const { summary, subtitle, planContent, actions: t1, recommendedAction, onAction, onFeedback, disabled: t2, embedded: t3, dialogOpen: controlledDialogOpen, onDialogClose } = t0;
	const actions = t1 === void 0 ? DEFAULT_ACTIONS : t1;
	const disabled = t2 === void 0 ? false : t2;
	const embedded = t3 === void 0 ? false : t3;
	const [feedbackValue, setFeedbackValue] = useState("");
	const [showFeedback, setShowFeedback] = useState(false);
	const [internalDialogOpen, setInternalDialogOpen] = useState(false);
	const effectiveRecommended = recommendedAction && actions.includes(recommendedAction) ? recommendedAction : actions[0];
	const isControlled = controlledDialogOpen !== void 0;
	const dialogOpen = isControlled ? controlledDialogOpen : internalDialogOpen;
	let t4;
	if ($[0] !== isControlled || $[1] !== onDialogClose) {
		t4 = () => {
			if (isControlled) onDialogClose?.();
			else setInternalDialogOpen(false);
		};
		$[0] = isControlled;
		$[1] = onDialogClose;
		$[2] = t4;
	} else t4 = $[2];
	const closeDialog = t4;
	let t5;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = () => setInternalDialogOpen(true);
		$[3] = t5;
	} else t5 = $[3];
	const openDialog = t5;
	let t6;
	if ($[4] !== feedbackValue || $[5] !== onFeedback) {
		t6 = () => {
			if (!onFeedback || !feedbackValue.trim()) return;
			onFeedback(feedbackValue.trim());
		};
		$[4] = feedbackValue;
		$[5] = onFeedback;
		$[6] = t6;
	} else t6 = $[6];
	const handleFeedback = t6;
	let t7;
	if ($[7] !== actions || $[8] !== closeDialog || $[9] !== dialogOpen || $[10] !== disabled || $[11] !== effectiveRecommended || $[12] !== embedded || $[13] !== feedbackValue || $[14] !== handleFeedback || $[15] !== onAction || $[16] !== onFeedback || $[17] !== planContent || $[18] !== showFeedback || $[19] !== subtitle || $[20] !== summary) {
		let t8;
		if ($[22] !== disabled || $[23] !== effectiveRecommended || $[24] !== onAction) {
			t8 = (action, i) => jsx(ChoiceButton, {
				number: i + 1,
				label: ACTION_LABELS[action] ?? action,
				description: ACTION_DESCRIPTIONS[action],
				isRecommended: action === effectiveRecommended,
				disabled,
				onClick: () => onAction?.(action)
			}, action);
			$[22] = disabled;
			$[23] = effectiveRecommended;
			$[24] = onAction;
			$[25] = t8;
		} else t8 = $[25];
		t7 = jsxs(Fragment$1, { children: [jsx(UserChoiceCard, {
			title: "Plan ready for review",
			subtitle,
			embedded,
			headerButtons: !embedded ? jsx(IconButton, {
				icon: ScreenFullIcon,
				"aria-label": "View full plan",
				size: "small",
				variant: "invisible",
				onClick: openDialog
			}) : void 0,
			previewContent: summary ? jsx(ScrollableSummary, { summary }) : void 0,
			children: jsxs(ChoiceButtonGroup, { children: [actions.map(t8), onFeedback && (showFeedback ? jsx(ChoiceButtonInput, {
				number: actions.length + 1,
				placeholder: "Suggest changes...",
				value: feedbackValue,
				onChange: setFeedbackValue,
				onSubmit: handleFeedback
			}) : jsx(ChoiceButton, {
				number: actions.length + 1,
				label: "Suggest changes",
				disabled,
				onClick: () => setShowFeedback(true)
			}))] })
		}), dialogOpen && jsx(PlanDialog, {
			planContent: planContent || summary || "",
			actions,
			effectiveRecommended,
			feedbackValue,
			showFeedback,
			onClose: closeDialog,
			onAction,
			onFeedback,
			onFeedbackChange: setFeedbackValue,
			onShowFeedback: () => setShowFeedback(true),
			onSubmitFeedback: handleFeedback
		})] });
		$[7] = actions;
		$[8] = closeDialog;
		$[9] = dialogOpen;
		$[10] = disabled;
		$[11] = effectiveRecommended;
		$[12] = embedded;
		$[13] = feedbackValue;
		$[14] = handleFeedback;
		$[15] = onAction;
		$[16] = onFeedback;
		$[17] = planContent;
		$[18] = showFeedback;
		$[19] = subtitle;
		$[20] = summary;
		$[21] = t7;
	} else t7 = $[21];
	return t7;
}
/** Scrollable plan summary with gradients indicating more content above/below */
PlanApprovalDisplay.displayName = "PlanApprovalDisplay";
function ScrollableSummary({ summary }) {
	const scrollRef = useRef(null);
	const [isScrolled, setIsScrolled] = useState(false);
	const [isScrolledToBottom, setIsScrolledToBottom] = useState(false);
	const [canScroll, setCanScroll] = useState(false);
	const checkScroll = useCallback(() => {
		const el = scrollRef.current;
		if (!el) return;
		setIsScrolled(el.scrollTop > 0);
		setCanScroll(el.scrollHeight > el.clientHeight);
		setIsScrolledToBottom(el.scrollTop + el.clientHeight >= el.scrollHeight - 1);
	}, []);
	useEffect(() => {
		checkScroll();
	}, [checkScroll]);
	return /* @__PURE__ */ jsxs("div", {
		ref: scrollRef,
		className: clsx(PlanApprovalDisplay_module_default.summaryContainer, isScrolled && PlanApprovalDisplay_module_default.scrolledTop),
		tabIndex: 0,
		role: "region",
		"aria-label": "Plan summary",
		onScroll: checkScroll,
		children: [
			canScroll && isScrolled ? /* @__PURE__ */ jsx("div", { className: PlanApprovalDisplay_module_default.summaryGradientTop }) : null,
			/* @__PURE__ */ jsx("div", {
				className: PlanApprovalDisplay_module_default.summary,
				children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: summary })
			}),
			canScroll && !isScrolledToBottom ? /* @__PURE__ */ jsx("div", { className: PlanApprovalDisplay_module_default.summaryGradient }) : null
		]
	});
}
ScrollableSummary.displayName = "ScrollableSummary";
function PlanDialog({ planContent, actions, effectiveRecommended, feedbackValue, showFeedback, onClose, onAction, onFeedback, onFeedbackChange, onShowFeedback, onSubmitFeedback }) {
	const contentRef = useRef(null);
	const [showChoices, setShowChoices] = useState(true);
	useEffect(() => {
		const el = contentRef.current;
		if (!el) return;
		setShowChoices(el.scrollHeight <= el.clientHeight * 2);
	}, []);
	return /* @__PURE__ */ jsxs(Dialog, {
		onClose,
		title: "Plan",
		width: "xlarge",
		style: { maxWidth: "min(960px, 90vw)" },
		children: [/* @__PURE__ */ jsx("div", {
			ref: contentRef,
			className: PlanApprovalDisplay_module_default.dialogContent,
			children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: planContent })
		}), showChoices ? /* @__PURE__ */ jsx("div", {
			className: PlanApprovalDisplay_module_default.dialogActions,
			children: /* @__PURE__ */ jsxs(ChoiceButtonGroup, { children: [actions.map((action, i) => /* @__PURE__ */ jsx(ChoiceButton, {
				number: i + 1,
				label: ACTION_LABELS[action] ?? action,
				description: ACTION_DESCRIPTIONS[action],
				isRecommended: action === effectiveRecommended,
				onClick: () => onAction?.(action)
			}, action)), onFeedback && (showFeedback ? /* @__PURE__ */ jsx(ChoiceButtonInput, {
				number: actions.length + 1,
				placeholder: "Suggest changes...",
				value: feedbackValue,
				onChange: onFeedbackChange,
				onSubmit: onSubmitFeedback
			}) : /* @__PURE__ */ jsx(ChoiceButton, {
				number: actions.length + 1,
				label: "Suggest changes",
				onClick: onShowFeedback
			}))] })
		}) : null]
	});
}
PlanDialog.displayName = "PlanDialog";
var ResolvedPlanStatus_module_default = { container: "ResolvedPlanStatus-module_kr8F0W_container" };
/** Simple status line shown when a plan has been approved */
function ResolvedPlanStatus() {
	return /* @__PURE__ */ jsxs("span", {
		className: ResolvedPlanStatus_module_default.container,
		children: [/* @__PURE__ */ jsx(CheckIcon, { size: 16 }), "Plan approved"]
	});
}
ResolvedPlanStatus.displayName = "ResolvedPlanStatus";
/**
* Regex pattern matching agent-internal PR metadata tags that should not be displayed to users.
*
* These tags are part of the structured output format used by the agent runtime:
* - `<pr_title>` / `<pr_description>`: structured PR metadata produced by the LLM
* - `<response_structure>`: prompt envelope that models sometimes echo back
* - `<empty>`: sentinel token meaning "no PR update needed"
*/
var PR_METADATA_TAG_PATTERN = /<pr_title>|<pr_description>|<response_structure>|<empty>/i;
/**
* Returns true if the content contains agent-internal PR metadata tags
* that should be excluded from user-facing displays.
*/
function hasPrMetadataTags(content) {
	return PR_METADATA_TAG_PATTERN.test(content);
}
/**
* Strips agent-internal PR metadata tags and their contents from a string.
* Returns the remaining text (trimmed), which may be empty if the entire
* content was metadata.
*/
function stripPrMetadataTags(content) {
	return content.replace(/<pr_title>.*?<\/pr_title>|<pr_description>.*?<\/pr_description>|<empty>/gs, "").replace(/<response_structure>.*?<\/response_structure>/gs, "").trim();
}
/**
* Well-known tool names that the agent can use.
* This is the single source of truth for all tool names used throughout the agent-sessions package.
*
* These include:
* - Standard SWE-agent tools (bash, edit, view, etc.)
* - Deprecated/legacy tools (kept for backwards compatibility with old sessions)
* - Custom MCP tools (handled via the string union in ToolName type)
*/
var TOOL_NAMES = {
	APPLY_PATCH: "apply_patch",
	STR_REPLACE_EDITOR: "str_replace_editor",
	STR_REPLACE: "str_replace",
	EDIT: "edit",
	CREATE: "create",
	VIEW: "view",
	INSERT: "insert",
	UNDO_EDIT: "undo_edit",
	BASH: "bash",
	WRITE_BASH: "write_bash",
	READ_BASH: "read_bash",
	STOP_BASH: "stop_bash",
	LIST_BASH: "list_bash",
	ASYNC_BASH: "async_bash",
	READ_ASYNC_BASH: "read_async_bash",
	STOP_ASYNC_BASH: "stop_async_bash",
	POWERSHELL: "powershell",
	WRITE_POWERSHELL: "write_powershell",
	READ_POWERSHELL: "read_powershell",
	STOP_POWERSHELL: "stop_powershell",
	LIST_POWERSHELL: "list_powershell",
	GREP: "grep",
	RG: "rg",
	GLOB: "glob",
	SEARCH_CODE_SUBAGENT: "search_code_subagent",
	WEB_SEARCH: "web_search",
	GITHUB_MCP_SERVER_WEB_SEARCH: "github-mcp-server-web_search",
	GITHUB_MCP_SERVER_BING_SEARCH: "github-mcp-server-bing_search",
	WEB_FETCH: "web_fetch",
	CREATE_PULL_REQUEST: "create_pull_request",
	COMMIT_CHANGES: "commit_changes",
	CODE_REVIEW: "code_review",
	CODEQL_CHECKER: "codeql_checker",
	PARALLEL_VALIDATION: "parallel_validation",
	RUN_CUSTOM_SETUP_STEP: "run_custom_setup_step",
	RUN_SETUP: "run_setup",
	THINK: "think",
	SKILL: "skill",
	REPORT_PROGRESS: "report_progress",
	REPLY_TO_COMMENT: "reply_to_comment",
	PROPOSE_WORK: "propose_work",
	TASK: "task",
	STORE_MEMORY: "store_memory"
};
/**
* Bash/terminal tools. These should not be grouped together, which is why they don't have group titles.
*/
var BASH_TOOLS = [
	TOOL_NAMES.BASH,
	TOOL_NAMES.WRITE_BASH,
	TOOL_NAMES.READ_BASH,
	TOOL_NAMES.STOP_BASH,
	TOOL_NAMES.LIST_BASH,
	TOOL_NAMES.ASYNC_BASH,
	TOOL_NAMES.READ_ASYNC_BASH,
	TOOL_NAMES.STOP_ASYNC_BASH
];
/**
* PowerShell tools. These should not be grouped together, which is why they don't have group titles.
* They behave the same as bash tools.
*/
var POWERSHELL_TOOLS = [
	TOOL_NAMES.POWERSHELL,
	TOOL_NAMES.WRITE_POWERSHELL,
	TOOL_NAMES.READ_POWERSHELL,
	TOOL_NAMES.STOP_POWERSHELL,
	TOOL_NAMES.LIST_POWERSHELL
];
/**
* All shell-related tools (Bash + PowerShell). Used for grouping logic.
*/
var SHELL_TOOLS = [...BASH_TOOLS, ...POWERSHELL_TOOLS];
/**
* Setup tools. These should be grouped together regardless of specific tool name.
*/
var SETUP_TOOLS = [TOOL_NAMES.RUN_CUSTOM_SETUP_STEP, TOOL_NAMES.RUN_SETUP];
/**
* Edit tools. These are tools that modify files and should show DiffPreviews expanded when in a group.
*/
var EDIT_TOOLS = [
	TOOL_NAMES.STR_REPLACE_EDITOR,
	TOOL_NAMES.STR_REPLACE,
	TOOL_NAMES.EDIT,
	TOOL_NAMES.APPLY_PATCH
];
var TOOL_GROUP_DISPLAY_CONFIG = {
	[TOOL_NAMES.APPLY_PATCH]: {
		getTitle: (count) => `Apply ${count} patches`,
		iconToolName: TOOL_NAMES.APPLY_PATCH
	},
	[TOOL_NAMES.STR_REPLACE_EDITOR]: {
		getTitle: (count) => `Edit ${count} files`,
		iconToolName: TOOL_NAMES.EDIT
	},
	[TOOL_NAMES.STR_REPLACE]: {
		getTitle: (count) => `Edit ${count} files`,
		iconToolName: TOOL_NAMES.EDIT
	},
	[TOOL_NAMES.EDIT]: {
		getTitle: (count) => `Edit ${count} files`,
		iconToolName: TOOL_NAMES.EDIT
	},
	[TOOL_NAMES.CREATE]: {
		getTitle: (count) => `Create ${count} files`,
		iconToolName: TOOL_NAMES.CREATE
	},
	[TOOL_NAMES.VIEW]: {
		getTitle: (count) => `View ${count} files`,
		iconToolName: TOOL_NAMES.VIEW
	},
	[TOOL_NAMES.INSERT]: {
		getTitle: (count) => `Insert at ${count} locations`,
		iconToolName: TOOL_NAMES.INSERT
	},
	[TOOL_NAMES.UNDO_EDIT]: {
		getTitle: (count) => `Undo ${count} edits`,
		iconToolName: TOOL_NAMES.UNDO_EDIT
	},
	[TOOL_NAMES.GREP]: {
		getTitle: (count) => `Search ${count} times`,
		iconToolName: TOOL_NAMES.GREP
	},
	[TOOL_NAMES.RG]: {
		getTitle: (count) => `Search ${count} times`,
		iconToolName: TOOL_NAMES.GREP
	},
	[TOOL_NAMES.GLOB]: {
		getTitle: () => "Find files",
		iconToolName: TOOL_NAMES.GLOB
	},
	[TOOL_NAMES.SEARCH_CODE_SUBAGENT]: {
		getTitle: (count) => `Search code ${count} times`,
		iconToolName: TOOL_NAMES.SEARCH_CODE_SUBAGENT
	},
	[TOOL_NAMES.WEB_SEARCH]: {
		getTitle: (count) => `Web search ${count} times`,
		iconToolName: TOOL_NAMES.GREP
	},
	[TOOL_NAMES.GITHUB_MCP_SERVER_WEB_SEARCH]: {
		getTitle: (count) => `Web search ${count} times`,
		iconToolName: TOOL_NAMES.GREP
	},
	[TOOL_NAMES.GITHUB_MCP_SERVER_BING_SEARCH]: {
		getTitle: (count) => `Web search ${count} times`,
		iconToolName: TOOL_NAMES.GREP
	},
	[TOOL_NAMES.WEB_FETCH]: {
		getTitle: (count) => `Fetch ${count} URLs`,
		iconToolName: TOOL_NAMES.WEB_FETCH
	},
	[TOOL_NAMES.COMMIT_CHANGES]: {
		getTitle: (count) => `Commit ${count} changes`,
		iconToolName: TOOL_NAMES.COMMIT_CHANGES
	},
	[TOOL_NAMES.CODE_REVIEW]: {
		getTitle: (count) => `Review ${count} changes`,
		iconToolName: TOOL_NAMES.CODE_REVIEW
	},
	[TOOL_NAMES.PARALLEL_VALIDATION]: {
		getTitle: () => "Check changes with Copilot code review and CodeQL",
		iconToolName: TOOL_NAMES.PARALLEL_VALIDATION
	},
	[TOOL_NAMES.RUN_CUSTOM_SETUP_STEP]: {
		getTitle: () => "Setting up environment",
		iconToolName: TOOL_NAMES.RUN_SETUP
	},
	[TOOL_NAMES.RUN_SETUP]: {
		getTitle: () => "Setting up environment",
		iconToolName: TOOL_NAMES.RUN_SETUP
	},
	[TOOL_NAMES.THINK]: {
		getTitle: (count) => `Thought ${count} times`,
		iconToolName: TOOL_NAMES.THINK
	},
	[TOOL_NAMES.SKILL]: {
		getTitle: (count) => `Activate ${count} skills`,
		iconToolName: TOOL_NAMES.SKILL
	},
	[TOOL_NAMES.REPORT_PROGRESS]: {
		getTitle: (count) => `${count} progress updates`,
		iconToolName: TOOL_NAMES.REPORT_PROGRESS
	},
	[TOOL_NAMES.REPLY_TO_COMMENT]: {
		getTitle: (count) => `Reply to ${count} comments`,
		iconToolName: TOOL_NAMES.REPLY_TO_COMMENT
	},
	[TOOL_NAMES.PROPOSE_WORK]: {
		getTitle: () => "Propose Work",
		iconToolName: TOOL_NAMES.PROPOSE_WORK
	},
	[TOOL_NAMES.TASK]: {
		getTitle: (count) => `Run ${count} subagent tasks`,
		iconToolName: TOOL_NAMES.TASK
	},
	[TOOL_NAMES.STORE_MEMORY]: {
		getTitle: () => "Store memory",
		iconToolName: TOOL_NAMES.STORE_MEMORY
	}
};
/**
* Marker patterns for subagent sessions
* Supports both legacy "custom agent" and current "subagent" formats for backward compatibility
*/
var AGENT_START_MARKERS = ["▶️ Begin subagent", "▶️ Begin custom agent"];
var AGENT_END_MARKERS = ["⏹️ End subagent", "⏹️ End custom agent"];
function isCustomAgentSessionGroup(entry) {
	return typeof entry === "object" && entry !== null && "agentId" in entry && "logs" in entry;
}
/**
* Groups log entries by agentId, creating nested structures for subagent sessions.
* This does NOT refer to the top-level Session — it groups logs from subagents
* that run within a parent session.
*
* SIMPLIFIED STRATEGY:
* 1. Pre-scan for originating task tool calls to extract descriptions.
* 2. Single pass through logs.
* 3. If a log has an agentId, route it to an active subagent session group.
* 4. If the group doesn't exist yet, create it and add it to the results immediately.
* 5. Interleaved logs (A, B, A) are handled automatically by the Map reference.
*
* The originating tool call (task("...")) stays in the log stream as a separate entry.
* The group represents the execution results of that task.
*/
function groupCustomAgentLogs(logs) {
	const result = [];
	const taskDescriptions = buildTaskDescriptionMap(logs);
	const activeSubagentSessions = /* @__PURE__ */ new Map();
	for (const log of logs) {
		const agentId = getCustomAgentId(log);
		if (!agentId) {
			result.push(log);
			continue;
		}
		let subagentSession = activeSubagentSessions.get(agentId);
		if (!subagentSession) {
			const taskInfo = taskDescriptions.get(agentId);
			subagentSession = {
				agentId,
				startMessage: null,
				endMessage: null,
				logs: [],
				isPending: true,
				description: taskInfo?.description,
				agentType: taskInfo?.agentType,
				prompt: taskInfo?.prompt
			};
			activeSubagentSessions.set(agentId, subagentSession);
			result.push(subagentSession);
		}
		if (isCustomAgentStartMarker(log)) subagentSession.startMessage = log;
		else if (isCustomAgentEndMarker(log)) {
			subagentSession.endMessage = log;
			subagentSession.isPending = false;
			activeSubagentSessions.delete(agentId);
		} else subagentSession.logs.push(log);
	}
	return reorderGroupsByOriginatingToolCall(result.filter((entry) => {
		if (isCustomAgentSessionGroup(entry) && !entry.isPending && entry.logs.length === 0) return false;
		return true;
	}));
}
/**
* Reorders subagent groups to appear immediately after their originating tool call.
*
* Without this, groups appear in log-arrival order (whichever subagent's first log
* chunk arrives from the server first). This is wrong when a slow subagent (e.g.
* implementation) is invoked before fast ones (e.g. testing) — the slow one's group
* would appear last even though it was invoked first.
*
* The originating tool call is a non-grouped CompletionChunk whose tool_calls[].id
* matches a subagent group's agentId.
*/
function reorderGroupsByOriginatingToolCall(entries) {
	const groupsByAgentId = /* @__PURE__ */ new Map();
	for (const entry of entries) if (isCustomAgentSessionGroup(entry)) groupsByAgentId.set(entry.agentId, entry);
	if (groupsByAgentId.size === 0) return entries;
	const placedGroupIds = /* @__PURE__ */ new Set();
	const reordered = [];
	for (const entry of entries) {
		if (isCustomAgentSessionGroup(entry)) continue;
		reordered.push(entry);
		if (!isCompletionChunk(entry)) continue;
		for (const choice of entry.choices) {
			const toolCalls = choice.delta?.tool_calls ?? [];
			for (const toolCall of toolCalls) {
				const toolCallId = toolCall?.id;
				if (toolCallId && !placedGroupIds.has(toolCallId) && groupsByAgentId.has(toolCallId)) {
					const group = groupsByAgentId.get(toolCallId);
					if (group) {
						reordered.push(group);
						placedGroupIds.add(toolCallId);
					}
				}
			}
		}
	}
	for (const entry of entries) if (isCustomAgentSessionGroup(entry) && !placedGroupIds.has(entry.agentId)) reordered.push(entry);
	return reordered;
}
/**
* Extracts the agentId from a log entry if present
*/
function getCustomAgentId(log) {
	if (typeof log === "object" && log !== null && "agentId" in log) {
		const { agentId } = log;
		return typeof agentId === "string" ? agentId : null;
	}
	return null;
}
/**
* Builds a map of toolCallId -> {agentType, description} from originating task tool calls.
* An originating task tool call is a CompletionChunk with no agentId that calls the 'task' tool.
* The tool call's id becomes the agentId of the resulting subagent group.
*/
function buildTaskDescriptionMap(logs) {
	const map = /* @__PURE__ */ new Map();
	for (const log of logs) {
		if (getCustomAgentId(log) !== null) continue;
		if (!isCompletionChunk(log)) continue;
		const choices = log.choices ?? [];
		for (const choice of choices) for (const toolCall of choice?.delta?.tool_calls ?? []) {
			if (!toolCall?.function) continue;
			if (toolCall.function.name !== TOOL_NAMES.TASK) continue;
			const toolCallId = toolCall.id;
			if (!toolCallId) continue;
			try {
				const args = JSON.parse(toolCall.function.arguments ?? "");
				const agentType = typeof args.agent_type === "string" ? args.agent_type : void 0;
				const description = (typeof args.description === "string" ? args.description : void 0) ?? (typeof args.name === "string" ? args.name : void 0);
				const prompt = typeof args.prompt === "string" ? args.prompt : void 0;
				if (agentType || description || prompt) map.set(toolCallId, {
					agentType,
					description,
					prompt
				});
			} catch {}
		}
	}
	return map;
}
/**
* Formats a descriptive title for a subagent session group.
* Uses the description from the originating task tool call when available,
* falling back to the agent name from the start marker.
*
* Examples:
*   - "Explore: Find database migrations"
*   - "Task: Run unit tests"
*   - "Subagent: joker" (fallback when no description)
*/
function formatAgentTitle(group) {
	if (group.description) return `${group.agentType ? capitalizeFirst(group.agentType) : "Subagent"}: ${group.description}`;
	return `Subagent: ${extractAgentName(group.startMessage)}`;
}
function capitalizeFirst(str) {
	return str.charAt(0).toUpperCase() + str.slice(1);
}
/**
* Extracts the parsed name argument from a run_setup tool call, or null if the log
* is not a valid run_setup completion chunk with a parseable name.
*/
function getRunSetupName(log) {
	if (!isCompletionChunk(log)) return null;
	const toolCall = log.choices?.[0]?.delta?.tool_calls?.[0];
	if (!toolCall?.function || toolCall.function.name !== TOOL_NAMES.RUN_SETUP) return null;
	try {
		const args = JSON.parse(toolCall.function.arguments ?? "");
		return typeof args.name === "string" ? args.name : null;
	} catch {
		return null;
	}
}
/**
* Checks if a log entry is a subagent session start marker
*/
function isCustomAgentStartMarker(log) {
	const name = getRunSetupName(log);
	return name !== null && AGENT_START_MARKERS.some((marker) => name.includes(marker));
}
/**
* Checks if a log entry is a subagent session end marker
*/
function isCustomAgentEndMarker(log) {
	const name = getRunSetupName(log);
	return name !== null && AGENT_END_MARKERS.some((marker) => name.includes(marker));
}
/**
* Extracts the agent name from the start marker tool call.
* Shared with CustomAgentSessionGroup component.
* Supports both legacy "custom agent" and current "subagent" formats.
*/
function extractAgentName(startMessage) {
	if (!startMessage) return "Subagent";
	try {
		const toolCall = startMessage.choices?.[0]?.delta?.tool_calls?.[0];
		if (!toolCall?.function?.arguments) return "Subagent";
		const name = JSON.parse(toolCall.function.arguments).name || "";
		const match = name.match(/^▶️ Begin (?:subagent|custom agent):\s*(.+)$/i);
		if (match) return match[1].trim();
		return name || "Subagent";
	} catch {
		return "Subagent";
	}
}
var CCA_PLAN_ACTIONS = ["implement", "exit_only"];
function CopilotFinalPlanMessage(t0) {
	const $ = c$1(12);
	const { logsPollingInterval, onApprove, onFeedback, isResolved: t1 } = t0;
	const isResolved = t1 === void 0 ? false : t1;
	const { currentUserIsSessionOwner } = useCurrentUser$1();
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = isFeatureEnabled("copilot_mission_control_rich_plan_ui");
		$[0] = t2;
	} else t2 = $[0];
	const richPlanUIEnabled = t2;
	let t3;
	if ($[1] !== currentUserIsSessionOwner || $[2] !== logsPollingInterval) {
		t3 = {
			logsPollingInterval,
			batchCompletedSessions: true,
			currentUserIsSessionOwner
		};
		$[1] = currentUserIsSessionOwner;
		$[2] = logsPollingInterval;
		$[3] = t3;
	} else t3 = $[3];
	const { data: logsData, isLoading: logsIsLoading, error: logsError } = useLogs(t3);
	let t4;
	let t5;
	if ($[4] !== isResolved || $[5] !== logsData || $[6] !== logsError || $[7] !== logsIsLoading || $[8] !== onApprove || $[9] !== onFeedback) {
		t5 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const stopMessages = extractStopMessages(logsData);
			if (logsIsLoading) {
				t5 = jsx(CopilotMessageLoading, {});
				break bb0;
			}
			if (logsError || stopMessages.length === 0) {
				t5 = null;
				break bb0;
			}
			const combinedSummary = stopMessages.map(_temp$36).join("\n\n");
			if (!richPlanUIEnabled) {
				t5 = jsx(CopilotMessageContainer, { children: stopMessages.map(_temp2$13) });
				break bb0;
			}
			if (isResolved) {
				t5 = jsx(ResolvedPlanStatus, {});
				break bb0;
			}
			t4 = jsx(PlanApprovalDisplay, {
				summary: combinedSummary,
				planContent: combinedSummary,
				actions: CCA_PLAN_ACTIONS,
				recommendedAction: "implement",
				onAction: (action) => onApprove?.(action, combinedSummary),
				onFeedback
			});
		}
		$[4] = isResolved;
		$[5] = logsData;
		$[6] = logsError;
		$[7] = logsIsLoading;
		$[8] = onApprove;
		$[9] = onFeedback;
		$[10] = t4;
		$[11] = t5;
	} else {
		t4 = $[10];
		t5 = $[11];
	}
	if (t5 !== Symbol.for("react.early_return_sentinel")) return t5;
	return t4;
}
/**
* Extracts assistant stop messages from log entries, excluding PR metadata.
* Usually there is only one that isn't a PR description. This ensures we don't lose any messages if there are multiple stop entries.
*/
CopilotFinalPlanMessage.displayName = "CopilotFinalPlanMessage";
function _temp2$13(message, index) {
	return jsx(CopilotMessageBubble, {
		markdown: message.content,
		showAvatar: index === 0
	}, message.id);
}
function _temp$36(m) {
	return m.content;
}
function extractStopMessages(logsData = []) {
	const messages = [];
	for (const logEntry of logsData) {
		if (!isCompletionChunk(logEntry)) continue;
		if (getCustomAgentId(logEntry)) continue;
		const choice = logEntry.choices[0];
		if (choice?.finish_reason === "stop" && choice.delta.role === "assistant" && choice.delta.content && !choice.delta.tool_calls && !hasPrMetadataTags(choice.delta.content)) {
			const content = choice.delta.content.trim();
			if (content) messages.push({
				id: logEntry.id,
				content
			});
		}
	}
	return messages;
}
var CopilotInitialMessage_module_default = {
	container: "CopilotInitialMessage-module_JFt1sq_container",
	message: "CopilotInitialMessage-module_JFt1sq_message"
};
var CopilotInitialMessage = (t0) => {
	const $ = c$1(4);
	const { message, session } = t0;
	const { data: agentInfo, isLoading: isAgentInfoLoading } = useAgentInfo(session.agent_id);
	const { isChatSession } = useIntentDetection(session);
	const agentDisplayName = agentInfo?.display_name ?? "Agent";
	if (isAgentInfoLoading) return null;
	if (isChatSession) return null;
	let t1;
	if ($[0] !== agentDisplayName || $[1] !== message || $[2] !== session.agent_id) {
		t1 = jsxs("div", {
			className: CopilotInitialMessage_module_default.container,
			children: [jsx(AgentAvatar, {
				size: 32,
				animationType: "static",
				loopAnimation: false,
				agentId: session.agent_id
			}), jsx("p", {
				className: CopilotInitialMessage_module_default.message,
				children: `${agentDisplayName} ${message}`
			})]
		});
		$[0] = agentDisplayName;
		$[1] = message;
		$[2] = session.agent_id;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
CopilotInitialMessage.displayName = "CopilotInitialMessage";
var UserInitialMessage_module_default = {
	agentMentionText: "UserInitialMessage-module_u_YLpa_agentMentionText",
	avatarContainer: "UserInitialMessage-module_u_YLpa_avatarContainer",
	container: "UserInitialMessage-module_u_YLpa_container",
	messageBubble: "UserInitialMessage-module_u_YLpa_messageBubble",
	meta: "UserInitialMessage-module_u_YLpa_meta",
	metaSmall: "UserInitialMessage-module_u_YLpa_metaSmall"
};
var ExpandableMarkdown_module_default = {
	content: "ExpandableMarkdown-module_5JJFlq_content",
	expanded: "ExpandableMarkdown-module_5JJFlq_expanded",
	overflowing: "ExpandableMarkdown-module_5JJFlq_overflowing",
	toggle: "ExpandableMarkdown-module_5JJFlq_toggle"
};
function ExpandableMarkdown({ markdown, className, extensions, maxHeight = 500 }) {
	const contentRef = useRef(null);
	const [isOverflowing, setIsOverflowing] = useState(false);
	const [isExpanded, setIsExpanded] = useState(false);
	useEffect(() => {
		const node = contentRef.current;
		if (!node) return;
		const checkOverflow = () => {
			setIsOverflowing(node.scrollHeight > maxHeight);
		};
		checkOverflow();
		const resizeObserver = new ResizeObserver(() => checkOverflow());
		resizeObserver.observe(node);
		const mutationObserver = new MutationObserver(() => checkOverflow());
		mutationObserver.observe(node, {
			childList: true,
			subtree: true,
			characterData: true
		});
		return () => {
			resizeObserver.disconnect();
			mutationObserver.disconnect();
		};
	}, [markdown, maxHeight]);
	const handleToggle = () => {
		setIsExpanded((e) => !e);
	};
	return /* @__PURE__ */ jsxs("div", {
		style: { "--max-height": `${maxHeight}px` },
		children: [/* @__PURE__ */ jsx("div", {
			ref: contentRef,
			className: clsx(isOverflowing && ExpandableMarkdown_module_default.overflowing, isExpanded && ExpandableMarkdown_module_default.expanded),
			inert: isOverflowing && !isExpanded,
			children: /* @__PURE__ */ jsx(MarkdownRenderer, {
				markdown,
				className: clsx(ExpandableMarkdown_module_default.content, className),
				extensions
			})
		}), isOverflowing && /* @__PURE__ */ jsx(ButtonComponent$1, {
			variant: "invisible",
			size: "small",
			onClick: handleToggle,
			className: ExpandableMarkdown_module_default.toggle,
			children: isExpanded ? "Show less" : "Show more"
		})]
	});
}
ExpandableMarkdown.displayName = "ExpandableMarkdown";
/**
* Regex pattern to match agent mentions in the format @agent-name[agent] or @copilot
*/
var AGENT_MENTION_REGEX = /(@[a-zA-Z0-9_-]+\[agent\]|@copilot)/gi;
/**
* Checks if a mention matches the current agent
* @param mentionText The full mention text (e.g., "@copilot" or "@agent-name[agent]")
* @param agentInfo The current agent information
* @returns Information about the mention match
*/
function matchAgentMention(mentionText, agentInfo) {
	const lowerMention = mentionText.toLowerCase();
	if (lowerMention === "@copilot") return {
		mentionText,
		isCurrentAgent: agentInfo?.display_name?.toLowerCase() === "copilot",
		type: "copilot"
	};
	if (lowerMention.endsWith("[agent]")) {
		const mentionedAgent = mentionText.slice(1, -7).toLowerCase();
		if (agentInfo?.display_name) return {
			mentionText,
			isCurrentAgent: mentionedAgent === agentInfo.display_name.toLowerCase().replace(/\s+/g, "-"),
			type: "agent"
		};
		return {
			mentionText,
			isCurrentAgent: false,
			type: "agent"
		};
	}
	return {
		mentionText,
		isCurrentAgent: false,
		type: "unknown"
	};
}
var createMarkdownWithAgentLinks = (body, agentInfo) => {
	return body.replace(AGENT_MENTION_REGEX, (match) => {
		const mentionMatch = matchAgentMention(match, agentInfo);
		if (mentionMatch.isCurrentAgent) {
			if (mentionMatch.type === "copilot") return `[${match}](https://gh.io/copilot-coding-agent-docs)`;
			else if (mentionMatch.type === "agent" && agentInfo) return `[${match}](${agentInfo.doc_url})`;
		}
		return match;
	});
};
var mobileEventTypes = [
	"ios_mobile_mission_control",
	"android_mobile_mission_control",
	"ios_mobile_repo_profile",
	"android_mobile_repo_profile"
];
function getDisplayName(isCurrentUserTheCreator, sessionOwner) {
	if (isCurrentUserTheCreator) return "You";
	if (sessionOwner?.login) return sessionOwner.login;
	return "User";
}
function getAvatarUrl(sessionOwner) {
	if (sessionOwner?.primaryAvatarUrl) return sessionOwner.primaryAvatarUrl;
	if (sessionOwner?.login) return `https://avatars.githubusercontent.com/${sessionOwner.login}`;
	return "https://avatars.githubusercontent.com/ghost";
}
var UserInitialMessage = (t0) => {
	const $ = c$1(10);
	const { currentUser, sessionOwner, threadId, session, message, agentId } = t0;
	const { data: agentInfo } = useAgentInfo(agentId);
	let t1;
	if ($[0] !== session.id || $[1] !== session.resource_global_id || $[2] !== threadId) {
		t1 = (linkText, url, article) => {
			return jsxs(Fragment$1, { children: [article ? ` from ${article} ` : " from ", url ? jsx(Link, {
				href: url,
				inline: true,
				onClick: () => {
					sendEvent("agent_sessions.task_view", {
						target: "VIEW_SESSION_LINK",
						session_id: session.id,
						task_id: session.resource_global_id,
						thread_id: threadId
					});
				},
				children: linkText
			}) : jsx("span", { children: linkText })] });
		};
		$[0] = session.id;
		$[1] = session.resource_global_id;
		$[2] = threadId;
		$[3] = t1;
	} else t1 = $[3];
	const generateOrigin = t1;
	let t2;
	if ($[4] !== generateOrigin || $[5] !== session.event_identifiers || $[6] !== session.event_type || $[7] !== session.event_url || $[8] !== threadId) {
		t2 = () => {
			const type = session.event_type;
			const identifiers = session.event_identifiers;
			const url_0 = session.event_url;
			if (threadId) return generateOrigin("conversation", `${window.location.origin}/copilot/c/${threadId}`, "a");
			if (!type) return null;
			if (type === "fix_failed_workflow") return generateOrigin("GitHub Actions", url_0);
			else if (type === "issues_agent_assignment") {
				const issueNumber = identifiers?.find(_temp$35)?.split("::")[1];
				if (!issueNumber) return generateOrigin("issue", url_0, "an");
				return generateOrigin(`issue #${issueNumber}`, url_0);
			} else if (type === "linear_webhook") return generateOrigin("Linear", url_0);
			else if (type === "jira_issue") return generateOrigin("Jira", url_0);
			else if (mobileEventTypes.includes(type)) return generateOrigin("GitHub Mobile");
			return null;
		};
		$[4] = generateOrigin;
		$[5] = session.event_identifiers;
		$[6] = session.event_type;
		$[7] = session.event_url;
		$[8] = threadId;
		$[9] = t2;
	} else t2 = $[9];
	const eventInformation = t2;
	const content = session.event_content;
	const displayName = getDisplayName(currentUser?.id === session.user_id, sessionOwner);
	const avatarUrl = getAvatarUrl(sessionOwner);
	const { isChatSession } = useIntentDetection(session);
	return jsxs("div", {
		className: UserInitialMessage_module_default.container,
		children: [jsxs("div", {
			className: UserInitialMessage_module_default.messageBubble,
			children: [!isChatSession && jsxs("p", {
				className: clsx(UserInitialMessage_module_default.meta, { [UserInitialMessage_module_default.metaSmall]: !!content }),
				children: [
					jsx("span", { children: displayName }),
					" ",
					message,
					eventInformation()
				]
			}), content && jsx(ExpandableMarkdown, {
				className: UserInitialMessage_module_default.agentMentionText,
				markdown: agentInfo ? createMarkdownWithAgentLinks(content, agentInfo) : content
			})]
		}), jsx("div", {
			className: UserInitialMessage_module_default.avatarContainer,
			children: jsx(GitHubAvatar, {
				src: avatarUrl,
				size: 24
			})
		})]
	});
};
UserInitialMessage.displayName = "UserInitialMessage";
function _temp$35(id) {
	return id.startsWith("issue::");
}
function useListCommands(t0) {
	const $ = c$1(25);
	const { pollingInterval } = t0;
	const { session } = useSessionContext();
	const activeSessionId = session.id;
	const queryClient = useQueryClient();
	let t1;
	if ($[0] !== activeSessionId) {
		t1 = ["agent-session-commands", activeSessionId];
		$[0] = activeSessionId;
		$[1] = t1;
	} else t1 = $[1];
	const queryKey = t1;
	let t2;
	if ($[2] !== activeSessionId || $[3] !== queryClient) {
		t2 = (payload) => {
			if (payload?.session_id && payload.session_id !== activeSessionId) return;
			queryClient.invalidateQueries({ queryKey: ["agent-session-commands", activeSessionId] });
		};
		$[2] = activeSessionId;
		$[3] = queryClient;
		$[4] = t2;
	} else t2 = $[4];
	const handleAliveUpdate = t2;
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { maxWait: 5e3 };
		$[5] = t3;
	} else t3 = $[5];
	const debouncedHandleAliveUpdate = useDebounce(handleAliveUpdate, pollingInterval, t3);
	let t4;
	if ($[6] !== debouncedHandleAliveUpdate) {
		t4 = {
			onEvent: debouncedHandleAliveUpdate,
			enableCreateEvents: false,
			enableUpdateEvents: true,
			enableLogUpdates: true
		};
		$[6] = debouncedHandleAliveUpdate;
		$[7] = t4;
	} else t4 = $[7];
	const { isConnected: aliveIsConnected } = useAgentSessionsAlive(t4);
	const shouldPoll = !aliveIsConnected && (session.state === "in_progress" || session.state === "queued") ? pollingInterval : false;
	let t5;
	if ($[8] !== activeSessionId || $[9] !== queryClient) {
		t5 = async (t6) => {
			const { queryKey: currentQueryKey } = t6;
			const result = await fetchCAPI({
				path: `/agents/sessions/${activeSessionId}/commands?sort=created_at,asc`,
				method: "GET"
			});
			if (!result.ok) throw new Error(`Failed to fetch commands: ${result.statusText}`);
			const serverData = await result.json();
			const currentData = queryClient.getQueryData(currentQueryKey);
			if (currentData) {
				const optimisticCommands = currentData.commands.filter(_temp$34);
				return { commands: [...serverData.commands, ...optimisticCommands] };
			}
			return serverData;
		};
		$[8] = activeSessionId;
		$[9] = queryClient;
		$[10] = t5;
	} else t5 = $[10];
	let t6;
	if ($[11] !== session) {
		t6 = isPendingSession(session);
		$[11] = session;
		$[12] = t6;
	} else t6 = $[12];
	const t7 = !t6;
	let t8;
	if ($[13] !== queryKey || $[14] !== shouldPoll || $[15] !== t5 || $[16] !== t7) {
		t8 = {
			queryKey,
			queryFn: t5,
			refetchInterval: shouldPoll,
			enabled: t7
		};
		$[13] = queryKey;
		$[14] = shouldPoll;
		$[15] = t5;
		$[16] = t7;
		$[17] = t8;
	} else t8 = $[17];
	const query = useCAPIQuery(t8);
	let t9;
	if ($[18] !== query.data?.commands) {
		t9 = query.data?.commands ?? [];
		$[18] = query.data?.commands;
		$[19] = t9;
	} else t9 = $[19];
	let t10;
	if ($[20] !== query.error || $[21] !== query.isError || $[22] !== query.isLoading || $[23] !== t9) {
		t10 = {
			data: t9,
			isLoading: query.isLoading,
			isError: query.isError,
			error: query.error
		};
		$[20] = query.error;
		$[21] = query.isError;
		$[22] = query.isLoading;
		$[23] = t9;
		$[24] = t10;
	} else t10 = $[24];
	return t10;
}
function _temp$34(cmd) {
	return cmd.id.startsWith("optimistic-");
}
function getFaviconElements() {
	return {
		favicon: document.querySelector(".js-site-favicon[type=\"image/svg+xml\"]"),
		faviconFallback: document.querySelector(".js-site-favicon[type=\"image/png\"]")
	};
}
/**
* Update the favicon to the given variant
* Primarily used by React components to update the favicon when the page status changes.
* This method abstracts url building logic from the React components.
*/
function updateFaviconByVariant(variant) {
	const { favicon, faviconFallback } = getFaviconElements();
	if (!favicon || !faviconFallback) return;
	const baseUrl = favicon.getAttribute("data-base-href");
	const variantSuffix = variant === "default" ? "" : `-${variant}`;
	const colorSchemeSuffix = getColorSchemeSuffix();
	if (baseUrl) {
		favicon.href = `${baseUrl}${variantSuffix}${colorSchemeSuffix}.svg`;
		faviconFallback.href = `${baseUrl}${variantSuffix}${colorSchemeSuffix}.png`;
	}
}
/**
* Helper method to reset the favicon to the default state.
*/
function resetFavicon() {
	updateFaviconByVariant("default");
}
function getColorSchemeSuffix() {
	return prefersDarkColorScheme() ? "-dark" : "";
}
function prefersDarkColorScheme() {
	return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
}
var CombinedStateToFaviconVariant = {
	[SessionState.Completed]: "success",
	[SessionState.InProgress]: "pending",
	[SessionState.Idle]: "pending",
	[SessionState.WaitingForUser]: "pending",
	[SessionState.Queued]: "pending",
	[SessionState.TimedOut]: "failure",
	[SessionState.Failed]: "failure",
	[SessionState.Cancelled]: "failure"
};
function useSyncFavicon(state) {
	const $ = c$1(3);
	let t0;
	let t1;
	if ($[0] !== state) {
		t0 = () => {
			const newVariant = CombinedStateToFaviconVariant[state];
			updateFaviconByVariant(newVariant);
			return _temp$33;
		};
		t1 = [state];
		$[0] = state;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
}
function _temp$33() {
	resetFavicon();
}
var NewToolHeader_module_default = {
	button: "NewToolHeader-module_sPz2Da_button",
	groupHeader: "NewToolHeader-module_sPz2Da_groupHeader",
	headerContainer: "NewToolHeader-module_sPz2Da_headerContainer",
	inGroup: "NewToolHeader-module_sPz2Da_inGroup",
	leadingVisualContainer: "NewToolHeader-module_sPz2Da_leadingVisualContainer",
	missionControl: "NewToolHeader-module_sPz2Da_missionControl",
	nonInteractive: "NewToolHeader-module_sPz2Da_nonInteractive",
	openBrowserButton: "NewToolHeader-module_sPz2Da_openBrowserButton",
	path: "NewToolHeader-module_sPz2Da_path",
	pathInGroup: "NewToolHeader-module_sPz2Da_pathInGroup",
	shimmerInline: "NewToolHeader-module_sPz2Da_shimmerInline",
	spinnerContainer: "NewToolHeader-module_sPz2Da_spinnerContainer",
	text: "NewToolHeader-module_sPz2Da_text",
	title: "NewToolHeader-module_sPz2Da_title",
	titleInGroup: "NewToolHeader-module_sPz2Da_titleInGroup",
	toggleIcon: "NewToolHeader-module_sPz2Da_toggleIcon",
	trailingVisualContainer: "NewToolHeader-module_sPz2Da_trailingVisualContainer"
};
var SessionLogsContext = createContext({
	variant: "default",
	onToolExpand: null,
	session: null,
	sessionNwo: null
});
SessionLogsContext.displayName = "SessionLogsContext";
function useSessionLogsContext() {
	return use(SessionLogsContext);
}
function SessionLogsProvider(t0) {
	const $ = c$1(8);
	const { variant, onToolExpand: t1, session: t2, sessionNwo: t3, children } = t0;
	const onToolExpand = t1 === void 0 ? null : t1;
	const session = t2 === void 0 ? null : t2;
	const sessionNwo = t3 === void 0 ? null : t3;
	let t4;
	if ($[0] !== onToolExpand || $[1] !== session || $[2] !== sessionNwo || $[3] !== variant) {
		t4 = {
			variant,
			onToolExpand,
			session,
			sessionNwo
		};
		$[0] = onToolExpand;
		$[1] = session;
		$[2] = sessionNwo;
		$[3] = variant;
		$[4] = t4;
	} else t4 = $[4];
	const t5 = t4;
	let t6;
	if ($[5] !== children || $[6] !== t5) {
		t6 = jsx(SessionLogsContext, {
			value: t5,
			children
		});
		$[5] = children;
		$[6] = t5;
		$[7] = t6;
	} else t6 = $[7];
	return t6;
}
SessionLogsProvider.displayName = "SessionLogsProvider";
var StatusTextSlider_module_default = {
	entering: "StatusTextSlider-module_-haaqG_entering",
	exiting: "StatusTextSlider-module_-haaqG_exiting",
	item: "StatusTextSlider-module_-haaqG_item",
	slider: "StatusTextSlider-module_-haaqG_slider"
};
/**
* StatusTextSlider — animated text ticker that slides new text up from below
* while the old text slides up and out, in a clipped vertical container.
*
* Ported from copilot-tauri-app's ActivityTicker.
*
* Enforces a minimum display time so rapid-fire updates don't feel jarring.
* If new text arrives before the minimum time elapses, only the latest value
* is queued and shown once the window opens.
*/
var TICKER_ANIMATION_MS = 150;
var TICKER_MIN_DISPLAY_MS = 1e3;
function StatusTextSlider(t0) {
	const $ = c$1(14);
	const { text } = t0;
	let t1;
	if ($[0] !== text) {
		t1 = () => [{
			text,
			key: 0
		}];
		$[0] = text;
		$[1] = t1;
	} else t1 = $[1];
	const [items, setItems] = useState(t1);
	const nextKeyRef = useRef(1);
	const prevTextRef = useRef(text);
	const lastTransitionRef = useRef(0);
	const pendingRef = useRef(null);
	const timerRef = useRef(null);
	const pruneRef = useRef(null);
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (newText) => {
			prevTextRef.current = newText;
			lastTransitionRef.current = Date.now();
			nextKeyRef.current = nextKeyRef.current + 1;
			const k = nextKeyRef.current;
			setItems((prev) => {
				return [prev[prev.length - 1] ?? {
					text: "",
					key: 0
				}, {
					text: newText,
					key: k
				}];
			});
			if (pruneRef.current) clearTimeout(pruneRef.current);
			pruneRef.current = setTimeout(() => {
				pruneRef.current = null;
				setItems(_temp$32);
			}, TICKER_ANIMATION_MS);
		};
		$[2] = t2;
	} else t2 = $[2];
	const transition = t2;
	let t3;
	let t4;
	if ($[3] !== text) {
		t3 = () => {
			if (text === prevTextRef.current) {
				pendingRef.current = null;
				if (timerRef.current) {
					clearTimeout(timerRef.current);
					timerRef.current = null;
				}
				return;
			}
			const elapsed = Date.now() - lastTransitionRef.current;
			if (elapsed >= TICKER_MIN_DISPLAY_MS) {
				if (timerRef.current) {
					clearTimeout(timerRef.current);
					timerRef.current = null;
				}
				pendingRef.current = null;
				transition(text);
			} else {
				pendingRef.current = text;
				if (!timerRef.current) timerRef.current = setTimeout(() => {
					timerRef.current = null;
					if (pendingRef.current && pendingRef.current !== prevTextRef.current) {
						const queued = pendingRef.current;
						pendingRef.current = null;
						transition(queued);
					}
				}, TICKER_MIN_DISPLAY_MS - elapsed);
			}
		};
		t4 = [text, transition];
		$[3] = text;
		$[4] = t3;
		$[5] = t4;
	} else {
		t3 = $[4];
		t4 = $[5];
	}
	useEffect(t3, t4);
	let t5;
	let t6;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = () => () => {
			if (timerRef.current) clearTimeout(timerRef.current);
			if (pruneRef.current) clearTimeout(pruneRef.current);
		};
		t6 = [];
		$[6] = t5;
		$[7] = t6;
	} else {
		t5 = $[6];
		t6 = $[7];
	}
	useEffect(t5, t6);
	const isTransitioning = items.length > 1;
	let t7;
	if ($[8] !== isTransitioning || $[9] !== items) {
		let t8;
		if ($[11] !== isTransitioning || $[12] !== items.length) {
			t8 = (item, index) => {
				const isExiting = isTransitioning && index === 0;
				const isEntering = isTransitioning && index === items.length - 1;
				return jsx("span", {
					className: clsx(StatusTextSlider_module_default.item, isExiting && StatusTextSlider_module_default.exiting, isEntering && StatusTextSlider_module_default.entering),
					children: item.text
				}, item.key);
			};
			$[11] = isTransitioning;
			$[12] = items.length;
			$[13] = t8;
		} else t8 = $[13];
		t7 = jsx("span", {
			className: StatusTextSlider_module_default.slider,
			"aria-live": "polite",
			children: items.map(t8)
		});
		$[8] = isTransitioning;
		$[9] = items;
		$[10] = t7;
	} else t7 = $[10];
	return t7;
}
StatusTextSlider.displayName = "StatusTextSlider";
function _temp$32(prev_0) {
	if (prev_0.length <= 1) return prev_0;
	const last_0 = prev_0[prev_0.length - 1];
	return last_0 ? [last_0] : prev_0;
}
function NewToolHeader(t0) {
	const $ = c$1(25);
	const { leadingVisual, trailingVisual, title, path, isCollapsed, hasReferences: t1, isError: t2, isPending: t3, isInGroup: t4, isGroupHeader: t5, statusText, onModifierClick, onToggle } = t0;
	const hasReferences = t1 === void 0 ? true : t1;
	const isError = t2 === void 0 ? false : t2;
	const isPending = t3 === void 0 ? false : t3;
	const isInGroup = t4 === void 0 ? false : t4;
	const isGroupHeader = t5 === void 0 ? false : t5;
	const { variant, onToolExpand } = useSessionLogsContext();
	let t6;
	if ($[0] !== isCollapsed || $[1] !== onModifierClick || $[2] !== onToggle || $[3] !== onToolExpand || $[4] !== title) {
		t6 = (event) => {
			if ((event.altKey || event.metaKey) && onModifierClick) {
				event.preventDefault();
				event.stopPropagation();
				onModifierClick(!!isCollapsed);
				sendEvent("agent_sessions.task_view", {
					target: "TOOL_HEADER_MODIFIER",
					action: isCollapsed ? "EXPAND_ALL" : "COLLAPSE_ALL",
					tool_title: title
				});
				return false;
			} else {
				onToggle?.();
				onToolExpand?.(!!isCollapsed);
				sendEvent("agent_sessions.task_view", {
					target: "TOOL_HEADER",
					action: isCollapsed ? "EXPAND" : "COLLAPSE",
					tool_title: title
				});
			}
		};
		$[0] = isCollapsed;
		$[1] = onModifierClick;
		$[2] = onToggle;
		$[3] = onToolExpand;
		$[4] = title;
		$[5] = t6;
	} else t6 = $[5];
	const handleClick = t6;
	if (variant === "mission-control" || variant === "chat") {
		let t7;
		if ($[6] !== handleClick || $[7] !== hasReferences || $[8] !== isCollapsed || $[9] !== isError || $[10] !== isGroupHeader || $[11] !== isInGroup || $[12] !== isPending || $[13] !== leadingVisual || $[14] !== path || $[15] !== statusText || $[16] !== title || $[17] !== trailingVisual) {
			t7 = jsxs("div", {
				className: NewToolHeader_module_default.headerContainer,
				children: [jsxs("button", {
					type: "button",
					className: clsx(NewToolHeader_module_default.missionControl, {
						[NewToolHeader_module_default.inGroup]: isInGroup,
						[NewToolHeader_module_default.groupHeader]: isGroupHeader,
						[NewToolHeader_module_default.nonInteractive]: !hasReferences
					}),
					onClick: hasReferences ? handleClick : void 0,
					"aria-disabled": !hasReferences,
					"aria-expanded": !isCollapsed,
					tabIndex: hasReferences ? 0 : -1,
					children: [
						leadingVisual ? jsx("span", {
							className: NewToolHeader_module_default.leadingVisualContainer,
							children: leadingVisual
						}) : null,
						isPending ? jsxs("div", {
							className: NewToolHeader_module_default.text,
							children: [jsx(WithShimmerEffect, {
								className: NewToolHeader_module_default.shimmerInline,
								innerClassName: NewToolHeader_module_default.shimmerInline,
								children: jsx("span", {
									className: clsx(NewToolHeader_module_default.title, { [NewToolHeader_module_default.titleInGroup]: isInGroup }),
									children: title
								})
							}), path && jsxs(Fragment$1, { children: [" ", jsx("span", {
								className: NewToolHeader_module_default.path,
								children: path
							})] })]
						}) : jsxs("span", {
							className: NewToolHeader_module_default.text,
							children: [jsx("span", {
								className: clsx(NewToolHeader_module_default.title, { [NewToolHeader_module_default.titleInGroup]: isInGroup }),
								children: title
							}), path && jsxs(Fragment$1, { children: [" ", jsx("span", {
								className: NewToolHeader_module_default.path,
								children: path
							})] })]
						}),
						hasReferences && jsx(ChevronRightIcon, {
							size: 12,
							className: NewToolHeader_module_default.toggleIcon,
							"data-expanded": !isCollapsed,
							"aria-hidden": "true"
						}),
						statusText && jsx(StatusTextSlider, { text: statusText }),
						isError && jsx(AlertIcon, {
							size: 16,
							className: "color-fg-attention flex-shrink-0"
						})
					]
				}), trailingVisual ? jsx("div", {
					className: NewToolHeader_module_default.trailingVisualContainer,
					children: trailingVisual
				}) : null]
			});
			$[6] = handleClick;
			$[7] = hasReferences;
			$[8] = isCollapsed;
			$[9] = isError;
			$[10] = isGroupHeader;
			$[11] = isInGroup;
			$[12] = isPending;
			$[13] = leadingVisual;
			$[14] = path;
			$[15] = statusText;
			$[16] = title;
			$[17] = trailingVisual;
			$[18] = t7;
		} else t7 = $[18];
		return t7;
	}
	let t7;
	if ($[19] !== handleClick || $[20] !== isCollapsed || $[21] !== isError || $[22] !== path || $[23] !== title) {
		t7 = jsx(ButtonComponent$1, {
			as: "summary",
			block: true,
			className: clsx("Button", NewToolHeader_module_default.button),
			alignContent: "start",
			"aria-expanded": !isCollapsed,
			"aria-labelledby": "tool-header-title",
			leadingVisual: isCollapsed ? jsx(ChevronRightIcon, {}) : jsx(ChevronDownIcon, {}),
			trailingVisual: isError ? jsx(AlertIcon, {
				size: 16,
				className: "color-fg-attention flex-shrink-0"
			}) : null,
			onClick: handleClick,
			children: jsxs(Fragment$1, { children: [
				jsx("span", {
					className: "overflow-hidden text-truncate flex-1",
					children: title
				}),
				" ",
				path && jsx("span", {
					className: "text-mono fgColor-default",
					children: path
				})
			] })
		});
		$[19] = handleClick;
		$[20] = isCollapsed;
		$[21] = isError;
		$[22] = path;
		$[23] = title;
		$[24] = t7;
	} else t7 = $[24];
	return t7;
}
NewToolHeader.displayName = "NewToolHeader";
var ToolCodeBlock_module_default = {
	code: "ToolCodeBlock-module_qQ4YUq_code",
	codeContainer: "ToolCodeBlock-module_qQ4YUq_codeContainer",
	codeWrap: "ToolCodeBlock-module_qQ4YUq_codeWrap",
	container: "ToolCodeBlock-module_qQ4YUq_container"
};
function ToolCodeBlock(t0) {
	const $ = c$1(8);
	const { shellLoading, children } = t0;
	const codeBlockLabelId = useId();
	const [loaderChar, setLoaderChar] = useState("|");
	let t1;
	let t2;
	if ($[0] !== shellLoading) {
		t1 = () => {
			let intervalId;
			if (shellLoading) {
				const loaderChars = [
					"|",
					"/",
					"-",
					"\\"
				];
				let currentCharIndex = 0;
				intervalId = setInterval(() => {
					currentCharIndex = (currentCharIndex + 1) % loaderChars.length;
					setLoaderChar(loaderChars[currentCharIndex] || "|");
				}, 250);
			} else setLoaderChar("|");
			return () => clearInterval(intervalId);
		};
		t2 = [shellLoading];
		$[0] = shellLoading;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useEffect(t1, t2);
	let t3;
	if ($[3] !== children || $[4] !== codeBlockLabelId || $[5] !== loaderChar || $[6] !== shellLoading) {
		t3 = jsx("figure", {
			className: ToolCodeBlock_module_default.container,
			"aria-labelledby": codeBlockLabelId,
			children: jsx("div", {
				className: ToolCodeBlock_module_default.codeContainer,
				children: jsx("pre", {
					className: ToolCodeBlock_module_default.code,
					tabIndex: 0,
					children: jsxs("code", {
						className: ToolCodeBlock_module_default.codeWrap,
						children: [children, shellLoading && jsx("span", { children: loaderChar })]
					})
				})
			})
		});
		$[3] = children;
		$[4] = codeBlockLabelId;
		$[5] = loaderChar;
		$[6] = shellLoading;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
ToolCodeBlock.displayName = "ToolCodeBlock";
var codeblockAttribute = "data-tool-codeblock-props";
var codeblockProperty = dataAttrToPropName(codeblockAttribute);
var reactComponents$2 = { code: (props, fallthrough) => {
	const codeblockProps = parseJsonAttribute(props, codeblockAttribute);
	if (!codeblockProps) return fallthrough;
	return /* @__PURE__ */ jsx(ToolCodeBlock, {
		...codeblockProps,
		children: props.children
	});
} };
function toolCodeBlockExtension(args = {}) {
	const { shellLoading } = args;
	return {
		transformMarkdown: (tree) => visit(tree, "code", (node) => {
			node.data = {
				...node.data,
				hName: "code",
				hProperties: { [codeblockProperty]: JSON.stringify({
					language: node.lang ?? "",
					code: node.value,
					startOffset: node.position?.start.offset ?? -1,
					endOffset: node.position?.end.offset ?? -1,
					shellLoading: !!shellLoading
				}) }
			};
		}),
		transformHtml: (tree) => visit(tree, "element", (node, i, parent) => {
			const child = node.children?.[0];
			if (parent && i !== void 0 && node.tagName === "pre" && node.children?.length === 1 && child?.type === "element" && child.tagName === "code" && codeblockProperty in child.properties) parent.children.splice(i, 1, child);
		}),
		reactComponents: reactComponents$2
	};
}
var ViewFilesIcon = ({ "aria-label": ariaLabel }) => /* @__PURE__ */ jsx("svg", {
	"aria-label": ariaLabel,
	width: "16",
	height: "16",
	viewBox: "0 0 16 16",
	fill: "none",
	xmlns: "http://www.w3.org/2000/svg",
	children: /* @__PURE__ */ jsx("path", {
		d: "M1.75 10C2.16421 10 2.5 10.3358 2.5 10.75V13.25C2.5 13.3881 2.61193 13.5 2.75 13.5H5.25C5.66421 13.5 6 13.8358 6 14.25C6 14.6642 5.66421 15 5.25 15H2.75C1.7835 15 1 14.2165 1 13.25V10.75C1 10.3358 1.33579 10 1.75 10ZM14.25 10C14.6642 10 15 10.3358 15 10.75V13.25C15 14.2165 14.2165 15 13.25 15H10.75C10.3358 15 10 14.6642 10 14.25C10 13.8358 10.3358 13.5 10.75 13.5H13.25C13.3881 13.5 13.5 13.3881 13.5 13.25V10.75C13.5 10.3358 13.8358 10 14.25 10ZM8.25 10C8.66421 10 9 10.3358 9 10.75C9 11.1642 8.66421 11.5 8.25 11.5H5.25C4.83579 11.5 4.5 11.1642 4.5 10.75C4.5 10.3358 4.83579 10 5.25 10H8.25ZM11.25 7.5C11.6642 7.5 12 7.83579 12 8.25C12 8.66421 11.6642 9 11.25 9H5.25C4.83579 9 4.5 8.66421 4.5 8.25C4.5 7.83579 4.83579 7.5 5.25 7.5H11.25ZM10.25 5C10.6642 5 11 5.33579 11 5.75C11 6.16421 10.6642 6.5 10.25 6.5H5.25C4.83579 6.5 4.5 6.16421 4.5 5.75C4.5 5.33579 4.83579 5 5.25 5H10.25ZM5.25 1C5.66421 1 6 1.33579 6 1.75C6 2.16421 5.66421 2.5 5.25 2.5H2.75C2.61193 2.5 2.5 2.61193 2.5 2.75V5.25C2.5 5.66421 2.16421 6 1.75 6C1.33579 6 1 5.66421 1 5.25V2.75C1 1.7835 1.7835 1 2.75 1H5.25ZM13.25 1C14.2165 1 15 1.7835 15 2.75V5.25C15 5.66421 14.6642 6 14.25 6C13.8358 6 13.5 5.66421 13.5 5.25V2.75C13.5 2.61193 13.3881 2.5 13.25 2.5H10.75C10.3358 2.5 10 2.16421 10 1.75C10 1.33579 10.3358 1 10.75 1H13.25Z",
		fill: "currentColor"
	})
});
ViewFilesIcon.displayName = "ViewFilesIcon";
function getToolIcon(toolName = "", mcpToolNameMappings) {
	switch (toolName) {
		case TOOL_NAMES.APPLY_PATCH: return /* @__PURE__ */ jsx(FileDiffIcon, {
			className: "fgColor-attention",
			"aria-label": "File Edit: "
		});
		case TOOL_NAMES.BASH:
		case TOOL_NAMES.WRITE_BASH:
		case TOOL_NAMES.READ_BASH:
		case TOOL_NAMES.STOP_BASH:
		case TOOL_NAMES.LIST_BASH:
		case TOOL_NAMES.ASYNC_BASH:
		case TOOL_NAMES.READ_ASYNC_BASH:
		case TOOL_NAMES.STOP_ASYNC_BASH:
		case TOOL_NAMES.POWERSHELL:
		case TOOL_NAMES.WRITE_POWERSHELL:
		case TOOL_NAMES.READ_POWERSHELL:
		case TOOL_NAMES.STOP_POWERSHELL:
		case TOOL_NAMES.LIST_POWERSHELL: return /* @__PURE__ */ jsx(TerminalIcon, { "aria-label": "CLI output: " });
		case TOOL_NAMES.THINK: return /* @__PURE__ */ jsx(LightBulbIcon, { "aria-label": "Copilot Thought: " });
		case TOOL_NAMES.STR_REPLACE_EDITOR:
		case TOOL_NAMES.STR_REPLACE:
		case TOOL_NAMES.EDIT: return /* @__PURE__ */ jsx(FileDiffIcon, {
			className: "fgColor-attention",
			"aria-label": "File Edit: "
		});
		case TOOL_NAMES.CREATE: return /* @__PURE__ */ jsx(FileAddedIcon, {
			className: "fgColor-success",
			"aria-label": "File Creation: "
		});
		case TOOL_NAMES.VIEW: return /* @__PURE__ */ jsx(ViewFilesIcon, { "aria-label": "View File: " });
		case TOOL_NAMES.GREP:
		case TOOL_NAMES.RG:
		case TOOL_NAMES.SEARCH_CODE_SUBAGENT: return /* @__PURE__ */ jsx(SearchIcon, { "aria-label": "Search: " });
		case TOOL_NAMES.WEB_SEARCH: return /* @__PURE__ */ jsx(SearchIcon, { "aria-label": "Web Search: " });
		case TOOL_NAMES.WEB_FETCH: return /* @__PURE__ */ jsx(GlobeIcon, { "aria-label": "Web Fetch: " });
		case TOOL_NAMES.GLOB: return /* @__PURE__ */ jsx(FileDirectoryIcon, { "aria-label": "Find files: " });
		case TOOL_NAMES.RUN_CUSTOM_SETUP_STEP:
		case TOOL_NAMES.RUN_SETUP: return /* @__PURE__ */ jsx(CodespacesIcon, { "aria-label": "Custom Setup Run: " });
		case TOOL_NAMES.PROPOSE_WORK: return /* @__PURE__ */ jsx(TasklistIcon, { "aria-label": "Propose Work: " });
		case TOOL_NAMES.CODE_REVIEW: return /* @__PURE__ */ jsx(CodescanCheckmarkIcon, { "aria-label": "Code Review: " });
		case TOOL_NAMES.CODEQL_CHECKER: return /* @__PURE__ */ jsx(CodescanCheckmarkIcon, { "aria-label": "CodeQL Scan: " });
		case TOOL_NAMES.CREATE_PULL_REQUEST: return /* @__PURE__ */ jsx(GitPullRequestIcon, { "aria-label": "Create pull request: " });
		case TOOL_NAMES.PARALLEL_VALIDATION: return /* @__PURE__ */ jsx(CodescanCheckmarkIcon, { "aria-label": "Parallel Validation: " });
		case TOOL_NAMES.REPORT_PROGRESS:
		case TOOL_NAMES.REPLY_TO_COMMENT: return /* @__PURE__ */ jsx(TerminalIcon, { "aria-label": "Tool output: " });
		default:
			if (mcpToolNameMappings && Object.prototype.hasOwnProperty.call(mcpToolNameMappings, toolName)) return /* @__PURE__ */ jsx(McpIcon, { "aria-label": "MCP tool: " });
			return /* @__PURE__ */ jsx(TerminalIcon, { "aria-label": "Tool output: " });
	}
}
var CodeInsightsDialog_module_default = {
	avatarInitial: "CodeInsightsDialog-module_fWTLXq_avatarInitial",
	chevronIcon: "CodeInsightsDialog-module_fWTLXq_chevronIcon",
	connectorLine: "CodeInsightsDialog-module_fWTLXq_connectorLine",
	dialogSubtitle: "CodeInsightsDialog-module_fWTLXq_dialogSubtitle",
	emptyState: "CodeInsightsDialog-module_fWTLXq_emptyState",
	expandedContent: "CodeInsightsDialog-module_fWTLXq_expandedContent",
	licenseBadge: "CodeInsightsDialog-module_fWTLXq_licenseBadge",
	matchItem: "CodeInsightsDialog-module_fWTLXq_matchItem",
	matchLink: "CodeInsightsDialog-module_fWTLXq_matchLink",
	matchList: "CodeInsightsDialog-module_fWTLXq_matchList",
	repositoryAvatar: "CodeInsightsDialog-module_fWTLXq_repositoryAvatar",
	repositoryAvatarFallback: "CodeInsightsDialog-module_fWTLXq_repositoryAvatarFallback",
	repositoryName: "CodeInsightsDialog-module_fWTLXq_repositoryName",
	section: "CodeInsightsDialog-module_fWTLXq_section",
	sectionGrid: "CodeInsightsDialog-module_fWTLXq_sectionGrid",
	sectionHeader: "CodeInsightsDialog-module_fWTLXq_sectionHeader",
	sectionIcon: "CodeInsightsDialog-module_fWTLXq_sectionIcon",
	sectionTitle: "CodeInsightsDialog-module_fWTLXq_sectionTitle"
};
function CodeInsightsDialog(t0) {
	const $ = c$1(6);
	const { isOpen, onClose, insights } = t0;
	const [isCodeMatchExpanded, setIsCodeMatchExpanded] = useState(true);
	const listId = useId();
	const citationsCount = insights.publicCodeReferences?.length ?? 0;
	if (!isOpen) return null;
	let t1;
	if ($[0] !== citationsCount || $[1] !== insights.publicCodeReferences || $[2] !== isCodeMatchExpanded || $[3] !== listId || $[4] !== onClose) {
		t1 = jsx(Dialog, {
			title: "Code insights",
			subtitle: jsx("span", {
				className: CodeInsightsDialog_module_default.dialogSubtitle,
				children: "Find matches across our platform."
			}),
			onClose,
			width: "large",
			children: jsxs("div", { children: [citationsCount > 0 && jsxs("div", {
				className: CodeInsightsDialog_module_default.section,
				children: [jsxs("button", {
					type: "button",
					className: CodeInsightsDialog_module_default.sectionHeader,
					onClick: () => setIsCodeMatchExpanded(!isCodeMatchExpanded),
					"aria-expanded": isCodeMatchExpanded,
					"aria-controls": listId,
					"aria-label": isCodeMatchExpanded ? "Collapse section" : "Expand section",
					children: [
						jsx("span", {
							className: CodeInsightsDialog_module_default.chevronIcon,
							children: isCodeMatchExpanded ? jsx(ChevronDownIcon, {
								size: 16,
								"aria-hidden": "true"
							}) : jsx(ChevronRightIcon, {
								size: 16,
								"aria-hidden": "true"
							})
						}),
						jsx(LawIcon, {
							size: 16,
							className: CodeInsightsDialog_module_default.sectionIcon,
							"aria-hidden": "true"
						}),
						jsx("span", {
							className: CodeInsightsDialog_module_default.sectionTitle,
							children: citationsCount === 1 ? "1 similar code snippet found" : `${citationsCount} similar code snippets found`
						})
					]
				}), isCodeMatchExpanded && jsxs("div", {
					className: CodeInsightsDialog_module_default.expandedContent,
					children: [jsx("div", {
						className: CodeInsightsDialog_module_default.connectorLine,
						"aria-hidden": "true"
					}), jsx("ul", {
						className: CodeInsightsDialog_module_default.matchList,
						id: listId,
						children: insights.publicCodeReferences?.map(_temp$31)
					})]
				})]
			}), citationsCount === 0 && jsx("div", {
				className: CodeInsightsDialog_module_default.emptyState,
				children: "No code matches found."
			})] })
		});
		$[0] = citationsCount;
		$[1] = insights.publicCodeReferences;
		$[2] = isCodeMatchExpanded;
		$[3] = listId;
		$[4] = onClose;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
/**
* Avatar component for repositories using the owner's avatar.
* Falls back to a deterministic colored placeholder if nwo is not available or image fails to load.
*/
CodeInsightsDialog.displayName = "CodeInsightsDialog";
function _temp$31(match) {
	return jsx("li", {
		className: CodeInsightsDialog_module_default.matchItem,
		children: jsxs("a", {
			href: match.sourceURL || void 0,
			target: "_blank",
			rel: "noopener noreferrer",
			className: CodeInsightsDialog_module_default.matchLink,
			children: [
				jsx(RepositoryAvatar, { nwo: match.nwo }),
				jsx("span", {
					className: CodeInsightsDialog_module_default.repositoryName,
					children: match.nwo ?? match.sourceURL
				}),
				jsx("span", {
					className: CodeInsightsDialog_module_default.licenseBadge,
					children: match.license && match.license !== "NOASSERTION" ? match.license : "No license"
				})
			]
		})
	}, match.annotationId);
}
function RepositoryAvatar(t0) {
	const $ = c$1(6);
	const { nwo } = t0;
	const [imageError, setImageError] = useState(false);
	const bgColor = AVATAR_FALLBACK_COLORS[(nwo ?? "").split("").reduce(_temp2$12, 0) % AVATAR_FALLBACK_COLORS.length];
	if (nwo && !imageError) {
		let t1;
		if ($[0] !== nwo) {
			t1 = Symbol.for("react.early_return_sentinel");
			bb0: {
				const [owner] = nwo.split("/");
				if (owner) {
					let t2;
					if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
						t2 = () => setImageError(true);
						$[2] = t2;
					} else t2 = $[2];
					t1 = jsx(GitHubAvatar, {
						src: ownerAvatarPath({ owner }),
						size: 20,
						alt: nwo,
						className: CodeInsightsDialog_module_default.repositoryAvatar,
						onError: t2
					});
					break bb0;
				}
			}
			$[0] = nwo;
			$[1] = t1;
		} else t1 = $[1];
		if (t1 !== Symbol.for("react.early_return_sentinel")) return t1;
	}
	let t1;
	if ($[3] !== bgColor || $[4] !== nwo) {
		t1 = jsx("div", {
			className: CodeInsightsDialog_module_default.repositoryAvatarFallback,
			style: { backgroundColor: bgColor },
			"aria-hidden": "true",
			children: jsx("span", {
				className: CodeInsightsDialog_module_default.avatarInitial,
				children: (nwo ?? "?").charAt(0).toUpperCase()
			})
		});
		$[3] = bgColor;
		$[4] = nwo;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
RepositoryAvatar.displayName = "RepositoryAvatar";
function _temp2$12(acc, char) {
	return acc + char.charCodeAt(0);
}
var CodeInsights_module_default = {
	indicatorButton: "CodeInsights-module_ugFn8a_indicatorButton",
	indicatorContainer: "CodeInsights-module_ugFn8a_indicatorContainer",
	indicatorText: "CodeInsights-module_ugFn8a_indicatorText"
};
/**
* Builds the full avatar URL for an owner, matching the logic in GitHubAvatar.
* GitHubAvatar doubles the display size for high-density screens (size={20} → ?size=40).
* Keep in sync with the size prop passed to GitHubAvatar in CodeInsightsDialog's RepositoryAvatar.
*/
function buildAvatarUrl(owner) {
	const url = new URL(ownerAvatarPath({ owner }), ssrSafeLocation.origin);
	url.searchParams.set("size", String(40));
	return url.toString();
}
/**
* Preloads avatar images so they are cached by the browser before the dialog opens.
* Appends <link rel="prefetch"> elements to <head> and removes them on cleanup.
*/
function usePreloadAvatars(insights) {
	const $ = c$1(3);
	const references = insights.publicCodeReferences;
	let t0;
	let t1;
	if ($[0] !== references) {
		t0 = () => {
			const owners = /* @__PURE__ */ new Set();
			for (const ref of references) if (ref.nwo) {
				const [owner] = ref.nwo.split("/");
				if (owner) owners.add(owner);
			}
			const links = [];
			for (const owner_0 of owners) {
				const link = document.createElement("link");
				link.rel = "prefetch";
				link.setAttribute("as", "image");
				link.href = buildAvatarUrl(owner_0);
				document.head.appendChild(link);
				links.push(link);
			}
			return () => {
				for (const link_0 of links) link_0.remove();
			};
		};
		t1 = [references];
		$[0] = references;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
}
/**
* Small icon in toolHeader that displays when code insights are available for the tool call.
* Clicking opens the CodeInsightsDialog.
*/
function CodeInsightsIndicator(t0) {
	const $ = c$1(5);
	const { insights } = t0;
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const totalCount = insights.publicCodeReferences.length;
	usePreloadAvatars(insights);
	if (totalCount === 0) return null;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (event) => {
			event.stopPropagation();
			setIsDialogOpen(true);
		};
		$[0] = t1;
	} else t1 = $[0];
	const handleClick = t1;
	let t2;
	if ($[1] !== insights || $[2] !== isDialogOpen) {
		let t3;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = () => setIsDialogOpen(false);
			$[4] = t3;
		} else t3 = $[4];
		t2 = jsxs("div", {
			className: CodeInsights_module_default.indicatorContainer,
			children: [jsx(ButtonComponent$1, {
				variant: "invisible",
				"aria-label": "Similar to public code",
				onClick: handleClick,
				className: CodeInsights_module_default.indicatorButton,
				leadingVisual: ShieldIcon,
				size: "small",
				children: jsx("span", {
					className: CodeInsights_module_default.indicatorText,
					children: "Similar to public code"
				})
			}), jsx(CodeInsightsDialog, {
				isOpen: isDialogOpen,
				onClose: t3,
				insights
			})]
		});
		$[1] = insights;
		$[2] = isDialogOpen;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
CodeInsightsIndicator.displayName = "CodeInsightsIndicator";
/**
* Extracts the content of a file from a git diff output.
* Currently assumes there's only one hunk in the diff.
*
* @param diff The git diff output
* @returns The extracted file content
*/
function extractContentFromDiff(diff) {
	if (!diff) return void 0;
	try {
		const lines = diff.split("\n");
		let contentStartIndex = -1;
		for (let i = 0; i < lines.length; i++) if (lines[i]?.startsWith("@@")) {
			contentStartIndex = i + 1;
			break;
		}
		return lines.slice(contentStartIndex).map((line) => {
			if (line.startsWith("+") || line.startsWith("-")) {
				const content = line.substring(1);
				return content.startsWith(" ") ? content.substring(1) : content;
			} else return line.startsWith(" ") ? line.substring(1) : line;
		}).filter((line) => line !== null).join("\n").trim();
	} catch {
		return diff;
	}
}
function trimFileName(path) {
	try {
		const windowsMatch = path.match(/^[A-Za-z]:\\a\\[^\\]+\\[^\\]+\\(.*)$/);
		if (windowsMatch && windowsMatch[1] !== void 0) {
			const relativePath = windowsMatch[1].replace(/\\/g, "/");
			return relativePath.length > 0 ? relativePath : void 0;
		}
		const shortenedPath = path.replace("/home/runner/work/", "").split("/").slice(2).join("/");
		return shortenedPath.length > 0 ? shortenedPath : void 0;
	} catch {
		return path;
	}
}
var Tool_module_default = {
	createDiffContainer: "Tool-module_zVJVjW_createDiffContainer",
	detailsContainer: "Tool-module_zVJVjW_detailsContainer",
	detailsContainerDefault: "Tool-module_zVJVjW_detailsContainerDefault",
	detailsContainerNoChildren: "Tool-module_zVJVjW_detailsContainerNoChildren",
	diffPreview: "Tool-module_zVJVjW_diffPreview",
	diffPreviewFooter: "Tool-module_zVJVjW_diffPreviewFooter",
	toolContainer: "Tool-module_zVJVjW_toolContainer",
	toolContainerDefault: "Tool-module_zVJVjW_toolContainerDefault",
	toolContainerExpanded: "Tool-module_zVJVjW_toolContainerExpanded",
	toolContainerInGroup: "Tool-module_zVJVjW_toolContainerInGroup",
	toolContent: "Tool-module_zVJVjW_toolContent",
	toolContentCollapsed: "Tool-module_zVJVjW_toolContentCollapsed",
	toolContentMissionControl: "Tool-module_zVJVjW_toolContentMissionControl",
	toolContentPreview: "Tool-module_zVJVjW_toolContentPreview",
	viewDiffContainer: "Tool-module_zVJVjW_viewDiffContainer"
};
var DiffLineType = {
	Addition: "ADDITION",
	Context: "CONTEXT",
	Deletion: "DELETION",
	Hunk: "HUNK",
	InjectedContext: "INJECTED_CONTEXT",
	Empty: "EMPTY"
};
var DiffLineTypeCharacter = {
	[DiffLineType.Addition]: "+",
	[DiffLineType.Deletion]: "-",
	[DiffLineType.Context]: " ",
	[DiffLineType.Hunk]: "@",
	[DiffLineType.InjectedContext]: "~"
};
var DiffFeature = {
	diffStats: "diffStats",
	expandLines: "expandLines",
	markAsViewed: "markAsViewed"
};
/**
* Escapes HTML special characters to prevent XSS
*/
function escapeHtml(text) {
	const map = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;",
		"'": "&#039;"
	};
	return text.replace(/[&<>"']/g, (m) => map[m] ?? m);
}
/**
* Parses a unified diff string into an array of StaticDiffLine objects
* for rendering with StaticUnifiedDiffPreview
*/
function parseUnifiedDiff(diffString) {
	const lines = diffString.split("\n");
	const diffLines = [];
	let leftLineNum = 0;
	let rightLineNum = 0;
	for (const line of lines) if (line.startsWith("@@")) {
		const match = line.match(/@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
		if (match && match[1] && match[2]) {
			leftLineNum = parseInt(match[1], 10);
			rightLineNum = parseInt(match[2], 10);
		}
		diffLines.push({
			type: DiffLineType.Hunk,
			left: null,
			right: null,
			html: escapeHtml(line),
			text: line
		});
	} else if (line.startsWith("+") && !line.startsWith("+++")) {
		const content = line.slice(1);
		diffLines.push({
			type: DiffLineType.Addition,
			left: null,
			right: rightLineNum++,
			html: escapeHtml(content),
			text: content
		});
	} else if (line.startsWith("-") && !line.startsWith("---")) {
		const content = line.slice(1);
		diffLines.push({
			type: DiffLineType.Deletion,
			left: leftLineNum++,
			right: null,
			html: escapeHtml(content),
			text: content
		});
	} else if (line.startsWith(" ")) {
		const content = line.slice(1);
		diffLines.push({
			type: DiffLineType.Context,
			left: leftLineNum++,
			right: rightLineNum++,
			html: escapeHtml(content),
			text: content
		});
	}
	return diffLines;
}
var StaticUnifiedDiffPreview_module_default = {
	HeaderContainer: "StaticUnifiedDiffPreview-module_fRNg3G_HeaderContainer",
	StaticDiffPreview: "StaticUnifiedDiffPreview-module_fRNg3G_StaticDiffPreview"
};
/**
* Renders a static representation of a unified diff
* Specifically for use in outdated threads, which return a slightly different set of difflines
*/
function StaticUnifiedDiffPreview({ diffLines, tabSize, className, diffTableClassName }) {
	if (!diffLines || diffLines.length < 1) return null;
	const lineWidth = getLineNumberWidth(diffLines);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(StaticUnifiedDiffPreview_module_default.StaticDiffPreview, className),
		children: /* @__PURE__ */ jsx(UnifiedDiffLines, {
			lineWidth,
			lines: diffLines,
			tabSize,
			className: diffTableClassName
		})
	});
}
StaticUnifiedDiffPreview.displayName = "StaticUnifiedDiffPreview";
var ToolProposeWork_module_default = {
	buttonsContainer: "ToolProposeWork-module_eJcbyW_buttonsContainer",
	container: "ToolProposeWork-module_eJcbyW_container",
	descriptionContainer: "ToolProposeWork-module_eJcbyW_descriptionContainer",
	startTaskButton: "ToolProposeWork-module_eJcbyW_startTaskButton",
	titleContainer: "ToolProposeWork-module_eJcbyW_titleContainer"
};
/**
* When we have an optimistic task causing overflow, limit to page size to prevent UI shift when the real task replaces it.
*/
function preventOptimisticOverflow(tasks) {
	if (tasks.length > 10) {
		if (tasks.some((task) => task.isOptimistic)) return tasks.slice(0, 10);
	}
	return tasks;
}
var repoTasksQueryKey = (owner, repo, currentUserId, page, archived) => [
	"repo-tasks",
	owner,
	repo,
	currentUserId,
	page,
	archived
];
function getFlatTaskList(data) {
	return data ? data[0] : void 0;
}
function setFlatTaskList(oldData, newList) {
	const hasNextPage = oldData ? oldData[1] : false;
	const taskCounts = oldData?.[2];
	return [
		preventOptimisticOverflow(newList),
		hasNextPage,
		taskCounts
	];
}
function NewRepoAgentTaskButton({ repository, currentUserId, currentUserLogin, icon, label = "New session", size, variant, tooltipDirection, eventType, initialText, maxTextareaHeight, isOpen: controlledIsOpen, onOpenChange, eventIdentifiers, decoupledModeEnabled }) {
	const [internalIsOpen, setInternalIsOpen] = useState(false);
	const buttonRef = useRef(null);
	const isControlled = controlledIsOpen !== void 0;
	const isOpen = isControlled ? controlledIsOpen : internalIsOpen;
	const handleOpen = useCallback(() => {
		if (isControlled) onOpenChange?.(true);
		else setInternalIsOpen(true);
	}, [isControlled, onOpenChange]);
	const handleClose = useCallback(() => {
		if (isControlled) onOpenChange?.(false);
		else setInternalIsOpen(false);
	}, [isControlled, onOpenChange]);
	const dialogTitle = `${label} in ${repository.ownerLogin}/${repository.name}`;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
		ref: buttonRef,
		icon,
		"aria-label": label,
		size,
		tooltipDirection,
		variant,
		onClick: handleOpen
	}), isOpen && /* @__PURE__ */ jsx(Dialog, {
		title: dialogTitle,
		onClose: handleClose,
		returnFocusRef: buttonRef,
		position: { narrow: "fullscreen" },
		children: /* @__PURE__ */ jsx(Dialog.Body, {
			className: "p-0",
			children: /* @__PURE__ */ jsx(NewRepoAgentTaskDialogContent, {
				repository,
				currentUserId,
				currentUserLogin,
				eventType,
				onClose: handleClose,
				initialText,
				maxTextareaHeight,
				eventIdentifiers,
				decoupledModeEnabled
			})
		})
	})] });
}
NewRepoAgentTaskButton.displayName = "NewRepoAgentTaskButton";
function NewRepoAgentTaskDialogContent({ repository, currentUserId, currentUserLogin, eventType, onClose, initialText, maxTextareaHeight, eventIdentifiers, decoupledModeEnabled }) {
	const [searchParams] = useSearchParams();
	const authorFilter = searchParams.get("author");
	const queryUserId = (currentUserLogin ? authorFilter === currentUserLogin : false) ? currentUserId : void 0;
	const { createTask } = useCreateAPITask({
		queryKey: repoTasksQueryKey(repository.ownerLogin, repository.name, queryUserId, 1, false),
		getFlatTaskList,
		setFlatTaskList,
		pageSize: 10,
		decoupledModeEnabled
	});
	const textAreaRef = useRef(null);
	useEffect(() => {
		textAreaRef.current?.focus();
	}, []);
	return /* @__PURE__ */ jsx(NewAgentTaskForm, {
		createTask: useCallback((params) => {
			createTask({
				...params,
				eventType,
				eventIdentifiers
			});
		}, [
			createTask,
			eventType,
			eventIdentifiers
		]),
		currentRepo: repository,
		onCreate: onClose,
		hideRepoSelector: true,
		eventType,
		showHeader: false,
		textAreaRef,
		initialText,
		maxTextareaHeight,
		isInPortal: true,
		decoupledModeEnabled
	});
}
NewRepoAgentTaskDialogContent.displayName = "NewRepoAgentTaskDialogContent";
function ToolProposeWork(t0) {
	const $ = c$1(24);
	const { title, description, type } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			queryKey: getAgentTasksQueryKeyForMutation(),
			pageSize: 10,
			getFlatTaskList: getFlatTaskList$1,
			setFlatTaskList: setFlatTaskList$1,
			decoupledModeEnabled: false
		};
		$[0] = t1;
	} else t1 = $[0];
	const { createTask, isCreating } = useCreateAPITask(t1);
	const { session, sessionNwo } = useSessionLogsContext();
	const { currentUser } = useCurrentUser$1();
	const [isStarted, setIsStarted] = useState(false);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	let t2;
	if ($[1] !== createTask || $[2] !== description || $[3] !== isCreating || $[4] !== isStarted || $[5] !== session || $[6] !== sessionNwo || $[7] !== title || $[8] !== type) {
		t2 = (e) => {
			e.preventDefault();
			e.stopPropagation();
			if (isStarted || isCreating) return;
			if (!sessionNwo) return;
			createTask({
				problemStatement: description,
				eventType: "propose_work",
				eventContent: `Proposed work: ${title}`,
				nwo: sessionNwo,
				createPullRequest: type === "code_change",
				eventIdentifiers: session?.workflow_run_id ? [session.workflow_run_id.toString()] : void 0
			});
			setIsStarted(true);
		};
		$[1] = createTask;
		$[2] = description;
		$[3] = isCreating;
		$[4] = isStarted;
		$[5] = session;
		$[6] = sessionNwo;
		$[7] = title;
		$[8] = type;
		$[9] = t2;
	} else t2 = $[9];
	const handleSubmit = t2;
	let t3;
	if ($[10] !== isDialogOpen) {
		t3 = (e_0) => {
			if (isDialogOpen) return;
			const target = e_0.target;
			if (target.closest("button") || target.closest("form") || target.closest("a") || target.closest("input")) return;
			setIsDialogOpen(true);
		};
		$[10] = isDialogOpen;
		$[11] = t3;
	} else t3 = $[11];
	const handleCardClick = t3;
	let t4;
	if ($[12] !== currentUser?.id || $[13] !== currentUser?.login || $[14] !== description || $[15] !== handleCardClick || $[16] !== handleSubmit || $[17] !== isCreating || $[18] !== isDialogOpen || $[19] !== isStarted || $[20] !== session || $[21] !== sessionNwo || $[22] !== title) {
		const [ownerLogin, repoName] = sessionNwo ? sessionNwo.split("/") : [null, null];
		const initialRepo = sessionNwo && repoName && ownerLogin && session?.repo_id ? {
			nameWithOwner: sessionNwo,
			name: repoName,
			ownerLogin,
			id: session.repo_id
		} : void 0;
		t4 = jsx(Fragment$1, { children: jsxs("div", {
			className: ToolProposeWork_module_default.container,
			onClick: handleCardClick,
			children: [jsxs("div", {
				className: ToolProposeWork_module_default.titleContainer,
				children: [jsx("h3", {
					className: "h4",
					children: title
				}), jsxs("div", {
					className: ToolProposeWork_module_default.buttonsContainer,
					children: [initialRepo && jsx(NewRepoAgentTaskButton, {
						icon: MaximizeIcon,
						label: "Edit task",
						repository: initialRepo,
						currentUserId: currentUser?.id,
						currentUserLogin: currentUser?.login,
						eventType: "propose_work",
						size: "small",
						variant: "invisible",
						initialText: description,
						maxTextareaHeight: 500,
						isOpen: isDialogOpen,
						onOpenChange: setIsDialogOpen,
						eventIdentifiers: session?.workflow_run_id ? [session.workflow_run_id.toString()] : void 0,
						decoupledModeEnabled: false
					}), jsx("form", {
						onSubmit: handleSubmit,
						className: ToolProposeWork_module_default.startTaskButton,
						children: jsx(StartTaskButton, {
							isCreating,
							isStarted
						})
					})]
				})]
			}), jsx("div", {
				className: ToolProposeWork_module_default.descriptionContainer,
				children: jsx(MarkdownRenderer, { markdown: description })
			})]
		}) });
		$[12] = currentUser?.id;
		$[13] = currentUser?.login;
		$[14] = description;
		$[15] = handleCardClick;
		$[16] = handleSubmit;
		$[17] = isCreating;
		$[18] = isDialogOpen;
		$[19] = isStarted;
		$[20] = session;
		$[21] = sessionNwo;
		$[22] = title;
		$[23] = t4;
	} else t4 = $[23];
	return t4;
}
ToolProposeWork.displayName = "ToolProposeWork";
function StartTaskButton(t0) {
	const $ = c$1(7);
	const { isCreating, isStarted } = t0;
	let t1;
	bb0: {
		if (isCreating) {
			let t2;
			if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
				t2 = ["Creating...", ButtonSpinner];
				$[0] = t2;
			} else t2 = $[0];
			t1 = t2;
			break bb0;
		}
		if (isStarted) {
			let t2;
			if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
				t2 = ["Task started", CheckCircleIcon];
				$[1] = t2;
			} else t2 = $[1];
			t1 = t2;
			break bb0;
		}
		let t2;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = ["Start task", PlayIcon];
			$[2] = t2;
		} else t2 = $[2];
		t1 = t2;
	}
	const [text, icon] = t1;
	const t2 = isCreating || isStarted;
	let t3;
	if ($[3] !== icon || $[4] !== t2 || $[5] !== text) {
		t3 = jsx(ButtonComponent$1, {
			type: "submit",
			leadingVisual: icon,
			inactive: t2,
			children: text
		});
		$[3] = icon;
		$[4] = t2;
		$[5] = text;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
StartTaskButton.displayName = "StartTaskButton";
function ButtonSpinner() {
	return /* @__PURE__ */ jsx(Spinner, {
		size: "small",
		srText: "Starting task…"
	});
}
ButtonSpinner.displayName = "ButtonSpinner";
var COLLAPSE_THRESHOLD = 20;
function DiffPreview(t0) {
	const $ = c$1(4);
	const { diffLines, canCollapse } = t0;
	const [isExpanded, setIsExpanded] = useState(false);
	const shouldCollapse = canCollapse && diffLines.length > COLLAPSE_THRESHOLD;
	let t1;
	if ($[0] !== diffLines || $[1] !== isExpanded || $[2] !== shouldCollapse) {
		t1 = jsxs(Fragment$1, { children: [jsx(StaticUnifiedDiffPreview, {
			diffLines: shouldCollapse && !isExpanded ? diffLines.slice(0, COLLAPSE_THRESHOLD) : diffLines,
			tabSize: 4,
			className: Tool_module_default.diffPreview
		}), shouldCollapse && jsx("button", {
			type: "button",
			className: Tool_module_default.diffPreviewFooter,
			onClick: () => setIsExpanded(!isExpanded),
			"aria-label": isExpanded ? "Collapse diff content" : `Expand diff to show all ${diffLines.length} lines`,
			"aria-expanded": isExpanded,
			children: isExpanded ? `Collapse ${diffLines.length - COLLAPSE_THRESHOLD} lines` : `Show all ${diffLines.length} lines`
		})] });
		$[0] = diffLines;
		$[1] = isExpanded;
		$[2] = shouldCollapse;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
DiffPreview.displayName = "DiffPreview";
var MAX_MARKDOWN_LENGTH = 1e5;
var TOOL_PREVIEW_HEIGHT_THRESHOLD = 475;
var wrapInCodeBlock = ({ language, markdown }) => {
	if (!markdown) return `~~~\nNothing to display\n~~~`;
	return `~~~${language}\n${markdown}\n~~~`;
};
/**
* Truncates markdown content to prevent the markdown parser from performance issues.
* Returns the truncated content and a flag indicating if truncation occurred.
* If truncation fails, returns the original markdown.
*/
function truncateMarkdownContent(markdown, maxLength = MAX_MARKDOWN_LENGTH) {
	if (!markdown || markdown.length <= maxLength) return { markdown };
	return { markdown: markdown.slice(0, maxLength) + `\n\n⚠️ **Output truncated**` };
}
var CODE_REVIEW_TITLE = "Review changes with Copilot code review";
var CODEQL_CHECKER_TITLE = "Run CodeQL security scan on changed files";
var PARALLEL_VALIDATION_TITLE = "Check changes with Copilot code review and CodeQL";
var SNIPPY_CUTOFF_DATE = /* @__PURE__ */ new Date("2026-02-11T22:00:00Z");
var TOOL_CALL_TITLES = {
	["playwright-browser_navigate"]: "Navigate Playwright web browser to a URL",
	["playwright-browser_navigate_back"]: "Navigate back in Playwright web browser",
	["playwright-browser_navigate_forward"]: "Navigate forward in Playwright web browser",
	["playwright-browser_click"]: "Click element in Playwright web browser",
	["playwright-browser_take_screenshot"]: "Take screenshot of Playwright web browser",
	["playwright-browser_type"]: "Type in Playwright web browser",
	["playwright-browser_wait_for"]: "Wait for text to appear/disappear in Playwright web browser",
	["playwright-browser_evaluate"]: "Run JavaScript in Playwright web browser",
	["playwright-browser_snapshot"]: "Take snapshot of page in Playwright web browser",
	["playwright-browser_resize"]: "Resize Playwright web browser window",
	["playwright-browser_close"]: "Close Playwright web browser",
	["playwright-browser_press_key"]: "Press key in Playwright web browser",
	["playwright-browser_select_option"]: "Select option in Playwright web browser",
	["playwright-browser_handle_dialog"]: "Interact with dialog in Playwright web browser",
	["playwright-browser_console_messages"]: "Get console messages from Playwright web browser",
	["playwright-browser_drag"]: "Drag mouse between elements in Playwright web browser",
	["playwright-browser_file_upload"]: "Upload file in Playwright web browser",
	["playwright-browser_hover"]: "Hover mouse over element in Playwright web browser",
	["playwright-browser_network_requests"]: "Get network requests from Playwright web browser",
	["github-mcp-server-get_file_contents"]: "Get file contents from GitHub",
	["github-mcp-server-get_pull_request"]: "Get pull request from GitHub",
	["github-mcp-server-get_issue"]: "Get issue from GitHub",
	["github-mcp-server-get_pull_request_files"]: "Get pull request changed files from GitHub",
	["github-mcp-server-list_pull_requests"]: "List pull requests on GitHub",
	["github-mcp-server-list_branches"]: "List branches on GitHub",
	["github-mcp-server-get_pull_request_diff"]: "Get pull request diff from GitHub",
	["github-mcp-server-get_pull_request_comments"]: "Get pull request comments from GitHub",
	["github-mcp-server-get_commit"]: "Get commit from GitHub",
	["github-mcp-server-search_repositories"]: "Search repositories on GitHub",
	["github-mcp-server-search_code"]: "Search code on GitHub",
	["github-mcp-server-get_issue_comments"]: "Get issue comments from GitHub",
	["github-mcp-server-list_issues"]: "List issues on GitHub",
	["github-mcp-server-search_pull_requests"]: "Search pull requests on GitHub",
	["github-mcp-server-list_commits"]: "List commits on GitHub",
	["github-mcp-server-get_pull_request_status"]: "Get pull request status from GitHub",
	["github-mcp-server-search_issues"]: "Search issues on GitHub",
	["github-mcp-server-get_pull_request_reviews"]: "Get pull request reviews from GitHub",
	["github-mcp-server-download_workflow_run_artifact"]: "Download GitHub Actions workflow run artifact",
	["github-mcp-server-get_job_logs"]: "Get GitHub Actions job logs",
	["github-mcp-server-get_workflow_run"]: "Get GitHub Actions workflow run",
	["github-mcp-server-get_workflow_run_logs"]: "Get GitHub Actions workflow run logs",
	["github-mcp-server-get_workflow_run_usage"]: "Get GitHub Actions workflow usage",
	["github-mcp-server-list_workflow_jobs"]: "List GitHub Actions workflow jobs",
	["github-mcp-server-list_workflow_run_artifacts"]: "List GitHub Actions workflow run artifacts",
	["github-mcp-server-list_workflow_runs"]: "List GitHub Actions workflow runs",
	["github-mcp-server-list_workflows"]: "List GitHub Actions workflows",
	["gh-advisory-database"]: "Check new dependencies against the GitHub Advisory Database",
	["codeql_checker"]: CODEQL_CHECKER_TITLE,
	["code_review"]: CODE_REVIEW_TITLE,
	["store_memory"]: "Store memory"
};
/**
* Creates tool header props with optional trailing visual for code insights indicator.
* Code insights indicator is gated behind copilot_agent_snippy flag.
*/
function createToolHeaderProps(baseProps, metadata, shouldShowCodeInsights) {
	if (shouldShowCodeInsights) {
		const codeInsights = metadata?.["code-insights"];
		if (codeInsights && codeInsights.publicCodeReferences.length > 0) return {
			...baseProps,
			trailingVisual: /* @__PURE__ */ jsx(CodeInsightsIndicator, { insights: codeInsights })
		};
	}
	return baseProps;
}
function ToolRenderer(t0) {
	const $ = c$1(4);
	const { name, delta, args, mcpToolNameMappings, isInGroup, isEditGroup, metadata } = t0;
	const isSnippyEnabled = isFeatureEnabled("copilot_agent_snippy");
	const isSnippyTimeFilteringEnabled = isFeatureEnabled("copilot_agent_snippy_time_filter");
	const { session } = useSessionLogsContext();
	let shouldShowCodeInsights;
	if (isSnippyTimeFilteringEnabled) shouldShowCodeInsights = isSnippyEnabled && session?.created_at !== void 0 && new Date(session.created_at) >= SNIPPY_CUTOFF_DATE;
	else shouldShowCodeInsights = isSnippyEnabled;
	const toolIcon = isInGroup ? void 0 : getToolIcon(name, mcpToolNameMappings);
	bb0: switch (name) {
		case TOOL_NAMES.BASH: {
			const bashArgs = args;
			const input_7 = `$ ${bashArgs.command}`;
			const title_14 = isInGroup ? bashArgs.description || bashArgs.command : bashArgs.description ? `${bashArgs.description}` : "Run Bash command";
			const { isError: isError_30, content: output_29 } = parseContent(delta.content);
			const isPending_23 = output_29 === void 0;
			return jsx(Tool, {
				title: title_14,
				isError: isError_30,
				isPending: isPending_23,
				hasPreview: false,
				isInGroup: false,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: bashArgs.command?.startsWith("git diff") ? "diff" : "bash",
					markdown: `${input_7}${output_29 ? `\n${output_29}` : ""}`,
					shellLoading: isPending_23
				})
			});
		}
		case TOOL_NAMES.WEB_SEARCH:
		case TOOL_NAMES.GITHUB_MCP_SERVER_WEB_SEARCH:
		case TOOL_NAMES.GITHUB_MCP_SERVER_BING_SEARCH: {
			const title_13 = `Web Search: ${args.query}`;
			const { isError: isError_29, content: output_28 } = parseContent(delta.content);
			return jsx(Tool, {
				title: title_13,
				isError: isError_29,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "json",
					markdown: output_28
				})
			});
		}
		case TOOL_NAMES.WEB_FETCH: {
			const title_12 = `Web Fetch: ${args.url}`;
			const { isError: isError_28, content: output_27 } = parseContent(delta.content);
			return jsx(Tool, {
				title: title_12,
				isError: isError_28,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "json",
					markdown: output_27
				})
			});
		}
		case TOOL_NAMES.WRITE_BASH: {
			const writeBashArgs = args;
			const input_6 = `$ ${writeBashArgs.input}`;
			const { isError: isError_27, content: output_26 } = parseContent(delta.content);
			const isPending_22 = output_26 === void 0;
			return jsx(Tool, {
				title: `Send input to Bash session ${writeBashArgs.shellId || writeBashArgs.sessionId}`,
				isError: isError_27,
				isPending: isPending_22,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: `${input_6}${output_26 ? `\n${output_26}` : ""}`,
					shellLoading: isPending_22
				})
			});
		}
		case TOOL_NAMES.READ_BASH: {
			const readBashArgs = args;
			const { isError: isError_26, content: output_25 } = parseContent(delta.content);
			const isPending_21 = output_25 === void 0;
			return jsx(Tool, {
				title: `Read logs from Bash session ${readBashArgs.shellId || readBashArgs.sessionId}`,
				isError: isError_26,
				isPending: isPending_21,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: output_25 ? `\n${output_25}` : void 0,
					shellLoading: isPending_21
				})
			});
		}
		case TOOL_NAMES.STOP_BASH: {
			const stopBashArgs = args;
			const { isError: isError_25, content: output_24 } = parseContent(delta.content);
			const isPending_20 = output_24 === void 0;
			return jsx(Tool, {
				title: `Stop Bash session ${stopBashArgs.shellId || stopBashArgs.sessionId}`,
				isError: isError_25,
				isPending: isPending_20,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: output_24,
					shellLoading: isPending_20
				})
			});
		}
		case TOOL_NAMES.POWERSHELL: {
			const powershellArgs = args;
			const input_5 = `PS> ${powershellArgs.command}`;
			const title_11 = isInGroup ? powershellArgs.description || powershellArgs.command : powershellArgs.description ? `${powershellArgs.description}` : "Run PowerShell command";
			const { isError: isError_24, content: output_23 } = parseContent(delta.content);
			const isPending_19 = output_23 === void 0;
			return jsx(Tool, {
				title: title_11,
				isError: isError_24,
				isPending: isPending_19,
				hasPreview: false,
				isInGroup: false,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: powershellArgs.command?.startsWith("git diff") ? "diff" : "powershell",
					markdown: `${input_5}${output_23 ? `\n${output_23}` : ""}`,
					shellLoading: isPending_19
				})
			});
		}
		case TOOL_NAMES.WRITE_POWERSHELL: {
			const writePowershellArgs = args;
			const input_4 = `PS> ${writePowershellArgs.input}`;
			const { isError: isError_23, content: output_22 } = parseContent(delta.content);
			const isPending_18 = output_22 === void 0;
			return jsx(Tool, {
				title: `Send input to PowerShell session ${writePowershellArgs.shellId || writePowershellArgs.sessionId}`,
				isError: isError_23,
				isPending: isPending_18,
				isInGroup,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: "powershell",
					markdown: `${input_4}${output_22 ? `\n${output_22}` : ""}`,
					shellLoading: isPending_18
				})
			});
		}
		case TOOL_NAMES.READ_POWERSHELL: {
			const readPowershellArgs = args;
			const { isError: isError_22, content: output_21 } = parseContent(delta.content);
			const isPending_17 = output_21 === void 0;
			return jsx(Tool, {
				title: `Read logs from PowerShell session ${readPowershellArgs.shellId || readPowershellArgs.sessionId}`,
				isError: isError_22,
				isPending: isPending_17,
				isInGroup,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: "powershell",
					markdown: output_21 ? `\n${output_21}` : void 0,
					shellLoading: isPending_17
				})
			});
		}
		case TOOL_NAMES.STOP_POWERSHELL: {
			const stopPowershellArgs = args;
			const { isError: isError_21, content: output_20 } = parseContent(delta.content);
			const isPending_16 = output_20 === void 0;
			return jsx(Tool, {
				title: `Stop PowerShell session ${stopPowershellArgs.shellId || stopPowershellArgs.sessionId}`,
				isError: isError_21,
				isPending: isPending_16,
				isInGroup,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: "powershell",
					markdown: output_20 ? output_20 : "",
					shellLoading: isPending_16
				})
			});
		}
		case TOOL_NAMES.LIST_POWERSHELL: {
			const { isError: isError_20, content: output_19 } = parseContent(delta.content);
			const isPending_15 = output_19 === void 0;
			return jsx(Tool, {
				title: "List PowerShell sessions",
				isError: isError_20,
				isPending: isPending_15,
				isInGroup,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: "powershell",
					markdown: output_19 ? output_19 : "",
					shellLoading: isPending_15
				})
			});
		}
		case TOOL_NAMES.THINK: {
			const { isError: isError_19, content: output_18 } = parseContent(args.thought);
			return jsx(Tool, {
				title: "Thought",
				isError: isError_19,
				hasPreview: true,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: output_18
				})
			});
		}
		case TOOL_NAMES.SKILL: {
			const skillArgs = args;
			const { isError: isError_18, content: output_17 } = parseContent(delta.content);
			return jsx(Tool, {
				title: isInGroup ? skillArgs.skill : `Activate ${skillArgs.skill} skill`,
				isError: isError_18,
				isPending: output_17 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: output_17
				})
			});
		}
		case TOOL_NAMES.RUN_CUSTOM_SETUP_STEP: {
			const runCustomSetupStepArgs = args;
			const { isError: isError_17, content: output_16 } = parseContent(delta.content);
			const title_9 = isInGroup ? runCustomSetupStepArgs.name?.trim() || "Custom setup step" : !runCustomSetupStepArgs.name?.trim() ? "Run custom setup step" : `Run "${runCustomSetupStepArgs.name.trim()}" custom setup step`;
			const isPending_13 = output_16 === void 0;
			return jsx(Tool, {
				title: title_9,
				isError: isError_17,
				isPending: isPending_13,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "console",
					markdown: output_16,
					shellLoading: isPending_13
				})
			});
		}
		case TOOL_NAMES.RUN_SETUP: {
			const runSetupArgs = args;
			const { isError: isError_16, content: output_15 } = parseContent(delta.content);
			const title_8 = runSetupArgs.name.trim();
			const isPending_12 = output_15 === void 0;
			return jsx(Tool, {
				title: title_8,
				isError: isError_16,
				isPending: isPending_12,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "console",
					markdown: output_15,
					shellLoading: isPending_12
				})
			});
		}
		case TOOL_NAMES.STR_REPLACE_EDITOR:
		case TOOL_NAMES.CREATE:
		case TOOL_NAMES.STR_REPLACE:
		case TOOL_NAMES.EDIT:
		case TOOL_NAMES.VIEW: {
			const strReplaceEditorArgs = args;
			const command = name === TOOL_NAMES.EDIT ? "str_replace" : strReplaceEditorArgs.command || name;
			const editToolIcon = isInGroup ? void 0 : getToolIcon(command);
			const fileExtension = strReplaceEditorArgs.path?.split(".").pop() || "";
			const language = fileExtension === "md" ? "markdown" : fileExtension || "text";
			const { isError: isError_15, content: parsedContent } = parseContent(delta.content);
			switch (command) {
				case "insert":
				case "undo_edit": {
					const filePath_1 = trimFileName(strReplaceEditorArgs.path);
					const displayPath_0 = filePath_1 + getPathSuffix(command, strReplaceEditorArgs.view_range, strReplaceEditorArgs.insert_line);
					const output_14 = extractContentFromDiff(parsedContent);
					return jsx(Tool, {
						title: getCommandTitle({
							command,
							path: strReplaceEditorArgs.path,
							isInGroup
						}),
						isError: isError_15,
						path: filePath_1 ? displayPath_0 : void 0,
						hasPreview: !isInGroup,
						isInGroup,
						toolHeaderProps: createToolHeaderProps({ leadingVisual: editToolIcon }, metadata, shouldShowCodeInsights),
						children: jsx(ToolPrimaryContent, {
							language,
							markdown: output_14
						})
					});
				}
				case "create":
				case "view":
				case "str_replace": {
					const output_13 = parsedContent?.trim();
					const isViewCommand = command === "view";
					const filePath_0 = trimFileName(strReplaceEditorArgs.path);
					const displayPath = isViewCommand ? filePath_0 + getPathSuffix(command, strReplaceEditorArgs.view_range, strReplaceEditorArgs.insert_line) : filePath_0;
					const shouldStartOpen = isInGroup ? isEditGroup ?? false : !isViewCommand;
					if (output_13) {
						const diffLines_1 = parseUnifiedDiff(output_13);
						if (diffLines_1.length > 0) {
							const canCollapse = !isViewCommand;
							const diffContainerClassName = isViewCommand ? Tool_module_default.viewDiffContainer : command === "create" ? Tool_module_default.createDiffContainer : void 0;
							return jsx(Tool, {
								title: getCommandTitle({
									command,
									path: strReplaceEditorArgs.path,
									isInGroup
								}),
								isError: isError_15,
								path: filePath_0 ? displayPath : void 0,
								hasPreview: false,
								isInGroup,
								isOpenOverride: shouldStartOpen,
								toolHeaderProps: createToolHeaderProps({ leadingVisual: editToolIcon }, metadata, shouldShowCodeInsights),
								children: jsx("div", {
									className: diffContainerClassName,
									children: jsx(DiffPreview, {
										diffLines: diffLines_1,
										canCollapse
									})
								})
							});
						}
					}
					return jsx(Tool, {
						title: getCommandTitle({
							command,
							path: strReplaceEditorArgs.path,
							isInGroup
						}),
						isError: isError_15,
						path: filePath_0 ? displayPath : void 0,
						hasPreview: !isInGroup && !isViewCommand,
						isInGroup,
						isOpenOverride: shouldStartOpen,
						toolHeaderProps: createToolHeaderProps({ leadingVisual: editToolIcon }, metadata, shouldShowCodeInsights),
						children: jsx(ToolPrimaryContent, {
							language: isViewCommand ? language : "diff",
							markdown: output_13
						})
					});
				}
			}
			break bb0;
		}
		case TOOL_NAMES.REPORT_PROGRESS: {
			const reportProgressArgs = args;
			const { isError: outputError_0, content: output_12 } = parseContent(delta.content);
			if ("prDescription" in reportProgressArgs) {
				const { isError: inputError, content: input_3 } = parseContent(reportProgressArgs.prDescription);
				let t1;
				if ($[0] !== reportProgressArgs.commitMessage) {
					t1 = reportProgressArgs.commitMessage?.split("\n")[0] || reportProgressArgs.commitMessage || "";
					$[0] = reportProgressArgs.commitMessage;
					$[1] = t1;
				} else t1 = $[1];
				const firstLineOfCommitMessage_0 = t1;
				return jsxs(Tool, {
					title: firstLineOfCommitMessage_0 ? `Progress update: ${firstLineOfCommitMessage_0}` : "Progress update",
					isError: inputError || outputError_0,
					isInGroup,
					toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
					children: [jsx(ToolPrimaryContent, {
						language: "markdown",
						markdown: input_3
					}), jsx(ToolSecondaryContent, {
						type: "output",
						language: "json",
						markdown: output_12
					})]
				});
			} else return jsx(Tool, {
				title: `Start next task: ${reportProgressArgs.nextTask}`,
				isError: outputError_0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: reportProgressArgs.tasksChecklist
				})
			});
		}
		case TOOL_NAMES.COMMIT_CHANGES: {
			const commitChangesArgs = args;
			const { isError: outputError, content: output_11 } = parseContent(delta.content);
			let t1;
			if ($[2] !== commitChangesArgs.commitMessage) {
				t1 = commitChangesArgs.commitMessage?.split("\n")[0] || commitChangesArgs.commitMessage || "";
				$[2] = commitChangesArgs.commitMessage;
				$[3] = t1;
			} else t1 = $[3];
			const firstLineOfCommitMessage = t1;
			return jsx(Tool, {
				title: firstLineOfCommitMessage ? `Commit changes: ${firstLineOfCommitMessage}` : "Commit changes",
				isError: outputError,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolSecondaryContent, {
					type: "output",
					language: "json",
					markdown: output_11
				})
			});
		}
		case TOOL_NAMES.REPLY_TO_COMMENT: {
			const { isError: isError_14, content: output_10 } = parseContent(args.reply);
			return jsx(Tool, {
				title: "Reply to comment",
				isError: isError_14,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: output_10
				})
			});
		}
		case TOOL_NAMES.ASYNC_BASH: {
			const asyncBashArgs = args;
			const input_2 = `$ ${asyncBashArgs.command}`;
			const { isError: isError_13, content: output_9 } = parseContent(delta.content);
			const isPending_11 = output_9 === void 0;
			return jsx(Tool, {
				title: `Start or send input to long-running Bash session ${asyncBashArgs.shellId || asyncBashArgs.sessionId}`,
				isError: isError_13,
				isPending: isPending_11,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: `${input_2}${output_9 ? `\n${output_9}` : ""}`,
					shellLoading: isPending_11
				})
			});
		}
		case TOOL_NAMES.READ_ASYNC_BASH: {
			const readAsyncBashArgs = args;
			const { isError: isError_12, content: output_8 } = parseContent(delta.content);
			const isPending_10 = output_8 === void 0;
			return jsx(Tool, {
				title: `View logs from long-running Bash session ${readAsyncBashArgs.shellId || readAsyncBashArgs.sessionId}`,
				isError: isError_12,
				isPending: isPending_10,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: output_8,
					shellLoading: isPending_10
				})
			});
		}
		case TOOL_NAMES.STOP_ASYNC_BASH: {
			const stopAsyncBashArgs = args;
			const { isError: isError_11, content: output_7 } = parseContent(delta.content);
			const isPending_9 = output_7 === void 0;
			return jsx(Tool, {
				title: `Stop long-running Bash session ${stopAsyncBashArgs.shellId || stopAsyncBashArgs.sessionId}`,
				isError: isError_11,
				isPending: isPending_9,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: output_7,
					shellLoading: isPending_9
				})
			});
		}
		case TOOL_NAMES.LIST_BASH: {
			const { isError: isError_10, content: output_6 } = parseContent(delta.content);
			const isPending_8 = output_6 === void 0;
			return jsx(Tool, {
				title: "List Bash sessions",
				isError: isError_10,
				isPending: isPending_8,
				isInGroup,
				toolHeaderProps: { leadingVisual: toolIcon },
				children: jsx(ToolPrimaryContent, {
					language: "bash",
					markdown: output_6 ? output_6 : "",
					shellLoading: isPending_8
				})
			});
		}
		case TOOL_NAMES.RG:
		case TOOL_NAMES.GREP: {
			const grepArgs = args ?? {};
			const { isError: isError_9, content: output_5 } = parseContent(delta.content);
			const isPending_7 = output_5 === void 0;
			const title_7 = isInGroup ? "" : "Search";
			const pattern_0 = grepArgs.pattern;
			return jsx(Tool, {
				title: title_7,
				isError: isError_9,
				isPending: isPending_7,
				path: pattern_0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(GrepOutput, { output: output_5 })
			});
		}
		case TOOL_NAMES.GLOB: {
			const globArgs = args ?? {};
			const { isError: isError_8, content: output_4 } = parseContent(delta.content);
			const isPending_6 = output_4 === void 0;
			const title_6 = isInGroup ? "" : "Find files";
			const pattern = globArgs.pattern;
			return jsx(Tool, {
				title: title_6,
				isError: isError_8,
				isPending: isPending_6,
				path: pattern,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(GlobOutput, { output: output_4 })
			});
		}
		case TOOL_NAMES.SEARCH_CODE_SUBAGENT: {
			const searchCodeArgs = args ?? {};
			const { isError: isError_7, content: output_3 } = parseContent(delta.content);
			const isPending_5 = output_3 === void 0;
			const query = searchCodeArgs.query ?? "";
			return jsx(Tool, {
				title: isInGroup ? query : `Search code: ${query}`,
				isError: isError_7,
				isPending: isPending_5,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: output_3
				})
			});
		}
		case TOOL_NAMES.APPLY_PATCH: {
			const { isError: isError_6, content: output_2 } = parseContent(delta.content);
			const patchText = (typeof args === "string" ? args : args?.arguments ?? args?.content ?? args?.patch) ?? "";
			const operations = parseApplyPatch(patchText);
			const renderOperationContent = (op) => {
				const path = trimFileName(op.path) ?? "unknown file";
				switch (op.type) {
					case "add": {
						const content_5 = op.lines.map(_temp$30).join("\n");
						const fauxDiff = [
							`diff --git a/${path} b/${path}`,
							"new file mode 100644",
							"--- /dev/null",
							`+++ b/${path}`,
							"@@ @@",
							...content_5.split("\n").map(_temp2$11)
						].join("\n");
						const diffLines_0 = parseUnifiedDiff(fauxDiff).map(_temp3$5);
						if (diffLines_0.length > 0) return jsx(StaticUnifiedDiffPreview, {
							diffLines: diffLines_0,
							tabSize: 4,
							className: Tool_module_default.diffPreview
						});
						return jsx(ToolPrimaryContent, {
							language: "diff",
							markdown: fauxDiff
						});
					}
					case "delete": return jsx(ToolPrimaryContent, {
						language: "text",
						markdown: "File deleted"
					});
					case "update": {
						const unifiedDiff = convertPatchToUnifiedDiff(op);
						if (unifiedDiff) {
							const diffLines = parseUnifiedDiff(unifiedDiff).map(_temp4$4);
							if (diffLines.length > 0) return jsx(StaticUnifiedDiffPreview, {
								diffLines,
								tabSize: 4,
								className: Tool_module_default.diffPreview
							});
						}
						return jsx(ToolPrimaryContent, {
							language: "diff",
							markdown: unifiedDiff || output_2
						});
					}
					default: return jsx(ToolPrimaryContent, {
						language: "text",
						markdown: output_2
					});
				}
			};
			const getOperationAction = _temp5$2;
			const getOperationPath = _temp6$1;
			const renderOperations = () => {
				if (operations.length === 0) return jsx(ToolPrimaryContent, {
					language: "text",
					markdown: patchText || output_2
				});
				if (operations.length === 1) {
					const op_2 = operations[0];
					if (!op_2) return jsx(ToolPrimaryContent, {
						language: "text",
						markdown: patchText || output_2
					});
					return jsxs("div", {
						className: "border-top tmp-px-3 py-2",
						children: [op_2.type === "update" && op_2.newPath && jsxs("span", {
							className: "d-block fgColor-muted mb-2",
							style: { fontSize: "12px" },
							children: ["Renamed from ", trimFileName(op_2.path)]
						}), renderOperationContent(op_2)]
					});
				}
				return operations.map((op_3) => jsxs("div", {
					className: "border-top tmp-px-3 py-2",
					children: [jsxs(Text$1, {
						as: "div",
						weight: "semibold",
						className: "mb-2",
						children: [
							getOperationAction(op_3),
							" ",
							jsx("span", {
								className: "fgColor-muted",
								children: getOperationPath(op_3)
							}),
							op_3.type === "update" && op_3.newPath && jsxs("span", {
								className: "fgColor-muted",
								style: { fontSize: "12px" },
								children: [
									" ",
									"(from ",
									trimFileName(op_3.path),
									")"
								]
							})
						]
					}), renderOperationContent(op_3)]
				}, `${op_3.type}-${op_3.path}-${op_3.newPath ?? ""}`));
			};
			let title_4 = "Edit File(s)";
			let filePath;
			if (operations.length === 1) {
				const firstOp = operations[0];
				if (firstOp) {
					title_4 = isInGroup ? "" : getOperationAction(firstOp) ?? "Edit File(s)";
					filePath = getOperationPath(firstOp);
				}
			}
			return jsx(Tool, {
				title: title_4,
				isError: isError_6,
				path: filePath,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: renderOperations()
			});
		}
		case TOOL_NAMES.CODE_REVIEW: {
			const { isError: isError_5, content: content_4 } = parseContent(delta.content);
			return jsx(Tool, {
				title: CODE_REVIEW_TITLE,
				isError: isError_5,
				isPending: content_4 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: content_4
				})
			});
		}
		case TOOL_NAMES.PROPOSE_WORK: {
			const proposeWorkArgs = args;
			const { isError: isError_4 } = parseContent(delta.content);
			return jsx(Tool, {
				title: isInGroup ? proposeWorkArgs.workTitle : `Propose Work: ${proposeWorkArgs.workTitle}`,
				isError: isError_4,
				hasPreview: false,
				isInGroup,
				isOpenOverride: true,
				toolHeaderProps: isInGroup ? void 0 : { leadingVisual: getToolIcon(name) },
				children: jsx(ToolProposeWork, {
					title: proposeWorkArgs.workTitle,
					description: proposeWorkArgs.workDescription,
					type: proposeWorkArgs.workType
				})
			});
		}
		case TOOL_NAMES.CODEQL_CHECKER: {
			const { isError: isError_3, content: content_3 } = parseContent(delta.content);
			return jsx(Tool, {
				title: CODEQL_CHECKER_TITLE,
				isError: isError_3,
				isPending: content_3 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: content_3
				})
			});
		}
		case TOOL_NAMES.PARALLEL_VALIDATION: {
			const { isError: isError_2, content: content_2 } = parseContent(delta.content);
			return jsx(Tool, {
				title: PARALLEL_VALIDATION_TITLE,
				isError: isError_2,
				isPending: content_2 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: jsx(ToolPrimaryContent, {
					language: "markdown",
					markdown: content_2
				})
			});
		}
		case TOOL_NAMES.TASK: {
			if (isFeatureEnabled("copilot_mission_control_decoupled_mode")) return null;
			const taskArgs = args;
			const { isError: isError_1, content: content_1 } = parseContent(delta.content);
			const { language: outputLanguage_1, output: output_1 } = parseGenericToolOutput(content_1);
			const inputObj_0 = args ?? {};
			const input_1 = Object.keys(inputObj_0).length === 0 ? null : JSON.stringify(inputObj_0, null, 2);
			return jsxs(Tool, {
				title: `Call to subagent ${taskArgs.agent_type}`,
				isError: isError_1,
				isPending: output_1 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: [input_1 && jsx(ToolSecondaryContent, {
					type: "input",
					language: "json",
					markdown: input_1
				}), jsx(ToolPrimaryContent, {
					language: outputLanguage_1,
					markdown: output_1
				})]
			});
		}
		case TOOL_NAMES.CREATE_PULL_REQUEST: {
			const createPullRequestArgs = args;
			const { isError: isError_0, content: content_0 } = parseContent(delta.content);
			const { language: outputLanguage_0, output: output_0 } = parseGenericToolOutput(content_0);
			const input_0 = Object.keys(createPullRequestArgs).length === 0 ? null : JSON.stringify(createPullRequestArgs, null, 2);
			const prefix = createPullRequestArgs.draft ? "Create draft pull request" : "Create pull request";
			return jsxs(Tool, {
				title: createPullRequestArgs.title ? `${prefix}: ${createPullRequestArgs.title}` : prefix,
				isError: isError_0,
				isPending: output_0 === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: [input_0 && jsx(ToolSecondaryContent, {
					type: "input",
					language: "json",
					markdown: input_0
				}), jsx(ToolPrimaryContent, {
					language: outputLanguage_0,
					markdown: output_0
				})]
			});
		}
		default: {
			const { isError, content } = parseContent(delta.content);
			const { language: outputLanguage, output } = parseGenericToolOutput(content);
			const inputObj = args ?? {};
			const input = Object.keys(inputObj).length === 0 ? null : JSON.stringify(inputObj, null, 2);
			const displayName = mcpToolNameMappings?.[name] || name;
			return jsxs(Tool, {
				title: TOOL_CALL_TITLES[name] || `Call to ${displayName}`,
				isError,
				isPending: output === void 0,
				isInGroup,
				toolHeaderProps: createToolHeaderProps({ leadingVisual: toolIcon }, metadata, shouldShowCodeInsights),
				children: [input && jsx(ToolSecondaryContent, {
					type: "input",
					language: "json",
					markdown: input
				}), jsx(ToolPrimaryContent, {
					language: outputLanguage,
					markdown: output
				})]
			});
		}
	}
}
ToolRenderer.displayName = "ToolRenderer";
function _temp6$1(op_1) {
	if (!op_1) return;
	const path_0 = trimFileName(op_1.path);
	if (op_1.type === "update" && op_1.newPath) return trimFileName(op_1.newPath);
	return path_0;
}
function _temp5$2(op_0) {
	if (!op_0) return;
	switch (op_0.type) {
		case "add": return "Create";
		case "delete": return "Delete";
		case "update": return "Edit";
		default: return `Apply patch (${op_0.type ?? "unknown"})`;
	}
}
function _temp4$4(line) {
	return {
		...line,
		left: null,
		right: null
	};
}
function _temp3$5(line_2) {
	return {
		...line_2,
		left: null,
		right: null
	};
}
function _temp2$11(line_1) {
	return `+${line_1}`;
}
function _temp$30(line_0) {
	return line_0.startsWith("+") ? line_0.slice(1) : line_0;
}
var parseGenericToolOutput = (content) => {
	if (typeof content === "undefined") return {
		language: "text",
		output: content
	};
	try {
		const parsedOutput = JSON.parse(content);
		return {
			language: "json",
			output: JSON.stringify(parsedOutput, null, 2)
		};
	} catch {
		return {
			language: "text",
			output: content
		};
	}
};
function shouldWrapInCodeBlock(language) {
	return !(language === "markdown" || language === "text" || language === "");
}
function parseApplyPatch(patchText) {
	const lines = patchText.split(/\r?\n/);
	const operations = [];
	let inPatch = false;
	let currentOp = null;
	const pushCurrent = () => {
		if (currentOp) {
			operations.push(currentOp);
			currentOp = null;
		}
	};
	for (const line of lines) {
		if (line.startsWith("*** Begin Patch")) {
			inPatch = true;
			continue;
		}
		if (!inPatch) continue;
		if (line.startsWith("*** End Patch")) {
			pushCurrent();
			break;
		}
		if (line.startsWith("*** Add File: ")) {
			pushCurrent();
			currentOp = {
				type: "add",
				path: line.replace("*** Add File: ", "").trim(),
				lines: []
			};
			continue;
		}
		if (line.startsWith("*** Delete File: ")) {
			pushCurrent();
			currentOp = {
				type: "delete",
				path: line.replace("*** Delete File: ", "").trim()
			};
			continue;
		}
		if (line.startsWith("*** Update File: ")) {
			pushCurrent();
			currentOp = {
				type: "update",
				path: line.replace("*** Update File: ", "").trim(),
				lines: []
			};
			continue;
		}
		if (line.startsWith("*** Move to: ") && currentOp && currentOp.type === "update") {
			currentOp.newPath = line.replace("*** Move to: ", "").trim();
			continue;
		}
		if (currentOp && "lines" in currentOp) currentOp.lines.push(line);
	}
	return operations;
}
/**
* Converts the custom patch format lines to unified diff format
*/
function convertPatchToUnifiedDiff(op) {
	if (!op.lines || op.lines.length === 0) return "";
	const path = op.path;
	const newPath = op.newPath || path;
	const lines = [];
	lines.push(`diff --git a/${path} b/${newPath}`);
	lines.push(`--- a/${path}`);
	lines.push(`+++ b/${newPath}`);
	lines.push("@@ @@");
	for (const line of op.lines) {
		if (line.startsWith("@@")) continue;
		if (line.startsWith("+") || line.startsWith("-") || line.startsWith(" ")) lines.push(line);
		else lines.push(` ${line}`);
	}
	return lines.join("\n");
}
function Tool({ title, isError = false, isPending = false, path, hasPreview = false, collapseLargeContent = false, toolHeaderProps, children, isOpenOverride, isInGroup = false, footer }) {
	const { variant } = useSessionLogsContext();
	const hasUserToggledRef = useRef(false);
	const [isToolContentOpen, setIsToolContentOpen] = useState(isOpenOverride ?? false);
	const prevIsOpenOverrideRef = useRef(isOpenOverride);
	const contentRef = useRef(null);
	const [shouldShowPreview, setShouldShowPreview] = useState(hasPreview);
	useEffect(() => {
		if (prevIsOpenOverrideRef.current !== isOpenOverride) {
			prevIsOpenOverrideRef.current = isOpenOverride;
			if (!hasUserToggledRef.current && isOpenOverride !== void 0) setIsToolContentOpen(isOpenOverride);
		}
	}, [isOpenOverride]);
	useEffect(() => {
		if (!hasPreview || !contentRef.current) {
			setShouldShowPreview(hasPreview);
			return;
		}
		if (contentRef.current.scrollHeight < TOOL_PREVIEW_HEIGHT_THRESHOLD) {
			setShouldShowPreview(false);
			if (!hasUserToggledRef.current) setIsToolContentOpen(true);
		} else {
			setShouldShowPreview(!collapseLargeContent);
			if (collapseLargeContent && !hasUserToggledRef.current) setIsToolContentOpen(false);
		}
	}, [hasPreview, collapseLargeContent]);
	const toolInstanceRef = useRef({});
	const handlerRef = useRef(null);
	handlerRef.current = (event) => {
		const customEvent = event;
		if (customEvent.detail.excludeInstance !== toolInstanceRef.current) {
			const shouldExpand = customEvent.detail.expand;
			setIsToolContentOpen(shouldExpand);
		}
	};
	useEffect(() => {
		const handler = (event_0) => {
			handlerRef.current?.(event_0);
		};
		document.addEventListener("mission-control-tool-global-toggle", handler);
		return () => {
			document.removeEventListener("mission-control-tool-global-toggle", handler);
		};
	}, []);
	const handleToggle = () => {
		hasUserToggledRef.current = true;
		setIsToolContentOpen((prev) => {
			return !prev;
		});
	};
	const handleModifierClick = (expand) => {
		hasUserToggledRef.current = true;
		setIsToolContentOpen(expand);
		const event_1 = new CustomEvent("mission-control-tool-global-toggle", { detail: {
			expand,
			excludeInstance: toolInstanceRef.current
		} });
		document.dispatchEvent(event_1);
	};
	const hasReferences = Children.toArray(children).filter(Boolean).length > 0;
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(Tool_module_default.toolContainer, {
			[Tool_module_default.toolContainerDefault]: variant === "default",
			[Tool_module_default.toolContainerInGroup]: isInGroup,
			[Tool_module_default.toolContainerExpanded]: isToolContentOpen
		}),
		style: { "--tool-preview-height-threshold": `${TOOL_PREVIEW_HEIGHT_THRESHOLD}px` },
		children: [/* @__PURE__ */ jsx(NewToolHeader, {
			leadingVisual: toolHeaderProps?.leadingVisual,
			trailingVisual: toolHeaderProps?.trailingVisual,
			title,
			path,
			isCollapsed: !isToolContentOpen,
			isPending,
			isError,
			isInGroup,
			onToggle: handleToggle,
			onModifierClick: handleModifierClick,
			hasReferences
		}), /* @__PURE__ */ jsxs("div", {
			ref: contentRef,
			className: clsx({
				[Tool_module_default.toolContentPreview]: !isToolContentOpen && shouldShowPreview,
				[Tool_module_default.toolContentCollapsed]: !isToolContentOpen && !shouldShowPreview,
				[Tool_module_default.toolContentMissionControl]: isToolContentOpen && variant === "mission-control"
			}, isToolContentOpen && variant === "default" && "border-top", isToolContentOpen && variant === "default" && Tool_module_default.toolContent),
			...!isToolContentOpen ? { inert: true } : {},
			children: [children, (isToolContentOpen || shouldShowPreview) && footer]
		})]
	});
}
Tool.displayName = "Tool";
function ToolPrimaryContent({ language, markdown, ...extensionProps }) {
	const { markdown: truncatedMarkdown } = truncateMarkdownContent(markdown);
	return markdown === void 0 ? /* @__PURE__ */ jsx(MarkdownLoading, {}) : /* @__PURE__ */ jsx(MarkdownRenderer, {
		markdown: shouldWrapInCodeBlock(language) ? wrapInCodeBlock({
			language,
			markdown: truncatedMarkdown || ""
		}) : truncatedMarkdown || "",
		extensions: [toolCodeBlockExtension({ ...extensionProps })],
		className: clsx(!shouldWrapInCodeBlock(language) && "tmp-p-3")
	});
}
ToolPrimaryContent.displayName = "ToolPrimaryContent";
function ToolSecondaryContent({ type, language, markdown }) {
	const { markdown: truncatedMarkdown } = truncateMarkdownContent(markdown);
	return /* @__PURE__ */ jsxs(Stack, {
		direction: "vertical",
		padding: "normal",
		gap: "condensed",
		children: [/* @__PURE__ */ jsx(Text$1, {
			size: "small",
			weight: "medium",
			className: "fgColor-muted",
			children: type === "input" ? "Input" : "Output"
		}), markdown === void 0 ? /* @__PURE__ */ jsx(MarkdownLoading, {}) : /* @__PURE__ */ jsx(MarkdownRenderer, {
			className: clsx(!shouldWrapInCodeBlock && "tmp-p-3", "border rounded bgColor-default overflow-hidden"),
			markdown: wrapInCodeBlock({
				language,
				markdown: truncatedMarkdown || ""
			}),
			extensions: [toolCodeBlockExtension()]
		})]
	});
}
ToolSecondaryContent.displayName = "ToolSecondaryContent";
function MarkdownLoading({ lines = 3, maxWidth = "45ch" }) {
	return /* @__PURE__ */ jsx("div", {
		className: "tmp-py-3 tmp-px-4",
		children: /* @__PURE__ */ jsx(SkeletonText, {
			lines,
			maxWidth
		})
	});
}
MarkdownLoading.displayName = "MarkdownLoading";
function parseContent(content) {
	if (!content) return {
		isError: false,
		content
	};
	const startTag = `<error>`;
	const endTag = `</error>`;
	const startIndex = content.indexOf(startTag);
	const endIndex = startIndex !== -1 ? content.indexOf(endTag, startIndex + startTag.length) : -1;
	const match = startIndex !== -1 && endIndex !== -1 ? content.slice(startIndex + startTag.length, endIndex) : null;
	if (match !== null) return {
		isError: true,
		content: match
	};
	return {
		isError: false,
		content
	};
}
var getCommandTitle = ({ command, path, isInGroup }) => {
	const hasPath = !!trimFileName(path)?.length;
	if (isInGroup) return "";
	switch (command) {
		case "create": return "Create";
		case "insert": return "Insert lines at";
		case "view": return `View${hasPath ? "" : " repository"}`;
		case "str_replace": return "Edit";
		case "undo_edit": return "Undo edit";
		default: return command || "Unknown";
	}
};
var getPathSuffix = (command, viewRange, insertLine) => {
	if (command === "view" && viewRange) {
		if (viewRange[0] === 1 && viewRange[1] === -1) return "";
		return `:${viewRange[0]}-${viewRange[1]}`;
	}
	if (command === "insert" && insertLine !== void 0) return `:${insertLine}`;
	return "";
};
/**
* Component to display grep/rg output in a structured way
*/
function GrepOutput({ output }) {
	if (!output) return /* @__PURE__ */ jsx(MarkdownLoading, {});
	if (output.trim() === "No matches found." || output.trim() === "No matches found") return /* @__PURE__ */ jsx("div", {
		className: "tmp-p-3",
		children: /* @__PURE__ */ jsx("span", {
			className: "fgColor-muted",
			children: "No matches found"
		})
	});
	const lines = output.split("\n").filter((line) => line.trim());
	if (lines.length > 0 && lines.every((line) => {
		return line.match(/^([^:]+):(\d+)$/) !== null;
	})) {
		const counts = [];
		for (const line of lines) {
			const match = line.match(/^([^:]+):(\d+)$/);
			if (match) counts.push({
				file: match[1] ?? "",
				count: parseInt(match[2] ?? "0", 10)
			});
		}
		return /* @__PURE__ */ jsxs("div", {
			className: "tmp-p-3",
			children: [/* @__PURE__ */ jsxs("span", {
				className: "fgColor-muted mb-2 d-block",
				style: { fontSize: "12px" },
				children: [
					counts.length,
					" ",
					/* @__PURE__ */ jsx("span", { children: counts.length === 1 ? "file" : "files" }),
					" with matches"
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "border rounded bgColor-default overflow-hidden",
				children: counts.map(({ file, count }, idx) => /* @__PURE__ */ jsxs("div", {
					className: clsx("tmp-px-3 py-2 d-flex", idx > 0 && "border-top"),
					style: {
						fontFamily: "var(--fontStack-monospace)",
						fontSize: "12px"
					},
					children: [/* @__PURE__ */ jsx("span", {
						className: "flex-1",
						children: trimFileName(file)
					}), /* @__PURE__ */ jsxs("span", {
						className: "fgColor-muted ml-2",
						children: [
							count,
							" ",
							/* @__PURE__ */ jsx("span", { children: count === 1 ? "match" : "matches" })
						]
					})]
				}, idx))
			})]
		});
	}
	const fileGroups = /* @__PURE__ */ new Map();
	let currentFile = "";
	for (const line of lines) {
		if (line === "--") continue;
		const lineOnlyColonMatch = line.match(/^(\d+):(.*)$/);
		const lineOnlyDashMatch = line.match(/^(\d+)-(.*)$/);
		const fullColonMatch = line.match(/^([^:]+):(\d+):(.*)$/);
		const fullDashMatch = line.match(/^([^-]+)-(\d+)-(.*)$/);
		if (fullColonMatch) {
			currentFile = fullColonMatch[1] ?? "";
			if (!fileGroups.has(currentFile)) fileGroups.set(currentFile, []);
			fileGroups.get(currentFile)?.push({
				lineNumber: fullColonMatch[2],
				content: fullColonMatch[3] ?? "",
				isContext: false
			});
		} else if (fullDashMatch) {
			currentFile = fullDashMatch[1] ?? "";
			if (!fileGroups.has(currentFile)) fileGroups.set(currentFile, []);
			fileGroups.get(currentFile)?.push({
				lineNumber: fullDashMatch[2],
				content: fullDashMatch[3] ?? "",
				isContext: true
			});
		} else if (lineOnlyColonMatch && currentFile) fileGroups.get(currentFile)?.push({
			lineNumber: lineOnlyColonMatch[1],
			content: lineOnlyColonMatch[2] ?? "",
			isContext: false
		});
		else if (lineOnlyDashMatch && currentFile) fileGroups.get(currentFile)?.push({
			lineNumber: lineOnlyDashMatch[1],
			content: lineOnlyDashMatch[2] ?? "",
			isContext: true
		});
		else {
			currentFile = line;
			if (!fileGroups.has(currentFile)) fileGroups.set(currentFile, []);
		}
	}
	return /* @__PURE__ */ jsx("div", {
		className: "tmp-p-3",
		children: fileGroups.size > 0 ? Array.from(fileGroups.entries()).map(([file, matches]) => /* @__PURE__ */ jsxs("div", {
			className: "tmp-mb-3",
			children: [/* @__PURE__ */ jsx(Text$1, {
				as: "div",
				weight: "semibold",
				className: "mb-2 fgColor-accent",
				children: trimFileName(file)
			}), /* @__PURE__ */ jsx("div", {
				className: "border rounded bgColor-default overflow-hidden",
				children: matches.map((match, idx) => /* @__PURE__ */ jsxs("div", {
					className: clsx("tmp-px-3 py-1", match.isContext ? "fgColor-muted" : "", idx > 0 && "border-top"),
					style: {
						fontFamily: "var(--fontStack-monospace)",
						fontSize: "12px"
					},
					children: [match.lineNumber && /* @__PURE__ */ jsxs("span", {
						className: "fgColor-muted",
						style: {
							minWidth: "3em",
							display: "inline-block"
						},
						children: [match.lineNumber, ":"]
					}), /* @__PURE__ */ jsx("span", {
						style: { whiteSpace: "pre-wrap" },
						children: match.content
					})]
				}, idx))
			})]
		}, file)) : /* @__PURE__ */ jsx("span", {
			className: "fgColor-muted",
			children: "No matches found"
		})
	});
}
/**
* Component to display glob output in a structured way
*/
GrepOutput.displayName = "GrepOutput";
function GlobOutput({ output }) {
	if (!output) return /* @__PURE__ */ jsx(MarkdownLoading, {});
	const files = output.split("\n").filter((f) => f.trim());
	if (files.length === 0) return /* @__PURE__ */ jsx("div", {
		className: "tmp-p-3",
		children: /* @__PURE__ */ jsx("span", {
			className: "fgColor-muted",
			children: "No files found"
		})
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "tmp-p-3",
		children: [/* @__PURE__ */ jsxs("span", {
			className: "fgColor-muted mb-2 d-block",
			style: { fontSize: "12px" },
			children: [
				files.length,
				" ",
				/* @__PURE__ */ jsx("span", { children: files.length === 1 ? "file" : "files" }),
				" found"
			]
		}), /* @__PURE__ */ jsx("div", {
			className: "border rounded bgColor-default overflow-hidden",
			children: files.map((file, idx) => /* @__PURE__ */ jsx("div", {
				className: clsx("tmp-px-3 py-2", idx > 0 && "border-top"),
				style: {
					fontFamily: "var(--fontStack-monospace)",
					fontSize: "12px"
				},
				children: trimFileName(file)
			}, idx))
		})]
	});
}
GlobOutput.displayName = "GlobOutput";
function SessionFailedBanner(t0) {
	const $ = c$1(4);
	const { errorMessage, workflowRunLink } = t0;
	const { session } = useSessionContext();
	const { data: agentInfo } = useAgentInfo(session.agent_id);
	const sessionFailedError = errorMessage || "An unexpected error occurred. For more details, see the detailed logs in GitHub Actions.";
	const t1 = `${agentInfo?.display_name || "Agent"} stopped work due to an error`;
	let t2;
	if ($[0] !== sessionFailedError || $[1] !== t1 || $[2] !== workflowRunLink) {
		t2 = jsx(Banner$1, {
			"aria-label": "Session Error",
			title: t1,
			description: sessionFailedError,
			variant: "critical",
			icon: jsx(StopIcon, {}),
			primaryAction: workflowRunLink && jsx(Banner$1.PrimaryAction, {
				as: "a",
				href: workflowRunLink,
				children: "View detailed logs"
			})
		});
		$[0] = sessionFailedError;
		$[1] = t1;
		$[2] = workflowRunLink;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
SessionFailedBanner.displayName = "SessionFailedBanner";
function SessionCancelledBanner(t0) {
	const $ = c$1(4);
	const { cancellationMessage, workflowRunLink } = t0;
	const { session } = useSessionContext();
	const { data: agentInfo } = useAgentInfo(session.agent_id);
	const sessionCancelledMessage = cancellationMessage || "The session was cancelled.";
	const t1 = `${agentInfo?.display_name || "Agent"}'s work was cancelled`;
	let t2;
	if ($[0] !== sessionCancelledMessage || $[1] !== t1 || $[2] !== workflowRunLink) {
		t2 = jsx(Banner$1, {
			"aria-label": "Session Cancelled",
			title: t1,
			description: sessionCancelledMessage,
			variant: "warning",
			icon: jsx(SkipIcon, {}),
			primaryAction: workflowRunLink && jsx(Banner$1.PrimaryAction, {
				as: "a",
				href: workflowRunLink,
				children: "View detailed logs"
			})
		});
		$[0] = sessionCancelledMessage;
		$[1] = t1;
		$[2] = workflowRunLink;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
SessionCancelledBanner.displayName = "SessionCancelledBanner";
function generateWorkflowRunLink(nwo, workflowRunId) {
	if (nwo == null || workflowRunId == null || workflowRunId === 0) return;
	return `/${nwo}/actions/runs/${workflowRunId}`;
}
var predefinedMessages = [
	"Spinning up dev environment…",
	"Fueling the runtime engines…",
	"Clearing the airspace for MCP traffic…",
	"Cabin pressure stable. Almost ready…",
	"Reticulating goggles...",
	"Calibrating flux capacitor...",
	"Adjusting seatbelt…",
	"Waiting for clearance from GitHub tower…",
	"Final systems check, standing by…",
	"Takeoff soon™…"
];
function BootingUpMessage(t0) {
	const $ = c$1(5);
	const { agentId } = t0;
	const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
	const intervalRef = useRef(null);
	let t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			if (intervalRef.current) {
				clearInterval(intervalRef.current);
				intervalRef.current = null;
			} else intervalRef.current = setInterval(() => {
				setLoadingMessageIndex(_temp$29);
			}, 7e3);
			return () => {
				if (intervalRef.current) {
					clearInterval(intervalRef.current);
					intervalRef.current = null;
				}
			};
		};
		t2 = [];
		$[0] = t1;
		$[1] = t2;
	} else {
		t1 = $[0];
		t2 = $[1];
	}
	useEffect(t1, t2);
	const t3 = predefinedMessages[loadingMessageIndex] || "Loading…";
	let t4;
	if ($[2] !== agentId || $[3] !== t3) {
		t4 = jsx(LoadingMessage$2, {
			message: t3,
			agentId
		});
		$[2] = agentId;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	return t4;
}
BootingUpMessage.displayName = "BootingUpMessage";
function _temp$29(prev) {
	if (prev < predefinedMessages.length - 1) return prev + 1;
	return prev;
}
function LoadingMessage$2({ message, agentId }) {
	return /* @__PURE__ */ jsxs(Stack, {
		direction: "horizontal",
		padding: "none",
		align: "center",
		justify: "start",
		gap: "condensed",
		children: [/* @__PURE__ */ jsx(AgentAvatar, {
			animationType: CopilotAnimationType.Thinking,
			loopAnimation: true,
			agentId
		}), /* @__PURE__ */ jsx(WithShimmerEffect, {
			className: "color-fg-muted",
			children: message
		})]
	});
}
LoadingMessage$2.displayName = "LoadingMessage";
/**
* Command types sent when responding to interactive prompts.
* Each maps to a specific prompt type that the CLI/agent can send.
*/
var COMMAND_TYPES = {
	ASK_USER_RESPONSE: "ask_user_response",
	ELICITATION_RESPONSE: "elicitation_response",
	PLAN_APPROVAL_RESPONSE: "plan_approval_response",
	PERMISSION_RESPONSE: "permission_response"
};
/**
* Normalize raw ask_user arguments into the canonical AskUserArguments union.
*
* Both ask_user variants (legacy choices and elicitation schema) arrive over the
* wire with `toolName: "ask_user"` because the MCP SDK registers them under the
* same name. The only way to distinguish them is by inspecting the argument
* shape — specifically the presence of a `requestedSchema` field.
*/
function normalizeAskUserArguments(raw) {
	const schema = parseRequestedSchema(raw.requestedSchema);
	if (schema) return {
		message: typeof raw.message === "string" ? raw.message : "",
		requestedSchema: schema
	};
	const question = typeof raw.question === "string" ? raw.question : "";
	let allowFreeform;
	if (typeof raw.allowFreeform === "boolean") allowFreeform = raw.allowFreeform;
	else if (typeof raw.allow_freeform === "boolean") allowFreeform = raw.allow_freeform;
	const result = { question };
	if (Array.isArray(raw.choices)) result.choices = raw.choices;
	if (allowFreeform !== void 0) result.allowFreeform = allowFreeform;
	return result;
}
/**
* Recursively extract enumerable choices from any JSON Schema construct.
* Handles: `enum`, `oneOf[{const,title}]`, `anyOf[{const,title}]`,
* and `items.{enum,oneOf,anyOf}` for array types.
* Returns undefined if no choices are found.
*/
function extractChoices(node) {
	if (Array.isArray(node.enum)) {
		const values = node.enum.filter((v) => typeof v === "string");
		if (values.length > 0) return { values };
	}
	const constTitleSource = Array.isArray(node.oneOf) ? node.oneOf : Array.isArray(node.anyOf) ? node.anyOf : null;
	if (constTitleSource) {
		const result = extractConstTitleEntries(constTitleSource);
		if (result) return result;
	}
	if (node.items && typeof node.items === "object") return extractChoices(node.items);
}
/** Extract values and labels from a oneOf/anyOf array of {const, title} entries. */
function extractConstTitleEntries(entries) {
	const values = [];
	const labels = {};
	for (const entry of entries) if (entry && typeof entry === "object") {
		const item = entry;
		if (typeof item.const === "string") {
			values.push(item.const);
			if (typeof item.title === "string") labels[item.const] = item.title;
		}
	}
	if (values.length === 0) return void 0;
	return Object.keys(labels).length > 0 ? {
		values,
		labels
	} : { values };
}
/**
* Validate and parse a raw `requestedSchema` value into a typed `RequestedSchema`.
* Returns `undefined` if the value is missing, not an object, or structurally invalid.
*/
function parseRequestedSchema(value) {
	if (!value || typeof value !== "object") return void 0;
	const obj = value;
	if (!obj.properties || typeof obj.properties !== "object") return void 0;
	const properties = {};
	for (const [key, propValue] of Object.entries(obj.properties)) {
		if (!propValue || typeof propValue !== "object") continue;
		const prop = propValue;
		const parsed = {};
		if (typeof prop.type === "string") parsed.type = prop.type;
		if (typeof prop.title === "string") parsed.title = prop.title;
		if (typeof prop.description === "string") parsed.description = prop.description;
		if (typeof prop.default === "string") parsed.default = prop.default;
		if (parsed.type === "array") {
			parsed.multiSelect = true;
			if (!parsed.title && prop.items && typeof prop.items === "object") {
				const items = prop.items;
				if (typeof items.title === "string") parsed.title = items.title;
			}
		}
		const choices = extractChoices(prop);
		if (choices) {
			parsed.enum = choices.values;
			if (choices.labels) parsed.enumLabels = choices.labels;
		}
		properties[key] = parsed;
	}
	if (Object.keys(properties).length === 0) return void 0;
	const result = { properties };
	if (Array.isArray(obj.required)) result.required = obj.required.filter((v) => typeof v === "string");
	return result;
}
/**
* Normalizes arguments for ask_user prompts across all entry formats.
*/
function normalizePromptArguments(toolName, args) {
	if (toolName === "ask_user") return normalizeAskUserArguments(args);
	return args;
}
/**
* Check if a log entry is a tool.execution_start event for an interactive prompt tool.
*/
function isInteractivePromptToolExecution(logEntry) {
	if (!isToolExecutionStartMessage(logEntry)) return false;
	return INTERACTIVE_PROMPT_TOOL_NAMES.has(logEntry.data.toolName);
}
/**
* Extract all interactive prompt tool calls from a CompletionChunk.
*/
function extractInteractivePromptsFromChunk(chunk) {
	const prompts = [];
	for (const choice of chunk.choices) {
		if (!choice.delta.tool_calls) continue;
		for (const toolCall of choice.delta.tool_calls) {
			if (!toolCall.function?.name || !INTERACTIVE_PROMPT_TOOL_NAMES.has(toolCall.function.name)) continue;
			let parsedArgs;
			try {
				parsedArgs = toolCall.function.arguments ? JSON.parse(toolCall.function.arguments) : {};
			} catch {
				parsedArgs = {};
			}
			const toolName = toolCall.function.name;
			prompts.push({
				toolCallId: toolCall.id,
				toolName,
				arguments: normalizePromptArguments(toolName, parsedArgs)
			});
		}
	}
	return prompts;
}
/**
* Check if a CompletionChunk contains an interactive prompt tool call.
*/
function hasInteractivePromptInChunk(logEntry) {
	if (!isCompletionChunk(logEntry)) return false;
	return extractInteractivePromptsFromChunk(logEntry).length > 0;
}
/**
* Extract interactive prompt data from a CompletionChunk.
* Returns the first interactive prompt found, or null if none.
*/
function extractInteractivePromptFromChunk(chunk) {
	return extractInteractivePromptsFromChunk(chunk)[0] ?? null;
}
/**
* Convert extracted prompt data to ToolUserRequestedMessage format.
*/
function toToolUserRequestedMessage(prompt, timestamp) {
	return {
		type: "tool.user_requested",
		toolCallId: prompt.toolCallId,
		toolName: prompt.toolName,
		arguments: prompt.arguments,
		timestamp: timestamp || (/* @__PURE__ */ new Date()).toISOString()
	};
}
/**
* Find the tool response for a given tool call ID in the logs.
* Returns the response content if found, undefined otherwise.
* Checks both CompletionToolMessage (role: 'tool') and ToolOutputsMessage (type: 'tool.outputs') formats.
*/
function findToolResponse(toolCallId, logsData) {
	if (!logsData) return void 0;
	for (const entry of logsData) {
		if (isCompletionToolMessage(entry) && entry.tool_call_id === toolCallId) {
			if (typeof entry.content === "string") return entry.content;
			if (Array.isArray(entry.content)) return entry.content.filter((part) => part.type === "text").map((part) => part.text).join("");
		}
		if (isToolOutputsMessage(entry) && entry.toolCallId === toolCallId) return entry.output;
	}
}
/**
* Extract a display-friendly answer from an optimistic response.
* Uses the commandType (already set by each prompt component) as the discriminant
* instead of duck-typing the response object.
*/
function formatOptimisticResponse(response, commandType) {
	if (response == null) return void 0;
	if (typeof response !== "object") return String(response);
	const obj = response;
	switch (commandType) {
		case COMMAND_TYPES.ASK_USER_RESPONSE: return obj.answer != null ? String(obj.answer) : void 0;
		case COMMAND_TYPES.ELICITATION_RESPONSE:
			if (obj.action === "decline" || obj.action === "cancel") return "Declined";
			if (obj.action === "accept" && obj.content && typeof obj.content === "object") return formatElicitationContent(obj.content);
			return;
		case COMMAND_TYPES.PERMISSION_RESPONSE: return obj.approved ? "Approved" : "Denied";
		case COMMAND_TYPES.PLAN_APPROVAL_RESPONSE:
			if (obj.selectedAction != null) return String(obj.selectedAction);
			if (obj.feedback != null) return `Feedback: ${String(obj.feedback)}`;
			return;
		default: return String(response);
	}
}
/**
* Format elicitation content for display. Produces a human-readable
* key: value list matching the runtime's detailed format.
*/
function formatElicitationContent(content) {
	const entries = Object.entries(content);
	if (entries.length === 0) return "";
	return entries.map(([key, value]) => {
		return `${key}: ${Array.isArray(value) ? value.join(", ") : String(value)}`;
	}).join("\n");
}
/**
* Extracts a normalized prompt from various log entry formats.
*/
function extractPromptFromEntry(entry) {
	if (isToolUserRequestedMessage(entry)) {
		const msg = entry;
		if (INTERACTIVE_PROMPT_TOOL_NAMES.has(msg.toolName)) return {
			toolCallId: msg.toolCallId,
			toolName: msg.toolName,
			arguments: normalizePromptArguments(msg.toolName, msg.arguments)
		};
	}
	if (isInteractivePromptToolExecution(entry)) {
		const msg = entry;
		return {
			toolCallId: msg.data.toolCallId,
			toolName: msg.data.toolName,
			arguments: normalizePromptArguments(msg.data.toolName, msg.data.arguments)
		};
	}
	if (hasInteractivePromptInChunk(entry)) {
		const promptData = extractInteractivePromptFromChunk(entry);
		if (promptData && INTERACTIVE_PROMPT_TOOL_NAMES.has(promptData.toolName)) return {
			toolCallId: promptData.toolCallId,
			toolName: promptData.toolName,
			arguments: promptData.arguments
		};
	}
	return null;
}
/**
* Checks if a prompt has been resolved by looking for a matching response in the logs.
*/
function isPromptResolved(toolCallId, logs) {
	for (const entry of logs) {
		if (isCompletionToolMessage(entry) && entry.tool_call_id === toolCallId) return true;
		if (isToolOutputsMessage(entry) && entry.toolCallId === toolCallId) return true;
	}
	return false;
}
/**
* Gets the tool call ID from a log entry if it's an interactive prompt.
*/
function getPromptToolCallId(entry) {
	return extractPromptFromEntry(entry)?.toolCallId ?? null;
}
function extractNwoFromURL(url) {
	try {
		const pathParts = new URL(url, "https://github.com").pathname.split("/").filter(Boolean);
		if (pathParts.length >= 2) return `${pathParts[0]}/${pathParts[1]}`;
		return;
	} catch {
		return;
	}
}
function mapCopilotAnnotationItemToPublicCodeReference(item) {
	const citations = item.citations;
	if (!citations || !citations.url) return;
	return {
		annotationId: item.id,
		sourceURL: citations.url,
		license: citations.license || void 0,
		language: void 0,
		nwo: extractNwoFromURL(citations.url)
	};
}
function parseCopilotAnnotationsToCodeInsights(copilotAnnotations) {
	if (!copilotAnnotations) return;
	let parsed;
	try {
		parsed = typeof copilotAnnotations === "string" ? JSON.parse(copilotAnnotations) : copilotAnnotations;
	} catch {
		return;
	}
	const publicCodeReferences = Object.values(parsed).flat().flatMap((item) => {
		const ref = mapCopilotAnnotationItemToPublicCodeReference(item);
		return ref ? [ref] : [];
	});
	return publicCodeReferences.length > 0 ? { publicCodeReferences } : void 0;
}
/**
* Checks if a log entry is the final plan message from the main agent.
* Subagent entries are excluded so their stop messages stay in the grouped logs.
*/
function isFinalPlanEntry(logEntry) {
	if (!isCompletionChunk(logEntry)) return false;
	if (getCustomAgentId(logEntry)) return false;
	const choice = logEntry.choices[0];
	return !!(choice?.finish_reason === "stop" && choice.delta.role === "assistant" && choice.delta.content && !choice.delta.tool_calls);
}
/**
* Copies assistant narration to `assistant_content` when a choice has both `content` and `tool_calls`.
* Prevents narration from being overwritten when tool results are merged during deduplication.
*/
function preserveAssistantContent(logEntry) {
	let hasUpdates = false;
	const choices = logEntry.choices.map((choice) => {
		if (!(choice.delta.role === "assistant" && !!choice.delta.content && !choice.delta.assistant_content && (choice.delta.tool_calls?.length ?? 0) > 0)) return choice;
		hasUpdates = true;
		return {
			...choice,
			delta: {
				...choice.delta,
				assistant_content: choice.delta.content
			}
		};
	});
	if (!hasUpdates) return logEntry;
	return {
		...logEntry,
		choices
	};
}
function maybePreserveAssistantContent(logEntry, shouldPreserve) {
	if (!shouldPreserve) return logEntry;
	return preserveAssistantContent(logEntry);
}
function customChoiceMerger(firstValue, secondValue) {
	if (Array.isArray(firstValue) && Array.isArray(secondValue) && firstValue[0]?.hasOwnProperty("delta") && secondValue[0]?.hasOwnProperty("delta")) {
		const finalChoices = new Array();
		const idToChoiceWithTool = /* @__PURE__ */ new Map();
		for (const choice of firstValue.concat(secondValue)) {
			const tool = choice.delta.tool_calls?.[0];
			if (!tool || !tool.id) {
				finalChoices.push(choice);
				continue;
			}
			let newChoice = choice;
			const existingChoice = idToChoiceWithTool.get(tool.id);
			if (existingChoice) newChoice = merge({}, existingChoice, choice);
			idToChoiceWithTool.set(tool.id, newChoice);
		}
		return finalChoices.concat(Array.from(idToChoiceWithTool.values()));
	}
}
function extractToolCallMetadataFromChunk(chunk) {
	const toolCallMetadata = {};
	for (const choice of chunk.choices) {
		const copilotAnnotations = choice.delta?.copilot_annotations;
		if (!copilotAnnotations) continue;
		const codeInsights = parseCopilotAnnotationsToCodeInsights(copilotAnnotations);
		if (!codeInsights) continue;
		const toolCalls = choice.delta?.tool_calls ?? [];
		for (const toolCall of toolCalls) if (toolCall.id) {
			const existingInsights = toolCallMetadata[toolCall.id]?.["code-insights"];
			if (existingInsights) toolCallMetadata[toolCall.id] = { "code-insights": { publicCodeReferences: [...existingInsights.publicCodeReferences, ...codeInsights.publicCodeReferences] } };
			else toolCallMetadata[toolCall.id] = { "code-insights": codeInsights };
		}
	}
	return Object.keys(toolCallMetadata).length > 0 ? toolCallMetadata : void 0;
}
/**
* Merges two tool-call metadata maps, concatenating code-insights arrays for matching tool_call_ids.
* Deduplicates publicCodeReferences by annotationId to avoid duplicates when the same tool
* appears in multiple chunks.
*/
function mergeToolCallMetadata(existing, incoming) {
	if (!incoming) return existing;
	if (!existing) return incoming;
	const merged = { ...existing };
	for (const [toolCallId, incomingBag] of Object.entries(incoming)) {
		const existingBag = merged[toolCallId];
		if (!existingBag) {
			merged[toolCallId] = incomingBag;
			continue;
		}
		const existingInsights = existingBag["code-insights"];
		const incomingInsights = incomingBag["code-insights"];
		if (existingInsights && incomingInsights) {
			const seenIds = new Set(existingInsights.publicCodeReferences.map((ref) => ref.annotationId));
			const newRefs = incomingInsights.publicCodeReferences.filter((ref) => !seenIds.has(ref.annotationId));
			merged[toolCallId] = {
				...existingBag,
				...incomingBag,
				"code-insights": { publicCodeReferences: [...existingInsights.publicCodeReferences, ...newRefs] }
			};
		} else merged[toolCallId] = {
			...existingBag,
			...incomingBag
		};
	}
	return merged;
}
/**
* Extracts content from a tool message, handling both string and array formats.
*/
function extractToolResultContent(toolMessage) {
	if (typeof toolMessage.content === "string") return toolMessage.content;
	return toolMessage.content.map((c) => c.text).join("\n");
}
/**
* Merges tool result content into the matching choice within a completion chunk.
* Returns a new chunk with the result content added to the matching tool call's delta.
*/
function mergeToolResultIntoChunk(chunk, toolMessage) {
	const resultContent = extractToolResultContent(toolMessage);
	const updatedChoices = chunk.choices.map((choice) => {
		if ((choice.delta.tool_calls ?? []).some((tc) => tc.id === toolMessage.tool_call_id)) return {
			...choice,
			delta: {
				...choice.delta,
				content: resultContent
			}
		};
		return choice;
	});
	return {
		...chunk,
		choices: updatedChoices
	};
}
/**
* Merges content from two assistant chat messages with choices.
* Concatenates the content from the first choice of each message.
*/
function mergeChatMessageContent(existing, incoming) {
	const existingContent = existing.choices?.[0]?.delta?.content ?? "";
	const newContent = incoming.choices?.[0]?.delta?.content ?? "";
	const existingChoice = existing.choices?.[0];
	return {
		...incoming,
		choices: existingChoice ? [{
			...existingChoice,
			delta: {
				...existingChoice.delta,
				content: existingContent + newContent
			}
		}] : incoming.choices
	};
}
function preprocessLogEntries(logEntries, options = {}) {
	if (!logEntries) return [];
	const shouldPreserve = options.preserveAssistantNarration ?? false;
	const idToLogEntry = /* @__PURE__ */ new Map();
	const toolCallIdToChunkId = /* @__PURE__ */ new Map();
	let previousCommandId = null;
	let previousLogEntries = [];
	if (logEntries !== void 0 && isChatMessage(logEntries[0])) logEntries.shift();
	for (const logEntry of logEntries) {
		if (isToolUserRequestedMessage(logEntry)) {
			idToLogEntry.set(logEntry.toolCallId, logEntry);
			previousCommandId = null;
			previousLogEntries = [];
			continue;
		}
		if (isInteractivePromptToolExecution(logEntry)) {
			const message = toToolUserRequestedMessage({
				toolCallId: logEntry.data.toolCallId,
				toolName: logEntry.data.toolName,
				arguments: logEntry.data.arguments
			});
			idToLogEntry.set(message.toolCallId, message);
			previousCommandId = null;
			previousLogEntries = [];
			continue;
		}
		if (isChatMessage(logEntry)) {
			const existingEntry = idToLogEntry.get(logEntry.id);
			if (existingEntry && isChatMessage(existingEntry)) if (logEntry.role === "assistant" && logEntry.choices && existingEntry.choices) {
				const mergedEntry = mergeChatMessageContent(existingEntry, logEntry);
				idToLogEntry.set(logEntry.id, mergedEntry);
			} else idToLogEntry.set(logEntry.id, logEntry);
			else idToLogEntry.set(logEntry.id, logEntry);
		} else if (isCompletionToolMessage(logEntry)) {
			const toolMessage = logEntry;
			const chunkId = toolCallIdToChunkId.get(toolMessage.tool_call_id);
			if (chunkId) {
				const existingChunk = idToLogEntry.get(chunkId);
				if (existingChunk && isCompletionChunk(existingChunk)) idToLogEntry.set(chunkId, mergeToolResultIntoChunk(existingChunk, toolMessage));
			}
			previousCommandId = null;
			previousLogEntries = [];
		} else if (isCompletionChunk(logEntry)) {
			const logEntryWithAssistantContent = maybePreserveAssistantContent(logEntry, shouldPreserve);
			if (hasInteractivePromptInChunk(logEntryWithAssistantContent)) {
				const prompts = extractInteractivePromptsFromChunk(logEntryWithAssistantContent);
				for (const prompt of prompts) {
					const message = toToolUserRequestedMessage(prompt);
					idToLogEntry.set(message.toolCallId, message);
				}
			}
			const incomingMetadata = extractToolCallMetadataFromChunk(logEntryWithAssistantContent);
			for (const choice of logEntryWithAssistantContent.choices) for (const toolCall of choice.delta.tool_calls ?? []) if (toolCall.id) toolCallIdToChunkId.set(toolCall.id, logEntry.id);
			let newEntry = logEntryWithAssistantContent;
			const existingEntry = idToLogEntry.get(logEntry.id);
			if (existingEntry) {
				const mergedBase = mergeWith({}, existingEntry, logEntryWithAssistantContent, customChoiceMerger);
				const mergedMetadata = mergeToolCallMetadata("tool_call_metadata" in existingEntry ? existingEntry.tool_call_metadata : void 0, incomingMetadata);
				newEntry = mergedMetadata ? {
					...mergedBase,
					tool_call_metadata: mergedMetadata
				} : mergedBase;
			} else if (incomingMetadata) newEntry = {
				...logEntryWithAssistantContent,
				tool_call_metadata: incomingMetadata
			};
			idToLogEntry.set(logEntry.id, newEntry);
			previousCommandId = null;
			previousLogEntries = [];
		} else if (isCommandMessage(logEntry)) {
			let commandId = null;
			let entries = [];
			if (previousCommandId && previousLogEntries.length > 0) {
				commandId = previousCommandId;
				entries = [...previousLogEntries, logEntry];
			} else {
				commandId = logEntry.source;
				entries = [logEntry];
			}
			idToLogEntry.set(commandId, entries);
			previousCommandId = commandId;
			previousLogEntries = entries;
		}
	}
	const preprocessed = [...idToLogEntry.values()];
	const filteredPreprocessed = options.filterFinalPlanMessage ? preprocessed.filter((entry) => {
		if (isFinalPlanEntry(entry)) return false;
		return true;
	}) : preprocessed;
	if (options.groupCustomAgentSessions) return groupCustomAgentLogs(filteredPreprocessed);
	return filteredPreprocessed;
}
/**
* Extracts the content string from either a LogEntry or ChatStreamMessage.
*/
function getEntryContent(entry) {
	if ("choices" in entry && Array.isArray(entry.choices)) return entry.choices.map((choice) => choice.delta?.content ?? "").join("");
	if ("content" in entry && typeof entry.content === "string") return entry.content;
	return "";
}
/**
* Extracts a comparable content length from either a LogEntry or ChatStreamMessage.
*/
function getEntryContentLength(entry) {
	return getEntryContent(entry).length;
}
/**
* Finds the first offset in logs where the chat history aligns via
* prefix matching. At each candidate offset, every non-empty pair in
* the overlap region must satisfy: one content string is a prefix of
* the other. Empty-content entries are skipped. Returns the first
* matching offset, or null to signal that chat should be appended.
*/
function findAlignmentOffset(logs, chat) {
	for (let k = 0; k < logs.length; k++) {
		const overlapEnd = Math.min(logs.length - k, chat.length);
		let allMatch = true;
		let anyMatch = false;
		for (let i = 0; i < overlapEnd; i++) {
			const logEntry = logs[k + i];
			const chatEntry = chat[i];
			if (!logEntry || !chatEntry) continue;
			const logContent = getEntryContent(logEntry);
			const chatContent = getEntryContent(chatEntry);
			if (logContent.length === 0 || chatContent.length === 0) continue;
			if (logContent.startsWith(chatContent) || chatContent.startsWith(logContent)) anyMatch = true;
			else {
				allMatch = false;
				break;
			}
		}
		if (allMatch && anyMatch) return k;
	}
	return null;
}
/**
* Merges preprocessed log entries with streaming chat history by aligning
* the two arrays on partial content matches.
*
* The algorithm finds the latest position in the log entries where the chat
* history overlaps (both arrays have entries with content at the same
* relative position). Entries before that point are kept as-is. From that
* point onward the two lists are merged position-by-position, preferring
* whichever entry has the longer content at each index.
*
* When no overlap is detected the chat history is treated as newer content
* and is appended after the log entries.
*/
function mergeLogsWithChatHistory(preprocessedLogEntries, chatMessageHistory) {
	if (chatMessageHistory.length === 0) return preprocessedLogEntries;
	if (preprocessedLogEntries.length > 0 && chatMessageHistory[0]?.role === "user") chatMessageHistory = chatMessageHistory.slice(1);
	if (chatMessageHistory.length === 0) return preprocessedLogEntries;
	const alignOffset = findAlignmentOffset(preprocessedLogEntries, chatMessageHistory);
	if (alignOffset === null) return [...preprocessedLogEntries, ...chatMessageHistory];
	const head = preprocessedLogEntries.slice(0, alignOffset);
	const tail = preprocessedLogEntries.slice(alignOffset);
	const overlapLength = Math.max(tail.length, chatMessageHistory.length);
	const merged = [];
	for (let i = 0; i < overlapLength; i++) {
		const logEntry = tail[i];
		const chatEntry = chatMessageHistory[i];
		if (logEntry && chatEntry) {
			const logLen = getEntryContentLength(logEntry);
			const chatLen = getEntryContentLength(chatEntry);
			merged.push(chatLen > logLen ? chatEntry : logEntry);
		} else if (logEntry) merged.push(logEntry);
		else if (chatEntry) merged.push(chatEntry);
	}
	return head.concat(merged);
}
var SteeringCommandInput_module_default = {
	errorIcon: "SteeringCommandInput-module_af3TTG_errorIcon",
	errorMessage: "SteeringCommandInput-module_af3TTG_errorMessage",
	steeringCommandInputContainer: "SteeringCommandInput-module_af3TTG_steeringCommandInputContainer",
	steeringCommandInputSubmitButton: "SteeringCommandInput-module_af3TTG_steeringCommandInputSubmitButton",
	steeringCommandInputTextarea: "SteeringCommandInput-module_af3TTG_steeringCommandInputTextarea",
	steeringCommandInputWrapper: "SteeringCommandInput-module_af3TTG_steeringCommandInputWrapper"
};
var MAX_TEXTAREA_HEIGHT_PX = 256;
function SteeringCommandInput({ onSubmit, error }) {
	const [value, setValue] = useState("");
	const textareaRef = useRef(null);
	const handleChange = (e) => {
		setValue(e.target.value);
		const textarea = e.target;
		textarea.style.height = "auto";
		textarea.style.height = `${Math.min(textarea.scrollHeight, MAX_TEXTAREA_HEIGHT_PX)}px`;
	};
	const handleSubmit = () => {
		if (value.trim()) {
			onSubmit(value);
			setValue("");
			if (textareaRef.current) textareaRef.current.style.height = "auto";
		}
	};
	return /* @__PURE__ */ jsx(ScopedCommands, {
		commands: { "copilot-chat:send-message": handleSubmit },
		children: /* @__PURE__ */ jsxs("div", {
			className: SteeringCommandInput_module_default.steeringCommandInputContainer,
			children: [/* @__PURE__ */ jsxs("div", {
				className: SteeringCommandInput_module_default.steeringCommandInputWrapper,
				children: [/* @__PURE__ */ jsx("textarea", {
					ref: textareaRef,
					className: SteeringCommandInput_module_default.steeringCommandInputTextarea,
					value,
					onChange: handleChange,
					placeholder: "What would you like to do next?",
					autoComplete: "off",
					autoCorrect: "on",
					rows: 1
				}), /* @__PURE__ */ jsx(IconButton, {
					className: SteeringCommandInput_module_default.steeringCommandInputSubmitButton,
					variant: "invisible",
					size: "small",
					icon: PaperAirplaneIcon,
					"aria-label": "Send",
					disabled: !value.trim(),
					onClick: handleSubmit
				})]
			}), error && /* @__PURE__ */ jsxs("div", {
				className: SteeringCommandInput_module_default.errorMessage,
				children: [/* @__PURE__ */ jsx(AlertIcon, { className: SteeringCommandInput_module_default.errorIcon }), /* @__PURE__ */ jsx("span", { children: error })]
			})]
		})
	});
}
SteeringCommandInput.displayName = "SteeringCommandInput";
var StickySteeringCommand_module_default = { stickyContainer: "StickySteeringCommand-module_C8kpVG_stickyContainer" };
function StickySteeringCommand({ onSubmit, error }) {
	return /* @__PURE__ */ jsx("div", {
		className: StickySteeringCommand_module_default.stickyContainer,
		children: /* @__PURE__ */ jsx(SteeringCommandInput, {
			onSubmit,
			error
		})
	});
}
StickySteeringCommand.displayName = "StickySteeringCommand";
var UserCommand_module_default = {
	actionText: "UserCommand-module_9V6ecq_actionText",
	avatar: "UserCommand-module_9V6ecq_avatar",
	commandBox: "UserCommand-module_9V6ecq_commandBox",
	commandContainer: "UserCommand-module_9V6ecq_commandContainer",
	commandRow: "UserCommand-module_9V6ecq_commandRow",
	containerMuted: "UserCommand-module_9V6ecq_containerMuted",
	username: "UserCommand-module_9V6ecq_username"
};
var require_pluralize = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(root, pluralize) {
		/* istanbul ignore else */
		if (typeof __require === "function" && typeof exports === "object" && typeof module === "object") module.exports = pluralize();
		else if (typeof define === "function" && define.amd) define(function() {
			return pluralize();
		});
		else root.pluralize = pluralize();
	})(exports, function() {
		var pluralRules = [];
		var singularRules = [];
		var uncountables = {};
		var irregularPlurals = {};
		var irregularSingles = {};
		/**
		* Sanitize a pluralization rule to a usable regular expression.
		*
		* @param  {(RegExp|string)} rule
		* @return {RegExp}
		*/
		function sanitizeRule(rule) {
			if (typeof rule === "string") return new RegExp("^" + rule + "$", "i");
			return rule;
		}
		/**
		* Pass in a word token to produce a function that can replicate the case on
		* another word.
		*
		* @param  {string}   word
		* @param  {string}   token
		* @return {Function}
		*/
		function restoreCase(word, token) {
			if (word === token) return token;
			if (word === word.toLowerCase()) return token.toLowerCase();
			if (word === word.toUpperCase()) return token.toUpperCase();
			if (word[0] === word[0].toUpperCase()) return token.charAt(0).toUpperCase() + token.substr(1).toLowerCase();
			return token.toLowerCase();
		}
		/**
		* Interpolate a regexp string.
		*
		* @param  {string} str
		* @param  {Array}  args
		* @return {string}
		*/
		function interpolate(str, args) {
			return str.replace(/\$(\d{1,2})/g, function(match, index) {
				return args[index] || "";
			});
		}
		/**
		* Replace a word using a rule.
		*
		* @param  {string} word
		* @param  {Array}  rule
		* @return {string}
		*/
		function replace(word, rule) {
			return word.replace(rule[0], function(match, index) {
				var result = interpolate(rule[1], arguments);
				if (match === "") return restoreCase(word[index - 1], result);
				return restoreCase(match, result);
			});
		}
		/**
		* Sanitize a word by passing in the word and sanitization rules.
		*
		* @param  {string}   token
		* @param  {string}   word
		* @param  {Array}    rules
		* @return {string}
		*/
		function sanitizeWord(token, word, rules) {
			if (!token.length || uncountables.hasOwnProperty(token)) return word;
			var len = rules.length;
			while (len--) {
				var rule = rules[len];
				if (rule[0].test(word)) return replace(word, rule);
			}
			return word;
		}
		/**
		* Replace a word with the updated word.
		*
		* @param  {Object}   replaceMap
		* @param  {Object}   keepMap
		* @param  {Array}    rules
		* @return {Function}
		*/
		function replaceWord(replaceMap, keepMap, rules) {
			return function(word) {
				var token = word.toLowerCase();
				if (keepMap.hasOwnProperty(token)) return restoreCase(word, token);
				if (replaceMap.hasOwnProperty(token)) return restoreCase(word, replaceMap[token]);
				return sanitizeWord(token, word, rules);
			};
		}
		/**
		* Check if a word is part of the map.
		*/
		function checkWord(replaceMap, keepMap, rules, bool) {
			return function(word) {
				var token = word.toLowerCase();
				if (keepMap.hasOwnProperty(token)) return true;
				if (replaceMap.hasOwnProperty(token)) return false;
				return sanitizeWord(token, token, rules) === token;
			};
		}
		/**
		* Pluralize or singularize a word based on the passed in count.
		*
		* @param  {string}  word      The word to pluralize
		* @param  {number}  count     How many of the word exist
		* @param  {boolean} inclusive Whether to prefix with the number (e.g. 3 ducks)
		* @return {string}
		*/
		function pluralize(word, count, inclusive) {
			var pluralized = count === 1 ? pluralize.singular(word) : pluralize.plural(word);
			return (inclusive ? count + " " : "") + pluralized;
		}
		/**
		* Pluralize a word.
		*
		* @type {Function}
		*/
		pluralize.plural = replaceWord(irregularSingles, irregularPlurals, pluralRules);
		/**
		* Check if a word is plural.
		*
		* @type {Function}
		*/
		pluralize.isPlural = checkWord(irregularSingles, irregularPlurals, pluralRules);
		/**
		* Singularize a word.
		*
		* @type {Function}
		*/
		pluralize.singular = replaceWord(irregularPlurals, irregularSingles, singularRules);
		/**
		* Check if a word is singular.
		*
		* @type {Function}
		*/
		pluralize.isSingular = checkWord(irregularPlurals, irregularSingles, singularRules);
		/**
		* Add a pluralization rule to the collection.
		*
		* @param {(string|RegExp)} rule
		* @param {string}          replacement
		*/
		pluralize.addPluralRule = function(rule, replacement) {
			pluralRules.push([sanitizeRule(rule), replacement]);
		};
		/**
		* Add a singularization rule to the collection.
		*
		* @param {(string|RegExp)} rule
		* @param {string}          replacement
		*/
		pluralize.addSingularRule = function(rule, replacement) {
			singularRules.push([sanitizeRule(rule), replacement]);
		};
		/**
		* Add an uncountable word rule.
		*
		* @param {(string|RegExp)} word
		*/
		pluralize.addUncountableRule = function(word) {
			if (typeof word === "string") {
				uncountables[word.toLowerCase()] = true;
				return;
			}
			pluralize.addPluralRule(word, "$0");
			pluralize.addSingularRule(word, "$0");
		};
		/**
		* Add an irregular word definition.
		*
		* @param {string} single
		* @param {string} plural
		*/
		pluralize.addIrregularRule = function(single, plural) {
			plural = plural.toLowerCase();
			single = single.toLowerCase();
			irregularSingles[single] = plural;
			irregularPlurals[plural] = single;
		};
		/**
		* Irregular rules.
		*/
		[
			["I", "we"],
			["me", "us"],
			["he", "they"],
			["she", "they"],
			["them", "them"],
			["myself", "ourselves"],
			["yourself", "yourselves"],
			["itself", "themselves"],
			["herself", "themselves"],
			["himself", "themselves"],
			["themself", "themselves"],
			["is", "are"],
			["was", "were"],
			["has", "have"],
			["this", "these"],
			["that", "those"],
			["echo", "echoes"],
			["dingo", "dingoes"],
			["volcano", "volcanoes"],
			["tornado", "tornadoes"],
			["torpedo", "torpedoes"],
			["genus", "genera"],
			["viscus", "viscera"],
			["stigma", "stigmata"],
			["stoma", "stomata"],
			["dogma", "dogmata"],
			["lemma", "lemmata"],
			["schema", "schemata"],
			["anathema", "anathemata"],
			["ox", "oxen"],
			["axe", "axes"],
			["die", "dice"],
			["yes", "yeses"],
			["foot", "feet"],
			["eave", "eaves"],
			["goose", "geese"],
			["tooth", "teeth"],
			["quiz", "quizzes"],
			["human", "humans"],
			["proof", "proofs"],
			["carve", "carves"],
			["valve", "valves"],
			["looey", "looies"],
			["thief", "thieves"],
			["groove", "grooves"],
			["pickaxe", "pickaxes"],
			["passerby", "passersby"]
		].forEach(function(rule) {
			return pluralize.addIrregularRule(rule[0], rule[1]);
		});
		/**
		* Pluralization rules.
		*/
		[
			[/s?$/i, "s"],
			[/[^\u0000-\u007F]$/i, "$0"],
			[/([^aeiou]ese)$/i, "$1"],
			[/(ax|test)is$/i, "$1es"],
			[/(alias|[^aou]us|t[lm]as|gas|ris)$/i, "$1es"],
			[/(e[mn]u)s?$/i, "$1s"],
			[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i, "$1"],
			[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i, "$1i"],
			[/(alumn|alg|vertebr)(?:a|ae)$/i, "$1ae"],
			[/(seraph|cherub)(?:im)?$/i, "$1im"],
			[/(her|at|gr)o$/i, "$1oes"],
			[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i, "$1a"],
			[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i, "$1a"],
			[/sis$/i, "ses"],
			[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i, "$1$2ves"],
			[/([^aeiouy]|qu)y$/i, "$1ies"],
			[/([^ch][ieo][ln])ey$/i, "$1ies"],
			[/(x|ch|ss|sh|zz)$/i, "$1es"],
			[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i, "$1ices"],
			[/\b((?:tit)?m|l)(?:ice|ouse)$/i, "$1ice"],
			[/(pe)(?:rson|ople)$/i, "$1ople"],
			[/(child)(?:ren)?$/i, "$1ren"],
			[/eaux$/i, "$0"],
			[/m[ae]n$/i, "men"],
			["thou", "you"]
		].forEach(function(rule) {
			return pluralize.addPluralRule(rule[0], rule[1]);
		});
		/**
		* Singularization rules.
		*/
		[
			[/s$/i, ""],
			[/(ss)$/i, "$1"],
			[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i, "$1fe"],
			[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i, "$1f"],
			[/ies$/i, "y"],
			[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i, "$1ie"],
			[/\b(mon|smil)ies$/i, "$1ey"],
			[/\b((?:tit)?m|l)ice$/i, "$1ouse"],
			[/(seraph|cherub)im$/i, "$1"],
			[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i, "$1"],
			[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i, "$1sis"],
			[/(movie|twelve|abuse|e[mn]u)s$/i, "$1"],
			[/(test)(?:is|es)$/i, "$1is"],
			[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i, "$1us"],
			[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i, "$1um"],
			[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i, "$1on"],
			[/(alumn|alg|vertebr)ae$/i, "$1a"],
			[/(cod|mur|sil|vert|ind)ices$/i, "$1ex"],
			[/(matr|append)ices$/i, "$1ix"],
			[/(pe)(rson|ople)$/i, "$1rson"],
			[/(child)ren$/i, "$1"],
			[/(eau)x?$/i, "$1"],
			[/men$/i, "man"]
		].forEach(function(rule) {
			return pluralize.addSingularRule(rule[0], rule[1]);
		});
		/**
		* Uncountable rules.
		*/
		[
			"adulthood",
			"advice",
			"agenda",
			"aid",
			"aircraft",
			"alcohol",
			"ammo",
			"analytics",
			"anime",
			"athletics",
			"audio",
			"bison",
			"blood",
			"bream",
			"buffalo",
			"butter",
			"carp",
			"cash",
			"chassis",
			"chess",
			"clothing",
			"cod",
			"commerce",
			"cooperation",
			"corps",
			"debris",
			"diabetes",
			"digestion",
			"elk",
			"energy",
			"equipment",
			"excretion",
			"expertise",
			"firmware",
			"flounder",
			"fun",
			"gallows",
			"garbage",
			"graffiti",
			"hardware",
			"headquarters",
			"health",
			"herpes",
			"highjinks",
			"homework",
			"housework",
			"information",
			"jeans",
			"justice",
			"kudos",
			"labour",
			"literature",
			"machinery",
			"mackerel",
			"mail",
			"media",
			"mews",
			"moose",
			"music",
			"mud",
			"manga",
			"news",
			"only",
			"personnel",
			"pike",
			"plankton",
			"pliers",
			"police",
			"pollution",
			"premises",
			"rain",
			"research",
			"rice",
			"salmon",
			"scissors",
			"series",
			"sewage",
			"shambles",
			"shrimp",
			"software",
			"species",
			"staff",
			"swine",
			"tennis",
			"traffic",
			"transportation",
			"trout",
			"tuna",
			"wealth",
			"welfare",
			"whiting",
			"wildebeest",
			"wildlife",
			"you",
			/pok[eé]mon$/i,
			/[^aeiou]ese$/i,
			/deer$/i,
			/fish$/i,
			/measles$/i,
			/o[iu]s$/i,
			/pox$/i,
			/sheep$/i
		].forEach(pluralize.addUncountableRule);
		return pluralize;
	});
}));
var import_pluralize = /* @__PURE__ */ __toESM(require_pluralize());
/**
* Check if a command type is a prompt response (not a user message).
* Prompt responses are displayed inline with the prompt UI, not as separate user messages.
*/
function isPromptResponseCommand(type) {
	return type === COMMAND_TYPES.ASK_USER_RESPONSE || type === COMMAND_TYPES.ELICITATION_RESPONSE || type === COMMAND_TYPES.PERMISSION_RESPONSE || type === COMMAND_TYPES.PLAN_APPROVAL_RESPONSE;
}
function stateToDescriptors({ state, count }) {
	return {
		queued: {
			actionText: "Queued for Copilot",
			containerStateClass: UserCommand_module_default.containerMuted
		},
		failed: {
			actionText: `Unable to submit ${(0, import_pluralize.default)("message", count)}`,
			containerStateClass: UserCommand_module_default.containerMuted
		},
		in_logs: {},
		dismissed: {
			actionText: `Copilot finished the session before it could pick up ${(0, import_pluralize.default)("this", count)} ${(0, import_pluralize.default)("message", count)}`,
			containerStateClass: UserCommand_module_default.containerMuted
		}
	}[state];
}
function getDisplayState({ sessionIsActive, commandState, inLogs }) {
	if (inLogs) return "in_logs";
	const happyPathStates = [
		"queued",
		"in_progress",
		"completed"
	];
	const unhappyPathStates = ["failed", "dismissed"];
	if (!sessionIsActive && happyPathStates.includes(commandState)) return "dismissed";
	else if (happyPathStates.includes(commandState)) return "queued";
	else if (unhappyPathStates.includes(commandState)) return commandState;
	else throw new Error(`Unexpected command state: ${commandState}`);
}
function LogCommands(t0) {
	const { rawCommands, commandData } = t0;
	const commands = [];
	const { session } = useSessionContext();
	const sessionIsActive = isActiveSession(session);
	for (const rawCommand of rawCommands) {
		const command = findCommandByID(commandData, rawCommand);
		let processedCommand;
		if (command) {
			if (isPromptResponseCommand(command.type)) continue;
			processedCommand = {
				state: getDisplayState({
					sessionIsActive,
					commandState: command.state,
					inLogs: true
				}),
				content: command.content
			};
		} else if (isCLISession(session)) {
			const content = typeof rawCommand.content === "string" ? rawCommand.content : rawCommand.content?.map(_temp$28).join("");
			if (content) processedCommand = {
				state: "in_logs",
				content
			};
		}
		if (processedCommand) commands.push(processedCommand);
	}
	return jsx(ProcessedUserCommands, { commands });
}
LogCommands.displayName = "LogCommands";
function _temp$28(c) {
	return "text" in c ? c.text : "";
}
function ChatCommands(t0) {
	const { commands } = t0;
	const processedCommands = [];
	const { session } = useSessionContext();
	const sessionIsActive = isActiveSession(session);
	for (const command of commands) {
		if (isPromptResponseCommand(command.type)) continue;
		const processedCommand = {
			state: getDisplayState({
				sessionIsActive,
				commandState: command.state,
				inLogs: false
			}),
			content: command.content
		};
		processedCommands.push(processedCommand);
	}
	return jsx(ProcessedUserCommands, { commands: processedCommands });
}
ChatCommands.displayName = "ChatCommands";
function ProcessedUserCommands({ commands }) {
	const commandsByState = [];
	for (const command of commands) {
		const lastGroup = commandsByState[commandsByState.length - 1];
		if (lastGroup?.state === command.state) lastGroup.commands.push(command.content);
		else commandsByState.push({
			state: command.state,
			commands: [command.content]
		});
	}
	return /* @__PURE__ */ jsx(Fragment$1, { children: commandsByState.map((commandGroup, index) => /* @__PURE__ */ jsx(UserCommandGroup, {
		contents: commandGroup.commands,
		state: commandGroup.state
	}, index)) });
}
ProcessedUserCommands.displayName = "ProcessedUserCommands";
function UserCommandGroup({ contents, state }) {
	const descriptors = stateToDescriptors({
		state,
		count: contents.length
	});
	const actionText = descriptors.actionText;
	const containerStateClass = descriptors.containerStateClass;
	return /* @__PURE__ */ jsx(Stack, { children: /* @__PURE__ */ jsxs("div", {
		className: `mb-2 ${UserCommand_module_default.commandContainer} ${containerStateClass ?? ""}`,
		children: [actionText && /* @__PURE__ */ jsx("div", {
			className: `mb-2 ${UserCommand_module_default.actionText}`,
			children: actionText
		}), contents.map((content, index) => /* @__PURE__ */ jsx(UserCommand, { content }, index))]
	}) });
}
UserCommandGroup.displayName = "UserCommandGroup";
function UserCommand(t0) {
	const $ = c$1(4);
	const { content } = t0;
	const { sessionOwner } = useSessionContext();
	const displayName = sessionOwner?.login ?? "user";
	let t1;
	if ($[0] !== content || $[1] !== displayName || $[2] !== sessionOwner) {
		t1 = jsxs(Stack, {
			align: "start",
			direction: "horizontal",
			gap: "condensed",
			className: UserCommand_module_default.commandRow,
			children: [jsx("span", {
				className: UserCommand_module_default.commandBox,
				children: content
			}), sessionOwner?.primaryAvatarUrl && jsx(GitHubAvatar, {
				src: sessionOwner.primaryAvatarUrl,
				alt: `${displayName}'s avatar`,
				size: 28,
				className: UserCommand_module_default.avatar
			})]
		});
		$[0] = content;
		$[1] = displayName;
		$[2] = sessionOwner;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
UserCommand.displayName = "UserCommand";
function findCommandByID(commandData, logEntry) {
	const matchingCommand = commandData.find((command) => `command-${command.external_id}` === logEntry.source);
	if (!matchingCommand) return null;
	if (typeof logEntry.content !== "string") return null;
	return matchingCommand;
}
/**
* Checks if a command appears in the logs by matching the source field.
* sweagentd sets source to `command-{external_id}` when processing commands.
*/
function isCommandInLogs(command, logEntry) {
	return isCompletionUserMessage(logEntry) && logEntry.source === `command-${command.external_id}`;
}
/**
* Filters commands to return only those that are still pending (not yet processed or shown in logs).
*
* - CLI: marks commands 'completed' immediately, so filter by state works
* - sweagentd: commands stay 'in_progress' forever, so also check source matching
* - Failed commands are shown because they never appear in logs
*/
function getPendingCommands(commandsData, logsData) {
	if (!commandsData?.length) return [];
	return commandsData.filter((command) => {
		if (command.state === "completed" || command.state === "dismissed") return false;
		if (command.state === "in_progress" && logsData?.some((log) => isCommandInLogs(command, log))) return false;
		return true;
	});
}
var SessionLogs_module_default = {
	copilotMessage: "SessionLogs-module_L0o15a_copilotMessage",
	copilotMessageContent: "SessionLogs-module_L0o15a_copilotMessageContent",
	intentDetectionChatAssistantContainer: "SessionLogs-module_L0o15a_intentDetectionChatAssistantContainer",
	intentDetectionChatAssistantMessageContainer: "SessionLogs-module_L0o15a_intentDetectionChatAssistantMessageContainer",
	intentDetectionChatContainer: "SessionLogs-module_L0o15a_intentDetectionChatContainer",
	intentDetectionChatMessageContainer: "SessionLogs-module_L0o15a_intentDetectionChatMessageContainer",
	intentDetectionChatMessageText: "SessionLogs-module_L0o15a_intentDetectionChatMessageText",
	intentDetectionChatUserContainer: "SessionLogs-module_L0o15a_intentDetectionChatUserContainer",
	intentDetectionChatUserMessageContainer: "SessionLogs-module_L0o15a_intentDetectionChatUserMessageContainer",
	markdownWrapper: "SessionLogs-module_L0o15a_markdownWrapper"
};
/**
* Extracts MCP tool name to display name mappings from log entries that contain
* run_setup tool calls with mcp_setup details.
*
* @param logEntries - Array of preprocessed log entries to search through
* @returns A record mapping tool names to their display names
*/
function extractMcpToolNameMappings(logEntries) {
	const mappings = {};
	for (const logEntry of logEntries) {
		if (isCustomAgentSessionGroup(logEntry) || !isCompletionChunk(logEntry)) continue;
		for (const choice of logEntry.choices) {
			const toolCalls = choice.delta.tool_calls ?? [];
			for (const toolCall of toolCalls) {
				const toolCallFunction = toolCall?.function;
				if (!toolCallFunction || toolCallFunction.name !== "run_setup" || typeof toolCallFunction.arguments !== "string") continue;
				try {
					const parsedArgs = JSON.parse(toolCallFunction.arguments.replace(/\n/g, "\\n"));
					if (parsedArgs.details?.type === "mcp_setup" && typeof parsedArgs.details.toolNamesToDisplayNames === "object") Object.assign(mappings, parsedArgs.details.toolNamesToDisplayNames ?? {});
				} catch {}
			}
		}
	}
	return mappings;
}
var ToolGroupRenderer_module_default = {
	connectorLine: "ToolGroupRenderer-module_VE4tOa_connectorLine",
	toolGroupContent: "ToolGroupRenderer-module_VE4tOa_toolGroupContent",
	toolGroupContentWrapper: "ToolGroupRenderer-module_VE4tOa_toolGroupContentWrapper",
	toolGroupHeader: "ToolGroupRenderer-module_VE4tOa_toolGroupHeader"
};
function ToolGroupRenderer(t0) {
	const $ = c$1(1);
	const { group, groupHeaderFn, children } = t0;
	const headerData = groupHeaderFn(group);
	const [isCollapsed, setIsCollapsed] = useState(group.entries.length >= 30);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			setIsCollapsed(_temp$27);
		};
		$[0] = t1;
	} else t1 = $[0];
	const handleToggle = t1;
	return jsxs("div", { children: [jsx("div", {
		className: ToolGroupRenderer_module_default.toolGroupHeader,
		children: jsx(NewToolHeader, {
			title: headerData.title,
			leadingVisual: headerData.leadingVisual,
			isError: false,
			isPending: false,
			isCollapsed,
			isGroupHeader: true,
			onToggle: handleToggle
		})
	}), !isCollapsed && jsxs("div", {
		className: ToolGroupRenderer_module_default.toolGroupContentWrapper,
		children: [jsx("div", { className: ToolGroupRenderer_module_default.connectorLine }), jsx("div", {
			className: ToolGroupRenderer_module_default.toolGroupContent,
			children
		})]
	})] });
}
ToolGroupRenderer.displayName = "ToolGroupRenderer";
function _temp$27(prev) {
	return !prev;
}
/**
* Generate a unique ID for a log entry for use in standalone groups
*/
function getItemId(item) {
	if (item.type === "choice") return `${item.entryId}-${item.choiceIndex}`;
	return `other-${item.index}`;
}
function ToolGrouping({ entries, groupingFn, groupHeaderFn, children }) {
	const result = [];
	let lastGroup = null;
	for (const item of entries) {
		const groupingResult = groupingFn(item, lastGroup);
		if (groupingResult.shouldGroup && groupingResult.groupId && lastGroup && !lastGroup.metadata?.standalone && lastGroup.id === groupingResult.groupId && lastGroup) {
			lastGroup.entries.push(item);
			if (groupingResult.groupMetadata) lastGroup.metadata = {
				...lastGroup.metadata,
				...groupingResult.groupMetadata
			};
		} else if (groupingResult.shouldGroup && groupingResult.groupId) {
			const newGroup = {
				id: groupingResult.groupId,
				entries: [item],
				metadata: groupingResult.groupMetadata
			};
			result.push(newGroup);
			lastGroup = newGroup;
		} else {
			const standaloneGroup = {
				id: `standalone-${getItemId(item)}`,
				entries: [item],
				metadata: { standalone: true }
			};
			result.push(standaloneGroup);
			lastGroup = standaloneGroup;
		}
	}
	return /* @__PURE__ */ jsx(Fragment$1, { children: result.map((group) => {
		const isStandalone = group.metadata?.standalone === true;
		const firstItem = group.entries[0];
		const isSingleItemGroup = group.entries.length === 1;
		if ((isStandalone || isSingleItemGroup) && firstItem) return /* @__PURE__ */ jsx(Fragment, { children: children(firstItem) }, group.id);
		const toolName = group.metadata?.toolName;
		const isEditGroup = EDIT_TOOLS.includes(toolName);
		return /* @__PURE__ */ jsx(ToolGroupRenderer, {
			group,
			groupHeaderFn,
			children: group.entries.map((item) => children(item, {
				isInGroup: true,
				groupId: group.id,
				isEditGroup
			}))
		}, group.id);
	}) });
}
ToolGrouping.displayName = "ToolGrouping";
/**
* Type guard to check if a session log item is a choice
*/
function isChoiceItem(item) {
	return item.type === "choice";
}
/**
* Helper to check if a view tool call has a path (viewing a file) vs no path (viewing repository)
* Uses the exact same logic as getCommandTitle in Tool.tsx: `!!trimFileName(path)?.length`
*/
function hasViewPath(choiceWithContext) {
	const { choice } = choiceWithContext;
	const toolCall = choice?.delta?.tool_calls?.[0];
	if (!toolCall) return false;
	const argsString = toolCall.function?.arguments;
	if (!argsString) return false;
	try {
		return !!trimFileName(JSON.parse(argsString).path || "")?.length;
	} catch {
		return false;
	}
}
/**
* Extracts the tool name from a choice.
*/
function getToolName(choiceWithContext) {
	const { choice } = choiceWithContext;
	const delta = choice?.delta;
	if (!delta?.tool_calls || delta.tool_calls.length === 0) return null;
	const toolCall = delta.tool_calls[0];
	const functionName = toolCall?.function?.name ?? toolCall?.custom?.name ?? null;
	if (!functionName) return null;
	if (functionName === TOOL_NAMES.STR_REPLACE_EDITOR || functionName === TOOL_NAMES.EDIT) {
		if (functionName === TOOL_NAMES.EDIT) return "str_replace";
		const argsString = toolCall?.function?.arguments ?? null;
		if (argsString) try {
			return JSON.parse(argsString).command || functionName;
		} catch {
			return functionName;
		}
		return functionName;
	}
	return functionName;
}
/**
* Grouping function that groups consecutive tool calls of the same type.
* Non-choice items (commands, etc.) are never grouped and break any active grouping.
*/
var groupByConsecutiveToolName = (item, lastGroup) => {
	if (!isChoiceItem(item)) return { shouldGroup: false };
	const currentToolName = getToolName(item);
	if (!currentToolName) return { shouldGroup: false };
	if (SHELL_TOOLS.includes(currentToolName)) return { shouldGroup: false };
	if (currentToolName === TOOL_NAMES.TASK && isFeatureEnabled("copilot_mission_control_decoupled_mode")) return { shouldGroup: false };
	const isSetupTool = SETUP_TOOLS.includes(currentToolName);
	const lastGroupToolName = lastGroup?.metadata?.toolName;
	const lastGroupIsSetupTool = lastGroup?.metadata?.isSetupTool;
	if (isSetupTool && lastGroupIsSetupTool && lastGroup) return {
		shouldGroup: true,
		groupId: lastGroup.id,
		groupMetadata: {
			toolName: lastGroupToolName,
			isSetupTool: true
		}
	};
	const isViewRepository = currentToolName === "view" && !hasViewPath(item);
	const lastGroupIsViewRepository = lastGroup?.metadata?.isViewRepository ?? false;
	if (currentToolName === "view" && lastGroupToolName === "view") {
		if (isViewRepository !== lastGroupIsViewRepository) return {
			shouldGroup: true,
			groupId: crypto.randomUUID(),
			groupMetadata: {
				toolName: currentToolName,
				isViewRepository,
				isSetupTool
			}
		};
	}
	if (lastGroupToolName === currentToolName && !lastGroup?.metadata?.standalone && lastGroup) return {
		shouldGroup: true,
		groupId: lastGroup.id,
		groupMetadata: {
			toolName: currentToolName,
			isViewRepository,
			isSetupTool
		}
	};
	if (currentToolName) return {
		shouldGroup: true,
		groupId: `${currentToolName}-${item.entryId}-${item.choiceIndex}`,
		groupMetadata: {
			toolName: currentToolName,
			isViewRepository,
			isSetupTool
		}
	};
	return { shouldGroup: false };
};
/**
* Helper to create a group header with a title and icon
*/
function createHeader(title, iconToolName, mcpToolNameMappings) {
	return {
		title,
		leadingVisual: getToolIcon(iconToolName, mcpToolNameMappings)
	};
}
/**
* Type guard to check if a tool name has display config
*/
function hasDisplayConfig(toolName) {
	return toolName in TOOL_GROUP_DISPLAY_CONFIG;
}
/**
* Creates a header function that creates a title based on tool type and count.
* Accepts optional MCP tool name mappings to show the MCP icon for MCP tools.
*/
function createGroupHeader(mcpToolNameMappings) {
	return (group) => {
		const toolName = group.metadata?.toolName;
		const count = group.entries.length;
		if (!toolName) return {
			title: `${count} operations`,
			leadingVisual: void 0
		};
		if (hasDisplayConfig(toolName)) {
			const displayConfig = TOOL_GROUP_DISPLAY_CONFIG[toolName];
			if (displayConfig) return createHeader(displayConfig.getTitle(count), displayConfig.iconToolName, mcpToolNameMappings);
		}
		return {
			title: `${toolName}`,
			leadingVisual: getToolIcon(toolName, mcpToolNameMappings)
		};
	};
}
createGroupHeader();
var ResolvedPromptDisplay_module_default = { content: "ResolvedPromptDisplay-module_e3oeqa_content" };
/** Renders a resolved interactive prompt in the same style as Tool calls */
function ResolvedPromptDisplay(t0) {
	const $ = c$1(7);
	const { icon, title, subtitle, children } = t0;
	const hasContent = children != null;
	const [isCollapsed, setIsCollapsed] = useState(!hasContent);
	const displayTitle = subtitle ? `${title} · ${subtitle}` : title;
	let t1;
	if ($[0] !== children || $[1] !== displayTitle || $[2] !== hasContent || $[3] !== icon || $[4] !== isCollapsed) {
		let t2;
		if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = () => setIsCollapsed(_temp$26);
			$[6] = t2;
		} else t2 = $[6];
		t1 = jsxs("div", {
			className: ResolvedPromptDisplay_module_default.container,
			children: [jsx(NewToolHeader, {
				leadingVisual: icon,
				title: displayTitle,
				isCollapsed,
				hasReferences: hasContent,
				onToggle: t2
			}), !isCollapsed && hasContent ? jsx("div", {
				className: ResolvedPromptDisplay_module_default.content,
				children
			}) : null]
		});
		$[0] = children;
		$[1] = displayTitle;
		$[2] = hasContent;
		$[3] = icon;
		$[4] = isCollapsed;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
ResolvedPromptDisplay.displayName = "ResolvedPromptDisplay";
function _temp$26(prev) {
	return !prev;
}
/** Resolved ask_user prompt shown in the session timeline */
function ResolvedAskUser({ question, title, isSkipped = false, resolvedAnswer }) {
	const cardTitle = title ?? question;
	let displayAnswer;
	if (isSkipped) displayAnswer = void 0;
	else if (resolvedAnswer === "Declined") displayAnswer = "Declined";
	else if (resolvedAnswer) displayAnswer = resolvedAnswer;
	return /* @__PURE__ */ jsx(ResolvedPromptDisplay, {
		icon: /* @__PURE__ */ jsx(QuestionIcon, { size: 16 }),
		title: cardTitle,
		subtitle: isSkipped ? "Skipped" : void 0,
		children: displayAnswer
	});
}
ResolvedAskUser.displayName = "ResolvedAskUser";
/** Renders a resolved ask_user prompt in the session logs timeline. */
function AskUserLogEntry({ prompt, resolvedAnswer }) {
	const { arguments: args } = prompt;
	if (!isAskUserArguments(args)) return null;
	return /* @__PURE__ */ jsx(ResolvedAskUser, {
		question: isElicitationAskUser(args) ? args.message : args.question,
		resolvedAnswer
	});
}
AskUserLogEntry.displayName = "AskUserLogEntry";
/** Resolved plan approval shown in the session timeline */
function ResolvedPlanApproval() {
	return /* @__PURE__ */ jsx(ResolvedPromptDisplay, {
		icon: /* @__PURE__ */ jsx(CheckCircleIcon, { size: 16 }),
		title: "Plan approved"
	});
}
ResolvedPlanApproval.displayName = "ResolvedPlanApproval";
/** Renders a resolved exit_plan_mode prompt in the session logs timeline. */
function PlanApprovalLogEntry({ prompt }) {
	if (!isExitPlanModeArguments(prompt.arguments)) return null;
	return /* @__PURE__ */ jsx(ResolvedPlanApproval, {});
}
PlanApprovalLogEntry.displayName = "PlanApprovalLogEntry";
/** Resolved permission prompt shown in the session timeline — only for denied permissions */
function ResolvedPermission({ kind, toolName, detail }) {
	const label = kind === "commands" || kind === "shell" ? "Run command" : kind === "write" ? "Edit file" : `Permission: ${toolName ?? kind}`;
	const subtitle = detail ? `Denied · ${detail}` : "Denied";
	return /* @__PURE__ */ jsx(ResolvedPromptDisplay, {
		icon: /* @__PURE__ */ jsx(ShieldCheckIcon, { size: 16 }),
		title: label,
		subtitle,
		children: detail
	});
}
ResolvedPermission.displayName = "ResolvedPermission";
/** Renders a resolved permission_request prompt in the session logs timeline.
*  Accepted → hidden (returns null). Denied → shows ResolvedPermission. */
function PermissionLogEntry({ prompt, resolvedAnswer }) {
	const { arguments: args } = prompt;
	if (!isPermissionRequestArguments(args)) return null;
	if (!(resolvedAnswer === "Denied" || resolvedAnswer === "false")) return null;
	return /* @__PURE__ */ jsx(ResolvedPermission, {
		kind: args.kind,
		toolName: args.toolName,
		detail: args.command || args.filePath || args.diff
	});
}
PermissionLogEntry.displayName = "PermissionLogEntry";
/**
* Renders an interactive prompt (ask_user, permission_request, exit_plan_mode)
* in the session logs timeline. Resolves the response centrally and delegates
* to the appropriate specialized component.
*/
function InteractivePromptLogEntry({ prompt, logsData, optimisticResponse }) {
	const { toolCallId, toolName } = prompt;
	const serverResponse = findToolResponse(toolCallId, logsData);
	const optimisticAnswer = optimisticResponse !== void 0 && optimisticResponse.status === "pending" ? formatOptimisticResponse(optimisticResponse.response, optimisticResponse.commandType) : void 0;
	const resolvedAnswer = serverResponse ?? optimisticAnswer;
	switch (toolName) {
		case "ask_user": return /* @__PURE__ */ jsx(AskUserLogEntry, {
			prompt,
			resolvedAnswer
		});
		case "exit_plan_mode": return /* @__PURE__ */ jsx(PlanApprovalLogEntry, { prompt });
		case "permission_request": return /* @__PURE__ */ jsx(PermissionLogEntry, {
			prompt,
			resolvedAnswer
		});
		default: return null;
	}
}
InteractivePromptLogEntry.displayName = "InteractivePromptLogEntry";
var CustomAgentSessionGroup_module_default = {
	detailsContainer: "CustomAgentSessionGroup-module_dAML2q_detailsContainer",
	promptBubble: "CustomAgentSessionGroup-module_dAML2q_promptBubble",
	promptText: "CustomAgentSessionGroup-module_dAML2q_promptText",
	toolContent: "CustomAgentSessionGroup-module_dAML2q_toolContent",
	toolContentWrapper: "CustomAgentSessionGroup-module_dAML2q_toolContentWrapper"
};
var TOOL_DISPLAY_NAMES = {
	[TOOL_NAMES.BASH]: "Run Bash command",
	[TOOL_NAMES.VIEW]: "View file",
	[TOOL_NAMES.EDIT]: "Edit file",
	[TOOL_NAMES.CREATE]: "Create file",
	[TOOL_NAMES.GREP]: "Search",
	[TOOL_NAMES.RG]: "Search",
	[TOOL_NAMES.GLOB]: "Find files",
	[TOOL_NAMES.STR_REPLACE_EDITOR]: "Edit file",
	[TOOL_NAMES.STR_REPLACE]: "Edit file",
	[TOOL_NAMES.APPLY_PATCH]: "Apply patch",
	[TOOL_NAMES.WEB_SEARCH]: "Web search",
	[TOOL_NAMES.WEB_FETCH]: "Fetch URL",
	[TOOL_NAMES.THINK]: "Thinking",
	[TOOL_NAMES.COMMIT_CHANGES]: "Commit changes"
};
/**
* Extracts a human-readable title for the last tool call in the group's logs.
* Prioritises the description field (set by the agent for bash/shell tools),
* then falls back to path for file tools, then just the display name.
*/
function getLastToolCallTitle(group) {
	for (let i = group.logs.length - 1; i >= 0; i--) {
		const log = group.logs[i];
		if (!log || !isCompletionChunk(log)) continue;
		for (const choice of log.choices) {
			const toolCalls = choice.delta?.tool_calls ?? [];
			for (const tc of toolCalls) {
				const name = tc?.function?.name ?? tc?.custom?.name;
				if (!name) continue;
				const displayName = TOOL_DISPLAY_NAMES[name] ?? name;
				const args = parseToolCallArgs(tc?.function?.arguments);
				if (!args) return displayName;
				if (args.description) return args.description;
				if (args.path) return `${displayName}: ${args.path}`;
				if (args.pattern) return `${displayName}: ${args.pattern}`;
				if (args.command) return `${displayName}: ${args.command.slice(0, 60)}`;
				return displayName;
			}
		}
	}
	return null;
}
function parseToolCallArgs(raw) {
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
/**
* Renders a nested subagent session with visual indication of the grouping.
*
* When collapsed, shows the last tool call name inline after the title as muted text.
* When expanded, shows full content with prompt bubble at the top.
*/
function CustomAgentSessionGroup({ customAgentSession, children }) {
	const [isDetailsOpen, setIsDetailsOpen] = useState(false);
	const agentInstanceRef = useRef({});
	const title = formatAgentTitle(customAgentSession);
	const isPending = customAgentSession.isPending;
	const prompt = customAgentSession.prompt;
	const lastToolTitle = useMemo(() => getLastToolCallTitle(customAgentSession), [customAgentSession]);
	const showLastTool = !isDetailsOpen && isPending && lastToolTitle;
	useEffect(() => {
		const handler = (event) => {
			const customEvent = event;
			if (customEvent.detail.excludeInstance !== agentInstanceRef.current) setIsDetailsOpen(customEvent.detail.expand);
		};
		document.addEventListener("mission-control-tool-global-toggle", handler);
		return () => {
			document.removeEventListener("mission-control-tool-global-toggle", handler);
		};
	}, []);
	const handleModifierClick = useCallback((expand) => {
		setIsDetailsOpen(expand);
		const event_0 = new CustomEvent("mission-control-tool-global-toggle", { detail: {
			expand,
			excludeInstance: agentInstanceRef.current
		} });
		document.dispatchEvent(event_0);
	}, []);
	const handleHeaderToggle = useCallback(() => {
		setIsDetailsOpen((prev) => !prev);
	}, []);
	return /* @__PURE__ */ jsxs("div", {
		className: CustomAgentSessionGroup_module_default.detailsContainer,
		children: [/* @__PURE__ */ jsx(NewToolHeader, {
			title,
			isCollapsed: !isDetailsOpen,
			isPending,
			onModifierClick: handleModifierClick,
			onToggle: handleHeaderToggle,
			leadingVisual: /* @__PURE__ */ jsx(DependabotIcon, {}),
			statusText: showLastTool ? lastToolTitle : void 0
		}), isDetailsOpen && /* @__PURE__ */ jsxs("div", {
			className: CustomAgentSessionGroup_module_default.toolContentWrapper,
			children: [/* @__PURE__ */ jsx("div", { className: ToolGroupRenderer_module_default.connectorLine }), /* @__PURE__ */ jsxs("div", {
				className: CustomAgentSessionGroup_module_default.toolContent,
				children: [prompt && /* @__PURE__ */ jsx("div", {
					className: CustomAgentSessionGroup_module_default.promptBubble,
					children: /* @__PURE__ */ jsx(ExpandableMarkdown, {
						markdown: prompt,
						className: CustomAgentSessionGroup_module_default.promptText
					})
				}), children]
			})]
		})]
	});
}
CustomAgentSessionGroup.displayName = "CustomAgentSessionGroup";
var EmptyCliSession_module_default = { EmptyCliSession: "EmptyCliSession-module_OAqkEq_EmptyCliSession" };
function EmptyCliSession() {
	return /* @__PURE__ */ jsx("div", {
		className: EmptyCliSession_module_default.EmptyCliSession,
		children: "Session ready. Waiting for your input."
	});
}
EmptyCliSession.displayName = "EmptyCliSession";
var NO_PENDING_PROMPT = {
	pendingPrompt: null,
	pendingToolCallId: null,
	hasPendingPrompt: false
};
/**
* Computes the last unresolved interactive prompt from session logs.
*/
function computePendingPrompt(logs) {
	if (!logs?.length) return NO_PENDING_PROMPT;
	const prompts = [];
	for (let i = 0; i < logs.length; i++) {
		const entry = logs[i];
		if (entry) {
			const prompt = extractPromptFromEntry(entry);
			if (prompt) prompts.push({
				prompt,
				index: i
			});
		}
	}
	for (let i = prompts.length - 1; i >= 0; i--) {
		const item = prompts[i];
		if (item && !isPromptResolved(item.prompt.toolCallId, logs)) return {
			pendingPrompt: item.prompt,
			pendingToolCallId: item.prompt.toolCallId,
			hasPendingPrompt: true
		};
	}
	return NO_PENDING_PROMPT;
}
/**
* Hook that detects the last unresolved CLI prompt from session logs.
*
* Used to:
* 1. Filter pending prompts from inline log display
* 2. Show pending prompts prominently in chat input area
*
* @param logs - The session log entries to analyze
* @returns The pending prompt info, or null values if no pending prompt
*/
function usePendingPrompt(logs) {
	const $ = c$1(2);
	let t0;
	if ($[0] !== logs) {
		t0 = computePendingPrompt(logs);
		$[0] = logs;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
/**
* When a choice has BOTH reasoning_text AND tool_calls, split it into two separate choices:
* 1. First choice: reasoning_text only (no tool_calls, no content) - renders outside groups
* 2. Second choice: tool_calls and content (no reasoning_text) - can be grouped with other tools
*
* This ensures reasoning_text renders before tool groups rather than inside them.
*/
function splitChoiceWithReasoningText(choice) {
	const hasReasoningText = !!choice.delta.reasoning_text;
	const hasToolCalls = !!(choice.delta.tool_calls && choice.delta.tool_calls.length > 0);
	if (hasReasoningText && hasToolCalls) return [{
		...choice,
		delta: {
			...choice.delta,
			tool_calls: void 0,
			content: void 0
		}
	}, {
		...choice,
		delta: {
			...choice.delta,
			reasoning_text: void 0
		}
	}];
	return [choice];
}
/**
* Determines whether a choice should be split based on having both reasoning_text and tool_calls.
*/
function shouldSplitChoice(choice) {
	const hasReasoningText = !!choice.delta.reasoning_text;
	const hasToolCalls = !!(choice.delta.tool_calls && choice.delta.tool_calls.length > 0);
	return hasReasoningText && hasToolCalls;
}
var ContentPreviewBlockContext = createContext(null);
ContentPreviewBlockContext.displayName = "ContentPreviewBlockContext";
var useContentPreviewBlockContext = () => {
	const context = use(ContentPreviewBlockContext);
	if (!context) throw new Error("Missing required ContentPreviewBlockContext provider.");
	return context;
};
/**
* Tracks changes to a value across render cycles and returns the value that was used in the previous render cycle.
* Note: This hook will return undefined on the first render cycle.
*/
function usePreviousValue(value) {
	const ref = useRef(void 0);
	useEffect(() => {
		ref.current = value;
	}, [value]);
	return ref.current;
}
/**
* This hook allows us to avoid losing a callback reference on component re-renders by returning a function that is referentially constant (it can never be outdated).
*
* The hook will also remove the hook function reference on unmount.
*
* This hook is preferred over `useSafeAsyncCallback` when the callback is not async and you need the function reference to be available on first mount.
*
* @param fn the function to call
* @throws {Error} if the callback is invoked after the component has unmounted
*/
var useStableCallback = (fn) => {
	const $ = c$1(4);
	const trackingRef = useRef(fn);
	let t0;
	let t1;
	if ($[0] !== fn) {
		t0 = () => {
			trackingRef.current = fn;
			return () => trackingRef.current = null;
		};
		t1 = [fn];
		$[0] = fn;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useLayoutEffect(t0, t1);
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (...t3) => {
			const args = t3;
			if (trackingRef.current === null) throw new Error("useStableCallback: Cannot call callback after component has unmounted");
			return trackingRef.current(...args);
		};
		$[3] = t2;
	} else t2 = $[3];
	return t2;
};
/**
* Easy boolean state manager. Returns two stable state setters instead of one, allowing you to combine a `useState`
* and two `useCallback` calls into one single `useBooleanState` call.
*/
function useBooleanState(initialValue) {
	const $ = c$1(4);
	const [state, setState] = useState(initialValue);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => setState(true);
		$[0] = t0;
	} else t0 = $[0];
	const setTrue = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => setState(false);
		$[1] = t1;
	} else t1 = $[1];
	const setFalse = t1;
	let t2;
	if ($[2] !== state) {
		t2 = [
			state,
			setTrue,
			setFalse
		];
		$[2] = state;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
/**
* Serializes draft issue projects for sending to the backend.
*
* Returns DraftIssueProjectReference[] (objects with id and title).
*
* @param projects - Array of project references to serialize
* @returns Serialized projects as DraftIssueProjectReference[]
*/
function serializeDraftIssueProjects(projects) {
	if (!projects || projects.length === 0) return [];
	return projects.filter((project) => Boolean(project.title) || Boolean(project.id));
}
/**
* Deserializes draft issue projects received from the backend.
*
* Accepts two input formats:
* - string[] (legacy format from older backend versions)
* - DraftIssueProjectReference[] (new format with id and title)
*
* Always returns DraftIssueProjectReference[] for consistent internal representation.
*
* @param projects - Projects in either string[] or DraftIssueProjectReference[] format
* @returns Array of DraftIssueProjectReference objects
*/
function deserializeDraftIssueProjects(projects) {
	if (!projects || projects.length === 0) return [];
	return projects.filter((project) => {
		if (typeof project === "string") return project.trim() !== "";
		return Boolean(project.title) || Boolean(project.id);
	}).map((project) => {
		if (typeof project === "string") return { title: project };
		return project;
	});
}
function stripVersionFromId(id) {
	return id.split("#")[0];
}
function getRevisionNumber(id, versionedItems, items) {
	const item = items.get(id);
	if (item && "duplicateOf" in item && item.duplicateOf) return getRevisionNumber(item.duplicateOf, versionedItems, items);
	const baseId = stripVersionFromId(id);
	const versions = versionedItems.get(baseId) ?? [];
	const versionIndex = versions.indexOf(id);
	return versions.length > 1 && versionIndex !== -1 ? versionIndex + 1 : null;
}
function makeReferenceFromFile(item) {
	return {
		type: "thread-scoped-file",
		name: item.name,
		language: item.language,
		text: item.value
	};
}
function getItemIdFromThreadScopedFileReference(ref, messageIndex) {
	return `file:${ref.name}#${messageIndex}`;
}
function getItemVersionForReference(ref, messageIndex, versionedItems, items) {
	switch (ref.type) {
		case "thread-scoped-file": return getRevisionNumber(getItemIdFromThreadScopedFileReference(ref, messageIndex), versionedItems, items) ?? void 0;
		case "draft-issue":
		case "draft-update-issue": return getRevisionNumber(makeVersionedItemFromReference({
			ref,
			messageIndex
		}).id, versionedItems, items) ?? void 0;
	}
}
function makeItemFromThreadScopedFileReference(ref, messageIndex, messageId = NullMessageId, timestamp) {
	return {
		type: "file",
		id: getItemIdFromThreadScopedFileReference(ref, messageIndex),
		reference: ref,
		messageId,
		name: ref.name,
		language: ref.language,
		value: ref.text,
		timestamp: timestamp ? new Date(timestamp) : /* @__PURE__ */ new Date(),
		isStreaming: false,
		isUserEdited: messageId === NullMessageId
	};
}
function makeItemFromFileReference(ref, messageId, timestamp) {
	return {
		type: "file",
		id: `file:${referenceID(ref)}#0`,
		reference: ref,
		messageId: messageId ?? "NULL_MESSAGE",
		name: ref.path,
		language: ref.languageName ?? "",
		value: "",
		isStreaming: true,
		isUserEdited: false,
		timestamp: timestamp ? new Date(timestamp) : /* @__PURE__ */ new Date()
	};
}
function makeItemFromFileDiffReference(ref, messageId, timestamp) {
	const createEmptyFile = (path) => ({
		type: "file",
		id: `file:empty:${path}#${Date.now()}`,
		messageId: messageId ?? "NULL_MESSAGE",
		name: path,
		language: "",
		value: "",
		isStreaming: false,
		isUserEdited: false,
		timestamp: timestamp ? new Date(timestamp) : /* @__PURE__ */ new Date()
	});
	const baseFile = ref.baseFile ? makeItemFromFileReference(ref.baseFile) : createEmptyFile(ref.headFile?.path || "");
	const headFile = ref.headFile ? makeItemFromFileReference(ref.headFile) : createEmptyFile(ref.baseFile?.path || "");
	const filePath = (ref.headFile || ref.baseFile)?.path || "";
	return {
		type: "file-diff",
		id: `file-diff:${referenceID(ref)}#0`,
		baseFile,
		headFile,
		name: filePath,
		language: (ref.headFile ? headFile : baseFile).language,
		isStreaming: true,
		isUserEdited: false,
		timestamp: timestamp ? new Date(timestamp) : /* @__PURE__ */ new Date(),
		messageId: messageId ?? "NULL_MESSAGE",
		reference: ref
	};
}
function makeItemFromIssueReference(ref, messageId) {
	return {
		type: "issue",
		id: `issue:${ref.number}`,
		messageId: messageId ?? "NULL_MESSAGE",
		name: ref.title ?? "",
		number: ref.number,
		owner: ref.repository.owner,
		repo: ref.repository.name,
		href: ref.url
	};
}
function makeItemFromJobReference(ref, messageId) {
	const { repoOwner, repoName, id } = ref;
	return {
		type: "job-result",
		id: `job-result:${repoOwner}-${repoName}-${id}`,
		messageId: messageId ?? "NULL_MESSAGE",
		name: `Job #${id} in ${repoOwner}/${repoName}`,
		jobId: Number(id),
		workflowId: ref.workflow?.id,
		repoOwner,
		repoName
	};
}
function makeReferenceFromDraftIssue(item) {
	return {
		type: item.type === "update-issue" ? "draft-update-issue" : "draft-issue",
		tag: item.tag,
		parentTag: item.parentTag,
		title: item.name,
		description: item.body,
		bodyVersion: item.bodyVersion,
		repository: item.repository,
		template: item.template,
		assignees: item.assignees,
		labels: item.labels,
		issueType: item.issueType,
		projects: serializeDraftIssueProjects(item.projects),
		rawProjectsInput: item.rawProjectsInput,
		milestone: item.milestone,
		templateFormValuesById: item.defaultValuesById,
		issueNumber: item.issueNumber,
		blockedByTags: item.blockedByTags,
		isBlockingTags: item.isBlockingTags
	};
}
function makeItemFromDraftIssueReference({ ref, messageId = NullMessageId, messageIndex }) {
	const type = ref.issueNumber ? "update-issue" : "new-issue";
	return {
		type,
		id: `${type}:${ref.tag}#${messageIndex}`,
		tag: ref.tag,
		parentTag: ref.parentTag,
		repository: ref.repository,
		name: ref.title,
		body: ref.description,
		bodyVersion: ref.bodyVersion,
		assignees: ref.assignees,
		labels: ref.labels,
		issueType: ref.issueType,
		projects: deserializeDraftIssueProjects(ref.projects),
		rawProjectsInput: ref.rawProjectsInput,
		milestone: ref.milestone,
		isUserEdited: messageId === NullMessageId,
		messageId,
		isStreaming: false,
		template: ref.template,
		defaultValuesById: ref.templateFormValuesById ?? {},
		issueNumber: ref.issueNumber,
		blockedByTags: ref.blockedByTags ?? [],
		isBlockingTags: ref.isBlockingTags ?? []
	};
}
function makeItemForPluginSupportedReference(reference, messageId = NullMessageId) {
	return {
		type: "plugin-content",
		id: `plugin-content:${reference.type}:${referenceID(reference)}`,
		name: referenceName(reference),
		icon: iconForReference(reference),
		messageId,
		reference
	};
}
function makeReferenceFromExistingIssue(item) {
	return {
		type: item.type,
		tag: item.tag,
		parentTag: item.parentTag,
		repository: item.repository,
		number: item.number,
		title: item.name,
		state: item.state,
		url: item.href,
		blockedByTags: item.blockedByTags ?? [],
		isBlockingTags: item.isBlockingTags ?? []
	};
}
function makeReferenceFromVersionedItem(item) {
	switch (item.type) {
		case "file": return makeReferenceFromFile(item);
		case "new-issue":
		case "update-issue": return makeReferenceFromDraftIssue(item);
		default: return null;
	}
}
function makeVersionedItemFromReference({ ref, messageIndex, messageId, timestamp }) {
	switch (ref.type) {
		case "thread-scoped-file": return makeItemFromThreadScopedFileReference(ref, messageIndex, messageId, timestamp);
		case "draft-issue":
		case "draft-update-issue": return makeItemFromDraftIssueReference({
			ref,
			messageIndex,
			messageId
		});
		default: return null;
	}
}
function getPreviousVersion(content, items, versionedItems) {
	const unversionedId = stripVersionFromId(content.id);
	const versions = versionedItems.get(unversionedId);
	const currentIdx = versions?.findIndex((v) => v === content.id) ?? -1;
	const previousVersionId = versions?.[currentIdx - 1];
	return previousVersionId && items.get(previousVersionId);
}
function areDraftIssuesEqual(a, b) {
	const normalize = (issue) => ({
		tag: issue.tag,
		parentTag: issue.parentTag,
		repository: issue.repository,
		type: issue.type,
		template: issue.template,
		name: issue.name,
		body: issue.body,
		bodyVersion: issue.bodyVersion,
		isUserEdited: issue.isUserEdited,
		issueType: issue.issueType,
		milestone: issue.milestone,
		issueNumber: issue.issueNumber,
		assignees: issue.assignees?.slice().sort(),
		labels: issue.labels?.slice().sort(),
		projects: issue.projects?.slice().sort((projectA, projectB) => {
			const aKey = `${projectA.id || ""}:${projectA.title || ""}`;
			const bKey = `${projectB.id || ""}:${projectB.title || ""}`;
			return aKey.localeCompare(bKey);
		}),
		rawProjectsInput: issue.rawProjectsInput?.slice().sort(),
		defaultValuesById: issue.defaultValuesById,
		blockedByTags: issue.blockedByTags?.slice().sort(),
		isBlockingTags: issue.isBlockingTags?.slice().sort()
	});
	return JSON.stringify(normalize(a)) === JSON.stringify(normalize(b));
}
function useLoadDiffReferences(t0) {
	const $ = c$1(5);
	const { updateItem, openItem, openPreviewPane } = t0;
	let t1;
	let t2;
	if ($[0] !== openItem || $[1] !== openPreviewPane || $[2] !== updateItem) {
		t1 = () => {
			if (!copilotFeatureFlags.copilotRedirectDiffViewToImmersive) return;
			const fileDiffReferences = copilotLocalStorage.getCopilotDiffReferences();
			if (!fileDiffReferences) return;
			if (fileDiffReferences.length === 0) return;
			for (const reference of fileDiffReferences) {
				const fileDiff = makeItemFromFileDiffReference(reference);
				updateItem(fileDiff);
				openItem(fileDiff.id);
			}
			openPreviewPane();
			copilotLocalStorage.removeCopilotDiffReferences();
		};
		t2 = [
			updateItem,
			openItem,
			openPreviewPane
		];
		$[0] = openItem;
		$[1] = openPreviewPane;
		$[2] = updateItem;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
}
var editedItemReferenceTypes = [
	"thread-scoped-file",
	"draft-issue",
	"draft-update-issue"
];
var isEditedItem = (item) => !!item.isUserEdited;
var mapsEqual = (a, b) => {
	return a.size === b.size && Array.from(a).every(([k, v]) => isEqual(b.get(k), v));
};
var haveEditedItemReferencesChanged = (a, b) => {
	return !mapsEqual(new Map(a.filter((r) => editedItemReferenceTypes.includes(r.type)).map((r) => [referenceID(r), r])), new Map(b.filter((r) => editedItemReferenceTypes.includes(r.type)).map((r) => [referenceID(r), r])));
};
var haveEditedItemsChanged = (a, b) => {
	return !mapsEqual(new Map(Array.from(a).filter(([, f]) => isEditedItem(f))), new Map(Array.from(b).filter(([, f]) => isEditedItem(f))));
};
/**
* Keeps references in `CopilotChatState.currentReferences` synchronized with the user-edited
* items in `ContentPreviewContext.items`. Either one might be updated independently, so this hook ensures the
* two should always remain aligned.
*
* This logic is pretty messy, and doing it like this isn't really idiomatic React, but making this effect-based ensures
* that we can never forget to update one state or the other across the dozens of callsites where we might make changes.
*
* Long-term, it would probably be better to resolve this somehow so that we only have one source of truth rather than
* two. But that probably means rewriting all of `ContentPreviewContext`.
*/
function useSyncEditedItemsWithCurrentReferences(t0) {
	const $ = c$1(10);
	const { items, removeItems, updateItem } = t0;
	const { currentReferences, messages, selectedThreadID } = useChatState();
	const manager = useChatManager();
	const previousItemsRef = useRef(items);
	const previousReferencesRef = useRef(currentReferences);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = safeStorage("sessionStorage");
		$[0] = t1;
	} else t1 = $[0];
	const sessionStorage = t1;
	let t2;
	let t3;
	if ($[1] !== currentReferences || $[2] !== items || $[3] !== manager || $[4] !== messages.length || $[5] !== removeItems || $[6] !== selectedThreadID || $[7] !== updateItem) {
		t2 = () => {
			const itemsDidChange = haveEditedItemsChanged(previousItemsRef.current, items);
			previousItemsRef.current = items;
			const referencesDidChange = haveEditedItemReferencesChanged(previousReferencesRef.current, currentReferences);
			previousReferencesRef.current = currentReferences;
			if (itemsDidChange) {
				const itemReferences = Array.from(items.values()).filter(isEditedItem).map(_temp$25).filter(_temp2$10);
				const itemReferencesById = new Map(itemReferences.map(_temp3$4));
				const encounteredIds = /* @__PURE__ */ new Set();
				for (const currentReference of currentReferences) if (editedItemReferenceTypes.includes(currentReference.type)) {
					const id = referenceID(currentReference);
					encounteredIds.add(id);
					const itemReference = itemReferencesById.get(id);
					if (!itemReference) manager.removeReference(currentReference);
					else if (haveEditedItemReferencesChanged([itemReference], [currentReference])) manager.addReference(itemReference, "content-preview");
				}
				for (const [id_0, itemReference_0] of itemReferencesById) if (!encounteredIds.has(id_0)) manager.addReference(itemReference_0, "content-preview");
			} else if (referencesDidChange) {
				const referenceItems = currentReferences.map((ref_0) => makeVersionedItemFromReference({
					ref: ref_0,
					messageIndex: messages.length
				})).filter(_temp4$3);
				const referenceItemsById = new Map(referenceItems.map(_temp5$1));
				const encounteredIds_0 = /* @__PURE__ */ new Set();
				for (const [id_1, currentItem] of items) if (isEditedItem(currentItem)) {
					encounteredIds_0.add(id_1);
					const referenceItem = referenceItemsById.get(id_1);
					if (referenceItem != null) {
						if (haveEditedItemsChanged(new Map([[referenceItem.id, referenceItem]]), new Map([[currentItem.id, currentItem]]))) updateItem(referenceItem);
					} else {
						removeItems([id_1]);
						sessionStorage.removeItem(`edited-${selectedThreadID}-${id_1}`);
					}
				}
				for (const [id_2, referenceItem_0] of referenceItemsById) if (!encounteredIds_0.has(id_2)) updateItem(referenceItem_0);
			}
		};
		t3 = [
			items,
			manager,
			currentReferences,
			messages.length,
			removeItems,
			updateItem,
			sessionStorage,
			selectedThreadID
		];
		$[1] = currentReferences;
		$[2] = items;
		$[3] = manager;
		$[4] = messages.length;
		$[5] = removeItems;
		$[6] = selectedThreadID;
		$[7] = updateItem;
		$[8] = t2;
		$[9] = t3;
	} else {
		t2 = $[8];
		t3 = $[9];
	}
	useEffect(t2, t3);
}
function _temp5$1(item_2) {
	return [item_2.id, item_2];
}
function _temp4$3(item_1) {
	return item_1 != null;
}
function _temp3$4(ref) {
	return [referenceID(ref), ref];
}
function _temp2$10(item_0) {
	return item_0 != null;
}
function _temp$25(item) {
	return makeReferenceFromVersionedItem(item);
}
var ContentPreviewContext = createContext(void 0);
ContentPreviewContext.displayName = "ContentPreviewContext";
var ContentPreviewActionsContext = createContext(void 0);
ContentPreviewActionsContext.displayName = "ContentPreviewActionsContext";
var emptyItems = /* @__PURE__ */ new Map();
var emptyOpenItems = [];
function ContentPreviewProvider({ children }) {
	const isContentPreviewOpen = useObservableValue(false);
	const isResourcePanelOpen = useObservableValue(false);
	const contentPreviewRef = useNavigableRef();
	const returnFocusElementRef = useRef(null);
	const [items, setItems] = useState(emptyItems);
	const [openItems, setOpenItems] = useState(emptyOpenItems);
	const openItemsRef = useRef(openItems);
	openItemsRef.current = openItems;
	const [openItemsBeforeSubthreadChange, setOpenItemsBeforeSubthreadChange] = useState(emptyOpenItems);
	const [selectedItem, setSelectedItem] = useState(void 0);
	const [showLoadingState, enableLoadingState, disableLoadingState] = useBooleanState(false);
	const [ephemeralTab, setEphemeralTab] = useState(void 0);
	const [resourcePanelRepoId, setResourcePanelRepoId] = useState(null);
	const [resourcePanelExpandedPath, setResourcePanelExpandedPath] = useState("");
	const [itemSelectionVersion, setItemSelectionVersion] = useState(0);
	const previousThreadId = usePreviousValue(useChatStateLens((s) => s.selectedThreadID));
	const threadId = useChatStateLens((s) => s.selectedThreadID);
	useEffect(() => {
		if (!previousThreadId || previousThreadId === threadId) return;
		setItems(emptyItems);
		setOpenItems(emptyOpenItems);
		setSelectedItem(void 0);
		setEphemeralTab(void 0);
		setResourcePanelRepoId(null);
		setResourcePanelExpandedPath("");
		setItemSelectionVersion(0);
		if (threadId === null) isContentPreviewOpen.setValue(false);
	}, [
		threadId,
		previousThreadId,
		isContentPreviewOpen,
		setResourcePanelRepoId,
		setItemSelectionVersion
	]);
	const openItem = useCallback((id, selectItem = true) => {
		setOpenItems((prevVisibleItems) => {
			if (prevVisibleItems.includes(id)) return prevVisibleItems;
			const unversionedId = stripVersionFromId(id);
			const replaceIndex = prevVisibleItems.findIndex((visibleItem) => stripVersionFromId(visibleItem) === unversionedId);
			const newVisibleItems = [...prevVisibleItems];
			if (replaceIndex === -1) newVisibleItems.push(id);
			else newVisibleItems.splice(replaceIndex, 1, id);
			return newVisibleItems;
		});
		setSelectedItem((prevSelectedItem) => selectItem || prevSelectedItem === void 0 || stripVersionFromId(prevSelectedItem) === stripVersionFromId(id) ? id : prevSelectedItem);
		setItemSelectionVersion((v) => v + 1);
	}, []);
	const openEphemeralItem = useCallback((id) => {
		if (openItemsRef.current.includes(id)) {
			openItem(id);
			return;
		}
		setEphemeralTab((prevEphemeral) => {
			if (prevEphemeral && prevEphemeral !== id) setOpenItems((prev) => {
				const idx = prev.indexOf(prevEphemeral);
				if (idx === -1) return prev;
				const next = [...prev];
				next.splice(idx, 1);
				return next;
			});
			return id;
		});
		openItem(id);
	}, [openItem]);
	const promoteTab = useCallback((id) => {
		setEphemeralTab((prev) => prev === id ? void 0 : prev);
		setItemSelectionVersion((v) => v + 1);
	}, []);
	const updateItem = useCallback((item) => {
		setItems((prevItems) => {
			const isStreaming = "isStreaming" in item ? item.isStreaming : false;
			let duplicateOfId;
			if (!isStreaming && (item.type === "new-issue" || item.type === "update-issue")) {
				const unversionedId = stripVersionFromId(item.id);
				for (const [existingId, existingItem] of prevItems) if (existingId !== item.id && stripVersionFromId(existingId) === unversionedId && (existingItem.type === "new-issue" || existingItem.type === "update-issue") && !existingItem.duplicateOf) {
					if (areDraftIssuesEqual(item, existingItem)) {
						const currentItemInPrevItems = prevItems.get(item.id);
						if (currentItemInPrevItems && areDraftIssuesEqual(item, currentItemInPrevItems) && "duplicateOf" in currentItemInPrevItems && currentItemInPrevItems.duplicateOf === existingId) return prevItems;
						duplicateOfId = existingId;
						break;
					}
				}
			}
			const newItems = new Map(prevItems);
			if (duplicateOfId && (item.type === "new-issue" || item.type === "update-issue")) newItems.set(item.id, {
				...item,
				duplicateOf: duplicateOfId
			});
			else newItems.set(item.id, item);
			return newItems;
		});
	}, []);
	const closeItem = useStableCallback((id) => {
		const index = openItems.indexOf(id);
		if (index === -1) return;
		const newOpenItems = openItems.toSpliced(index, 1);
		if (selectedItem === id) setSelectedItem(newOpenItems[index - 1] ?? newOpenItems[0]);
		setOpenItems(newOpenItems);
		if (ephemeralTab === id) setEphemeralTab(void 0);
	});
	const closeItems = useStableCallback((ids) => {
		if (ids) {
			let newOpenItems = openItems;
			for (const id of ids) {
				const index = newOpenItems.indexOf(id);
				if (index === -1) continue;
				newOpenItems = newOpenItems.toSpliced(index, 1);
				if (selectedItem === id) setSelectedItem(newOpenItems[index - 1] ?? newOpenItems[0]);
			}
			setOpenItems(newOpenItems);
		} else {
			setOpenItems(emptyOpenItems);
			setSelectedItem(void 0);
			setEphemeralTab(void 0);
		}
	});
	const versionedItems = useMemo(() => {
		const result = /* @__PURE__ */ new Map();
		for (const [versionedId, item] of items) {
			const unversionedId = stripVersionFromId(versionedId);
			const versions = result.get(unversionedId) ?? [];
			if ("duplicateOf" in item && item.duplicateOf) continue;
			if ("isStreaming" in item && item.isStreaming) continue;
			versions.push(item.id);
			result.set(unversionedId, versions);
		}
		for (const versions of result.values()) versions.sort((idA, idB) => {
			const a = items.get(idA);
			const b = items.get(idB);
			return "timestamp" in a && "timestamp" in b ? a.timestamp.valueOf() - b.timestamp.valueOf() : 0;
		});
		return result;
	}, [items]);
	const removeItems = useStableCallback((ids) => {
		if (ids) for (const id of ids) {
			setItems((prevItems) => {
				const newItems = new Map(prevItems);
				return newItems.delete(id) ? newItems : prevItems;
			});
			if (openItems.includes(id)) {
				const unversionedId = stripVersionFromId(id);
				const versions = versionedItems.get(unversionedId);
				const versionIndex = versions?.indexOf(id) ?? -1;
				const previousVersion = versions?.[versionIndex - 1];
				if (previousVersion) openItem(previousVersion, false);
				else closeItem(id);
			}
		}
		else {
			setItems(emptyItems);
			setOpenItems(emptyOpenItems);
			setSelectedItem(void 0);
		}
	});
	const getOpenItems = useStableCallback(() => isContentPreviewOpen.value ? openItems : emptyOpenItems);
	const getItems = useStableCallback(() => items);
	const getVersionedItems = useStableCallback(() => versionedItems);
	const getOpenItemsBeforeSubthreadChange = useStableCallback(() => openItemsBeforeSubthreadChange);
	const openPreviewPane = useCallback((newReturnFocusElement) => {
		isContentPreviewOpen.setValue(true);
		queueMicrotask(() => {
			contentPreviewRef.current?.focus();
		});
		if (newReturnFocusElement !== void 0) returnFocusElementRef.current = newReturnFocusElement;
	}, [
		isContentPreviewOpen,
		contentPreviewRef,
		returnFocusElementRef
	]);
	const closePreviewPane = useCallback(() => {
		isContentPreviewOpen.setValue(false);
		isResourcePanelOpen.setValue(false);
	}, [isContentPreviewOpen, isResourcePanelOpen]);
	const openResourcePanel = useCallback(() => isResourcePanelOpen.setValue(true), [isResourcePanelOpen]);
	const closeResourcePanel = useCallback(() => isResourcePanelOpen.setValue(false), [isResourcePanelOpen]);
	const value = useMemo(() => ({
		items,
		versionedItems,
		contentPreviewRef,
		isContentPreviewOpen,
		isResourcePanelOpen,
		getOpenItems,
		allOpenItems: openItems,
		openItemsBeforeSubthreadChange,
		selectedItem,
		updateItem,
		setOpenItemsBeforeSubthreadChange,
		openItem,
		closeItem,
		closeItems,
		openPreviewPane,
		closePreviewPane,
		openResourcePanel,
		closeResourcePanel,
		resourcePanelRepoId,
		setResourcePanelRepoId,
		resourcePanelExpandedPath,
		setResourcePanelExpandedPath,
		removeItems,
		showLoadingState,
		enableLoadingState,
		disableLoadingState,
		returnFocusElementRef,
		ephemeralTab,
		openEphemeralItem,
		promoteTab,
		itemSelectionVersion
	}), [
		items,
		versionedItems,
		contentPreviewRef,
		isContentPreviewOpen,
		isResourcePanelOpen,
		getOpenItems,
		openItems,
		openItemsBeforeSubthreadChange,
		selectedItem,
		updateItem,
		openItem,
		closeItem,
		closeItems,
		openPreviewPane,
		closePreviewPane,
		openResourcePanel,
		closeResourcePanel,
		resourcePanelRepoId,
		setResourcePanelRepoId,
		resourcePanelExpandedPath,
		setResourcePanelExpandedPath,
		removeItems,
		showLoadingState,
		enableLoadingState,
		disableLoadingState,
		returnFocusElementRef,
		ephemeralTab,
		openEphemeralItem,
		promoteTab,
		itemSelectionVersion
	]);
	const actionsValue = useMemo(() => ({
		getItems,
		getVersionedItems,
		getOpenItems,
		getOpenItemsBeforeSubthreadChange,
		updateItem,
		openItem,
		closeItem,
		closeItems,
		removeItems,
		openPreviewPane,
		closePreviewPane,
		openResourcePanel,
		closeResourcePanel,
		enableLoadingState,
		disableLoadingState,
		setOpenItemsBeforeSubthreadChange,
		contentPreviewRef,
		returnFocusElementRef
	}), []);
	useLoadDiffReferences(value);
	useEditedIssueWithSessionStorage(value);
	useSyncEditedItemsWithCurrentReferences(value);
	return /* @__PURE__ */ jsx(ContentPreviewActionsContext, {
		value: actionsValue,
		children: /* @__PURE__ */ jsx(ContentPreviewContext, {
			value,
			children
		})
	});
}
ContentPreviewProvider.displayName = "ContentPreviewProvider";
var useEditedIssueWithSessionStorage = (t0) => {
	const $ = c$1(5);
	const { updateItem } = t0;
	const { messagesLoading, selectedThreadID } = useChatState();
	const storageKeyPrefix = `edited-${selectedThreadID}`;
	let t1;
	let t2;
	if ($[0] !== messagesLoading.state || $[1] !== storageKeyPrefix || $[2] !== updateItem) {
		t1 = () => {
			const editedIssues = getSessionStorageItemsForKeyPrefix(storageKeyPrefix);
			if (editedIssues && messagesLoading.state === "loaded") {
				for (const editedIssue of editedIssues) if (editedIssue) updateItem(editedIssue);
			}
		};
		t2 = [
			storageKeyPrefix,
			updateItem,
			messagesLoading.state
		];
		$[0] = messagesLoading.state;
		$[1] = storageKeyPrefix;
		$[2] = updateItem;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
};
function useContentPreview() {
	const context = use(ContentPreviewContext);
	if (!context) throw new Error("useContentPreview must be used within ContentPreviewProvider");
	return context;
}
/**
* Returns stable callbacks and imperative getters for content preview.
* Does not cause re-renders when items, openItems, or selectedItem change.
* Use this when you only need to call actions or read data imperatively (not in render).
*/
function useContentPreviewActions() {
	const context = use(ContentPreviewActionsContext);
	if (!context) throw new Error("useContentPreviewActions must be used within ContentPreviewProvider");
	return context;
}
/**
* Returns true if the content preview pane is open, false otherwise.
*/
function useContentPreviewOpen() {
	const context = use(ContentPreviewContext);
	if (!context) throw new Error("useContentPreviewOpen must be used within ContentPreviewProvider");
	return useObservedState(context.isContentPreviewOpen);
}
/**
* Returns true if the content preview pane is open, false otherwise.
*/
function useResourcePanelOpen() {
	const context = use(ContentPreviewContext);
	if (!context) throw new Error("useResourcePanelOpen must be used within ContentPreviewProvider");
	return useObservedState(context.isResourcePanelOpen);
}
function prettySize(bytes) {
	if (bytes === 0) return "0 bytes";
	if (bytes === 1) return "1 byte";
	const sizes = [
		"bytes",
		"KB",
		"MB",
		"GB",
		"TB"
	];
	const i = Math.floor(Math.log(bytes) / Math.log(1024));
	return `${Math.round(bytes / Math.pow(1024, i))} ${sizes[i]}`;
}
function useFileInfo(file) {
	const $ = c$1(12);
	let t0;
	let t1;
	let t2;
	if ($[0] !== file.language || $[1] !== file.value) {
		const bytes = new Blob([file.value]).size;
		let t3;
		if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = new Set(["markdown", "html"]);
			$[5] = t3;
		} else t3 = $[5];
		const previewableLanguages = t3;
		let t4;
		if ($[6] !== file.value) {
			t4 = file.value.split("\n");
			$[6] = file.value;
			$[7] = t4;
		} else t4 = $[7];
		t0 = t4.length;
		t1 = previewableLanguages.has(file.language);
		t2 = prettySize(bytes);
		$[0] = file.language;
		$[1] = file.value;
		$[2] = t0;
		$[3] = t1;
		$[4] = t2;
	} else {
		t0 = $[2];
		t1 = $[3];
		t2 = $[4];
	}
	let t3;
	if ($[8] !== t0 || $[9] !== t1 || $[10] !== t2) {
		t3 = {
			linesOfCode: t0,
			isPreviewable: t1,
			size: t2
		};
		$[8] = t0;
		$[9] = t1;
		$[10] = t2;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
/**
* Extracts repository owner, repository name, and file path from a GitHub URL.
* Validates URL security by checking:
* - URL is from the current GitHub instance
* @param url - GitHub URL (e.g., https://github.com/owner/repo/blob/sha/path/to/file.md)
* @returns Object with repoOwner, repoName, and filePath, or null if parsing fails or URL is unsafe
*/
function parseGitHubUrl(url) {
	try {
		const urlObj = new URL(url, window.location.origin);
		if (urlObj.origin !== window.location.origin) return null;
		const pathParts = urlObj.pathname.split("/").filter(Boolean);
		if (pathParts.length < 4) return null;
		const repoOwner = pathParts[0];
		const repoName = pathParts[1];
		if (!repoOwner || !repoName) return null;
		return {
			repoOwner,
			repoName,
			filePath: pathParts.slice(4).join("/")
		};
	} catch {
		return null;
	}
}
/**
* Formats a file path with repository information in a readable format.
* @param repoOwner - The repository owner
* @param repoName - The repository name
* @param filePath - The file path within the repository
* @param ref - Optional branch or commit ref to include (e.g., "main")
* @returns Formatted path string (e.g., "owner / repo / main / path / to / file.md")
*/
function formatFilePath(repoOwner, repoName, filePath, ref) {
	return `${ref ? `${repoOwner} / ${repoName} / ${ref}` : `${repoOwner} / ${repoName}`} / ${filePath.split("/").join(" / ")}`;
}
function ExpandIcon({ className }) {
	return /* @__PURE__ */ jsxs("svg", {
		width: 16,
		height: 16,
		viewBox: "0 0 16 16",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		role: "presentation",
		className,
		children: [/* @__PURE__ */ jsx("g", {
			clipPath: "url(#clip0_6911_7629)",
			fill: "currentColor",
			children: /* @__PURE__ */ jsx("path", { d: "M14.722 6.047a.75.75 0 11-1.5 0V3.615L10.2 6.638a.75.75 0 01-1.06-1.06l3.023-3.024H9.729a.75.75 0 010-1.499h4.243a.75.75 0 01.75.75v4.242zM1.278 9.953a.75.75 0 111.5 0v2.432L5.8 9.362a.75.75 0 011.06 1.06l-3.023 3.024h2.433a.75.75 0 010 1.499H2.028a.75.75 0 01-.75-.75V9.953z" })
		}), /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("clipPath", {
			id: "clip0_6911_7629",
			children: /* @__PURE__ */ jsx("path", {
				fill: "#fff",
				d: "M0 0H16V16H0z"
			})
		}) })]
	});
}
ExpandIcon.displayName = "ExpandIcon";
var FileBlock_module_default = {
	actionsContainer: "FileBlock-module_3AOVIW_actionsContainer",
	container: "FileBlock-module_3AOVIW_container",
	expandIconContainer: "FileBlock-module_3AOVIW_expandIconContainer",
	header: "FileBlock-module_3AOVIW_header",
	isClipped: "FileBlock-module_3AOVIW_isClipped",
	language: "FileBlock-module_3AOVIW_language",
	name: "FileBlock-module_3AOVIW_name",
	previewCode: "FileBlock-module_3AOVIW_previewCode"
};
function extractRepoInfo(url) {
	if (!copilotFeatureFlags.fileBlockRefMatching || !url) return null;
	const match = /^https?:\/\/(?:github|.*\.ghe)\.com\/([^/]+)\/([^/]+)/.exec(url);
	if (!match || !match[1] || !match[2]) return null;
	return {
		owner: match[1],
		name: match[2]
	};
}
function stripLineNumbers(url) {
	return url.replace(/#L\d+(-L\d+)?$/, "");
}
function findFileReference(url, messageReferences) {
	if (!copilotFeatureFlags.fileBlockRefMatching || !url || !messageReferences) return void 0;
	const urlForMatching = stripLineNumbers(url);
	return messageReferences.find((ref) => stripLineNumbers(ref.url) === urlForMatching);
}
function FileBlock({ language, name, url, code, line, children, isClipped, isStreaming, index, startOffset, endOffset }) {
	const { message } = useChatMessage();
	const repoInfoUrl = url ? parseGitHubUrl(url) : null;
	const filePath = repoInfoUrl?.repoOwner && repoInfoUrl?.repoName ? formatFilePath(repoInfoUrl.repoOwner, repoInfoUrl.repoName, repoInfoUrl.filePath) : name;
	const { updateItem, openItem: openFileBlock, openPreviewPane, versionedItems, getOpenItems } = useContentPreview();
	const { messageIndex, messageId, messageTimestamp, autoOpenPreviewPane, markdown, hasAutoOpenedPreviewPaneRef, setHasAutoOpenedPreviewPane } = useContentPreviewBlockContext();
	const { name: languageName } = getLanguageInfo(language);
	const baseId = `file:${name}`;
	const id = `${baseId}#${messageIndex}.${line}`;
	const readyToPreview = !!code;
	const versions = versionedItems.get(baseId) ?? [];
	const versionIndex = versions.indexOf(id);
	const version = versions.length > 1 && versionIndex !== -1 ? versionIndex + 1 : null;
	const fileBlockButtonRef = useRef(null);
	const fileReference = useMemo(() => {
		const refs = message.references?.filter((ref) => ref.type === "file" || ref.type === "file-v2" || ref.type === "snippet");
		return findFileReference(url, refs);
	}, [url, message.references]);
	const ensurePreviewItem = useCallback(() => {
		if (!code) return;
		if (copilotFeatureFlags.fileBlockRefMatching) updateItem({
			messageId,
			id,
			language,
			name,
			value: code,
			type: "file",
			timestamp: new Date(messageTimestamp),
			isStreaming,
			isUserEdited: false,
			reference: (() => {
				if (!fileReference) return void 0;
				const repoInfo = extractRepoInfo(fileReference.url);
				return {
					type: "file",
					url: stripLineNumbers(fileReference.url),
					path: fileReference.path,
					repoID: fileReference.repoID,
					repoOwner: repoInfo?.owner ?? fileReference.repoOwner ?? "",
					repoName: repoInfo?.name ?? fileReference.repoName ?? "",
					ref: fileReference.ref,
					commitOID: fileReference.commitOID
				};
			})()
		});
		else updateItem({
			messageId,
			id,
			language,
			name,
			value: code,
			type: "file",
			timestamp: new Date(messageTimestamp),
			isStreaming,
			isUserEdited: false
		});
	}, [
		messageId,
		id,
		language,
		name,
		code,
		messageTimestamp,
		isStreaming,
		fileReference,
		updateItem
	]);
	const openItem = useCallback((openPane, userInitiated = true) => {
		if (userInitiated && readyToPreview && messageId !== "NULL_MESSAGE") ensurePreviewItem();
		sendEvent("dotcom_chat.activate", {
			target: "BROWSER_FILE_OPENED",
			mode: "immersive",
			...copilotFeatureFlags.fileBlockRefMatching ? { isRepoFile: !!fileReference } : {}
		});
		openFileBlock(id, userInitiated || getOpenItems().length < 1 || index === 0);
		if (openPane) openPreviewPane(fileBlockButtonRef.current);
	}, [
		openFileBlock,
		id,
		getOpenItems,
		index,
		openPreviewPane,
		fileReference,
		readyToPreview,
		messageId,
		ensurePreviewItem
	]);
	useEffect(() => {
		const isValidOffset = startOffset >= 0 && endOffset >= 0 && startOffset < endOffset && startOffset < markdown.length && endOffset <= markdown.length;
		const hasBasicValidOffsets = startOffset >= 0 && endOffset >= 0 && startOffset < endOffset && startOffset < markdown.length;
		if (!(readyToPreview && messageId !== "NULL_MESSAGE" && (isValidOffset || isStreaming && hasBasicValidOffsets))) return;
		ensurePreviewItem();
	}, [
		readyToPreview,
		messageId,
		markdown,
		startOffset,
		endOffset,
		ensurePreviewItem,
		isStreaming
	]);
	useEffect(() => {
		if (isStreaming && readyToPreview && messageId !== "NULL_MESSAGE") {
			openItem(autoOpenPreviewPane && !hasAutoOpenedPreviewPaneRef.current, false);
			setHasAutoOpenedPreviewPane(true);
		}
	}, [
		isStreaming,
		readyToPreview,
		openItem,
		autoOpenPreviewPane,
		messageId,
		hasAutoOpenedPreviewPaneRef,
		setHasAutoOpenedPreviewPane
	]);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const { publicCodeReferences, codeVulnerabilities } = useFilteredCopilotAnnotations(message.copilotAnnotations, startOffset, endOffset);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
		className: "position-relative",
		children: /* @__PURE__ */ jsxs("div", {
			ref: fileBlockButtonRef,
			className: FileBlock_module_default.container,
			onClick: () => {
				if (copilotFeatureFlags.fileBlockTransitionOpen) startTransition(() => openItem(true));
				else openItem(true);
			},
			onKeyDown: (e) => {
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					if (copilotFeatureFlags.fileBlockTransitionOpen) startTransition(() => openItem(true));
					else openItem(true);
				}
			},
			role: "button",
			tabIndex: 0,
			"aria-label": `View file: ${name}`,
			"data-testid": `chat-message-view-file-${name}`,
			children: [/* @__PURE__ */ jsxs("div", {
				className: FileBlock_module_default.header,
				children: [/* @__PURE__ */ jsxs("div", {
					className: FileBlock_module_default.language,
					children: [
						isStreaming ? /* @__PURE__ */ jsx(Spinner, {
							size: "small",
							className: disableStreamingFadeIn
						}) : docLanguages.has(languageName) ? /* @__PURE__ */ jsx(MarkdownIcon, { className: disableStreamingFadeIn }) : /* @__PURE__ */ jsx(CodeIcon, { className: disableStreamingFadeIn }),
						/* @__PURE__ */ jsx("span", {
							className: FileBlock_module_default.name,
							children: filePath
						}),
						version !== null && /* @__PURE__ */ jsx(VersionName, { version })
					]
				}), /* @__PURE__ */ jsxs("div", {
					className: FileBlock_module_default.actionsContainer,
					children: [
						(publicCodeReferences.length > 0 || codeVulnerabilities.length > 0) && /* @__PURE__ */ jsx(IconButton, {
							variant: "invisible",
							size: "small",
							icon: ShieldIcon,
							"aria-label": "Code insights",
							onClick: (e_0) => {
								e_0.stopPropagation();
								setIsDialogOpen(true);
							},
							onKeyDown: (e_1) => {
								if (e_1.key === "Enter" || e_1.key === " ") {
									e_1.stopPropagation();
									setIsDialogOpen(true);
								}
							}
						}),
						url && /* @__PURE__ */ jsx(IconButton, {
							as: "a",
							type: void 0,
							"aria-label": "Open file in a new tab",
							icon: LinkExternalIcon,
							variant: "invisible",
							href: url,
							target: "_blank",
							rel: "noopener noreferrer",
							size: "small",
							onClick: (e_2) => e_2.stopPropagation(),
							onKeyDown: (e_3) => {
								if (e_3.key === "Enter" || e_3.key === " ") e_3.stopPropagation();
							}
						}),
						/* @__PURE__ */ jsx("div", {
							className: FileBlock_module_default.expandIconContainer,
							children: /* @__PURE__ */ jsx(ExpandIcon, {})
						})
					]
				})]
			}), /* @__PURE__ */ jsx("pre", {
				className: clsx(FileBlock_module_default.previewCode, isClipped && FileBlock_module_default.isClipped),
				"aria-hidden": true,
				children: /* @__PURE__ */ jsx("code", { children })
			})]
		})
	}), isDialogOpen && /* @__PURE__ */ jsx(CodeInsightsDialog$1, {
		publicCodeReferences,
		codeVulnerabilities,
		onClose: () => setIsDialogOpen(false)
	})] });
}
FileBlock.displayName = "FileBlock";
var fileblockAttribute = "data-fileblock-props";
var fileblockProperty = dataAttrToPropName(fileblockAttribute);
/** Matches code block meta in the form `name=filename`. The presence of the `name` indicates a file. */
var nameRegex = /^name=(?<name>[^\s]+)/;
/**
* Matches the file name in the first line of a code block.
* We have this because sometimes the model does it this way, even though it shouldn't.
*/
var fileNameCodeRegex = /^name=(?<name>[^\s]+)\n?/;
/** Matches URL in the code block meta in the form `url=url`. */
var urlRegex = /url=(?<url>[^\s]+)/;
/** Number of lines of code to show in the block. */
var previewSizeLines = 6;
function getName(meta, code) {
	const nameMatch = meta && nameRegex.exec(meta);
	if (nameMatch) return {
		name: nameMatch.groups?.name,
		code
	};
	const codeMatch = fileNameCodeRegex.exec(code);
	if (codeMatch) return {
		name: codeMatch.groups?.name,
		code: code.replace(fileNameCodeRegex, "")
	};
	return { code };
}
function getUrl(meta) {
	if (!meta) return void 0;
	return urlRegex.exec(meta)?.groups?.url;
}
var reactComponents$1 = { code: (props, fallthrough) => {
	const fileblockProps = parseJsonAttribute(props, fileblockAttribute);
	if (!fileblockProps) return fallthrough;
	return /* @__PURE__ */ jsx(FileBlock, {
		...fileblockProps,
		children: props.children
	});
} };
/**
* Renders small blocks that can be clicked to open files for previewing. Must be configured before
* `codeBlocksExtension` because it also operates on code blocks and should take priority.
*/
function fileViewExtension(fileBlocksInMessage) {
	return {
		transformMarkdown: (tree) => visit(tree, "code", (node) => {
			const language = node.lang ?? "";
			const { name, code } = getName(node.meta ?? void 0, node.value);
			if (!name) return;
			if (!fileBlocksInMessage.includes(name)) fileBlocksInMessage.push(name);
			const url = getUrl(node.meta ?? void 0);
			const previewLines = code.split("\n", previewSizeLines);
			const isClipped = previewLines.length === previewSizeLines;
			const previewCode = isClipped ? previewLines.join("\n") : `${previewLines.join("\n")}\n`;
			const lineNumber = node.position?.start.line ?? 0;
			node.value = previewCode;
			node.data = {
				...node.data,
				hName: "code",
				hProperties: { [fileblockProperty]: JSON.stringify({
					language,
					name,
					url,
					code,
					line: lineNumber,
					isStreaming: node.isStreaming ?? false,
					isClipped,
					index: fileBlocksInMessage.indexOf(name),
					startOffset: node.position?.start.offset ?? -1,
					endOffset: node.position?.end.offset ?? -1
				}) }
			};
		}),
		transformHtml: (tree) => visit(tree, "element", (node, i, parent) => {
			const child = node.children?.[0];
			if (parent && i !== void 0 && node.tagName === "pre" && node.children?.length === 1 && child?.type === "element" && child.tagName === "code" && fileblockProperty in child.properties) parent.children.splice(i, 1, child);
		}),
		reactComponents: reactComponents$1
	};
}
/** Matches the type in the first line of a code block. */
var typeRawRegex = /^type=(?<type>[^\s]+)\n?/;
/** Strips surrounding single or double quotes. */
var stripQuotes = (str) => str.startsWith("\"") && str.endsWith("\"") || str.startsWith("'") && str.endsWith("'") ? str.slice(1, -1) : str;
/**
* A base class for YAML block extensions that render custom React components based on the content of fenced code blocks in markdown.
*/
var YamlBlockExtension = class {
	get dataProperty() {
		return dataAttrToPropName(this.dataAttribute);
	}
	transformMarkdown = (tree) => {
		visit(tree, "code", (node) => {
			const lang = node.lang;
			if (!lang) return;
			const type = stripQuotes(typeRawRegex.exec(node.meta ?? "")?.groups?.type ?? "");
			if (!type) return;
			const nodeMeta = {
				lang,
				type,
				value: node.value,
				isStreaming: node.isStreaming
			};
			if (!this.isSupported(nodeMeta)) return;
			const componentProps = this.extractProps(nodeMeta);
			node.data = {
				hName: "div",
				hProperties: { [this.dataProperty]: JSON.stringify(componentProps) },
				hChildren: []
			};
		});
	};
	transformHtml = (tree) => {
		visit(tree, "element", (node, i, parent) => {
			const child = node.children?.[0];
			if (parent && i != null && node.tagName === "pre" && node.children?.length === 1 && child?.type === "element" && this.dataProperty in child.properties) parent.children.splice(i, 1, child);
		});
	};
	reactComponents = { div: (props, fallthrough) => {
		const componentProps = parseJsonAttribute(props, this.dataAttribute);
		if (!componentProps) return fallthrough;
		return this.createComponent(componentProps);
	} };
};
function IssueIcon(props) {
	if (props.type === "existing-issue") {
		if (props.state === "open") return /* @__PURE__ */ jsx(IssueOpenedIcon, { className: "fgColor-open" });
		if (props.state === "closed") return /* @__PURE__ */ jsx(IssueClosedIcon, { className: "fgColor-done" });
	}
	return /* @__PURE__ */ jsx(IssueDraftIcon, { className: "fgColor-draft" });
}
IssueIcon.displayName = "IssueIcon";
var IssueTree_module_default = {
	blockedBy: "IssueTree-module_0NqLeW_blockedBy",
	container: "IssueTree-module_0NqLeW_container",
	content: "IssueTree-module_0NqLeW_content",
	description: "IssueTree-module_0NqLeW_description",
	grid: "IssueTree-module_0NqLeW_grid",
	item: "IssueTree-module_0NqLeW_item",
	leadingVisual: "IssueTree-module_0NqLeW_leadingVisual",
	rootItem: "IssueTree-module_0NqLeW_rootItem",
	spacer: "IssueTree-module_0NqLeW_spacer",
	subHeader: "IssueTree-module_0NqLeW_subHeader",
	title: "IssueTree-module_0NqLeW_title",
	tokenContainer: "IssueTree-module_0NqLeW_tokenContainer",
	trailingVisual: "IssueTree-module_0NqLeW_trailingVisual",
	tree: "IssueTree-module_0NqLeW_tree"
};
var TreeContext = React.createContext({ hasTrailingVisuals: void 0 });
TreeContext.displayName = "TreeContext";
var ItemContext = React.createContext({ level: 0 });
ItemContext.displayName = "ItemContext";
function Tree(t0) {
	const $ = c$1(8);
	const { subIssueCount, subIssueHeaderText: t1, hasTrailingVisuals: t2, children } = t0;
	const subIssueHeaderText = t1 === void 0 ? "Sub-issues" : t1;
	const hasTrailingVisuals = t2 === void 0 ? false : t2;
	let t3;
	if ($[0] !== children || $[1] !== hasTrailingVisuals || $[2] !== subIssueCount || $[3] !== subIssueHeaderText) {
		const childrenArray = React.Children.toArray(children);
		const rootItem = childrenArray.find(_temp$24);
		const items = childrenArray.filter(_temp2$9);
		const lastItemsIndex = items.length - 1;
		if (lastItemsIndex >= 0 && React.isValidElement(items[lastItemsIndex])) {
			let t4;
			if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
				t4 = { isLastBranch: true };
				$[5] = t4;
			} else t4 = $[5];
			items[lastItemsIndex] = React.cloneElement(items[lastItemsIndex], t4);
		}
		let t4;
		if ($[6] !== hasTrailingVisuals) {
			t4 = { hasTrailingVisuals };
			$[6] = hasTrailingVisuals;
			$[7] = t4;
		} else t4 = $[7];
		t3 = jsx(TreeContext, {
			value: t4,
			children: jsxs("div", {
				className: IssueTree_module_default.container,
				"data-has-trailing-visual": hasTrailingVisuals || void 0,
				children: [rootItem, items.length > 0 && jsxs(Fragment$1, { children: [jsxs("div", {
					className: IssueTree_module_default.subHeader,
					children: [subIssueHeaderText, jsx(CounterLabel, { children: subIssueCount })]
				}), jsx("ul", {
					role: "tree",
					className: IssueTree_module_default.tree,
					children: items
				})] })]
			})
		});
		$[0] = children;
		$[1] = hasTrailingVisuals;
		$[2] = subIssueCount;
		$[3] = subIssueHeaderText;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
}
Tree.displayName = "Tree";
function _temp2$9(child_0) {
	return React.isValidElement(child_0) && child_0.type === TreeItem;
}
function _temp$24(child) {
	return React.isValidElement(child) && child.type === TreeRootItem;
}
function TreeRootItem(props) {
	const $ = c$1(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { level: 0 };
		$[0] = t0;
	} else t0 = $[0];
	const providerProps = t0;
	let t1;
	if ($[1] !== props) {
		t1 = jsx(ItemContext, {
			value: providerProps,
			children: jsx("div", {
				className: clsx(IssueTree_module_default.item, IssueTree_module_default.rootItem),
				children: jsx(TreeItemContent, { ...props })
			})
		});
		$[1] = props;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
TreeRootItem.displayName = "TreeRootItem";
function TreeItem(t0) {
	const $ = c$1(3);
	const { children, isLastBranch, ...props } = t0;
	const childrenArray = React.Children.toArray(children);
	const nestedItems = childrenArray.filter(_temp3$3);
	const contentChildren = childrenArray.filter(_temp4$2);
	const { level } = React.use(ItemContext);
	const t1 = level + 1;
	let t2;
	if ($[0] !== t1) {
		t2 = { level: t1 };
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const providerProps = t2;
	const isLastRendered = isLastBranch && nestedItems.length === 0;
	const lastNestedIndex = nestedItems.length - 1;
	if (isLastBranch && lastNestedIndex >= 0 && React.isValidElement(nestedItems[lastNestedIndex])) {
		let t3;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = { isLastBranch: true };
			$[2] = t3;
		} else t3 = $[2];
		nestedItems[lastNestedIndex] = React.cloneElement(nestedItems[lastNestedIndex], t3);
	}
	return jsx(ItemContext, {
		value: providerProps,
		children: jsxs("li", {
			role: "treeitem",
			"aria-selected": "false",
			className: IssueTree_module_default.item,
			"data-is-last-rendered": isLastRendered || void 0,
			children: [jsx(TreeItemContent, {
				...props,
				children: contentChildren
			}), nestedItems.length > 0 && jsx("ul", {
				role: "group",
				className: IssueTree_module_default.tree,
				children: nestedItems
			})]
		})
	});
}
TreeItem.displayName = "TreeItem";
function _temp4$2(child_0) {
	return !(React.isValidElement(child_0) && child_0.type === TreeItem);
}
function _temp3$3(child) {
	return React.isValidElement(child) && child.type === TreeItem;
}
function TreeItemContent({ leadingVisual, title, description, trailingBadge, trailingVisual, href, onClick, blockedBy }) {
	const { level } = React.use(ItemContext);
	const { hasTrailingVisuals } = React.use(TreeContext);
	const hasDependencies = blockedBy != null && blockedBy.length > 0;
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("div", {
		className: IssueTree_module_default.grid,
		style: { "--level": level },
		"data-has-onclick": onClick ? true : void 0,
		children: [
			level > 0 && /* @__PURE__ */ jsx("div", { className: IssueTree_module_default.spacer }),
			/* @__PURE__ */ jsx("div", {
				className: IssueTree_module_default.leadingVisual,
				children: leadingVisual
			}),
			/* @__PURE__ */ jsxs("div", {
				className: IssueTree_module_default.content,
				children: [/* @__PURE__ */ jsx(Link, {
					as: href ? "a" : onClick ? "button" : "span",
					className: IssueTree_module_default.title,
					href,
					onClick,
					children: title
				}), trailingBadge]
			}),
			(description != null || hasDependencies) && /* @__PURE__ */ jsxs("div", {
				className: IssueTree_module_default.description,
				children: [hasDependencies && /* @__PURE__ */ jsx(IssueDependencies, {
					dependencyType: "Blocked by",
					blockedBy
				}), description]
			}),
			hasTrailingVisuals && /* @__PURE__ */ jsx("div", {
				className: IssueTree_module_default.trailingVisual,
				children: trailingVisual
			})
		]
	}) });
}
TreeItemContent.displayName = "TreeItemContent";
function IssueDependencies({ dependencyType, blockedBy }) {
	if (!blockedBy.length) return null;
	const blockedByIssueLink = /* @__PURE__ */ jsx(Link, {
		"data-testid": "blocked-by-link",
		className: IssueTree_module_default.blockedBy,
		muted: true,
		as: blockedBy[0]?.href ? "a" : blockedBy[0]?.onClick ? "button" : "span",
		href: blockedBy[0]?.href,
		onClick: blockedBy[0]?.onClick,
		title: blockedBy[0]?.title,
		children: blockedBy[0]?.title
	});
	return /* @__PURE__ */ jsx(Token, {
		size: "medium",
		className: "mr-2",
		leadingVisual: () => /* @__PURE__ */ jsx(BlockedIcon, {
			"data-testid": "blocked-by-icon",
			className: "fgColor-danger",
			size: 14
		}),
		text: blockedBy.length > 1 ? /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("span", {
			className: IssueTree_module_default.tokenContainer,
			children: [
				dependencyType,
				" ",
				blockedBy.length
			]
		}) }) : /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("span", {
			className: IssueTree_module_default.tokenContainer,
			children: [
				dependencyType,
				": ",
				blockedByIssueLink
			]
		}) })
	});
}
IssueDependencies.displayName = "IssueDependencies";
var IssueTree = Object.assign(Tree, {
	RootItem: TreeRootItem,
	Item: TreeItem
});
function useMediaContent() {
	const $ = c$1(4);
	const { messages } = useChatState();
	let t0;
	if ($[0] !== messages) {
		t0 = getActiveMessages(messages);
		$[0] = messages;
		$[1] = t0;
	} else t0 = $[1];
	const activeMessages = t0;
	let t1;
	if ($[2] !== activeMessages) {
		t1 = activeMessages.flatMap(_temp$23);
		$[2] = activeMessages;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
function _temp$23(message) {
	return message.mediaContent || [];
}
function usePreProcessedDraftIssueContent(value) {
	const $ = c$1(3);
	const media = useMediaContent();
	if (!value) return "";
	let t0;
	if ($[0] !== media || $[1] !== value) {
		t0 = replaceImagePlaceholders(value, media);
		$[0] = media;
		$[1] = value;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
function replaceImagePlaceholders(issueBody, media) {
	if (!issueBody) return "";
	const matches = issueBody.match(/(!\[.*?\]\(image\d+\))/g);
	if (matches == null) return issueBody;
	for (const match of matches) {
		const urlPlaceholderRegex = /\(image(\d+)\)/;
		const imageIdString = match.match(urlPlaceholderRegex)[1];
		const imageId = parseInt(imageIdString, 10);
		const imageIndex = media.length - imageId;
		const url = media[imageIndex]?.chatAttachmentUrl || media[imageIndex]?.url;
		if (url) {
			const updatedMarkdown = match.replace(urlPlaceholderRegex, `(${url})`);
			issueBody = issueBody.replace(match, updatedMarkdown);
		}
	}
	return issueBody;
}
function useSyncState(input, process, initialValue) {
	const ref = useRef(initialValue);
	return useMemo(() => {
		const value = process(input);
		if (value != null) ref.current = value;
		return ref.current;
	}, [input, process]);
}
/**
* Helper function to normalize a single string value, removing all leading and trailing
* whitespace and newlines, including escaped newlines
* @param value - The string value to normalize
* @returns The normalized string value
*/
var normalizeString = (value) => {
	return value.replace(/\\n/g, "\n").replace(/^\s+|\s+$/g, "");
};
/**
* Helper function to compare two arrays for equality, handling order independence
* Uses lodash utilities for robust comparison, with whitespace trimming
* @param arr1 - First array to compare
* @param arr2 - Second array to compare
* @returns true if arrays contain the same elements regardless of order
*/
var arraysEqual = (arr1, arr2) => {
	const a1 = (arr1 || []).map((item) => normalizeString(item));
	const a2 = (arr2 || []).map((item) => normalizeString(item));
	if (a1.length !== a2.length) return false;
	return isEqual(sortBy(a1), sortBy(a2));
};
/**
* Helper function to compare project arrays for equality, handling different project formats
* Prioritizes ID matching when both arrays have objects with IDs, falls back to title matching
* when IDs are missing or when dealing with string arrays
* @param projects1 - First project array to compare (strings or objects)
* @param projects2 - Second project array to compare (strings or objects)
* @returns true if arrays contain the same projects regardless of order
*/
var projectsEqual = (projects1, projects2) => {
	const arr1 = projects1 || [];
	const arr2 = projects2 || [];
	if (arr1.length !== arr2.length) return false;
	if (arr1.length === 0) return true;
	if (!(arr1.some((p) => typeof p === "string") || arr2.some((p) => typeof p === "string")) && arr1.every((p) => typeof p === "object" && p.id) && arr2.every((p) => typeof p === "object" && p.id)) {
		const ids1 = arr1.map((p) => normalizeString(p.id || ""));
		const ids2 = arr2.map((p) => normalizeString(p.id || ""));
		return isEqual(sortBy(ids1), sortBy(ids2));
	}
	const getProjectTitle = (project) => {
		if (typeof project === "string") return project;
		return project.title || "";
	};
	const titles1 = arr1.map((project) => normalizeString(getProjectTitle(project)));
	const titles2 = arr2.map((project) => normalizeString(getProjectTitle(project)));
	return isEqual(sortBy(titles1), sortBy(titles2));
};
/**
* Helper function to normalize string values for comparison.
* Treats null, undefined, and empty strings as equivalent.
* Handles escaped newlines and strips all leading/trailing whitespace.
* @param value - The string value to normalize
* @returns The normalized string value
*/
var normalizeStringValue = (value) => {
	if (value === null || value === void 0) return "";
	return normalizeString(value);
};
/**
* Helper function to serialize a value to a string for comparison logging.
* Uses normalizeStringValue for consistent string handling and ensures
* all whitespace and newlines are properly stripped for output.
*/
var serializeValue = (value) => {
	if (Array.isArray(value)) return `[${value.map((item) => typeof item === "string" ? normalizeString(item) : String(item)).join(",")}]`;
	if (typeof value === "string" || value === null || value === void 0) return normalizeStringValue(value);
	return JSON.stringify(value);
};
/**
* Helper function to compare a parsed draft issue with a draft issue reference
* to detect if they have any differences in their key fields.
*
* @param draftIssue - The parsed draft issue from YAML
* @param draftIssueRef - The draft issue reference from chat message
* @returns An object with isEqual boolean, mismatchedFields array, and field comparison details
*/
var compareDraftIssueWithReference = (draftIssue, draftIssueRef) => {
	const mismatchedFields = [];
	const fieldComparisons = {};
	if (!(normalizeStringValue(draftIssue.title) === normalizeStringValue(draftIssueRef.title))) {
		mismatchedFields.push("title");
		fieldComparisons.title = {
			expected: serializeValue(draftIssueRef.title),
			actual: serializeValue(draftIssue.title)
		};
	}
	if (!(normalizeStringValue(draftIssue.body) === normalizeStringValue(draftIssueRef.description))) {
		mismatchedFields.push("body");
		fieldComparisons.body = {
			expected: serializeValue(draftIssueRef.description),
			actual: serializeValue(draftIssue.body)
		};
	}
	if (!(normalizeStringValue(draftIssue.repository) === normalizeStringValue(draftIssueRef.repository))) {
		mismatchedFields.push("repository");
		fieldComparisons.repository = {
			expected: serializeValue(draftIssueRef.repository),
			actual: serializeValue(draftIssue.repository)
		};
	}
	if (!(normalizeStringValue(draftIssue.template) === normalizeStringValue(draftIssueRef.template))) {
		mismatchedFields.push("template");
		fieldComparisons.template = {
			expected: serializeValue(draftIssueRef.template),
			actual: serializeValue(draftIssue.template)
		};
	}
	if (!(normalizeStringValue(draftIssue.issueType) === normalizeStringValue(draftIssueRef.issueType))) {
		mismatchedFields.push("issueType");
		fieldComparisons.issueType = {
			expected: serializeValue(draftIssueRef.issueType),
			actual: serializeValue(draftIssue.issueType)
		};
	}
	if (!(normalizeStringValue(draftIssue.milestone) === normalizeStringValue(draftIssueRef.milestone))) {
		mismatchedFields.push("milestone");
		fieldComparisons.milestone = {
			expected: serializeValue(draftIssueRef.milestone),
			actual: serializeValue(draftIssue.milestone)
		};
	}
	if (!arraysEqual(draftIssue.assignees, draftIssueRef.assignees)) {
		mismatchedFields.push("assignees");
		fieldComparisons.assignees = {
			expected: serializeValue(draftIssueRef.assignees),
			actual: serializeValue(draftIssue.assignees)
		};
	}
	if (!arraysEqual(draftIssue.labels, draftIssueRef.labels)) {
		mismatchedFields.push("labels");
		fieldComparisons.labels = {
			expected: serializeValue(draftIssueRef.labels),
			actual: serializeValue(draftIssue.labels)
		};
	}
	if (!projectsEqual(draftIssue.projects, draftIssueRef.projects)) {
		mismatchedFields.push("projects");
		fieldComparisons.projects = {
			expected: serializeValue(draftIssueRef.projects),
			actual: serializeValue(draftIssue.projects)
		};
	}
	if (!isEqual(draftIssue.templateFormValues, draftIssueRef.templateFormValuesById)) {
		mismatchedFields.push("templateFormValues");
		fieldComparisons.templateFormValues = {
			expected: serializeValue(draftIssueRef.templateFormValuesById),
			actual: serializeValue(draftIssue.templateFormValues)
		};
	}
	if (!arraysEqual(draftIssue.blockedByTags, draftIssueRef.blockedByTags)) {
		mismatchedFields.push("blockedByTags");
		fieldComparisons.blockedByTags = {
			expected: serializeValue(draftIssueRef.blockedByTags),
			actual: serializeValue(draftIssue.blockedByTags)
		};
	}
	if (!arraysEqual(draftIssue.isBlockingTags, draftIssueRef.isBlockingTags)) {
		mismatchedFields.push("isBlockingTags");
		fieldComparisons.isBlockingTags = {
			expected: serializeValue(draftIssueRef.isBlockingTags),
			actual: serializeValue(draftIssue.isBlockingTags)
		};
	}
	return {
		isEqual: mismatchedFields.length === 0,
		mismatchedFields,
		fieldComparisons
	};
};
/**
* Hook that validates draft issues against their references in the corresponding assistant message.
* Only validates issues that belong to the same message as the references.
* Emits telemetry when mismatches are detected.
*/
function useDraftIssueReferenceValidation(t0) {
	const $ = c$1(8);
	const { issues, isStreaming, isIssueTree: t1 } = t0;
	const isIssueTree = t1 === void 0 ? false : t1;
	const { messages, threadSelectedAt } = useChatState();
	const { messageId } = useContentPreviewBlockContext();
	let t2;
	let t3;
	if ($[0] !== isIssueTree || $[1] !== isStreaming || $[2] !== issues || $[3] !== messageId || $[4] !== messages || $[5] !== threadSelectedAt) {
		t2 = () => {
			const activeMessages = getActiveMessages(messages);
			const latestMessage = activeMessages[activeMessages.length - 1];
			const currentMessage = activeMessages.find((msg) => msg.id === messageId);
			if (isStreaming || !currentMessage || currentMessage.role !== "assistant" || currentMessage.id !== latestMessage?.id) return;
			if (new Date(currentMessage.createdAt) >= threadSelectedAt && currentMessage.references && issues.length > 0) {
				const draftIssueRefs = currentMessage.references.filter(_temp$22);
				for (const issue of issues) if (issue.tag) {
					const matchingRef = draftIssueRefs.find((ref_0) => ref_0.tag === issue.tag);
					if (matchingRef) {
						const comparison = compareDraftIssueWithReference(issue, matchingRef);
						if (!comparison.isEqual) {
							sendEvent("dotcom_chat.activate", {
								target: "BROWSER_ISSUE_DRAFT_ISSUE_REFERENCE_MISMATCH",
								mode: "immersive",
								messageId,
								issueTree: isIssueTree,
								mismatchedFields: comparison.mismatchedFields.join(","),
								fieldComparisons: JSON.stringify(comparison.fieldComparisons),
								yamlMarshaled: isFeatureEnabled("copilot_api_agentic_issue_marshal_yaml")
							});
							return;
						}
					}
				}
			}
		};
		t3 = [
			isStreaming,
			issues,
			messages,
			threadSelectedAt,
			isIssueTree,
			messageId
		];
		$[0] = isIssueTree;
		$[1] = isStreaming;
		$[2] = issues;
		$[3] = messageId;
		$[4] = messages;
		$[5] = threadSelectedAt;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	useEffect(t2, t3);
}
function _temp$22(ref) {
	return ref.type === "draft-issue" || ref.type === "draft-update-issue";
}
var DraftIssue = { fromUnknown: (data) => {
	if (typeof data !== "object" || data == null) return null;
	const item = {};
	if ("title" in data && typeof data.title === "string") item.title = data.title;
	else if ("name" in data && typeof data.name === "string") item.title = data.name;
	if ("tag" in data && typeof data.tag === "string") item.tag = data.tag;
	if ("template-form-values" in data && typeof data["template-form-values"] === "object" && data["template-form-values"] != null) item.templateFormValues = Object.fromEntries(Object.entries(data["template-form-values"]).map(([key, value]) => [key, typeof value === "string" ? value.trim() : value]));
	if ("description" in data && typeof data.description === "string") item.body = data.description;
	if ("labels" in data && Array.isArray(data.labels)) item.labels = data.labels.filter((el) => typeof el === "string");
	if ("assignees" in data && Array.isArray(data.assignees)) item.assignees = data.assignees.filter((el) => typeof el === "string");
	if ("repository" in data && typeof data.repository === "string") item.repository = data.repository;
	if ("template" in data && typeof data.template === "string") item.template = data.template;
	if ("projects" in data && Array.isArray(data.projects)) item.projects = data.projects.filter((el) => typeof el === "string" || typeof el === "object" && el != null);
	if ("milestone" in data && typeof data.milestone === "string") item.milestone = data.milestone;
	if ("state" in data && typeof data.state === "string") item.state = data.state;
	if ("parentTag" in data && typeof data.parentTag === "string") item.parentTag = data.parentTag;
	if ("issueNumber" in data && typeof data.issueNumber === "number") item.issueNumber = data.issueNumber;
	if ("blockedByTags" in data && Array.isArray(data.blockedByTags)) item.blockedByTags = data.blockedByTags.filter((el) => typeof el === "string");
	if ("isBlockingTags" in data && Array.isArray(data.isBlockingTags)) item.isBlockingTags = data.isBlockingTags.filter((el) => typeof el === "string");
	if ("bodyVersion" in data && typeof data.bodyVersion === "string") item.bodyVersion = data.bodyVersion;
	if ("issueType" in data && typeof data.issueType === "string") item.issueType = data.issueType;
	if ("type" in data && typeof data.type === "string") item.type = data.type;
	return item;
} };
var parseIssueData = (yaml) => {
	try {
		const result = load(yaml);
		return DraftIssue.fromUnknown(result);
	} catch {
		return null;
	}
};
function DraftIssueBlock({ yaml, isStreaming }) {
	const [fromStreaming, setFromStreaming] = useState(isStreaming);
	useEffect(() => {
		if (isStreaming) setFromStreaming(true);
	}, [isStreaming]);
	const { updateItem, openItem, openPreviewPane, closeItem, versionedItems, items } = useContentPreview();
	const { messageId, messageIndex, autoOpenPreviewPane, hasAutoOpenedPreviewPaneRef, setHasAutoOpenedPreviewPane } = useContentPreviewBlockContext();
	yaml = usePreProcessedDraftIssueContent(yaml);
	const issue = useSyncState(yaml, parseIssueData, {});
	useDraftIssueReferenceValidation({
		issues: [issue],
		isStreaming,
		isIssueTree: false
	});
	useEffect(() => sendEvent("dotcom_chat.activate", {
		target: "ISSUE_DRAFT_BLOCK_RENDERED",
		mode: "immersive"
	}), []);
	const draftIssueType = issue.type == null && isStreaming ? void 0 : issue.type === "draft-update-issue" ? "update-issue" : "new-issue";
	const id = issue.tag != null && draftIssueType != null ? `${draftIssueType}:${issue.tag}#${messageIndex}` : void 0;
	const version = id != null ? getRevisionNumber(id, versionedItems, items) : null;
	const item = id != null ? items.get(id) : void 0;
	const repository = !issue.repository && draftIssueType != null && item?.type === draftIssueType ? item.repository || "" : issue.repository;
	const openDraftIssue = useCallback(({ selectItem, event }) => {
		if (id != null) {
			openItem(id, selectItem);
			if (selectItem || autoOpenPreviewPane && !hasAutoOpenedPreviewPaneRef.current) {
				openPreviewPane(event?.currentTarget);
				setHasAutoOpenedPreviewPane(true);
			}
			sendEvent("dotcom_chat.activate", {
				target: "BROWSER_DRAFT_ISSUE_OPENED",
				mode: "immersive"
			});
		}
	}, [
		id,
		openItem,
		autoOpenPreviewPane,
		hasAutoOpenedPreviewPaneRef,
		openPreviewPane,
		setHasAutoOpenedPreviewPane
	]);
	const normalizedProjects = useMemo(() => {
		return deserializeDraftIssueProjects(issue.projects);
	}, [issue.projects]);
	useEffect(() => {
		if (id != null) {
			if (draftIssueType === "update-issue" && repository && issue.issueNumber) closeItem(`issue:${repository}/${issue.issueNumber}`);
			updateItem({
				messageId,
				name: issue.title ?? "",
				body: issue.body,
				bodyVersion: issue.bodyVersion,
				repository,
				id,
				type: draftIssueType,
				tag: issue.tag ?? "",
				parentTag: issue.parentTag,
				isStreaming,
				template: issue.template,
				issueType: issue.issueType,
				milestone: issue.milestone,
				assignees: issue.assignees?.sort(),
				labels: issue.labels?.sort(),
				projects: normalizedProjects,
				rawProjectsInput: normalizedProjects.map((project) => project.title || "").filter((title) => title !== "").sort(),
				isUserEdited: false,
				defaultValuesById: issue.templateFormValues ?? {},
				issueNumber: issue.issueNumber
			});
		}
	}, [
		closeItem,
		draftIssueType,
		id,
		isStreaming,
		issue.assignees,
		issue.body,
		issue.bodyVersion,
		issue.issueNumber,
		issue.issueType,
		issue.labels,
		issue.milestone,
		issue.parentTag,
		issue.projects,
		issue.tag,
		issue.template,
		issue.templateFormValues,
		issue.title,
		messageId,
		normalizedProjects,
		repository,
		updateItem
	]);
	useEffect(() => {
		if (id != null && fromStreaming) openDraftIssue({ selectItem: true });
	}, [
		id,
		openDraftIssue,
		fromStreaming
	]);
	return /* @__PURE__ */ jsx(IssueTree, {
		subIssueCount: 0,
		children: /* @__PURE__ */ jsx(IssueTree.RootItem, {
			title: issue.title ?? "",
			leadingVisual: isStreaming ? /* @__PURE__ */ jsx(Spinner, {
				size: "small",
				className: disableStreamingFadeIn
			}) : /* @__PURE__ */ jsx(IssueIcon, { type: "new-issue" }),
			trailingBadge: version != null && /* @__PURE__ */ jsx(VersionName, {
				"data-testid": "version-label",
				version
			}),
			onClick: (e) => openDraftIssue({
				selectItem: true,
				event: e
			})
		})
	});
}
DraftIssueBlock.displayName = "DraftIssueBlock";
var instance$3 = new class extends YamlBlockExtension {
	get dataAttribute() {
		return "data-draft-issue-block";
	}
	isSupported(node) {
		return node.lang === "yaml" && node.type === "draft-issue";
	}
	extractProps(node) {
		return {
			yaml: node.value,
			isStreaming: node.isStreaming ?? false
		};
	}
	createComponent(props) {
		return /* @__PURE__ */ jsx(DraftIssueBlock, { ...props });
	}
}();
function draftIssueExtension() {
	return instance$3;
}
function visit$1(node, callback) {
	callback(node);
	for (const child of node.children) visit$1(child, callback);
}
function visitDependencies(node, callback, visited = /* @__PURE__ */ new Set()) {
	if (visited.has(node)) return;
	visited.add(node);
	callback(node);
	for (const child of node.children) visitDependencies(child, callback, visited);
	for (const blockedBy of node.blockedBy) visitDependencies(blockedBy, callback, visited);
	for (const isBlocking of node.isBlocking) visitDependencies(isBlocking, callback, visited);
}
async function visitDependenciesAsync(node, callback, visited = /* @__PURE__ */ new Set()) {
	if (visited.has(node)) return;
	visited.add(node);
	await callback(node);
	for (const child of node.children) await visitDependenciesAsync(child, callback, visited);
	for (const blockedBy of node.blockedBy) await visitDependenciesAsync(blockedBy, callback, visited);
	for (const isBlocking of node.isBlocking) await visitDependenciesAsync(isBlocking, callback, visited);
}
function toTreeMap(items, keySelector, parentKeySelector, blockedByKeySelector, isBlockingKeySelector) {
	const itemMap = items.reduce((map, item) => {
		map.set(keySelector(item), {
			item,
			parent: null,
			children: [],
			blockedBy: [],
			isBlocking: []
		});
		return map;
	}, /* @__PURE__ */ new Map());
	for (const item of items) {
		const currentNode = itemMap.get(keySelector(item));
		const parentKey = parentKeySelector(item);
		if (parentKey != null) {
			const parentNode = itemMap.get(parentKey);
			if (parentNode && currentNode) {
				currentNode.parent = parentNode;
				parentNode.children.push(currentNode);
			}
		}
		const blockedByKeys = blockedByKeySelector?.(item) ?? [];
		for (const blockedByKey of blockedByKeys) {
			const dependencyNode = itemMap.get(blockedByKey);
			if (dependencyNode && currentNode && !dependencyNode.blockedBy.includes(currentNode)) {
				if (!currentNode.blockedBy.includes(dependencyNode)) currentNode.blockedBy.push(dependencyNode);
				if (!dependencyNode.isBlocking.includes(currentNode)) dependencyNode.isBlocking.push(currentNode);
			}
		}
		const isBlockingKeys = isBlockingKeySelector?.(item) ?? [];
		for (const isBlockingKey of isBlockingKeys) {
			const dependencyNode = itemMap.get(isBlockingKey);
			if (dependencyNode && currentNode && !dependencyNode.isBlocking.includes(currentNode)) {
				if (!currentNode.isBlocking.includes(dependencyNode)) currentNode.isBlocking.push(dependencyNode);
				if (!dependencyNode.blockedBy.includes(currentNode)) dependencyNode.blockedBy.push(currentNode);
			}
		}
	}
	return itemMap;
}
/**
* Convert content preview draft issue items into a tree structure.
*
* @returns a `Map` of all draft issues, where
*   - `key` is the issue `tag`
*   - `value` is a `TreeNode`, containing the draft issue, and pointers to its parent and children
*/
function useDraftIssueTreeMap() {
	const $ = c$1(6);
	const { items, allOpenItems, versionedItems } = useContentPreview();
	let t0;
	if ($[0] !== allOpenItems) {
		t0 = new Set(allOpenItems);
		$[0] = allOpenItems;
		$[1] = t0;
	} else t0 = $[1];
	const openItemsSet = t0;
	let t1;
	if ($[2] !== items || $[3] !== openItemsSet || $[4] !== versionedItems) {
		t1 = toTreeMap([...versionedItems.entries()].filter(_temp$21).map((t2) => {
			const [, versionIds] = t2;
			const openedVersionId = versionIds.find((id_0) => openItemsSet.has(id_0));
			if (openedVersionId) return items.get(openedVersionId);
			const latestVersionId = versionIds.at(-1);
			return latestVersionId ? items.get(latestVersionId) : void 0;
		}).filter(_temp2$8), _temp3$2, _temp4$1, _temp5, _temp6);
		$[2] = items;
		$[3] = openItemsSet;
		$[4] = versionedItems;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
function _temp6(item_2) {
	return item_2.isBlockingTags;
}
function _temp5(item_1) {
	return item_1.blockedByTags;
}
function _temp4$1(item_0) {
	return item_0.parentTag;
}
function _temp3$2(item) {
	return item.tag;
}
function _temp2$8(x) {
	return !!x;
}
function _temp$21(t0) {
	const [id] = t0;
	return id.startsWith("new-issue:") || id.startsWith("existing-issue:");
}
function useIsStreamingComplete(isStreaming) {
	const $ = c$1(4);
	const [hasStreamingCompleted, setHasStreamingCompleted] = useState(false);
	const hasStreamingStartedRef = useRef(isStreaming);
	let t0;
	let t1;
	if ($[0] !== hasStreamingCompleted || $[1] !== isStreaming) {
		t0 = () => {
			if (isStreaming) hasStreamingStartedRef.current = true;
			if (!isStreaming && hasStreamingStartedRef.current && !hasStreamingCompleted) setHasStreamingCompleted(true);
		};
		t1 = [isStreaming, hasStreamingCompleted];
		$[0] = hasStreamingCompleted;
		$[1] = isStreaming;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	return hasStreamingCompleted;
}
var DraftIssueTreeBlock_module_default = { container: "DraftIssueTreeBlock-module_aodLqW_container" };
var IssueTreeItem = { fromUnknown: (data) => {
	if (typeof data !== "object" || data === null) return null;
	const item = {};
	if ("tag" in data && typeof data.tag === "string") item.tag = data.tag;
	if ("parentTag" in data && typeof data.parentTag === "string") item.parentTag = data.parentTag;
	if ("title" in data && typeof data.title === "string") item.title = data.title;
	else if ("name" in data && typeof data.name === "string") item.title = data.name;
	if ("repository" in data && typeof data.repository === "string") item.repository = data.repository;
	if ("number" in data && typeof data.number === "number") item.number = data.number;
	if ("state" in data && typeof data.state === "string") item.state = data.state;
	if ("url" in data && typeof data.url === "string") item.url = data.url;
	if ("blockedByTags" in data && Array.isArray(data.blockedByTags)) item.blockedByTags = data.blockedByTags.filter((el) => typeof el === "string");
	if ("isBlockingTags" in data && Array.isArray(data.isBlockingTags)) item.isBlockingTags = data.isBlockingTags.filter((el) => typeof el === "string");
	return item;
} };
function parseList(yaml) {
	try {
		const result = load(yaml);
		if (typeof result === "object" && result !== null && "data" in result && Array.isArray(result.data)) return result.data.map(IssueTreeItem.fromUnknown).filter((item) => !!item).filter((item) => !!item.tag);
		return null;
	} catch {
		return null;
	}
}
function IssueTreeBlock({ data }) {
	const items = useSyncState(data, parseList, []);
	const { messageId } = useContentPreviewBlockContext();
	const { updateItem, openItem, openPreviewPane } = useContentPreview();
	const rootNodes = useMemo(() => {
		const tree = toTreeMap(items, (item) => item.tag, (item_0) => item_0.parentTag, (item_1) => item_1.blockedByTags, (item_2) => item_2.isBlockingTags);
		return Array.from(tree.values()).filter((node) => !node.parent);
	}, [items]);
	function onClick(item_3, event) {
		if (!item_3.url) return;
		const [owner, repo] = item_3.repository?.split("/") ?? [];
		if (!owner || !repo || !item_3.number) return;
		const id = `issue:${owner}/${repo}/${item_3.number}`;
		updateItem({
			messageId,
			name: item_3.title ?? "",
			number: item_3.number,
			owner,
			repo,
			id,
			href: item_3.url,
			type: "issue"
		});
		openItem(id);
		openPreviewPane(event?.currentTarget);
	}
	const blockedByDependencies = (node_0) => {
		return node_0.blockedBy.map((b) => {
			return {
				title: b.item.title ?? "",
				href: b.item.url,
				onClick: (e) => {
					if (e.metaKey || e.ctrlKey) return;
					e.preventDefault();
					onClick(b.item, e);
				}
			};
		});
	};
	function renderNode(node_1) {
		return /* @__PURE__ */ jsx(IssueTree.Item, {
			title: node_1.item.title ?? "",
			leadingVisual: /* @__PURE__ */ jsx(LeadingVisual$1, { item: node_1.item }),
			trailingBadge: /* @__PURE__ */ jsx(IssueLocation, { node: node_1 }),
			href: node_1.item.url,
			onClick: (e_0) => {
				if (e_0.metaKey || e_0.ctrlKey) return;
				e_0.preventDefault();
				return onClick(node_1.item, e_0);
			},
			blockedBy: blockedByDependencies(node_1),
			children: node_1.children.map(renderNode)
		}, node_1.item.tag);
	}
	return /* @__PURE__ */ jsx("div", {
		className: DraftIssueTreeBlock_module_default.container,
		children: rootNodes.map((node_2) => {
			let subIssueCount = -1;
			visit$1(node_2, () => subIssueCount++);
			return /* @__PURE__ */ jsxs(IssueTree, {
				subIssueCount,
				children: [/* @__PURE__ */ jsx(IssueTree.RootItem, {
					leadingVisual: /* @__PURE__ */ jsx(LeadingVisual$1, { item: node_2.item }),
					title: node_2.item.title ?? "",
					trailingBadge: /* @__PURE__ */ jsx(IssueLocation, { node: node_2 }),
					href: node_2.item.url,
					onClick: (e_1) => {
						if (e_1.metaKey || e_1.ctrlKey) return;
						e_1.preventDefault();
						return onClick(node_2.item, e_1);
					},
					blockedBy: blockedByDependencies(node_2)
				}), node_2.children.map(renderNode)]
			}, node_2.item.tag);
		})
	});
}
IssueTreeBlock.displayName = "IssueTreeBlock";
function LeadingVisual$1({ item }) {
	if (item.state === "open") return /* @__PURE__ */ jsx(IssueOpenedIcon, { className: "fgColor-open" });
	if (item.state === "closed") return /* @__PURE__ */ jsx(IssueClosedIcon, { className: "fgColor-done" });
}
LeadingVisual$1.displayName = "LeadingVisual";
function IssueLocation({ node }) {
	if (!node.item.repository || !node.item.number) return null;
	if (node.item.repository === node.parent?.item.repository) return /* @__PURE__ */ jsxs("span", {
		className: "fgColor-muted no-wrap",
		children: ["#", node.item.number]
	});
	return /* @__PURE__ */ jsxs("span", {
		className: "fgColor-muted no-wrap",
		children: [
			node.item.repository,
			"#",
			node.item.number
		]
	});
}
IssueLocation.displayName = "IssueLocation";
function isDraftIssueTreeItem(item) {
	return "state" in item && item.state === "draft";
}
function isExistingIssueTreeItem(item) {
	return "state" in item && (item.state === "open" || item.state === "closed");
}
function parseListData$1(yaml) {
	try {
		const result = loadAll(yaml);
		if (Array.isArray(result)) return result.filter((item) => typeof item === "object" && item != null).map((item) => {
			switch ("state" in item ? item.state : void 0) {
				case void 0:
				case "draft": return DraftIssue.fromUnknown(item);
				case "open":
				case "closed": return IssueTreeItem.fromUnknown(item);
			}
		}).filter((item) => !!item).filter((item) => !!item.tag);
		return null;
	} catch {
		return null;
	}
}
function DraftIssueTreeBlock({ data, isStreaming }) {
	const processedData = usePreProcessedDraftIssueContent(data);
	const issues = useMemo(() => {
		return parseListData$1(processedData) || [];
	}, [processedData]);
	const { items, updateItem, openItem, openPreviewPane, closeItem, versionedItems } = useContentPreview();
	const { messageId, messageIndex, autoOpenPreviewPane, hasAutoOpenedPreviewPaneRef, setHasAutoOpenedPreviewPane } = useContentPreviewBlockContext();
	const getId = useCallback((item) => {
		if (isDraftIssueTreeItem(item) && item.tag) return `${item.type === "draft-update-issue" ? "update-issue" : "new-issue"}:${item.tag}#${messageIndex}`;
		if (isExistingIssueTreeItem(item) && item.repository && item.number) return `existing-issue:${item.repository}/${item.number}`;
	}, [messageIndex]);
	useDraftIssueReferenceValidation({
		issues,
		isStreaming,
		isIssueTree: true
	});
	useEffect(() => {
		for (const issue of issues) {
			if (!issue.tag) continue;
			if (!getId(issue)) continue;
			if (isDraftIssueTreeItem(issue)) {
				const draftIssueType_0 = issue.type === "draft-update-issue" ? "update-issue" : "new-issue";
				const issueId = `${draftIssueType_0}:${issue.tag}#${messageIndex}`;
				if (draftIssueType_0 === "update-issue" && issue.repository && issue.issueNumber) closeItem(`issue:${issue.repository}/${issue.issueNumber}`);
				updateItem({
					messageId,
					type: draftIssueType_0,
					id: issueId,
					tag: issue.tag,
					parentTag: issue.parentTag,
					name: issue.title ?? "",
					body: issue.body,
					bodyVersion: issue.bodyVersion,
					repository: issue.repository,
					template: issue.template,
					issueType: issue.issueType,
					milestone: issue.milestone,
					assignees: issue.assignees?.sort(),
					labels: issue.labels?.sort(),
					projects: issue.projects?.map((project) => {
						if (typeof project === "object" && project !== null) {
							const projectObj = project;
							return {
								id: typeof projectObj.id === "string" ? projectObj.id : void 0,
								title: typeof projectObj.title === "string" ? projectObj.title : void 0
							};
						} else return { title: String(project) };
					}).filter((project_0) => Boolean(project_0.title) || Boolean(project_0.id)).sort((a, b) => (a.title || "").localeCompare(b.title || "")),
					defaultValuesById: issue.templateFormValues ?? {},
					isUserEdited: false,
					isStreaming,
					blockedByTags: issue.blockedByTags ?? [],
					isBlockingTags: issue.isBlockingTags ?? [],
					issueNumber: issue.issueNumber
				});
			}
			if (isExistingIssueTreeItem(issue) && issue.repository && issue.number && issue.url) {
				closeItem(`issue:${issue.repository}/${issue.number}`);
				updateItem({
					messageId,
					type: "existing-issue",
					id: `existing-issue:${issue.repository}/${issue.number}`,
					tag: issue.tag,
					parentTag: issue.parentTag,
					repository: issue.repository,
					number: issue.number,
					name: issue.title ?? "",
					state: issue.state ?? "open",
					href: issue.url,
					blockedByTags: issue.blockedByTags ?? [],
					isBlockingTags: issue.isBlockingTags ?? []
				});
			}
		}
	}, [
		getId,
		isStreaming,
		issues,
		messageId,
		messageIndex,
		updateItem,
		closeItem
	]);
	const openIssue = useCallback((issue_0, { selectItem, event }) => {
		const id_0 = getId(issue_0);
		if (id_0) {
			openItem(id_0, selectItem);
			if (selectItem || autoOpenPreviewPane && !hasAutoOpenedPreviewPaneRef.current) {
				openPreviewPane(event?.currentTarget);
				setHasAutoOpenedPreviewPane(true);
			}
			sendEvent("dotcom_chat.activate", {
				target: "BROWSER_DRAFT_ISSUE_OPENED",
				mode: "immersive"
			});
		}
	}, [
		getId,
		openItem,
		autoOpenPreviewPane,
		hasAutoOpenedPreviewPaneRef,
		openPreviewPane,
		setHasAutoOpenedPreviewPane
	]);
	const resolveMissingIssue = useCallback((missingTag) => {
		const missingItem = [...items.entries()].find(([id_1, item_0]) => (id_1.startsWith("new-issue:") || id_1.startsWith("existing-issue:")) && (item_0.type === "new-issue" || item_0.type === "existing-issue") && item_0.tag === missingTag);
		if (!missingItem) return;
		const [missingId] = missingItem;
		const unversionedId = stripVersionFromId(missingId);
		const latestVersionId = versionedItems.get(unversionedId)?.at(-1);
		if (!latestVersionId) return;
		const latestMissingIssue = items.get(latestVersionId);
		if (!latestMissingIssue) return;
		switch (latestMissingIssue?.type) {
			case "new-issue":
			case "update-issue": return {
				...DraftIssue.fromUnknown(latestMissingIssue),
				state: "draft"
			};
			case "existing-issue": return IssueTreeItem.fromUnknown(latestMissingIssue);
			default: return;
		}
	}, [items, versionedItems]);
	const rootNodes = useMemo(() => {
		const distinctTags = new Set(issues.map((issue_1) => issue_1.tag));
		const distinctParentTags = new Set(issues.filter((x) => x.parentTag != null).map((x_0) => x_0.parentTag));
		const distinctBlockedByTags = new Set(issues.flatMap((x_1) => x_1.blockedByTags != null ? x_1.blockedByTags : []).filter((tag) => tag != null));
		const distinctIsBlockingTags = new Set(issues.flatMap((x_2) => x_2.isBlockingTags != null ? x_2.isBlockingTags : []).filter((tag_0) => tag_0 != null));
		const resolvedIssues = Array.from(new Set([
			...distinctParentTags,
			...distinctBlockedByTags,
			...distinctIsBlockingTags
		])).filter((tag_1) => tag_1 != null && !distinctTags.has(tag_1)).map((tag_2) => resolveMissingIssue(tag_2)).filter((issue_2) => issue_2 != null);
		const tree = toTreeMap([...issues, ...resolvedIssues], (issue_3) => issue_3.tag, (issue_4) => issue_4.parentTag, (issue_5) => issue_5.blockedByTags, (issue_6) => issue_6.isBlockingTags);
		return Array.from(tree.values()).filter((node) => !node.parent);
	}, [issues, resolveMissingIssue]);
	const isStreamingCompleted = useIsStreamingComplete(isStreaming);
	useEffect(() => {
		if (!isStreamingCompleted) return;
		let selectItem_0 = true;
		for (const node_0 of rootNodes.values()) {
			if (isDraftIssueTreeItem(node_0.item)) {
				openIssue(node_0.item, { selectItem: selectItem_0 });
				selectItem_0 = false;
				continue;
			}
			for (const child of node_0.children) if (isDraftIssueTreeItem(child.item)) {
				openIssue(child.item, { selectItem: selectItem_0 });
				selectItem_0 = false;
			}
		}
	}, [
		isStreamingCompleted,
		rootNodes,
		openIssue
	]);
	const blockedByDependencies = (node_1) => {
		return node_1.blockedBy.map((b_0) => {
			return {
				title: b_0.item.title ?? "",
				href: isExistingIssueTreeItem(b_0.item) ? b_0.item.url : void 0,
				onClick: (e) => {
					if (e.metaKey || e.ctrlKey) return;
					e.preventDefault();
					openIssue(b_0.item, {
						selectItem: true,
						event: e
					});
				}
			};
		});
	};
	const renderNode = (node_2) => {
		const id_2 = getId(node_2.item);
		const version = id_2 ? getRevisionNumber(id_2, versionedItems, items) : null;
		return /* @__PURE__ */ jsx(IssueTree.Item, {
			title: node_2.item.title ?? "",
			leadingVisual: /* @__PURE__ */ jsx(LeadingVisual, {
				isStreaming,
				item: node_2.item
			}),
			trailingBadge: version != null ? /* @__PURE__ */ jsx(VersionName, { version }) : void 0,
			onClick: (e_0) => {
				if (e_0.metaKey || e_0.ctrlKey) return;
				e_0.preventDefault();
				openIssue(node_2.item, {
					selectItem: true,
					event: e_0
				});
			},
			href: isExistingIssueTreeItem(node_2.item) ? node_2.item.url : void 0,
			blockedBy: blockedByDependencies(node_2),
			children: node_2.children.map(renderNode)
		}, node_2.item.tag);
	};
	return /* @__PURE__ */ jsx("div", {
		className: DraftIssueTreeBlock_module_default.container,
		children: rootNodes.map((node_3) => {
			const id_3 = getId(node_3.item);
			const version_0 = id_3 ? getRevisionNumber(id_3, versionedItems, items) : null;
			let totalChildCount = -1;
			visit$1(node_3, () => totalChildCount++);
			return /* @__PURE__ */ jsxs(IssueTree, {
				subIssueHeaderText: isExistingIssueTreeItem(node_3.item) ? "New sub-issues" : void 0,
				subIssueCount: totalChildCount,
				children: [/* @__PURE__ */ jsx(IssueTree.RootItem, {
					title: node_3.item.title ?? "",
					leadingVisual: /* @__PURE__ */ jsx(LeadingVisual, {
						isStreaming,
						item: node_3.item
					}),
					trailingBadge: version_0 != null ? /* @__PURE__ */ jsx(VersionName, {
						"data-testid": "version-label",
						version: version_0
					}) : void 0,
					onClick: (e_1) => {
						if (e_1.metaKey || e_1.ctrlKey) return;
						e_1.preventDefault();
						openIssue(node_3.item, {
							selectItem: true,
							event: e_1
						});
					},
					href: isExistingIssueTreeItem(node_3.item) ? node_3.item.url : void 0,
					blockedBy: blockedByDependencies(node_3)
				}), node_3.children.map(renderNode)]
			}, node_3.item.tag);
		})
	});
}
DraftIssueTreeBlock.displayName = "DraftIssueTreeBlock";
function LeadingVisual({ isStreaming, item }) {
	if (isStreaming) return /* @__PURE__ */ jsx(Spinner, {
		size: "small",
		className: `${disableStreamingFadeIn} mt-1`
	});
	if (isDraftIssueTreeItem(item)) return /* @__PURE__ */ jsx(IssueIcon, { type: item.type === "draft-update-issue" ? "update-issue" : "new-issue" });
	if (isExistingIssueTreeItem(item)) return /* @__PURE__ */ jsx(IssueIcon, {
		type: "existing-issue",
		state: item.state
	});
}
LeadingVisual.displayName = "LeadingVisual";
var instance$2 = new class extends YamlBlockExtension {
	get dataAttribute() {
		return "data-draft-tree-issue-block";
	}
	isSupported(node) {
		return node.lang === "yaml" && node.type === "draft-issue-tree";
	}
	extractProps(node) {
		return {
			data: node.value,
			isStreaming: node.isStreaming ?? false
		};
	}
	createComponent(props) {
		return /* @__PURE__ */ jsx(DraftIssueTreeBlock, { ...props });
	}
}();
function draftIssueTreeExtension() {
	return instance$2;
}
/**
* Extract the issue title from the message's references.
*/
function extractIssueTitle(messages, messageId, owner, repo, number) {
	if (!owner || !repo || !number || isNaN(number)) return void 0;
	const references = messages.find((m) => m.id === messageId)?.references;
	const title = (references?.find((reference) => reference.type === "issue" && reference.number === number && reference.repository.name === repo && reference.repository.owner === owner))?.title;
	if (title) return title;
	return ((references?.find((reference) => reference.type === "api-response" && reference.resourceType === "Issue" && reference.repo === `${owner}/${repo}` && reference.data.number === number))?.data)?.title;
}
function IssueLinkBlock({ owner, repo, issueNumber, href, children }) {
	const { updateItem, openItem, openPreviewPane, items } = useContentPreview();
	const { messageId } = useContentPreviewBlockContext();
	const messages = useChatStateValue("messages");
	const linkRef = useRef(null);
	const number = Number(issueNumber);
	const issueLink = href;
	const id = `issue:${owner}/${repo}/${number}`;
	const item = items.get(id);
	const title = extractIssueTitle(messages, messageId, owner, repo, number) ?? item?.name ?? `Issue #${number}`;
	useEffect(() => {
		if (owner && repo) updateItem({
			messageId,
			name: title,
			number,
			owner,
			repo,
			id,
			href,
			type: "issue"
		});
	}, [
		id,
		messageId,
		href,
		number,
		owner,
		repo,
		title,
		updateItem
	]);
	return /* @__PURE__ */ jsx(Link, {
		ref: linkRef,
		href: issueLink,
		onClick: (e) => {
			if (e.metaKey || e.ctrlKey) return;
			openItem(id);
			openPreviewPane(linkRef.current);
			sendEvent("dotcom_chat.activate", {
				target: "BROWSER_ISSUE_OPENED",
				mode: "immersive"
			});
			e.preventDefault();
		},
		target: "_blank",
		rel: "noreferrer",
		children
	});
}
IssueLinkBlock.displayName = "IssueLinkBlock";
var issueLinkAttribute = "data-issuelink-props";
var issueLinkProperty = dataAttrToPropName(issueLinkAttribute);
var issueLinkRegex = /\/(?<owner>[^/]+)\/(?<repo>[^/]+)\/issues\/(?<number>\d+)/;
var reactComponents = { span: (props, fallthrough) => {
	const issueLinkBlockProps = parseJsonAttribute(props, issueLinkAttribute);
	if (!issueLinkBlockProps) return fallthrough;
	return /* @__PURE__ */ jsx(IssueLinkBlock, { ...issueLinkBlockProps });
} };
/**
* Intercepts issue links and replaces them with a link that opens the issue browser
*/
function issueLinkExtension() {
	return {
		transformMarkdown: (tree) => visit(tree, "link", (node) => {
			try {
				if (new URL(node.url, window.location.origin).origin !== window.location.origin) return;
			} catch {
				return;
			}
			const match = issueLinkRegex.exec(node.url);
			if (!match?.groups) return;
			const { owner = "", repo = "", number = "" } = match.groups;
			node.data = {
				hName: "span",
				hProperties: { [issueLinkProperty]: JSON.stringify({
					owner,
					repo,
					issueNumber: number,
					href: node.url,
					children: toString(node)
				}) }
			};
		}),
		reactComponents
	};
}
/**
* Hook to sync with live agent task data including states and titles
* This subscribes to changes from both the agent-tasks cache and pull-requests cache
* to get live state and title updates without making additional API calls.
*
* @returns A map of task URLs to their current state and title
*/
function useTaskStateSync() {
	const $ = c$1(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = getAgentTasksQueryKey(1, "active");
		$[0] = t0;
	} else t0 = $[0];
	const tasksQueryKey = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			queryKey: tasksQueryKey,
			queryFn: _temp$20,
			enabled: false,
			notifyOnChangeProps: ["data"]
		};
		$[1] = t1;
	} else t1 = $[1];
	const { data: cachedData } = useQuery(t1);
	const cachedTasks = cachedData?.[0] ?? [];
	const pullRequestIds = getSortedResourceIds(cachedTasks || []);
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = ["data"];
		$[2] = t2;
	} else t2 = $[2];
	const { data: pullRequestsMap } = useQuery({
		queryKey: ["agent-sessions-pull-requests", pullRequestIds],
		queryFn: _temp2$7,
		enabled: false,
		notifyOnChangeProps: t2
	});
	const taskStateMap = /* @__PURE__ */ new Map();
	if (cachedTasks.length > 0) for (const task of cachedTasks) {
		if (!task.resource_global_id) continue;
		const taskUrl = `https://github.com/copilot/tasks/pull/${task.resource_global_id}`;
		const pull = task.resource_id && pullRequestsMap ? pullRequestsMap[task.resource_id] : void 0;
		const taskData = {
			state: task.latest_session_state,
			title: pull?.title
		};
		taskStateMap.set(taskUrl, taskData);
	}
	return taskStateMap;
}
function _temp2$7() {
	return {};
}
function _temp$20() {
	return [
		[],
		false,
		void 0
	];
}
var IssueListBlock_module_default = {
	blockContainer: "IssueListBlock-module_D0N9aq_blockContainer",
	checkCircleIcon: "IssueListBlock-module_D0N9aq_checkCircleIcon",
	clockIcon: "IssueListBlock-module_D0N9aq_clockIcon",
	closed: "IssueListBlock-module_D0N9aq_closed",
	comments: "IssueListBlock-module_D0N9aq_comments",
	content: "IssueListBlock-module_D0N9aq_content",
	description: "IssueListBlock-module_D0N9aq_description",
	descriptionSkeleton: "IssueListBlock-module_D0N9aq_descriptionSkeleton",
	done: "IssueListBlock-module_D0N9aq_done",
	dotFillIcon: "IssueListBlock-module_D0N9aq_dotFillIcon",
	draft: "IssueListBlock-module_D0N9aq_draft",
	header: "IssueListBlock-module_D0N9aq_header",
	icon: "IssueListBlock-module_D0N9aq_icon",
	item: "IssueListBlock-module_D0N9aq_item",
	label: "IssueListBlock-module_D0N9aq_label",
	labelIcon: "IssueListBlock-module_D0N9aq_labelIcon",
	labels: "IssueListBlock-module_D0N9aq_labels",
	link: "IssueListBlock-module_D0N9aq_link",
	list: "IssueListBlock-module_D0N9aq_list",
	metadata: "IssueListBlock-module_D0N9aq_metadata",
	number: "IssueListBlock-module_D0N9aq_number",
	open: "IssueListBlock-module_D0N9aq_open",
	shimmer: "IssueListBlock-module_D0N9aq_shimmer",
	skipIcon: "IssueListBlock-module_D0N9aq_skipIcon",
	stopIcon: "IssueListBlock-module_D0N9aq_stopIcon",
	streaming: "IssueListBlock-module_D0N9aq_streaming",
	title: "IssueListBlock-module_D0N9aq_title",
	titleSkeleton: "IssueListBlock-module_D0N9aq_titleSkeleton",
	toggleButton: "IssueListBlock-module_D0N9aq_toggleButton",
	toggleContent: "IssueListBlock-module_D0N9aq_toggleContent",
	toggleIcon: "IssueListBlock-module_D0N9aq_toggleIcon",
	unassignedAvatar: "IssueListBlock-module_D0N9aq_unassignedAvatar",
	unknown: "IssueListBlock-module_D0N9aq_unknown",
	unknownTitle: "IssueListBlock-module_D0N9aq_unknownTitle"
};
var ListItem = { fromUnknown: (data) => {
	if (typeof data !== "object" || data === null) return {};
	const item = {};
	if ("url" in data && typeof data.url === "string") item.url = data.url;
	if ("state" in data && typeof data.state === "string") item.state = data.state;
	if ("draft" in data && typeof data.draft === "boolean") item.draft = data.draft;
	if ("created_at" in data && typeof data.created_at === "string") item.created_at = data.created_at;
	if ("closed_at" in data && typeof data.closed_at === "string") item.closed_at = data.closed_at;
	if ("merged_at" in data && typeof data.merged_at === "string") item.merged_at = data.merged_at;
	if ("title" in data && typeof data.title === "string") item.title = data.title;
	if ("number" in data && typeof data.number === "number") item.number = data.number;
	if ("labels" in data && Array.isArray(data.labels)) item.labels = data.labels.filter((el) => typeof el === "string");
	if ("author" in data && typeof data.author === "string") item.author = data.author;
	if ("comments" in data && typeof data.comments === "number") item.comments = data.comments;
	if ("assignees_avatar_urls" in data && Array.isArray(data.assignees_avatar_urls)) item.assignees_avatar_urls = data.assignees_avatar_urls.filter((el) => typeof el === "string");
	if ("repository" in data && typeof data.repository === "string") item.repository = data.repository;
	return item;
} };
function parseGitHubIssueUrl(url) {
	const match = /^https?:\/\/[^/]+\/([^/]+)\/([^/]+)\/issues\/(\d+)(\/.*)?$/.exec(url);
	if (!match) return {};
	const number = parseInt(match[3] ?? "0", 10);
	return {
		owner: match[1],
		repo: match[2],
		number
	};
}
function getIconProps(item, taskResponseEnabled) {
	let icon = null;
	let colorClass;
	if (item.type === "issue") {
		if (item.state === "open" && !item.draft) {
			icon = /* @__PURE__ */ jsx(IssueOpenedIcon, { "aria-label": "Open issue" });
			colorClass = IssueListBlock_module_default.open;
		} else if (item.state === "closed" && !item.draft) {
			icon = /* @__PURE__ */ jsx(IssueClosedIcon, { "aria-label": "Closed issue" });
			colorClass = IssueListBlock_module_default.done;
		} else if (item.state === "open" && item.draft) {
			icon = /* @__PURE__ */ jsx(IssueDraftIcon, { "aria-label": "Draft issue" });
			colorClass = IssueListBlock_module_default.draft;
		} else if (item.state === "closed" && item.draft) {
			icon = /* @__PURE__ */ jsx(SkipIcon, { "aria-label": "Closed draft issue" });
			colorClass = IssueListBlock_module_default.draft;
		}
	} else if (item.type === "pr") {
		const isMerged = typeof item.merged_at === "string" && item.merged_at.length > 0;
		if (item.state === "open" && !isMerged && item.draft) {
			icon = /* @__PURE__ */ jsx(GitPullRequestDraftIcon, { "aria-label": "Draft pull request" });
			colorClass = IssueListBlock_module_default.draft;
		} else if (item.state === "open" && !isMerged && !item.draft) {
			icon = /* @__PURE__ */ jsx(GitPullRequestIcon, { "aria-label": "Pull request" });
			colorClass = IssueListBlock_module_default.open;
		} else if (item.state === "closed" && !isMerged) {
			icon = /* @__PURE__ */ jsx(GitPullRequestClosedIcon, { "aria-label": "Closed pull request" });
			colorClass = IssueListBlock_module_default.closed;
		} else if (item.state === "closed" && isMerged) {
			icon = /* @__PURE__ */ jsx(GitMergeIcon, { "aria-label": "Merged pull request" });
			colorClass = IssueListBlock_module_default.done;
		}
	} else if (item.type === "task" && taskResponseEnabled) {
		if (item.state === "queued") {
			icon = /* @__PURE__ */ jsx(ClockIcon, {
				"aria-label": "Task queued",
				className: IssueListBlock_module_default.clockIcon
			});
			colorClass = IssueListBlock_module_default.open;
		} else if (item.state === "pending" || item.state === "idle") {
			icon = /* @__PURE__ */ jsx(DotFillIcon, {
				"aria-label": "Task pending",
				className: IssueListBlock_module_default.dotFillIcon
			});
			colorClass = IssueListBlock_module_default.open;
		} else if (item.state === "running" || item.state === "in_progress") {
			icon = /* @__PURE__ */ jsx(CheckSpinner, { animated: true });
			colorClass = IssueListBlock_module_default.open;
		} else if (item.state === "completed" || item.state === "waiting_for_user") {
			icon = /* @__PURE__ */ jsx(CheckCircleFillIcon, {
				"aria-label": "Task completed",
				className: IssueListBlock_module_default.checkCircleIcon
			});
			colorClass = IssueListBlock_module_default.done;
		} else if (item.state === "failed" || item.state === "timed_out") {
			icon = /* @__PURE__ */ jsx(XCircleFillIcon, {
				"aria-label": "Task failed",
				className: IssueListBlock_module_default.stopIcon
			});
			colorClass = IssueListBlock_module_default.closed;
		} else if (item.state === "cancelled") {
			icon = /* @__PURE__ */ jsx(SkipIcon, {
				"aria-label": "Task cancelled",
				className: IssueListBlock_module_default.skipIcon
			});
			colorClass = IssueListBlock_module_default.closed;
		}
	}
	return {
		icon,
		colorClass
	};
}
function Description({ item, isStreaming }) {
	const author = item.author;
	let dateValue = void 0;
	let action = void 0;
	if (item.merged_at) {
		dateValue = item.merged_at;
		action = "Merged";
	} else if (item.closed_at) {
		dateValue = item.closed_at;
		action = "Closed";
	} else if (item.created_at) {
		dateValue = item.created_at;
		action = "Opened";
	}
	let parsedDate = dateValue ? new Date(dateValue) : null;
	if (parsedDate && isNaN(parsedDate.getTime())) parsedDate = null;
	const hasRepository = !!item.repository;
	if ((!author || !parsedDate) && isStreaming && !hasRepository) return null;
	return /* @__PURE__ */ jsxs("span", {
		className: IssueListBlock_module_default.description,
		children: [hasRepository && /* @__PURE__ */ jsxs(Fragment$1, { children: [item.repository, (author || parsedDate) && " · "] }), (author || parsedDate) && action && /* @__PURE__ */ jsxs(Fragment$1, { children: [
			author,
			" ",
			author ? action.toLowerCase() : action,
			" ",
			parsedDate && /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(RelativeTime, {
				date: parsedDate,
				format: "relative"
			}) })
		] })]
	});
}
Description.displayName = "Description";
var parseListData = (yaml) => {
	try {
		const result = load(yaml);
		if (typeof result === "object" && result !== null && "data" in result && Array.isArray(result.data)) return result.data.map(ListItem.fromUnknown);
		return null;
	} catch {
		return null;
	}
};
function ListBlock(t0) {
	const $ = c$1(5);
	const { data, type, isStreaming: isBlockStreaming } = t0;
	let t1;
	if ($[0] !== data) {
		t1 = () => parseListData(data) ?? [];
		$[0] = data;
		$[1] = t1;
	} else t1 = $[1];
	const [items, setItems] = useState(t1);
	const { updateItem, openItem, openPreviewPane } = useContentPreview();
	const { messageId } = useContentPreviewBlockContext();
	const [collapsed, setCollapsed] = useState(true);
	const hasMoreItemsEnabled = isFeatureEnabled("copilot_issue_list_show_more");
	const taskResponseEnabled = isFeatureEnabled("copilot_coding_agent_task_response");
	const taskStateMap = useTaskStateSync();
	const visibleItems = hasMoreItemsEnabled && collapsed ? items.slice(0, 10) : items;
	const hasMoreItems = hasMoreItemsEnabled && items.length > 10;
	let t2;
	let t3;
	if ($[2] !== data) {
		t2 = () => setItems((lastParsedData) => parseListData(data) ?? lastParsedData);
		t3 = [data];
		$[2] = data;
		$[3] = t2;
		$[4] = t3;
	} else {
		t2 = $[3];
		t3 = $[4];
	}
	useEffect(t2, t3);
	useEffect(() => {
		if (type === "issue") sendEvent("dotcom_chat.activate", {
			target: "ISSUE_LIST_BLOCK_RENDERED",
			mode: "immersive"
		});
		else if (type === "pr") sendEvent("dotcom_chat.activate", {
			target: "PR_LIST_BLOCK_RENDERED",
			mode: "immersive"
		});
		else if (type === "task" && taskResponseEnabled) sendEvent("dotcom_chat.activate", {
			target: "TASK_LIST_BLOCK_RENDERED",
			mode: "immersive"
		});
	}, [type, taskResponseEnabled]);
	return jsx("div", { children: jsxs("ul", {
		id: "issue-list",
		className: clsx(IssueListBlock_module_default.list, isBlockStreaming && IssueListBlock_module_default.streaming),
		children: [visibleItems.map((item, index) => {
			let newItem = {
				...item,
				type
			};
			if (type === "task" && taskResponseEnabled && item.url) {
				const liveTaskState = taskStateMap.get(item.url);
				if (liveTaskState) newItem = {
					...newItem,
					state: liveTaskState.state,
					title: liveTaskState.title ?? newItem.title
				};
			}
			const isStreaming = isBlockStreaming && index === visibleItems.length - 1;
			const { icon, colorClass } = getIconProps(newItem, taskResponseEnabled);
			return jsx("li", {
				className: IssueListBlock_module_default.item,
				children: jsxs("div", {
					className: IssueListBlock_module_default.content,
					children: [
						jsx("div", {
							className: clsx(colorClass, IssueListBlock_module_default.icon),
							children: icon
						}),
						jsxs("div", {
							className: IssueListBlock_module_default.header,
							children: [isStreaming && !newItem.title ? null : jsx("a", {
								...testIdProps("issue-list-item-link"),
								href: newItem.url ?? "#",
								className: IssueListBlock_module_default.link,
								onClick: (e) => {
									if (e.metaKey || e.ctrlKey) return;
									e.preventDefault();
									const targetUrl = newItem.url;
									if (!targetUrl) return;
									if (newItem.type === "issue") {
										sendEvent("dotcom_chat.activate", {
											target: "ISSUE_LIST_BLOCK_ITEM_OPEN",
											mode: "immersive"
										});
										const { owner, repo, number } = parseGitHubIssueUrl(targetUrl);
										if (owner && repo && number) {
											const id = `issue:${owner}/${repo}/${number}`;
											updateItem({
												messageId,
												name: newItem.title ?? `Issue #${number}`,
												state: newItem.state === "open" || newItem.state === "closed" ? newItem.state : void 0,
												number,
												owner,
												repo,
												id,
												href: targetUrl,
												type: "issue"
											});
											openItem(id);
											openPreviewPane(e.currentTarget);
										}
									} else if (newItem.type === "task" && taskResponseEnabled) {
										sendEvent("dotcom_chat.activate", {
											target: "TASK_LIST_BLOCK_ITEM_OPEN",
											mode: "immersive"
										});
										window.open(targetUrl, "_self");
									} else {
										sendEvent("dotcom_chat.activate", {
											target: "PR_LIST_BLOCK_ITEM_OPEN",
											mode: "immersive"
										});
										window.open(targetUrl, "_self");
									}
								},
								target: "_blank",
								rel: "noreferrer",
								children: newItem.title ? jsxs(Fragment$1, { children: [jsx("span", {
									className: IssueListBlock_module_default.title,
									children: newItem.title
								}), newItem.number !== void 0 && newItem.type !== "task" && jsxs("span", {
									className: IssueListBlock_module_default.number,
									children: ["#", newItem.number]
								})] }) : newItem.number !== void 0 ? jsxs("span", {
									className: IssueListBlock_module_default.title,
									children: ["#", newItem.number]
								}) : jsx("span", {
									className: clsx(IssueListBlock_module_default.title, IssueListBlock_module_default.unknownTitle),
									children: newItem.type === "task" ? "Unknown task" : "Unknown issue"
								})
							}), newItem.type !== "task" && jsxs("div", {
								className: IssueListBlock_module_default.labels,
								children: [newItem.labels?.length ? newItem.labels.map(_temp$19) : null, newItem.comments !== 0 && newItem.comments !== void 0 && jsxs(Label, {
									size: "small",
									variant: "secondary",
									children: [jsx(CommentIcon, {
										className: IssueListBlock_module_default.labelIcon,
										size: 12
									}), newItem.comments]
								})]
							})]
						}),
						newItem.type === "task" && taskResponseEnabled ? newItem.repository ? jsx("div", {
							className: IssueListBlock_module_default.description,
							children: newItem.repository
						}) : null : jsx(Description, {
							item: newItem,
							isStreaming
						}),
						(newItem.type !== "task" || !taskResponseEnabled) && jsx("div", {
							className: IssueListBlock_module_default.metadata,
							children: newItem.assignees_avatar_urls === void 0 ? null : newItem.assignees_avatar_urls.length === 0 ? jsx("div", {
								className: IssueListBlock_module_default.unassignedAvatar,
								role: "img",
								"aria-label": "Unassigned",
								children: jsx(PersonIcon, { size: 12 })
							}) : jsx("div", {
								role: "img",
								"aria-label": `${newItem.assignees_avatar_urls.length} ${newItem.assignees_avatar_urls.length === 1 ? "assignee" : "assignees"}`,
								children: jsx(AvatarStack, {
									disableExpand: true,
									children: newItem.assignees_avatar_urls.map(_temp2$6)
								})
							})
						})
					]
				})
			}, index);
		}), hasMoreItems && jsx("li", {
			className: IssueListBlock_module_default.item,
			children: jsx("div", {
				className: clsx(IssueListBlock_module_default.content, IssueListBlock_module_default.toggleContent),
				children: jsxs("button", {
					type: "button",
					className: clsx(IssueListBlock_module_default.toggleButton, isBlockStreaming && IssueListBlock_module_default.shimmer),
					onClick: () => setCollapsed(!collapsed),
					"aria-expanded": !collapsed,
					"aria-controls": "issue-list",
					children: [jsx("span", {
						className: IssueListBlock_module_default.toggleIcon,
						children: collapsed ? jsx(UnfoldIcon, { size: 16 }) : jsx(FoldIcon, { size: 16 })
					}), collapsed ? `Show ${items.length - 10} more` : "Show less"]
				})
			})
		})]
	}) });
}
ListBlock.displayName = "ListBlock";
function _temp2$6(url) {
	return jsx(GitHubAvatar, {
		src: url,
		alt: "Assignee avatar"
	}, url);
}
function _temp$19(label) {
	return jsx(Label, {
		size: "small",
		variant: "secondary",
		className: IssueListBlock_module_default.label,
		children: jsx(Truncate, {
			inline: true,
			maxWidth: "100%",
			title: label,
			children: label
		})
	}, label);
}
var instance$1 = new class extends YamlBlockExtension {
	get dataAttribute() {
		return "data-issues-list-block";
	}
	isSupported(node) {
		return node.lang === "list" && (node.type === "issue" || node.type === "pr" || node.type === "task");
	}
	extractProps(node) {
		return {
			data: node.value,
			type: node.type,
			isStreaming: node.isStreaming ?? false
		};
	}
	createComponent(props) {
		return /* @__PURE__ */ jsx(ListBlock, { ...props });
	}
}();
function listExtension() {
	return instance$1;
}
var instance = new class extends YamlBlockExtension {
	get dataAttribute() {
		return "data-tree-issue-block";
	}
	isSupported(node) {
		return node.lang === "yaml" && node.type === "issue-tree";
	}
	extractProps(node) {
		return { data: node.value };
	}
	createComponent(props) {
		return /* @__PURE__ */ jsx(IssueTreeBlock, { ...props });
	}
}();
function issueTreeExtension() {
	return instance;
}
var MarkdownViewer_module_default = { markdownOverrides: "MarkdownViewer-module_VGrRjW_markdownOverrides" };
var MarkdownViewer = ({ messageId, messageIndex, messageTimestamp, autoOpenPreviewPane, markdown, onGitHubLinkClick, ...rendererProps }) => {
	const hasAutoOpenedPreviewPaneRef = useRef(false);
	const setHasAutoOpenedPreviewPane = useCallback((value) => {
		hasAutoOpenedPreviewPaneRef.current = value;
	}, []);
	const extensions = useMemo(() => {
		const fileBlocksInMessage = [];
		return [
			...rendererProps.extensions ?? [],
			fileViewExtension(fileBlocksInMessage),
			issueLinkExtension(),
			listExtension(),
			issueTreeExtension(),
			draftIssueExtension(),
			draftIssueTreeExtension()
		];
	}, [rendererProps.extensions]);
	return /* @__PURE__ */ jsx(ContentPreviewBlockContext, {
		value: useMemo(() => ({
			messageId,
			messageIndex,
			messageTimestamp,
			autoOpenPreviewPane,
			markdown,
			hasAutoOpenedPreviewPaneRef,
			setHasAutoOpenedPreviewPane
		}), [
			messageId,
			messageIndex,
			messageTimestamp,
			autoOpenPreviewPane,
			markdown,
			hasAutoOpenedPreviewPaneRef,
			setHasAutoOpenedPreviewPane
		]),
		children: /* @__PURE__ */ jsx(MarkdownRenderer, {
			...rendererProps,
			markdown,
			extensions,
			chatMode: "immersive",
			className: MarkdownViewer_module_default.markdownOverrides,
			onLinkClick: onGitHubLinkClick
		})
	});
};
MarkdownViewer.displayName = "MarkdownViewer";
var MemoizedMarkdownViewer = React.memo(MarkdownViewer);
MemoizedMarkdownViewer.displayName = "MemoizedMarkdownViewer";
var OptimisticLogsContext = createContext(void 0);
/**
* Check if a tool response exists in logs for a given tool call ID.
*/
OptimisticLogsContext.displayName = "OptimisticLogsContext";
function hasToolResponseInLogs(toolCallId, logs) {
	return logs.some((entry) => {
		if (isCompletionToolMessage(entry) && entry.tool_call_id === toolCallId) return true;
		if (isToolOutputsMessage(entry) && entry.toolCallId === toolCallId) return true;
		return false;
	});
}
/**
* Provider for managing optimistic log entries.
*
* When a user responds to a prompt (permission, ask_user, plan approval),
* we show the response optimistically before the server confirms it.
* This prevents a jarring gap between the user's action and visual feedback.
*
* Pass `sessionId` to enable automatic cleanup when real responses appear in logs.
*/
function OptimisticLogsProvider(t0) {
	const $ = c$1(19);
	const { children, sessionId } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [rawOptimisticResponses, setRawOptimisticResponses] = useState(t1);
	const t2 = !!sessionId;
	let t3;
	if ($[1] !== sessionId || $[2] !== t2) {
		t3 = {
			sessionId,
			enabled: t2
		};
		$[1] = sessionId;
		$[2] = t2;
		$[3] = t3;
	} else t3 = $[3];
	const { data: logs } = useLogsQuery(t3);
	let t4;
	bb0: {
		if (!logs || logs.length === 0 || rawOptimisticResponses.length === 0) {
			t4 = rawOptimisticResponses;
			break bb0;
		}
		let t5;
		if ($[4] !== logs || $[5] !== rawOptimisticResponses) {
			let t6;
			if ($[7] !== logs) {
				t6 = (entry) => !hasToolResponseInLogs(entry.toolCallId, logs);
				$[7] = logs;
				$[8] = t6;
			} else t6 = $[8];
			t5 = rawOptimisticResponses.filter(t6);
			$[4] = logs;
			$[5] = rawOptimisticResponses;
			$[6] = t5;
		} else t5 = $[6];
		t4 = t5;
	}
	const optimisticResponses = t4;
	let t5;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = (t6) => {
			const { toolCallId, response, commandType } = t6;
			const id = `optimistic-${uuid()}`;
			const entry_0 = {
				id,
				toolCallId,
				response,
				commandType,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				status: "pending"
			};
			setRawOptimisticResponses((prev) => [...prev, entry_0]);
			return id;
		};
		$[9] = t5;
	} else t5 = $[9];
	const addOptimisticResponse = t5;
	let t6;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = (id_0) => {
			setRawOptimisticResponses((prev_0) => prev_0.filter((r) => r.id !== id_0));
		};
		$[10] = t6;
	} else t6 = $[10];
	const removeOptimisticResponse = t6;
	let t7;
	if ($[11] !== optimisticResponses) {
		t7 = (toolCallId_0) => optimisticResponses.find((r_0) => r_0.toolCallId === toolCallId_0);
		$[11] = optimisticResponses;
		$[12] = t7;
	} else t7 = $[12];
	const getOptimisticResponseForToolCall = t7;
	let t8;
	if ($[13] !== getOptimisticResponseForToolCall || $[14] !== optimisticResponses) {
		t8 = {
			optimisticResponses,
			addOptimisticResponse,
			removeOptimisticResponse,
			getOptimisticResponseForToolCall
		};
		$[13] = getOptimisticResponseForToolCall;
		$[14] = optimisticResponses;
		$[15] = t8;
	} else t8 = $[15];
	const value = t8;
	let t9;
	if ($[16] !== children || $[17] !== value) {
		t9 = jsx(OptimisticLogsContext, {
			value,
			children
		});
		$[16] = children;
		$[17] = value;
		$[18] = t9;
	} else t9 = $[18];
	return t9;
}
OptimisticLogsProvider.displayName = "OptimisticLogsProvider";
function useOptimisticLogs() {
	const context = use(OptimisticLogsContext);
	if (!context) throw new Error("useOptimisticLogs must be used within an OptimisticLogsProvider");
	return context;
}
/**
* Hook that safely returns optimistic logs context if available.
* Returns undefined if not within provider (for gradual adoption).
*/
function useOptimisticLogsOptional() {
	return use(OptimisticLogsContext);
}
var ASSISTANT_ROLE = "assistant";
function SessionLogs(t0) {
	const $ = c$1(41);
	const { logsPollingInterval, nwo, batchCompletedSessions, currentUser, onLogsLoadingChange } = t0;
	const { session, setMcpToolNameMappings } = useSessionContext();
	const { getChatMessageHistory } = useChatStreamContext();
	let t1;
	if ($[0] !== getChatMessageHistory || $[1] !== session.id) {
		t1 = getChatMessageHistory(session.id);
		$[0] = getChatMessageHistory;
		$[1] = session.id;
		$[2] = t1;
	} else t1 = $[2];
	const chatMessageHistory = t1;
	const deprecatedCurrentUser = useCurrentUser();
	const currentUserOwnsSession = currentUser?.id === session.user_id || deprecatedCurrentUser?.id === session.user_id;
	const { variant } = useSessionLogsContext();
	const { data: agentInfo, isLoading: isAgentInfoLoading } = useAgentInfo(session.agent_id);
	let t2;
	if ($[3] !== logsPollingInterval) {
		t2 = { pollingInterval: logsPollingInterval };
		$[3] = logsPollingInterval;
		$[4] = t2;
	} else t2 = $[4];
	const { data: commandsData } = useListCommands(t2);
	const [steeringCommandError, setSteeringCommandError] = useState(null);
	let t3;
	if ($[5] !== session.id) {
		t3 = async (message) => {
			try {
				setSteeringCommandError(null);
				const response = await fetchCAPI({
					path: `/agents/sessions/${session.id}/commands`,
					method: "POST",
					body: { content: message }
				});
				if (!response.ok) {
					setSteeringCommandError(`Failed to create command: ${response.statusText}`);
					return;
				}
			} catch {
				setSteeringCommandError("Failed to submit command. Please try again.");
			}
		};
		$[5] = session.id;
		$[6] = t3;
	} else t3 = $[6];
	const handleSteeringCommandSubmit = t3;
	let t4;
	if ($[7] !== batchCompletedSessions || $[8] !== currentUserOwnsSession || $[9] !== logsPollingInterval) {
		t4 = {
			logsPollingInterval,
			batchCompletedSessions,
			currentUserIsSessionOwner: currentUserOwnsSession
		};
		$[7] = batchCompletedSessions;
		$[8] = currentUserOwnsSession;
		$[9] = logsPollingInterval;
		$[10] = t4;
	} else t4 = $[10];
	const { data: logsData, isLoading: logsIsLoading, showPollingError } = useLogs(t4);
	useSyncFavicon(session.state);
	const pendingCommands = getPendingCommands(commandsData, logsData);
	let t5;
	if ($[11] !== agentInfo?.slug) {
		t5 = (isFeatureEnabled("copilot_mission_control_decoupled_mode") || isFeatureEnabled("copilot_mission_control_custom_agent_group")) && isCopilotCodingAgent(agentInfo?.slug);
		$[11] = agentInfo?.slug;
		$[12] = t5;
	} else t5 = $[12];
	const agentGroupingEnabled = t5;
	let t6;
	if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		$[13] = t6;
	} else t6 = $[13];
	const summaryOutsideLogsEnabled = t6;
	let t7;
	if ($[14] !== session) {
		t7 = summaryOutsideLogsEnabled && isCompletedSession(session) && MISSION_CONTROL_EVENT_TYPES.includes(session.event_type ?? "");
		$[14] = session;
		$[15] = t7;
	} else t7 = $[15];
	const shouldFilterFinalPlan = t7;
	let t8;
	if ($[16] !== agentGroupingEnabled || $[17] !== logsData || $[18] !== shouldFilterFinalPlan) {
		t8 = preprocessLogEntries(logsData, {
			preserveAssistantNarration: false,
			groupCustomAgentSessions: agentGroupingEnabled,
			filterFinalPlanMessage: shouldFilterFinalPlan
		});
		$[16] = agentGroupingEnabled;
		$[17] = logsData;
		$[18] = shouldFilterFinalPlan;
		$[19] = t8;
	} else t8 = $[19];
	const preprocessedLogEntries = t8;
	let t9;
	bb0: {
		if (chatMessageHistory.length === 0 || session.event_type !== "chat") {
			t9 = preprocessedLogEntries;
			break bb0;
		}
		let t10;
		if ($[20] !== chatMessageHistory || $[21] !== preprocessedLogEntries) {
			t10 = mergeLogsWithChatHistory(preprocessedLogEntries, chatMessageHistory);
			$[20] = chatMessageHistory;
			$[21] = preprocessedLogEntries;
			$[22] = t10;
		} else t10 = $[22];
		t9 = t10;
	}
	const logsToShow = t9;
	let t10;
	let t11;
	if ($[23] !== logsIsLoading || $[24] !== onLogsLoadingChange) {
		t10 = () => {
			onLogsLoadingChange?.(!!logsIsLoading);
		};
		t11 = [logsIsLoading, onLogsLoadingChange];
		$[23] = logsIsLoading;
		$[24] = onLogsLoadingChange;
		$[25] = t10;
		$[26] = t11;
	} else {
		t10 = $[25];
		t11 = $[26];
	}
	useEffect(t10, t11);
	const optimisticLogs = useOptimisticLogsOptional();
	const { pendingToolCallId } = usePendingPrompt(logsData);
	let t12;
	bb1: {
		if (!pendingToolCallId) {
			t12 = logsToShow;
			break bb1;
		}
		let t13;
		if ($[27] !== optimisticLogs || $[28] !== pendingToolCallId) {
			t13 = optimisticLogs?.getOptimisticResponseForToolCall(pendingToolCallId);
			$[27] = optimisticLogs;
			$[28] = pendingToolCallId;
			$[29] = t13;
		} else t13 = $[29];
		const hasOptimisticResponse = t13;
		let t14;
		if ($[30] !== hasOptimisticResponse || $[31] !== logsToShow || $[32] !== pendingToolCallId) {
			let t15;
			if ($[34] !== hasOptimisticResponse || $[35] !== pendingToolCallId) {
				t15 = (entry) => {
					if (isCustomAgentSessionGroup(entry)) return true;
					if (Array.isArray(entry)) return true;
					if (getPromptToolCallId(entry) === pendingToolCallId) {
						if (hasOptimisticResponse) return true;
						return false;
					}
					return true;
				};
				$[34] = hasOptimisticResponse;
				$[35] = pendingToolCallId;
				$[36] = t15;
			} else t15 = $[36];
			t14 = logsToShow.filter(t15);
			$[30] = hasOptimisticResponse;
			$[31] = logsToShow;
			$[32] = pendingToolCallId;
			$[33] = t14;
		} else t14 = $[33];
		t12 = t14;
	}
	const logsToShowFiltered = t12;
	let t13;
	let t14;
	if ($[37] !== logsToShowFiltered || $[38] !== setMcpToolNameMappings) {
		t13 = () => {
			const mappings = extractMcpToolNameMappings(logsToShowFiltered);
			if (Object.keys(mappings).length > 0) setMcpToolNameMappings((prevMappings) => ({
				...prevMappings,
				...mappings
			}));
		};
		t14 = [logsToShowFiltered, setMcpToolNameMappings];
		$[37] = logsToShowFiltered;
		$[38] = setMcpToolNameMappings;
		$[39] = t13;
		$[40] = t14;
	} else {
		t13 = $[39];
		t14 = $[40];
	}
	useEffect(t13, t14);
	if (session.state === "queued") return jsxs(Fragment$1, { children: [jsx(BootingUpMessage, { agentId: session.agent_id }), jsx(ChatCommands, { commands: pendingCommands })] });
	const workflowLink = session.workflow_run_id ? generateWorkflowRunLink(nwo ?? null, session.workflow_run_id) : void 0;
	const errorBannerPrimaryAction = workflowLink ? jsx(Banner$1.PrimaryAction, {
		as: "a",
		href: workflowLink,
		children: "View detailed logs"
	}) : void 0;
	const isEmptyCliSession = isCLISession(session) && !logsIsLoading && !showPollingError && logsData?.length === 0 && session.state === "in_progress";
	return jsxs(Fragment$1, { children: [
		logsIsLoading && !showPollingError && jsx(LoadingMessage$2, {
			message: "Loading…",
			agentId: session.agent_id
		}),
		isEmptyCliSession && pendingCommands.length > 0 && jsx(ChatCommands, { commands: pendingCommands }),
		isEmptyCliSession && pendingCommands.length === 0 && jsx(EmptyCliSession, {}),
		!logsIsLoading && !showPollingError && logsData?.length === 0 && session.state !== "in_progress" && jsx("div", { children: "No logs to display" }),
		!logsIsLoading && (logsData && logsData?.length > 0 || logsToShow?.length > 0) && jsxs(Fragment$1, { children: [jsx(GroupedSessionLogs, {
			preprocessedLogEntries: logsToShowFiltered,
			commandsData,
			logsData
		}), jsx(ChatCommands, { commands: pendingCommands })] }),
		showPollingError && jsx(Banner$1, {
			title: "Error",
			hideTitle: true,
			description: "There was an error loading the logs. Please try again later.",
			variant: "critical",
			primaryAction: errorBannerPrimaryAction
		}),
		session.state === "in_progress" && session.event_type !== "chat" && !logsIsLoading && !showPollingError && !isCLISession(session) && jsxs(Fragment$1, { children: [!isAgentInfoLoading && (logsData && logsData.length > 0 ? jsx(LoadingMessage$2, {
			message: `${agentInfo?.display_name ?? "Agent"} is working…`,
			agentId: session.agent_id
		}) : jsx(BootingUpMessage, { agentId: session.agent_id })), variant === "default" && currentUserOwnsSession && jsx(StickySteeringCommand, {
			onSubmit: handleSteeringCommandSubmit,
			error: steeringCommandError
		})] }),
		session.error?.message && !showPollingError && (session.state === "cancelled" ? jsx(SessionCancelledBanner, {
			cancellationMessage: session.error.message,
			workflowRunLink: workflowLink ?? null
		}) : jsx(SessionFailedBanner, {
			errorMessage: session.error.message,
			workflowRunLink: workflowLink ?? null
		}))
	] });
}
SessionLogs.displayName = "SessionLogs";
function LogEntryChoice(t0) {
	const $ = c$1(6);
	const { choice, isInGroup, isEditGroup, toolCallMetadata } = t0;
	const { mcpToolNameMappings } = useSessionContext();
	let t1;
	if ($[0] !== choice || $[1] !== isEditGroup || $[2] !== isInGroup || $[3] !== mcpToolNameMappings || $[4] !== toolCallMetadata) {
		t1 = renderLogEntryChoice(choice, mcpToolNameMappings, isInGroup, isEditGroup, toolCallMetadata);
		$[0] = choice;
		$[1] = isEditGroup;
		$[2] = isInGroup;
		$[3] = mcpToolNameMappings;
		$[4] = toolCallMetadata;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
LogEntryChoice.displayName = "LogEntryChoice";
function renderLogEntryChoice(choice, mcpToolNameMappings, isInGroup, isEditGroup, toolCallMetadata) {
	const tool = (choice.delta.tool_calls ?? [])[0];
	if (!tool && !choice.delta.content && choice.delta.reasoning_text) return /* @__PURE__ */ jsx(ReasoningText, { content: choice.delta.reasoning_text });
	if (!tool && choice.delta.content && choice.delta.role === ASSISTANT_ROLE) return /* @__PURE__ */ jsx(CopilotMessage, { content: choice.delta.content });
	const isCustomTool = !!tool?.custom;
	const toolName = tool?.function?.name ?? tool?.custom?.name;
	const rawArgs = isCustomTool ? tool?.custom?.input : tool?.function?.arguments;
	if (!tool || !tool.id || !toolName) return null;
	const parsedArgs = parseToolArgs(isCustomTool, rawArgs);
	const component = parsedArgs === null ? /* @__PURE__ */ jsx(Tool, {
		title: "Error parsing tool call arguments",
		isError: true,
		children: /* @__PURE__ */ jsx(ToolPrimaryContent, {
			language: "text",
			markdown: typeof rawArgs === "string" ? rawArgs : JSON.stringify(rawArgs ?? {}, null, 2)
		})
	}) : /* @__PURE__ */ jsx(ToolRenderer, {
		name: toolName,
		delta: choice.delta,
		args: parsedArgs,
		mcpToolNameMappings,
		isInGroup,
		isEditGroup,
		metadata: tool.id ? toolCallMetadata?.[tool.id] : void 0
	});
	if (choice.delta.reasoning_text) return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ReasoningText, { content: choice.delta.reasoning_text }), component] });
	return component;
}
function parseToolArgs(isCustomTool, rawArgs) {
	let parsedArgs = {};
	let hasParsingError = false;
	if (isCustomTool) parsedArgs = typeof rawArgs === "string" ? { content: rawArgs } : {};
	else if (typeof rawArgs === "string") {
		if (rawArgs.trim() !== "") try {
			parsedArgs = JSON.parse(rawArgs);
		} catch {
			try {
				parsedArgs = JSON.parse(rawArgs.replace(/\r?\n/g, "\\n"));
			} catch {
				hasParsingError = true;
			}
		}
	}
	return hasParsingError ? null : parsedArgs;
}
function CopilotMessage({ content }) {
	const strippedContent = stripPrMetadataTags(content);
	if (!strippedContent) return null;
	return /* @__PURE__ */ jsx("div", {
		className: SessionLogs_module_default.copilotMessage,
		children: /* @__PURE__ */ jsx("div", {
			className: SessionLogs_module_default.copilotMessageContent,
			children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: strippedContent })
		})
	});
}
CopilotMessage.displayName = "CopilotMessage";
function ReasoningText({ content }) {
	return /* @__PURE__ */ jsx("div", {
		className: SessionLogs_module_default.markdownWrapper,
		children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: content })
	});
}
/**
* Helper function to render session log entries with tool grouping.
* Builds a unified timeline where choices are flattened in place,
* allowing commands to appear in their chronological position while
* consecutive tool calls can still be grouped together.
*/
ReasoningText.displayName = "ReasoningText";
function GroupedSessionLogs(t0) {
	const $ = c$1(13);
	const { preprocessedLogEntries, commandsData, logsData } = t0;
	const { mcpToolNameMappings } = useSessionContext();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("session_logs_ungroup_reasoning_text");
		$[0] = t1;
	} else t1 = $[0];
	const shouldUngroupReasoningText = t1;
	let otherIndex = 0;
	let items;
	if ($[1] !== otherIndex || $[2] !== preprocessedLogEntries) {
		items = [];
		for (const entry of preprocessedLogEntries) {
			if (isCustomAgentSessionGroup(entry)) {
				items.push({
					type: "other",
					entry,
					index: otherIndex++
				});
				continue;
			}
			const toolCallMetadata = "tool_call_metadata" in entry ? entry.tool_call_metadata : void 0;
			if (isCompletionChunk(entry) && !isChatMessage(entry)) for (const [choiceIndex, choice] of entry.choices.entries()) if (shouldUngroupReasoningText && shouldSplitChoice(choice)) {
				const splitChoices = splitChoiceWithReasoningText(choice);
				for (const splitChoice of splitChoices) items.push({
					type: "choice",
					choice: splitChoice,
					entryId: entry.id,
					choiceIndex,
					toolCallMetadata
				});
			} else items.push({
				type: "choice",
				choice,
				entryId: entry.id,
				choiceIndex,
				toolCallMetadata
			});
			else items.push({
				type: "other",
				entry,
				index: otherIndex++
			});
		}
		$[1] = otherIndex;
		$[2] = preprocessedLogEntries;
		$[3] = items;
	} else items = $[3];
	const sessionLogItems = items;
	let t2;
	if ($[4] !== mcpToolNameMappings) {
		t2 = createGroupHeader(mcpToolNameMappings);
		$[4] = mcpToolNameMappings;
		$[5] = t2;
	} else t2 = $[5];
	const groupHeaderFn = t2;
	let t3;
	if ($[6] !== commandsData || $[7] !== logsData) {
		t3 = (item, groupContext) => {
			if (item.type === "other" && isCustomAgentSessionGroup(item.entry)) return jsx(CustomAgentSessionGroup, {
				customAgentSession: item.entry,
				children: jsx(GroupedSessionLogs, {
					preprocessedLogEntries: item.entry.logs,
					commandsData,
					logsData
				})
			});
			return jsx(GroupedLogEntryRenderer, {
				item,
				commandData: commandsData ?? [],
				isInGroup: groupContext?.isInGroup,
				isEditGroup: groupContext?.isEditGroup,
				logsData
			});
		};
		$[6] = commandsData;
		$[7] = logsData;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== groupHeaderFn || $[10] !== sessionLogItems || $[11] !== t3) {
		t4 = jsx(ToolGrouping, {
			entries: sessionLogItems,
			groupingFn: groupByConsecutiveToolName,
			groupHeaderFn,
			children: t3
		});
		$[9] = groupHeaderFn;
		$[10] = sessionLogItems;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
}
GroupedSessionLogs.displayName = "GroupedSessionLogs";
function LogChatMessage(t0) {
	const $ = c$1(8);
	const { logEntry, logsData } = t0;
	const { currentUser } = useCurrentUser$1();
	const isUser = logEntry.role === "user";
	const roleClassName = isUser ? SessionLogs_module_default.intentDetectionChatUserContainer : SessionLogs_module_default.intentDetectionChatAssistantContainer;
	const messageClassName = isUser ? SessionLogs_module_default.intentDetectionChatUserMessageContainer : SessionLogs_module_default.intentDetectionChatAssistantMessageContainer;
	const content = isUser ? logEntry.content : logEntry.choices?.[0]?.delta?.content ?? logEntry.content ?? "";
	let t1;
	if ($[0] !== content || $[1] !== currentUser?.primaryAvatarUrl || $[2] !== isUser || $[3] !== logEntry || $[4] !== logsData || $[5] !== messageClassName || $[6] !== roleClassName) {
		const messageIndex = logsData ? logsData.indexOf(logEntry) : 0;
		t1 = jsxs("div", {
			className: `${SessionLogs_module_default.intentDetectionChatContainer} ${roleClassName}`,
			children: [
				!isUser ? jsx(AgentAvatar, { animationType: CopilotAnimationType.Static }) : null,
				jsx("div", {
					className: `${SessionLogs_module_default.intentDetectionChatMessageContainer} ${messageClassName}`,
					children: isUser ? jsx("p", {
						className: SessionLogs_module_default.intentDetectionChatMessageText,
						children: content
					}) : jsx("div", {
						className: SessionLogs_module_default.intentDetectionChatMessageText,
						children: jsx(ChatMessageProvider, {
							message: {
								id: logEntry.id,
								role: logEntry.role,
								content: logEntry.content,
								createdAt: "",
								threadID: logEntry.threadID,
								references: []
							},
							children: jsx(MarkdownViewer, {
								markdown: content ?? "",
								messageId: logEntry.id,
								messageIndex,
								messageTimestamp: "",
								autoOpenPreviewPane: true
							})
						})
					})
				}),
				isUser ? jsx(GitHubAvatar, {
					src: currentUser?.primaryAvatarUrl || "",
					size: 24
				}) : null
			]
		});
		$[0] = content;
		$[1] = currentUser?.primaryAvatarUrl;
		$[2] = isUser;
		$[3] = logEntry;
		$[4] = logsData;
		$[5] = messageClassName;
		$[6] = roleClassName;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
/**
* Renders a single log entry in the grouped session logs view.
* Handles both individual choices (from flattened CompletionChunks) and other entries (commands).
*
* This is specifically for the grouped view where choices are flattened and can receive
* the `isInGroup` context from ToolGrouping.
*/
LogChatMessage.displayName = "LogChatMessage";
function GroupedLogEntryRenderer(t0) {
	const $ = c$1(18);
	const { item: entryWithContext, commandData, isInGroup, isEditGroup, logsData } = t0;
	const optimisticLogs = useOptimisticLogsOptional();
	if (entryWithContext.type === "choice") {
		let t1;
		if ($[0] !== entryWithContext.choice || $[1] !== entryWithContext.toolCallMetadata || $[2] !== isEditGroup || $[3] !== isInGroup) {
			t1 = jsx(LogEntryChoice, {
				choice: entryWithContext.choice,
				isInGroup,
				isEditGroup,
				toolCallMetadata: entryWithContext.toolCallMetadata
			});
			$[0] = entryWithContext.choice;
			$[1] = entryWithContext.toolCallMetadata;
			$[2] = isEditGroup;
			$[3] = isInGroup;
			$[4] = t1;
		} else t1 = $[4];
		return t1;
	}
	const { entry } = entryWithContext;
	if (isCustomAgentSessionGroup(entry)) return null;
	if (isToolUserRequestedMessage(entry)) {
		const prompt = entry;
		let t1;
		if ($[5] !== logsData || $[6] !== optimisticLogs || $[7] !== prompt) {
			const optimisticResponse = optimisticLogs?.getOptimisticResponseForToolCall(prompt.toolCallId);
			t1 = jsx(InteractivePromptLogEntry, {
				prompt,
				logsData,
				optimisticResponse
			});
			$[5] = logsData;
			$[6] = optimisticLogs;
			$[7] = prompt;
			$[8] = t1;
		} else t1 = $[8];
		return t1;
	}
	if (isCommandGroup(entry)) {
		let t1;
		if ($[9] !== commandData || $[10] !== entry) {
			t1 = jsx(LogCommands, {
				rawCommands: entry,
				commandData
			});
			$[9] = commandData;
			$[10] = entry;
			$[11] = t1;
		} else t1 = $[11];
		return t1;
	}
	if (isChatMessage(entry)) {
		let t1;
		if ($[12] !== entry || $[13] !== logsData) {
			t1 = jsx(LogChatMessage, {
				logEntry: entry,
				logsData
			});
			$[12] = entry;
			$[13] = logsData;
			$[14] = t1;
		} else t1 = $[14];
		return t1;
	}
	if (isCompletionUserMessage(entry)) {
		let t1;
		if ($[15] !== commandData || $[16] !== entry) {
			t1 = jsx(LogCommands, {
				rawCommands: [entry],
				commandData
			});
			$[15] = commandData;
			$[16] = entry;
			$[17] = t1;
		} else t1 = $[17];
		return t1;
	}
	return null;
}
GroupedLogEntryRenderer.displayName = "GroupedLogEntryRenderer";
var SessionHeader_module_default = {
	container: "SessionHeader-module_uoAzWq_container",
	containerStickyToChatInput: "SessionHeader-module_uoAzWq_containerStickyToChatInput",
	containerStickyToTop: "SessionHeader-module_uoAzWq_containerStickyToTop",
	containerWrapper: "SessionHeader-module_uoAzWq_containerWrapper",
	icon: "SessionHeader-module_uoAzWq_icon",
	mainContent: "SessionHeader-module_uoAzWq_mainContent",
	rightContent: "SessionHeader-module_uoAzWq_rightContent",
	sessionName: "SessionHeader-module_uoAzWq_sessionName",
	statusIcon: "SessionHeader-module_uoAzWq_statusIcon",
	toggleButton: "SessionHeader-module_uoAzWq_toggleButton"
};
function useStopSession(t0) {
	const $ = c$1(9);
	const { nwo, session } = t0;
	const t1 = session?.id;
	let t2;
	if ($[0] !== nwo || $[1] !== t1) {
		t2 = [
			"stopSession",
			nwo,
			t1
		];
		$[0] = nwo;
		$[1] = t1;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== nwo || $[4] !== session?.id) {
		t3 = async () => {
			return await fetchCAPI({
				path: `/agents/swe/jobs/${nwo}/session/${session?.id}/cancel`,
				method: "POST"
			});
		};
		$[3] = nwo;
		$[4] = session?.id;
		$[5] = t3;
	} else t3 = $[5];
	let t4;
	if ($[6] !== t2 || $[7] !== t3) {
		t4 = {
			mutationKey: t2,
			mutationFn: t3
		};
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
	} else t4 = $[8];
	return useMutation(t4);
}
function SessionStopButton(t0) {
	const $ = c$1(23);
	const { nwo, currentUserCanPush, variant: t1, onStoppingStateChange, loading: externalLoading } = t0;
	const variant = t1 === void 0 ? "button" : t1;
	const { session } = useSessionContext();
	const [isSessionStopped, setIsSessionStopped] = useState(false);
	const sessionStoppable = [
		SessionState.InProgress,
		SessionState.Idle,
		SessionState.WaitingForUser
	].includes(session.state) && !isSessionStopped;
	const { isChatSession } = useIntentDetection(session);
	let t2;
	if ($[0] !== nwo || $[1] !== session) {
		t2 = {
			nwo,
			session
		};
		$[0] = nwo;
		$[1] = session;
		$[2] = t2;
	} else t2 = $[2];
	const { isSuccess, isPending, mutate } = useStopSession(t2);
	let t3;
	let t4;
	if ($[3] !== isPending || $[4] !== isSuccess) {
		t3 = () => {
			if (isSuccess && !isPending) setIsSessionStopped(true);
		};
		t4 = [isSuccess, isPending];
		$[3] = isPending;
		$[4] = isSuccess;
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	useEffect(t3, t4);
	const stoppingSession = isPending;
	const buttonText = stoppingSession ? "Stopping session..." : "Stop session";
	let t5;
	if ($[7] !== mutate) {
		t5 = () => mutate();
		$[7] = mutate;
		$[8] = t5;
	} else t5 = $[8];
	const handleStopSession = t5;
	let t6;
	let t7;
	if ($[9] !== onStoppingStateChange || $[10] !== stoppingSession) {
		t6 = () => {
			onStoppingStateChange?.(stoppingSession);
		};
		t7 = [stoppingSession, onStoppingStateChange];
		$[9] = onStoppingStateChange;
		$[10] = stoppingSession;
		$[11] = t6;
		$[12] = t7;
	} else {
		t6 = $[11];
		t7 = $[12];
	}
	useEffect(t6, t7);
	const isLoading = externalLoading ?? stoppingSession;
	const iconButtonText = isLoading ? "" : "Stop";
	if (isChatSession) return null;
	if (variant === "icon-text-button") {
		let t8;
		if ($[13] !== handleStopSession || $[14] !== iconButtonText || $[15] !== isLoading || $[16] !== stoppingSession) {
			t8 = jsx(ButtonComponent$1, {
				leadingVisual: SquareCircleIcon,
				"aria-label": "Stop session",
				variant: "invisible",
				size: "small",
				onClick: handleStopSession,
				"aria-disabled": stoppingSession,
				loading: isLoading,
				children: iconButtonText
			});
			$[13] = handleStopSession;
			$[14] = iconButtonText;
			$[15] = isLoading;
			$[16] = stoppingSession;
			$[17] = t8;
		} else t8 = $[17];
		return t8;
	}
	if (!nwo || !currentUserCanPush || !sessionStoppable) return null;
	let t8;
	if ($[18] !== buttonText || $[19] !== handleStopSession || $[20] !== isLoading || $[21] !== stoppingSession) {
		t8 = jsx(ButtonComponent$1, {
			className: "mr-2",
			leadingVisual: SquareFillIcon,
			variant: "danger",
			onClick: handleStopSession,
			loading: isLoading,
			loadingAnnouncement: "Stopping session",
			"aria-disabled": stoppingSession,
			children: buttonText
		});
		$[18] = buttonText;
		$[19] = handleStopSession;
		$[20] = isLoading;
		$[21] = stoppingSession;
		$[22] = t8;
	} else t8 = $[22];
	return t8;
}
SessionStopButton.displayName = "SessionStopButton";
function calculateElapsedTime(createdAt, completedAt) {
	const created = new Date(createdAt).getTime();
	const nowOrCompleted = completedAt && completedAt !== "0001-01-01T00:00:00Z" ? new Date(completedAt).getTime() : Date.now();
	const diffInSeconds = Math.floor((nowOrCompleted - created) / 1e3);
	const days = Math.floor(diffInSeconds / (3600 * 24));
	const hours = Math.floor(diffInSeconds % (3600 * 24) / 3600);
	const minutes = Math.floor(diffInSeconds % 3600 / 60);
	const seconds = diffInSeconds % 60;
	const nonZeroIntervals = [
		{
			value: days,
			label: "d"
		},
		{
			value: hours,
			label: "h"
		},
		{
			value: minutes,
			label: "m"
		},
		{
			value: seconds,
			label: "s"
		}
	].filter((interval) => interval.value > 0);
	if (nonZeroIntervals.length === 0) return "0s";
	if (nonZeroIntervals.length === 1) return `${nonZeroIntervals[0]?.value ?? 0}${nonZeroIntervals[0]?.label ?? ""}`;
	return nonZeroIntervals[1] ? `${nonZeroIntervals[0]?.value}${nonZeroIntervals[0]?.label} ${nonZeroIntervals[1].value}${nonZeroIntervals[1].label ?? ""}` : `${nonZeroIntervals[0]?.value ?? 0}${nonZeroIntervals[0]?.label ?? ""}`;
}
function SessionElapsedTime(t0) {
	const $ = c$1(10);
	const { createdAt, completedAt, state } = t0;
	let t1;
	if ($[0] !== completedAt || $[1] !== createdAt) {
		t1 = () => calculateElapsedTime(createdAt, completedAt);
		$[0] = completedAt;
		$[1] = createdAt;
		$[2] = t1;
	} else t1 = $[2];
	const [elapsedTime, setElapsedTime] = useState(t1);
	let t2;
	let t3;
	if ($[3] !== completedAt || $[4] !== createdAt || $[5] !== state) {
		t2 = () => {
			setElapsedTime(calculateElapsedTime(createdAt, completedAt));
			if (state === SessionState.InProgress || state === SessionState.Queued) {
				const interval = setInterval(() => {
					setElapsedTime(calculateElapsedTime(createdAt, completedAt));
				}, 500);
				return () => clearInterval(interval);
			}
		};
		t3 = [
			createdAt,
			completedAt,
			state
		];
		$[3] = completedAt;
		$[4] = createdAt;
		$[5] = state;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	useEffect(t2, t3);
	let t4;
	if ($[8] !== elapsedTime) {
		t4 = jsx("time", {
			"aria-live": "off",
			className: "text-tabular-nums",
			children: elapsedTime
		});
		$[8] = elapsedTime;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
}
SessionElapsedTime.displayName = "SessionElapsedTime";
var getScrollParams = (container) => {
	if (!container) {
		const docEl = document.scrollingElement || document.documentElement;
		const currentTop = window.scrollY || window.pageYOffset;
		const targetTop = docEl.scrollHeight;
		return {
			element: null,
			targetTop,
			distance: Math.abs(targetTop - currentTop)
		};
	}
	return {
		element: container,
		targetTop: container.scrollHeight,
		distance: Math.abs(container.scrollHeight - container.scrollTop)
	};
};
function useScrollToBottom(t0) {
	const $ = c$1(6);
	const { containerRef, behavior: t1, smoothThreshold } = t0;
	const defaultBehavior = t1 === void 0 ? "auto" : t1;
	let t2;
	if ($[0] !== containerRef || $[1] !== defaultBehavior || $[2] !== smoothThreshold) {
		t2 = (options) => {
			const { distance, element, targetTop } = getScrollParams(containerRef?.current);
			const behavior = options?.behavior ?? defaultBehavior;
			const offset = options?.offset ?? 0;
			let actualBehavior = behavior;
			if (behavior === "auto" && smoothThreshold !== void 0) actualBehavior = distance >= smoothThreshold ? "smooth" : "auto";
			const adjustedTop = targetTop - offset;
			if (!element) window.scrollTo({
				top: adjustedTop,
				behavior: actualBehavior
			});
			else element.scrollTo({
				top: adjustedTop,
				behavior: actualBehavior
			});
		};
		$[0] = containerRef;
		$[1] = defaultBehavior;
		$[2] = smoothThreshold;
		$[3] = t2;
	} else t2 = $[3];
	const scrollToBottom = t2;
	let t3;
	if ($[4] !== scrollToBottom) {
		t3 = { scrollToBottom };
		$[4] = scrollToBottom;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
function SessionHeader({ nwo, currentUserCanPush, isCollapsed, onModifierClick, scrollContainerRef, hideStopButton = false, contentId, onOpenChange, sticky = true }) {
	const { session } = useSessionContext();
	const workflowLink = generateWorkflowRunLink(nwo ?? null, session.workflow_run_id);
	const { isChatSession, isUsingIntentDetection } = useIntentDetection(session);
	const isCLI = isCLISession(session);
	let sessionLink = generateTaskPath(session.resource_global_id, session.id);
	if (nwo) {
		const taskUrl = generateTaskPathForRepo({
			repositoryNwo: nwo,
			taskId: session.task_id,
			sessionId: session.id,
			isUsingIntentDetection
		});
		if (taskUrl) sessionLink = taskUrl;
	}
	const showMoreActionsMenu = !!(workflowLink || sessionLink);
	const ref = useRef(null);
	const isActive = isActiveSession(session);
	const isPending = isPendingSession(session);
	const isCompleted = isCompletedSession(session);
	const isCancelled = isCancelledSession(session);
	const isFailed = isFailedSession(session);
	const [isStoppingSession, setIsStoppingSession] = useState(false);
	const { scrollToBottom } = useScrollToBottom({
		containerRef: scrollContainerRef,
		behavior: "smooth"
	});
	const handleStoppingStateChange = (isStopping) => {
		if (isStopping) {
			setIsStoppingSession(true);
			sendEvent("agent_sessions.task_view", {
				target: "STOP_SESSION_BUTTON",
				session_id: session.id,
				task_id: session.resource_global_id
			});
		}
	};
	useEffect(() => {
		if (isCancelled && isStoppingSession) {
			const timer = setTimeout(() => setIsStoppingSession(false), 0);
			return () => clearTimeout(timer);
		}
	}, [isCancelled, isStoppingSession]);
	const { isLeaving } = useElementLeavingContainer({
		scrollContainerRef,
		elementRef: ref,
		enabled: isActive,
		offset: -8
	});
	const handleClick = (event) => {
		if ((event.altKey || event.metaKey) && onModifierClick) {
			event.preventDefault();
			event.stopPropagation();
			onModifierClick(!!isCollapsed);
			sendEvent("agent_sessions.task_view", {
				target: "SESSION_HEADER_MODIFIER",
				action: isCollapsed ? "EXPAND_ALL" : "COLLAPSE_ALL",
				session_id: session.id,
				task_id: session.resource_global_id
			});
			return false;
		} else {
			sendEvent("agent_sessions.task_view", {
				target: "SESSION_HEADER",
				action: isCollapsed ? "EXPAND" : "COLLAPSE",
				session_id: session.id,
				task_id: session.resource_global_id
			});
			if (isLeaving) {
				onOpenChange(true);
				setTimeout(() => {
					scrollToBottom();
				}, 50);
				return;
			}
		}
		onOpenChange(isCollapsed);
	};
	const handleLinkClick = (e) => {
		sendEvent("agent_sessions.task_view", {
			target: "CLICK_WORKFLOW_LOGS_LINK",
			session_id: session.id,
			task_id: session.resource_global_id
		});
		if (e.metaKey || e.ctrlKey) {
			e.stopPropagation();
			return;
		}
	};
	const handleCopyLink = useCallback(async (event_0) => {
		if (sessionLink) try {
			await copyText(window.location.origin + sessionLink);
			sendEvent("agent_sessions.task_view", {
				target: "COPY_SESSION_LINK",
				session_id: session.id,
				task_id: session.resource_global_id
			});
		} catch {
			event_0.preventDefault();
			event_0.stopPropagation();
		}
	}, [sessionLink, session]);
	const sessionName = useMemo(() => {
		if (isPending) return "New session";
		return session.name;
	}, [isPending, session.name]);
	const statusIcon = useMemo(() => {
		if (isStoppingSession || isCancelled) return /* @__PURE__ */ jsx(SkipIcon, { className: "fgColor-muted" });
		else if (isCompleted) return /* @__PURE__ */ jsx(CheckIcon, { className: "fgColor-success" });
		else if (isFailed) return /* @__PURE__ */ jsx(XCircleFillIcon, { className: "fgColor-danger" });
		return null;
	}, [
		isCompleted,
		isStoppingSession,
		isCancelled,
		isFailed
	]);
	const duration = useMemo(() => {
		if (isPending || isCLI) return null;
		if (isActive || isCompleted || isCancelled || isFailed) return /* @__PURE__ */ jsx(SessionElapsedTime, {
			createdAt: session.created_at,
			completedAt: session.completed_at,
			state: session.state
		});
		return null;
	}, [
		isPending,
		isActive,
		isCompleted,
		isCancelled,
		isFailed,
		isCLI,
		session.created_at,
		session.completed_at,
		session.state
	]);
	const shouldShowStopButton = useMemo(() => {
		if (hideStopButton || isCLI) return false;
		return isActive;
	}, [
		isActive,
		hideStopButton,
		isCLI
	]);
	if (isChatSession) return null;
	const content = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
		className: SessionHeader_module_default.mainContent,
		children: [/* @__PURE__ */ jsx("button", {
			onClick: handleClick,
			type: "button",
			className: SessionHeader_module_default.toggleButton,
			"aria-expanded": !isCollapsed,
			"aria-controls": contentId,
			"aria-labelledby": "session-header-title",
			children: /* @__PURE__ */ jsx(ChevronRightIcon, {
				className: SessionHeader_module_default.icon,
				"data-expanded": !isCollapsed
			})
		}), /* @__PURE__ */ jsx("span", {
			className: SessionHeader_module_default.sessionName,
			id: "session-header-title",
			children: sessionName
		})]
	}), /* @__PURE__ */ jsxs("div", {
		className: SessionHeader_module_default.rightContent,
		children: [
			(statusIcon || duration) && /* @__PURE__ */ jsxs("div", {
				className: "d-flex align-items-center gap-1 mr-2",
				children: [statusIcon && /* @__PURE__ */ jsx("span", {
					className: SessionHeader_module_default.statusIcon,
					children: statusIcon
				}), duration && /* @__PURE__ */ jsx("span", {
					className: "text-small text-medium text-tabular-nums",
					children: duration
				})]
			}),
			shouldShowStopButton && /* @__PURE__ */ jsx(SessionStopButton, {
				variant: "icon-text-button",
				nwo,
				currentUserCanPush,
				onStoppingStateChange: handleStoppingStateChange,
				loading: isStoppingSession
			}),
			showMoreActionsMenu && /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
				icon: KebabHorizontalIcon,
				"aria-label": "More actions",
				variant: "invisible"
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				align: "end",
				children: /* @__PURE__ */ jsxs(ActionList, { children: [workflowLink && /* @__PURE__ */ jsx(ActionList.LinkItem, {
					href: workflowLink,
					onClick: handleLinkClick,
					children: "View verbose logs"
				}), sessionLink && /* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: handleCopyLink,
					children: "Copy link"
				})] })
			})] })
		]
	})] });
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
		ref,
		className: clsx(SessionHeader_module_default.containerWrapper, { [SessionHeader_module_default.containerStickyToTop]: !isLeaving && sticky }),
		children: /* @__PURE__ */ jsx("div", {
			"data-active": isActive,
			"data-expanded": !isCollapsed,
			className: SessionHeader_module_default.container,
			children: content
		})
	}), isLeaving && /* @__PURE__ */ jsx("div", {
		className: clsx(SessionHeader_module_default.container, sticky && SessionHeader_module_default.containerStickyToChatInput),
		children: content
	})] });
}
SessionHeader.displayName = "SessionHeader";
function useElementLeavingContainer(options) {
	const $ = c$1(11);
	const { scrollContainerRef, elementRef, enabled, offset: t0 } = options;
	const offset = t0 === void 0 ? 0 : t0;
	const [isLeaving, setIsLeaving] = useState(false);
	const isLeavingRef = useRef(isLeaving);
	let t1;
	let t2;
	if ($[0] !== isLeaving) {
		t1 = () => {
			isLeavingRef.current = isLeaving;
		};
		t2 = [isLeaving];
		$[0] = isLeaving;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useEffect(t1, t2);
	let t3;
	let t4;
	if ($[3] !== elementRef || $[4] !== enabled || $[5] !== offset || $[6] !== scrollContainerRef) {
		t3 = () => {
			const container = scrollContainerRef.current;
			const element = elementRef.current;
			if (!enabled || !container || !element) return;
			const compute = () => {
				const containerRect = container.getBoundingClientRect();
				const isElementLeaving = element.getBoundingClientRect().bottom > containerRect.bottom + offset;
				if (isElementLeaving !== isLeavingRef.current) setIsLeaving(isElementLeaving);
			};
			compute();
			let animationFrameId = null;
			const throttledCompute = () => {
				if (animationFrameId == null) animationFrameId = window.requestAnimationFrame(() => {
					compute();
					animationFrameId = null;
				});
			};
			container.addEventListener("scroll", throttledCompute);
			return () => {
				setIsLeaving(false);
				container.removeEventListener("scroll", throttledCompute);
			};
		};
		t4 = [
			enabled,
			scrollContainerRef,
			elementRef,
			offset
		];
		$[3] = elementRef;
		$[4] = enabled;
		$[5] = offset;
		$[6] = scrollContainerRef;
		$[7] = t3;
		$[8] = t4;
	} else {
		t3 = $[7];
		t4 = $[8];
	}
	useEffect(t3, t4);
	let t5;
	if ($[9] !== isLeaving) {
		t5 = { isLeaving };
		$[9] = isLeaving;
		$[10] = t5;
	} else t5 = $[10];
	return t5;
}
function FeedbackDialog({ surveyDialogRef, feedbackDialogRef, initialRatingRef, ratingOptions, source, showSurvey, returnFocusRef, onClose, onSubmitted }) {
	const onSubmit = useCallback(async (rating, text) => {
		const errors = [];
		if (rating == null) errors.push("Please select a rating.");
		const limit = 2e3;
		if (text.length > limit) errors.push(`Please keep your feedback within ${limit} characters or less.`);
		if (errors.length > 0) return errors;
		const body = {
			subject: `mission-control:${source}`,
			rating,
			content: text,
			hostname: window.location.hostname,
			path: window.location.pathname,
			mode: "immersive"
		};
		try {
			if (!(await verifiedFetchJSON("/github-copilot/feedback", {
				method: "POST",
				body
			})).ok) errors.push("An error occurred while submitting your feedback.");
			else if (rating != null) onSubmitted?.(rating);
		} catch {
			errors.push("An error occurred while submitting your feedback.");
		}
		return errors;
	}, [source, onSubmitted]);
	const onSurveyClose = useCallback((reason) => {
		if (reason === "no-thanks") feedbackDialogRef.current?.openDialog(initialRatingRef.current);
		else {
			if (initialRatingRef.current != null) onSubmit(initialRatingRef.current, "");
			onClose?.("dismiss");
		}
	}, [
		feedbackDialogRef,
		initialRatingRef,
		onSubmit,
		onClose
	]);
	const onFeedbackClose = useCallback((reason_0) => {
		if (reason_0 === "dismiss" && initialRatingRef.current) onSubmit(initialRatingRef.current, "");
		onClose?.(reason_0);
	}, [
		initialRatingRef,
		onSubmit,
		onClose
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [showSurvey && /* @__PURE__ */ jsx(InterviewSurveyDialog, {
		ref: surveyDialogRef,
		onClose: onSurveyClose
	}), /* @__PURE__ */ jsx(UserFeedback, {
		ref: feedbackDialogRef,
		options: ratingOptions,
		onSubmit,
		onClose: onFeedbackClose,
		returnFocusRef
	})] });
}
FeedbackDialog.displayName = "FeedbackDialog";
function useFeedbackDialog$1(source, ratingOptions) {
	const $ = c$1(7);
	const surveyDialogRef = useRef(null);
	const feedbackDialogRef = useRef(null);
	const initialRatingRef = useRef(void 0);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("copilot_mission_control_interview_survey");
		$[0] = t0;
	} else t0 = $[0];
	const showSurvey = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (initialRatingValue) => {
			initialRatingRef.current = initialRatingValue;
			if (showSurvey) surveyDialogRef.current?.openDialog();
			else feedbackDialogRef.current?.openDialog(initialRatingValue);
		};
		$[1] = t1;
	} else t1 = $[1];
	const openFeedback = t1;
	let t2;
	if ($[2] !== ratingOptions || $[3] !== source) {
		t2 = (props) => jsx(FeedbackDialog, {
			surveyDialogRef,
			feedbackDialogRef,
			initialRatingRef,
			ratingOptions,
			source,
			showSurvey,
			...props
		});
		$[2] = ratingOptions;
		$[3] = source;
		$[4] = t2;
	} else t2 = $[4];
	const DialogComponent = t2;
	let t3;
	if ($[5] !== DialogComponent) {
		t3 = {
			openFeedback,
			FeedbackDialog: DialogComponent
		};
		$[5] = DialogComponent;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
var SessionFeedbackButtons_module_default = { container: "SessionFeedbackButtons-module_ZnC49a_container" };
var ratingOptions$1 = [{
	name: "Bad",
	value: "NEGATIVE",
	icon: thumbsDownIcon,
	color: "bad"
}, {
	name: "Good",
	value: "POSITIVE",
	icon: thumbsUpIcon,
	color: "good"
}];
function SessionFeedbackButtons() {
	const $ = c$1(12);
	const { session } = useSessionContext();
	const [submittedFeedback, setSubmittedFeedback] = useState(null);
	const [currentSessionId, setCurrentSessionId] = useState(session.id);
	let t0;
	let t1;
	if ($[0] !== currentSessionId || $[1] !== session.id) {
		t0 = () => {
			if (currentSessionId !== session.id) {
				setSubmittedFeedback(null);
				setCurrentSessionId(session.id);
			}
		};
		t1 = [session.id, currentSessionId];
		$[0] = currentSessionId;
		$[1] = session.id;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	const { openFeedback, FeedbackDialog } = useFeedbackDialog$1(`session-log:session_id=${session.id}`, ratingOptions$1);
	let t2;
	if ($[4] !== openFeedback) {
		t2 = (rating) => {
			setSubmittedFeedback(rating);
			openFeedback(rating);
		};
		$[4] = openFeedback;
		$[5] = t2;
	} else t2 = $[5];
	const onClick = t2;
	let t3;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = (rating_0) => setSubmittedFeedback(rating_0);
		$[6] = t3;
	} else t3 = $[6];
	const onFeedbackSubmitted = t3;
	let t4;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (reason) => {
			if (reason === "cancel") setSubmittedFeedback(null);
		};
		$[7] = t4;
	} else t4 = $[7];
	const onFeedbackDialogClose = t4;
	let t5;
	if ($[8] !== FeedbackDialog || $[9] !== onClick || $[10] !== submittedFeedback) {
		t5 = jsxs("div", {
			className: SessionFeedbackButtons_module_default.container,
			children: [submittedFeedback != null ? jsx(IconButton, {
				"aria-label": `${capitalize(submittedFeedback)} Feedback Submitted`,
				icon: submittedFeedback === "POSITIVE" ? ThumbsupIcon : ThumbsdownIcon,
				variant: "invisible",
				size: "small",
				inactive: true,
				"aria-disabled": true
			}) : jsxs(Fragment$1, { children: [jsx(IconButton, {
				icon: ThumbsupIcon,
				"aria-label": "Positive Feedback",
				onClick: () => onClick("POSITIVE"),
				variant: "invisible",
				size: "small"
			}), jsx(IconButton, {
				icon: ThumbsdownIcon,
				"aria-label": "Negative Feedback",
				onClick: () => onClick("NEGATIVE"),
				variant: "invisible",
				size: "small"
			})] }), jsx(FeedbackDialog, {
				onClose: onFeedbackDialogClose,
				onSubmitted: onFeedbackSubmitted
			})]
		});
		$[8] = FeedbackDialog;
		$[9] = onClick;
		$[10] = submittedFeedback;
		$[11] = t5;
	} else t5 = $[11];
	return t5;
}
SessionFeedbackButtons.displayName = "SessionFeedbackButtons";
var Session_module_default = {
	bottomFooter: "Session-module_HCKXkW_bottomFooter",
	chatContentContainer: "Session-module_HCKXkW_chatContentContainer",
	contentContainer: "Session-module_HCKXkW_contentContainer",
	detailsContainer: "Session-module_HCKXkW_detailsContainer",
	logsContainer: "Session-module_HCKXkW_logsContainer",
	permalinkedSession: "Session-module_HCKXkW_permalinkedSession"
};
var GLOBAL_TOGGLE_EVENT = "session-global-toggle";
function Session({ defaultOpen = false, onOpenChange, scrollContainerRef, hideStopButton = false, onToolExpand, shouldHighlight = false, stickyHeaders = true, currentUserCanPush, pull, logsPollingInterval, currentUser, nwo }) {
	const { session } = useSessionContext();
	const effectiveNwo = nwo ?? pull?.repository_nwo;
	const [isOpen, setIsOpen] = useState(defaultOpen);
	const [logsAreLoading, setLogsAreLoading] = useState(false);
	const sessionContainerRef = useRef(null);
	const toolInstanceRef = useRef({});
	const { isChatSession, isUsingIntentDetection } = useIntentDetection(session);
	const handlerRef = useRef((event) => {
		const customEvent = event;
		if (customEvent.detail.excludeInstance !== toolInstanceRef.current) {
			const shouldExpand = customEvent.detail.expand;
			setIsOpen(shouldExpand);
		}
	});
	useEffect(() => {
		const globalToggleHandler = (event_0) => {
			handlerRef.current?.(event_0);
		};
		document.addEventListener(GLOBAL_TOGGLE_EVENT, globalToggleHandler);
		return () => {
			document.removeEventListener(GLOBAL_TOGGLE_EVENT, globalToggleHandler);
		};
	}, []);
	const handleModifierClick = (expand) => {
		setIsOpen(expand);
		const event_1 = new CustomEvent(GLOBAL_TOGGLE_EVENT, { detail: {
			expand,
			excludeInstance: toolInstanceRef.current
		} });
		document.dispatchEvent(event_1);
	};
	const handleOpenChange = (open) => {
		setIsOpen(open);
		onOpenChange(open);
	};
	const isActive = isActiveSession(session);
	const isPending = isPendingSession(session);
	const contentId = `session-content-${session.id}`;
	useEffect(() => {
		if (!shouldHighlight) return;
		if (!sessionContainerRef.current) return;
		let frameId = 0;
		let secondFrameId = 0;
		frameId = requestAnimationFrame(() => {
			secondFrameId = requestAnimationFrame(() => {
				sessionContainerRef.current?.scrollIntoView({
					behavior: "smooth",
					block: "start"
				});
			});
		});
		return () => {
			cancelAnimationFrame(frameId);
			cancelAnimationFrame(secondFrameId);
		};
	}, [shouldHighlight]);
	if (isPending && isUsingIntentDetection) return /* @__PURE__ */ jsxs(Stack, {
		direction: "horizontal",
		padding: "none",
		align: "center",
		justify: "start",
		gap: "condensed",
		children: [/* @__PURE__ */ jsx(AgentAvatar, {
			animationType: CopilotAnimationType.Thinking,
			loopAnimation: true
		}), /* @__PURE__ */ jsx(WithShimmerEffect, {
			className: "color-fg-muted",
			children: "Planning response..."
		})]
	});
	const containerClassNames = isChatSession ? `${Session_module_default.contentContainer} ${Session_module_default.chatContentContainer}` : Session_module_default.contentContainer;
	return /* @__PURE__ */ jsxs("div", {
		ref: sessionContainerRef,
		className: clsx(Session_module_default.detailsContainer, { [Session_module_default.permalinkedSession]: shouldHighlight }),
		"data-active": isActive,
		"data-session-id": session.id,
		children: [/* @__PURE__ */ jsx(SessionHeader, {
			nwo: effectiveNwo,
			currentUserCanPush: !!currentUserCanPush,
			isCollapsed: !isOpen,
			onModifierClick: handleModifierClick,
			scrollContainerRef,
			hideStopButton,
			contentId,
			onOpenChange: handleOpenChange,
			sticky: stickyHeaders
		}), /* @__PURE__ */ jsxs("div", {
			id: contentId,
			className: containerClassNames,
			"data-expanded": isOpen || isChatSession,
			children: [/* @__PURE__ */ jsx("div", {
				className: Session_module_default.logsContainer,
				children: /* @__PURE__ */ jsx(SessionLogsProvider, {
					variant: "mission-control",
					onToolExpand,
					session,
					sessionNwo: effectiveNwo,
					children: /* @__PURE__ */ jsx(SessionLogs, {
						logsPollingInterval: logsPollingInterval ?? 3e3,
						nwo: effectiveNwo,
						currentUser,
						batchCompletedSessions: true,
						onLogsLoadingChange: setLogsAreLoading
					})
				})
			}), (session.state === SessionState.Completed || session.state === SessionState.InProgress) && session.premium_requests > 0 && !logsAreLoading && /* @__PURE__ */ jsxs("div", {
				className: Session_module_default.bottomFooter,
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("span", {
					className: "text-semibold",
					children: [session.premium_requests, " "]
				}), /* @__PURE__ */ jsxs("span", {
					className: "fgColor-muted",
					children: ["premium ", (0, import_pluralize.default)("request", session.premium_requests)]
				})] }), !isActiveSession(session) && !logsAreLoading && /* @__PURE__ */ jsx(SessionFeedbackButtons, {})]
			})]
		})]
	});
}
Session.displayName = "Session";
var TaskChat_module_default = {
	blankSlateContainer: "TaskChat-module_h9VVYG_blankSlateContainer",
	chatInputContainer: "TaskChat-module_h9VVYG_chatInputContainer",
	container: "TaskChat-module_h9VVYG_container",
	content: "TaskChat-module_h9VVYG_content",
	diffOverlayWrapper: "TaskChat-module_h9VVYG_diffOverlayWrapper",
	initialMessages: "TaskChat-module_h9VVYG_initialMessages",
	readonlyMessageContainer: "TaskChat-module_h9VVYG_readonlyMessageContainer",
	repoAgentsViewChatInput: "TaskChat-module_h9VVYG_repoAgentsViewChatInput",
	repoAgentsViewContent: "TaskChat-module_h9VVYG_repoAgentsViewContent",
	root: "TaskChat-module_h9VVYG_root",
	scrollContainer: "TaskChat-module_h9VVYG_scrollContainer",
	scrollToBottomButton: "TaskChat-module_h9VVYG_scrollToBottomButton",
	sidePanelContent: "TaskChat-module_h9VVYG_sidePanelContent",
	stickableContainer: "TaskChat-module_h9VVYG_stickableContainer",
	stickableContainerFrozen: "TaskChat-module_h9VVYG_stickableContainerFrozen",
	suspenseSpinner: "TaskChat-module_h9VVYG_suspenseSpinner",
	taskChatDuringCreationContainer: "TaskChat-module_h9VVYG_taskChatDuringCreationContainer"
};
function useAgentMentions({ pull, sessions = [], initialData = [], agentId }) {
	const { data: agentInfo } = useAgentInfo(agentId);
	const agentDisplayName = agentInfo?.display_name.toLowerCase() || "copilot";
	const { data: validAgentNames = [] } = useTopLevelAgents(pull?.repository_nwo);
	const params = buildRequestParams(sessions);
	const fetchMentionsQuery = useQuery({
		queryKey: [
			"agent-mentions",
			pull?.id,
			params
		],
		queryFn: async () => {
			if (!pull?.id) return [];
			const response = await fetch(`/copilot/agent-sessions/pull-requests/${pull.id}/agent-mentions?${params}`, { headers: {
				Accept: "application/json",
				"X-Requested-With": "XMLHttpRequest"
			} });
			if (!response.ok) throw new Error("Failed to fetch pull request comments");
			return (await response.json()).agent_mentions;
		},
		enabled: sessions.length > 0 && !!pull?.id,
		initialData,
		placeholderData: (previousData) => previousData
	});
	const createMentionMutation = useMutation({ mutationFn: async (text) => {
		if (!pull) throw new Error("Cannot create mention without a pull request");
		const mentionPrefix = !(agentDisplayName === "copilot") ? `@${agentDisplayName}[agent]` : `@${agentDisplayName}`;
		const agentMentionWithSuffixMatch = text.match(/^@([\w-]+)\[agent\](?:\s|$)/i);
		const agentMentionWithoutSuffixMatch = text.match(/^@([\w-]+)(?:\s|$)/i);
		const startsWithCopilot = /^@copilot(?:\s|$)/i;
		const isValidAgentName = (name) => validAgentNames.some((agent) => agent.display_name.toLowerCase() === name.toLowerCase());
		if (!(agentMentionWithSuffixMatch?.[1] && isValidAgentName(agentMentionWithSuffixMatch[1]) || startsWithCopilot.test(text))) if (agentMentionWithoutSuffixMatch?.[1] && isValidAgentName(agentMentionWithoutSuffixMatch[1])) {
			const agentName = agentMentionWithoutSuffixMatch[1];
			text = text.replace(new RegExp(`^@${agentName}`, "i"), `@${agentName}[agent]`);
		} else text = `${mentionPrefix} ${text.trim()}`;
		const result = await reactFetchJSON(`/${pull.repository_nwo}/pull/${pull.number}/page_data/create_timeline_comment`, {
			method: "POST",
			headers: { Accept: "application/json" },
			body: { text }
		});
		const json = await result.json();
		if (!result.ok) throw new Error("Failed to submit comment");
		sendEvent("agent_sessions.task_view", {
			target: "CREATE_COMMAND_POST_SESSION",
			pull_id: pull.id,
			pull_number: pull.number
		});
		return json;
	} });
	const createMention = async (text_0, callbacks) => {
		try {
			const result_0 = await createMentionMutation.mutateAsync(text_0);
			callbacks?.onSuccess?.(result_0);
			return result_0;
		} catch (error) {
			callbacks?.onError?.();
			throw error;
		}
	};
	return {
		...fetchMentionsQuery,
		createMention
	};
}
function buildRequestParams(sessions) {
	const pull_request_comment_ids = sessions.filter((session) => session.event_type === "pull_request_comment" || session.event_type === "pull_request_comment_non_copilot_pull_request").map((session) => session.event_identifiers).flat().sort();
	const pull_request_review_ids = sessions.filter((session) => session.event_type === "pull_request_review" || session.event_type === "pull_request_review_non_copilot_pull_request").map((session) => session.event_identifiers).flat().sort();
	const params = new URLSearchParams();
	for (const id of pull_request_comment_ids) if (id != null) params.append("pull_request_comment_ids[]", id.toString());
	for (const id of pull_request_review_ids) if (id != null) params.append("pull_request_review_ids[]", id.toString());
	return params.toString();
}
var TaskChatInput_module_default = {
	blockedContent: "TaskChatInput-module_x5qOKq_blockedContent",
	blockedIcon: "TaskChatInput-module_x5qOKq_blockedIcon",
	blockedOverlay: "TaskChatInput-module_x5qOKq_blockedOverlay",
	extraToolbarText: "TaskChatInput-module_x5qOKq_extraToolbarText",
	formControl: "TaskChatInput-module_x5qOKq_formControl",
	inputWrapper: "TaskChatInput-module_x5qOKq_inputWrapper"
};
/**
* Hook for creating session commands and immediately showing them in the UI before server confirmation.
*/
function useCreateCommand(options) {
	const $ = c$1(16);
	const queryClient = useQueryClient();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["createCommand"];
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== queryClient) {
		t1 = async (params) => {
			const { sessionId, content, type, optimisticId } = params;
			const queryKey = ["agent-session-commands", sessionId];
			await queryClient.cancelQueries({ queryKey });
			const currentData = queryClient.getQueryData(queryKey);
			const optimisticCommand = {
				id: optimisticId,
				external_id: null,
				user_id: -1,
				session_id: sessionId,
				content,
				created_at: (/* @__PURE__ */ new Date()).toISOString(),
				updated_at: (/* @__PURE__ */ new Date()).toISOString(),
				state: "queued",
				type: type ?? "user_message",
				error: null
			};
			const updatedData = { commands: [...currentData?.commands ?? [], optimisticCommand] };
			queryClient.setQueryData(queryKey, updatedData);
			return {
				queryKey,
				optimisticId
			};
		};
		$[1] = queryClient;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	let t3;
	if ($[3] !== options || $[4] !== queryClient) {
		t2 = (error, variables, context) => {
			if (!context?.queryKey || !context?.optimisticId) {
				options?.onError?.(error);
				return;
			}
			queryClient.setQueryData(context.queryKey, (currentData_0) => {
				if (!currentData_0) return currentData_0;
				return { commands: currentData_0.commands.filter((cmd) => cmd.id !== context.optimisticId) };
			});
			options?.onError?.(error);
		};
		t3 = (data, variables_0, context_0) => {
			if (!context_0?.queryKey) return;
			queryClient.setQueryData(context_0.queryKey, (currentData_1) => {
				if (!currentData_1) return currentData_1;
				return { commands: currentData_1.commands.map((cmd_0) => cmd_0.id === context_0.optimisticId ? {
					...data,
					content: data.content ?? cmd_0.content
				} : cmd_0) };
			});
			queryClient.invalidateQueries({ queryKey: context_0.queryKey });
			options?.onSuccess?.();
		};
		$[3] = options;
		$[4] = queryClient;
		$[5] = t2;
		$[6] = t3;
	} else {
		t2 = $[5];
		t3 = $[6];
	}
	let t4;
	if ($[7] !== t1 || $[8] !== t2 || $[9] !== t3) {
		t4 = {
			mutationKey: t0,
			onMutate: t1,
			mutationFn: _temp$18,
			onError: t2,
			onSuccess: t3
		};
		$[7] = t1;
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	const createCommandMutation = useMutation(t4);
	let t5;
	if ($[11] !== createCommandMutation) {
		t5 = (params_1) => {
			const optimisticId_0 = `optimistic-${uuid()}`;
			createCommandMutation.mutate({
				...params_1,
				optimisticId: optimisticId_0
			});
		};
		$[11] = createCommandMutation;
		$[12] = t5;
	} else t5 = $[12];
	const createCommand = t5;
	let t6;
	if ($[13] !== createCommand || $[14] !== createCommandMutation.isPending) {
		t6 = {
			createCommand,
			isPending: createCommandMutation.isPending
		};
		$[13] = createCommand;
		$[14] = createCommandMutation.isPending;
		$[15] = t6;
	} else t6 = $[15];
	return t6;
}
async function _temp$18(params_0) {
	const { sessionId: sessionId_0, content: content_0, type: type_0 } = params_0;
	const response = await fetchCAPI({
		path: `/agents/sessions/${sessionId_0}/commands`,
		method: "POST",
		body: {
			content: content_0,
			type: type_0 ?? "user_message"
		}
	});
	if (!response.ok) throw new Error("Failed to submit command");
	const command = await response.json();
	if (!command.state) command.state = "queued";
	return command;
}
function TaskChatInput({ taskAgentId, activeSession, onAddPendingSession, onClearPendingSession, payload, scrollToBottom, inputRef, chatInputRef }) {
	const { pull, steeringEnabled, currentUserCanPush } = payload;
	const [failedToSubmit, setFailedToSubmit] = useState(false);
	const { data: agentInfo, isLoading: isAgentInfoLoading } = useAgentInfo(taskAgentId);
	const { data: topLevelAgents, isLoading: isLoadingTopLevelAgents } = useTopLevelAgents(pull?.repository_nwo);
	const agentNotEnabled = taskAgentId && !isLoadingTopLevelAgents && topLevelAgents && topLevelAgents.length > 0 && !topLevelAgents.some((agent) => Number(agent.id) === taskAgentId);
	const name = agentInfo?.display_name?.toLowerCase() || "agent";
	const isAgentCopilot = isAgentInfoLoading || name === "copilot";
	const steerable = !!activeSession && isAgentCopilot;
	const startingSession = activeSession && isPendingSession(activeSession);
	const activeSessionOwner = payload.sessionOwners.find((owner) => owner.id === activeSession?.user_id) || null;
	const { currentUserIsSessionOwner } = useCurrentUser$1();
	useEffect(() => {
		const inputElement = inputRef.current;
		if (!inputElement) return;
		let timeout;
		const handleInput = () => {
			if (failedToSubmit) timeout = setTimeout(() => {
				setFailedToSubmit(false);
			}, 0);
		};
		inputElement.addEventListener("input", handleInput);
		return () => {
			inputElement.removeEventListener("input", handleInput);
			if (timeout) clearTimeout(timeout);
		};
	}, [failedToSubmit, inputRef]);
	const { createMention } = useAgentMentions({
		pull,
		agentId: taskAgentId
	});
	const { createCommand } = useCreateCommand({ onError: () => {
		setFailedToSubmit(true);
	} });
	const handleActiveSessionCommandSubmit = (message) => {
		if (!steerable || !activeSession) return;
		createCommand({
			sessionId: activeSession.id,
			content: message
		});
	};
	const handleSubmit = async (text) => {
		setFailedToSubmit(false);
		try {
			if (steerable) {
				handleActiveSessionCommandSubmit(text);
				scrollToBottom();
				return;
			}
			onAddPendingSession(text, { agentId: taskAgentId });
			await createMention(text, { onError: () => {
				onClearPendingSession();
			} });
			scrollToBottom();
		} catch {
			setFailedToSubmit(true);
			throw new ChatInputValidationError(text);
		}
	};
	const getBlockedText = () => {
		if (agentNotEnabled) return "Your organization has removed access for this agent. Contact your administrator for more information.";
		if (activeSession && !isAgentCopilot) return `Wait until the session is complete before steering ${agentInfo?.display_name || "agent"} sessions`;
		if (!steeringEnabled) return "Steering Copilot requires an active subscription";
		if (!currentUserCanPush) return "You do not have write permission on the repository";
		if (pull?.state && pull.state !== "open") return `Pull request is ${pull.state}`;
		if (!currentUserIsSessionOwner) {
			if (steerable) return `Only ${activeSessionOwner?.login ?? "the session owner"} can steer this session`;
			if (pull?.url) return /* @__PURE__ */ jsxs(Fragment$1, { children: [
				"Only the author of the task can ask for changes.",
				" ",
				/* @__PURE__ */ jsx(Link, {
					href: pull.url,
					inline: true,
					children: "View pull request"
				}),
				" ",
				"to request more changes."
			] });
			return "Only the author of the task can ask for changes.";
		}
	};
	const placeHolderText = startingSession ? "Waiting for agent to start session..." : steerable ? "Steer active session while agent is working" : "What would you like to do next?";
	const blockedText = getBlockedText();
	const isBlocked = !!blockedText;
	const shouldShowHelpText = !isBlocked && !steerable && !startingSession;
	const helpTextId = "task-chat-input-help";
	useEffect(() => {
		const inputElement_0 = inputRef.current;
		if (!inputElement_0) return;
		if (shouldShowHelpText) inputElement_0.setAttribute("aria-describedby", helpTextId);
		else inputElement_0.removeAttribute("aria-describedby");
	}, [
		helpTextId,
		shouldShowHelpText,
		inputRef
	]);
	return /* @__PURE__ */ jsxs(FormControl$1, {
		className: TaskChatInput_module_default.formControl,
		children: [
			/* @__PURE__ */ jsx(FormControl$1.Label, {
				visuallyHidden: true,
				children: "New prompt"
			}),
			/* @__PURE__ */ jsxs("div", {
				className: TaskChatInput_module_default.inputWrapper,
				children: [/* @__PURE__ */ jsx(ChatInput, {
					onSubmit: handleSubmit,
					textAreaRef: inputRef,
					chatInputRef,
					modes: [{
						name: ModeSupportName.Agent,
						supportsAttachments: false,
						supportsAutocompletion: false,
						supportsSpaces: false,
						supportsReferenceAttachments: false,
						icon: AgentIcon,
						placeholder: placeHolderText,
						submitLabel: startingSession ? "Wait for the session to be started" : void 0
					}],
					size: "large",
					isStreaming: false,
					disabled: isBlocked,
					submitDisabled: startingSession || isBlocked,
					isNewConversation: false,
					extraToolbar: shouldShowHelpText ? /* @__PURE__ */ jsx("p", {
						id: helpTextId,
						className: TaskChatInput_module_default.extraToolbarText,
						children: "Submitting will post a pull request comment"
					}) : null
				}), isBlocked && /* @__PURE__ */ jsx("div", {
					className: TaskChatInput_module_default.blockedOverlay,
					children: /* @__PURE__ */ jsxs("div", {
						className: TaskChatInput_module_default.blockedContent,
						children: [/* @__PURE__ */ jsx(LockIcon, {
							size: 16,
							className: TaskChatInput_module_default.blockedIcon
						}), /* @__PURE__ */ jsx("p", {
							className: "mb-0",
							children: blockedText
						})]
					})
				})]
			}),
			failedToSubmit && !isBlocked && /* @__PURE__ */ jsx(FormControl$1.Validation, {
				variant: "error",
				className: "pt-2",
				children: "Failed to submit latest message"
			})
		]
	});
}
TaskChatInput.displayName = "TaskChatInput";
function useSessionOwners(t0) {
	const $ = c$1(11);
	const { sessions, initialData } = t0;
	let t1;
	if ($[0] !== sessions) {
		t1 = sessions || [];
		$[0] = sessions;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t1) {
		t2 = getSortedUserIds(t1);
		$[2] = t1;
		$[3] = t2;
	} else t2 = $[3];
	const userIds = t2;
	let t3;
	let t4;
	if ($[4] !== userIds) {
		t3 = ["agent-sessions-users", userIds];
		t4 = async () => {
			const response = await fetch(`/copilot/agent-sessions/users?user_ids=${encodeURIComponent(userIds)}`, { headers: {
				Accept: "application/json",
				"X-Requested-With": "XMLHttpRequest"
			} });
			if (!response.ok) throw new Error("Failed to fetch session owners");
			return (await response.json()).users;
		};
		$[4] = userIds;
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	let t5;
	if ($[7] !== initialData || $[8] !== t3 || $[9] !== t4) {
		t5 = {
			queryKey: t3,
			queryFn: t4,
			initialData
		};
		$[7] = initialData;
		$[8] = t3;
		$[9] = t4;
		$[10] = t5;
	} else t5 = $[10];
	return useQuery(t5);
}
function getSortedUserIds(sessions) {
	const userIdSet = /* @__PURE__ */ new Set();
	for (const session of sessions) userIdSet.add(session.user_id);
	return Array.from(userIdSet).sort((a, b) => a - b).join(",");
}
var UserMessage_module_default = {
	avatarContainer: "UserMessage-module_m9QL9a_avatarContainer",
	container: "UserMessage-module_m9QL9a_container",
	messageContainer: "UserMessage-module_m9QL9a_messageContainer",
	messageMeta: "UserMessage-module_m9QL9a_messageMeta",
	messageText: "UserMessage-module_m9QL9a_messageText",
	truncatedPath: "UserMessage-module_m9QL9a_truncatedPath"
};
var MessageTextWithHovercards = ({ body, agentInfo }) => {
	const parts = parseBodyWithMentions(body, agentInfo);
	if (parts.length === 0) return /* @__PURE__ */ jsx(ExpandableMarkdown, {
		className: UserMessage_module_default.messageText,
		markdown: body
	});
	return /* @__PURE__ */ jsx("div", {
		className: UserMessage_module_default.messageText,
		children: parts.map(({ key, element }) => /* @__PURE__ */ jsx("span", { children: element }, key))
	});
};
MessageTextWithHovercards.displayName = "MessageTextWithHovercards";
function parseBodyWithMentions(body, agentInfo) {
	const parts = [];
	const mentionRegex = new RegExp(AGENT_MENTION_REGEX.source, AGENT_MENTION_REGEX.flags);
	let lastIndex = 0;
	let match;
	while ((match = mentionRegex.exec(body)) !== null) {
		addTextPart(parts, body, lastIndex, match.index);
		const mentionText = match[0];
		addMentionPart(parts, mentionText, match.index, agentInfo);
		lastIndex = match.index + mentionText.length;
	}
	addTextPart(parts, body, lastIndex, body.length);
	return parts;
}
function addTextPart(parts, body, startIndex, endIndex) {
	if (endIndex > startIndex) {
		const textContent = body.slice(startIndex, endIndex);
		parts.push({
			key: `text-${startIndex}`,
			element: /* @__PURE__ */ jsx(ExpandableMarkdown, { markdown: textContent })
		});
	}
}
function addMentionPart(parts, mentionText, index, agentInfo) {
	const mentionElement = /* @__PURE__ */ jsx(MentionElement, {
		mentionText,
		agentInfo
	});
	parts.push({
		key: `link-${index}`,
		element: mentionElement
	});
}
function MentionElement(t0) {
	const $ = c$1(11);
	const { mentionText, agentInfo } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const mentionMatch = matchAgentMention(mentionText, agentInfo);
	if (mentionMatch.isCurrentAgent) {
		if (mentionMatch.type === "copilot") {
			let t1;
			if ($[0] !== getHovercardAttributesForType || $[1] !== mentionText) {
				t1 = jsx("a", {
					href: "https://gh.io/copilot-coding-agent-docs",
					...getHovercardAttributesForType("copilot", { url: "/copilot/hovercard?bot=copilot-swe-agent" }),
					children: mentionText
				});
				$[0] = getHovercardAttributesForType;
				$[1] = mentionText;
				$[2] = t1;
			} else t1 = $[2];
			return t1;
		}
		if (mentionMatch.type === "agent") {
			let t1;
			if ($[3] !== agentInfo.display_name || $[4] !== agentInfo.doc_url || $[5] !== agentInfo.slug || $[6] !== getHovercardAttributesForType || $[7] !== mentionText) {
				t1 = jsx("a", {
					href: agentInfo.doc_url,
					...getHovercardAttributesForType("copilot", { url: `/copilot/hovercard?bot=${agentInfo.slug}` }),
					"aria-label": `Information about the ${agentInfo.display_name} agent`,
					children: mentionText
				});
				$[3] = agentInfo.display_name;
				$[4] = agentInfo.doc_url;
				$[5] = agentInfo.slug;
				$[6] = getHovercardAttributesForType;
				$[7] = mentionText;
				$[8] = t1;
			} else t1 = $[8];
			return t1;
		}
	}
	let t1;
	if ($[9] !== mentionText) {
		t1 = jsx(ExpandableMarkdown, { markdown: mentionText });
		$[9] = mentionText;
		$[10] = t1;
	} else t1 = $[10];
	return t1;
}
MentionElement.displayName = "MentionElement";
/**
* UserMention component displays a message triggered by a user comment or review.
* TODO: adopt shared components like UserMessageLayout
*/
var UserMessage = (t0) => {
	const $ = c$1(10);
	const { mention, isLoading: t1, agentId } = t0;
	const isLoading = t1 === void 0 ? false : t1;
	const { data: agentInfo } = useAgentInfo(agentId);
	const { currentUser } = useCurrentUser$1();
	if (!mention) {
		let t2;
		if ($[0] !== isLoading) {
			t2 = isLoading ? jsx(LoadingMessage$1, {}) : jsx(ErrorMessage$1, {});
			$[0] = isLoading;
			$[1] = t2;
		} else t2 = $[1];
		return t2;
	}
	let t2;
	if ($[2] !== currentUser || $[3] !== mention.author.display_login || $[4] !== mention.author.id) {
		t2 = () => {
			if (currentUser && mention.author.id === currentUser.id) return "You";
			return mention.author.display_login;
		};
		$[2] = currentUser;
		$[3] = mention.author.display_login;
		$[4] = mention.author.id;
		$[5] = t2;
	} else t2 = $[5];
	const getAuthorDisplayLogin = t2;
	let t3;
	if ($[6] !== agentInfo || $[7] !== getAuthorDisplayLogin || $[8] !== mention) {
		t3 = jsxs("div", {
			className: UserMessage_module_default.container,
			children: [jsx(MessageContent, {
				mention,
				agentInfo: agentInfo ?? void 0,
				authorDisplayLogin: getAuthorDisplayLogin()
			}), jsx("div", {
				className: UserMessage_module_default.avatarContainer,
				children: jsx(GitHubAvatar, {
					src: mention.author.avatar_url,
					size: 24
				})
			})]
		});
		$[6] = agentInfo;
		$[7] = getAuthorDisplayLogin;
		$[8] = mention;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
};
UserMessage.displayName = "UserMessage";
var ErrorMessage$1 = () => /* @__PURE__ */ jsx("div", {
	className: UserMessage_module_default.container,
	children: /* @__PURE__ */ jsx("div", {
		className: UserMessage_module_default.messageContainer,
		children: /* @__PURE__ */ jsx("p", {
			className: UserMessage_module_default.messageText,
			children: "Failed to fetch triggering comment"
		})
	})
});
ErrorMessage$1.displayName = "ErrorMessage";
var LoadingMessage$1 = () => /* @__PURE__ */ jsxs("div", {
	className: UserMessage_module_default.container,
	children: [/* @__PURE__ */ jsxs("div", {
		className: UserMessage_module_default.messageContainer,
		children: [/* @__PURE__ */ jsx("span", {
			className: UserMessage_module_default.messageMeta,
			children: /* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "sm",
				width: "80px"
			})
		}), /* @__PURE__ */ jsx("div", {
			className: UserMessage_module_default.messageText,
			children: /* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "sm",
				width: "random"
			})
		})]
	}), /* @__PURE__ */ jsx("div", {
		className: UserMessage_module_default.avatarContainer,
		children: /* @__PURE__ */ jsx(LoadingSkeleton, {
			variant: "elliptical",
			height: "24px",
			width: "24px"
		})
	})]
});
LoadingMessage$1.displayName = "LoadingMessage";
var MessageContent = ({ mention, agentInfo, authorDisplayLogin }) => {
	const hasBody = !!mention.body;
	return /* @__PURE__ */ jsxs("div", {
		className: UserMessage_module_default.messageContainer,
		children: [
			hasBody && /* @__PURE__ */ jsx(MessageMeta, {
				mention,
				authorDisplayLogin
			}),
			/* @__PURE__ */ jsx(MessageText, {
				mention,
				agentInfo,
				authorDisplayLogin
			}),
			mention.type === "review" && /* @__PURE__ */ jsx(ReviewCommentText, { mention })
		]
	});
};
MessageContent.displayName = "MessageContent";
var MessageMeta = ({ mention, authorDisplayLogin }) => {
	const { type, url, path, isPending } = mention;
	const getMetaContent = () => {
		switch (type) {
			case "single_comment_review": return /* @__PURE__ */ jsxs("span", {
				className: UserMessage_module_default.truncatedPath,
				children: [
					authorDisplayLogin,
					" reviewed",
					" ",
					/* @__PURE__ */ jsx(Link, {
						muted: true,
						inline: true,
						href: url,
						children: path
					})
				]
			});
			case "review": return `${authorDisplayLogin} reviewed`;
			default:
				if (isPending) return `${authorDisplayLogin} commented`;
				return /* @__PURE__ */ jsxs(Fragment$1, { children: [
					authorDisplayLogin,
					" ",
					/* @__PURE__ */ jsx(Link, {
						muted: true,
						inline: true,
						href: url,
						children: "commented"
					})
				] });
		}
	};
	return /* @__PURE__ */ jsx("span", {
		className: UserMessage_module_default.messageMeta,
		children: getMetaContent()
	});
};
MessageMeta.displayName = "MessageMeta";
var MessageText = ({ mention, agentInfo, authorDisplayLogin }) => {
	if (mention.type === "review" && !mention.body) return /* @__PURE__ */ jsx("p", {
		className: UserMessage_module_default.messageText,
		children: `${authorDisplayLogin} requested changes`
	});
	if (!mention.body) return null;
	if (agentInfo) return /* @__PURE__ */ jsx(MessageTextWithHovercards, {
		body: mention.body,
		agentInfo
	});
	return /* @__PURE__ */ jsx(ExpandableMarkdown, {
		className: UserMessage_module_default.messageText,
		markdown: createMarkdownWithAgentLinks(mention.body, agentInfo)
	});
};
MessageText.displayName = "MessageText";
var ReviewCommentText = ({ mention }) => {
	const commentsCount = mention.child_comments ?? 0;
	const commentsText = `${commentsCount} review comment${commentsCount !== 1 ? "s" : ""}`;
	return /* @__PURE__ */ jsxs("span", {
		className: UserMessage_module_default.messageMeta,
		children: [/* @__PURE__ */ jsx(Link, {
			muted: true,
			inline: true,
			href: mention.url,
			children: commentsText
		}), /* @__PURE__ */ jsx(ArrowUpRightIcon, { size: 12 })]
	});
};
ReviewCommentText.displayName = "ReviewCommentText";
var UserProblemStatementMessage_module_default = {
	messageMeta: "UserProblemStatementMessage-module_-9o-Pa_messageMeta",
	messageText: "UserProblemStatementMessage-module_-9o-Pa_messageText"
};
var UserMessageLayout_module_default = {
	avatarContainer: "UserMessageLayout-module_IGFFfa_avatarContainer",
	container: "UserMessageLayout-module_IGFFfa_container",
	messageContainer: "UserMessageLayout-module_IGFFfa_messageContainer"
};
/**
* Shared layout component for user messages (PR comments and problem statements).
* Provides consistent styling for the message container and avatar placement.
* Pass either `avatarUrl` for a standard avatar or `avatar` for a custom element (e.g., loading skeleton).
*/
var UserMessageLayout = ({ avatarUrl, avatar, children }) => {
	const avatarContent = avatar ?? (avatarUrl && /* @__PURE__ */ jsx(GitHubAvatar, {
		src: avatarUrl,
		size: 24
	}));
	return /* @__PURE__ */ jsxs("div", {
		className: UserMessageLayout_module_default.container,
		children: [/* @__PURE__ */ jsx("div", {
			className: UserMessageLayout_module_default.messageContainer,
			children
		}), avatarContent ? /* @__PURE__ */ jsx("div", {
			className: UserMessageLayout_module_default.avatarContainer,
			children: avatarContent
		}) : null]
	});
};
UserMessageLayout.displayName = "UserMessageLayout";
var UserMessageLoading_module_default = {
	messageMeta: "UserMessageLoading-module_J8tAyq_messageMeta",
	messageText: "UserMessageLoading-module_J8tAyq_messageText"
};
var UserMessageLoading = () => /* @__PURE__ */ jsxs(UserMessageLayout, {
	avatar: /* @__PURE__ */ jsx(LoadingSkeleton, {
		variant: "elliptical",
		height: "24px",
		width: "24px"
	}),
	children: [/* @__PURE__ */ jsx("span", {
		className: UserMessageLoading_module_default.messageMeta,
		children: /* @__PURE__ */ jsx(LoadingSkeleton, {
			variant: "rounded",
			height: "sm",
			width: "80px"
		})
	}), /* @__PURE__ */ jsx("div", {
		className: UserMessageLoading_module_default.messageText,
		children: /* @__PURE__ */ jsx(LoadingSkeleton, {
			variant: "rounded",
			height: "sm",
			width: "random"
		})
	})]
});
UserMessageLoading.displayName = "UserMessageLoading";
var ErrorMessage = () => /* @__PURE__ */ jsx(UserMessageLayout, { children: /* @__PURE__ */ jsx("p", {
	className: UserProblemStatementMessage_module_default.messageText,
	children: "Failed to fetch problem statement"
}) });
ErrorMessage.displayName = "ErrorMessage";
var UserProblemStatementMessage = (t0) => {
	const $ = c$1(16);
	const { session, sessionOwner, isLoading: t1 } = t0;
	const isLoading = t1 === void 0 ? false : t1;
	const { data: agentInfo } = useAgentInfo(session.agent_id);
	const { currentUser } = useCurrentUser$1();
	let t2;
	if ($[0] !== session) {
		t2 = isPendingSession(session);
		$[0] = session;
		$[1] = t2;
	} else t2 = $[1];
	const isPending = t2;
	const { isChatSession, isUsingIntentDetection } = useIntentDetection(session);
	if (!session.event_content) {
		let t3;
		if ($[2] !== isLoading) {
			t3 = isLoading ? jsx(UserMessageLoading, {}) : jsx(ErrorMessage, {});
			$[2] = isLoading;
			$[3] = t3;
		} else t3 = $[3];
		return t3;
	}
	let t3;
	if ($[4] !== currentUser || $[5] !== session.user_id || $[6] !== sessionOwner?.login) {
		t3 = () => {
			if (currentUser && session.user_id === currentUser.id) return "You";
			return sessionOwner?.login ?? "User";
		};
		$[4] = currentUser;
		$[5] = session.user_id;
		$[6] = sessionOwner?.login;
		$[7] = t3;
	} else t3 = $[7];
	const getAuthorDisplayLogin = t3;
	const avatarUrl = sessionOwner?.primaryAvatarUrl ?? `https://avatars.githubusercontent.com/${sessionOwner?.login ?? "ghost"}`;
	let t4;
	if ($[8] !== agentInfo || $[9] !== avatarUrl || $[10] !== getAuthorDisplayLogin || $[11] !== isChatSession || $[12] !== isPending || $[13] !== isUsingIntentDetection || $[14] !== session.event_content) {
		const markdownContent = agentInfo ? createMarkdownWithAgentLinks(session.event_content ?? "", agentInfo) : session.event_content ?? "";
		t4 = jsxs(UserMessageLayout, {
			avatarUrl,
			children: [!(isChatSession || isUsingIntentDetection && isPending) && jsxs("span", {
				className: UserProblemStatementMessage_module_default.messageMeta,
				children: [getAuthorDisplayLogin(), " asked"]
			}), jsx(ExpandableMarkdown, {
				className: UserProblemStatementMessage_module_default.messageText,
				markdown: markdownContent
			})]
		});
		$[8] = agentInfo;
		$[9] = avatarUrl;
		$[10] = getAuthorDisplayLogin;
		$[11] = isChatSession;
		$[12] = isPending;
		$[13] = isUsingIntentDetection;
		$[14] = session.event_content;
		$[15] = t4;
	} else t4 = $[15];
	return t4;
};
UserProblemStatementMessage.displayName = "UserProblemStatementMessage";
function createPendingMention(body, currentUser) {
	const userLogin = currentUser?.login ?? "You";
	return {
		type: "timeline_comment",
		id: -1,
		global_relay_id: "",
		pull_request_id: 0,
		body,
		url: "",
		created_at: "",
		updated_at: "",
		author: {
			avatar_url: currentUser?.primaryAvatarUrl ?? `https://avatars.githubusercontent.com/${currentUser?.login ?? "ghost"}`,
			display_login: userLogin,
			global_relay_id: "",
			id: 0,
			url: ""
		},
		path: null,
		subject_type: null,
		child_comments: null,
		isPending: true
	};
}
function createPendingSession(pullId, textOrMentionId, currentUserId, options) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const { agentId, isPRComment = true, taskId } = options ?? {};
	return {
		id: `pending-session`,
		name: "New session",
		user_id: currentUserId ?? 0,
		agent_id: agentId ?? 0,
		state: SessionState.Queued,
		owner_id: 0,
		repo_id: 0,
		resource_type: "pull",
		resource_id: pullId ?? 0,
		resource_global_id: "",
		created_at: now,
		last_updated_at: now,
		updated_at: now,
		completed_at: void 0,
		workflow_run_id: 0,
		log_entries: [],
		error: null,
		premium_requests: 0,
		event_identifiers: isPRComment ? [textOrMentionId] : null,
		event_type: isPRComment ? "pull_request_comment" : "api_call_received",
		event_url: null,
		event_content: isPRComment ? null : textOrMentionId,
		isPending: true,
		model: "",
		task_id: taskId
	};
}
function usePendingSession(t0) {
	const $ = c$1(33);
	const { pullId, taskId, sessions: t1, mentions: t2, currentUser } = t0;
	let t3;
	if ($[0] !== t1) {
		t3 = t1 === void 0 ? [] : t1;
		$[0] = t1;
		$[1] = t3;
	} else t3 = $[1];
	const sessions = t3;
	let t4;
	if ($[2] !== t2) {
		t4 = t2 === void 0 ? [] : t2;
		$[2] = t2;
		$[3] = t4;
	} else t4 = $[3];
	const mentions = t4;
	const [pendingSession, setPendingSession] = useState(null);
	const [pendingMention, setPendingMention] = useState(null);
	const pendingSessionMatchesTask = pendingSession?.task_id === taskId;
	const [prevSessionCount, setPrevSessionCount] = useState(sessions.length);
	const [prevMentionCount, setPrevMentionCount] = useState(mentions.length);
	const hasNewSessions = sessions.length > prevSessionCount;
	const hasNewMentions = mentions.length > prevMentionCount;
	let t5;
	let t6;
	if ($[4] !== prevSessionCount || $[5] !== sessions.length) {
		t5 = () => {
			if (sessions.length !== prevSessionCount) {
				const timeoutId = setTimeout(() => {
					setPrevSessionCount(sessions.length);
				}, 0);
				return () => clearTimeout(timeoutId);
			}
		};
		t6 = [sessions.length, prevSessionCount];
		$[4] = prevSessionCount;
		$[5] = sessions.length;
		$[6] = t5;
		$[7] = t6;
	} else {
		t5 = $[6];
		t6 = $[7];
	}
	useEffect(t5, t6);
	let t7;
	let t8;
	if ($[8] !== mentions.length || $[9] !== prevMentionCount) {
		t7 = () => {
			if (mentions.length !== prevMentionCount) {
				const timeoutId_0 = setTimeout(() => {
					setPrevMentionCount(mentions.length);
				}, 0);
				return () => clearTimeout(timeoutId_0);
			}
		};
		t8 = [mentions.length, prevMentionCount];
		$[8] = mentions.length;
		$[9] = prevMentionCount;
		$[10] = t7;
		$[11] = t8;
	} else {
		t7 = $[10];
		t8 = $[11];
	}
	useEffect(t7, t8);
	const filteredPendingSession = hasNewSessions || !pendingSessionMatchesTask ? null : pendingSession;
	const filteredPendingMention = hasNewMentions || !pendingSessionMatchesTask ? null : pendingMention;
	let t10;
	let t9;
	if ($[12] !== hasNewMentions || $[13] !== hasNewSessions || $[14] !== pendingMention || $[15] !== pendingSession) {
		t9 = () => {
			if (hasNewSessions && pendingSession !== null || hasNewMentions && pendingMention !== null) {
				const timeoutId_1 = setTimeout(() => {
					if (hasNewSessions) setPendingSession(null);
					if (hasNewMentions) setPendingMention(null);
				}, 0);
				return () => clearTimeout(timeoutId_1);
			}
		};
		t10 = [
			hasNewSessions,
			hasNewMentions,
			pendingSession,
			pendingMention
		];
		$[12] = hasNewMentions;
		$[13] = hasNewSessions;
		$[14] = pendingMention;
		$[15] = pendingSession;
		$[16] = t10;
		$[17] = t9;
	} else {
		t10 = $[16];
		t9 = $[17];
	}
	useEffect(t9, t10);
	let t11;
	if ($[18] !== currentUser || $[19] !== pullId || $[20] !== taskId) {
		t11 = (text, t12) => {
			const { agentId, isPRComment: t13 } = t12 === void 0 ? {} : t12;
			const isPRComment = t13 === void 0 ? true : t13;
			if (isPRComment) {
				const newPendingMention = createPendingMention(text, currentUser);
				setPendingMention(newPendingMention);
				setPendingSession(createPendingSession(pullId, newPendingMention.id.toString(), currentUser?.id, {
					agentId,
					isPRComment,
					taskId
				}));
			} else setPendingSession(createPendingSession(pullId, text, currentUser?.id, {
				agentId,
				isPRComment,
				taskId
			}));
		};
		$[18] = currentUser;
		$[19] = pullId;
		$[20] = taskId;
		$[21] = t11;
	} else t11 = $[21];
	const addPendingSession = t11;
	let t12;
	if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = () => {
			setPendingSession(null);
			setPendingMention(null);
		};
		$[22] = t12;
	} else t12 = $[22];
	const clearPendingSession = t12;
	let t13;
	if ($[23] !== filteredPendingSession || $[24] !== sessions) {
		t13 = filteredPendingSession ? [...sessions, filteredPendingSession] : sessions;
		$[23] = filteredPendingSession;
		$[24] = sessions;
		$[25] = t13;
	} else t13 = $[25];
	const allSessions = t13;
	let t14;
	if ($[26] !== filteredPendingMention || $[27] !== mentions) {
		t14 = filteredPendingMention ? [...mentions, filteredPendingMention] : mentions;
		$[26] = filteredPendingMention;
		$[27] = mentions;
		$[28] = t14;
	} else t14 = $[28];
	const allMentions = t14;
	let t15;
	if ($[29] !== addPendingSession || $[30] !== allMentions || $[31] !== allSessions) {
		t15 = {
			allSessions,
			allMentions,
			addPendingSession,
			clearPendingSession
		};
		$[29] = addPendingSession;
		$[30] = allMentions;
		$[31] = allSessions;
		$[32] = t15;
	} else t15 = $[32];
	return t15;
}
/**
* Fetches logs for inactive (completed/failed/cancelled) sessions.
*
* When a pullId is provided, uses the batch endpoint `/agents/sessions/resource/pull/{pullId}/inactive_logs`.
* When no pullId is provided, fetches logs for each inactive session individually.
*/
function useInactiveLogs(t0) {
	const $ = c$1(18);
	const { sessions, pullId, taskId, repoOwner, repoName } = t0;
	let inactiveSessionIds;
	let t1;
	let t2;
	if ($[0] !== pullId || $[1] !== repoName || $[2] !== repoOwner || $[3] !== sessions || $[4] !== taskId) {
		inactiveSessionIds = sessions.filter(_temp$17).map(_temp2$5).sort();
		t2 = useCAPIQuery;
		t1 = [
			"agent-inactive-session-logs",
			taskId,
			pullId,
			repoOwner,
			repoName,
			...inactiveSessionIds
		];
		$[0] = pullId;
		$[1] = repoName;
		$[2] = repoOwner;
		$[3] = sessions;
		$[4] = taskId;
		$[5] = inactiveSessionIds;
		$[6] = t1;
		$[7] = t2;
	} else {
		inactiveSessionIds = $[5];
		t1 = $[6];
		t2 = $[7];
	}
	let t3;
	if ($[8] !== inactiveSessionIds || $[9] !== pullId || $[10] !== repoName || $[11] !== repoOwner || $[12] !== taskId) {
		t3 = async () => {
			let logsPath = void 0;
			if (taskId && repoOwner && repoName) logsPath = taskInactiveLogsApiPath(repoOwner, repoName, taskId);
			else if (pullId) logsPath = pullInactiveLogsApiPath(pullId);
			if (logsPath) {
				const result = await fetchCAPI({ path: logsPath });
				if (!result.ok) throw new Error(`Error fetching inactive session logs: ${result.statusText}`);
				const logsMap = (await result.json()).logs;
				const parsedLogsMap = {};
				for (const sessionId in logsMap) {
					const logString = logsMap[sessionId];
					const logs = [];
					const formattedLogs = formatLogs(logString);
					for (const log of formattedLogs) {
						if (isValidLogEntry(log)) logs.push(log);
						else throw new Error(`Invalid log entry received: ${JSON.stringify(log)}`);
						parsedLogsMap[sessionId] = logs;
					}
				}
				return parsedLogsMap;
			}
			return fetchInactiveLogsBySessionIds(inactiveSessionIds);
		};
		$[8] = inactiveSessionIds;
		$[9] = pullId;
		$[10] = repoName;
		$[11] = repoOwner;
		$[12] = taskId;
		$[13] = t3;
	} else t3 = $[13];
	const t4 = !!pullId || !!taskId || inactiveSessionIds.length > 0;
	let t5;
	if ($[14] !== t1 || $[15] !== t3 || $[16] !== t4) {
		t5 = {
			queryKey: t1,
			queryFn: t3,
			enabled: t4,
			placeholderData: _temp3$1
		};
		$[14] = t1;
		$[15] = t3;
		$[16] = t4;
		$[17] = t5;
	} else t5 = $[17];
	return t2(t5);
}
/**
* Fetches logs for each session individually using the streaming endpoint.
* Used when no PR is available (PR-less tasks).
*/
function _temp3$1(prev) {
	return prev;
}
function _temp2$5(s) {
	return s.id;
}
function _temp$17(session) {
	return [
		"completed",
		"failed",
		"cancelled"
	].includes(session.state.toLowerCase());
}
async function fetchInactiveLogsBySessionIds(sessionIds) {
	const parsedLogsMap = {};
	const logPromises = sessionIds.map(async (sessionId) => {
		try {
			return {
				sessionId,
				logs: await fetchLogsForSession(sessionId)
			};
		} catch (error) {
			console.error(`Error fetching logs for session ${sessionId}:`, error);
			return {
				sessionId,
				logs: []
			};
		}
	});
	const results = await Promise.all(logPromises);
	for (const { sessionId, logs } of results) parsedLogsMap[sessionId] = logs;
	return parsedLogsMap;
}
/**
* Fetches logs for a single session.
*/
async function fetchLogsForSession(sessionId) {
	const result = await fetchCAPI({ path: `/agents/sessions/${sessionId}/logs` });
	if (!result.ok) throw new Error(`Error fetching logs for session ${sessionId}: ${result.statusText}`);
	const logString = await result.text();
	const logs = [];
	const formattedLogs = formatLogs(logString);
	for (const log of formattedLogs) if (isValidLogEntry(log)) logs.push(log);
	else throw new Error(`Invalid log entry received: ${JSON.stringify(log)}`);
	return logs;
}
function formatLogs(logs) {
	return parseSSEString(logs).map((jsonString) => JSON.parse(jsonString));
}
function parseSSEString(sseString) {
	return sseString.split("\n\n").map((event) => event.trim()).filter((event) => event.length > 0).map((event) => {
		return event.split("\n").filter((line) => line.startsWith("data: ")).map((line) => line.substring(6)).join("\n");
	}).filter((data) => data !== "[DONE]").filter((data) => data.length > 0);
}
function LegacyCopilotMessage(t0) {
	const $ = c$1(9);
	const { logsPollingInterval } = t0;
	const { currentUserIsSessionOwner } = useCurrentUser$1();
	let t1;
	if ($[0] !== currentUserIsSessionOwner || $[1] !== logsPollingInterval) {
		t1 = {
			logsPollingInterval,
			batchCompletedSessions: true,
			currentUserIsSessionOwner
		};
		$[0] = currentUserIsSessionOwner;
		$[1] = logsPollingInterval;
		$[2] = t1;
	} else t1 = $[2];
	const { data: logsData, isLoading, error } = useLogs(t1);
	let t2;
	let t3;
	if ($[3] !== error || $[4] !== isLoading || $[5] !== logsData) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const replyToCommentCalls = extractReplyToCommentCalls$1(logsData);
			if (isLoading) {
				let t4;
				if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
					t4 = jsx(LoadingMessage, {});
					$[8] = t4;
				} else t4 = $[8];
				t3 = t4;
				break bb0;
			}
			if (error) {
				t3 = null;
				break bb0;
			}
			if (replyToCommentCalls.length === 0) {
				t3 = null;
				break bb0;
			}
			t2 = jsx("div", {
				className: LegacyCopilotMessage_module_default.container,
				children: replyToCommentCalls.map(_temp$16)
			});
		}
		$[3] = error;
		$[4] = isLoading;
		$[5] = logsData;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
LegacyCopilotMessage.displayName = "LegacyCopilotMessage";
function _temp$16(call, index) {
	return jsxs("div", {
		className: LegacyCopilotMessage_module_default.message,
		children: [jsx("div", {
			className: LegacyCopilotMessage_module_default.icon,
			children: index === 0 && jsx(AgentAvatar, {
				size: 32,
				animationType: "static",
				loopAnimation: false
			})
		}), jsx(MarkdownRenderer, {
			className: LegacyCopilotMessage_module_default.text,
			markdown: call.reply
		})]
	}, call.comment_id);
}
var LoadingMessage = () => /* @__PURE__ */ jsx("div", {
	className: LegacyCopilotMessage_module_default.container,
	children: /* @__PURE__ */ jsxs("div", {
		className: LegacyCopilotMessage_module_default.message,
		children: [/* @__PURE__ */ jsx("div", {
			className: LegacyCopilotMessage_module_default.icon,
			children: /* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "elliptical",
				height: "32px",
				width: "32px"
			})
		}), /* @__PURE__ */ jsxs("div", {
			className: clsx(LegacyCopilotMessage_module_default.text, LegacyCopilotMessage_module_default.loadingText),
			children: [
				/* @__PURE__ */ jsx(LoadingSkeleton, {
					variant: "rounded",
					height: "sm",
					width: "100%"
				}),
				/* @__PURE__ */ jsx(LoadingSkeleton, {
					variant: "rounded",
					height: "sm",
					width: "100%"
				}),
				/* @__PURE__ */ jsx(LoadingSkeleton, {
					variant: "rounded",
					height: "sm",
					width: "70%"
				})
			]
		})]
	})
});
LoadingMessage.displayName = "LoadingMessage";
function extractReplyToCommentCalls$1(logsData = []) {
	const replyToCommentCallsMap = /* @__PURE__ */ new Map();
	for (const logEntry of logsData) if (isCompletionChunk(logEntry)) for (const choice of logEntry.choices) {
		if (choice.delta.role !== "assistant") continue;
		const toolCalls = choice.delta.tool_calls || [];
		for (const toolCall of toolCalls) {
			const toolName = toolCall.function?.name ?? toolCall.custom?.name;
			const rawArguments = toolCall.function?.arguments ?? toolCall.custom?.input;
			if (toolName !== "reply_to_comment") continue;
			if (!rawArguments) continue;
			try {
				const args = typeof rawArguments === "string" ? JSON.parse(rawArguments) : rawArguments;
				replyToCommentCallsMap.set(logEntry.id, args);
			} catch {
				if (typeof rawArguments === "string") replyToCommentCallsMap.set(logEntry.id, { reply: rawArguments });
			}
		}
	}
	return [...replyToCommentCallsMap.values()];
}
function CopilotReplyMessage(t0) {
	const $ = c$1(9);
	const { logsPollingInterval } = t0;
	const { currentUserIsSessionOwner } = useCurrentUser$1();
	let t1;
	if ($[0] !== currentUserIsSessionOwner || $[1] !== logsPollingInterval) {
		t1 = {
			logsPollingInterval,
			batchCompletedSessions: true,
			currentUserIsSessionOwner
		};
		$[0] = currentUserIsSessionOwner;
		$[1] = logsPollingInterval;
		$[2] = t1;
	} else t1 = $[2];
	const { data: logsData, isLoading: logsIsLoading, error: logsError } = useLogs(t1);
	let t2;
	let t3;
	if ($[3] !== logsData || $[4] !== logsError || $[5] !== logsIsLoading) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const replyToCommentCalls = extractReplyToCommentCalls(logsData);
			if (logsIsLoading) {
				let t4;
				if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
					t4 = jsx(CopilotMessageLoading, {});
					$[8] = t4;
				} else t4 = $[8];
				t3 = t4;
				break bb0;
			}
			if (logsError || replyToCommentCalls.length === 0) {
				t3 = null;
				break bb0;
			}
			t2 = jsx(CopilotMessageContainer, { children: replyToCommentCalls.map(_temp$15) });
		}
		$[3] = logsData;
		$[4] = logsError;
		$[5] = logsIsLoading;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
CopilotReplyMessage.displayName = "CopilotReplyMessage";
function _temp$15(call, index) {
	return jsx(CopilotMessageBubble, {
		markdown: call.reply,
		showAvatar: index === 0
	}, call.comment_id);
}
function extractReplyToCommentCalls(logsData = []) {
	const replyToCommentCallsMap = /* @__PURE__ */ new Map();
	for (const logEntry of logsData) if (isCompletionChunk(logEntry)) for (const choice of logEntry.choices) {
		if (choice.delta.role !== "assistant") continue;
		const toolCalls = choice.delta.tool_calls || [];
		for (const toolCall of toolCalls) {
			const toolName = toolCall.function?.name ?? toolCall.custom?.name;
			const rawArguments = toolCall.function?.arguments ?? toolCall.custom?.input;
			if (toolName !== "reply_to_comment") continue;
			if (!rawArguments) continue;
			try {
				const args = typeof rawArguments === "string" ? JSON.parse(rawArguments) : rawArguments;
				replyToCommentCallsMap.set(logEntry.id, args);
			} catch {
				if (typeof rawArguments === "string") replyToCommentCallsMap.set(logEntry.id, { reply: rawArguments });
			}
		}
	}
	return [...replyToCommentCallsMap.values()];
}
function useCreateAPISession(t0) {
	const $ = c$1(23);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { onError, onSuccess, onCommandCreated } = t1;
	const { setStreamingChatResponse, setStreamingState } = useChatStreamContext();
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = ["createAPISession"];
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== onCommandCreated || $[4] !== setStreamingChatResponse || $[5] !== setStreamingState) {
		t3 = async (params) => {
			const imageCount = isFeatureEnabled("copilot_agent_image_upload") ? extractImageUrls(params.problemStatement).length : 0;
			sendEvent("copilot.agent_session.session_creation_requested", {
				nwo: params.nwo,
				task_id: params.taskId,
				image_count: imageCount
			});
			try {
				await createSession({
					...params,
					setStreamingChatResponse,
					setStreamingState,
					onCommandCreated
				});
			} catch (t4) {
				const error = t4;
				setStreamingState?.("closed");
				if (error instanceof FetchCAPIError) sendEvent("copilot.agent_session.session_creation_failed", {
					nwo: params.nwo,
					task_id: params.taskId,
					status: error.status,
					error: error.message,
					image_count: imageCount
				});
				throw error;
			}
			sendEvent("copilot.agent_session.session_creation_accepted", {
				nwo: params.nwo,
				task_id: params.taskId,
				image_count: imageCount
			});
		};
		$[3] = onCommandCreated;
		$[4] = setStreamingChatResponse;
		$[5] = setStreamingState;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== onError || $[8] !== setStreamingState) {
		t4 = (error_0) => {
			setStreamingState?.("closed");
			onError?.(error_0);
		};
		$[7] = onError;
		$[8] = setStreamingState;
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== onSuccess || $[11] !== setStreamingState) {
		t5 = () => {
			setStreamingState?.("closed");
			onSuccess?.();
		};
		$[10] = onSuccess;
		$[11] = setStreamingState;
		$[12] = t5;
	} else t5 = $[12];
	let t6;
	if ($[13] !== t3 || $[14] !== t4 || $[15] !== t5) {
		t6 = {
			mutationKey: t2,
			mutationFn: t3,
			onError: t4,
			onSuccess: t5
		};
		$[13] = t3;
		$[14] = t4;
		$[15] = t5;
		$[16] = t6;
	} else t6 = $[16];
	const createSessionMutation = useMutation(t6);
	let t7;
	if ($[17] !== createSessionMutation) {
		t7 = (params_0) => {
			createSessionMutation.mutate(params_0);
		};
		$[17] = createSessionMutation;
		$[18] = t7;
	} else t7 = $[18];
	const createAPISession = t7;
	let t8;
	if ($[19] !== createAPISession || $[20] !== createSessionMutation.error || $[21] !== createSessionMutation.isPending) {
		t8 = {
			createSession: createAPISession,
			isCreating: createSessionMutation.isPending,
			createError: createSessionMutation.error
		};
		$[19] = createAPISession;
		$[20] = createSessionMutation.error;
		$[21] = createSessionMutation.isPending;
		$[22] = t8;
	} else t8 = $[22];
	return t8;
}
/**
* Helper function to create session via the Task API
*/
async function createSession({ nwo, taskId, problemStatement, model, agentId, customAgent, eventType, intentDetectionMode, setStreamingChatResponse, setStreamingState, onCommandCreated }) {
	const endpoint = repoTaskSessionsApiPath(nwo, taskId);
	const additionalHeaders = intentDetectionHeaders(intentDetectionMode);
	if (setStreamingChatResponse) {
		setStreamingState?.("requested");
		const resp = await fetchCAPI({
			path: endpoint,
			method: "POST",
			additionalHeaders,
			body: {
				problem_statement: problemStatement,
				...model && { model },
				...agentId && { agent_id: agentId },
				...customAgent && { custom_agent: customAgent }
			}
		});
		const contentType = resp.headers.get("Content-Type") ?? "";
		if (resp.status === 201 && contentType.includes("application/json")) {
			const commandResponse = await resp.json();
			onCommandCreated?.(commandResponse, problemStatement);
			setStreamingState?.("closed");
			return resp;
		}
		if (contentType.includes("text/event-stream")) {
			const reader = resp.body?.getReader();
			if (!reader) {
				setStreamingState?.("closed");
				throw new Error("No reader found in response body");
			}
			const streamer = new CopilotChatMessageStreamer(reader);
			let accumulated = "";
			let sessionID = "";
			for await (const message of streamer.stream()) {
				if (message.type === "metadata") sessionID = message.session_id;
				if (message.type === "content") {
					const content = message.body;
					if (content) {
						accumulated += content;
						setStreamingChatResponse(sessionID, accumulated);
					}
				}
			}
		}
		setStreamingState?.("closed");
		return resp;
	}
	return await fetchCAPI({
		path: endpoint,
		method: "POST",
		additionalHeaders,
		body: {
			problem_statement: problemStatement,
			event_type: eventType,
			...model && { model },
			...agentId && { agent_id: agentId },
			...customAgent && { custom_agent: customAgent }
		}
	});
}
var ChatInputDisplay_module_default = {
	container: "ChatInputDisplay-module_MnZxKG_container",
	input: "ChatInputDisplay-module_MnZxKG_input",
	inputFocused: "ChatInputDisplay-module_MnZxKG_inputFocused",
	inputWrapper: "ChatInputDisplay-module_MnZxKG_inputWrapper",
	inputWrapperWithToolbar: "ChatInputDisplay-module_MnZxKG_inputWrapperWithToolbar",
	sendButton: "ChatInputDisplay-module_MnZxKG_sendButton",
	skeletonWrapper: "ChatInputDisplay-module_MnZxKG_skeletonWrapper",
	toolbar: "ChatInputDisplay-module_MnZxKG_toolbar"
};
function ChatInputDisplay({ value, onChange, onSubmit, placeholder = "Type a message...", disabled = false, isSubmitting = false, ariaLabel, sendButtonAriaLabel = "Send", onPaste, toolbarSlot, ref, allowEmptySubmit = false }) {
	const [isFocused, setIsFocused] = useState(false);
	const isEmpty = !value.trim();
	const isButtonInactive = disabled || isSubmitting || !allowEmptySubmit && isEmpty;
	const handleKeyDown = (e) => {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			if (!disabled && !isSubmitting && (allowEmptySubmit || !isEmpty)) onSubmit();
		}
	};
	const handleSubmitClick = () => {
		if (!disabled && !isSubmitting && (allowEmptySubmit || !isEmpty)) onSubmit();
	};
	const hasToolbar = !!toolbarSlot;
	return /* @__PURE__ */ jsx("div", {
		className: ChatInputDisplay_module_default.container,
		children: /* @__PURE__ */ jsxs("div", {
			className: clsx(ChatInputDisplay_module_default.inputWrapper, hasToolbar && ChatInputDisplay_module_default.inputWrapperWithToolbar),
			children: [/* @__PURE__ */ jsx("textarea", {
				ref,
				className: clsx(ChatInputDisplay_module_default.input, (isFocused || value) && ChatInputDisplay_module_default.inputFocused),
				value,
				onChange: (e_0) => onChange(e_0.target.value),
				onKeyDown: handleKeyDown,
				onFocus: () => setIsFocused(true),
				onBlur: () => setIsFocused(false),
				onPaste,
				placeholder,
				disabled,
				"aria-label": ariaLabel ?? placeholder,
				rows: isFocused || value ? 3 : 1
			}), hasToolbar ? /* @__PURE__ */ jsxs("div", {
				className: ChatInputDisplay_module_default.toolbar,
				children: [toolbarSlot, /* @__PURE__ */ jsx(IconButton, {
					variant: "invisible",
					size: "medium",
					icon: PaperAirplaneIcon,
					"aria-label": sendButtonAriaLabel,
					inactive: isButtonInactive,
					"aria-disabled": isButtonInactive,
					onClick: handleSubmitClick
				})]
			}) : /* @__PURE__ */ jsx(IconButton, {
				variant: "invisible",
				size: "medium",
				icon: PaperAirplaneIcon,
				"aria-label": sendButtonAriaLabel,
				inactive: isButtonInactive,
				"aria-disabled": isButtonInactive,
				onClick: handleSubmitClick,
				className: ChatInputDisplay_module_default.sendButton
			})]
		})
	});
}
ChatInputDisplay.displayName = "ChatInputDisplay";
function SimpleAskUserDisplay(t0) {
	const $ = c$1(20);
	const { question, choices, multiSelect, allowFreeform, recommendedChoice, onChoose, onSubmitChoices, onFreeform, onSkip, disabled } = t0;
	const [freeformValue, setFreeformValue] = useState("");
	const [showFreeform, setShowFreeform] = useState(false);
	const [selectedChoices, setSelectedChoices] = useState(_temp$14);
	let t1;
	if ($[0] !== disabled || $[1] !== freeformValue || $[2] !== onFreeform) {
		t1 = () => {
			if (disabled || !onFreeform || !freeformValue.trim()) return;
			onFreeform(freeformValue.trim());
		};
		$[0] = disabled;
		$[1] = freeformValue;
		$[2] = onFreeform;
		$[3] = t1;
	} else t1 = $[3];
	const handleFreeformSubmit = t1;
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (choice) => {
			setSelectedChoices((prev) => {
				const next = new Set(prev);
				if (next.has(choice)) next.delete(choice);
				else next.add(choice);
				return next;
			});
		};
		$[4] = t2;
	} else t2 = $[4];
	const toggleChoice = t2;
	const isFreeformOnly = choices.length === 0 && allowFreeform;
	let t3;
	if ($[5] !== allowFreeform || $[6] !== choices || $[7] !== disabled || $[8] !== freeformValue || $[9] !== handleFreeformSubmit || $[10] !== isFreeformOnly || $[11] !== multiSelect || $[12] !== onChoose || $[13] !== onSkip || $[14] !== onSubmitChoices || $[15] !== question || $[16] !== recommendedChoice || $[17] !== selectedChoices || $[18] !== showFreeform) {
		t3 = jsx(UserChoiceCard, {
			title: question,
			embedded: true,
			previewContent: jsx(MarkdownRenderer, { markdown: question }),
			footerButtons: jsxs(Fragment$1, { children: [
				multiSelect && jsx(ButtonComponent$1, {
					variant: "primary",
					onClick: () => onSubmitChoices?.([...selectedChoices]),
					disabled: disabled || selectedChoices.size === 0,
					children: "Submit"
				}),
				(showFreeform || isFreeformOnly) && jsx(ButtonComponent$1, {
					variant: "primary",
					onClick: handleFreeformSubmit,
					disabled: disabled || !freeformValue.trim(),
					children: "Send"
				}),
				onSkip && jsx(ButtonComponent$1, {
					variant: "default",
					onClick: onSkip,
					disabled,
					children: "Skip"
				})
			] }),
			children: isFreeformOnly ? jsx(TextInput$1, {
				placeholder: "Type your answer...",
				value: freeformValue,
				onChange: (e) => setFreeformValue(e.target.value),
				onKeyDown: (e_0) => {
					if (e_0.key === "Enter") {
						e_0.preventDefault();
						handleFreeformSubmit();
					}
				},
				disabled,
				block: true,
				autoFocus: true
			}) : choices.length > 0 ? jsxs(ChoiceButtonGroup, { children: [choices.map((choice_0, i) => jsx(ChoiceButton, {
				number: i + 1,
				label: jsx(MarkdownRenderer, { markdown: choice_0 }),
				showCheckbox: multiSelect,
				checked: selectedChoices.has(choice_0),
				isRecommended: choice_0 === recommendedChoice,
				disabled,
				onClick: () => multiSelect ? toggleChoice(choice_0) : onChoose?.(choice_0)
			}, choice_0)), allowFreeform && (showFreeform ? jsx(ChoiceButtonInput, {
				number: choices.length + 1,
				placeholder: "Type your answer...",
				value: freeformValue,
				onChange: setFreeformValue,
				onSubmit: handleFreeformSubmit,
				disabled
			}) : jsx(ChoiceButton, {
				number: choices.length + 1,
				label: "Other (type your answer)",
				disabled,
				onClick: () => setShowFreeform(true)
			}))] }) : null
		});
		$[5] = allowFreeform;
		$[6] = choices;
		$[7] = disabled;
		$[8] = freeformValue;
		$[9] = handleFreeformSubmit;
		$[10] = isFreeformOnly;
		$[11] = multiSelect;
		$[12] = onChoose;
		$[13] = onSkip;
		$[14] = onSubmitChoices;
		$[15] = question;
		$[16] = recommendedChoice;
		$[17] = selectedChoices;
		$[18] = showFreeform;
		$[19] = t3;
	} else t3 = $[19];
	return t3;
}
SimpleAskUserDisplay.displayName = "SimpleAskUserDisplay";
function _temp$14() {
	return /* @__PURE__ */ new Set();
}
var ElicitationAskUserDisplay_module_default = {
	fieldDescription: "ElicitationAskUserDisplay-module_jUBHKG_fieldDescription",
	fieldTitle: "ElicitationAskUserDisplay-module_jUBHKG_fieldTitle",
	freeformInput: "ElicitationAskUserDisplay-module_jUBHKG_freeformInput",
	previewRow: "ElicitationAskUserDisplay-module_jUBHKG_previewRow",
	previewText: "ElicitationAskUserDisplay-module_jUBHKG_previewText",
	required: "ElicitationAskUserDisplay-module_jUBHKG_required",
	stepIndicator: "ElicitationAskUserDisplay-module_jUBHKG_stepIndicator",
	stepLabel: "ElicitationAskUserDisplay-module_jUBHKG_stepLabel"
};
function ElicitationAskUserDisplay(t0) {
	const $ = c$1(37);
	const { message, schema, onElicitationSubmit, onDecline, disabled } = t0;
	let t1;
	if ($[0] !== schema.properties) {
		t1 = Object.entries(schema.properties);
		$[0] = schema.properties;
		$[1] = t1;
	} else t1 = $[1];
	const entries = t1;
	const totalSteps = entries.length;
	const isMultiStep = totalSteps > 1;
	const [currentStep, setCurrentStep] = useState(0);
	let t2;
	if ($[2] !== entries) {
		t2 = () => {
			const defaults = {};
			for (const [key, prop] of entries) if (prop.multiSelect) defaults[key] = [];
			else if (prop.default) defaults[key] = prop.default;
			return defaults;
		};
		$[2] = entries;
		$[3] = t2;
	} else t2 = $[3];
	const [selections, setSelections] = useState(t2);
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = {};
		$[4] = t3;
	} else t3 = $[4];
	const [freeformValues, setFreeformValues] = useState(t3);
	const [freeformSelectedSteps, setFreeformSelectedSteps] = useState(_temp$13);
	let t4;
	if ($[5] !== currentStep || $[6] !== entries) {
		t4 = entries[currentStep] ?? [];
		$[5] = currentStep;
		$[6] = entries;
		$[7] = t4;
	} else t4 = $[7];
	const [currentKey] = t4;
	let t5;
	if ($[8] !== currentKey || $[9] !== currentStep || $[10] !== disabled || $[11] !== entries || $[12] !== freeformSelectedSteps || $[13] !== freeformValues || $[14] !== isMultiStep || $[15] !== message || $[16] !== onDecline || $[17] !== onElicitationSubmit || $[18] !== schema.required || $[19] !== selections || $[20] !== totalSteps) {
		const isFreeformSelected = currentKey ? freeformSelectedSteps.has(currentKey) : false;
		const currentFreeformValue = currentKey ? freeformValues[currentKey] ?? "" : "";
		let t6;
		if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
			t6 = (key_0, value) => {
				setSelections((prev) => ({
					...prev,
					[key_0]: value
				}));
				setFreeformSelectedSteps((prev_0) => {
					const next = new Set(prev_0);
					next.delete(key_0);
					return next;
				});
			};
			$[22] = t6;
		} else t6 = $[22];
		const setSelection = t6;
		let t7;
		if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = (key_1, value_0) => {
				setSelections((prev_1) => {
					const current = prev_1[key_1];
					const arr = Array.isArray(current) ? current : [];
					const next_0 = arr.includes(value_0) ? arr.filter((v) => v !== value_0) : [...arr, value_0];
					return {
						...prev_1,
						[key_1]: next_0
					};
				});
				setFreeformSelectedSteps((prev_2) => {
					const next_1 = new Set(prev_2);
					next_1.delete(key_1);
					return next_1;
				});
			};
			$[23] = t7;
		} else t7 = $[23];
		const toggleMultiSelection = t7;
		let t8;
		if ($[24] !== disabled || $[25] !== freeformSelectedSteps || $[26] !== freeformValues || $[27] !== onElicitationSubmit || $[28] !== selections) {
			t8 = () => {
				if (disabled) return;
				const finalSelections = { ...selections };
				for (const key_2 of freeformSelectedSteps) {
					const freeVal = freeformValues[key_2]?.trim();
					if (freeVal) finalSelections[key_2] = freeVal;
				}
				onElicitationSubmit(finalSelections);
			};
			$[24] = disabled;
			$[25] = freeformSelectedSteps;
			$[26] = freeformValues;
			$[27] = onElicitationSubmit;
			$[28] = selections;
			$[29] = t8;
		} else t8 = $[29];
		const handleSubmit = t8;
		let t9;
		if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
			t9 = () => setCurrentStep(_temp2$4);
			$[30] = t9;
		} else t9 = $[30];
		const goPrev = t9;
		let t10;
		if ($[31] !== totalSteps) {
			t10 = () => setCurrentStep((prev_4) => Math.min(totalSteps - 1, prev_4 + 1));
			$[31] = totalSteps;
			$[32] = t10;
		} else t10 = $[32];
		const goNext = t10;
		const requiredFields = schema.required ?? [];
		let t11;
		if ($[33] !== freeformSelectedSteps || $[34] !== freeformValues || $[35] !== selections) {
			t11 = (key_3) => {
				if (freeformSelectedSteps.has(key_3)) return (freeformValues[key_3]?.trim() ?? "").length > 0;
				const sel = selections[key_3];
				if (Array.isArray(sel)) return sel.length > 0;
				return !!sel;
			};
			$[33] = freeformSelectedSteps;
			$[34] = freeformValues;
			$[35] = selections;
			$[36] = t11;
		} else t11 = $[36];
		const allRequiredFilled = requiredFields.every(t11);
		const hasFreeformWithEmptyInput = [...freeformSelectedSteps].some((key_4) => (freeformValues[key_4]?.trim() ?? "").length === 0);
		const isSubmitDisabled = disabled || !allRequiredFilled || hasFreeformWithEmptyInput;
		const isLastStep = currentStep >= totalSteps - 1;
		const currentProp = entries[currentStep]?.[1];
		const enumCount = currentProp?.enum?.length ?? 0;
		const currentLabel = currentProp ? currentProp.title ?? currentKey : "";
		t5 = jsx(UserChoiceCard, {
			title: message,
			embedded: true,
			previewContent: jsxs("div", {
				className: ElicitationAskUserDisplay_module_default.previewRow,
				children: [jsxs("div", {
					className: ElicitationAskUserDisplay_module_default.previewText,
					children: [jsx(MarkdownRenderer, { markdown: message }), currentKey && currentProp && jsxs(Fragment$1, { children: [jsxs("p", {
						className: ElicitationAskUserDisplay_module_default.fieldTitle,
						children: [currentLabel, requiredFields.includes(currentKey) && jsx("span", {
							className: ElicitationAskUserDisplay_module_default.required,
							children: " *"
						})]
					}), currentProp.description && jsx("p", {
						className: ElicitationAskUserDisplay_module_default.fieldDescription,
						children: currentProp.description
					})] })]
				}), isMultiStep && jsx(SchemaStepIndicator, {
					current: currentStep,
					total: totalSteps,
					onPrev: goPrev,
					onNext: goNext
				})]
			}),
			footerButtons: jsxs(Fragment$1, { children: [
				onDecline && jsx(ButtonComponent$1, {
					variant: "default",
					onClick: onDecline,
					disabled,
					children: "Skip"
				}),
				isMultiStep && currentStep > 0 && jsx(ButtonComponent$1, {
					variant: "default",
					onClick: goPrev,
					disabled,
					children: "Previous question"
				}),
				isLastStep ? jsx(ButtonComponent$1, {
					variant: "primary",
					onClick: handleSubmit,
					disabled: isSubmitDisabled,
					children: "Submit"
				}) : jsx(ButtonComponent$1, {
					variant: "primary",
					onClick: goNext,
					disabled,
					children: "Next question"
				})
			] }),
			children: currentKey && currentProp && jsxs(ChoiceButtonGroup, { children: [jsx(SchemaField, {
				property: currentProp,
				selectedValue: isFreeformSelected ? void 0 : selections[currentKey],
				onSelect: (value_1) => currentProp.multiSelect ? toggleMultiSelection(currentKey, value_1) : setSelection(currentKey, value_1),
				startNumber: 1,
				disabled
			}), jsx(FreeformChoiceRow, {
				number: enumCount + 1,
				selected: isFreeformSelected,
				value: currentFreeformValue,
				onToggle: () => {
					setFreeformSelectedSteps((prev_5) => {
						const next_2 = new Set(prev_5);
						if (next_2.has(currentKey)) next_2.delete(currentKey);
						else next_2.add(currentKey);
						return next_2;
					});
				},
				onChange: (val) => setFreeformValues((prev_6) => ({
					...prev_6,
					[currentKey]: val
				})),
				onSubmit: handleSubmit,
				disabled
			})] })
		});
		$[8] = currentKey;
		$[9] = currentStep;
		$[10] = disabled;
		$[11] = entries;
		$[12] = freeformSelectedSteps;
		$[13] = freeformValues;
		$[14] = isMultiStep;
		$[15] = message;
		$[16] = onDecline;
		$[17] = onElicitationSubmit;
		$[18] = schema.required;
		$[19] = selections;
		$[20] = totalSteps;
		$[21] = t5;
	} else t5 = $[21];
	return t5;
}
ElicitationAskUserDisplay.displayName = "ElicitationAskUserDisplay";
function _temp2$4(prev_3) {
	return Math.max(0, prev_3 - 1);
}
function _temp$13() {
	return /* @__PURE__ */ new Set();
}
function SchemaStepIndicator({ current, total, onPrev, onNext }) {
	return /* @__PURE__ */ jsxs("div", {
		className: ElicitationAskUserDisplay_module_default.stepIndicator,
		children: [
			/* @__PURE__ */ jsx(IconButton, {
				icon: ChevronLeftIcon,
				"aria-label": "Previous step",
				size: "small",
				variant: "invisible",
				onClick: onPrev,
				disabled: current === 0
			}),
			/* @__PURE__ */ jsxs("span", {
				className: ElicitationAskUserDisplay_module_default.stepLabel,
				children: [
					current + 1,
					" of ",
					total
				]
			}),
			/* @__PURE__ */ jsx(IconButton, {
				icon: ChevronRightIcon,
				"aria-label": "Next step",
				size: "small",
				variant: "invisible",
				onClick: onNext,
				disabled: current >= total - 1
			})
		]
	});
}
SchemaStepIndicator.displayName = "SchemaStepIndicator";
function SchemaField({ property, selectedValue, onSelect, startNumber, disabled }) {
	const enumValues = property.enum ?? [];
	const enumLabels = property.enumLabels;
	const selectedSet = Array.isArray(selectedValue) ? new Set(selectedValue) : null;
	return /* @__PURE__ */ jsx(Fragment$1, { children: enumValues.map((value, i) => /* @__PURE__ */ jsx(ChoiceButton, {
		number: startNumber + i,
		label: enumLabels?.[value] ?? value,
		isRecommended: value === property.default,
		disabled,
		showCheckbox: true,
		checked: selectedSet ? selectedSet.has(value) : selectedValue === value,
		onClick: () => onSelect(value)
	}, value)) });
}
SchemaField.displayName = "SchemaField";
function FreeformChoiceRow({ number, selected, value, onToggle, onChange, onSubmit, disabled }) {
	const inputRef = useRef(null);
	useEffect(() => {
		if (selected) inputRef.current?.focus();
	}, [selected]);
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(ChoiceButton_module_default.row, ChoiceButton_module_default.inputRow),
		role: "button",
		tabIndex: 0,
		"aria-pressed": selected,
		onClick: (e) => {
			if (!e.target.closest("input")) onToggle();
		},
		onKeyDown: (e_0) => {
			if (e_0.key === "Enter" && !e_0.target.closest("input")) onToggle();
		},
		children: [
			/* @__PURE__ */ jsx("span", {
				className: ChoiceButton_module_default.numberBadge,
				children: number
			}),
			/* @__PURE__ */ jsx("span", {
				className: clsx(ChoiceButton_module_default.checkbox, selected && ChoiceButton_module_default.checkboxChecked),
				"aria-hidden": "true"
			}),
			selected ? /* @__PURE__ */ jsx(TextInput$1, {
				ref: inputRef,
				className: ElicitationAskUserDisplay_module_default.freeformInput,
				placeholder: "Type your answer...",
				value,
				onChange: (e_1) => onChange(e_1.target.value),
				onKeyDown: (e_2) => {
					if (e_2.key === "Enter") {
						e_2.preventDefault();
						onSubmit();
					}
				},
				disabled,
				size: "small",
				"aria-label": "Freeform answer"
			}) : /* @__PURE__ */ jsx("div", {
				className: ChoiceButton_module_default.text,
				children: /* @__PURE__ */ jsx("div", {
					className: ChoiceButton_module_default.title,
					children: "Other (type your answer)"
				})
			})
		]
	});
}
FreeformChoiceRow.displayName = "FreeformChoiceRow";
var PermissionDisplay_module_default = {
	sessionLabelCode: "PermissionDisplay-module_9EkNvW_sessionLabelCode",
	standaloneContainer: "PermissionDisplay-module_9EkNvW_standaloneContainer",
	standaloneDetail: "PermissionDisplay-module_9EkNvW_standaloneDetail",
	standaloneIntention: "PermissionDisplay-module_9EkNvW_standaloneIntention",
	standaloneLabel: "PermissionDisplay-module_9EkNvW_standaloneLabel",
	standaloneLabelOnly: "PermissionDisplay-module_9EkNvW_standaloneLabelOnly"
};
/**
* Renders text with inline `code` segments styled as <code> elements.
*
* When split() uses a capturing group, captured content is included in the result array.
* Example: "Allow for `git`, `npm`".split(/`([^`]+)`/)
*        → ["Allow for ", "git", ", ", "npm", ""]
*           index 0 (text)  1 (code)  2 (text)  3 (code)  4 (text)
* Captured groups always land on odd indices, so index % 2 === 1 identifies code.
*/
function InlineCode({ text, codeClassName }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: text.split(/`([^`]+)`/).map((part, index) => index % 2 === 1 ? /* @__PURE__ */ jsx("code", {
		className: codeClassName,
		children: part
	}, `code-${index}-${part}`) : /* @__PURE__ */ jsx("span", { children: part }, `text-${index}-${part}`)) });
}
InlineCode.displayName = "InlineCode";
var EMPTY_COMMAND_IDENTIFIERS = [];
/** Display a permission request prompt with Allow/Deny choices */
function PermissionDisplay(t0) {
	const $ = c$1(23);
	const { kind, toolName, intention, detail, canOfferSessionApproval: t1, commandIdentifiers: t2, onRespond, disabled: t3 } = t0;
	const canOfferSessionApproval = t1 === void 0 ? false : t1;
	const commandIdentifiers = t2 === void 0 ? EMPTY_COMMAND_IDENTIFIERS : t2;
	const disabled = t3 === void 0 ? false : t3;
	let t4;
	if ($[0] !== disabled || $[1] !== onRespond) {
		t4 = () => {
			if (disabled) return;
			onRespond?.(true);
		};
		$[0] = disabled;
		$[1] = onRespond;
		$[2] = t4;
	} else t4 = $[2];
	const handleAllow = t4;
	let t5;
	if ($[3] !== disabled || $[4] !== onRespond) {
		t5 = () => {
			if (disabled) return;
			onRespond?.(true, "session");
		};
		$[3] = disabled;
		$[4] = onRespond;
		$[5] = t5;
	} else t5 = $[5];
	const handleAllowSession = t5;
	let t6;
	if ($[6] !== disabled || $[7] !== onRespond) {
		t6 = () => {
			if (disabled) return;
			onRespond?.(false);
		};
		$[6] = disabled;
		$[7] = onRespond;
		$[8] = t6;
	} else t6 = $[8];
	const handleDeny = t6;
	const isCommand = kind === "commands" || kind === "shell";
	const isWrite = kind === "write";
	const label = isCommand ? "Run command" : isWrite ? "Edit file" : `Permission: ${toolName ?? kind}`;
	let t7;
	if ($[9] !== canOfferSessionApproval || $[10] !== commandIdentifiers || $[11] !== isWrite) {
		t7 = canOfferSessionApproval && commandIdentifiers.length > 0 ? `Allow and don't ask again for \`${commandIdentifiers.join("`, `")}\`` : isWrite ? "Allow all edits this session" : "Allow for session";
		$[9] = canOfferSessionApproval;
		$[10] = commandIdentifiers;
		$[11] = isWrite;
		$[12] = t7;
	} else t7 = $[12];
	const sessionLabel = t7;
	const showSessionOption = canOfferSessionApproval || isWrite;
	let choiceIndex = 1;
	let t8;
	if ($[13] !== detail || $[14] !== disabled || $[15] !== handleAllow || $[16] !== handleAllowSession || $[17] !== handleDeny || $[18] !== intention || $[19] !== label || $[20] !== sessionLabel || $[21] !== showSessionOption) {
		t8 = jsxs("div", {
			className: PermissionDisplay_module_default.standaloneContainer,
			children: [
				jsx("span", {
					className: clsx(PermissionDisplay_module_default.standaloneLabel, !intention && PermissionDisplay_module_default.standaloneLabelOnly),
					children: label
				}),
				intention && jsx("span", {
					className: PermissionDisplay_module_default.standaloneIntention,
					children: intention
				}),
				detail && jsx("div", {
					className: PermissionDisplay_module_default.standaloneDetail,
					children: detail
				}),
				jsxs(ChoiceButtonGroup, { children: [
					jsx(ChoiceButton, {
						number: choiceIndex++,
						label: "Allow",
						disabled,
						onClick: handleAllow
					}),
					showSessionOption && jsx(ChoiceButton, {
						number: choiceIndex++,
						label: jsx(InlineCode, {
							text: sessionLabel,
							codeClassName: PermissionDisplay_module_default.sessionLabelCode
						}),
						disabled,
						onClick: handleAllowSession
					}),
					jsx(ChoiceButton, {
						number: choiceIndex,
						label: "Deny",
						disabled,
						onClick: handleDeny
					})
				] })
			]
		});
		$[13] = detail;
		$[14] = disabled;
		$[15] = handleAllow;
		$[16] = handleAllowSession;
		$[17] = handleDeny;
		$[18] = intention;
		$[19] = label;
		$[20] = sessionLabel;
		$[21] = showSessionOption;
		$[22] = t8;
	} else t8 = $[22];
	return t8;
}
PermissionDisplay.displayName = "PermissionDisplay";
var PromptInput_module_default = {
	container: "PromptInput-module_6juszW_container",
	content: "PromptInput-module_6juszW_content",
	contentWrapper: "PromptInput-module_6juszW_contentWrapper",
	header: "PromptInput-module_6juszW_header",
	headerActions: "PromptInput-module_6juszW_headerActions",
	headerTitle: "PromptInput-module_6juszW_headerTitle"
};
var PROMPT_TITLES = {
	ask_user: "Question from agent",
	permission_request: "Permission requested",
	exit_plan_mode: "Plan ready for review"
};
/**
* Renders a CLI prompt (ask_user, permission_request, exit_plan_mode) in the chat input area.
* Wraps the existing display components and handles response callbacks.
*/
function PromptInput(t0) {
	const $ = c$1(21);
	const { prompt, onRespond, onDismiss } = t0;
	const [isExpanded, setIsExpanded] = useState(true);
	const [planDialogOpen, setPlanDialogOpen] = useState(false);
	const [hasResponded, setHasResponded] = useState(false);
	const { toolName, toolCallId, arguments: args } = prompt;
	const title = PROMPT_TITLES[toolName] ?? "Agent prompt";
	const isPlanPrompt = toolName === "exit_plan_mode";
	let t1;
	if ($[0] !== hasResponded || $[1] !== onRespond) {
		t1 = (id, response, commandType) => {
			if (hasResponded) return;
			setHasResponded(true);
			onRespond?.(id, response, commandType);
		};
		$[0] = hasResponded;
		$[1] = onRespond;
		$[2] = t1;
	} else t1 = $[2];
	const handleRespond = t1;
	let t2;
	if ($[3] !== hasResponded || $[4] !== onDismiss) {
		t2 = () => {
			if (hasResponded) return;
			setHasResponded(true);
			onDismiss?.();
		};
		$[3] = hasResponded;
		$[4] = onDismiss;
		$[5] = t2;
	} else t2 = $[5];
	const handleDismiss = t2;
	let t3;
	if ($[6] !== args || $[7] !== handleDismiss || $[8] !== handleRespond || $[9] !== hasResponded || $[10] !== planDialogOpen || $[11] !== toolCallId || $[12] !== toolName) {
		t3 = () => {
			switch (toolName) {
				case "ask_user": return jsx(AskUserPromptContent, {
					args,
					toolCallId,
					onRespond: handleRespond,
					onDismiss: handleDismiss,
					disabled: hasResponded
				});
				case "permission_request": return jsx(PermissionPromptContent, {
					args,
					toolCallId,
					onRespond: handleRespond,
					disabled: hasResponded
				});
				case "exit_plan_mode": return jsx(PlanApprovalPromptContent, {
					args,
					toolCallId,
					onRespond: handleRespond,
					dialogOpen: planDialogOpen,
					onDialogClose: () => setPlanDialogOpen(false),
					disabled: hasResponded
				});
				default: return null;
			}
		};
		$[6] = args;
		$[7] = handleDismiss;
		$[8] = handleRespond;
		$[9] = hasResponded;
		$[10] = planDialogOpen;
		$[11] = toolCallId;
		$[12] = toolName;
		$[13] = t3;
	} else t3 = $[13];
	const renderContent = t3;
	let t4;
	if ($[14] !== isExpanded || $[15] !== isPlanPrompt || $[16] !== renderContent || $[17] !== title) {
		let t5;
		if ($[19] !== isExpanded) {
			t5 = () => setIsExpanded(!isExpanded);
			$[19] = isExpanded;
			$[20] = t5;
		} else t5 = $[20];
		t4 = jsxs("div", {
			className: PromptInput_module_default.container,
			children: [jsxs("div", {
				className: PromptInput_module_default.header,
				children: [jsx("span", {
					className: PromptInput_module_default.headerTitle,
					children: title
				}), jsxs("div", {
					className: PromptInput_module_default.headerActions,
					children: [isPlanPrompt && jsx(IconButton, {
						icon: ScreenFullIcon,
						"aria-label": "View full plan",
						size: "small",
						variant: "invisible",
						onClick: () => setPlanDialogOpen(true)
					}), jsx(IconButton, {
						icon: isExpanded ? DashIcon : ChevronUpIcon,
						"aria-label": isExpanded ? "Minimize" : "Expand",
						size: "small",
						variant: "invisible",
						onClick: t5
					})]
				})]
			}), jsx("div", {
				className: PromptInput_module_default.contentWrapper,
				"data-expanded": isExpanded,
				children: jsx("div", {
					className: PromptInput_module_default.content,
					children: renderContent()
				})
			})]
		});
		$[14] = isExpanded;
		$[15] = isPlanPrompt;
		$[16] = renderContent;
		$[17] = title;
		$[18] = t4;
	} else t4 = $[18];
	return t4;
}
PromptInput.displayName = "PromptInput";
function AskUserPromptContent({ args, toolCallId, onRespond, onDismiss, disabled }) {
	if (isElicitationAskUser(args)) return /* @__PURE__ */ jsx(ElicitationAskUserPromptContent, {
		args,
		toolCallId,
		onRespond,
		disabled
	});
	return /* @__PURE__ */ jsx(SimpleAskUserPromptContent, {
		args,
		toolCallId,
		onRespond,
		onDismiss,
		disabled
	});
}
AskUserPromptContent.displayName = "AskUserPromptContent";
function SimpleAskUserPromptContent(t0) {
	const $ = c$1(12);
	const { args, toolCallId, onRespond, onDismiss, disabled } = t0;
	let t1;
	if ($[0] !== onRespond || $[1] !== toolCallId) {
		t1 = (choice) => {
			onRespond?.(toolCallId, {
				promptId: toolCallId,
				answer: choice,
				wasFreeform: false
			}, COMMAND_TYPES.ASK_USER_RESPONSE);
		};
		$[0] = onRespond;
		$[1] = toolCallId;
		$[2] = t1;
	} else t1 = $[2];
	const handleChoose = t1;
	let t2;
	if ($[3] !== onRespond || $[4] !== toolCallId) {
		t2 = (text) => {
			onRespond?.(toolCallId, {
				promptId: toolCallId,
				answer: text,
				wasFreeform: true
			}, COMMAND_TYPES.ASK_USER_RESPONSE);
		};
		$[3] = onRespond;
		$[4] = toolCallId;
		$[5] = t2;
	} else t2 = $[5];
	const handleFreeform = t2;
	let t3;
	if ($[6] !== args || $[7] !== disabled || $[8] !== handleChoose || $[9] !== handleFreeform || $[10] !== onDismiss) {
		t3 = jsx(SimpleAskUserDisplay, {
			question: args.question,
			choices: "choices" in args && args.choices ? args.choices : [],
			multiSelect: false,
			allowFreeform: args.allowFreeform ?? true,
			onChoose: handleChoose,
			onFreeform: handleFreeform,
			onSkip: onDismiss,
			disabled: disabled ?? false
		});
		$[6] = args;
		$[7] = disabled;
		$[8] = handleChoose;
		$[9] = handleFreeform;
		$[10] = onDismiss;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
SimpleAskUserPromptContent.displayName = "SimpleAskUserPromptContent";
function ElicitationAskUserPromptContent(t0) {
	const $ = c$1(12);
	const { args, toolCallId, onRespond, disabled } = t0;
	let t1;
	if ($[0] !== onRespond || $[1] !== toolCallId) {
		t1 = (content) => {
			onRespond?.(toolCallId, {
				promptId: toolCallId,
				action: "accept",
				content
			}, COMMAND_TYPES.ELICITATION_RESPONSE);
		};
		$[0] = onRespond;
		$[1] = toolCallId;
		$[2] = t1;
	} else t1 = $[2];
	const handleElicitationSubmit = t1;
	let t2;
	if ($[3] !== onRespond || $[4] !== toolCallId) {
		t2 = () => {
			onRespond?.(toolCallId, {
				promptId: toolCallId,
				action: "decline"
			}, COMMAND_TYPES.ELICITATION_RESPONSE);
		};
		$[3] = onRespond;
		$[4] = toolCallId;
		$[5] = t2;
	} else t2 = $[5];
	const handleDecline = t2;
	const t3 = disabled ?? false;
	let t4;
	if ($[6] !== args.message || $[7] !== args.requestedSchema || $[8] !== handleDecline || $[9] !== handleElicitationSubmit || $[10] !== t3) {
		t4 = jsx(ElicitationAskUserDisplay, {
			message: args.message,
			schema: args.requestedSchema,
			onElicitationSubmit: handleElicitationSubmit,
			onDecline: handleDecline,
			disabled: t3
		});
		$[6] = args.message;
		$[7] = args.requestedSchema;
		$[8] = handleDecline;
		$[9] = handleElicitationSubmit;
		$[10] = t3;
		$[11] = t4;
	} else t4 = $[11];
	return t4;
}
ElicitationAskUserPromptContent.displayName = "ElicitationAskUserPromptContent";
function PermissionPromptContent(t0) {
	const $ = c$1(10);
	const { args, toolCallId, onRespond, disabled } = t0;
	const { kind, toolName, description, command, filePath } = args;
	let t1;
	if ($[0] !== onRespond || $[1] !== toolCallId) {
		t1 = (approved, scope) => {
			onRespond?.(toolCallId, {
				promptId: toolCallId,
				approved,
				scope: scope ?? "once"
			}, COMMAND_TYPES.PERMISSION_RESPONSE);
		};
		$[0] = onRespond;
		$[1] = toolCallId;
		$[2] = t1;
	} else t1 = $[2];
	const handleRespond = t1;
	const detail = command || filePath;
	let t2;
	if ($[3] !== description || $[4] !== detail || $[5] !== disabled || $[6] !== handleRespond || $[7] !== kind || $[8] !== toolName) {
		t2 = jsx(PermissionDisplay, {
			kind,
			toolName,
			intention: description,
			detail,
			onRespond: handleRespond,
			disabled
		});
		$[3] = description;
		$[4] = detail;
		$[5] = disabled;
		$[6] = handleRespond;
		$[7] = kind;
		$[8] = toolName;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
PermissionPromptContent.displayName = "PermissionPromptContent";
function PlanApprovalPromptContent(t0) {
	const $ = c$1(15);
	const { args, toolCallId, onRespond, dialogOpen, onDialogClose, disabled } = t0;
	const { summary, actions: t1, recommendedAction } = args;
	let t2;
	if ($[0] !== dialogOpen || $[1] !== disabled || $[2] !== onDialogClose || $[3] !== onRespond || $[4] !== recommendedAction || $[5] !== summary || $[6] !== t1 || $[7] !== toolCallId) {
		const actions = t1 === void 0 ? [] : t1;
		let t3;
		if ($[9] !== onRespond || $[10] !== toolCallId) {
			t3 = (action) => {
				onRespond?.(toolCallId, {
					promptId: toolCallId,
					approved: true,
					selectedAction: action
				}, COMMAND_TYPES.PLAN_APPROVAL_RESPONSE);
			};
			$[9] = onRespond;
			$[10] = toolCallId;
			$[11] = t3;
		} else t3 = $[11];
		const handleAction = t3;
		let t4;
		if ($[12] !== onRespond || $[13] !== toolCallId) {
			t4 = (feedback) => {
				onRespond?.(toolCallId, {
					promptId: toolCallId,
					approved: false,
					feedback
				}, COMMAND_TYPES.PLAN_APPROVAL_RESPONSE);
			};
			$[12] = onRespond;
			$[13] = toolCallId;
			$[14] = t4;
		} else t4 = $[14];
		t2 = jsx(PlanApprovalDisplay, {
			summary,
			actions,
			recommendedAction,
			onAction: handleAction,
			onFeedback: t4,
			embedded: true,
			dialogOpen,
			onDialogClose,
			disabled
		});
		$[0] = dialogOpen;
		$[1] = disabled;
		$[2] = onDialogClose;
		$[3] = onRespond;
		$[4] = recommendedAction;
		$[5] = summary;
		$[6] = t1;
		$[7] = toolCallId;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
PlanApprovalPromptContent.displayName = "PlanApprovalPromptContent";
/**
* Hook that monitors a CLI session for pending prompts.
*/
function useCLIPromptState(t0) {
	const $ = c$1(12);
	const { sessionId, enabled } = t0;
	const [resolvedPromptIds, setResolvedPromptIds] = useState(_temp$12);
	const t1 = enabled && !!sessionId;
	let t2;
	if ($[0] !== sessionId || $[1] !== t1) {
		t2 = {
			sessionId,
			enabled: t1
		};
		$[0] = sessionId;
		$[1] = t1;
		$[2] = t2;
	} else t2 = $[2];
	const { data: logs, isLoading } = useLogsQuery(t2);
	const { pendingPrompt: detectedPrompt } = usePendingPrompt(logs);
	let t3;
	bb0: {
		if (!detectedPrompt) {
			t3 = null;
			break bb0;
		}
		if (resolvedPromptIds.has(detectedPrompt.toolCallId)) {
			t3 = null;
			break bb0;
		}
		t3 = detectedPrompt;
	}
	const pendingPrompt = t3;
	let t4;
	if ($[3] !== detectedPrompt) {
		t4 = () => {
			if (detectedPrompt) setResolvedPromptIds((prev) => new Set(prev).add(detectedPrompt.toolCallId));
		};
		$[3] = detectedPrompt;
		$[4] = t4;
	} else t4 = $[4];
	const markPromptResolved = t4;
	let t5;
	if ($[5] !== detectedPrompt) {
		t5 = () => {
			if (detectedPrompt) setResolvedPromptIds((prev_0) => new Set(prev_0).add(detectedPrompt.toolCallId));
		};
		$[5] = detectedPrompt;
		$[6] = t5;
	} else t5 = $[6];
	const dismissPrompt = t5;
	let t6;
	if ($[7] !== dismissPrompt || $[8] !== isLoading || $[9] !== markPromptResolved || $[10] !== pendingPrompt) {
		t6 = {
			pendingPrompt,
			isLoading,
			markPromptResolved,
			dismissPrompt
		};
		$[7] = dismissPrompt;
		$[8] = isLoading;
		$[9] = markPromptResolved;
		$[10] = pendingPrompt;
		$[11] = t6;
	} else t6 = $[11];
	return t6;
}
function _temp$12() {
	return /* @__PURE__ */ new Set();
}
/**
* Input component for CLI sessions.
* Shows PromptInput when there's a pending prompt, otherwise shows ChatInputDisplay.
* Handles both regular message submission and prompt response submission.
*/
function CLIChatInput({ sessionId, onCommandSent }) {
	const [value, setValue] = useState("");
	const isPromptResponseRef = useRef(false);
	const optimisticIdRef = useRef(null);
	const { pendingPrompt, isLoading, markPromptResolved, dismissPrompt } = useCLIPromptState({
		sessionId,
		enabled: true
	});
	const { addOptimisticResponse, removeOptimisticResponse } = useOptimisticLogs();
	const { createCommand, isPending } = useCreateCommand({
		onSuccess: () => {
			if (isPromptResponseRef.current) {
				markPromptResolved();
				isPromptResponseRef.current = false;
			}
			optimisticIdRef.current = null;
		},
		onError: () => {
			isPromptResponseRef.current = false;
			if (optimisticIdRef.current) {
				removeOptimisticResponse(optimisticIdRef.current);
				optimisticIdRef.current = null;
			}
		}
	});
	const handleSubmit = useCallback(() => {
		if (!value.trim() || isPending) return;
		createCommand({
			sessionId,
			content: value.trim()
		});
		setValue("");
		onCommandSent?.();
	}, [
		value,
		isPending,
		sessionId,
		createCommand,
		onCommandSent
	]);
	const handlePromptRespond = useCallback((toolCallId, response, commandType) => {
		if (!pendingPrompt || isPending) return;
		isPromptResponseRef.current = true;
		optimisticIdRef.current = addOptimisticResponse({
			toolCallId,
			response,
			commandType
		});
		createCommand({
			sessionId,
			content: JSON.stringify(response),
			type: commandType
		});
	}, [
		pendingPrompt,
		isPending,
		sessionId,
		createCommand,
		addOptimisticResponse
	]);
	if (isLoading) return /* @__PURE__ */ jsx("div", {
		className: ChatInputDisplay_module_default.container,
		children: /* @__PURE__ */ jsx("div", {
			className: ChatInputDisplay_module_default.skeletonWrapper,
			children: /* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				height: "100%",
				width: "100%"
			})
		})
	});
	if (pendingPrompt) return /* @__PURE__ */ jsx(PromptInput, {
		prompt: pendingPrompt,
		onRespond: handlePromptRespond,
		onDismiss: dismissPrompt
	}, pendingPrompt.toolCallId);
	return /* @__PURE__ */ jsx(ChatInputDisplay, {
		value,
		onChange: setValue,
		onSubmit: handleSubmit,
		placeholder: "Send a message to the CLI session...",
		isSubmitting: isPending
	});
}
CLIChatInput.displayName = "CLIChatInput";
function useStickToBottom(t0) {
	const $ = c$1(29);
	const { containerRef, sentinelRef, offset, scrollBehavior: t1, initialStickToBottom: t2, resetKey } = t0;
	const scrollBehavior = t1 === void 0 ? "instant" : t1;
	const initialStickToBottom = t2 === void 0 ? true : t2;
	const [isAtBottom, setIsAtBottom] = useState(initialStickToBottom);
	const hasScrolledRef = useRef(false);
	const isAtBottomRef = useRef(isAtBottom);
	let t3;
	let t4;
	if ($[0] !== isAtBottom) {
		t3 = () => {
			isAtBottomRef.current = isAtBottom;
		};
		t4 = [isAtBottom];
		$[0] = isAtBottom;
		$[1] = t3;
		$[2] = t4;
	} else {
		t3 = $[1];
		t4 = $[2];
	}
	useEffect(t3, t4);
	const [prevResetKey, setPrevResetKey] = useState(resetKey);
	if (resetKey !== void 0 && prevResetKey !== resetKey) {
		setPrevResetKey(resetKey);
		setIsAtBottom(initialStickToBottom);
	}
	let t5;
	if ($[3] !== containerRef || $[4] !== scrollBehavior) {
		t5 = {
			containerRef,
			behavior: scrollBehavior,
			smoothThreshold: 500
		};
		$[3] = containerRef;
		$[4] = scrollBehavior;
		$[5] = t5;
	} else t5 = $[5];
	const { scrollToBottom } = useScrollToBottom(t5);
	let t6;
	if ($[6] !== containerRef || $[7] !== sentinelRef) {
		t6 = () => {
			const container = containerRef?.current;
			if (!container) return {
				containerElement: null,
				contentElement: document.scrollingElement || document.documentElement
			};
			return {
				containerElement: container,
				contentElement: sentinelRef.current?.parentElement ?? container
			};
		};
		$[6] = containerRef;
		$[7] = sentinelRef;
		$[8] = t6;
	} else t6 = $[8];
	const getRootAndContent = t6;
	let t7;
	if ($[9] !== containerRef || $[10] !== initialStickToBottom) {
		t7 = () => {
			hasScrolledRef.current = false;
			isAtBottomRef.current = initialStickToBottom;
			const scrollElement = containerRef?.current || window;
			const handleScroll = () => {
				hasScrolledRef.current = true;
			};
			scrollElement.addEventListener("scroll", handleScroll, { once: true });
			return () => {
				scrollElement.removeEventListener("scroll", handleScroll);
			};
		};
		$[9] = containerRef;
		$[10] = initialStickToBottom;
		$[11] = t7;
	} else t7 = $[11];
	let t8;
	if ($[12] !== containerRef || $[13] !== initialStickToBottom || $[14] !== resetKey) {
		t8 = [
			containerRef,
			resetKey,
			initialStickToBottom
		];
		$[12] = containerRef;
		$[13] = initialStickToBottom;
		$[14] = resetKey;
		$[15] = t8;
	} else t8 = $[15];
	useEffect(t7, t8);
	let t10;
	let t9;
	if ($[16] !== getRootAndContent || $[17] !== offset || $[18] !== sentinelRef) {
		t9 = () => {
			const sentinel = sentinelRef.current;
			if (!sentinel) return;
			const { containerElement } = getRootAndContent();
			const io = new IntersectionObserver((entries) => {
				const entry = entries[0];
				if (entry) setIsAtBottom(entry.isIntersecting);
			}, {
				root: containerElement ?? null,
				rootMargin: `0px 0px ${offset}px 0px`,
				threshold: 0
			});
			io.observe(sentinel);
			return () => io.disconnect();
		};
		t10 = [
			offset,
			getRootAndContent,
			sentinelRef
		];
		$[16] = getRootAndContent;
		$[17] = offset;
		$[18] = sentinelRef;
		$[19] = t10;
		$[20] = t9;
	} else {
		t10 = $[19];
		t9 = $[20];
	}
	useEffect(t9, t10);
	let t11;
	let t12;
	if ($[21] !== getRootAndContent || $[22] !== initialStickToBottom || $[23] !== scrollToBottom) {
		t11 = () => {
			const { contentElement: contentElement_0 } = getRootAndContent();
			if (!contentElement_0) return;
			const ro = new ResizeObserver(() => {
				if (!hasScrolledRef.current && initialStickToBottom || hasScrolledRef.current && isAtBottomRef.current) scrollToBottom();
			});
			ro.observe(contentElement_0);
			return () => ro.disconnect();
		};
		t12 = [
			getRootAndContent,
			scrollToBottom,
			initialStickToBottom
		];
		$[21] = getRootAndContent;
		$[22] = initialStickToBottom;
		$[23] = scrollToBottom;
		$[24] = t11;
		$[25] = t12;
	} else {
		t11 = $[24];
		t12 = $[25];
	}
	useEffect(t11, t12);
	let t13;
	if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = (value) => {
			isAtBottomRef.current = value;
			setIsAtBottom(value);
		};
		$[26] = t13;
	} else t13 = $[26];
	let t14;
	if ($[27] !== isAtBottom) {
		t14 = {
			isAtBottom,
			setIsAtBottom: t13
		};
		$[27] = isAtBottom;
		$[28] = t14;
	} else t14 = $[28];
	return t14;
}
var DiffAddCommentButtonClickedEvent = class extends Event {
	endLineNumber;
	endOrientation;
	filePath;
	startOrientation;
	startLineNumber;
	constructor(lineRange, filePath) {
		super("DiffAddCommentButtonClickedEvent", {
			bubbles: true,
			cancelable: true,
			composed: true
		});
		this.startLineNumber = lineRange.startLineNumber;
		this.endLineNumber = lineRange.endLineNumber;
		this.startOrientation = lineRange.startOrientation;
		this.endOrientation = lineRange.endOrientation;
		this.filePath = filePath;
	}
};
var DiffSelectedLineEvent = class extends Event {
	endLineNumber;
	endOrientation;
	filePath;
	startOrientation;
	startLineNumber;
	constructor(lineRange, filePath) {
		super("DiffSelectedLineEvent", {
			bubbles: true,
			cancelable: true,
			composed: true
		});
		this.startLineNumber = lineRange.startLineNumber;
		this.endLineNumber = lineRange.endLineNumber;
		this.startOrientation = lineRange.startOrientation;
		this.endOrientation = lineRange.endOrientation;
		this.filePath = filePath;
	}
};
/**
* Custom hook to handle diff line selection events and populate the chat input.
* Listens for DiffAddCommentButtonClickedEvent and DiffSelectedLineEvent,
* formats the file path and line numbers, and appends them to the chat input.
* Debounces rapid events to only capture the final selection when highlighting ranges.
*/
function useDiffEventHandler(t0) {
	const $ = c$1(10);
	const { chatInputRef, textAreaRef, isReadonly, taskId } = t0;
	const debounceTimerRef = useRef(null);
	const lastEventRef = useRef(null);
	const formatLineRange = _temp$11;
	let t1;
	if ($[0] !== chatInputRef || $[1] !== textAreaRef) {
		t1 = (formattedText) => {
			if (chatInputRef.current) {
				chatInputRef.current.setText((prevText) => {
					if (prevText && prevText.trim()) return `${prevText}\n${formattedText}`;
					return formattedText;
				});
				textAreaRef?.current?.focus();
			}
		};
		$[0] = chatInputRef;
		$[1] = textAreaRef;
		$[2] = t1;
	} else t1 = $[2];
	const addToInput = t1;
	let t2;
	if ($[3] !== addToInput || $[4] !== isReadonly || $[5] !== taskId) {
		t2 = (event_0) => {
			if (event_0 instanceof DiffAddCommentButtonClickedEvent || event_0 instanceof DiffSelectedLineEvent) {
				if (isReadonly) return;
				sendEvent("agent_sessions.task_view", {
					target: "CREATE_COMMAND_DIFF_BUTTON",
					file_path: event_0.filePath,
					line_number: event_0.endLineNumber,
					has_range: event_0.startLineNumber !== event_0.endLineNumber,
					task_id: taskId
				});
				lastEventRef.current = event_0;
				if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
				debounceTimerRef.current = setTimeout(() => {
					if (lastEventRef.current) {
						addToInput(formatLineRange(lastEventRef.current));
						lastEventRef.current = null;
					}
				}, 300);
			}
		};
		$[3] = addToInput;
		$[4] = isReadonly;
		$[5] = taskId;
		$[6] = t2;
	} else t2 = $[6];
	const handleDiffEvent = t2;
	let t3;
	let t4;
	if ($[7] !== handleDiffEvent) {
		t3 = () => {
			window.addEventListener("DiffAddCommentButtonClickedEvent", handleDiffEvent);
			window.addEventListener("DiffSelectedLineEvent", handleDiffEvent);
			return () => {
				window.removeEventListener("DiffAddCommentButtonClickedEvent", handleDiffEvent);
				window.removeEventListener("DiffSelectedLineEvent", handleDiffEvent);
				if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
			};
		};
		t4 = [handleDiffEvent];
		$[7] = handleDiffEvent;
		$[8] = t3;
		$[9] = t4;
	} else {
		t3 = $[8];
		t4 = $[9];
	}
	useEffect(t3, t4);
}
function _temp$11(event) {
	const { filePath, startLineNumber, endLineNumber } = event;
	if (startLineNumber === endLineNumber || !startLineNumber) return `${filePath}:${endLineNumber}`;
	else return `${filePath}:${startLineNumber}-${endLineNumber}`;
}
var TaskChatHeader_module_default = {
	checkCircleIcon: "TaskChatHeader-module_4w60eG_checkCircleIcon",
	clockIcon: "TaskChatHeader-module_4w60eG_clockIcon",
	closedIcon: "TaskChatHeader-module_4w60eG_closedIcon",
	dotFillIcon: "TaskChatHeader-module_4w60eG_dotFillIcon",
	headerDescriptionContent: "TaskChatHeader-module_4w60eG_headerDescriptionContent",
	headerStatus: "TaskChatHeader-module_4w60eG_headerStatus",
	headerTitle: "TaskChatHeader-module_4w60eG_headerTitle",
	headerTitleArea: "TaskChatHeader-module_4w60eG_headerTitleArea",
	headerUser: "TaskChatHeader-module_4w60eG_headerUser",
	mergedIcon: "TaskChatHeader-module_4w60eG_mergedIcon",
	modelDisplay: "TaskChatHeader-module_4w60eG_modelDisplay",
	modelIcon: "TaskChatHeader-module_4w60eG_modelIcon",
	skipIcon: "TaskChatHeader-module_4w60eG_skipIcon",
	xCircleIcon: "TaskChatHeader-module_4w60eG_xCircleIcon"
};
var ratingOptions = [
	{
		name: "Hate it",
		value: "VERY_NEGATIVE",
		icon: frustratedIcon,
		color: "veryDissatisfied"
	},
	{
		name: "Not great",
		value: "NEGATIVE",
		icon: frownIcon,
		color: "dissatisfied"
	},
	{
		name: "It’s ok",
		value: "POSITIVE",
		icon: smileIcon,
		color: "satisfied"
	},
	{
		name: "Love it",
		value: "VERY_POSITIVE",
		icon: grinIcon,
		color: "verySatisfied"
	}
];
var useFeedbackDialog = (sessionId) => {
	return useFeedbackDialog$1(sessionId ? `task-header:session_id=${sessionId}` : "task-header", ratingOptions);
};
function FeedbackButton({ sessionId }) {
	const { openFeedback, FeedbackDialog } = useFeedbackDialog(sessionId);
	const buttonRef = useRef(null);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ButtonComponent$1, {
		ref: buttonRef,
		variant: "link",
		className: "f6",
		onClick: useCallback(() => openFeedback(), [openFeedback]),
		children: "Give feedback"
	}), /* @__PURE__ */ jsx(FeedbackDialog, { returnFocusRef: buttonRef })] });
}
FeedbackButton.displayName = "FeedbackButton";
function trimModelName(modelName) {
	return modelName.startsWith("sweagent-capi:") ? modelName.slice(SWEAGENT_CAPI_MODEL_PREFIX.length) : modelName;
}
var ArchiveDialogContext = React.createContext(void 0);
ArchiveDialogContext.displayName = "ArchiveDialogContext";
function ArchiveDialogProvider(t0) {
	const $ = c$1(9);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { isOpen: false };
		$[0] = t1;
	} else t1 = $[0];
	const [dialogState, setDialogState] = useState(t1);
	const [archiveStatus, setArchiveStatus] = useState("idle");
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (taskId, repoOwner, repoName) => {
			setDialogState({
				isOpen: true,
				taskId,
				repoOwner,
				repoName
			});
		};
		$[1] = t2;
	} else t2 = $[1];
	const openArchiveDialog = t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			setDialogState({ isOpen: false });
		};
		$[2] = t3;
	} else t3 = $[2];
	const closeArchiveDialog = t3;
	let t4;
	if ($[3] !== archiveStatus || $[4] !== dialogState) {
		t4 = {
			dialogState,
			archiveStatus,
			openArchiveDialog,
			closeArchiveDialog,
			setArchiveStatus
		};
		$[3] = archiveStatus;
		$[4] = dialogState;
		$[5] = t4;
	} else t4 = $[5];
	const value = t4;
	let t5;
	if ($[6] !== children || $[7] !== value) {
		t5 = jsx(ArchiveDialogContext, {
			value,
			children
		});
		$[6] = children;
		$[7] = value;
		$[8] = t5;
	} else t5 = $[8];
	return t5;
}
ArchiveDialogProvider.displayName = "ArchiveDialogProvider";
function useArchiveDialog() {
	const context = React.use(ArchiveDialogContext);
	if (!context) throw new Error("useArchiveDialog must be used within an ArchiveDialogProvider");
	return context;
}
function TaskActions({ state, taskId, pull, repoOwner, repoName, currentUserIsOwner, archivedAt, eventType, eventIdentifiers, hideCopy = false }) {
	const sessionCompleted = state && [
		SessionState.Completed,
		SessionState.Failed,
		SessionState.Cancelled
	].map((s) => s.toLowerCase()).includes(state);
	const isTaskPlanLinksEnabled = isFeatureEnabled("copilot_immersive_task_hyperlinking");
	const { openArchiveDialog } = useArchiveDialog();
	const { isUsingIntentDetection } = useIntentDetectionEnabled();
	const handleCopyLink = useCallback(async (event) => {
		try {
			const path = generateTaskPathForRepo({
				repositoryNwo: `${repoOwner}/${repoName}`,
				pullRequestNumber: pull?.number,
				taskId,
				isUsingIntentDetection
			});
			await copyText(`${window.location.origin}${path}`);
			sendEvent("agent_sessions.task_actions", {
				target: "COPY_TASK_LINK",
				task_id: taskId ?? pull?.global_relay_id
			});
		} catch {
			event.preventDefault();
			event.stopPropagation();
		}
	}, [
		repoOwner,
		repoName,
		taskId,
		pull,
		isUsingIntentDetection
	]);
	const handleViewPullRequest = () => {
		sendEvent("dotcom_chat.activate", {
			target: "TASK_ACTION_VIEW_PR",
			mode: "immersive"
		});
	};
	const handleGoToConversation = () => {
		sendEvent("dotcom_chat.activate", {
			target: "TASK_ACTION_GO_TO_CONVERSATION",
			mode: "immersive"
		});
	};
	const conversationThreadId = extractSpecTaskThreadIdFromEventIdentifiers(eventIdentifiers);
	const conversationHref = conversationThreadId ? `/copilot/c/${conversationThreadId}` : void 0;
	const hasConversationAction = eventType === "copilot-chat-spec-task" && isTaskPlanLinksEnabled;
	return /* @__PURE__ */ jsxs(ActionList, { children: [
		!hideCopy && repoOwner && repoName && /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: handleCopyLink,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CopyIcon, {}) }), "Copy link"]
		}),
		pull?.url && /* @__PURE__ */ jsxs(ActionList.LinkItem, {
			href: pull.url,
			onClick: handleViewPullRequest,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitPullRequestIcon, {}) }), "View pull request"]
		}),
		hasConversationAction && conversationHref && /* @__PURE__ */ jsxs(ActionList.LinkItem, {
			href: conversationHref,
			onClick: handleGoToConversation,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CommentDiscussionIcon, {}) }), "Go to parent conversation"]
		}),
		sessionCompleted && !archivedAt && taskId && repoOwner && repoName && currentUserIsOwner && /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: async () => {
				openArchiveDialog(taskId, repoOwner, repoName);
			},
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ArchiveIcon, {}) }), "Archive session"]
		})
	] });
}
TaskActions.displayName = "TaskActions";
var Icon_module_default = {
	auburn: "Icon-module_XZpmTG_auburn",
	blue: "Icon-module_XZpmTG_blue",
	brown: "Icon-module_XZpmTG_brown",
	container: "Icon-module_XZpmTG_container",
	coral: "Icon-module_XZpmTG_coral",
	customColor: "Icon-module_XZpmTG_customColor",
	cyan: "Icon-module_XZpmTG_cyan",
	gray: "Icon-module_XZpmTG_gray",
	green: "Icon-module_XZpmTG_green",
	hasBackground: "Icon-module_XZpmTG_hasBackground",
	indigo: "Icon-module_XZpmTG_indigo",
	lemon: "Icon-module_XZpmTG_lemon",
	lime: "Icon-module_XZpmTG_lime",
	olive: "Icon-module_XZpmTG_olive",
	orange: "Icon-module_XZpmTG_orange",
	pine: "Icon-module_XZpmTG_pine",
	pink: "Icon-module_XZpmTG_pink",
	plum: "Icon-module_XZpmTG_plum",
	purple: "Icon-module_XZpmTG_purple",
	red: "Icon-module_XZpmTG_red",
	teal: "Icon-module_XZpmTG_teal",
	yellow: "Icon-module_XZpmTG_yellow"
};
var predefinedColors = new Set(Object.keys(Icon_module_default).filter((key) => ![
	"container",
	"hasBackground",
	"customColor"
].includes(key)));
var isIconName = (name) => name in index_esm_exports;
/** Get the `Icon` component for a kebab-case icon name. */
function getIcon(icon) {
	const iconName = `${icon.replaceAll(/(?:^|-)(\w)/g, (_, letter) => letter.toUpperCase())}Icon`;
	return isIconName(iconName) ? index_esm_exports[iconName] : void 0;
}
function Icon({ icon, hasBackground = false, color = "gray", size = 16, className }) {
	let IconComponent;
	if (typeof icon === "string") if (icon in iconMapping) IconComponent = iconMapping[icon];
	else IconComponent = getIcon(icon);
	else IconComponent = icon;
	if (!IconComponent) return null;
	const isPredefined = predefinedColors.has(color);
	const containerStyle = { "--custom-size": `${hasBackground ? size * 2 : size}px` };
	if (!isPredefined) containerStyle["--custom-color"] = color;
	return /* @__PURE__ */ jsx("div", {
		style: containerStyle,
		className: clsx(Icon_module_default.container, isPredefined ? Icon_module_default[color] : Icon_module_default.customColor, hasBackground && Icon_module_default.hasBackground, className),
		children: /* @__PURE__ */ jsx(IconComponent, {
			size,
			fill: "currentColor"
		})
	});
}
Icon.displayName = "Icon";
/**
* Build the GitHub Desktop URL for a pull request.
* Uses the x-github-client protocol to open GitHub Desktop directly
* Better solution might be pulling down the actual Desktop URL: /workspaces/github/app/helpers/desktop_helper.rb
*/
function buildGitHubDesktopPullRequestUrl(repositoryNwo, pullNumber) {
	return `x-github-client://openRepo/${ssrSafeWindow?.location.origin || "https://github.com"}/${repositoryNwo}?pr=${pullNumber}`;
}
/**
* Build the GitHub Desktop URL for a branch. Returns undefined if window origin is not available.
*/
function buildGitHubDesktopBranchUrl(repositoryNwo, branchName) {
	const origin = ssrSafeWindow?.location.origin;
	return origin ? `x-github-client://openRepo/${origin}/${repositoryNwo}?branch=${branchName}` : void 0;
}
var OpenInMenu_module_default = {
	cliDescription: "OpenInMenu-module_fwT-Aa_cliDescription",
	cliHeader: "OpenInMenu-module_fwT-Aa_cliHeader",
	cliSection: "OpenInMenu-module_fwT-Aa_cliSection"
};
function attemptOpenUrlWithFallback(url, repositoryNwo) {
	const command = `git clone https://github.com/${repositoryNwo}.git && code ${repositoryNwo.split("/")[1]}`;
	window.open(url, "_self");
	if (navigator.clipboard) navigator.clipboard.writeText(command);
}
function buildVSCodeAgentSessionUrl(protocol, repositoryNwo, globalId, headRefName) {
	const repoUrl = `https://github.com/${repositoryNwo}.git`;
	return `${protocol}://GitHub.copilot-chat/openAgentSession?id=${globalId}&type=copilot&url=${encodeURIComponent(repoUrl)}&branch=${encodeURIComponent(headRefName)}`;
}
var createHandleOpenInVSCode = (repositoryNwo, globalId, headRefName) => () => {
	attemptOpenUrlWithFallback(buildVSCodeAgentSessionUrl("vscode", repositoryNwo, globalId, headRefName), repositoryNwo);
};
var createHandleOpenInVSCodeInsiders = (repositoryNwo, globalId, headRefName) => () => {
	attemptOpenUrlWithFallback(buildVSCodeAgentSessionUrl("vscode-insiders", repositoryNwo, globalId, headRefName), repositoryNwo);
};
var createHandleOpenInGitHubDesktop = (repositoryNwo, pullNumber) => () => {
	attemptOpenUrlWithFallback(buildGitHubDesktopPullRequestUrl(repositoryNwo, pullNumber), repositoryNwo);
};
var createHandleOpenInCodespaces = (repositoryId, pullRequestId, headRefName) => () => {
	const codespacesPath = buildCodespacesPath(repositoryId, headRefName, {
		currentBranchName: headRefName,
		pullRequestId
	});
	if (codespacesPath) window.open(codespacesPath, "_self");
};
function OpenInMenu({ pull, session }) {
	const openAgentSessionInVSCodeInsiders = isFeatureEnabled("open_agent_session_in_vscode_insiders");
	const openAgentSessionInVSCodeStable = isFeatureEnabled("open_agent_session_in_vscode_stable");
	const handleOpenInVSCode = createHandleOpenInVSCode(pull.repository_nwo, pull.global_relay_id, pull.head_ref_name);
	const handleOpenInVSCodeInsiders = createHandleOpenInVSCodeInsiders(pull.repository_nwo, pull.global_relay_id, pull.head_ref_name);
	const handleOpenInGitHubDesktop = createHandleOpenInGitHubDesktop(pull.repository_nwo, pull.number);
	const codespacesPath = buildCodespacesPath(pull.repository_id, pull.head_ref_name, {
		currentBranchName: pull.head_ref_name,
		pullRequestId: pull.id
	});
	const isEnterpriseMode = isEnterprise();
	const shouldShowCodespacesTab = !!codespacesPath;
	const isSessionActive = session ? isActiveSession(session) : false;
	return /* @__PURE__ */ jsx(CodeDropdownButton, {
		primary: false,
		size: "small",
		isEnterprise: isEnterpriseMode,
		showCodespacesTab: shouldShowCodespacesTab,
		codespacesPath,
		refName: pull.head_ref_name,
		currentBranchName: pull.head_ref_name,
		createRef: pull.head_ref_name,
		localTab: /* @__PURE__ */ jsx(CustomLocalTab, {
			pullURL: pull.url,
			pullGlobalRelayID: pull.global_relay_id,
			onOpenInVSCode: handleOpenInVSCode,
			onOpenInVSCodeInsiders: handleOpenInVSCodeInsiders,
			onOpenInGitHubDesktop: handleOpenInGitHubDesktop,
			showVSCodeStable: openAgentSessionInVSCodeStable,
			showVSCodeInsiders: openAgentSessionInVSCodeInsiders,
			isSessionActive,
			sessionId: session?.id
		})
	});
}
OpenInMenu.displayName = "OpenInMenu";
function CustomLocalTab({ pullURL, pullGlobalRelayID, onOpenInVSCode, onOpenInVSCodeInsiders, onOpenInGitHubDesktop, showVSCodeInsiders, showVSCodeStable, isSessionActive, sessionId }) {
	const ghCommand = `gh agent-task view ${sessionId || pullURL} --log${isSessionActive ? " --follow" : ""}`;
	const copilotCLICommand = `copilot --resume=${pullGlobalRelayID}`;
	return /* @__PURE__ */ jsxs(ActionList, { children: [
		showVSCodeStable && /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: onOpenInVSCode,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(VscodeIcon, {}) }), "Open in VS Code"]
		}) }),
		showVSCodeInsiders && /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: onOpenInVSCodeInsiders,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(VscodeIcon, {}) }), "Open in VS Code Insiders"]
		}),
		/* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: onOpenInGitHubDesktop,
			children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(DesktopDownloadIcon, {}) }), "Open with GitHub Desktop"]
		}),
		/* @__PURE__ */ jsx(ActionList.Divider, {}),
		/* @__PURE__ */ jsx(CLICommandListItem, {
			toolName: "GitHub CLI",
			buttonAriaLabel: "Copy GitHub agent-task command to clipboard",
			inputId: "github-cli",
			command: ghCommand,
			additionalInfo: /* @__PURE__ */ jsxs(Fragment$1, { children: [
				"Work fast with our official CLI.",
				" ",
				/* @__PURE__ */ jsxs(Link, {
					inline: true,
					href: "https://cli.github.com",
					target: "_blank",
					rel: "noopener noreferrer",
					children: ["Learn more", /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: " about the GitHub CLI"
					})]
				})
			] })
		}),
		isFeatureEnabled("mission_control_show_copilot_cli_handoff_command") && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsx(CLICommandListItem, {
			toolName: "Copilot CLI",
			buttonAriaLabel: "Copy Copilot CLI command to clipboard",
			inputId: "copilot-cli",
			command: copilotCLICommand,
			additionalInfo: /* @__PURE__ */ jsxs(Fragment$1, { children: [
				"Automate coding tasks with Copilot CLI.",
				" ",
				/* @__PURE__ */ jsxs(Link, {
					inline: true,
					href: "https://github.com/features/copilot/cli",
					target: "_blank",
					rel: "noopener noreferrer",
					children: ["Learn more", /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: " about the Copilot CLI"
					})]
				})
			] })
		})] })
	] });
}
CustomLocalTab.displayName = "CustomLocalTab";
function CLICommandListItem({ toolName, buttonAriaLabel, inputId, command, additionalInfo }) {
	return /* @__PURE__ */ jsx("ul", { children: /* @__PURE__ */ jsxs("li", {
		className: OpenInMenu_module_default.cliSection,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: OpenInMenu_module_default.cliHeader,
				children: [/* @__PURE__ */ jsx(TerminalIcon, { className: "fgColor-muted" }), /* @__PURE__ */ jsx("span", { children: toolName })]
			}),
			/* @__PURE__ */ jsx(CloneUrl, {
				buttonAriaLabel,
				inputId,
				inputLabel: `${toolName} command`,
				url: command
			}),
			additionalInfo && /* @__PURE__ */ jsx("p", {
				className: "text-small fgColor-muted mb-0",
				children: additionalInfo
			})
		]
	}) });
}
CLICommandListItem.displayName = "CLICommandListItem";
var OpenInMenuV2_module_default = {
	cliDescription: "OpenInMenuV2-module_PIiu5q_cliDescription",
	dropdownIcon: "OpenInMenuV2-module_PIiu5q_dropdownIcon",
	overlay: "OpenInMenuV2-module_PIiu5q_overlay"
};
function OpenInMenuV2(t0) {
	const $ = c$1(40);
	const { pull, branchName, className, taskId, isCurrentUserTaskCreator } = t0;
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== branchName || $[1] !== pull || $[2] !== taskId) {
		t1 = () => {
			if (!pull) return null;
			const handleOpenInVSCode = createHandleOpenInVSCode(pull.repository_nwo, pull.global_relay_id, pull.head_ref_name);
			return jsx(ButtonComponent$1, {
				onClick: () => {
					sendEvent("repo_agents", {
						target: "open_in_vscode",
						task_id: taskId,
						pull_id: pull.global_relay_id,
						branch_name: branchName
					});
					handleOpenInVSCode();
				},
				leadingVisual: jsx(VscodeIcon, { className: "hide-sm" }),
				size: "small",
				children: "Open in VS Code"
			});
		};
		$[0] = branchName;
		$[1] = pull;
		$[2] = taskId;
		$[3] = t1;
	} else t1 = $[3];
	const getOpenInVSCodeButton = t1;
	let t2;
	if ($[4] !== pull) {
		t2 = () => {
			if (pull) return jsx(ActionMenu.Button, {
				size: "small",
				"aria-label": "More options",
				icon: jsx(TriangleDownIcon, { className: OpenInMenuV2_module_default.dropdownIcon })
			});
			return jsx(ActionMenu.Button, {
				leadingVisual: jsx(CodeIcon, { className: "hide-sm" }),
				size: "small",
				"aria-label": "More options",
				children: "Code"
			});
		};
		$[4] = pull;
		$[5] = t2;
	} else t2 = $[5];
	const getActionMenuButton = t2;
	let t3;
	if ($[6] !== branchName || $[7] !== pull || $[8] !== taskId) {
		t3 = () => {
			if (!pull) return null;
			const handleOpenInVSCodeInsiders = createHandleOpenInVSCodeInsiders(pull.repository_nwo, pull.global_relay_id, pull.head_ref_name);
			return jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("repo_agents", {
						target: "open_in_vscode_insiders",
						task_id: taskId,
						pull_id: pull.global_relay_id,
						branch_name: branchName
					});
					handleOpenInVSCodeInsiders();
				},
				children: [jsx(ActionList.LeadingVisual, { children: jsx(VscodeIcon, { size: 16 }) }), "Open in VS Code Insiders"]
			});
		};
		$[6] = branchName;
		$[7] = pull;
		$[8] = taskId;
		$[9] = t3;
	} else t3 = $[9];
	const getOpenInVSCodeInsidersItem = t3;
	let t4;
	if ($[10] !== isCurrentUserTaskCreator || $[11] !== pull?.global_relay_id || $[12] !== taskId) {
		t4 = () => {
			const disableCLIResume = isFeatureEnabled("copilot_mc_cli_resume_any_users_task") && !isCurrentUserTaskCreator;
			const cliResumeWithTaskId = isFeatureEnabled("copilot_mission_control_cli_resume_with_task_id");
			const resumeTarget = pull?.global_relay_id ?? (cliResumeWithTaskId ? taskId : void 0);
			if (!resumeTarget) return null;
			const cliCommand = `copilot --resume=${resumeTarget}`;
			return jsxs(Fragment$1, { children: [jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("repo_agents", {
						target: "continue_in_copilot_cli",
						task_id: taskId,
						pull_id: pull?.global_relay_id
					});
					copyText(cliCommand);
				},
				disabled: disableCLIResume,
				inactiveText: disableCLIResume ? "Only session creator can resume" : void 0,
				children: [
					jsx(ActionList.LeadingVisual, { children: jsx(AgentIcon, {}) }),
					"Continue in Copilot CLI",
					!disableCLIResume ? jsx(ActionList.Description, {
						className: OpenInMenuV2_module_default.cliDescription,
						variant: "block",
						children: cliCommand
					}) : null,
					jsx(ActionList.TrailingVisual, { children: jsx(CopyIcon, { size: 16 }) })
				]
			}), jsx(ActionList.Divider, {})] });
		};
		$[10] = isCurrentUserTaskCreator;
		$[11] = pull?.global_relay_id;
		$[12] = taskId;
		$[13] = t4;
	} else t4 = $[13];
	const getContinueInCopilotCLIItem = t4;
	let t5;
	if ($[14] !== branchName || $[15] !== pull?.global_relay_id || $[16] !== taskId) {
		t5 = () => jsxs(ActionList.Item, {
			onSelect: () => {
				sendEvent("repo_agents", {
					target: "checkout_with_github_cli",
					task_id: taskId,
					pull_id: pull?.global_relay_id
				});
				copyText(`gh pr checkout ${branchName}`);
			},
			children: [
				jsx(ActionList.LeadingVisual, { children: jsx(TerminalIcon, { size: 16 }) }),
				"Checkout with GitHub CLI",
				jsx(ActionList.TrailingVisual, { children: jsx(CopyIcon, { size: 16 }) })
			]
		});
		$[14] = branchName;
		$[15] = pull?.global_relay_id;
		$[16] = taskId;
		$[17] = t5;
	} else t5 = $[17];
	const getCheckoutWithGitHubCLIItem = t5;
	let t6;
	if ($[18] !== branchName || $[19] !== pull?.global_relay_id || $[20] !== repo || $[21] !== taskId) {
		t6 = () => {
			if (!repo) return null;
			const createCodespacePath = `/codespaces/new?skip_quickstart=true&repo=${repo.id}&ref=${encodeURIComponent(branchName)}`;
			return jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("repo_agents", {
						target: "create_codespace",
						task_id: taskId,
						pull_id: pull?.global_relay_id,
						repo_id: repo.id.toString()
					});
					window.open(createCodespacePath, "_self");
				},
				children: [jsx(ActionList.LeadingVisual, { children: jsx(CodespacesIcon, { size: 16 }) }), "Create a codespace"]
			});
		};
		$[18] = branchName;
		$[19] = pull?.global_relay_id;
		$[20] = repo;
		$[21] = taskId;
		$[22] = t6;
	} else t6 = $[22];
	const getCreateCodespaceItem = t6;
	let t7;
	if ($[23] !== branchName || $[24] !== pull?.global_relay_id || $[25] !== repo || $[26] !== taskId) {
		t7 = () => {
			if (!repo) return null;
			const repoNwo = `${repo.ownerLogin}/${repo.name}`;
			const desktopUrl = buildGitHubDesktopBranchUrl(repoNwo, branchName);
			if (!desktopUrl) return null;
			return jsxs(ActionList.Item, {
				onSelect: () => {
					sendEvent("repo_agents", {
						target: "checkout_with_github_desktop",
						task_id: taskId,
						pull_id: pull?.global_relay_id,
						repo_nwo: repoNwo
					});
					attemptOpenUrlWithFallback(desktopUrl, repoNwo);
				},
				children: [jsx(ActionList.LeadingVisual, { children: jsx(DesktopDownloadIcon, { size: 16 }) }), "Checkout with GitHub Desktop"]
			});
		};
		$[23] = branchName;
		$[24] = pull?.global_relay_id;
		$[25] = repo;
		$[26] = taskId;
		$[27] = t7;
	} else t7 = $[27];
	const getCheckoutWithGitHubDesktopItem = t7;
	let t8;
	if ($[28] !== getActionMenuButton || $[29] !== getCheckoutWithGitHubCLIItem || $[30] !== getCheckoutWithGitHubDesktopItem || $[31] !== getContinueInCopilotCLIItem || $[32] !== getCreateCodespaceItem || $[33] !== getOpenInVSCodeInsidersItem) {
		t8 = () => jsxs(ActionMenu, { children: [getActionMenuButton(), jsx(ActionMenu.Overlay, {
			className: OpenInMenuV2_module_default.overlay,
			align: "end",
			side: "outside-bottom",
			children: jsxs(ActionList, { children: [
				getContinueInCopilotCLIItem(),
				getOpenInVSCodeInsidersItem(),
				getCheckoutWithGitHubCLIItem(),
				getCreateCodespaceItem(),
				getCheckoutWithGitHubDesktopItem()
			] })
		})] });
		$[28] = getActionMenuButton;
		$[29] = getCheckoutWithGitHubCLIItem;
		$[30] = getCheckoutWithGitHubDesktopItem;
		$[31] = getContinueInCopilotCLIItem;
		$[32] = getCreateCodespaceItem;
		$[33] = getOpenInVSCodeInsidersItem;
		$[34] = t8;
	} else t8 = $[34];
	const getActionMenu = t8;
	let t9;
	if ($[35] !== className || $[36] !== getActionMenu || $[37] !== getOpenInVSCodeButton || $[38] !== pull) {
		t9 = jsx("div", {
			className,
			children: pull ? jsxs(ButtonGroup, { children: [getOpenInVSCodeButton(), getActionMenu()] }) : getActionMenu()
		});
		$[35] = className;
		$[36] = getActionMenu;
		$[37] = getOpenInVSCodeButton;
		$[38] = pull;
		$[39] = t9;
	} else t9 = $[39];
	return t9;
}
OpenInMenuV2.displayName = "OpenInMenuV2";
function TaskChatHeader(t0) {
	const $ = c$1(14);
	const { sessions, sessionOwners, pull, task, repoOwner, repoName, branchName } = t0;
	const mostRecentSession = sessions[sessions.length - 1];
	const firstSession = sessions[0];
	const taskCreatedAt = sessions.length > 0 ? firstSession?.created_at : null;
	const premiumRequests = sessions.reduce(_temp$10, 0);
	const taskOwnerLogin = sessionOwners.find((owner) => owner.id === firstSession?.user_id)?.login ?? "Unknown";
	const modelId = mostRecentSession?.model;
	const { data: agentInfo } = useAgentInfo(mostRecentSession?.agent_id ?? null);
	const { models: agentModels } = useAgentModels();
	const availableModels = copilotFeatureFlags.codingAgentModelSelection ? agentModels : void 0;
	const isCopilotAgent = isCopilotCodingAgent(agentInfo?.slug);
	const selectedModel = modelId && availableModels && isCopilotAgent ? availableModels.find((m) => m.id === trimModelName(modelId)) : void 0;
	const { currentUser, optedInToFeedback } = useCurrentUser$1();
	const currentUserIsOwner = currentUser?.id === firstSession?.user_id;
	const effectiveBranchName = branchName || getBranchArtifactData(task?.artifacts)?.head_ref || pull?.head_ref_name || "";
	const t1 = mostRecentSession ?? null;
	let t2;
	if ($[0] !== t1) {
		t2 = isCLISession(t1);
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const isCLI = t2;
	pull?.state;
	pull?.inMergeQueue;
	mostRecentSession?.state;
	task?.archived_at;
	const t3 = pull?.state;
	const t4 = pull?.inMergeQueue;
	const t5 = mostRecentSession?.state;
	const t6 = !!task?.archived_at;
	let t7;
	if ($[2] !== isCLI || $[3] !== t3 || $[4] !== t4 || $[5] !== t5 || $[6] !== t6) {
		t7 = getLeadingVisualIconAttributes(t3, t4, t5, t6, isCLI);
		$[2] = isCLI;
		$[3] = t3;
		$[4] = t4;
		$[5] = t5;
		$[6] = t6;
		$[7] = t7;
	} else t7 = $[7];
	const iconAttributes = t7;
	const { isUsingIntentDetection } = useIntentDetectionEnabled();
	let t8;
	if ($[8] !== isUsingIntentDetection || $[9] !== pull?.number || $[10] !== repoName || $[11] !== repoOwner || $[12] !== task?.id) {
		t8 = () => {
			if (!repoOwner || !repoName) return "";
			const path = generateTaskPathForRepo({
				repositoryNwo: `${repoOwner}/${repoName}`,
				pullRequestNumber: pull?.number,
				taskId: task?.id,
				isUsingIntentDetection
			});
			return `${window.location.origin}${path}`;
		};
		$[8] = isUsingIntentDetection;
		$[9] = pull?.number;
		$[10] = repoName;
		$[11] = repoOwner;
		$[12] = task?.id;
		$[13] = t8;
	} else t8 = $[13];
	pull?.number;
	task?.id;
	const taskUrl = t8();
	const getTaskAuthorLogin = () => {
		if (currentUserIsOwner) return "You";
		return taskOwnerLogin;
	};
	return jsxs(PageHeader$1, {
		"aria-label": "Agent session header",
		children: [
			jsx(PageHeader$1.TitleArea, {
				className: TaskChatHeader_module_default.headerTitleArea,
				children: jsx(PageHeader$1.Title, {
					as: "h1",
					className: TaskChatHeader_module_default.headerTitle,
					children: getTaskTitle(task, pull?.title)
				})
			}),
			jsx(PageHeader$1.Description, { children: jsx("div", {
				className: TaskChatHeader_module_default.headerDescriptionContent,
				children: jsxs("div", {
					className: TaskChatHeader_module_default.headerStatus,
					children: [
						jsx(Icon, {
							icon: iconAttributes.icon,
							color: iconAttributes.color
						}),
						jsx("span", {
							className: TaskChatHeader_module_default.headerUser,
							children: getTaskAuthorLogin()
						}),
						jsx("span", { children: "created the session" }),
						taskCreatedAt && jsx(RelativeTime, {
							date: new Date(taskCreatedAt),
							tense: "past"
						}),
						jsx("span", { children: " · " }),
						selectedModel && jsxs("span", {
							className: TaskChatHeader_module_default.modelDisplay,
							children: [selectedModel.logoURL ? jsx(GitHubAvatar, {
								alt: `${selectedModel.vendor} logo`,
								square: true,
								size: 18,
								src: selectedModel.logoURL,
								className: TaskChatHeader_module_default.modelIcon
							}) : jsx(CopilotIcon, { className: TaskChatHeader_module_default.modelIcon }), jsxs("span", { children: [selectedModel.displayName, " · "] })]
						}),
						jsxs("span", { children: [
							sessions.length,
							" ",
							(0, import_pluralize.default)("session", sessions.length)
						] }),
						premiumRequests > 0 && jsxs("span", { children: [
							" · ",
							premiumRequests,
							" ",
							(0, import_pluralize.default)("premium request", premiumRequests)
						] })
					]
				})
			}) }),
			jsxs(PageHeader$1.Actions, { children: [
				optedInToFeedback && jsx(FeedbackButton, { sessionId: mostRecentSession?.id }),
				repoOwner && repoName && !isCLI && jsx(CopyToClipboardButton, {
					textToCopy: taskUrl,
					ariaLabel: "Copy session link",
					icon: CopyIcon,
					tooltipProps: { direction: "s" }
				}),
				jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
					icon: KebabHorizontalIcon,
					variant: "invisible",
					"aria-label": "More actions"
				}) }), jsx(ActionMenu.Overlay, {
					align: "end",
					children: jsx(TaskActions, {
						state: mostRecentSession?.state,
						taskId: task?.id,
						repoOwner,
						repoName,
						currentUserIsOwner,
						archivedAt: task?.archived_at,
						eventType: firstSession?.event_type,
						eventIdentifiers: firstSession?.event_identifiers,
						pull,
						hideCopy: true
					})
				})] }),
				effectiveBranchName && jsx(OpenInMenuV2, {
					branchName: effectiveBranchName,
					pull,
					taskId: task?.id,
					isCurrentUserTaskCreator: currentUserIsOwner
				})
			] })
		]
	});
}
TaskChatHeader.displayName = "TaskChatHeader";
function _temp$10(total, session) {
	return total + (session.premium_requests || 0);
}
var TaskChatInputV2_module_default = {
	blockedContainer: "TaskChatInputV2-module_lW8CWG_blockedContainer",
	blockedContent: "TaskChatInputV2-module_lW8CWG_blockedContent",
	blockedIcon: "TaskChatInputV2-module_lW8CWG_blockedIcon",
	blockedText: "TaskChatInputV2-module_lW8CWG_blockedText",
	container: "TaskChatInputV2-module_lW8CWG_container",
	input: "TaskChatInputV2-module_lW8CWG_input",
	inputContainer: "TaskChatInputV2-module_lW8CWG_inputContainer",
	inputFocused: "TaskChatInputV2-module_lW8CWG_inputFocused",
	inputToolbar: "TaskChatInputV2-module_lW8CWG_inputToolbar",
	inputWrapper: "TaskChatInputV2-module_lW8CWG_inputWrapper",
	inputWrapperWithToolbar: "TaskChatInputV2-module_lW8CWG_inputWrapperWithToolbar",
	isDraggedOver: "TaskChatInputV2-module_lW8CWG_isDraggedOver",
	modeAndButtonContainer: "TaskChatInputV2-module_lW8CWG_modeAndButtonContainer",
	modeSelector: "TaskChatInputV2-module_lW8CWG_modeSelector",
	sendButton: "TaskChatInputV2-module_lW8CWG_sendButton",
	withImageUpload: "TaskChatInputV2-module_lW8CWG_withImageUpload"
};
var TaskChatInputHeader_module_default = {
	actions: "TaskChatInputHeader-module_X7Ugcq_actions",
	additions: "TaskChatInputHeader-module_X7Ugcq_additions",
	branch: "TaskChatInputHeader-module_X7Ugcq_branch",
	branchText: "TaskChatInputHeader-module_X7Ugcq_branchText",
	container: "TaskChatInputHeader-module_X7Ugcq_container",
	copyIcon: "TaskChatInputHeader-module_X7Ugcq_copyIcon",
	deletions: "TaskChatInputHeader-module_X7Ugcq_deletions",
	diffContainer: "TaskChatInputHeader-module_X7Ugcq_diffContainer",
	diffItem: "TaskChatInputHeader-module_X7Ugcq_diffItem",
	diffList: "TaskChatInputHeader-module_X7Ugcq_diffList",
	diffStatAdded: "TaskChatInputHeader-module_X7Ugcq_diffStatAdded",
	diffStatDeleted: "TaskChatInputHeader-module_X7Ugcq_diffStatDeleted",
	diffStatsContainer: "TaskChatInputHeader-module_X7Ugcq_diffStatsContainer",
	fileAdded: "TaskChatInputHeader-module_X7Ugcq_fileAdded",
	fileChanged: "TaskChatInputHeader-module_X7Ugcq_fileChanged",
	fileDeleted: "TaskChatInputHeader-module_X7Ugcq_fileDeleted",
	fileDirectory: "TaskChatInputHeader-module_X7Ugcq_fileDirectory",
	fileInfo: "TaskChatInputHeader-module_X7Ugcq_fileInfo",
	fileName: "TaskChatInputHeader-module_X7Ugcq_fileName",
	icon: "TaskChatInputHeader-module_X7Ugcq_icon",
	info: "TaskChatInputHeader-module_X7Ugcq_info",
	noDiffs: "TaskChatInputHeader-module_X7Ugcq_noDiffs",
	prErrorBanner: "TaskChatInputHeader-module_X7Ugcq_prErrorBanner",
	root: "TaskChatInputHeader-module_X7Ugcq_root",
	toggleButton: "TaskChatInputHeader-module_X7Ugcq_toggleButton"
};
async function createPullRequestForTask({ repoNwo, taskId }) {
	return (await fetchCAPI({
		path: `/agents/repos/${repoNwo}/tasks/${taskId}/pulls`,
		method: "POST",
		retryOn401: true
	})).json();
}
function useCreatePullRequestForTask(t0) {
	const $ = c$1(10);
	let t1;
	if ($[0] !== t0) {
		t1 = t0 === void 0 ? {} : t0;
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	const { onSuccess, onError } = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = ["createPullRequestForTask"];
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== onError || $[4] !== onSuccess) {
		t3 = {
			mutationKey: t2,
			mutationFn: _temp$9,
			onSuccess,
			onError
		};
		$[3] = onError;
		$[4] = onSuccess;
		$[5] = t3;
	} else t3 = $[5];
	const mutation = useMutation(t3);
	let t4;
	if ($[6] !== mutation.error || $[7] !== mutation.isPending || $[8] !== mutation.mutate) {
		t4 = {
			createPullRequest: mutation.mutate,
			isLoading: mutation.isPending,
			error: mutation.error
		};
		$[6] = mutation.error;
		$[7] = mutation.isPending;
		$[8] = mutation.mutate;
		$[9] = t4;
	} else t4 = $[9];
	return t4;
}
async function _temp$9(params) {
	sendEvent("copilot.agent_session.pr_creation_requested", {
		task_id: params.taskId,
		nwo: params.repoNwo
	});
	try {
		const response = await createPullRequestForTask(params);
		sendEvent("copilot.agent_session.pr_creation_completed", {
			task_id: params.taskId,
			nwo: params.repoNwo,
			pr_id: response.id,
			pr_number: response.number
		});
		return response;
	} catch (t0) {
		const error = t0;
		const status = error instanceof FetchCAPIError ? error.status : void 0;
		sendEvent("copilot.agent_session.pr_creation_failed", {
			task_id: params.taskId,
			nwo: params.repoNwo,
			status,
			error: error instanceof Error ? error.message : String(error)
		});
		throw error;
	}
}
var PullRequestButton_module_default = {
	button: "PullRequestButton-module__kX-IG_button",
	diffIcon: "PullRequestButton-module__kX-IG_diffIcon",
	disabled: "PullRequestButton-module__kX-IG_disabled"
};
function PullRequestButton(t0) {
	const $ = c$1(25);
	const { pullUrl, taskId, repoNwo, baseRef, headRef, disabled: t1, onError } = t0;
	const disabled = t1 === void 0 ? false : t1;
	const { createPullRequest, isLoading } = useCreatePullRequestForTask();
	const showCreatePrButton = !pullUrl && Boolean(baseRef) && Boolean(headRef);
	let t2;
	let t3;
	if ($[0] !== showCreatePrButton || $[1] !== taskId) {
		t2 = () => {
			if (showCreatePrButton) sendEvent("agent_sessions.task_view", {
				target: "CREATE_PULL_REQUEST_BUTTON_RENDER",
				task_id: taskId
			});
		};
		t3 = [showCreatePrButton, taskId];
		$[0] = showCreatePrButton;
		$[1] = taskId;
		$[2] = t2;
		$[3] = t3;
	} else {
		t2 = $[2];
		t3 = $[3];
	}
	useEffect(t2, t3);
	let t4;
	if ($[4] !== pullUrl || $[5] !== taskId) {
		t4 = () => {
			sendEvent("agent_sessions.task_view", {
				target: "VIEW_PULL_REQUEST_BUTTON",
				pull_url: pullUrl,
				task_id: taskId
			});
		};
		$[4] = pullUrl;
		$[5] = taskId;
		$[6] = t4;
	} else t4 = $[6];
	const handleViewPRClick = t4;
	let t5;
	if ($[7] !== pullUrl || $[8] !== taskId) {
		t5 = () => {
			sendEvent("agent_sessions.task_view", {
				target: "VIEW_PULL_REQUEST_DIFF_BUTTON",
				pull_url: pullUrl,
				task_id: taskId
			});
		};
		$[7] = pullUrl;
		$[8] = taskId;
		$[9] = t5;
	} else t5 = $[9];
	const handleViewDiffClick = t5;
	let t6;
	if ($[10] !== createPullRequest || $[11] !== onError || $[12] !== repoNwo || $[13] !== taskId) {
		t6 = () => {
			if (!taskId) return;
			sendEvent("agent_sessions.task_view", {
				target: "CREATE_PULL_REQUEST_BUTTON",
				task_id: taskId
			});
			createPullRequest({
				repoNwo,
				taskId
			}, {
				onSuccess: (response) => {
					window.location.href = `/${repoNwo}/pull/${response.number}`;
				},
				onError: (error) => {
					onError?.(error instanceof Error ? error.message : "Failed to create pull request");
				}
			});
		};
		$[10] = createPullRequest;
		$[11] = onError;
		$[12] = repoNwo;
		$[13] = taskId;
		$[14] = t6;
	} else t6 = $[14];
	const handleCreatePRViaAPI = t6;
	let t7;
	if ($[15] !== baseRef || $[16] !== disabled || $[17] !== handleCreatePRViaAPI || $[18] !== handleViewDiffClick || $[19] !== handleViewPRClick || $[20] !== headRef || $[21] !== isLoading || $[22] !== pullUrl || $[23] !== taskId) {
		t7 = pullUrl ? jsxs(ButtonGroup, { children: [jsx(ButtonComponent, {
			url: pullUrl,
			icon: jsx(GitPullRequestIcon, {}),
			onClick: handleViewPRClick,
			label: "View pull request"
		}), jsx(ButtonComponent, {
			url: `${pullUrl}/files`,
			icon: jsx(FileDiffIcon, { className: PullRequestButton_module_default.diffIcon }),
			onClick: handleViewDiffClick,
			ariaLabel: "View pull request files"
		})] }) : baseRef && headRef && taskId ? jsx(ButtonComponent$1, {
			className: PullRequestButton_module_default.button,
			leadingVisual: isLoading ? _temp$8 : GitPullRequestIcon,
			variant: "primary",
			size: "small",
			onClick: handleCreatePRViaAPI,
			"aria-label": "Create pull request",
			"aria-disabled": disabled || isLoading,
			inactive: disabled || isLoading,
			disabled: disabled || isLoading,
			children: "Create pull request"
		}) : null;
		$[15] = baseRef;
		$[16] = disabled;
		$[17] = handleCreatePRViaAPI;
		$[18] = handleViewDiffClick;
		$[19] = handleViewPRClick;
		$[20] = headRef;
		$[21] = isLoading;
		$[22] = pullUrl;
		$[23] = taskId;
		$[24] = t7;
	} else t7 = $[24];
	return t7;
}
PullRequestButton.displayName = "PullRequestButton";
function _temp$8() {
	return jsx(Spinner, { size: "small" });
}
function ButtonComponent({ url, icon, onClick, label, ariaLabel, disabled = false }) {
	return /* @__PURE__ */ jsx(ButtonComponent$1, {
		as: "a",
		href: disabled ? void 0 : url,
		target: "_self",
		className: PullRequestButton_module_default.button,
		leadingVisual: icon,
		variant: "primary",
		size: "small",
		onClick: disabled ? void 0 : onClick,
		"aria-label": ariaLabel || label,
		"aria-disabled": disabled,
		inactive: disabled,
		tabIndex: disabled ? 0 : void 0,
		children: label
	});
}
ButtonComponent.displayName = "ButtonComponent";
var THROTTLE_INTERVAL_MS = 2e3;
/**
* Hook that subscribes to branch alive updates and triggers the appropriate refetch callback.
*
* @param aliveChannel - The signed alive channel for the branch
* @param onBranchUpdate - Callback to trigger when an update occurs
*/
function useBranchAliveUpdates(aliveChannel, onBranchUpdate) {
	const $ = c$1(4);
	let t0;
	if ($[0] !== onBranchUpdate) {
		t0 = throttle$1(onBranchUpdate, THROTTLE_INTERVAL_MS, {
			leading: false,
			trailing: true
		});
		$[0] = onBranchUpdate;
		$[1] = t0;
	} else t0 = $[1];
	const throttledBranchRefetch = t0;
	let t1;
	if ($[2] !== throttledBranchRefetch) {
		t1 = () => {
			throttledBranchRefetch();
		};
		$[2] = throttledBranchRefetch;
		$[3] = t1;
	} else t1 = $[3];
	useAlive(aliveChannel, t1);
}
function generateTaskDiffsQueryKey(repoNwo, taskId, baseRef, headRef, includePatch) {
	return [
		"task-diff",
		repoNwo,
		taskId,
		baseRef,
		headRef,
		...includePatch ? ["with-patch"] : []
	];
}
/**
* Hook to fetch task diff data for a task.
* Pass `{ includePatch: true }` to include full patch content per file.
* Pass `{ enabled: false }` to defer fetching until needed.
*/
function useTaskDiffs(repoNwo, taskId, baseRef, headRef, options) {
	const $ = c$1(18);
	let t0;
	if ($[0] !== options) {
		t0 = options ?? {};
		$[0] = options;
		$[1] = t0;
	} else t0 = $[1];
	const { includePatch: t1, enabled: t2 } = t0;
	const includePatch = t1 === void 0 ? false : t1;
	const enabled = t2 === void 0 ? true : t2;
	let t3;
	if ($[2] !== baseRef || $[3] !== headRef || $[4] !== includePatch || $[5] !== repoNwo || $[6] !== taskId) {
		t3 = generateTaskDiffsQueryKey(repoNwo, taskId, baseRef, headRef, includePatch);
		$[2] = baseRef;
		$[3] = headRef;
		$[4] = includePatch;
		$[5] = repoNwo;
		$[6] = taskId;
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== baseRef || $[9] !== headRef || $[10] !== includePatch || $[11] !== repoNwo || $[12] !== taskId) {
		t4 = async () => {
			let url = `/${repoNwo}/tasks/${taskId}/diff?base=${encodeURIComponent(baseRef)}&head=${encodeURIComponent(headRef)}`;
			if (includePatch) url = url + "&include_patch=true";
			const response = await verifiedFetchJSON(url);
			if (!response.ok) throw new Error("Failed to fetch diff data");
			return await response.json();
		};
		$[8] = baseRef;
		$[9] = headRef;
		$[10] = includePatch;
		$[11] = repoNwo;
		$[12] = taskId;
		$[13] = t4;
	} else t4 = $[13];
	let t5;
	if ($[14] !== enabled || $[15] !== t3 || $[16] !== t4) {
		t5 = {
			queryKey: t3,
			queryFn: t4,
			enabled
		};
		$[14] = enabled;
		$[15] = t3;
		$[16] = t4;
		$[17] = t5;
	} else t5 = $[17];
	return useQuery(t5);
}
function TaskChatInputHeader(t0) {
	const $ = c$1(24);
	const { pull, repoNwo, taskId, baseRef, headRef, branchAliveChannel, isSessionInProgress: t1, onViewDiff } = t0;
	const isSessionInProgress = t1 === void 0 ? false : t1;
	const [isDrawerOpen, setIsDrawerOpen] = useState(false);
	const [prError, setPrError] = useState(null);
	const { data: diffs, refetch: refetchDiffs } = useTaskDiffs(repoNwo, taskId, baseRef, headRef);
	const hasDiffs = !!diffs && diffs.files.length > 0;
	const branchHref = `/${repoNwo}/tree/${encodeURIComponent(headRef)}`;
	let t2;
	if ($[0] !== refetchDiffs) {
		t2 = () => {
			refetchDiffs();
		};
		$[0] = refetchDiffs;
		$[1] = t2;
	} else t2 = $[1];
	useBranchAliveUpdates(branchAliveChannel, t2);
	if (!hasDiffs) return null;
	const getPathComponents = _temp$7;
	const getFileStatusIcon = _temp2$3;
	let t3;
	if ($[2] !== isDrawerOpen) {
		t3 = () => {
			setIsDrawerOpen(!isDrawerOpen);
		};
		$[2] = isDrawerOpen;
		$[3] = t3;
	} else t3 = $[3];
	const handleClick = t3;
	let t4;
	if ($[4] !== baseRef || $[5] !== branchHref || $[6] !== diffs || $[7] !== handleClick || $[8] !== hasDiffs || $[9] !== headRef || $[10] !== isDrawerOpen || $[11] !== isSessionInProgress || $[12] !== onViewDiff || $[13] !== prError || $[14] !== pull || $[15] !== repoNwo || $[16] !== taskId) {
		let t5;
		if ($[18] !== headRef || $[19] !== isSessionInProgress || $[20] !== onViewDiff || $[21] !== pull || $[22] !== repoNwo) {
			t5 = (diff) => {
				const [directory, fileName] = getPathComponents(diff.path);
				return jsxs(ActionList.Item, {
					className: TaskChatInputHeader_module_default.diffItem,
					onSelect: () => {
						if (!isSessionInProgress && !pull && onViewDiff) onViewDiff(diff.path);
						else if (pull?.url) window.open(`${pull.url}/files#diff-${diff.path_digest}`, "_blank");
						else window.open(`/${repoNwo}/blob/${headRef}/${diff.path}`, "_blank");
					},
					children: [
						jsx(ActionList.LeadingVisual, { children: getFileStatusIcon(diff.status) }),
						jsxs("div", {
							className: TaskChatInputHeader_module_default.fileInfo,
							children: [jsx("span", {
								className: TaskChatInputHeader_module_default.fileName,
								children: fileName
							}), jsx("span", {
								className: TaskChatInputHeader_module_default.fileDirectory,
								children: directory
							})]
						}),
						jsx(ActionList.TrailingVisual, { children: jsx(DiffStats, {
							linesAdded: diff.additions,
							linesDeleted: diff.deletions,
							linesChanged: diff.changes,
							hideSquares: true
						}) })
					]
				}, diff.path);
			};
			$[18] = headRef;
			$[19] = isSessionInProgress;
			$[20] = onViewDiff;
			$[21] = pull;
			$[22] = repoNwo;
			$[23] = t5;
		} else t5 = $[23];
		t4 = jsxs("div", {
			className: TaskChatInputHeader_module_default.root,
			children: [jsxs("div", {
				className: TaskChatInputHeader_module_default.container,
				children: [
					jsxs("div", {
						className: TaskChatInputHeader_module_default.info,
						children: [
							jsx("button", {
								onClick: handleClick,
								type: "button",
								className: TaskChatInputHeader_module_default.toggleButton,
								"aria-expanded": isDrawerOpen,
								"aria-controls": "task-diff-drawer",
								"aria-label": isDrawerOpen ? "Collapse changed files" : "View changed files",
								children: jsx(ChevronRightIcon, {
									className: TaskChatInputHeader_module_default.icon,
									"data-expanded": isDrawerOpen
								})
							}),
							jsxs("div", {
								className: TaskChatInputHeader_module_default.branch,
								children: [jsx(Link, {
									href: branchHref,
									className: TaskChatInputHeader_module_default.branchText,
									children: headRef
								}), jsx(CopyToClipboardButton, {
									textToCopy: headRef,
									variant: "invisible",
									ariaLabel: `Copy branch name ${headRef}`,
									className: TaskChatInputHeader_module_default.copyIcon
								})]
							}),
							hasDiffs && (isSessionInProgress || !!pull || !onViewDiff) && jsx(DiffStats, {
								linesAdded: diffs.additions,
								linesDeleted: diffs.deletions,
								linesChanged: diffs.changes,
								hideSquares: true
							})
						]
					}),
					jsxs("div", {
						className: TaskChatInputHeader_module_default.actions,
						children: [!isSessionInProgress && !pull && onViewDiff && jsxs(ButtonComponent$1, {
							size: "small",
							onClick: () => onViewDiff?.(),
							"aria-label": "View diff",
							children: ["Diff", diffs && (diffs.additions > 0 || diffs.deletions > 0) && jsxs(Fragment$1, { children: [
								" ",
								diffs.additions > 0 && jsxs("span", {
									className: TaskChatInputHeader_module_default.additions,
									children: ["+", diffs.additions]
								}),
								diffs.additions > 0 && diffs.deletions > 0 && " ",
								diffs.deletions > 0 && jsxs("span", {
									className: TaskChatInputHeader_module_default.deletions,
									children: ["-", diffs.deletions]
								})
							] })]
						}), jsx(PullRequestButton, {
							pullUrl: pull?.url,
							taskId,
							repoNwo,
							baseRef,
							headRef,
							disabled: isSessionInProgress,
							onError: setPrError
						})]
					}),
					prError && jsx(Banner$1, {
						className: TaskChatInputHeader_module_default.prErrorBanner,
						variant: "critical",
						title: "Error creating pull request",
						hideTitle: true,
						description: prError,
						onDismiss: () => setPrError(null)
					})
				]
			}), jsx("div", {
				id: "task-diff-drawer",
				className: TaskChatInputHeader_module_default.diffContainer,
				"data-expanded": isDrawerOpen,
				children: jsx(ActionList, {
					className: TaskChatInputHeader_module_default.diffList,
					children: diffs.files.map(t5)
				})
			})]
		});
		$[4] = baseRef;
		$[5] = branchHref;
		$[6] = diffs;
		$[7] = handleClick;
		$[8] = hasDiffs;
		$[9] = headRef;
		$[10] = isDrawerOpen;
		$[11] = isSessionInProgress;
		$[12] = onViewDiff;
		$[13] = prError;
		$[14] = pull;
		$[15] = repoNwo;
		$[16] = taskId;
		$[17] = t4;
	} else t4 = $[17];
	return t4;
}
TaskChatInputHeader.displayName = "TaskChatInputHeader";
function _temp2$3(status) {
	switch (status) {
		case "A": return jsx(FileAddedIcon, { className: TaskChatInputHeader_module_default.fileAdded });
		case "D":
		case "R": return jsx(FileRemovedIcon, { className: TaskChatInputHeader_module_default.fileDeleted });
		default: return jsx(FileDiffIcon, { className: TaskChatInputHeader_module_default.fileChanged });
	}
}
function _temp$7(filePath) {
	const lastSlashIndex = filePath.lastIndexOf("/");
	if (lastSlashIndex === -1) return ["", filePath];
	return [filePath.slice(0, lastSlashIndex), filePath.slice(lastSlashIndex + 1)];
}
var ViewModeContext = React.createContext("default");
ViewModeContext.displayName = "ViewModeContext";
function ViewModeProvider({ mode = "default", children }) {
	return /* @__PURE__ */ jsx(ViewModeContext, {
		value: mode,
		children
	});
}
ViewModeProvider.displayName = "ViewModeProvider";
function useViewMode() {
	return React.use(ViewModeContext);
}
function TaskChatInputV2({ taskAgentId, activeSession, onAddPendingSession, onClearPendingSession, payload, scrollToBottom, repoNwo, task, branchAliveChannel, onViewDiff, onCloseDiff }) {
	const { pull, steeringEnabled, currentUserCanPush } = payload;
	const viewMode = useViewMode();
	const [failedToSubmit, setFailedToSubmit] = useState(false);
	const { data: agentInfo, isLoading: isAgentInfoLoading } = useAgentInfo(taskAgentId);
	const { data: topLevelAgents, isLoading: isLoadingTopLevelAgents } = useTopLevelAgents(repoNwo);
	const { setPendingChat } = useChatStreamContext();
	const agentNotEnabled = taskAgentId && !isLoadingTopLevelAgents && topLevelAgents && topLevelAgents.length > 0 && !topLevelAgents.some((agent) => Number(agent.id) === taskAgentId);
	const name = agentInfo?.display_name?.toLowerCase() || "agent";
	const isAgentCopilot = isAgentInfoLoading || name === "copilot";
	const { isUsingIntentDetection } = useIntentDetection(activeSession);
	const { mode, setMode } = useIntentDetectionContext();
	const steerable = !!activeSession && isAgentCopilot && !isUsingIntentDetection;
	const startingSession = activeSession && isPendingSession(activeSession);
	const activeSessionOwner = payload.sessionOwners.find((owner) => owner.id === activeSession?.user_id) || null;
	const { currentUserIsSessionOwner } = useCurrentUser$1();
	const queryClient = useQueryClient();
	const [text, setText] = useState("");
	const [isFocused, setIsFocused] = useState(false);
	const inputAreaRef = useRef(null);
	const containerRef = useRef(null);
	const handleCommandCreated = useCallback((commandResponse, problemStatement) => {
		const sessionId = commandResponse.session_id || activeSession?.id;
		if (!sessionId) return;
		const queryKey = ["agent-session-commands", sessionId];
		const command = {
			id: commandResponse.id,
			external_id: commandResponse.external_id ?? null,
			user_id: -1,
			session_id: sessionId,
			content: problemStatement,
			created_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			state: commandResponse.state || "queued",
			error: null
		};
		const currentData = queryClient.getQueryData(queryKey);
		queryClient.setQueryData(queryKey, { commands: [...currentData?.commands ?? [], command] });
		onClearPendingSession();
	}, [
		activeSession,
		queryClient,
		onClearPendingSession
	]);
	const isImageUploadEnabled = isFeatureEnabled("copilot_agent_image_upload");
	const repositoryId = task.repository?.id?.toString();
	const { onPaste, dropTargetProps, isDraggedOver, isUploading: isImageUploading } = useMarkdownImageHandling({
		textAreaRef: inputAreaRef,
		repositoryId,
		enabled: isImageUploadEnabled
	});
	const branchArtifact = getBranchArtifactData(task?.artifacts);
	const baseRef = branchArtifact?.base_ref || pull?.base_ref_name;
	const headRef = branchArtifact?.head_ref || pull?.head_ref_name;
	useEffect(() => {
		const inputElement = inputAreaRef.current;
		if (!inputElement) return;
		let timeout;
		const handleInput = () => {
			if (failedToSubmit) timeout = setTimeout(() => {
				setFailedToSubmit(false);
			}, 0);
		};
		inputElement.addEventListener("input", handleInput);
		return () => {
			inputElement.removeEventListener("input", handleInput);
			if (timeout) clearTimeout(timeout);
		};
	}, [failedToSubmit, inputAreaRef]);
	const handleChange = (e) => {
		if (!inputAreaRef?.current) return;
		setText(e.target.value);
	};
	const handleKeyDown = (e_0) => {
		if (e_0.key === "Enter" && !e_0.shiftKey) {
			e_0.preventDefault();
			handleSubmit();
		}
	};
	const { createSession } = useCreateAPISession({
		onError: () => {
			setFailedToSubmit(true);
			onClearPendingSession();
		},
		onCommandCreated: isUsingIntentDetection ? handleCommandCreated : void 0
	});
	const { createCommand } = useCreateCommand({ onError: () => {
		setFailedToSubmit(true);
	} });
	const getBlockedText = () => {
		if (agentNotEnabled) return "Your organization has removed access for this agent. Contact your administrator for more information.";
		if (activeSession && !isAgentCopilot) return `Wait until the session is complete before steering ${agentInfo?.display_name || "agent"} sessions`;
		if (!steeringEnabled) return "Steering Copilot requires an active subscription";
		if (task.archived_at) return "This session has been archived";
		if (!currentUserCanPush) return "You do not have write permission on the repository";
		if (pull?.state === "merged") return /* @__PURE__ */ jsxs(Fragment$1, { children: [
			"This pull request was merged. To continue iterating,",
			" ",
			/* @__PURE__ */ jsx(Link, {
				href: `/${repoNwo}/agents`,
				inline: true,
				children: "start a new session"
			}),
			"."
		] });
		else if (pull?.state === "closed") return "This pull request was closed. To continue iterating, reopen the pull request.";
		if (!currentUserIsSessionOwner) {
			if (steerable) return `Only ${activeSessionOwner?.login ?? "the session owner"} can steer this session`;
			return /* @__PURE__ */ jsxs(Fragment$1, { children: [
				"Only the author of the task can ask for changes.",
				" ",
				pull && /* @__PURE__ */ jsxs(Fragment$1, { children: [
					/* @__PURE__ */ jsx(Link, {
						href: pull.url,
						inline: true,
						children: "View pull request"
					}),
					" ",
					"to request more changes."
				] })
			] });
		}
	};
	const blockedText = getBlockedText();
	const isBlocked = !!blockedText;
	const getContainerOffset = () => containerRef.current?.offsetHeight ?? 0;
	const handleActiveSessionCommandSubmit = (message) => {
		if (!steerable || !activeSession) return;
		createCommand({
			sessionId: activeSession.id,
			content: message
		});
		setText("");
	};
	const handleSubmit = async () => {
		setFailedToSubmit(false);
		try {
			if (!text.trim() || isBlocked || startingSession || isImageUploading) return;
			if (steerable) {
				handleActiveSessionCommandSubmit(text);
				scrollToBottom();
				return;
			}
			if (!isUsingIntentDetection) onAddPendingSession(text, {
				agentId: taskAgentId,
				isPRComment: false
			});
			else setPendingChat(text);
			setText("");
			onCloseDiff?.();
			createSession({
				nwo: repoNwo,
				taskId: task.id,
				problemStatement: text,
				agentId: taskAgentId,
				eventType: "agent_task_post_session_steering",
				intentDetectionMode: mode
			});
			requestAnimationFrame(() => {
				scrollToBottom({ offset: getContainerOffset() });
			});
		} catch {
			setFailedToSubmit(true);
			throw new ChatInputValidationError(text);
		}
	};
	const placeHolderText = startingSession ? "Waiting for agent to start session..." : steerable ? "Steer active session while agent is working" : "What would you like to do next?";
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(TaskChatInputV2_module_default.container, isImageUploadEnabled && isDraggedOver && TaskChatInputV2_module_default.isDraggedOver),
		ref: containerRef,
		...isImageUploadEnabled ? dropTargetProps : {},
		children: [baseRef && headRef && viewMode !== "sidePanel" && /* @__PURE__ */ jsx(TaskChatInputHeader, {
			pull,
			repoNwo,
			taskId: task.id,
			baseRef,
			headRef,
			branchAliveChannel,
			isSessionInProgress: activeSession ? isActiveSession(activeSession) : false,
			onViewDiff
		}), /* @__PURE__ */ jsx("form", {
			onSubmit: (e_1) => {
				e_1.preventDefault();
				handleSubmit();
			},
			id: "task-chat-input-form",
			"data-testid": "task-chat-input-form",
			children: /* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, {
					visuallyHidden: true,
					children: "Send message"
				}),
				isBlocked ? /* @__PURE__ */ jsx("div", {
					className: clsx(TaskChatInputV2_module_default.inputWrapper, isImageUploadEnabled && TaskChatInputV2_module_default.inputWrapperWithToolbar, isImageUploadEnabled && TaskChatInputV2_module_default.withImageUpload),
					children: /* @__PURE__ */ jsx("div", {
						className: TaskChatInputV2_module_default.blockedContainer,
						children: /* @__PURE__ */ jsxs("div", {
							className: TaskChatInputV2_module_default.blockedContent,
							children: [/* @__PURE__ */ jsx(LockIcon, {
								size: 16,
								className: TaskChatInputV2_module_default.blockedIcon
							}), /* @__PURE__ */ jsx("p", {
								className: TaskChatInputV2_module_default.blockedText,
								children: blockedText
							})]
						})
					})
				}) : isUsingIntentDetection ? /* @__PURE__ */ jsx("div", {
					className: clsx(TaskChatInputV2_module_default.inputWrapper, isImageUploadEnabled && TaskChatInputV2_module_default.inputWrapperWithToolbar, isImageUploadEnabled && TaskChatInputV2_module_default.withImageUpload),
					children: /* @__PURE__ */ jsxs(Stack, {
						direction: "vertical",
						className: TaskChatInputV2_module_default.inputContainer,
						children: [/* @__PURE__ */ jsx("textarea", {
							className: clsx(TaskChatInputV2_module_default.input, isImageUploadEnabled && TaskChatInputV2_module_default.withImageUpload, (isFocused || text) && TaskChatInputV2_module_default.inputFocused),
							onSubmit: handleSubmit,
							"aria-label": placeHolderText,
							value: text,
							onChange: handleChange,
							onKeyDown: handleKeyDown,
							placeholder: placeHolderText,
							disabled: isBlocked,
							ref: inputAreaRef,
							rows: isFocused || text ? 3 : 1,
							onFocus: () => setIsFocused(true),
							onBlur: () => setIsFocused(false)
						}), /* @__PURE__ */ jsxs(Stack, {
							direction: "horizontal",
							className: TaskChatInputV2_module_default.modeAndButtonContainer,
							children: [/* @__PURE__ */ jsx("span", {
								className: TaskChatInputV2_module_default.modeSelector,
								children: /* @__PURE__ */ jsx(ModeSelector, {
									selectedMode: mode,
									setMode
								})
							}), /* @__PURE__ */ jsx(IconButton, {
								variant: "invisible",
								size: "medium",
								icon: PaperAirplaneIcon,
								"aria-label": "Send now",
								inactive: startingSession || isBlocked,
								"aria-disabled": startingSession || isBlocked,
								onClick: handleSubmit,
								className: TaskChatInputV2_module_default.sendButton
							})]
						})]
					})
				}) : /* @__PURE__ */ jsx(ChatInputDisplay, {
					ref: inputAreaRef,
					value: text,
					onChange: setText,
					onSubmit: handleSubmit,
					placeholder: placeHolderText,
					disabled: isBlocked,
					isSubmitting: startingSession || isImageUploading,
					sendButtonAriaLabel: "Send now",
					allowEmptySubmit: true,
					onPaste: isImageUploadEnabled ? onPaste : void 0,
					toolbarSlot: isImageUploadEnabled ? /* @__PURE__ */ jsx(ImageAttachButton, {
						textAreaRef: inputAreaRef,
						repositoryId
					}) : void 0
				}),
				failedToSubmit && !isBlocked && /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					className: "pt-2",
					children: "Failed to submit latest message"
				})
			] })
		})]
	});
}
TaskChatInputV2.displayName = "TaskChatInputV2";
function hasChanges(patchData) {
	return patchData.linesChanged !== void 0 && patchData.linesChanged !== 0;
}
function fileModeChanged(status, oldMode, newMode) {
	return status === "MODIFIED" && oldMode !== newMode;
}
function fileModeChangedOnlyNoOtherChanges(patchData, status, oldMode, newMode) {
	return status === "MODIFIED" && oldMode !== newMode && !hasChanges(patchData);
}
function fileCopiedOnly(patchData) {
	return patchData.status === "COPIED" && !hasChanges(patchData);
}
function fileRenamedOnly(patchData) {
	return patchData.status === "RENAMED" && !hasChanges(patchData);
}
function fileWasDeleted(patchData) {
	return !!patchData.oldTreeEntry && patchData.newTreeEntry === null;
}
function fileTruncated(patchData) {
	return !!patchData.truncatedReason;
}
var truncationReasonLiterals = ["maximum diff size exceeded.", "maximum number of lines exceeded."];
var maxFilesRexExp = /^maximum file count exceeded/;
function truncatedReason(reason) {
	let output = reason;
	if (truncationReasonLiterals.includes(reason)) output = "This diff could not be loaded automatically because of too many other changes.";
	else if (maxFilesRexExp.test(reason)) output = "This diff could not be loaded automatically because of too many other files to display.";
	return output;
}
function fileWasGenerated(patch) {
	return !!patch.newTreeEntry?.isGenerated;
}
function whitespaceChangedOnly(patchData) {
	return patchData.linesChanged === 0;
}
var DiffFileHeader_module_default = {
	collapsed: "DiffFileHeader-module_fg8A_G_collapsed",
	"container-flex-order": "DiffFileHeader-module_fg8A_G_container-flex-order",
	"container-flex-order-reverse": "DiffFileHeader-module_fg8A_G_container-flex-order-reverse",
	"container-flex-wrap": "DiffFileHeader-module_fg8A_G_container-flex-wrap",
	"diff-file-header": "DiffFileHeader-module_fg8A_G_diff-file-header",
	"file-name": "DiffFileHeader-module_fg8A_G_file-name",
	"file-name-truncate": "DiffFileHeader-module_fg8A_G_file-name-truncate",
	"file-path-section": "DiffFileHeader-module_fg8A_G_file-path-section",
	"hide-on-desktop": "DiffFileHeader-module_fg8A_G_hide-on-desktop",
	"hide-on-mobile": "DiffFileHeader-module_fg8A_G_hide-on-mobile",
	"hide-on-small": "DiffFileHeader-module_fg8A_G_hide-on-small"
};
/**
* Custom hook to determine if a tooltip should be shown for truncated file names.
* This hook checks whenever the element is hovered for whether it is large enough to require a tooltip.
*/
function useFileNameTooltip(headingRef) {
	const $ = c$1(3);
	const [isOverflowing, setIsOverflowing] = useState(false);
	let t0;
	let t1;
	if ($[0] !== headingRef) {
		t0 = () => {
			const heading = headingRef.current;
			if (!heading) return;
			const showIfOverflowing = () => {
				setIsOverflowing(heading.scrollWidth > heading.offsetWidth);
			};
			const handleFocus = () => showIfOverflowing();
			const handleBlur = () => setIsOverflowing(false);
			const handleMouseEnter = () => showIfOverflowing();
			const handleMouseLeave = () => setIsOverflowing(false);
			heading.addEventListener("focus", handleFocus);
			heading.addEventListener("blur", handleBlur);
			heading.addEventListener("mouseenter", handleMouseEnter);
			heading.addEventListener("mouseleave", handleMouseLeave);
			return () => {
				heading.removeEventListener("focus", handleFocus);
				heading.removeEventListener("blur", handleBlur);
				heading.removeEventListener("mouseenter", handleMouseEnter);
				heading.removeEventListener("mouseleave", handleMouseLeave);
			};
		};
		t1 = [headingRef];
		$[0] = headingRef;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	return isOverflowing;
}
/**
* Truncates text from the beginning if it exceeds the maximum length.
* Adds ellipsis at the truncation point.
*
* @param text - The text to truncate
* @param maxLength - Maximum length of the output (default: 41)
* @returns An object containing the truncated text and a flag indicating if truncation occurred
*
* @example
* reverseTruncate('very/long/path/to/some/file.txt', 20)
* // Returns: { text: '…th/to/some/file.txt', truncated: true }
*/
function reverseTruncate(text, maxLength = 41) {
	if (!text || text.length <= maxLength) return {
		text: text ?? "",
		truncated: false
	};
	const targetLength = maxLength - 1;
	return {
		text: `…${text.slice(-targetLength)}`,
		truncated: true
	};
}
var defaultHiddenFeatures = /* @__PURE__ */ new Set();
/**
* Renders the file name for a renamed file.
* Includes both the old and new file names with an arrow icon in between.
* Renamed file names will not be truncated via CSS to ensure the arrow is always visible.
*/
function RenamedFileName({ oldPath, newPath, oldPathTruncated, newPathTruncated }) {
	return /* @__PURE__ */ jsxs("code", { children: [/* @__PURE__ */ jsxs("span", {
		"aria-hidden": "true",
		children: [
			"‎",
			oldPathTruncated,
			"‎ ",
			/* @__PURE__ */ jsx(ArrowRightIcon, {}),
			" ‎",
			newPathTruncated,
			"‎"
		]
	}), /* @__PURE__ */ jsxs("span", {
		className: "sr-only",
		children: [
			oldPath,
			" renamed to ",
			newPath,
			" "
		]
	})] });
}
/**
* Renders the file name for a single file.
* Wraps the file name in a `<code>` element with left-to-right marks to truncate from the left.
*/
RenamedFileName.displayName = "RenamedFileName";
function FileName({ path }) {
	return /* @__PURE__ */ jsxs("code", { children: [
		"‎",
		path,
		"‎"
	] });
}
/**
* Returns the heading text, which also serves as the accessible name for the `region`.
* Ensure this logic stays consistent with the table's aria-label in `DiffLines`
* to maintain accessibility alignment.
* @returns An object containing the full display text and truncation information
*/
FileName.displayName = "FileName";
function displayNameText({ newPath, oldPath, status }) {
	if (status === "RENAMED") {
		const oldPathTruncatedResult = reverseTruncate(oldPath);
		const newPathTruncatedResult = reverseTruncate(newPath);
		const truncated = oldPathTruncatedResult.truncated || newPathTruncatedResult.truncated;
		return {
			text: `${oldPath} renamed to ${newPath}`,
			truncated,
			oldPathTruncated: oldPathTruncatedResult.text,
			newPathTruncated: newPathTruncatedResult.text
		};
	} else if (status === "DELETED" || status === "REMOVED") return {
		text: oldPath ?? "",
		truncated: false
	};
	else return {
		text: newPath ?? "",
		truncated: false
	};
}
function HeadingFileName({ headingId, fileLinkHref, onHeaderClick, fileLinkRef, newPath, oldPath, patchStatus }) {
	const headingRef = useRef(null);
	const showFileNameTooltip = useFileNameTooltip(headingRef);
	const displayPath = displayNameText({
		newPath,
		oldPath,
		status: patchStatus
	});
	const fileName = patchStatus === "RENAMED" ? /* @__PURE__ */ jsx(RenamedFileName, {
		oldPath,
		newPath,
		oldPathTruncated: displayPath.oldPathTruncated,
		newPathTruncated: displayPath.newPathTruncated
	}) : /* @__PURE__ */ jsx(FileName, { path: displayPath.text });
	return /* @__PURE__ */ jsx("h3", {
		id: headingId,
		className: clsx(DiffFileHeader_module_default["file-name"], patchStatus !== "RENAMED" && DiffFileHeader_module_default["file-name-truncate"]),
		ref: headingRef,
		children: showFileNameTooltip || displayPath.truncated ? /* @__PURE__ */ jsx(Tooltip$1, {
			text: displayPath.text,
			direction: "s",
			children: /* @__PURE__ */ jsx(Link, {
				className: "Link--primary",
				href: fileLinkHref,
				onClick: onHeaderClick,
				ref: fileLinkRef,
				children: fileName
			})
		}) : /* @__PURE__ */ jsx(Link, {
			className: "Link--primary",
			href: fileLinkHref,
			onClick: onHeaderClick,
			ref: fileLinkRef,
			children: fileName
		})
	});
}
/**
* Renders the header of a diff file.
*/
HeadingFileName.displayName = "HeadingFileName";
function DiffFileHeader({ additionalLeftSideContent, areLinesExpanded, canExpandOrCollapseLines, className, diffStatsProps, hiddenFeatures = defaultHiddenFeatures, isBinary, isSubmodule, isCollapsed, canToggleRichDiff, headingId, linesAdded, linesChanged, linesDeleted, fileLinkHref, fileLinkRef, newMode, newPath, oldMode, oldPath, onCopyPath, onHeaderClick, onToggleDiffDisplay, onToggleExpandAllLines, onToggleFileCollapsed, patchStatus, path, rightSideContent, size, showRichDiff, isInSingleFileMode }) {
	const isNegative = size && size[0] === "-";
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(DiffFileHeader_module_default["diff-file-header"], isCollapsed ? DiffFileHeader_module_default["collapsed"] : "", DiffFileHeader_module_default["container-flex-wrap"], className),
		children: [
			!isInSingleFileMode && /* @__PURE__ */ jsx("div", {
				className: "d-flex flex-shrink-0 flex-order-1",
				style: {
					width: "28px",
					justifyContent: "center"
				},
				children: /* @__PURE__ */ jsx(IconButton, {
					onClick: onToggleFileCollapsed,
					"aria-label": isCollapsed ? `Expand file` : `Collapse file`,
					icon: isCollapsed ? ChevronRightIcon : ChevronDownIcon,
					size: "small",
					variant: "invisible"
				})
			}),
			additionalLeftSideContent,
			/* @__PURE__ */ jsxs("div", {
				className: clsx("d-flex px-1 flex-items-center overflow-hidden", DiffFileHeader_module_default["container-flex-order-reverse"], DiffFileHeader_module_default["file-path-section"], patchStatus !== "RENAMED" && "flex-1"),
				children: [
					/* @__PURE__ */ jsx(HeadingFileName, {
						headingId,
						fileLinkHref,
						onHeaderClick,
						fileLinkRef,
						newPath,
						oldPath,
						patchStatus
					}),
					/* @__PURE__ */ jsx(CopyToClipboardButton, {
						className: clsx("ml-2 flex-shrink-0", DiffFileHeader_module_default["hide-on-mobile"]),
						textToCopy: newPath ?? oldPath ?? "",
						ariaLabel: "Copy file name to clipboard",
						tooltipProps: { direction: "s" },
						onCopy: onCopyPath,
						size: "small"
					}),
					fileModeChanged(patchStatus, oldMode, newMode) && /* @__PURE__ */ jsxs("div", {
						className: "p-2",
						children: [
							/* @__PURE__ */ jsx("code", { children: oldMode }),
							/* @__PURE__ */ jsx(ArrowRightIcon, { className: "mx-1" }),
							/* @__PURE__ */ jsx("code", { children: newMode })
						]
					}),
					!hiddenFeatures.has(DiffFeature.expandLines) && canExpandOrCollapseLines && onToggleExpandAllLines && /* @__PURE__ */ jsx(Tooltip$1, {
						text: areLinesExpanded ? `Collapse non-diff lines: ${path}` : `Expand all lines: ${path}`,
						direction: "s",
						children: /* @__PURE__ */ jsx(IconButton, {
							onClick: onToggleExpandAllLines,
							"aria-label": areLinesExpanded ? `Collapse non-diff lines: ${path}` : `Expand all lines: ${path}`,
							icon: areLinesExpanded ? FoldIcon : UnfoldIcon,
							size: "small",
							variant: "invisible",
							"data-file-path": path,
							className: clsx("flex-shrink-0", !areLinesExpanded && "js-expand-all-difflines-button", DiffFileHeader_module_default["hide-on-mobile"])
						})
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: clsx("d-flex flex-row flex-justify-end flex-items-center gap-2 flex-1", DiffFileHeader_module_default["container-flex-order"]),
				children: [
					!hiddenFeatures.has(DiffFeature.diffStats) && /* @__PURE__ */ jsx("div", {
						className: "d-flex flex-justify-end flex-items-center",
						children: !isSubmodule && /* @__PURE__ */ jsx("div", {
							className: DiffFileHeader_module_default["hide-on-mobile"],
							children: /* @__PURE__ */ jsx(DiffStats, {
								linesAdded,
								linesDeleted,
								linesChanged,
								...diffStatsProps
							})
						})
					}),
					isBinary && /* @__PURE__ */ jsx("div", {
						className: "d-flex flex-items-center",
						children: /* @__PURE__ */ jsx("code", {
							className: clsx("px-2", isNegative && "fgColor-danger", !isNegative && "fgColor-success"),
							children: `${size}`
						})
					}),
					canToggleRichDiff && /* @__PURE__ */ jsxs(SegmentedControl, {
						"aria-label": "File view",
						size: "small",
						className: DiffFileHeader_module_default["hide-on-small"],
						onChange: onToggleDiffDisplay ? (index) => onToggleDiffDisplay(index === 1) : void 0,
						children: [/* @__PURE__ */ jsx(SegmentedControl.IconButton, {
							"aria-label": "Display the source diff",
							selected: !showRichDiff,
							icon: CodeIcon
						}), /* @__PURE__ */ jsx(SegmentedControl.IconButton, {
							"aria-label": "Display the rich diff",
							selected: showRichDiff,
							icon: FileIcon
						})]
					}),
					rightSideContent
				]
			})
		]
	});
}
DiffFileHeader.displayName = "DiffFileHeader";
function LinesChangedCounterLabel({ children, isAddition, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx("ml-1 text-small text-bold", isAddition ? "fgColor-success" : "fgColor-danger", className),
		children
	});
}
LinesChangedCounterLabel.displayName = "LinesChangedCounterLabel";
var FileFilter_module_default = {
	clearFiltersText: "FileFilter-module_uiGCHa_clearFiltersText",
	filterIndicator: "FileFilter-module_uiGCHa_filterIndicator",
	filterLoadingHeight: "FileFilter-module_uiGCHa_filterLoadingHeight",
	filterMaxHeight: "FileFilter-module_uiGCHa_filterMaxHeight"
};
var NO_FILE_EXTENSION = "No extension";
function FileFilterLoading({ filterText, onFilterTextChange }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "d-flex flex-nowrap gap-2",
		children: [/* @__PURE__ */ jsx(TextInput$1, {
			block: true,
			"aria-label": "Filter files…",
			leadingVisual: SearchIcon,
			placeholder: "Filter files…",
			value: filterText,
			onChange: (event) => onFilterTextChange?.(event.target.value)
		}), /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			"aria-label": "Filter options",
			icon: FilterIcon,
			className: "flex-shrink-0"
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			className: clsx(FileFilter_module_default.filterLoadingHeight),
			children: /* @__PURE__ */ jsx("div", {
				className: clsx("d-flex", "flex-column", "flex-justify-center", "flex-items-center", FileFilter_module_default.filterLoadingHeight),
				children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
			})
		})] })]
	});
}
FileFilterLoading.displayName = "FileFilterLoading";
function FileFilterShared({ ref, filterSize = "medium", filterText: initialFilterText, onFilterTextChange, fileExtensions, unselectedFileExtensions, onFilterChange, onClearAllFilters, additionalFilterGroups, isFilteringActive }) {
	fileExtensions = fileExtensions ?? {};
	unselectedFileExtensions = unselectedFileExtensions ?? /* @__PURE__ */ new Set();
	const [filterText, setFilterText] = useState(initialFilterText ?? "");
	const setSelectedFileFilters = (select, extension) => {
		onFilterChange?.(select ? "selectFileExtension" : "unselectFileExtension", { extension });
	};
	const clearFilters = () => {
		setFilterText("");
		onClearAllFilters?.();
	};
	const extensions = Object.keys(fileExtensions).filter((ext) => ext !== NO_FILE_EXTENSION).sort();
	const fileExtensionIsSelected = (ext_0) => !unselectedFileExtensions.has(ext_0);
	const noExtensionPresent = !!fileExtensions[NO_FILE_EXTENSION];
	return /* @__PURE__ */ jsxs("div", {
		id: "diff-file-tree-filter",
		className: "d-flex flex-nowrap gap-2",
		children: [/* @__PURE__ */ jsx(TextInput$1, {
			ref,
			block: true,
			"aria-label": "Filter files…",
			leadingVisual: SearchIcon,
			placeholder: "Filter files…",
			size: filterSize,
			className: clsx(filterSize === "small" && FileFilter_module_default.filterMaxHeight),
			value: filterText,
			onChange: (event) => {
				setFilterText(event.target.value);
				onFilterTextChange?.(event.target.value);
			}
		}), /* @__PURE__ */ jsxs("div", {
			className: "position-relative",
			children: [/* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
				"aria-label": "Filter options",
				icon: FilterIcon,
				className: "flex-shrink-0",
				size: filterSize
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, { children: [
				/* @__PURE__ */ jsxs(ActionList.Group, {
					selectionVariant: "multiple",
					children: [
						/* @__PURE__ */ jsx(ActionList.GroupHeading, { children: "File extensions" }),
						extensions.map((ext_1) => {
							const selected = fileExtensionIsSelected(ext_1);
							return /* @__PURE__ */ jsxs(ActionList.Item, {
								selected,
								onSelect: () => setSelectedFileFilters(!selected, ext_1),
								children: [ext_1, /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(CounterLabel, { children: fileExtensions[ext_1] }) })]
							}, ext_1);
						}),
						noExtensionPresent && /* @__PURE__ */ jsxs(ActionList.Item, {
							selected: fileExtensionIsSelected("No extension"),
							onSelect: () => setSelectedFileFilters(!fileExtensionIsSelected("No extension"), "No extension"),
							children: ["No extension", /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(CounterLabel, { children: fileExtensions["No extension"] }) })]
						}, "No extension")
					]
				}),
				additionalFilterGroups,
				isFilteringActive && onClearAllFilters && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsx(ActionList.Item, {
					onSelect: clearFilters,
					children: /* @__PURE__ */ jsx("span", {
						className: FileFilter_module_default.clearFiltersText,
						children: "Clear filters"
					})
				})] })
			] }) })] }), isFilteringActive && /* @__PURE__ */ jsx("span", { className: FileFilter_module_default.filterIndicator })]
		})]
	});
}
FileFilterShared.displayName = "FileFilterShared";
/**
* Compare two strings with case-first ordering. ZZZ.txt will come before aaa.txt with this strategy.
*/
function caseFirstCompare(a, b) {
	if (a.startsWith(b) && a !== b) return -1;
	if (b.startsWith(a) && a !== b) return 1;
	if (a < b) return -1;
	if (a > b) return 1;
	return 0;
}
function compareDirectoryNames(a, b) {
	return caseFirstCompare(a.name, b.name);
}
function compareFileNames(a, b) {
	return caseFirstCompare(a.fileName, b.fileName);
}
var FileNode = class {
	diff;
	filePath;
	fileName;
	directoryParts;
	sortOrder;
	constructor(diff, sortOrder) {
		this.diff = diff;
		this.filePath = diff.path;
		const pathParts = this.filePath.split("/");
		this.fileName = pathParts[pathParts.length - 1];
		this.directoryParts = pathParts.slice(0, pathParts.length - 1);
		this.sortOrder = sortOrder;
	}
};
var DirectoryNode = class DirectoryNode {
	directories = [];
	files = [];
	#directoriesByName = /* @__PURE__ */ new Map();
	name;
	path;
	sortOrder;
	constructor(name, path, sortOrder) {
		this.name = name;
		this.path = path;
		this.sortOrder = sortOrder;
	}
	getOrCreateDirectory(name, sortOrder) {
		let directory = this.#directoriesByName.get(name);
		if (!directory) {
			directory = new DirectoryNode(name, `${this.path ? `${this.path}/` : ""}${name}`, sortOrder);
			this.directories.push(directory);
			this.#directoriesByName.set(name, directory);
		}
		return directory;
	}
	sort() {
		this.directories.sort(compareDirectoryNames);
		this.files.sort(compareFileNames);
		for (const subDirectory of this.directories) subDirectory.sort();
	}
};
function getFileTree(summaryDeltas) {
	const baseNode = new DirectoryNode("", "", Number.MAX_SAFE_INTEGER);
	const files = summaryDeltas.map((diff, index) => new FileNode(diff, index));
	for (const file of files) {
		let directory = baseNode;
		for (const directoryPath of file.directoryParts) {
			directory = directory.getOrCreateDirectory(directoryPath, file.sortOrder);
			directory.sortOrder = Math.min(directory.sortOrder, file.sortOrder);
		}
		directory.files.push(file);
	}
	updateDirectorySortOrders(baseNode);
	baseNode.sort();
	return baseNode;
}
function updateDirectorySortOrders(node) {
	for (const subDir of node.directories) updateDirectorySortOrders(subDir);
	const subDirectorySortOrders = node.directories.map((d) => d.sortOrder);
	const fileSortOrders = node.files.map((f) => f.sortOrder);
	node.sortOrder = Math.min(node.sortOrder, ...subDirectorySortOrders, ...fileSortOrders);
}
function getFileExtension(file) {
	let path;
	if (typeof file === "string") path = file;
	else path = file?.newPath || file?.oldPath;
	const lastPeriodIndex = path?.lastIndexOf(".");
	if (!path) return "";
	if (!lastPeriodIndex || lastPeriodIndex < 0) return NO_FILE_EXTENSION;
	return `.${path.substring(lastPeriodIndex + 1)}`;
}
function FileStatusIcon({ status, isSymlink }) {
	if (isSymlink) return /* @__PURE__ */ jsx(FileSymlinkFileIcon, {
		size: 16,
		className: "fgColor-attention"
	});
	switch (status) {
		case "ADDED":
		case "COPIED": return /* @__PURE__ */ jsx(FileAddedIcon, {
			size: 16,
			className: "fgColor-success"
		});
		case "DELETED":
		case "REMOVED": return /* @__PURE__ */ jsx(FileRemovedIcon, {
			size: 16,
			className: "fgColor-danger"
		});
		case "RENAMED": return /* @__PURE__ */ jsx(FileMovedIcon, {
			size: 16,
			className: "fgColor-attention"
		});
		default: return /* @__PURE__ */ jsx(FileDiffIcon, {
			size: 16,
			className: "fgColor-muted"
		});
	}
}
FileStatusIcon.displayName = "FileStatusIcon";
/**
* Detect if location Hash matches a diff anchor with line numbers
*/
function matchHash(hash) {
	const diffAnchorMatch = hash.match(/^#?(diff-[a-f0-9]+)(L|R)(\d+)(?:-(L|R)(\d+))?$/i);
	if (diffAnchorMatch != null && diffAnchorMatch.length === 6) return diffAnchorMatch;
	const discussionAnchorMatch = hash.match(/^#?(discussion-diff-[0-9]+)(L|R)(\d+)(?:-(L|R)(\d+))?$/i);
	if (discussionAnchorMatch != null && discussionAnchorMatch.length === 6) return discussionAnchorMatch;
	return null;
}
function lineHashFragmentFrom(lineNumber, orientation) {
	return `${orientation === "left" ? "L" : "R"}${lineNumber}`;
}
function parseDiffHash(hash) {
	return hash.match(/^#?(diff-[a-f0-9]+)/)?.[1];
}
function isSelectingDiffLineOrRange(hash) {
	if (!(matchHash(hash) || matchHash(`diff-${hash}`))) return false;
	return hash.includes("R") || hash.includes("L");
}
function parsePathDigestWithoutLineNumbers(hash) {
	if (!(parseDiffHash(hash) || parseDiffHash(`diff-${hash}`))) return;
	let pathDigest = hash.replace("#", "").replace("diff-", "");
	if (pathDigest.includes("-")) pathDigest = pathDigest.split("-")[0] ?? "";
	if (pathDigest.includes("L")) pathDigest = pathDigest.split("L")[0] ?? "";
	if (pathDigest.includes("R")) pathDigest = pathDigest.split("R")[0] ?? "";
	return pathDigest;
}
/**
*
* Check if we're specifying a comment in the hash.
* This format is defined in
* [Platform::Models::PullRequestReviewComment#async_current_diff_path_uri](https://github.com/github/github/blob/420ce06f085acf1c9fd9d8948472b3fcca3ba467/packages/pull_requests/app/models/pull_request_review_comment.rb#L571)
*
* Basically `#r<database-id>`
*/
function parseCommentHash(hash) {
	const commentId = hash.match(/^#?(r\d+)/)?.[1];
	if (commentId) return parseInt(commentId.slice(1));
	else return;
}
function parseAnnotationHash(hash) {
	const annotationId = hash.match(/^#annotation_(\d+)/)?.[1];
	if (annotationId) return parseInt(annotationId);
	else return;
}
function updateURLHashFromLineRange(lineRange) {
	updateUrlHash(urlHashFromLineRange(lineRange));
	addUrlToHistoryStack(window.location.href);
}
function urlHashFromLineRange(lineRange) {
	const lineStartFragment = lineHashFragmentFrom(lineRange.startLineNumber, lineRange.startOrientation);
	let newHash = `${lineRange.diffAnchor}${lineStartFragment}`;
	if (lineRange.endLineNumber !== lineRange.startLineNumber || lineRange.endOrientation !== lineRange.startOrientation) {
		const lineEndFragment = lineHashFragmentFrom(lineRange.endLineNumber, lineRange.endOrientation);
		newHash += `-${lineEndFragment}`;
	}
	return newHash;
}
function updateURLHash(hash) {
	const newHash = `#${hash}`;
	if (newHash === window.location.hash) return;
	const oldURL = window.location.href;
	updateUrlHash(newHash);
	window.dispatchEvent(new HashChangeEvent("hashchange", {
		newURL: window.location.href,
		oldURL
	}));
}
/**
* Extracts the full diff hash from the current window URL.
*
* This function examines the URL hash and attempts to extract a diff identifier.
* It first tries to match the hash against the pattern for line selections
* using `matchHash()`. If that fails, it falls back to looking for just a diff
* identifier using `parseDiffHash()`.
*
* The function returns the diff hash with any prefix ('diff-' or '#') removed.
* Line numbers will be included in the return if present in the string
*
* @returns {string} The full diff hash from the URL without prefixes, or an empty string if none exists
*/
function getSelectedFullDiffHash() {
	const windowHash = matchHash(ssrSafeLocation.hash ?? "") ?? "";
	let hashToUse = "";
	if (windowHash === "") hashToUse = parseDiffHash(ssrSafeLocation.hash ?? "") ?? "";
	else hashToUse = windowHash?.[0] ?? "";
	return hashToUse.replace("#", "").replace("diff-", "");
}
/**
* Extracts the comment id the current window URL.
*
* @returns {number | undefined} The comment database Id, or undefined if none exists
*/
function getSelectedCommentId() {
	return parseCommentHash(ssrSafeLocation.hash ?? "");
}
/**
* Extracts the annotation id the current window URL.
*
* @returns {number | undefined} The annotation database Id, or undefined if none exists
*/
function getSelectedAnnotationId() {
	return parseAnnotationHash(ssrSafeLocation.hash ?? "");
}
/**
* Hook that tracks the currently selected diff hash from the URL.
*
* This provides a consistent way to track diff navigation across different components
* that need to respond to hash changes (like DiffFileTree, use-diff-navigation, etc.).
*
* @returns Object containing the selected diff hash information
*/
function useSelectedDiffHash() {
	const $ = c$1(6);
	const [selectedHash, setSelectedHash] = useState("");
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			setSelectedHash((parseDiffHash(ssrSafeLocation.hash ?? "") ?? "").replace("diff-", ""));
		};
		$[0] = t0;
	} else t0 = $[0];
	const onHashChange = t0;
	let t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			window.addEventListener("hashchange", onHashChange);
			onHashChange();
			return () => {
				window.removeEventListener("hashchange", onHashChange);
			};
		};
		t2 = [onHashChange];
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useEffect(t1, t2);
	const t3 = selectedHash ? `diff-${selectedHash}` : "";
	let t4;
	if ($[3] !== selectedHash || $[4] !== t3) {
		t4 = {
			selectedPathDigest: selectedHash,
			selectedFullDiffHash: t3
		};
		$[3] = selectedHash;
		$[4] = t3;
		$[5] = t4;
	} else t4 = $[5];
	return t4;
}
var DiffFileTree_module_default = { "file-tree-row": "DiffFileTree-module_RgTqRW_file-tree-row" };
var DIFF_FILE_TREE_ID = "diff_file_tree";
var FileStatusIconItem = memo(function({ changeType, isSymlink }) {
	return /* @__PURE__ */ jsx(FileStatusIcon, {
		status: changeType,
		isSymlink
	});
});
FileStatusIconItem.displayName = "FileStatusIconItem";
var File$1 = memo(function File({ file, depth, hash, onSelect }) {
	const rowRef = useRef(null);
	const anchorRef = useRef(null);
	const anchorHref = useMemo(() => `#diff-${file.diff.pathDigest}`, [file.diff.pathDigest]);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: rowRef,
		mouseRowRef: rowRef
	});
	const totalCommentsCount = file.diff.totalCommentsCount ?? 0;
	const maxAnnotation = file.diff.highestAnnotationLevel;
	const { screenReaderText, annotationElement } = useMemo(() => {
		let text = file.fileName ?? "This file";
		let element = null;
		if (totalCommentsCount > 0) text += ` has ${totalCommentsCount < 10 ? totalCommentsCount : "9+"} ${totalCommentsCount > 1 ? "comments" : "comment"}`;
		switch (maxAnnotation) {
			case "WARNING":
				text += `${totalCommentsCount > 0 ? " and" : ""} has warning annotations`;
				element = /* @__PURE__ */ jsx("div", {
					className: "pl-1 fgColor-attention",
					children: /* @__PURE__ */ jsx(AlertIcon, {})
				});
				break;
			case "NOTICE":
				text += `${totalCommentsCount > 0 ? " and" : ""} has notice annotations`;
				element = /* @__PURE__ */ jsx("div", {
					className: "pl-1 fgColor-default",
					children: /* @__PURE__ */ jsx(InfoIcon, {})
				});
				break;
			case "FAILURE":
				text += `${totalCommentsCount > 0 ? " and" : ""} has failure annotations`;
				element = /* @__PURE__ */ jsx("div", {
					className: "pl-1 fgColor-danger",
					children: /* @__PURE__ */ jsx(XCircleFillIcon, {})
				});
				break;
		}
		return {
			screenReaderText: text,
			annotationElement: element
		};
	}, [
		file.fileName,
		totalCommentsCount,
		maxAnnotation
	]);
	useEffect(() => {
		if (rowRef.current && file.diff.pathDigest === hash) {
			const timeout = window.setTimeout(() => {
				const fileTreeParent = ssrSafeDocument?.getElementById(DIFF_FILE_TREE_ID)?.parentElement;
				const rowHeight = rowRef.current.offsetTop;
				const usableHeight = (ssrSafeWindow?.innerHeight ?? 0) / 2;
				if (fileTreeParent) fileTreeParent.scrollTop = rowHeight - usableHeight;
			}, 0);
			return () => {
				window.clearTimeout(timeout);
			};
		}
	}, [file.diff.pathDigest, hash]);
	const onLinkClick = useCallback((e) => {
		const mouseEvent = e;
		if (mouseEvent.metaKey || mouseEvent.ctrlKey || mouseEvent.button === 1) {
			mouseEvent.preventDefault();
			window.open(anchorHref, "_blank");
			return;
		}
	}, [anchorHref]);
	const onSelectItem = useCallback((e_0) => {
		if (e_0.nativeEvent instanceof KeyboardEvent) {
			const keyboardEvent = e_0;
			if (rowRef?.current !== document.activeElement) {
				keyboardEvent.preventDefault();
				return;
			}
			if (keyboardEvent.key === "Enter" || keyboardEvent.key === " ") {
				keyboardEvent.preventDefault();
				onSelect?.();
				anchorRef?.current?.click();
				return;
			}
		}
		if (e_0.nativeEvent instanceof MouseEvent) {
			const mouseEvent_0 = e_0;
			if (mouseEvent_0.metaKey || mouseEvent_0.ctrlKey || mouseEvent_0.button === 1) {
				mouseEvent_0.preventDefault();
				onLinkClick(mouseEvent_0);
				return;
			}
			onSelect?.();
			anchorRef?.current?.click();
		}
	}, [onLinkClick, onSelect]);
	const fileName = file.fileName ?? "";
	const fileLinkElement = /* @__PURE__ */ jsx(Link, {
		href: anchorHref,
		muted: true,
		ref: anchorRef,
		role: "presentation",
		className: "fgColor-default",
		tabIndex: -1,
		onClick: onLinkClick,
		children: fileName
	});
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs(TreeView.Item, {
		defaultExpanded: true,
		"aria-label": screenReaderText,
		"aria-level": depth,
		current: file.diff.pathDigest === hash,
		id: file.diff.path,
		onSelect: onSelectItem,
		ref: rowRef,
		className: DiffFileTree_module_default["file-tree-row"],
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(FileStatusIconItem, {
				changeType: file.diff.changeType,
				isSymlink: file.diff.isSymlink
			}) }),
			showTooltip ? /* @__PURE__ */ jsx(Tooltip$1, {
				text: fileName,
				direction: "ne",
				children: fileLinkElement
			}) : fileLinkElement,
			(!!totalCommentsCount || maxAnnotation) && /* @__PURE__ */ jsx(TreeView.TrailingVisual, { children: /* @__PURE__ */ jsxs("div", {
				className: "d-flex flex-items-center flex-row",
				children: [!!totalCommentsCount && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CommentIcon, {}), /* @__PURE__ */ jsx("div", {
					className: "ml-1 text-bold fgColor-default f6",
					children: totalCommentsCount < 10 ? totalCommentsCount : "9+"
				})] }), annotationElement]
			}) })
		]
	}, file.diff.pathDigest) });
});
File$1.displayName = "File";
var Directory = memo(function Directory({ directory, depth = 0, leadingPath = "", sortByDiffOrder, onSelect, hash, fileNodeRenderer }) {
	const pathPrefix = leadingPath ? `${leadingPath}/` : "";
	const rowRef = useRef(null);
	const listItemRef = useRef(null);
	const showTooltip = useFileTreeTooltip({
		focusRowRef: listItemRef,
		mouseRowRef: rowRef
	});
	if (!directory.files.length && directory.directories.length === 1) return /* @__PURE__ */ jsx(Fragment$1, { children: directory.directories.map((subDirectory) => /* @__PURE__ */ jsx(Directory, {
		depth: depth === 0 ? 1 : depth,
		directory: subDirectory,
		leadingPath: `${pathPrefix}${directory.name}`,
		sortByDiffOrder,
		onSelect,
		hash,
		fileNodeRenderer
	}, subDirectory.path)) });
	function renderDirectoryContents() {
		return /* @__PURE__ */ jsx(DirectoryRendering, {
			directory,
			depth,
			sortByDiffOrder,
			onSelect,
			hash,
			fileNodeRenderer
		});
	}
	if (depth === 0) return renderDirectoryContents();
	return /* @__PURE__ */ jsxs(TreeView.Item, {
		ref: listItemRef,
		defaultExpanded: true,
		id: directory.path,
		children: [
			/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(TreeView.DirectoryIcon, {}) }),
			/* @__PURE__ */ jsx("span", {
				ref: rowRef,
				children: `${pathPrefix}${directory.name}`
			}),
			showTooltip && /* @__PURE__ */ jsx(PortalTooltip, {
				"data-testid": `${directory.name}-directory-item-tooltip`,
				id: `${directory.name}-directory-item-tooltip`,
				contentRef: listItemRef,
				"aria-label": `${pathPrefix}${directory.name}`,
				open: true,
				direction: "ne"
			}),
			/* @__PURE__ */ jsx(TreeView.SubTree, { children: renderDirectoryContents() })
		]
	}, directory.path);
});
Directory.displayName = "Directory";
var DirectoryRendering = memo(function DirectoryRendering(t0) {
	const $ = c$1(17);
	const { directory, fileNodeRenderer, sortByDiffOrder, depth: t1, onSelect, hash } = t0;
	const depth = t1 === void 0 ? 0 : t1;
	let paths;
	if ($[0] !== directory.directories || $[1] !== directory.files || $[2] !== sortByDiffOrder) {
		paths = directory.files.map(_temp$6).concat(directory.directories.map(_temp2$2));
		if (sortByDiffOrder) paths.sort(_temp3);
		else paths.sort(_temp4);
		$[0] = directory.directories;
		$[1] = directory.files;
		$[2] = sortByDiffOrder;
		$[3] = paths;
	} else paths = $[3];
	const mergedPaths = paths;
	let t2;
	if ($[4] !== depth || $[5] !== fileNodeRenderer || $[6] !== hash || $[7] !== mergedPaths || $[8] !== onSelect || $[9] !== sortByDiffOrder) {
		let t3;
		if ($[11] !== depth || $[12] !== fileNodeRenderer || $[13] !== hash || $[14] !== onSelect || $[15] !== sortByDiffOrder) {
			t3 = (entry) => {
				if (entry.pathType === "file") {
					if (fileNodeRenderer) return fileNodeRenderer({
						onSelect,
						hash,
						file: entry.node,
						depth: depth + 1
					});
					return jsx(File$1, {
						depth: depth + 1,
						file: entry.node,
						onSelect,
						hash
					}, entry.path);
				} else return jsx(Directory, {
					depth: depth + 1,
					directory: entry.node,
					fileNodeRenderer,
					sortByDiffOrder,
					onSelect,
					hash
				}, entry.path);
			};
			$[11] = depth;
			$[12] = fileNodeRenderer;
			$[13] = hash;
			$[14] = onSelect;
			$[15] = sortByDiffOrder;
			$[16] = t3;
		} else t3 = $[16];
		t2 = jsx(Fragment$1, { children: mergedPaths.map(t3) });
		$[4] = depth;
		$[5] = fileNodeRenderer;
		$[6] = hash;
		$[7] = mergedPaths;
		$[8] = onSelect;
		$[9] = sortByDiffOrder;
		$[10] = t2;
	} else t2 = $[10];
	return t2;
});
DirectoryRendering.displayName = "DirectoryRendering";
var DiffFileTree = memo(function FileTree(t0) {
	const $ = c$1(9);
	const { diffs, fileNodeRenderer, sortByDiffOrder, className, onSelect } = t0;
	let t1;
	if ($[0] !== diffs) {
		t1 = getFileTree(diffs);
		$[0] = diffs;
		$[1] = t1;
	} else t1 = $[1];
	const fileTree = t1;
	const { selectedPathDigest } = useSelectedDiffHash();
	let t2;
	if ($[2] !== className || $[3] !== fileNodeRenderer || $[4] !== fileTree || $[5] !== onSelect || $[6] !== selectedPathDigest || $[7] !== sortByDiffOrder) {
		t2 = jsx(TreeView, {
			"aria-label": "File Tree",
			className,
			children: jsx(Directory, {
				directory: fileTree,
				fileNodeRenderer,
				sortByDiffOrder,
				onSelect,
				hash: selectedPathDigest
			})
		});
		$[2] = className;
		$[3] = fileNodeRenderer;
		$[4] = fileTree;
		$[5] = onSelect;
		$[6] = selectedPathDigest;
		$[7] = sortByDiffOrder;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
});
DiffFileTree.displayName = "DiffFileTree";
function _temp$6(file) {
	return {
		path: file.filePath,
		pathType: "file",
		node: file,
		sortOrder: file.sortOrder
	};
}
function _temp2$2(dir) {
	return {
		path: dir.path,
		pathType: "directory",
		node: dir,
		sortOrder: dir.sortOrder
	};
}
function _temp3(a, b) {
	return a.sortOrder - b.sortOrder;
}
function _temp4(a_0, b_0) {
	return caseFirstCompare(a_0.path, b_0.path);
}
var DiffOverlay_module_default = {
	body: "DiffOverlay-module_HBq8kq_body",
	diffContainer: "DiffOverlay-module_HBq8kq_diffContainer",
	diffPanel: "DiffOverlay-module_HBq8kq_diffPanel",
	diffPreview: "DiffOverlay-module_HBq8kq_diffPreview",
	emptyState: "DiffOverlay-module_HBq8kq_emptyState",
	fileTreePanel: "DiffOverlay-module_HBq8kq_fileTreePanel",
	fileTreePanelHeader: "DiffOverlay-module_HBq8kq_fileTreePanelHeader",
	fileTreePanelMobileOpen: "DiffOverlay-module_HBq8kq_fileTreePanelMobileOpen",
	fileTreePanelTitle: "DiffOverlay-module_HBq8kq_fileTreePanelTitle",
	header: "DiffOverlay-module_HBq8kq_header",
	headerActions: "DiffOverlay-module_HBq8kq_headerActions",
	headerButton: "DiffOverlay-module_HBq8kq_headerButton",
	headerLeft: "DiffOverlay-module_HBq8kq_headerLeft",
	headerTitle: "DiffOverlay-module_HBq8kq_headerTitle",
	loading: "DiffOverlay-module_HBq8kq_loading",
	overlay: "DiffOverlay-module_HBq8kq_overlay"
};
var MOBILE_BREAKPOINT = 768;
function mapStatus(status) {
	switch (status) {
		case "A": return "ADDED";
		case "D": return "DELETED";
		case "R": return "RENAMED";
		case "C": return "COPIED";
		default: return "MODIFIED";
	}
}
function toDiffDeltas(files) {
	return files.map((file) => ({
		path: file.path,
		pathDigest: file.path_digest,
		changeType: mapStatus(file.status)
	}));
}
function DiffOverlay({ isOpen, onClose, repoNwo, taskId, baseRef, headRef, initialFilePath }) {
	const { data: diffs, isLoading } = useTaskDiffs(repoNwo, taskId, baseRef, headRef, {
		includePatch: true,
		enabled: isOpen
	});
	const overlayRef = useRef(null);
	useOnEscapePress(onClose, [onClose]);
	const [isMobile, setIsMobile] = useState(false);
	const [fileTreeOverride, setFileTreeOverride] = useState(null);
	useEffect(() => {
		const el = overlayRef.current;
		if (!el) return;
		let prevWidth = null;
		const observer = new ResizeObserver(([entry]) => {
			if (!entry) return;
			const width = entry.contentRect.width;
			const nowMobile = width <= MOBILE_BREAKPOINT;
			if (prevWidth !== null && nowMobile !== (prevWidth !== null && prevWidth <= MOBILE_BREAKPOINT)) setFileTreeOverride(null);
			prevWidth = width;
			setIsMobile(nowMobile);
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, [isOpen]);
	const showFileTree = fileTreeOverride ?? !isMobile;
	const diffPanelRef = useRef(null);
	const scrollToFile = useCallback((filePath) => {
		const panel = diffPanelRef.current;
		if (!panel) return;
		const element = panel.querySelector(`[data-file-path="${CSS.escape(filePath)}"]`);
		if (element) panel.scrollTo({
			top: element.offsetTop - panel.offsetTop,
			behavior: "smooth"
		});
	}, [diffPanelRef]);
	const handleFileSelect = useCallback((filePath_0) => {
		scrollToFile(filePath_0);
		if (isMobile) setFileTreeOverride(false);
	}, [scrollToFile, isMobile]);
	const diffDeltas = diffs ? toDiffDeltas(diffs.files) : [];
	const fileNodeRenderer = useCallback(({ file }) => {
		return /* @__PURE__ */ jsxs(TreeView.Item, {
			id: file.diff.path,
			onSelect: () => handleFileSelect(file.filePath),
			children: [/* @__PURE__ */ jsx(TreeView.LeadingVisual, { children: /* @__PURE__ */ jsx(FileStatusIcon, { status: file.diff.changeType }) }), file.fileName]
		}, file.diff.pathDigest);
	}, [handleFileSelect]);
	useEffect(() => {
		if (isOpen && initialFilePath && diffs && !isLoading) scrollToFile(initialFilePath);
	}, [
		isOpen,
		initialFilePath,
		diffs,
		isLoading,
		scrollToFile
	]);
	if (!isOpen) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: DiffOverlay_module_default.overlay,
		ref: overlayRef,
		children: [/* @__PURE__ */ jsxs("div", {
			className: DiffOverlay_module_default.header,
			children: [/* @__PURE__ */ jsx("div", {
				className: DiffOverlay_module_default.headerLeft,
				children: /* @__PURE__ */ jsx("span", {
					className: DiffOverlay_module_default.headerTitle,
					children: diffs ? `${diffs.files.length} file${diffs.files.length !== 1 ? "s" : ""} changed` : "Changed files"
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: DiffOverlay_module_default.headerActions,
				children: [/* @__PURE__ */ jsx(IconButton, {
					icon: showFileTree ? SidebarCollapseIcon : SidebarExpandIcon,
					"aria-label": showFileTree ? "Collapse file tree" : "Expand file tree",
					variant: "invisible",
					size: "small",
					onClick: () => setFileTreeOverride(!showFileTree),
					className: DiffOverlay_module_default.headerButton
				}), /* @__PURE__ */ jsx(IconButton, {
					icon: XIcon,
					"aria-label": "Close diff overlay",
					variant: "invisible",
					size: "small",
					onClick: onClose,
					className: DiffOverlay_module_default.headerButton
				})]
			})]
		}), /* @__PURE__ */ jsx("div", {
			className: DiffOverlay_module_default.body,
			children: isLoading ? /* @__PURE__ */ jsx("div", {
				className: DiffOverlay_module_default.loading,
				children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
			}) : !diffs || diffs.files.length === 0 ? /* @__PURE__ */ jsx("div", {
				className: DiffOverlay_module_default.emptyState,
				children: "No changes found."
			}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
				className: DiffOverlay_module_default.diffPanel,
				ref: diffPanelRef,
				children: diffs.files.map((file_0) => /* @__PURE__ */ jsx(DiffFileEntry, {
					file: file_0,
					repoNwo,
					headRef
				}, file_0.path))
			}), showFileTree && /* @__PURE__ */ jsxs("div", {
				className: clsx(DiffOverlay_module_default.fileTreePanel, isMobile && fileTreeOverride === true && DiffOverlay_module_default.fileTreePanelMobileOpen),
				children: [/* @__PURE__ */ jsxs("div", {
					className: DiffOverlay_module_default.fileTreePanelHeader,
					children: [/* @__PURE__ */ jsx("span", {
						className: DiffOverlay_module_default.fileTreePanelTitle,
						children: "Files"
					}), /* @__PURE__ */ jsx(IconButton, {
						icon: XIcon,
						"aria-label": "Close file tree",
						variant: "invisible",
						size: "small",
						onClick: () => setFileTreeOverride(false),
						className: DiffOverlay_module_default.headerButton
					})]
				}), /* @__PURE__ */ jsx(DiffFileTree, {
					diffs: diffDeltas,
					fileNodeRenderer,
					sortByDiffOrder: true
				})]
			})] })
		})]
	});
}
DiffOverlay.displayName = "DiffOverlay";
function DiffFileEntry(t0) {
	const $ = c$1(10);
	const { file, repoNwo, headRef } = t0;
	const [isExpanded, setIsExpanded] = useState(true);
	let t1;
	if ($[0] !== file || $[1] !== headRef || $[2] !== isExpanded || $[3] !== repoNwo) {
		const [owner, repo] = repoNwo.split("/", 2);
		const fileLinkHref = owner && repo ? blobPath({
			owner,
			repo,
			commitish: headRef,
			filePath: file.path
		}) : void 0;
		let t2;
		bb0: {
			if (file.lines) {
				let t3;
				if ($[5] !== file.lines) {
					t3 = file.lines.map(_temp$5);
					$[5] = file.lines;
					$[6] = t3;
				} else t3 = $[6];
				t2 = t3;
				break bb0;
			}
			let t3;
			if ($[7] !== file.patch) {
				t3 = file.patch ? parseUnifiedDiff(file.patch) : [];
				$[7] = file.patch;
				$[8] = t3;
			} else t3 = $[8];
			t2 = t3;
		}
		const diffLines = t2;
		let t3;
		if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = () => setIsExpanded(_temp2$1);
			$[9] = t3;
		} else t3 = $[9];
		t1 = jsxs("div", {
			"data-file-path": file.path,
			id: file.path,
			children: [jsx(DiffFileHeader, {
				isCollapsed: !isExpanded,
				onToggleFileCollapsed: t3,
				fileLinkHref,
				path: file.path,
				newPath: file.path,
				patchStatus: mapStatus(file.status),
				linesAdded: file.additions,
				linesDeleted: file.deletions,
				linesChanged: file.changes
			}), isExpanded && jsx("div", {
				className: DiffOverlay_module_default.diffContainer,
				children: diffLines.length > 0 ? jsx(StaticUnifiedDiffPreview, {
					diffLines,
					tabSize: 4,
					className: DiffOverlay_module_default.diffPreview
				}) : jsx("div", {
					className: DiffOverlay_module_default.emptyState,
					children: "Binary file or no patch available."
				})
			})]
		});
		$[0] = file;
		$[1] = headRef;
		$[2] = isExpanded;
		$[3] = repoNwo;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
DiffFileEntry.displayName = "DiffFileEntry";
function _temp2$1(v) {
	return !v;
}
function _temp$5(line) {
	return {
		type: line.type.toUpperCase(),
		html: line.html,
		text: line.text,
		left: line.left,
		right: line.right
	};
}
var fetchPullRequest = async (pullRequestId, options = {}) => {
	const { includeBody = false } = options;
	const url = new URL("/copilot/agent-sessions/pull-requests", window.location.origin);
	url.searchParams.set("pull_request_ids", String(pullRequestId));
	if (includeBody) url.searchParams.set("include_body", "true");
	const response = await fetch(url.toString(), { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error(`Failed to fetch pull request ${pullRequestId}`);
	const pullRequest = (await response.json()).pull_requests[pullRequestId];
	if (!pullRequest) throw new Error(`Pull request ${pullRequestId} not found`);
	return pullRequest;
};
function usePullRequest(t0) {
	const $ = c$1(25);
	const { pullRequestId, includeBody: t1, initialData, enabled: t2, refetchOnMount: t3 } = t0;
	const includeBody = t1 === void 0 ? false : t1;
	const enabled = t2 === void 0 ? true : t2;
	const refetchOnMount = t3 === void 0 ? false : t3;
	const queryClient = useQueryClient();
	let t4;
	if ($[0] !== includeBody || $[1] !== pullRequestId) {
		t4 = [
			"pull-request",
			pullRequestId,
			includeBody
		];
		$[0] = includeBody;
		$[1] = pullRequestId;
		$[2] = t4;
	} else t4 = $[2];
	const queryKey = t4;
	let t5;
	if ($[3] !== includeBody || $[4] !== pullRequestId) {
		t5 = () => {
			if (!pullRequestId) throw new Error("pullRequestId is required");
			return fetchPullRequest(pullRequestId, { includeBody });
		};
		$[3] = includeBody;
		$[4] = pullRequestId;
		$[5] = t5;
	} else t5 = $[5];
	const queryFn = t5;
	const staleTime = refetchOnMount || !initialData ? 0 : 3e5;
	const t6 = enabled && pullRequestId !== void 0;
	let t7;
	if ($[6] !== initialData || $[7] !== queryFn || $[8] !== queryKey || $[9] !== staleTime || $[10] !== t6) {
		t7 = {
			queryKey,
			queryFn,
			initialData,
			staleTime,
			enabled: t6
		};
		$[6] = initialData;
		$[7] = queryFn;
		$[8] = queryKey;
		$[9] = staleTime;
		$[10] = t6;
		$[11] = t7;
	} else t7 = $[11];
	const { data, refetch: refetchAll } = useQuery(t7);
	let t8;
	if ($[12] !== pullRequestId || $[13] !== queryClient || $[14] !== queryKey) {
		t8 = async () => {
			if (!pullRequestId) throw new Error("pullRequestId is required");
			const bodyData = await fetchPullRequest(pullRequestId, { includeBody: true });
			queryClient.setQueryData(queryKey, (oldData) => {
				if (!oldData) return bodyData;
				return {
					...oldData,
					body: bodyData.body,
					body_html: bodyData.body_html,
					body_revision_count: bodyData.body_revision_count
				};
			});
		};
		$[12] = pullRequestId;
		$[13] = queryClient;
		$[14] = queryKey;
		$[15] = t8;
	} else t8 = $[15];
	const refetchBody = t8;
	let t9;
	if ($[16] !== pullRequestId || $[17] !== queryClient || $[18] !== queryKey) {
		t9 = async () => {
			if (!pullRequestId) throw new Error("pullRequestId is required");
			const headerData = await fetchPullRequest(pullRequestId, { includeBody: false });
			queryClient.setQueryData(queryKey, (oldData_0) => {
				if (!oldData_0) return headerData;
				return {
					...oldData_0,
					title: headerData.title,
					head_sha: headerData.head_sha,
					changed_files: headerData.changed_files,
					commit_alive_channel: headerData.commit_alive_channel
				};
			});
		};
		$[16] = pullRequestId;
		$[17] = queryClient;
		$[18] = queryKey;
		$[19] = t9;
	} else t9 = $[19];
	const refetchPullRequest = t9;
	let t10;
	if ($[20] !== data || $[21] !== refetchAll || $[22] !== refetchBody || $[23] !== refetchPullRequest) {
		t10 = {
			data,
			refetch: refetchAll,
			refetchBody,
			refetchPullRequest
		};
		$[20] = data;
		$[21] = refetchAll;
		$[22] = refetchBody;
		$[23] = refetchPullRequest;
		$[24] = t10;
	} else t10 = $[24];
	return t10;
}
/**
* Navigate to the new thread page.
* In assistive mode, creates a new thread in-place without navigating away.
*/
function useNavigateToNewThread() {
	const $ = c$1(4);
	const manager = useChatManager();
	const navigate = useNavigate$1();
	const isAssistive = useChatStateLens(_temp$4);
	let t0;
	if ($[0] !== isAssistive || $[1] !== manager || $[2] !== navigate) {
		t0 = async (newThreadOptions) => {
			if (isAssistive) {
				await manager.selectThread(null, newThreadOptions);
				return;
			}
			if (window.location.pathname !== "/copilot") navigate(COPILOT_PATH);
			await manager.selectThread(null, newThreadOptions);
		};
		$[0] = isAssistive;
		$[1] = manager;
		$[2] = navigate;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
function _temp$4(s) {
	return s.mode === "assistive";
}
var ConversationActions_module_default = { hideOnDesktop: "ConversationActions-module_aNf9EG_hideOnDesktop" };
var ConversationSharingDialog_module_default = {
	buttonStack: "ConversationSharingDialog-module_GMQ_uG_buttonStack",
	cancelButton: "ConversationSharingDialog-module_GMQ_uG_cancelButton",
	container: "ConversationSharingDialog-module_GMQ_uG_container",
	infoIcon: "ConversationSharingDialog-module_GMQ_uG_infoIcon",
	innerContainer: "ConversationSharingDialog-module_GMQ_uG_innerContainer",
	lockIcon: "ConversationSharingDialog-module_GMQ_uG_lockIcon",
	mutedText: "ConversationSharingDialog-module_GMQ_uG_mutedText",
	quickFadeUp: "ConversationSharingDialog-module_GMQ_uG_quickFadeUp",
	sharedLinkContainer: "ConversationSharingDialog-module_GMQ_uG_sharedLinkContainer",
	snapshotText: "ConversationSharingDialog-module_GMQ_uG_snapshotText",
	spinner: "ConversationSharingDialog-module_GMQ_uG_spinner",
	success: "ConversationSharingDialog-module_GMQ_uG_success",
	successIcon: "ConversationSharingDialog-module_GMQ_uG_successIcon",
	textInput: "ConversationSharingDialog-module_GMQ_uG_textInput",
	textInputContainer: "ConversationSharingDialog-module_GMQ_uG_textInputContainer",
	warningText: "ConversationSharingDialog-module_GMQ_uG_warningText"
};
var ConversationSharingDialog = (t0) => {
	const $ = c$1(70);
	const { closeDialog, threadId, returnFocusRef } = t0;
	const state = useChatState();
	const manager = useChatManager();
	const [copied, setCopied] = useState(false);
	const [loading, setLoading] = useState(false);
	const [showSharedSuccess, setShowSharedSuccess] = useState(false);
	const [showConfirmationText, setShowConfirmationText] = useState(false);
	const { selectedThreadID, ssoOrganizations, apiUrl, threads } = state;
	let t1;
	if ($[0] !== selectedThreadID || $[1] !== threadId || $[2] !== threads) {
		t1 = threads.get(threadId || selectedThreadID);
		$[0] = selectedThreadID;
		$[1] = threadId;
		$[2] = threads;
		$[3] = t1;
	} else t1 = $[3];
	const selectedThread = t1;
	let t2;
	if ($[4] !== selectedThread?.sharedID) {
		t2 = () => selectedThread?.sharedID || "";
		$[4] = selectedThread?.sharedID;
		$[5] = t2;
	} else t2 = $[5];
	const [sharedThreadId, setSharedThreadId] = useState(t2);
	let t3;
	if ($[6] !== selectedThread) {
		t3 = () => selectedThread?.sharedMessageID ? selectedThread.sharedMessageID : "";
		$[6] = selectedThread;
		$[7] = t3;
	} else t3 = $[7];
	const [sharedMessageId, setSharedMessageId] = useState(t3);
	const sharedLink = `${ssrSafeLocation.origin}/copilot/share/${sharedThreadId}`;
	let t4;
	let t5;
	if ($[8] !== copied) {
		t4 = () => {
			if (copied) {
				const timer = setTimeout(() => setCopied(false), 1500);
				return () => clearTimeout(timer);
			}
		};
		t5 = [copied];
		$[8] = copied;
		$[9] = t4;
		$[10] = t5;
	} else {
		t4 = $[9];
		t5 = $[10];
	}
	useEffect(t4, t5);
	let t6;
	let t7;
	if ($[11] !== showSharedSuccess) {
		t6 = () => {
			if (showSharedSuccess) {
				const timer_0 = setTimeout(() => setShowSharedSuccess(false), 1500);
				return () => clearTimeout(timer_0);
			}
		};
		t7 = [showSharedSuccess];
		$[11] = showSharedSuccess;
		$[12] = t6;
		$[13] = t7;
	} else {
		t6 = $[12];
		t7 = $[13];
	}
	useEffect(t6, t7);
	let t8;
	if ($[14] !== sharedLink) {
		t8 = async () => {
			try {
				await copyText(sharedLink);
				setCopied(true);
				sendEvent("dotcom_chat.activate", {
					target: "COPILOT_COPY_SHARED_CONVERSATION_LINK",
					mode: "immersive"
				});
			} catch {}
		};
		$[14] = sharedLink;
		$[15] = t8;
	} else t8 = $[15];
	const copySharedLink = t8;
	let t9;
	if ($[16] !== selectedThread?.sharedID || $[17] !== selectedThreadID || $[18] !== threadId) {
		t9 = () => {
			if (threadId || selectedThreadID) setSharedThreadId(selectedThread?.sharedID || "");
		};
		$[16] = selectedThread?.sharedID;
		$[17] = selectedThreadID;
		$[18] = threadId;
		$[19] = t9;
	} else t9 = $[19];
	const t10 = selectedThread?.sharedID;
	let t11;
	if ($[20] !== selectedThreadID || $[21] !== t10 || $[22] !== threadId) {
		t11 = [
			t10,
			selectedThreadID,
			threadId
		];
		$[20] = selectedThreadID;
		$[21] = t10;
		$[22] = threadId;
		$[23] = t11;
	} else t11 = $[23];
	useEffect(t9, t11);
	let t12;
	if ($[24] !== apiUrl || $[25] !== manager || $[26] !== selectedThreadID || $[27] !== ssoOrganizations || $[28] !== threadId) {
		t12 = async () => {
			setLoading(true);
			const id_0 = threadId || selectedThreadID;
			const res = await new CopilotChatService(apiUrl, ssoOrganizations).shareThread(id_0, copilotFeatureFlags.copilotShareActiveSubthread && id_0 === selectedThreadID ? manager.FindLastMessageID() : "");
			if (res.ok) {
				setLoading(false);
				const { sharedAt, sharedID, sharedMessageID } = res.payload;
				setSharedThreadId(sharedID);
				setShowSharedSuccess(true);
				setSharedMessageId(sharedMessageID);
				manager.dispatch({
					type: "SHARED_THREAD_UPDATED",
					thread: {
						id: id_0,
						sharedID,
						sharedAt,
						sharedMessageID
					}
				});
				sendEvent("dotcom_chat.activate", {
					target: "COPILOT_CREATE_SHARED_CONVERSATION",
					mode: "immersive",
					originalThreadId: id_0,
					sharedThreadId: sharedID
				});
			} else setLoading(false);
		};
		$[24] = apiUrl;
		$[25] = manager;
		$[26] = selectedThreadID;
		$[27] = ssoOrganizations;
		$[28] = threadId;
		$[29] = t12;
	} else t12 = $[29];
	const handleCreateLink = t12;
	let t13;
	if ($[30] !== apiUrl || $[31] !== manager || $[32] !== selectedThreadID || $[33] !== sharedThreadId || $[34] !== showConfirmationText || $[35] !== ssoOrganizations || $[36] !== threadId) {
		t13 = async () => {
			if (!showConfirmationText) {
				setShowConfirmationText(true);
				return;
			}
			setShowConfirmationText(false);
			setLoading(true);
			const id_1 = threadId || selectedThreadID;
			const previousSharedID = sharedThreadId;
			const res_0 = await new CopilotChatService(apiUrl, ssoOrganizations).unshareThread(id_1);
			if (res_0.ok) {
				setLoading(false);
				setSharedMessageId("");
				const { sharedID: sharedID_0, sharedAt: sharedAt_0, sharedMessageID: sharedMessageID_0 } = res_0.payload;
				manager.dispatch({
					type: "SHARED_THREAD_UPDATED",
					thread: {
						id: id_1,
						sharedID: sharedID_0,
						sharedAt: sharedAt_0,
						sharedMessageID: sharedMessageID_0
					}
				});
				sendEvent("dotcom_chat.activate", {
					target: "COPILOT_UNSHARE_CONVERSATION",
					mode: "immersive",
					originalThreadId: id_1,
					sharedThreadId: previousSharedID
				});
			} else setLoading(false);
		};
		$[30] = apiUrl;
		$[31] = manager;
		$[32] = selectedThreadID;
		$[33] = sharedThreadId;
		$[34] = showConfirmationText;
		$[35] = ssoOrganizations;
		$[36] = threadId;
		$[37] = t13;
	} else t13 = $[37];
	const handleUnshareClick = t13;
	let t14;
	if ($[38] !== handleCreateLink || $[39] !== loading || $[40] !== sharedThreadId) {
		t14 = () => {
			if (sharedThreadId) return;
			return jsx(ButtonComponent$1, {
				variant: "primary",
				disabled: loading,
				onClick: handleCreateLink,
				children: "Share"
			});
		};
		$[38] = handleCreateLink;
		$[39] = loading;
		$[40] = sharedThreadId;
		$[41] = t14;
	} else t14 = $[41];
	const shareButton = t14;
	let t15;
	if ($[42] !== copySharedLink || $[43] !== sharedThreadId) {
		t15 = () => {
			if (!sharedThreadId) return;
			return jsx(ButtonComponent$1, {
				variant: "primary",
				autoFocus: true,
				onClick: copySharedLink,
				children: "Copy link"
			});
		};
		$[42] = copySharedLink;
		$[43] = sharedThreadId;
		$[44] = t15;
	} else t15 = $[44];
	const copyButton = t15;
	let t16;
	if ($[45] !== handleUnshareClick || $[46] !== loading || $[47] !== sharedThreadId) {
		t16 = () => {
			if (!sharedThreadId) return;
			return jsx(ButtonComponent$1, {
				variant: "danger",
				disabled: loading,
				onClick: handleUnshareClick,
				children: "Unshare"
			});
		};
		$[45] = handleUnshareClick;
		$[46] = loading;
		$[47] = sharedThreadId;
		$[48] = t16;
	} else t16 = $[48];
	const unshareButton = t16;
	let t17;
	if ($[49] !== sharedThreadId || $[50] !== showConfirmationText) {
		t17 = () => {
			if (!sharedThreadId || !showConfirmationText) return;
			return jsx(ButtonComponent$1, {
				variant: "default",
				onClick: () => setShowConfirmationText(false),
				className: ConversationSharingDialog_module_default.cancelButton,
				children: "Cancel"
			});
		};
		$[49] = sharedThreadId;
		$[50] = showConfirmationText;
		$[51] = t17;
	} else t17 = $[51];
	const cancelButton = t17;
	let t18;
	if ($[52] !== copied || $[53] !== loading || $[54] !== sharedThreadId || $[55] !== showConfirmationText || $[56] !== showSharedSuccess) {
		t18 = () => {
			if (loading) return jsxs("div", {
				className: ConversationSharingDialog_module_default.quickFadeUp,
				children: [jsx(Spinner, {
					size: "small",
					className: ConversationSharingDialog_module_default.spinner
				}), sharedThreadId ? "Unsharing chat..." : "Sharing chat..."]
			});
			if (showConfirmationText) return jsx("div", {
				className: ConversationSharingDialog_module_default.quickFadeUp,
				children: jsx(Text$1, {
					size: "medium",
					className: ConversationSharingDialog_module_default.warningText,
					children: "Confirm unsharing this chat?"
				})
			});
			if (copied) return jsxs("div", {
				className: ConversationSharingDialog_module_default.quickFadeUp,
				children: [jsx(CheckIcon, { className: ConversationSharingDialog_module_default.successIcon }), jsx(Text$1, {
					size: "medium",
					className: ConversationSharingDialog_module_default.success,
					children: "Copied to clipboard"
				})]
			});
			if (showSharedSuccess) return jsxs("div", {
				className: ConversationSharingDialog_module_default.quickFadeUp,
				children: [jsx(CheckIcon, { className: ConversationSharingDialog_module_default.successIcon }), jsx(Text$1, {
					size: "medium",
					className: ConversationSharingDialog_module_default.success,
					children: "Chat shared"
				})]
			});
			if (sharedThreadId) return jsxs("div", { children: [jsx(UnlockIcon, { className: ConversationSharingDialog_module_default.lockIcon }), jsx(Text$1, {
				size: "medium",
				className: ConversationSharingDialog_module_default.mutedText,
				children: "Visible to anyone with the link"
			})] });
			return jsx("div", {});
		};
		$[52] = copied;
		$[53] = loading;
		$[54] = sharedThreadId;
		$[55] = showConfirmationText;
		$[56] = showSharedSuccess;
		$[57] = t18;
	} else t18 = $[57];
	const getStateDisplay = t18;
	const t19 = sharedThreadId ? "Chat shared" : "Share chat";
	let t20;
	if ($[58] !== cancelButton || $[59] !== closeDialog || $[60] !== copyButton || $[61] !== getStateDisplay || $[62] !== returnFocusRef || $[63] !== shareButton || $[64] !== sharedLink || $[65] !== sharedMessageId || $[66] !== sharedThreadId || $[67] !== t19 || $[68] !== unshareButton) {
		t20 = jsx(Dialog, {
			title: t19,
			onClose: closeDialog,
			width: "large",
			returnFocusRef,
			children: jsxs("div", {
				className: ConversationSharingDialog_module_default.container,
				children: [jsxs(Stack, {
					direction: "vertical",
					gap: "condensed",
					children: [jsx(Stack, {
						direction: "horizontal",
						padding: "none",
						align: "center",
						justify: "start",
						gap: "condensed",
						children: sharedMessageId ? jsx("span", { children: jsx("span", {
							className: ConversationSharingDialog_module_default.snapshotText,
							children: "This shared chat is a snapshot, accessible to anyone with the link. It will not update with new messages."
						}) }) : sharedThreadId ? jsx("span", { children: "This chat and future messages are visible to anyone with the link. If private repository content is included, repository access is required to view." }) : jsx("span", { children: "When shared, this chat and future messages will be visible to anyone with the link. If private repository content is included, repository access is required to view." })
					}), sharedThreadId && jsx("div", {
						className: ConversationSharingDialog_module_default.innerContainer,
						children: jsx("div", {
							className: ConversationSharingDialog_module_default.sharedLinkContainer,
							children: jsxs(FormControl$1, {
								id: "share-link",
								className: ConversationSharingDialog_module_default.textInputContainer,
								children: [jsx(FormControl$1.Label, { children: "Share link" }), jsx(TextInput$1, {
									size: "large",
									readOnly: true,
									value: sharedThreadId && sharedLink,
									className: ConversationSharingDialog_module_default.textInput
								})]
							})
						})
					})]
				}), jsxs(Stack, {
					direction: "horizontal",
					gap: "condensed",
					align: "center",
					justify: "space-between",
					className: ConversationSharingDialog_module_default.buttonStack,
					children: [jsx("div", {
						role: "status",
						children: getStateDisplay()
					}), jsxs(Stack, {
						direction: "horizontal",
						gap: "condensed",
						align: "center",
						justify: "end",
						children: [
							shareButton(),
							cancelButton(),
							unshareButton(),
							copyButton()
						]
					})]
				})]
			})
		});
		$[58] = cancelButton;
		$[59] = closeDialog;
		$[60] = copyButton;
		$[61] = getStateDisplay;
		$[62] = returnFocusRef;
		$[63] = shareButton;
		$[64] = sharedLink;
		$[65] = sharedMessageId;
		$[66] = sharedThreadId;
		$[67] = t19;
		$[68] = unshareButton;
		$[69] = t20;
	} else t20 = $[69];
	return t20;
};
ConversationSharingDialog.displayName = "ConversationSharingDialog";
var FILE_TYPE_CONFIGS = {
	json: {
		name: "JSON",
		mimeType: "application/json",
		exportHandler: generateJsonExport
	},
	md: {
		name: "Markdown",
		mimeType: "text/markdown",
		exportHandler: generateMarkdownExport
	}
};
function threadUrl(threadId) {
	return `${window.location.origin}/copilot/c/${threadId}`;
}
function filterMessageFields(message) {
	return {
		id: message.id,
		parentMessageID: message.parentMessageID,
		intent: message.intent,
		role: message.role,
		model: message.model,
		content: message.content,
		createdAt: message.createdAt,
		threadID: message.threadID,
		references: message.references,
		skillExecutions: message.skillExecutions
	};
}
function formatMessagesAsJson(messages, files, currentUserLogin, threadId, threadName) {
	const filteredMessages = messages.map(filterMessageFields);
	const filesObject = Object.fromEntries(files);
	const metaData = {
		currentUserLogin,
		threadUrl: threadUrl(threadId),
		threadName,
		messages: filteredMessages,
		files: filesObject
	};
	return JSON.stringify(metaData, null, 2);
}
function generateJsonExport(messages, files, currentUserLogin, threadId, threadName) {
	const jsonData = formatMessagesAsJson(messages, files, currentUserLogin, threadId, threadName);
	const blob = new Blob([jsonData], { type: FILE_TYPE_CONFIGS["json"].mimeType });
	return {
		url: URL.createObjectURL(blob),
		exportName: `${fileName(threadName)}.json`
	};
}
function formatMessagesAsMarkdown(messages, currentUserLogin, threadId, threadName) {
	const filteredMessages = messages.filter((message) => message.id !== "root");
	const parentMap = /* @__PURE__ */ new Map();
	for (const message of filteredMessages) {
		const parentId = message.parentMessageID;
		if (parentId) {
			if (!parentMap.has(parentId)) parentMap.set(parentId, { childMessageCount: 0 });
			const entry = parentMap.get(parentId);
			entry.childMessageCount += 1;
		}
	}
	return `${`# Copilot Chat Conversation Export: ${threadName}

**User:** @${currentUserLogin}
**Thread URL:** ${threadUrl(threadId)}`}\n\n${filteredMessages.map((message) => {
		let messageContent = `${message.role === "user" ? `## @${currentUserLogin}` : "## Copilot"}\n\n${message.content || ""}\n`;
		if (message.parentMessageID) {
			const parentMessage = parentMap.get(message.parentMessageID);
			if (parentMessage && parentMessage.childMessageCount > 1) messageContent += `\n*System: User retried message*\n`;
		}
		return messageContent;
	}).join("\n")}`;
}
async function generateMarkdownExport(messages, files, currentUserLogin, threadId, threadName) {
	const markdownChatMessages = formatMessagesAsMarkdown(messages, currentUserLogin, threadId, threadName);
	const content = [new File([markdownChatMessages], `${fileName(threadName)}.md`)];
	if (files.size > 0) {
		for (const [, versions] of files) for (const item of versions) if ("value" in item && typeof item.value === "string") content.push(new File([item.value], `v${item.version}_${item.name}`));
		const blob = await downloadZip(content).blob();
		return {
			url: URL.createObjectURL(blob),
			exportName: `${fileName(threadName)}.zip`
		};
	} else {
		const blob = new Blob(content, { type: FILE_TYPE_CONFIGS["md"].mimeType });
		return {
			url: URL.createObjectURL(blob),
			exportName: `${fileName(threadName)}.md`
		};
	}
}
function fileName(threadName) {
	return snakeCase(`${(/* @__PURE__ */ new Date()).toDateString()} ${threadName}`);
}
function sendTelemetryEvent(target) {
	sendEvent("dotcom_chat.activate", {
		target,
		mode: "immersive"
	});
}
function hydrateVersionedFiles(items, versionedItems) {
	const hydratedMap = /* @__PURE__ */ new Map();
	for (const [, versionIds] of versionedItems) {
		const hydratedVersions = versionIds.map((versionId) => items.get(versionId)).filter((item) => item !== void 0).map((item, index) => ({
			version: index + 1,
			...item
		}));
		if (hydratedVersions.length > 0 && hydratedVersions[0]?.type === "file" && hydratedVersions[0]?.name) hydratedMap.set(hydratedVersions[0].name, hydratedVersions);
	}
	return hydratedMap;
}
var ERROR_MESSAGE = "There was an error exporting the conversation. Please try again.";
function ExportActionItem(t0) {
	const $ = c$1(18);
	const { fileType, threadName, threadId, currentUserLogin, messages } = t0;
	const manager = useChatManager();
	const { items, versionedItems } = useContentPreview();
	let t1;
	if ($[0] !== items || $[1] !== versionedItems) {
		t1 = hydrateVersionedFiles(items, versionedItems);
		$[0] = items;
		$[1] = versionedItems;
		$[2] = t1;
	} else t1 = $[2];
	const hydratedFiles = t1;
	const displayName = FILE_TYPE_CONFIGS[fileType].name;
	let t2;
	if ($[3] !== displayName) {
		t2 = displayName.toUpperCase();
		$[3] = displayName;
		$[4] = t2;
	} else t2 = $[4];
	const telemetryTarget = `CONVERSATION_CONTEXT_MENU_EXPORT_${t2}`;
	let t3;
	if ($[5] !== currentUserLogin || $[6] !== fileType || $[7] !== hydratedFiles || $[8] !== manager || $[9] !== messages || $[10] !== telemetryTarget || $[11] !== threadId || $[12] !== threadName) {
		t3 = async () => {
			try {
				const { url, exportName } = await FILE_TYPE_CONFIGS[fileType].exportHandler(messages, hydratedFiles, currentUserLogin, threadId, threadName);
				const a = document.createElement("a");
				a.href = url;
				a.download = exportName;
				a.style.display = "none";
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				sendTelemetryEvent(`${telemetryTarget}_SUCCEEDED`);
				setTimeout(() => URL.revokeObjectURL(url), 0);
			} catch {
				sendTelemetryEvent(`${telemetryTarget}_DOWNLOAD_FAILED`);
				manager.addAmbientError(ERROR_MESSAGE);
			}
		};
		$[5] = currentUserLogin;
		$[6] = fileType;
		$[7] = hydratedFiles;
		$[8] = manager;
		$[9] = messages;
		$[10] = telemetryTarget;
		$[11] = threadId;
		$[12] = threadName;
		$[13] = t3;
	} else t3 = $[13];
	const handleSelect = t3;
	const t4 = `Export conversation as ${displayName}`;
	let t5;
	if ($[14] !== displayName || $[15] !== handleSelect || $[16] !== t4) {
		t5 = jsx(ActionList.Item, {
			"aria-label": t4,
			onSelect: handleSelect,
			children: displayName
		});
		$[14] = displayName;
		$[15] = handleSelect;
		$[16] = t4;
		$[17] = t5;
	} else t5 = $[17];
	return t5;
}
ExportActionItem.displayName = "ExportActionItem";
function ExportActionList({ threadName, threadId, currentUserLogin, messages, selectedThreadID }) {
	if (!(selectedThreadID === threadId)) return null;
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs(ActionList.Item, { children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(DownloadIcon, {}) }), "Export"] }) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, { children: [/* @__PURE__ */ jsx(ExportActionItem, {
		threadName,
		fileType: "json",
		threadId,
		currentUserLogin,
		messages
	}), /* @__PURE__ */ jsx(ExportActionItem, {
		threadName,
		fileType: "md",
		threadId,
		currentUserLogin,
		messages
	})] }) })] });
}
ExportActionList.displayName = "ExportActionList";
function ConversationActions(t0) {
	const $ = c$1(18);
	const { onOpenDialog, showShare: t1, hideShareOnDesktop: t2, isShared: t3, threadName, threadId } = t0;
	const showShare = t1 === void 0 ? true : t1;
	const hideShareOnDesktop = t2 === void 0 ? false : t2;
	const isShared = t3 === void 0 ? false : t3;
	const { canShareThread } = useAppPayload();
	const { isWaitingOnCopilot, messages, currentUserLogin, selectedThreadID } = useChatState();
	let t4;
	if ($[0] !== messages) {
		t4 = findAgentCorrespondents(messages);
		$[0] = messages;
		$[1] = t4;
	} else t4 = $[1];
	const shareDisabled = t4.length > 0 || isWaitingOnCopilot;
	let t5;
	if ($[2] !== canShareThread || $[3] !== currentUserLogin || $[4] !== hideShareOnDesktop || $[5] !== isShared || $[6] !== messages || $[7] !== onOpenDialog || $[8] !== selectedThreadID || $[9] !== shareDisabled || $[10] !== showShare || $[11] !== threadId || $[12] !== threadName) {
		let t6;
		if ($[14] !== onOpenDialog) {
			t6 = () => {
				sendEvent("dotcom_chat.activate", {
					target: "CONVERSATION_CONTEXT_MENU_RENAME",
					mode: "immersive"
				});
				onOpenDialog("rename");
			};
			$[14] = onOpenDialog;
			$[15] = t6;
		} else t6 = $[15];
		let t7;
		if ($[16] !== onOpenDialog) {
			t7 = () => {
				sendEvent("dotcom_chat.activate", {
					target: "CONVERSATION_CONTEXT_MENU_DELETE",
					mode: "immersive"
				});
				onOpenDialog("delete");
			};
			$[16] = onOpenDialog;
			$[17] = t7;
		} else t7 = $[17];
		t5 = jsxs(Fragment$1, { children: [
			jsxs(ActionList.Item, {
				onSelect: t6,
				children: [jsx(ActionList.LeadingVisual, { children: jsx(PencilIcon, {}) }), "Rename"]
			}),
			showShare && canShareThread && jsxs(ActionList.Item, {
				className: hideShareOnDesktop ? ConversationActions_module_default.hideOnDesktop : void 0,
				disabled: shareDisabled,
				onSelect: () => {
					sendEvent("dotcom_chat.activate", {
						target: "CONVERSATION_CONTEXT_MENU_SHARE",
						mode: "immersive"
					});
					onOpenDialog("share");
				},
				children: [jsx(ActionList.LeadingVisual, { children: isShared ? jsx(UnlockIcon, {}) : jsx(LockIcon, {}) }), "Share"]
			}),
			jsx(ExportActionList, {
				threadName,
				threadId,
				currentUserLogin,
				messages,
				selectedThreadID
			}),
			jsxs(ActionList.Item, {
				variant: "danger",
				onSelect: t7,
				children: [jsx(ActionList.LeadingVisual, { children: jsx(TrashIcon, {}) }), "Delete"]
			})
		] });
		$[2] = canShareThread;
		$[3] = currentUserLogin;
		$[4] = hideShareOnDesktop;
		$[5] = isShared;
		$[6] = messages;
		$[7] = onOpenDialog;
		$[8] = selectedThreadID;
		$[9] = shareDisabled;
		$[10] = showShare;
		$[11] = threadId;
		$[12] = threadName;
		$[13] = t5;
	} else t5 = $[13];
	return t5;
}
ConversationActions.displayName = "ConversationActions";
function ConversationActionDialogs(t0) {
	const $ = c$1(27);
	const { visibleDialog, onClose, threadName, threadId, selectedThreadId, onStartLoading, onFinishLoading, returnFocusRef } = t0;
	const { threads } = useChatState();
	const manager = useChatManager();
	const navigateToNewThread = useNavigateToNewThread();
	let t1;
	if ($[0] !== onClose) {
		t1 = () => {
			sendEvent("dotcom_chat.activate", {
				target: "COPILOT_SHARE_DIALOG_CLOSE",
				mode: "immersive"
			});
			onClose();
		};
		$[0] = onClose;
		$[1] = t1;
	} else t1 = $[1];
	const closeConversationSharingDialog = t1;
	let t2;
	if ($[2] !== manager || $[3] !== navigateToNewThread || $[4] !== onClose || $[5] !== onFinishLoading || $[6] !== onStartLoading || $[7] !== selectedThreadId || $[8] !== threadId || $[9] !== threads) {
		t2 = async () => {
			sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_LIST_ACTION_DELETE",
				mode: "immersive"
			});
			onStartLoading();
			const threadToDelete = threads.get(threadId);
			if (threadToDelete) {
				if (threadId === selectedThreadId) await navigateToNewThread({
					clearTopic: true,
					includeThreads: false
				});
				await manager.deleteThread(threadToDelete);
			}
			onFinishLoading();
			onClose();
		};
		$[2] = manager;
		$[3] = navigateToNewThread;
		$[4] = onClose;
		$[5] = onFinishLoading;
		$[6] = onStartLoading;
		$[7] = selectedThreadId;
		$[8] = threadId;
		$[9] = threads;
		$[10] = t2;
	} else t2 = $[10];
	const confirmDelete = t2;
	let t3;
	if ($[11] !== manager || $[12] !== onClose || $[13] !== onFinishLoading || $[14] !== onStartLoading || $[15] !== threadId || $[16] !== threads) {
		t3 = async (name) => {
			sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_LIST_ACTION_RENAME",
				mode: "immersive"
			});
			onStartLoading();
			const threadToRename = threads.get(threadId);
			if (threadToRename) await manager.renameThread(threadToRename, name);
			onFinishLoading();
			onClose();
		};
		$[11] = manager;
		$[12] = onClose;
		$[13] = onFinishLoading;
		$[14] = onStartLoading;
		$[15] = threadId;
		$[16] = threads;
		$[17] = t3;
	} else t3 = $[17];
	const submitRename = t3;
	let t4;
	if ($[18] !== closeConversationSharingDialog || $[19] !== confirmDelete || $[20] !== onClose || $[21] !== returnFocusRef || $[22] !== submitRename || $[23] !== threadId || $[24] !== threadName || $[25] !== visibleDialog) {
		t4 = jsx(Fragment$1, { children: visibleDialog === "delete" ? jsx(DeleteDialog, {
			onCancel: onClose,
			onConfirm: confirmDelete,
			returnFocusRef
		}) : visibleDialog === "rename" ? jsx(RenameDialog, {
			onCancel: onClose,
			currentName: threadName,
			onSubmit: submitRename,
			returnFocusRef
		}) : visibleDialog === "share" ? jsx(ConversationSharingDialog, {
			closeDialog: closeConversationSharingDialog,
			threadId,
			returnFocusRef
		}) : null });
		$[18] = closeConversationSharingDialog;
		$[19] = confirmDelete;
		$[20] = onClose;
		$[21] = returnFocusRef;
		$[22] = submitRename;
		$[23] = threadId;
		$[24] = threadName;
		$[25] = visibleDialog;
		$[26] = t4;
	} else t4 = $[26];
	return t4;
}
ConversationActionDialogs.displayName = "ConversationActionDialogs";
var DeleteDialog = ({ onConfirm, onCancel, returnFocusRef }) => /* @__PURE__ */ jsx(ConfirmationDialog, {
	title: "Delete chat",
	onClose: (gesture) => {
		if (gesture === "confirm") {
			sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_DIALOG_DELETE_CONFIRM",
				mode: "immersive"
			});
			const closestLandmarkParent = returnFocusRef.current?.closest("nav,aside,section");
			onConfirm();
			window.setTimeout(() => {
				if (closestLandmarkParent instanceof HTMLElement) closestLandmarkParent.focus();
			}, 0);
		} else {
			sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_DIALOG_DELETE_CANCEL",
				mode: "immersive"
			});
			onCancel();
			window.setTimeout(() => returnFocusRef.current?.focus(), 0);
		}
	},
	confirmButtonContent: "Delete",
	confirmButtonType: "danger",
	children: "Are you sure you want to delete this chat? This action cannot be undone."
});
DeleteDialog.displayName = "DeleteDialog";
var RenameDialog = ({ currentName, onCancel, onSubmit, returnFocusRef }) => {
	const [invalid, setInvalid] = useState(void 0);
	const inputRef = useRef(null);
	const formId = useId();
	const dialogId = useId();
	const submit = (event) => {
		event.preventDefault();
		const value = inputRef.current?.value?.trim() ?? "";
		if (!value) {
			setInvalid("required");
			inputRef.current?.focus();
		} else if (value.length > 100) {
			setInvalid("max_length");
			inputRef.current?.focus();
		} else {
			setInvalid(void 0);
			onSubmit(value);
		}
	};
	const handleClose = () => {
		sendEvent("dotcom_chat.activate", {
			target: "CONVERSATION_DIALOG_RENAME_CANCEL",
			mode: "immersive"
		});
		onCancel();
	};
	return /* @__PURE__ */ jsx(Dialog, {
		title: /* @__PURE__ */ jsx("span", {
			id: dialogId,
			children: "Rename chat"
		}),
		onClose: handleClose,
		width: "small",
		footerButtons: [{
			content: "Cancel",
			onClick: handleClose
		}, {
			content: "Update",
			buttonType: "primary",
			type: "submit",
			form: formId,
			onClick: () => sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_DIALOG_RENAME_CONFIRM",
				mode: "immersive"
			})
		}],
		initialFocusRef: inputRef,
		returnFocusRef,
		children: /* @__PURE__ */ jsx("form", {
			id: formId,
			onSubmit: submit,
			children: /* @__PURE__ */ jsxs(FormControl$1, {
				required: true,
				children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, {
						visuallyHidden: true,
						children: "Rename chat"
					}),
					/* @__PURE__ */ jsx(TextInput$1, {
						"aria-labelledby": dialogId,
						"aria-describedby": invalid ? "error-message" : void 0,
						"aria-invalid": invalid ? "true" : void 0,
						ref: inputRef,
						defaultValue: currentName,
						block: true
					}),
					invalid && /* @__PURE__ */ jsx(FormControl$1.Validation, {
						id: "error-message",
						variant: "error",
						children: invalid === "required" ? "Enter a name" : "Name cannot exceed 100 characters"
					})
				]
			})
		})
	});
};
RenameDialog.displayName = "RenameDialog";
var ConversationListV2_module_default = {
	condensed: "ConversationListV2-module_gZLLlq_condensed",
	container: "ConversationListV2-module_gZLLlq_container",
	context: "ConversationListV2-module_gZLLlq_context",
	empty: "ConversationListV2-module_gZLLlq_empty",
	emptyStateHeading: "ConversationListV2-module_gZLLlq_emptyStateHeading",
	emptyStateText: "ConversationListV2-module_gZLLlq_emptyStateText",
	item: "ConversationListV2-module_gZLLlq_item",
	link: "ConversationListV2-module_gZLLlq_link",
	list: "ConversationListV2-module_gZLLlq_list",
	section: "ConversationListV2-module_gZLLlq_section",
	text: "ConversationListV2-module_gZLLlq_text",
	title: "ConversationListV2-module_gZLLlq_title"
};
function groupItemsByDate(items) {
	const today = /* @__PURE__ */ new Date();
	const yesterday = new Date(today);
	yesterday.setDate(today.getDate() - 1);
	const last7Days = new Date(today);
	last7Days.setDate(today.getDate() - 7);
	const last30Days = new Date(today);
	last30Days.setDate(today.getDate() - 30);
	const todayItems = [];
	const yesterdayItems = [];
	const last7DaysItems = [];
	const last30DaysItems = [];
	for (const item of items) if (item.date.toDateString() === today.toDateString()) todayItems.push(item);
	else if (item.date.toDateString() === yesterday.toDateString()) yesterdayItems.push(item);
	else if (item.date > last7Days) last7DaysItems.push(item);
	else if (item.date > last30Days) last30DaysItems.push(item);
	return {
		Today: todayItems,
		Yesterday: yesterdayItems,
		"Last 7 days": last7DaysItems,
		"Last 30 days": last30DaysItems
	};
}
function ConversationList(t0) {
	const { selectedItemID, loadingState, onConversationSelect, isSidebarCondensed } = t0;
	const manager = useChatManager();
	const { threads } = useChatState();
	const ungroupedItems = manager.sortAndFilterThreads(threads).map(_temp$3);
	const groupedItems = groupItemsByDate(ungroupedItems);
	const isEmpty = ungroupedItems.length === 0;
	const isLoading = loadingState === "loading" || loadingState === "pending";
	const id = useId();
	return jsx("nav", {
		"aria-labelledby": `${id}-conversations`,
		id: `${id}-conversation-list`,
		tabIndex: -1,
		className: clsx(ConversationListV2_module_default.container, isSidebarCondensed && ConversationListV2_module_default.condensed),
		children: isEmpty && isLoading ? jsx(SkeletonText, { lines: 5 }) : isEmpty ? jsx(EmptyState, {}) : jsxs("div", {
			className: ConversationListV2_module_default.section,
			children: [jsx("h3", {
				id: `${id}-conversations`,
				className: "sr-only",
				children: "Chats"
			}), Object.entries(groupedItems).map((t1) => {
				const [group, items] = t1;
				return items.length > 0 && jsxs("div", { children: [jsx("h4", {
					id: `${id}_${group}`,
					className: ConversationListV2_module_default.title,
					children: group
				}), jsx("ul", {
					className: ConversationListV2_module_default.list,
					children: items.map((item) => jsx(ConversationListEntry$1, {
						item,
						selectedItemId: selectedItemID ?? void 0,
						onSelect: onConversationSelect,
						threads
					}, item.id))
				})] }, group);
			})]
		})
	});
}
ConversationList.displayName = "ConversationList";
function _temp$3(thread) {
	return {
		id: thread.id,
		text: threadName(thread),
		href: `${COPILOT_PATH}/c/${thread.id}`,
		date: new Date(thread.updatedAt)
	};
}
function ConversationListEntry$1({ item, selectedItemId, onSelect, threads }) {
	const selected = item.id === selectedItemId;
	const [dialog, setDialog] = useState(null);
	const [loading, setLoading] = useState(false);
	const startLoading = useCallback(() => setLoading(true), []);
	const finishLoading = useCallback(() => setLoading(false), []);
	const selectedThread = threads.get(selectedItemId);
	const isSpace = Boolean(selectedThread?.customCopilotID);
	const anchorRef = useRef(null);
	const closeDialog = useCallback(() => {
		flushSync(() => setDialog(null));
		anchorRef.current?.focus();
	}, [anchorRef]);
	return item.href && /* @__PURE__ */ jsxs("li", {
		className: ConversationListV2_module_default.item,
		children: [
			/* @__PURE__ */ jsx(Link$1, {
				className: ConversationListV2_module_default.link,
				to: item.href,
				"aria-current": selected ? "page" : void 0,
				onClick: () => {
					onSelect();
					sendEvent("dotcom_chat.activate", {
						target: "CONVERSATION_SELECT",
						threadId: item.id,
						mode: "immersive"
					});
				},
				children: /* @__PURE__ */ jsx("span", {
					className: ConversationListV2_module_default.text,
					children: item.text
				})
			}),
			/* @__PURE__ */ jsx("span", {
				className: ConversationListV2_module_default.context,
				children: /* @__PURE__ */ jsxs(ActionMenu, {
					anchorRef,
					children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
						loading,
						icon: KebabHorizontalIcon,
						"aria-label": "Manage chat",
						variant: "invisible",
						onClick: () => sendEvent("dotcom_chat.activate", {
							target: "CONVERSATION_CONTEXT_MENU",
							mode: "immersive"
						})
					}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsx(ConversationActions, {
						onOpenDialog: setDialog,
						isShared: Boolean(threads.get(item.id)?.sharedID),
						showShare: !isSpace,
						threadName: item.text,
						threadId: item.id
					}) }) })]
				})
			}),
			/* @__PURE__ */ jsx(ConversationActionDialogs, {
				visibleDialog: dialog,
				onClose: closeDialog,
				threadName: item.text,
				threadId: item.id,
				selectedThreadId: selectedItemId,
				onStartLoading: startLoading,
				onFinishLoading: finishLoading,
				returnFocusRef: anchorRef
			})
		]
	}, item.id);
}
ConversationListEntry$1.displayName = "ConversationListEntry";
function EmptyState() {
	return /* @__PURE__ */ jsxs("div", {
		className: ConversationListV2_module_default.empty,
		children: [/* @__PURE__ */ jsx(Heading$2, {
			as: "h3",
			className: ConversationListV2_module_default.emptyStateHeading,
			children: "No chats yet"
		}), /* @__PURE__ */ jsx("span", {
			className: ConversationListV2_module_default.emptyStateText,
			children: "Ask Copilot anything on the right to start your first chat."
		})]
	});
}
EmptyState.displayName = "EmptyState";
var SidebarListItem_module_default = {
	content: "SidebarListItem-module_qq0Qra_content",
	item: "SidebarListItem-module_qq0Qra_item",
	link: "SidebarListItem-module_qq0Qra_link",
	linkWithSecondaryText: "SidebarListItem-module_qq0Qra_linkWithSecondaryText",
	secondaryText: "SidebarListItem-module_qq0Qra_secondaryText",
	statusIcon: "SidebarListItem-module_qq0Qra_statusIcon",
	topLine: "SidebarListItem-module_qq0Qra_topLine",
	trailingAction: "SidebarListItem-module_qq0Qra_trailingAction",
	trailingVisual: "SidebarListItem-module_qq0Qra_trailingVisual"
};
function SidebarListItem({ href, text, isSelected, trailingAction, trailingVisual, onClick, className, leadingVisual: LeadingVisual, secondaryText, reloadDocument = false, linkRef }) {
	const hasSecondaryText = Boolean(secondaryText);
	const isNonInteractive = href === "";
	const content = /* @__PURE__ */ jsxs("div", {
		className: SidebarListItem_module_default.content,
		children: [/* @__PURE__ */ jsxs("div", {
			className: SidebarListItem_module_default.topLine,
			children: [LeadingVisual && /* @__PURE__ */ jsx("span", {
				className: SidebarListItem_module_default.statusIcon,
				children: /* @__PURE__ */ jsx(LeadingVisual, {})
			}), /* @__PURE__ */ jsx("span", { children: text })]
		}), secondaryText ? /* @__PURE__ */ jsx("p", {
			className: SidebarListItem_module_default.secondaryText,
			children: secondaryText
		}) : null]
	});
	return /* @__PURE__ */ jsxs("li", {
		className: clsx(SidebarListItem_module_default.item, className),
		"data-selected": isSelected,
		children: [
			isNonInteractive ? /* @__PURE__ */ jsx("div", {
				className: clsx(SidebarListItem_module_default.link, { [SidebarListItem_module_default.linkWithSecondaryText]: hasSecondaryText }),
				children: content
			}) : /* @__PURE__ */ jsx(Link$1, {
				ref: linkRef,
				className: clsx(SidebarListItem_module_default.link, { [SidebarListItem_module_default.linkWithSecondaryText]: hasSecondaryText }),
				to: href,
				"aria-current": isSelected ? "page" : void 0,
				onClick,
				reloadDocument,
				children: content
			}),
			trailingVisual ? /* @__PURE__ */ jsx("span", {
				className: SidebarListItem_module_default.trailingVisual,
				children: trailingVisual
			}) : null,
			trailingAction ? /* @__PURE__ */ jsx("span", {
				className: SidebarListItem_module_default.trailingAction,
				children: trailingAction
			}) : null
		]
	});
}
SidebarListItem.displayName = "SidebarListItem";
var SidebarNavigation_module_default = {
	condensed: "SidebarNavigation-module_fVmsRa_condensed",
	container: "SidebarNavigation-module_fVmsRa_container",
	list: "SidebarNavigation-module_fVmsRa_list",
	scrollingContainer: "SidebarNavigation-module_fVmsRa_scrollingContainer",
	section: "SidebarNavigation-module_fVmsRa_section",
	sectionContainer: "SidebarNavigation-module_fVmsRa_sectionContainer",
	title: "SidebarNavigation-module_fVmsRa_title",
	titleContainer: "SidebarNavigation-module_fVmsRa_titleContainer"
};
/**
* Main navigation container for sidebar content.
* Should wrap all sidebar sections and provide consistent styling.
*/
function SidebarNavigation(t0) {
	const $ = c$1(6);
	const { children, isCondensed, "aria-label": t1, className } = t0;
	const ariaLabel = t1 === void 0 ? "Navigation" : t1;
	const t2 = `${useId()}-navigation`;
	let t3;
	if ($[0] !== ariaLabel || $[1] !== children || $[2] !== className || $[3] !== isCondensed || $[4] !== t2) {
		t3 = jsx("nav", {
			"aria-label": ariaLabel,
			id: t2,
			tabIndex: -1,
			className: clsx(SidebarNavigation_module_default.container, isCondensed && SidebarNavigation_module_default.condensed, className),
			children: jsx("div", {
				className: SidebarNavigation_module_default.scrollingContainer,
				children: jsx("div", {
					className: SidebarNavigation_module_default.section,
					children
				})
			})
		});
		$[0] = ariaLabel;
		$[1] = children;
		$[2] = className;
		$[3] = isCondensed;
		$[4] = t2;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
/**
* A section within the sidebar navigation.
* Provides consistent grouping with titles and handles loading/empty states.
*/
SidebarNavigation.displayName = "SidebarNavigation";
function SidebarSection(t0) {
	const $ = c$1(8);
	const { title, children, isLoading, isEmpty, viewMoreLink, trailingAction } = t0;
	const id = useId();
	let t1;
	if ($[0] !== children || $[1] !== id || $[2] !== isEmpty || $[3] !== isLoading || $[4] !== title || $[5] !== trailingAction || $[6] !== viewMoreLink) {
		t1 = jsxs("div", {
			className: SidebarNavigation_module_default.sectionContainer,
			children: [title && jsxs("div", {
				className: SidebarNavigation_module_default.titleContainer,
				children: [jsx("h4", {
					id,
					className: SidebarNavigation_module_default.title,
					children: title
				}), trailingAction ? trailingAction : null]
			}), isEmpty && isLoading ? jsx(SkeletonText, { lines: 5 }) : isEmpty ? null : jsxs(Fragment$1, { children: [jsx("ul", {
				className: SidebarNavigation_module_default.list,
				children
			}), viewMoreLink] })]
		});
		$[0] = children;
		$[1] = id;
		$[2] = isEmpty;
		$[3] = isLoading;
		$[4] = title;
		$[5] = trailingAction;
		$[6] = viewMoreLink;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
SidebarSection.displayName = "SidebarSection";
function getPRStatusIcon(status) {
	switch (status) {
		case "draft": return /* @__PURE__ */ jsx(GitPullRequestDraftIcon, { className: "fgColor-draft" });
		case "open": return /* @__PURE__ */ jsx(GitPullRequestIcon, { className: "fgColor-open" });
		case "closed": return /* @__PURE__ */ jsx(GitPullRequestClosedIcon, { className: "fgColor-closed" });
		case "merged": return /* @__PURE__ */ jsx(GitMergeIcon, { className: "fgColor-done" });
		default: return /* @__PURE__ */ jsx(GitPullRequestIcon, { className: "fgColor-open" });
	}
}
var PAGE_SIZE = 5;
var TASK_BUCKET_LABELS = [
	"Today",
	"This week",
	"Older"
];
function getTaskBucketTestId(label) {
	return `task-bucket-${label.toLowerCase().replace(/\s+/g, "-")}`;
}
function getStartOfDay(date) {
	const startOfDay = new Date(date);
	startOfDay.setHours(0, 0, 0, 0);
	return startOfDay;
}
function getStartOfWeek(date) {
	const startOfWeek = getStartOfDay(date);
	startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
	return startOfWeek;
}
function getTaskBucketLabel(updatedAt, now) {
	const updatedAtDate = new Date(updatedAt);
	if (Number.isNaN(updatedAtDate.getTime())) return "Older";
	if (updatedAtDate >= getStartOfDay(now)) return "Today";
	if (updatedAtDate >= getStartOfWeek(now)) return "This week";
	return "Older";
}
function sortTasksByUpdatedAtDesc(tasks) {
	return [...tasks].sort((leftTask, rightTask) => {
		return new Date(rightTask.latest_session_updated_at).getTime() - new Date(leftTask.latest_session_updated_at).getTime();
	});
}
function groupTasksByUpdatedAt(tasks, now = /* @__PURE__ */ new Date()) {
	const buckets = new Map(TASK_BUCKET_LABELS.map((label) => [label, []]));
	for (const task of sortTasksByUpdatedAtDesc(tasks)) buckets.get(getTaskBucketLabel(task.latest_session_updated_at, now))?.push(task);
	return TASK_BUCKET_LABELS.map((label) => ({
		label,
		tasks: buckets.get(label) ?? []
	})).filter((bucket) => bucket.tasks.length > 0);
}
function TaskBucketHeader({ label }) {
	return /* @__PURE__ */ jsx("li", {
		"data-testid": getTaskBucketTestId(label),
		children: /* @__PURE__ */ jsx("div", {
			className: "m-0 px-2 py-2 color-fg-muted text-small text-semibold",
			children: label
		})
	});
}
TaskBucketHeader.displayName = "TaskBucketHeader";
function getPRStatusLabel(task) {
	const { pull } = task;
	if (!pull) return void 0;
	if (pull.state === "merged") return "Merged";
	if (pull.state === "closed") return "Closed";
	if (pull.state === "open" && pull.reviewable_state === "draft") return "Draft";
	if (pull.inMergeQueue) return "Queued to merge";
}
function getTaskSecondaryText(task) {
	if (task.isOptimistic) return "Initializing...";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		task.latest_session_state === "in_progress" || task.latest_session_state === "queued" ? getReadableSessionState(task.latest_session_state, { hasPull: !!task.pull }) : getPRStatusLabel(task) || getReadableSessionState(task.latest_session_state, { hasPull: !!task.pull }),
		task.pull?.number ? ` · #${task.pull.number}` : "",
		" · ",
		/* @__PURE__ */ jsx(RelativeTime, {
			format: "micro",
			datetime: task.latest_session_updated_at
		})
	] });
}
function TasksListWrapper({ viewAllLink, showTitle, trailingAction, onTaskClick }) {
	return /* @__PURE__ */ jsx(ConsecutiveCAPI401sProvider, { children: /* @__PURE__ */ jsx(ArchiveDialogProvider, { children: /* @__PURE__ */ jsx(TasksList, {
		viewAllLink,
		showTitle,
		trailingAction,
		onTaskClick
	}) }) });
}
TasksListWrapper.displayName = "TasksListWrapper";
function TasksList(t0) {
	const $ = c$1(1);
	const { viewAllLink, showTitle, trailingAction, onTaskClick } = t0;
	const location = useLocation$1();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			taskFilter: "active",
			pageSize: PAGE_SIZE,
			includeCounts: true
		};
		$[0] = t1;
	} else t1 = $[0];
	const { tasks, isLoading } = useTasks(t1);
	useSSOChangeDetection();
	const visibleTasks = sortTasksByUpdatedAtDesc(tasks).slice(0, PAGE_SIZE);
	const groupedVisibleTasks = groupTasksByUpdatedAt(visibleTasks);
	const isEmpty = visibleTasks.length === 0;
	const { isUsingIntentDetection } = useIntentDetection();
	return jsxs(Fragment$1, { children: [jsx(SidebarSection, {
		title: showTitle ? "Agent sessions" : void 0,
		isEmpty,
		isLoading,
		trailingAction,
		children: groupedVisibleTasks.map((bucket) => jsxs(Fragment, { children: [groupedVisibleTasks.length > 1 && jsx(TaskBucketHeader, { label: bucket.label }), bucket.tasks.map((task) => {
			const href = generateTaskPathForRepo({
				repositoryNwo: task.nwo,
				pullRequestNumber: task.pull?.number ?? 0,
				sessionId: task.latest_session_id,
				taskId: task.id,
				isUsingIntentDetection
			});
			const isSelected = location.pathname === href;
			const nwo = task.nwo;
			const [owner, repo] = nwo ? nwo.split("/") : [void 0, void 0];
			return jsx(TaskListEntry, {
				task,
				href,
				isSelected,
				reloadDocument: true,
				secondaryText: getTaskSecondaryText(task),
				onTaskClick,
				repoOwner: owner,
				repoName: repo
			}, task.clientGeneratedId ?? task.id ?? task.resource_id);
		})] }, bucket.label))
	}), !isEmpty && viewAllLink] });
}
TasksList.displayName = "TasksList";
function TaskListEntry({ task, href, isSelected, secondaryText, reloadDocument, onTaskClick, repoOwner, repoName, currentUserIsOwner }) {
	const anchorRef = useRef(null);
	const sessionState = task.latest_session_state;
	const prState = task.pull?.state;
	const hasPullRequest = !!task.pull;
	const isOptimistic = !!task.isOptimistic;
	const prInMergeQueue = task.pull?.inMergeQueue;
	const isArchived = !!task.archived_at;
	const isCLI = isTaskFromCLI(task);
	const isDraftPullRequest = prState === "open" && task.pull?.reviewable_state === "draft";
	const isActiveTask = sessionState === "queued" || sessionState === "in_progress";
	const trailingAction = /* @__PURE__ */ jsxs(ActionMenu, {
		anchorRef,
		children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			icon: KebabHorizontalIcon,
			"aria-label": "Manage session",
			variant: "invisible",
			onClick: () => sendEvent("dotcom_chat.activate", {
				target: "TASK_CONTEXT_MENU",
				mode: "immersive"
			})
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(TaskActions, {
			state: task.latest_session_state,
			pull: task.pull,
			taskId: task.id,
			repoOwner,
			repoName,
			currentUserIsOwner,
			archivedAt: task.archived_at,
			eventType: task.event_type,
			eventIdentifiers: task.event_identifiers
		}) })]
	});
	const effectivePrStatus = isDraftPullRequest ? "draft" : prState;
	const leadingVisual = useCallback(() => {
		if (isCLI || prInMergeQueue || isArchived) return /* @__PURE__ */ jsx(TaskLeadingVisual, {
			isOptimistic,
			prState,
			prInMergeQueue,
			sessionState,
			isArchived,
			isCLI
		});
		if (isOptimistic || isActiveTask) return /* @__PURE__ */ jsx("span", {
			"data-testid": "task-list-entry-active-icon",
			style: {
				display: "inline-flex",
				marginTop: "3px"
			},
			children: /* @__PURE__ */ jsx(InProgressSpinner, {})
		});
		if (hasPullRequest) return getPRStatusIcon(effectivePrStatus || "open");
		if (sessionState === "completed") return /* @__PURE__ */ jsx(CheckIcon, {
			className: "fgColor-success",
			"data-testid": "task-list-entry-completed-icon"
		});
		if (sessionState === "failed" || sessionState === "timed_out" || sessionState === "cancelled") return /* @__PURE__ */ jsx(StopIcon, {
			className: "fgColor-danger",
			"data-testid": "task-list-entry-error-icon"
		});
		return /* @__PURE__ */ jsx(DotFillIcon, {
			className: "fgColor-muted",
			"data-testid": "task-list-entry-inactive-icon"
		});
	}, [
		isCLI,
		prInMergeQueue,
		isArchived,
		isOptimistic,
		prState,
		sessionState,
		isActiveTask,
		hasPullRequest,
		effectivePrStatus
	]);
	return /* @__PURE__ */ jsx(SidebarListItem, {
		href,
		text: getTaskTitle(task, task.pull?.title),
		leadingVisual,
		isSelected,
		trailingAction,
		secondaryText,
		reloadDocument,
		onClick: () => {
			onTaskClick?.();
			sendEvent("agent_sessions.task_view", {
				target: "VIEW_TASK_FROM_MISSION_CONTROL",
				task_id: task.resource_global_id
			});
		}
	});
}
TaskListEntry.displayName = "TaskListEntry";
var button = "Button-module_mQ8Dtq_button";
var condensed$3 = "Button-module_mQ8Dtq_condensed";
var disabled = "Button-module_mQ8Dtq_disabled";
var icon$1 = "Button-module_mQ8Dtq_icon";
var iconOnly = "Button-module_mQ8Dtq_iconOnly";
var invisible = "Button-module_mQ8Dtq_invisible";
var medium = "Button-module_mQ8Dtq_medium";
var small = "Button-module_mQ8Dtq_small";
var text$1 = "Button-module_mQ8Dtq_text";
var Button_module_default = {
	button,
	condensed: condensed$3,
	"default": "Button-module_mQ8Dtq_default",
	disabled,
	icon: icon$1,
	iconOnly,
	invisible,
	medium,
	small,
	text: text$1
};
var Button = ({ ref, size = "small", variant = "default", condensed = false, iconOnly = false, icon, className, children, disabled, ...props }) => {
	const classes = clsx(Button_module_default.button, Button_module_default[size], Button_module_default[variant], condensed && Button_module_default.condensed, iconOnly && Button_module_default.iconOnly, disabled && Button_module_default.disabled, className);
	const content = /* @__PURE__ */ jsxs(Fragment$1, { children: [icon != null ? /* @__PURE__ */ jsx("span", {
		className: Button_module_default.icon,
		children: icon
	}) : null, !iconOnly && children ? /* @__PURE__ */ jsx("span", {
		className: Button_module_default.text,
		children
	}) : null] });
	if ("to" in props) {
		const { to, onClick, ...rest } = props;
		return /* @__PURE__ */ jsx(Link$1, {
			ref,
			to,
			className: classes,
			"aria-disabled": disabled,
			onClick,
			...rest,
			children: content
		});
	}
	if ("href" in props) {
		const { href, target, rel, onClick, ...rest } = props;
		return /* @__PURE__ */ jsx("a", {
			ref,
			href,
			target,
			rel,
			className: classes,
			"aria-disabled": disabled,
			onClick,
			...rest,
			children: content
		});
	}
	const { onClick, type = "button", ...rest } = props;
	return /* @__PURE__ */ jsx("button", {
		ref,
		type,
		onClick,
		disabled,
		className: classes,
		...rest,
		children: content
	});
};
Button.displayName = "Button";
Button.displayName = "Button";
var Tooltip_module_default = {
	tooltip: "Tooltip-module_b7SFhq_tooltip",
	trigger: "Tooltip-module_b7SFhq_trigger"
};
var Tooltip = ({ ref, text, position, children, relationship = "description", offset: offsetValue = 8, ...childrenProps }) => {
	const [isOpen, setIsOpen] = useState(false);
	const openTimeoutRef = useRef(null);
	const { refs, floatingStyles, context, isPositioned } = useFloating({
		open: isOpen,
		onOpenChange: setIsOpen,
		placement: position,
		middleware: [offset(offsetValue), ...position ? [] : [autoPlacement()]],
		whileElementsMounted: autoUpdate
	});
	const { getReferenceProps, getFloatingProps } = useInteractions([
		useHover(context, {
			move: false,
			delay: {
				open: 100,
				close: 0
			}
		}),
		useFocus(context),
		useDismiss(context),
		useRole(context, {
			role: "tooltip",
			enabled: relationship === "description"
		})
	]);
	const referenceProps = getReferenceProps();
	const childProps = childrenProps;
	if (relationship === "label") childProps["aria-label"] = text;
	else if (relationship === "description") childProps["aria-describedby"] = context.floatingId;
	const handleTouchEnd = (event) => {
		if (children.props.onTouchEnd) children.props.onTouchEnd(event);
		setTimeout(() => setIsOpen(false), 10);
	};
	const handleMouseOver = (event_0) => {
		if (children.props.onMouseEnter) children.props.onMouseEnter(event_0);
		if (openTimeoutRef.current) {
			clearTimeout(openTimeoutRef.current);
			openTimeoutRef.current = null;
		}
	};
	const childRef = useMergeRefs([refs.setReference, ref]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [cloneElement(children, {
		...referenceProps,
		...childProps,
		onTouchEnd: handleTouchEnd,
		onMouseEnter: handleMouseOver,
		ref: childRef
	}), isOpen && /* @__PURE__ */ jsx(FloatingPortal, { children: /* @__PURE__ */ jsx("div", {
		ref: refs.setFloating,
		id: context.floatingId,
		style: {
			...floatingStyles,
			visibility: isPositioned ? "visible" : "hidden"
		},
		className: clsx(Tooltip_module_default.tooltip),
		...getFloatingProps(),
		children: text
	}) })] });
};
Tooltip.displayName = "Tooltip";
Tooltip.displayName = "Tooltip";
var ActivityPanel_module_default = {
	compactAgentsMenu: "ActivityPanel-module_5eGGKa_compactAgentsMenu",
	compactContainer: "ActivityPanel-module_5eGGKa_compactContainer",
	contentContainer: "ActivityPanel-module_5eGGKa_contentContainer",
	largeButton: "ActivityPanel-module_5eGGKa_largeButton",
	listContainer: "ActivityPanel-module_5eGGKa_listContainer",
	overlay: "ActivityPanel-module_5eGGKa_overlay",
	segmentedControl: "ActivityPanel-module_5eGGKa_segmentedControl",
	topBar: "ActivityPanel-module_5eGGKa_topBar"
};
var SSOWarningBanner_module_default = {
	ssoSignInLink: "SSOWarningBanner-module_sZWUCq_ssoSignInLink",
	ssoWarningBanner: "SSOWarningBanner-module_sZWUCq_ssoWarningBanner"
};
function SSOWarningBanner(t0) {
	const $ = c$1(3);
	const { ssoOrganizations } = t0;
	const location = useLocation$1();
	if (ssoOrganizations.length === 0) return null;
	let t1;
	if ($[0] !== location || $[1] !== ssoOrganizations) {
		t1 = jsxs(Flash, {
			className: SSOWarningBanner_module_default.ssoWarningBanner,
			variant: "warning",
			children: [jsx(AlertIcon, { size: 16 }), jsxs("span", { children: [
				"Some threads are hidden. Please",
				" ",
				ssoOrganizations.length === 1 ? ssoOrganizations[0]?.login ? jsx("a", {
					href: generateSSOUrl(ssoOrganizations[0].login, location),
					children: "sign in"
				}) : jsx("span", { children: "sign in" }) : jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsx("button", {
					type: "button",
					className: SSOWarningBanner_module_default.ssoSignInLink,
					children: "sign in"
				}) }), jsx(ActionMenu.Overlay, { children: jsx(ActionList, { children: ssoOrganizations.filter(_temp$2).map((org_0) => jsx(ActionList.LinkItem, {
					href: generateSSOUrl(org_0.login, location),
					children: org_0.login
				}, org_0.login)) }) })] }),
				" ",
				jsx("span", { children: "with SSO to view them." })
			] })]
		});
		$[0] = location;
		$[1] = ssoOrganizations;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
SSOWarningBanner.displayName = "SSOWarningBanner";
function _temp$2(org) {
	return org.login;
}
function ConversationListWrapper(t0) {
	const $ = c$1(22);
	const { handleSidebarClick, title, trailingAction } = t0;
	const location = useLocation$1();
	let t1;
	if ($[0] !== location.pathname) {
		t1 = location.pathname.includes("/share/");
		$[0] = location.pathname;
		$[1] = t1;
	} else t1 = $[1];
	const isSharedThread = t1;
	const { threadsLoading, selectedThreadID, threads, threadsHidden, ssoOrganizations } = useChatStateValues("threadsLoading", "selectedThreadID", "threads", "threadsHidden", "ssoOrganizations");
	const manager = useChatManager();
	let t2;
	if ($[2] !== manager || $[3] !== threads) {
		t2 = manager.sortAndFilterThreads(threads).map(_temp$1);
		$[2] = manager;
		$[3] = threads;
		$[4] = t2;
	} else t2 = $[4];
	const conversationItems = t2;
	const isEmpty = conversationItems.length === 0;
	const isLoading = threadsLoading.state === "loading" || threadsLoading.state === "pending";
	let t3;
	if ($[5] !== conversationItems || $[6] !== handleSidebarClick || $[7] !== isEmpty || $[8] !== isLoading || $[9] !== isSharedThread || $[10] !== selectedThreadID || $[11] !== ssoOrganizations || $[12] !== threads || $[13] !== threadsHidden || $[14] !== title || $[15] !== trailingAction) {
		let t4;
		if ($[17] !== handleSidebarClick || $[18] !== isSharedThread || $[19] !== selectedThreadID || $[20] !== threads) {
			t4 = (item) => jsx(ConversationListEntry, {
				item,
				selectedItemId: isSharedThread ? void 0 : selectedThreadID ?? void 0,
				onSelect: handleSidebarClick,
				threads
			}, item.id);
			$[17] = handleSidebarClick;
			$[18] = isSharedThread;
			$[19] = selectedThreadID;
			$[20] = threads;
			$[21] = t4;
		} else t4 = $[21];
		t3 = jsxs(SidebarSection, {
			title,
			isEmpty,
			isLoading,
			trailingAction,
			children: [threadsHidden && jsx(SSOWarningBanner, { ssoOrganizations }), conversationItems.map(t4)]
		});
		$[5] = conversationItems;
		$[6] = handleSidebarClick;
		$[7] = isEmpty;
		$[8] = isLoading;
		$[9] = isSharedThread;
		$[10] = selectedThreadID;
		$[11] = ssoOrganizations;
		$[12] = threads;
		$[13] = threadsHidden;
		$[14] = title;
		$[15] = trailingAction;
		$[16] = t3;
	} else t3 = $[16];
	return t3;
}
ConversationListWrapper.displayName = "ConversationListWrapper";
function _temp$1(thread) {
	return {
		id: thread.id,
		text: threadName(thread),
		href: `${COPILOT_PATH}/c/${thread.id}`,
		date: new Date(thread.updatedAt)
	};
}
function ConversationListEntry({ item, selectedItemId, onSelect, threads }) {
	const selected = item.id === selectedItemId;
	const [dialog, setDialog] = useState(null);
	const [loading, setLoading] = useState(false);
	const startLoading = useCallback(() => setLoading(true), []);
	const finishLoading = useCallback(() => setLoading(false), []);
	const selectedThread = threads.get(selectedItemId);
	const isSpace = Boolean(selectedThread?.customCopilotID);
	const anchorRef = useRef(null);
	const closeDialog = useCallback(() => {
		flushSync(() => setDialog(null));
		anchorRef.current?.focus();
	}, [anchorRef]);
	const trailingAction = /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(ActionMenu, {
		anchorRef,
		children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			loading,
			icon: KebabHorizontalIcon,
			"aria-label": "Manage chat",
			variant: "invisible",
			onClick: () => sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_CONTEXT_MENU",
				mode: "immersive"
			})
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsx(ConversationActions, {
			onOpenDialog: setDialog,
			isShared: Boolean(threads.get(item.id)?.sharedID),
			showShare: !isSpace,
			threadName: item.text,
			threadId: item.id
		}) }) })]
	}), /* @__PURE__ */ jsx(ConversationActionDialogs, {
		visibleDialog: dialog,
		onClose: closeDialog,
		threadName: item.text,
		threadId: item.id,
		selectedThreadId: selectedItemId,
		onStartLoading: startLoading,
		onFinishLoading: finishLoading,
		returnFocusRef: anchorRef
	})] });
	return /* @__PURE__ */ jsx(SidebarListItem, {
		href: item.href,
		text: item.text,
		isSelected: selected,
		trailingAction,
		onClick: () => {
			onSelect();
			sendEvent("dotcom_chat.activate", {
				target: "CONVERSATION_SELECT",
				threadId: item.id,
				mode: "immersive"
			});
		}
	});
}
ConversationListEntry.displayName = "ConversationListEntry";
function ActivityPanel(t0) {
	const $ = c$1(14);
	const { handleSidebarClick, isCondensed, onToggleSidebar } = t0;
	const [isMenuOpen, setIsMenuOpen] = useState(false);
	const navigateToNewThread = useNavigateToNewThread();
	let t1;
	if ($[0] !== handleSidebarClick || $[1] !== isCondensed || $[2] !== isMenuOpen || $[3] !== navigateToNewThread || $[4] !== onToggleSidebar) {
		const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
		let t2;
		if ($[6] !== isCondensed || $[7] !== onToggleSidebar) {
			t2 = () => {
				if (isCondensed) onToggleSidebar();
			};
			$[6] = isCondensed;
			$[7] = onToggleSidebar;
			$[8] = t2;
		} else t2 = $[8];
		const expandPanel = t2;
		let t3;
		if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
			t3 = () => setIsMenuOpen(false);
			$[9] = t3;
		} else t3 = $[9];
		const closeMenu = t3;
		let t4;
		if ($[10] !== handleSidebarClick || $[11] !== isCondensed || $[12] !== navigateToNewThread) {
			t4 = async () => {
				if (isCondensed) closeMenu();
				else handleSidebarClick();
				await navigateToNewThread({
					clearTopic: true,
					includeThreads: false
				});
				sendEvent("dotcom_chat.activate", {
					target: "SIDEBAR_CONVERSATION_NEW",
					mode: "immersive"
				});
			};
			$[10] = handleSidebarClick;
			$[11] = isCondensed;
			$[12] = navigateToNewThread;
			$[13] = t4;
		} else t4 = $[13];
		const handleNewChat = t4;
		const newAgentTaskButton = jsx(NewAgentTaskButton, {
			isIconButton: true,
			icon: PlusIcon,
			label: "New agent session",
			onOpen: _temp2,
			onClose: expandPanel,
			eventType: "activity_panel",
			size: "small",
			tooltipDirection: "e",
			variant: "invisible",
			decoupledModeEnabled
		});
		const getSidebarContent = () => jsxs(SidebarNavigation, {
			isCondensed: false,
			"aria-label": "Navigation",
			children: [jsx(IntentDetectionEnabledProvider, {
				isUsingIntentDetection: isFeatureEnabled("copilot_intent_detection"),
				children: jsx(TasksListWrapper, {
					showTitle: true,
					trailingAction: newAgentTaskButton,
					onTaskClick: isCondensed ? closeMenu : void 0
				})
			}), jsx(ConversationListWrapper, {
				title: "Chats",
				trailingAction: jsx(IconButton, {
					icon: PlusIcon,
					variant: "invisible",
					"aria-label": "New chat",
					size: "small",
					tooltipDirection: "e",
					onClick: handleNewChat
				}),
				handleSidebarClick
			})]
		});
		t1 = isCondensed ? jsx("div", {
			className: ActivityPanel_module_default.compactContainer,
			children: jsxs("div", {
				className: ActivityPanel_module_default.compactAgentsMenu,
				children: [jsxs(ActionMenu, {
					open: isMenuOpen,
					onOpenChange: setIsMenuOpen,
					children: [jsx(ActionMenu.Anchor, { children: jsx(Tooltip, {
						text: "Agent sessions and chats",
						children: jsx(Button, {
							"aria-label": "Agent sessions and chats",
							icon: jsx(HistoryIcon, {}),
							iconOnly: true,
							size: "medium",
							variant: "invisible"
						})
					}) }), jsx(ActionMenu.Overlay, {
						width: "medium",
						side: "outside-right",
						align: "start",
						maxHeight: "xlarge",
						className: ActivityPanel_module_default.overlay,
						children: jsx("div", { children: getSidebarContent() })
					})]
				}), jsx("div", {
					className: ActivityPanel_module_default.largeButton,
					children: newAgentTaskButton
				})]
			})
		}) : getSidebarContent();
		$[0] = handleSidebarClick;
		$[1] = isCondensed;
		$[2] = isMenuOpen;
		$[3] = navigateToNewThread;
		$[4] = onToggleSidebar;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
ActivityPanel.displayName = "ActivityPanel";
function _temp2() {
	return sendEvent("agent_sessions.task_view", { target: "CREATE_TASK_FROM_CHAT_BUTTON" });
}
var CopilotNavigation_module_default = {
	blankslateContainer: "CopilotNavigation-module_uszUlG_blankslateContainer",
	condensed: "CopilotNavigation-module_uszUlG_condensed",
	footer: "CopilotNavigation-module_uszUlG_footer",
	footerButton: "CopilotNavigation-module_uszUlG_footerButton",
	footerButtonContent: "CopilotNavigation-module_uszUlG_footerButtonContent",
	footerButtonIcon: "CopilotNavigation-module_uszUlG_footerButtonIcon",
	quicklinks: "CopilotNavigation-module_uszUlG_quicklinks",
	toggleButtonIcon: "CopilotNavigation-module_uszUlG_toggleButtonIcon"
};
var ServiceList_module_default = {
	condensed: "ServiceList-module_9AEjTG_condensed",
	content: "ServiceList-module_9AEjTG_content",
	externalIcon: "ServiceList-module_9AEjTG_externalIcon",
	externalLabel: "ServiceList-module_9AEjTG_externalLabel",
	icon: "ServiceList-module_9AEjTG_icon",
	item: "ServiceList-module_9AEjTG_item",
	label: "ServiceList-module_9AEjTG_label",
	link: "ServiceList-module_9AEjTG_link",
	list: "ServiceList-module_9AEjTG_list",
	previewLabel: "ServiceList-module_9AEjTG_previewLabel",
	section: "ServiceList-module_9AEjTG_section",
	text: "ServiceList-module_9AEjTG_text",
	textWrapper: "ServiceList-module_9AEjTG_textWrapper"
};
function ServiceListItem({ "aria-current": ariaCurrent, "data-analytics-event": dataAnalyticsEvent, href, icon, onLinkClick, id, displayName, condensed, label, external }) {
	const handleLinkClick = (e) => {
		onLinkClick?.(e, id);
	};
	const commonLinkProps = {
		"aria-current": ariaCurrent,
		"data-analytics-event": dataAnalyticsEvent,
		className: ServiceList_module_default.link,
		onClick: handleLinkClick
	};
	const linkContent = external ? /* @__PURE__ */ jsxs("a", {
		href,
		className: ServiceList_module_default.link,
		"aria-label": displayName,
		rel: "noopener noreferrer",
		children: [/* @__PURE__ */ jsx(Icon, {
			size: 16,
			icon
		}), /* @__PURE__ */ jsxs("div", {
			className: clsx(ServiceList_module_default.content, condensed && ServiceList_module_default.condensed),
			children: [/* @__PURE__ */ jsx("div", {
				className: ServiceList_module_default.textWrapper,
				children: /* @__PURE__ */ jsx("div", {
					className: ServiceList_module_default.text,
					children: displayName
				})
			}), /* @__PURE__ */ jsx("div", {
				className: ServiceList_module_default.label,
				children: /* @__PURE__ */ jsxs("div", {
					className: ServiceList_module_default.externalLabel,
					children: [/* @__PURE__ */ jsx("span", {
						className: ServiceList_module_default.previewLabel,
						children: label
					}), /* @__PURE__ */ jsx(ArrowUpRightIcon, { className: ServiceList_module_default.externalIcon })]
				})
			})]
		})]
	}) : /* @__PURE__ */ jsxs(Link$1, {
		to: href,
		...commonLinkProps,
		"aria-label": displayName,
		children: [/* @__PURE__ */ jsx(Icon, {
			size: 16,
			icon
		}), /* @__PURE__ */ jsxs("div", {
			className: clsx(ServiceList_module_default.content, condensed && ServiceList_module_default.condensed),
			children: [/* @__PURE__ */ jsx("div", {
				className: ServiceList_module_default.textWrapper,
				children: /* @__PURE__ */ jsx("div", {
					className: ServiceList_module_default.text,
					children: displayName
				})
			}), /* @__PURE__ */ jsx("div", {
				className: ServiceList_module_default.label,
				children: label
			})]
		})]
	});
	return /* @__PURE__ */ jsx("li", {
		className: ServiceList_module_default.section,
		children: /* @__PURE__ */ jsx("div", {
			className: ServiceList_module_default.item,
			children: /* @__PURE__ */ jsx(Tooltip, {
				text: condensed ? displayName : "",
				children: linkContent
			})
		})
	});
}
ServiceListItem.displayName = "ServiceListItem";
var serviceListAnalyticsData = JSON.stringify({ source: "ServiceList" });
function ServiceList(t0) {
	const $ = c$1(28);
	const { toggleFloatingSidebar, isSidebarCondensed } = t0;
	const { selectedThreadID } = useChatState();
	const activePluginId = useActivePlugin()?.id;
	const plugins = usePlugins();
	const navigateToNewThread = useNavigateToNewThread();
	const isCustomCopilotsEnabled = useCustomCopilotsEnabled();
	const isSpacesPage = useIsCopilotSpacesPage();
	const isMainPage = !selectedThreadID && !activePluginId && !isSpacesPage;
	let t1;
	if ($[0] !== navigateToNewThread || $[1] !== toggleFloatingSidebar) {
		t1 = async (e) => {
			if (e.metaKey || e.ctrlKey) return;
			toggleFloatingSidebar();
			await navigateToNewThread({
				clearTopic: true,
				includeThreads: false
			});
			sendEvent("dotcom_chat.activate", {
				target: "SIDEBAR_CONVERSATION_NEW",
				mode: "immersive"
			});
		};
		$[0] = navigateToNewThread;
		$[1] = toggleFloatingSidebar;
		$[2] = t1;
	} else t1 = $[2];
	const handleNewThread = t1;
	let t2;
	if ($[3] !== toggleFloatingSidebar) {
		t2 = (e_0) => {
			if (e_0.metaKey || e_0.ctrlKey) return;
			toggleFloatingSidebar();
		};
		$[3] = toggleFloatingSidebar;
		$[4] = t2;
	} else t2 = $[4];
	const handleSpacesNavigate = t2;
	let t3;
	if ($[5] !== toggleFloatingSidebar) {
		t3 = (e_1) => {
			if (e_1.metaKey || e_1.ctrlKey) return;
			toggleFloatingSidebar();
		};
		$[5] = toggleFloatingSidebar;
		$[6] = t3;
	} else t3 = $[6];
	const handlePluginNavigate = t3;
	let t4;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = isFeatureEnabled("copilot_spaces_ga");
		$[7] = t4;
	} else t4 = $[7];
	const showSpacesPreviewLabel = !t4;
	let t5;
	if ($[8] !== activePluginId || $[9] !== handlePluginNavigate || $[10] !== handleSpacesNavigate || $[11] !== isCustomCopilotsEnabled || $[12] !== isSidebarCondensed || $[13] !== isSpacesPage || $[14] !== plugins) {
		const spacesItem = isCustomCopilotsEnabled ? [{
			type: "spaces",
			component: jsx(ServiceListItem, {
				"aria-current": isSpacesPage ? "page" : void 0,
				"data-analytics-event": serviceListAnalyticsData,
				displayName: "Spaces",
				href: COPILOT_SPACES_PATH,
				icon: SpacesIcon,
				condensed: isSidebarCondensed,
				id: "spaces",
				onLinkClick: handleSpacesNavigate,
				label: showSpacesPreviewLabel && jsx(Label, {
					variant: "success",
					children: "Preview"
				})
			}, "spaces"),
			displayName: "Spaces"
		}] : [];
		let t6;
		if ($[16] !== activePluginId || $[17] !== handlePluginNavigate || $[18] !== isSidebarCondensed) {
			t6 = (p) => {
				if (p.navigationItems && p.navigationItems.length > 0) return p.navigationItems.map((item) => ({
					type: "plugin",
					component: jsx(ServiceListItem, {
						"aria-current": activePluginId === p.id ? "page" : void 0,
						"data-analytics-event": serviceListAnalyticsData,
						displayName: item.displayName,
						href: item.href,
						icon: item.icon,
						condensed: isSidebarCondensed,
						id: item.id,
						onLinkClick: item.external ? void 0 : handlePluginNavigate,
						label: item.label,
						external: item.external
					}, `${p.id}-${item.id}`),
					displayName: item.displayName
				}));
				return [];
			};
			$[16] = activePluginId;
			$[17] = handlePluginNavigate;
			$[18] = isSidebarCondensed;
			$[19] = t6;
		} else t6 = $[19];
		const pluginItems = plugins.flatMap(t6);
		let t7;
		if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = isFeatureEnabled("copilot_default_to_task_input");
			$[20] = t7;
		} else t7 = $[20];
		const defaultToAgent = t7;
		let t8;
		if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
			t8 = (a, b) => {
				if (defaultToAgent) {
					if (a.displayName === "Agents") return -1;
					if (b.displayName === "Agents") return 1;
				}
				return a.displayName.localeCompare(b.displayName);
			};
			$[21] = t8;
		} else t8 = $[21];
		t5 = [...spacesItem, ...pluginItems].sort(t8);
		$[8] = activePluginId;
		$[9] = handlePluginNavigate;
		$[10] = handleSpacesNavigate;
		$[11] = isCustomCopilotsEnabled;
		$[12] = isSidebarCondensed;
		$[13] = isSpacesPage;
		$[14] = plugins;
		$[15] = t5;
	} else t5 = $[15];
	const sortedItems = t5;
	let t6;
	if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = isFeatureEnabled("copilot_default_to_task_input");
		$[22] = t6;
	} else t6 = $[22];
	const defaultToAgent_0 = t6;
	let t7;
	if ($[23] !== handleNewThread || $[24] !== isMainPage || $[25] !== isSidebarCondensed || $[26] !== sortedItems) {
		const items = sortedItems.map(_temp);
		const chatItem = jsx(ServiceListItem, {
			"aria-current": isMainPage ? "page" : void 0,
			"data-analytics-event": serviceListAnalyticsData,
			displayName: defaultToAgent_0 ? "Chat" : "New chat",
			href: COPILOT_PATH,
			icon: defaultToAgent_0 ? CommentDiscussionIcon : ComposeIcon,
			condensed: isSidebarCondensed,
			id: "home",
			onLinkClick: handleNewThread
		}, "home");
		const allItems = isFeatureEnabled("copilot_default_to_task_input") && sortedItems[0]?.displayName === "Agents" && items[0] ? [
			items[0],
			chatItem,
			...items.slice(1)
		] : [chatItem, ...items];
		t7 = jsx("ul", {
			className: ServiceList_module_default.list,
			children: allItems
		});
		$[23] = handleNewThread;
		$[24] = isMainPage;
		$[25] = isSidebarCondensed;
		$[26] = sortedItems;
		$[27] = t7;
	} else t7 = $[27];
	return t7;
}
ServiceList.displayName = "ServiceList";
function _temp(item_0) {
	return item_0.component;
}
var ManageSharedConversationsDialog_module_default = {
	actionButtons: "ManageSharedConversationsDialog-module_LqL7jq_actionButtons",
	alertIcon: "ManageSharedConversationsDialog-module_LqL7jq_alertIcon",
	confirmationText: "ManageSharedConversationsDialog-module_LqL7jq_confirmationText",
	conversationLink: "ManageSharedConversationsDialog-module_LqL7jq_conversationLink",
	copiedButton: "ManageSharedConversationsDialog-module_LqL7jq_copiedButton",
	dialog: "ManageSharedConversationsDialog-module_LqL7jq_dialog",
	footer: "ManageSharedConversationsDialog-module_LqL7jq_footer",
	footerContent: "ManageSharedConversationsDialog-module_LqL7jq_footerContent",
	footerLeft: "ManageSharedConversationsDialog-module_LqL7jq_footerLeft",
	footerRight: "ManageSharedConversationsDialog-module_LqL7jq_footerRight",
	mutedText: "ManageSharedConversationsDialog-module_LqL7jq_mutedText",
	quickFadeUp: "ManageSharedConversationsDialog-module_LqL7jq_quickFadeUp",
	successIcon: "ManageSharedConversationsDialog-module_LqL7jq_successIcon"
};
var UnshareConversationDialog_module_default = {
	bannerContainer: "UnshareConversationDialog-module_2ImUtG_bannerContainer",
	buttonStack: "UnshareConversationDialog-module_2ImUtG_buttonStack",
	container: "UnshareConversationDialog-module_2ImUtG_container",
	content: "UnshareConversationDialog-module_2ImUtG_content",
	copiedButton: "UnshareConversationDialog-module_2ImUtG_copiedButton",
	description: "UnshareConversationDialog-module_2ImUtG_description",
	innerContainer: "UnshareConversationDialog-module_2ImUtG_innerContainer",
	mutedText: "UnshareConversationDialog-module_2ImUtG_mutedText",
	sharedLinkContainer: "UnshareConversationDialog-module_2ImUtG_sharedLinkContainer",
	successIcon: "UnshareConversationDialog-module_2ImUtG_successIcon",
	textInput: "UnshareConversationDialog-module_2ImUtG_textInput",
	textInputContainer: "UnshareConversationDialog-module_2ImUtG_textInputContainer",
	textInputWithDelete: "UnshareConversationDialog-module_2ImUtG_textInputWithDelete",
	threadDescription: "UnshareConversationDialog-module_2ImUtG_threadDescription",
	threadInfoStack: "UnshareConversationDialog-module_2ImUtG_threadInfoStack",
	threadTitle: "UnshareConversationDialog-module_2ImUtG_threadTitle"
};
var UnshareConversationDialog = ({ closeDialog, threadId }) => {
	const state = useChatState();
	const manager = useChatManager();
	const { selectedThreadID, ssoOrganizations, apiUrl, threads } = state;
	const [loadedMessages, setLoadedMessages] = useState(state.messages);
	const [sharedThreadId, setSharedThreadId] = useState(() => {
		return threads.get(threadId)?.sharedID || "";
	});
	const sharedIdLoaded = useRef(sharedThreadId !== "");
	const prevSharedThreadId = useRef("");
	useEffect(() => {
		const fetchMessages = async () => {
			if (loadedMessages.filter((message) => message.threadID === threadId).length === 0) {
				const res = await new CopilotChatService(state.apiUrl, state.ssoOrganizations).listSharedThreadMessages(sharedThreadId);
				if (res.ok) setLoadedMessages(res.payload.messages);
			}
		};
		if (prevSharedThreadId.current !== sharedThreadId && sharedThreadId) {
			prevSharedThreadId.current = sharedThreadId;
			fetchMessages();
		}
	}, [
		sharedThreadId,
		threadId,
		loadedMessages,
		state.apiUrl,
		state.ssoOrganizations
	]);
	const currentThread = threads.get(threadId || selectedThreadID);
	const lastMessageContent = loadedMessages[loadedMessages.length - 1]?.content || "";
	useEffect(() => {
		const id = threadId || selectedThreadID;
		if (id) setSharedThreadId(threads.get(id)?.sharedID || "");
	}, [
		manager,
		setSharedThreadId,
		selectedThreadID,
		threads,
		threadId
	]);
	const handleUnshareLink = useCallback(async () => {
		const id_0 = threadId || selectedThreadID;
		const previousSharedID = sharedThreadId;
		const res_0 = await new CopilotChatService(apiUrl, ssoOrganizations).unshareThread(id_0);
		if (res_0.ok) {
			const { sharedID, sharedAt, sharedMessageID } = res_0.payload;
			manager.dispatch({
				type: "SHARED_THREAD_UPDATED",
				thread: {
					id: id_0,
					sharedID,
					sharedAt,
					sharedMessageID
				}
			});
			sharedIdLoaded.current = false;
			closeDialog();
			sendEvent("dotcom_chat.activate", {
				target: "COPILOT_UNSHARE_CONVERSATION",
				mode: "immersive",
				originalThreadId: id_0,
				sharedThreadId: previousSharedID
			});
		}
	}, [
		apiUrl,
		closeDialog,
		manager,
		selectedThreadID,
		ssoOrganizations,
		sharedThreadId,
		threadId
	]);
	const handleClose = useCallback(() => {
		closeDialog();
	}, [closeDialog]);
	const unshareButton = () => {
		if (!sharedThreadId) return;
		return /* @__PURE__ */ jsx(ButtonComponent$1, {
			onClick: handleUnshareLink,
			variant: "danger",
			children: "Unshare"
		});
	};
	const cancelButton = () => {
		return /* @__PURE__ */ jsx(ButtonComponent$1, {
			onClick: closeDialog,
			children: "Cancel"
		});
	};
	return /* @__PURE__ */ jsx(Dialog, {
		title: "Unshare conversation",
		onClose: handleClose,
		width: "large",
		children: /* @__PURE__ */ jsxs("div", {
			className: UnshareConversationDialog_module_default.container,
			children: [
				/* @__PURE__ */ jsx("span", { children: "You're about to unshare the link for the following conversation:" }),
				/* @__PURE__ */ jsxs(Stack, {
					direction: "vertical",
					className: UnshareConversationDialog_module_default.threadInfoStack,
					children: [/* @__PURE__ */ jsx("span", {
						className: UnshareConversationDialog_module_default.threadTitle,
						children: currentThread?.name || ""
					}), /* @__PURE__ */ jsx("span", {
						className: UnshareConversationDialog_module_default.threadDescription,
						children: lastMessageContent
					})]
				}),
				/* @__PURE__ */ jsx("span", { children: "Once unshared, the link will no longer be accessible." }),
				/* @__PURE__ */ jsxs(Stack, {
					direction: "horizontal",
					gap: "condensed",
					align: "end",
					justify: "end",
					className: UnshareConversationDialog_module_default.buttonStack,
					children: [cancelButton(), unshareButton()]
				})
			]
		})
	});
};
UnshareConversationDialog.displayName = "UnshareConversationDialog";
var formatDate = (dateString) => {
	const date = new Date(dateString);
	return new Intl.DateTimeFormat("en-US", {
		year: "numeric",
		month: "long",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
};
var ManageSharedConversationsDialog = ({ closeDialog, returnFocusRef }) => {
	const manager = useChatManager();
	const state = useChatState();
	const [pageIndex, setPageIndex] = useState(0);
	const [tableData, setTableData] = useState([]);
	const [isLoading, setIsLoading] = useState(true);
	const [showUnshareDialog, setShowUnshareDialog] = useState(false);
	const [selectedConversation, setSelectedConversation] = useState(null);
	const [showConfirmationText, setShowConfirmationText] = useState(false);
	const pageSize = 5;
	const [isPaginated, setIsPaginated] = useState(pageSize > tableData.length);
	const start = pageIndex * pageSize;
	const end = start + pageSize;
	const paginatedData = tableData.slice(start, end);
	useEffect(() => {
		const loadSharedThreads = async () => {
			const sharedThreads = await manager.fetchSharedThreads();
			if (sharedThreads) setTableData(sharedThreads.map((thread) => ({
				id: thread.id,
				conversation: thread.name || "New conversation",
				lastUpdated: formatDate(thread.updatedAt),
				sharedUrl: `${ssrSafeLocation.origin}/copilot/share/${thread.sharedID}`,
				threadUrl: `${ssrSafeLocation.origin}/copilot/c/${thread.id}`
			})));
			setIsLoading(false);
		};
		loadSharedThreads();
	}, [manager]);
	useEffect(() => {
		if (isPaginated && pageIndex > 0 && tableData.length <= pageIndex * pageSize) setPageIndex(0);
		const newIsPaginated = pageSize < tableData.length;
		if (newIsPaginated !== isPaginated) setIsPaginated(newIsPaginated);
	}, [
		tableData,
		pageIndex,
		pageSize,
		isPaginated
	]);
	const handleClose = useCallback(() => {
		closeDialog();
	}, [closeDialog]);
	const handleUnshareAllClick = useCallback(async () => {
		if (!showConfirmationText) {
			setShowConfirmationText(true);
			return;
		}
		setShowConfirmationText(false);
		setIsLoading(true);
		try {
			if ((await manager.unshareAllThreads()).ok) {
				setTableData([]);
				await manager.fetchThreads();
			}
		} finally {
			setIsLoading(false);
		}
	}, [showConfirmationText, manager]);
	const handleOpenUnshareDialog = (conversation) => {
		setSelectedConversation(conversation);
		setShowUnshareDialog(true);
	};
	const handleCloseUnshareDialog = async () => {
		setShowUnshareDialog(false);
		setSelectedConversation(null);
		setIsLoading(true);
		const sharedThreads_0 = await manager.fetchSharedThreads();
		if (sharedThreads_0) setTableData(sharedThreads_0.map((thread_0) => ({
			id: thread_0.id,
			conversation: thread_0.name || "New chat",
			lastUpdated: formatDate(thread_0.updatedAt),
			sharedUrl: `${ssrSafeLocation.origin}/copilot/share/${thread_0.sharedID}`,
			threadUrl: `${ssrSafeLocation.origin}/copilot/c/${thread_0.id}`
		})));
		setIsLoading(false);
	};
	const shouldShowBlankslate = isLoading || state.sharedThreadsLoading.state === "error" || tableData.length === 0;
	const footerButtons = useMemo(() => {
		if (!tableData.length) return [];
		const cancelButton = {
			buttonType: "default",
			content: "Cancel",
			onClick: () => setShowConfirmationText(false)
		};
		const unshareButton = {
			buttonType: "danger",
			content: "Unshare all",
			onClick: () => {
				if (showConfirmationText) handleUnshareAllClick();
				else setShowConfirmationText(true);
			}
		};
		return showConfirmationText ? [cancelButton, unshareButton] : [unshareButton];
	}, [
		tableData.length,
		showConfirmationText,
		handleUnshareAllClick
	]);
	const getConfirmationText = (count) => {
		if (count === 1) return "Are you sure you want to unshare this conversation?";
		return `Are you sure you want to unshare all ${count} conversations?`;
	};
	const blankslateContent = useMemo(() => {
		if (isLoading) return {
			result: "loading",
			heading: "Loading shared conversations",
			description: "Your shared conversations will appear here.",
			isSpinner: true
		};
		if (state.sharedThreadsLoading.state === "error") return {
			result: "error",
			heading: "We couldn't load the shared conversations",
			description: "Try again or, if the problem persists, contact support."
		};
		return {
			result: "empty",
			heading: "No shared conversations",
			description: "Your shared conversations will appear here."
		};
	}, [isLoading, state.sharedThreadsLoading.state]);
	return /* @__PURE__ */ jsxs(Dialog, {
		title: "Manage shared conversations",
		width: "xlarge",
		className: ManageSharedConversationsDialog_module_default.dialog,
		position: {
			narrow: "fullscreen",
			regular: "center"
		},
		onClose: handleClose,
		returnFocusRef,
		renderFooter: () => {
			if (!footerButtons?.length) return null;
			return /* @__PURE__ */ jsx(Dialog.Footer, {
				className: ManageSharedConversationsDialog_module_default.footer,
				children: /* @__PURE__ */ jsxs("div", {
					className: ManageSharedConversationsDialog_module_default.footerContent,
					children: [/* @__PURE__ */ jsx("div", {
						className: ManageSharedConversationsDialog_module_default.footerLeft,
						children: showConfirmationText && /* @__PURE__ */ jsx("div", {
							className: `${ManageSharedConversationsDialog_module_default.confirmationText} ${ManageSharedConversationsDialog_module_default.quickFadeUp}`,
							children: getConfirmationText(tableData.length)
						})
					}), /* @__PURE__ */ jsx("div", {
						className: ManageSharedConversationsDialog_module_default.footerRight,
						children: /* @__PURE__ */ jsx(Dialog.Buttons, { buttons: footerButtons })
					})]
				})
			});
		},
		children: [shouldShowBlankslate ? /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
			/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: blankslateContent.isSpinner ? /* @__PURE__ */ jsx(Stack, {
				direction: "horizontal",
				align: "center",
				children: /* @__PURE__ */ jsx(Spinner, {
					size: "medium",
					srText: "Loading shared conversations…"
				})
			}) : /* @__PURE__ */ jsx("div", {
				className: ManageSharedConversationsDialog_module_default.mutedText,
				children: blankslateContent.result === "error" ? /* @__PURE__ */ jsx(AlertIcon, {
					size: "medium",
					className: ManageSharedConversationsDialog_module_default.alertIcon,
					"aria-label": "Error loading shared conversations"
				}) : /* @__PURE__ */ jsx(LinkIcon, {
					size: "medium",
					"aria-label": "No shared conversations"
				})
			}) }),
			/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: blankslateContent.heading }),
			/* @__PURE__ */ jsx(BlankslateContainer.Description, { children: blankslateContent.description })
		] }) : /* @__PURE__ */ jsxs(Table.Container, { children: [/* @__PURE__ */ jsx(DataTable, {
			"aria-labelledby": "manage-shared-conversations",
			cellPadding: "normal",
			columns: [
				{
					header: "Chat",
					field: "conversation",
					width: "growCollapse",
					minWidth: "60%",
					rowHeader: true,
					renderCell: (row) => /* @__PURE__ */ jsx(Link, {
						href: row.threadUrl,
						className: ManageSharedConversationsDialog_module_default.conversationLink,
						children: row.conversation
					})
				},
				{
					header: "Last updated",
					field: "lastUpdated",
					width: "growCollapse",
					renderCell: (row_0) => /* @__PURE__ */ jsx("span", {
						className: ManageSharedConversationsDialog_module_default.mutedText,
						children: row_0.lastUpdated
					})
				},
				{
					id: "actions",
					width: "growCollapse",
					align: "end",
					header: () => /* @__PURE__ */ jsx("div", {
						className: "sr-only",
						children: "Actions"
					}),
					renderCell: (row_1) => {
						return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("div", {
							className: ManageSharedConversationsDialog_module_default.actionButtons,
							children: [/* @__PURE__ */ jsx(CopyToClipboardButton, {
								textToCopy: row_1.sharedUrl,
								onCopy: () => {
									sendEvent("dotcom_chat.activate", {
										target: "COPILOT_COPY_SHARED_CONVERSATION_LINK",
										mode: "immersive"
									});
								},
								ariaLabel: "Copy share link"
							}), /* @__PURE__ */ jsx(IconButton, {
								"aria-label": `Unshare chat`,
								title: `Unshare chat`,
								icon: UnlinkIcon,
								variant: "invisible",
								onClick: () => handleOpenUnshareDialog(row_1)
							})]
						}) });
					}
				}
			],
			data: paginatedData
		}), tableData.length > pageSize && /* @__PURE__ */ jsx(Table.Pagination, {
			"aria-label": "Shared chats pagination",
			pageSize,
			defaultPageIndex: pageIndex,
			totalCount: tableData.length,
			onChange: (pageInfo) => {
				setPageIndex(pageInfo.pageIndex);
			},
			showPages: false
		})] }), showUnshareDialog && selectedConversation && /* @__PURE__ */ jsx(UnshareConversationDialog, {
			threadId: selectedConversation.id,
			closeDialog: handleCloseUnshareDialog
		})]
	});
};
ManageSharedConversationsDialog.displayName = "ManageSharedConversationsDialog";
var UserMenu_module_default = {
	condensed: "UserMenu-module_o4r3jq_condensed",
	description: "UserMenu-module_o4r3jq_description",
	menuItem: "UserMenu-module_o4r3jq_menuItem",
	planLabel: "UserMenu-module_o4r3jq_planLabel",
	upgradeLink: "UserMenu-module_o4r3jq_upgradeLink",
	userAvatar: "UserMenu-module_o4r3jq_userAvatar",
	userButton: "UserMenu-module_o4r3jq_userButton",
	userContent: "UserMenu-module_o4r3jq_userContent",
	userDetails: "UserMenu-module_o4r3jq_userDetails",
	username: "UserMenu-module_o4r3jq_username"
};
function getPlanLabel(plan) {
	switch (plan) {
		case CopilotPlan.IndividualFree: return "Free";
		case CopilotPlan.IndividualStudent: return "Student";
		case CopilotPlan.IndividualPro: return "Pro";
		case CopilotPlan.IndividualProPlus: return "Pro+";
		case CopilotPlan.Business: return "Business";
		case CopilotPlan.Enterprise: return "Enterprise";
		default: return "Free";
	}
}
function UserMenu({ isCondensed = false }) {
	const anchorRef = useRef(null);
	const feedbackRef = useRef(null);
	const [showManageSharedDialog, setShowManageSharedDialog] = useState(false);
	const [showPersonalInstructionsDialog, setShowPersonalInstructionsDialog] = useState(false);
	const { currentUserLogin, plan, optedInToUserFeedback } = useChatStateValues("currentUserLogin", "plan", "optedInToUserFeedback");
	const isSpacesPage = useIsCopilotSpacesPage();
	const planLabel = `Copilot ${getPlanLabel(plan)}`;
	const isFree = !plan || plan === CopilotPlan.IndividualFree;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs(ActionMenu, {
			anchorRef,
			children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsxs("button", {
				className: clsx(UserMenu_module_default.userButton, isCondensed && UserMenu_module_default.condensed),
				"aria-label": isCondensed ? "user" : void 0,
				children: [/* @__PURE__ */ jsx("div", {
					className: UserMenu_module_default.userAvatar,
					children: /* @__PURE__ */ jsx(GitHubAvatar, {
						src: `/${currentUserLogin}.png`,
						size: 24
					})
				}), /* @__PURE__ */ jsxs("div", {
					className: UserMenu_module_default.userContent,
					children: [currentUserLogin, /* @__PURE__ */ jsx("div", {
						className: UserMenu_module_default.planLabel,
						children: planLabel
					})]
				})]
			}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				width: "small",
				align: "end",
				children: /* @__PURE__ */ jsxs(ActionList, { children: [
					/* @__PURE__ */ jsxs("div", {
						className: UserMenu_module_default.menuItem,
						children: [/* @__PURE__ */ jsx("div", {
							className: UserMenu_module_default.userAvatar,
							children: /* @__PURE__ */ jsx(GitHubAvatar, {
								src: `/${currentUserLogin}.png`,
								size: 32
							})
						}), /* @__PURE__ */ jsxs("div", {
							className: UserMenu_module_default.userDetails,
							children: [/* @__PURE__ */ jsx("div", {
								className: UserMenu_module_default.username,
								children: currentUserLogin
							}), /* @__PURE__ */ jsxs("span", {
								className: UserMenu_module_default.description,
								children: [planLabel, isFree && /* @__PURE__ */ jsxs(Fragment$1, { children: [" · ", /* @__PURE__ */ jsx(Link, {
									onClick: () => {
										sendEvent("dotcom_chat.activate", {
											target: "UPGRADE_USER_MENU_LINK",
											mode: "immersive"
										});
									},
									href: "https://github.com/github-copilot/pro",
									className: UserMenu_module_default.upgradeLink,
									children: "Upgrade"
								})] })]
							})]
						})]
					}),
					/* @__PURE__ */ jsx(ActionList.Divider, {}),
					/* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							setShowPersonalInstructionsDialog(true);
							sendEvent("dotcom_chat.activate", {
								target: "USER_MENU_PERSONAL_INSTRUCTIONS",
								mode: "immersive"
							});
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(NoteIcon, {}) }), "Personal instructions"]
					}),
					!isSpacesPage && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							setShowManageSharedDialog(true);
							sendEvent("dotcom_chat.activate", {
								target: "USER_MENU_MANAGE_SHARED",
								mode: "immersive"
							});
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ListUnorderedIcon, {}) }), "Manage shared conversations"]
					}),
					optedInToUserFeedback && /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							feedbackRef.current?.openDialog();
							sendEvent("dotcom_chat.activate", {
								target: "USER_MENU_GIVE_FEEDBACK",
								mode: "immersive"
							});
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CommentIcon, {}) }), "Give feedback"]
					}),
					/* @__PURE__ */ jsxs(ActionList.LinkItem, {
						href: "/settings/copilot",
						onClick: () => sendEvent("dotcom_chat.activate", {
							target: "USER_MENU_SETTINGS",
							mode: "immersive"
						}),
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GearIcon, {}) }), "Settings"]
					})
				] })
			})]
		}),
		/* @__PURE__ */ jsx(ConversationFeedbackDialog, {
			ref: feedbackRef,
			mode: "immersive",
			returnFocusRef: anchorRef
		}),
		showManageSharedDialog && /* @__PURE__ */ jsx(ManageSharedConversationsDialog, {
			closeDialog: () => {
				setShowManageSharedDialog(false);
			},
			returnFocusRef: anchorRef
		}),
		showPersonalInstructionsDialog && /* @__PURE__ */ jsx(PersonalInstructionsDialog, {
			onDismiss: () => setShowPersonalInstructionsDialog(false),
			returnFocusRef: anchorRef
		})
	] });
}
UserMenu.displayName = "UserMenu";
function CopilotNavigationWithContext() {
	const $ = c$1(5);
	const { sidebarExpanded, sidebarVisible, layoutBreakpoint, toggleSidebar } = useLayoutContext();
	let t0;
	if ($[0] !== layoutBreakpoint || $[1] !== sidebarExpanded || $[2] !== sidebarVisible || $[3] !== toggleSidebar) {
		t0 = jsx(CopilotNavigation, {
			sidebarExpanded,
			sidebarVisible,
			sidebarFloating: layoutBreakpoint,
			onToggleSidebar: toggleSidebar
		});
		$[0] = layoutBreakpoint;
		$[1] = sidebarExpanded;
		$[2] = sidebarVisible;
		$[3] = toggleSidebar;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
CopilotNavigationWithContext.displayName = "CopilotNavigationWithContext";
function ConditionalTooltip({ children, showTooltip, text, direction = "e" }) {
	if (!showTooltip) return /* @__PURE__ */ jsx(Fragment$1, { children });
	return /* @__PURE__ */ jsx(Tooltip$1, {
		text,
		direction,
		children
	});
}
ConditionalTooltip.displayName = "ConditionalTooltip";
function CopilotNavigation(t0) {
	const $ = c$1(32);
	const { onSidebarClick, onToggleSidebar: toggleSidebar, sidebarExpanded, sidebarFloating, sidebarVisible } = t0;
	const isCondensed = sidebarFloating ? false : !sidebarExpanded;
	const manager = useChatManager();
	const { threadsLoading, threads, selectedThreadID, ssoOrganizations, agentsEnabled, threadsHidden } = useChatStateValues("threadsLoading", "threads", "selectedThreadID", "ssoOrganizations", "agentsEnabled", "threadsHidden");
	const location = useLocation$1();
	let t1;
	if ($[0] !== location.pathname) {
		t1 = location.pathname.includes("/share/");
		$[0] = location.pathname;
		$[1] = t1;
	} else t1 = $[1];
	const isSharedThread = t1;
	let t2;
	let t3;
	if ($[2] !== manager || $[3] !== threads.size || $[4] !== threadsLoading.state) {
		t2 = () => {
			if (threads.size === 0 && threadsLoading.state === "pending") manager.fetchThreads();
		};
		t3 = [
			threads.size,
			manager,
			threadsLoading.state
		];
		$[2] = manager;
		$[3] = threads.size;
		$[4] = threadsLoading.state;
		$[5] = t2;
		$[6] = t3;
	} else {
		t2 = $[5];
		t3 = $[6];
	}
	useEffect(t2, t3);
	let t4;
	if ($[7] !== onSidebarClick || $[8] !== sidebarVisible || $[9] !== toggleSidebar) {
		t4 = () => {
			onSidebarClick?.();
			if (sidebarVisible) toggleSidebar();
		};
		$[7] = onSidebarClick;
		$[8] = sidebarVisible;
		$[9] = toggleSidebar;
		$[10] = t4;
	} else t4 = $[10];
	const handleSidebarClick = t4;
	const id = useId();
	let t5;
	if ($[11] !== isCondensed || $[12] !== toggleSidebar) {
		t5 = () => jsx(ConditionalTooltip, {
			showTooltip: isCondensed,
			text: "Expand sidebar",
			children: jsxs("button", {
				className: CopilotNavigation_module_default.footerButton,
				"aria-label": isCondensed ? "Expand sidebar" : "Collapse sidebar",
				onClick: toggleSidebar,
				children: [isCondensed ? jsx(SidebarCollapseIcon, {
					size: 16,
					className: CopilotNavigation_module_default.toggleButtonIcon
				}) : jsx(SidebarExpandIcon, {
					size: 16,
					className: CopilotNavigation_module_default.toggleButtonIcon
				}), jsx("span", {
					className: clsx(CopilotNavigation_module_default.footerButtonContent, isCondensed && CopilotNavigation_module_default.condensed),
					children: "Collapse"
				})]
			})
		});
		$[11] = isCondensed;
		$[12] = toggleSidebar;
		$[13] = t5;
	} else t5 = $[13];
	const renderToggleButton = t5;
	let t6;
	if ($[14] !== isCondensed || $[15] !== location || $[16] !== ssoOrganizations) {
		t6 = () => {
			if (ssoOrganizations.length === 0) return null;
			if (ssoOrganizations.length === 1) {
				const org = ssoOrganizations[0];
				if (!org) return null;
				return jsx(ConditionalTooltip, {
					showTooltip: isCondensed,
					text: "Single sign-on",
					children: jsxs("a", {
						href: generateSSOUrl(org.login, location),
						className: CopilotNavigation_module_default.footerButton,
						children: [jsx(ShieldLockIcon, {
							size: 16,
							className: CopilotNavigation_module_default.footerButtonIcon
						}), jsx("span", {
							className: clsx(CopilotNavigation_module_default.footerButtonContent, isCondensed && CopilotNavigation_module_default.condensed),
							"aria-hidden": isCondensed,
							children: "Single sign-on"
						})]
					})
				});
			}
			return jsx(ConditionalTooltip, {
				showTooltip: isCondensed,
				text: "Single sign-on",
				children: jsx("div", { children: jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsxs("button", {
					className: CopilotNavigation_module_default.footerButton,
					"aria-label": "Single sign-on",
					children: [jsx(Icon, {
						icon: ShieldLockIcon,
						size: 16,
						className: CopilotNavigation_module_default.footerButtonIcon
					}), jsx("div", {
						className: clsx(CopilotNavigation_module_default.footerButtonContent, isCondensed && CopilotNavigation_module_default.condensed),
						"aria-hidden": isCondensed,
						children: "Single sign-on"
					})]
				}) }), jsx(ActionMenu.Overlay, { children: jsx(ActionList, { children: ssoOrganizations.map((org_0) => jsx(ActionList.LinkItem, {
					href: generateSSOUrl(org_0.login, location),
					children: org_0.login
				}, org_0.login)) }) })] }) })
			});
		};
		$[14] = isCondensed;
		$[15] = location;
		$[16] = ssoOrganizations;
		$[17] = t6;
	} else t6 = $[17];
	const renderSSOMenu = t6;
	let t7;
	if ($[18] !== agentsEnabled || $[19] !== handleSidebarClick || $[20] !== id || $[21] !== isCondensed || $[22] !== isSharedThread || $[23] !== renderSSOMenu || $[24] !== renderToggleButton || $[25] !== selectedThreadID || $[26] !== sidebarFloating || $[27] !== ssoOrganizations || $[28] !== threadsHidden || $[29] !== threadsLoading.state || $[30] !== toggleSidebar) {
		t7 = jsxs(Fragment$1, { children: [jsxs(ErrorBoundary, {
			fallback: jsx(SidebarContentsFallback, {}),
			children: [jsxs("nav", {
				"aria-labelledby": `${id}-quick-links`,
				className: CopilotNavigation_module_default.quicklinks,
				children: [jsx("h3", {
					id: `${id}-quick-links`,
					className: "sr-only",
					children: "Quick links"
				}), jsx(ServiceList, {
					isSidebarCondensed: isCondensed,
					toggleFloatingSidebar: handleSidebarClick
				})]
			}), agentsEnabled ? jsx(ActivityPanel, {
				handleSidebarClick,
				isCondensed,
				onToggleSidebar: toggleSidebar
			}) : jsxs(Fragment$1, { children: [threadsHidden && !isCondensed && jsx(SSOWarningBanner, { ssoOrganizations }), jsx(ConversationList, {
				selectedItemID: isSharedThread ? null : selectedThreadID,
				loadingState: threadsLoading.state,
				onConversationSelect: handleSidebarClick,
				isSidebarCondensed: isCondensed
			})] })]
		}), jsxs("div", {
			className: CopilotNavigation_module_default.footer,
			children: [
				!sidebarFloating && renderToggleButton(),
				renderSSOMenu(),
				jsx(UserMenu, { isCondensed })
			]
		})] });
		$[18] = agentsEnabled;
		$[19] = handleSidebarClick;
		$[20] = id;
		$[21] = isCondensed;
		$[22] = isSharedThread;
		$[23] = renderSSOMenu;
		$[24] = renderToggleButton;
		$[25] = selectedThreadID;
		$[26] = sidebarFloating;
		$[27] = ssoOrganizations;
		$[28] = threadsHidden;
		$[29] = threadsLoading.state;
		$[30] = toggleSidebar;
		$[31] = t7;
	} else t7 = $[31];
	return t7;
}
CopilotNavigation.displayName = "CopilotNavigation";
function SidebarContentsFallback() {
	return /* @__PURE__ */ jsx("div", {
		className: CopilotNavigation_module_default.blankslateContainer,
		children: /* @__PURE__ */ jsx("div", { children: "Error loading conversations" })
	});
}
SidebarContentsFallback.displayName = "SidebarContentsFallback";
async function fetchAppPayloadByTask(incomingTaskID, owner, repo, taskCreationRequest, setStreamingChatResponse, setStreamingState) {
	if (!owner) throw new Error("No owner provided");
	if (!repo) throw new Error("No repo provided");
	let taskID = incomingTaskID;
	if (!taskID || taskID === "new") if (taskCreationRequest) {
		const trimmedContent = taskCreationRequest.problemStatement.trim();
		setStreamingState?.("requested");
		let resp;
		try {
			resp = await createTask({
				nwo: taskCreationRequest.nwo,
				problemStatement: trimmedContent,
				baseRef: taskCreationRequest.baseRef,
				eventType: "chat_page",
				eventContent: trimmedContent,
				model: taskCreationRequest.model,
				agentId: taskCreationRequest.agentId,
				customAgent: taskCreationRequest.customAgent,
				createPullRequest: taskCreationRequest.createPullRequest,
				clientGeneratedId: taskCreationRequest.clientGeneratedId,
				intentDetectionMode: taskCreationRequest.mode
			});
		} catch (error) {
			setStreamingState?.("closed");
			throw error;
		}
		if ((resp.headers.get("Content-Type") ?? "").includes("text/event-stream")) {
			const reader = resp.body?.getReader();
			if (!reader) {
				setStreamingState?.("closed");
				throw new Error("No reader found in response body");
			}
			const iterator = new CopilotChatMessageStreamer(reader).stream()[Symbol.asyncIterator]();
			let sessionID = "";
			let result = await iterator.next();
			while (!result.done) {
				if (result.value.type === "metadata") {
					taskID = result.value.task_id;
					sessionID = result.value.session_id;
					break;
				}
				result = await iterator.next();
			}
			(async () => {
				let accumulated = "";
				try {
					for (let next = await iterator.next(); !next.done; next = await iterator.next()) if (next.value.type === "content") {
						const content = next.value.body;
						if (content && setStreamingChatResponse) {
							accumulated += content;
							setStreamingChatResponse(sessionID, accumulated);
						}
					}
				} finally {
					setStreamingState?.("closed");
				}
			})();
		} else {
			setStreamingState?.("closed");
			const data = await resp.json();
			taskID = data.task?.id ?? data.id;
		}
	} else return null;
	const url = new URL(`/copilot/t/${owner}/${repo}/${taskID}`, window.location.origin);
	const response = await fetch(url.toString(), { headers: {
		Accept: "application/json",
		"X-Requested-With": "XMLHttpRequest"
	} });
	if (!response.ok) throw new Error(`Failed to fetch task payload for ${taskID}`);
	return await response.json();
}
function hasExpectedKeys(data, keys) {
	return typeof data === "object" && data !== null && keys.every((key) => key in data);
}
var agentTaskKeys = [
	"pull",
	"sessions",
	"currentUser",
	"currentUserCanPush",
	"steeringEnabled",
	"logsPollingInterval",
	"sessionsPollingInterval"
];
function isTaskAppPayload(payload) {
	return !!payload && hasExpectedKeys(payload, agentTaskKeys);
}
function useOrFetchOrCreateTaskPayload() {
	const $ = c$1(17);
	const ssrPayload = useAppPayload();
	const { taskID, owner, repository } = useParams$1();
	const validPayload = isTaskAppPayload(ssrPayload) && ssrPayload.pull ? ssrPayload : void 0;
	const { taskCreationRequest } = useIntentDetectionContext();
	const { setStreamingChatResponse, setStreamingState } = useChatStreamContext();
	useInitializeAuthToken(ssrPayload?.initialAuthToken);
	const t0 = taskCreationRequest?.clientGeneratedId;
	let t1;
	if ($[0] !== owner || $[1] !== repository || $[2] !== t0 || $[3] !== taskID) {
		t1 = [
			"create-task-payload",
			taskID,
			owner,
			repository,
			t0
		];
		$[0] = owner;
		$[1] = repository;
		$[2] = t0;
		$[3] = taskID;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== owner || $[6] !== repository || $[7] !== setStreamingChatResponse || $[8] !== setStreamingState || $[9] !== taskCreationRequest || $[10] !== taskID) {
		t2 = () => fetchAppPayloadByTask(taskID, owner, repository, taskCreationRequest, setStreamingChatResponse, setStreamingState);
		$[5] = owner;
		$[6] = repository;
		$[7] = setStreamingChatResponse;
		$[8] = setStreamingState;
		$[9] = taskCreationRequest;
		$[10] = taskID;
		$[11] = t2;
	} else t2 = $[11];
	const t3 = !!taskID && !validPayload;
	let t4;
	if ($[12] !== t1 || $[13] !== t2 || $[14] !== t3 || $[15] !== validPayload) {
		t4 = {
			queryKey: t1,
			queryFn: t2,
			initialData: validPayload,
			enabled: t3,
			staleTime: Infinity
		};
		$[12] = t1;
		$[13] = t2;
		$[14] = t3;
		$[15] = validPayload;
		$[16] = t4;
	} else t4 = $[16];
	return useQuery(t4);
}
/**
* Provides a render function for ContentPreview via context to avoid circular module dependencies.
* Consumers (e.g. TaskChat in agent-sessions) use ContentPreviewSlot instead of
* importing ContentPreview directly.
*/
var ContentPreviewRendererContext = createContext(null);
/**
* Stable wrapper component that renders ContentPreview from context.
* Uses a render function pattern to avoid React Compiler's
* "Cannot create components during render" error.
*/
ContentPreviewRendererContext.displayName = "ContentPreviewRendererContext";
function ContentPreviewSlot({ returnFocusRef, disableResourcePanel, disableActionsMenu, hideExpandButton, className }) {
	const renderer = use(ContentPreviewRendererContext);
	if (!renderer) return null;
	return renderer({
		returnFocusRef,
		disableResourcePanel,
		disableActionsMenu,
		hideExpandButton,
		className
	});
}
ContentPreviewSlot.displayName = "ContentPreviewSlot";
function useDiffOverlay(t0) {
	const $ = c$1(11);
	const { artifacts, pullBaseRef, pullHeadRef, hasActiveSession } = t0;
	const [isOpen, setIsOpen] = useState(false);
	const [initialFilePath, setInitialFilePath] = useState(null);
	let t1;
	if ($[0] !== artifacts) {
		t1 = getBranchArtifactData(artifacts);
		$[0] = artifacts;
		$[1] = t1;
	} else t1 = $[1];
	const branchArtifact = t1;
	const baseRef = branchArtifact?.base_ref || pullBaseRef;
	const headRef = branchArtifact?.head_ref || pullHeadRef;
	const [prevHasActiveSession, setPrevHasActiveSession] = useState(hasActiveSession);
	if (prevHasActiveSession !== hasActiveSession) {
		setPrevHasActiveSession(hasActiveSession);
		if (!prevHasActiveSession && hasActiveSession) {
			setIsOpen(false);
			setInitialFilePath(null);
		}
	}
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			setIsOpen(false);
			setInitialFilePath(null);
		};
		$[2] = t2;
	} else t2 = $[2];
	const close = t2;
	let t3;
	if ($[3] !== isOpen) {
		t3 = (filePath) => {
			if (isOpen && !filePath) {
				setIsOpen(false);
				setInitialFilePath(null);
			} else {
				setInitialFilePath(filePath ?? null);
				setIsOpen(true);
			}
		};
		$[3] = isOpen;
		$[4] = t3;
	} else t3 = $[4];
	const onViewDiff = t3;
	const onCloseDiff = close;
	let t4;
	if ($[5] !== baseRef || $[6] !== headRef || $[7] !== initialFilePath || $[8] !== isOpen || $[9] !== onViewDiff) {
		t4 = {
			isOpen,
			initialFilePath,
			baseRef,
			headRef,
			close,
			onViewDiff,
			onCloseDiff
		};
		$[5] = baseRef;
		$[6] = headRef;
		$[7] = initialFilePath;
		$[8] = isOpen;
		$[9] = onViewDiff;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
function TaskChatSuspendedWrapper() {
	return /* @__PURE__ */ jsx(IntentDetectionEnabledProvider, {
		isUsingIntentDetection: isFeatureEnabled("copilot_intent_detection"),
		children: /* @__PURE__ */ jsx(ChatStreamProvider, { children: /* @__PURE__ */ jsx(TaskChatSuspendedWrapperInner, {}) })
	});
}
TaskChatSuspendedWrapper.displayName = "TaskChatSuspendedWrapper";
function TaskChatSuspendedWrapperInner() {
	const $ = c$1(3);
	const { data: payload } = useOrFetchOrCreateTaskPayload();
	const { taskCreationRequest } = useIntentDetectionContext();
	const [createOwner, createRepo] = taskCreationRequest?.nwo?.split("/") || [];
	const { taskID } = useParams$1();
	const navigate = useNavigate$1();
	const ref = useNavigableRef();
	const isContentPreviewOpen = useContentPreviewOpen();
	const { openPreviewPane, closePreviewPane } = useContentPreview();
	const { currentUser, repository, sessionOwners } = payload || {};
	if (payload && !repository) throw new Error("No repository found in payload");
	useEffect(() => {
		if (payload && taskID === "new") navigate(`/copilot/t/${repository?.ownerLogin}/${repository?.name}/${payload.taskId}`, { replace: true });
	}, [
		taskID,
		payload,
		repository?.ownerLogin,
		repository?.name,
		navigate
	]);
	const originalPayload = useAppPayload();
	const currentUserIsSessionOwner = sessionOwners && !!sessionOwners.some((owner) => owner.id === currentUser?.id);
	let t0;
	if ($[0] !== closePreviewPane || $[1] !== openPreviewPane) {
		t0 = (open) => {
			if (open) openPreviewPane();
			else closePreviewPane();
		};
		$[0] = closePreviewPane;
		$[1] = openPreviewPane;
		$[2] = t0;
	} else t0 = $[2];
	const setContentPreviewPaneOpen = t0;
	return jsx(ConsecutiveCAPI401sProvider, { children: jsx(ArchiveDialogProvider, { children: jsxs(Layout, {
		mainColumn: "left",
		"data-hpc": true,
		secondaryColumnState: [isContentPreviewOpen, setContentPreviewPaneOpen],
		slimLineTopTabs: copilotFeatureFlags.copilotWorkbenchSlimLineTopTabs,
		children: [
			jsx(Layout.Sidebar, { children: jsx(CopilotNavigationWithContext, {}) }),
			jsxs(Layout.ColumnLeft, { children: [
				(!payload || !repository) && !taskCreationRequest && jsx("div", {
					className: TaskChat_module_default.suspenseSpinner,
					children: jsx(Spinner, { size: "medium" })
				}),
				!payload && taskCreationRequest && jsx(CurrentUserProvider, {
					currentUser: originalPayload?.currentUser,
					currentUserIsSessionOwner: true,
					children: jsx(TaskChatDuringCreation, {
						content: taskCreationRequest.problemStatement,
						currentUser: originalPayload?.currentUser,
						owner: createOwner,
						repo: createRepo
					})
				}),
				payload && repository && jsx(CurrentRepositoryProvider, {
					repository,
					children: jsx(CurrentUserProvider, {
						currentUser: payload.currentUser,
						currentUserIsSessionOwner,
						children: jsx(TaskChat, {
							forceV2Input: true,
							repoOwner: repository.ownerLogin,
							repoName: repository.name,
							showHeader: true,
							...payload
						}, payload.taskId)
					})
				})
			] }),
			jsx(Layout.ColumnRight, { children: jsx(ContentPreviewSlot, { returnFocusRef: ref }) })
		]
	}) }) });
}
TaskChatSuspendedWrapperInner.displayName = "TaskChatSuspendedWrapperInner";
function TaskChatDuringCreation({ currentUser, content, owner, repo }) {
	const fakeSession = {
		event_content: content,
		event_type: "chat",
		state: "in_progress"
	};
	return /* @__PURE__ */ jsx("div", {
		className: TaskChat_module_default.root,
		children: /* @__PURE__ */ jsx("div", {
			className: TaskChat_module_default.container,
			children: /* @__PURE__ */ jsx("div", {
				className: TaskChat_module_default.stickableContainer,
				children: /* @__PURE__ */ jsx("div", {
					className: TaskChat_module_default.content,
					children: /* @__PURE__ */ jsxs("div", {
						className: TaskChat_module_default.taskChatDuringCreationContainer,
						children: [
							/* @__PURE__ */ jsx(TaskChatHeader, {
								sessions: [fakeSession],
								sessionOwners: [],
								pull: void 0,
								task: void 0,
								repoOwner: owner,
								repoName: repo
							}),
							/* @__PURE__ */ jsx("div", {
								className: TaskChat_module_default.initialMessages,
								children: /* @__PURE__ */ jsx(UserInitialMessage, {
									currentUser,
									sessionOwner: currentUser,
									threadId: void 0,
									session: fakeSession,
									message: "",
									agentId: null
								})
							}),
							/* @__PURE__ */ jsxs(Stack, {
								direction: "horizontal",
								padding: "normal",
								align: "center",
								justify: "start",
								gap: "condensed",
								children: [/* @__PURE__ */ jsx(AgentAvatar, {
									animationType: CopilotAnimationType.Thinking,
									loopAnimation: true
								}), /* @__PURE__ */ jsx(WithShimmerEffect, {
									className: "color-fg-muted",
									children: "Planning response..."
								})]
							})
						]
					})
				})
			})
		})
	});
}
TaskChatDuringCreation.displayName = "TaskChatDuringCreation";
function TaskChatSuspended() {
	const $ = c$1(3);
	const { data: payload, isLoading } = useOrFetchTaskViewPayload();
	if (isLoading) {
		let t0;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t0 = jsx("div", {
				className: TaskChat_module_default.suspenseSpinner,
				children: jsx(Spinner, { size: "medium" })
			});
			$[0] = t0;
		} else t0 = $[0];
		return t0;
	}
	let t0;
	if ($[1] !== payload) {
		t0 = payload && jsx(TaskChat, { ...payload }, payload.taskId);
		$[1] = payload;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
TaskChatSuspended.displayName = "TaskChatSuspended";
function CenteredSpinner() {
	return /* @__PURE__ */ jsx("div", {
		className: TaskChat_module_default.blankSlateContainer,
		style: { alignItems: "center" },
		children: /* @__PURE__ */ jsx(Spinner, {})
	});
}
CenteredSpinner.displayName = "CenteredSpinner";
function CenteredBlankSlate({ title, description, statusLink, pullLink }) {
	return /* @__PURE__ */ jsx("div", {
		className: TaskChat_module_default.blankSlateContainer,
		children: /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
			/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(AlertIcon, {
				size: 24,
				className: "fgColor-muted"
			}) }),
			/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: title }),
			/* @__PURE__ */ jsx(BlankslateContainer.Description, {
				className: "text-center",
				children: description
			}),
			statusLink ? /* @__PURE__ */ jsx(BlankslateContainer.SecondaryAction, {
				href: statusLink,
				children: "GitHub status"
			}) : null,
			pullLink ? /* @__PURE__ */ jsx(BlankslateContainer.SecondaryAction, {
				href: pullLink,
				children: "Go to pull request"
			}) : null
		] })
	});
}
CenteredBlankSlate.displayName = "CenteredBlankSlate";
var ScrollToBottomButton = () => {
	const $ = c$1(2);
	const { isScrolledUp, scrollToBottom } = useChatScroll();
	if (!isScrolledUp) return null;
	let t0;
	if ($[0] !== scrollToBottom) {
		t0 = jsx(IconButton, {
			"aria-label": "Scroll to bottom",
			className: TaskChat_module_default.scrollToBottomButton,
			onClick: () => scrollToBottom("smooth"),
			icon: ArrowDownIcon,
			tooltipDirection: "n"
		});
		$[0] = scrollToBottom;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
};
ScrollToBottomButton.displayName = "ScrollToBottomButton";
function TaskChat({ showHeader = false, isRepoAgentsView = false, forceV2Input = false, repoOwner, repoName, taskId, branchAliveChannel, task, ...payload }) {
	const { agentMentions, pull, sessions, logsPollingInterval = 3e3, sessionsPollingInterval = 3e3, sessionOwners: initialSessionOwners, currentUserCanPush } = payload;
	const effectiveTaskId = taskId ?? pull?.global_relay_id;
	const repoNwo = repoOwner && repoName ? `${repoOwner}/${repoName}` : void 0;
	const isSidePanel = useViewMode() === "sidePanel";
	const effectiveNwo = repoNwo ?? pull?.repository_nwo;
	const useScrollToBottomButton = isRepoAgentsView && isFeatureEnabled("copilot_mission_control_scroll_to_bottom_button");
	const [searchParams] = useSearchParams();
	const urlSessionId = searchParams.get("session_id");
	const { currentUser, currentUserIsSessionOwner } = useCurrentUser$1();
	const [highlightedSessionId, setHighlightedSessionId] = useState(currentUserIsSessionOwner && urlSessionId ? urlSessionId : null);
	const sessionIdClearedRef = useRef(false);
	const scrollContainerRef = useRef(null);
	const sentinelRef = useRef(null);
	const chatInputRef = useRef(null);
	const textAreaRef = useRef(null);
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const collapsedSessionsEnabled = isFeatureEnabled("copilot_mission_control_collapsed_sessions");
	const initialDataSpinnerEnabled = isFeatureEnabled("copilot_mission_control_initial_data_spinner");
	const { streamingState, pendingChatMessage, clearPendingChat, latestChatSessionId, getChatMessageHistory } = useChatStreamContext();
	const { isUsingIntentDetection } = useIntentDetection();
	const { data: taskData } = useTask({
		owner: repoOwner,
		repo: repoName,
		taskId,
		initialTask: task
	});
	const { createSession: createNewSession } = useCreateAPISession();
	const { mutate: patchSession } = usePatchSession({ onError: (_error, variables) => {
		setOptimisticPlanStates((prev) => {
			const next = { ...prev };
			delete next[variables.session_id];
			return next;
		});
	} });
	const handlePlanApprove = (session) => (action, planSummary) => {
		if (!effectiveNwo || !effectiveTaskId) return;
		if (action === "exit_only") {
			updatePlanState(session.id, PLAN_STATE_DISMISSED);
			textAreaRef.current?.focus();
			return;
		}
		updatePlanState(session.id, PLAN_STATE_APPROVED);
		createNewSession({
			nwo: effectiveNwo,
			taskId: effectiveTaskId,
			problemStatement: action === "implement" ? `Implement the plan:\n\n${planSummary}` : action,
			eventType: "agent_task_post_session_steering"
		});
	};
	const isCLI = isAPITaskFromCLI(taskData);
	const taskPullRequestId = taskData ? getGitHubArtifactData(taskData.artifacts)?.id : void 0;
	const { data: detectedPull } = usePullRequest({
		pullRequestId: !pull ? taskPullRequestId : void 0,
		includeBody: false,
		refetchOnMount: true
	});
	const effectivePull = pull ?? detectedPull;
	const effectivePayload = {
		...payload,
		pull: effectivePull
	};
	const { data: sessionsData, isError: sessionsIsError, timedOut: sessionsTimedOut, isFetchedAfterMount: notUsingSessionInitialData } = useSessions({
		pullId: effectivePull?.id,
		taskId,
		initialData: sessions,
		sessionsPollingInterval,
		clearPendingChat
	});
	const hasActiveSession = sessionsData?.some(isActiveSession) ?? false;
	const [optimisticPlanStates, setOptimisticPlanStates] = useState({});
	const planStates = useMemo(() => {
		const states = {};
		const confirmedIds = /* @__PURE__ */ new Set();
		if (sessionsData) {
			for (const session_0 of sessionsData) if (session_0.event_identifiers?.includes("plan_approved")) {
				states[session_0.id] = PLAN_STATE_APPROVED;
				confirmedIds.add(session_0.id);
			} else if (session_0.event_identifiers?.includes("plan_dismissed")) {
				states[session_0.id] = PLAN_STATE_DISMISSED;
				confirmedIds.add(session_0.id);
			}
		}
		for (const [sessionId, state] of Object.entries(optimisticPlanStates)) if (!confirmedIds.has(sessionId)) states[sessionId] = state;
		return states;
	}, [sessionsData, optimisticPlanStates]);
	const updatePlanState = (sessionId_0, state_0) => {
		const freshSession = sessionsData?.find((s) => s.id === sessionId_0);
		if (!freshSession) return;
		const newEventIdentifiers = [...freshSession.event_identifiers ?? [], PLAN_STATE_TO_EVENT[state_0]];
		setOptimisticPlanStates((prev_0) => ({
			...prev_0,
			[sessionId_0]: state_0
		}));
		patchSession({
			user_id: freshSession.user_id,
			session_id: freshSession.id,
			task_id: freshSession.task_id,
			event_identifiers: newEventIdentifiers
		});
	};
	const diffOverlay = useDiffOverlay({
		artifacts: taskData?.artifacts,
		pullBaseRef: effectivePull?.base_ref_name,
		pullHeadRef: effectivePull?.head_ref_name,
		hasActiveSession
	});
	const { data: sessionOwners } = useSessionOwners({
		sessions: sessionsData,
		initialData: initialSessionOwners
	});
	const mostRecentSession = sessionsData?.[sessionsData.length - 1];
	const { data: mentions, isFetching: isFetchingMentions } = useAgentMentions({
		pull: effectivePull,
		sessions: sessionsData,
		initialData: agentMentions ?? [],
		agentId: mostRecentSession?.agent_id
	});
	const { allSessions, allMentions, addPendingSession, clearPendingSession } = usePendingSession({
		pullId: effectivePull?.id,
		taskId: effectiveTaskId,
		sessions: sessionsData,
		mentions,
		currentUser
	});
	const clearPending = () => {
		clearPendingSession();
	};
	const everySessionReadonly = sessionsData?.every((s_0) => isReadonlyAgent(s_0)) ?? false;
	const sortedSessions = allSessions.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
	const lastSession = allSessions.at(-1);
	const { data: inactiveLogs, isLoading: inactiveLogsIsLoading, isFetching: inactiveLogsIsFetching } = useInactiveLogs({
		sessions: sortedSessions,
		pullId: effectivePull?.id,
		repoOwner,
		repoName,
		taskId
	});
	const threadId = isFeatureEnabled("copilot_immersive_task_hyperlinking") ? extractSpecTaskThreadIdFromEventIdentifiers(allSessions.find((session_1) => session_1.event_type === COPILOT_CHAT_SPEC_TASK_EVENT_TYPE)?.event_identifiers) : void 0;
	const getMentionForSession = (session_2) => {
		if (!allMentions || !session_2.event_identifiers) return;
		return allMentions.find((mention) => session_2.event_identifiers?.includes(mention.id.toString()));
	};
	const getDefaultOpenState = (sessionId_1, index, isPending) => {
		if (urlSessionId) return sessionId_1 === urlSessionId;
		if (isPending) return true;
		if (sessionsData && sessionsData.some((session_4) => isActiveSession(session_4))) return sessionId_1 === sessionsData.find((session_3) => isActiveSession(session_3))?.id;
		if (collapsedSessionsEnabled) return false;
		return index === sortedSessions.length - 1;
	};
	const { scrollToBottom } = useScrollToBottom({
		containerRef: scrollContainerRef,
		behavior: "smooth"
	});
	const { setIsAtBottom } = useStickToBottom({
		containerRef: scrollContainerRef,
		sentinelRef,
		offset: 4,
		initialStickToBottom: !useScrollToBottomButton,
		resetKey: effectiveTaskId
	});
	const removeSessionIdFromUrl = useCallback(() => {
		if (!urlSessionId) return;
		if (typeof window === "undefined") return;
		if (sessionIdClearedRef.current) return;
		sessionIdClearedRef.current = true;
		const newParams = new URLSearchParams(searchParams);
		newParams.delete("session_id");
		const searchString = newParams.toString();
		addUrlToHistoryStack(`${window.location.pathname}${searchString ? `?${searchString}` : ""}${window.location.hash}`);
		queueMicrotask(() => setHighlightedSessionId(null));
	}, [searchParams, urlSessionId]);
	const handleContainerClick = (event) => {
		if (!highlightedSessionId) return;
		const target = event.target;
		const highlightedSession = scrollContainerRef.current?.querySelector(`[data-session-id="${highlightedSessionId}"]`);
		if (highlightedSession && !highlightedSession.contains(target)) removeSessionIdFromUrl();
	};
	useEffect(() => {
		sessionIdClearedRef.current = false;
	}, [urlSessionId]);
	useEffect(() => {
		if (urlSessionId) setIsAtBottom(false);
	}, [urlSessionId, setIsAtBottom]);
	useDiffEventHandler({
		chatInputRef,
		textAreaRef,
		isReadonly: everySessionReadonly,
		taskId: effectiveTaskId ?? ""
	});
	useEffect(() => {
		if (!urlSessionId) return;
		if (!sessionsData) return;
		const activeSessionId = sessionsData.find(isActiveSession)?.id ?? null;
		if (!activeSessionId) return;
		if (activeSessionId === urlSessionId) return;
		removeSessionIdFromUrl();
	}, [
		urlSessionId,
		sessionsData,
		removeSessionIdFromUrl
	]);
	useEffect(() => {
		if (chatInputRef.current) chatInputRef.current.setText("");
		if (urlSessionId) {
			setIsAtBottom(false);
			return;
		}
		if (!useScrollToBottomButton) {
			setIsAtBottom(true);
			if (scrollContainerRef.current) scrollToBottom({ behavior: "instant" });
		}
	}, [
		effectiveTaskId,
		setIsAtBottom,
		scrollToBottom,
		urlSessionId,
		useScrollToBottomButton
	]);
	const latestChatSessionLoaded = latestChatSessionId ? sortedSessions.some((s_1) => s_1.id === latestChatSessionId) : true;
	const showPendingUserMessage = isUsingIntentDetection && !!pendingChatMessage && streamingState === "requested";
	const showStreamingChatBridge = isUsingIntentDetection && !!latestChatSessionId && !latestChatSessionLoaded;
	const bridgeUserMessage = showStreamingChatBridge && latestChatSessionId ? getChatMessageHistory(latestChatSessionId).find((msg) => msg.role === "user") : null;
	return !sessionsData || !sessionOwners ? /* @__PURE__ */ jsx(CenteredSpinner, {}) : sessionsIsError && sessionsTimedOut ? /* @__PURE__ */ jsx(CenteredBlankSlate, {
		title: "Activity cannot be loaded",
		description: "The activity on this task is temporarily unavailable due to a system error. Try reloading the page, or if the problem persists, contact support.",
		statusLink: "https://www.githubstatus.com/"
	}) : !sessionsData.length && initialDataSpinnerEnabled && !notUsingSessionInitialData ? /* @__PURE__ */ jsx(CenteredSpinner, {}) : !sessionsData.length ? /* @__PURE__ */ jsx(CenteredBlankSlate, {
		title: "This task is not viewable",
		description: `You can't view this task because you do not have any active sessions${effectivePull ? " for this pull request" : ""}.`,
		pullLink: effectivePull?.url
	}) : /* @__PURE__ */ jsx(OptimisticLogsProvider, {
		sessionId: isCLI ? lastSession?.id : void 0,
		children: /* @__PURE__ */ jsx("div", {
			className: TaskChat_module_default.root,
			children: /* @__PURE__ */ jsxs("div", {
				className: TaskChat_module_default.container,
				children: [/* @__PURE__ */ jsxs("div", {
					className: TaskChat_module_default.diffOverlayWrapper,
					children: [/* @__PURE__ */ jsx("div", {
						className: clsx(TaskChat_module_default.stickableContainer, diffOverlay.isOpen && TaskChat_module_default.stickableContainerFrozen),
						children: /* @__PURE__ */ jsxs(ChatScrollContainer, {
							containerRef: scrollContainerRef,
							disabled: false,
							className: TaskChat_module_default.scrollContainer,
							onClick: handleContainerClick,
							children: [useScrollToBottomButton && /* @__PURE__ */ jsx(ScrollToBottomButton, {}), /* @__PURE__ */ jsxs("div", {
								className: clsx(TaskChat_module_default.content, isRepoAgentsView && TaskChat_module_default.repoAgentsViewContent, isSidePanel && TaskChat_module_default.sidePanelContent),
								children: [
									showHeader && /* @__PURE__ */ jsx(TaskChatHeader, {
										sessions: sortedSessions,
										sessionOwners,
										pull: effectivePull,
										task: taskData,
										repoOwner,
										repoName
									}),
									sortedSessions.map((session_5, index_0) => {
										const isFirstSession = index_0 === 0;
										const mention_0 = getMentionForSession(session_5);
										const isPending_0 = isPendingSession(session_5);
										const isReadonly = isReadonlyAgent(session_5);
										const sessionOwner = sessionOwners.find((owner) => owner.id === session_5.user_id);
										return /* @__PURE__ */ jsxs("div", {
											className: "d-flex flex-column",
											children: [
												isFirstSession && !isCLI && /* @__PURE__ */ jsxs("div", {
													className: TaskChat_module_default.initialMessages,
													children: [/* @__PURE__ */ jsx(UserInitialMessage, {
														currentUser,
														sessionOwner,
														threadId,
														session: session_5,
														message: isReadonly ? "requested a review" : "started a task",
														agentId: session_5.agent_id
													}), /* @__PURE__ */ jsx(CopilotInitialMessage, {
														session: session_5,
														message: isReadonly ? "started a review" : "started work"
													})]
												}),
												!isFirstSession && !isReadonly && (mention_0 || isFetchingMentions) && /* @__PURE__ */ jsx(UserMessage, {
													mention: mention_0,
													isLoading: !mention_0 && isFetchingMentions,
													agentId: session_5.agent_id
												}, mention_0?.id),
												!isFirstSession && !isReadonly && !mention_0 && !isFetchingMentions && /* @__PURE__ */ jsx(UserProblemStatementMessage, {
													session: session_5,
													sessionOwner
												}),
												!isFirstSession && isReadonly && /* @__PURE__ */ jsx("div", {
													className: TaskChat_module_default.readonlyMessageContainer,
													children: /* @__PURE__ */ jsx(CopilotInitialMessage, {
														session: session_5,
														message: "started a review"
													})
												}),
												/* @__PURE__ */ jsxs(SessionContextProvider, {
													session: session_5,
													sessionOwner,
													logs: inactiveLogs?.[session_5.id],
													logsAreLoading: inactiveLogsIsLoading || inactiveLogsIsFetching && inactiveLogs?.[session_5.id] === void 0,
													children: [/* @__PURE__ */ jsx(Session, {
														defaultOpen: getDefaultOpenState(session_5.id, index_0, isPending_0),
														scrollContainerRef,
														hideStopButton: isPending_0,
														onOpenChange: () => setIsAtBottom(false),
														onToolExpand: () => setIsAtBottom(false),
														shouldHighlight: session_5.id === highlightedSessionId,
														stickyHeaders: !isRepoAgentsView,
														currentUserCanPush,
														pull: effectivePull,
														logsPollingInterval,
														currentUser,
														nwo: effectiveNwo
													}), session_5.state === "completed" && /* @__PURE__ */ jsxs(Fragment$1, { children: [(currentUserIsSessionOwner && !isFirstSession || !currentUserIsSessionOwner) && (decoupledModeEnabled ? /* @__PURE__ */ jsx(CopilotReplyMessage, { logsPollingInterval: logsPollingInterval ?? 3e3 }) : /* @__PURE__ */ jsx(LegacyCopilotMessage, { logsPollingInterval: logsPollingInterval ?? 3e3 })), decoupledModeEnabled && MISSION_CONTROL_EVENT_TYPES.includes(session_5.event_type ?? "") && planStates[session_5.id] !== "dismissed" && (planStates[session_5.id] === "approved" || index_0 === sortedSessions.length - 1) && /* @__PURE__ */ jsx(CopilotFinalPlanMessage, {
														logsPollingInterval: logsPollingInterval ?? 3e3,
														onApprove: planStates[session_5.id] === "approved" ? void 0 : handlePlanApprove(session_5),
														isResolved: planStates[session_5.id] === "approved"
													})] })]
												})
											]
										}, session_5.id);
									}),
									(showPendingUserMessage || showStreamingChatBridge) && /* @__PURE__ */ jsxs(Fragment$1, { children: [
										showPendingUserMessage && sortedSessions[sortedSessions.length - 1]?.event_type !== "chat" && /* @__PURE__ */ jsx(LogChatMessage, { logEntry: pendingChatMessage }),
										showStreamingChatBridge && bridgeUserMessage && /* @__PURE__ */ jsx(LogChatMessage, { logEntry: bridgeUserMessage }),
										/* @__PURE__ */ jsxs(Stack, {
											direction: "horizontal",
											padding: "normal",
											align: "center",
											justify: "start",
											gap: "condensed",
											children: [/* @__PURE__ */ jsx(AgentAvatar, {
												animationType: CopilotAnimationType.Thinking,
												loopAnimation: true
											}), /* @__PURE__ */ jsx(WithShimmerEffect, {
												className: "color-fg-muted",
												children: "Planning response..."
											})]
										})
									] }),
									/* @__PURE__ */ jsx("div", {
										ref: sentinelRef,
										"aria-hidden": true,
										style: { height: 1 }
									})
								]
							})]
						})
					}), !effectivePull && diffOverlay.baseRef && diffOverlay.headRef && repoNwo && effectiveTaskId && /* @__PURE__ */ jsx(DiffOverlay, {
						isOpen: diffOverlay.isOpen,
						onClose: diffOverlay.close,
						repoNwo,
						taskId: effectiveTaskId,
						baseRef: diffOverlay.baseRef,
						headRef: diffOverlay.headRef,
						initialFilePath: diffOverlay.initialFilePath
					})]
				}), !everySessionReadonly && /* @__PURE__ */ jsx("div", {
					className: clsx(TaskChat_module_default.chatInputContainer, isRepoAgentsView && TaskChat_module_default.repoAgentsViewChatInput),
					children: isCLI && lastSession ? /* @__PURE__ */ jsx(CLIChatInput, {
						sessionId: lastSession.id,
						onCommandSent: scrollToBottom
					}) : (isRepoAgentsView || forceV2Input) && repoNwo ? taskData ? /* @__PURE__ */ jsx(TaskChatInputV2, {
						taskAgentId: allSessions[0]?.agent_id,
						activeSession: allSessions?.find(isActiveSession) ?? null,
						onAddPendingSession: addPendingSession,
						onClearPendingSession: clearPending,
						payload: effectivePayload,
						scrollToBottom,
						repoNwo,
						task: taskData,
						branchAliveChannel,
						onCloseDiff: diffOverlay.onCloseDiff,
						onViewDiff: diffOverlay.onViewDiff
					}) : null : /* @__PURE__ */ jsx(TaskChatInput, {
						taskAgentId: allSessions[0]?.agent_id,
						activeSession: allSessions?.find(isActiveSession) ?? null,
						onAddPendingSession: addPendingSession,
						onClearPendingSession: clearPendingSession,
						payload: effectivePayload,
						scrollToBottom,
						chatInputRef,
						inputRef: textAreaRef
					})
				})]
			})
		})
	});
}
TaskChat.displayName = "TaskChat";
export { getSelectedCommentId as $, TaskChatSuspended as A, useFileInfo as At, fileCopiedOnly as B, visit$1 as Bt, MarkdownViewer as C, urlHashFromLineRange as Ct, SessionLogsProvider as D, useContentPreviewOpen as Dt, PullRequestButton as E, useContentPreviewActions as Et, caseFirstCompare as F, usePreviousValue as Ft, fileWasGenerated as G, fileRenamedOnly as H, visitDependenciesAsync as Ht, createHandleOpenInCodespaces as I, usePullRequest as It, getFileTree as J, formatFilePath as K, createHandleOpenInGitHubDesktop as L, useResourcePanelOpen as Lt, Tool as M, useLayoutContext as Mt, Tooltip as N, useNavigateToNewThread as Nt, StaticUnifiedDiffPreview as O, useDraftIssueTreeMap as Ot, ViewModeProvider as P, useOrFetchTaskViewPayload as Pt, getSelectedAnnotationId as Q, createHandleOpenInVSCode as R, useSessions as Rt, LinesChangedCounterLabel as S, updateURLHashFromLineRange as St, OpenInMenu as T, useContentPreview as Tt, fileTruncated as U, whitespaceChangedOnly as Ut, fileModeChangedOnlyNoOtherChanges as V, visitDependencies as Vt, fileWasDeleted as W, getPreviousVersion as X, getItemVersionForReference as Y, getRevisionNumber as Z, IssueIcon as _, stripVersionFromId as _t, DataTable as a, makeItemFromIssueReference as at, Layout as b, updateFaviconByVariant as bt, DiffFileHeader as c, makeReferenceFromVersionedItem as ct, DiffLineTypeCharacter as d, parseDiffHash as dt, getSelectedFullDiffHash as et, DiffSelectedLineEvent as f, parseGitHubUrl as ft, Icon as g, serializeDraftIssueProjects as gt, FileStatusIcon as h, resetFavicon as ht, CopilotNavigationWithContext as i, makeItemFromFileReference as it, TaskChatSuspendedWrapper as j, useInitializeAuthToken as jt, TaskChat as k, useFeedbackDialog as kt, DiffFileTree_module_default as l, makeVersionedItemFromReference as lt, FileFilterShared as m, require_pluralize as mt, ContentPreviewProvider as n, makeItemForPluginSupportedReference as nt, DiffAddCommentButtonClickedEvent as o, makeItemFromJobReference as ot, FeedbackButton as p, parsePathDigestWithoutLineNumbers as pt, getFileExtension as q, ContentPreviewRendererContext as r, makeItemFromFileDiffReference as rt, DiffFeature as s, makeReferenceFromExistingIssue as st, ArchiveDialogProvider as t, isSelectingDiffLineOrRange as tt, DiffLineType as u, matchHash as ut, IssueTree as v, trimModelName as vt, MemoizedMarkdownViewer as w, useArchiveDialog as wt, LayoutContext as x, updateURLHash as xt, LAYOUT_BREAKPOINT as y, truncatedReason as yt, createHandleOpenInVSCodeInsiders as z, useStableCallback as zt };
