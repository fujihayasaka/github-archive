import { D as CheckCircleIcon, E as CheckCircleFillIcon, a as AlertFillIcon, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isValidElementType } from "react-is";
var classes = {
	"InlineMessage": "prc-InlineMessage-InlineMessage-8xfK-",
	"InlineMessageIcon": "prc-InlineMessage-InlineMessageIcon-rl8pZ"
};
var icons = {
	warning: /* @__PURE__ */ jsx(AlertIcon, { className: classes.InlineMessageIcon }),
	critical: /* @__PURE__ */ jsx(AlertIcon, { className: classes.InlineMessageIcon }),
	success: /* @__PURE__ */ jsx(CheckCircleIcon, { className: classes.InlineMessageIcon }),
	unavailable: /* @__PURE__ */ jsx(AlertIcon, { className: classes.InlineMessageIcon })
};
var smallIcons = {
	warning: /* @__PURE__ */ jsx(AlertFillIcon, {
		className: classes.InlineMessageIcon,
		size: 12
	}),
	critical: /* @__PURE__ */ jsx(AlertFillIcon, {
		className: classes.InlineMessageIcon,
		size: 12
	}),
	success: /* @__PURE__ */ jsx(CheckCircleFillIcon, {
		className: classes.InlineMessageIcon,
		size: 12
	}),
	unavailable: /* @__PURE__ */ jsx(AlertFillIcon, {
		className: classes.InlineMessageIcon,
		size: 12
	})
};
function InlineMessage(t0) {
	const $ = c(18);
	let LeadingVisual;
	let children;
	let className;
	let rest;
	let t1;
	let variant;
	if ($[0] !== t0) {
		({children, className, size: t1, variant, leadingVisual: LeadingVisual, ...rest} = t0);
		$[0] = t0;
		$[1] = LeadingVisual;
		$[2] = children;
		$[3] = className;
		$[4] = rest;
		$[5] = t1;
		$[6] = variant;
	} else {
		LeadingVisual = $[1];
		children = $[2];
		className = $[3];
		rest = $[4];
		t1 = $[5];
		variant = $[6];
	}
	const size = t1 === void 0 ? "medium" : t1;
	let icon;
	if (LeadingVisual !== void 0) if (typeof LeadingVisual !== "string" && isValidElementType(LeadingVisual)) {
		let t2;
		if ($[7] !== LeadingVisual) {
			t2 = /* @__PURE__ */ jsx(LeadingVisual, { className: classes.InlineMessageIcon });
			$[7] = LeadingVisual;
			$[8] = t2;
		} else t2 = $[8];
		icon = t2;
	} else icon = LeadingVisual;
	else icon = size === "small" ? smallIcons[variant] : icons[variant];
	let t2;
	if ($[9] !== className) {
		t2 = clsx(className, classes.InlineMessage);
		$[9] = className;
		$[10] = t2;
	} else t2 = $[10];
	let t3;
	if ($[11] !== children || $[12] !== icon || $[13] !== rest || $[14] !== size || $[15] !== t2 || $[16] !== variant) {
		t3 = /* @__PURE__ */ jsxs("div", {
			...rest,
			className: t2,
			"data-size": size,
			"data-variant": variant,
			children: [icon, children]
		});
		$[11] = children;
		$[12] = icon;
		$[13] = rest;
		$[14] = size;
		$[15] = t2;
		$[16] = variant;
		$[17] = t3;
	} else t3 = $[17];
	return t3;
}
export { InlineMessage as t };
