import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { r as getBaseFetchHeaders } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { a as getCursor, b as setSelection, d as insertAtCursor, f as insertAtStartOfLine, g as removeFromStartOfLine, h as posToOffset, i as findAndReplace, l as getSelection, n as computeMinimalChange, r as find, t as autocompleteTheme, u as helpPanelConstructor, v as replaceSelection, x as somethingSelected, y as setCursor } from "./server-theme-BtyxB5Uk-ZXETvnL8.js";
import { t as areCharacterKeyShortcutsEnabled } from "./server-keyboard-shortcuts-helper-BRqP2m0f-DOsDhPIe.js";
import { n as readOnly, r as spacingControls, t as externalUpdate } from "./server-readonly-G_4lcq4K-NnVP_IuN.js";
import memoize from "@github/memoize";
import { useEffect, useImperativeHandle, useLayoutEffect, useMemo, useRef } from "react";
import { jsx } from "react/jsx-runtime";
import { Decoration, EditorView, GutterMarker, ViewPlugin, dropCursor, gutterLineClass, keymap, lineNumbers, placeholder, tooltips } from "@codemirror/view";
import { Compartment, EditorState, Prec, RangeSet, RangeSetBuilder, StateEffect, StateField } from "@codemirror/state";
import { search, searchKeymap } from "@codemirror/search";
import { HighlightStyle, bracketMatching, indentOnInput, indentUnit, syntaxHighlighting } from "@codemirror/language";
import { acceptCompletion, autocompletion } from "@codemirror/autocomplete";
import { defaultKeymap, history, historyKeymap, indentLess, indentMore } from "@codemirror/commands";
import { tags } from "@lezer/highlight";
import { languages } from "@codemirror/language-data";
import { markdown, markdownLanguage } from "@codemirror/lang-markdown";
var specialCharacterKeyShortcuts = (() => {
	if (!areCharacterKeyShortcutsEnabled()) return [{
		key: "Alt-g",
		run: () => {
			return true;
		},
		preventDefault: true
	}];
	return [];
})();
var basicSetup = [
	history(),
	indentOnInput(),
	lineNumbers({ formatNumber: (line) => {
		return line.toString().padStart(3, " ");
	} }),
	bracketMatching(),
	tooltips({ position: "absolute" }),
	search({ top: true }),
	EditorView.editorAttributes.of({
		class: "js-codemirror-editor",
		"data-testid": "codemirror-editor"
	}),
	keymap.of([
		...specialCharacterKeyShortcuts,
		...defaultKeymap,
		...searchKeymap,
		...historyKeymap
	])
];
var ghTheme = {
	"&": {
		background: "var(--codeMirror-bgColor, var(--color-codemirror-bg))",
		color: "var(--codeMirror-fgColor, var(--color-codemirror-text))",
		cursor: "text"
	},
	".cm-gutters, .cm-gutters.cm-gutters-before": {
		background: "var(--codeMirror-gutters-bgColor, var(--color-codemirror-gutters-bg))",
		borderRightWidth: 0
	},
	".cm-lineNumbers .cm-gutterElement": {
		color: "var(--codeMirror-lineNumber-fgColor, var(--color-codemirror-linenumber-text))",
		fontFamily: "var(--fontStack-monospace)",
		fontSize: "var(--codeMirror-gutter-fontSize, var(--codeMirror-content-fontSize, 12px))",
		lineHeight: "20px",
		padding: "0 16px 0 16px"
	},
	".cm-content": {
		caretColor: "var(--codeMirror-cursor-fgColor, var(--color-codemirror-cursor))",
		fontFamily: "var(--fontStack-monospace)",
		fontSize: "var(--codeMirror-content-fontSize, 12px)",
		background: "var(--codeMirror-lines-bgColor, var(--color-codemirror-lines-bg))",
		lineHeight: "20px",
		paddingTop: "8px"
	},
	"&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": { backgroundColor: "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, #d7d4f0))" },
	"&.cm-focused": { outline: "none" },
	"&.hide-help-until-focus": {
		"&.cm-focused .cm-panels-bottom": { display: "block" },
		"& .cm-panels-bottom": { display: "none" }
	},
	"&.hide-help": { "& .cm-panels-top": {
		display: "none",
		position: "absolute"
	} },
	".cm-content ::-moz-selection": { backgroundColor: "var(--codeMirror-selection-bgColor, var(--color-codemirror-selection-bg, #d7d4f0))" },
	".cm-activeLine": { backgroundColor: "var(--codeMirror-activeline-bgColor, var(--color-codemirror-activeline-bg))" },
	".cm-selectionAttachment-mark": {
		backgroundColor: "var(--bgColor-accent-muted, var(--codeMirror-selection-bgColor, #d7d4f0))",
		borderBottom: "1px solid var(--borderColor-accent-emphasis, var(--color-accent-fg))",
		boxSizing: "border-box"
	},
	".cm-selectionAttachment-line": {
		backgroundColor: "var(--bgColor-accent-muted, var(--codeMirror-selection-bgColor, #d7d4f0))",
		boxSizing: "border-box"
	},
	".cm-selectionAttachment-gutter": {
		backgroundColor: "var(--bgColor-accent-muted, var(--codeMirror-selection-bgColor, #d7d4f0))",
		boxShadow: "inset 2px 0 0 var(--borderColor-accent-emphasis, var(--color-accent-fg))",
		color: "var(--fgColor-accent, var(--color-accent-fg))",
		fontWeight: "600",
		boxSizing: "border-box"
	},
	".cm-line": { paddingLeft: "16px" },
	".cm-help-panel": {
		background: "var(--bgColor-muted, var(--color-canvas-subtle))",
		padding: "7px 10px",
		margin: 0,
		fontSize: "13px",
		lineHeight: "16px",
		color: "var(--fgColor-muted, var(--color-fg-muted))",
		cursor: "default"
	},
	".cm-panels-bottom": {
		borderTop: "var(--borderWidth-thin, 1px) solid var(--borderColor-default, var(--color-border-default))",
		background: "none"
	},
	"@media (max-width: 544px)": { ".cm-panels-bottom": { position: "relative" } },
	".cm-panel.cm-search": {
		background: "var(--bgColor-muted, var(--color-canvas-subtle))",
		padding: "8px",
		fontSize: "16px"
	},
	".cm-panel.cm-search > button": {
		borderRadius: "6px",
		padding: "4px 8px",
		background: "var(--codeMirror-bgColor, var(--color-codemirror-bg))",
		color: "var(--button-default-fgColor-rest, var(--color-btn-text))",
		border: "1px solid var(--button-default-borderColor-rest, var(--color-btn-border))",
		textTransform: "capitalize"
	},
	".cm-panel.cm-search > label": {
		color: "var(--fgColor-default, var(--color-fg-default))",
		textTransform: "capitalize",
		fontSize: "12px"
	},
	".cm-panel.cm-search > input": {
		borderRadius: "6px",
		padding: "4px 8px",
		background: "var(--bgColor-default, var(--color-canvas-default))",
		color: "var(--fgColor-default, var(--color-fg-default))",
		border: "1px solid var(--borderColor-default, var(--color-border-default))",
		fontSize: "12px"
	},
	".cm-panel.cm-search > button[name=\"close\"]": { padding: "4px" },
	".cm-panels-top": {
		borderBottom: "var(--borderWidth-thin, 1px) solid var(--color-border-default)",
		background: "none"
	},
	".cm-panel.cm-search input, .cm-panel.cm-search button, .cm-panel.cm-search label": {
		marginRight: "8px",
		marginBottom: "4px",
		marginTop: "4px",
		marginLeft: 0
	},
	".cm-lintRange": {
		cursor: "help",
		backgroundImage: "none !important"
	},
	".cm-placeholder": {
		height: "1em",
		color: "var(--fgColor-muted)"
	},
	"&.custom-tooltips .cm-tooltip": {
		border: "none !important",
		backgroundColor: "transparent !important"
	},
	"&.custom-tooltips .cm-diagnostic": {
		padding: 0,
		marginLeft: "0 !important",
		borderLeft: "none !important",
		whiteSpace: "unset"
	}
};
var githubDefaultHighlights = [
	{
		tag: [tags.keyword],
		color: "var(--codeMirror-syntax-fgColor-keyword, var(--color-codemirror-syntax-keyword))"
	},
	{
		tag: [tags.comment],
		color: "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment))"
	},
	{
		tag: [tags.bracket],
		color: "var(--codeMirror-matchingBracket-fgColor, var(--color-codemirror-matchingbracket-text))"
	},
	{
		tag: [
			tags.string,
			tags.url,
			tags.regexp
		],
		color: "var(--codeMirror-syntax-fgColor-string, var(--color-codemirror-syntax-string))"
	},
	{
		tag: [
			tags.constant(tags.name),
			tags.propertyName,
			tags.attributeName
		],
		color: "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant))"
	},
	{
		tag: [
			tags.atom,
			tags.number,
			tags.bool
		],
		color: "var(--codeMirror-syntax-fgColor-constant, var(--color-codemirror-syntax-constant))"
	},
	{
		tag: [tags.function(tags.variableName)],
		color: "var(--codeMirror-syntax-fgColor-entity, var(--color-codemirror-syntax-entity))"
	},
	{
		tag: tags.definition(tags.variableName),
		color: "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable))"
	},
	{
		tag: tags.meta,
		color: "inherit"
	},
	{
		tag: tags.heading,
		fontWeight: "bold",
		color: "inherit !important"
	},
	{
		tag: tags.monospace,
		color: "var(--codeMirror-syntax-fgColor-comment, var(--color-codemirror-syntax-comment))"
	}
];
var darkModeHighlights = [];
var codemirrorDefaultHighlightStyle = [
	{
		tag: tags.link,
		textDecoration: "underline"
	},
	{
		tag: tags.emphasis,
		fontStyle: "italic"
	},
	{
		tag: tags.strong,
		fontWeight: "bold"
	},
	{
		tag: tags.strikethrough,
		textDecoration: "line-through"
	}
];
var githubLightHighlightStyle = [...githubDefaultHighlights, ...codemirrorDefaultHighlightStyle];
var githubDarkHighlightStyle = [
	...githubDefaultHighlights,
	...darkModeHighlights,
	...codemirrorDefaultHighlightStyle
];
function getTheme(additionalStyles = []) {
	const extendedHighlightStyles = [...document.querySelector("[data-color-mode=\"dark\"]") !== null ? githubDarkHighlightStyle : githubLightHighlightStyle, ...additionalStyles];
	return [EditorView.theme(ghTheme), syntaxHighlighting(HighlightStyle.define(extendedHighlightStyles), { fallback: true })];
}
var handleUploadChange = (event, view) => {
	const { state, placeholder, replacementText } = event.detail;
	if (state === "uploading") if (somethingSelected(view)) replaceSelection(view, placeholder);
	else insertAtCursor(view, replacementText);
	else if (state === "uploaded" || state === "failed") findAndReplace(view, placeholder, replacementText);
};
var handleCursorChange = (event, view) => {
	const { left, top } = event.detail;
	const dropPos = view.posAtCoords({
		x: left,
		y: top
	});
	if (!dropPos) return;
	view.dispatch({ selection: {
		anchor: dropPos,
		head: dropPos
	} });
};
function fileUploadListener() {
	const eventHandlers = {
		"upload:editor:change": handleUploadChange,
		"upload:editor:cursor": handleCursorChange
	};
	return [EditorView.domEventHandlers(eventHandlers)];
}
var addLintMark = StateEffect.define({ map: ({ from, to, severity }, change) => ({
	from: change.mapPos(from),
	to: change.mapPos(to),
	severity
}) });
var lintMarkField = StateField.define({
	create() {
		return Decoration.none;
	},
	update(lintMarks, tr) {
		lintMarks = lintMarks.map(tr.changes);
		for (const e of tr.effects) if (e.is(addLintMark)) {
			if (e.value.severity === "error") lintMarks = lintMarks.update({ add: [lintMarkError.range(e.value.from, e.value.to)] });
			else if (e.value.severity === "warning") lintMarks = lintMarks.update({ add: [lintMarkWarning.range(e.value.from, e.value.to)] });
			else if (e.value.severity === "info") lintMarks = lintMarks.update({ add: [lintMarkInfo.range(e.value.from, e.value.to)] });
		}
		return lintMarks;
	},
	provide: (f) => EditorView.decorations.from(f)
});
var lintMarkError = Decoration.mark({ class: "CodeMirror-lint-mark-error" });
var lintMarkWarning = Decoration.mark({ class: "CodeMirror-lint-mark-warning" });
var lintMarkInfo = Decoration.mark({ class: "CodeMirror-lint-mark-info" });
var handleSecretLint = (event, view) => {
	const { from, to, severity } = event.detail;
	const fromOffset = posToOffset(view, {
		line: from.lineNumber,
		ch: from.character
	});
	const toOffset = posToOffset(view, {
		line: to.lineNumber,
		ch: to.character
	});
	view.dispatch({ effects: [addLintMark.of({
		from: fromOffset,
		to: toOffset,
		severity
	})] });
};
function secretDetectedListener() {
	const eventHandlers = { "secret-detected:lint": handleSecretLint };
	return [EditorView.domEventHandlers(eventHandlers), lintMarkField];
}
function dataHpc() {
	return EditorView.editorAttributes.of({ "data-hpc": "true" });
}
/**
* Adds role, tabIndex, and aria-labelledby attributes to the scroller DOM element
* @param ariaLabelledBy The id of the element that the scroller is labelled by
* @returns Extension
*/
function scrollerAttributes(ariaLabelledBy) {
	return [ViewPlugin.fromClass(class {
		constructor(view) {
			view.scrollDOM.tabIndex = 0;
			view.scrollDOM.setAttribute("role", "region");
			view.scrollDOM.setAttribute("aria-labelledby", ariaLabelledBy);
		}
	})];
}
/**
* This function is used to create an extension that is toggleable by a key binding.
* @param key The key to use to toggle the extension
* @param extension The extension to toggle
* @param initialState The initial state of the extension
* @returns An extension array
*/
function toggleWith(keyBinding, extension, initiallyEnabled) {
	const initial = initiallyEnabled ? extension : [];
	const privateCompartment = new Compartment();
	function toggle(view) {
		const on = privateCompartment.get(view.state) === extension;
		view.dispatch({ effects: privateCompartment.reconfigure(on ? [] : extension) });
		return true;
	}
	return [privateCompartment.of(initial), keymap.of([{
		key: keyBinding,
		run: toggle
	}])];
}
var insertIndent = ({ state, dispatch }) => {
	if (state.selection.ranges.some((r) => !r.empty)) return indentMore({
		state,
		dispatch
	});
	dispatch(state.update(state.replaceSelection(state.facet(indentUnit)), {
		scrollIntoView: true,
		userEvent: "input"
	}));
	return true;
};
var indentWithTab = {
	key: "Tab",
	run: insertIndent,
	shift: indentLess
};
function focusTrapToggle(hideHelp) {
	return [toggleWith("Shift-Ctrl-m", keymap.of([indentWithTab]), true), helpPanelConstructor(focusTrapHelpPanel(), hideHelp ? "top" : "bottom")];
}
function focusTrapHelpPanel() {
	const dom = document.createElement("div");
	const createKbdElement = (key) => {
		const kbd = document.createElement("kbd");
		kbd.textContent = key;
		return kbd;
	};
	dom.append("Use ", createKbdElement(`Control + Shift + m`), " to toggle the ", createKbdElement("tab"), " key moving focus. Alternatively, use ", createKbdElement("esc"), " then ", createKbdElement("tab"), " to move to the next interactive element on the page.");
	dom.className = "cm-help-panel";
	dom.id = "focus-trap-help-panel";
	return dom;
}
var languageThemes = {
	ruby: [{
		tag: tags.variableName,
		color: "var(--codeMirror-syntax-fgColor-variable, var(--color-codemirror-syntax-variable))"
	}],
	html: [{
		tag: tags.meta,
		color: "var(--color-prettylights-syntax-constant)"
	}, {
		tag: tags.name,
		color: "var(--color-prettylights-syntax-entity-tag)"
	}],
	javascript: [{
		tag: tags.name,
		color: "var(--color-prettylights-syntax-variable)"
	}],
	typescript: [{
		tag: tags.name,
		color: "var(--color-prettylights-syntax-variable)"
	}, {
		tag: tags.typeName,
		color: "var(--color-prettylights-syntax-keyword)"
	}],
	java: [{
		tag: tags.typeName,
		color: "var(--color-prettylights-syntax-entity)"
	}],
	"c++": [{
		tag: tags.meta,
		color: "var(--color-prettylights-syntax-constant)"
	}, {
		tag: tags.typeName,
		color: "var(--color-prettylights-syntax-keyword)"
	}],
	php: [{
		tag: tags.processingInstruction,
		color: "var(--color-prettylights-syntax-constant)"
	}, {
		tag: tags.name,
		color: "var(--color-prettylights-syntax-entity)"
	}]
};
var languageNames = Object.keys(languageThemes);
function loadLanguageTheme(name) {
	if (languageNames.includes(name.toLowerCase())) return languageThemes[name.toLowerCase()];
	return null;
}
var emojiRequest = memoize(async function getEmojis() {
	const request = new Request("/autocomplete/emojis_for_editor", {
		method: "GET",
		credentials: "same-origin",
		headers: {
			Accept: "application/json",
			...getBaseFetchHeaders()
		}
	});
	const res = await fetch(request);
	if (res.status !== 200) throw new Error(`emoji request failed with a ${res.status}`);
	const emojiData = await res.json();
	return Object.keys(emojiData).map((emojiName) => {
		const emoji = emojiData[emojiName];
		return {
			name: emojiName,
			src: emoji[0],
			emoji: emoji[1]
		};
	});
});
function emojiAutocompleteContext(context, data = []) {
	const word = context.matchBefore(/:\w+/);
	if (!word) return null;
	if (word && word.from === word.to && !context.explicit) return null;
	const completions = data.filter((emoji) => {
		return emoji.name.indexOf(word.text.replace(":", "")) !== -1;
	}).map((emoji) => {
		return {
			label: emoji.name,
			apply: emoji.emoji || `:${emoji.name}:`,
			type: emoji.src
		};
	});
	return {
		from: word.from,
		to: word.to,
		options: completions,
		filter: false
	};
}
function emojiAutocomplete() {
	return [
		autocompleteTheme,
		autocompletion({
			override: [async (context) => {
				return emojiAutocompleteContext(context, await emojiRequest());
			}],
			icons: false,
			addToOptions: [{
				render: (completion) => {
					const emojiOption = document.createElement("img");
					emojiOption.className = "emoji emoji-result mr-2";
					emojiOption.height = 20;
					emojiOption.width = 20;
					emojiOption.alt = `:${completion.label}:`;
					emojiOption.src = completion.type;
					emojiOption.setAttribute("async", "");
					return emojiOption;
				},
				position: 0
			}]
		}),
		Prec.highest(keymap.of([{
			key: "Tab",
			run: acceptCompletion
		}]))
	];
}
var ITALIC_TOKEN = "_";
var BOLD_TOKEN = "**";
var CODE_TOKEN = "`";
var BLOCKQUOTE_TOKEN = ">";
var ORDERED_LIST_TOKEN = "ol";
var UNORDERED_LIST_TOKEN = "-";
var DISALLOW_LINKYFY_ON_PASTE = /* @__PURE__ */ new WeakMap();
function insertToken(view, token) {
	if (somethingSelected(view)) replaceSelection(view, `${token}${getSelection(view.state)}${token}`);
	else {
		const cursor = getCursor(view);
		insertAtCursor(view, token.repeat(2));
		setCursor(view, cursor.anchor + token.length);
	}
	return true;
}
function toggleList(view, token) {
	const cursor = getCursor(view);
	const currentLine = view.state.doc.lineAt(cursor.from);
	const selection = getSelection(view.state);
	const prefixRegex = new RegExp(`^${token === "ol" ? "\\d+\\." : token}\\s`);
	if (selection) {
		const lines = (selection.endsWith("\n") ? selection.slice(0, -2) : selection).split("\n").map((_line, index) => {
			const lineNumber = currentLine.number + index;
			return {
				text: view.state.doc.line(lineNumber).text,
				lineNumber
			};
		});
		const everyLineStartsWithPrefix = lines.every((line) => prefixRegex.test(line.text));
		for (let i = 0; i < lines.length; i++) {
			const line = lines[i];
			if (everyLineStartsWithPrefix) {
				const match = line.text.match(prefixRegex);
				if (match) removeFromStartOfLine(view, line?.lineNumber, match[0]);
			} else {
				const marker = `${token === "ol" ? `${i + 1}.` : token} `;
				insertAtStartOfLine(view, line?.lineNumber, marker);
			}
		}
	} else {
		const match = currentLine.text.match(prefixRegex);
		if (match) removeFromStartOfLine(view, currentLine.number, match[0]);
		else {
			const marker = `${token === "ol" ? `1.` : token} `;
			insertAtStartOfLine(view, currentLine.number, marker);
			if (!currentLine.text) setCursor(view, cursor.anchor + marker.length);
		}
	}
	return true;
}
var insertLink = (view) => {
	const selection = getSelection(view.state);
	if (selection) {
		const newSelection = `[${selection}](url)`;
		replaceSelection(view, newSelection);
		const matchStart = find(view, newSelection).value.from;
		setSelection(view, matchStart + selection.length + 3, matchStart + selection.length + 6);
	} else {
		const cursor = getCursor(view);
		insertAtCursor(view, "[](url)");
		setCursor(view, cursor.anchor + 1);
	}
	return true;
};
function insertSelectedTextLink(view, event) {
	const selection = getSelection(view.state);
	const dataTransfer = event.clipboardData;
	if (selection && dataTransfer) {
		const pasteLink = dataTransfer.getData("text/plain");
		if (!/^https?:\/\//i.test(pasteLink)) return;
		if (pasteLink) {
			event.preventDefault();
			replaceSelection(view, `[${selection}](${pasteLink})`);
		}
	}
}
function setDisallowLinkifyOnPaste(view, disallow) {
	DISALLOW_LINKYFY_ON_PASTE.set(view, disallow);
	return false;
}
var insertItalicToken = (view) => insertToken(view, ITALIC_TOKEN);
var insertBoldToken = (view) => insertToken(view, BOLD_TOKEN);
var insertCodeToken = (view) => insertToken(view, CODE_TOKEN);
var toggleBlockQuoteList = (view) => toggleList(view, BLOCKQUOTE_TOKEN);
var toggleOrderedList = (view) => toggleList(view, ORDERED_LIST_TOKEN);
var toggleUnorderedList = (view) => toggleList(view, UNORDERED_LIST_TOKEN);
var pasteFormatted = (view) => setDisallowLinkifyOnPaste(view, false);
var pasteUnformatted = (view) => setDisallowLinkifyOnPaste(view, true);
var MarkdownKeymaps = [
	{
		key: "Mod-i",
		run: insertItalicToken,
		preventDefault: true
	},
	{
		key: "Mod-b",
		run: insertBoldToken,
		preventDefault: true
	},
	{
		key: "Mod-e",
		run: insertCodeToken,
		preventDefault: true
	},
	{
		key: "Mod-k",
		run: insertLink,
		preventDefault: true
	},
	{
		key: "Shift-Mod-.",
		run: toggleBlockQuoteList,
		preventDefault: true
	},
	{
		key: "Shift-Mod-7",
		run: toggleOrderedList,
		preventDefault: true
	},
	{
		key: "Shift-Mod-8",
		run: toggleUnorderedList,
		preventDefault: true
	},
	{
		key: "Mod-v",
		run: pasteFormatted
	},
	{
		key: "Shift-Mod-v",
		run: pasteUnformatted
	}
];
var autoDirectionDecoration = Decoration.line({ attributes: { dir: "auto" } });
function autoDirectionBuilder(view) {
	const builder = new RangeSetBuilder();
	for (const { from, to } of view.visibleRanges) for (let pos = from; pos <= to;) {
		const line = view.state.doc.lineAt(pos);
		builder.add(line.from, line.from, autoDirectionDecoration);
		pos = line.to + 1;
	}
	return builder.finish();
}
var autoDirectionPlugin = ViewPlugin.fromClass(class {
	decorations;
	constructor(view) {
		this.decorations = autoDirectionBuilder(view);
	}
	update(update) {
		if (update.docChanged || update.viewportChanged) if (update.viewportChanged) this.decorations = autoDirectionBuilder(update.view);
		else {
			this.decorations = this.decorations.map(update.changes);
			const newLineDecos = [];
			const changedRanges = [];
			update.changes.iterChangedRanges((_fromA, _toA, fromB, toB) => {
				const doc = update.state.doc;
				const startLine = doc.lineAt(fromB);
				const endLine = doc.lineAt(Math.min(toB, doc.length));
				changedRanges.push({
					from: startLine.from,
					to: endLine.to
				});
				for (let ln = startLine.number; ln <= endLine.number; ln++) {
					const line = doc.line(ln);
					newLineDecos.push(autoDirectionDecoration.range(line.from, line.from));
				}
			});
			if (newLineDecos.length > 0) this.decorations = this.decorations.update({
				filter: (from) => !changedRanges.some((r) => from >= r.from && from <= r.to),
				add: newLineDecos,
				sort: true
			});
		}
	}
}, { decorations: (v) => v.decorations });
var markdownExtension = [
	EditorView.domEventHandlers({
		keydown(event) {
			if ((event.metaKey || event.ctrlKey) && event.key === "k") event.stopPropagation();
		},
		paste(event, view) {
			if (!DISALLOW_LINKYFY_ON_PASTE.get(view)) insertSelectedTextLink(view, event);
			DISALLOW_LINKYFY_ON_PASTE.set(view, false);
		}
	}),
	keymap.of(MarkdownKeymaps),
	autoDirectionPlugin
];
async function loadLanguage({ autoCompleteCompartment, view, viewB, fileName, languageCompartment, managedExtensions, themeCompartment }) {
	const fileExtension = fileName.split(".").pop() || "";
	const language = fileExtension ? languages.find((l) => l.extensions.includes(fileExtension) || l.filename && l.filename.test(fileName)) : void 0;
	if (language && view) {
		const languageTheme = loadLanguageTheme(language.name);
		if (languageTheme) dispatch(view, viewB, { effects: themeCompartment.reconfigure(getTheme(languageTheme)) });
		if (language.name === "Markdown") {
			dispatch(view, viewB, { effects: languageCompartment.reconfigure(markdown({ base: markdownLanguage })) });
			dispatch(view, viewB, { effects: StateEffect.reconfigure.of([...markdownExtension, ...managedExtensions]) });
			dispatch(view, viewB, { effects: autoCompleteCompartment.reconfigure(emojiAutocomplete()) });
		} else {
			dispatch(view, viewB, { effects: autoCompleteCompartment.reconfigure([]) });
			dispatch(view, viewB, { effects: languageCompartment.reconfigure(await language.load()) });
		}
	}
}
function dispatch(view, viewB, transaction) {
	view.dispatch(transaction);
	if (viewB) viewB.dispatch(transaction);
}
/**
* CodeMirror extension that notifies when a non-empty selection changes and when it is cleared.
* - Calls onSelection with the current selection (from/to/text and line numbers).
* - Calls onClear when the selection becomes empty after being non-empty.
* - Debounced by default to avoid excessive calls while dragging.
*/
function selectionListener({ onSelection, onClear, debounceMs = 300 } = {}) {
	let lastSignature = "";
	let emittingSelection = false;
	const debouncedHandle = debounce((vu) => {
		const sel = vu.state.selection.main;
		if (!emittingSelection || sel.empty) return;
		const from = sel.from;
		const to = sel.to;
		const text = vu.state.doc.sliceString(from, to);
		const signature = `${from}-${to}:${vu.state.doc.length}`;
		if (lastSignature === signature) return;
		lastSignature = signature;
		const fromLine = vu.state.doc.lineAt(from).number;
		const toLine = vu.state.doc.lineAt(to).number;
		onSelection?.({
			view: vu.view,
			from,
			to,
			text,
			fromLine,
			toLine
		});
	}, debounceMs);
	return EditorView.updateListener.of((vu) => {
		if (vu.state.selection.main.empty) {
			if (emittingSelection) {
				onClear?.(vu.view);
				lastSignature = "";
			}
			emittingSelection = false;
			return;
		}
		emittingSelection = true;
		debouncedHandle(vu);
	});
}
var addSelectionAttachmentMark = StateEffect.define({ map: ({ from, to }, change) => ({
	from: change.mapPos(from),
	to: change.mapPos(to)
}) });
var addSelectionAttachmentGutters = StateEffect.define({ map: ({ from, to }, change) => ({
	from: change.mapPos(from),
	to: change.mapPos(to)
}) });
var addSelectionAttachmentLines = StateEffect.define({ map: ({ from, to }, change) => ({
	from: change.mapPos(from),
	to: change.mapPos(to)
}) });
var clearSelectionAttachments = StateEffect.define();
var selectionAttachmentMark = Decoration.mark({ class: "cm-selectionAttachment-mark" });
/** Create a gutter marker for highlighted line numbers */
var selectionAttachmentGutterMarker = new class extends GutterMarker {
	elementClass = "cm-selectionAttachment-gutter";
}();
var selectionAttachmentLineDeco = Decoration.line({ class: "cm-selectionAttachment-line" });
var selectionAttachmentMarkField = StateField.define({
	create() {
		return Decoration.none;
	},
	update(marks, tr) {
		marks = marks.map(tr.changes);
		for (const e of tr.effects) if (e.is(addSelectionAttachmentMark)) if (e.value.from !== e.value.to) {
			const b = new RangeSetBuilder();
			b.add(e.value.from, e.value.to, selectionAttachmentMark);
			marks = b.finish();
		} else marks = Decoration.none;
		else if (e.is(clearSelectionAttachments)) marks = Decoration.none;
		return marks;
	},
	provide: (f) => EditorView.decorations.from(f)
});
var selectionAttachmentGutterField = StateField.define({
	create() {
		return RangeSet.empty;
	},
	update(gutters, tr) {
		gutters = gutters.map(tr.changes);
		for (const e of tr.effects) if (e.is(addSelectionAttachmentGutters)) {
			if (e.value.from !== e.value.to) {
				const { state } = tr;
				const startLine = state.doc.lineAt(e.value.from);
				const endLine = state.doc.lineAt(e.value.to);
				const b = new RangeSetBuilder();
				for (let lineNumber = startLine.number; lineNumber <= endLine.number; lineNumber++) {
					const line = state.doc.line(lineNumber);
					b.add(line.from, line.from, selectionAttachmentGutterMarker);
				}
				gutters = b.finish();
			}
		} else if (e.is(clearSelectionAttachments)) gutters = RangeSet.empty;
		return gutters;
	},
	provide: (f) => gutterLineClass.from(f)
});
var selectionAttachmentLineField = StateField.define({
	create() {
		return Decoration.none;
	},
	update(lines, tr) {
		lines = lines.map(tr.changes);
		for (const e of tr.effects) if (e.is(addSelectionAttachmentLines)) if (e.value.from !== e.value.to) {
			const { state } = tr;
			const startLine = state.doc.lineAt(e.value.from);
			const endLine = state.doc.lineAt(e.value.to);
			const b = new RangeSetBuilder();
			for (let lineNumber = startLine.number; lineNumber <= endLine.number; lineNumber++) {
				const line = state.doc.line(lineNumber);
				b.add(line.from, line.from, selectionAttachmentLineDeco);
			}
			lines = b.finish();
		} else lines = Decoration.none;
		else if (e.is(clearSelectionAttachments)) lines = Decoration.none;
		return lines;
	},
	provide: (f) => EditorView.decorations.from(f)
});
function useCodeMirror({ extensions = [], fileName = "", onChange, spacing, isHpc, isReadOnly, enableFileUpload, parentRef, placeholder: placeholder$1 = "Enter file contents here", ariaLabelledBy, value, width = "", height = "", minHeight = "", hideHelpUntilFocus, hideHelp, onCreateEditor, onDestroyEditor, selectionListenerOptions, selectionAttachmentRange }) {
	const viewRef = useRef(void 0);
	const languageCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const autoCompleteCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const themeCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const onChangeRef = useRef(onChange);
	useLayoutEffect(() => {
		onChangeRef.current = onChange;
	});
	const inpOptimizationsEnabled = isFeatureEnabled("codemirror_inp_optimizations");
	const lastInternalValueRef = useRef(value);
	const hasPendingFlushRef = useRef(false);
	const flushTimerRef = useRef(0);
	const updateListener = useMemo(() => EditorView.updateListener.of((update) => {
		if (update.docChanged) if (inpOptimizationsEnabled) {
			hasPendingFlushRef.current = true;
			const updatedState = update.state;
			window.clearTimeout(flushTimerRef.current);
			flushTimerRef.current = window.setTimeout(() => {
				hasPendingFlushRef.current = false;
				const newDoc = updatedState.doc.toString() || "";
				lastInternalValueRef.current = newDoc;
				onChangeRef.current(newDoc);
			}, 0);
		} else onChangeRef.current(update.state.doc.toString() || "");
	}), [inpOptimizationsEnabled]);
	const editorSizingTheme = useMemo(() => EditorView.theme({ "&": {
		height,
		minHeight,
		width
	} }), [
		height,
		minHeight,
		width
	]);
	const managedExtensions = useMemo(() => {
		const exts = [
			...basicSetup,
			updateListener,
			editorSizingTheme,
			placeholder(placeholder$1),
			...spacingControls(spacing),
			secretDetectedListener(),
			languageCompartment.of([]),
			autoCompleteCompartment.of([]),
			themeCompartment.of([getTheme()]),
			scrollerAttributes(ariaLabelledBy),
			EditorView.contentAttributes.of({ "aria-labelledby": `${ariaLabelledBy} focus-trap-help-panel` }),
			EditorView.editorAttributes.of({ class: hideHelpUntilFocus ? "hide-help-until-focus" : "" }),
			EditorView.editorAttributes.of({ class: hideHelp ? "hide-help" : "" })
		];
		if (enableFileUpload) {
			exts.push(dropCursor());
			exts.push(fileUploadListener());
		}
		if (isHpc) exts.push(dataHpc());
		if (isReadOnly) exts.push(readOnly());
		else exts.push(focusTrapToggle(hideHelp));
		if (selectionListenerOptions) exts.push(selectionListener(selectionListenerOptions));
		if (selectionAttachmentRange !== void 0) exts.push(selectionAttachmentMarkField, selectionAttachmentGutterField, selectionAttachmentLineField);
		exts.push(...extensions);
		return exts;
	}, [
		updateListener,
		editorSizingTheme,
		placeholder$1,
		spacing,
		languageCompartment,
		autoCompleteCompartment,
		themeCompartment,
		ariaLabelledBy,
		hideHelpUntilFocus,
		hideHelp,
		enableFileUpload,
		isHpc,
		isReadOnly,
		selectionListenerOptions,
		selectionAttachmentRange,
		extensions
	]);
	useEffect(() => {
		const parent = parentRef.current;
		if (!parent) return;
		const view = new EditorView({
			state: EditorState.create({
				doc: value,
				extensions: managedExtensions
			}),
			parent
		});
		onCreateEditor?.(view);
		viewRef.current = view;
		return () => {
			window.clearTimeout(flushTimerRef.current);
			view.destroy();
			onDestroyEditor?.(view);
		};
	}, []);
	useEffect(() => {
		if (viewRef.current) {
			viewRef.current.dispatch({ effects: autoCompleteCompartment.reconfigure([]) });
			viewRef.current.dispatch({ effects: StateEffect.reconfigure.of(managedExtensions) });
		}
	}, [autoCompleteCompartment, managedExtensions]);
	useEffect(() => {
		if (viewRef.current && value !== void 0) {
			if (inpOptimizationsEnabled) {
				if (value === lastInternalValueRef.current) return;
				if (hasPendingFlushRef.current) return;
			}
			const currentValue = viewRef.current.state.doc.toString() || "";
			const newValue = value || "";
			if (newValue !== currentValue) {
				const changes = computeMinimalChange(currentValue, newValue);
				if (changes.length > 0) {
					if (inpOptimizationsEnabled) lastInternalValueRef.current = newValue;
					viewRef.current.dispatch({
						changes,
						annotations: [externalUpdate.of(true)]
					});
				}
			}
		}
	}, [value, inpOptimizationsEnabled]);
	useEffect(() => {
		if (viewRef.current && selectionAttachmentRange !== void 0) if (selectionAttachmentRange === null) viewRef.current.dispatch({ effects: clearSelectionAttachments.of() });
		else viewRef.current.dispatch({ effects: [addSelectionAttachmentGutters.of(selectionAttachmentRange), addSelectionAttachmentLines.of(selectionAttachmentRange)] });
	}, [selectionAttachmentRange]);
	useEffect(() => {
		loadLanguage({
			autoCompleteCompartment,
			fileName,
			languageCompartment,
			managedExtensions,
			themeCompartment,
			view: viewRef.current
		});
	}, [
		fileName,
		languageCompartment,
		autoCompleteCompartment,
		managedExtensions,
		themeCompartment
	]);
	return viewRef;
}
var EMPTY_EXTENSION_ARRAY = [];
var EMPTY_KEY_BINDING_ARRAY = [];
var CodeMirror = ({ ref, ...props }) => {
	const { value = "", extensions = EMPTY_EXTENSION_ARRAY, keyBindings = EMPTY_KEY_BINDING_ARRAY, height = "85vh", width = "100%", focusNextRenderRef, containerClassName, selectionListenerOptions, selectionAttachmentRange: decoratedSelectionRange, ...rest } = props;
	const editorRef = useRef(null);
	const viewRef = useCodeMirror({
		parentRef: editorRef,
		value,
		height,
		width,
		extensions: useMemo(() => [...extensions, keymap.of(keyBindings)], [extensions, keyBindings]),
		selectionListenerOptions,
		selectionAttachmentRange: decoratedSelectionRange,
		...rest
	});
	useImperativeHandle(ref, () => ({
		editor: editorRef.current,
		view: viewRef.current
	}), [editorRef, viewRef]);
	if (focusNextRenderRef?.current && viewRef) {
		window.requestAnimationFrame(() => {
			if (viewRef.current && !viewRef.current.hasFocus) viewRef.current.focus();
		});
		focusNextRenderRef.current = false;
	}
	return /* @__PURE__ */ jsx("div", {
		className: containerClassName,
		ref: editorRef
	});
};
CodeMirror.displayName = "CodeMirror";
export { scrollerAttributes as a, loadLanguage as i, basicSetup as n, secretDetectedListener as o, getTheme as r, CodeMirror as t };
