performance.mark("js-parse-end:server-NavigationTabPopover-kJ1QqvVY-DtSsPJCb.js");
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Mi as XIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { a as GlobalCommands, r as CommandIconButton } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import React from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:NavigationTabPopover-kJ1QqvVY.js");
var NavigationTabPopover_module_default = {
	CloseButton: "NavigationTabPopover-module_1YidsG_CloseButton",
	PopoverContainer: "NavigationTabPopover-module_1YidsG_PopoverContainer",
	PopoverContent: "NavigationTabPopover-module_1YidsG_PopoverContent",
	PopoverHeader: "NavigationTabPopover-module_1YidsG_PopoverHeader",
	PopoverMessage: "NavigationTabPopover-module_1YidsG_PopoverMessage"
};
/**
* A popover component that displays on a navigation tab to provide contextual
* messaging and a call-to-action.
*/
function NavigationTabPopover(t0) {
	const $ = c(15);
	const { id, popoverData, onDismiss } = t0;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const navigate = useNavigate$1();
	let t1;
	if ($[0] !== navigate || $[1] !== onDismiss || $[2] !== popoverData.analytics || $[3] !== popoverData.cta.href || $[4] !== sendClickAnalyticsEvent) {
		t1 = (e) => {
			e.stopPropagation();
			e.preventDefault();
			if (popoverData.analytics) sendClickAnalyticsEvent({
				label: popoverData.analytics.label,
				target_url: popoverData.analytics.target_url,
				view: popoverData.analytics.view
			});
			onDismiss();
			navigate(popoverData.cta.href);
		};
		$[0] = navigate;
		$[1] = onDismiss;
		$[2] = popoverData.analytics;
		$[3] = popoverData.cta.href;
		$[4] = sendClickAnalyticsEvent;
		$[5] = t1;
	} else t1 = $[5];
	const handleCtaClick = t1;
	let t2;
	if ($[6] !== handleCtaClick || $[7] !== id || $[8] !== onDismiss || $[9] !== popoverData.cta.label || $[10] !== popoverData.header || $[11] !== popoverData.message) {
		let t3;
		if ($[13] !== onDismiss) {
			t3 = () => onDismiss();
			$[13] = onDismiss;
			$[14] = t3;
		} else t3 = $[14];
		t2 = jsxs(Fragment$1, { children: [jsx(GlobalCommands, { commands: { "github:cancel": onDismiss } }), jsx(Popover_default, {
			open: true,
			className: NavigationTabPopover_module_default.PopoverContainer,
			popover: "manual",
			caret: "top-left",
			id,
			children: jsxs(Popover_default.Content, {
				onClickOutside: t3,
				className: NavigationTabPopover_module_default.PopoverContent,
				children: [
					jsx(CommandIconButton, {
						"aria-label": "Dismiss",
						commandId: "github:cancel",
						icon: XIcon,
						variant: "invisible",
						className: NavigationTabPopover_module_default.CloseButton
					}),
					jsx("h4", {
						className: NavigationTabPopover_module_default.PopoverHeader,
						children: popoverData.header
					}),
					jsx("p", {
						className: NavigationTabPopover_module_default.PopoverMessage,
						children: popoverData.message
					}),
					jsx(ButtonComponent, {
						onClick: handleCtaClick,
						children: popoverData.cta.label
					})
				]
			})
		})] });
		$[6] = handleCtaClick;
		$[7] = id;
		$[8] = onDismiss;
		$[9] = popoverData.cta.label;
		$[10] = popoverData.header;
		$[11] = popoverData.message;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
}
NavigationTabPopover.displayName = "NavigationTabPopover";
export { NavigationTabPopover };
