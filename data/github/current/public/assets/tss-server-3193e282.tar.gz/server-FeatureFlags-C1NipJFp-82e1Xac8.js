import { n as FeatureFlagScope, t as FeatureFlagContext } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { useContext, useMemo } from "react";
import { jsx } from "react/jsx-runtime";
/**
* Ref count for data-dialog-scroll-optimized attribute management.
*
* NOTE: This is temporary infrastructure while we feature flag the CSS :has()
* performance optimization (primer_react_css_has_selector_perf). Once the flag
* is removed and the optimization is the default behavior, this ref counting
* can be removed - the attribute can simply always be present.
*
* @internal - Not part of the public API
*/
var dialogScrollOptimizedCount = 0;
function FeatureFlags({ children, flags }) {
	const parentFeatureFlags = useContext(FeatureFlagContext);
	const value = useMemo(() => {
		return FeatureFlagScope.merge(parentFeatureFlags, FeatureFlagScope.create(flags));
	}, [parentFeatureFlags, flags]);
	const isOptimizationEnabled = value.enabled("primer_react_css_has_selector_perf");
	useIsomorphicLayoutEffect(() => {
		if (isOptimizationEnabled) {
			dialogScrollOptimizedCount++;
			document.body.setAttribute("data-dialog-scroll-optimized", "");
			return () => {
				dialogScrollOptimizedCount--;
				if (dialogScrollOptimizedCount === 0) document.body.removeAttribute("data-dialog-scroll-optimized");
			};
		}
	}, [isOptimizationEnabled]);
	return /* @__PURE__ */ jsx(FeatureFlagContext.Provider, {
		value,
		children
	});
}
FeatureFlags.displayName = "FeatureFlags";
export { FeatureFlags as t };
