import { QueryClient } from "@tanstack/react-query";
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
*
* Extended from https://github.com/TanStack/query/blob/256624af671772732c7e11c2689bb1697ee7e72c/packages/query-core/src/utils.ts#L212-L223
*/
function queryKeyHashFn(queryKey) {
	return JSON.stringify(queryKey, (_, val) => {
		if (isPlainObject(val)) return Object.keys(val).sort().reduce((result, key) => {
			result[key] = val[key];
			return result;
		}, {});
		/**
		* Define extensions to the standard JSONSerializer here
		* This is used to ensure that the query key is always the same for the same data
		* Especially when that data doesn't traditionally `JSON.stringify` correctly.
		*/
		if (val instanceof URLSearchParams) return new URLSearchParams([...val.entries()].sort(([a], [b]) => a.localeCompare(b))).toString();
		if (typeof val === "bigint") return `$bigint:${val}`;
		if (val instanceof Set) return Array.from(val).sort();
		if (val instanceof Map) return Array.from(val.entries()).sort(([a], [b]) => a.localeCompare(b)).reduce((obj, [key, value]) => {
			obj[key] = value;
			return obj;
		}, {});
		return val;
	});
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (Object.getPrototypeOf(o) !== Object.prototype) return false;
	return true;
}
var browserQueryClient = null;
var serverQueryClientGetter = null;
var QueryClientConfig = { defaultOptions: {
	queries: {
		refetchOnWindowFocus: false,
		retry: false,
		networkMode: "always",
		queryKeyHashFn
	},
	mutations: { networkMode: "always" }
} };
/**
* Creates a new QueryClient with default configuration. Can be customized via `queryConfig`.
*
* @param queryConfig - Partial options to customize the QueryClient
* @returns A new QueryClient instance
*/
function createQueryClient(queryConfig) {
	return new QueryClient({
		...QueryClientConfig,
		...queryConfig
	});
}
/**
* Get the QueryClient instance for the current environment.
*
* On the server, if a custom getter has been set via `setServerQueryClientGetter`,
* it will be used to retrieve the QueryClient (typically from AsyncLocalStorage).
*
* On the browser (or if no server getter is set), returns a singleton QueryClient
* instance that is lazily created on first access.
*
* @returns The QueryClient instance for the current environment
*/
function getQueryClient() {
	if (serverQueryClientGetter) return serverQueryClientGetter();
	return browserQueryClient ??= createQueryClient();
}
/**
* Set a custom getter function for retrieving the QueryClient on the server.
*
* This allows server-side code to use AsyncLocalStorage or other request-scoped
* mechanisms to provide per-request QueryClient instances, ensuring data isolation
* between concurrent requests.
*
* @example
* ```ts
* // In server initialization
* setServerQueryClientGetter(() => getServerQueryClient())
* ```
*
* @param getter - A function that returns the QueryClient for the current request
*/
function setServerQueryClientGetter(getter) {
	serverQueryClientGetter = getter;
}
/**
* Resets the query client by clearing all cached queries.
* This should be called before or after server renders to ensure a clean state.
*/
function resetQueryClient() {
	getQueryClient().clear();
}
export { setServerQueryClientGetter as i, getQueryClient as n, resetQueryClient as r, createQueryClient as t };
