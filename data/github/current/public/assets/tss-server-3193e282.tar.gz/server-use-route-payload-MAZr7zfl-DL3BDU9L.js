import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { createContext, use } from "react";
var RouteStateMapContext = createContext({});
RouteStateMapContext.displayName = "RouteStateMapContext";
function useCurrentRouteState() {
	return use(RouteStateMapContext)[useLocation$1().key];
}
function useRoutePayload() {
	const state = useCurrentRouteState();
	return (state && state.type === "loaded" ? state.data : void 0)?.payload;
}
export { useRoutePayload as t };
