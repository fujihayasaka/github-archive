import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { c as Text$1, i as ButtonComponent, l as VisuallyHidden } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Hi as useProvidedRefOrCreate, a as AlertFillIcon, an as IconButton, pi as Tooltip$1 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import React, { forwardRef, useCallback, useEffect, useId, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isValidElementType } from "react-is";
var styles$3 = {
	"TextInputBaseWrapper": "prc-components-TextInputBaseWrapper-wY-n0",
	"TextInputWrapper": "prc-components-TextInputWrapper-Hpdqi"
};
var TextInputBaseWrapper = /* @__PURE__ */ React.forwardRef(function TextInputBaseWrapper(t0, forwardRef) {
	const $ = c(43);
	let block;
	let className;
	let contrast;
	let disabled;
	let hasTrailingAction;
	let isInputFocused;
	let maxWidth;
	let minWidth;
	let monospace;
	let restProps;
	let size;
	let style;
	let validationStatus;
	let variant;
	let width;
	if ($[0] !== t0) {
		({className, style, variant, size, isInputFocused, hasTrailingAction, validationStatus, disabled, contrast, monospace, block, width, minWidth, maxWidth, ...restProps} = t0);
		$[0] = t0;
		$[1] = block;
		$[2] = className;
		$[3] = contrast;
		$[4] = disabled;
		$[5] = hasTrailingAction;
		$[6] = isInputFocused;
		$[7] = maxWidth;
		$[8] = minWidth;
		$[9] = monospace;
		$[10] = restProps;
		$[11] = size;
		$[12] = style;
		$[13] = validationStatus;
		$[14] = variant;
		$[15] = width;
	} else {
		block = $[1];
		className = $[2];
		contrast = $[3];
		disabled = $[4];
		hasTrailingAction = $[5];
		isInputFocused = $[6];
		maxWidth = $[7];
		minWidth = $[8];
		monospace = $[9];
		restProps = $[10];
		size = $[11];
		style = $[12];
		validationStatus = $[13];
		variant = $[14];
		width = $[15];
	}
	let t1;
	if ($[16] !== width) {
		t1 = width ? { width } : {};
		$[16] = width;
		$[17] = t1;
	} else t1 = $[17];
	let t2;
	if ($[18] !== minWidth) {
		t2 = minWidth ? { minWidth } : {};
		$[18] = minWidth;
		$[19] = t2;
	} else t2 = $[19];
	let t3;
	if ($[20] !== maxWidth) {
		t3 = maxWidth ? { maxWidth } : {};
		$[20] = maxWidth;
		$[21] = t3;
	} else t3 = $[21];
	let t4;
	if ($[22] !== style || $[23] !== t1 || $[24] !== t2 || $[25] !== t3) {
		t4 = {
			...t1,
			...t2,
			...t3,
			...style
		};
		$[22] = style;
		$[23] = t1;
		$[24] = t2;
		$[25] = t3;
		$[26] = t4;
	} else t4 = $[26];
	const memoizedStyle = t4;
	let t5;
	if ($[27] !== className) {
		t5 = clsx(className, styles$3.TextInputBaseWrapper);
		$[27] = className;
		$[28] = t5;
	} else t5 = $[28];
	const t6 = block || void 0;
	const t7 = contrast || void 0;
	const t8 = disabled || void 0;
	const t9 = isInputFocused || void 0;
	const t10 = monospace || void 0;
	const t11 = size || void 0;
	const t12 = hasTrailingAction || void 0;
	const t13 = validationStatus || void 0;
	const t14 = variant || void 0;
	let t15;
	if ($[29] !== forwardRef || $[30] !== memoizedStyle || $[31] !== restProps || $[32] !== t10 || $[33] !== t11 || $[34] !== t12 || $[35] !== t13 || $[36] !== t14 || $[37] !== t5 || $[38] !== t6 || $[39] !== t7 || $[40] !== t8 || $[41] !== t9) {
		t15 = /* @__PURE__ */ jsx("span", {
			ref: forwardRef,
			className: t5,
			"data-block": t6,
			"data-contrast": t7,
			"data-disabled": t8,
			"data-focused": t9,
			"data-monospace": t10,
			"data-size": t11,
			"data-trailing-action": t12,
			"data-validation": t13,
			"data-variant": t14,
			style: memoizedStyle,
			...restProps
		});
		$[29] = forwardRef;
		$[30] = memoizedStyle;
		$[31] = restProps;
		$[32] = t10;
		$[33] = t11;
		$[34] = t12;
		$[35] = t13;
		$[36] = t14;
		$[37] = t5;
		$[38] = t6;
		$[39] = t7;
		$[40] = t8;
		$[41] = t9;
		$[42] = t15;
	} else t15 = $[42];
	return t15;
});
TextInputBaseWrapper.displayName = "TextInputBaseWrapper";
var TextInputWrapper = /* @__PURE__ */ React.forwardRef(function TextInputWrapper(t0, forwardRef) {
	const $ = c(13);
	let className;
	let hasLeadingVisual;
	let hasTrailingVisual;
	let restProps;
	if ($[0] !== t0) {
		({className, hasLeadingVisual, hasTrailingVisual, ...restProps} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = hasLeadingVisual;
		$[3] = hasTrailingVisual;
		$[4] = restProps;
	} else {
		className = $[1];
		hasLeadingVisual = $[2];
		hasTrailingVisual = $[3];
		restProps = $[4];
	}
	let t1;
	if ($[5] !== className) {
		t1 = clsx(className, styles$3.TextInputWrapper);
		$[5] = className;
		$[6] = t1;
	} else t1 = $[6];
	const t2 = hasLeadingVisual || void 0;
	const t3 = hasTrailingVisual || void 0;
	let t4;
	if ($[7] !== forwardRef || $[8] !== restProps || $[9] !== t1 || $[10] !== t2 || $[11] !== t3) {
		t4 = /* @__PURE__ */ jsx(TextInputBaseWrapper, {
			ref: forwardRef,
			className: t1,
			"data-leading-visual": t2,
			"data-trailing-visual": t3,
			...restProps
		});
		$[7] = forwardRef;
		$[8] = restProps;
		$[9] = t1;
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
});
var styles$2 = { "Input": "prc-components-Input-IwWrt" };
var UnstyledTextInput = /* @__PURE__ */ React.forwardRef(function UnstyledTextInput(t0, forwardRef) {
	const $ = c(9);
	let className;
	let rest;
	if ($[0] !== t0) {
		({className, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = rest;
	} else {
		className = $[1];
		rest = $[2];
	}
	let t1;
	if ($[3] !== className) {
		t1 = clsx(className, styles$2.Input);
		$[3] = className;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== forwardRef || $[6] !== rest || $[7] !== t1) {
		t2 = /* @__PURE__ */ jsx("input", {
			ref: forwardRef,
			...rest,
			className: t1
		});
		$[5] = forwardRef;
		$[6] = rest;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
});
UnstyledTextInput.displayName = "UnstyledTextInput";
var styles$1 = {
	"Spinner": "prc-components-Spinner-fIUBk",
	"SpinnerLeading": "prc-components-SpinnerLeading-phYLe",
	"SpinnerHidden": "prc-components-SpinnerHidden-mRxuj",
	"SpinnerVisible": "prc-components-SpinnerVisible-paqsj",
	"Box": "prc-components-Box-XRSqm"
};
var TextInputInnerVisualSlot = (t0) => {
	const $ = c(17);
	const { children, hasLoadingIndicator, showLoadingIndicator, visualPosition, id } = t0;
	const isLeading = visualPosition === "leading";
	if (!children && !hasLoadingIndicator || isLeading && !children && !showLoadingIndicator) return null;
	if (!hasLoadingIndicator) {
		let t1;
		if ($[0] !== children || $[1] !== id) {
			t1 = /* @__PURE__ */ jsx("span", {
				className: "TextInput-icon",
				id,
				"aria-hidden": "true",
				children
			});
			$[0] = children;
			$[1] = id;
			$[2] = t1;
		} else t1 = $[2];
		return t1;
	}
	let t1;
	if ($[3] !== children || $[4] !== showLoadingIndicator) {
		t1 = children && /* @__PURE__ */ jsx("div", {
			className: clsx(showLoadingIndicator ? styles$1.SpinnerHidden : styles$1.SpinnerVisible),
			children
		});
		$[3] = children;
		$[4] = showLoadingIndicator;
		$[5] = t1;
	} else t1 = $[5];
	const t2 = showLoadingIndicator ? styles$1.SpinnerVisible : styles$1.SpinnerHidden;
	const t3 = children && styles$1.Spinner;
	const t4 = children && isLeading && styles$1.SpinnerLeading;
	let t5;
	if ($[6] !== t2 || $[7] !== t3 || $[8] !== t4) {
		t5 = clsx(t2, t3, t4);
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else t5 = $[9];
	const t6 = children ? void 0 : "small";
	let t7;
	if ($[10] !== t5 || $[11] !== t6) {
		t7 = /* @__PURE__ */ jsx(Spinner, {
			srText: null,
			className: t5,
			size: t6
		});
		$[10] = t5;
		$[11] = t6;
		$[12] = t7;
	} else t7 = $[12];
	let t8;
	if ($[13] !== id || $[14] !== t1 || $[15] !== t7) {
		t8 = /* @__PURE__ */ jsx("span", {
			className: "TextInput-icon",
			children: /* @__PURE__ */ jsxs("div", {
				className: styles$1.Box,
				id,
				children: [t1, t7]
			})
		});
		$[13] = id;
		$[14] = t1;
		$[15] = t7;
		$[16] = t8;
	} else t8 = $[16];
	return t8;
};
/**
* Shared character counting functionality for text inputs with character limits.
* Handles real-time character count updates, validation, and aria-live announcements.
*/
var SCREEN_READER_DELAY = 500;
var CharacterCounter = class {
	announceTimeout = null;
	isInitialLoad = true;
	constructor(callbacks) {
		this.callbacks = callbacks;
	}
	/**
	* Update the character count based on current input value
	*/
	updateCharacterCount(currentLength, maxLength) {
		const charactersRemaining = maxLength - currentLength;
		let message = "";
		if (charactersRemaining >= 0) {
			message = `${charactersRemaining} ${charactersRemaining === 1 ? "character" : "characters"} remaining`;
			this.callbacks.onCountUpdate(charactersRemaining, false, message);
		} else {
			const charactersOver = -charactersRemaining;
			message = `${charactersOver} ${charactersOver === 1 ? "character" : "characters"} over`;
			this.callbacks.onCountUpdate(charactersOver, true, message);
		}
		if (!this.isInitialLoad) this.announceToScreenReader(message);
		if (this.isInitialLoad) this.isInitialLoad = false;
	}
	/**
	* Announce character count to screen readers with debouncing
	*/
	announceToScreenReader(message) {
		if (this.announceTimeout) clearTimeout(this.announceTimeout);
		if (typeof window === "undefined" || typeof window.setTimeout !== "function") return;
		this.announceTimeout = window.setTimeout(() => {
			this.callbacks.onScreenReaderAnnounce(message);
		}, SCREEN_READER_DELAY);
	}
	/**
	* Clean up any pending timeouts
	*/
	cleanup() {
		if (this.announceTimeout) clearTimeout(this.announceTimeout);
	}
};
var classes = {
	"CharacterCounter": "prc-TextInput-CharacterCounter-vJZBe",
	"CharacterCounter--error": "prc-TextInput-CharacterCounter--error-HA0kN"
};
var styles = {
	"Invisible": "prc-components-Invisible-bKOcl",
	"TextInputAction": "prc-components-TextInputAction-CjGDX",
	"ConditionalTooltip": "prc-components-ConditionalTooltip-1n0Zr"
};
var ConditionalTooltip = (t0) => {
	const $ = c(6);
	const { "aria-label": ariaLabel, children, tooltipDirection } = t0;
	let t1;
	if ($[0] !== ariaLabel || $[1] !== children || $[2] !== tooltipDirection) {
		t1 = ariaLabel ? /* @__PURE__ */ jsx(Tooltip$1, {
			text: ariaLabel,
			direction: tooltipDirection,
			className: styles.ConditionalTooltip,
			children
		}) : children;
		$[0] = ariaLabel;
		$[1] = children;
		$[2] = tooltipDirection;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== t1) {
		t2 = /* @__PURE__ */ jsx(Fragment$1, { children: t1 });
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
};
var TextInputAction = /* @__PURE__ */ forwardRef((t0, forwardedRef) => {
	const $ = c(28);
	let ariaLabel;
	let ariaLabelledBy;
	let children;
	let className;
	let icon;
	let rest;
	let t1;
	let tooltipDirection;
	if ($[0] !== t0) {
		({"aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, tooltipDirection, children, icon, className, variant: t1, ...rest} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = ariaLabelledBy;
		$[3] = children;
		$[4] = className;
		$[5] = icon;
		$[6] = rest;
		$[7] = t1;
		$[8] = tooltipDirection;
	} else {
		ariaLabel = $[1];
		ariaLabelledBy = $[2];
		children = $[3];
		className = $[4];
		icon = $[5];
		rest = $[6];
		t1 = $[7];
		tooltipDirection = $[8];
	}
	const variant = t1 === void 0 ? "invisible" : t1;
	const t2 = variant === "invisible" && styles.Invisible;
	let t3;
	if ($[9] !== className || $[10] !== t2) {
		t3 = clsx(t2, className);
		$[9] = className;
		$[10] = t2;
		$[11] = t3;
	} else t3 = $[11];
	let t4;
	if ($[12] !== t3) {
		t4 = { className: t3 };
		$[12] = t3;
		$[13] = t4;
	} else t4 = $[13];
	const styleProps = t4;
	if (icon && !ariaLabel || !children && !ariaLabel) console.warn("Use the `aria-label` prop to provide an accessible label for assistive technology");
	let t5;
	if ($[14] !== ariaLabel || $[15] !== ariaLabelledBy) {
		t5 = ariaLabel ? { "aria-label": ariaLabel } : ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": "" };
		$[14] = ariaLabel;
		$[15] = ariaLabelledBy;
		$[16] = t5;
	} else t5 = $[16];
	const accessibleLabel = t5;
	let t6;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = clsx("TextInput-action", styles.TextInputAction);
		$[17] = t6;
	} else t6 = $[17];
	let t7;
	if ($[18] !== accessibleLabel || $[19] !== ariaLabel || $[20] !== children || $[21] !== forwardedRef || $[22] !== icon || $[23] !== rest || $[24] !== styleProps || $[25] !== tooltipDirection || $[26] !== variant) {
		var _tooltipDirection;
		t7 = /* @__PURE__ */ jsx("span", {
			className: t6,
			children: icon && !children && ariaLabel ? /* @__PURE__ */ jsx(IconButton, {
				...accessibleLabel,
				tooltipDirection: (_tooltipDirection = tooltipDirection) !== null && _tooltipDirection !== void 0 ? _tooltipDirection : "s",
				variant,
				type: "button",
				icon,
				size: "small",
				...styleProps,
				...rest,
				ref: forwardedRef
			}) : /* @__PURE__ */ jsx(ConditionalTooltip, {
				"aria-label": ariaLabel,
				children: /* @__PURE__ */ jsx(ButtonComponent, {
					variant,
					type: "button",
					...styleProps,
					...rest,
					ref: forwardedRef,
					children
				})
			})
		});
		$[18] = accessibleLabel;
		$[19] = ariaLabel;
		$[20] = children;
		$[21] = forwardedRef;
		$[22] = icon;
		$[23] = rest;
		$[24] = styleProps;
		$[25] = tooltipDirection;
		$[26] = variant;
		$[27] = t7;
	} else t7 = $[27];
	return t7;
});
var TextInput = /* @__PURE__ */ React.forwardRef(({ icon: IconComponent, leadingVisual: LeadingVisual, trailingVisual: TrailingVisual, trailingAction, block, className, contrast, disabled, loading, loaderPosition = "auto", loaderText = "Loading", monospace, validationStatus, size: sizeProp, onFocus, onBlur, variant: variantProp, width: widthProp, minWidth: minWidthProp, maxWidth: maxWidthProp, type = "text", required, characterLimit, onChange, value, defaultValue, ...inputProps }, ref) => {
	const [isInputFocused, setIsInputFocused] = useState(false);
	const inputRef = useProvidedRefOrCreate(ref);
	const [characterCount, setCharacterCount] = useState("");
	const [isOverLimit, setIsOverLimit] = useState(false);
	const [screenReaderMessage, setScreenReaderMessage] = useState("");
	const characterCounterRef = useRef(null);
	const lastCountedLengthRef = useRef(null);
	const lastCharacterCountRef = useRef("");
	const lastIsOverLimitRef = useRef(false);
	const lastScreenReaderMessageRef = useRef("");
	const wrapperClasses = clsx(className, "TextInput-wrapper");
	const showLeadingLoadingIndicator = loading && (loaderPosition === "leading" || Boolean(LeadingVisual && loaderPosition !== "trailing"));
	const showTrailingLoadingIndicator = loading && (loaderPosition === "trailing" || Boolean(loaderPosition === "auto" && !LeadingVisual));
	const isSegmentedInputType = type === "date" || type === "time" || type === "datetime-local";
	const focusInput = (e) => {
		if (e.target !== inputRef.current || !isSegmentedInputType) {
			var _inputRef$current;
			(_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 || _inputRef$current.focus();
		}
	};
	const leadingVisualId = useId();
	const trailingVisualId = useId();
	const loadingId = useId();
	const inputDescribedBy = clsx(inputProps["aria-describedby"], LeadingVisual && leadingVisualId, TrailingVisual && trailingVisualId, loading && loadingId) || void 0;
	const handleInputFocus = useCallback((e_0) => {
		setIsInputFocused(true);
		onFocus && onFocus(e_0);
	}, [onFocus]);
	const handleInputBlur = useCallback((e_1) => {
		setIsInputFocused(false);
		onBlur && onBlur(e_1);
	}, [onBlur]);
	useEffect(() => {
		if (characterLimit) {
			characterCounterRef.current = new CharacterCounter({
				onCountUpdate: (count, overLimit, message) => {
					if (message !== lastCharacterCountRef.current) {
						lastCharacterCountRef.current = message;
						setCharacterCount(message);
					}
					if (overLimit !== lastIsOverLimitRef.current) {
						lastIsOverLimitRef.current = overLimit;
						setIsOverLimit(overLimit);
					}
				},
				onScreenReaderAnnounce: (message_0) => {
					if (message_0 !== lastScreenReaderMessageRef.current) {
						lastScreenReaderMessageRef.current = message_0;
						setScreenReaderMessage(message_0);
					}
				}
			});
			lastCountedLengthRef.current = null;
			return () => {
				var _characterCounterRef$;
				(_characterCounterRef$ = characterCounterRef.current) === null || _characterCounterRef$ === void 0 || _characterCounterRef$.cleanup();
				characterCounterRef.current = null;
				lastCountedLengthRef.current = null;
				lastCharacterCountRef.current = "";
				lastIsOverLimitRef.current = false;
				lastScreenReaderMessageRef.current = "";
			};
		}
	}, [characterLimit]);
	useEffect(() => {
		if (characterLimit && characterCounterRef.current) {
			const currentLength = (value !== void 0 ? String(value) : defaultValue !== void 0 ? String(defaultValue) : "").length;
			if (currentLength !== lastCountedLengthRef.current) {
				lastCountedLengthRef.current = currentLength;
				characterCounterRef.current.updateCharacterCount(currentLength, characterLimit);
			}
		}
	}, [
		value,
		defaultValue,
		characterLimit
	]);
	const handleInputChange = useCallback((e_2) => {
		if (characterLimit && characterCounterRef.current) {
			const currentLength_0 = e_2.target.value.length;
			if (currentLength_0 !== lastCountedLengthRef.current) {
				lastCountedLengthRef.current = currentLength_0;
				characterCounterRef.current.updateCharacterCount(currentLength_0, characterLimit);
			}
		}
		onChange === null || onChange === void 0 || onChange(e_2);
	}, [onChange, characterLimit]);
	const characterCountId = useId();
	const characterCountStaticMessageId = useId();
	const isValid = isOverLimit ? "error" : validationStatus;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(TextInputWrapper, {
		block,
		className: wrapperClasses,
		validationStatus: isValid,
		contrast,
		disabled,
		monospace,
		size: sizeProp,
		width: widthProp,
		minWidth: minWidthProp,
		maxWidth: maxWidthProp,
		variant: variantProp,
		hasLeadingVisual: Boolean(LeadingVisual || showLeadingLoadingIndicator),
		hasTrailingVisual: Boolean(TrailingVisual || showTrailingLoadingIndicator),
		hasTrailingAction: Boolean(trailingAction),
		isInputFocused,
		onClick: focusInput,
		"aria-busy": Boolean(loading),
		children: [
			IconComponent && /* @__PURE__ */ jsx(IconComponent, { className: "TextInput-icon" }),
			/* @__PURE__ */ jsx(TextInputInnerVisualSlot, {
				visualPosition: "leading",
				showLoadingIndicator: showLeadingLoadingIndicator,
				hasLoadingIndicator: typeof loading === "boolean",
				id: leadingVisualId,
				children: typeof LeadingVisual !== "string" && isValidElementType(LeadingVisual) ? /* @__PURE__ */ jsx(LeadingVisual, {}) : LeadingVisual
			}),
			/* @__PURE__ */ jsx(UnstyledTextInput, {
				ref: inputRef,
				disabled,
				onFocus: handleInputFocus,
				onBlur: handleInputBlur,
				onChange: handleInputChange,
				type,
				"aria-required": required,
				"aria-invalid": isValid === "error" ? "true" : void 0,
				value,
				defaultValue,
				...inputProps,
				"aria-describedby": characterLimit ? [characterCountStaticMessageId, inputDescribedBy].filter(Boolean).join(" ") || void 0 : inputDescribedBy,
				"data-component": "input"
			}),
			loading && /* @__PURE__ */ jsx(VisuallyHidden, {
				id: loadingId,
				children: loaderText
			}),
			/* @__PURE__ */ jsx(TextInputInnerVisualSlot, {
				visualPosition: "trailing",
				showLoadingIndicator: showTrailingLoadingIndicator,
				hasLoadingIndicator: typeof loading === "boolean",
				id: trailingVisualId,
				"data-testid": "text-input-trailing-visual",
				children: typeof TrailingVisual !== "string" && isValidElementType(TrailingVisual) ? /* @__PURE__ */ jsx(TrailingVisual, {}) : TrailingVisual
			}),
			trailingAction
		]
	}), characterLimit && /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(VisuallyHidden, {
			"aria-live": "polite",
			role: "status",
			children: screenReaderMessage
		}),
		/* @__PURE__ */ jsxs(VisuallyHidden, {
			id: characterCountStaticMessageId,
			children: [
				"You can enter up to ",
				characterLimit,
				" ",
				characterLimit === 1 ? "character" : "characters"
			]
		}),
		/* @__PURE__ */ jsxs(Text$1, {
			"aria-hidden": "true",
			id: characterCountId,
			size: "small",
			className: clsx(classes.CharacterCounter, isOverLimit && classes["CharacterCounter--error"]),
			children: [isOverLimit && /* @__PURE__ */ jsx(AlertFillIcon, { size: 16 }), characterCount]
		})
	] })] });
});
TextInput.displayName = "TextInput";
var TextInput$1 = Object.assign(TextInput, {
	__SLOT__: Symbol("TextInput"),
	Action: TextInputAction
});
export { TextInputWrapper as a, TextInputInnerVisualSlot as i, TextInput$1 as n, UnstyledTextInput as o, TextInputBaseWrapper as r, CharacterCounter as t };
