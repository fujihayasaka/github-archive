import { ot as useIsCursorEnabled } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { createContext, use, useCallback, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* Context for search term state.
* Split from dispatch context to prevent re-renders when only reading state.
*/
var SearchTermStateContext = createContext("");
/**
* Context for search term dispatch function.
* Split from state context to prevent re-renders when only setting state.
*/
SearchTermStateContext.displayName = "SearchTermStateContext";
var SearchTermDispatchContext = createContext(() => void 0);
/**
* Provider for search term state and dispatch.
* Uses split contexts to optimize re-renders:
* - Components that only read searchTerm won't re-render when setSearchTerm changes
* - Components that only call setSearchTerm won't re-render when searchTerm changes
*/
SearchTermDispatchContext.displayName = "SearchTermDispatchContext";
function SearchTermProvider(t0) {
	const $ = c(3);
	const { children } = t0;
	const [searchTerm, setSearchTerm] = useState("");
	let t1;
	if ($[0] !== children || $[1] !== searchTerm) {
		t1 = jsx(SearchTermStateContext, {
			value: searchTerm,
			children: jsx(SearchTermDispatchContext, {
				value: setSearchTerm,
				children
			})
		});
		$[0] = children;
		$[1] = searchTerm;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
/**
* Hook to read the current search term.
* Only re-renders when searchTerm changes.
*/
SearchTermProvider.displayName = "SearchTermProvider";
function useSearchTerm() {
	return use(SearchTermStateContext);
}
/**
* Hook to get the setSearchTerm function.
* Never re-renders due to search term changes.
*/
function useSetSearchTerm() {
	return use(SearchTermDispatchContext);
}
var FindInFileOpenContext = createContext({
	findInFileOpen: false,
	setFindInFileOpen: () => void 0,
	searchTerm: "",
	setSearchTerm: () => void 0
});
/**
* This is equivalent to a simple setState, except we save the search state of the find in file panel when it's closed
* so we can reopen with the last used value
*/
FindInFileOpenContext.displayName = "FindInFileOpenContext";
function FindInFileOpenProvider({ children, isBlame }) {
	const searchTerm = useSearchTerm();
	const setSearchTerm = useSetSearchTerm();
	const cursorEnabled = useIsCursorEnabled(isBlame);
	const lastSearchTerm = useRef("");
	const [findInFileOpen, setRawFindInFileOpen] = useState(false);
	const setFindInFileOpen = useCallback((open) => {
		if (open && searchTerm === "" && lastSearchTerm.current !== "") setSearchTerm(lastSearchTerm.current);
		else if (!open && searchTerm !== "") {
			lastSearchTerm.current = searchTerm;
			setSearchTerm("");
		}
		setRawFindInFileOpen(open);
	}, [searchTerm, setSearchTerm]);
	return /* @__PURE__ */ jsx(FindInFileOpenContext, {
		value: useMemo(() => {
			return {
				findInFileOpen: cursorEnabled ? false : findInFileOpen,
				setFindInFileOpen,
				setSearchTerm,
				searchTerm
			};
		}, [
			findInFileOpen,
			setFindInFileOpen,
			searchTerm,
			setSearchTerm,
			cursorEnabled
		]),
		children
	});
}
FindInFileOpenProvider.displayName = "FindInFileOpenProvider";
function useFindInFileOpen() {
	return use(FindInFileOpenContext);
}
export { useSetSearchTerm as a, useSearchTerm as i, SearchTermProvider as n, useFindInFileOpen as r, FindInFileOpenProvider as t };
