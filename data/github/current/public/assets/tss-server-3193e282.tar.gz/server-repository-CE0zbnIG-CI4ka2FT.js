import { d as businessOrgsSuggestionsValidatePath, u as businessOrgsSuggestionsPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import { t as fuzzyFilter } from "./server-fuzzy-filter-WZcmODdB-CGCfWix3.js";
import { $ as isFilterBlock, K as getHasValueSuggestion, M as defaultFilterProviderOptions, O as capitalize, P as escapeString, Q as isEmptyFilterBlockValue, T as ValidationTypes, U as getFilterValue, V as getExcludeKeySuggestion, X as getUnescapedFilterValue, Y as getNoValueSuggestion, b as Strings, c as FilterProviderType, d as FilterValueType, i as FILTER_KEYS, n as BlockType, nt as isMutableFilterBlock, ot as shouldProviderShowSuggestions, q as getLastFilterBlockValue, t as AvatarType, z as getDefaultValueVisualDescriptors } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
var RootFilterProvider = class {
	key;
	aliases;
	displayName;
	description;
	priority;
	type;
	icon;
	options;
	constructor(filterKey, options) {
		Object.assign(this, filterKey);
		this.key = filterKey.key;
		this.icon = filterKey.icon;
		this.type = FilterProviderType.Text;
		this.displayName = filterKey.displayName ?? capitalize(filterKey.key);
		this.options = {
			...defaultFilterProviderOptions,
			priority: filterKey.priority,
			...options,
			filterTypes: {
				...defaultFilterProviderOptions.filterTypes,
				...options?.filterTypes
			}
		};
		this.priority = this.options.priority;
	}
	shouldGetSuggestions(filterBlock) {
		return filterBlock && filterBlock.type !== BlockType.Space && shouldProviderShowSuggestions(filterBlock, this.options.filterTypes.multiValue);
	}
	allowsFilterValues() {
		return this.options.filterTypes.inclusive !== false || this.options.filterTypes.exclusive !== false;
	}
};
var ValueValidator = class extends RootFilterProvider {
	validateValue(filterQuery, value, data) {
		if (!data) return false;
		return data;
	}
};
var SsoRequiredError = class extends Error {
	organization;
	ssoUrl;
	constructor(organization, ssoUrl) {
		super(`SSO required for ${organization}`);
		this.name = "SsoRequiredError";
		this.organization = organization;
		this.ssoUrl = ssoUrl;
	}
};
var ValidationAbortController = class extends AbortController {
	#rawQuery;
	constructor(rawQuery) {
		super();
		this.#rawQuery = rawQuery;
	}
	abortIfChanged(rawQuery) {
		if (rawQuery === void 0 || rawQuery !== this.#rawQuery) this.abort();
	}
};
var AsyncFilterProvider = class extends ValueValidator {
	suggestionCache;
	validationCache;
	prefetchedSuggestions;
	completeResultSetQueries;
	providerContext;
	suggestionEndpoint;
	validationEndpoint;
	abortSuggestionsController;
	abortValidationController;
	valueValidator;
	constructor(filterKey, options) {
		super(filterKey, options);
		this.suggestionEndpoint = "";
		this.validationEndpoint = "";
		this.suggestionCache = /* @__PURE__ */ new Map();
		this.completeResultSetQueries = /* @__PURE__ */ new Set();
		this.validationCache = /* @__PURE__ */ new Map();
		this.abortSuggestionsController = new AbortController();
		this.abortValidationController = new ValidationAbortController();
		this.prefetchedSuggestions = /* @__PURE__ */ new Map();
	}
	abortPreviousSuggestionsRequests() {
		this.abortSuggestionsController.abort();
		this.abortSuggestionsController = new AbortController();
	}
	abortPreviousValidationRequests(filterQuery) {
		this.abortValidationController.abortIfChanged(filterQuery?.raw);
		this.abortValidationController = new ValidationAbortController(filterQuery?.raw);
	}
	getFilterValue(filterBlock, filterValue) {
		if (filterValue) return filterValue;
		return getFilterValue(isMutableFilterBlock(filterBlock) ? getFilterValue(filterBlock.value?.values.at(-1)?.value) : filterBlock.raw) ?? "";
	}
	getMetaSuggestions(value) {
		if (!value) return [];
		return [];
	}
	async processSuggestions(filterQuery, filterBlock, processSuggestion, caretIndex) {
		if (!this.shouldGetSuggestions(filterBlock)) return null;
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		this.abortPreviousSuggestionsRequests();
		const instanceAbortController = this.abortSuggestionsController;
		const filterProviderKey = filterBlock.provider.key;
		const suggestions = [];
		const noValueSuggestion = getNoValueSuggestion(this.displayName, this.icon);
		const hasValueSuggestion = getHasValueSuggestion(this.displayName, this.icon);
		const excludeKeySuggestion = getExcludeKeySuggestion(filterProviderKey);
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.valueless && !filterBlock.raw.startsWith("-")) suggestions.push(noValueSuggestion);
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.hasValue && !filterBlock.raw.startsWith("-")) suggestions.push(hasValueSuggestion);
		if (this.options.filterTypes.exclusive && lastValue === "" && isFilterBlock(filterBlock) && filterBlock.raw !== `-${filterProviderKey}:`) suggestions.unshift(excludeKeySuggestion);
		let processedSuggestions = suggestions;
		if (this.allowsFilterValues()) {
			const items = await this.fetchSuggestions(lastValue, filterBlock, filterQuery) ?? [];
			processedSuggestions = [...suggestions, ...[...items].map((item) => processSuggestion(item, lastValue, filterQuery))];
			for (const suggestion of processedSuggestions) {
				if ([
					noValueSuggestion,
					hasValueSuggestion,
					excludeKeySuggestion
				].includes(suggestion)) continue;
				this.prefetchedSuggestions.set(suggestion.value, suggestion);
			}
			if (instanceAbortController.signal.aborted) return null;
		}
		return processedSuggestions;
	}
	async validateFilterBlockValues(filterQuery, block, values) {
		const valuesIndex = {};
		const validations = values.map(async (v, i) => {
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			const prevIndex = values.findIndex((vi) => getUnescapedFilterValue(vi.value) === extractedValue);
			if (!extractedValue || prevIndex < i && prevIndex >= 0) {
				valuesIndex[i] = {
					...v,
					valid: false,
					validations: [{
						type: ValidationTypes.EmptyValue,
						message: Strings.filterValueEmpty(this.key)
					}]
				};
				return;
			}
			const prefetchedValue = this.prefetchedSuggestions.get(extractedValue);
			const metaSuggestion = this.getMetaSuggestions(extractedValue)?.[0];
			if (prefetchedValue) {
				valuesIndex[i] = {
					...v,
					...prefetchedValue,
					valid: true,
					value: v.value
				};
				return;
			} else if (metaSuggestion?.value === extractedValue) {
				valuesIndex[i] = {
					...v,
					...metaSuggestion,
					valid: true,
					value: v.value
				};
				return;
			} else if (filterQuery.activeBlockId !== block.id) {
				const queryValue = this.getFilterValue({
					id: 1,
					type: BlockType.Filter,
					raw: `${this.key}:`,
					value: {
						raw: extractedValue,
						values: [{ value: extractedValue }]
					}
				}, extractedValue);
				const data = await this.validateFilterValue(queryValue, filterQuery.contextURLParams, filterQuery);
				if (data instanceof Error) if (data instanceof SsoRequiredError) {
					valuesIndex[i] = {
						...v,
						valid: false,
						validations: [{
							type: ValidationTypes.SsoRequired,
							message: Strings.filterSsoRequired(this.key, extractedValue, data.organization)
						}],
						ssoUrl: data.ssoUrl
					};
					return;
				} else if (data.message === "Aborted") valuesIndex[i] = {
					...v,
					valid: void 0,
					value: v.value
				};
				else valuesIndex[i] = {
					...v,
					valid: false
				};
				else {
					const validatedData = this.validateValue?.(filterQuery, v, data);
					if (validatedData) if (validatedData.value === "#INDETERMINANT#") valuesIndex[i] = {
						...v,
						valid: true,
						value: v.value
					};
					else valuesIndex[i] = {
						...v,
						valid: true,
						...validatedData,
						value: v.value
					};
					else valuesIndex[i] = {
						...v,
						valid: false,
						validations: [{
							type: ValidationTypes.InvalidValue,
							message: Strings.filterInvalidValue(this.key, extractedValue)
						}]
					};
					return v;
				}
			}
			valuesIndex[i] = {
				...v,
				valid: void 0
			};
		});
		await Promise.all(validations);
		return Object.values(valuesIndex);
	}
	async fetchSuggestions(value, block, filterQuery) {
		try {
			if (this.suggestionCache.has(value)) return this.suggestionCache.get(value) ?? [];
			if (!this.suggestionEndpoint || this.suggestionEndpoint === "") throw new Error("No suggestion endpoint provided");
			const endpoint = new URL(this.suggestionEndpoint, window.location.origin);
			const fetchParams = filterQuery.contextURLParams;
			const params = new URLSearchParams([fetchParams?.toString(), this.providerContext?.toString()].join("&"));
			params.set("q", value);
			params.set("filter_value", value);
			endpoint.search = params.toString();
			const response = await this.fetchData(endpoint.toString());
			if (!response || !response.ok) return null;
			const json = await response.json();
			const dataKey = Object.keys(json)[0];
			const suggestions = dataKey ? json[dataKey] : null;
			if (Array.isArray(suggestions) && suggestions.length < 25) this.completeResultSetQueries.add(value);
			if (!suggestions) return null;
			this.suggestionCache.set(value, suggestions);
			return suggestions;
		} catch {
			return null;
		}
	}
	isCompleteResultSetQuery(value) {
		if (!value) return false;
		return Array.from(this.completeResultSetQueries).findIndex((completedQuery) => completedQuery === "" ? completedQuery === value : value.startsWith(completedQuery)) !== -1;
	}
	rankSuggestion(query, suggestion, _) {
		return {
			...suggestion,
			priority: suggestion.priority ?? 3
		};
	}
	findPrefetchedSuggestions(value) {
		if (!value) return [];
		const suggestions = fuzzyFilter({
			items: [...this.prefetchedSuggestions.values()],
			filter: value,
			key: (suggestion) => getFilterValue(suggestion.value) ?? "",
			secondaryKey: (suggestion) => suggestion.displayName ?? suggestion.description ?? ""
		}).map((suggestion) => this.rankSuggestion(value, suggestion, {})).sort((a, b) => b.priority - a.priority).slice(0, 25);
		suggestions.push(...this.getMetaSuggestions(value));
		return suggestions;
	}
	async validateFilterValue(value, fetchParams, filterQuery) {
		try {
			if (this.validationCache.has(value)) return this.validationCache.get(value) ?? null;
			if (!this.validationEndpoint || this.validationEndpoint === "") throw new Error("No validation endpoint provided");
			const endpoint = new URL(this.validationEndpoint, window.location.origin);
			const params = new URLSearchParams([fetchParams?.toString(), this.providerContext?.toString()].join("&"));
			params.set("q", value);
			params.set("filter_value", value);
			endpoint.search = params.toString();
			this.abortPreviousValidationRequests(filterQuery);
			const response = await this.fetchData(endpoint.toString(), this.abortValidationController);
			if (!response) return /* @__PURE__ */ new Error("Aborted");
			if (!response.ok) {
				if (response.status === 401) try {
					const errorBody = await response.json();
					if (errorBody.error === "sso_required") return new SsoRequiredError(errorBody.organization ?? errorBody.enterprise ?? "", errorBody["sso_url"] ?? "");
				} catch {}
				return null;
			}
			const json = await response.json();
			const keys = Object.keys(json);
			let validationData;
			if (keys.length === 1 && keys[0] && Array.isArray(json[keys[0]])) validationData = Array.isArray(json[keys[0]]) ? json[keys[0]][0] : json[keys[0]];
			else validationData = json;
			if (!validationData) return null;
			this.validationCache.set(value, validationData);
			return validationData;
		} catch {
			return null;
		}
	}
	async fetchData(apiURL, abortController) {
		let response;
		try {
			response = await fetch(apiURL, {
				method: "GET",
				mode: "same-origin",
				headers: {
					Accept: "application/json",
					"Content-Type": "application/json"
				},
				signal: abortController?.signal
			});
		} catch (error) {
			if (error.name !== "AbortError") throw error;
		}
		return response;
	}
};
var ORG_SUGGESTION_ENDPOINT = "/_filter/organizations";
var ORG_VALIDATION_ENDPOINT = "/_filter/organizations/validate";
var OrgFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.org, options);
		const businessSlug = options?.businessSlug;
		this.suggestionEndpoint = businessSlug ? businessOrgsSuggestionsPath({ businessSlug }) : ORG_SUGGESTION_ENDPOINT;
		this.validationEndpoint = businessSlug ? businessOrgsSuggestionsValidatePath({ businessSlug }) : ORG_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	rankSuggestion(query, suggestion) {
		const { displayName: name, description: login } = suggestion;
		let priority = 3;
		if (query) {
			if (name) priority -= fuzzyScore(query, name);
			if (login) priority -= fuzzyScore(query, login);
		}
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(org, query) {
		const { name, login, avatarUrl } = org;
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: name,
			ariaLabel: `${name}, ${this.displayName}`,
			value: escapeString(login) ?? "",
			description: login,
			inlineDescription: true,
			icon: !avatarUrl ? this.icon : void 0,
			avatar: avatarUrl ? {
				url: avatarUrl,
				type: AvatarType.Org
			} : void 0
		});
	}
	validateValue(filterQuery, value, org) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!org || !extractedValue) return false;
		return {
			avatar: org.avatarUrl ? {
				url: org.avatarUrl,
				type: AvatarType.Org
			} : void 0,
			value: extractedValue,
			displayName: org.name
		};
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon, true)
		};
	}
};
var REPOSITORY_SUGGESTION_ENDPOINT = "/_filter/repositories";
var REPOSITORY_VALIDATION_ENDPOINT = "/_filter/repositories/validate";
var RepositoryFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.repo, options);
		this.suggestionEndpoint = REPOSITORY_SUGGESTION_ENDPOINT;
		this.validationEndpoint = REPOSITORY_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	rankSuggestion(query, suggestion) {
		const { displayName: nameWithOwner } = suggestion;
		let priority = 3;
		if (query) {
			if (nameWithOwner) priority -= fuzzyScore(query, nameWithOwner);
		}
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(repo, query) {
		const { nameWithOwner } = repo;
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: nameWithOwner,
			ariaLabel: `${nameWithOwner}, ${this.displayName}`,
			value: nameWithOwner,
			inlineDescription: false,
			icon: this.icon
		});
	}
	validateValue(filterQuery, value, repo) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!repo || !extractedValue) return false;
		return {
			displayName: repo.name,
			value: extractedValue
		};
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon, true)
		};
	}
};
export { RootFilterProvider as i, OrgFilterProvider as n, RepositoryFilterProvider as r, AsyncFilterProvider as t };
