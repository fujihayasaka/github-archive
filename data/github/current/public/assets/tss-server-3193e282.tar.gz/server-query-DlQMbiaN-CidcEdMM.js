import { Br as SortDescIcon, Sr as RowsIcon, _n as KebabHorizontalIcon, an as IconButton, ci as ThreeBarsIcon, n as ActionList, zr as SortAscIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as announceFromElement$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as ActionBar } from "./server-drag-and-drop-ekoR4DH7-Bqpb-P1q.js";
import { _ as useListViewVariant, g as useListViewTitle, h as useListViewSelection, m as useListViewMultiPageSelection, p as useListViewId, v as useNextHeaderTag } from "./server-MainContent-ouZQ_bM_-DHVoK7D7.js";
import { isValidElement, startTransition, useCallback, useEffect, useId, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var SortingDropdown_module_default = { sortDropdownButton: "SortingDropdown-module_JuboUa_sortDropdownButton" };
var ASCENDING_SUFFIX = "-asc";
var DESCENDING_SUFFIX = "-desc";
function getSortingOptionLabel(sortingKey, sortingOptions) {
	return sortingOptions[sortingKey]?.label || sortingKey;
}
function getSortingKeyAndDirection(sorting, defaultSortingKey) {
	return splitOrderDirection(sorting || defaultSortingKey);
}
function splitOrderDirection(value) {
	if (value.endsWith(DESCENDING_SUFFIX)) return [value.substring(0, value.length - 5), "desc"];
	if (value.endsWith(ASCENDING_SUFFIX)) return [value.substring(0, value.length - 4), "asc"];
	return [value, ""];
}
/**
* SortingDropdown component for selecting sorting options.
*
* This component allows users to choose a sorting option from a dropdown menu.
* It provides a visual indication of the current sorting state and allows users to change the sorting order.
* defaultSortingKey should exist as a key on the sortingOptions.
*/
function SortingDropdown(t0) {
	const $ = c(4);
	const { sortingItemSelected, onSortingItemSelect, defaultSortingKey, sortingOptions, directionRestrictedKeys, sortFieldsRequireDescSuffix } = t0;
	const [field, direction] = getSortingKeyAndDirection(sortingItemSelected, defaultSortingKey);
	const isAscending = direction === "asc";
	const orderIcon = isAscending ? SortAscIcon : SortDescIcon;
	const canSelectDirection = !directionRestrictedKeys?.includes(field);
	let t1;
	if ($[0] !== defaultSortingKey || $[1] !== onSortingItemSelect || $[2] !== sortFieldsRequireDescSuffix) {
		t1 = function select(newField, newDirection) {
			if (newDirection === "asc") onSortingItemSelect(`${newField}-asc`);
			else if (newField === defaultSortingKey) onSortingItemSelect("");
			else if (newDirection === "desc" && sortFieldsRequireDescSuffix) onSortingItemSelect(`${newField}-desc`);
			else onSortingItemSelect(newField);
		};
		$[0] = defaultSortingKey;
		$[1] = onSortingItemSelect;
		$[2] = sortFieldsRequireDescSuffix;
		$[3] = t1;
	} else t1 = $[3];
	const select = t1;
	const buttonLabel = getSortingOptionLabel(field, sortingOptions);
	const buttonAriaLabel = `Sort by ${buttonLabel} ${isAscending ? "ascending" : "descending"}`;
	const regularAnchor = jsx(ActionMenu.Button, {
		leadingVisual: orderIcon,
		variant: "invisible",
		"aria-label": buttonAriaLabel,
		className: SortingDropdown_module_default.sortDropdownButton,
		children: buttonLabel
	});
	return jsxs(ActionMenu, { children: [useResponsiveValue({
		narrow: jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
			icon: KebabHorizontalIcon,
			variant: "invisible",
			"aria-label": buttonAriaLabel
		}) }),
		regular: regularAnchor
	}, regularAnchor), jsx(ActionMenu.Overlay, { children: jsxs(ActionList, {
		selectionVariant: "single",
		children: [Object.entries(sortingOptions).map((t2) => {
			const [key, t3] = t2;
			const { label, defaultDirection, icon: FieldIcon } = t3;
			return jsxs(ActionList.Item, {
				selected: key === field,
				onSelect: () => select(key, defaultDirection),
				children: [FieldIcon && jsx(ActionList.LeadingVisual, { children: jsx(FieldIcon, {}) }), label]
			}, key);
		}), canSelectDirection && jsxs(Fragment$1, { children: [
			jsx(ActionList.Divider, {}),
			jsxs(ActionList.Item, {
				selected: isAscending,
				onSelect: () => select(field, "asc"),
				children: [jsx(ActionList.LeadingVisual, { children: jsx(SortAscIcon, {}) }), "Ascending"]
			}, "ascending"),
			jsxs(ActionList.Item, {
				selected: !isAscending,
				onSelect: () => select(field, "desc"),
				children: [jsx(ActionList.LeadingVisual, { children: jsx(SortDescIcon, {}) }), "Descending"]
			}, "descending")
		] })]
	}) })] });
}
SortingDropdown.displayName = "SortingDropdown";
var ListViewDensityToggle = (t0) => {
	const { localStorageVariantKey, onChange: externalOnChange, className, ...props } = t0;
	const { title } = useListViewTitle();
	const { variant, setVariant } = useListViewVariant();
	const { getItem, setItem } = safeStorage("localStorage");
	const handleDensityChange = (selectedIndex) => {
		if (localStorageVariantKey) setItem(localStorageVariantKey, selectedIndex.toString());
		startTransition(() => {
			setVariant(selectedIndex === 1 ? "compact" : "default");
			externalOnChange?.(selectedIndex);
		});
	};
	useEffect(() => {
		if (localStorageVariantKey) setVariant(getItem(localStorageVariantKey) === "1" ? "compact" : "default");
	}, [
		getItem,
		localStorageVariantKey,
		setVariant
	]);
	return jsxs(SegmentedControl, {
		className,
		...props,
		"aria-label": `${title} display density`,
		onChange: handleDensityChange,
		...testIdProps("density-toggle"),
		children: [jsx(SegmentedControl.IconButton, {
			"aria-label": "Comfortable display density",
			selected: variant === "default",
			icon: RowsIcon
		}), jsx(SegmentedControl.IconButton, {
			"aria-label": "Compact display density",
			selected: variant === "compact",
			icon: ThreeBarsIcon
		})]
	});
};
ListViewDensityToggle.displayName = "ListViewDensityToggle";
var density_gap_module_default = {
	condensed: "density-gap-module_S86WWW_condensed",
	none: "density-gap-module_S86WWW_none",
	normal: "density-gap-module_S86WWW_normal",
	spacious: "density-gap-module_S86WWW_spacious"
};
var ActionBar_module_default = { container: "ActionBar-module_56BbRa_container" };
var ListViewActionBar = ({ actions, style, className, children, density, actionsLabel, densityToggle, overflowMenuProps, overflowMenuToggleProps }) => {
	const nonCollapsibleActions = /* @__PURE__ */ jsxs(Fragment$1, { children: [children, densityToggle] });
	if (actions && actions.length > 0) return /* @__PURE__ */ jsx(ActionBar, {
		label: actionsLabel?.trim(),
		actions,
		density,
		overflowMenuProps,
		overflowMenuToggleProps,
		...testIdProps("list-view-actions"),
		style,
		className,
		children: nonCollapsibleActions
	});
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("list-view-actions"),
		style,
		className: clsx(ActionBar_module_default.container, density && density_gap_module_default[density], className),
		children: nonCollapsibleActions
	});
};
ListViewActionBar.displayName = "ListViewActionBar";
var Metadata_module_default = {
	container: "Metadata-module_MJCpwq_container",
	heading: "Metadata-module_MJCpwq_heading"
};
var SectionFilters_module_default = { container: "SectionFilters-module_dbXTSG_container" };
var ListViewSectionFilters = ({ links }) => {
	if (links.length < 1) return null;
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("list-view-section-filters"),
		children: /* @__PURE__ */ jsx("ul", {
			className: clsx("list-style-none", SectionFilters_module_default.container),
			children: links.map((sectionFilterLink, index) => /* @__PURE__ */ jsx("li", {
				...testIdProps(`list-view-section-filter-${index}`),
				children: sectionFilterLink
			}, `section-filter-${index}`))
		})
	});
};
ListViewSectionFilters.displayName = "ListViewSectionFilters";
var SelectAllCheckbox_module_default = {
	container: "SelectAllCheckbox-module_mdAidG_container",
	count: "SelectAllCheckbox-module_mdAidG_count",
	formControlContainer: "SelectAllCheckbox-module_mdAidG_formControlContainer"
};
var ListViewSelectAllCheckbox = ({ onToggle, style, className }) => {
	const { title } = useListViewTitle();
	const { isSelectable, selectedCount, totalCount, countOnPage, isSelectAllChecked, anyItemsSelected, singularUnits, pluralUnits } = useListViewSelection();
	const { multiPageSelectionAllowed } = useListViewMultiPageSelection();
	const idPrefix = useId();
	const checkboxRef = useRef(null);
	const srRef = useRef(null);
	const notAllItemsSelected = useMemo(() => {
		if (multiPageSelectionAllowed && typeof totalCount === "number") return selectedCount < Math.max(totalCount, countOnPage);
		return selectedCount < countOnPage;
	}, [
		countOnPage,
		multiPageSelectionAllowed,
		selectedCount,
		totalCount
	]);
	const isIndeterminate = anyItemsSelected && notAllItemsSelected;
	const units = selectedCount === 1 ? singularUnits : pluralUnits;
	const suffix = typeof totalCount === "number" ? `of ${totalCount} selected` : "selected";
	const srString = `${selectedCount} ${units} ${suffix}`;
	const handleBulkSelectToggle = useCallback(() => {
		if (!onToggle) return;
		if (isIndeterminate) onToggle(false);
		else onToggle(!isSelectAllChecked);
	}, [
		isIndeterminate,
		isSelectAllChecked,
		onToggle
	]);
	useEffect(() => {
		if (srRef.current) announceFromElement$1(srRef.current);
	}, [srRef, srString]);
	if (!isSelectable) return null;
	const checkboxId = `${idPrefix}-list-view-select-all`;
	const onKeyDown = (event) => {
		if (event.key === "Enter" || event.key === " ") {
			event.preventDefault();
			handleBulkSelectToggle();
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		style,
		className: clsx(SelectAllCheckbox_module_default.container, className),
		...testIdProps("list-view-select-all-container"),
		id: `${idPrefix}-list-view-select-all-container`,
		children: [/* @__PURE__ */ jsx("div", {
			className: SelectAllCheckbox_module_default.formControlContainer,
			children: /* @__PURE__ */ jsxs(FormControl$1, {
				id: checkboxId,
				children: [/* @__PURE__ */ jsx(Checkbox, {
					onChange: handleBulkSelectToggle,
					value: "default",
					checked: isSelectAllChecked,
					indeterminate: isIndeterminate,
					onKeyDown,
					tabIndex: 0,
					ref: checkboxRef,
					...testIdProps("select-all-checkbox")
				}), /* @__PURE__ */ jsxs(FormControl$1.Label, {
					visuallyHidden: true,
					...testIdProps("select-all-label"),
					children: [
						"Select all ",
						pluralUnits,
						": ",
						title
					]
				})]
			})
		}), /* @__PURE__ */ jsxs("p", {
			className: clsx(SelectAllCheckbox_module_default.count, anyItemsSelected ? void 0 : "sr-only"),
			...testIdProps("select-all-selected-count"),
			children: [/* @__PURE__ */ jsxs("span", {
				"aria-hidden": "true",
				className: anyItemsSelected ? void 0 : "sr-only",
				...testIdProps("select-all-selected-count-without-units"),
				children: [
					selectedCount,
					" ",
					suffix,
					" "
				]
			}), /* @__PURE__ */ jsx("span", {
				className: "sr-only",
				ref: srRef,
				...testIdProps("sr-content"),
				children: srString
			})]
		})]
	});
};
ListViewSelectAllCheckbox.displayName = "ListViewSelectAllCheckbox";
var ListFilters = ({ sectionFilters }) => {
	if (!sectionFilters) return null;
	if (Array.isArray(sectionFilters)) return /* @__PURE__ */ jsx(ListViewSectionFilters, { links: sectionFilters });
	else if (isValidElement(sectionFilters)) return /* @__PURE__ */ jsx(Fragment$1, { children: sectionFilters });
	return null;
};
ListFilters.displayName = "ListFilters";
var ListViewMetadata = ({ title, assistiveAnnouncement, sectionFilters, children, style, className, actionsStyle, actionsClassName, onToggleSelectAll, overflowMenuProps, overflowMenuToggleProps, ...actionBarProps }) => {
	const { idPrefix } = useListViewId();
	const { anyItemsSelected } = useListViewSelection();
	const { setHasMetadataTitle } = useListViewTitle();
	const TitleTag = useNextHeaderTag("list-view-metadata");
	const announceRef = useRef(null);
	useEffect(() => {
		setHasMetadataTitle(!!title);
	});
	useEffect(() => {
		if (announceRef.current) announceFromElement$1(announceRef.current);
	}, [assistiveAnnouncement]);
	return /* @__PURE__ */ jsxs("div", {
		id: `${idPrefix}-list-view-metadata`,
		className: clsx(Metadata_module_default.container, className, anyItemsSelected && density_gap_module_default.spacious),
		style,
		...testIdProps("list-view-metadata"),
		children: [
			/* @__PURE__ */ jsx(ListViewSelectAllCheckbox, { onToggle: (isSelectAllChecked) => {
				if (onToggleSelectAll) onToggleSelectAll(isSelectAllChecked);
			} }),
			/* @__PURE__ */ jsx(ListFilters, { sectionFilters }),
			Boolean(title) && /* @__PURE__ */ jsx(TitleTag, {
				className: clsx(Metadata_module_default.heading, anyItemsSelected && "sr-only"),
				...testIdProps("list-view-header-title"),
				children: title
			}),
			/* @__PURE__ */ jsx(ListViewActionBar, {
				style: actionsStyle,
				className: actionsClassName,
				overflowMenuProps,
				overflowMenuToggleProps,
				...actionBarProps,
				children
			}),
			assistiveAnnouncement && /* @__PURE__ */ jsx(ListViewAnnouncements, {
				idPrefix,
				announceRef,
				assistiveAnnouncement
			})
		]
	});
};
ListViewMetadata.displayName = "ListViewMetadata";
var ListViewAnnouncements = ({ idPrefix, announceRef, assistiveAnnouncement }) => {
	return /* @__PURE__ */ jsx("div", {
		id: `${idPrefix}-list-view-announcements`,
		role: "status",
		"aria-live": "polite",
		"aria-atomic": "true",
		className: "sr-only",
		ref: announceRef,
		...testIdProps("list-view-announcement-container"),
		children: assistiveAnnouncement
	});
};
ListViewAnnouncements.displayName = "ListViewAnnouncements";
function addSortToQuery(query, sort) {
	const sortFilter = sort ? `sort:${sort}` : "";
	if (!query) return sortFilter;
	const filterTerms = query.split(" ");
	const nonSortTerms = filterTerms.filter((term) => !term.startsWith("sort:"));
	if (nonSortTerms.length === 0) return sortFilter;
	const newQuery = filterTerms.length === nonSortTerms.length ? query : nonSortTerms.join(" ");
	return sortFilter ? `${newQuery} ${sortFilter}` : newQuery;
}
function getSortFromQuery(query) {
	if (!query) return "";
	const sortTerms = query.split(" ").filter((term) => term.startsWith("sort:"));
	if (sortTerms.length === 0) return "";
	return sortTerms[0].substring(5);
}
export { getSortFromQuery as a, addSortToQuery as i, ListViewMetadata as n, getSortingKeyAndDirection as o, SortingDropdown as r, getSortingOptionLabel as s, ListViewDensityToggle as t };
