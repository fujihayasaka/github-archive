import { useSyncExternalStore } from "react";
var browserEnvironment = {
	type: "browser",
	isBrowser: true,
	isServer: false
};
var serverEnvironment = {
	type: "server",
	isBrowser: false,
	isServer: true
};
function subscribe() {
	return () => {};
}
function getSnapshot() {
	return browserEnvironment;
}
function getServerSnapshot() {
	return serverEnvironment;
}
/**
* A React hook that returns the current runtime environment.
*
* This hook uses `useSyncExternalStore` to properly handle SSR and hydration,
* ensuring consistent behavior across server and client rendering.
*
* @example
* ```tsx
* function MyComponent() {
*   const {isBrowser, isServer, type} = useRuntimeEnvironment()
*
*   if (isServer) {
*     return <ServerPlaceholder />
*   }
*
*   return <BrowserOnlyContent />
* }
* ```
*
* @returns RuntimeEnvironment object containing:
*   - `type`: 'browser' | 'server'
*   - `isBrowser`: boolean
*   - `isServer`: boolean
*/
function useRuntimeEnvironment() {
	return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
export { useRuntimeEnvironment as t };
