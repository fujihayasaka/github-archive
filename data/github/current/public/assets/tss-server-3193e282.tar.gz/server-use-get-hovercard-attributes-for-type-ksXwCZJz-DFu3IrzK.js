import { A as cweHovercardPath, F as dependencyGraphPackageHovercardPath, I as discussionHovercardPath, J as issueLinkedPullRequestHovercardPath, Kt as userHovercardPath, Lt as securityAlertHovercardPath, P as dependabotAlertHovercardPath, Pt as repositoryPath, S as commitHovercardPath, Ut as trackedInHovercardPath, Vt as teamHovercardPath, W as integrationHovercardPath, Wt as trackingHovercardPath, at as orgHovercardPath, dt as projectHovercardPath, k as copilotHovercardPath, n as advisoryHovercardPath, q as issueHovercardPath, qt as userIdHovercardPath, t as achievementHovercardPath, ut as profileHighlightHovercardPath, zt as sponsorsListingHovercardPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { useCallback } from "react";
import { c } from "react/compiler-runtime";
/**
* User preferences for hovercards.
*
* Preferences are read from `<meta>` tags in the document head and cached
* after first access. No DOM queries are performed after the initial read.
*/
var cachedHovercardsEnabled;
var cachedHovercardHintEnabled;
/**
* Check if hovercards are enabled for the current user.
* Reads from `<meta name="hovercards-preference">` tag. Defaults to true if not set.
* Result is cached after first call - no repeated DOM queries.
*/
function isHovercardEnabledForUser() {
	if (typeof document === "undefined") return true;
	if (cachedHovercardsEnabled !== void 0) return cachedHovercardsEnabled;
	const meta = document.querySelector("meta[name=hovercards-preference]");
	cachedHovercardsEnabled = meta?.content === "true" || meta === null;
	return cachedHovercardsEnabled;
}
/**
* Check if hovercard keyboard hint (aria-keyshortcuts) is enabled for the current user.
* Reads from `<meta name="announcement-preference-hovercard">` tag. Defaults to true if not set.
* Returns false if hovercards are disabled entirely.
* Result is cached after first call - no repeated DOM queries.
*/
function isHovercardHintEnabledForUser() {
	if (typeof document === "undefined") return true;
	if (cachedHovercardHintEnabled !== void 0) return cachedHovercardHintEnabled;
	if (!isHovercardEnabledForUser()) {
		cachedHovercardHintEnabled = false;
		return false;
	}
	const meta = document.querySelector("meta[name=announcement-preference-hovercard]");
	cachedHovercardHintEnabled = meta?.content === "true" || meta === null;
	return cachedHovercardHintEnabled;
}
/** The keyboard shortcut for opening hovercards */
var HOVERCARD_KEYBOARD_SHORTCUT = "Alt+ArrowUp";
var EMPTY_RESULT = Object.freeze({});
/**
* Add keyboard hint aria attribute if enabled for the user.
*/
function addKeyboardHint(attributes) {
	if (isHovercardHintEnabledForUser()) return {
		...attributes,
		"aria-keyshortcuts": HOVERCARD_KEYBOARD_SHORTCUT
	};
	return attributes;
}
/**
* Add analytics tracking attributes to hovercard attributes.
*/
function addTrackingAttributes(attributes) {
	return addKeyboardHint({
		...attributes,
		"octo-click": "hovercard-link-click",
		"octo-dimensions": "link_type:self"
	});
}
/**
* Add configuration attributes to hovercard attributes.
*/
function addConfigAttributes(attributes, config) {
	if (!config) return attributes;
	const result = { ...attributes };
	if (config.fixedPositioning) result["data-hovercard-fixed-positioning"] = "";
	if (config.zIndexOverride !== void 0) result["data-hovercard-z-index-override"] = String(config.zIndexOverride);
	if (config.cache) result["data-hovercard-cache"] = config.cache;
	return result;
}
/**
* Build final hovercard attributes with optional tracking.
*/
function buildHovercardAttributes(url, type, tracking = true) {
	const attributes = {
		"data-hovercard-url": url,
		"data-hovercard-type": type
	};
	if (tracking) return addTrackingAttributes(attributes);
	return addKeyboardHint(attributes);
}
/**
* Build final hovercard attributes with optional tracking and configuration.
*/
function buildHovercardAttributesWithConfig(url, type, tracking = true, config) {
	const baseAttributes = buildHovercardAttributes(url, type, tracking);
	if (Object.keys(baseAttributes).length === 0) return EMPTY_RESULT;
	return addConfigAttributes(baseAttributes, config);
}
/**
* Generate the URL for a hovercard based on type and options.
*/
function getHovercardUrlForType(type, options) {
	const anyOpts = options;
	if (typeof anyOpts.url === "string" && anyOpts.url) return anyOpts.url;
	switch (type) {
		case "user": {
			const opts = options;
			if ("userId" in opts && opts.userId != null) return userIdHovercardPath({ userId: opts.userId });
			if ("login" in opts && opts.login) return userHovercardPath({ owner: opts.login });
			return null;
		}
		case "organization": {
			const opts = options;
			if ("login" in opts && opts.login) return orgHovercardPath({ owner: opts.login });
			return null;
		}
		case "team": {
			const opts = options;
			if ("owner" in opts && opts.owner && "team" in opts && opts.team) return teamHovercardPath({
				owner: opts.owner,
				team: opts.team
			});
			return null;
		}
		case "issue": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "issueNumber" in opts && opts.issueNumber != null) return issueHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				issueNumber: opts.issueNumber
			});
			return null;
		}
		case "pull_request": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "pullRequestNumber" in opts && opts.pullRequestNumber != null) return issueLinkedPullRequestHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				pullRequestNumber: opts.pullRequestNumber
			});
			return null;
		}
		case "commit": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "commitish" in opts && opts.commitish) return commitHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				commitish: opts.commitish
			});
			return null;
		}
		case "copilot": {
			const opts = options;
			if ("botSlug" in opts && opts.botSlug) return copilotHovercardPath({ bot_slug: opts.botSlug });
			return null;
		}
		case "repository": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo) return repositoryPath({
				owner: opts.owner,
				repo: opts.repo,
				action: "hovercard"
			});
			return null;
		}
		case "discussion": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "discussionNumber" in opts && opts.discussionNumber != null) return discussionHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				discussionNumber: opts.discussionNumber
			});
			return null;
		}
		case "advisory": {
			const opts = options;
			if ("ghsaId" in opts && opts.ghsaId) return advisoryHovercardPath({ ghsaId: opts.ghsaId });
			return null;
		}
		case "cwe": {
			const opts = options;
			if ("id" in opts && opts.id) return cweHovercardPath({ id: opts.id });
			return null;
		}
		case "sponsors_listing": {
			const opts = options;
			if ("login" in opts && opts.login) return sponsorsListingHovercardPath({ login: opts.login });
			return null;
		}
		case "achievement": {
			const opts = options;
			if ("login" in opts && opts.login && "slug" in opts && opts.slug) return achievementHovercardPath({
				login: opts.login,
				slug: opts.slug
			});
			return null;
		}
		case "tracked_in": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "issueNumber" in opts && opts.issueNumber != null) return trackedInHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				issueNumber: opts.issueNumber
			});
			return null;
		}
		case "tracking": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "issueNumber" in opts && opts.issueNumber != null && "id" in opts && opts.id != null) return trackingHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				issueNumber: opts.issueNumber,
				id: opts.id
			});
			return null;
		}
		case "security_alert": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "alertNumber" in opts && opts.alertNumber != null) return securityAlertHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				alertNumber: opts.alertNumber
			});
			return null;
		}
		case "dependabot_alert": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "alertNumber" in opts && opts.alertNumber != null) return dependabotAlertHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				alertNumber: opts.alertNumber
			});
			return null;
		}
		case "dependency_graph_package": {
			const opts = options;
			if ("owner" in opts && opts.owner && "repo" in opts && opts.repo && "id" in opts && opts.id && "name" in opts && opts.name) return dependencyGraphPackageHovercardPath({
				owner: opts.owner,
				repo: opts.repo,
				id: opts.id,
				name: opts.name
			});
			return null;
		}
		case "project": {
			const opts = options;
			if ("projectId" in opts && opts.projectId != null) return projectHovercardPath({ projectId: opts.projectId });
			return null;
		}
		case "integration": {
			const opts = options;
			if ("id" in opts && opts.id != null) return integrationHovercardPath({ id: opts.id });
			return null;
		}
		case "profile_highlight": {
			const opts = options;
			if ("login" in opts && opts.login && "highlightType" in opts && opts.highlightType) return profileHighlightHovercardPath({
				login: opts.login,
				highlightType: opts.highlightType
			});
			return null;
		}
		default: return null;
	}
}
/**
* React hook that returns a function for generating hovercard attributes.
* Handles SSR and user preferences automatically.
*
* @example
* ```tsx
* function MyComponent() {
*   const getHovercardAttributesForType = useGetHovercardAttributesForType()
*
*   return (
*     <>
*       <a {...getHovercardAttributesForType('user', {login: 'octocat'})} href="/octocat">
*         @octocat
*       </a>
*       <a {...getHovercardAttributesForType('issue', {owner: 'github', repo: 'docs', issueNumber: 123})} href="/github/docs/issues/123">
*         #123
*       </a>
*       <a {...getHovercardAttributesForType('repository', {owner: 'github', repo: 'docs', fixedPositioning: true})} href="/github/docs">
*         github/docs
*       </a>
*     </>
*   )
* }
* ```
*/
function useGetHovercardAttributesForType() {
	const $ = c(4);
	const { isServer } = useRuntimeEnvironment();
	let t0;
	if ($[0] !== isServer) {
		t0 = isServer || !isHovercardEnabledForUser();
		$[0] = isServer;
		$[1] = t0;
	} else t0 = $[1];
	const isDisabled = t0;
	let t1;
	if ($[2] !== isDisabled) {
		t1 = (type, options) => {
			if (isDisabled) return EMPTY_RESULT;
			const url = getHovercardUrlForType(type, options);
			if (!url) return EMPTY_RESULT;
			return buildHovercardAttributesWithConfig(url, type, options.tracking ?? true, {
				fixedPositioning: options.fixedPositioning,
				zIndexOverride: options.zIndexOverride,
				cache: options.cache
			});
		};
		$[2] = isDisabled;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
export { isHovercardHintEnabledForUser as n, useGetHovercardAttributesForType as r, HOVERCARD_KEYBOARD_SHORTCUT as t };
