import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { In as MoonIcon, Jt as GitPullRequestIcon, Zr as StarIcon, _i as Truncate, _r as RepoLockedIcon, an as IconButton, ar as PlusIcon, bn as Link, er as PersonIcon, fn as IssueOpenedIcon, gr as RepoIcon, hi as TriangleDownIcon, hr as RepoForkedIcon, mr as RepoCloneIcon, pi as Tooltip$1, vi as TypographyIcon, vn as LawIcon, vr as RepoPushIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { At as repoStargazersPath, Ct as repoCommitActivityInsightsPath, Et as repoIssuesPath, H as forksListPath, Nt as repositoryParticipationPath, Pt as repositoryPath, kt as repoPullRequestsPath, ot as orgTopicReposPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { r as mainQuery, t as DataRouterApplicationBuilder } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as NavList } from "./server-NavList-D8uWdChJ-BgWGw1cA.js";
import { c as FilterProviderType, u as FilterQueryParser } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { t as useIntersectionObserver } from "./server-use-intersection-observer-B95-tqzf-CUpd9cN-.js";
import { _ as useListViewVariant, a as ListItemLeadingVisual, c as ListItemTitle, d as human, i as ListItemLeadingContent, l as ListView, o as ListItemMainContent, r as ListItemDescription, s as ListItemMetadata, t as ListItem, u as getSignificanceBasedPrecision } from "./server-MainContent-ouZQ_bM_-DHVoK7D7.js";
import { X as getIconComponent, Y as getIconColorClassName } from "./server-providers-w0hxsmcG-B_8wxADa.js";
import { a as getSortFromQuery, n as ListViewMetadata, o as getSortingKeyAndDirection, r as SortingDropdown, s as getSortingOptionLabel, t as ListViewDensityToggle } from "./server-query-DlQMbiaN-CidcEdMM.js";
import { Fragment, memo, useId, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var reposFinderAppBuilder = DataRouterApplicationBuilder.create("repos-finder");
var reposFinderLayoutRoute = reposFinderAppBuilder.createQueryRouteConfig("reposFinderLayoutRoute", {
	path: "/repos",
	queries: [mainQuery({
		queryDeps: ({ pathname }) => ({ pathname: `${pathname}/_layout` }),
		staleTimeForNavigation: 36e4
	})]
});
function getHandlerNavItemClick({ linkItem, onSelectLink, sendAnalyticsEvent }) {
	const tags = linkItem.source === "predefined" ? { id: linkItem.id } : { shortcut: true };
	return (event) => {
		sendAnalyticsEvent("repos-list.sidebar", "SIDEBAR_PICKER", tags);
		if (canSoftNavigate(event)) {
			onSelectLink(linkItem);
			event.preventDefault();
		}
	};
}
function canSoftNavigate(event) {
	return !event.ctrlKey && !event.metaKey && !event.shiftKey && event.button === 0;
}
var ListSidebar_module_default = {
	dialog: "ListSidebar-module_DWMAEW_dialog",
	sidebarHeading: "ListSidebar-module_DWMAEW_sidebarHeading",
	sidebarToggleButton: "ListSidebar-module_DWMAEW_sidebarToggleButton"
};
var ReposShortcutSidebar_module_default = {
	headerRow: "ReposShortcutSidebar-module_NMPztW_headerRow",
	headerRowText: "ReposShortcutSidebar-module_NMPztW_headerRowText",
	icon: "ReposShortcutSidebar-module_NMPztW_icon",
	savedViewsList: "ReposShortcutSidebar-module_NMPztW_savedViewsList"
};
function SidebarLinkIcon({ name, color }) {
	const IconComponent = getIconComponent(name);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(ReposShortcutSidebar_module_default.icon, getIconColorClassName(color)),
		children: /* @__PURE__ */ jsx(IconComponent, {})
	});
}
SidebarLinkIcon.displayName = "SidebarLinkIcon";
function ListSidebar(t0) {
	const $ = c(9);
	const { links, selectedLink, onSelectLink } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== links || $[1] !== onSelectLink || $[2] !== selectedLink || $[3] !== sendAnalyticsEvent) {
		let t2;
		if ($[5] !== onSelectLink || $[6] !== selectedLink || $[7] !== sendAnalyticsEvent) {
			t2 = (linkItem) => jsxs(NavList.Item, {
				"aria-current": selectedLink === linkItem.id && "page",
				href: `?q=${linkItem.query}`,
				onClick: getHandlerNavItemClick({
					onSelectLink,
					sendAnalyticsEvent,
					linkItem
				}),
				children: [jsx(NavList.LeadingVisual, { children: jsx(SidebarLinkIcon, {
					name: linkItem.icon,
					color: linkItem.color
				}) }), jsx(Truncate, {
					title: linkItem.name,
					maxWidth: "100%",
					children: linkItem.name
				})]
			}, linkItem.id);
			$[5] = onSelectLink;
			$[6] = selectedLink;
			$[7] = sendAnalyticsEvent;
			$[8] = t2;
		} else t2 = $[8];
		t1 = jsx(NavList, { children: links.map(t2) });
		$[0] = links;
		$[1] = onSelectLink;
		$[2] = selectedLink;
		$[3] = sendAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
ListSidebar.displayName = "ListSidebar";
function ListSidebarCollapsedButton({ onSelectLink, onCreateView, showCreateShortcuts = false, ...props }) {
	const [isDialogOpen, showDialog] = useState(false);
	const buttonRef = useRef(null);
	const listName = props.links.find((link) => link.id === props.selectedLink)?.name || "Search";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(ButtonComponent, {
			ref: buttonRef,
			variant: "invisible",
			onClick: () => showDialog(true),
			trailingVisual: TriangleDownIcon,
			"aria-describedby": "types-collapsed-button-description",
			className: ListSidebar_module_default.sidebarToggleButton,
			children: /* @__PURE__ */ jsx("h1", {
				className: ListSidebar_module_default.sidebarHeading,
				children: /* @__PURE__ */ jsx(Truncate, {
					title: listName,
					maxWidth: "100%",
					children: listName
				})
			})
		}),
		/* @__PURE__ */ jsx("span", {
			className: "sr-only",
			id: "types-collapsed-button-description",
			"aria-live": "polite",
			children: "Change the repository type filter"
		}),
		isDialogOpen && /* @__PURE__ */ jsx(Dialog, {
			className: ListSidebar_module_default.dialog,
			onClose: () => showDialog(false),
			title: "Views",
			width: "small",
			returnFocusRef: buttonRef,
			footerButtons: showCreateShortcuts && onCreateView ? [{
				buttonType: "default",
				content: "Close",
				onClick: () => showDialog(false)
			}, {
				buttonType: "primary",
				content: "New view",
				onClick: onCreateView
			}] : [],
			children: /* @__PURE__ */ jsx(ListSidebar, {
				onSelectLink: (linkItem) => {
					onSelectLink(linkItem);
					showDialog(false);
				},
				...props
			})
		})
	] });
}
ListSidebarCollapsedButton.displayName = "ListSidebarCollapsedButton";
function getScreenReaderMessage(sortingOptions, defaultSortingKey, getEmptyMessage, isFetching, currentPage, query, results, userInfo) {
	if (isFetching) return "";
	const { repositories, repositoryCount, pageCount } = results;
	if (repositories.length === 0) {
		const { heading, description } = getEmptyMessage({
			filtered: !!query,
			currentPage,
			pageCount,
			userInfo
		});
		return `${heading} ${description || ""}`.trim();
	}
	const [sortKey, direction] = getSortingKeyAndDirection(getSortFromQuery(query), defaultSortingKey);
	const sortingLabel = getSortingOptionLabel(sortKey, sortingOptions);
	const sortOrder = direction === "asc" ? "ascending" : "descending";
	return `${getDisplayReposCount(repositoryCount)} found. List is sorted by ${sortingLabel} in ${sortOrder} order.`;
}
function getDisplayReposCount(count) {
	return `${human(count, { precision: getSignificanceBasedPrecision(count) })} ${count === 1 ? "repository" : "repositories"}`;
}
var ReposList_module_default = {
	ReposCountText: "ReposList-module_6fzhGW_ReposCountText",
	ReposListContainer: "ReposList-module_6fzhGW_ReposListContainer"
};
var LanguageCircle_module_default = { LanguageCircleIndicator: "LanguageCircle-module_QbmutG_LanguageCircleIndicator" };
function LanguageCircle({ color }) {
	return /* @__PURE__ */ jsx(Box, {
		sx: { bg: color || "attention.emphasis" },
		className: LanguageCircle_module_default.LanguageCircleIndicator
	});
}
LanguageCircle.displayName = "LanguageCircle";
var ReposListItem_module_default = {
	CompactItemAttributes: "ReposListItem-module_3U0AWW_CompactItemAttributes",
	CompactItemLanguageLabel: "ReposListItem-module_3U0AWW_CompactItemLanguageLabel",
	CompactItemLeadingContent: "ReposListItem-module_3U0AWW_CompactItemLeadingContent",
	CompactItemMetadataContainer: "ReposListItem-module_3U0AWW_CompactItemMetadataContainer",
	CompactItemSettingsLink: "ReposListItem-module_3U0AWW_CompactItemSettingsLink",
	CompactItemTitle: "ReposListItem-module_3U0AWW_CompactItemTitle",
	CompactItemTitleContainer: "ReposListItem-module_3U0AWW_CompactItemTitleContainer",
	CompactItemTypeLabel: "ReposListItem-module_3U0AWW_CompactItemTypeLabel",
	CompactListItem: "ReposListItem-module_3U0AWW_CompactListItem",
	CompactNarrowItemContent: "ReposListItem-module_3U0AWW_CompactNarrowItemContent",
	CompactWideItemDescription: "ReposListItem-module_3U0AWW_CompactWideItemDescription",
	DefaultItemContent: "ReposListItem-module_3U0AWW_DefaultItemContent",
	DefaultItemTitle: "ReposListItem-module_3U0AWW_DefaultItemTitle",
	DefaultItemTitleContainer: "ReposListItem-module_3U0AWW_DefaultItemTitleContainer",
	FormattedDescription: "ReposListItem-module_3U0AWW_FormattedDescription",
	HideOnSmallScreen: "ReposListItem-module_3U0AWW_HideOnSmallScreen",
	IconLabel: "ReposListItem-module_3U0AWW_IconLabel",
	LabelsContainer: "ReposListItem-module_3U0AWW_LabelsContainer",
	LanguageLabelContainer: "ReposListItem-module_3U0AWW_LanguageLabelContainer",
	LastUpdated: "ReposListItem-module_3U0AWW_LastUpdated",
	LastUpdatedNarrow: "ReposListItem-module_3U0AWW_LastUpdatedNarrow",
	MoreTopicsButton: "ReposListItem-module_3U0AWW_MoreTopicsButton",
	NwoTitle: "ReposListItem-module_3U0AWW_NwoTitle",
	PrimaryLanguageName: "ReposListItem-module_3U0AWW_PrimaryLanguageName",
	RepoOwner: "ReposListItem-module_3U0AWW_RepoOwner",
	SmallScreenOnly: "ReposListItem-module_3U0AWW_SmallScreenOnly",
	SparklineContainer: "ReposListItem-module_3U0AWW_SparklineContainer",
	TopicLabel: "ReposListItem-module_3U0AWW_TopicLabel",
	TopicsList: "ReposListItem-module_3U0AWW_TopicsList",
	TruncatedPrimaryLanguageName: "ReposListItem-module_3U0AWW_TruncatedPrimaryLanguageName"
};
/**
* Removes the wrapping quotes from a value if it starts and ends with quotes.
*/
function dropWrappingQuotes(value) {
	if (value.startsWith("\"") && value.endsWith("\"")) return value.slice(1, -1);
	return value;
}
var keyPattern = /* @__PURE__ */ new RegExp(/([\w.#-]+):/g);
function tokenizeQuery(query, providers) {
	if (query.length > 1e3) return [{
		type: "text",
		value: query
	}];
	if (!providers) providers = Array.from(query.matchAll(keyPattern), (match) => match[1] || "").filter(Boolean).map(buildFakeProvider);
	return new FilterQueryParser(providers).parse(query).blocks.filter((block) => block.type !== "space").map((block) => {
		if (block.type === "filter") {
			const isNegated = block.key.value.startsWith("-");
			return {
				type: "filter",
				key: isNegated ? block.key.value.slice(1) : block.key.value,
				isNegated,
				values: block.value.values.map(({ value }) => {
					return typeof value === "string" ? dropWrappingQuotes(value) : `${value}`;
				}),
				quotedValues: block.value.values.map(({ value }) => `${value}`),
				raw: block.raw
			};
		} else return {
			type: "text",
			value: block.raw
		};
	});
}
function buildFakeProvider(key) {
	return {
		key,
		icon: MoonIcon,
		priority: 0,
		getSuggestions: () => null,
		type: FilterProviderType.Text,
		validateFilterBlockValues: (_filterQuery, _block, values) => values,
		getValueRowProps: () => ({ text: "" }),
		options: {
			priority: 0,
			filterTypes: {},
			support: {}
		}
	};
}
var SearchMatchText_module_default = { highlightedText: "SearchMatchText-module_p9MetG_highlightedText" };
var MINIMUM_LENGTH_TO_HIGHLIGHT = 3;
var SPECIAL_REGEX_CHARACTERS = /[.*+?^${}()|[\]\\]/g;
function SearchMatchText({ query, children }) {
	if (!query) return children;
	const queryTextTokens = tokenizeQuery(query).filter((segment) => segment.type === "text").filter((segment) => segment.value.length >= MINIMUM_LENGTH_TO_HIGHLIGHT).map((segment) => segment.value.toLowerCase());
	if (!queryTextTokens.length) return children;
	const escapedTokens = queryTextTokens.map((token) => token.replace(SPECIAL_REGEX_CHARACTERS, "\\$&"));
	return /* @__PURE__ */ jsx(Fragment$1, { children: children.split(new RegExp(`(${escapedTokens.join("|")})`, "gi")).filter((part) => !!part).map((part, index) => queryTextTokens.includes(part.toLowerCase()) ? /* @__PURE__ */ jsx("span", {
		className: SearchMatchText_module_default.highlightedText,
		"data-testid": "highlighted-text",
		children: part
	}, index) : /* @__PURE__ */ jsx(Fragment, { children: part }, index)) });
}
SearchMatchText.displayName = "SearchMatchText";
var strokeWidth = 2;
var defaultWidth = 120;
var tinyWidth = 60;
var sparklineHeight = 25;
function Sparkline({ uniqueKey, points, variant = "default", label }) {
	const width = variant === "tiny" ? tinyWidth : defaultWidth;
	const coordinates = getCoordinates(points, width, sparklineHeight - strokeWidth);
	const gradientId = `gradient-${uniqueKey}`;
	const maskId = `sparkline-${uniqueKey}`;
	return /* @__PURE__ */ jsx("div", {
		style: { height: sparklineHeight },
		children: /* @__PURE__ */ jsxs("svg", {
			"data-testid": `${uniqueKey}-sparkline`,
			"aria-label": label,
			width,
			height: sparklineHeight,
			viewBox: `0 0 ${width} ${sparklineHeight}`,
			children: [/* @__PURE__ */ jsxs("defs", { children: [/* @__PURE__ */ jsxs("linearGradient", {
				id: gradientId,
				x1: "0",
				x2: "0",
				y1: "1",
				y2: "0",
				children: [
					/* @__PURE__ */ jsx("stop", {
						offset: "0%",
						stopColor: "var(--contribution-default-bgColor-1)"
					}),
					/* @__PURE__ */ jsx("stop", {
						offset: "10%",
						stopColor: "var(--contribution-default-bgColor-2)"
					}),
					/* @__PURE__ */ jsx("stop", {
						offset: "25%",
						stopColor: "var(--contribution-default-bgColor-3)"
					}),
					/* @__PURE__ */ jsx("stop", {
						offset: "50%",
						stopColor: "var(--contribution-default-bgColor-4)"
					})
				]
			}), /* @__PURE__ */ jsx("mask", {
				id: maskId,
				x: "0",
				y: "0",
				width,
				height: sparklineHeight,
				children: /* @__PURE__ */ jsx("polyline", {
					transform: `translate(0, ${sparklineHeight - strokeWidth / 2}) scale(1,-1)`,
					points: coordinates.join(" "),
					fill: "transparent",
					stroke: "#8cc665",
					strokeWidth
				})
			})] }), /* @__PURE__ */ jsx("g", { children: /* @__PURE__ */ jsx("rect", {
				x: "0",
				y: "0",
				width,
				height: sparklineHeight,
				style: {
					stroke: "none",
					fill: `url(#${gradientId})`,
					mask: `url(#${maskId})`
				}
			}) })]
		})
	});
}
Sparkline.displayName = "Sparkline";
function getCoordinates(points, width, height) {
	const scaledPoints = rescale(points.length < 2 ? [0, 0] : points, height);
	const xOffset = width / (scaledPoints.length - 1);
	const coordinates = [];
	for (let i = 0; i < scaledPoints.length; i++) {
		const y = scaledPoints[i];
		coordinates.push(`${xOffset * i},${y}`);
	}
	return coordinates;
}
function rescale(points, height) {
	const maxPoint = Math.max(...points);
	if (maxPoint <= height) return points;
	return points.map((point) => roundToTwoDecimalPlaces(point / maxPoint * height));
}
function roundToTwoDecimalPlaces(value) {
	return Math.round(value * 100) / 100;
}
var ReposListItem = memo(function ReposListItem(props) {
	const $ = c(7);
	const { repo, showNameWithOwner } = props;
	const { variant } = useListViewVariant();
	if (variant === "default") {
		let t0;
		if ($[0] !== props || $[1] !== showNameWithOwner) {
			t0 = jsx(ListItem, {
				title: showNameWithOwner ? jsx(DefaultItemTitleWithOwner, { ...props }) : jsx(DefaultItemTitle, { ...props }),
				children: jsx(DefaultItemContent, { ...props })
			});
			$[0] = props;
			$[1] = showNameWithOwner;
			$[2] = t0;
		} else t0 = $[2];
		return t0;
	}
	let t0;
	if ($[3] !== props || $[4] !== repo || $[5] !== showNameWithOwner) {
		t0 = jsxs(ListItem, {
			metadata: jsx(CompactItemMetadata, { repo }),
			title: showNameWithOwner ? jsx(CompactItemTitleWithOwner, { ...props }) : jsx(CompactItemTitle, { ...props }),
			className: ReposListItem_module_default.CompactListItem,
			metadataContainerClassName: ReposListItem_module_default.CompactItemMetadataContainer,
			children: [jsx(ListItemLeadingContent, {
				className: ReposListItem_module_default.CompactItemLeadingContent,
				children: jsx(ListItemLeadingVisual, {
					icon: getRepoIcon(repo),
					color: "fg.muted"
				})
			}), jsxs(ListItemMainContent, { children: [jsx(CompactWideItemContent, { ...props }), jsx(CompactNarrowItemContent, { ...props })] })]
		});
		$[3] = props;
		$[4] = repo;
		$[5] = showNameWithOwner;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
});
ReposListItem.displayName = "ReposListItem";
function DefaultItemContent({ repo, query }) {
	const { description, lastUpdated, license, allTopics, isAdminableByUser } = repo;
	const topicsProps = {
		topics: allTopics,
		owner: repo.owner,
		name: repo.name
	};
	return /* @__PURE__ */ jsx(ListItemMainContent, { children: /* @__PURE__ */ jsxs("div", {
		className: ReposListItem_module_default.DefaultItemContent,
		children: [
			description && /* @__PURE__ */ jsx(ListItemDescription, { children: /* @__PURE__ */ jsx(FormattedDescription, {
				description,
				query,
				className: ReposListItem_module_default.FormattedDescription
			}) }),
			allTopics.length > 0 && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(TopicsList, {
				...topicsProps,
				max: 3,
				className: ReposListItem_module_default.SmallScreenOnly
			}), /* @__PURE__ */ jsx(TopicsList, {
				...topicsProps,
				max: 10,
				className: ReposListItem_module_default.HideOnSmallScreen
			})] }),
			/* @__PURE__ */ jsxs("div", {
				className: ReposListItem_module_default.LabelsContainer,
				children: [
					/* @__PURE__ */ jsx(LanguageLabel, { ...repo }),
					repo.primaryLanguage && /* @__PURE__ */ jsx("span", { children: "•" }),
					license && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(LicenseLabel, { ...repo }), /* @__PURE__ */ jsx("span", { children: "•" })] }),
					/* @__PURE__ */ jsx(ForksLabel, { ...repo }),
					/* @__PURE__ */ jsx("span", { children: "•" }),
					/* @__PURE__ */ jsx(StarsLabel, { ...repo }),
					/* @__PURE__ */ jsx("span", { children: "•" }),
					repo.issueCount !== null && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IssuesLabel, {
						...repo,
						issueCount: repo.issueCount
					}), /* @__PURE__ */ jsx("span", { children: "•" })] }),
					repo.pullRequestCount !== null && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(PullRequestsLabel, {
						...repo,
						pullRequestCount: repo.pullRequestCount
					}), /* @__PURE__ */ jsx("span", { children: "•" })] }),
					/* @__PURE__ */ jsxs("span", {
						className: ReposListItem_module_default.LastUpdated,
						children: [
							lastUpdated.hasBeenPushedTo ? "Updated" : "Created",
							" ",
							/* @__PURE__ */ jsx(RelativeTime, { datetime: lastUpdated.timestamp })
						]
					}),
					/* @__PURE__ */ jsx(RelativeTime, {
						datetime: lastUpdated.timestamp,
						format: "micro",
						className: ReposListItem_module_default.LastUpdatedNarrow
					}),
					isAdminableByUser && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", { children: "•" }), /* @__PURE__ */ jsx(RepoSettingsLink, { ...repo })] })
				]
			})
		]
	}) });
}
DefaultItemContent.displayName = "DefaultItemContent";
function CompactNarrowItemContent({ repo, query }) {
	const { description, isAdminableByUser, pullRequestCount } = repo;
	return /* @__PURE__ */ jsxs("div", {
		className: ReposListItem_module_default.CompactNarrowItemContent,
		children: [description && /* @__PURE__ */ jsx(ListItemDescription, { children: /* @__PURE__ */ jsx(FormattedDescription, {
			description,
			query,
			className: ReposListItem_module_default.FormattedDescription
		}) }), /* @__PURE__ */ jsxs("div", {
			className: ReposListItem_module_default.LabelsContainer,
			children: [
				/* @__PURE__ */ jsx(LanguageLabel, { ...repo }),
				repo.primaryLanguage && /* @__PURE__ */ jsx("span", { children: "•" }),
				/* @__PURE__ */ jsx(ForksLabel, { ...repo }),
				/* @__PURE__ */ jsx("span", { children: "•" }),
				/* @__PURE__ */ jsx(StarsLabel, { ...repo }),
				/* @__PURE__ */ jsx("span", { children: "•" }),
				pullRequestCount !== null && /* @__PURE__ */ jsx(PullRequestsLabel, {
					...repo,
					pullRequestCount
				}),
				isAdminableByUser && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", { children: "•" }), /* @__PURE__ */ jsx(RepoSettingsLink, { ...repo })] })
			]
		})]
	});
}
CompactNarrowItemContent.displayName = "CompactNarrowItemContent";
function CompactWideItemContent({ repo, query }) {
	const { description } = repo;
	return /* @__PURE__ */ jsx(ListItemDescription, {
		className: ReposListItem_module_default.CompactWideItemDescription,
		children: /* @__PURE__ */ jsx(FormattedDescription, {
			description,
			query
		})
	});
}
CompactWideItemContent.displayName = "CompactWideItemContent";
function DefaultItemTitle({ repo, query, linkAs }) {
	const { name, type, owner } = repo;
	const repoPath = repositoryPath({
		owner,
		repo: name
	});
	return /* @__PURE__ */ jsxs(ListItemTitle, {
		...linkAs && { linkProps: {
			as: linkAs,
			to: repoPath
		} },
		value: /* @__PURE__ */ jsx(SearchMatchText, {
			query,
			children: name
		}),
		href: repoPath,
		headingClassName: ReposListItem_module_default.DefaultItemTitle,
		containerClassName: ReposListItem_module_default.DefaultItemTitleContainer,
		children: [/* @__PURE__ */ jsx(Label, {
			variant: "secondary",
			"data-listview-item-visibility-label": true,
			children: type
		}), /* @__PURE__ */ jsx(ParticipationSparkline, { repo })]
	});
}
DefaultItemTitle.displayName = "DefaultItemTitle";
function CompactItemTitle({ repo, query, linkAs }) {
	const { name, type, owner } = repo;
	const repoPath = repositoryPath({
		owner,
		repo: name
	});
	return /* @__PURE__ */ jsx(ListItemTitle, {
		...linkAs && { linkProps: {
			as: linkAs,
			to: repoPath
		} },
		value: /* @__PURE__ */ jsx(SearchMatchText, {
			query,
			children: name
		}),
		href: repoPath,
		headingClassName: ReposListItem_module_default.CompactItemTitle,
		containerClassName: ReposListItem_module_default.CompactItemTitleContainer,
		children: /* @__PURE__ */ jsx(Label, {
			variant: "secondary",
			className: ReposListItem_module_default.CompactItemTypeLabel,
			children: type
		})
	});
}
CompactItemTitle.displayName = "CompactItemTitle";
function DefaultItemTitleWithOwner({ repo, query, linkAs }) {
	const { name, type, owner } = repo;
	const searchMatchName = /* @__PURE__ */ jsx(SearchMatchText, {
		query,
		children: name
	});
	const searchMatchOwner = /* @__PURE__ */ jsx(SearchMatchText, {
		query,
		children: owner
	});
	const repoPath = repositoryPath({
		owner,
		repo: name
	});
	return /* @__PURE__ */ jsxs(ListItemTitle, {
		...linkAs && { linkProps: {
			as: linkAs,
			to: repoPath
		} },
		value: /* @__PURE__ */ jsx(NwoTitle, {
			name: searchMatchName,
			owner: searchMatchOwner
		}),
		href: repoPath,
		headingClassName: ReposListItem_module_default.DefaultItemTitle,
		containerClassName: ReposListItem_module_default.DefaultItemTitleContainer,
		children: [/* @__PURE__ */ jsx(Label, {
			variant: "secondary",
			children: type
		}), /* @__PURE__ */ jsx(ParticipationSparkline, { repo })]
	});
}
DefaultItemTitleWithOwner.displayName = "DefaultItemTitleWithOwner";
function CompactItemTitleWithOwner({ repo, query, linkAs }) {
	const { name, type, owner } = repo;
	const searchMatchName = /* @__PURE__ */ jsx(SearchMatchText, {
		query,
		children: name
	});
	const searchMatchOwner = /* @__PURE__ */ jsx(SearchMatchText, {
		query,
		children: owner
	});
	const repoPath = repositoryPath({
		owner,
		repo: name
	});
	return /* @__PURE__ */ jsx(ListItemTitle, {
		...linkAs && { linkProps: {
			as: linkAs,
			to: repoPath
		} },
		value: /* @__PURE__ */ jsx(NwoTitle, {
			name: searchMatchName,
			owner: searchMatchOwner
		}),
		href: repoPath,
		headingClassName: ReposListItem_module_default.CompactItemTitle,
		containerClassName: ReposListItem_module_default.CompactItemTitleContainer,
		children: /* @__PURE__ */ jsx(Label, {
			variant: "secondary",
			className: ReposListItem_module_default.CompactItemTypeLabel,
			children: type
		})
	});
}
CompactItemTitleWithOwner.displayName = "CompactItemTitleWithOwner";
function CompactItemMetadata({ repo }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(ListItemMetadata, {
			className: ReposListItem_module_default.CompactItemLanguageLabel,
			children: /* @__PURE__ */ jsx(LanguageLabel, {
				truncate: true,
				...repo
			})
		}),
		/* @__PURE__ */ jsx(ListItemMetadata, {
			className: ReposListItem_module_default.CompactItemSettingsLink,
			children: repo.isAdminableByUser && /* @__PURE__ */ jsx(RepoSettingsLink, { ...repo })
		}),
		/* @__PURE__ */ jsx(ListItemMetadata, {
			className: ReposListItem_module_default.CompactItemAttributes,
			children: /* @__PURE__ */ jsx(ForksLabel, { ...repo })
		}),
		/* @__PURE__ */ jsx(ListItemMetadata, {
			className: ReposListItem_module_default.CompactItemAttributes,
			children: /* @__PURE__ */ jsx(StarsLabel, { ...repo })
		})
	] });
}
CompactItemMetadata.displayName = "CompactItemMetadata";
function TopicLabel({ topic, owner }) {
	return /* @__PURE__ */ jsx(Link, {
		href: orgTopicReposPath({
			topic,
			org: owner
		}),
		"data-testid": `${topic}-topic-link`,
		children: /* @__PURE__ */ jsx(Label, {
			size: "large",
			className: clsx(ReposListItem_module_default.TopicLabel),
			children: topic
		})
	}, topic);
}
TopicLabel.displayName = "TopicLabel";
function TopicsList(t0) {
	const $ = c(2);
	const { topics, owner, max, name, className } = t0;
	const shownTopics = topics.slice(0, max);
	const numberOfTopicsNotShown = Math.max(0, topics.length - max);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	let t1;
	if ($[0] !== owner) {
		t1 = (topic) => jsx(TopicLabel, {
			topic,
			owner
		}, topic);
		$[0] = owner;
		$[1] = t1;
	} else t1 = $[1];
	return jsxs("div", {
		className: clsx(ReposListItem_module_default.TopicsList, className),
		children: [
			shownTopics.map(t1),
			numberOfTopicsNotShown > 0 && jsxs(Label, {
				as: "button",
				"aria-label": `Show ${numberOfTopicsNotShown} more ${pluralizeTopic(numberOfTopicsNotShown)}`,
				className: ReposListItem_module_default.MoreTopicsButton,
				size: "large",
				variant: "secondary",
				onClick: () => setIsDialogOpen(true),
				children: ["+ ", numberOfTopicsNotShown]
			}),
			isDialogOpen && jsx(Dialog, {
				title: `Topics for ${owner}/${name}`,
				width: "small",
				position: {
					narrow: "bottom",
					wide: "center"
				},
				footerButtons: [{
					content: "Done",
					onClick: () => setIsDialogOpen(false)
				}],
				onClose: () => setIsDialogOpen(false),
				children: jsx("div", {
					className: ReposListItem_module_default.TopicsList,
					children: topics.map((topic_0) => jsx(TopicLabel, {
						topic: topic_0,
						owner
					}, topic_0))
				})
			})
		]
	});
}
TopicsList.displayName = "TopicsList";
function LanguageLabel({ primaryLanguage, truncate }) {
	if (!primaryLanguage) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: ReposListItem_module_default.LanguageLabelContainer,
		children: [/* @__PURE__ */ jsx(LanguageCircle, { color: primaryLanguage.color }), truncate ? /* @__PURE__ */ jsx(Truncate, {
			inline: true,
			title: primaryLanguage.name,
			className: ReposListItem_module_default.TruncatedPrimaryLanguageName,
			children: primaryLanguage.name
		}) : /* @__PURE__ */ jsx("span", {
			className: ReposListItem_module_default.PrimaryLanguageName,
			children: primaryLanguage.name
		})]
	});
}
LanguageLabel.displayName = "LanguageLabel";
function LicenseLabel({ license }) {
	if (!license) return null;
	return /* @__PURE__ */ jsx(IconLabel, {
		content: license,
		icon: LawIcon
	});
}
LicenseLabel.displayName = "LicenseLabel";
function StarsLabel({ starsCount, owner, name }) {
	const count = human(starsCount, { precision: getSignificanceBasedPrecision(starsCount) });
	const label = `${count} ${count === "1" ? "star" : "stars"}`;
	return /* @__PURE__ */ jsx(IconLabel, {
		"aria-label": label,
		content: count,
		icon: StarIcon,
		href: repoStargazersPath(owner, name)
	});
}
StarsLabel.displayName = "StarsLabel";
function ForksLabel({ forksCount, owner, name }) {
	const count = human(forksCount, { precision: getSignificanceBasedPrecision(forksCount) });
	const label = `${count} ${count === "1" ? "fork" : "forks"}`;
	return /* @__PURE__ */ jsx(IconLabel, {
		"aria-label": label,
		content: count,
		icon: RepoForkedIcon,
		href: forksListPath({
			owner,
			repo: name
		})
	});
}
ForksLabel.displayName = "ForksLabel";
function IssuesLabel({ issueCount, owner, name }) {
	const count = human(issueCount, { precision: getSignificanceBasedPrecision(issueCount) });
	const label = `${count} ${count === "1" ? "issue" : "issues"}`;
	return /* @__PURE__ */ jsx(IconLabel, {
		"aria-label": label,
		"data-testid": "issue-count",
		content: count,
		icon: IssueOpenedIcon,
		href: repoIssuesPath(owner, name)
	});
}
IssuesLabel.displayName = "IssuesLabel";
function PullRequestsLabel({ pullRequestCount, owner, name }) {
	const count = human(pullRequestCount, { precision: getSignificanceBasedPrecision(pullRequestCount) });
	const label = `${count} ${count === "1" ? "pull request" : "pull requests"}`;
	return /* @__PURE__ */ jsx(IconLabel, {
		"aria-label": label,
		"data-testid": "pull-request-count",
		content: count,
		icon: GitPullRequestIcon,
		href: repoPullRequestsPath(owner, name)
	});
}
PullRequestsLabel.displayName = "PullRequestsLabel";
function IconLabel({ icon: IconComponent, href, content, ...props }) {
	if (href) return /* @__PURE__ */ jsxs(Link, {
		...props,
		muted: true,
		href,
		className: ReposListItem_module_default.IconLabel,
		children: [/* @__PURE__ */ jsx(IconComponent, {}), content]
	});
	return /* @__PURE__ */ jsxs("div", {
		...props,
		className: ReposListItem_module_default.IconLabel,
		children: [/* @__PURE__ */ jsx(IconComponent, {}), content]
	});
}
IconLabel.displayName = "IconLabel";
function ParticipationSparkline(t0) {
	const $ = c(11);
	const { repo } = t0;
	const [participation, setParticipation] = useState(repo.participation);
	const isFetchingRef = useRef(false);
	let t1;
	if ($[0] !== participation || $[1] !== repo.name || $[2] !== repo.owner) {
		t1 = async function fetchParticipation() {
			if (participation || isFetchingRef.current) return;
			isFetchingRef.current = true;
			const response = await verifiedFetchJSON(repositoryParticipationPath({
				owner: repo.owner,
				repo: repo.name
			}));
			if (response.ok) {
				const bodyText = await response.text();
				setParticipation(bodyText.length > 0 ? JSON.parse(bodyText) : []);
			}
		};
		$[0] = participation;
		$[1] = repo.name;
		$[2] = repo.owner;
		$[3] = t1;
	} else t1 = $[3];
	const fetchParticipation = t1;
	let t2;
	if ($[4] !== fetchParticipation) {
		t2 = (entries) => {
			if (entries[0]?.isIntersecting) fetchParticipation();
		};
		$[4] = fetchParticipation;
		$[5] = t2;
	} else t2 = $[5];
	const sentinelRef = useIntersectionObserver(t2);
	let t3;
	if ($[6] !== participation || $[7] !== repo.name || $[8] !== repo.owner || $[9] !== sentinelRef) {
		t3 = participation ? participation.length === 0 ? jsx("div", { "data-testid": "empty-repo-sparkline" }) : jsx(Tooltip$1, {
			text: `${repo.owner}/${repo.name}’s past year of commit activity`,
			children: jsx("div", {
				className: ReposListItem_module_default.SparklineContainer,
				children: jsxs(Link, {
					className: "d-block",
					href: repoCommitActivityInsightsPath({
						owner: repo.owner,
						repo: repo.name
					}),
					"aria-label": `${repo.owner}/${repo.name}'s past year of commit activity`,
					target: "_blank",
					children: [jsx("div", {
						className: ReposListItem_module_default.HideOnSmallScreen,
						children: jsx(Sparkline, {
							uniqueKey: `${repo.owner}/${repo.name}`,
							points: participation
						})
					}), jsx("div", {
						className: ReposListItem_module_default.SmallScreenOnly,
						"data-listview-item-tiny-sparkline": true,
						children: jsx(Sparkline, {
							variant: "tiny",
							uniqueKey: `${repo.owner}/${repo.name}#tiny`,
							points: participation
						})
					})]
				})
			})
		}) : jsx("div", {
			ref: sentinelRef,
			role: "presentation"
		});
		$[6] = participation;
		$[7] = repo.name;
		$[8] = repo.owner;
		$[9] = sentinelRef;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
ParticipationSparkline.displayName = "ParticipationSparkline";
function FormattedDescription({ description, query, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx("repos-list-description width-full", className),
		children: /* @__PURE__ */ jsx(Truncate, {
			title: description,
			maxWidth: "100%",
			children: /* @__PURE__ */ jsx(SearchMatchText, {
				query,
				children: description
			})
		})
	});
}
FormattedDescription.displayName = "FormattedDescription";
function NwoTitle({ name, owner }) {
	return /* @__PURE__ */ jsxs("span", {
		className: ReposListItem_module_default.NwoTitle,
		children: [/* @__PURE__ */ jsxs("span", {
			className: ReposListItem_module_default.RepoOwner,
			children: [owner, "/"]
		}), /* @__PURE__ */ jsx("span", { children: name })]
	});
}
NwoTitle.displayName = "NwoTitle";
function RepoSettingsLink({ owner, name }) {
	return /* @__PURE__ */ jsx(Link, {
		muted: true,
		href: `${repositoryPath({
			owner,
			repo: name
		})}/settings`,
		"aria-label": "Repository settings",
		children: /* @__PURE__ */ jsx(GearIcon, {})
	});
}
RepoSettingsLink.displayName = "RepoSettingsLink";
function getRepoIcon(repo) {
	const { isFork, type } = repo;
	const lowerCaseType = type.toLowerCase();
	let icon;
	if (isFork) icon = RepoForkedIcon;
	else if (lowerCaseType.includes("mirror")) icon = RepoCloneIcon;
	else if (lowerCaseType.includes("private") || lowerCaseType.includes("internal")) icon = RepoLockedIcon;
	else icon = RepoIcon;
	return icon;
}
function pluralizeTopic(count) {
	return count === 1 ? "topic" : "topics";
}
function ReposList({ query, showNameWithOwner = false, compactMode, onCompactModeChanged, repositoryCount, repos, sortingItemSelected, onSortingItemSelect, defaultSortingKey, sortingOptions, noReposMessage, directionRestrictedKeys, listRef, linkAs }) {
	const metadata = /* @__PURE__ */ jsx(ListViewMetadata, {
		title: /* @__PURE__ */ jsx("span", {
			className: ReposList_module_default.ReposCountText,
			children: getDisplayReposCount(repositoryCount)
		}),
		densityToggle: /* @__PURE__ */ jsx(ListViewDensityToggle, {}),
		children: /* @__PURE__ */ jsx("div", {
			className: "mr-2",
			children: /* @__PURE__ */ jsx(SortingDropdown, {
				sortingItemSelected: sortingItemSelected || "",
				onSortingItemSelect,
				defaultSortingKey,
				sortingOptions,
				directionRestrictedKeys
			})
		})
	});
	return /* @__PURE__ */ jsx("div", {
		className: ReposList_module_default.ReposListContainer,
		"data-listview-repos-list": true,
		children: /* @__PURE__ */ jsx(ListView, {
			onVariantChange: (value) => onCompactModeChanged(value === "compact"),
			variant: compactMode ? "compact" : "default",
			metadata,
			title: "Repositories list",
			titleHeaderTag: "h2",
			listRef,
			children: repos.length > 0 ? repos.map((repo) => /* @__PURE__ */ jsx(ReposListItem, {
				repo,
				showNameWithOwner,
				query,
				linkAs
			}, `${repo.owner}/${repo.name}`)) : /* @__PURE__ */ jsx("li", { children: noReposMessage })
		})
	});
}
ReposList.displayName = "ReposList";
var ReposListLoadingSkeleton_module_default = {
	reposListContainer: "ReposListLoadingSkeleton-module_r6b4Dq_reposListContainer",
	skeletonDescription: "ReposListLoadingSkeleton-module_r6b4Dq_skeletonDescription",
	skeletonHeader: "ReposListLoadingSkeleton-module_r6b4Dq_skeletonHeader",
	skeletonItem: "ReposListLoadingSkeleton-module_r6b4Dq_skeletonItem",
	skeletonMetadata: "ReposListLoadingSkeleton-module_r6b4Dq_skeletonMetadata"
};
function ReposListLoadingSkeleton() {
	const metadata = /* @__PURE__ */ jsx(ListViewMetadata, {
		title: /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Loading repositories"
		}), /* @__PURE__ */ jsx(SkeletonBox, {
			width: "80px",
			height: "20px"
		})] }),
		children: /* @__PURE__ */ jsx(SkeletonBox, {
			width: "120px",
			height: "32px"
		})
	});
	return /* @__PURE__ */ jsx("div", {
		className: "tmp-my-3",
		children: /* @__PURE__ */ jsx("div", {
			className: ReposListLoadingSkeleton_module_default.reposListContainer,
			children: /* @__PURE__ */ jsx(ListView, {
				metadata,
				title: "Loading repositories",
				titleHeaderTag: "h2",
				children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("div", {
					className: ReposListLoadingSkeleton_module_default.skeletonItem,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: ReposListLoadingSkeleton_module_default.skeletonHeader,
							children: [/* @__PURE__ */ jsx(SkeletonBox, {
								width: "20px",
								height: "20px"
							}), /* @__PURE__ */ jsx(SkeletonBox, {
								width: "60%",
								height: "20px"
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: ReposListLoadingSkeleton_module_default.skeletonDescription,
							children: /* @__PURE__ */ jsx(SkeletonBox, {
								width: "80%",
								height: "16px"
							})
						}),
						/* @__PURE__ */ jsxs("div", {
							className: ReposListLoadingSkeleton_module_default.skeletonMetadata,
							children: [
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								}),
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								}),
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								})
							]
						})
					]
				}) }, `${i}`))
			})
		})
	});
}
ReposListLoadingSkeleton.displayName = "ReposListLoadingSkeleton";
function ReposShortcutSidebar(t0) {
	const $ = c(11);
	const { shortcuts, selectedLink, onSelectLink, onCreateView } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	const createViewButtonId = useId();
	let t1;
	if ($[0] !== createViewButtonId || $[1] !== onCreateView || $[2] !== onSelectLink || $[3] !== selectedLink || $[4] !== sendAnalyticsEvent || $[5] !== shortcuts) {
		let t2;
		if ($[7] !== onSelectLink || $[8] !== selectedLink || $[9] !== sendAnalyticsEvent) {
			t2 = (linkItem) => jsxs(NavList.Item, {
				"aria-current": selectedLink === linkItem.id && "page",
				href: `?q=${linkItem.query}`,
				onClick: getHandlerNavItemClick({
					onSelectLink,
					sendAnalyticsEvent,
					linkItem
				}),
				children: [jsx(NavList.LeadingVisual, { children: jsx(SidebarLinkIcon, {
					name: linkItem.icon,
					color: linkItem.color
				}) }), jsx(Truncate, {
					title: linkItem.name,
					maxWidth: "100%",
					children: linkItem.name
				})]
			}, linkItem.id);
			$[7] = onSelectLink;
			$[8] = selectedLink;
			$[9] = sendAnalyticsEvent;
			$[10] = t2;
		} else t2 = $[10];
		t1 = jsxs("div", { children: [jsxs("div", {
			className: ReposShortcutSidebar_module_default.headerRow,
			id: createViewButtonId,
			children: [jsx("span", {
				className: ReposShortcutSidebar_module_default.headerRowText,
				children: "Views"
			}), jsx(IconButton, {
				icon: PlusIcon,
				size: "small",
				variant: "invisible",
				onClick: onCreateView,
				"aria-label": "Create view"
			})]
		}), jsx(NavList, {
			"aria-labelledby": createViewButtonId,
			className: ReposShortcutSidebar_module_default.savedViewsList,
			children: shortcuts.map(t2)
		})] });
		$[0] = createViewButtonId;
		$[1] = onCreateView;
		$[2] = onSelectLink;
		$[3] = selectedLink;
		$[4] = sendAnalyticsEvent;
		$[5] = shortcuts;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
ReposShortcutSidebar.displayName = "ReposShortcutSidebar";
/**
* Hook to manage and persist the compact mode setting for repository lists.
* @param compactMode The initial compact mode value.
* @param preferenceKey The key to use for the FormData.
*/
function useCompactModeSetting(compactMode, preferenceKey) {
	const $ = c(2);
	const savedCompactModeRef = useRef(compactMode);
	let t0;
	if ($[0] !== preferenceKey) {
		t0 = { updateCompactModeSetting: function updateCompactModeSetting(value) {
			if (savedCompactModeRef.current === value) return;
			savedCompactModeRef.current = value;
			const formData = new FormData();
			formData.set(preferenceKey, value.toString());
			verifiedFetch("/repos/preferences", {
				method: "PUT",
				body: formData
			});
		} };
		$[0] = preferenceKey;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
var sortingOptionsWithRelevance = {
	relevance: {
		label: "Relevance",
		defaultDirection: "desc",
		icon: PersonIcon
	},
	updated: {
		label: "Last pushed",
		defaultDirection: "desc",
		icon: RepoPushIcon
	},
	name: {
		label: "Name",
		defaultDirection: "asc",
		icon: TypographyIcon
	},
	stars: {
		label: "Stars",
		defaultDirection: "desc",
		icon: StarIcon
	}
};
var reposFinderPageRoute = reposFinderAppBuilder.createQueryRouteConfig("reposFinderPageRoute", {
	path: "/repos",
	queries: [mainQuery({ queryDeps: ({ pathname, searchParams }) => ({
		pathname,
		searchParams: {
			q: searchParams.get("q") || "",
			page: searchParams.get("page") || "1"
		}
	}) })]
});
export { ReposShortcutSidebar as a, reposFinderPageRoute as c, ReposListLoadingSkeleton as i, sortingOptionsWithRelevance as l, ListSidebarCollapsedButton as n, getScreenReaderMessage as o, ReposList as r, reposFinderLayoutRoute as s, ListSidebar as t, useCompactModeSetting as u };
