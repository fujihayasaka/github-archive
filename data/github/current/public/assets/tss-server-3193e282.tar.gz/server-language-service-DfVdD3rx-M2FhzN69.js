performance.mark("js-parse-end:server-language-service-DfVdD3rx-M2FhzN69.js");
import { t as getDocumentUri } from "./server-document-uri-CiR3FLCW-BF5w9Niz.js";
import { n as md2html } from "./server-md2html-TgcTyYQC-DzwxtslQ.js";
import { complete, hover, validate } from "@actions/languageservice";
import { clearCacheEntry } from "@actions/languageservice/utils/workflow-cache";
import { TextDocument } from "vscode-languageserver-textdocument";
import { FeatureFlags } from "@actions/expressions";
import { CompletionItemKind, InsertTextFormat } from "vscode-languageserver-types";
performance.mark("js-parse-end:language-service-DfVdD3rx.js");
/**
* Create a text document for the language service, clearing any cached parse results first.
* The language service caches parsed workflows by URI, so we must clear the cache
* to ensure fresh parsing when the document content changes.
*/
function createTextDocument(content) {
	const documentUri = getDocumentUri();
	clearCacheEntry(documentUri);
	return TextDocument.create(documentUri, "yaml", 1, content);
}
/**
* Autocomplete implementation using @actions/languageservice
*/
async function workflowAutocompleteContextWithLanguageService(context, allowCaseFunction = false, allowCronTimezone = false) {
	try {
		const textDocument = createTextDocument(context.state.doc.toString());
		const line = context.state.doc.lineAt(context.pos);
		return convertLanguageServiceCompletions(await complete(textDocument, {
			line: line.number - 1,
			character: context.pos - line.from
		}, { featureFlags: new FeatureFlags({
			allowCaseFunction,
			allowCronTimezone
		}) }), context.state.doc, context.pos);
	} catch (error) {
		console.error("[Language Service] Autocomplete error:", error);
		return null;
	}
}
/**
* Validation implementation using @actions/languageservice
*/
async function workflowYamlLintSourceWithLanguageService(view, allowCronTimezone = false) {
	try {
		return convertLanguageServiceDiagnostics(await validate(createTextDocument(view.state.doc.toString()), { featureFlags: new FeatureFlags({ allowCronTimezone }) }), view);
	} catch (error) {
		console.error("[Language Service] Validation error:", error);
		return [];
	}
}
/**
* Hover implementation using @actions/languageservice
* Returns hover information (e.g., cron expression descriptions, context documentation)
*/
async function workflowHoverWithLanguageService(view, pos) {
	try {
		const textDocument = createTextDocument(view.state.doc.toString());
		const line = view.state.doc.lineAt(pos);
		const hoverResult = await hover(textDocument, {
			line: line.number - 1,
			character: pos - line.from
		});
		if (!hoverResult || !hoverResult.contents) return null;
		let startPos = pos;
		let endPos = pos;
		if (hoverResult.range) {
			const startLine = view.state.doc.line(hoverResult.range.start.line + 1);
			const endLine = view.state.doc.line(hoverResult.range.end.line + 1);
			startPos = startLine.from + hoverResult.range.start.character;
			endPos = endLine.from + hoverResult.range.end.character;
		}
		return {
			pos: startPos,
			end: endPos,
			dom: createHoverTooltip(hoverResult)
		};
	} catch (error) {
		console.error("[Language Service] Hover error:", error);
		return null;
	}
}
/**
* Create a styled tooltip element for hover information
*/
function createHoverTooltip(hoverResult) {
	const tooltip = document.createElement("div");
	tooltip.setAttribute("role", "tooltip");
	tooltip.classList.add("Box", "Box--condensed", "text-small", "color-shadow-large");
	const row = document.createElement("div");
	row.classList.add("Box-row", "markdown-body", "f6");
	const contents = hoverResult.contents;
	let markdownContent;
	if (typeof contents === "string") markdownContent = contents;
	else if ("value" in contents) markdownContent = contents.value;
	else if (Array.isArray(contents)) markdownContent = contents.map((c) => typeof c === "string" ? c : c.value).join("\n");
	else markdownContent = "";
	row.innerHTML = md2html(markdownContent);
	tooltip.appendChild(row);
	return tooltip;
}
/**
* Expand LSP snippet syntax to plain text by replacing tabstop placeholders
* with their default values.
*
* Converts `${1:placeholder}` to just `placeholder`.
* Converts `$1` or `${1}` (no placeholder) to empty string.
* Unescapes `\$` to `$`, `\}` to `}`, and `\\` to `\`.
*/
function expandSnippetPlaceholders(snippetText) {
	let result = snippetText.replace(/\$\{\d+:([^}]*)\}/g, "$1");
	result = result.replace(/\$\d+|\$\{\d+\}/g, "");
	result = result.replace(/\\(.)/g, "$1");
	return { text: result };
}
/**
* Convert language service CompletionItems to CodeMirror CompletionResult
*/
function convertLanguageServiceCompletions(items, doc, cursorPos) {
	const cursorLine = doc.lineAt(cursorPos);
	const cursorLineNumber = cursorLine.number - 1;
	let wordStart = cursorPos - cursorLine.from;
	const lineText = cursorLine.text;
	while (wordStart > 0 && /[a-zA-Z0-9_-]/.test(lineText[wordStart - 1])) wordStart--;
	return {
		from: cursorLine.from + wordStart,
		validFor: /^[\w-]*$/,
		options: items.filter((item) => {
			if (item.textEdit && "range" in item.textEdit) {
				if (item.textEdit.range.start.line !== cursorLineNumber) return false;
			}
			return true;
		}).map((item) => {
			const description = typeof item.documentation === "string" ? item.documentation : item.documentation?.value;
			if (item.insertTextFormat === InsertTextFormat.Snippet && item.textEdit && "range" in item.textEdit) {
				const textEdit = item.textEdit;
				const from = doc.line(textEdit.range.start.line + 1).from + textEdit.range.start.character;
				const baseIndent = lineText.match(/^(\s*)/)?.[1] ?? "";
				const { text: expandedText } = expandSnippetPlaceholders(textEdit.newText);
				let newText = expandedText;
				if (newText.includes("\n") && baseIndent) newText = newText.replace(/\n/g, `\n${baseIndent}`);
				return {
					label: item.label,
					detail: item.labelDetails?.description,
					sortText: item.sortText ?? item.label,
					type: completionKindToType(item.kind),
					info: description ? () => createCompletionInfoTooltip(description) : void 0,
					insertedText: newText,
					skipChaining: true,
					apply: (view, _completion, _from, currentTo) => {
						view.dispatch({
							changes: [{
								from,
								to: currentTo,
								insert: newText
							}],
							selection: { anchor: from }
						});
					}
				};
			}
			if (item.textEdit && "range" in item.textEdit) {
				const textEdit = item.textEdit;
				const from = doc.line(textEdit.range.start.line + 1).from + textEdit.range.start.character;
				let newText = textEdit.newText;
				const baseIndent = lineText.match(/^(\s*)/)?.[1] ?? "";
				if (newText.includes("\n") && baseIndent) newText = newText.replace(/\n/g, `\n${baseIndent}`);
				const additionalChanges = (item.additionalTextEdits ?? []).map((edit) => {
					const editStartLine = doc.line(edit.range.start.line + 1);
					const editEndLine = doc.line(edit.range.end.line + 1);
					return {
						from: editStartLine.from + edit.range.start.character,
						to: editEndLine.from + edit.range.end.character,
						insert: edit.newText
					};
				});
				let positionShift = 0;
				for (const change of additionalChanges) if (change.to <= from) {
					const removed = change.to - change.from;
					const added = change.insert.length;
					positionShift += added - removed;
				}
				return {
					label: item.label,
					detail: item.labelDetails?.description,
					sortText: item.sortText ?? item.label,
					type: completionKindToType(item.kind),
					info: description ? () => createCompletionInfoTooltip(description) : void 0,
					insertedText: newText,
					apply: (view, _completion, _from, currentTo) => {
						const changes = [{
							from,
							to: currentTo,
							insert: newText
						}, ...additionalChanges];
						view.dispatch({
							changes,
							selection: { anchor: from + positionShift + newText.length }
						});
					}
				};
			}
			return {
				label: item.label,
				detail: item.labelDetails?.description,
				sortText: item.sortText ?? item.label,
				type: completionKindToType(item.kind),
				info: description ? () => createCompletionInfoTooltip(description) : void 0,
				apply: item.insertText || item.label
			};
		})
	};
}
/**
* Create a styled tooltip element for completion info/documentation
*/
function createCompletionInfoTooltip(description) {
	const tooltip = document.createElement("div");
	tooltip.setAttribute("role", "tooltip");
	tooltip.classList.add("Box", "Box--condensed", "text-small", "color-shadow-large");
	const row = document.createElement("div");
	row.classList.add("Box-row", "markdown-body", "f6");
	row.innerHTML = md2html(description);
	tooltip.appendChild(row);
	return tooltip;
}
/**
* Convert LSP CompletionItemKind to CodeMirror completion type
*/
function completionKindToType(kind) {
	switch (kind) {
		case CompletionItemKind.Function: return "function";
		case CompletionItemKind.Constructor:
		case CompletionItemKind.Field:
		case CompletionItemKind.Property: return "property";
		case CompletionItemKind.Variable: return "variable";
		case CompletionItemKind.Class:
		case CompletionItemKind.Interface: return "type";
		case CompletionItemKind.Module: return "namespace";
		case CompletionItemKind.Keyword: return "keyword";
		case CompletionItemKind.Snippet: return "snippet";
		case CompletionItemKind.Text:
		case CompletionItemKind.Color:
		case CompletionItemKind.File: return "text";
		default: return "property";
	}
}
/**
* Create a styled tooltip element for a diagnostic message
*/
function createDiagnosticTooltip(diag) {
	const tooltip = document.createElement("div");
	tooltip.setAttribute("role", "tooltip");
	tooltip.classList.add("Box", "Box--condensed", "text-small", "color-shadow-large");
	const row = document.createElement("div");
	row.classList.add("Box-row", "markdown-body", "f6");
	const paragraph = document.createElement("p");
	paragraph.classList.add("mb-0");
	paragraph.textContent = diag.message;
	row.appendChild(paragraph);
	if (diag.codeDescription?.href) {
		const linkParagraph = document.createElement("p");
		linkParagraph.classList.add("mb-0", "mt-2");
		if (diag.code) {
			const textNode = document.createTextNode("Learn more: ");
			linkParagraph.appendChild(textNode);
			const link = document.createElement("a");
			link.href = diag.codeDescription.href;
			link.target = "_blank";
			link.rel = "noopener noreferrer";
			link.textContent = String(diag.code);
			link.classList.add("Link");
			const srText = document.createElement("span");
			srText.classList.add("sr-only");
			srText.textContent = " (opens in new tab)";
			link.appendChild(srText);
			linkParagraph.appendChild(link);
		} else {
			const link = document.createElement("a");
			link.href = diag.codeDescription.href;
			link.target = "_blank";
			link.rel = "noopener noreferrer";
			link.textContent = "Learn more";
			link.classList.add("Link");
			const srText = document.createElement("span");
			srText.classList.add("sr-only");
			srText.textContent = " (opens in new tab)";
			link.appendChild(srText);
			linkParagraph.appendChild(link);
		}
		row.appendChild(linkParagraph);
	}
	tooltip.appendChild(row);
	return tooltip;
}
/**
* Convert language service Diagnostics to CodeMirror Diagnostics
*/
function convertLanguageServiceDiagnostics(lspDiagnostics, view) {
	const doc = view.state.doc;
	const maxLine = doc.lines;
	return lspDiagnostics.filter((diag) => {
		return diag.range.start.line < maxLine && diag.range.end.line < maxLine;
	}).map((diag) => {
		const startLine = doc.line(diag.range.start.line + 1);
		const endLine = doc.line(diag.range.end.line + 1);
		const from = startLine.from + Math.min(diag.range.start.character, startLine.length);
		const to = endLine.from + Math.min(diag.range.end.character, endLine.length);
		return {
			from,
			to: Math.max(from, to),
			severity: diag.severity === 2 ? "warning" : diag.severity === 3 || diag.severity === 4 ? "info" : "error",
			message: "",
			renderMessage: () => createDiagnosticTooltip(diag)
		};
	});
}
export { workflowAutocompleteContextWithLanguageService, workflowHoverWithLanguageService, workflowYamlLintSourceWithLanguageService };
