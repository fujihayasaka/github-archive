import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { o as isStaff, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { AnalyticsClient, getOptionsFromMeta } from "@github/hydro-analytics-client";
var EVENT_BADGE_STYLE = "background: #8957e5; color: #fff; padding: 2px 6px; border-radius: 3px; font-weight: bold; font-size: 11px;";
var LABEL_STYLE = "font-weight: bold; font-size: 12px;";
var BASE_CONTEXT_KEYS = new Set([
	"actor_id",
	"actor_login",
	"actor_hash",
	"referrer",
	"request_id",
	"visitor_id",
	"region_edge",
	"region_render",
	"staff",
	"service",
	"react",
	"app_name",
	"page",
	"title"
]);
var WEB_VITAL_KEYS = new Set([
	"hpc",
	"ttfb",
	"fcp",
	"lcp",
	"fid",
	"inp",
	"cls",
	"elementtiming",
	"longTasks",
	"longAnimationFrames"
]);
var WEB_VITAL_META_KEYS = new Set([
	"react",
	"reactApp",
	"reactPartials",
	"featureFlags",
	"ssr",
	"controller",
	"action",
	"routePattern",
	"cpu",
	"domNodes",
	"previousDomNodes",
	"navigationId"
]);
function tryParseJSON(str) {
	try {
		return JSON.parse(str);
	} catch {
		return str;
	}
}
function formatHeaderValue(value) {
	const parsed = tryParseJSON(value);
	return typeof parsed === "number" ? String(Math.round(parsed)) : String(parsed);
}
/**
* Log a sendEvent (Hydro) call with a styled collapsed console group.
* Shows target and custom fields prominently; base context is hidden in a sub-group.
*/
function logSendEvent(type, context = {}) {
	const customEntries = [];
	for (const [key, value] of Object.entries(context)) if (!BASE_CONTEXT_KEYS.has(key)) customEntries.push([key, tryParseJSON(value)]);
	const headerValue = context.value !== void 0 ? ` ${formatHeaderValue(context.value)}` : "";
	console.groupCollapsed(`%cevent%c ${type}${headerValue}`, EVENT_BADGE_STYLE, LABEL_STYLE);
	if (type === "web-vital") logWebVitalEvent(customEntries);
	else {
		console.table(Object.fromEntries(customEntries.map(([k, v]) => [k, { value: v }])));
		console.log(Object.fromEntries(customEntries));
	}
	console.groupEnd();
}
function logWebVitalEvent(entries) {
	for (const [key, value] of entries) if (WEB_VITAL_KEYS.has(key)) {
		console.log(`%c${key}`, LABEL_STYLE);
		console.table(value);
	} else if (!WEB_VITAL_META_KEYS.has(key)) console.log(`${key}:`, value);
}
var { getItem } = safeStorage("localStorage");
var dimensionPrefix = "dimension_";
var hydroAnalyticsClient;
var MARKETING_PARAMS = [
	"utm_source",
	"utm_medium",
	"utm_campaign",
	"utm_term",
	"utm_content",
	"scid"
];
function safeGetOptionsFromMeta(prefix) {
	try {
		return getOptionsFromMeta(prefix);
	} catch {
		return;
	}
}
var initOptions = safeGetOptionsFromMeta("octolytics");
if (initOptions) {
	delete initOptions.baseContext;
	initOptions.idleTimeout = 5e3;
	initOptions.maxBatchSize = 50;
	hydroAnalyticsClient = new AnalyticsClient(initOptions);
}
function extendBaseContext(context) {
	const baseContext = safeGetOptionsFromMeta("octolytics")?.baseContext ?? {};
	if (baseContext) {
		delete baseContext.app_id;
		delete baseContext.event_url;
		delete baseContext.host;
		for (const [key, value] of Object.entries(baseContext)) if (key.startsWith(dimensionPrefix)) {
			baseContext[key.replace(dimensionPrefix, "")] = value;
			delete baseContext[key];
		}
	}
	const visitorMeta = ssrSafeDocument?.querySelector("meta[name=visitor-payload]");
	if (visitorMeta) {
		const visitorHash = JSON.parse(atob(visitorMeta.content));
		Object.assign(baseContext, visitorHash);
	}
	const urlParams = new URLSearchParams(window.location.search);
	for (const [key, value] of urlParams) if (MARKETING_PARAMS.includes(key.toLowerCase())) baseContext[key] = value;
	baseContext.staff = isStaff().toString();
	return Object.assign(baseContext, context);
}
function currentCatalogService() {
	return ssrSafeDocument?.head?.querySelector("meta[name=\"current-catalog-service\"]")?.content;
}
function sendEvent(type, context = {}, { batched = false } = {}) {
	const service = currentCatalogService();
	const cleanContext = service ? { service } : {};
	for (const [key, value] of Object.entries(context)) if (value !== void 0 && value !== null) cleanContext[key] = `${value}`;
	if (hydroAnalyticsClient) {
		const typeWithFallback = type || "unknown";
		const fullContext = extendBaseContext(cleanContext);
		if (batched) hydroAnalyticsClient.sendBatchedEvent(typeWithFallback, extendBaseContext(cleanContext));
		else hydroAnalyticsClient.sendEvent(typeWithFallback, extendBaseContext(cleanContext));
		if (getItem("stats-dev-logger") === "true") logSendEvent(typeWithFallback, fullContext);
	}
}
function stringifyObjectValues(obj) {
	return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, JSON.stringify(v)]));
}
export { stringifyObjectValues as n, sendEvent as t };
