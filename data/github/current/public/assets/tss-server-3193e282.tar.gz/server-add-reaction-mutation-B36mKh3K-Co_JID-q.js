import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v4 = [v3], v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "addReactionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddReactionPayload",
				"kind": "LinkedField",
				"name": "addReaction",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subject",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ReactionViewerRelayGroups"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "addReactionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddReactionPayload",
				"kind": "LinkedField",
				"name": "addReaction",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subject",
					"plural": false,
					"selections": [
						v2,
						{
							"kind": "TypeDiscriminator",
							"abstractKey": "__isReactable"
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "ReactionGroup",
							"kind": "LinkedField",
							"name": "reactionGroups",
							"plural": true,
							"selections": [
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "content",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "viewerHasReacted",
									"storageKey": null
								},
								{
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 5
									}],
									"concreteType": "ReactorConnection",
									"kind": "LinkedField",
									"name": "reactors",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "totalCount",
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											v2,
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "User",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v3,
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "isCopilot",
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "isAgent",
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "displayName",
														"storageKey": null
													}
												],
												"type": "Bot",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "Organization",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "Mannequin",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [v5],
												"type": "Node",
												"abstractKey": "__isNode"
											}
										],
										"storageKey": null
									}],
									"storageKey": "reactors(first:5)"
								}
							],
							"storageKey": null
						},
						v5
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "686efd568fb637fee7e532b3356444b1",
			"metadata": {},
			"name": "addReactionMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "504ef43df20e9ee96a023f421682e18d";
var import_react_relay = require_react_relay();
function addReactionMutation({ environment, input: { subject, content }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		variables: { input: {
			subjectId: subject,
			content
		} },
		optimisticUpdater: (store) => {
			const subjectRecord = store.get(subject);
			if (!subjectRecord) return;
			const reactionGroups = subjectRecord.getLinkedRecords("reactionGroups");
			if (!reactionGroups) return;
			const reactionGroupIndex = reactionGroups.findIndex((r) => r.getValue("content") === content);
			const reactionGroup = reactionGroups[reactionGroupIndex];
			if (reactionGroup) {
				reactionGroup.setValue(true, "viewerHasReacted");
				const connectionId = `client:${subject}:reactionGroups:${reactionGroupIndex}:reactors(first:5)`;
				const connection = store.get(connectionId);
				if (connection) {
					const totalCount = connection.getValue("totalCount");
					connection.setValue(totalCount ? totalCount + 1 : 1, "totalCount");
				}
			}
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
export { addReactionMutation as t };
