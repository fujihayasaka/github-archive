import { t as sanitize } from "./server-sanitize.server-b2h7HJ0t-CE6bPZBY.js";
import { marked } from "marked";
var DompurifyConfig = {
	FORBID_TAGS: ["style"],
	FORBID_ATTR: [
		"class",
		"id",
		"style"
	],
	ALLOW_DATA_ATTR: false,
	ALLOWED_TAGS: [
		"h1",
		"h2",
		"h3",
		"h4",
		"h5",
		"h6",
		"h7",
		"h8",
		"br",
		"b",
		"i",
		"strong",
		"em",
		"a",
		"pre",
		"code",
		"img",
		"tt",
		"div",
		"span",
		"ins",
		"del",
		"sup",
		"sub",
		"p",
		"ol",
		"ul",
		"table",
		"thead",
		"tbody",
		"tfoot",
		"blockquote",
		"dl",
		"dt",
		"dd",
		"kbd",
		"q",
		"samp",
		"var",
		"hr",
		"ruby",
		"rt",
		"rp",
		"li",
		"tr",
		"td",
		"th",
		"s",
		"strike",
		"summary",
		"details",
		"picture",
		"source"
	]
};
function canBeOptimisticallyParsed(markdown) {
	return !/^\s*[-*+] \[[ xX]\] .*/m.test(markdown);
}
function md2html(markdown) {
	try {
		return sanitize(marked.parse(markdown, {
			gfm: true,
			breaks: true,
			silent: true
		}), DompurifyConfig);
	} catch {
		return "";
	}
}
export { md2html as n, canBeOptimisticallyParsed as t };
