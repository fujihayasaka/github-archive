import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { an as IconButton, i as AgentIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { Suspense, lazy, useCallback, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
var LazyNewAgentTaskButtonContent = lazy(() => import("./server-NewAgentTaskButtonContent-enp3d83C-CFWITa0C.js").then((m) => ({ default: m.NewAgentTaskButtonContent })));
LazyNewAgentTaskButtonContent.displayName = "LazyNewAgentTaskButtonContent";
function NewAgentTaskButton({ isIconButton, icon = AgentIcon, label = "New agent session", onOpen, onClose, setContentOpen, open, currentRepo, currentReference, hideRepoSelector, eventType, size, tooltipDirection, variant, decoupledModeEnabled }) {
	const [isOpen, setOpen] = useState(!!open);
	const { isServer: isSSR } = useRuntimeEnvironment();
	const buttonRef = useRef(null);
	const handleOpen = useCallback(() => {
		setOpen(true);
		onOpen?.();
	}, [onOpen]);
	const handleClose = useCallback(() => {
		setOpen(false);
		onClose?.();
		setContentOpen?.(false);
	}, [onClose, setContentOpen]);
	const dialogTitle = currentRepo ? `${label} in ${currentRepo.ownerLogin}/${currentRepo.name}` : label;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [isIconButton ? /* @__PURE__ */ jsx(IconButton, {
		ref: buttonRef,
		icon,
		"aria-label": label,
		size,
		tooltipDirection,
		variant,
		onClick: handleOpen
	}) : /* @__PURE__ */ jsx(ButtonComponent, {
		ref: buttonRef,
		onClick: handleOpen,
		leadingVisual: icon,
		size,
		children: label
	}), isOpen && !isSSR && /* @__PURE__ */ jsx(Dialog, {
		title: dialogTitle,
		onClose: handleClose,
		returnFocusRef: buttonRef,
		position: { narrow: "fullscreen" },
		children: /* @__PURE__ */ jsx(Dialog.Body, {
			className: "p-0",
			children: /* @__PURE__ */ jsx(Suspense, {
				fallback: /* @__PURE__ */ jsx(FallbackContent, {}),
				children: /* @__PURE__ */ jsx(LazyNewAgentTaskButtonContent, {
					currentRepo,
					currentReference,
					hideRepoSelector,
					setOpen: handleClose,
					eventType,
					decoupledModeEnabled
				})
			})
		})
	})] });
}
NewAgentTaskButton.displayName = "NewAgentTaskButton";
function FallbackContent() {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-column flex-items-center tmp-p-6",
		children: /* @__PURE__ */ jsx(Spinner, { srText: "Loading…" })
	});
}
FallbackContent.displayName = "FallbackContent";
export { NewAgentTaskButton as t };
