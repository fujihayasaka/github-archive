import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { _i as Truncate, _r as RepoLockedIcon, an as IconButton, gr as RepoIcon, hi as TriangleDownIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { r as ItemPicker } from "./server-ItemPicker-ILw4RsMA-BLDIejLk.js";
import React, { useCallback, useEffect, useEffectEvent, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
var ReposSelector_module_default = {
	invisibleWithBorder: "ReposSelector-module_PNoOIW_invisibleWithBorder",
	selected: "ReposSelector-module_PNoOIW_selected"
};
function ReposSelector({ currentSelection, repositoryLoader, onSelect, selectionVariant, selectAllOption, additionalButtonProps, buttonText: _buttonText = "", width, truncateMaxWidth, disableItemTruncation = false, height, fullscreenOnNarrow, defaultOwner, onLoad, loadingElement, liveSelection = false, onOpen, onClose, responsiveStyle = "full", iconOnly = false, anchorSide, tooltipDirection, portalContainerName, overlayPosition, secondaryAction }) {
	const [filterText, setFilterText] = useState("");
	const [filteredRepos, setFilteredRepos] = useState([]);
	const [isLoadingRepos, setIsLoadingRepos] = useState(true);
	const [initialLoadComplete, setInitialLoadComplete] = useState(false);
	const loadRepos = useEffectEvent(async (filter) => {
		try {
			const response = await repositoryLoader(filter, defaultOwner);
			setFilteredRepos(response);
			onLoad?.(response);
		} catch {}
		setIsLoadingRepos(false);
		setInitialLoadComplete(true);
	});
	useEffect(() => {
		setIsLoadingRepos(true);
		const timeoutId = setTimeout(() => {
			loadRepos(filterText);
		}, 200);
		return () => clearTimeout(timeoutId);
	}, [filterText]);
	const selectRepos = useCallback((repos) => {
		if (selectionVariant === "single") if (!repos[0] || repos[0]._all) onSelect(void 0);
		else onSelect(repos[0]);
		else onSelect(repos);
	}, [selectionVariant, onSelect]);
	const selected = useMemo(() => {
		return selectionVariant === "multiple" ? currentSelection || [] : currentSelection ? [currentSelection] : [];
	}, [selectionVariant, currentSelection]);
	const convertToItemProps = useCallback((repo) => {
		const truncationCharLimit = width === "medium" ? 35 : width === "large" ? 60 : 24;
		let truncatedRepoName = void 0;
		if (!disableItemTruncation && repo.name.length > truncationCharLimit) truncatedRepoName = `${repo.name.substring(0, truncationCharLimit)}...`;
		if (repo._all) return {
			id: repo.name,
			text: "All repositories",
			source: repo,
			groupId: "all"
		};
		return {
			id: repo.name,
			text: truncatedRepoName || repo.name,
			source: repo,
			groupId: "select",
			disabled: repo.enabled === false,
			leadingVisual: () => {
				if (repo.private) return /* @__PURE__ */ jsx(RepoLockedIcon, { size: 16 });
				else return /* @__PURE__ */ jsx(RepoIcon, { size: 16 });
			}
		};
	}, [width, disableItemTruncation]);
	const getItemKey = useCallback((repo_0) => repo_0.name, []);
	const items = useMemo(() => {
		const memoItems = [];
		memoItems.push(...filteredRepos);
		if (selectAllOption) memoItems.push({
			name: "$all$",
			_all: true
		});
		return memoItems;
	}, [filteredRepos, selectAllOption]);
	let buttonText = _buttonText;
	let buttonIcon = RepoIcon;
	if (!buttonText) if (selectionVariant === "multiple") buttonText = selected.length > 0 ? `${selected.length} repositor${selected.length > 1 ? "ies" : "y"}` : "Select repositories";
	else if (selected.length > 0 && selected[0]) {
		buttonText = selected[0].name;
		buttonIcon = selected[0].private ? RepoLockedIcon : RepoIcon;
	} else if (selectAllOption) buttonText = "All repositories";
	else buttonText = "Select a repository";
	const isNarrow = useResponsiveValue(responsiveStyle === "icon-on-mobile" ? { narrow: true } : { narrow: false }, false);
	const showIconOnly = iconOnly || isNarrow;
	return loadingElement && isLoadingRepos && !currentSelection && !initialLoadComplete ? loadingElement : /* @__PURE__ */ jsx(ItemPicker, {
		renderAnchor: ({ "aria-labelledby": ariaLabelledBy, ...anchorProps }) => {
			const { "aria-label": _ariaLabel, ...iconAnchorProps } = anchorProps;
			const iconButtonAriaLabel = additionalButtonProps?.["aria-label"] ?? _ariaLabel ?? buttonText;
			return showIconOnly ? /* @__PURE__ */ jsx(IconButton, {
				variant: "invisible",
				...ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": iconButtonAriaLabel },
				icon: additionalButtonProps?.leadingVisual || buttonIcon,
				...iconAnchorProps,
				className: `${ReposSelector_module_default.invisibleWithBorder}${selected.length ? ` ${ReposSelector_module_default.selected}` : ""}`,
				tooltipDirection
			}) : /* @__PURE__ */ jsx(ButtonComponent, {
				variant: responsiveStyle === "icon-on-mobile" ? "invisible" : void 0,
				leadingVisual: buttonIcon,
				trailingAction: TriangleDownIcon,
				"aria-labelledby": ariaLabelledBy,
				...anchorProps,
				...additionalButtonProps,
				className: `${additionalButtonProps?.className}${responsiveStyle === "icon-on-mobile" ? ` ${ReposSelector_module_default.invisibleWithBorder}` : ""}`,
				children: /* @__PURE__ */ jsx(Truncate, {
					title: buttonText,
					maxWidth: truncateMaxWidth ?? 195,
					children: buttonText
				})
			});
		},
		placeholderText: "Search",
		items,
		loading: isLoadingRepos,
		groups: selectAllOption ? [{ groupId: "all" }, { groupId: "select" }] : [],
		selectionVariant,
		initialSelectedItems: selected,
		onSelectionChange: selectRepos,
		onLiveSelectionChange: selectionVariant === "multiple" && liveSelection ? selectRepos : void 0,
		filterItems: setFilterText,
		getItemKey,
		convertToItemProps,
		title: "Select a repository",
		width,
		height,
		responsiveOnNarrow: fullscreenOnNarrow,
		onOpen,
		onClose,
		anchorSide,
		portalContainerName,
		overlayPosition,
		secondaryAction
	});
}
ReposSelector.displayName = "ReposSelector";
export { ReposSelector as t };
