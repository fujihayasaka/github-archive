import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ht as GitBranchIcon, Tn as LockIcon, Zn as PencilIcon, bn as Link, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var EditingForkBanner_module_default = { Flash: "EditingForkBanner-module_hCzdwW_Flash" };
function EditingForkBanner({ forkName, forkOwner, canCreatePullRequest }) {
	return /* @__PURE__ */ jsxs(Flash, {
		"aria-live": "polite",
		className: EditingForkBanner_module_default.Flash,
		children: [
			"You’re making changes in a project you don’t have write access to. Submitting a change will write it to a new branch in your fork ",
			/* @__PURE__ */ jsx("b", { children: `${forkOwner}/${forkName}` }),
			canCreatePullRequest ?? true ? ", so you can send a pull request" : "",
			"."
		]
	});
}
EditingForkBanner.displayName = "EditingForkBanner";
var EditIssues_module_default = {
	Banner: "EditIssues-module_oPj0Iq_Banner",
	BannerDescription: "EditIssues-module_oPj0Iq_BannerDescription",
	Box: "EditIssues-module_oPj0Iq_Box",
	Octicon: "EditIssues-module_oPj0Iq_Octicon",
	Text: "EditIssues-module_oPj0Iq_Text",
	Text_1: "EditIssues-module_oPj0Iq_Text_1"
};
var PullRequestInfoBanner = ({ webCommitInfo, repositoryName }) => {
	const pullRequestEnabled = webCommitInfo.pullRequestEnabled ?? true;
	const supportLink = webCommitInfo.supportFileUrl ? /* @__PURE__ */ jsxs(Fragment, { children: [
		" ",
		"If you need help, view the ",
		/* @__PURE__ */ jsx("b", { children: repositoryName }),
		" ",
		/* @__PURE__ */ jsx(Link, {
			inline: true,
			href: webCommitInfo.supportFileUrl,
			children: "support resources"
		}),
		"."
	] }) : null;
	if (pullRequestEnabled) return /* @__PURE__ */ jsx(Banner, {
		className: EditIssues_module_default.Banner,
		title: "You are not authorized to create pull requests in this repository",
		description: /* @__PURE__ */ jsxs("p", {
			className: EditIssues_module_default.BannerDescription,
			children: ["The repository owner has restricted who can propose changes.", supportLink]
		})
	});
	return /* @__PURE__ */ jsx(Banner, {
		className: EditIssues_module_default.Banner,
		title: "Pull requests cannot be created in this repository",
		description: /* @__PURE__ */ jsxs("p", {
			className: EditIssues_module_default.BannerDescription,
			children: ["The repository owner has disabled pull requests.", supportLink]
		})
	});
};
PullRequestInfoBanner.displayName = "PullRequestInfoBanner";
function EditIssues(t0) {
	const $ = c(15);
	const { binary, helpUrl, webCommitInfo, repositoryName } = t0;
	const { shouldFork, lockedOnMigration, shouldUpdate, userOverRepositoryLimit } = webCommitInfo;
	let pathname = ssrSafeLocation.pathname;
	if (pathname.endsWith("/")) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = pathname.slice(0, -1);
			$[0] = t1;
		} else t1 = $[0];
		pathname = t1;
	}
	const navigate = useNavigate$1();
	const { addToast } = useToastContext();
	const currentPath = pathname + ssrSafeLocation.search;
	let t1;
	if ($[1] !== addToast || $[2] !== navigate) {
		t1 = async (e) => {
			e.preventDefault();
			try {
				if ((await verifiedFetch(currentPath, {
					method: "POST",
					headers: { Accept: "application/json" }
				})).ok) navigate(currentPath);
				else addToast({
					type: "error",
					message: "An unexpected error occurred. Please try again."
				});
			} catch {
				addToast({
					type: "error",
					message: "An unexpected error occurred. Please try again."
				});
			}
		};
		$[1] = addToast;
		$[2] = navigate;
		$[3] = t1;
	} else t1 = $[3];
	const handleSubmit = t1;
	let t2;
	let t3;
	if ($[4] !== binary || $[5] !== handleSubmit || $[6] !== helpUrl || $[7] !== lockedOnMigration || $[8] !== repositoryName || $[9] !== shouldFork || $[10] !== shouldUpdate || $[11] !== userOverRepositoryLimit || $[12] !== webCommitInfo) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const issue = lockedOnMigration ? {
				message: "This repository is currently being migrated.",
				description: "Sorry, you’re not able to edit this repository while the migration is in progress.",
				icon: LockIcon
			} : shouldFork ? userOverRepositoryLimit ? {
				message: "You are over your repository limit",
				description: "Sorry, you’re not able to fork this repository.",
				icon: AlertIcon
			} : {
				message: "You need to fork this repository to propose changes.",
				description: "Sorry, you’re not able to edit this repository directly—you need to fork it and propose your changes from there instead.",
				icon: GitBranchIcon
			} : shouldUpdate ? {
				message: "Sorry, it looks like your fork is outdated!",
				description: "You’ll have to bring it up to date before you can propose changes.",
				icon: AlertIcon
			} : binary ? {
				message: "Binary file content is not editable.",
				description: "But you can still rename or move it.",
				icon: PencilIcon
			} : null;
			if (!issue) {
				t3 = null;
				break bb0;
			}
			t2 = jsxs(Fragment, { children: [!(webCommitInfo.canCreatePullRequest ?? true) && jsx(PullRequestInfoBanner, {
				webCommitInfo,
				repositoryName
			}), jsxs("div", {
				className: EditIssues_module_default.Box,
				children: [
					jsx(Octicon, {
						icon: issue.icon,
						size: "medium",
						className: EditIssues_module_default.Octicon
					}),
					jsx("h3", {
						className: EditIssues_module_default.Text,
						children: issue.message
					}),
					jsx("span", {
						className: EditIssues_module_default.Text_1,
						children: issue.description
					}),
					(shouldFork && !userOverRepositoryLimit || shouldUpdate) && jsx("form", {
						onSubmit: handleSubmit,
						"data-turbo": "false",
						method: "post",
						action: currentPath,
						"data-testid": "edit-issues-form",
						children: jsx(ButtonComponent, {
							type: "submit",
							variant: "primary",
							children: shouldFork ? "Fork this repository" : "Update your fork"
						})
					}),
					shouldFork && userOverRepositoryLimit ? jsx(Link, {
						href: `${helpUrl}/repositories/creating-and-managing-repositories/repository-limits`,
						children: "Learn more repository limits"
					}) : jsx(Link, {
						href: `${helpUrl}/articles/fork-a-repo`,
						children: "Learn more about forks"
					})
				]
			})] });
		}
		$[4] = binary;
		$[5] = handleSubmit;
		$[6] = helpUrl;
		$[7] = lockedOnMigration;
		$[8] = repositoryName;
		$[9] = shouldFork;
		$[10] = shouldUpdate;
		$[11] = userOverRepositoryLimit;
		$[12] = webCommitInfo;
		$[13] = t2;
		$[14] = t3;
	} else {
		t2 = $[13];
		t3 = $[14];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
EditIssues.displayName = "EditIssues";
export { EditingForkBanner as n, EditIssues as t };
