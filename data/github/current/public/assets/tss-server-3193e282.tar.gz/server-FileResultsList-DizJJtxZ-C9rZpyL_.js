import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { Ai as XCircleFillIcon, Bi as useFocusZone, Dt as FileIcon, bn as Link, n as ActionList, wr as SearchIcon, wt as FileDirectoryFillIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { h as codeNavSearchPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as positions } from "./server-fzy.js-7qhjn37q.js";
import { a as useTreeList, i as useFileQueryContext, n as WebWorker, r as findFileWorkerJob } from "./server-find-file-BEBNNIhZ-BiOBklr2.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { c as useUrlCreator, n as AllShortcutsEnabled, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as getScrollableParent } from "./server-get-scrollable-parent-CYFmVGg0-DxdSiurz.js";
import { i as useScreenSize, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import React, { startTransition, useCallback, useDeferredValue, useEffectEvent, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys, scrollIntoView } from "@primer/behaviors";
import { c } from "react/compiler-runtime";
var FilesSearchBox$1 = ({ ref, ariaActiveDescendant, ariaControls, ariaExpanded, ariaHasPopup, onBlur, onFocus, onKeyDown, onPreload, onSearch, query, className }) => {
	const { sendRepoClickEvent } = useReposAnalytics();
	const [textValue, setTextValue] = React.useState(query);
	React.useEffect(() => {
		setTextValue(query);
	}, [query]);
	const clearAction = query ? /* @__PURE__ */ jsx(TextInput$1.Action, {
		onClick: () => {
			sendRepoClickEvent("FILE_TREE.CANCEL_SEARCH");
			onSearch("");
		},
		icon: XCircleFillIcon,
		"aria-label": "Clear",
		className: "fgColor-muted"
	}) : void 0;
	return /* @__PURE__ */ jsx(TextInput$1, {
		autoFocus: isSearchUrl(),
		ref,
		value: textValue,
		onKeyDown,
		onChange: (e) => {
			setTextValue(e.target.value);
			onPreload();
			onSearch(e.target.value);
		},
		className: clsx("d-flex", className),
		"aria-label": "Go to file",
		"aria-activedescendant": ariaActiveDescendant,
		role: ariaHasPopup ? "combobox" : void 0,
		"aria-controls": ariaControls,
		"aria-expanded": ariaExpanded,
		"aria-haspopup": ariaHasPopup ? "dialog" : void 0,
		autoCorrect: "off",
		spellCheck: "false",
		placeholder: "Go to file",
		leadingVisual: SearchIcon,
		trailingAction: clearAction,
		trailingVisual: clearAction ? void 0 : () => /* @__PURE__ */ jsx(AllShortcutsEnabled, { children: /* @__PURE__ */ jsx("kbd", { children: "t" }) }),
		onFocus: (e_0) => {
			onPreload();
			e_0.target.select();
			onFocus?.(e_0);
		},
		onBlur,
		onClick: () => sendRepoClickEvent("FILE_TREE.SEARCH_BOX")
	});
};
/**
* Whether the URL contains ?search=1 which indicates user is searching for a file
*/
FilesSearchBox$1.displayName = "FilesSearchBox";
function isSearchUrl() {
	return new URLSearchParams(ssrSafeLocation.search).get("search") === "1";
}
FilesSearchBox$1.displayName = "FilesSearchBox";
var FileResultsList_module_default = {
	ActionList: "FileResultsList-module_ysudIa_ActionList",
	ActionList_Item: "FileResultsList-module_ysudIa_ActionList_Item",
	ActionList_ItemFocused: "FileResultsList-module_ysudIa_ActionList_ItemFocused",
	ActionList_Overlay: "FileResultsList-module_ysudIa_ActionList_Overlay",
	Box: "FileResultsList-module_ysudIa_Box",
	Box_2: "FileResultsList-module_ysudIa_Box_2",
	FilesSearchBox: "FileResultsList-module_ysudIa_FilesSearchBox",
	HighlightMatch: "FileResultsList-module_ysudIa_HighlightMatch",
	Octicon: "FileResultsList-module_ysudIa_Octicon",
	OverlayEnabled: "FileResultsList-module_ysudIa_OverlayEnabled",
	PrimerLink: "FileResultsList-module_ysudIa_PrimerLink"
};
var LIST_SIZE = 40;
var defaultConfig = {
	excludeDirectories: false,
	excludeSeeAllResults: false
};
function FileResultsList({ actionListClassName, additionalResults, commitOid, config = defaultConfig, findFileWorkerPath, getItemUrl, onRenderRow, onItemSelected, searchBoxRef, className }) {
	const { excludeDirectories, excludeSeeAllResults } = config;
	const { query, setQuery } = useFileQueryContext();
	const repo = useCurrentRepository();
	const internalInputRef = React.useRef(null);
	const inputRef = searchBoxRef ?? internalInputRef;
	const [preloadSearch, setPreloadSearch] = React.useState(query.length > 0);
	const [overlayOpen, setOverlayOpen] = React.useState(!!query);
	const { list, directories, loading, error } = useTreeList(commitOid, preloadSearch, !!excludeDirectories);
	const directoriesSet = useMemo(() => new Set(directories), [directories]);
	const path = usePath();
	const { getUrl } = useUrlCreator();
	const { queryText, queryLine } = parseQuery(query);
	const deferredQueryText = useDeferredValue(queryText);
	const { matches, clearMatches } = useFilter(useMemo(() => [...list, ...additionalResults ?? []].sort(), [additionalResults, list]), deferredQueryText, findFileWorkerPath, preloadSearch);
	const { sendRepoClickEvent } = useReposAnalytics();
	const navigate = useNavigate$1();
	const [focusedSearchIndex, setFocusedSearchIndex] = React.useState(0);
	const [listFocusVisible, setListFocusVisible] = React.useState(() => isSearchUrl());
	const allResultsLink = React.useRef(null);
	const textInputContainerRef = React.useRef(null);
	const overlayId = "file-results-list";
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const { screenSize } = useScreenSize();
	const enableOverlay = config.enableOverlay ?? screenSize >= ScreenSize.large;
	const onRowClick = React.useCallback((selectedPath) => {
		sendRepoClickEvent("FILE_TREE.SEARCH_RESULT_CLICK");
		onItemSelected?.(selectedPath);
		setOverlayOpen(false);
	}, [sendRepoClickEvent, onItemSelected]);
	const buildUrl = (itemPath, knownDirectories, hash) => {
		const isDirectory = knownDirectories.has(itemPath);
		if (getItemUrl) return getItemUrl(itemPath, isDirectory, hash);
		return getUrl({
			path: itemPath,
			action: isDirectory ? "tree" : "blob",
			hash
		});
	};
	const { containerRef: listRef } = useFocusZone({
		bindKeys: FocusKeys.ArrowVertical | FocusKeys.HomeAndEnd,
		focusInStrategy: "previous"
	}, [loading, error]);
	React.useEffect(() => {
		if (!query) setOverlayOpen(false);
	}, [query]);
	React.useEffect(() => {
		if (document.activeElement !== inputRef.current && enableOverlay) setOverlayOpen(false);
	}, [
		path,
		inputRef,
		enableOverlay
	]);
	const displayMatches = useMemo(() => matches?.slice(0, LIST_SIZE) ?? [], [matches]);
	const matchesTruncated = matches && matches.length > displayMatches.length;
	const handleSearchBoxKeyDown = (event) => {
		const { key, shiftKey, metaKey, altKey, ctrlKey } = event;
		if (shiftKey || metaKey || altKey) return;
		if (key === "Escape") {
			if (query) {
				sendRepoKeyDownEvent("FILE_TREE.CANCEL_SEARCH");
				setQuery("");
				clearMatches();
			} else if (document.activeElement) document.activeElement.blur();
		} else if (!query) return;
		else if (key === "Enter") {
			if (!excludeSeeAllResults && matchesTruncated && focusedSearchIndex === displayMatches.length) {
				navigate(codeNavSearchPath({
					owner: repo.ownerLogin,
					repo: repo.name,
					searchTerm: `path:${queryText}`
				}));
				onItemSelected?.();
			} else if (displayMatches[focusedSearchIndex]) {
				const selectedPath_0 = displayMatches[focusedSearchIndex];
				navigate(buildUrl(selectedPath_0, directoriesSet, queryLine ? `L${queryLine}` : ""));
				setOverlayOpen(false);
				onItemSelected?.(selectedPath_0);
			}
		} else if (key === "ArrowDown" || ctrlKey && key === "n") {
			if (!excludeSeeAllResults && matchesTruncated && focusedSearchIndex >= displayMatches.length - 1) {
				setFocusedSearchIndex(displayMatches.length);
				if (allResultsLink.current && listRef.current) {
					const container = getScrollableParent(listRef.current);
					scrollIntoView(allResultsLink.current, container, { behavior: "instant" });
				}
			} else setFocusedSearchIndex(Math.min(focusedSearchIndex + 1, displayMatches.length - 1));
			event.preventDefault();
			return;
		} else if (key === "ArrowUp" || ctrlKey && key === "p") {
			setFocusedSearchIndex(Math.max(focusedSearchIndex - 1, 0));
			event.preventDefault();
			return;
		}
	};
	const listContents = /* @__PURE__ */ jsx("div", {
		className: clsx(FileResultsList_module_default.Box, { [FileResultsList_module_default.OverlayEnabled]: enableOverlay }),
		children: error ? /* @__PURE__ */ jsx(Flash, {
			variant: "danger",
			className: "tmp-m-3",
			children: "Failed to search"
		}) : /* @__PURE__ */ jsxs(ActionList, {
			ref: listRef,
			className: clsx(actionListClassName, FileResultsList_module_default.ActionList, { [FileResultsList_module_default.ActionList_Overlay]: enableOverlay }),
			role: "listbox",
			children: [!loading && displayMatches.map((match, index) => {
				const isDirectory_0 = directoriesSet.has(match);
				const itemUrl_0 = buildUrl(match, directoriesSet, queryLine ? `L${queryLine}` : "");
				return /* @__PURE__ */ jsx(MemoizedFileResultRow, {
					active: match === path,
					index,
					focused: listFocusVisible && focusedSearchIndex === index,
					match,
					onRender: onRenderRow,
					query: deferredQueryText,
					onClick: onRowClick,
					isDirectory: isDirectory_0,
					to: itemUrl_0,
					useOverlay: enableOverlay,
					listRef
				}, match);
			}), /* @__PURE__ */ jsxs("div", {
				className: "tmp-m-3 text-center",
				children: [/* @__PURE__ */ jsx(FileResultsStatus, {
					loading: loading || !matches,
					visibleResultCount: displayMatches.length,
					truncated: !!matchesTruncated
				}), matchesTruncated && !excludeSeeAllResults && /* @__PURE__ */ jsxs(Fragment$1, { children: ["\xA0", /* @__PURE__ */ jsx(Link, {
					id: "see-all-results-link",
					className: clsx("focus-visible", { [FileResultsList_module_default.PrimerLink]: listFocusVisible && focusedSearchIndex === displayMatches.length }),
					ref: allResultsLink,
					href: codeNavSearchPath({
						owner: repo.ownerLogin,
						repo: repo.name,
						searchTerm: `path:${queryText}`
					}),
					children: "See all results"
				})] })]
			})]
		})
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("div", {
			ref: textInputContainerRef,
			className,
			children: /* @__PURE__ */ jsx(FilesSearchBox$1, {
				ariaActiveDescendant: (enableOverlay || !query) && (!enableOverlay || !overlayOpen) ? void 0 : listFocusVisible && focusedSearchIndex > -1 ? matchesTruncated && focusedSearchIndex === displayMatches.length ? "see-all-results-link" : `file-result-${focusedSearchIndex}` : void 0,
				ariaExpanded: enableOverlay ? overlayOpen : void 0,
				ariaHasPopup: enableOverlay,
				ariaControls: enableOverlay ? overlayId : void 0,
				ref: inputRef,
				query,
				onKeyDown: handleSearchBoxKeyDown,
				onPreload: () => setPreloadSearch(true),
				onSearch: (newQuery) => {
					setQuery(newQuery);
					if (newQuery) setOverlayOpen(true);
					else {
						clearMatches();
						setOverlayOpen(false);
					}
					setFocusedSearchIndex(0);
				},
				onBlur: (e) => {
					if (!listRef.current?.contains(e.relatedTarget)) {
						setOverlayOpen(false);
						setListFocusVisible(false);
					}
				},
				onFocus: () => {
					if (query) setOverlayOpen(true);
					setListFocusVisible(true);
				},
				className: FileResultsList_module_default.FilesSearchBox
			})
		}),
		enableOverlay && /* @__PURE__ */ jsx(AnchoredOverlay, {
			anchorRef: textInputContainerRef,
			open: enableOverlay && overlayOpen,
			renderAnchor: null,
			onClose: () => {
				setOverlayOpen(false);
			},
			focusZoneSettings: { disabled: true },
			focusTrapSettings: { disabled: true },
			width: "xlarge",
			align: "end",
			overlayProps: {
				id: overlayId,
				role: "dialog"
			},
			children: listContents
		}),
		!enableOverlay && query && listContents
	] });
}
FileResultsList.displayName = "FileResultsList";
function FileResultsStatus({ visibleResultCount, truncated, loading }) {
	return /* @__PURE__ */ jsx("span", {
		role: "status",
		className: !loading && !truncated && visibleResultCount !== 0 ? "sr-only" : void 0,
		"aria-label": loading ? "Loading" : void 0,
		children: loading ? /* @__PURE__ */ jsx(Spinner, { size: "large" }) : visibleResultCount === 0 ? "No matches found" : truncated ? `First ${visibleResultCount} files shown.` : `Showing ${visibleResultCount} files.`
	}, "results-count-status");
}
FileResultsStatus.displayName = "FileResultsStatus";
var FileResultRow = ({ active, focused, index, match, query, to, isDirectory, onClick, onRender, useOverlay, listRef }) => {
	const positionsList = positions(query, match);
	onRender?.();
	const ref = React.useRef(null);
	const leadingIcon = isDirectory ? DirectoryIcon : FileResultIcon;
	React.useEffect(() => {
		if (focused && ref.current && listRef?.current) {
			const container = getScrollableParent(listRef.current);
			scrollIntoView(ref.current, container, { behavior: "instant" });
		}
	}, [focused, listRef]);
	const onClickWrapped = useCallback(() => {
		onClick?.(match);
	}, [match, onClick]);
	return /* @__PURE__ */ jsx(ActionList.Item, {
		role: "group",
		active,
		className: clsx(focused ? FileResultsList_module_default.ActionList_ItemFocused : void 0),
		children: /* @__PURE__ */ jsxs(Link$1, {
			to,
			ref,
			role: "option",
			onClick: onClickWrapped,
			id: `file-result-${index}`,
			tabIndex: useOverlay ? -1 : 0,
			"data-focus-visible-added": focused || void 0,
			className: clsx("d-flex", FileResultsList_module_default.ActionList_Item),
			children: [/* @__PURE__ */ jsx("div", {
				className: "d-flex flex-1 flex-column overflow-hidden",
				children: /* @__PURE__ */ jsx(HighlightMatch, {
					text: match,
					positionsList,
					LeadingIcon: leadingIcon,
					className: FileResultsList_module_default.HighlightMatch
				})
			}), focused && /* @__PURE__ */ jsx("div", {
				className: "sr-only",
				children: `Go to ${isDirectory ? "folder" : "file"}`
			})]
		})
	}, match);
};
FileResultRow.displayName = "FileResultRow";
var DirectoryIcon = () => /* @__PURE__ */ jsx(Octicon, {
	"aria-label": "Directory",
	icon: FileDirectoryFillIcon,
	size: "small",
	className: FileResultsList_module_default.Octicon
});
DirectoryIcon.displayName = "DirectoryIcon";
var FileResultIcon = () => /* @__PURE__ */ jsx(Octicon, {
	"aria-label": "File",
	icon: FileIcon,
	className: "fgColor-muted mr-2",
	size: "small"
});
FileResultIcon.displayName = "FileResultIcon";
var MemoizedFileResultRow = React.memo(FileResultRow);
MemoizedFileResultRow.displayName = "MemoizedFileResultRow";
function HighlightMatch({ text, positionsList, className, LeadingIcon }) {
	const parts = [];
	let lastPosition = 0;
	for (const i of positionsList) {
		if (Number(i) !== i || i < lastPosition || i > text.length) continue;
		const slice = text.slice(lastPosition, i);
		if (slice) parts.push(allowSlashWrapping(slice));
		lastPosition = i + 1;
		parts.push(/* @__PURE__ */ jsx("mark", {
			className: "text-bold bgColor-transparent fgColor-default",
			children: text[i]
		}, i));
	}
	parts.push(allowSlashWrapping(text.slice(lastPosition)));
	return /* @__PURE__ */ jsx("div", {
		className,
		children: /* @__PURE__ */ jsxs(Fragment$1, { children: [LeadingIcon && /* @__PURE__ */ jsx(LeadingIcon, {}), parts] })
	});
}
HighlightMatch.displayName = "HighlightMatch";
function allowSlashWrapping(text) {
	return text.replaceAll("/", "/​");
}
function useFilter(list, query, workerPath, startWorker) {
	const $ = c(21);
	const [matches, setMatches] = React.useState();
	const lastQueryRef = React.useRef("");
	const workerRef = React.useRef(null);
	const { sendStats } = useReposAnalytics();
	const isWorkerWorking = React.useRef(false);
	const latestQueryRef = React.useRef("");
	let t0;
	if ($[0] !== sendStats || $[1] !== workerPath) {
		t0 = () => {
			const worker = new WebWorker(workerPath, findFileWorkerJob);
			worker.onmessage = (t1) => {
				const { data } = t1;
				isWorkerWorking.current = false;
				startTransition(() => {
					setMatches(data.list);
				});
				lastQueryRef.current = data.query;
				if (data.startTime && data.query === latestQueryRef.current) sendStats("repository.find-file", {
					"find-file-base-count": data.baseCount,
					"find-file-results-count": data.list.length,
					"find-file-duration-ms": performance.now() - data.startTime
				});
			};
			workerRef.current = worker;
		};
		$[0] = sendStats;
		$[1] = workerPath;
		$[2] = t0;
	} else t0 = $[2];
	const createWorker = useEffectEvent(t0);
	let t1;
	if ($[3] !== matches) {
		t1 = (baseList, currentQuery) => {
			const canFilterPreviousMatches = lastQueryRef.current && currentQuery.startsWith(lastQueryRef.current);
			isWorkerWorking.current = true;
			latestQueryRef.current = currentQuery;
			workerRef.current?.postMessage({
				baseList: canFilterPreviousMatches && matches || baseList,
				query: currentQuery,
				startTime: performance.now()
			});
		};
		$[3] = matches;
		$[4] = t1;
	} else t1 = $[4];
	const postFilterRequest = useEffectEvent(t1);
	let t2;
	if ($[5] !== createWorker || $[6] !== startWorker) {
		t2 = () => {
			if (!startWorker) return;
			createWorker();
			return function destroy() {
				workerRef.current?.terminate();
			};
		};
		$[5] = createWorker;
		$[6] = startWorker;
		$[7] = t2;
	} else t2 = $[7];
	let t3;
	if ($[8] !== startWorker) {
		t3 = [startWorker];
		$[8] = startWorker;
		$[9] = t3;
	} else t3 = $[9];
	React.useEffect(t2, t3);
	let t4;
	if ($[10] !== createWorker || $[11] !== list || $[12] !== postFilterRequest || $[13] !== query) {
		t4 = () => {
			if (list.length && query) {
				if (isWorkerWorking.current) {
					workerRef.current?.terminate();
					createWorker();
				}
				postFilterRequest(list, query);
			}
		};
		$[10] = createWorker;
		$[11] = list;
		$[12] = postFilterRequest;
		$[13] = query;
		$[14] = t4;
	} else t4 = $[14];
	let t5;
	if ($[15] !== list || $[16] !== query) {
		t5 = [list, query];
		$[15] = list;
		$[16] = query;
		$[17] = t5;
	} else t5 = $[17];
	React.useEffect(t4, t5);
	let t6;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => setMatches(void 0);
		$[18] = t6;
	} else t6 = $[18];
	let t7;
	if ($[19] !== matches) {
		t7 = {
			matches,
			clearMatches: t6
		};
		$[19] = matches;
		$[20] = t7;
	} else t7 = $[20];
	return t7;
}
function parseQuery(query) {
	query = query.replaceAll(" ", "");
	const colonIndex = query.indexOf(":");
	if (colonIndex >= 0) return {
		queryText: query.substring(0, colonIndex),
		queryLine: parseInt(query.substring(colonIndex + 1), 10)
	};
	return {
		queryText: query,
		queryLine: void 0
	};
}
export { FileResultsList as n, isSearchUrl as r, FileResultRow as t };
