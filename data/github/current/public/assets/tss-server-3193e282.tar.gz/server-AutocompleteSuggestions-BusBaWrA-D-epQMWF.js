import { n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { Children, useId, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
var AutocompleteSuggestions_module_default = {
	ActionList_0: "AutocompleteSuggestions-module_C51b4q_ActionList_0",
	Overlay_0: "AutocompleteSuggestions-module_C51b4q_Overlay_0",
	suggestion: "AutocompleteSuggestions-module_C51b4q_suggestion"
};
var singleWordTriggerTerminators = new Set([" ", "\n"]);
var multiWordTriggerTerminators = new Set([".", "\n"]);
/**
* Calculate whether or not suggestions should be shown based on the given state of the
* input. If they should be shown, returns the show event.
*/
var calculateSuggestionsQuery = (triggers, text, caretLocation) => {
	const sortedTriggers = triggers.sort((a, b) => b.triggerChar.length - a.triggerChar.length);
	for (let i = caretLocation - 1, query = "", potentialTriggers = sortedTriggers; i >= 0 && potentialTriggers.length > 0; i--) {
		const character = text[i] ?? "";
		query = character + query;
		if (singleWordTriggerTerminators.has(character)) potentialTriggers = potentialTriggers.filter((t) => t.multiWord);
		if (multiWordTriggerTerminators.has(character)) potentialTriggers = potentialTriggers.filter((t) => !t.multiWord);
		for (const trigger of potentialTriggers.filter((t) => query.startsWith(t.triggerChar))) {
			const prevChar = text[i - 1] ?? "";
			const nextChar = query[1] ?? "";
			if ((!prevChar || /[\s([]/.test(prevChar)) && (!nextChar || !/\s/.test(nextChar))) return {
				trigger,
				query: query.slice(trigger.triggerChar.length),
				caretLocation: i
			};
			potentialTriggers = potentialTriggers.filter((t) => t !== trigger);
		}
	}
	return null;
};
var isNullSuggestion = (suggestion) => typeof suggestion === "object" && suggestion.value === null;
var getSuggestionValue = (suggestion) => typeof suggestion === "string" ? suggestion : suggestion.value;
var getSuggestionKey = (suggestion) => {
	if (typeof suggestion === "string") return suggestion;
	if (suggestion.value === null) return suggestion.key;
	return suggestion.key ?? suggestion.value;
};
/**
* Attempts to assert that the child element is of a supported type. This can't be enforced
* by the type system so it has to be done as a runtime check. This isn't foolproof - a
* component that forwards a ref to a correct element but does not forward event handlers
* will not work. But it's the best we can reasonably do.
*/
function requireChildrenToBeInput(child, childRef) {
	Children.only(child);
	if (childRef.current && !(childRef.current instanceof HTMLInputElement) && !(childRef.current instanceof HTMLTextAreaElement)) throw new TypeError(`AutocompleteTextarea child must be a component that forwards a ref and props to an <input> or <textarea> element.`);
	return child;
}
/**
* Combine several event handlers into one. The last handler in the list is called first
* and no further handlers will be called if `event.preventDefault()` is called.
*/
var augmentHandler = (...handlers) => (event) => {
	for (const handler of [...handlers].reverse()) if (!event.isDefaultPrevented()) handler?.(event);
};
var LoadingIndicator = () => /* @__PURE__ */ jsxs(Fragment$1, { children: [
	/* @__PURE__ */ jsx(ActionList.Item, {
		disabled: true,
		children: /* @__PURE__ */ jsx(SkeletonText, {})
	}),
	/* @__PURE__ */ jsx(ActionList.Item, {
		disabled: true,
		children: /* @__PURE__ */ jsx(SkeletonText, {})
	}),
	/* @__PURE__ */ jsx(ActionList.Item, {
		disabled: true,
		children: /* @__PURE__ */ jsx(SkeletonText, {})
	})
] });
LoadingIndicator.displayName = "LoadingIndicator";
var SuggestionListItem = ({ suggestion, onSelect, isActive, id, parentRole }) => {
	const value = getSuggestionValue(suggestion);
	const sharedProps = {
		id,
		role: parentRole === "menu" ? "menuitem" : "option",
		active: isActive,
		className: AutocompleteSuggestions_module_default.suggestion,
		["aria-selected"]: parentRole === "listbox" && isActive ? true : void 0,
		onMouseDown: (event) => {
			event.preventDefault();
			onSelect();
		}
	};
	return typeof suggestion === "string" ? /* @__PURE__ */ jsx(ActionList.Item, {
		...sharedProps,
		children: value
	}) : suggestion.render({
		...sharedProps,
		children: value
	});
};
/**
* Renders an overlayed list at the given relative coordinates. Handles keyboard navigation
* and accessibility concerns.
*/
SuggestionListItem.displayName = "SuggestionListItem";
var AutocompleteSuggestions = ({ suggestions, portalName, triggerCharCoords, onClose, onCommit, inputRef, visible, defaultPlacement, activeSuggestion, getSuggestionId, id, menuTitle, role, tabInsertsSuggestions }) => {
	const overlayRef = useRef(null);
	const [top, setTop] = useState(0);
	const [height, setHeight] = useState("auto");
	useIsomorphicLayoutEffect(function recalculateTop() {
		setHeight("auto");
		const overlayHeight = overlayRef.current?.offsetHeight ?? 0;
		const belowOffset = triggerCharCoords.top + triggerCharCoords.height;
		const wouldOverflowBelow = belowOffset + overlayHeight > window.innerHeight;
		const aboveOffset = triggerCharCoords.top - overlayHeight;
		const wouldOverflowAbove = aboveOffset < 0;
		let finalTopPosition = {
			below: wouldOverflowBelow && !wouldOverflowAbove ? aboveOffset : belowOffset,
			above: wouldOverflowAbove && !wouldOverflowBelow ? belowOffset : aboveOffset
		}[defaultPlacement];
		if (Number.isNaN(finalTopPosition)) finalTopPosition = 0;
		setTop(Math.max(0, finalTopPosition));
		if (wouldOverflowBelow && wouldOverflowAbove) setHeight(`${defaultPlacement === "above" ? window.innerHeight + finalTopPosition : window.innerHeight - finalTopPosition}px`);
	}, [
		triggerCharCoords.top,
		triggerCharCoords.height,
		suggestions,
		visible,
		defaultPlacement
	]);
	const items = /* @__PURE__ */ jsx(Fragment$1, { children: suggestions === "loading" ? /* @__PURE__ */ jsx(LoadingIndicator, {}) : suggestions?.map((suggestion) => /* @__PURE__ */ jsx(SuggestionListItem, {
		suggestion,
		id: getSuggestionId(suggestion),
		onSelect: () => onCommit(suggestion),
		isActive: activeSuggestion === suggestion,
		parentRole: role
	}, getSuggestionKey(suggestion))) });
	const labelId = useId();
	const typedInputRef = inputRef;
	/**
	* Even though we apply all the aria attributes, screen readers don't fully support this
	* dynamic use case and so they don't have a native way to indicate to the user when
	* there are suggestions available. So we use some hidden text with aria-live to politely
	* indicate what's available and how to use it.
	*
	* This text should be consistent and the important info should be first, because users
	* will hear it as they type - if they have heard the message before they should be able
	* to recognize it and quickly apply the first suggestion without listening to the rest
	* of the message.
	*
	* When screen reader users navigate using arrow keys, the `aria-activedescendant` will
	* change and will be read out so we don't need to handle that interaction here.
	*/
	const description = !visible || !suggestions ? "" : suggestions === "loading" ? "Loading autocomplete suggestions…" : role === "listbox" ? `${suggestions.length} autocomplete ${suggestions.length === 1 ? "suggestion" : "suggestions"} available; "${getSuggestionValue(suggestions[0])}" is highlighted. Press ${tabInsertsSuggestions ? "Enter or Tab" : "Enter"} to select.` : "";
	return visible ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Overlay, {
		onEscape: onClose,
		onClickOutside: onClose,
		returnFocusRef: typedInputRef,
		preventFocusOnOpen: true,
		portalContainerName: portalName,
		top,
		left: triggerCharCoords.left,
		ref: overlayRef,
		className: AutocompleteSuggestions_module_default.Overlay_0,
		children: /* @__PURE__ */ jsx(ActionList, {
			role,
			id,
			"aria-label": menuTitle ? void 0 : "Autocomplete suggestions",
			"aria-labelledby": menuTitle ? labelId : void 0,
			className: AutocompleteSuggestions_module_default.ActionList_0,
			style: { height },
			children: menuTitle ? /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
				id: labelId,
				children: menuTitle
			}), items] }) : items
		})
	}), /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("span", {
		"aria-live": "assertive",
		"aria-atomic": true,
		style: {
			clipPath: "circle(0)",
			position: "absolute"
		},
		children: description
	}) })] }) : /* @__PURE__ */ jsx(Fragment$1, {});
};
AutocompleteSuggestions.displayName = "AutocompleteSuggestions";
export { getSuggestionValue as a, getSuggestionKey as i, augmentHandler as n, isNullSuggestion as o, calculateSuggestionsQuery as r, requireChildrenToBeInput as s, AutocompleteSuggestions as t };
