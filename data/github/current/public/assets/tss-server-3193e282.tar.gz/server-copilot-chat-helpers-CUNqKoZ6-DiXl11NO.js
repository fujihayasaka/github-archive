import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { It as repositoryTreePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
/**
* IMPORTANT NOTICE: Feature flags added here must also be added to the `packages/feature-flags/client-feature-flags.ts` file
* or they will not be available to check in this file!
*/
var CopilotFeatureFlags = class {
	get immersiveFigmaIntegration() {
		return isFeatureEnabled("copilot_immersive_figma_integration");
	}
	get focusTextAreaInsteadOfWorkbench() {
		return isFeatureEnabled("copilot_focus_text_area_instead_of_workbench");
	}
	get forceLegacyChatDefaultModel() {
		return isFeatureEnabled("copilot_api_force_legacy_base_chat_model");
	}
	get domPageContext() {
		return isFeatureEnabled("copilot_use_dom_page_context");
	}
	/**
	* When enabled, the interview survey dialog replaces the 'Give feedback' dialog in copilot chat.
	* @returns {boolean} Whether the feature is enabled.
	*/
	get copilotChatInterviewSurvey() {
		return isFeatureEnabled("copilot_chat_interview_survey");
	}
	get attachMultipleImages() {
		return isFeatureEnabled("copilot_chat_attach_multiple_images");
	}
	get clearModelSelectionForDefaultChange() {
		return isFeatureEnabled("copilot_chat_clear_model_selection_for_default_change");
	}
	get enableToolCallLogs() {
		return isFeatureEnabled("copilot_chat_enable_tool_call_logs");
	}
	/** Feature flag for text selection attachments in file previews */
	get selectionAttachments() {
		return isFeatureEnabled("copilot_chat_selection_attachments");
	}
	get customCopilots() {
		return isFeatureEnabled("copilot_custom_copilots");
	}
	get immersiveLayoutRoutes() {
		return isFeatureEnabled("copilot_immersive_layout_routes");
	}
	get immersiveStructuredModelPicker() {
		return isFeatureEnabled("copilot_immersive_structured_model_picker");
	}
	get customCopilotsFeaturePreview() {
		return isFeatureEnabled("copilot_custom_copilots_feature_preview");
	}
	get workbenchPlugin() {
		return isFeatureEnabled("copilot_workbench");
	}
	get copilotChatOpeningThreadSwitch() {
		return isFeatureEnabled("copilot_chat_opening_thread_switch");
	}
	get copilotDuplicateThread() {
		return isFeatureEnabled("copilot_duplicate_thread");
	}
	get copilotShareActiveSubthread() {
		return isFeatureEnabled("copilot_share_active_subthread");
	}
	get copilotChatO1Tools() {
		return isFeatureEnabled("copilot_api_tools_for_non_streaming_models");
	}
	get showDeepCodeSearchButton() {
		return isFeatureEnabled("copilot_show_deep_code_search_button") && isFeatureEnabled("copilot_api_search_agent_skill");
	}
	get deleteAllConversations() {
		return isFeatureEnabled("copilot_delete_all_conversations");
	}
	get staffPromptDialog() {
		return isFeatureEnabled("copilot_staff_prompt_dialog");
	}
	get staffToolsMenu() {
		return isFeatureEnabled("copilot_staff_tools_menu");
	}
	get visionAllowedInClaude() {
		return isFeatureEnabled("copilot_chat_vision_in_claude");
	}
	get premiumRequestQuotasEnabled() {
		return isFeatureEnabled("copilot_premium_request_quotas");
	}
	get freeToPaidTelemetry() {
		return isFeatureEnabled("copilot_free_to_paid_telem");
	}
	get freeToPaidSettingsUpgrade() {
		return isFeatureEnabled("copilot_ftp_settings_upgrade");
	}
	get freeToPaidYourCopilotSettings() {
		return isFeatureEnabled("copilot_ftp_your_copilot_settings");
	}
	get freeToPaidUpgradeToProFromModels() {
		return isFeatureEnabled("copilot_ftp_upgrade_to_pro_from_models");
	}
	get spacesImagesEnabled() {
		return isFeatureEnabled("copilot_custom_copilots_images");
	}
	get immersiveJobResultPreview() {
		return isFeatureEnabled("copilot_immersive_job_result_preview");
	}
	get disableModelPickerWhileStreaming() {
		return isFeatureEnabled("copilot_chat_disable_model_picker_while_streaming");
	}
	get freeToPaidHyperspaceUpgradePrompt() {
		return isFeatureEnabled("copilot_ftp_hyperspace_upgrade_prompt");
	}
	get reduceChatQuotaChecks() {
		return isFeatureEnabled("copilot_chat_reduce_quota_checks");
	}
	get requestTracing() {
		return isFeatureEnabled("copilot_api_staff_only_tracing");
	}
	get coffeTraceViewer() {
		return isFeatureEnabled("copilot_coffe_trace_view_enabled");
	}
	get capiErrorResponseTelemetry() {
		return isFeatureEnabled("copilot_capi_error_response_telemetry");
	}
	get fileBlockRefMatching() {
		return isFeatureEnabled("copilot_file_block_ref_matching");
	}
	get copilotRedirectDiffViewToImmersive() {
		return isFeatureEnabled("copilot_chat_diff_view_redirect") && !isFeatureEnabled("copilot_immersive_embedded");
	}
	get copilotRedirectFileViewToImmersive() {
		return isFeatureEnabled("copilot_chat_file_redirect") && !isFeatureEnabled("copilot_immersive_embedded");
	}
	get copilotRedirectSnippetToImmersive() {
		return isFeatureEnabled("copilot_chat_snippet_redirect") && !isFeatureEnabled("copilot_immersive_embedded");
	}
	get immersiveEmbedded() {
		return isFeatureEnabled("copilot_immersive_embedded");
	}
	get immersiveEmbeddedImplicitReferences() {
		return isFeatureEnabled("copilot_immersive_embedded_implicit_references");
	}
	get copilotResourcePanel() {
		return isFeatureEnabled("copilot_resource_panel");
	}
	get spacesIndividualPoliciesEnabled() {
		return isFeatureEnabled("copilot_spaces_individual_policies_ga");
	}
	get copilotWorkbenchSlimLineTopTabs() {
		return isFeatureEnabled("copilot_workbench_slim_line_top_tabs");
	}
	get sweAgentUseSubagents() {
		return isFeatureEnabled("copilot_swe_agent_use_subagents");
	}
	get chatInputCommands() {
		return isFeatureEnabled("copilot_chat_input_commands");
	}
	get removeAssistiveChatButton() {
		return isFeatureEnabled("copilot_chat_remove_assistive_button");
	}
	get hideExtensionsInDotcomChat() {
		return isFeatureEnabled("copilot_extensions_hide_in_dotcom_chat");
	}
	get copilotSearchBarRedirect() {
		return isFeatureEnabled("copilot_chat_search_bar_redirect");
	}
	get agentExpandedCapabilitiesTooltip() {
		return isFeatureEnabled("copilot_mission_control_decoupled_mode") && isFeatureEnabled("copilot_mission_control_decoupled_mode_agent_tooltip");
	}
	get askModeDropdown() {
		return isFeatureEnabled("copilot_ask_mode_dropdown");
	}
	get taskWithinChatThread() {
		return isFeatureEnabled("copilot_immersive_task_within_chat_thread");
	}
	get previewFeaturesVisionGate() {
		return isFeatureEnabled("copilot_chat_vision_preview_gate");
	}
	get codingAgentModelSelection() {
		return isFeatureEnabled("coding_agent_model_selection");
	}
	get codingAgentModelSelectionAllSkus() {
		return isFeatureEnabled("coding_agent_model_selection_all_skus");
	}
	get codingAgentProposeTasks() {
		return isFeatureEnabled("coding_agent_propose_tasks");
	}
	get codingAgentPullRequestToggle() {
		return isFeatureEnabled("coding_agent_pull_request_toggle");
	}
	get codingAgentHideModelPickerIfOnlyAuto() {
		return isFeatureEnabled("copilot_swe_agent_hide_model_picker_if_only_auto");
	}
	get defaultToAgentInput() {
		return isFeatureEnabled("copilot_default_to_task_input");
	}
	get defaultToAgentControl() {
		return isFeatureEnabled("copilot_default_to_task_input_control_group");
	}
	get copilotIcebreakersExperimentDashboard() {
		return isFeatureEnabled("copilot_icebreakers_experiment_dashboard");
	}
	get copilotIcebreakersExperimentHyperspace() {
		return isFeatureEnabled("copilot_icebreakers_experiment_hyperspace");
	}
	get copilotChatRepositoryPicker() {
		return this.askModeDropdown && isFeatureEnabled("copilot_chat_repository_picker");
	}
	get copilotSpacesPagination() {
		return isFeatureEnabled("copilot_spaces_pagination");
	}
	get customInstructionsFileReferences() {
		return isFeatureEnabled("custom_instructions_file_references");
	}
	get chatInputPerformanceOptimizations() {
		return isFeatureEnabled("copilot_chat_input_performance_optimizations");
	}
	get scrollPreviewTabs() {
		return isFeatureEnabled("copilot_scroll_preview_tabs");
	}
	get filePreviewKeepMounted() {
		return isFeatureEnabled("copilot_immersive_file_preview_keep_mounted");
	}
	get fileBlockTransitionOpen() {
		return isFeatureEnabled("copilot_immersive_file_block_transition_open");
	}
};
var copilotFeatureFlags = new CopilotFeatureFlags();
var experimentsLocalStorageKey = "copilot_experiments";
function getCopilotExperiments() {
	const experiments = safeStorage("localStorage").getItem(experimentsLocalStorageKey);
	if (!experiments) return [];
	return experiments.split(",");
}
function setCopilotExperiments(experiments) {
	safeStorage("localStorage").setItem(experimentsLocalStorageKey, experiments.join(","));
}
var COPILOT_PREVIOUS_PAGE_TITLE_KEY = "COPILOT_PREVIOUS_PAGE_TITLE_KEY";
var tempStorage = safeStorage("localStorage", {
	throwQuotaErrorsOnSet: false,
	ttl: 1e3 * 60 * 30
});
function getPreviousPageInfo() {
	const val = tempStorage.getItem(COPILOT_PREVIOUS_PAGE_TITLE_KEY);
	if (!val) return null;
	try {
		const parsed = JSON.parse(val);
		if (typeof parsed.title === "string" && typeof parsed.url === "string") return parsed;
		return null;
	} catch {
		return null;
	}
}
function setPreviousPageInfo(title) {
	const key = COPILOT_PREVIOUS_PAGE_TITLE_KEY;
	if (title === null) {
		tempStorage.removeItem(key);
		return;
	}
	tempStorage.setItem(key, JSON.stringify({
		title,
		url: document.location.href
	}));
}
var ModeSupportName = {
	Ask: "Ask",
	Agent: "Agent",
	CreateIssue: "Create issue",
	Loops: "Loops",
	Spark: "Spark"
};
var CopilotChatIntents = {
	explain: "explain",
	conversation: "conversation",
	suggest: "suggest",
	discussFileDiff: "discuss-file-diff",
	explainFileDiff: "explain-file-diff",
	reviewPr: "review-pull-request",
	actionsAgent: "actions-agent"
};
var MESSAGE_STREAMING_ERROR_TYPES = [
	"exception",
	"filtered",
	"publicCode",
	"contentTooLarge",
	"rateLimit",
	"agentUnauthorized",
	"agentRequest",
	"networkError",
	"multipleAgentsAttempt",
	"quotaExceeded",
	"billingNotConfigured"
];
var SUPPORTED_FUNCTIONS = [
	"bing-search",
	"codesearch",
	"semantic-code-search",
	"lexical-code-search",
	"lexical-code-search-githubread",
	"kb-search",
	"getfile",
	"getfilechanges",
	"getdiscussion",
	"get-actions-job-logs",
	"getalert",
	"planskill",
	"get-github-data",
	"support-search",
	"get-figma",
	"codesearchagentskill",
	"github-draft-issue_draft-issue",
	"github-draft-issue_existing-issue",
	"github-draft-issue_repository-metadata",
	"github-draft-issue_get-issues",
	"github-coding-agent",
	"github-coding-agent-immersive",
	"load_ability"
];
var DialogType = {
	Experiments: "experiements",
	Prompt: "prompt",
	None: "none"
};
var CopilotLicenseType = {
	Unlicensed: "unlicensed",
	LicensedFull: "licensed_full",
	LicensedLimited: "licensed_limited"
};
var CopilotPlan = {
	IndividualFree: "free",
	IndividualPro: "pro",
	IndividualProPlus: "pro_plus",
	IndividualStudent: "edu",
	Business: "business",
	Enterprise: "enterprise"
};
var NullMessageId = "NULL_MESSAGE";
function getFailedActionsJobPrompt(jobId, shouldFetchLogs = false) {
	return `Please find a solution for ${jobId != null ? `failing job ${jobId}` : "this failing job"}. ${shouldFetchLogs ? "Use the provided reference to fetch the job logs. Use the logs, job definition, and any referenced files where the failure occurred." : "Use the logs, job definition, and any referenced files where the failure occurred."} Keep your response focused on the solution and include code suggestions when appropriate.`;
}
function getExplainSnippetPrompt() {
	return "Explain this snippet";
}
function getSuggestImprovementsPrompt() {
	return "Suggest improvements to this code.";
}
function getExplainDiffPrompt() {
	return "Explain this diff";
}
var suggestedPrompts = {
	"Languages & frameworks": [
		"Show me Python beginner projects.",
		"Explain Java's garbage collection.",
		"Start me off with Node.js.",
		"Introduce me to Django best practices."
	],
	"Tools & environments": [
		"Set up a local development environment.",
		"Demonstrate the basics of Docker.",
		"Get me started with Git.",
		"Recommend popular VS Code extensions."
	],
	"Open source & contribution": [
		"Suggest 10 open source projects I can contribute to.",
		"Walk me through the GitHub Pull Request flow.",
		"How do I start my own open source project?",
		"Guide me through contributing to React's codebase."
	],
	"Best practices & concepts": [
		"Explain the SOLID principles of object-oriented design.",
		"Introduce me to test-driven development.",
		"Describe common design patterns.",
		"Teach me about RESTful API design."
	],
	"Web development": [
		"Guide me through creating a basic website.",
		"Introduce HTML5 and CSS3 features.",
		"Explain responsive web design.",
		"Start me off with Tailwind CSS."
	],
	"Databases & data": [
		"Get me started with SQL queries.",
		"Recommend popular NoSQL databases.",
		"How to back up a database?",
		"Give a walkthrough on normalizing a database."
	],
	"Algorithms & data structures": [
		"Teach me basic sorting algorithms.",
		"Explain binary search trees.",
		"Introduce me to graph algorithms.",
		"What is a hash table?"
	],
	"Security & authentication": [
		"Give a guide on basic web security.",
		"Show me how to set up OAuth.",
		"What's a JSON Web Token?",
		"Describe common encryption techniques."
	],
	"Mobile development": [
		"Kickstart my journey with Android development.",
		"Introduce me to iOS app basics.",
		"Recommend cross-platform mobile frameworks.",
		"Give a guide to the app store submission process."
	],
	"Cloud & DevOps": [
		"Start me off with AWS basics.",
		"How do I deploy apps on Azure DevOps?",
		"Introduce me to Kubernetes.",
		"What are the basics of continuous integration/continuous deployment?"
	],
	"Frontend frameworks & libraries": [
		"Get me started with React.",
		"Walk me through Vue.js essentials.",
		"What are some best practices in Angular development?",
		"How do I use Svelte for web apps?"
	],
	"Performance & optimization": [
		"Teach me about website performance optimization.",
		"Explain database indexing benefits.",
		"What are some tips to optimize JavaScript code?",
		"Give a guide to efficient API caching."
	]
};
var threadSuggestions = {
	repository: [
		{ question: "What questions can I ask?" },
		{ question: "What does this repository do?" },
		{ question: "How should I get started exploring this repo?" },
		{ question: "Can you tell me about this repository?" }
	],
	issue: [
		{ question: "Summarize this issue." },
		{ question: "What are the main points being discussed here?" },
		{ question: "Suggest next steps for this issue." }
	],
	alert: [{ question: "Summarize this alert." }],
	file: [
		{ question: "Explain this file." },
		{ question: "Summarize this file for me." },
		{ question: "How can I improve this file?" }
	],
	"pull-request": [
		{ question: "Summarize this pull request." },
		{ question: "What commits are included in this PR?" },
		{ question: "Can you tell me about the changes in this PR?" }
	],
	discussion: [
		{ question: "Summarize this discussion." },
		{ question: "Summarize the comments made by user in a discussion." },
		{ question: "What were some key decisions made in this discussion?" }
	],
	job: [{
		question: "Why did this job fail?",
		intent: CopilotChatIntents.actionsAgent
	}, {
		question: "How can I fix this build?",
		intent: CopilotChatIntents.actionsAgent
	}],
	"security-assessment": [
		{ question: "How do I enable secret protection?" },
		{ question: "What kind of credentials does secret scanning find?" },
		{ question: "What is the impact of leaked secret in one of my repositories?" }
	],
	default: [
		{ question: "What questions can I ask?" },
		{ question: "What is the best way to get started with Copilot?" },
		{ question: "How do I clone this repository?" },
		{ question: "How do I revert a commit?" },
		{ question: "How do I add myself as a reviewer?" },
		{ question: "How do I create a repository?" }
	],
	issues: [
		{ question: "How do I create an issue?" },
		{ question: "How do I filter issues by label?" },
		{ question: "What are the most recently updated issues?" }
	],
	"pull-requests": [
		{ question: "How do I create a pull request?" },
		{ question: "How do I filter pull requests by label?" },
		{ question: "How do I reopen a closed pull request?" }
	],
	discussions: [
		{ question: "How do I start a new discussion?" },
		{ question: "How do I filter discussions by category or tag?" },
		{ question: "How do I search for a specific discussion?" }
	]
};
var COPILOT_PATH = "/copilot";
var COPILOT_SPACES_PATH = `${COPILOT_PATH}/spaces`;
`${COPILOT_SPACES_PATH}`;
var UPGRADE_PLAN_URL = "https://github.com/features/copilot#pricing";
var UPGRADE_TO_PRO_PLAN_URL = "https://github.com/github-copilot/pro";
var ENABLE_ADDITIONAL_REQUESTS_URL = "https://github.com/settings/billing/budgets";
var MANAGE_BILLING_URL = "https://github.com/settings/billing";
var COPILOT_BILLING_SETTINGS_URL = "https://github.com/settings/copilot";
var LIMITING_TOS_MESSAGE = "For more on scraping GitHub and how it may affect your rights, please review our Terms of Service (https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)";
var ERRORS_BY_STATUS = {
	400: "This message could not be processed.",
	401: "You’re not authorized to use Copilot.",
	402: "Your usage quota has been exceeded. Please wait for your quota to reset or upgrade your plan.",
	403: `Access denied. You do not have permission to view this. ${LIMITING_TOS_MESSAGE}`,
	404: "Resource not found. Please try again.",
	408: "Your network connection was interrupted. Please try again.",
	413: "Message too large. Please shorten it or remove some references and try again.",
	429: `GitHub API rate limit exceeded. Please wait and try again. ${LIMITING_TOS_MESSAGE}`
};
var ERRORS_BY_TYPE = { extensionForbidden: "Copilot extensions can’t be used in shared conversations. Please unshare the conversation and try again." };
var ERROR_MSG = "I'm sorry but there was an error. Please try again.";
/**
* Tracks telemetry for CAPI request errors.
* Only sends telemetry if the capiErrorResponseTelemetry feature flag is enabled.
*/
function trackCAPIRequestError({ status, path, method, error, requestId, responseBody }) {
	if (copilotFeatureFlags.capiErrorResponseTelemetry) {
		const payload = {
			status,
			requestId: requestId || "",
			path,
			method,
			error
		};
		if (responseBody) payload.responseBody = responseBody.substring(0, 100);
		sendEvent("dotcom_chat.capi_request_error", payload);
	}
}
async function makeCAPIRequest({ authToken, basePath, body, integrationId, method, path, streamingResponse = false, additionalHeaders, realIp, signal, apiVersion }) {
	try {
		const headers = {
			...additionalHeaders || {},
			Authorization: authToken.authorizationHeaderValue
		};
		if (integrationId) headers["copilot-integration-id"] = integrationId;
		for (const exp of getCopilotExperiments()) {
			const components = exp.split("=");
			const name = components[0]?.replaceAll("_", "-");
			let value = "1";
			if (components.length > 1) value = components[1];
			headers[`X-Experiment-${name}`] = value;
		}
		if (apiVersion) headers["X-GitHub-Api-Version"] = apiVersion;
		if (streamingResponse) headers["Content-Type"] = "text/event-stream";
		if (realIp) headers["X-Real-IP"] = realIp;
		const res = await fetch(basePath + path, {
			method,
			mode: "cors",
			cache: "no-cache",
			headers,
			body: JSON.stringify(body),
			signal
		});
		if (res.ok) return res;
		let responseBody;
		try {
			responseBody = await res.clone().text();
		} catch {
			responseBody = void 0;
		}
		trackCAPIRequestError({
			status: res.status,
			requestId: res.headers?.get("X-GitHub-Request-ID") || "",
			path,
			method,
			error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again.",
			responseBody
		});
		return {
			status: res.status,
			ok: false,
			error: ERRORS_BY_STATUS[res.status] || "I'm sorry but there was an error. Please try again.",
			response: res
		};
	} catch (error) {
		trackCAPIRequestError({
			status: 500,
			path,
			method,
			error: error instanceof Error ? error.message : ERROR_MSG
		});
		return {
			status: 500,
			ok: false,
			error: ERROR_MSG
		};
	}
}
function buildMessage({ role, content, mediaContent, error, references = [], thread, confirmationResponses, clientSkillConfirmations, parentMessageID, skillOptions }) {
	return {
		id: crypto.randomUUID(),
		threadID: thread?.id || "temp",
		role,
		content,
		mediaContent,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		error,
		references,
		skillExecutions: [],
		clientConfirmations: confirmationResponses,
		confirmations: clientSkillConfirmations,
		parentMessageID,
		clientSide: true,
		skillOptions
	};
}
function threadName(thread) {
	return thread?.name || "New chat";
}
function referenceName(ref) {
	switch (ref.type) {
		case "figma": return ref.title || ref.url;
		case "file": return fileRefName(ref);
		case "folder": return fileRefName(ref);
		case "file-diff": return fileDiffRefName(ref);
		case "snippet": return snippetRefName(ref);
		case "repository": return repoRefName(ref);
		case "symbol":
		case "image":
		case "thread-scoped-file": return ref.name;
		case "commit": return ref.message;
		case "pull-request": return ref.title;
		case "tree-comparison": return diffRefName(ref);
		case "third-party": return ref.displayName;
		case "workspace-terminal-log": return "terminal log";
		case "text": return ref.name ? ref.name : "text reference";
		case "thread-scoped-snippet": return ref.name;
		case "repo-instructions": return "copilot-instructions.md";
		case "issue": return ref?.title || ref.number.toString();
		case "draft-issue":
		case "draft-update-issue": return ref.title;
		case "org-instructions": return ref?.owner;
		case "loop-node": return ref.title;
		case "loop-execution": return ref.loopTitle;
		case "discussion": return ref?.title || ref.number.toString();
		case "web-search-result": return ref.title;
		case "loading": return ref.title;
		case "copilot-space": return ref.name;
		case "job": return jobRefName(ref);
		case "github-url": return githubUrlRefName(ref);
		case "pr-overview": return "Overview";
		case "pr-files-changed": return "Files changed";
		default: return "unrecognized reference";
	}
}
function referenceID(ref) {
	switch (ref.type) {
		case "figma": return `${ref.type}-${ref.url}`;
		case "file": return `${ref.type}-${ref.repoOwner}/${ref.repoName}@${ref.commitOID}:${ref.path}`;
		case "folder": return `${ref.type}-${ref.repoOwner}/${ref.repoName}@${ref.ref}:${ref.path}`;
		case "file-changes": return `${ref.type}-${ref.repository.owner}/${ref.repository.owner}@${ref.ref}:${ref.path}`;
		case "file-diff": return `${ref.type}:${ref.baseFile?.path}@${ref.baseFile?.commitOID}-${ref.headFile?.path}@${ref.headFile?.commitOID}##${ref.selectedRange?.start}-${ref.selectedRange?.end}`;
		case "snippet": return `${ref.type}-${ref.repoOwner}/${ref.repoName}@${ref.commitOID}:${ref.path}#${ref.range.start}-${ref.range.end}`;
		case "repository": return `${ref.type}-${ref.id}-${ref.ownerLogin}/${ref.name}`;
		case "symbol": return `${ref.type}-${ref.kind}-${ref.name}`;
		case "commit": return `${ref.type}-@${ref.oid}-${ref.repository.owner}/${ref.repository.name}`;
		case "pull-request": return `${ref.type}-${ref.id}-${ref.repository.ownerLogin}/${ref.repository.name}`;
		case "web-search": return `${ref.type}-${ref.query}`;
		case "web-search-result": return `${ref.type}-${ref.url}`;
		case "workspace-terminal-log": return `${ref.type}-${ref.repoOwner}/${ref.repoName}@${ref.pullRequestID}`;
		case "repo-instructions": return `${ref.type}-.github/custom-instructions.md`;
		case "image": return `${ref.type}-${ref.id}/${ref.name}`;
		case "issue": return `${ref.repository.owner}/${ref.repository.name}#${ref.number}`;
		case "discussion": return `${ref.repository.owner}/${ref.repository.name}#${ref.number}`;
		case "draft-issue":
		case "draft-update-issue": return `${ref.type}-${ref.tag}`;
		case "text": return `${ref.type}-${ref.name}`;
		case "thread-scoped-file": return `${ref.type}-${ref.name}`;
		case "thread-scoped-snippet": return `${ref.type}-${ref.name}-${ref.range.start}-${ref.range.end}`;
		case "loop-node": return `${ref.type}-${ref.id}`;
		case "loop-execution": return `${ref.type}-${ref.executionID}`;
		case "loading": return `${ref.type}-${ref.id}`;
		case "copilot-space": return `${ref.type}`;
		case "github-url": return `${ref.type}-${ref.url}`;
		case "job": return `${ref.type}-${ref.id}`;
		default: return "";
	}
}
var renderableReferenceTypesCache = void 0;
/**
* Set of reference types that are able to be displayed to the user. All of these must be supported by `referenceName`
* and `referenceId` have icons defined in ReferenceToken.
*/
var renderableReferenceTypes = () => renderableReferenceTypesCache ??= new Set([
	"commit",
	"discussion",
	"figma",
	"file",
	"file-v2",
	"file-diff",
	"folder",
	"issue",
	"job",
	"draft-issue",
	"draft-update-issue",
	"pull-request",
	"org-instructions",
	"repo-instructions",
	"snippet",
	"symbol",
	"third-party",
	"web-search",
	"web-search-result",
	"image",
	"thread-scoped-file",
	"thread-scoped-snippet",
	"loading",
	"loop-node",
	"repository",
	"copilot-space",
	"loop-execution",
	"github-url"
]);
function getRenderableReferences(references) {
	const newReferences = [];
	for (const reference of references ?? []) {
		if (!renderableReferenceTypes().has(reference.type)) continue;
		if (reference.type === "web-search") {
			for (const webSearchResult of reference.results) {
				const webSearchResultReference = {
					...webSearchResult,
					type: "web-search-result"
				};
				newReferences.push(webSearchResultReference);
			}
			continue;
		}
		newReferences.push(reference);
	}
	return newReferences;
}
function isMarkdown(reference) {
	if (reference.type !== "file" && reference.type !== "snippet") return false;
	if (!reference.languageName) return false;
	return reference.languageName.toLowerCase() === "markdown";
}
function plainRenderableUrl(ref) {
	if (isMarkdown(ref)) {
		const url = new URL(ref.url, window.location.origin);
		url.search = "plain=1";
		return url.href;
	}
	return ref.url;
}
function referenceURL(ref) {
	switch (ref.type) {
		case "repository": return `/${ref.ownerLogin}/${ref.name}`;
		case "commit": return ref.permalink;
		case "third-party": return ref.displayUrl;
		case "snippet": return plainRenderableUrl(ref);
		case "job": return jobRefUrl(ref) ?? "#";
		case "loop-node": return ref.url ?? "#";
		case "loop-execution": return `/copilot/l/${ref.loopID}?version=${ref.version}`;
		case "issue":
		case "figma":
		case "file":
		case "file-diff":
		case "folder":
		case "pull-request":
		case "discussion":
		case "repo-instructions":
		case "org-instructions":
		case "web-search-result":
		case "github-url": return ref.url;
		default: return "#";
	}
}
function validReferenceURL(url) {
	return url !== "#" && url !== "";
}
/**
* Returns the folder of the reference.
*
* e.g. for "/foo/bar/file.ts" returns "foo/bar"
*/
function referencePath(ref) {
	const split = ref.path.split("/");
	split.pop();
	if (split.length === 0) return "/";
	else return split.join("/");
}
/**
* Returns the file name of the reference.
*
* e.g. for "/foo/bar/file.ts" returns "file.ts"
*/
function referenceFileName(ref) {
	return fileRefName(ref);
}
function fileRefName(ref) {
	return ref.path.split("/").pop() || ref.path;
}
function fileDiffRefName(ref) {
	const fileName = (ref.headFile?.path ?? ref.baseFile?.path)?.split("/").pop() ?? "";
	if (!ref.selectedRange || !ref.selectedRange.start) return fileName;
	if (!ref.selectedRange.end || ref.selectedRange.start === ref.selectedRange.end) return `${fileName} ${ref.selectedRange.start}`;
	return `${fileName} ${ref.selectedRange.start}-${ref.selectedRange.end}`;
}
function snippetRefName(ref) {
	if (ref.title) return ref.title;
	return `${ref.path.split("/").pop()}:${`${ref.range.start}-${ref.range.end}`}`;
}
function repoRefName(ref) {
	return `${ref.ownerLogin}/${ref.name}`;
}
function diffRefName(ref) {
	return `${ref.baseRevision.substring(0, 5)}..${ref.headRevision.substring(0, 5)}`;
}
function githubUrlRefName(ref) {
	const previousPageInfo = getPreviousPageInfo();
	if (previousPageInfo?.url.endsWith(ref.url)) return previousPageInfo?.title ?? "Previous page";
	return "Previous page";
}
function jobRefName(ref) {
	if (ref.jobName) return `${ref.jobName}`;
	else if (ref.repoOwner && ref.repoName) return `${ref.repoOwner}/${ref.repoName} workflow run`;
	return `Workflow run.`;
}
function jobRefUrl(ref) {
	if (ref.jobUrl) return ref.jobUrl;
	else if (ref.repoOwner && ref.repoName && ref.workflow) return [
		"",
		ref.repoOwner,
		ref.repoName,
		"actions",
		"runs",
		ref.workflow.id,
		"job",
		ref.id
	].map(encodeURIComponent).join("/");
}
function makeFileReference(file, repository, commitish, oid) {
	const blobPath = repositoryTreePath({
		repo: repository,
		commitish: commitish ?? repository.refInfo.name,
		action: "blob",
		path: file
	});
	return {
		type: "file",
		url: new URL(blobPath, window.location.origin).href,
		path: file,
		repoID: repository.id,
		repoOwner: repository.ownerLogin,
		repoName: repository.name,
		ref: commitish ?? repository.ref,
		commitOID: oid ?? repository.commitOID
	};
}
function makeSnippetReference(file, range, repository) {
	return {
		...makeFileReference(file, repository),
		type: "snippet",
		range: {
			start: range.start,
			end: range.end
		}
	};
}
function makePlaceholderReference(title) {
	return {
		id: crypto.randomUUID(),
		title,
		type: "loading",
		isClientOnly: true
	};
}
function makeFolderReference(path, repository) {
	const treePath = repositoryTreePath({
		repo: repository,
		commitish: repository.refInfo.name,
		action: "tree",
		path
	});
	return {
		type: "folder",
		url: new URL(treePath, window.location.origin).href,
		path,
		repoID: repository.id,
		repoOwner: repository.ownerLogin,
		repoName: repository.name,
		ref: repository.ref
	};
}
function makeRepositoryReference(repo) {
	return {
		...repo,
		type: "repository"
	};
}
function makeOrgInstructionsReference(owner) {
	return {
		owner: `${owner} Instructions`,
		type: "org-instructions",
		url: "https://docs.github.com/en/copilot/customizing-copilot/adding-organization-custom-instructions-for-github-copilot"
	};
}
function isRepository(repo) {
	return !!repo;
}
function getCustomInstructionsFromReferences(references) {
	return references.reduce((list, ref) => {
		const repoRef = ref;
		if ("customInstructions" in repoRef && Array.isArray(repoRef.customInstructions)) list.push(...repoRef.customInstructions);
		return list;
	}, []);
}
/**
* Async version of getCustomInstructionsFromReferences that also handles FileReference types.
* For FileReference, it fetches the repository using the provided fetchRepo function to get custom instructions.
* Fetches all repositories in parallel for better performance.
*
* @param references - Array of chat references to extract custom instructions from
* @param fetchRepo - Function to fetch repository details by ID, returns a RepositoryReference with customInstructions
* @returns Promise resolving to array of custom instructions from all references
*/
async function getCustomInstructionsFromReferencesAsync(references, fetchRepo) {
	const instructions = [];
	const processedRepoIds = /* @__PURE__ */ new Set();
	for (const ref of references) {
		const repoRef = ref;
		if ("customInstructions" in repoRef && Array.isArray(repoRef.customInstructions)) {
			processedRepoIds.add(repoRef.id);
			instructions.push(...repoRef.customInstructions);
		}
	}
	const fileRefRepoIds = /* @__PURE__ */ new Set();
	for (const ref of references) if (isFileReference(ref) && ref.repoID && !processedRepoIds.has(ref.repoID)) fileRefRepoIds.add(ref.repoID);
	if (fileRefRepoIds.size > 0) {
		const repoIds = Array.from(fileRefRepoIds);
		const repoResponses = await Promise.all(repoIds.map((repoID) => fetchRepo(repoID)));
		for (const repoResponse of repoResponses) if (repoResponse && "customInstructions" in repoResponse && Array.isArray(repoResponse.customInstructions)) instructions.push(...repoResponse.customInstructions);
	}
	return instructions;
}
function hasCustomInstructions(references) {
	return getCustomInstructionsFromReferences(references).length > 0;
}
/**
* Async version of hasCustomInstructions that also handles FileReference types.
* For FileReference, it fetches the repository using the provided fetchRepo function to get custom instructions.
*
* @param references - Array of chat references to check for custom instructions
* @param fetchRepo - Function to fetch repository details by ID
* @returns Promise resolving to true if any references have custom instructions
*/
async function hasCustomInstructionsAsync(references, fetchRepo) {
	return (await getCustomInstructionsFromReferencesAsync(references, fetchRepo)).length > 0;
}
/**
*
* Returns a list of comma separated owners from the custom instructions in the references.
* For repository references, this will be the NWO (owner/repo) of the repository.
* This is solely for hydro telemetry.
* Example:
* ```
* 'github/github,github/copilot-api'
* ```
*/
function customInstructionsOwnersFromReferences(references) {
	return getCustomInstructionsFromReferences(references).map((instruction) => instruction.owner).join(",");
}
/**
* Async version of customInstructionsOwnersFromReferences that also handles FileReference types.
* For FileReference, it fetches the repository using the provided fetchRepo function to get custom instructions.
*
* Returns a list of comma separated owners from the custom instructions in the references.
* For repository references, this will be the NWO (owner/repo) of the repository.
* This is solely for hydro telemetry.
* Example:
* ```
* 'github/github,github/copilot-api'
* ```
*
* @param references - Array of chat references to extract custom instructions from
* @param fetchRepo - Function to fetch repository details by ID
* @returns Promise resolving to comma-separated string of owners
*/
async function customInstructionsOwnersFromReferencesAsync(references, fetchRepo) {
	return (await getCustomInstructionsFromReferencesAsync(references, fetchRepo)).map((instruction) => instruction.owner).join(",");
}
function referencesAreEqual(a, b) {
	if (a === b) return true;
	if (a === void 0 || b === void 0) return false;
	return referenceID(a) === referenceID(b);
}
function referenceArraysAreEqual(a, b) {
	if (a === void 0 && b === void 0) return true;
	if (a === void 0 || b === void 0) return false;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (!referencesAreEqual(a[i], b[i])) return false;
	return true;
}
function isFileReference(reference) {
	return reference?.type === "file";
}
function isCopilotSpaceReference(reference) {
	return reference.type === "copilot-space";
}
/**
* Returns the author of a message.
*/
function findAuthor(message, currentUserLogin) {
	if (message.role === "user") return {
		name: currentUserLogin,
		avatarURL: `/${currentUserLogin}.png`,
		type: "user"
	};
	if (message.references) {
		const agentReference = message.references.find((ref) => ref.type === "github.agent");
		if (agentReference) return {
			name: agentReference.login,
			avatarURL: agentReference.avatarURL,
			type: "agent"
		};
	}
	return {
		name: "Copilot",
		avatarURL: "",
		type: "copilot"
	};
}
function isAgent(author) {
	return author.type === "agent";
}
/**
* Finds all the agents who have sent messages to the thread.
*/
function findAgentCorrespondents(messages) {
	const agentMessages = messages.map((message) => findAuthor(message, "")).filter((author) => author?.type === "agent");
	const uniqueAgents = /* @__PURE__ */ new Map();
	for (const agent of agentMessages) uniqueAgents.set(agent.name, agent);
	return Array.from(uniqueAgents.values());
}
function isThreadOlderThan4Hours(thread) {
	const threadUpdatedAt = new Date(thread.updatedAt).getTime();
	return Date.now() - threadUpdatedAt > 14400 * 1e3;
}
function filterUniqueConfirmations(confirmations) {
	if (!confirmations) return [];
	const set = /* @__PURE__ */ new Set();
	return confirmations.filter((confirmation) => {
		const key = JSON.stringify(confirmation.confirmation);
		if (set.has(key)) return false;
		set.add(key);
		return true;
	});
}
function getThreadStaticSuggestions(context) {
	const referenceType = "type" in context && typeof context.type === "string" ? context.type : "repository";
	return {
		referenceType,
		suggestions: shuffle(threadSuggestions[referenceType ? referenceType.replace(/(\.api|-v2)$/, "").toLowerCase() : "default"] || threadSuggestions.default).slice(0, 3)
	};
}
function shuffle(list) {
	const shuffled = list.slice();
	for (let i = shuffled.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		const temp = shuffled[i];
		shuffled[i] = shuffled[j];
		shuffled[j] = temp;
	}
	return shuffled;
}
function srOnlyHeader(author, message) {
	const messageArr = message.split(" ");
	let prefix = `${author} said`;
	if (author === "Timeline") prefix = "The following action was initiated";
	return `${prefix}: ${messageArr.slice(0, messageArr.length < 7 ? messageArr.length : 7).join(" ")}`;
}
export { referencePath as $, getExplainSnippetPrompt as A, isRepository as B, filterUniqueConfirmations as C, getCustomInstructionsFromReferences as D, getCopilotExperiments as E, hasCustomInstructions as F, makeOrgInstructionsReference as G, makeCAPIRequest as H, hasCustomInstructionsAsync as I, makeSnippetReference as J, makePlaceholderReference as K, isAgent as L, getRenderableReferences as M, getSuggestImprovementsPrompt as N, getCustomInstructionsFromReferencesAsync as O, getThreadStaticSuggestions as P, referenceName as Q, isCopilotSpaceReference as R, customInstructionsOwnersFromReferencesAsync as S, findAuthor as T, makeFileReference as U, isThreadOlderThan4Hours as V, makeFolderReference as W, referenceFileName as X, referenceArraysAreEqual as Y, referenceID as Z, UPGRADE_PLAN_URL as _, CopilotLicenseType as a, shuffle as at, copilotFeatureFlags as b, ENABLE_ADDITIONAL_REQUESTS_URL as c, threadName as ct, ERROR_MSG as d, referenceURL as et, MANAGE_BILLING_URL as f, SUPPORTED_FUNCTIONS as g, NullMessageId as h, CopilotChatIntents as i, setPreviousPageInfo as it, getFailedActionsJobPrompt as j, getExplainDiffPrompt as k, ERRORS_BY_STATUS as l, validReferenceURL as lt, ModeSupportName as m, COPILOT_PATH as n, renderableReferenceTypes as nt, CopilotPlan as o, srOnlyHeader as ot, MESSAGE_STREAMING_ERROR_TYPES as p, makeRepositoryReference as q, COPILOT_SPACES_PATH as r, setCopilotExperiments as rt, DialogType as s, suggestedPrompts as st, COPILOT_BILLING_SETTINGS_URL as t, referencesAreEqual as tt, ERRORS_BY_TYPE as u, UPGRADE_TO_PRO_PLAN_URL as v, findAgentCorrespondents as w, customInstructionsOwnersFromReferences as x, buildMessage as y, isFileReference as z };
