import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { t as IS_BROWSER } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { d as sendCustomMetric, o as isStaff, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { i as createPath, o as generatePath } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as getAppTypeHeader } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as getQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { Profiler, createContext, memo, use, useMemo, version } from "react";
import { Fragment as Fragment$1, jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
import { queryOptions } from "@tanstack/react-query";
var QueryRouteQueryType = {
	Blocking: "Blocking",
	Deferred: "Deferred"
};
/**
* Provides a shorthand for creating a `QueryConfig` that reads `payload[routeId].mainQuery` from `embeddedData` on
* page load and via `json` request to the current matched route on soft-navigation. This is the most common use
* case for route-bound query data and should be all that is needed to provide data for most pages.
*/
function mainQuery({ ...opts } = {}) {
	return {
		queryName: "mainQuery",
		queryDeps: ({ pathname }) => ({ pathname }),
		queryFn: opts.queryFn ?? (async ({ routeId, queryDeps }) => {
			const appTypeHeader = getAppTypeHeader("dataRouter");
			return responseJsonToQueryData(await queryFnFetch({ queryDeps: {
				...queryDeps,
				init: {
					...queryDeps?.init,
					headers: {
						...appTypeHeader,
						...queryDeps?.init?.headers
					}
				}
			} }, { encodePath: opts.encodeFetchPath ?? false }), routeId);
		}),
		type: QueryRouteQueryType.Blocking,
		select: selectDataFromQueryData,
		...opts
	};
}
function responseJsonToQueryData(json, routeId) {
	const routePayload = json.payload?.[routeId];
	if (!routePayload) throw new Error(`Unable to find payload for route Id: ${routeId}`);
	return {
		meta: json.meta,
		payload: routePayload
	};
}
function selectDataFromQueryData(data) {
	return data.payload;
}
/**
* Generates an app-unique react-query query key based on the data provided.
* This is used to interact with the query client that powers queryRoute.
* @param appName Name of the app that the query is for. This is the top level name of the react app.
* @param routeId The unique identifier for the route that the current router matched.
* @param path The path that the router matched. This is the path match pattern (ie `/path/:id`), not the path that was generated for the route (ie `/path/123`).
* @param queryName The key of the QueryConfig in the route.queries object in the query route registration.
* @param queryDeps An object that uniquely identifies a query's fetch function. In a `QueryRoute`'s `QueryConfig`, this is the return value from `queryDeps`.
* @returns A unique query key that can be used to interact with the query client. In the form of [appName, path, queryName, queryDeps?].
*/
function makeQueryKey({ appName, routeId, routePath, queryName, queryDeps }) {
	return [
		appName,
		routeId,
		routePath,
		queryName,
		queryDeps
	];
}
/**
* Converts a RouteQueryKey array into an object with named properties.
* This is used to provide type safety to the queryFn of a QueryRoute's QueryConfig.
* @param queryKey The query key to convert. This is in the form of [appName, path, queryName, queryDeps?].
* @returns An object with named properties for each part of the query key.
*/
function queryKeyObjFromKey(queryKey) {
	return {
		appName: queryKey[0],
		routeId: queryKey[1],
		routePath: queryKey[2],
		queryName: queryKey[3],
		queryDeps: queryKey[4]
	};
}
var { getItem, setItem, removeItem } = safeStorage("localStorage");
var REACT_PROFILING_DISABLED_UNTIL = "REACT_PROFILING_DISABLED_UNTIL";
var OPT_OUT_DURATION_MS = 1440 * 60 * 1e3;
var PRODUCTION_ENABLEMENT_RATE = .02;
var cachedEnabled;
/**
* Checks if the user has opted out of profiling (localStorage-based).
* Returns true if NOT opted out (or opt-out expired).
*/
function isNotOptedOut() {
	const disabledUntil = getItem(REACT_PROFILING_DISABLED_UNTIL);
	if (!disabledUntil) return true;
	const expiresAt = Number(disabledUntil);
	if (Number.isNaN(expiresAt) || Date.now() >= expiresAt) {
		removeItem(REACT_PROFILING_DISABLED_UNTIL);
		return true;
	}
	return false;
}
/**
* Controls React profiling for users.
*
* Enablement rules:
* - Staff users: Enabled by default (can opt-out for 24 hours via `disable()`)
* - Production users: Enabled for 2% randomly (session-stable)
*
* - `enable()`: Removes the opt-out, restoring default profiling behavior immediately
* - `disable()`: Opts out of profiling for 24 hours (staff only)
* - `isEnabled()`: Returns true if profiling is enabled for this session
* - `resetCache()`: Resets the cached decision (for testing only)
*/
var ReactProfilingMode = {
	enable: () => {
		removeItem(REACT_PROFILING_DISABLED_UNTIL);
		cachedEnabled = void 0;
	},
	disable: () => {
		setItem(REACT_PROFILING_DISABLED_UNTIL, String(Date.now() + OPT_OUT_DURATION_MS));
		cachedEnabled = false;
	},
	isEnabled: () => {
		if (typeof window === "undefined") return false;
		if (cachedEnabled !== void 0) return cachedEnabled;
		if (isStaff()) {
			cachedEnabled = isNotOptedOut();
			return cachedEnabled;
		}
		cachedEnabled = Math.random() < PRODUCTION_ENABLEMENT_RATE;
		return cachedEnabled;
	},
	resetCache: () => {
		cachedEnabled = void 0;
	}
};
/**
* Determines if React Profiler should be enabled for this user session.
*
* Delegates to ReactProfilingMode which handles:
* - Staff users: enabled by default (can opt-out for 24 hours)
* - Production users: enabled for 2% randomly (session-stable)
*
* @returns true if profiling should be enabled, false otherwise
*/
function isReactProfilerEnabled() {
	return ReactProfilingMode.isEnabled();
}
var APP_METRIC_KEYS = {
	actualDuration: "BROWSER_REACT_PROFILER_APP_ACTUAL_DURATION",
	baseDuration: "BROWSER_REACT_PROFILER_APP_BASE_DURATION",
	commitLag: "BROWSER_REACT_PROFILER_APP_COMMIT_LAG",
	renderEfficiency: "BROWSER_REACT_PROFILER_APP_RENDER_EFFICIENCY"
};
var ROUTE_METRIC_KEYS = {
	actualDuration: "BROWSER_REACT_PROFILER_ROUTE_ACTUAL_DURATION",
	baseDuration: "BROWSER_REACT_PROFILER_ROUTE_BASE_DURATION",
	commitLag: "BROWSER_REACT_PROFILER_ROUTE_COMMIT_LAG",
	renderEfficiency: "BROWSER_REACT_PROFILER_ROUTE_RENDER_EFFICIENCY"
};
var PHASE_SAMPLE_RATES = {
	mount: .2,
	update: .02,
	"nested-update": .2
};
var SLOW_THRESHOLDS = {
	mount: 50,
	update: 32,
	"nested-update": 16
};
var COMMIT_LAG_THRESHOLD = 50;
var IDLE_CALLBACK_TIMEOUT = 2e3;
function shouldSample(phase, actualDuration, commitLag, sessionSampleKey) {
	if (actualDuration > (SLOW_THRESHOLDS[phase] ?? 50)) return true;
	if (commitLag > COMMIT_LAG_THRESHOLD) return true;
	return sessionSampleKey < PHASE_SAMPLE_RATES[phase];
}
function sendAllProfilerMetrics(keys, tags, actualDuration, baseDuration, commitLag) {
	const requestUrl = window.location.href;
	sendCustomMetric({
		name: keys.actualDuration,
		value: actualDuration,
		tags,
		requestUrl
	}, false, 1);
	sendCustomMetric({
		name: keys.baseDuration,
		value: baseDuration,
		tags,
		requestUrl
	}, false, 1);
	sendCustomMetric({
		name: keys.commitLag,
		value: commitLag,
		tags,
		requestUrl
	}, false, 1);
	if (baseDuration > 0) sendCustomMetric({
		name: keys.renderEfficiency,
		value: actualDuration / baseDuration,
		tags,
		requestUrl
	}, false, 1);
}
function sendAppProfileMetrics({ actualDuration, baseDuration, commitLag, phase, appName, isDataRouterEnabled }) {
	sendAllProfilerMetrics(APP_METRIC_KEYS, {
		phase,
		appName,
		isDataRouterEnabled: String(isDataRouterEnabled),
		reactVersion: version
	}, actualDuration, baseDuration, commitLag);
}
function sendRouteProfileMetrics({ actualDuration, baseDuration, commitLag, phase, appName, isDataRouterEnabled, routeId }) {
	sendAllProfilerMetrics(ROUTE_METRIC_KEYS, {
		phase,
		appName,
		routeId,
		isDataRouterEnabled: String(isDataRouterEnabled),
		reactVersion: version
	}, actualDuration, baseDuration, commitLag);
}
var sessionSampleKey = null;
function getSessionSampleKey() {
	if (typeof window === "undefined") return 1;
	if (sessionSampleKey === null) sessionSampleKey = Math.random();
	return sessionSampleKey;
}
var noopCallback = () => {};
var DISABLED_RESULT = {
	onAppRender: noopCallback,
	onRouteRender: noopCallback,
	isEnabled: false
};
function useAppScopedProfilerCollector(t0) {
	const $ = c(9);
	const { appName, isDataRouterEnabled } = t0;
	let t1;
	bb0: {
		if (!isReactProfilerEnabled()) {
			t1 = DISABLED_RESULT;
			break bb0;
		}
		let t2;
		if ($[0] !== appName || $[1] !== isDataRouterEnabled) {
			t2 = (_id, phase, actualDuration, baseDuration, startTime, commitTime) => {
				requestIdleCallback(() => {
					const commitLag = commitTime - startTime;
					if (!shouldSample(phase, actualDuration, commitLag, getSessionSampleKey())) return;
					sendAppProfileMetrics({
						actualDuration,
						baseDuration,
						commitLag,
						phase,
						appName,
						isDataRouterEnabled
					});
				}, { timeout: IDLE_CALLBACK_TIMEOUT });
			};
			$[0] = appName;
			$[1] = isDataRouterEnabled;
			$[2] = t2;
		} else t2 = $[2];
		const onAppRender = t2;
		let t3;
		if ($[3] !== appName || $[4] !== isDataRouterEnabled) {
			t3 = (id, phase_0, actualDuration_0, baseDuration_0, startTime_0, commitTime_0) => {
				requestIdleCallback(() => {
					const commitLag_0 = commitTime_0 - startTime_0;
					if (!shouldSample(phase_0, actualDuration_0, commitLag_0, getSessionSampleKey())) return;
					sendRouteProfileMetrics({
						actualDuration: actualDuration_0,
						baseDuration: baseDuration_0,
						commitLag: commitLag_0,
						phase: phase_0,
						appName,
						isDataRouterEnabled,
						routeId: id
					});
				}, { timeout: IDLE_CALLBACK_TIMEOUT });
			};
			$[3] = appName;
			$[4] = isDataRouterEnabled;
			$[5] = t3;
		} else t3 = $[5];
		const onRouteRender = t3;
		let t4;
		if ($[6] !== onAppRender || $[7] !== onRouteRender) {
			t4 = {
				onAppRender,
				onRouteRender,
				isEnabled: true
			};
			$[6] = onAppRender;
			$[7] = onRouteRender;
			$[8] = t4;
		} else t4 = $[8];
		t1 = t4;
	}
	return t1;
}
var ProfilerContext = createContext(null);
ProfilerContext.displayName = "ProfilerContext";
var ProfilerProvider = memo(function ProfilerProvider(t0) {
	const $ = c(6);
	const { isDataRouterEnabled, appName, children } = t0;
	let t1;
	if ($[0] !== appName || $[1] !== isDataRouterEnabled) {
		t1 = {
			appName,
			isDataRouterEnabled
		};
		$[0] = appName;
		$[1] = isDataRouterEnabled;
		$[2] = t1;
	} else t1 = $[2];
	const contextValue = useAppScopedProfilerCollector(t1);
	let t2;
	if ($[3] !== children || $[4] !== contextValue) {
		t2 = jsx(ProfilerContext, {
			value: contextValue,
			children
		});
		$[3] = children;
		$[4] = contextValue;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
});
ProfilerProvider.displayName = "ProfilerProvider";
var useProfilerOnRender = (profilerType) => {
	const contextValue = use(ProfilerContext);
	if (!contextValue) return noop;
	return profilerType === "app" ? contextValue.onAppRender : contextValue.onRouteRender;
};
/**
* Profiler wrapper that conditionally renders React's Profiler component.
* When profiling is disabled, children are rendered directly without any Profiler overhead.
* This ensures zero performance impact for users without profiling enabled.
*/
var Profiler$1 = memo(function Profiler$2(t0) {
	const $ = c(4);
	const { id, children, profilerType } = t0;
	const onRender = useProfilerOnRender(profilerType);
	let t1;
	if ($[0] !== children || $[1] !== id || $[2] !== onRender) {
		t1 = jsx(Profiler, {
			id,
			onRender,
			children
		});
		$[0] = children;
		$[1] = id;
		$[2] = onRender;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
});
/**
* AppProfiler is a specialized Profiler for app-level performance tracking.
* It uses the 'app' profiler type to report metrics separately from route-level metrics.
*/
Profiler$1.displayName = "Profiler";
var AppProfiler = memo(function AppProfiler({ id, children }) {
	return /* @__PURE__ */ jsx(Profiler$1, {
		id,
		profilerType: "app",
		children
	});
});
/**
* RouteProfiler is a specialized Profiler for route-level performance tracking.
* It uses the 'route' profiler type to report metrics separately from app-level metrics.
*/
AppProfiler.displayName = "AppProfiler";
var RouteProfiler = memo(function RouteProfiler({ id, children }) {
	return /* @__PURE__ */ jsx(Profiler$1, {
		id,
		profilerType: "route",
		children
	});
});
RouteProfiler.displayName = "RouteProfiler";
/**
* Creates a wrapper Component that renders the content inside a RouteProfiler.
* Preserves the original Component's preload and ssr properties for SSR preloading.
*/
function wrapComponentWithProfiler(profilerId, { element, Component }) {
	if (!element && !Component) return void 0;
	const ProfilerWrapper = () => {
		let node = null;
		if (element !== void 0) node = /* @__PURE__ */ jsx(Fragment$1, { children: element });
		else if (Component) node = /* @__PURE__ */ jsx(Component, {});
		if (!node) return null;
		return /* @__PURE__ */ jsx(RouteProfiler, {
			id: profilerId,
			children: node
		});
	};
	ProfilerWrapper.displayName = "ProfilerWrapper";
	if (Component?.preload) ProfilerWrapper.preload = Component.preload;
	if (Component?.ssr !== void 0) ProfilerWrapper.ssr = Component.ssr;
	return ProfilerWrapper;
}
var QUERY_ROUTE_QUERY_CLIENT_DEFAULTS = {
	refetchOnWindowFocus: false,
	retry: false,
	networkMode: "always",
	staleTime: 1e3 * 60 * 60 * 24
};
var QueryRoute = class {
	#appName;
	#getEmbeddedData;
	#shouldRevalidate;
	id;
	path;
	queries;
	index;
	constructor(args) {
		this.#appName = args.appName;
		this.id = args.id;
		this.path = args.path;
		this.queries = this.#processQueries(args.queries);
		this.index = args.index;
		this.#getEmbeddedData = args.getEmbeddedData;
		this.#shouldRevalidate = args.shouldRevalidate;
	}
	#processQueries(queries) {
		return Object.fromEntries(objectEntries(queries).map(([queryName, queryConfig]) => {
			const makeQueryKey$1 = (queryDeps) => makeQueryKey({
				appName: this.#appName,
				routeId: this.id,
				routePath: this.path,
				queryName: queryName.toString(),
				queryDeps: queryDeps ?? {}
			});
			return [queryName, {
				...queryConfig,
				makeQueryKey: makeQueryKey$1
			}];
		}));
	}
	/**
	* Validates whether an argument is the same as the route
	*
	* We don't want to do a pure equality check like `Object.is` since on hydration
	* we might have different/similar objects.
	*
	* Doing a simple `id === id` check since this is most commonly going to catch issues
	* should there be any without doing a real deepEquality check
	*/
	isSameRoute(route) {
		return Boolean(typeof route === "object" && route && "id" in route && typeof route.id === "string" && route.id === this.id);
	}
	/**
	* Given a params object generates a valid pathname for the route.
	* Optionally search parameters and/or a hash can be passed.
	*/
	generatePath(params, args) {
		return createPath({
			pathname: generatePath(this.path, params),
			search: args?.search ? new URLSearchParams(args.search).toString() : void 0,
			hash: args?.hash
		});
	}
	#initializeQueryFromEmbeddedData({ queryName, queryKey }) {
		const queryClient = getQueryClient();
		const embeddedData = this.#getEmbeddedData();
		const embeddedDataPayload = embeddedData?.payload;
		const initialData = this.#buildInitialDataForQueryClient({
			embeddedData,
			queryName
		});
		if (initialData) {
			if (queryName === "mainQuery") delete embeddedDataPayload?.[this.id];
			else {
				delete embeddedDataPayload?.[String(queryName)];
				delete embeddedDataPayload?.[this.id]?.[queryName];
			}
			queryClient.setQueryData(queryKey, initialData);
		}
	}
	/**
	* The react-route compatible loader. This loops through each query defined on the route,
	* fetching or prefetching the data as necessary.
	*/
	#loader = async ({ request, params }) => {
		const blockingRequests = [];
		const { searchParams } = new URL(request.url, ssrSafeLocation.origin);
		const pathname = toQualifiedPath(this.path, params);
		const queryClient = getQueryClient();
		const queryConfigs = objectEntries(this.queries).map(([queryName, { queryFn, queryDeps, makeQueryKey, type = QueryRouteQueryType.Deferred, staleTimeForNavigation = 200, navigationBehavior = "stale-while-revalidate", enabled, ...config }]) => {
			const queryKey = makeQueryKey(queryDeps?.({
				pathname,
				params,
				searchParams
			}) ?? {});
			const queryConfig = queryOptions({
				...QUERY_ROUTE_QUERY_CLIENT_DEFAULTS,
				queryKey,
				queryFn: ({ signal, meta }) => {
					return queryFn(queryKeyObjFromKey(queryKey), {
						signal,
						meta
					});
				},
				enabled,
				...config
			});
			const isEnabled = typeof enabled === "function" ? enabled() : enabled ?? true;
			if (isEnabled) this.#initializeQueryFromEmbeddedData({
				queryName,
				queryKey: queryConfig.queryKey
			});
			if (IS_BROWSER && isEnabled) {
				const fetchConfig = {
					...queryConfig,
					staleTime: staleTimeForNavigation
				};
				switch (type) {
					case QueryRouteQueryType.Deferred:
						/**
						* Deferred queries use prefetch to avoid throwing/rejecting on failure.
						* We initiate these requests during navigation, but we don't await them, so they
						* can resolve anytime between now and well after navigation completes.
						*/
						queryClient.prefetchQuery(fetchConfig);
						break;
					case QueryRouteQueryType.Blocking: {
						/**
						* Immediately returns stale data if it exists, but fetches updates in the background
						* this gives us a default `stale-while-revalidate` behavior.
						*
						* We may later make this configureable with a `blockingQueryBehavior` of `stale-while-revalidate` or `revalidate`
						*/
						const state = queryClient.getQueryState(fetchConfig.queryKey);
						if (!state || state.status === "pending" || state.status === "error" || state.fetchStatus === "fetching") blockingRequests.push(queryClient.fetchQuery(fetchConfig));
						else if (Date.now() - state.dataUpdatedAt >= staleTimeForNavigation) {
							queryClient.invalidateQueries({ queryKey: fetchConfig.queryKey });
							if (navigationBehavior === "network-first") blockingRequests.push(queryClient.fetchQuery(fetchConfig));
						}
						break;
					}
					default: throw new Error(`Invalid QueryRouteQueryType defined, \`${type}\`. Valid QueryRouteQueryTypes are ${JSON.stringify(Object.keys(QueryRouteQueryType))}`);
				}
			}
			return [queryName, {
				queryConfig,
				type
			}];
		});
		await Promise.all(blockingRequests);
		return {
			route: this,
			queries: Object.fromEntries(queryConfigs)
		};
	};
	/**
	* Given components and children to render, returns a react-router compatible route
	* definition implementing the `QueryRoute` logic.
	*/
	toRoute = ({ Component, element, ...args }) => {
		const WrappedComponent = wrapComponentWithProfiler(this.id, {
			element,
			Component
		});
		const shouldRevalidate = this.#shouldRevalidate;
		if (this.index) return {
			...args,
			id: this.id,
			children: void 0,
			path: this.path,
			index: this.index,
			loader: this.#loader,
			shouldRevalidate,
			Component: WrappedComponent
		};
		return {
			...args,
			id: this.id,
			path: this.path,
			index: this.index,
			loader: this.#loader,
			shouldRevalidate,
			Component: WrappedComponent
		};
	};
	#buildInitialDataForQueryClient({ embeddedData, queryName }) {
		const embeddedDataPayload = embeddedData?.payload;
		let routePayload;
		if (queryName === "mainQuery") routePayload = embeddedDataPayload?.[this.id];
		else routePayload = embeddedDataPayload?.[String(queryName)] || embeddedDataPayload?.[this.id]?.[queryName];
		if (!routePayload) return;
		if (queryName !== "mainQuery") return routePayload;
		const embeddedDataTitle = embeddedData?.title || embeddedData?.meta?.title;
		return {
			meta: embeddedDataTitle ? { title: embeddedDataTitle } : void 0,
			payload: routePayload
		};
	}
};
/**
* Given a `routePath` path pattern and a loader-like params object return a
* string with the params replacing the pattern
*/
function toQualifiedPath(routePath, params) {
	return generatePath(routePath, translateUndefinedToNull(params));
}
/**
* Given an object with potentially undefined parameters map those to `null`
*
* This is mostly useful for mapping an object from a loader params shape
* to a generatePath params shape
*/
function translateUndefinedToNull(input) {
	return Object.fromEntries(objectEntries(input).map(([key, value]) => [key, value === void 0 ? null : value]));
}
/**
* A small type-safe wrapper around `Object.entries`
*
* By default, typescript makes the entries keys `string` typed only (as it does for Object.keys)
* this assumes a bit more stable structure around the entries
*/
var objectEntries = (obj) => {
	return Object.entries(obj);
};
var DataRouterApplication = class {
	name;
	#routesOrGetRoutes;
	embeddedData;
	constructor(name, routesOrGetRoutes) {
		this.name = name;
		this.#routesOrGetRoutes = routesOrGetRoutes;
		this.registration = this.registration.bind(this);
	}
	registration(opts) {
		this.embeddedData = opts?.embeddedData;
		return { routes: this.#getRoutes() };
	}
	#getRoutes() {
		if (typeof this.#routesOrGetRoutes === "function") {
			const isEnabled = (featureName) => {
				const enabledFeatures = this.embeddedData?.appPayload?.enabled_features;
				if (!enabledFeatures || !(featureName in enabledFeatures)) return;
				return enabledFeatures[featureName];
			};
			return this.#routesOrGetRoutes({ isEnabled });
		}
		return this.#routesOrGetRoutes;
	}
};
var DataRouterApplicationBuilder = class DataRouterApplicationBuilder {
	static create(name) {
		return new DataRouterApplicationBuilder(name);
	}
	name;
	#app;
	constructor(name) {
		this.name = name;
	}
	getEmbeddedData = () => {
		if (!this.#app) throw new Error("getEmbeddedData should only be called after createDataRouterAppFromRoutes");
		return this.#app.embeddedData;
	};
	createDataRouterAppFromRoutes(routes) {
		this.#app = new DataRouterApplication(this.name, routes);
		return this.#app;
	}
	/**
	* Creates a query route config with a variadic list of queries.
	* Each query's name, deps, response type, and query type are inferred from the provided config.
	* The returned QueryRoute merges all query configs into a single keyed record type.
	*/
	createQueryRouteConfig(id, { path, index, queries, shouldRevalidate }) {
		const resolvedQueries = queries ?? [];
		assertCamelCase(id);
		return new QueryRoute({
			appName: this.name,
			id,
			path,
			queries: toKeyedQueries(resolvedQueries, id),
			index: index ?? false,
			getEmbeddedData: this.getEmbeddedData,
			shouldRevalidate
		});
	}
};
var DuplicateRouteQueryNameError = class extends Error {
	constructor(queryName) {
		super(`query names cannot be duplicated: \`${queryName}\` has already been defined for this route.`);
		this.name = "DuplicateRouteQueryNameError";
	}
};
function toKeyedQueries(queries, id) {
	const registeredQueryNames = /* @__PURE__ */ new Set();
	return Object.fromEntries(queries.map((configOrGenerator) => {
		let query;
		if (typeof configOrGenerator === "function") query = configOrGenerator(id);
		else query = configOrGenerator;
		const { queryName, ...config } = query;
		if (registeredQueryNames.has(queryName)) throw new DuplicateRouteQueryNameError(queryName);
		registeredQueryNames.add(queryName);
		return [queryName, config];
	}));
}
function assertCamelCase(str) {
	if (!/^[a-z][a-zA-Z0-9]*$/.test(str)) throw new InvalidIdentifierError(str);
}
var InvalidIdentifierError = class extends Error {
	constructor(str) {
		super(`\`${str}\` must be camel cased`);
		this.name = "InvalidIdentifierError";
	}
};
export { QueryRouteQueryType as n, mainQuery as r, DataRouterApplicationBuilder as t };
