import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { createContext, use, useEffect, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* Hook to manage URL-based list results state for repository search.
* Handles query parameters, pagination, and navigation for repository lists.
*
* @param params Configuration object
* @param params.defaultFilterValue Default filter value to use when no query param is present
* @returns An object containing:
*   - fetchedQuery: The active query (empty string if explicitly cleared)
*   - queryParam: The raw query parameter from URL (or default value)
*   - currentPage: The current page number from URL
*   - fetchResults: Function to navigate to new search results
*   - locationSidebarItemId: The sidebar item ID saved along with the URL
*/
function useListResults(t0) {
	const $ = c(15);
	const { defaultFilterValue: t1 } = t0;
	const defaultFilterValue = t1 === void 0 ? "" : t1;
	const navigate = useNavigate$1();
	const location = useLocation$1();
	const { isBrowser } = useRuntimeEnvironment();
	const locationState = isBrowser ? location.state : void 0;
	const locationSidebarItemId = locationState?.sidebarItemId;
	const currentParams = new URLSearchParams(location.search);
	const [isEmptyQuery, setIsEmptyQuery] = useState(false);
	const queryParam = currentParams.get("q") || defaultFilterValue;
	const fetchedQuery = isEmptyQuery ? "" : queryParam;
	let t2;
	if ($[0] !== setIsEmptyQuery) {
		t2 = () => {
			setIsEmptyQuery(false);
		};
		$[0] = setIsEmptyQuery;
		$[1] = t2;
	} else t2 = $[1];
	useEffect(t2, [queryParam]);
	const currentPage = Number(currentParams.get("page") || 1);
	let t3;
	if ($[2] !== defaultFilterValue || $[3] !== location.pathname || $[4] !== locationSidebarItemId || $[5] !== navigate || $[6] !== setIsEmptyQuery) {
		t3 = function fetchResults(t4) {
			const { q, page: t5, sidebarItemId: t6 } = t4;
			const page = t5 === void 0 ? 1 : t5;
			const sidebarItemId = t6 === void 0 ? locationSidebarItemId : t6;
			if (!q) {
				setIsEmptyQuery(true);
				return;
			}
			const navigateParams = new URLSearchParams();
			if (q && q !== defaultFilterValue) navigateParams.set("q", q);
			if (page > 1) navigateParams.set("page", page.toString());
			const search = navigateParams.toString();
			navigate({
				pathname: location.pathname,
				search: search ? `?${search}` : ""
			}, sidebarItemId ? { state: { sidebarItemId } } : void 0);
		};
		$[2] = defaultFilterValue;
		$[3] = location.pathname;
		$[4] = locationSidebarItemId;
		$[5] = navigate;
		$[6] = setIsEmptyQuery;
		$[7] = t3;
	} else t3 = $[7];
	const fetchResults = t3;
	const t4 = !!locationState;
	let t5;
	if ($[8] !== currentPage || $[9] !== fetchResults || $[10] !== fetchedQuery || $[11] !== locationSidebarItemId || $[12] !== queryParam || $[13] !== t4) {
		t5 = {
			fetchedQuery,
			queryParam,
			currentPage,
			fetchResults,
			locationSidebarItemId,
			hasLocationState: t4
		};
		$[8] = currentPage;
		$[9] = fetchResults;
		$[10] = fetchedQuery;
		$[11] = locationSidebarItemId;
		$[12] = queryParam;
		$[13] = t4;
		$[14] = t5;
	} else t5 = $[14];
	return t5;
}
var ReposFinderStateContext = createContext(null);
ReposFinderStateContext.displayName = "ReposFinderStateContext";
function ReposFinderStateProvider(t0) {
	const $ = c(12);
	const { children, payload } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = { defaultFilterValue: "contributed-by:@me" };
		$[0] = t1;
	} else t1 = $[0];
	const { fetchedQuery, currentPage, fetchResults, queryParam, locationSidebarItemId, hasLocationState } = useListResults(t1);
	let t2;
	if ($[1] !== currentPage || $[2] !== fetchResults || $[3] !== fetchedQuery || $[4] !== hasLocationState || $[5] !== locationSidebarItemId || $[6] !== payload || $[7] !== queryParam) {
		t2 = {
			payload,
			fetchedQuery,
			currentPage,
			fetchResults,
			queryParam,
			locationSidebarItemId,
			hasLocationState
		};
		$[1] = currentPage;
		$[2] = fetchResults;
		$[3] = fetchedQuery;
		$[4] = hasLocationState;
		$[5] = locationSidebarItemId;
		$[6] = payload;
		$[7] = queryParam;
		$[8] = t2;
	} else t2 = $[8];
	const value = t2;
	let t3;
	if ($[9] !== children || $[10] !== value) {
		t3 = jsx(ReposFinderStateContext, {
			value,
			children
		});
		$[9] = children;
		$[10] = value;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
ReposFinderStateProvider.displayName = "ReposFinderStateProvider";
function useReposFinderStateContext() {
	const context = use(ReposFinderStateContext);
	if (!context) throw new Error("useReposFinderStateContext must be used within a ReposFinderStateProvider");
	return context;
}
export { useReposFinderStateContext as n, ReposFinderStateProvider as t };
