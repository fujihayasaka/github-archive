performance.mark("js-parse-end:server-IssueBodyEditor-CJ65iLUQ-BUIENlzx.js");
import { Xn as PencilAiIcon, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { a as MarkdownEditor, m as validateIssueBody, t as CommentBox } from "./server-validators-DpH9Vi4K-BgoqazXb.js";
import { n as TEST_IDS, r as useCopilotGeneratePanel, t as CopilotGenerateDescriptionPanel } from "./server-test-ids-BnesLCJj-D-AL_t-I.js";
import { t as LABELS } from "./server-labels-SzbmBfXH-BSw62xIA.js";
import { useEffect, useId, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
performance.mark("js-parse-end:IssueBodyEditor-CJ65iLUQ.js");
var IssueBodyEditor_module_default = {
	copilotWriteButton: "IssueBodyEditor-module_dPiotq_copilotWriteButton",
	editorContainer: "IssueBodyEditor-module_dPiotq_editorContainer",
	validationErrorFlash: "IssueBodyEditor-module_dPiotq_validationErrorFlash"
};
function IssueBodyEditor({ subjectId, subject, body, bodyIsStale, onChange, onCancel, onCommit, editorDisabled = false, trailingIcon = true, repoOwner, repoName, title = "", shouldShowCopilotFunctionality = false }) {
	const [validationError, setValidationError] = useState(void 0);
	const [viewMode, setViewMode] = useState();
	const ref = useRef(null);
	const { isPanelOpen, isGenerating, shouldShowCopilot, togglePanel, handleInputFocus, commands: copilotPanelCommands, panelProps, containerStyle } = useCopilotGeneratePanel({
		editorRef: ref,
		body,
		onChange,
		shouldShowCopilotFunctionality,
		repoOwner,
		repoName,
		title,
		generateTitle: false,
		commandId: "issue-body:open-copilot-panel",
		canToggle: viewMode !== "preview"
	});
	useEffect(() => {
		if (ref && ref.current) ref.current.focus();
	}, [ref]);
	const validationResult = validateIssueBody(body);
	const validationErrorId = useId();
	return /* @__PURE__ */ jsxs(ScopedCommands, {
		commands: copilotPanelCommands,
		children: [/* @__PURE__ */ jsxs("div", {
			className: IssueBodyEditor_module_default.editorContainer,
			style: containerStyle,
			children: [/* @__PURE__ */ jsx(CommentBox, {
				disabled: editorDisabled || isGenerating,
				saveButtonTrailingIcon: trailingIcon,
				subject,
				value: body,
				placeholder: LABELS.issueBodyPlaceholder,
				viewMode,
				onChangeViewMode: setViewMode,
				onChange: (newMarkdown) => {
					if (validationError) setValidationError(void 0);
					onChange(newMarkdown);
				},
				onCancel: () => onCancel(true, ref),
				validationResult: { isValid: true },
				onSave: () => {
					if (validationResult.isValid) onCommit(subjectId);
					else setValidationError(validationResult.errorMessage);
				},
				contentIsStale: bodyIsStale,
				ref,
				label: "Body input",
				"aria-describedby": validationError ? validationErrorId : void 0,
				buttonSize: "medium",
				teamHovercardsEnabled: true,
				minHeightLines: isGenerating ? 8 : void 0,
				toolbarButtons: shouldShowCopilot ? /* @__PURE__ */ jsx(MarkdownEditor.ToolbarButton, {
					className: IssueBodyEditor_module_default.copilotWriteButton,
					variant: "invisible",
					icon: PencilAiIcon,
					size: "small",
					onClick: togglePanel,
					"aria-pressed": isPanelOpen,
					"aria-label": LABELS.copilotCTAButton
				}) : null,
				generatingText: isGenerating,
				onInputFocus: handleInputFocus,
				...testIdProps(TEST_IDS.commentBox("body"))
			}), shouldShowCopilot && isPanelOpen && viewMode !== "preview" && /* @__PURE__ */ jsx(CopilotGenerateDescriptionPanel, { ...panelProps })]
		}), validationError && /* @__PURE__ */ jsxs(Flash, {
			variant: "danger",
			id: validationErrorId,
			className: IssueBodyEditor_module_default.validationErrorFlash,
			children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), validationError]
		})]
	});
}
IssueBodyEditor.displayName = "IssueBodyEditor";
export { IssueBodyEditor };
