import { t as Box } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { jsx } from "react/jsx-runtime";
function PreviewCardOutlet() {
	return /* @__PURE__ */ jsx(Box, {
		className: "Popover js-hovercard-content",
		sx: {
			position: "absolute",
			display: "none",
			outline: "none"
		},
		tabIndex: 0,
		children: /* @__PURE__ */ jsx("div", {
			className: "Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large",
			style: { width: "360px" }
		})
	});
}
PreviewCardOutlet.displayName = "PreviewCardOutlet";
export { PreviewCardOutlet as t };
