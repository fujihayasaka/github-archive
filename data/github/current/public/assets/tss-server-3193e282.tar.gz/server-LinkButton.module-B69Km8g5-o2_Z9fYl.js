var LinkButton_module_default = { linkButton: "LinkButton-module_spLpMa_linkButton" };
export { LinkButton_module_default as t };
