import { t as useTrackingRef } from "./server-use-tracking-ref-CdNeH4dZ-DBOS4qOg.js";
import { useEffect, useMemo } from "react";
import debounce from "lodash-es/debounce.js";
/**
* Get a debounced version of the provided function. A debounced function will wait to be
* called until `waitMs` milliseconds have passed since the last invocation. The result of
* this hook is referentially stable with respect to `fn`, but will change if the other
* parameters change.
*
* @see {@link debounce Lodash's debounce docs} for more details on available options.
*/
var useDebounce = (fn, waitMs, { leading = false, maxWait, trailing = true, onChangeBehavior = "flush" } = {}) => {
	const fnRef = useTrackingRef(fn);
	const debouncedFn = useMemo(() => {
		return debounce((...args) => fnRef.current(...args), waitMs, maxWait === void 0 ? {
			leading,
			trailing
		} : {
			leading,
			trailing,
			maxWait
		});
	}, [
		fnRef,
		waitMs,
		leading,
		maxWait,
		trailing
	]);
	useEffect(() => () => {
		debouncedFn?.[onChangeBehavior]();
	}, [debouncedFn, onChangeBehavior]);
	return debouncedFn;
};
export { useDebounce as t };
