import { Ai as XCircleFillIcon, bn as Link } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
var FlashError_module_default = {
	Flash: "FlashError-module_cvqR3a_Flash",
	Link: "FlashError-module_cvqR3a_Link",
	Octicon: "FlashError-module_cvqR3a_Octicon",
	ruleViolationRow: "FlashError-module_cvqR3a_ruleViolationRow",
	ruleViolationsTitle: "FlashError-module_cvqR3a_ruleViolationsTitle",
	ruleViolationText: "FlashError-module_cvqR3a_ruleViolationText",
	SafeHTMLText: "FlashError-module_cvqR3a_SafeHTMLText"
};
function FlashError({ prefix, errorMessageUsingPrefix, errorMessageNotUsingPrefix, hideRuleErrorsTitle, ruleErrors, helpUrl, flashRef }) {
	const isRuleViolation = (ruleErrors?.length || 0) > 0;
	return errorMessageUsingPrefix || errorMessageNotUsingPrefix ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Flash, {
		id: "flash",
		variant: "danger",
		className: clsx("d-flex flex-items-center flex-justify-between", FlashError_module_default.Flash),
		tabIndex: -1,
		ref: flashRef,
		children: errorMessageUsingPrefix ? /* @__PURE__ */ jsxs("div", { children: [
			prefix,
			" ",
			/* @__PURE__ */ jsx(UnsafeHTMLText, {
				className: FlashError_module_default.SafeHTMLText,
				html: errorMessageUsingPrefix
			}),
			isRuleViolation && helpUrl && /* @__PURE__ */ jsx(Link, {
				href: `${helpUrl}/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets`,
				className: FlashError_module_default.Link,
				children: "Learn more about rulesets."
			})
		] }) : errorMessageNotUsingPrefix && /* @__PURE__ */ jsx("div", { children: errorMessageNotUsingPrefix })
	}), isRuleViolation && /* @__PURE__ */ jsxs("div", {
		className: FlashError_module_default.Flash,
		children: [!hideRuleErrorsTitle && /* @__PURE__ */ jsx("div", {
			className: FlashError_module_default.ruleViolationsTitle,
			children: "Repository rule violations found:"
		}), ruleErrors?.map((rule) => /* @__PURE__ */ jsxs("div", {
			className: FlashError_module_default.ruleViolationRow,
			children: [/* @__PURE__ */ jsx(Octicon, {
				icon: XCircleFillIcon,
				size: 16,
				className: FlashError_module_default.Octicon
			}), /* @__PURE__ */ jsx("div", {
				className: FlashError_module_default.ruleViolationText,
				children: rule
			})]
		}, rule))]
	})] }) : null;
}
FlashError.displayName = "FlashError";
export { FlashError as t };
