performance.mark("js-parse-end:server-CodeMirror-Jr5rxiCl-DkWtYTAE.js");
import { t as CodeMirror } from "./server-CodeMirror-BtlhKpYu-BOBEUoQl.js";
performance.mark("js-parse-end:CodeMirror-Jr5rxiCl.js");
export { CodeMirror as default };
