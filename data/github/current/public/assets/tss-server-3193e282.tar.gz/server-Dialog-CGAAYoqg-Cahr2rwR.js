import { o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Gi as useSlots, Hi as useProvidedRefOrCreate, Mi as XIcon, Vi as useOnEscapePress, an as IconButton } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as useFocusTrap, t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as useOverflow } from "./server-useOverflow-CWkWsgCk-CBzg9WER.js";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
var classes$1 = {
	"Backdrop": "prc-Dialog-Backdrop-5Nt2U",
	"dialog-backdrop-appear": "prc-Dialog-dialog-backdrop-appear-tCG2K",
	"Dialog": "prc-Dialog-Dialog-G8cDF",
	"Overlay--motion-scaleFade": "prc-Dialog-Overlay--motion-scaleFade-mE6-C",
	"Overlay--motion-slideInRight": "prc-Dialog-Overlay--motion-slideInRight-BR-CZ",
	"Overlay--motion-slideInLeft": "prc-Dialog-Overlay--motion-slideInLeft-ISmQZ",
	"Overlay--motion-slideUp": "prc-Dialog-Overlay--motion-slideUp-tPElO",
	"DisableScroll": "prc-Dialog-DisableScroll-UkWFM",
	"DialogOverflowWrapper": "prc-Dialog-DialogOverflowWrapper-JvHzz",
	"detect-scroll": "prc-Dialog-detect-scroll-b3i8Q",
	"Header": "prc-Dialog-Header-f7Me-",
	"HeaderInner": "prc-Dialog-HeaderInner-H-fFY",
	"HeaderContent": "prc-Dialog-HeaderContent-mjAsn",
	"Title": "prc-Dialog-Title-M-iPn",
	"Subtitle": "prc-Dialog-Subtitle-aBFSq",
	"Body": "prc-Dialog-Body-bB903",
	"Footer": "prc-Dialog-Footer-PMeQk"
};
var classes = { "ScrollableRegion": "prc-ScrollableRegion-ScrollableRegion--xtjK" };
function ScrollableRegion(t0) {
	const $ = c(17);
	let children;
	let className;
	let label;
	let labelledby;
	let rest;
	if ($[0] !== t0) {
		({"aria-label": label, "aria-labelledby": labelledby, children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = label;
		$[4] = labelledby;
		$[5] = rest;
	} else {
		children = $[1];
		className = $[2];
		label = $[3];
		labelledby = $[4];
		rest = $[5];
	}
	const ref = React.useRef(null);
	const hasOverflow = useOverflow(ref);
	let t1;
	if ($[6] !== hasOverflow || $[7] !== label || $[8] !== labelledby) {
		t1 = hasOverflow ? {
			"aria-label": label,
			"aria-labelledby": labelledby,
			role: "region",
			tabIndex: 0
		} : {};
		$[6] = hasOverflow;
		$[7] = label;
		$[8] = labelledby;
		$[9] = t1;
	} else t1 = $[9];
	const regionProps = t1;
	let t2;
	if ($[10] !== className) {
		t2 = clsx(classes.ScrollableRegion, className);
		$[10] = className;
		$[11] = t2;
	} else t2 = $[11];
	let t3;
	if ($[12] !== children || $[13] !== regionProps || $[14] !== rest || $[15] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			...rest,
			...regionProps,
			ref,
			className: t2,
			children
		});
		$[12] = children;
		$[13] = regionProps;
		$[14] = rest;
		$[15] = t2;
		$[16] = t3;
	} else t3 = $[16];
	return t3;
}
var DefaultHeader = ({ dialogLabelId, title, subtitle, dialogDescriptionId, onClose }) => {
	const onCloseClick = useCallback(() => {
		onClose("close-button");
	}, [onClose]);
	return /* @__PURE__ */ jsx(Dialog.Header, { children: /* @__PURE__ */ jsxs("div", {
		className: classes$1.HeaderInner,
		children: [/* @__PURE__ */ jsxs("div", {
			className: classes$1.HeaderContent,
			children: [/* @__PURE__ */ jsx(Dialog.Title, {
				id: dialogLabelId,
				children: title !== null && title !== void 0 ? title : "Dialog"
			}), subtitle && /* @__PURE__ */ jsx(Dialog.Subtitle, {
				id: dialogDescriptionId,
				children: subtitle
			})]
		}), /* @__PURE__ */ jsx(Dialog.CloseButton, { onClose: onCloseClick })]
	}) });
};
DefaultHeader.displayName = "DefaultHeader";
var DefaultBody = ({ children }) => {
	return /* @__PURE__ */ jsx(Dialog.Body, { children });
};
DefaultBody.displayName = "DefaultBody";
var DefaultFooter = ({ footerButtons }) => {
	const { containerRef: footerRef } = useFocusZone({
		bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.Tab,
		focusInStrategy: "closest"
	});
	return footerButtons ? /* @__PURE__ */ jsx(Dialog.Footer, {
		ref: footerRef,
		children: /* @__PURE__ */ jsx(Dialog.Buttons, { buttons: footerButtons })
	}) : null;
};
var defaultPosition = {
	narrow: "center",
	regular: "center"
};
var defaultFooterButtons = [];
var DialogContext = /* @__PURE__ */ React.createContext(void 0);
var DIALOG_CONTEXT_VALUE = Object.freeze({});
var _Dialog = /* @__PURE__ */ React.forwardRef((props, forwardedRef) => {
	var _slots$header, _slots$body, _slots$footer;
	const { title = "Dialog", subtitle = "", renderHeader, renderBody, renderFooter, onClose, role = "dialog", width = "xlarge", height = "auto", footerButtons = defaultFooterButtons, position = defaultPosition, align, returnFocusRef, initialFocusRef, className, style } = props;
	const dialogLabelId = useId$1();
	const dialogDescriptionId = useId$1();
	const autoFocusedFooterButtonRef = useRef(null);
	for (const footerButton of footerButtons) if (footerButton.autoFocus) footerButton.ref = autoFocusedFooterButtonRef;
	const [lastMouseDownIsBackdrop, setLastMouseDownIsBackdrop] = useState(false);
	const defaultedProps = {
		...props,
		title,
		subtitle,
		role,
		dialogLabelId,
		dialogDescriptionId
	};
	const onBackdropClick = useCallback((e) => {
		if (e.target === e.currentTarget && lastMouseDownIsBackdrop) onClose("escape");
	}, [onClose, lastMouseDownIsBackdrop]);
	const [slots, childrenWithoutSlots] = useSlots(props.children, {
		body: Dialog.Body,
		header: Dialog.Header,
		footer: Dialog.Footer
	});
	const dialogRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, dialogRef);
	const backdropRef = useRef(null);
	useFocusTrap({
		containerRef: dialogRef,
		initialFocusRef: initialFocusRef !== null && initialFocusRef !== void 0 ? initialFocusRef : autoFocusedFooterButtonRef,
		restoreFocusOnCleanUp: returnFocusRef !== null && returnFocusRef !== void 0 && returnFocusRef.current ? false : true,
		returnFocusRef
	});
	useOnEscapePress((event) => {
		onClose("escape");
		event.preventDefault();
	}, [onClose]);
	React.useEffect(() => {
		const scrollbarWidth = window.innerWidth - document.body.clientWidth;
		const dialog = dialogRef.current;
		const usePerfOptimization = document.body.hasAttribute("data-dialog-scroll-optimized");
		dialog === null || dialog === void 0 || dialog.classList.add(classes$1.DisableScroll);
		document.body.style.setProperty("--prc-dialog-scrollgutter", `${scrollbarWidth}px`);
		if (usePerfOptimization) document.body.setAttribute("data-dialog-scroll-disabled", "");
		return () => {
			dialog === null || dialog === void 0 || dialog.classList.remove(classes$1.DisableScroll);
			if (document.querySelectorAll(`.${classes$1.DisableScroll}`).length === 0) {
				document.body.style.removeProperty("--prc-dialog-scrollgutter");
				if (usePerfOptimization) document.body.removeAttribute("data-dialog-scroll-disabled");
			}
		};
	}, []);
	const header = (_slots$header = slots.header) !== null && _slots$header !== void 0 ? _slots$header : (renderHeader !== null && renderHeader !== void 0 ? renderHeader : DefaultHeader)(defaultedProps);
	const body = (_slots$body = slots.body) !== null && _slots$body !== void 0 ? _slots$body : (renderBody !== null && renderBody !== void 0 ? renderBody : DefaultBody)({
		...defaultedProps,
		children: childrenWithoutSlots
	});
	const footer = (_slots$footer = slots.footer) !== null && _slots$footer !== void 0 ? _slots$footer : (renderFooter !== null && renderFooter !== void 0 ? renderFooter : DefaultFooter)(defaultedProps);
	const positionDataAttributes = typeof position === "string" ? { "data-position-regular": position } : Object.fromEntries(Object.entries(position).map(([key, value]) => {
		return [`data-position-${key}`, value];
	}));
	return /* @__PURE__ */ jsx(DialogContext.Provider, {
		value: DIALOG_CONTEXT_VALUE,
		children: /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
			ref: backdropRef,
			className: classes$1.Backdrop,
			...positionDataAttributes,
			...align && { "data-align": align },
			onClick: onBackdropClick,
			onMouseDown: (e) => {
				setLastMouseDownIsBackdrop(e.target === e.currentTarget);
			},
			children: /* @__PURE__ */ jsxs("div", {
				ref: dialogRef,
				role,
				"aria-labelledby": dialogLabelId,
				"aria-describedby": dialogDescriptionId,
				"aria-modal": true,
				...positionDataAttributes,
				...align && { "data-align": align },
				"data-width": width,
				"data-height": height,
				"data-has-footer": footer != null ? "" : void 0,
				className: clsx(className, classes$1.Dialog),
				style,
				children: [
					header,
					/* @__PURE__ */ jsx(ScrollableRegion, {
						"aria-labelledby": dialogLabelId,
						className: classes$1.DialogOverflowWrapper,
						children: body
					}),
					footer
				]
			})
		}) })
	});
});
_Dialog.displayName = "Dialog";
var Header = /* @__PURE__ */ React.forwardRef(function Header({ className, ...rest }, forwardRef) {
	return /* @__PURE__ */ jsx("div", {
		ref: forwardRef,
		className: clsx(className, classes$1.Header),
		...rest
	});
});
Header.displayName = "Dialog.Header";
var Title = /* @__PURE__ */ React.forwardRef(function Title({ className, ...rest }, forwardRef) {
	return /* @__PURE__ */ jsx("h1", {
		ref: forwardRef,
		className: clsx(className, classes$1.Title),
		...rest
	});
});
Title.displayName = "Dialog.Title";
var Subtitle = /* @__PURE__ */ React.forwardRef(function Subtitle({ className, ...rest }, forwardRef) {
	return /* @__PURE__ */ jsx("h2", {
		ref: forwardRef,
		className: clsx(className, classes$1.Subtitle),
		...rest
	});
});
Subtitle.displayName = "Dialog.Subtitle";
var Body = /* @__PURE__ */ React.forwardRef(function Body({ className, ...rest }, forwardRef) {
	return /* @__PURE__ */ jsx("div", {
		ref: forwardRef,
		className: clsx(className, classes$1.Body),
		...rest
	});
});
Body.displayName = "Dialog.Body";
var Footer = /* @__PURE__ */ React.forwardRef(function Footer({ className, ...rest }, forwardRef) {
	return /* @__PURE__ */ jsx("div", {
		ref: forwardRef,
		className: clsx(className, classes$1.Footer),
		...rest
	});
});
Footer.displayName = "Dialog.Footer";
var Buttons = ({ buttons }) => {
	var _buttons$find;
	const autoFocusRef = useProvidedRefOrCreate((_buttons$find = buttons.find((button) => button.autoFocus)) === null || _buttons$find === void 0 ? void 0 : _buttons$find.ref);
	let autoFocusCount = 0;
	const [hasRendered, setHasRendered] = useState(0);
	useEffect(() => {
		if (hasRendered === 1) {
			var _autoFocusRef$current;
			(_autoFocusRef$current = autoFocusRef.current) === null || _autoFocusRef$current === void 0 || _autoFocusRef$current.focus();
		} else setHasRendered(hasRendered + 1);
	}, [autoFocusRef, hasRendered]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: buttons.map((dialogButtonProps, index) => {
		const { content, buttonType = "default", autoFocus = false, ...buttonProps } = dialogButtonProps;
		return /* @__PURE__ */ jsx(ButtonComponent, {
			...buttonProps,
			variant: buttonType === "normal" ? "default" : buttonType,
			ref: autoFocus && autoFocusCount === 0 ? (autoFocusCount++, autoFocusRef) : null,
			children: content
		}, index);
	}) });
};
var CloseButton = ({ onClose }) => {
	return /* @__PURE__ */ jsx(IconButton, {
		icon: XIcon,
		"aria-label": "Close",
		onClick: onClose,
		variant: "invisible"
	});
};
CloseButton.displayName = "CloseButton";
/**
* A dialog is a type of overlay that can be used for confirming actions, asking
* for disambiguation, and presenting small forms. They generally allow the user
* to focus on a quick task without having to navigate to a different page.
*
* Dialogs appear in the page after a direct user interaction. Don't show dialogs
* on page load or as system alerts.
*
* Dialogs appear centered in the page, with a visible backdrop that dims the rest
* of the window for focus.
*
* All dialogs have a title and a close button.
*
* Dialogs are modal. Dialogs can be dismissed by clicking on the close button,
* pressing the escape key, or by interacting with another button in the dialog.
* To avoid losing information and missing important messages, clicking outside
* of the dialog will not close it.
*
* The sub components provided (e.g. Header, Title, etc.) are available for custom
* renderers only. They are not intended to be used otherwise.
*/
Header.__SLOT__ = Symbol("Dialog.Header");
Footer.__SLOT__ = Symbol("Dialog.Footer");
Body.__SLOT__ = Symbol("Dialog.Body");
var Dialog = Object.assign(_Dialog, {
	__SLOT__: Symbol("Dialog"),
	Header,
	Title,
	Subtitle,
	Body,
	Footer,
	Buttons,
	CloseButton
});
export { DialogContext as n, ScrollableRegion as r, Dialog as t };
