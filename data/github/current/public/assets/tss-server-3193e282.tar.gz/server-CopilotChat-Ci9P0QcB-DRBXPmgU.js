performance.mark("js-parse-end:server-CopilotChat-Ci9P0QcB-DRBXPmgU.js");
import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as VisuallyHidden, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { B as CircleSlashIcon, Cr as ScreenFullIcon, Hn as NoteIcon, Mi as XIcon, O as CheckIcon, Qn as PeopleIcon, Qt as Heading$2, Ut as GitCommitIcon, X as CommentDiscussionIcon, Z as CommentIcon, _i as Truncate, _n as KebabHorizontalIcon, an as IconButton, ar as PlusIcon, bn as Link, cn as InfoIcon, d as ArrowRightIcon, di as ToolsIcon, et as CopilotIcon, fi as Tooltip, gr as RepoIcon, h as BeakerIcon, mi as TrashIcon, mt as DownloadIcon, n as ActionList, o as AlertIcon, tn as HistoryIcon, u as ArrowLeftIcon, wr as SearchIcon, xn as LinkExternalIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as Overlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { o as isStaff } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { C as commitPath, Ot as repoOverviewUrl, a as blobPath, r as blamePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { B as isRepository, C as filterUniqueConfirmations, F as hasCustomInstructions, I as hasCustomInstructionsAsync, L as isAgent, M as getRenderableReferences, Z as referenceID, a as CopilotLicenseType, at as shuffle, b as copilotFeatureFlags, it as setPreviousPageInfo, m as ModeSupportName, n as COPILOT_PATH, q as makeRepositoryReference, s as DialogType, st as suggestedPrompts } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { r as VerifiedHTMLDiv } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { t as Dialog_default } from "./server-Dialog-Bj1Iyrx--DrNEVM4r.js";
import { i as useScreenSize, n as ScreenSizeProvider, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { t as BetaLabel } from "./server-BetaLabel-D0vwDZNc-CsXfuTFf.js";
import { t as addUrlToHistoryStack } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { a as subscribeAddCopilotChatReference, c as subscribeSymbolChanged, o as subscribeOpenCopilotChat, s as subscribeSearchCopilot } from "./server-copilot-chat-events-CAR-de8z-CxKg4yWR.js";
import { n as unqualifyRef } from "./server-ref-utils-DurADI35-f0lQqMVw.js";
import { n as useLatestCommit } from "./server-use-latest-commit-CEaptRlH-Dq4wXeZZ.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { E as useEntitlement, T as useDefaultModel, b as useChatState, c as copilotChatPanelID, l as copilotChatPanelInnerID, p as getActiveMessages, s as copilotChatHeaderButtonID, t as CopilotChatProvider, u as copilotChatSearchInputId, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { a as GlobalCommands, o as ScopedCommands, r as CommandIconButton } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { a as ChatPortalContainer, c as EMBEDDED_MENU_PORTAL_CLASS, d as MenuPortalContainer, f as MessagesPortalContainer } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { D as useRepositoryItems, O as useResizablePanel, f as RepositoryListItem, h as WebSearchReferencePreview, l as ReferencePreview, n as ChatInput, v as getSelectedThread } from "./server-ChatInput-DNU7qLKC-DqztNW8O.js";
import { a as PersonalInstructionsDialog, c as useChatScroll, n as ChatScrollContainer, r as ConversationFeedbackDialog, s as useChatMessage, t as ChatMessageProvider } from "./server-PersonalInstructionsDialog-31usJWBy-DGjuoNqn.js";
import { t as CopilotAnimation } from "./server-CopilotAnimation-DOXbbPXC-CqTp-mSh.js";
import { n as MarkdownRenderer } from "./server-MarkdownRenderer-CWn3CeTy-lToasg6Z.js";
import { D as useChatMessageBehavior, E as useChat, S as UserMessage, a as ChatMessageReferencesList, b as ThreadListView, d as CopilotIconAnimation, f as CopilotSuggestions_default, g as LegalDisclaimer, h as InterruptedBanner, i as ChatMessageReferenceTokens, k as useGroupedMessages, l as Confirmation, m as Feedback, n as AmbientErrorBanner, o as ChatMessage_module_default, p as ErrorMessage, r as ChatImage, s as ChatMessagesGroup, t as AgentErrors, u as CopilotBadge, v as RetryButton, w as messageFromFunctionCall, y as StaffDialogs } from "./server-ThreadListView-DRBOLDcY-DuY5jeo1.js";
import { t as WithShimmerEffect } from "./server-WithShimmerEffect-C6EPOEv6-DHTqBfIK.js";
import { t as useContributors } from "./server-use-contributors-pFlHrUQY-DveB_mcH.js";
import { n as useOnAnchorClick } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:CopilotChat-Ci9P0QcB.js");
var CodeReferencePreview_module_default = {
	avatar: "CodeReferencePreview-module_7FhAaG_avatar",
	blobContainer: "CodeReferencePreview-module_7FhAaG_blobContainer",
	blobPreviewHeader: "CodeReferencePreview-module_7FhAaG_blobPreviewHeader",
	blobSize: "CodeReferencePreview-module_7FhAaG_blobSize",
	downloadButton: "CodeReferencePreview-module_7FhAaG_downloadButton",
	filePath: "CodeReferencePreview-module_7FhAaG_filePath",
	rawButtonsContainer: "CodeReferencePreview-module_7FhAaG_rawButtonsContainer",
	rawLinkButton: "CodeReferencePreview-module_7FhAaG_rawLinkButton",
	refName: "CodeReferencePreview-module_7FhAaG_refName",
	repoName: "CodeReferencePreview-module_7FhAaG_repoName",
	separatorDot: "CodeReferencePreview-module_7FhAaG_separatorDot"
};
var SimpleCodeListing_module_default = { SimpleCodeListing: "SimpleCodeListing-module_ZbH_7G_SimpleCodeListing" };
function SimpleCodeListing({ lineNumbers, lines, trimLineBeginnings }) {
	return /* @__PURE__ */ jsx("div", {
		className: SimpleCodeListing_module_default.SimpleCodeListing,
		children: /* @__PURE__ */ jsx("table", {
			style: {
				fontSize: "12px",
				fontFamily: "var(--fontStack-monospace)",
				overflowX: "auto"
			},
			children: lineNumbers.map((num, i) => /* @__PURE__ */ jsxs("tr", { children: [/* @__PURE__ */ jsx("td", { children: num }, num), /* @__PURE__ */ jsx("td", {
				style: {
					whiteSpace: "pre",
					paddingLeft: "16px"
				},
				children: /* @__PURE__ */ jsx(VerifiedHTMLDiv, { html: trimLineBeginnings ? trimLineBeginning(lines[i] ?? "") : lines[i] || "\n" }, `line-${i}`)
			})] }, `line-row-${num}`))
		})
	});
}
SimpleCodeListing.displayName = "SimpleCodeListing";
function trimLineBeginning(str) {
	return str.trimStart();
}
function CodeReferencePreview(t0) {
	const $ = c(21);
	const { reference, details, detailsLoading, detailsError, onDismiss } = t0;
	const { contributors } = useContributors(reference.repoOwner, reference.repoName, reference.commitOID, reference.path);
	const [latestCommit] = useLatestCommit(reference.repoOwner, reference.repoName, reference.commitOID, reference.path);
	const { lines, lineNumbers, expandUp, expandDown } = useExpandableRange(details?.range, details?.expandedRange, details?.highlightedContents);
	const headerInfo = details?.headerInfo;
	let t1;
	if ($[0] !== contributors || $[1] !== details?.range || $[2] !== details?.repoIsOrgOwned || $[3] !== detailsError || $[4] !== detailsLoading || $[5] !== expandDown || $[6] !== expandUp || $[7] !== headerInfo || $[8] !== latestCommit || $[9] !== lineNumbers || $[10] !== lines || $[11] !== onDismiss || $[12] !== reference.commitOID || $[13] !== reference.path || $[14] !== reference.range || $[15] !== reference.ref || $[16] !== reference.repoName || $[17] !== reference.repoOwner || $[18] !== reference.type || $[19] !== reference.url) {
		t1 = jsxs(ReferencePreview.Frame, { children: [jsxs(ReferencePreview.Header, {
			onDismiss,
			children: [
				jsx(GitHubAvatar, {
					square: details?.repoIsOrgOwned,
					src: `${reference.repoOwner}.png`,
					className: CodeReferencePreview_module_default.avatar
				}),
				jsxs("span", {
					className: CodeReferencePreview_module_default.repoName,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName
					]
				}),
				jsx("span", {
					className: CodeReferencePreview_module_default.separatorDot,
					children: "·"
				}),
				jsx("span", {
					className: CodeReferencePreview_module_default.refName,
					children: unqualifyRef(reference.ref)
				}),
				jsx("span", {
					className: CodeReferencePreview_module_default.separatorDot,
					children: "·"
				}),
				jsx("span", {
					className: CodeReferencePreview_module_default.filePath,
					children: reference.path
				}),
				reference.type === "snippet" && jsxs("span", { children: [
					":",
					reference.range.start,
					"-",
					reference.range.end
				] })
			]
		}), jsxs(ReferencePreview.Body, {
			detailsError,
			detailsLoading,
			children: [jsxs("div", {
				className: CodeReferencePreview_module_default.blobContainer,
				children: [
					jsxs(BlobPreviewHeader, { children: [headerInfo && jsx(BlobSize, { headerInfo }), headerInfo && jsx(RawButtons, { headerInfo })] }),
					expandUp && jsx(ReferencePreview.ContentExpander, {
						direction: "above",
						onExpand: expandUp
					}),
					jsx(ReferencePreview.Content, { children: jsx(SimpleCodeListing, {
						lines,
						lineNumbers
					}) }),
					expandDown && jsx(ReferencePreview.ContentExpander, {
						direction: "below",
						onExpand: expandDown
					})
				]
			}), jsxs(ReferencePreview.Details, { children: [
				jsxs(ReferencePreview.DetailLink, {
					href: repoOverviewUrl({
						name: reference.repoName,
						ownerLogin: reference.repoOwner
					}),
					icon: RepoIcon,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName
					]
				}),
				contributors && jsxs(ReferencePreview.DetailLink, {
					icon: PeopleIcon,
					href: blamePath({
						owner: reference.repoOwner,
						repo: reference.repoName,
						commitish: reference.commitOID,
						filePath: reference.path,
						lineNumber: details?.range.start
					}),
					children: [
						contributors.totalCount,
						" ",
						contributors.totalCount === 1 ? "contributor" : "contributors"
					]
				}),
				latestCommit && jsxs(ReferencePreview.DetailLink, {
					icon: HistoryIcon,
					href: commitPath({
						owner: reference.repoOwner,
						repo: reference.repoName,
						commitish: latestCommit?.oid
					}),
					children: [
						latestCommit?.author?.displayName,
						" updated ",
						jsx(RelativeTime, { datetime: latestCommit?.date })
					]
				}),
				jsxs(ReferencePreview.DetailLink, {
					icon: LinkExternalIcon,
					href: reference.url,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName,
						"/",
						reference.path,
						reference.type === "snippet" ? jsxs(Fragment$1, { children: [
							"#",
							reference.range.start,
							"-",
							reference.range.end
						] }) : null
					]
				})
			] })]
		})] });
		$[0] = contributors;
		$[1] = details?.range;
		$[2] = details?.repoIsOrgOwned;
		$[3] = detailsError;
		$[4] = detailsLoading;
		$[5] = expandDown;
		$[6] = expandUp;
		$[7] = headerInfo;
		$[8] = latestCommit;
		$[9] = lineNumbers;
		$[10] = lines;
		$[11] = onDismiss;
		$[12] = reference.commitOID;
		$[13] = reference.path;
		$[14] = reference.range;
		$[15] = reference.ref;
		$[16] = reference.repoName;
		$[17] = reference.repoOwner;
		$[18] = reference.type;
		$[19] = reference.url;
		$[20] = t1;
	} else t1 = $[20];
	return t1;
}
CodeReferencePreview.displayName = "CodeReferencePreview";
function BlobPreviewHeader({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: CodeReferencePreview_module_default.blobPreviewHeader,
		children
	});
}
BlobPreviewHeader.displayName = "BlobPreviewHeader";
function BlobSize({ headerInfo }) {
	return /* @__PURE__ */ jsx(Truncate, {
		title: headerInfo.blobSize,
		inline: true,
		className: CodeReferencePreview_module_default.blobSize,
		"data-testid": "blob-size",
		children: /* @__PURE__ */ jsx("span", { children: `${headerInfo.lineInfo.truncatedLoc} lines (${headerInfo.lineInfo.truncatedSloc} loc) · ${headerInfo.blobSize}` })
	});
}
BlobSize.displayName = "BlobSize";
function RawButtons({ headerInfo }) {
	const lfsDownloadUrl = new URL(headerInfo.rawBlobUrl, ssrSafeLocation.origin);
	lfsDownloadUrl.searchParams.set("download", "");
	const downloadButtonProps = {
		["aria-label"]: "Download raw content",
		icon: DownloadIcon,
		size: "small",
		onClick: async () => {
			if (!headerInfo.isLfs) await downloadFile(headerInfo.rawBlobUrl, headerInfo.displayName);
		},
		["data-testid"]: "download-raw-button",
		className: CodeReferencePreview_module_default.downloadButton
	};
	return /* @__PURE__ */ jsxs("div", {
		className: CodeReferencePreview_module_default.rawButtonsContainer,
		children: [/* @__PURE__ */ jsx(LinkButton, {
			href: headerInfo.rawBlobUrl,
			download: !headerInfo.viewable ? "true" : void 0,
			size: "small",
			className: CodeReferencePreview_module_default.rawLinkButton,
			"data-testid": "raw-button",
			children: "Raw"
		}), headerInfo.isLfs ? /* @__PURE__ */ jsx(IconButton, {
			unsafeDisableTooltip: true,
			as: "a",
			"data-turbo": "false",
			href: lfsDownloadUrl.toString(),
			...downloadButtonProps
		}) : /* @__PURE__ */ jsx(IconButton, {
			unsafeDisableTooltip: true,
			...downloadButtonProps
		})]
	});
}
RawButtons.displayName = "RawButtons";
function useExpandableRange(range, expandedRange, allLines) {
	const $ = c(42);
	const [startLine, setStartLine] = useState(range?.start ?? -1);
	const [endLine, setEndLine] = useState(range?.end ?? -1);
	let t0;
	if ($[0] !== allLines || $[1] !== expandedRange || $[2] !== range) {
		t0 = allLines && range && expandedRange ? allLines.slice(range.start - expandedRange.start, range.end - expandedRange.start + 1) : [];
		$[0] = allLines;
		$[1] = expandedRange;
		$[2] = range;
		$[3] = t0;
	} else t0 = $[3];
	const [lines, setLines] = useState(t0);
	let t1;
	if ($[4] !== allLines || $[5] !== endLine || $[6] !== expandedRange || $[7] !== range || $[8] !== startLine) {
		t1 = (t2, t3) => {
			const start = t2 === void 0 ? startLine : t2;
			const end = t3 === void 0 ? endLine : t3;
			if (!allLines || !range || !expandedRange || start < 0 || end < 0) return;
			setLines(allLines.slice(start - expandedRange.start, end - expandedRange.start + 1));
		};
		$[4] = allLines;
		$[5] = endLine;
		$[6] = expandedRange;
		$[7] = range;
		$[8] = startLine;
		$[9] = t1;
	} else t1 = $[9];
	const updateLines = t1;
	let t2;
	if ($[10] !== allLines || $[11] !== endLine || $[12] !== range || $[13] !== startLine || $[14] !== updateLines) {
		t2 = () => {
			if (range && allLines && (startLine === -1 || endLine === -1)) {
				const start_0 = range.start;
				const end_0 = range.end;
				setStartLine(start_0);
				setEndLine(end_0);
				updateLines(start_0, end_0);
			}
		};
		$[10] = allLines;
		$[11] = endLine;
		$[12] = range;
		$[13] = startLine;
		$[14] = updateLines;
		$[15] = t2;
	} else t2 = $[15];
	let t3;
	if ($[16] !== allLines || $[17] !== endLine || $[18] !== expandedRange || $[19] !== range || $[20] !== startLine || $[21] !== updateLines) {
		t3 = [
			allLines,
			range,
			expandedRange,
			updateLines,
			startLine,
			endLine
		];
		$[16] = allLines;
		$[17] = endLine;
		$[18] = expandedRange;
		$[19] = range;
		$[20] = startLine;
		$[21] = updateLines;
		$[22] = t3;
	} else t3 = $[22];
	useEffect(t2, t3);
	let t4;
	if ($[23] !== expandedRange?.start || $[24] !== startLine || $[25] !== updateLines) {
		t4 = () => {
			const start_1 = Math.max(startLine - pageSize, expandedRange?.start ?? -1);
			setStartLine(start_1);
			updateLines(start_1);
		};
		$[23] = expandedRange?.start;
		$[24] = startLine;
		$[25] = updateLines;
		$[26] = t4;
	} else t4 = $[26];
	expandedRange?.start;
	const expandUp = t4;
	let t5;
	if ($[27] !== endLine || $[28] !== expandedRange?.end || $[29] !== startLine || $[30] !== updateLines) {
		t5 = () => {
			const end_1 = Math.min(endLine + pageSize, expandedRange?.end ?? -1);
			setEndLine(end_1);
			updateLines(startLine, end_1);
		};
		$[27] = endLine;
		$[28] = expandedRange?.end;
		$[29] = startLine;
		$[30] = updateLines;
		$[31] = t5;
	} else t5 = $[31];
	expandedRange?.end;
	const expandDown = t5;
	const canExpandUp = startLine !== -1 && startLine !== expandedRange?.start;
	const canExpandDown = endLine !== -1 && endLine !== expandedRange?.end;
	let t6;
	if ($[32] !== lines || $[33] !== startLine) {
		let t7;
		if ($[35] !== startLine) {
			t7 = (_, i) => startLine + i;
			$[35] = startLine;
			$[36] = t7;
		} else t7 = $[36];
		t6 = lines.map(t7);
		$[32] = lines;
		$[33] = startLine;
		$[34] = t6;
	} else t6 = $[34];
	const t7 = canExpandUp ? expandUp : null;
	const t8 = canExpandDown ? expandDown : null;
	let t9;
	if ($[37] !== lines || $[38] !== t6 || $[39] !== t7 || $[40] !== t8) {
		t9 = {
			lines,
			lineNumbers: t6,
			expandUp: t7,
			expandDown: t8
		};
		$[37] = lines;
		$[38] = t6;
		$[39] = t7;
		$[40] = t8;
		$[41] = t9;
	} else t9 = $[41];
	return t9;
}
var pageSize = 25;
async function downloadFile(rawHref, name) {
	const blob = await (await fetch(rawHref, { method: "get" })).blob();
	const aElement = document.createElement("a");
	aElement.setAttribute("download", name);
	const href = URL.createObjectURL(blob);
	aElement.href = href;
	aElement.setAttribute("target", "_blank");
	aElement.click();
	URL.revokeObjectURL(href);
}
var CommitReferencePreview_module_default = {
	avatar: "CommitReferencePreview-module_nt4jJa_avatar",
	borderDivider: "CommitReferencePreview-module_nt4jJa_borderDivider",
	commitAuthorRow: "CommitReferencePreview-module_nt4jJa_commitAuthorRow",
	iconMarginRight: "CommitReferencePreview-module_nt4jJa_iconMarginRight",
	truncate: "CommitReferencePreview-module_nt4jJa_truncate",
	truncateRtl: "CommitReferencePreview-module_nt4jJa_truncateRtl"
};
function CommitReferencePreview({ reference, detailsLoading, detailsError, onDismiss }) {
	return /* @__PURE__ */ jsxs(ReferencePreview.Frame, { children: [/* @__PURE__ */ jsxs(ReferencePreview.Header, {
		onDismiss,
		children: [/* @__PURE__ */ jsx(Octicon, {
			icon: GitCommitIcon,
			className: CommitReferencePreview_module_default.iconMarginRight
		}), /* @__PURE__ */ jsx("div", {
			className: CommitReferencePreview_module_default.truncate,
			children: reference.message
		})]
	}), /* @__PURE__ */ jsxs(ReferencePreview.Body, {
		detailsError,
		detailsLoading,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: CommitReferencePreview_module_default.commitAuthorRow,
				children: [/* @__PURE__ */ jsx(GitHubAvatar, {
					src: `${reference.author.login}.png`,
					className: CommitReferencePreview_module_default.avatar
				}), /* @__PURE__ */ jsx("div", {
					className: CommitReferencePreview_module_default.truncateRtl,
					children: reference.author.login
				})]
			}),
			/* @__PURE__ */ jsx("div", { className: CommitReferencePreview_module_default.borderDivider }),
			/* @__PURE__ */ jsx(ReferencePreview.Content, { children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: reference.message }) }),
			/* @__PURE__ */ jsx("div", { className: CommitReferencePreview_module_default.borderDivider }),
			/* @__PURE__ */ jsxs(ReferencePreview.Details, { children: [/* @__PURE__ */ jsxs(ReferencePreview.DetailLink, {
				href: repoOverviewUrl({
					name: reference.repository.name,
					ownerLogin: reference.repository.owner
				}),
				icon: RepoIcon,
				children: [
					reference.repository.owner,
					"/",
					reference.repository.name
				]
			}), /* @__PURE__ */ jsxs(ReferencePreview.DetailLink, {
				href: reference.permalink,
				icon: LinkExternalIcon,
				children: [
					reference.repository.owner,
					"/",
					reference.repository.name,
					"/commit/",
					reference.oid
				]
			})] })
		]
	})] });
}
CommitReferencePreview.displayName = "CommitReferencePreview";
var MarkdownReferencePreview_module_default = {
	avatar: "MarkdownReferencePreview-module_3XuR7W_avatar",
	blobContainer: "MarkdownReferencePreview-module_3XuR7W_blobContainer",
	filePath: "MarkdownReferencePreview-module_3XuR7W_filePath",
	headerControls: "MarkdownReferencePreview-module_3XuR7W_headerControls",
	highlightedContent: "MarkdownReferencePreview-module_3XuR7W_highlightedContent",
	preBlock: "MarkdownReferencePreview-module_3XuR7W_preBlock",
	refName: "MarkdownReferencePreview-module_3XuR7W_refName",
	repoName: "MarkdownReferencePreview-module_3XuR7W_repoName",
	SegmentedControl: "MarkdownReferencePreview-module_3XuR7W_SegmentedControl",
	separatorDot: "MarkdownReferencePreview-module_3XuR7W_separatorDot"
};
function MarkdownReferencePreview(t0) {
	const $ = c(13);
	const { reference, details, detailsLoading, detailsError, onDismiss } = t0;
	const { contributors } = useContributors(reference.repoOwner, reference.repoName, reference.commitOID, reference.path);
	const [latestCommit] = useLatestCommit(reference.repoOwner, reference.repoName, reference.commitOID, reference.path);
	let t1;
	if ($[0] !== contributors || $[1] !== details || $[2] !== detailsError || $[3] !== detailsLoading || $[4] !== latestCommit || $[5] !== onDismiss || $[6] !== reference.commitOID || $[7] !== reference.path || $[8] !== reference.ref || $[9] !== reference.repoName || $[10] !== reference.repoOwner || $[11] !== reference.url) {
		t1 = jsxs(ReferencePreview.Frame, { children: [jsxs(ReferencePreview.Header, {
			onDismiss,
			children: [
				jsx(GitHubAvatar, {
					square: details?.repoIsOrgOwned,
					src: `${reference.repoOwner}.png`,
					className: MarkdownReferencePreview_module_default.avatar
				}),
				jsxs("span", {
					className: MarkdownReferencePreview_module_default.repoName,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName
					]
				}),
				jsx("span", {
					className: MarkdownReferencePreview_module_default.separatorDot,
					children: "·"
				}),
				jsx("span", {
					className: MarkdownReferencePreview_module_default.refName,
					children: unqualifyRef(reference.ref)
				}),
				jsx("span", {
					className: MarkdownReferencePreview_module_default.separatorDot,
					children: "·"
				}),
				jsx("span", {
					className: MarkdownReferencePreview_module_default.filePath,
					children: reference.path
				})
			]
		}), jsxs(ReferencePreview.Body, {
			detailsLoading,
			detailsError,
			children: [details && jsx(MarkdownReferencePreviewContent, { details }), jsxs(ReferencePreview.Details, { children: [
				jsxs(ReferencePreview.DetailLink, {
					href: repoOverviewUrl({
						name: reference.repoName,
						ownerLogin: reference.repoOwner
					}),
					icon: RepoIcon,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName
					]
				}),
				contributors && jsxs(ReferencePreview.DetailLink, {
					icon: PeopleIcon,
					href: blamePath({
						owner: reference.repoOwner,
						repo: reference.repoName,
						commitish: reference.commitOID,
						filePath: reference.path,
						lineNumber: details?.range.start
					}),
					children: [contributors.totalCount, " contributors"]
				}),
				latestCommit && jsxs(ReferencePreview.DetailLink, {
					icon: HistoryIcon,
					href: commitPath({
						owner: reference.repoOwner,
						repo: reference.repoName,
						commitish: latestCommit?.oid
					}),
					children: [
						latestCommit?.author?.displayName,
						" updated ",
						jsx(RelativeTime, { datetime: latestCommit?.date })
					]
				}),
				jsxs(ReferencePreview.DetailLink, {
					icon: LinkExternalIcon,
					href: reference.url,
					children: [
						reference.repoOwner,
						"/",
						reference.repoName,
						"/",
						reference.path,
						details ? jsxs(Fragment$1, { children: [
							"#",
							details.range.start,
							"-",
							details.range.end
						] }) : null
					]
				})
			] })]
		})] });
		$[0] = contributors;
		$[1] = details;
		$[2] = detailsError;
		$[3] = detailsLoading;
		$[4] = latestCommit;
		$[5] = onDismiss;
		$[6] = reference.commitOID;
		$[7] = reference.path;
		$[8] = reference.ref;
		$[9] = reference.repoName;
		$[10] = reference.repoOwner;
		$[11] = reference.url;
		$[12] = t1;
	} else t1 = $[12];
	return t1;
}
MarkdownReferencePreview.displayName = "MarkdownReferencePreview";
function MarkdownReferencePreviewContent(t0) {
	const $ = c(27);
	const { details } = t0;
	const [startLine, setStartLine] = useState(details.range.start);
	const [endLine, setEndLine] = useState(details.range.end);
	const lineCount = indexToLine(details.contents, details.contents.length);
	const [displayMode, setDisplayMode] = useState("preview");
	let t1;
	if ($[0] !== displayMode) {
		t1 = (selectedTabIndex) => {
			const newMode = ["preview", "code"][selectedTabIndex];
			if (newMode && displayMode !== newMode) setDisplayMode(newMode);
		};
		$[0] = displayMode;
		$[1] = t1;
	} else t1 = $[1];
	const handleSegmentChange = t1;
	const headerInfo = details?.headerInfo;
	let t2;
	if ($[2] !== details.contents || $[3] !== startLine) {
		t2 = () => {
			setStartLine(findPrecedingHeading(details.contents, startLine));
		};
		$[2] = details.contents;
		$[3] = startLine;
		$[4] = t2;
	} else t2 = $[4];
	const expandUp = t2;
	let t3;
	if ($[5] !== details.contents || $[6] !== endLine || $[7] !== lineCount) {
		t3 = () => {
			let nextHeadingLine = endLine;
			while (nextHeadingLine < lineCount && nextHeadingLine < endLine + 10) nextHeadingLine = findFollowingHeading(details.contents, nextHeadingLine + 1);
			setEndLine(nextHeadingLine - 1);
		};
		$[5] = details.contents;
		$[6] = endLine;
		$[7] = lineCount;
		$[8] = t3;
	} else t3 = $[8];
	const expandDown = t3;
	let result = details.contents;
	if (startLine) {
		if ($[9] !== endLine || $[10] !== result || $[11] !== startLine) {
			const offsets = findLines(result, startLine, endLine);
			if (offsets.endIndex > -1) result = result.slice(offsets.startIndex, offsets.endIndex);
			$[9] = endLine;
			$[10] = result;
			$[11] = startLine;
			$[12] = result;
		} else result = $[12];
		let t4;
		if ($[13] !== result) {
			let t5;
			if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
				t5 = /^---\n[\s\S]*?\n---\n/;
				$[15] = t5;
			} else t5 = $[15];
			t4 = result.replace(t5, "");
			$[13] = result;
			$[14] = t4;
		} else t4 = $[14];
		result = t4;
	}
	const markdownSlice = result;
	let t4;
	if ($[16] !== details.contents || $[17] !== displayMode || $[18] !== endLine || $[19] !== expandDown || $[20] !== expandUp || $[21] !== handleSegmentChange || $[22] !== headerInfo || $[23] !== lineCount || $[24] !== markdownSlice || $[25] !== startLine) {
		t4 = jsxs("div", {
			className: MarkdownReferencePreview_module_default.blobContainer,
			children: [
				jsxs(BlobPreviewHeader, { children: [jsxs("div", {
					className: MarkdownReferencePreview_module_default.headerControls,
					children: [jsxs(SegmentedControl, {
						"aria-label": "File view",
						size: "small",
						onChange: handleSegmentChange,
						className: MarkdownReferencePreview_module_default.SegmentedControl,
						children: [jsx(SegmentedControl.Button, {
							selected: displayMode === "preview",
							children: "Preview"
						}, "preview'"), jsx(SegmentedControl.Button, {
							selected: displayMode === "code",
							children: "Code"
						}, "raw")]
					}), headerInfo && jsx(BlobSize, { headerInfo })]
				}), headerInfo && jsx(RawButtons, { headerInfo })] }),
				startLine > 1 && jsx(ReferencePreview.ContentExpander, {
					direction: "above",
					onExpand: expandUp
				}),
				jsx(ReferencePreview.Content, { children: displayMode === "preview" ? jsx("div", {
					className: clsx("js-snippet-clipboard-copy-unpositioned", MarkdownReferencePreview_module_default.highlightedContent),
					children: jsx(MarkdownRenderer, {
						markdown: markdownSlice,
						openLinksInCurrentTab: false
					})
				}) : jsx("code", { children: jsx("pre", {
					className: MarkdownReferencePreview_module_default.preBlock,
					children: details.contents
				}) }) }),
				endLine < lineCount && jsx(ReferencePreview.ContentExpander, {
					direction: "below",
					onExpand: expandDown
				})
			]
		});
		$[16] = details.contents;
		$[17] = displayMode;
		$[18] = endLine;
		$[19] = expandDown;
		$[20] = expandUp;
		$[21] = handleSegmentChange;
		$[22] = headerInfo;
		$[23] = lineCount;
		$[24] = markdownSlice;
		$[25] = startLine;
		$[26] = t4;
	} else t4 = $[26];
	return t4;
}
/** find the line number (starting from 1) the given character index occurs on */
MarkdownReferencePreviewContent.displayName = "MarkdownReferencePreviewContent";
function indexToLine(str, index) {
	return count(str.slice(0, index).matchAll(/\n/g)) + 1;
}
/** find the line of the last heading before the given line */
function findPrecedingHeading(str, line) {
	const index = lineToIndex(str, line);
	return indexToLine(str, getLast(str.slice(0, index).matchAll(/^#+\s/gm))?.index ?? 0);
}
/** find the line of the first heading after the given line */
function findFollowingHeading(str, line) {
	const index = lineToIndex(str, line);
	const nextHeading = str.slice(index).match(/^#+\s/m);
	return indexToLine(str, nextHeading ? index + nextHeading.index : str.length);
}
function lineToIndex(str, line) {
	if (line === 1) return 0;
	let index = -1;
	for (let i = 2; i <= line; i++) {
		index = str.indexOf("\n", index + 1);
		if (index === -1) return str.length;
	}
	return index + 1;
}
/** get the last item in an iterable */
function getLast(iterator) {
	let last;
	for (const v of iterator) last = v;
	return last;
}
/** count the items in an interable */
function count(iterator) {
	let c = 0;
	for (const _ of iterator) c++;
	return c;
}
/** finds the character index of the start of the start line (starting from 1) and the end of the end line */
function findLines(str, startLine, endLine = startLine - 1) {
	let index = -1;
	let startIndex = -1;
	let endIndex = -1;
	for (let i = 1;; i++) {
		if (i === startLine) startIndex = index + 1;
		if (i === endLine + 1) {
			endIndex = index;
			break;
		}
		index = str.indexOf("\n", index + 1);
		if (index === -1) break;
	}
	return {
		startIndex,
		endIndex
	};
}
var PullRequestReferencePreview_module_default = {
	authorRow: "PullRequestReferencePreview-module_Vp0V9q_authorRow",
	avatar: "PullRequestReferencePreview-module_Vp0V9q_avatar",
	borderDivider: "PullRequestReferencePreview-module_Vp0V9q_borderDivider",
	iconMarginRight: "PullRequestReferencePreview-module_Vp0V9q_iconMarginRight",
	truncate: "PullRequestReferencePreview-module_Vp0V9q_truncate",
	truncateRtl: "PullRequestReferencePreview-module_Vp0V9q_truncateRtl"
};
function PullRequestReferencePreview({ reference, detailsLoading, detailsError, onDismiss }) {
	return /* @__PURE__ */ jsxs(ReferencePreview.Frame, { children: [/* @__PURE__ */ jsxs(ReferencePreview.Header, {
		onDismiss,
		children: [/* @__PURE__ */ jsx(Octicon, {
			icon: GitCommitIcon,
			className: PullRequestReferencePreview_module_default.iconMarginRight
		}), /* @__PURE__ */ jsx("div", {
			className: PullRequestReferencePreview_module_default.truncate,
			children: reference.title
		})]
	}), /* @__PURE__ */ jsxs(ReferencePreview.Body, {
		detailsError,
		detailsLoading,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: PullRequestReferencePreview_module_default.authorRow,
				children: [/* @__PURE__ */ jsx(GitHubAvatar, {
					src: `${reference.authorLogin}.png`,
					className: PullRequestReferencePreview_module_default.avatar
				}), /* @__PURE__ */ jsx("div", {
					className: PullRequestReferencePreview_module_default.truncateRtl,
					children: reference.authorLogin
				})]
			}),
			/* @__PURE__ */ jsx("div", { className: PullRequestReferencePreview_module_default.borderDivider }),
			/* @__PURE__ */ jsx(ReferencePreview.Content, { children: /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: reference.title }) }),
			/* @__PURE__ */ jsx("div", { className: PullRequestReferencePreview_module_default.borderDivider }),
			/* @__PURE__ */ jsxs(ReferencePreview.Details, { children: [/* @__PURE__ */ jsxs(ReferencePreview.DetailLink, {
				href: repoOverviewUrl({
					name: reference.repository.name,
					ownerLogin: reference.repository.ownerLogin
				}),
				icon: RepoIcon,
				children: [
					reference.repository.ownerLogin,
					"/",
					reference.repository.name
				]
			}), /* @__PURE__ */ jsx(ReferencePreview.DetailLink, {
				href: reference.url,
				icon: LinkExternalIcon,
				children: reference.url
			})] })
		]
	})] });
}
PullRequestReferencePreview.displayName = "PullRequestReferencePreview";
function SymbolReferencePreview(t0) {
	const { reference, details, detailsLoading, detailsError, onDismiss } = t0;
	const definitionsByFile = /* @__PURE__ */ new Map();
	const referencesByFile = /* @__PURE__ */ new Map();
	if (details?.kind === "suggestionSymbol") for (const def of details.suggestionDefinitions ?? []) {
		if (!def.highlightedContents) continue;
		const key = `${def.repoOwner}/${def.repoName}/${def.path}`;
		if (!definitionsByFile.has(key)) definitionsByFile.set(key, []);
		definitionsByFile.get(key).push(def);
	}
	else if (details?.kind === "codeNavSymbol") {
		for (const def_0 of details.codeNavDefinitions ?? []) {
			if (!def_0.highlightedContents) continue;
			const key_0 = `${def_0.repoOwner}/${def_0.repoName}/${def_0.path}`;
			if (!definitionsByFile.has(key_0)) definitionsByFile.set(key_0, []);
			definitionsByFile.get(key_0).push(def_0);
		}
		for (const ref of details?.codeNavReferences ?? []) {
			if (!ref.highlightedContents) continue;
			const key_1 = `${ref.repoOwner}/${ref.repoName}/${ref.path}`;
			if (!referencesByFile.has(key_1)) referencesByFile.set(key_1, []);
			referencesByFile.get(key_1).push(ref);
		}
	}
	const firstDefOrRef = [...definitionsByFile.values()][0]?.[0] ?? [...referencesByFile.values()][0]?.[0];
	const hasDefinitions = definitionsByFile.size > 0;
	const hasReferences = referencesByFile.size > 0;
	const totalDefinitionFiles = [...definitionsByFile.values()].length;
	const totalDefinitions = [...definitionsByFile.values()].reduce(_temp$6, 0);
	const totalReferenceFiles = [...referencesByFile.values()].length;
	const totalReferences = [...referencesByFile.values()].reduce(_temp2$3, 0);
	const { contributors } = useContributors(firstDefOrRef?.repoOwner, firstDefOrRef?.repoName, firstDefOrRef?.commitOID, firstDefOrRef?.path);
	const [latestCommit] = useLatestCommit(firstDefOrRef?.repoOwner, firstDefOrRef?.repoName, firstDefOrRef?.commitOID, firstDefOrRef?.path);
	return jsxs(ReferencePreview.Frame, { children: [jsx(ReferencePreview.Header, {
		onDismiss,
		children: reference.name
	}), jsxs(ReferencePreview.Body, {
		detailsError,
		detailsLoading,
		children: [
			hasDefinitions && jsxs(Fragment$1, { children: [jsxs(ReferencePreview.SectionDivider, { children: [
				totalDefinitions,
				" ",
				totalDefinitions === 1 ? "definition" : "definitions",
				totalDefinitionFiles > 1 ? ` across ${totalDefinitionFiles} files` : null
			] }), [...definitionsByFile.values()].map(_temp4)] }),
			hasReferences && jsxs(Fragment$1, { children: [jsxs(ReferencePreview.SectionDivider, { children: [
				totalReferences,
				" ",
				totalReferences === 1 ? "reference" : "references",
				totalReferenceFiles > 1 ? ` across ${totalReferenceFiles} files` : null
			] }), [...referencesByFile.values()].map((refs, i_0) => jsx(ReferencePreview.CollapsibleSubsection, {
				title: refs[0].path,
				initiallyOpen: i_0 === 0 && !hasDefinitions,
				children: jsx(ReferencePreview.Content, { children: refs.map(_temp5) })
			}, refs[0].path))] }),
			jsxs(ReferencePreview.Details, { children: [
				firstDefOrRef && jsxs(ReferencePreview.DetailLink, {
					href: repoOverviewUrl({
						name: firstDefOrRef.repoName,
						ownerLogin: firstDefOrRef.repoOwner
					}),
					icon: RepoIcon,
					children: [
						firstDefOrRef.repoOwner,
						"/",
						firstDefOrRef.repoName
					]
				}),
				contributors && firstDefOrRef && jsxs(ReferencePreview.DetailLink, {
					icon: PeopleIcon,
					href: blamePath({
						owner: firstDefOrRef.repoOwner,
						repo: firstDefOrRef.repoName,
						commitish: firstDefOrRef.commitOID,
						filePath: firstDefOrRef.path
					}),
					children: [
						contributors.totalCount,
						" ",
						contributors.totalCount === 1 ? "contributor" : "contributors"
					]
				}),
				latestCommit && firstDefOrRef && jsxs(ReferencePreview.DetailLink, {
					icon: HistoryIcon,
					href: commitPath({
						owner: firstDefOrRef.repoOwner,
						repo: firstDefOrRef.repoName,
						commitish: latestCommit?.oid
					}),
					children: [
						latestCommit?.author?.displayName,
						" updated ",
						jsx(RelativeTime, { datetime: latestCommit?.date })
					]
				}),
				firstDefOrRef && jsxs(ReferencePreview.DetailLink, {
					icon: LinkExternalIcon,
					href: blobPath({
						owner: firstDefOrRef.repoOwner,
						repo: firstDefOrRef.repoName,
						commitish: firstDefOrRef.commitOID,
						filePath: firstDefOrRef.path
					}),
					children: [
						firstDefOrRef.repoOwner,
						"/",
						firstDefOrRef.repoName,
						"/",
						firstDefOrRef.path
					]
				})
			] })
		]
	})] });
}
SymbolReferencePreview.displayName = "SymbolReferencePreview";
function _temp5(ref_0, j_0) {
	return ref_0.highlightedContents ? jsx(SimpleCodeListing, {
		trimLineBeginnings: ref_0.highlightedContents.length === 1,
		lines: ref_0.highlightedContents,
		lineNumbers: getLineNumbers(ref_0)
	}, j_0) : null;
}
function _temp4(defs, i) {
	return jsx(ReferencePreview.CollapsibleSubsection, {
		title: defs[0].path,
		initiallyOpen: i === 0,
		children: jsx(ReferencePreview.Content, { children: defs.map(_temp3) })
	}, defs[0].path);
}
function _temp3(def_1, j) {
	return def_1.highlightedContents ? jsx(SimpleCodeListing, {
		trimLineBeginnings: def_1.highlightedContents.length === 1,
		lines: def_1.highlightedContents,
		lineNumbers: getLineNumbers(def_1)
	}, j) : null;
}
function _temp2$3(sum_0, nextRefs) {
	return sum_0 + nextRefs.length;
}
function _temp$6(sum, nextDefs) {
	return sum + nextDefs.length;
}
function getLineNumbers({ range }) {
	if (!range) return [];
	return new Array(range.end - range.start + 1).fill(null).map((_, i) => range.start + i);
}
var FileDiffReferencePreview_module_default = {
	avatar: "FileDiffReferencePreview-module_5A16Da_avatar",
	truncate: "FileDiffReferencePreview-module_5A16Da_truncate"
};
var getRangeString = (selectedRange) => {
	if (!selectedRange?.start) return "";
	return selectedRange.end ? `${selectedRange.start}-${selectedRange.end}` : `${selectedRange.start}`;
};
var splitReferenceURL = (reference) => {
	const range = getRangeString(reference.selectedRange);
	const path = reference.url.split(window.location.host)[1];
	return {
		href: reference.url + range,
		path: path + range,
		range
	};
};
function FileDiffReferencePreview(t0) {
	const $ = c(12);
	const { reference, details, detailsLoading, detailsError, onDismiss } = t0;
	const contentReference = reference.headFile ?? reference.baseFile;
	const { contributors } = useContributors(contentReference.repoOwner, contentReference.repoName, contentReference.commitOID, contentReference.path);
	const [latestCommit] = useLatestCommit(contentReference.repoOwner, contentReference.repoName, contentReference.commitOID, contentReference.path);
	let t1;
	if ($[0] !== contentReference.commitOID || $[1] !== contentReference.path || $[2] !== contentReference.repoName || $[3] !== contentReference.repoOwner || $[4] !== contributors || $[5] !== details?.repoIsOrgOwned || $[6] !== detailsError || $[7] !== detailsLoading || $[8] !== latestCommit || $[9] !== onDismiss || $[10] !== reference) {
		const { href, path, range } = splitReferenceURL(reference);
		t1 = jsxs(ReferencePreview.Frame, { children: [jsxs(ReferencePreview.Header, {
			onDismiss,
			children: [jsx(GitHubAvatar, {
				square: details?.repoIsOrgOwned,
				src: `${contentReference.repoOwner}.png`,
				className: FileDiffReferencePreview_module_default.avatar
			}), jsxs("div", {
				className: FileDiffReferencePreview_module_default.truncate,
				children: [
					contentReference.repoOwner,
					"/",
					contentReference.repoName,
					"/",
					contentReference.path,
					" ",
					range
				]
			})]
		}), jsx(ReferencePreview.Body, {
			detailsError,
			detailsLoading,
			children: jsxs(ReferencePreview.Details, { children: [
				jsxs(ReferencePreview.DetailLink, {
					href: repoOverviewUrl({
						name: contentReference.repoName,
						ownerLogin: contentReference.repoOwner
					}),
					icon: RepoIcon,
					children: [
						contentReference.repoOwner,
						"/",
						contentReference.repoName
					]
				}),
				contributors && jsxs(ReferencePreview.DetailLink, {
					icon: PeopleIcon,
					href: blamePath({
						owner: contentReference.repoOwner,
						repo: contentReference.repoName,
						commitish: contentReference.commitOID,
						filePath: contentReference.path
					}),
					children: [
						contributors.totalCount,
						" ",
						contributors.totalCount === 1 ? "contributor" : "contributors"
					]
				}),
				latestCommit && jsxs(ReferencePreview.DetailLink, {
					icon: HistoryIcon,
					href: commitPath({
						owner: contentReference.repoOwner,
						repo: contentReference.repoName,
						commitish: latestCommit?.oid
					}),
					children: [
						latestCommit?.author?.displayName,
						" updated ",
						jsx(RelativeTime, { datetime: latestCommit?.date })
					]
				}),
				jsx(ReferencePreview.DetailLink, {
					icon: LinkExternalIcon,
					href,
					children: path
				})
			] })
		})] });
		$[0] = contentReference.commitOID;
		$[1] = contentReference.path;
		$[2] = contentReference.repoName;
		$[3] = contentReference.repoOwner;
		$[4] = contributors;
		$[5] = details?.repoIsOrgOwned;
		$[6] = detailsError;
		$[7] = detailsLoading;
		$[8] = latestCommit;
		$[9] = onDismiss;
		$[10] = reference;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
FileDiffReferencePreview.displayName = "FileDiffReferencePreview";
function CopilotReferencePreview(t0) {
	const $ = c(6);
	const { dismissable } = t0;
	const { reference, details, detailsLoading, detailsError, dismissReference } = useReferences();
	const t1 = dismissable ? dismissReference : void 0;
	let t2;
	if ($[0] !== details || $[1] !== detailsError || $[2] !== detailsLoading || $[3] !== reference || $[4] !== t1) {
		t2 = jsx(CopilotReferencePreviewImpl, {
			reference,
			details,
			detailsLoading,
			detailsError,
			onDismiss: t1
		});
		$[0] = details;
		$[1] = detailsError;
		$[2] = detailsLoading;
		$[3] = reference;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
CopilotReferencePreview.displayName = "CopilotReferencePreview";
function CopilotReferencePreviewImpl({ reference, details, detailsLoading, detailsError, onDismiss }) {
	switch (reference.type) {
		case "symbol": return /* @__PURE__ */ jsx(SymbolReferencePreview, {
			reference,
			details,
			detailsLoading,
			detailsError,
			onDismiss
		}, referenceID(reference));
		case "file":
		case "snippet": return reference.languageName === "Markdown" ? /* @__PURE__ */ jsx(MarkdownReferencePreview, {
			reference,
			details,
			detailsError,
			detailsLoading,
			onDismiss
		}, referenceID(reference)) : /* @__PURE__ */ jsx(CodeReferencePreview, {
			reference,
			details,
			detailsLoading,
			detailsError,
			onDismiss
		}, referenceID(reference));
		case "file-diff": return /* @__PURE__ */ jsx(FileDiffReferencePreview, {
			reference,
			details,
			detailsLoading,
			detailsError,
			onDismiss
		}, referenceID(reference));
		case "commit": return /* @__PURE__ */ jsx(CommitReferencePreview, {
			reference,
			detailsLoading,
			detailsError,
			onDismiss
		}, referenceID(reference));
		case "pull-request": return /* @__PURE__ */ jsx(PullRequestReferencePreview, {
			reference,
			detailsLoading,
			detailsError,
			onDismiss
		}, referenceID(reference));
		case "web-search": return /* @__PURE__ */ jsx(WebSearchReferencePreview, {
			reference,
			onDismiss
		}, referenceID(reference));
		default: return null;
	}
}
/**
* Manages the currently displayed reference.
*/
CopilotReferencePreviewImpl.displayName = "CopilotReferencePreviewImpl";
function useReferences() {
	const $ = c(19);
	const manager = useChatManager();
	const reference = useChatState().selectedReference;
	const t0 = reference?.type;
	let t1;
	if ($[0] !== reference) {
		t1 = reference ? referenceID(reference) : void 0;
		$[0] = reference;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== t0 || $[3] !== t1) {
		t2 = [
			"copilot-reference-preview",
			"copilot",
			"references",
			t0,
			t1
		];
		$[2] = t0;
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== manager || $[6] !== reference) {
		t3 = async () => {
			if (!reference) return null;
			const result = await manager.service.hydrateReference(reference);
			if (!result.ok) return null;
			return result.payload;
		};
		$[5] = manager;
		$[6] = reference;
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== t2 || $[9] !== t3) {
		t4 = {
			queryKey: t2,
			queryFn: t3,
			staleTime: Number.MIN_VALUE
		};
		$[8] = t2;
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	const { isLoading, isError, data } = useQuery(t4);
	let t5;
	if ($[11] !== manager) {
		t5 = () => manager.selectReference(null);
		$[11] = manager;
		$[12] = t5;
	} else t5 = $[12];
	const dismissReference = t5;
	const t6 = data ?? void 0;
	let t7;
	if ($[13] !== dismissReference || $[14] !== isError || $[15] !== isLoading || $[16] !== reference || $[17] !== t6) {
		t7 = {
			reference,
			dismissReference,
			details: t6,
			detailsLoading: isLoading,
			detailsError: isError
		};
		$[13] = dismissReference;
		$[14] = isError;
		$[15] = isLoading;
		$[16] = reference;
		$[17] = t6;
		$[18] = t7;
	} else t7 = $[18];
	return t7;
}
var CopilotReferencePreviewDialog_module_default = {
	dialog: "CopilotReferencePreviewDialog-module_rORYvG_dialog",
	largeScreen: "CopilotReferencePreviewDialog-module_rORYvG_largeScreen",
	smallScreen: "CopilotReferencePreviewDialog-module_rORYvG_smallScreen"
};
function CopilotReferencePreviewDialog() {
	const $ = c(4);
	const { dismissReference, reference } = useReferences();
	const { screenSize } = useScreenSize();
	const smallScreen = screenSize < ScreenSize.large;
	let t0;
	if ($[0] !== dismissReference || $[1] !== reference || $[2] !== smallScreen) {
		const title = dialogTitleForReference(reference);
		t0 = jsxs(Dialog_default, {
			"aria-label": title,
			isOpen: !!reference,
			onDismiss: dismissReference,
			className: clsx(CopilotReferencePreviewDialog_module_default.dialog, smallScreen ? CopilotReferencePreviewDialog_module_default.smallScreen : CopilotReferencePreviewDialog_module_default.largeScreen),
			children: [jsx(Dialog_default.Header, { children: title }), jsx(CopilotReferencePreview, {})]
		});
		$[0] = dismissReference;
		$[1] = reference;
		$[2] = smallScreen;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
}
CopilotReferencePreviewDialog.displayName = "CopilotReferencePreviewDialog";
function dialogTitleForReference(reference) {
	switch (reference?.type) {
		case "web-search": return `Bing search results for "${reference.query}"`;
		default: return "Reference";
	}
}
var Chat_module_default = {
	chatInputContainer: "Chat-module_DyU0xW_chatInputContainer",
	ChatMainContainer: "Chat-module_DyU0xW_ChatMainContainer",
	errorContainer: "Chat-module_DyU0xW_errorContainer",
	errorContainerDefault: "Chat-module_DyU0xW_errorContainerDefault",
	errorContainerImmersive: "Chat-module_DyU0xW_errorContainerImmersive",
	legalText: "Chat-module_DyU0xW_legalText",
	loadingStateContainer: "Chat-module_DyU0xW_loadingStateContainer",
	loadingText: "Chat-module_DyU0xW_loadingText",
	messagesContainer: "Chat-module_DyU0xW_messagesContainer",
	promptDescription: "Chat-module_DyU0xW_promptDescription",
	promptHeading: "Chat-module_DyU0xW_promptHeading",
	suggestedPromptButton: "Chat-module_DyU0xW_suggestedPromptButton",
	suggestedPromptsGrid: "Chat-module_DyU0xW_suggestedPromptsGrid"
};
var InnerChatMessage = (t0) => {
	const $ = c(54);
	let isFirstReply;
	let isLatestMessage;
	let isStreaming;
	let onClickReference;
	let props;
	if ($[0] !== t0) {
		({isLatestMessage, isFirstReply, isStreaming, onClickReference, ...props} = t0);
		$[0] = t0;
		$[1] = isFirstReply;
		$[2] = isLatestMessage;
		$[3] = isStreaming;
		$[4] = onClickReference;
		$[5] = props;
	} else {
		isFirstReply = $[1];
		isLatestMessage = $[2];
		isStreaming = $[3];
		onClickReference = $[4];
		props = $[5];
	}
	const { message } = useChatMessage();
	const state = useChatState();
	const manager = useChatManager();
	let t1;
	if ($[6] !== isLatestMessage || $[7] !== isStreaming || $[8] !== props.excludeFeedback || $[9] !== props.inputRef) {
		t1 = {
			excludeFeedback: props.excludeFeedback,
			inputRef: props.inputRef,
			isLatestMessage,
			isStreaming,
			excludeReferencesFromFocusZone: true
		};
		$[6] = isLatestMessage;
		$[7] = isStreaming;
		$[8] = props.excludeFeedback;
		$[9] = props.inputRef;
		$[10] = t1;
	} else t1 = $[10];
	const { author, handleConfirmationAction, handleRetryErrorMessage, hasClientConfirmations, isAI, isCopilot, isError, isAgentError, isInterrupted, isUser: isFromUser, myRef, rendererConfig, renderFeedback, shouldShowMessageActions, skillExecutionToUseForRespondingText, showRetryButton } = useChatMessageBehavior(t1);
	const isUser = isFromUser;
	const isCopilotLoading = isStreaming;
	const isLoading = isCopilotLoading && isLatestMessage;
	const isCopilotMessage = isCopilot;
	let t2;
	if ($[11] !== message.references) {
		t2 = message.references ?? [];
		$[11] = message.references;
		$[12] = t2;
	} else t2 = $[12];
	let t3;
	if ($[13] !== t2) {
		t3 = getRenderableReferences(t2);
		$[13] = t2;
		$[14] = t3;
	} else t3 = $[14];
	const renderableReferences = t3;
	let t4;
	if ($[15] !== manager) {
		t4 = manager.maxMessagesReached();
		$[15] = manager;
		$[16] = t4;
	} else t4 = $[16];
	const maxMessagesReached = t4;
	let t5;
	if ($[17] !== author || $[18] !== handleConfirmationAction || $[19] !== handleRetryErrorMessage || $[20] !== hasClientConfirmations || $[21] !== isAI || $[22] !== isAgentError || $[23] !== isCopilot || $[24] !== isCopilotLoading || $[25] !== isCopilotMessage || $[26] !== isError || $[27] !== isFirstReply || $[28] !== isInterrupted || $[29] !== isLatestMessage || $[30] !== isLoading || $[31] !== isStreaming || $[32] !== isUser || $[33] !== manager || $[34] !== maxMessagesReached || $[35] !== message || $[36] !== myRef || $[37] !== onClickReference || $[38] !== renderFeedback || $[39] !== renderableReferences || $[40] !== rendererConfig || $[41] !== shouldShowMessageActions || $[42] !== showRetryButton || $[43] !== skillExecutionToUseForRespondingText || $[44] !== state) {
		const tokenRenderableReferences = renderableReferences.filter(_temp$5);
		let t6;
		if ($[46] !== message.mediaContent) {
			t6 = message.mediaContent?.filter(_temp2$2);
			$[46] = message.mediaContent;
			$[47] = t6;
		} else t6 = $[47];
		const images = t6;
		const shouldShowImages = typeof images !== "undefined" && images.length > 0 || false;
		let t7;
		if ($[48] !== manager || $[49] !== renderableReferences || $[50] !== state.mode) {
			t7 = (event) => {
				const href = event.target.href;
				const reference = renderableReferences.find((r_0) => r_0.url === href);
				if (reference && state.mode === "immersive") {
					manager.selectReference(reference);
					event.preventDefault();
				}
			};
			$[48] = manager;
			$[49] = renderableReferences;
			$[50] = state.mode;
			$[51] = t7;
		} else t7 = $[51];
		const onLinkClick = t7;
		let t8;
		if ($[52] !== manager) {
			t8 = (wrap) => {
				manager.setWrapCodeLines(wrap);
			};
			$[52] = manager;
			$[53] = t8;
		} else t8 = $[53];
		const onWrapCodeLinesChange = t8;
		t5 = jsxs("div", {
			className: clsx("message-container", ChatMessage_module_default.messageContainer, isUser && ChatMessage_module_default.user, isAI && ChatMessage_module_default.ai),
			ref: myRef,
			...testIdProps(`message-${isError ? "error" : isStreaming ? "streaming" : message.id}`),
			children: [
				isUser && shouldShowImages && jsx("div", { children: images?.map((image) => jsx(ChatImage, {
					src: image?.url || "",
					alt: "Uploaded image",
					mode: state.mode
				}, image?.url || "")) }),
				isCopilotMessage ? jsx(CopilotBadge, {
					isLoading: isCopilotLoading && isLatestMessage,
					isError: isError && message.error?.type !== "agentUnauthorized",
					mode: state.mode,
					isFirstMessage: isFirstReply,
					isLoadingSkills: (message.skillExecutions ?? []).length > 0 && isCopilotLoading && message.content === "" && isLatestMessage,
					message: message.content || "",
					createdAt: message.createdAt
				}) : isAI ? jsx("div", {
					className: ChatMessage_module_default.avatar,
					children: jsx(GitHubAvatar, {
						src: author.avatarURL,
						size: 24,
						"aria-label": `${author.name} avatar`,
						alt: `${author.name} avatar`,
						"data-testid": "chat-message-author-avatar"
					})
				}) : null,
				isUser && !hasClientConfirmations && jsx(ChatMessageReferenceTokens, {
					size: "small",
					className: "mb-2",
					references: tokenRenderableReferences,
					message,
					onClickReference
				}),
				jsxs("div", {
					className: clsx(ChatMessage_module_default.message, isUser && ChatMessage_module_default.user),
					children: [
						hasClientConfirmations && message.clientConfirmations?.length ? jsx("div", {
							className: clsx("my-1", ChatMessage_module_default.clientConfirmationContainer, isUser && ChatMessage_module_default.clientConfirmationUser),
							"data-testid": "chat-message-client-confirmations",
							children: jsxs("span", {
								className: ChatMessage_module_default.confirmationStatusText,
								children: [
									jsx(CheckIcon, {}),
									" ",
									message.clientConfirmations?.[0]?.userLogin || "User",
									" ",
									message.clientConfirmations?.[0]?.state,
									" the action"
								]
							})
						}) : null,
						isCopilot && isLoading && !message.content && jsx(WithShimmerEffect, {
							className: clsx(ChatMessage_module_default.skillExecutionText, "mb-2"),
							children: `${messageFromFunctionCall(skillExecutionToUseForRespondingText)}...`
						}),
						jsx("div", {
							className: clsx(ChatMessage_module_default.messageContent, !!hasClientConfirmations && ChatMessage_module_default.hasClientConfirmations),
							children: jsxs(Fragment$1, { children: [
								jsxs("div", {
									className: clsx("js-snippet-clipboard-copy-unpositioned", ChatMessage_module_default.messageContentWrapper),
									children: [
										message.role === "assistant" && message.content && (renderableReferences?.length ? jsx(ChatMessageReferencesList, {
											className: "mb-2",
											references: renderableReferences
										}) : null),
										!hasClientConfirmations && (isUser ? jsx(UserMessage, {}) : message.content && jsx(MarkdownRenderer, {
											markdown: message.content,
											onLinkClick,
											chatMode: "assistive",
											wrapCodeLines: state.wrapCodeLines,
											onWrapCodeLinesChange,
											...rendererConfig
										})),
										isError ? jsx(ErrorMessage, { manager }) : null,
										isAgentError && message.agentErrors?.length ? jsx(AgentErrors, { errors: message.agentErrors }) : null,
										isInterrupted ? jsx(InterruptedBanner, { messageHasContent: !!message.content || !!message.skillExecutions?.length }) : null,
										(isCopilot || isAgent(author)) && filterUniqueConfirmations(message.confirmations).map((confirmation, i) => confirmation.confirmation.name === "indexrepo" ? null : jsx(Confirmation, {
											confirmation,
											handleConfirmation: handleConfirmationAction,
											isLatestMessage
										}, i))
									]
								}),
								!shouldShowMessageActions && showRetryButton && jsx(RetryButton, {
									handleRetryMessage: handleRetryErrorMessage,
									disabled: maxMessagesReached
								}),
								shouldShowMessageActions && jsxs("div", {
									className: clsx("message-actions", ChatMessage_module_default.messageActionsContainer, !isLatestMessage && ChatMessage_module_default.floatingActions),
									"data-testid": "message-action-bar",
									children: [
										renderFeedback && jsx(Feedback, { iconSize: "small" }),
										isCopilot && !!message.content && !isStreaming && jsx(CopyToClipboardButton, {
											textToCopy: message.content ?? "",
											ariaLabel: "Copy to clipboard",
											size: "small",
											className: "d-flex flex-items-center",
											onCopy: () => {
												sendEvent("copilot_chat.activate", {
													target: "CHAT_MESSAGE_COPY",
													mode: state.mode
												});
											}
										}),
										showRetryButton && jsx(RetryButton, {
											handleRetryMessage: handleRetryErrorMessage,
											disabled: maxMessagesReached
										})
									]
								})
							] })
						})
					]
				})
			]
		});
		$[17] = author;
		$[18] = handleConfirmationAction;
		$[19] = handleRetryErrorMessage;
		$[20] = hasClientConfirmations;
		$[21] = isAI;
		$[22] = isAgentError;
		$[23] = isCopilot;
		$[24] = isCopilotLoading;
		$[25] = isCopilotMessage;
		$[26] = isError;
		$[27] = isFirstReply;
		$[28] = isInterrupted;
		$[29] = isLatestMessage;
		$[30] = isLoading;
		$[31] = isStreaming;
		$[32] = isUser;
		$[33] = manager;
		$[34] = maxMessagesReached;
		$[35] = message;
		$[36] = myRef;
		$[37] = onClickReference;
		$[38] = renderFeedback;
		$[39] = renderableReferences;
		$[40] = rendererConfig;
		$[41] = shouldShowMessageActions;
		$[42] = showRetryButton;
		$[43] = skillExecutionToUseForRespondingText;
		$[44] = state;
		$[45] = t5;
	} else t5 = $[45];
	return t5;
};
InnerChatMessage.displayName = "InnerChatMessage";
var ChatMessage = ({ message, ...props }) => /* @__PURE__ */ jsx(ChatMessageProvider, {
	message,
	children: /* @__PURE__ */ jsx(InnerChatMessage, { ...props })
});
ChatMessage.displayName = "ChatMessage";
function _temp$5(r) {
	return r.type !== "image" && r.type !== "org-instructions";
}
function _temp2$2(media) {
	return media.mediaType.startsWith("image/");
}
var CustomBanner_module_default = {
	actions: "CustomBanner-module_H3HEEq_actions",
	container: "CustomBanner-module_H3HEEq_container",
	content: "CustomBanner-module_H3HEEq_content",
	expanded: "CustomBanner-module_H3HEEq_expanded",
	icon: "CustomBanner-module_H3HEEq_icon",
	iconButton: "CustomBanner-module_H3HEEq_iconButton"
};
function CustomBanner({ icon, content, actions, onDismiss }) {
	const containerRef = useRef(null);
	const [isExpanded, setIsExpanded] = useState(false);
	useEffect(() => {
		const container = containerRef.current;
		if (!container) return;
		const resizeObserver = new ResizeObserver((entries) => {
			for (const entry of entries) if (entry.target === container) if (entry.contentRect.height > 40) setIsExpanded(true);
			else setIsExpanded(false);
		});
		resizeObserver.observe(container);
		return () => {
			resizeObserver.disconnect();
		};
	}, []);
	return /* @__PURE__ */ jsxs("div", {
		ref: containerRef,
		className: `${CustomBanner_module_default.container} ${isExpanded ? CustomBanner_module_default.expanded : ""}`,
		children: [
			/* @__PURE__ */ jsx("div", {
				className: CustomBanner_module_default.icon,
				children: icon
			}),
			/* @__PURE__ */ jsx("div", {
				className: CustomBanner_module_default.content,
				children: content
			}),
			/* @__PURE__ */ jsxs("div", {
				className: CustomBanner_module_default.actions,
				children: [actions, onDismiss && /* @__PURE__ */ jsx(IconButton, {
					className: CustomBanner_module_default.iconButton,
					variant: "invisible",
					icon: XIcon,
					size: "medium",
					"aria-label": "Close",
					onClick: onDismiss
				})]
			})
		]
	});
}
CustomBanner.displayName = "CustomBanner";
function QuotaExceededBanner() {
	const $ = c(2);
	const { resetDate } = useEntitlement();
	let t0;
	if ($[0] !== resetDate) {
		t0 = jsx(CustomBanner, {
			icon: jsx(InfoIcon, {}),
			content: jsxs(Fragment$1, { children: [
				jsx(VisuallyHidden, { children: jsx("h2", { children: "Usage limit reached" }) }),
				"You have reached your free plan limit. It will reset on ",
				resetDate
			] }),
			actions: jsx(LinkButton, {
				as: "a",
				href: "https://github.com/features/copilot#pricing",
				onClick: _temp$4,
				children: "Upgrade"
			})
		});
		$[0] = resetDate;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
QuotaExceededBanner.displayName = "QuotaExceededBanner";
function _temp$4() {
	sendEvent("dotcom_chat.activate", {
		target: "QUOTA_EXCEEDED_BANNER_LINK_UPGRADE",
		mode: "assistive"
	});
}
var QuotaExceededEmptyState_module_default = {
	container: "QuotaExceededEmptyState-module_i-88oG_container",
	copy: "QuotaExceededEmptyState-module_i-88oG_copy",
	description: "QuotaExceededEmptyState-module_i-88oG_description",
	footer: "QuotaExceededEmptyState-module_i-88oG_footer",
	heading: "QuotaExceededEmptyState-module_i-88oG_heading",
	main: "QuotaExceededEmptyState-module_i-88oG_main"
};
function QuotaExceededEmptyState() {
	const $ = c(7);
	const { resetDate } = useEntitlement();
	const [hovered, setHovered] = useState(false);
	const [isAnimating, setIsAnimating] = useState(false);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			setHovered(true);
			setIsAnimating(true);
		};
		$[0] = t0;
	} else t0 = $[0];
	const handleMouseEnter = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			setHovered(false);
		};
		$[1] = t1;
	} else t1 = $[1];
	const handleMouseLeave = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			setIsAnimating(false);
		};
		$[2] = t2;
	} else t2 = $[2];
	const handleAnimationEnd = t2;
	const shouldAnimate = hovered || isAnimating;
	let t3;
	if ($[3] !== hovered || $[4] !== resetDate || $[5] !== shouldAnimate) {
		t3 = jsxs("div", {
			className: QuotaExceededEmptyState_module_default.container,
			children: [jsxs("div", {
				className: QuotaExceededEmptyState_module_default.main,
				children: [shouldAnimate ? jsx(CopilotAnimation, {
					animationType: "jumpWiggle",
					loopAnimation: hovered,
					size: 80,
					onAnimationEnd: handleAnimationEnd
				}) : jsx(CopilotAnimation, {
					animationType: "static",
					loopAnimation: false,
					size: 80
				}), jsxs("div", {
					className: QuotaExceededEmptyState_module_default.copy,
					children: [
						jsx("h2", {
							className: QuotaExceededEmptyState_module_default.heading,
							children: "You’ve reached your free plan limit"
						}),
						jsxs("p", {
							className: QuotaExceededEmptyState_module_default.description,
							children: [
								"Your limits will reset on ",
								resetDate,
								"."
							]
						}),
						jsx(LinkButton, {
							as: "a",
							variant: "primary",
							href: "https://github.com/github-copilot/pro",
							onMouseEnter: handleMouseEnter,
							onMouseLeave: handleMouseLeave,
							onClick: _temp$3,
							children: "Upgrade"
						})
					]
				})]
			}), jsxs("div", {
				className: QuotaExceededEmptyState_module_default.footer,
				children: [jsx("strong", { children: "Part of an organization?" }), jsxs("span", { children: [
					"Upgrade to",
					" ",
					jsx(Link, {
						href: "https://github.com/github-copilot/business_signup/choose_business_type?cft=copilot_li.features_copilot.cfb",
						inline: true,
						children: "Copilot Business"
					}),
					" ",
					"to enable across teams."
				] })]
			})]
		});
		$[3] = hovered;
		$[4] = resetDate;
		$[5] = shouldAnimate;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
QuotaExceededEmptyState.displayName = "QuotaExceededEmptyState";
function _temp$3() {
	sendEvent("dotcom_chat.activate", {
		target: "QUOTA_EXCEEDED_EMPTY_STATE_LINK_UPGRADE",
		mode: "assistive"
	});
}
var QuotaMeterBanner_module_default = { container: "QuotaMeterBanner-module_-YMgrG_container" };
function QuotaMeterBanner() {
	const $ = c(6);
	const { isLicensedLimited, chatQuotaRemaining } = useEntitlement();
	const [isVisible, setIsVisible] = useState(_temp$2);
	let t0;
	let t1;
	if ($[0] !== chatQuotaRemaining || $[1] !== isLicensedLimited) {
		t0 = () => {
			if (isLicensedLimited && chatQuotaRemaining !== void 0) {
				const existingFlag = copilotLocalStorage.getMeterBannerFlag();
				if (chatQuotaRemaining > 0 && chatQuotaRemaining <= 10) if (existingFlag === null) {
					copilotLocalStorage.setMeterBannerFlag(true);
					setIsVisible(true);
				} else setIsVisible(existingFlag);
				else {
					copilotLocalStorage.removeMeterBannerFlag();
					setIsVisible(false);
				}
			}
		};
		t1 = [isLicensedLimited, chatQuotaRemaining];
		$[0] = chatQuotaRemaining;
		$[1] = isLicensedLimited;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			copilotLocalStorage.setMeterBannerFlag(false);
			setIsVisible(false);
		};
		$[4] = t2;
	} else t2 = $[4];
	const handleDismiss = t2;
	if (!isVisible || chatQuotaRemaining === void 0) return null;
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		const icon = jsx(InfoIcon, {});
		const content = jsxs(Fragment$1, { children: [jsx(VisuallyHidden, { children: jsx("h2", { children: "Usage limit approaching" }) }), "You only have a few free responses remaining."] });
		const actions = jsx(LinkButton, {
			as: "a",
			href: "https://github.com/features/copilot#pricing",
			onClick: _temp2$1,
			children: "Upgrade"
		});
		t3 = jsx("div", {
			className: QuotaMeterBanner_module_default.container,
			children: jsx(CustomBanner, {
				icon,
				content,
				actions,
				onDismiss: handleDismiss
			})
		});
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
QuotaMeterBanner.displayName = "QuotaMeterBanner";
function _temp2$1() {
	sendEvent("dotcom_chat.activate", {
		target: "QUOTA_METER_BANNER_LINK_UPGRADE",
		mode: "assistive"
	});
}
function _temp$2() {
	return copilotLocalStorage.getMeterBannerFlag() ?? false;
}
var ChatWithCopilotHeader_module_default = {
	descriptionText: "ChatWithCopilotHeader-module_4DOWmG_descriptionText",
	descriptionTextDefault: "ChatWithCopilotHeader-module_4DOWmG_descriptionTextDefault",
	descriptionTextImmersive: "ChatWithCopilotHeader-module_4DOWmG_descriptionTextImmersive",
	headerTitle: "ChatWithCopilotHeader-module_4DOWmG_headerTitle",
	iconContainer: "ChatWithCopilotHeader-module_4DOWmG_iconContainer"
};
function ChatWithCopilotHeader({ mode }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("div", {
			className: ChatWithCopilotHeader_module_default.iconContainer,
			children: /* @__PURE__ */ jsx(CopilotIconAnimation, {})
		}),
		/* @__PURE__ */ jsx(Heading$2, {
			as: "h1",
			className: ChatWithCopilotHeader_module_default.headerTitle,
			children: "Ask Copilot"
		}),
		/* @__PURE__ */ jsx("p", {
			className: clsx(ChatWithCopilotHeader_module_default.descriptionText, mode === "immersive" ? ChatWithCopilotHeader_module_default.descriptionTextImmersive : ChatWithCopilotHeader_module_default.descriptionTextDefault),
			children: "Select a repository to get started. Ask questions about your codebase to get answers fast and learn your way around."
		})
	] });
}
ChatWithCopilotHeader.displayName = "ChatWithCopilotHeader";
var ActionList_Divider = "TopicList-module_VAj2YG_ActionList_Divider";
var generalPurposeItem = "TopicList-module_VAj2YG_generalPurposeItem";
var loadingContainer = "TopicList-module_VAj2YG_loadingContainer";
var mutedLeadingVisual = "TopicList-module_VAj2YG_mutedLeadingVisual";
var searchInputContainer = "TopicList-module_VAj2YG_searchInputContainer";
var TextInput = "TopicList-module_VAj2YG_TextInput";
var TopicListContainer = "TopicList-module_VAj2YG_TopicListContainer";
var TopicList_module_default = {
	ActionList_Divider,
	"chat-with-no-context--label": "TopicList-module_VAj2YG_chat-with-no-context--label",
	generalPurposeItem,
	loadingContainer,
	mutedLeadingVisual,
	searchInputContainer,
	TextInput,
	TopicListContainer
};
var UNFILTERED_TOPICS_DISPLAY_COUNT = 4;
function TopicList() {
	const $ = c(8);
	const copilotChatManager = useChatManager();
	const { mode, selectedThreadID } = useChatState();
	const [filterText, setFilterText] = useState("");
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (newFilter) => setFilterText(newFilter);
		$[0] = t0;
	} else t0 = $[0];
	const debouncedSetFilter = debounce(t0, 400, { start: false });
	const { repositories, loading: reposLoading, resetTopRepoResults } = useRepositoryItems(filterText, true, UNFILTERED_TOPICS_DISPLAY_COUNT);
	let t1;
	if ($[1] !== copilotChatManager || $[2] !== mode || $[3] !== resetTopRepoResults || $[4] !== selectedThreadID) {
		t1 = async (repoId) => {
			resetTopRepoResults();
			if (repoId === void 0) {
				copilotChatManager.showTopicPicker(false);
				copilotChatManager.clearCurrentTopic();
				copilotChatManager.clearCurrentReferences();
				if (mode === "immersive") addUrlToHistoryStack("/copilot");
				if (selectedThreadID) copilotLocalStorage.setSelectedTopic(selectedThreadID, null);
				return;
			} else {
				await copilotChatManager.fetchCurrentRepo(Number(repoId));
				copilotChatManager.showTopicPicker(false);
			}
		};
		$[1] = copilotChatManager;
		$[2] = mode;
		$[3] = resetTopRepoResults;
		$[4] = selectedThreadID;
		$[5] = t1;
	} else t1 = $[5];
	const onSelect = t1;
	let t2;
	bb0: {
		if (reposLoading) {
			t2 = "Loading repositories";
			break bb0;
		}
		if (repositories.length === 0) {
			t2 = "No repositories found";
			break bb0;
		}
		if (repositories.length === 1) {
			t2 = "1 repository found";
			break bb0;
		}
		t2 = `${repositories.length} repositories found`;
	}
	const srRepoSearchStatus = t2;
	let t3;
	if ($[6] !== onSelect) {
		t3 = () => onSelect(void 0);
		$[6] = onSelect;
		$[7] = t3;
	} else t3 = $[7];
	return jsxs("div", {
		className: TopicList_module_default.TopicListContainer,
		children: [jsx("div", {
			className: TopicList_module_default.searchInputContainer,
			children: jsx(TextInput$1, {
				id: copilotChatSearchInputId,
				leadingVisual: SearchIcon,
				name: "topic-search",
				"aria-label": "Search repositories to chat about",
				placeholder: "Search repositories to chat about",
				onChange: (e) => debouncedSetFilter(e.target.value),
				className: TopicList_module_default.TextInput
			})
		}), jsxs(ActionList, { children: [
			jsx("div", {
				role: "status",
				className: "sr-only",
				children: srRepoSearchStatus
			}),
			reposLoading ? jsx("li", {
				className: TopicList_module_default.loadingContainer,
				children: jsx(Spinner, {})
			}) : repositories.length === 0 ? jsxs(ActionList.Item, {
				disabled: true,
				children: [jsx(ActionList.LeadingVisual, {
					className: TopicList_module_default.mutedLeadingVisual,
					children: jsx(CircleSlashIcon, {})
				}), jsx("span", {
					className: TopicList_module_default.mutedLeadingVisual,
					children: "No results found"
				})]
			}) : jsx(Fragment$1, { children: repositories.length > 0 && jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, {
				as: "h3",
				children: "Recent repositories"
			}), repositories.map((repo) => jsx(RepositoryListItem, {
				repo,
				onSelect,
				trailingVisualComponent: jsx(ArrowRightIcon, {})
			}, repo.nwo))] }) }),
			jsx(ActionList.Divider, { className: TopicList_module_default.ActionList_Divider }),
			jsxs(ActionList.Item, {
				id: "chat-with-no-context",
				onSelect: t3,
				className: TopicList_module_default.generalPurposeItem,
				children: ["General purpose chat", jsx(ActionList.TrailingVisual, { children: jsx(ArrowRightIcon, {}) })]
			}, "chat-with-no-context")
		] })]
	});
}
TopicList.displayName = "TopicList";
var TopicPicker_module_default = {
	Heading: "TopicPicker-module_roZTAG_Heading",
	mainContentContainer: "TopicPicker-module_roZTAG_mainContentContainer",
	repositoriesContainer: "TopicPicker-module_roZTAG_repositoriesContainer",
	repositoriesSubheading: "TopicPicker-module_roZTAG_repositoriesSubheading",
	repositoryItem: "TopicPicker-module_roZTAG_repositoryItem",
	SingleSignOnBanner: "TopicPicker-module_roZTAG_SingleSignOnBanner",
	statusText: "TopicPicker-module_roZTAG_statusText",
	topicDescriptionContainer: "TopicPicker-module_roZTAG_topicDescriptionContainer",
	topicListContainer: "TopicPicker-module_roZTAG_topicListContainer",
	TopicPickerContainer: "TopicPicker-module_roZTAG_TopicPickerContainer"
};
var TopicPicker = () => {
	const $ = c(2);
	const state = useChatState();
	let t0;
	if ($[0] !== state.mode) {
		t0 = jsx("div", {
			className: TopicPicker_module_default.TopicPickerContainer,
			children: jsxs("div", {
				className: TopicPicker_module_default.mainContentContainer,
				children: [jsx(ChatWithCopilotHeader, { mode: state.mode }), jsx("div", {
					className: TopicPicker_module_default.topicListContainer,
					children: jsx(TopicList, {})
				})]
			})
		});
		$[0] = state.mode;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
};
TopicPicker.displayName = "TopicPicker";
var Messages = (t0) => {
	const $ = c(12);
	const { disableTopicPicker, inputRef, showQuotaExceededEmptyState } = t0;
	const state = useChatState();
	const { isWaitingOnCopilot, showTopicPicker, streamingMessage } = state;
	const { scrollToBottom } = useChatScroll();
	const { messages: activeMessages, groupedMessages } = useGroupedMessages(state);
	let t1;
	let t2;
	if ($[0] !== scrollToBottom) {
		t1 = () => scrollToBottom("instant");
		t2 = [scrollToBottom];
		$[0] = scrollToBottom;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useLayoutEffect(t1, t2);
	let t3;
	if ($[3] !== activeMessages || $[4] !== disableTopicPicker || $[5] !== groupedMessages || $[6] !== inputRef || $[7] !== isWaitingOnCopilot || $[8] !== showQuotaExceededEmptyState || $[9] !== showTopicPicker || $[10] !== streamingMessage) {
		t3 = jsxs(Fragment$1, { children: [jsx("h2", {
			className: "sr-only",
			children: "Copilot Chat"
		}), showQuotaExceededEmptyState ? jsx(QuotaExceededEmptyState, {}) : showTopicPicker && !disableTopicPicker ? jsx(TopicPicker, {}) : jsx("div", {
			className: Chat_module_default.ChatMainContainer,
			children: jsxs("div", {
				className: clsx("copilot-messages-container", Chat_module_default.messagesContainer),
				children: [activeMessages.length === 0 && jsx("p", {
					className: Chat_module_default.legalText,
					children: jsx(LegalDisclaimer, {})
				}), groupedMessages.map((group, i) => jsx(ChatMessagesGroup, {
					isLastGroup: i === groupedMessages.length - 1,
					children: group.map((message, j) => {
						const isLatestMessage = i === groupedMessages.length - 1 && j === group.length - 1;
						return (message === streamingMessage || message.id === "NULL_MESSAGE" || !isMessageEmpty(message) || message.error) && jsx(ChatMessage, {
							isLatestMessage,
							isFirstReply: activeMessages.length === 1,
							isStreaming: message.id === streamingMessage?.id || isLatestMessage && isWaitingOnCopilot,
							message,
							inputRef
						}, j);
					})
				}, i))]
			})
		})] });
		$[3] = activeMessages;
		$[4] = disableTopicPicker;
		$[5] = groupedMessages;
		$[6] = inputRef;
		$[7] = isWaitingOnCopilot;
		$[8] = showQuotaExceededEmptyState;
		$[9] = showTopicPicker;
		$[10] = streamingMessage;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
};
Messages.displayName = "Messages";
var isMessageEmpty = (message) => {
	return !message.content && (!message.confirmations || message.confirmations.length === 0) && (!message.clientConfirmations || message.clientConfirmations.length === 0);
};
var Loading = () => {
	return /* @__PURE__ */ jsxs("div", {
		className: Chat_module_default.loadingStateContainer,
		children: [/* @__PURE__ */ jsx(Spinner, { size: "large" }), /* @__PURE__ */ jsx("div", {
			className: Chat_module_default.loadingText,
			children: "Loading conversation…"
		})]
	});
};
Loading.displayName = "Loading";
var Error = () => {
	const $ = c(3);
	const { mode, reviewLab } = useChatState();
	let t0;
	if ($[0] !== mode || $[1] !== reviewLab) {
		t0 = jsxs("div", {
			className: clsx(Chat_module_default.errorContainer, mode === "immersive" ? Chat_module_default.errorContainerImmersive : Chat_module_default.errorContainerDefault),
			children: [
				jsx(Octicon, { icon: AlertIcon }),
				"Failed to load previous messages.",
				reviewLab && jsx(Fragment$1, { children: "\xA0You are in a review lab. Please check that you are connected to the Developer VPN." })
			]
		});
		$[0] = mode;
		$[1] = reviewLab;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
};
Error.displayName = "Error";
var Chat = (t0) => {
	const $ = c(36);
	const { inputRef } = t0;
	const state = useChatState();
	const manager = useChatManager();
	const { currentReferences, messagesLoading, messagesRestored, threadsLoading, currentTopic, messages, mode, selectedThreadID, showTopicPicker, context } = state;
	let t1;
	if ($[0] !== state) {
		t1 = getSelectedThread(state);
		$[0] = state;
		$[1] = t1;
	} else t1 = $[1];
	const thread = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = getSuggestions();
		$[2] = t2;
	} else t2 = $[2];
	const suggestions = t2;
	const { textAreaRef } = useChat(inputRef);
	const { chatQuotaExceeded, isLicensedLimited, reloadQuota } = useEntitlement();
	const { ambientError } = useChatState();
	const defaultModel = useDefaultModel(state.availableModels);
	let t3;
	let t4;
	if ($[3] !== messages.length || $[4] !== mode || $[5] !== selectedThreadID) {
		t3 = () => {
			if (!selectedThreadID || mode === "assistive") return;
			const threadPath = `${COPILOT_PATH}/c/${selectedThreadID}`;
			if (window.location.pathname === threadPath || messages.length === 0) return;
			addUrlToHistoryStack(threadPath);
		};
		t4 = [
			selectedThreadID,
			mode,
			messages.length
		];
		$[3] = messages.length;
		$[4] = mode;
		$[5] = selectedThreadID;
		$[6] = t3;
		$[7] = t4;
	} else {
		t3 = $[6];
		t4 = $[7];
	}
	useEffect(t3, t4);
	let t5;
	if ($[8] !== context || $[9] !== currentReferences || $[10] !== currentTopic || $[11] !== defaultModel || $[12] !== manager || $[13] !== reloadQuota || $[14] !== state.customInstructions || $[15] !== state.skillOptions || $[16] !== thread) {
		t5 = async (content, additionalReferences) => {
			if (content.trim() === "") return;
			reloadQuota("user_submit");
			const allReferences = [...currentReferences, ...additionalReferences || []];
			await manager.sendChatMessage({
				thread,
				content,
				references: allReferences,
				topic: currentTopic,
				context,
				customInstructions: state.customInstructions,
				skillOptions: state.skillOptions,
				model: defaultModel
			});
		};
		$[8] = context;
		$[9] = currentReferences;
		$[10] = currentTopic;
		$[11] = defaultModel;
		$[12] = manager;
		$[13] = reloadQuota;
		$[14] = state.customInstructions;
		$[15] = state.skillOptions;
		$[16] = thread;
		$[17] = t5;
	} else t5 = $[17];
	const handleUserSubmit = t5;
	const hasRestoredMessages = messagesRestored && messages.length > 0;
	const isLoading = messagesLoading.state === "loading" && state.selectedThreadID && !showTopicPicker && !hasRestoredMessages;
	const isError = messagesLoading.state === "error" || threadsLoading.state === "error";
	const isLoaded = messagesLoading.state === "loaded" || hasRestoredMessages;
	const showQuotaExceededEmptyState = chatQuotaExceeded && (showTopicPicker || !thread);
	const shouldShowChatInput = !showTopicPicker && !showQuotaExceededEmptyState;
	let t6;
	if ($[18] !== messages) {
		t6 = getActiveMessages(messages);
		$[18] = messages;
		$[19] = t6;
	} else t6 = $[19];
	const activeMessages = t6;
	const shouldShowSuggestedPrompts = Boolean(!isLoading && !state.currentTopic && !showTopicPicker && activeMessages.length === 0 && currentReferences.length === 0 && !state.suggestionsContext);
	let t7;
	if ($[20] !== activeMessages || $[21] !== ambientError || $[22] !== chatQuotaExceeded || $[23] !== handleUserSubmit || $[24] !== isError || $[25] !== isLicensedLimited || $[26] !== isLoaded || $[27] !== isLoading || $[28] !== manager || $[29] !== selectedThreadID || $[30] !== shouldShowChatInput || $[31] !== shouldShowSuggestedPrompts || $[32] !== showQuotaExceededEmptyState || $[33] !== state || $[34] !== textAreaRef) {
		t7 = jsx(Fragment$1, { children: jsxs(Fragment$1, { children: [
			jsxs(ChatScrollContainer, {
				className: "copilot-chat-messages",
				style: { flex: "1 1 auto" },
				children: [
					isLoading && jsx(Loading, {}),
					isError && jsx(Error, {}),
					isLoaded && !isLoading && jsx(Messages, {
						inputRef: textAreaRef,
						showQuotaExceededEmptyState
					}),
					jsx(MessagesPortalContainer, {})
				]
			}),
			shouldShowSuggestedPrompts && jsx("div", {
				className: clsx("copilot-chat-messages", Chat_module_default.suggestedPromptsGrid),
				children: suggestions.map((s, i) => jsx(SuggestedPrompt, {
					heading: s.heading,
					content: s.content,
					onSubmit: () => {
						manager.sendChatMessage({
							thread: getSelectedThread(state),
							content: s.content,
							references: state.currentReferences,
							topic: state.currentTopic,
							context: state.context
						});
						sendEvent("copilot_chat_suggestion_click", { topic: state.currentTopic?.name });
					}
				}, i))
			}),
			!isLoading && shouldShowChatInput && jsx("div", {
				className: clsx("copilot-chat-input copilot-chat-input-outer", Chat_module_default.chatInputContainer),
				children: chatQuotaExceeded ? jsx(QuotaExceededBanner, {}) : jsxs(Fragment$1, { children: [!shouldShowSuggestedPrompts && activeMessages.length === 0 && !state.showTopicPicker && jsx(CopilotSuggestions_default, { suggestionKind: "initial" }), jsxs("div", { children: [
					isLicensedLimited && jsx(QuotaMeterBanner, {}),
					ambientError && jsx(AmbientErrorBanner, { ambientError }),
					jsx(ChatInput, {
						modes: [{
							name: ModeSupportName.Ask,
							supportsAttachments: true,
							supportsModelSwitching: true,
							supportsSpaces: true,
							supportsAutocompletion: true,
							icon: CommentIcon
						}],
						textAreaRef,
						onSubmit: handleUserSubmit,
						isStreaming: !!state.streamingMessage,
						size: "small",
						isNewConversation: activeMessages.length === 0
					}, selectedThreadID)
				] })] })
			})
		] }) });
		$[20] = activeMessages;
		$[21] = ambientError;
		$[22] = chatQuotaExceeded;
		$[23] = handleUserSubmit;
		$[24] = isError;
		$[25] = isLicensedLimited;
		$[26] = isLoaded;
		$[27] = isLoading;
		$[28] = manager;
		$[29] = selectedThreadID;
		$[30] = shouldShowChatInput;
		$[31] = shouldShowSuggestedPrompts;
		$[32] = showQuotaExceededEmptyState;
		$[33] = state;
		$[34] = textAreaRef;
		$[35] = t7;
	} else t7 = $[35];
	return t7;
};
Chat.displayName = "Chat";
function SuggestedPrompt({ heading, content, onSubmit }) {
	return /* @__PURE__ */ jsxs(ButtonComponent, {
		onClick: onSubmit,
		className: Chat_module_default.suggestedPromptButton,
		children: [/* @__PURE__ */ jsx(Heading$2, {
			as: "h3",
			className: Chat_module_default.promptHeading,
			children: heading
		}), /* @__PURE__ */ jsx("p", {
			className: Chat_module_default.promptDescription,
			children: content
		})]
	});
}
SuggestedPrompt.displayName = "SuggestedPrompt";
function getSuggestions() {
	return shuffle(Object.keys(suggestedPrompts)).slice(0, 4).map((c) => ({
		heading: c,
		content: shuffle(suggestedPrompts[c])[0]
	}));
}
var ChatPanel_module_default = {
	ChatPanelContainer: "ChatPanel-module_qmsg6q_ChatPanelContainer",
	copilotChatPanel: "ChatPanel-module_qmsg6q_copilotChatPanel",
	cornerResizeTarget: "ChatPanel-module_qmsg6q_cornerResizeTarget",
	horizontalResizeTarget: "ChatPanel-module_qmsg6q_horizontalResizeTarget",
	openChat: "ChatPanel-module_qmsg6q_openChat",
	panelContentContainer: "ChatPanel-module_qmsg6q_panelContentContainer",
	verticalResizeTarget: "ChatPanel-module_qmsg6q_verticalResizeTarget"
};
var ChatPanel = (props) => {
	const { children, initialFocusRef, staffDialogRef, handleClose, panelWidth, panelHeight, startResize, onResizerKeyDown } = props;
	const state = useChatState();
	const { chatIsOpen, currentTopic } = state;
	const entryPointId = state.entryPointId ?? "copilot-chat-header-button";
	const overlayRef = useRef(null);
	const entryPointRef = useRef(null);
	useEffect(() => {
		entryPointRef.current = document.getElementById(entryPointId);
	}, [entryPointId]);
	const onEscape = useCallback(() => {
		if (overlayRef.current && overlayRef.current.contains(document.activeElement)) handleClose(true);
	}, [handleClose]);
	const manager = useChatManager();
	const thread = getSelectedThread(state);
	const navigate = useNavigate$1();
	const navigateToImmersive = () => {
		sendEvent("dotcom_chat.activate", {
			target: "IMMERSIVE_OPTION",
			mode: "assistive"
		});
		copilotLocalStorage.setCurrentReferences(thread?.id ?? null, state.currentReferences);
		if (thread) navigate(`${COPILOT_PATH}/c/${thread.id}`);
		else if (currentTopic && isRepository(currentTopic)) navigate(`${COPILOT_PATH}/r/${currentTopic.ownerLogin}/${currentTopic.name}`);
		else navigate(COPILOT_PATH);
	};
	return /* @__PURE__ */ jsx(Fragment$1, { children: chatIsOpen ? /* @__PURE__ */ jsxs(Overlay, {
		id: copilotChatPanelID,
		className: clsx(ChatPanel_module_default.copilotChatPanel, chatIsOpen && ChatPanel_module_default.openChat),
		ref: overlayRef,
		onEscape,
		onClickOutside: () => {},
		ignoreClickRefs: [staffDialogRef],
		initialFocusRef,
		returnFocusRef: entryPointRef,
		style: {
			"--panel-width": `${panelWidth}px`,
			"--panel-height": `${panelHeight}px`,
			"--panel-min-height": `256px`,
			"--panel-min-width": `400px`
		},
		right: 8,
		bottom: 8,
		anchorSide: "inside-top",
		position: "fixed",
		role: "dialog",
		"aria-labelledby": copilotChatPanelInnerID,
		children: [/* @__PURE__ */ jsx(GlobalCommands, { commands: { "copilot-chat:close-assistive": () => manager.closeChat() } }), /* @__PURE__ */ jsx(ScopedCommands, {
			commands: { "copilot-chat:continue-in-immersive": navigateToImmersive },
			children: /* @__PURE__ */ jsx("section", {
				id: copilotChatPanelInnerID,
				"aria-label": "Copilot chat panel",
				style: { height: "100%" },
				children: /* @__PURE__ */ jsxs("div", {
					"data-testid": copilotChatPanelInnerID,
					className: ChatPanel_module_default.ChatPanelContainer,
					children: [
						/* @__PURE__ */ jsx("div", {
							id: "vertical-resize-click-target",
							onMouseDown: (e) => startResize(e, false, true),
							className: ChatPanel_module_default.verticalResizeTarget
						}),
						/* @__PURE__ */ jsx("div", {
							onMouseDown: (e_0) => startResize(e_0, true, false),
							className: ChatPanel_module_default.horizontalResizeTarget
						}),
						/* @__PURE__ */ jsx("div", {
							"aria-label": "Chat panel resizer",
							"aria-valuetext": `${panelWidth}, ${panelHeight}`,
							"aria-valuenow": panelWidth,
							role: "separator",
							onMouseDown: (e_1) => startResize(e_1, true, true),
							tabIndex: 0,
							onKeyDown: onResizerKeyDown,
							className: ChatPanel_module_default.cornerResizeTarget
						}),
						/* @__PURE__ */ jsx("div", {
							className: ChatPanel_module_default.panelContentContainer,
							children
						})
					]
				})
			})
		})]
	}) : null });
};
ChatPanel.displayName = "ChatPanel";
var Header_module_default = {
	actionButton: "Header-module_IJ-NBG_actionButton",
	assistiveBackButton: "Header-module_IJ-NBG_assistiveBackButton",
	betaLabel: "Header-module_IJ-NBG_betaLabel",
	buttonSeparator: "Header-module_IJ-NBG_buttonSeparator",
	defaultPadding: "Header-module_IJ-NBG_defaultPadding",
	headerActions: "Header-module_IJ-NBG_headerActions",
	HeaderContainer: "Header-module_IJ-NBG_HeaderContainer",
	HeaderTitle: "Header-module_IJ-NBG_HeaderTitle",
	headerTitleContainer: "Header-module_IJ-NBG_headerTitleContainer",
	immersivePadding: "Header-module_IJ-NBG_immersivePadding",
	withBorderBottom: "Header-module_IJ-NBG_withBorderBottom"
};
var Header = (props) => {
	const state = useChatState();
	const manager = useChatManager();
	const [showPersonalInstructionsDialog, setShowPersonalInstructionsDialog] = useState(false);
	const thread = getSelectedThread(state);
	const { showTopicPicker, messages, streamingMessage } = state;
	const threadName = thread?.name ?? state.restoredThreadTitle;
	const handleThreadDelete = useCallback(async () => {
		return thread && manager.deleteThread(thread);
	}, [thread, manager]);
	const lifecycleLabelNameEnabled = isFeatureEnabled("lifecycle_label_name_updates");
	const menuAnchorRef = useRef(null);
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(Header_module_default.HeaderContainer, state.mode === "immersive" ? Header_module_default.immersivePadding : Header_module_default.defaultPadding, !showTopicPicker && Header_module_default.withBorderBottom),
		children: [
			/* @__PURE__ */ jsx("div", {
				className: Header_module_default.headerTitleContainer,
				children: state.currentView === "thread" ? !showTopicPicker && !props.isImmersive && messages.length === 0 && state.chatIsOpen && /* @__PURE__ */ jsx(Heading$2, {
					as: "h2",
					className: Header_module_default.HeaderTitle,
					children: state.currentView === "thread" ? /* @__PURE__ */ jsx(Fragment$1, { children: threadName ? /* @__PURE__ */ jsx("span", {
						className: "Truncate",
						children: /* @__PURE__ */ jsx("span", {
							className: "Truncate-text",
							title: threadName,
							children: threadName
						})
					}) : props.isResponding && !state.chatIsOpen ? /* @__PURE__ */ jsx(Fragment$1, { children: "Responding…" }) : !state.chatIsOpen ? /* @__PURE__ */ jsx(Fragment$1, { children: "Ask Copilot" }) : !showTopicPicker && /* @__PURE__ */ jsx(Fragment$1, { children: "New conversation" }) }) : "Copilot"
				}) : /* @__PURE__ */ jsx(ReturnToCurrentThreadButton, {})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: Header_module_default.headerActions,
				children: [state.chatIsOpen && /* @__PURE__ */ jsxs(Fragment$1, { children: [state.renderBetaLabel && (lifecycleLabelNameEnabled ? /* @__PURE__ */ jsx(BetaLabel, { className: "mr-2" }) : /* @__PURE__ */ jsx(Label, {
					variant: "success",
					className: Header_module_default.betaLabel,
					children: "Beta"
				})), state.currentView === "thread" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
					hidden: messages.length === 0,
					variant: "invisible",
					icon: PlusIcon,
					"aria-label": "New conversation",
					tooltipDirection: "s",
					onClick: async () => {
						await manager.selectThread(null);
					},
					className: Header_module_default.actionButton
				}), /* @__PURE__ */ jsx(ThreadOptionButton, {
					anchorRef: menuAnchorRef,
					handleDelete: handleThreadDelete,
					thread,
					setShowStaffDialog: props.setShowStaffDialog,
					setShowPersonalInstructionsDialog
				})] }) : /* @__PURE__ */ jsx(IconButton, {
					variant: "invisible",
					icon: PlusIcon,
					"aria-label": "New conversation",
					tooltipDirection: "w",
					onClick: async () => {
						await manager.selectThread(null);
					},
					className: Header_module_default.actionButton
				})] }), !props.isImmersive && /* @__PURE__ */ jsxs(Fragment$1, { children: [
					state.chatIsOpen && /* @__PURE__ */ jsx("div", { className: Header_module_default.buttonSeparator }),
					/* @__PURE__ */ jsx(CommandIconButton, {
						commandId: "copilot-chat:continue-in-immersive",
						variant: "invisible",
						icon: ScreenFullIcon,
						"aria-label": "Continue in immersive",
						disabled: !!streamingMessage,
						tooltipDirection: "sw",
						className: Header_module_default.actionButton
					}),
					/* @__PURE__ */ jsx(CommandIconButton, {
						commandId: "copilot-chat:close-assistive",
						variant: "invisible",
						icon: XIcon,
						tooltipDirection: "sw",
						className: Header_module_default.actionButton
					})
				] })]
			}),
			/* @__PURE__ */ jsx(StaffDialogs, {
				dialogType: props.showStaffDialog,
				staffDialogRef: props.staffDialogRef,
				onDismiss: () => props.setShowStaffDialog(DialogType.None)
			}),
			showPersonalInstructionsDialog && /* @__PURE__ */ jsx(PersonalInstructionsDialog, {
				returnFocusRef: menuAnchorRef,
				onDismiss: () => setShowPersonalInstructionsDialog(false)
			})
		]
	});
};
Header.displayName = "Header";
var ReturnToCurrentThreadButton = () => {
	const $ = c(5);
	const { mode } = useChatState();
	const manager = useChatManager();
	let t0;
	if ($[0] !== manager) {
		t0 = () => manager.viewCurrentThread();
		$[0] = manager;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== mode || $[3] !== t0) {
		t1 = jsx(ButtonComponent, {
			leadingVisual: ArrowLeftIcon,
			variant: "invisible",
			onClick: t0,
			className: clsx(Header_module_default.actionButton, mode === "assistive" && Header_module_default.assistiveBackButton),
			children: "Back"
		});
		$[2] = mode;
		$[3] = t0;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
ReturnToCurrentThreadButton.displayName = "ReturnToCurrentThreadButton";
var ThreadOptionButton = (props) => {
	const [open, setOpen] = useState(false);
	const { mode, repoCustomInstructionsEnabled, currentReferences, optedInToUserFeedback } = useChatState();
	const manager = useChatManager();
	const feedbackRef = useRef(null);
	const showPromptDialog = copilotFeatureFlags.staffPromptDialog;
	const [customInstructionsExist, setCustomInstructionsExist] = useState(false);
	useEffect(() => {
		let cancelled = false;
		const fetchHasCustomInstructions = async () => {
			if (copilotFeatureFlags.customInstructionsFileReferences) {
				const fetchRepoForInstructions = async (repoID) => {
					const res = await manager.service.fetchRepo(repoID);
					if (res.ok) return makeRepositoryReference(res.payload);
					return null;
				};
				const has = await hasCustomInstructionsAsync(currentReferences, fetchRepoForInstructions);
				if (!cancelled) setCustomInstructionsExist(has);
			} else {
				const has_0 = hasCustomInstructions(currentReferences);
				if (!cancelled) setCustomInstructionsExist(has_0);
			}
		};
		fetchHasCustomInstructions();
		return () => {
			cancelled = true;
		};
	}, [currentReferences, manager.service]);
	const handleClickViewAll = useCallback(() => {
		manager.fetchThreads();
		manager.viewAllThreads();
		sendEvent("copilot.view-conversations-clicked");
	}, [manager]);
	const handleSelectDelete = () => {
		props.handleDelete();
		setOpen(false);
	};
	const userIsStaff = useMemo(() => {
		return isStaff();
	}, []);
	const deleteDisabled = !props.thread;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(ActionMenu, {
		open,
		onOpenChange: () => setOpen((prev) => !prev),
		anchorRef: props.anchorRef,
		children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
			icon: KebabHorizontalIcon,
			variant: "invisible",
			"aria-label": "Conversation options",
			tooltipDirection: "n",
			className: Header_module_default.actionButton
		}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, { children: [
			customInstructionsExist && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: () => {
					manager.toggleRepoCustomInstructions(!repoCustomInstructionsEnabled);
				},
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(NoteIcon, {}) }), repoCustomInstructionsEnabled ? "Disable custom instructions" : "Enable custom instructions"]
			}),
			/* @__PURE__ */ jsxs(ActionList.Item, {
				variant: deleteDisabled ? "default" : "danger",
				onSelect: handleSelectDelete,
				disabled: deleteDisabled,
				"aria-describedby": "delete-conversation-description",
				children: [
					/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(TrashIcon, {}) }),
					"Delete conversation",
					/* @__PURE__ */ jsx("p", {
						id: "delete-conversation-description",
						className: "sr-only",
						children: "This is a destructive action that cannot be undone"
					})
				]
			}),
			/* @__PURE__ */ jsx(ActionList.Divider, {}),
			/* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: () => props.setShowPersonalInstructionsDialog(true),
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(ToolsIcon, {}) }), "Personal instructions"]
			}),
			mode === "assistive" && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: handleClickViewAll,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(HistoryIcon, {}) }), "View all conversations"]
			}),
			optedInToUserFeedback && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: () => {
					feedbackRef.current?.openDialog();
					sendEvent("dotcom_chat.activate", {
						target: "META_CONTEXT_MENU_GIVE_FEEDBACK",
						mode: "assistive"
					});
				},
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CommentDiscussionIcon, {}) }), "Give feedback"]
			}),
			userIsStaff && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: () => props.setShowStaffDialog(DialogType.Experiments),
				children: [
					/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(BeakerIcon, {}) }),
					"Configure experiments",
					/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(Label, {
						variant: "attention",
						children: "Staff"
					}) })
				]
			}),
			userIsStaff && showPromptDialog && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: () => props.setShowStaffDialog(DialogType.Prompt),
				children: [
					/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(BeakerIcon, {}) }),
					"Adjust prompts",
					/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(Label, {
						variant: "attention",
						children: "Staff"
					}) })
				]
			})
		] }) })]
	}), /* @__PURE__ */ jsx(ConversationFeedbackDialog, {
		ref: feedbackRef,
		mode: "assistive"
	})] });
};
ThreadOptionButton.displayName = "ThreadOptionButton";
var CopilotChat_module_default = {
	chatContentScrollContainer: "CopilotChat-module_aKuD4G_chatContentScrollContainer",
	chatViewContainer: "CopilotChat-module_aKuD4G_chatViewContainer",
	CopilotChatContainer: "CopilotChat-module_aKuD4G_CopilotChatContainer",
	IconButton: "CopilotChat-module_aKuD4G_IconButton",
	Popover: "CopilotChat-module_aKuD4G_Popover",
	Popover_Content: "CopilotChat-module_aKuD4G_Popover_Content"
};
function useSavePageTitle() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = [];
		$[0] = t0;
	} else t0 = $[0];
	useEffect(_temp2, t0);
}
function _temp2() {
	const handleBeforeUnload = _temp$1;
	window.addEventListener("beforeunload", handleBeforeUnload);
	return () => {
		window.removeEventListener("beforeunload", handleBeforeUnload);
	};
}
function _temp$1() {
	setPreviousPageInfo(document.title);
}
function CopilotChat(props) {
	const copilotButtonRef = useRef(null);
	const inputRef = useRef(null);
	const selectedThreadID = copilotLocalStorage.selectedThreadID;
	const currentReferences = copilotLocalStorage.getCurrentReferences(selectedThreadID) || [];
	return /* @__PURE__ */ jsx(ScreenSizeProvider, { children: /* @__PURE__ */ jsxs(CopilotChatProvider, {
		topic: props.currentTopic,
		workerPath: props.findFileWorkerPath,
		threadId: selectedThreadID,
		refs: currentReferences,
		mode: "assistive",
		ssoOrganizations: props.ssoOrganizations,
		chatIsOpen: false,
		chatIsVisible: props.chatIsVisible,
		chatVisibleSettingPath: props.chatVisibleSettingPath,
		realIp: props.realIp,
		copilotChatPayload: props,
		children: [
			/* @__PURE__ */ jsx(CopilotHeaderButton, {
				renderPopover: props.renderPopover || false,
				ref: copilotButtonRef,
				reactPartialAnchor: props.reactPartialAnchor,
				inputRef
			}),
			/* @__PURE__ */ jsx(ChatPortalContainer, {}),
			/* @__PURE__ */ jsx(ChatPanelWithHeader, { inputRef })
		]
	}) });
}
CopilotChat.displayName = "CopilotChat";
var dismissNoticePath = ({ notice }) => `/settings/dismiss-notice/${notice}`;
var CopilotHeaderButton = ({ ref, ...props }) => {
	const manager = useChatManager();
	const state = useChatState();
	const selectedThread = getSelectedThread(state);
	const { currentTopic, currentView } = state;
	const { screenSize } = useScreenSize();
	const { licenseType } = useEntitlement();
	const defaultModel = useDefaultModel(state.availableModels);
	const initialRenderRef = useRef(true);
	useSavePageTitle();
	useEffect(() => {
		return subscribeOpenCopilotChat((e) => void manager.handleOpenPanelEvent(selectedThread, e, state.chatIsOpen, currentTopic, defaultModel));
	}, [
		currentTopic,
		selectedThread,
		manager,
		state.chatIsOpen,
		defaultModel
	]);
	useEffect(() => {
		return subscribeAddCopilotChatReference((e_0) => {
			manager.handleAddReferenceEvent(e_0);
		});
	}, [
		selectedThread,
		manager,
		state.currentReferences
	]);
	useEffect(() => {
		return subscribeSymbolChanged((e_1) => {
			manager.handleSymbolChangedEvent(e_1);
		});
	});
	useEffect(() => {
		return subscribeSearchCopilot((e_2) => {
			manager.handleSearchCopilotEvent(e_2, defaultModel);
		});
	}, [manager, defaultModel]);
	useEffect(() => {
		const url = new URL(window.location.href, window.location.origin);
		const params = url.searchParams;
		const threadId = state.selectedThreadID;
		if (params.get("copilot") === "1" && threadId) {
			const thread = state.threads.get(threadId) ?? null;
			manager.openChat(thread, currentView, "immersive", state.chatVisibleSettingPath);
			url.searchParams.delete("copilot");
			addUrlToHistoryStack(url.toString());
		}
	}, [
		manager,
		state.selectedThreadID,
		state.threads,
		currentView,
		state.chatVisibleSettingPath
	]);
	useEffect(() => {
		if (initialRenderRef.current) {
			initialRenderRef.current = false;
			if (state.chatIsVisible && !copilotLocalStorage.getCollapsedState() && screenSize > ScreenSize.large) manager.openChat(selectedThread, state.currentView, "page load", state.chatVisibleSettingPath);
		}
	}, [
		manager,
		screenSize,
		selectedThread,
		state.chatIsVisible,
		state.chatVisibleSettingPath,
		state.currentView
	]);
	const openChat = useCallback(async () => {
		if (!state.chatIsOpen) {
			if (licenseType === CopilotLicenseType.Unlicensed) {
				if (state.chatVisibleSettingPath) {
					const data = new FormData();
					data.set("copilot_chat_visible", "true");
					await verifiedFetch(state.chatVisibleSettingPath, {
						method: "PUT",
						body: data
					});
					copilotLocalStorage.setCollapsedState(false);
				}
				window.location.replace(`${window.location.origin}/github-copilot/signup?return_to=${window.location.pathname}`);
				return;
			}
			manager.openChat(selectedThread, currentView, "header", state.chatVisibleSettingPath, isRepository(currentTopic) ? makeRepositoryReference(currentTopic) : void 0);
		} else if (props.inputRef.current) props.inputRef.current.focus();
	}, [
		currentTopic,
		currentView,
		licenseType,
		manager,
		props.inputRef,
		selectedThread,
		state.chatIsOpen,
		state.chatVisibleSettingPath
	]);
	if (props.reactPartialAnchor) return /* @__PURE__ */ jsxs("div", {
		className: CopilotChat_module_default.CopilotChatContainer,
		children: [/* @__PURE__ */ jsx(ExternalAnchorListener, { reactPartialAnchor: props.reactPartialAnchor }), props.renderPopover ? /* @__PURE__ */ jsx(WelcomePopover, { renderPopover: true }) : /* @__PURE__ */ jsx(Fragment$1, {})]
	});
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("AppHeader-CopilotChatButton", CopilotChat_module_default.CopilotChatContainer),
		children: [/* @__PURE__ */ jsx(Tooltip, {
			"aria-label": "Chat with Copilot",
			direction: "s",
			children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(IconButton, {
				unsafeDisableTooltip: true,
				ref,
				id: copilotChatHeaderButtonID,
				icon: CopilotIcon,
				"aria-label": "Chat with Copilot",
				"aria-controls": copilotChatPanelID,
				onClick: openChat,
				className: clsx("AppHeader-button", CopilotChat_module_default.IconButton),
				"data-testid": "copilot-chat-button",
				"data-hotkey": "Shift+C",
				"aria-expanded": false
			}) })
		}), /* @__PURE__ */ jsx(WelcomePopover, { renderPopover: props.renderPopover })]
	});
};
function ExternalAnchorListener(t0) {
	const $ = c(1);
	const { reactPartialAnchor } = t0;
	useOnAnchorClick(reactPartialAnchor, _temp);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = jsx(Fragment$1, {});
		$[0] = t1;
	} else t1 = $[0];
	return t1;
}
ExternalAnchorListener.displayName = "ExternalAnchorListener";
function _temp() {
	sendEvent("dotcom_chat.activate", {
		target: "GLOBAL_COPILOT_MENU_HEADER_TO_IMMERSIVE",
		mode: "global_nav",
		defaultToAgent: copilotFeatureFlags.defaultToAgentInput,
		defaultToAgentControl: copilotFeatureFlags.defaultToAgentControl
	});
}
function WelcomePopover(t0) {
	const $ = c(3);
	const { renderPopover } = t0;
	const [showPopover, setShowPopover] = useState(renderPopover);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = async () => {
			setShowPopover(false);
			await verifiedFetch(dismissNoticePath({ notice: "copilot_chat_new_user_popover" }), { method: "POST" });
		};
		$[0] = t1;
	} else t1 = $[0];
	const handleClosePopover = t1;
	let t2;
	if ($[1] !== showPopover) {
		t2 = jsx(Popover_default, {
			open: showPopover,
			caret: "top-right",
			className: CopilotChat_module_default.Popover,
			children: jsxs(Popover_default.Content, {
				"data-testid": "copilot-chat-cta-popover",
				className: CopilotChat_module_default.Popover_Content,
				children: [jsxs("p", { children: [
					"You now have access to",
					" ",
					jsx("a", {
						href: "https://docs.github.com/enterprise-cloud@latest/copilot/github-copilot-enterprise/overview/about-github-copilot-enterprise",
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Copilot Enterprise"
					}),
					". ",
					"Use the Copilot icon to get started."
				] }), jsx(ButtonComponent, {
					"data-testid": "dismiss-copilot-chat-cta-popover",
					onClick: handleClosePopover,
					children: "Got it!"
				})]
			})
		});
		$[1] = showPopover;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
WelcomePopover.displayName = "WelcomePopover";
CopilotHeaderButton.displayName = "CopilotHeaderButton";
function ChatPanelWithHeader({ inputRef }) {
	const state = useChatState();
	const manager = useChatManager();
	const staffDialogRef = useRef(null);
	const [showStaffDialog, setShowStaffDialog] = useState(DialogType.None);
	const [hasUnreadMessages, setHasUnreadMessages] = useState(false);
	const prevMessageCount = useRef(state.messages.length);
	const prevMessageLoadingState = useRef(state.messagesLoading.state);
	const { panelWidth, panelHeight, startResize, onResizerKeyDown } = useResizablePanel();
	useEffect(() => {
		if (state.messages.length > prevMessageCount.current && !state.chatIsOpen && prevMessageLoadingState.current === "loaded") setHasUnreadMessages(true);
		prevMessageCount.current = state.messages.length;
		prevMessageLoadingState.current = state.messagesLoading.state;
	}, [
		state.chatIsOpen,
		state.messages.length,
		state.messagesLoading.state
	]);
	useEffect(() => {
		if (state.chatIsOpen && hasUnreadMessages) setHasUnreadMessages(false);
	}, [hasUnreadMessages, state.chatIsOpen]);
	return /* @__PURE__ */ jsxs(ChatPanel, {
		staffDialogRef,
		handleClose: (usedEscapeKey) => {
			setShowStaffDialog(DialogType.None);
			manager.closeChat();
			const entryId = state.entryPointId ?? "copilot-chat-header-button";
			if (usedEscapeKey && entryId) {
				const entryElement = document.getElementById(entryId);
				const scrollX = window.scrollX;
				const scrollY = window.scrollY;
				setTimeout(() => {
					entryElement?.focus();
					window.scrollTo(scrollX, scrollY);
				}, 0);
			}
		},
		panelWidth,
		panelHeight,
		startResize,
		onResizerKeyDown,
		initialFocusRef: inputRef,
		children: [/* @__PURE__ */ jsx(Header, {
			staffDialogRef,
			showStaffDialog,
			setShowStaffDialog,
			isResponding: state.messages.length <= 1 && (!!state.streamingMessage || state.isWaitingOnCopilot)
		}), state.chatIsOpen && /* @__PURE__ */ jsx("div", {
			className: CopilotChat_module_default.chatContentScrollContainer,
			children: /* @__PURE__ */ jsxs("div", {
				className: CopilotChat_module_default.chatViewContainer,
				children: [/* @__PURE__ */ jsx(MenuPortalContainer, { className: EMBEDDED_MENU_PORTAL_CLASS }), state.currentView === "thread" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Chat, { inputRef }, state.selectedThreadID), /* @__PURE__ */ jsx(CopilotReferencePreviewDialog, {})] }) : /* @__PURE__ */ jsx(ThreadListView, {})]
			})
		})]
	});
}
ChatPanelWithHeader.displayName = "ChatPanelWithHeader";
export { CopilotChat };
