performance.mark("js-parse-end:server-layout-BeF00bA9-B9RJu31S.js");
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { T as CalendarIcon, _i as Truncate, an as IconButton, ar as PlusIcon, bn as Link, hi as TriangleDownIcon, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { g as useLocation$1, n as Outlet$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as PageLayout } from "./server-PageLayout-CYFdz829-BD84oh7w.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as ReposSelector } from "./server-ReposSelector-DzGKvaFx-Dm7ShIoG.js";
import { i as grinIcon, n as frownIcon, o as smileIcon, r as frustratedIcon, t as UserFeedback } from "./server-UserFeedback-kIRVi6Wu-D1dZx8ou.js";
import { t as NavList } from "./server-NavList-D8uWdChJ-BgWGw1cA.js";
import { t as ContextualGlobalSsoBanner } from "./server-ContextualGlobalSsoBanner-BxYXWjwo-Dq9T9smw.js";
import { t as AnalyticsProvider } from "./server-AnalyticsProvider-D0POAVQk-B5tW16h5.js";
import { t as PreviewCardOutlet } from "./server-PreviewCard-DmDRpyYj-LruPyakF.js";
import { r as pullsDashboardSurfaceContentRoute } from "./server-pulls-dashboard-surface-content-route-CY12u0dp-B-R1iWh6.js";
import { t as pullsDashboardSurfaceLayoutRoute } from "./server-pulls-dashboard-surface-layout-route-BUkOm7Nm-BgXjnlHv.js";
import { L as ShortcutEditingHeader, R as ShortcutOptionsButton, X as getIconComponent, Y as getIconColorClassName } from "./server-providers-w0hxsmcG-B_8wxADa.js";
import { c as dashboardTypeLabels, d as usePullsDashboardSurfaceStateContext, l as isOnInboxPath, n as PullsDashboardSurfaceStateProvider, r as PullsInboxMaxAge, t as PULLS_INBOX_MAX_AGE_LABELS, u as usePullsDashboardSurfaceLayoutState } from "./server-dashboard-types-BuwdHcA--CDy_6se1.js";
import { t as Filter } from "./server-Filter-DGmvUrMW-BT0gplWp.js";
import { useCallback, useId, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:layout-BeF00bA9.js");
function getHandlerNavItemClick({ dashboardType, linkItem, sendAnalyticsEvent }) {
	const tags = linkItem.source === "predefined" ? { id: linkItem.id } : { shortcut: true };
	return () => {
		sendAnalyticsEvent(`${dashboardType}.click`, "SIDEBAR_LINK", tags);
	};
}
var SidebarList_module_default = {
	dialog: "SidebarList-module_JxRGGG_dialog",
	sidebarHeading: "SidebarList-module_JxRGGG_sidebarHeading",
	sidebarToggleButton: "SidebarList-module_JxRGGG_sidebarToggleButton"
};
var SidebarLinkIcon_module_default = { icon: "SidebarLinkIcon-module_S1UM-a_icon" };
function SidebarLinkIcon({ name, color }) {
	const IconComponent = getIconComponent(name);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(SidebarLinkIcon_module_default.icon, getIconColorClassName(color)),
		children: /* @__PURE__ */ jsx(IconComponent, {})
	});
}
SidebarLinkIcon.displayName = "SidebarLinkIcon";
function SidebarList(t0) {
	const $ = c(13);
	const { dashboardType, links, selectedLink, onSelectLink, generateLinkPath } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	if ($[0] !== dashboardType || $[1] !== generateLinkPath || $[2] !== links || $[3] !== onSelectLink || $[4] !== selectedLink || $[5] !== sendAnalyticsEvent) {
		let t2;
		if ($[7] !== dashboardType || $[8] !== generateLinkPath || $[9] !== onSelectLink || $[10] !== selectedLink || $[11] !== sendAnalyticsEvent) {
			t2 = (linkItem) => jsxs(NavList.Item, {
				as: Link$1,
				"aria-current": selectedLink === linkItem.id && "page",
				to: generateLinkPath(linkItem.path),
				onClick: getHandlerNavItemClick({
					dashboardType,
					onSelectLink,
					sendAnalyticsEvent,
					linkItem
				}),
				children: [jsx(NavList.LeadingVisual, { children: jsx(SidebarLinkIcon, {
					name: linkItem.icon,
					color: linkItem.color
				}) }), jsx(Truncate, {
					title: linkItem.name,
					maxWidth: "100%",
					children: linkItem.name
				})]
			}, linkItem.id);
			$[7] = dashboardType;
			$[8] = generateLinkPath;
			$[9] = onSelectLink;
			$[10] = selectedLink;
			$[11] = sendAnalyticsEvent;
			$[12] = t2;
		} else t2 = $[12];
		t1 = jsx(NavList, { children: links.map(t2) });
		$[0] = dashboardType;
		$[1] = generateLinkPath;
		$[2] = links;
		$[3] = onSelectLink;
		$[4] = selectedLink;
		$[5] = sendAnalyticsEvent;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
SidebarList.displayName = "SidebarList";
function SidebarListCollapsed({ onSelectLink, onCreateView, showCreateSavedViews = false, generateLinkPath, ...props }) {
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const buttonRef = useRef(null);
	const listName = props.links.find((link) => link.id === props.selectedLink)?.name || "Search";
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(ButtonComponent, {
			ref: buttonRef,
			variant: "invisible",
			onClick: () => setIsDialogOpen(true),
			trailingVisual: TriangleDownIcon,
			"aria-describedby": "types-collapsed-button-description",
			className: SidebarList_module_default.sidebarToggleButton,
			children: /* @__PURE__ */ jsx("h1", {
				className: SidebarList_module_default.sidebarHeading,
				children: /* @__PURE__ */ jsx(Truncate, {
					title: listName,
					maxWidth: "100%",
					children: listName
				})
			})
		}),
		/* @__PURE__ */ jsxs("span", {
			className: "sr-only",
			id: "types-collapsed-button-description",
			"aria-live": "polite",
			children: [
				"Change the ",
				dashboardTypeLabels[props.dashboardType],
				" type filter"
			]
		}),
		isDialogOpen && /* @__PURE__ */ jsx(Dialog, {
			className: SidebarList_module_default.dialog,
			onClose: () => setIsDialogOpen(false),
			title: "Views",
			width: "small",
			returnFocusRef: buttonRef,
			footerButtons: showCreateSavedViews && onCreateView ? [{
				buttonType: "default",
				content: "Close",
				onClick: () => setIsDialogOpen(false)
			}, {
				buttonType: "primary",
				content: "New view",
				onClick: onCreateView
			}] : [],
			children: /* @__PURE__ */ jsx(SidebarList, {
				onSelectLink: (linkItem) => {
					onSelectLink(linkItem);
					setIsDialogOpen(false);
				},
				generateLinkPath,
				...props
			})
		})
	] });
}
SidebarListCollapsed.displayName = "SidebarListCollapsed";
var SidebarSavedViews_module_default = {
	headerRow: "SidebarSavedViews-module_TqmhuG_headerRow",
	headerRowText: "SidebarSavedViews-module_TqmhuG_headerRowText",
	hiddenButton: "SidebarSavedViews-module_TqmhuG_hiddenButton",
	icon: "SidebarSavedViews-module_TqmhuG_icon",
	savedViewsList: "SidebarSavedViews-module_TqmhuG_savedViewsList"
};
function SidebarSavedViews(t0) {
	const $ = c(15);
	const { dashboardType, savedViews, selectedLink, onSelectLink, onCreateView, generateLinkPath } = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	const createViewButtonId = useId();
	let t1;
	if ($[0] !== createViewButtonId || $[1] !== dashboardType || $[2] !== generateLinkPath || $[3] !== onCreateView || $[4] !== onSelectLink || $[5] !== savedViews || $[6] !== selectedLink || $[7] !== sendAnalyticsEvent) {
		let t2;
		if ($[9] !== dashboardType || $[10] !== generateLinkPath || $[11] !== onSelectLink || $[12] !== selectedLink || $[13] !== sendAnalyticsEvent) {
			t2 = (linkItem) => jsxs(NavList.Item, {
				as: Link$1,
				"aria-current": selectedLink === linkItem.id && "page",
				to: generateLinkPath(linkItem.id, linkItem.query),
				onClick: getHandlerNavItemClick({
					dashboardType,
					onSelectLink,
					sendAnalyticsEvent,
					linkItem
				}),
				children: [jsx(NavList.LeadingVisual, { children: jsx(SidebarLinkIcon, {
					name: linkItem.icon,
					color: linkItem.color
				}) }), jsx(Truncate, {
					title: linkItem.name,
					maxWidth: "100%",
					children: linkItem.name
				})]
			}, linkItem.id);
			$[9] = dashboardType;
			$[10] = generateLinkPath;
			$[11] = onSelectLink;
			$[12] = selectedLink;
			$[13] = sendAnalyticsEvent;
			$[14] = t2;
		} else t2 = $[14];
		t1 = jsxs("div", { children: [jsxs("div", {
			className: SidebarSavedViews_module_default.headerRow,
			id: createViewButtonId,
			children: [jsx("span", {
				className: SidebarSavedViews_module_default.headerRowText,
				children: "Views"
			}), jsx(IconButton, {
				icon: PlusIcon,
				size: "small",
				variant: "invisible",
				onClick: onCreateView,
				"aria-label": "Create view",
				className: selectedLink === "inbox" ? SidebarSavedViews_module_default.hiddenButton : void 0
			})]
		}), jsx(NavList, {
			"aria-labelledby": createViewButtonId,
			className: SidebarSavedViews_module_default.savedViewsList,
			children: savedViews.map(t2)
		})] });
		$[0] = createViewButtonId;
		$[1] = dashboardType;
		$[2] = generateLinkPath;
		$[3] = onCreateView;
		$[4] = onSelectLink;
		$[5] = savedViews;
		$[6] = selectedLink;
		$[7] = sendAnalyticsEvent;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
SidebarSavedViews.displayName = "SidebarSavedViews";
function DashboardSidebar({ dashboardType, links, selectedLink, onSelectLink, savedViews, showSavedViews = false, onCreateView, generateLinkPath }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SidebarList, {
		dashboardType,
		links,
		selectedLink,
		onSelectLink,
		generateLinkPath
	}), showSavedViews && onCreateView && /* @__PURE__ */ jsx(SidebarSavedViews, {
		dashboardType,
		savedViews,
		selectedLink,
		onSelectLink,
		onCreateView,
		generateLinkPath
	})] });
}
DashboardSidebar.displayName = "DashboardSidebar";
var ratingOptions = [
	{
		name: "Hate it",
		value: "VERY_NEGATIVE",
		icon: frustratedIcon,
		color: "veryDissatisfied"
	},
	{
		name: "Not great",
		value: "NEGATIVE",
		icon: frownIcon,
		color: "dissatisfied"
	},
	{
		name: "It’s ok",
		value: "POSITIVE",
		icon: smileIcon,
		color: "satisfied"
	},
	{
		name: "Love it",
		value: "VERY_POSITIVE",
		icon: grinIcon,
		color: "verySatisfied"
	}
];
function DashboardFeedbackDialog({ title, subject, placeholderText, buttonText, returnFocusRef }) {
	const feedbackDialogRef = useRef(null);
	const onSubmit = async (rating, text) => {
		const errors = [];
		if (rating == null) errors.push("Please select a rating.");
		const limit = 2e3;
		if (text.length > limit) errors.push(`Please keep your feedback within ${limit} characters or less.`);
		if (errors.length > 0) return errors;
		const body = {
			subject,
			rating,
			content: text,
			hostname: window.location.hostname,
			path: window.location.pathname
		};
		try {
			if (!(await verifiedFetchJSON("/dashboard/feedback", {
				method: "POST",
				body
			})).ok) errors.push("An error occurred while submitting your feedback.");
		} catch {
			errors.push("An error occurred while submitting your feedback.");
		}
		return errors;
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Link, {
		as: "button",
		onClick: () => feedbackDialogRef.current?.openDialog(),
		children: buttonText ?? "Give feedback"
	}), /* @__PURE__ */ jsx(UserFeedback, {
		ref: feedbackDialogRef,
		title,
		options: ratingOptions,
		placeholderText,
		onSubmit,
		returnFocusRef
	})] });
}
DashboardFeedbackDialog.displayName = "DashboardFeedbackDialog";
function DashboardSidebarCollapsed({ dashboardType, links, selectedLink, onSelectLink, showSavedViews = false, savedViews, onCreateView, generateLinkPath }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(SidebarListCollapsed, {
		dashboardType,
		links: showSavedViews ? [...links, ...savedViews] : links,
		selectedLink,
		onSelectLink,
		showCreateSavedViews: showSavedViews,
		onCreateView,
		generateLinkPath
	}) });
}
DashboardSidebarCollapsed.displayName = "DashboardSidebarCollapsed";
var SharedHeader_module_default = { description: "SharedHeader-module_TNy0ba_description" };
function SharedHeader({ dashboardType, links, selectedLink, onSelectLink, showFeedbackDialog = false, feedbackSubject = "dashboard-surface-feedback", feedbackPlaceholderText, filter, rightSideContent, savedViews, showSavedViews = false, onCreateView, onEditView, onDeleteView, onUpdateView, isViewModified = false, deleteErrorMessage, newButton, generateLinkPath }) {
	const { name = "Authored by me", description } = selectedLink || {};
	return /* @__PURE__ */ jsxs("div", { children: [
		deleteErrorMessage && /* @__PURE__ */ jsx(Flash, {
			variant: "danger",
			className: "pr-mb-3",
			children: deleteErrorMessage
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "d-flex tmp-mb-3 gap-2",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex-1 min-width-0",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "d-flex flex-items-top gap-2",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "hide-lg hide-xl",
							children: /* @__PURE__ */ jsx(DashboardSidebarCollapsed, {
								dashboardType,
								links,
								selectedLink: selectedLink?.id || "",
								onSelectLink,
								showSavedViews,
								savedViews,
								onCreateView,
								generateLinkPath
							})
						}),
						/* @__PURE__ */ jsx("h1", {
							className: "h3 hide-sm hide-md min-width-0 mb-1",
							"data-testid": "header-title",
							children: /* @__PURE__ */ jsx(Truncate, {
								title: name,
								maxWidth: "100%",
								children: name
							})
						}),
						showSavedViews && selectedLink?.source === "user" && onEditView && onDeleteView && onUpdateView && /* @__PURE__ */ jsx(ShortcutOptionsButton, {
							onEditView: () => onEditView(selectedLink),
							onDeleteView: () => onDeleteView(selectedLink),
							onUpdateQueryView: () => onUpdateView(selectedLink),
							isQueryModified: isViewModified
						})
					]
				}), description && /* @__PURE__ */ jsx(Truncate, {
					className: SharedHeader_module_default.description,
					title: description,
					maxWidth: "100%",
					children: description
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "d-flex flex-items-center gap-2",
				children: [
					rightSideContent,
					/* @__PURE__ */ jsx(Label, {
						variant: "success",
						children: "Preview"
					}),
					showFeedbackDialog && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", { children: "·" }), /* @__PURE__ */ jsx(DashboardFeedbackDialog, {
						subject: feedbackSubject,
						placeholderText: feedbackPlaceholderText
					})] }),
					newButton && /* @__PURE__ */ jsx(ButtonComponent, {
						as: "a",
						href: newButton.newPath,
						variant: "primary",
						size: "medium",
						children: newButton.label
					})
				]
			})]
		}),
		filter
	] });
}
SharedHeader.displayName = "SharedHeader";
function SharedLayout({ sidebar, header }) {
	return /* @__PURE__ */ jsxs(PageLayout, {
		containerWidth: "full",
		columnGap: "none",
		padding: "none",
		children: [/* @__PURE__ */ jsx(PageLayout.Pane, {
			divider: "line",
			hidden: {
				narrow: true,
				regular: false,
				wide: false
			},
			padding: "condensed",
			position: "start",
			className: "min-height-full",
			children: /* @__PURE__ */ jsx("aside", { children: sidebar })
		}), /* @__PURE__ */ jsxs(PageLayout.Content, {
			as: "div",
			padding: "condensed",
			className: "min-height-full px-2 mx-auto",
			style: { maxWidth: "1400px" },
			children: [header, /* @__PURE__ */ jsx(Outlet$1, {})]
		})]
	});
}
SharedLayout.displayName = "SharedLayout";
var DASHBOARD_PREFERENCES_PATH = "/dashboard/preferences";
async function saveInboxMaxPrAge(maxPrAge) {
	const formData = new FormData();
	formData.set("pulls_inbox_max_pr_age", maxPrAge);
	const response = await verifiedFetch(DASHBOARD_PREFERENCES_PATH, {
		method: "PUT",
		body: formData
	});
	if (!response.ok) throw new Error(`Failed to save preference: ${response.statusText}`);
}
var AGE_OPTIONS = [
	PullsInboxMaxAge.OneMonth,
	PullsInboxMaxAge.ThreeMonths,
	PullsInboxMaxAge.OneYear,
	PullsInboxMaxAge.None
];
function InboxPrAgeFilter({ selectedMaxPrAge, onMaxPrAgeChange }) {
	const [isSaving, setIsSaving] = useState(false);
	const handleSelect = useCallback(async (maxPrAge) => {
		if (maxPrAge === selectedMaxPrAge) return;
		onMaxPrAgeChange(maxPrAge);
		setIsSaving(true);
		try {
			await saveInboxMaxPrAge(maxPrAge);
		} catch {
			onMaxPrAgeChange(selectedMaxPrAge);
		} finally {
			setIsSaving(false);
		}
	}, [selectedMaxPrAge, onMaxPrAgeChange]);
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Button, {
		leadingVisual: CalendarIcon,
		disabled: isSaving,
		"aria-label": `Filter by age: ${PULLS_INBOX_MAX_AGE_LABELS[selectedMaxPrAge]}`,
		children: `Updated: ${PULLS_INBOX_MAX_AGE_LABELS[selectedMaxPrAge]}`
	}), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		width: "auto",
		children: /* @__PURE__ */ jsx(ActionList, {
			selectionVariant: "single",
			children: AGE_OPTIONS.map((option) => /* @__PURE__ */ jsx(ActionList.Item, {
				selected: option === selectedMaxPrAge,
				onSelect: () => handleSelect(option),
				children: PULLS_INBOX_MAX_AGE_LABELS[option]
			}, option))
		})
	})] });
}
InboxPrAgeFilter.displayName = "InboxPrAgeFilter";
function PullsDashboardSurfaceLayoutComponent() {
	const $ = c(3);
	const { data: payload, isPending: isLoading } = useRouteQuery(pullsDashboardSurfaceLayoutRoute, "mainQuery");
	let t0;
	if ($[0] !== isLoading || $[1] !== payload) {
		t0 = jsx(PullsDashboardSurfaceLayoutRoot, {
			payload,
			isLoading
		});
		$[0] = isLoading;
		$[1] = payload;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
PullsDashboardSurfaceLayoutComponent.displayName = "PullsDashboardSurfaceLayoutComponent";
function PullsDashboardSurfaceLayoutRoot({ payload, isLoading }) {
	return /* @__PURE__ */ jsxs(AnalyticsProvider, {
		appName: "pulls-dashboard-surface",
		category: "Dashboard Surface",
		metadata: { page: "pulls-dashboard" },
		children: [/* @__PURE__ */ jsx(ContextualGlobalSsoBanner, {}), /* @__PURE__ */ jsxs("div", {
			"data-testid": "pulls-dashboard-surface-layout",
			"data-issue-and-pr-hovercards-enabled": true,
			children: [payload && /* @__PURE__ */ jsx(PullsDashboardSurfaceStateProvider, {
				payload,
				isLoading,
				children: /* @__PURE__ */ jsx(PullsDashboardSurfaceLayout, {})
			}), /* @__PURE__ */ jsx(PreviewCardOutlet, {})]
		})]
	});
}
PullsDashboardSurfaceLayoutRoot.displayName = "PullsDashboardSurfaceLayoutRoot";
function PullsDashboardSurfaceLayout() {
	const $ = c(23);
	const { sidebarLinks, savedViews, selectedSidebarLink, editing, deleting, methods, pullsFilterProps, inboxPickerProps } = usePullsDashboardSurfaceLayoutState();
	const { fetchedQuery, isLoading, maxPrAge } = usePullsDashboardSurfaceStateContext();
	const { pathname } = useLocation$1();
	let t0;
	if ($[0] !== pathname) {
		t0 = isOnInboxPath({ pathname });
		$[0] = pathname;
		$[1] = t0;
	} else t0 = $[1];
	const isOnInbox = t0;
	const visibleLinks = sidebarLinks;
	const generateLinkPath = _temp;
	let t1;
	if ($[2] !== deleting || $[3] !== editing.dismiss || $[4] !== editing.errorMessage || $[5] !== editing.isSaving || $[6] !== editing.saveAndDismiss || $[7] !== editing.setValue || $[8] !== editing.shortcut || $[9] !== fetchedQuery || $[10] !== inboxPickerProps || $[11] !== isLoading || $[12] !== isOnInbox || $[13] !== maxPrAge || $[14] !== methods.createShortcut || $[15] !== methods.editShortcut || $[16] !== methods.selectSidebarLink || $[17] !== methods.updateShortcut || $[18] !== pullsFilterProps || $[19] !== savedViews || $[20] !== selectedSidebarLink || $[21] !== visibleLinks) {
		t1 = jsx(SharedLayout, {
			header: editing.shortcut ? jsx(ShortcutEditingHeader, {
				renderFilter: (filterProps) => jsx(Filter, {
					...filterProps,
					...pullsFilterProps,
					"data-testid": "pulls-filter-component"
				}),
				onSave: editing.saveAndDismiss,
				onDismiss: editing.dismiss,
				shortcut: editing.shortcut,
				setShortcutValue: editing.setValue,
				isSaving: editing.isSaving,
				errorMessage: editing.errorMessage
			}) : jsx(SharedHeader, {
				dashboardType: "pull-requests",
				links: visibleLinks,
				selectedLink: selectedSidebarLink,
				onSelectLink: methods.selectSidebarLink,
				showFeedbackDialog: true,
				feedbackSubject: isOnInbox ? "pulls_inbox_feedback" : "pulls_dashboard_feedback",
				feedbackPlaceholderText: "Tell us your feedback on the new pull request experience",
				rightSideContent: isOnInbox && inboxPickerProps ? jsxs("div", {
					className: "d-flex flex-wrap gap-2",
					"data-testid": "pulls-inbox-picker-filter",
					children: [jsx(ReposSelector, {
						selectionVariant: "multiple",
						selectAllOption: false,
						currentSelection: inboxPickerProps.repoSelection,
						repositoryLoader: inboxPickerProps.repoLoader,
						onSelect: inboxPickerProps.selectRepos
					}), jsx(InboxPrAgeFilter, {
						selectedMaxPrAge: maxPrAge,
						onMaxPrAgeChange: inboxPickerProps.handleMaxPrAgeChange
					})]
				}) : void 0,
				filter: !isOnInbox ? jsx(Filter, {
					...pullsFilterProps,
					"data-testid": "pulls-filter-component"
				}) : void 0,
				savedViews,
				showSavedViews: true,
				onCreateView: methods.createShortcut,
				onEditView: methods.editShortcut,
				onDeleteView: deleting.deleteShortcut,
				onUpdateView: methods.updateShortcut,
				isViewModified: !isLoading && fetchedQuery !== selectedSidebarLink?.query,
				deleteErrorMessage: deleting.errorMessage,
				generateLinkPath
			}),
			sidebar: jsx(DashboardSidebar, {
				dashboardType: "pull-requests",
				links: visibleLinks,
				selectedLink: selectedSidebarLink?.id || "",
				onSelectLink: methods.selectSidebarLink,
				savedViews,
				showSavedViews: true,
				onCreateView: methods.createShortcut,
				generateLinkPath
			})
		});
		$[2] = deleting;
		$[3] = editing.dismiss;
		$[4] = editing.errorMessage;
		$[5] = editing.isSaving;
		$[6] = editing.saveAndDismiss;
		$[7] = editing.setValue;
		$[8] = editing.shortcut;
		$[9] = fetchedQuery;
		$[10] = inboxPickerProps;
		$[11] = isLoading;
		$[12] = isOnInbox;
		$[13] = maxPrAge;
		$[14] = methods.createShortcut;
		$[15] = methods.editShortcut;
		$[16] = methods.selectSidebarLink;
		$[17] = methods.updateShortcut;
		$[18] = pullsFilterProps;
		$[19] = savedViews;
		$[20] = selectedSidebarLink;
		$[21] = visibleLinks;
		$[22] = t1;
	} else t1 = $[22];
	return t1;
}
PullsDashboardSurfaceLayout.displayName = "PullsDashboardSurfaceLayout";
function _temp(path, query) {
	if (query) return pullsDashboardSurfaceContentRoute.generatePath({ mode: path || "" }, { search: `?q=${query}` });
	else return pullsDashboardSurfaceContentRoute.generatePath({ mode: path || "" });
}
var SplitComponent = PullsDashboardSurfaceLayoutComponent;
export { SplitComponent as component };
