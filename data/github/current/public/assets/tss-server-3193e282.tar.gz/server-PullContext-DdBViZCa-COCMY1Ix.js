import { createContext, use, useMemo } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var PullContext = createContext(void 0);
PullContext.displayName = "PullContext";
function PullContextProvider(t0) {
	const $ = c(5);
	const { pull, children } = t0;
	let t1;
	if ($[0] !== pull) {
		t1 = { pull };
		$[0] = pull;
		$[1] = t1;
	} else t1 = $[1];
	const value = t1;
	let t2;
	if ($[2] !== children || $[3] !== value) {
		t2 = jsx(PullContext, {
			value,
			children
		});
		$[2] = children;
		$[3] = value;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
PullContextProvider.displayName = "PullContextProvider";
export { PullContextProvider as t };
