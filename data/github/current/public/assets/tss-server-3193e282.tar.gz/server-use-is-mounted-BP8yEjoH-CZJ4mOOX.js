import { useCallback, useLayoutEffect, useRef } from "react";
import { c } from "react/compiler-runtime";
/**
* Hook for determining whether a component is still mounted.
*
* Use this to guard side-effects of asynchronous operations (fetches,
* promises) that may complete after a component has been unmounted.
*
* Example:
*
*      const isMounted = useIsMounted();
*      const [value, setHidden] = useHidden(true);
*
*      setTimeout(() => {
*          if (isMounted()) {
*              setHidden(true);
*          }
*      }, 1000);
*
*/
function useIsMounted() {
	const $ = c(3);
	const mountedRef = useRef(false);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => mountedRef.current;
		$[0] = t0;
	} else t0 = $[0];
	const isMounted = t0;
	let t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			mountedRef.current = true;
			return () => {
				mountedRef.current = false;
			};
		};
		t2 = [];
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useLayoutEffect(t1, t2);
	return isMounted;
}
export { useIsMounted as t };
