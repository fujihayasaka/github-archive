performance.mark("js-parse-end:server-PullRequestsSidePanel-CtMOCEE1-BQlypwqQ.js");
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as AgentIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { r as fetchCAPI, t as ConsecutiveCAPI401sProvider } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { t as CopilotChatProvider } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { n as CurrentUserProvider, r as agentTaskQueryKey, t as ChatStreamProvider } from "./server-use-task-B-REuEVT-BE9pVUx2.js";
import { P as ViewModeProvider, jt as useInitializeAuthToken, k as TaskChat, t as ArchiveDialogProvider, wt as useArchiveDialog } from "./server-TaskChat-CtDXk6Za-BcxdUxem.js";
import { t as PullContextProvider } from "./server-PullContext-DdBViZCa-COCMY1Ix.js";
import { t as useChatPayload } from "./server-use-chat-payload-I_4Odglq-LaW0idPG.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:PullRequestsSidePanel-CtMOCEE1.js");
function useArchiveTask(t0) {
	const $ = c(14);
	const { taskId, repoOwner, repoName } = t0;
	const queryClient = useQueryClient();
	let t1;
	let t2;
	if ($[0] !== repoName || $[1] !== repoOwner || $[2] !== taskId) {
		t1 = [
			"archiveTask",
			repoOwner,
			repoName,
			taskId
		];
		t2 = async () => {
			return await fetchCAPI({
				path: `/agents/repos/${repoOwner}/${repoName}/tasks/${taskId}/archive`,
				method: "POST"
			});
		};
		$[0] = repoName;
		$[1] = repoOwner;
		$[2] = taskId;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	let t3;
	if ($[5] !== queryClient || $[6] !== repoName || $[7] !== repoOwner || $[8] !== taskId) {
		t3 = () => {
			const taskQueryKey = agentTaskQueryKey(repoOwner, repoName, taskId);
			queryClient.invalidateQueries({ queryKey: taskQueryKey });
			queryClient.invalidateQueries({ queryKey: [
				"repo-tasks",
				repoOwner,
				repoName
			] });
		};
		$[5] = queryClient;
		$[6] = repoName;
		$[7] = repoOwner;
		$[8] = taskId;
		$[9] = t3;
	} else t3 = $[9];
	let t4;
	if ($[10] !== t1 || $[11] !== t2 || $[12] !== t3) {
		t4 = {
			mutationKey: t1,
			mutationFn: t2,
			onSuccess: t3
		};
		$[10] = t1;
		$[11] = t2;
		$[12] = t3;
		$[13] = t4;
	} else t4 = $[13];
	return useMutation(t4);
}
function ArchiveConfirmationDialog() {
	const $ = c(10);
	const { dialogState, closeArchiveDialog, setArchiveStatus } = useArchiveDialog();
	const t0 = dialogState.taskId ?? void 0;
	let t1;
	if ($[0] !== dialogState.repoName || $[1] !== dialogState.repoOwner || $[2] !== t0) {
		t1 = {
			repoOwner: dialogState.repoOwner,
			repoName: dialogState.repoName,
			taskId: t0
		};
		$[0] = dialogState.repoName;
		$[1] = dialogState.repoOwner;
		$[2] = t0;
		$[3] = t1;
	} else t1 = $[3];
	const { mutate: archiveTask } = useArchiveTask(t1);
	let t2;
	if ($[4] !== archiveTask || $[5] !== closeArchiveDialog || $[6] !== setArchiveStatus) {
		t2 = (gesture) => {
			if (gesture === "confirm") archiveTask(void 0, {
				onSuccess: () => {
					setArchiveStatus("success");
					closeArchiveDialog();
				},
				onError: () => {
					setArchiveStatus("error");
					closeArchiveDialog();
				}
			});
			else closeArchiveDialog();
		};
		$[4] = archiveTask;
		$[5] = closeArchiveDialog;
		$[6] = setArchiveStatus;
		$[7] = t2;
	} else t2 = $[7];
	const handleClose = t2;
	if (!dialogState.isOpen) return null;
	let t3;
	if ($[8] !== handleClose) {
		t3 = jsx(ConfirmationDialog, {
			onClose: handleClose,
			title: "Archive session",
			confirmButtonContent: "Yes, archive",
			cancelButtonContent: "Cancel",
			confirmButtonType: "danger",
			children: "Are you sure you want to archive this session?"
		});
		$[8] = handleClose;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
ArchiveConfirmationDialog.displayName = "ArchiveConfirmationDialog";
function ArchiveTaskBanner() {
	const $ = c(6);
	const { archiveStatus, setArchiveStatus } = useArchiveDialog();
	let t0;
	if ($[0] !== setArchiveStatus) {
		t0 = () => {
			setArchiveStatus("idle");
		};
		$[0] = setArchiveStatus;
		$[1] = t0;
	} else t0 = $[1];
	const handleDismiss = t0;
	if (archiveStatus === "idle") return null;
	if (archiveStatus === "success") {
		let t1;
		if ($[2] !== handleDismiss) {
			t1 = jsx(Banner, {
				variant: "success",
				title: "Session archived",
				hideTitle: true,
				description: "The session has been archived successfully.",
				onDismiss: handleDismiss
			});
			$[2] = handleDismiss;
			$[3] = t1;
		} else t1 = $[3];
		return t1;
	}
	let t1;
	if ($[4] !== handleDismiss) {
		t1 = jsx(Banner, {
			variant: "critical",
			title: "Archive failed",
			hideTitle: true,
			description: "Failed to archive the session. Please try again.",
			onDismiss: handleDismiss
		});
		$[4] = handleDismiss;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
ArchiveTaskBanner.displayName = "ArchiveTaskBanner";
var NotFoundError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "NotFoundError";
	}
};
function useTaskPayload(repository, pullRequestNumber) {
	const $ = c(4);
	let t0;
	if ($[0] !== pullRequestNumber || $[1] !== repository.name || $[2] !== repository.ownerLogin) {
		t0 = {
			queryKey: [
				"pull-request-side-panel",
				"task-payload",
				repository.ownerLogin,
				repository.name,
				pullRequestNumber
			],
			queryFn: async () => {
				const resp = await verifiedFetchJSON(`/${repository.ownerLogin}/${repository.name}/agents/pull/${pullRequestNumber}.json`);
				if (resp.status === 404) throw new NotFoundError("No agent sessions for this pull request.");
				if (!resp.ok) throw new Error(`Failed to fetch sessions: ${resp.statusText}`);
				const backendPayload = (await resp.json()).payload.repoTaskRoute;
				return {
					pull: backendPayload.pull,
					sessions: backendPayload.sessions || [],
					currentUser: backendPayload.currentUser,
					currentUserCanPush: backendPayload.currentUserCanPush ?? false,
					steeringEnabled: backendPayload.steeringEnabled ?? false,
					sessionOwners: backendPayload.sessionOwners || [],
					agentMentions: backendPayload.agentMentions || [],
					branchAliveChannel: backendPayload.branchAliveChannel,
					taskId: backendPayload.taskId,
					task: backendPayload.task,
					initialAuthToken: backendPayload.initialAuthToken
				};
			},
			staleTime: Infinity
		};
		$[0] = pullRequestNumber;
		$[1] = repository.name;
		$[2] = repository.ownerLogin;
		$[3] = t0;
	} else t0 = $[3];
	return useQuery(t0);
}
var NoAgentSessions = () => /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
	/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(AgentIcon, { size: 24 }) }),
	/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: "No agent sessions" }),
	/* @__PURE__ */ jsx(BlankslateContainer.Description, { children: "No agent sessions found for this pull request." })
] });
/**
* Component that fetches and displays agent logs for a pull request
*/
NoAgentSessions.displayName = "NoAgentSessions";
function PullRequestsSidePanel(t0) {
	const $ = c(9);
	const { repository, pullRequestNumber } = t0;
	const chatQuery = useChatPayload();
	const taskQuery = useTaskPayload(repository, pullRequestNumber);
	const isLoading = chatQuery.isLoading || taskQuery.isLoading;
	const error = chatQuery.error || taskQuery.error;
	if (isLoading) {
		let t1;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx("div", {
				className: "d-flex flex-justify-center flex-items-center tmp-p-4",
				children: jsx(Spinner, { size: "medium" })
			});
			$[0] = t1;
		} else t1 = $[0];
		return t1;
	}
	if (error) {
		if (taskQuery.error?.name === "NotFoundError") {
			let t1;
			if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
				t1 = jsx(NoAgentSessions, {});
				$[1] = t1;
			} else t1 = $[1];
			return t1;
		}
		const errorMessage = error.message || "Failed to load agent logs";
		let t1;
		if ($[2] !== errorMessage) {
			t1 = jsx("div", {
				className: "tmp-p-4 color-fg-danger",
				children: errorMessage
			});
			$[2] = errorMessage;
			$[3] = t1;
		} else t1 = $[3];
		return t1;
	}
	if (!chatQuery.data || !taskQuery.data) {
		let t1;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t1 = jsx(NoAgentSessions, {});
			$[4] = t1;
		} else t1 = $[4];
		return t1;
	}
	let t1;
	if ($[5] !== chatQuery.data || $[6] !== repository || $[7] !== taskQuery.data) {
		t1 = jsx(TaskDetailView, {
			chatPayload: chatQuery.data,
			taskPayload: taskQuery.data,
			repository
		});
		$[5] = chatQuery.data;
		$[6] = repository;
		$[7] = taskQuery.data;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
PullRequestsSidePanel.displayName = "PullRequestsSidePanel";
function TaskDetailView(t0) {
	const $ = c(8);
	const { chatPayload, taskPayload, repository } = t0;
	useInitializeAuthToken(taskPayload.initialAuthToken);
	let t1;
	if ($[0] !== taskPayload.currentUser?.id || $[1] !== taskPayload.sessionOwners) {
		t1 = taskPayload.sessionOwners?.some((owner) => owner.id === taskPayload.currentUser?.id);
		$[0] = taskPayload.currentUser?.id;
		$[1] = taskPayload.sessionOwners;
		$[2] = t1;
	} else t1 = $[2];
	const currentUserIsSessionOwner = !!t1;
	let t2;
	if ($[3] !== chatPayload || $[4] !== currentUserIsSessionOwner || $[5] !== repository || $[6] !== taskPayload) {
		t2 = jsx(ViewModeProvider, {
			mode: "sidePanel",
			children: jsx(CurrentRepositoryProvider, {
				repository,
				children: jsx(CopilotChatProvider, {
					workerPath: chatPayload.findFileWorkerPath,
					threadId: null,
					refs: chatPayload.refs ?? [],
					mode: "assistive",
					ssoOrganizations: chatPayload.ssoOrganizations ?? [],
					copilotChatPayload: chatPayload,
					children: jsx(ConsecutiveCAPI401sProvider, { children: jsx(ChatStreamProvider, { children: jsxs(ArchiveDialogProvider, { children: [
						jsx(ArchiveTaskBanner, {}),
						jsx(CurrentUserProvider, {
							currentUser: taskPayload.currentUser,
							currentUserIsSessionOwner,
							optedInToFeedback: chatPayload.optedInToUserFeedback,
							children: jsx(PullContextProvider, {
								pull: taskPayload.pull,
								children: jsx(TaskChat, {
									...taskPayload,
									showHeader: true,
									isRepoAgentsView: true,
									repoOwner: repository.ownerLogin,
									repoName: repository.name,
									taskId: taskPayload.taskId,
									branchAliveChannel: taskPayload.branchAliveChannel,
									task: taskPayload.task
								})
							})
						}),
						jsx(ArchiveConfirmationDialog, {})
					] }) }) })
				})
			})
		});
		$[3] = chatPayload;
		$[4] = currentUserIsSessionOwner;
		$[5] = repository;
		$[6] = taskPayload;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
TaskDetailView.displayName = "TaskDetailView";
export { PullRequestsSidePanel };
