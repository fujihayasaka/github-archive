import { useCallback, useEffect, useEffectEvent, useReducer, useRef, useState } from "react";
import { c } from "react/compiler-runtime";
var ObservableBase = class {
	#subscriptions = /* @__PURE__ */ new Set();
	/**
	* Adds a callback to run in response to changes in the observable.
	* @param onChange a callback to run in response to changes in the observable
	* @returns a function to unsubscribe from the observable
	*/
	subscribe(onChange) {
		this.#subscriptions.add(onChange);
		return () => {
			this.#subscriptions.delete(onChange);
		};
	}
	notify(value) {
		for (const onChange of this.#subscriptions) onChange(value);
	}
};
/**
* A value that can be observed for changes.
* If the value is an object, the observable updates when any properties of that object change.
* If the value is not an object, the observable updates when the value is a new reference.
*/
var ObservableValue = class extends ObservableBase {
	#value;
	constructor(value) {
		super();
		this.#value = value;
	}
	/**
	* The current value of the observable.
	*/
	get value() {
		return this.#value;
	}
	/**
	* Updates the value of the observable.
	*/
	set value(value) {
		if (!hasChanges(this.#value, value)) return;
		this.#value = value;
		this.notify(value);
	}
	/**
	* Sets the value of the observable.
	* This is a convenience method that doesn't upset the React compiler like setting the value directly does.
	*/
	setValue(value) {
		this.value = value;
	}
};
/**
* For two truthy objects, returns true if there is a difference in the top-level
* properties of the arguments. Otherwise, returns true if the arguments are different.
*/
function hasChanges(previous, current) {
	if (typeof current === "object" && !!current && typeof previous === "object" && !!previous) return hasObjectPropertyChanges(previous, current);
	return !Object.is(previous, current);
}
function hasObjectPropertyChanges(previous, current) {
	const keys = new Set(Object.keys(previous).concat(Object.keys(current)));
	for (const key of keys) if (!Object.is(previous[key], current[key])) return true;
	return false;
}
/**
* A Set that can be observed for changes to its contents.
*/
var ObservableSet = class extends ObservableBase {
	#value;
	#memberObservables = /* @__PURE__ */ new Map();
	constructor(...args) {
		super();
		this.#value = new Set(...args);
	}
	/**
	* The Set underlying the observable.
	*/
	get value() {
		return this.#value;
	}
	/**
	* Returns an observable boolean that indicates whether the Set contains a
	* given value. This observable will be updated if the given value is added
	* to or removed from the Set.
	* @param value the value to check for
	*/
	has(value) {
		if (!this.#memberObservables.has(value)) {
			const observable = new ObservableValue(this.#value.has(value));
			this.#memberObservables.set(value, observable);
		}
		return this.#memberObservables.get(value);
	}
	/**
	* Adds the given value to the Set.
	* Updates subscribers to the Set if the value was added.
	* Updates subscribers to the given value's membership via `has` if it was added.
	* @param value the value to add
	*/
	add(value) {
		if (this.#value.has(value)) return;
		this.#value.add(value);
		if (this.#memberObservables.has(value)) this.#memberObservables.get(value).value = true;
		this.notify(this.#value);
	}
	/**
	* Removes the given value from the Set.
	* Updates subscribers to the Set if the value was removed.
	* Updates subscribers to the given value's membership via `has` if it was removed.
	* @param value the value to remove
	*/
	delete(value) {
		if (!this.#value.has(value)) return;
		this.#value.delete(value);
		if (this.#memberObservables.has(value)) this.#memberObservables.get(value).value = false;
		this.notify(this.#value);
	}
	/**
	* Removes all values from the Set.
	* Updates subscribers to the Set if any values were removed.
	* Updates subscribers to each value that was removed.
	*/
	clear() {
		if (this.#value.size === 0) return;
		this.#value.clear();
		for (const observable of this.#memberObservables.values()) observable.value = false;
		this.notify(this.#value);
	}
};
/**
* A Map that can be observed for changes to its contents.
*/
var ObservableMap = class extends ObservableBase {
	#value;
	#keyObservables = /* @__PURE__ */ new Map();
	#valueObservables = /* @__PURE__ */ new Map();
	constructor(...args) {
		super();
		this.#value = new Map(...args);
	}
	/**
	* The Map underlying the observable.
	*/
	get value() {
		return this.#value;
	}
	/**
	* Returns an observable boolean that indicates whether the Map contains a
	* given key. This observable will be updated if the given value is added
	* to or removed from the Map.
	* @param key the key to check for
	*/
	has(key) {
		if (!this.#keyObservables.has(key)) {
			const observable = new ObservableValue(this.#value.has(key));
			this.#keyObservables.set(key, observable);
		}
		return this.#keyObservables.get(key);
	}
	/**
	* Returns an observable value that contains the value associated with the
	* given key, or undefined if the Map does not contain the key. This observable
	* will be updated if the key is added to or removed from the Map, or if the
	* value associated with the key changes.
	* @param key the key for which to retrieve the value
	*/
	get(key) {
		if (!this.#valueObservables.has(key)) {
			const observable = new ObservableValue(this.#value.get(key));
			this.#valueObservables.set(key, observable);
		}
		return this.#valueObservables.get(key);
	}
	/**
	* Associates the given value with the given key in the Map.
	* Updates subscribers to the Map if the key did not already have this value.
	* Updates subscribers to the given key's membership via `has` if it was newly added.
	* Updates subscribers to the given key's value via `get` if it changed.
	* @param key the key for which to add the value
	* @param value the value to add
	*/
	set(key, value) {
		if (this.#value.get(key) === value) return;
		this.#value.set(key, value);
		if (this.#keyObservables.has(key)) this.#keyObservables.get(key).value = true;
		if (this.#valueObservables.has(key)) this.#valueObservables.get(key).value = value;
		this.notify(this.#value);
	}
	/**
	* Removes the value associated with the given key from the Map.
	* Updates subscribers to the Map if the key was removed.
	* Updates subscribers to the given key's membership via `has` if it was removed.
	* Updates subscribers to the given key's value via `get` if it was removed.
	* @param key the key to remove
	*/
	delete(key) {
		if (!this.#value.has(key)) return;
		this.#value.delete(key);
		if (this.#keyObservables.has(key)) this.#keyObservables.get(key).value = false;
		if (this.#valueObservables.has(key)) this.#valueObservables.get(key).value = void 0;
		this.notify(this.#value);
	}
	/**
	* Removes all keys and their values from the Map.
	* Updates subscribers to the Map if any keys were removed.
	* Updates subscribers to each removed key's membership via `has`.
	* Updates subscribers to each removed key's value via `get`.
	*/
	clear() {
		if (this.#value.size === 0) return;
		this.#value.clear();
		for (const observable of this.#keyObservables.values()) observable.value = false;
		for (const observable of this.#valueObservables.values()) observable.value = void 0;
		this.notify(this.#value);
	}
};
/**
* Returns a constant reference to an ObservableValue
* @param initialValue the initial value of the observable
*/
function useObservableValue(initialValue) {
	const $ = c(2);
	let t0;
	if ($[0] !== initialValue) {
		t0 = () => new ObservableValue(initialValue);
		$[0] = initialValue;
		$[1] = t0;
	} else t0 = $[1];
	const [observableRef] = useState(t0);
	return observableRef;
}
/**
* Returns a ref to an ObservableValue
* @param initialValue the initial value of the observable
*/
function useObservableValueRef(initialValue) {
	const $ = c(4);
	const observableRef = useRef(null);
	if (observableRef.current === null) {
		let t0;
		if ($[0] !== initialValue) {
			t0 = new ObservableValue(initialValue);
			$[0] = initialValue;
			$[1] = t0;
		} else t0 = $[1];
		observableRef.current = t0;
	}
	let t0;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (value) => {
			if (observableRef.current !== null) observableRef.current.value = value;
		};
		$[2] = t0;
	} else t0 = $[2];
	const setObservableRef = t0;
	let t1;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [observableRef, setObservableRef];
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
/**
* Returns a constant reference to an ObservableMap
* @param args the initializer arguments for the underlying Map
*/
function useObservableMap(...t0) {
	const $ = c(2);
	const args = t0;
	let t1;
	if ($[0] !== args) {
		t1 = () => new ObservableMap(...args);
		$[0] = args;
		$[1] = t1;
	} else t1 = $[1];
	const [observableRef] = useState(t1);
	return observableRef;
}
/** We could use null or undefined, but those are valid values for an observable, so we need a value that is guaranteed unique. */
var NO_VALUE = Symbol("no value");
/**
* Safely subscribes to and unsubscribes from an observable
* @param observable the subject observable
* @param onChange a callback to run in response to changes in the observable
*/
function useSubscription(observable, onChange) {
	const $ = c(5);
	const initialValueRef = useRef(observable.value);
	const handleOnChange = useEffectEvent(onChange);
	let t0;
	if ($[0] !== handleOnChange || $[1] !== observable) {
		t0 = () => {
			if (initialValueRef.current !== NO_VALUE && initialValueRef.current !== observable.value) {
				handleOnChange(observable.value);
				initialValueRef.current = NO_VALUE;
			}
			return observable.subscribe((value) => handleOnChange(value));
		};
		$[0] = handleOnChange;
		$[1] = observable;
		$[2] = t0;
	} else t0 = $[2];
	let t1;
	if ($[3] !== observable) {
		t1 = [observable];
		$[3] = observable;
		$[4] = t1;
	} else t1 = $[4];
	useEffect(t0, t1);
}
/**
* Returns a stateful value that is updated (re-rendering the
* component) when the given observable changes
* @param observable the subject observable
*/
function useObservedState(observable) {
	const $ = c(1);
	const [value, setValue] = useState(observable.value);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (newValue) => setValue(newValue);
		$[0] = t0;
	} else t0 = $[0];
	useSubscription(observable, t0);
	return value;
}
/**
* Returns a stateful value that is updated (re-rendering the
* component) when the given observable changes - can use this
* with an observable map as the return value becasue we manually
* re-render when the value is updated
* @param observable the subject observable
*/
function useObservedStateMap(observable) {
	const $ = c(2);
	const [value, setValue] = useState(observable.value);
	const [, forceRender] = useReducer(_temp, 0);
	let t0;
	if ($[0] !== forceRender) {
		t0 = (newValue) => {
			setValue(newValue);
			forceRender();
		};
		$[0] = forceRender;
		$[1] = t0;
	} else t0 = $[1];
	useSubscription(observable, t0);
	return value;
}
/**
* Returns a constant reference to an observable that is updated in
* response to changes in the given observable.
* @param observable the subject observable
* @param derive a function which transforms the value of the subject
*               observable to the value of the returned observable
*/
function _temp(s) {
	return s + 1;
}
function useDerivedObservable(observable, derive) {
	const derivedObservable = useObservableValue(derive(observable.value));
	useSubscription(observable, (value) => {
		derivedObservable.value = derive(value);
	});
	return derivedObservable;
}
export { useObservableMap as a, useObservedState as c, useDerivedObservable as i, useObservedStateMap as l, ObservableSet as n, useObservableValue as o, ObservableValue as r, useObservableValueRef as s, ObservableMap as t, useSubscription as u };
