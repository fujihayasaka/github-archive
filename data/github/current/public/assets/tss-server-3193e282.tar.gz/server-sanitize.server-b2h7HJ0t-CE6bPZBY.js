import createDOMPurify from "dompurify";
import { parseHTML } from "linkedom";
/**
* Build a plain window-like object from linkedom for DOMPurify.
*
* linkedom's `parseHTML` returns a `defaultView` that is a Proxy around
* globalThis — property assignments silently go to globalThis. We build
* a plain object instead, with only the APIs DOMPurify needs.
*/
function createLinkedomWindow() {
	const linkedomWindow = parseHTML("");
	const doc = linkedomWindow.document;
	const reusableDoc = parseHTML("<!DOCTYPE html><html><head></head><body></body></html>").document;
	const w = {
		document: doc,
		DocumentFragment: linkedomWindow.DocumentFragment,
		HTMLTemplateElement: linkedomWindow.HTMLTemplateElement,
		Node: linkedomWindow.Node,
		Element: linkedomWindow.Element,
		NodeFilter: linkedomWindow.NodeFilter || {
			SHOW_ELEMENT: 1,
			SHOW_TEXT: 4,
			SHOW_COMMENT: 128,
			SHOW_PROCESSING_INSTRUCTION: 64,
			SHOW_CDATA_SECTION: 8,
			FILTER_ACCEPT: 1,
			FILTER_REJECT: 2,
			FILTER_SKIP: 3
		},
		NamedNodeMap: linkedomWindow.NamedNodeMap,
		HTMLFormElement: linkedomWindow.HTMLFormElement,
		trustedTypes: void 0,
		DOMParser: class {
			parseFromString(html, type) {
				if (type === "text/html") {
					reusableDoc.head.textContent = "";
					reusableDoc.body.textContent = "";
					reusableDoc.body.innerHTML = html;
					return reusableDoc;
				}
				const P = linkedomWindow.DOMParser;
				return new P().parseFromString(html, type);
			}
		}
	};
	if (!doc.implementation || typeof doc.implementation.createHTMLDocument !== "function") doc.implementation = {
		createHTMLDocument(_title) {
			reusableDoc.head.textContent = "";
			reusableDoc.body.textContent = "";
			return reusableDoc;
		},
		createDocument() {
			reusableDoc.head.textContent = "";
			reusableDoc.body.textContent = "";
			return reusableDoc;
		}
	};
	const origRemove = w.Element.prototype.remove;
	w.Element.prototype.remove = function() {
		try {
			origRemove.call(this);
		} catch {
			if (this.parentNode) this.parentNode.removeChild(this);
		}
	};
	const origCloneNode = w.Element.prototype.cloneNode;
	w.Element.prototype.cloneNode = function(deep) {
		try {
			return origCloneNode.call(this, deep);
		} catch {
			let proto = Object.getPrototypeOf(this);
			while (proto) {
				const desc = Object.getOwnPropertyDescriptor(proto, "cloneNode");
				if (desc && desc.value !== w.Element.prototype.cloneNode) return desc.value.call(this, deep);
				proto = Object.getPrototypeOf(proto);
			}
			throw new Error("cloneNode: no fallback found for node");
		}
	};
	return w;
}
var defaultInstance = createDOMPurify(createLinkedomWindow());
var isSanitizing = false;
function sanitize(dirty, cfg) {
	if (isSanitizing) throw new Error("sanitize(): reentrant call detected. Do not call sanitize() from within a DOMPurify hook — the shared linkedom document would be corrupted.");
	isSanitizing = true;
	try {
		if (cfg?.RETURN_DOM && !cfg.RETURN_DOM_FRAGMENT) return defaultInstance.sanitize(dirty, cfg).cloneNode(true);
		return defaultInstance.sanitize(dirty, cfg);
	} finally {
		isSanitizing = false;
	}
}
export { sanitize as t };
