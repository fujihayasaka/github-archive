import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
async function fetchTree(contentUrl) {
	const response = await verifiedFetchJSON(`${contentUrl}?noancestors=1`);
	if (!response.ok) throw new Error(`Failed to fetch tree data: ${response.status} ${response.statusText}`);
	const data = await response.json();
	let normalizedPayload;
	if ("codeViewTreeRoute" in data.payload) normalizedPayload = { tree: {
		items: data.payload.codeViewTreeRoute.tree.items,
		totalCount: data.payload.codeViewTreeRoute.tree.totalCount
	} };
	else normalizedPayload = { tree: {
		items: data.payload.tree.items,
		totalCount: data.payload.tree.totalCount
	} };
	return normalizedPayload;
}
export { fetchTree as t };
