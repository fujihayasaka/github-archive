import { r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
var fuzzyFilter = ({ items, filter, key, secondaryKey }) => {
	const scoredItems = [];
	for (const item of items) {
		const primaryScore = fuzzyScore(filter, key(item));
		const finalScore = secondaryKey ? Math.max(primaryScore, fuzzyScore(filter, secondaryKey(item))) : primaryScore;
		if (finalScore > -Infinity) scoredItems.push([finalScore, item]);
	}
	scoredItems.sort(([aScore, a], [bScore, b]) => {
		if (bScore === aScore) return key(a).localeCompare(key(b));
		return bScore - aScore;
	});
	return scoredItems.map(([, item]) => item);
};
export { fuzzyFilter as t };
