import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewTreeDeleteRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewTreeDeleteRoute", {
	path: "/:owner/:repo/tree/delete/:branch/*",
	queries: [mainQuery({ encodeFetchPath: true })]
});
export { codeViewTreeDeleteRoute as t };
