import { r as mainQuery, t as DataRouterApplicationBuilder } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
var codeViewAppBuilder = DataRouterApplicationBuilder.create("code-view");
var codeViewLayoutRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewLayoutRoute", {
	path: "/:owner/:repo",
	queries: [mainQuery({ queryDeps: ({ pathname }) => ({ pathname: `${pathname}/_layout` }) })],
	shouldRevalidate: ({ currentParams, nextParams }) => {
		return currentParams.owner !== nextParams.owner || currentParams.repo !== nextParams.repo;
	}
});
export { codeViewLayoutRoute as n, codeViewAppBuilder as t };
