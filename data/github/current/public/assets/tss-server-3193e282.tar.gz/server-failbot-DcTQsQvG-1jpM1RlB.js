import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { i as isAutomatedBrowser$1, n as bundler } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { o as getSoftNavReferrer } from "./server-utils-4Tqzfq5z-FwA7hod1.js";
import { n as getRecentRequestIds } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { getOrCreateClientId } from "@github/hydro-analytics-client";
var UNKNOWN_FUNCTION = "<unknown>";
/**
* This parses the different stack traces and puts them into one format
* This borrows heavily from TraceKit (https://github.com/csnover/TraceKit)
*/
function parse(stackString) {
	return stackString.split("\n").reduce(function(stack, line) {
		var parseResult = parseChrome(line) || parseWinjs(line) || parseGecko(line) || parseNode(line) || parseJSC(line);
		if (parseResult) stack.push(parseResult);
		return stack;
	}, []);
}
var chromeRe = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|rsc|<anonymous>|\/|[a-z]:\\|\\\\).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
var chromeEvalRe = /\((\S*)(?::(\d+))(?::(\d+))\)/;
function parseChrome(line) {
	var parts = chromeRe.exec(line);
	if (!parts) return null;
	var isNative = parts[2] && parts[2].indexOf("native") === 0;
	var isEval = parts[2] && parts[2].indexOf("eval") === 0;
	var submatch = chromeEvalRe.exec(parts[2]);
	if (isEval && submatch != null) {
		parts[2] = submatch[1];
		parts[3] = submatch[2];
		parts[4] = submatch[3];
	}
	return {
		file: !isNative ? parts[2] : null,
		methodName: parts[1] || UNKNOWN_FUNCTION,
		arguments: isNative ? [parts[2]] : [],
		lineNumber: parts[3] ? +parts[3] : null,
		column: parts[4] ? +parts[4] : null
	};
}
var winjsRe = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|rsc|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;
function parseWinjs(line) {
	var parts = winjsRe.exec(line);
	if (!parts) return null;
	return {
		file: parts[2],
		methodName: parts[1] || UNKNOWN_FUNCTION,
		arguments: [],
		lineNumber: +parts[3],
		column: parts[4] ? +parts[4] : null
	};
}
var geckoRe = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|rsc|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i;
var geckoEvalRe = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function parseGecko(line) {
	var parts = geckoRe.exec(line);
	if (!parts) return null;
	var isEval = parts[3] && parts[3].indexOf(" > eval") > -1;
	var submatch = geckoEvalRe.exec(parts[3]);
	if (isEval && submatch != null) {
		parts[3] = submatch[1];
		parts[4] = submatch[2];
		parts[5] = null;
	}
	return {
		file: parts[3],
		methodName: parts[1] || UNKNOWN_FUNCTION,
		arguments: parts[2] ? parts[2].split(",") : [],
		lineNumber: parts[4] ? +parts[4] : null,
		column: parts[5] ? +parts[5] : null
	};
}
var javaScriptCoreRe = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i;
function parseJSC(line) {
	var parts = javaScriptCoreRe.exec(line);
	if (!parts) return null;
	return {
		file: parts[3],
		methodName: parts[1] || UNKNOWN_FUNCTION,
		arguments: [],
		lineNumber: +parts[4],
		column: parts[5] ? +parts[5] : null
	};
}
var nodeRe = /^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i;
function parseNode(line) {
	var parts = nodeRe.exec(line);
	if (!parts) return null;
	return {
		file: parts[2],
		methodName: parts[1] || UNKNOWN_FUNCTION,
		arguments: [],
		lineNumber: +parts[3],
		column: parts[4] ? +parts[4] : null
	};
}
function isSupported() {
	return false;
}
function stacktrace(error) {
	return parse(error.stack || "").map((frame) => ({
		filename: frame.file || "",
		function: String(frame.methodName),
		lineno: (frame.lineNumber || 0).toString(),
		colno: (frame.column || 0).toString()
	}));
}
function formatError(error) {
	return {
		type: error.name,
		value: error.message,
		stacktrace: stacktrace(error),
		catalogService: error.catalogService || currentCatalogService$1(),
		catalogServiceHash: error.catalogServiceHash || currentCatalogServiceHash$1()
	};
}
function currentCatalogService$1() {
	return globalThis.document?.head?.querySelector("meta[name=\"current-catalog-service\"]")?.content;
}
function currentCatalogServiceHash$1() {
	return globalThis.document?.head?.querySelector("meta[name=\"current-catalog-service-hash\"]")?.content;
}
function queryLast(selector) {
	const list = document.querySelectorAll(selector);
	if (list.length > 0) return list[list.length - 1];
}
function pagePathname() {
	const locationOverride = queryLast("meta[name=analytics-location]");
	if (locationOverride) return locationOverride.content;
	else return window.location.pathname;
}
function pageQuery() {
	const stripParams = queryLast("meta[name=analytics-location-query-strip]");
	let search = "";
	if (!stripParams) search = window.location.search;
	const extraParams = queryLast("meta[name=analytics-location-params]");
	if (extraParams) search += (search ? "&" : "?") + extraParams.content;
	for (const meta of document.querySelectorAll("meta[name=analytics-param-rename]")) {
		const names = meta.content.split(":", 2);
		search = search.replace(new RegExp(`(^|[?&])${names[0]}($|=)`, "g"), `$1${names[1]}$2`);
	}
	return search;
}
function requestUri() {
	return `${window.location.protocol}//${window.location.host}${pagePathname() + pageQuery()}`;
}
var extensionErrors = false;
var errorsReported = 0;
var loadTime = Date.now();
var EXPECTED_NETWORK_ERROR_TYPES = new Set([
	"AbortError",
	"AuthSessionExpiredError",
	"TypeError",
	"RateLimitError",
	"NotAcceptableError",
	"SecFetchHeaderError",
	"FetchNetworkError",
	"NoiseError",
	"ServiceUnavailableError"
]);
var EXPECTED_NETWORK_ERROR_MESSAGES = new Set([
	"Failed to fetch",
	"NetworkError when attempting to fetch resource.",
	"Unable to perform this operation. Please try again later."
]);
function isError(error) {
	if (error instanceof Error) return true;
	return typeof error === "object" && error !== null && "name" in error && typeof error.name === "string" && "message" in error && typeof error.message === "string";
}
/** Tries to serialize an arbitrary error value that is not an Error object, and returns a default message otherwise */
function serializeNonError(error) {
	try {
		return JSON.stringify(error);
	} catch {
		return "Unserializable";
	}
}
function isExpectedError(error) {
	if (!error.name) return false;
	if (error.name === "AbortError") return true;
	if (error.name === "RateLimitError") return true;
	if (error.name === "NotAcceptableError") return true;
	if (error.name === "SecFetchHeaderError") return true;
	if (error.name === "FetchNetworkError") return true;
	if (error.name === "NoiseError") return true;
	if (error.name === "ServiceUnavailableError" && isAnonymousUser()) return true;
	if (EXPECTED_NETWORK_ERROR_TYPES.has(error.name) && EXPECTED_NETWORK_ERROR_MESSAGES.has(error.message)) return true;
	if (error.name.startsWith("ApiError") && EXPECTED_NETWORK_ERROR_MESSAGES.has(error.message)) return true;
	return false;
}
function reportError(error, context = {}) {
	if (!isError(error)) {
		if (isIgnoredNonError(error)) return;
		const errorForStackTrace = /* @__PURE__ */ new Error();
		const serializedErrorValue = serializeNonError(error);
		report(errorContext({
			type: "UnknownError",
			value: `Unable to report error, due to a thrown non-Error type: ${typeof error}, with value ${serializedErrorValue}`,
			stacktrace: stacktrace(errorForStackTrace),
			catalogService: currentCatalogService(),
			catalogServiceHash: currentCatalogServiceHash()
		}, context));
		return;
	}
	if (!isExpectedError(error)) report(errorContext(formatError(error), context));
}
async function report(context) {
	if (!reportable()) return;
	const url = document.head?.querySelector("meta[name=\"browser-errors-url\"]")?.content;
	if (!url) return;
	if (isExtensionError(context.error.stacktrace)) {
		extensionErrors = true;
		return;
	}
	errorsReported++;
	try {
		await fetch(url, {
			method: "post",
			body: JSON.stringify({
				context,
				target: getUITarget()
			})
		});
	} catch {}
}
function errorContext(error, context = {}) {
	const newContext = { ...context };
	if (!newContext.reactAppName) newContext.reactAppName = getAppFromStacktrace(error.stacktrace);
	return Object.assign({
		error,
		sanitizedUrl: requestUri() || window.location.href,
		readyState: document.readyState,
		referrer: getSoftNavReferrer(),
		timeSinceLoad: Math.round(Date.now() - loadTime),
		user: pageUser() || void 0,
		actorId: pageActorId(),
		bundler,
		ui: true,
		release: pageRelease(),
		pastRequestIds: getRecentRequestIds()
	}, newContext);
}
var extensions = /(chrome|moz|safari)-extension:\/\//;
function isExtensionError(stack) {
	return stack.some((frame) => extensions.test(frame.filename) || extensions.test(frame.function));
}
function pageRelease() {
	return document.head?.querySelector("meta[name=\"release\"]")?.content;
}
function pageActorId() {
	return document.head?.querySelector("meta[name=\"octolytics-actor-id\"]")?.content;
}
function getUITarget() {
	return document.head?.querySelector("meta[name=\"ui-target\"]")?.content || "full";
}
function pageUser() {
	const login = document.head?.querySelector("meta[name=\"user-login\"]")?.content;
	if (login) return login;
	return `anonymous-${getOrCreateClientId()}`;
}
function isAnonymousUser() {
	return !document.head?.querySelector("meta[name=\"user-login\"]")?.content;
}
function currentCatalogService() {
	return document.head?.querySelector("meta[name=\"current-catalog-service\"]")?.content;
}
function currentCatalogServiceHash() {
	return document.head?.querySelector("meta[name=\"current-catalog-service-hash\"]")?.content;
}
var unloaded = false;
ssrSafeWindow?.addEventListener("pageshow", () => unloaded = false);
ssrSafeWindow?.addEventListener("pagehide", () => unloaded = true);
var STALE_TAB_MS = 4320 * 60 * 1e3;
function reportable() {
	const isStaleTab = Date.now() - loadTime > STALE_TAB_MS;
	return !unloaded && !extensionErrors && errorsReported < 10 && isSupportedEnvironment() && !isStaleTab && !isAutomatedBrowser$1();
}
if (typeof BroadcastChannel === "function") new BroadcastChannel("shared-worker-error").addEventListener("message", (event) => {
	reportError(event.data.error);
});
var ignoredErrorMessages = [
	"Object Not Found Matching Id",
	"Not implemented on this platform",
	`provider because it's not your default extension`
];
/**
* We see a fair number of "errors" which are not actually Error objects. This function will return true if the
* error is one of these known non-Error types and has content which we know can safely be ignored.
* Most of these errors come from specific browsers or extensions which we can't control, so we just ignore them.
* @param error An error that is not an Error object
* @returns boolean
*/
function isIgnoredNonError(error) {
	if (!error || typeof error === "boolean" || typeof error === "number") return true;
	else if (typeof error === "string") {
		if (ignoredErrorMessages.some((message) => error.includes(message))) return true;
	} else if (typeof error === "object" && typeof error.message === "string" && typeof error.code === "number") return true;
	return false;
}
var _isSupportedEnvironment = void 0;
function isSupportedEnvironment() {
	return _isSupportedEnvironment ??= isSupported() && canReplaceHistoryState();
}
function canReplaceHistoryState() {
	const history = ssrSafeWindow?.history;
	const location = ssrSafeWindow?.location;
	if (!history || !location) return false;
	try {
		history.replaceState(history.state, document.title, location.href);
		return true;
	} catch {
		return false;
	}
}
/**
* Attempts to determine which app/partial an error belongs to by matching a filename in the stacktrace
* based on the react apps that exist on the page. Starts at the top of the stack and tries to match an app.
* If that filename does not match an app, then continue to the next line of the stack trace.
* @param stack Stacktrace array (PlatformStackframe[])
*/
function getAppFromStacktrace(stack) {
	const reactAppsOnPage = getReactAppsOnPage();
	if (!reactAppsOnPage || !reactAppsOnPage.length || !stack || !stack.length) return;
	const filenames = /* @__PURE__ */ new Set();
	for (const frame of stack) {
		if (!frame || !frame.filename) continue;
		const filename = frame.filename.split(/[\\/]/).pop();
		if (!filename) continue;
		if (filenames.has(filename)) continue;
		filenames.add(filename);
		const foundApp = reactAppsOnPage.find((appName) => filename.toLowerCase().includes(appName.toLowerCase()));
		if (foundApp) return foundApp;
	}
}
var appAndPartialElementAndAttributes = [["react-app", "app-name"], ["react-partial", "partial-name"]];
/**
* Find all of the elements on the page that are either a react-app or react-partial.
* For each of them, grab their app-name (or partial-name) attribute and return
* an array containing the unique names.
*/
function getReactAppsOnPage() {
	const apps = /* @__PURE__ */ new Set();
	for (const [elementName, attributeName] of appAndPartialElementAndAttributes) for (const el of document.querySelectorAll(elementName)) if (el instanceof HTMLElement) {
		const name = el.getAttribute(attributeName);
		if (name) apps.add(name);
	}
	return Array.from(apps);
}
export { reportError as t };
