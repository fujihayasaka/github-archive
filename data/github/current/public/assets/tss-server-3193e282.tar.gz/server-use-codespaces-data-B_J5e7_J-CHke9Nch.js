import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { n as throttle } from "./server-dist-CJwx2KGE.js";
import { s as isUIService } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { r as reactFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { f as useSuspenseQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { t as createPersister } from "./server-react-query-persister-D24LKcxB-BQe2u09x.js";
import { n as Type, t as Compile } from "./server-typebox-DK1Y6Tz8-C4QyQJfa.js";
import { useCallback, useEffect, useMemo } from "react";
import { c } from "react/compiler-runtime";
/**
* Builds the URL path for fetching Codespaces content
* @param repoId - The repository ID
* @param createRef - The ref or commitish used for create actions
* @returns The encoded URL path for Codespaces
*/
function buildCodespacesPath(repoId, createRef, options) {
	const params = new URLSearchParams({
		event_target: "REPO_PAGE",
		repo: String(repoId)
	});
	if (options?.pullRequestId != null) params.set("codespace[pull_request_id]", String(options.pullRequestId));
	else params.set("codespace[ref]", createRef);
	const currentBranchName = options?.currentBranchName ?? (options?.pullRequestId == null ? createRef : void 0);
	if (currentBranchName) params.set("current_branch", currentBranchName);
	return `/codespaces?${params.toString()}`;
}
function isReactCodespacesTabEnabled() {
	return isUIService || isFeatureEnabled("codespaces_tab_react");
}
function isCachingEnabled() {
	return isFeatureEnabled("codespaces_tab_caching");
}
var CodespaceSchema = Type.Object({
	id: Type.Number(),
	name: Type.String(),
	displayName: Type.String(),
	openUrl: Type.String(),
	branch: Type.String(),
	lastUsedAt: Type.Union([Type.String(), Type.Null()]),
	isActive: Type.Boolean(),
	isFailed: Type.Boolean(),
	isBlocking: Type.Boolean(),
	blockingOperationText: Type.Union([Type.String(), Type.Null()]),
	hasUnpushedChanges: Type.Boolean(),
	hasUncommittedChanges: Type.Boolean(),
	commitsAhead: Type.Number(),
	pullRequest: Type.Union([Type.Object({
		number: Type.Number(),
		state: Type.Union([
			Type.Literal("open"),
			Type.Literal("closed"),
			Type.Literal("merged")
		])
	}), Type.Null()]),
	isForCurrentRepository: Type.Boolean(),
	isForFork: Type.Boolean(),
	isOwnersFork: Type.Boolean(),
	forkNwo: Type.Union([Type.String(), Type.Null()]),
	autoDeleteSoon: Type.Boolean(),
	retentionExpiresAt: Type.Union([Type.String(), Type.Null()]),
	retentionPeriodDays: Type.Union([Type.Number(), Type.Null()]),
	isUnpublished: Type.Boolean(),
	deletable: Type.Boolean(),
	deleteConfirmationMessage: Type.String(),
	suspendable: Type.Boolean(),
	isReadOnly: Type.Boolean(),
	needsForkToPush: Type.Boolean(),
	needsMachineTypeChange: Type.Boolean(),
	needsBaseImageChange: Type.Boolean(),
	linkDisabled: Type.Boolean(),
	allowChangeMachineType: Type.Boolean(),
	keepDisabled: Type.Boolean(),
	keepEnabled: Type.Boolean(),
	startDisabled: Type.Boolean(),
	paths: Type.Object({
		codespace: Type.String(),
		suspend: Type.String(),
		rename: Type.String(),
		changeMachineType: Type.String(),
		exportControl: Type.String(),
		export: Type.String(),
		exported: Type.String()
	}),
	exportBranchName: Type.String(),
	exportBranchUrl: Type.Union([Type.String(), Type.Null()]),
	editors: Type.Array(Type.Object({
		id: Type.String(),
		label: Type.String(),
		url: Type.String(),
		icon: Type.String(),
		beta: Type.Boolean()
	}))
});
var CodespacesDataValidator = Compile(Type.Object({
	header: Type.Object({
		createPath: Type.String(),
		newWithOptionsUrl: Type.String(),
		createFormFields: Type.Object({
			repositoryId: Type.Union([Type.Number(), Type.Null()]),
			pullRequestId: Type.Union([Type.Number(), Type.Null()]),
			expectedBillableOwnerId: Type.Union([Type.Number(), Type.Null()]),
			devcontainerPath: Type.Union([Type.String(), Type.Null()]),
			openInDeeplink: Type.Boolean()
		}),
		canCreate: Type.Boolean(),
		disableOneClickCreation: Type.Boolean(),
		manageUrl: Type.String(),
		configureDevContainerUrl: Type.Union([Type.String(), Type.Null()]),
		prebuildsUrl: Type.Union([Type.String(), Type.Null()]),
		helpUrl: Type.String(),
		billableOwnerName: Type.Union([Type.String(), Type.Null()]),
		shareUrl: Type.Optional(Type.String()),
		createNotice: Type.Optional(Type.Union([Type.Object({
			message: Type.String(),
			linkText: Type.Optional(Type.String()),
			linkUrl: Type.Optional(Type.String())
		}), Type.Null()])),
		maintenanceNotice: Type.Optional(Type.Union([Type.Object({
			message: Type.String(),
			linkText: Type.String(),
			linkUrl: Type.String(),
			dismissPath: Type.String()
		}), Type.Null()]))
	}),
	codespaces: Type.Array(CodespaceSchema),
	pullRequestWarning: Type.Union([Type.Object({
		message: Type.String(),
		linkText: Type.Optional(Type.String()),
		linkUrl: Type.Optional(Type.String())
	}), Type.Null()]),
	showActions: Type.Boolean(),
	aliveChannel: Type.Union([Type.String(), Type.Null()]),
	ssoWarning: Type.Union([Type.Object({ message: Type.String() }), Type.Null()])
}));
function normalizeCodespacesJsonPath(codespacesPath) {
	if (!codespacesPath) return void 0;
	const url = new URL(codespacesPath, "https://github.local");
	url.searchParams.delete("current_branch");
	return `${url.pathname}${url.search}`;
}
async function fetchCodespacesData(codespacesPath) {
	if (!codespacesPath) return null;
	const result = await reactFetch(codespacesPath, { headers: { Accept: "application/json" } });
	if (result.status >= 400 && result.status <= 499) return null;
	else if (!result.ok) throw new Error(`HTTP ${result.status}`);
	return await result.json();
}
var useCodespacesDataQueryOptions = (codespacesPathProp) => {
	const $ = c(13);
	const repo = useCurrentRepository();
	const refInfo = useRefInfo();
	let t0;
	if ($[0] !== codespacesPathProp || $[1] !== refInfo || $[2] !== repo) {
		t0 = normalizeCodespacesJsonPath(codespacesPathProp) || (repo && refInfo ? normalizeCodespacesJsonPath(buildCodespacesPath(repo.id, refInfo.name)) : void 0);
		$[0] = codespacesPathProp;
		$[1] = refInfo;
		$[2] = repo;
		$[3] = t0;
	} else t0 = $[3];
	const codespacesPath = t0;
	const { sendAnalyticsEvent } = useAnalytics();
	let t1;
	let t2;
	if ($[4] !== codespacesPath) {
		t1 = ["CodespacesTab.json", codespacesPath];
		t2 = () => fetchCodespacesData(codespacesPath);
		$[4] = codespacesPath;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	let t3;
	if ($[7] !== sendAnalyticsEvent) {
		t3 = createPersister({
			validator: CodespacesDataValidator,
			sendAnalyticsEvent,
			enabled: isCachingEnabled()
		});
		$[7] = sendAnalyticsEvent;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== t1 || $[10] !== t2 || $[11] !== t3) {
		t4 = {
			queryKey: t1,
			queryFn: t2,
			staleTime: 6e4,
			persister: t3
		};
		$[9] = t1;
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
};
function useCodespacesData(codespacesPath) {
	return useSuspenseQuery(useCodespacesDataQueryOptions(codespacesPath));
}
function usePrefetchCodespacesData(codespacesPath) {
	const $ = c(3);
	const queryClient = useQueryClient();
	const queryOptions = useCodespacesDataQueryOptions(codespacesPath);
	let t0;
	if ($[0] !== queryClient || $[1] !== queryOptions) {
		t0 = () => {
			if (!isCachingEnabled()) return;
			return queryClient.prefetchQuery(queryOptions);
		};
		$[0] = queryClient;
		$[1] = queryOptions;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
function useInvalidateCodespacesData(codespacesPath) {
	const $ = c(3);
	const queryClient = useQueryClient();
	const queryOptions = useCodespacesDataQueryOptions(codespacesPath);
	let t0;
	if ($[0] !== queryClient || $[1] !== queryOptions.queryKey) {
		t0 = () => queryClient.invalidateQueries({ queryKey: queryOptions.queryKey });
		$[0] = queryClient;
		$[1] = queryOptions.queryKey;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
var ALIVE_THROTTLE_MS = 2e3;
function useCodespacesAlive(aliveChannel, codespacesPath) {
	const $ = c(5);
	const invalidate = useInvalidateCodespacesData(codespacesPath);
	let t0;
	if ($[0] !== invalidate) {
		t0 = throttle(invalidate, ALIVE_THROTTLE_MS);
		$[0] = invalidate;
		$[1] = t0;
	} else t0 = $[1];
	const throttledInvalidate = t0;
	let t1;
	let t2;
	if ($[2] !== throttledInvalidate) {
		t1 = () => () => throttledInvalidate.cancel();
		t2 = [throttledInvalidate];
		$[2] = throttledInvalidate;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
	useAlive(aliveChannel, throttledInvalidate);
}
export { useCodespacesData as a, useCodespacesAlive as i, isCachingEnabled as n, useInvalidateCodespacesData as o, isReactCodespacesTabEnabled as r, usePrefetchCodespacesData as s, buildCodespacesPath as t };
