import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { l as ListView } from "./server-MainContent-ouZQ_bM_-DHVoK7D7.js";
import { n as ListViewMetadata } from "./server-query-DlQMbiaN-CidcEdMM.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var PullsListLoadingSkeleton_module_default = {
	pullsListContainer: "PullsListLoadingSkeleton-module_-oUSDa_pullsListContainer",
	skeletonDescription: "PullsListLoadingSkeleton-module_-oUSDa_skeletonDescription",
	skeletonHeader: "PullsListLoadingSkeleton-module_-oUSDa_skeletonHeader",
	skeletonItem: "PullsListLoadingSkeleton-module_-oUSDa_skeletonItem",
	skeletonMetadata: "PullsListLoadingSkeleton-module_-oUSDa_skeletonMetadata"
};
function PullsListLoadingSkeleton() {
	const metadata = /* @__PURE__ */ jsx(ListViewMetadata, {
		title: /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "Loading pull requests"
		}), /* @__PURE__ */ jsx(SkeletonBox, {
			width: "80px",
			height: "20px"
		})] }),
		children: /* @__PURE__ */ jsx(SkeletonBox, {
			width: "120px",
			height: "32px"
		})
	});
	return /* @__PURE__ */ jsx("div", {
		className: "tmp-my-3",
		children: /* @__PURE__ */ jsx("div", {
			className: PullsListLoadingSkeleton_module_default.pullsListContainer,
			children: /* @__PURE__ */ jsx(ListView, {
				metadata,
				title: "Loading pull requests",
				titleHeaderTag: "h2",
				children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("div", {
					className: PullsListLoadingSkeleton_module_default.skeletonItem,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: PullsListLoadingSkeleton_module_default.skeletonHeader,
							children: [/* @__PURE__ */ jsx(SkeletonBox, {
								width: "20px",
								height: "20px"
							}), /* @__PURE__ */ jsx(SkeletonBox, {
								width: "60%",
								height: "20px"
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: PullsListLoadingSkeleton_module_default.skeletonDescription,
							children: /* @__PURE__ */ jsx(SkeletonBox, {
								width: "80%",
								height: "16px"
							})
						}),
						/* @__PURE__ */ jsxs("div", {
							className: PullsListLoadingSkeleton_module_default.skeletonMetadata,
							children: [
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								}),
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								}),
								/* @__PURE__ */ jsx(SkeletonBox, {
									width: "80px",
									height: "16px"
								})
							]
						})
					]
				}) }, `skeleton-item-${i}`))
			})
		})
	});
}
PullsListLoadingSkeleton.displayName = "PullsListLoadingSkeleton";
export { PullsListLoadingSkeleton as t };
