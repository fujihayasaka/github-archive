performance.mark("js-parse-end:server-color-modes-BNonmdiP-NFEBswin.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as getCookie } from "./server-request-C9AEnFH8-C42vJH27.js";
performance.mark("js-parse-end:color-modes-BNonmdiP.js");
function parseColorModesCookie(cookieValue) {
	try {
		const colorModes = JSON.parse(cookieValue);
		if (!colorModes?.color_mode || !colorModes.light_theme?.name || !colorModes.dark_theme?.name) return null;
		return {
			colorMode: colorModes.color_mode,
			lightTheme: colorModes.light_theme.name,
			darkTheme: colorModes.dark_theme.name
		};
	} catch {
		return null;
	}
}
function getColorModesHandler() {
	try {
		const colorModeCookie = getCookie("color_mode");
		return colorModeCookie ? parseColorModesCookie(colorModeCookie) : null;
	} catch {
		return null;
	}
}
var getColorModes_createServerFn_handler = createServerRpc({
	id: "ef4114798e0b83bf658371727c8c96649edc020f02b6ff83ac0124a900a0ded0",
	name: "getColorModes",
	filename: "src/routes/root/color-modes.ts"
}, (opts) => getColorModes.__executeServer(opts));
var getColorModes = createServerFn().handler(getColorModes_createServerFn_handler, getColorModesHandler);
export { getColorModes_createServerFn_handler };
