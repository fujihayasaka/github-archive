import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Dn as MarkGithubIcon, Dt as FileIcon, F as ChevronDownIcon, H as CodeIcon, Jn as PaperAirplaneIcon, Jt as GitPullRequestIcon, Mi as XIcon, Or as ShieldIcon, Qt as Heading$2, R as ChevronUpIcon, Sn as LinkIcon, Ut as GitCommitIcon, X as CommentDiscussionIcon, Yn as PaperclipIcon, Yt as GlobeIcon, Z as CommentIcon, Zt as HashIcon, _i as Truncate, _n as KebabHorizontalIcon, a as AlertFillIcon, ai as TasklistIcon, an as IconButton, ar as PlusIcon, b as BookIcon, bn as Link, cn as InfoIcon, fn as IssueOpenedIcon, gr as RepoIcon, i as AgentIcon, ii as TagIcon, kr as ShieldLockIcon, li as ThumbsdownIcon, mi as TrashIcon, n as ActionList, ni as SyncIcon, o as AlertIcon, qr as Stack, rr as PlayIcon, ui as ThumbsupIcon, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Portal } from "./server-Portal-BhFOPOrj-e1Gwag3s.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as Details } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { $ as referencePath, E as getCopilotExperiments, L as isAgent, M as getRenderableReferences, Q as referenceName, T as findAuthor, X as referenceFileName, Z as referenceID, b as copilotFeatureFlags, ct as threadName, et as referenceURL, h as NullMessageId, lt as validReferenceURL, rt as setCopilotExperiments, s as DialogType, y as buildMessage } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as announceFromElement$1, t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { n as readOnly, r as spacingControls } from "./server-readonly-G_4lcq4K-NnVP_IuN.js";
import { a as scrollerAttributes, i as loadLanguage, n as basicSetup, o as secretDetectedListener, r as getTheme, t as CodeMirror } from "./server-CodeMirror-BtlhKpYu-BOBEUoQl.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as ToggleSwitch } from "./server-ToggleSwitch-ouBLvY5S-LRpaQ39O.js";
import { C as useChatStateValues, D as useGetChatState, b as useChatState, p as getActiveMessages, y as useChatManager } from "./server-CopilotChatContext-Cxy8NE69-vuYiAx41.js";
import { n as ActionMenuOverlay, p as ModelPicker } from "./server-TaskChatInputToolbar-xO96qg7U-00kuFnPA.js";
import { b as iconForReference, j as userMessageParser, p as UserMessage_module_default, s as FigmaIcon, t as BingIcon, u as ReferenceToken, v as getSelectedThread, x as useAvailableAgents, y as hasPotentialAgentMention } from "./server-ChatInput-DNU7qLKC-DqztNW8O.js";
import { c as thumbsUpIcon, s as thumbsDownIcon, t as UserFeedback } from "./server-UserFeedback-kIRVi6Wu-D1dZx8ou.js";
import { c as useChatScroll, i as InterviewSurveyDialog, o as useActivePlugin, s as useChatMessage } from "./server-PersonalInstructionsDialog-31usJWBy-DGjuoNqn.js";
import { n as CopilotAnimationType, t as CopilotAnimation } from "./server-CopilotAnimation-DOXbbPXC-CqTp-mSh.js";
import { n as MarkdownRenderer } from "./server-MarkdownRenderer-CWn3CeTy-lToasg6Z.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import React, { memo, useCallback, useEffect, useId, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { c as c$1 } from "react/compiler-runtime";
import { EditorView } from "@codemirror/view";
import { Compartment } from "@codemirror/state";
import { unified } from "unified";
import { MergeView, unifiedMergeView } from "@codemirror/merge";
function useDetails(t0) {
	const $ = c(15);
	const { ref, closeOnOutsideClick, defaultOpen, onClickOutside } = t0;
	const [open, setOpen] = useState(defaultOpen);
	const backupRef = useRef(null);
	const customRef = ref !== null && ref !== void 0 ? ref : backupRef;
	let t1;
	if ($[0] !== customRef || $[1] !== onClickOutside) {
		t1 = (event) => {
			const { current } = customRef;
			if (event.target.closest("details") !== current) {
				onClickOutside && onClickOutside(event);
				if (!event.defaultPrevented) setOpen(false);
			}
		};
		$[0] = customRef;
		$[1] = onClickOutside;
		$[2] = t1;
	} else t1 = $[2];
	const onClickOutsideInternal = t1;
	let t2;
	let t3;
	if ($[3] !== closeOnOutsideClick || $[4] !== onClickOutsideInternal || $[5] !== open) {
		t2 = () => {
			if (open && closeOnOutsideClick) {
				document.addEventListener("click", onClickOutsideInternal);
				return () => {
					document.removeEventListener("click", onClickOutsideInternal);
				};
			}
		};
		t3 = [
			open,
			closeOnOutsideClick,
			onClickOutsideInternal
		];
		$[3] = closeOnOutsideClick;
		$[4] = onClickOutsideInternal;
		$[5] = open;
		$[6] = t2;
		$[7] = t3;
	} else {
		t2 = $[6];
		t3 = $[7];
	}
	useEffect(t2, t3);
	let t4;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = (e) => {
			if (!e.defaultPrevented) {
				const eventTarget_0 = e.target;
				setOpen(eventTarget_0.open);
			}
		};
		$[8] = t4;
	} else t4 = $[8];
	const handleToggle = t4;
	let t5;
	if ($[9] !== customRef || $[10] !== open) {
		t5 = () => ({
			onToggle: handleToggle,
			open,
			ref: customRef
		});
		$[9] = customRef;
		$[10] = open;
		$[11] = t5;
	} else t5 = $[11];
	const getDetailsProps = t5;
	let t6;
	if ($[12] !== getDetailsProps || $[13] !== open) {
		t6 = {
			open,
			setOpen,
			getDetailsProps
		};
		$[12] = getDetailsProps;
		$[13] = open;
		$[14] = t6;
	} else t6 = $[14];
	return t6;
}
function useChat(inputRef) {
	const $ = c$1(26);
	const state = useChatState();
	const manager = useChatManager();
	const { currentTopic, messages, selectedThreadID } = state;
	let t0;
	if ($[0] !== state) {
		t0 = getSelectedThread(state);
		$[0] = state;
		$[1] = t0;
	} else t0 = $[1];
	const thread = t0;
	const chatTextAreaRef = useRef(null);
	const textAreaRef = inputRef || chatTextAreaRef;
	let t1;
	let t2;
	if ($[2] !== manager || $[3] !== messages.length || $[4] !== thread) {
		t1 = () => {
			if (thread && messages.length > 0) manager.showTopicPicker(false);
		};
		t2 = [
			thread,
			messages.length,
			manager
		];
		$[2] = manager;
		$[3] = messages.length;
		$[4] = thread;
		$[5] = t1;
		$[6] = t2;
	} else {
		t1 = $[5];
		t2 = $[6];
	}
	useEffect(t1, t2);
	let t3;
	let t4;
	if ($[7] !== currentTopic || $[8] !== selectedThreadID) {
		t3 = () => {
			const topicID = currentTopic ? String(currentTopic.id) : null;
			if (selectedThreadID && topicID) copilotLocalStorage.setSelectedTopic(selectedThreadID, topicID);
		};
		t4 = [selectedThreadID, currentTopic];
		$[7] = currentTopic;
		$[8] = selectedThreadID;
		$[9] = t3;
		$[10] = t4;
	} else {
		t3 = $[9];
		t4 = $[10];
	}
	useEffect(t3, t4);
	let t5;
	let t6;
	if ($[11] !== textAreaRef) {
		t5 = () => {
			const timeout = window.setTimeout(() => {
				textAreaRef.current?.focus();
			}, 1);
			return () => {
				window.clearTimeout(timeout);
			};
		};
		t6 = [textAreaRef];
		$[11] = textAreaRef;
		$[12] = t5;
		$[13] = t6;
	} else {
		t5 = $[12];
		t6 = $[13];
	}
	useEffect(t5, t6);
	let t7;
	if ($[14] !== manager || $[15] !== state.context?.[0] || $[16] !== state.currentRepository) {
		t7 = () => {
			const generateSuggestions = () => {
				const suggestionContext = state.context?.[0] ?? state.currentRepository;
				if (!suggestionContext) return;
				manager.generateSuggestions(suggestionContext);
			};
			generateSuggestions();
			return () => {
				manager.clearSuggestions();
			};
		};
		$[14] = manager;
		$[15] = state.context?.[0];
		$[16] = state.currentRepository;
		$[17] = t7;
	} else t7 = $[17];
	let t8;
	if ($[18] !== manager || $[19] !== state.context || $[20] !== state.currentRepository || $[21] !== state.currentTopic || $[22] !== state.selectedThreadID) {
		t8 = [
			manager,
			state.context,
			state.currentTopic,
			state.currentRepository,
			state.selectedThreadID
		];
		$[18] = manager;
		$[19] = state.context;
		$[20] = state.currentRepository;
		$[21] = state.currentTopic;
		$[22] = state.selectedThreadID;
		$[23] = t8;
	} else t8 = $[23];
	useEffect(t7, t8);
	let t9;
	if ($[24] !== textAreaRef) {
		t9 = { textAreaRef };
		$[24] = textAreaRef;
		$[25] = t9;
	} else t9 = $[25];
	return t9;
}
var ChatMessagesGroup = (t0) => {
	const $ = c$1(8);
	const { isLastGroup, children } = t0;
	const { scrollContainerHeight, scrollToBottom } = useChatScroll();
	const { threadHasNewMessages, pendingFirstMessage } = useChatStateValues("threadHasNewMessages", "pendingFirstMessage");
	const fillViewport = isLastGroup && (threadHasNewMessages || pendingFirstMessage);
	let t1;
	let t2;
	if ($[0] !== fillViewport || $[1] !== scrollToBottom) {
		t1 = () => {
			if (fillViewport) scrollToBottom("smooth");
		};
		t2 = [fillViewport, scrollToBottom];
		$[0] = fillViewport;
		$[1] = scrollToBottom;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] !== children || $[5] !== fillViewport || $[6] !== scrollContainerHeight) {
		let style = void 0;
		if (fillViewport) if (ssrSafeWindow?.CSS?.supports("container-type: size")) style = { minHeight: "100cqh" };
		else style = { minHeight: scrollContainerHeight };
		t3 = jsx("div", {
			style,
			children
		});
		$[4] = children;
		$[5] = fillViewport;
		$[6] = scrollContainerHeight;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
};
/** Each group is a set of user requests followed by assistant responses. */
ChatMessagesGroup.displayName = "ChatMessagesGroup";
function groupChatMessages(messages) {
	return messages.reduce((groups, message) => {
		const lastGroup = groups.at(-1);
		if ((lastGroup?.at(-1)?.role ?? "assistant") === "assistant" && message.role === "user") groups.push([message]);
		else lastGroup?.push(message);
		return groups;
	}, []);
}
function useGroupedMessages(state) {
	const $ = c$1(14);
	const { streamingMessage, isWaitingOnCopilot, messages: completedMessages, selectedThreadID, pendingFirstMessage } = state;
	let t0;
	if ($[0] !== completedMessages || $[1] !== isWaitingOnCopilot || $[2] !== pendingFirstMessage || $[3] !== selectedThreadID || $[4] !== streamingMessage) {
		bb0: {
			const t1 = selectedThreadID || "";
			let t2;
			if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
				t2 = [];
				$[6] = t2;
			} else t2 = $[6];
			let t3;
			if ($[7] !== t1) {
				t3 = {
					id: NullMessageId,
					role: "assistant",
					content: "",
					createdAt: "",
					threadID: t1,
					references: t2,
					clientSide: true,
					messageIndex: -1
				};
				$[7] = t1;
				$[8] = t3;
			} else t3 = $[8];
			const nullMessage = t3;
			const activeMessages = getActiveMessages(completedMessages, pendingFirstMessage);
			if (isWaitingOnCopilot) {
				t0 = [...activeMessages, streamingMessage ?? nullMessage];
				break bb0;
			}
			t0 = activeMessages;
		}
		$[0] = completedMessages;
		$[1] = isWaitingOnCopilot;
		$[2] = pendingFirstMessage;
		$[3] = selectedThreadID;
		$[4] = streamingMessage;
		$[5] = t0;
	} else t0 = $[5];
	const messages = t0;
	let t1;
	if ($[9] !== messages) {
		t1 = groupChatMessages(messages);
		$[9] = messages;
		$[10] = t1;
	} else t1 = $[10];
	let t2;
	if ($[11] !== messages || $[12] !== t1) {
		t2 = {
			messages,
			groupedMessages: t1
		};
		$[11] = messages;
		$[12] = t1;
		$[13] = t2;
	} else t2 = $[13];
	return t2;
}
var AmbientErrorBanner_module_default = {
	ambientErrorBanner: "AmbientErrorBanner-module_OS6ItW_ambientErrorBanner",
	largeBorderRadius: "AmbientErrorBanner-module_OS6ItW_largeBorderRadius",
	mediumBorderRadius: "AmbientErrorBanner-module_OS6ItW_mediumBorderRadius"
};
function AmbientErrorBanner({ ambientError, useLargerBorderRadius = false }) {
	const chatManager = useChatManager();
	const [bannerKey, setBannerKey] = useState(0);
	const borderRadiusClass = useLargerBorderRadius ? AmbientErrorBanner_module_default.largeBorderRadius : AmbientErrorBanner_module_default.mediumBorderRadius;
	const errorMessageRef = useRef(null);
	useEffect(() => {
		if (ambientError.message) {
			setBannerKey((prev) => prev + 1);
			const timeoutId = setTimeout(() => {
				if (errorMessageRef.current) errorMessageRef.current.focus();
			}, 250);
			return () => clearTimeout(timeoutId);
		}
	}, [ambientError]);
	return /* @__PURE__ */ jsx(Banner, {
		"aria-atomic": "true",
		className: `${AmbientErrorBanner_module_default.ambientErrorBanner} ${borderRadiusClass}`,
		description: /* @__PURE__ */ jsx("div", {
			ref: errorMessageRef,
			tabIndex: -1,
			style: { outline: "none" },
			children: ambientError.message
		}),
		variant: "critical",
		title: "Error during copilot chat has occurred.",
		hideTitle: true,
		onDismiss: () => {
			chatManager.dismissAmbientError();
		}
	}, bannerKey);
}
AmbientErrorBanner.displayName = "AmbientErrorBanner";
function capitalize(s) {
	return s.charAt(0).toUpperCase() + s.slice(1);
}
function useChatMessageBehavior(t0) {
	const $ = c$1(69);
	const { excludeFeedback, inputRef, isLatestMessage, isStreaming, removeOutdatedContentPreviewItems } = t0;
	const { message } = useChatMessage();
	const state = useChatStateValues("currentUserLogin", "mode");
	const getChatState = useGetChatState();
	const manager = useChatManager();
	const plugin = useActivePlugin();
	let author;
	let isCopilot;
	let isUser;
	let t1;
	if ($[0] !== message || $[1] !== state.currentUserLogin) {
		author = findAuthor(message, state.currentUserLogin);
		isCopilot = author.name === "Copilot";
		isUser = author.type === "user";
		t1 = isCopilot || isAgent(author);
		$[0] = message;
		$[1] = state.currentUserLogin;
		$[2] = author;
		$[3] = isCopilot;
		$[4] = isUser;
		$[5] = t1;
	} else {
		author = $[2];
		isCopilot = $[3];
		isUser = $[4];
		t1 = $[5];
	}
	const isAI = t1;
	const isAgentError = isCopilot && !!message.agentErrors?.length;
	const isError = !isAgentError && isCopilot && message.error ? message.error.isError : false;
	const renderFeedback = isCopilot && !excludeFeedback && (!isLatestMessage || !isStreaming) && !isError;
	const myRef = useRef(null);
	const isInterrupted = message.interrupted;
	const hasClientConfirmations = message.clientConfirmations && message.clientConfirmations.length > 0;
	const isErrorRetryable = isError && message.error?.retryable;
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[6] = t2;
	} else t2 = $[6];
	const [shownSkillExecutionsForRespondingText, setShownSkillExecutionsForRespondingText] = useState(t2);
	const [skillExecutionToUseForRespondingText, setSkillExecutionToUseForRespondingText] = useState(void 0);
	const showRetryButton = (isErrorRetryable || isInterrupted) && isLatestMessage;
	const isLatestStreamingMessage = isLatestMessage && isStreaming;
	const pluginMarkdownExtensions = plugin?.markdownExtensions;
	const t3 = state.mode === "assistive";
	let t4;
	if ($[7] !== pluginMarkdownExtensions) {
		t4 = pluginMarkdownExtensions ? pluginMarkdownExtensions.map(_temp$4) : [];
		$[7] = pluginMarkdownExtensions;
		$[8] = t4;
	} else t4 = $[8];
	let t5;
	if ($[9] !== isLatestStreamingMessage || $[10] !== t3 || $[11] !== t4) {
		t5 = {
			openLinksInCurrentTab: t3,
			isStreaming: isLatestStreamingMessage,
			extensions: t4
		};
		$[9] = isLatestStreamingMessage;
		$[10] = t3;
		$[11] = t4;
		$[12] = t5;
	} else t5 = $[12];
	const rendererConfig = t5;
	const shouldShowMessageActions = !isError && (renderFeedback || isAI && !!message.content && !isStreaming) && (!isUser || !message.confirmations) || isUser && !isLatestMessage || isError && isLatestMessage;
	const lastSkillUpdateTime = useRef(0);
	let t6;
	if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => {
			setSkillExecutionToUseForRespondingText(void 0);
			setShownSkillExecutionsForRespondingText([]);
		};
		$[13] = t6;
	} else t6 = $[13];
	let t7;
	if ($[14] !== message.id) {
		t7 = [message.id];
		$[14] = message.id;
		$[15] = t7;
	} else t7 = $[15];
	useEffect(t6, t7);
	let t8;
	let t9;
	if ($[16] !== message.skillExecutions || $[17] !== shownSkillExecutionsForRespondingText) {
		t8 = () => {
			const skillExecutionToUse = (message.skillExecutions ?? []).find((skillExecution) => !shownSkillExecutionsForRespondingText.some((shownSkillExecution) => {
				return (!(shownSkillExecution.callId !== void 0 && skillExecution.callId !== void 0) || shownSkillExecution.callId === skillExecution.callId) && shownSkillExecution.slug === skillExecution.slug && shownSkillExecution.statusMessage === skillExecution.statusMessage;
			}));
			if (skillExecutionToUse) {
				const timeElapsedSinceLastUpdate = Date.now() - lastSkillUpdateTime.current;
				const timeToWait = Math.max(0, 2e3 - timeElapsedSinceLastUpdate);
				const timer = setTimeout(() => {
					lastSkillUpdateTime.current = Date.now();
					setShownSkillExecutionsForRespondingText([...shownSkillExecutionsForRespondingText, skillExecutionToUse]);
					setSkillExecutionToUseForRespondingText(skillExecutionToUse);
				}, timeToWait);
				return () => clearTimeout(timer);
			}
		};
		t9 = [message.skillExecutions, shownSkillExecutionsForRespondingText];
		$[16] = message.skillExecutions;
		$[17] = shownSkillExecutionsForRespondingText;
		$[18] = t8;
		$[19] = t9;
	} else {
		t8 = $[18];
		t9 = $[19];
	}
	useEffect(t8, t9);
	let t10;
	let t11;
	if ($[20] !== isLatestStreamingMessage) {
		t10 = () => {
			if (isLatestStreamingMessage) announce$1("Copilot is responding");
		};
		t11 = [isLatestStreamingMessage];
		$[20] = isLatestStreamingMessage;
		$[21] = t10;
		$[22] = t11;
	} else {
		t10 = $[21];
		t11 = $[22];
	}
	useEffect(t10, t11);
	let t12;
	let t13;
	if ($[23] !== isLatestMessage || $[24] !== isStreaming) {
		t12 = () => {
			if (isLatestMessage && !isStreaming && myRef.current) announceFromElement$1(myRef.current);
		};
		t13 = [isLatestMessage, isStreaming];
		$[23] = isLatestMessage;
		$[24] = isStreaming;
		$[25] = t12;
		$[26] = t13;
	} else {
		t12 = $[25];
		t13 = $[26];
	}
	useEffect(t12, t13);
	let t14;
	if ($[27] !== author.name || $[28] !== getChatState || $[29] !== manager || $[30] !== message.references) {
		t14 = async (clientConfirmation, confirmationTitle, onSubmit) => {
			if (onSubmit) onSubmit(clientConfirmation.state === "accepted");
			else {
				const localState = getChatState();
				await manager.sendChatMessage({
					thread: getSelectedThread(localState),
					content: `@${author.name} ${capitalize(clientConfirmation.state)} Confirmation: ${confirmationTitle}`,
					references: message.references ?? [],
					topic: localState.currentTopic,
					context: localState.context,
					confirmations: clientConfirmation,
					customInstructions: localState.customInstructions,
					model: localState.model
				});
			}
		};
		$[27] = author.name;
		$[28] = getChatState;
		$[29] = manager;
		$[30] = message.references;
		$[31] = t14;
	} else t14 = $[31];
	const handleConfirmationAction = t14;
	let t15;
	if ($[32] !== inputRef) {
		t15 = () => {
			window.setTimeout(() => inputRef?.current?.focus(), 1);
		};
		$[32] = inputRef;
		$[33] = t15;
	} else t15 = $[33];
	const focusChatInput = t15;
	let t16;
	if ($[34] !== focusChatInput || $[35] !== getChatState || $[36] !== manager || $[37] !== removeOutdatedContentPreviewItems) {
		t16 = async () => {
			const localState_0 = getChatState();
			const thread = getSelectedThread(localState_0);
			if (!thread) return;
			removeOutdatedContentPreviewItems?.();
			focusChatInput();
			sendEvent("dotcom_chat.activate", {
				target: "RESPONSE_ACTION_RETRY",
				mode: localState_0.mode
			});
			await manager.retryLastUnsuccessfulChatMessage(thread);
		};
		$[34] = focusChatInput;
		$[35] = getChatState;
		$[36] = manager;
		$[37] = removeOutdatedContentPreviewItems;
		$[38] = t16;
	} else t16 = $[38];
	const handleRetryErrorMessage = t16;
	let t17;
	if ($[39] !== focusChatInput || $[40] !== getChatState || $[41] !== manager || $[42] !== message || $[43] !== removeOutdatedContentPreviewItems) {
		t17 = async (model) => {
			const localState_1 = getChatState();
			const thread_0 = getSelectedThread(localState_1);
			if (!thread_0) return;
			removeOutdatedContentPreviewItems?.();
			focusChatInput();
			sendEvent("dotcom_chat.activate", {
				target: "RESPONSE_ACTION_RETRY_FOR_NEW_SUBTHREAD",
				mode: localState_1.mode
			});
			await manager.retryUserChatMessage(thread_0, message, model);
		};
		$[39] = focusChatInput;
		$[40] = getChatState;
		$[41] = manager;
		$[42] = message;
		$[43] = removeOutdatedContentPreviewItems;
		$[44] = t17;
	} else t17 = $[44];
	const handleRetryCopilotResponse = t17;
	let t18;
	if ($[45] !== getChatState || $[46] !== manager || $[47] !== message || $[48] !== removeOutdatedContentPreviewItems) {
		t18 = async (editedValue) => {
			const thread_1 = getSelectedThread(getChatState());
			if (!thread_1) return;
			removeOutdatedContentPreviewItems?.();
			await manager.editUserChatMessage(thread_1, message, editedValue);
		};
		$[45] = getChatState;
		$[46] = manager;
		$[47] = message;
		$[48] = removeOutdatedContentPreviewItems;
		$[49] = t18;
	} else t18 = $[49];
	const handleEditUserMessage = t18;
	let t19;
	if ($[50] !== author || $[51] !== handleConfirmationAction || $[52] !== handleEditUserMessage || $[53] !== handleRetryCopilotResponse || $[54] !== handleRetryErrorMessage || $[55] !== hasClientConfirmations || $[56] !== isAI || $[57] !== isAgentError || $[58] !== isCopilot || $[59] !== isError || $[60] !== isInterrupted || $[61] !== isUser || $[62] !== removeOutdatedContentPreviewItems || $[63] !== renderFeedback || $[64] !== rendererConfig || $[65] !== shouldShowMessageActions || $[66] !== showRetryButton || $[67] !== skillExecutionToUseForRespondingText) {
		t19 = {
			author,
			removeOutdatedContentPreviewItems,
			handleConfirmationAction,
			handleRetryErrorMessage,
			handleRetryCopilotResponse,
			handleEditUserMessage,
			hasClientConfirmations,
			isCopilot,
			isUser,
			isAI,
			isAgentError,
			isError,
			isInterrupted,
			myRef,
			rendererConfig,
			renderFeedback,
			shouldShowMessageActions,
			skillExecutionToUseForRespondingText,
			showRetryButton
		};
		$[50] = author;
		$[51] = handleConfirmationAction;
		$[52] = handleEditUserMessage;
		$[53] = handleRetryCopilotResponse;
		$[54] = handleRetryErrorMessage;
		$[55] = hasClientConfirmations;
		$[56] = isAI;
		$[57] = isAgentError;
		$[58] = isCopilot;
		$[59] = isError;
		$[60] = isInterrupted;
		$[61] = isUser;
		$[62] = removeOutdatedContentPreviewItems;
		$[63] = renderFeedback;
		$[64] = rendererConfig;
		$[65] = shouldShowMessageActions;
		$[66] = showRetryButton;
		$[67] = skillExecutionToUseForRespondingText;
		$[68] = t19;
	} else t19 = $[68];
	return t19;
}
function _temp$4(extension) {
	return extension();
}
var ChatImage_module_default = {
	assistive: "ChatImage-module_u_Sp9W_assistive",
	chatImageAttachment: "ChatImage-module_u_Sp9W_chatImageAttachment",
	expandIcon: "ChatImage-module_u_Sp9W_expandIcon",
	fullView: "ChatImage-module_u_Sp9W_fullView",
	overlay: "ChatImage-module_u_Sp9W_overlay",
	overlayScreen: "ChatImage-module_u_Sp9W_overlayScreen",
	squareView: "ChatImage-module_u_Sp9W_squareView",
	userAttachedImage: "ChatImage-module_u_Sp9W_userAttachedImage"
};
function ExpandIcon({ className, size }) {
	return /* @__PURE__ */ jsx("svg", {
		className,
		xmlns: "http://www.w3.org/2000/svg",
		width: size || 14,
		height: size || 14,
		fill: "none",
		viewBox: "0 0 14 14",
		role: "presentation",
		children: /* @__PURE__ */ jsx("path", {
			fill: "currentColor",
			fillRule: "evenodd",
			d: "M13.672 5.342a.8.8 0 0 0 .05-.295V.805a.75.75 0 0 0-.75-.75H8.73a.75.75 0 0 0 0 1.5h2.433L8.138 4.577A.75.75 0 0 0 9.2 5.638l3.024-3.023v2.432a.75.75 0 0 0 1.45.295M.328 8.657a.8.8 0 0 0-.05.295v4.243a.75.75 0 0 0 .75.75h4.243a.75.75 0 0 0 0-1.5H2.838l3.024-3.023A.75.75 0 1 0 4.8 8.362l-3.024 3.023V8.952a.75.75 0 0 0-1.45-.295",
			clipRule: "evenodd"
		})
	});
}
ExpandIcon.displayName = "ExpandIcon";
var ChatImageUnmemoized = (t0) => {
	const $ = c$1(10);
	const { src, alt, onClick, useOverlay, mode, squareView } = t0;
	const [isHovered, setIsHovered] = useState(false);
	if (!src) return null;
	let t1;
	if ($[0] !== alt || $[1] !== isHovered || $[2] !== mode || $[3] !== onClick || $[4] !== squareView || $[5] !== src || $[6] !== useOverlay) {
		let t2;
		let t3;
		if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = () => setIsHovered(true);
			t3 = () => setIsHovered(false);
			$[8] = t2;
			$[9] = t3;
		} else {
			t2 = $[8];
			t3 = $[9];
		}
		t1 = jsxs("div", {
			className: clsx(ChatImage_module_default.chatImageAttachment, squareView ? ChatImage_module_default.squareView : ChatImage_module_default.fullView, { assistive: mode === "assistive" }),
			children: [jsx("img", {
				className: clsx(ChatImage_module_default.userAttachedImage, squareView ? ChatImage_module_default.squareView : ChatImage_module_default.fullView),
				src,
				alt
			}), jsx("a", {
				href: src,
				className: clsx(ChatImage_module_default.overlay, {
					hovered: isHovered,
					[ChatImage_module_default.squareView]: squareView
				}),
				onClick,
				onMouseEnter: t2,
				onMouseLeave: t3,
				"aria-label": "Open image thumbnail",
				target: "_blank",
				rel: "noreferrer",
				children: useOverlay && jsxs(Fragment$1, { children: [jsx("div", { className: ChatImage_module_default.overlayScreen }), jsx(ExpandIcon, {
					className: ChatImage_module_default.expandIcon,
					size: 20
				})] })
			})]
		});
		$[0] = alt;
		$[1] = isHovered;
		$[2] = mode;
		$[3] = onClick;
		$[4] = squareView;
		$[5] = src;
		$[6] = useOverlay;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
};
ChatImageUnmemoized.displayName = "ChatImageUnmemoized";
var ChatImage = memo(ChatImageUnmemoized);
ChatImage.displayName = "ChatImage";
var agentUnauthorizedAvatar = "ChatMessage-module_m3u25G_agentUnauthorizedAvatar";
var ai = "ChatMessage-module_m3u25G_ai";
var avatar = "ChatMessage-module_m3u25G_avatar";
var clientConfirmationContainer = "ChatMessage-module_m3u25G_clientConfirmationContainer";
var clientConfirmationUser = "ChatMessage-module_m3u25G_clientConfirmationUser";
var confirmationStatusText = "ChatMessage-module_m3u25G_confirmationStatusText";
var contentContainer = "ChatMessage-module_m3u25G_contentContainer";
var fileListItem = "ChatMessage-module_m3u25G_fileListItem";
var floatingActions = "ChatMessage-module_m3u25G_floatingActions";
var hasClientConfirmations = "ChatMessage-module_m3u25G_hasClientConfirmations";
var message = "ChatMessage-module_m3u25G_message";
var messageActionsContainer = "ChatMessage-module_m3u25G_messageActionsContainer";
var messageContainer = "ChatMessage-module_m3u25G_messageContainer";
var messageContent = "ChatMessage-module_m3u25G_messageContent";
var messageContentWrapper = "ChatMessage-module_m3u25G_messageContentWrapper";
var skillExecutionText = "ChatMessage-module_m3u25G_skillExecutionText";
var user = "ChatMessage-module_m3u25G_user";
var ChatMessage_module_default = {
	agentUnauthorizedAvatar,
	ai,
	avatar,
	clientConfirmationContainer,
	clientConfirmationUser,
	confirmationStatusText,
	contentContainer,
	fileListItem,
	floatingActions,
	hasClientConfirmations,
	message,
	"message-action": "ChatMessage-module_m3u25G_message-action",
	messageActionsContainer,
	messageContainer,
	messageContent,
	messageContentWrapper,
	skillExecutionText,
	"snippet-clipboard-content": "ChatMessage-module_m3u25G_snippet-clipboard-content",
	user
};
var ChatReference_module_default = { ActionList_LinkItem: "ChatReference-module_Lr4G8W_ActionList_LinkItem" };
function OutputReference({ reference, onClick }) {
	const state = useChatState();
	const manager = useChatManager();
	const actionButtonRef = useRef(null);
	const [moreMenuOpen, setMoreMenuOpen] = useState(false);
	const mode = state?.mode ?? "assistive";
	const { currentReferences } = state ?? { currentReferences: [] };
	const selectedRefIDs = useMemo(() => currentReferences.map((r) => referenceID(r)), [currentReferences]);
	const thisRefID = useMemo(() => referenceID(reference), [reference]);
	const isRepoInstructions = useMemo(() => reference.type === "repo-instructions", [reference]);
	const isOrgInstructions = useMemo(() => reference.type === "org-instructions", [reference]);
	const showTrailingVisual = !isRepoInstructions && !isOrgInstructions && reference.type !== "web-search-result";
	const isInCurrentReferences = useMemo(() => isRepoInstructions || isOrgInstructions || selectedRefIDs.includes(thisRefID), [
		isRepoInstructions,
		isOrgInstructions,
		selectedRefIDs,
		thisRefID
	]);
	const handleAddReference = useCallback((e) => {
		e.stopPropagation();
		if (isInCurrentReferences) return;
		manager.addReference(reference, "refMenu");
	}, [
		manager,
		reference,
		isInCurrentReferences
	]);
	const refURL = referenceURL(reference);
	const validURL = validReferenceURL(refURL);
	const Icon = iconForReference(reference);
	let filePath;
	switch (reference.type) {
		case "file":
		case "snippet": {
			filePath = `${reference.repoName}`;
			const index = reference.path.lastIndexOf("/");
			if (index !== -1) filePath = `${filePath}/${reference.path.substring(0, index)}`;
			break;
		}
		case "web-search-result":
			filePath = new URL(reference.url, window.location.origin).hostname.replace(/^www\./, "");
			break;
	}
	const referenceTitle = referenceName(reference);
	return /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		onClick: (e_0) => {
			if (onClick && !e_0.defaultPrevented) onClick(reference, e_0);
		},
		href: refURL,
		rel: "noopener",
		className: clsx("reference-action", ChatReference_module_default.ActionList_LinkItem),
		target: mode === "immersive" || reference.type === "third-party" ? "_blank" : void 0,
		children: [
			Icon && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }),
			/* @__PURE__ */ jsxs(Truncate, {
				title: referenceTitle,
				maxWidth: "100%",
				className: "text-semibold",
				children: [referenceTitle, filePath && /* @__PURE__ */ jsx("span", {
					className: "color-fg-muted ml-2",
					children: filePath
				})]
			}),
			showTrailingVisual && /* @__PURE__ */ jsx(ActionList.TrailingAction, {
				onClick: () => setMoreMenuOpen(true),
				icon: KebabHorizontalIcon,
				label: "More reference options",
				ref: actionButtonRef
			}),
			showTrailingVisual && /* @__PURE__ */ jsx(ActionMenu, {
				anchorRef: actionButtonRef,
				open: moreMenuOpen,
				onOpenChange: setMoreMenuOpen,
				children: /* @__PURE__ */ jsx(ActionMenuOverlay, {
					portalContainerName: "copilotChatMessagesMenuPortalRoot",
					children: /* @__PURE__ */ jsxs(ActionList, { children: [validURL && (mode === "immersive" || [
						"third-party",
						"folder",
						"repository"
					].includes(reference.type) ? /* @__PURE__ */ jsxs(ActionList.LinkItem, {
						href: refURL,
						rel: "noopener",
						target: "_blank",
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LinkIcon, {}) }), "Open"]
					}) : /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => {
							manager.selectReference(reference);
						},
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LinkIcon, {}) }), "Preview"]
					})), /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: handleAddReference,
						disabled: isInCurrentReferences,
						children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PaperclipIcon, {}) }), "Attach to chat"]
					})] })
				})
			})
		]
	});
}
OutputReference.displayName = "OutputReference";
var ActionList$1 = "ChatReferences-module_XL_EsW_ActionList";
var assistiveTitle = "ChatReferences-module_XL_EsW_assistiveTitle";
var chatMessageReferenceListFooter = "ChatReferences-module_XL_EsW_chatMessageReferenceListFooter";
var chevronDownIcon = "ChatReferences-module_XL_EsW_chevronDownIcon";
var chevronUpIcon = "ChatReferences-module_XL_EsW_chevronUpIcon";
var referencesContainer = "ChatReferences-module_XL_EsW_referencesContainer";
var referencesDetails = "ChatReferences-module_XL_EsW_referencesDetails";
var referencesListImmersiveContainer = "ChatReferences-module_XL_EsW_referencesListImmersiveContainer";
var referenceTokensContainer = "ChatReferences-module_XL_EsW_referenceTokensContainer";
var referenceTokensOuterContainer = "ChatReferences-module_XL_EsW_referenceTokensOuterContainer";
var title = "ChatReferences-module_XL_EsW_title";
var ChatReferences_module_default = {
	ActionList: ActionList$1,
	assistiveTitle,
	chatMessageReferenceListFooter,
	chevronDownIcon,
	chevronUpIcon,
	"references-chevron-down": "ChatReferences-module_XL_EsW_references-chevron-down",
	"references-chevron-up": "ChatReferences-module_XL_EsW_references-chevron-up",
	referencesContainer,
	referencesDetails,
	referencesListImmersiveContainer,
	referenceTokensContainer,
	referenceTokensOuterContainer,
	title
};
var FigmaChatReference_module_default = {
	content: "FigmaChatReference-module_nMaUaq_content",
	figmaIcon: "FigmaChatReference-module_nMaUaq_figmaIcon",
	figmaIconOuter: "FigmaChatReference-module_nMaUaq_figmaIconOuter",
	name: "FigmaChatReference-module_nMaUaq_name",
	referenceToken: "FigmaChatReference-module_nMaUaq_referenceToken",
	thumbnail: "FigmaChatReference-module_nMaUaq_thumbnail",
	thumbnailHidden: "FigmaChatReference-module_nMaUaq_thumbnailHidden",
	thumbnailLoading: "FigmaChatReference-module_nMaUaq_thumbnailLoading",
	thumbnailOuter: "FigmaChatReference-module_nMaUaq_thumbnailOuter"
};
function FigmaChatReference({ ref, reference, ...rest }) {
	const [thumbnailIsLoading, setThumbnailIsLoading] = useState(true);
	return /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsxs("a", {
		href: referenceURL(reference),
		className: clsx(FigmaChatReference_module_default.referenceToken),
		ref,
		target: "_blank",
		rel: "noreferrer",
		...rest,
		children: [/* @__PURE__ */ jsx("span", {
			className: FigmaChatReference_module_default.thumbnailOuter,
			children: reference.thumbnailUrl && /* @__PURE__ */ jsxs(Fragment$1, { children: [thumbnailIsLoading && /* @__PURE__ */ jsx("span", {
				className: FigmaChatReference_module_default.thumbnailLoading,
				children: /* @__PURE__ */ jsx(Spinner, { size: "medium" })
			}), /* @__PURE__ */ jsx("img", {
				className: clsx(FigmaChatReference_module_default.thumbnail, { [FigmaChatReference_module_default.thumbnailHidden]: thumbnailIsLoading }),
				src: reference.thumbnailUrl,
				alt: `preview thumbnail for ${reference.title}`,
				onLoad: () => setThumbnailIsLoading(false)
			})] })
		}), /* @__PURE__ */ jsxs("span", {
			className: FigmaChatReference_module_default.content,
			children: [/* @__PURE__ */ jsx("div", {
				className: FigmaChatReference_module_default.figmaIconOuter,
				children: /* @__PURE__ */ jsx(FigmaIcon, { className: FigmaChatReference_module_default.figmaIcon })
			}), /* @__PURE__ */ jsx("span", {
				className: FigmaChatReference_module_default.name,
				children: referenceName(reference)
			})]
		})]
	}) });
}
FigmaChatReference.displayName = "FigmaChatReference";
function Toolbar(props) {
	const { className, ...restProps } = props;
	const containerRef = useRef(null);
	useFocusZone({
		containerRef,
		focusInStrategy: "first",
		focusOutBehavior: "stop",
		bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd
	});
	return /* @__PURE__ */ jsx("div", {
		ref: containerRef,
		className,
		role: "toolbar",
		...restProps,
		children: props.children
	});
}
Toolbar.displayName = "Toolbar";
/** renders references for assistant messages */
function ChatMessageReferencesList(t0) {
	const $ = c$1(11);
	const { references, onToggle, onClick, isImmersive, className } = t0;
	let t1;
	if ($[0] !== references) {
		t1 = getRenderableReferences(references);
		$[0] = references;
		$[1] = t1;
	} else t1 = $[1];
	const renderableReferences = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = {};
		$[2] = t2;
	} else t2 = $[2];
	const { getDetailsProps } = useDetails(t2);
	if (renderableReferences.length === 0) return null;
	const title = `${renderableReferences.length} ${renderableReferences.length === 1 ? "reference" : "references"}`;
	let t3;
	if ($[3] !== className || $[4] !== getDetailsProps || $[5] !== isImmersive || $[6] !== onClick || $[7] !== onToggle || $[8] !== renderableReferences || $[9] !== title) {
		t3 = jsxs(Details, {
			...getDetailsProps(),
			onToggle,
			className: clsx(className, ChatReferences_module_default.referencesDetails),
			children: [jsxs("summary", {
				className: clsx(ChatReferences_module_default.referencesContainer),
				children: [
					jsx("span", {
						className: clsx(ChatReferences_module_default.title, isImmersive ? "" : ChatReferences_module_default.assistiveTitle),
						children: title
					}),
					jsx(Octicon, {
						icon: ChevronDownIcon,
						className: clsx("references-chevron-down", ChatReferences_module_default.chevronDownIcon)
					}),
					jsx(Octicon, {
						icon: ChevronUpIcon,
						className: clsx("references-chevron-up", ChatReferences_module_default.chevronUpIcon)
					})
				]
			}), jsx(ReferencesList, {
				references: renderableReferences,
				onClick,
				isImmersive
			})]
		});
		$[3] = className;
		$[4] = getDetailsProps;
		$[5] = isImmersive;
		$[6] = onClick;
		$[7] = onToggle;
		$[8] = renderableReferences;
		$[9] = title;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
ChatMessageReferencesList.displayName = "ChatMessageReferencesList";
function ReferencesList(t0) {
	const $ = c$1(9);
	const { references, onClick, isImmersive } = t0;
	let t1;
	if ($[0] !== references) {
		t1 = references.some(_temp$3);
		$[0] = references;
		$[1] = t1;
	} else t1 = $[1];
	const webSearchUsed = t1;
	let t2;
	if ($[2] !== isImmersive || $[3] !== onClick || $[4] !== references || $[5] !== webSearchUsed) {
		let t3;
		if ($[7] !== onClick) {
			t3 = (reference) => jsx(OutputReference, {
				reference,
				onClick
			}, referenceID(reference));
			$[7] = onClick;
			$[8] = t3;
		} else t3 = $[8];
		t2 = jsxs(ActionList, {
			className: clsx(isImmersive && ChatReferences_module_default.referencesListImmersiveContainer, ChatReferences_module_default.ActionList),
			children: [references.map(t3), webSearchUsed && jsxs("div", {
				className: ChatReferences_module_default.chatMessageReferenceListFooter,
				children: [
					"Copilot used the",
					" ",
					jsx(Link, {
						inline: true,
						href: "https://gh.io/azure-ai-agent-with-bing-grounding",
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Bing Search"
					}),
					" ",
					"tool.",
					" ",
					jsx(Link, {
						inline: true,
						href: "https://privacy.microsoft.com/privacystatement",
						rel: "nofollow",
						target: "_blank",
						children: "Microsoft Privacy Statement"
					})
				]
			})]
		});
		$[2] = isImmersive;
		$[3] = onClick;
		$[4] = references;
		$[5] = webSearchUsed;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
/** renders references for user messages */
ReferencesList.displayName = "ReferencesList";
function _temp$3(ref) {
	return ref.type === "web-search-result";
}
function ChatMessageReferenceTokens(t0) {
	const $ = c$1(12);
	const { references, message, className, size, onClickReference, getReferenceVersion } = t0;
	let t1;
	if ($[0] !== references) {
		t1 = partitionReferences(references);
		$[0] = references;
		$[1] = t1;
	} else t1 = $[1];
	const { bigReferences, smallReferences } = t1;
	let t2;
	if ($[2] !== getReferenceVersion || $[3] !== message || $[4] !== onClickReference || $[5] !== size) {
		t2 = (reference) => reference.type === "figma" && copilotFeatureFlags.immersiveFigmaIntegration ? jsx(FigmaChatReference, {
			reference,
			onClick: (e) => onClickReference?.(reference, e)
		}, referenceID(reference)) : jsx(ReferenceToken, {
			message,
			reference,
			size,
			onClick: (_, e_0) => onClickReference?.(reference, e_0),
			getReferenceVersion
		}, referenceID(reference));
		$[2] = getReferenceVersion;
		$[3] = message;
		$[4] = onClickReference;
		$[5] = size;
		$[6] = t2;
	} else t2 = $[6];
	const renderReference = t2;
	let t3;
	if ($[7] !== bigReferences || $[8] !== className || $[9] !== renderReference || $[10] !== smallReferences) {
		t3 = jsxs(Toolbar, {
			"aria-label": "Attachments",
			className: clsx(ChatReferences_module_default.referenceTokensOuterContainer, className),
			children: [bigReferences.map(renderReference), jsx("div", {
				className: ChatReferences_module_default.referenceTokensContainer,
				children: smallReferences.map(renderReference)
			})]
		});
		$[7] = bigReferences;
		$[8] = className;
		$[9] = renderReference;
		$[10] = smallReferences;
		$[11] = t3;
	} else t3 = $[11];
	return t3;
}
ChatMessageReferenceTokens.displayName = "ChatMessageReferenceTokens";
var BIG_REFERENCE_TYPES = new Set(["figma", "image"]);
/**
* Filters out unrenderable references and partitions them into bigReferences (rendered on their own line),
* and smallReferences (rendered inline).
*/
function partitionReferences(references) {
	const renderableReferences = getRenderableReferences(references);
	const bigReferences = [];
	const smallReferences = [];
	for (const r of renderableReferences) if (BIG_REFERENCE_TYPES.has(r.type)) bigReferences.push(r);
	else smallReferences.push(r);
	return {
		bigReferences,
		smallReferences
	};
}
var CodeMirrorDiff_module_default = {
	container: "CodeMirrorDiff-module_gAcvtq_container",
	deletedFile: "CodeMirrorDiff-module_gAcvtq_deletedFile",
	newFile: "CodeMirrorDiff-module_gAcvtq_newFile"
};
function useCodeMirrorDiff({ fileName, left, leftLabelledBy, parentRef, right, rightLabelledBy, spacing }) {
	const mergeViewRef = useRef(null);
	const autoCompleteCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const languageCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const themeCompartment = useMemo(() => {
		return new Compartment();
	}, []);
	const [managedLeftExtensions, managedRightExtensions] = useMemo(() => {
		const exts = [
			...basicSetup,
			...spacingControls(spacing),
			secretDetectedListener(),
			languageCompartment.of([]),
			autoCompleteCompartment.of([]),
			themeCompartment.of([getTheme()]),
			readOnly()
		];
		const leftExts = [scrollerAttributes(leftLabelledBy), EditorView.contentAttributes.of({ "aria-labelledby": leftLabelledBy })];
		const rightExts = [scrollerAttributes(rightLabelledBy), EditorView.contentAttributes.of({ "aria-labelledby": rightLabelledBy })];
		return [exts.concat(leftExts), exts.concat(rightExts)];
	}, [
		spacing,
		languageCompartment,
		autoCompleteCompartment,
		themeCompartment,
		leftLabelledBy,
		rightLabelledBy
	]);
	useEffect(() => {
		const parent = parentRef.current;
		if (!parent) return;
		mergeViewRef.current = new MergeView({
			a: {
				doc: left,
				extensions: managedLeftExtensions
			},
			b: {
				doc: right,
				extensions: managedRightExtensions
			},
			parent,
			gutter: false
		});
		loadLanguage({
			autoCompleteCompartment,
			fileName,
			languageCompartment,
			managedExtensions: [],
			themeCompartment,
			view: mergeViewRef.current?.a,
			viewB: mergeViewRef.current?.b
		});
		return () => mergeViewRef.current?.destroy();
	}, []);
}
/**
* Displays a diff using CodeMirror
*/
function CodeMirrorDiff(props) {
	if (!props.left || !props.right) return /* @__PURE__ */ jsx(CodeMirrorDiffNewOrDeletedFile, { ...props });
	else if (props.view === "split") return /* @__PURE__ */ jsx(CodeMirrorDiffSplit, { ...props });
	else return /* @__PURE__ */ jsx(CodeMirrorDiffUnified, { ...props });
}
CodeMirrorDiff.displayName = "CodeMirrorDiff";
function CodeMirrorDiffSplit(props) {
	const containerRef = useRef(null);
	useCodeMirrorDiff({
		...props,
		parentRef: containerRef
	});
	return /* @__PURE__ */ jsx("div", {
		ref: containerRef,
		className: CodeMirrorDiff_module_default.container
	});
}
CodeMirrorDiffSplit.displayName = "CodeMirrorDiffSplit";
function CodeMirrorDiffUnified(props) {
	const $ = c$1(10);
	let t0;
	if ($[0] !== props.left) {
		t0 = unifiedMergeView({
			original: props.left,
			mergeControls: false,
			gutter: false
		});
		$[0] = props.left;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== t0) {
		t1 = [t0];
		$[2] = t0;
		$[3] = t1;
	} else t1 = $[3];
	const unifiedExtensions = t1;
	let t2;
	if ($[4] !== props.fileName || $[5] !== props.right || $[6] !== props.spacing || $[7] !== props.unifiedLabelledBy || $[8] !== unifiedExtensions) {
		t2 = jsx(CodeMirror, {
			ariaLabelledBy: props.unifiedLabelledBy,
			containerClassName: CodeMirrorDiff_module_default.container,
			fileName: props.fileName,
			height: "100%",
			isReadOnly: true,
			spacing: props.spacing,
			value: props.right,
			onChange: noop,
			placeholder: "Loading...",
			hideHelp: true,
			extensions: unifiedExtensions
		});
		$[4] = props.fileName;
		$[5] = props.right;
		$[6] = props.spacing;
		$[7] = props.unifiedLabelledBy;
		$[8] = unifiedExtensions;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
CodeMirrorDiffUnified.displayName = "CodeMirrorDiffUnified";
function CodeMirrorDiffNewOrDeletedFile(props) {
	const style = props.left === "" ? CodeMirrorDiff_module_default.newFile : CodeMirrorDiff_module_default.deletedFile;
	const fileValue = props.right || props.left;
	return /* @__PURE__ */ jsx(CodeMirror, {
		ariaLabelledBy: props.unifiedLabelledBy,
		containerClassName: style,
		fileName: props.fileName,
		height: "100%",
		isReadOnly: true,
		spacing: props.spacing,
		value: fileValue,
		onChange: noop,
		placeholder: "Loading...",
		hideHelp: true
	});
}
CodeMirrorDiffNewOrDeletedFile.displayName = "CodeMirrorDiffNewOrDeletedFile";
var Confirmation_module_default = {
	actionButtonsContainer: "Confirmation-module_HLtryW_actionButtonsContainer",
	codeMargin: "Confirmation-module_HLtryW_codeMargin",
	ConfirmationContainer: "Confirmation-module_HLtryW_ConfirmationContainer",
	confirmationMessage: "Confirmation-module_HLtryW_confirmationMessage",
	confirmationTitle: "Confirmation-module_HLtryW_confirmationTitle",
	pathText: "Confirmation-module_HLtryW_pathText"
};
/** Split on both real newlines and literal backslash-n sequences. */
function splitNewlines(text) {
	return text.split(/\\n|\n/);
}
function isCreateOrUpdateFileConfirmationData(data) {
	try {
		const parsed = JSON.parse(data);
		return typeof parsed === "object" && parsed !== null && typeof parsed.content === "string" && typeof parsed.path === "string" && typeof parsed.repo === "string" && typeof parsed.owner === "string" && typeof parsed.message === "string" && (parsed.sha === void 0 || typeof parsed.sha === "string") && (parsed.branch === void 0 || typeof parsed.branch === "string");
	} catch {
		return false;
	}
}
function isPushFilesConfirmationData(data) {
	try {
		const parsed = JSON.parse(data);
		return typeof parsed === "object" && parsed !== null && Array.isArray(parsed.files) && parsed.files.every((file) => typeof file === "object" && file !== null && typeof file.path === "string" && typeof file.content === "string") && (parsed.branch === void 0 || typeof parsed.branch === "string") && (parsed.message === void 0 || typeof parsed.message === "string") && (parsed.owner === void 0 || typeof parsed.owner === "string") && (parsed.repo === void 0 || typeof parsed.repo === "string");
	} catch {
		return false;
	}
}
function ConfirmationInner({ confirmation, actionTaken, isWaitingOnCopilot, handleUserAction }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("border rounded-2", Confirmation_module_default.ConfirmationContainer),
		children: [
			/* @__PURE__ */ jsx(Heading$2, {
				as: "h3",
				className: Confirmation_module_default.confirmationTitle,
				children: confirmation.title
			}),
			splitNewlines(confirmation.message).map((message, index) => /* @__PURE__ */ jsx("p", {
				className: Confirmation_module_default.confirmationMessage,
				children: message
			}, `${index}-${message}`)),
			!actionTaken && /* @__PURE__ */ jsxs("div", {
				className: Confirmation_module_default.actionButtonsContainer,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					variant: "primary",
					onClick: () => handleUserAction("accepted"),
					children: "Allow"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					onClick: () => handleUserAction("dismissed"),
					children: "Dismiss"
				})]
			})
		]
	});
}
ConfirmationInner.displayName = "ConfirmationInner";
function Confirmation(t0) {
	const $ = c$1(28);
	const { confirmation, handleConfirmation, isLatestMessage } = t0;
	const state = useChatState();
	let t1;
	if ($[0] !== confirmation.confirmation || $[1] !== state.allClientConfirmations) {
		const confirmationConfirmation = JSON.stringify(Object.values(confirmation.confirmation).sort());
		t1 = state.allClientConfirmations?.includes(confirmationConfirmation);
		$[0] = confirmation.confirmation;
		$[1] = state.allClientConfirmations;
		$[2] = t1;
	} else t1 = $[2];
	const clientConfirmationExists = t1;
	const { isWaitingOnCopilot, currentUserLogin } = state;
	const [actionTaken, setActionTaken] = useState(Boolean(clientConfirmationExists && !isLatestMessage));
	let t2;
	if ($[3] !== confirmation.confirmation || $[4] !== confirmation.onSubmit || $[5] !== confirmation.title || $[6] !== currentUserLogin || $[7] !== handleConfirmation) {
		t2 = (action) => {
			setActionTaken(true);
			handleConfirmation({
				state: action,
				userLogin: currentUserLogin,
				confirmation: confirmation.confirmation
			}, confirmation.title, confirmation.onSubmit);
		};
		$[3] = confirmation.confirmation;
		$[4] = confirmation.onSubmit;
		$[5] = confirmation.title;
		$[6] = currentUserLogin;
		$[7] = handleConfirmation;
		$[8] = t2;
	} else t2 = $[8];
	const handleUserAction = t2;
	const manager = useChatManager();
	const confirmationId = useId();
	const toolCall = confirmation.confirmation;
	if (isCreateOrUpdateFileConfirmationData(toolCall.arguments)) {
		let t3;
		if ($[9] !== actionTaken || $[10] !== confirmation || $[11] !== confirmationId || $[12] !== handleUserAction || $[13] !== isWaitingOnCopilot || $[14] !== manager || $[15] !== toolCall.arguments) {
			t3 = Symbol.for("react.early_return_sentinel");
			bb0: {
				const confirmationData = JSON.parse(toolCall.arguments);
				if (confirmationData.sha) {
					t3 = jsx(UpdateFileWithDiff, {
						confirmationData,
						manager,
						confirmation,
						actionTaken,
						isWaitingOnCopilot,
						handleUserAction,
						confirmationId
					});
					break bb0;
				} else {
					t3 = jsx(CodeConfirmationInner, {
						files: [{
							path: confirmationData.path,
							content: confirmationData.content
						}],
						confirmation,
						actionTaken,
						isWaitingOnCopilot,
						handleUserAction
					});
					break bb0;
				}
			}
			$[9] = actionTaken;
			$[10] = confirmation;
			$[11] = confirmationId;
			$[12] = handleUserAction;
			$[13] = isWaitingOnCopilot;
			$[14] = manager;
			$[15] = toolCall.arguments;
			$[16] = t3;
		} else t3 = $[16];
		if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	}
	if (isPushFilesConfirmationData(toolCall.arguments)) {
		let t3;
		if ($[17] !== actionTaken || $[18] !== confirmation || $[19] !== handleUserAction || $[20] !== isWaitingOnCopilot || $[21] !== toolCall.arguments) {
			t3 = jsx(CodeConfirmationInner, {
				files: JSON.parse(toolCall.arguments).files || [],
				confirmation,
				actionTaken,
				isWaitingOnCopilot,
				handleUserAction
			});
			$[17] = actionTaken;
			$[18] = confirmation;
			$[19] = handleUserAction;
			$[20] = isWaitingOnCopilot;
			$[21] = toolCall.arguments;
			$[22] = t3;
		} else t3 = $[22];
		return t3;
	}
	let t3;
	if ($[23] !== actionTaken || $[24] !== confirmation || $[25] !== handleUserAction || $[26] !== isWaitingOnCopilot) {
		t3 = jsx(ConfirmationInner, {
			confirmation,
			actionTaken,
			isWaitingOnCopilot,
			handleUserAction
		});
		$[23] = actionTaken;
		$[24] = confirmation;
		$[25] = handleUserAction;
		$[26] = isWaitingOnCopilot;
		$[27] = t3;
	} else t3 = $[27];
	return t3;
}
Confirmation.displayName = "Confirmation";
function CodeConfirmationInner({ files, confirmation, actionTaken, isWaitingOnCopilot, handleUserAction }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx("border rounded-2", Confirmation_module_default.ConfirmationContainer),
		children: [
			/* @__PURE__ */ jsx(Heading$2, {
				as: "h3",
				className: Confirmation_module_default.confirmationTitle,
				children: "Make these code changes?"
			}),
			files.map((file, index) => {
				const markdown = `\`\`\`${file.path ? file.path.split(".").pop() || "text" : "text"}\n${file.content}\n\`\`\``;
				return /* @__PURE__ */ jsxs("div", {
					className: Confirmation_module_default.codeMargin,
					children: [/* @__PURE__ */ jsx("p", {
						className: Confirmation_module_default.pathText,
						children: file.path
					}), /* @__PURE__ */ jsx(MarkdownRenderer, { markdown })]
				}, file.path || index);
			}),
			splitNewlines(confirmation.message).map((message, index) => /* @__PURE__ */ jsx("p", {
				className: Confirmation_module_default.confirmationMessage,
				children: message
			}, `${index}-${message}`)),
			!actionTaken && /* @__PURE__ */ jsxs("div", {
				className: Confirmation_module_default.actionButtonsContainer,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					variant: "primary",
					onClick: () => handleUserAction("accepted"),
					children: "Allow"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					onClick: () => handleUserAction("dismissed"),
					children: "Dismiss"
				})]
			})
		]
	});
}
CodeConfirmationInner.displayName = "CodeConfirmationInner";
function UpdateFileWithDiff({ confirmationData, manager, confirmation, actionTaken, isWaitingOnCopilot, handleUserAction, confirmationId }) {
	const [originalContent, setOriginalContent] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		async function fetchOriginalContent() {
			try {
				setIsLoading(true);
				const result = await manager.service.fetchFileContentsNwo(confirmationData.owner, confirmationData.repo, confirmationData.path, confirmationData.branch);
				if (result.ok && result.payload) setOriginalContent(result.payload.content);
				else setError("Failed to fetch original file content");
			} catch {
				setError("Error fetching original file content");
			} finally {
				setIsLoading(false);
			}
		}
		fetchOriginalContent();
	}, [confirmationData, manager.service]);
	if (isLoading) return /* @__PURE__ */ jsx("div", {
		className: clsx("border rounded-2", Confirmation_module_default.ConfirmationContainer),
		children: /* @__PURE__ */ jsx(Heading$2, {
			as: "h3",
			className: Confirmation_module_default.confirmationTitle,
			children: "Loading file diff..."
		})
	});
	if (error) return /* @__PURE__ */ jsx(CodeConfirmationInner, {
		files: [{
			path: confirmationData.path,
			content: confirmationData.content
		}],
		confirmation,
		actionTaken,
		isWaitingOnCopilot,
		handleUserAction
	});
	return /* @__PURE__ */ jsxs("div", {
		id: confirmationId,
		className: clsx("border rounded-2", Confirmation_module_default.ConfirmationContainer),
		children: [
			/* @__PURE__ */ jsx(Heading$2, {
				as: "h3",
				className: Confirmation_module_default.confirmationTitle,
				children: "Make these code changes?"
			}),
			/* @__PURE__ */ jsxs("div", {
				className: Confirmation_module_default.codeMargin,
				children: [/* @__PURE__ */ jsx("p", {
					className: Confirmation_module_default.pathText,
					children: confirmationData.path
				}), /* @__PURE__ */ jsx(CodeMirrorDiff, {
					fileName: confirmationData.path,
					left: originalContent,
					right: confirmationData.content,
					leftLabelledBy: "",
					rightLabelledBy: "",
					unifiedLabelledBy: confirmationId,
					spacing: {
						indentUnit: 2,
						indentWithTabs: false,
						lineWrapping: true
					},
					view: "unified"
				})]
			}),
			splitNewlines(confirmation.message).map((message, index) => /* @__PURE__ */ jsx("p", {
				className: Confirmation_module_default.confirmationMessage,
				children: message
			}, `${index}-${message}`)),
			!actionTaken && /* @__PURE__ */ jsxs("div", {
				className: Confirmation_module_default.actionButtonsContainer,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					variant: "primary",
					onClick: () => handleUserAction("accepted"),
					children: "Allow"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					disabled: isWaitingOnCopilot,
					onClick: () => handleUserAction("dismissed"),
					children: "Dismiss"
				})]
			})
		]
	});
}
UpdateFileWithDiff.displayName = "UpdateFileWithDiff";
var CopilotBadgeV2_module_default = {
	animation: "CopilotBadgeV2-module_YjUWnW_animation",
	assistive: "CopilotBadgeV2-module_YjUWnW_assistive",
	clickableAnimationWrapper: "CopilotBadgeV2-module_YjUWnW_clickableAnimationWrapper",
	copilotBadge: "CopilotBadgeV2-module_YjUWnW_copilotBadge",
	loading: "CopilotBadgeV2-module_YjUWnW_loading"
};
var INTERACTIVE_STATES = [
	CopilotAnimationType.Tickle,
	CopilotAnimationType.Celebrate,
	CopilotAnimationType.JumpWiggle
];
var AFFIRM_KEYWORDS = [
	"yes",
	"absolutely",
	"certainly",
	"sure",
	"definitely",
	"right",
	"correct",
	"indeed",
	"precisely",
	"exactly",
	"true",
	"affirmative",
	"agree",
	"agreed"
];
var NEG_KEYWORDS = [
	"no",
	"never",
	"negative",
	"wrong",
	"false",
	"untrue",
	"cannot",
	"can't",
	"sorry",
	"incorrect",
	"deny",
	"disagree",
	"refuse",
	"unfortunately"
];
function isStrongAffirmative(message) {
	if (message.length < 200) {
		const tokens = message.toLowerCase().split(/\W+/).filter(Boolean);
		return AFFIRM_KEYWORDS.some((keyword) => tokens.includes(keyword.toLowerCase()));
	}
	return false;
}
function isStrongNegative(message) {
	if (message.length < 200) {
		const tokens = message.toLowerCase().split(/\W+/).filter(Boolean);
		return NEG_KEYWORDS.some((keyword) => tokens.includes(keyword.toLowerCase()));
	}
	return false;
}
function getNextAnimationState({ previousState, isLoadingSkills, isAffirmativeSentiment, isNegativeSentiment, isError, isLoading }) {
	switch (previousState.animationType) {
		case CopilotAnimationType.Static:
			if ((isAffirmativeSentiment || isNegativeSentiment) && !isError && !previousState.hasLoadedMessage) return {
				animationType: isAffirmativeSentiment ? CopilotAnimationType.Affirmative : CopilotAnimationType.Negative,
				onFinish: CopilotAnimationType.Static,
				loopAnimation: false,
				hasLoadedMessage: true
			};
			if (isLoadingSkills) return {
				...previousState,
				animationType: CopilotAnimationType.Thinking,
				loopAnimation: true
			};
			if (!isLoading && !previousState.hasLoadedMessage && !isError) return {
				animationType: CopilotAnimationType.Confirm,
				onFinish: CopilotAnimationType.Static,
				loopAnimation: false,
				hasLoadedMessage: true
			};
			if (isError && !previousState.hasLoadedMessage) return {
				animationType: CopilotAnimationType.Negative,
				onFinish: CopilotAnimationType.Static,
				loopAnimation: false,
				hasLoadedMessage: true
			};
			return previousState;
		case CopilotAnimationType.Thinking:
			if (!isLoadingSkills) return {
				...previousState,
				animationType: isError ? CopilotAnimationType.Negative : CopilotAnimationType.Static,
				loopAnimation: false
			};
			return previousState;
		default: return previousState;
	}
}
function isRecentMessage(createdAt) {
	const msgDateTime = new Date(createdAt);
	return ((/* @__PURE__ */ new Date()).getTime() - msgDateTime.getTime()) / 1e3 / 60 < .5;
}
/**
* Originally only utilized in immersive chat, this Copilot avatar does not have a border and has a "loading dots"
* animation to indicate when Copilot is thinking. Currently called "V2" since the original CopilotBadge is still
* utilized in several places.
*/
function CopilotBadge(t0) {
	const $ = c$1(29);
	const { isFirstMessage: t1, isLoading, isLoadingSkills, isError, className, mode, message, createdAt } = t0;
	const isFirstMessage = t1 === void 0 ? false : t1;
	let t2;
	if ($[0] !== createdAt || $[1] !== isFirstMessage) {
		t2 = () => ({
			animationType: isFirstMessage && (!createdAt || isRecentMessage(createdAt)) ? CopilotAnimationType.Celebrate : CopilotAnimationType.Static,
			onFinish: CopilotAnimationType.Static,
			loopAnimation: false,
			hasLoadedMessage: false
		});
		$[0] = createdAt;
		$[1] = isFirstMessage;
		$[2] = t2;
	} else t2 = $[2];
	const [badgeState, setBadgeState] = useState(t2);
	let t3;
	if ($[3] !== createdAt || $[4] !== isError || $[5] !== isLoading || $[6] !== isLoadingSkills || $[7] !== message) {
		t3 = () => {
			if (isRecentMessage(createdAt)) setBadgeState((previousState) => getNextAnimationState({
				previousState,
				isLoadingSkills: isLoadingSkills || false,
				isError: isError || false,
				isLoading: isLoading || false,
				isAffirmativeSentiment: isStrongAffirmative(message),
				isNegativeSentiment: isStrongNegative(message)
			}));
		};
		$[3] = createdAt;
		$[4] = isError;
		$[5] = isLoading;
		$[6] = isLoadingSkills;
		$[7] = message;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== badgeState.animationType || $[10] !== badgeState.hasLoadedMessage || $[11] !== createdAt || $[12] !== isError || $[13] !== isFirstMessage || $[14] !== isLoading || $[15] !== isLoadingSkills || $[16] !== message) {
		t4 = [
			isLoadingSkills,
			isError,
			isLoading,
			badgeState.animationType,
			badgeState.hasLoadedMessage,
			isFirstMessage,
			message,
			createdAt
		];
		$[9] = badgeState.animationType;
		$[10] = badgeState.hasLoadedMessage;
		$[11] = createdAt;
		$[12] = isError;
		$[13] = isFirstMessage;
		$[14] = isLoading;
		$[15] = isLoadingSkills;
		$[16] = message;
		$[17] = t4;
	} else t4 = $[17];
	useEffect(t3, t4);
	let t5;
	if ($[18] !== badgeState || $[19] !== isLoading) {
		t5 = () => {
			if (!isLoading) setBadgeState({
				...badgeState,
				animationType: INTERACTIVE_STATES[Math.floor(Math.random() * INTERACTIVE_STATES.length)],
				onFinish: CopilotAnimationType.Static,
				loopAnimation: false
			});
		};
		$[18] = badgeState;
		$[19] = isLoading;
		$[20] = t5;
	} else t5 = $[20];
	const handleCelebrationClick = t5;
	let t6;
	if ($[21] !== badgeState.animationType || $[22] !== badgeState.loopAnimation || $[23] !== className || $[24] !== handleCelebrationClick || $[25] !== isLoading || $[26] !== mode) {
		let t7;
		if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setBadgeState(_temp$2);
			$[28] = t7;
		} else t7 = $[28];
		t6 = jsx("div", {
			className: clsx(CopilotBadgeV2_module_default.copilotBadge, isLoading && CopilotBadgeV2_module_default.loading, className),
			"aria-label": "Copilot badge",
			role: "img",
			children: jsx("div", {
				onClick: handleCelebrationClick,
				className: CopilotBadgeV2_module_default.clickableAnimationWrapper,
				children: jsx(CopilotAnimation, {
					animationType: badgeState.animationType,
					onAnimationEnd: t7,
					loopAnimation: badgeState.loopAnimation,
					className: clsx(CopilotBadgeV2_module_default.animation, mode === "assistive" && CopilotBadgeV2_module_default.assistive)
				})
			})
		});
		$[21] = badgeState.animationType;
		$[22] = badgeState.loopAnimation;
		$[23] = className;
		$[24] = handleCelebrationClick;
		$[25] = isLoading;
		$[26] = mode;
		$[27] = t6;
	} else t6 = $[27];
	return t6;
}
CopilotBadge.displayName = "CopilotBadge";
function _temp$2(prev) {
	return {
		...prev,
		animationType: prev.onFinish
	};
}
memo(CopilotBadge);
var SingleSignOnBanner_module_default = {
	bannerContainer: "SingleSignOnBanner-module_kKs5Jq_bannerContainer",
	Flash: "SingleSignOnBanner-module_kKs5Jq_Flash",
	FlashFullWidth: "SingleSignOnBanner-module_kKs5Jq_FlashFullWidth",
	ForceWrap: "SingleSignOnBanner-module_kKs5Jq_ForceWrap",
	multiOrgLayout: "SingleSignOnBanner-module_kKs5Jq_multiOrgLayout",
	Octicon: "SingleSignOnBanner-module_kKs5Jq_Octicon",
	orgListWrapper: "SingleSignOnBanner-module_kKs5Jq_orgListWrapper",
	ProtectedOrgs_FullList: "SingleSignOnBanner-module_kKs5Jq_ProtectedOrgs_FullList",
	ProtectedOrgs_Shortened: "SingleSignOnBanner-module_kKs5Jq_ProtectedOrgs_Shortened",
	ShieldLockIcon: "SingleSignOnBanner-module_kKs5Jq_ShieldLockIcon"
};
function SSOBannerFromError({ error, className }) {
	const identifier = error.identifier || "";
	const authorizeUrl = identifier.split("url=")[1] || "";
	const orgMatch = identifier.match(/\/([^/]+)\/sso/);
	const org = orgMatch && orgMatch[1] || "";
	if (!org || !authorizeUrl) return null;
	return /* @__PURE__ */ jsx("div", {
		className,
		"data-testid": "sso-banner",
		children: /* @__PURE__ */ jsx("div", {
			className: SingleSignOnBanner_module_default.bannerContainer,
			children: /* @__PURE__ */ jsx("section", {
				"aria-label": "Single sign-on information",
				children: /* @__PURE__ */ jsx(Flash, {
					className: SingleSignOnBanner_module_default.Flash,
					children: /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx(ShieldLockIcon, {}),
						/* @__PURE__ */ jsx(Link, {
							inline: true,
							href: buildAuthorizeUrl({ authorizeUrl }),
							children: "Single sign-on"
						}),
						" ",
						"to see results in the ",
						/* @__PURE__ */ jsx("b", { children: org }),
						" organization."
					] })
				})
			})
		})
	});
}
SSOBannerFromError.displayName = "SSOBannerFromError";
function buildAuthorizeUrl({ authorizeUrl }) {
	const url = new URL(authorizeUrl, window.location.origin);
	url.searchParams.set("return_to", window.location.toString());
	return url.toString();
}
function ErrorMessage(t0) {
	const $ = c$1(7);
	const { manager } = t0;
	const { message } = useChatMessage();
	const { error } = message;
	if (!error) return null;
	switch (error.type) {
		case "agentUnauthorized": {
			let t1;
			if ($[0] !== error || $[1] !== manager) {
				t1 = jsx(AgentUnauthorizedError, {
					error,
					manager
				});
				$[0] = error;
				$[1] = manager;
				$[2] = t1;
			} else t1 = $[2];
			return t1;
		}
		case "agentRequest": {
			let t1;
			if ($[3] !== error.details) {
				t1 = jsx(AgentErrors, { errors: [error.details] });
				$[3] = error.details;
				$[4] = t1;
			} else t1 = $[4];
			return t1;
		}
		default: {
			let t1;
			if ($[5] !== error.message) {
				t1 = jsx(Banner, {
					...testIdProps("error-message-banner"),
					title: "Error",
					hideTitle: true,
					description: error.message || "Something went wrong",
					variant: "warning"
				});
				$[5] = error.message;
				$[6] = t1;
			} else t1 = $[6];
			return t1;
		}
	}
}
ErrorMessage.displayName = "ErrorMessage";
function AgentUnauthorizedError(t0) {
	const $ = c$1(9);
	const { error, manager } = t0;
	const { details } = error;
	const [dismissed, setDismissed] = useState(false);
	let t1;
	if ($[0] !== details.name || $[1] !== manager) {
		t1 = () => {
			setDismissed(true);
			manager.dispatch({
				type: "MESSAGE_ADDED",
				message: buildMessage({
					role: "user",
					content: `Dismissed the connection with ${details.name}.`,
					mediaContent: [],
					parentMessageID: manager.FindLastMessageID()
				})
			});
			manager.dispatch({
				type: "MESSAGE_ADDED",
				message: buildMessage({
					role: "assistant",
					content: `I was unable to connect you to ${details.name} because you cancelled the authentication.`,
					mediaContent: [],
					parentMessageID: manager.FindLastMessageID()
				})
			});
		};
		$[0] = details.name;
		$[1] = manager;
		$[2] = t1;
	} else t1 = $[2];
	const onDismiss = t1;
	let t2;
	if ($[3] !== details.authorize_url || $[4] !== details.avatar_url || $[5] !== details.name || $[6] !== dismissed || $[7] !== onDismiss) {
		t2 = jsxs("div", {
			className: "position-relative d-flex flex-column flex-items-center gap-3 border rounded-2 tmp-p-5",
			...testIdProps("agent-unauthorized-error"),
			children: [
				!dismissed && jsx(IconButton, {
					"aria-label": "Close",
					className: "position-absolute top-0 right-0 mt-2 mr-2",
					icon: XIcon,
					onClick: onDismiss,
					variant: "invisible",
					unsafeDisableTooltip: true
				}),
				jsxs("div", {
					className: "d-flex flex-items-center gap-2",
					children: [
						jsx(MarkGithubIcon, {
							size: 48,
							className: "border circle borderColor-muted"
						}),
						jsx(LinkIcon, { className: "fgColor-muted" }),
						jsx("img", {
							className: clsx("avatar", ChatMessage_module_default.agentUnauthorizedAvatar, "border circle borderColor-muted"),
							src: details.avatar_url,
							alt: `icon for ${details.name}`
						})
					]
				}),
				jsxs("p", {
					className: "h4 m-0 text-center",
					children: ["Connect with ", details.name]
				}),
				jsxs("p", {
					className: "fgColor-muted text-center",
					children: [
						"To use the ",
						details.name,
						" extension, you’ll need to connect your GitHub account to your ",
						details.name,
						" account."
					]
				}),
				!dismissed && jsxs(Fragment$1, { children: [jsx(ButtonComponent, {
					as: "a",
					variant: "primary",
					size: "large",
					className: "width-full",
					href: details.authorize_url,
					rel: "noopener",
					target: "_blank",
					children: "Connect"
				}), jsxs("p", {
					className: "fgColor-muted text-center f6 m-0",
					children: ["Click connect to be redirected to ", details.authorize_url]
				})] })
			]
		});
		$[3] = details.authorize_url;
		$[4] = details.avatar_url;
		$[5] = details.name;
		$[6] = dismissed;
		$[7] = onDismiss;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
AgentUnauthorizedError.displayName = "AgentUnauthorizedError";
function AgentErrors({ errors }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-column gap-2",
		children: errors.map((error, i) => renderError(error, i))
	});
}
AgentErrors.displayName = "AgentErrors";
function renderError(error, i) {
	switch (error.code) {
		case "sso": return /* @__PURE__ */ jsx(SSOBannerFromError, {
			error,
			className: "tmp-mt-3"
		}, i);
		default: return defaultError(error, i);
	}
}
function defaultError(error, key) {
	return /* @__PURE__ */ jsxs("div", {
		className: "tmp-p-3 border rounded-2",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "text-bold",
			children: [
				/* @__PURE__ */ jsx(AlertFillIcon, { className: "mr-1 fgColor-attention" }),
				" ",
				errorTitle(error)
			]
		}), /* @__PURE__ */ jsx(MarkdownRenderer, { markdown: error.message })]
	}, key);
}
function errorTitle(error) {
	if (error.type === "http") return `${error.code} ${error.identifier}`;
	else return `${capitalize(error.type)} error`;
}
var Feedback_module_default = { submittedFeedbackButton: "Feedback-module_o_buqW_submittedFeedbackButton" };
var ratingOptions = [{
	name: "Bad",
	value: "NEGATIVE",
	icon: thumbsDownIcon,
	color: "bad"
}, {
	name: "Good",
	value: "POSITIVE",
	icon: thumbsUpIcon,
	color: "good"
}];
function MessageFeedbackDialog({ ref, messageId, threadId, returnFocusRef, onSubmitted, onClose }) {
	const manager = useChatManager();
	const surveyDialogRef = useRef(null);
	const feedbackDialogRef = useRef(null);
	const initialRatingRef = useRef(void 0);
	useImperativeHandle(ref, () => ({ openDialog: (rating) => {
		initialRatingRef.current = rating;
		if (copilotFeatureFlags.copilotChatInterviewSurvey) surveyDialogRef.current?.openDialog();
		else feedbackDialogRef.current?.openDialog(rating);
	} }));
	const onSubmit = async (rating_0, text) => {
		const errors = [];
		if (rating_0 == null) errors.push("Please select a rating.");
		const limit = 500;
		if (text.length > limit) errors.push(`Please keep your feedback within ${limit} characters or less.`);
		if (errors.length > 0) return errors;
		else rating_0 = rating_0;
		try {
			if ((await manager.service.sendFeedback({
				feedback: rating_0,
				feedbackChoice: [],
				messageId,
				threadId,
				textResponse: text
			})).ok) onSubmitted?.(rating_0);
			else errors.push("An error occurred while submitting your feedback.");
		} catch {
			errors.push("An error occurred while submitting your feedback.");
		}
		return errors;
	};
	const onSurveyClose = (reason) => {
		if (reason === "no-thanks") feedbackDialogRef.current?.openDialog(initialRatingRef.current);
		else onClose?.();
	};
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(InterviewSurveyDialog, {
		ref: surveyDialogRef,
		title: "Give additional feedback",
		onClose: onSurveyClose
	}), /* @__PURE__ */ jsx(UserFeedback, {
		title: "Give additional feedback",
		ref: feedbackDialogRef,
		options: ratingOptions,
		onSubmit,
		onClose,
		requestID: copilotLocalStorage.getRequestID(messageId),
		returnFocusRef
	})] });
}
MessageFeedbackDialog.displayName = "MessageFeedbackDialog";
MessageFeedbackDialog.displayName = "MessageFeedbackDialog";
function Feedback({ iconSize }) {
	const { message } = useChatMessage();
	const messageId = message.id;
	const threadId = message.threadID;
	const manager = useChatManager();
	const dialogRef = useRef(null);
	const submittedFeedbackButtonRef = useRef(null);
	const onFeedbackGiven = useCallback((feedbackGiven) => {
		manager.handleFeedback(message, feedbackGiven);
	}, [manager, message]);
	const { optedInToUserFeedback } = useChatState();
	const sendFeedback = useCallback((feedbackGiven_0) => {
		manager.service.sendFeedback({
			feedback: feedbackGiven_0,
			messageId,
			threadId
		});
		onFeedbackGiven(feedbackGiven_0);
		if (optedInToUserFeedback) dialogRef.current?.openDialog(feedbackGiven_0);
		else submittedFeedbackButtonRef.current?.focus();
	}, [
		manager.service,
		messageId,
		threadId,
		submittedFeedbackButtonRef,
		onFeedbackGiven,
		optedInToUserFeedback
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [message.feedback != null ? /* @__PURE__ */ jsx(IconButton, {
		ref: submittedFeedbackButtonRef,
		"aria-label": `${message.feedback.toLocaleLowerCase()} feedback submitted`,
		icon: message.feedback === "POSITIVE" ? ThumbsupIcon : ThumbsdownIcon,
		variant: "invisible",
		size: iconSize,
		"aria-disabled": true,
		className: Feedback_module_default.submittedFeedbackButton
	}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
		icon: ThumbsupIcon,
		"aria-label": "Good response",
		onClick: () => sendFeedback("POSITIVE"),
		variant: "invisible",
		size: iconSize
	}), /* @__PURE__ */ jsx(IconButton, {
		icon: ThumbsdownIcon,
		size: iconSize,
		"aria-label": "Bad response",
		onClick: () => sendFeedback("NEGATIVE"),
		variant: "invisible"
	})] }), /* @__PURE__ */ jsx(MessageFeedbackDialog, {
		ref: dialogRef,
		messageId,
		threadId,
		onSubmitted: onFeedbackGiven,
		returnFocusRef: submittedFeedbackButtonRef
	})] });
}
Feedback.displayName = "Feedback";
var FunctionCallButton_module_default = { functionCallButton: "FunctionCallButton-module_JMLRla_functionCallButton" };
var FunctionLoadingUtils_module_default = {
	errorContainer: "FunctionLoadingUtils-module_sVMyNa_errorContainer",
	errorHeading: "FunctionLoadingUtils-module_sVMyNa_errorHeading",
	errorMessage: "FunctionLoadingUtils-module_sVMyNa_errorMessage",
	functionLoading: "FunctionLoadingUtils-module_sVMyNa_functionLoading",
	functionReferenceButton: "FunctionLoadingUtils-module_sVMyNa_functionReferenceButton",
	functionReferenceButtonContents: "FunctionLoadingUtils-module_sVMyNa_functionReferenceButtonContents",
	functionReferenceListContainer: "FunctionLoadingUtils-module_sVMyNa_functionReferenceListContainer",
	functionReferenceListFooter: "FunctionLoadingUtils-module_sVMyNa_functionReferenceListFooter",
	functionReferenceTitle: "FunctionLoadingUtils-module_sVMyNa_functionReferenceTitle",
	functionTitleContainer: "FunctionLoadingUtils-module_sVMyNa_functionTitleContainer",
	spinner: "FunctionLoadingUtils-module_sVMyNa_spinner",
	toolDescriptionText: "FunctionLoadingUtils-module_sVMyNa_toolDescriptionText",
	toolNameHighlight: "FunctionLoadingUtils-module_sVMyNa_toolNameHighlight"
};
function BingGroundingFunctionButton({ chatManager, functionCall, skillArgs }) {
	const query = skillArgs.query;
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		additionalFooterContent: /* @__PURE__ */ jsx(Link, {
			href: "https://privacy.microsoft.com/privacystatement",
			rel: "nofollow",
			target: "_blank",
			children: "Microsoft Privacy Statement"
		}),
		chatManager,
		errorButtonText: `An error occurred when searching for “${query}”`,
		errorTitle: "An error occurred when searching the web",
		toolLink: "https://gh.io/azure-ai-agent-with-bing-grounding",
		toolName: "Bing Search",
		functionCall,
		inProgressMessage: `Searching the web for “${query}”`,
		noResultsMessage: `No web search results for “${query}” were found`,
		resultsMapper: (execution) => {
			return getBingGroundingReferenceData((execution.references?.[0])?.results ?? []);
		},
		successButtonText: `Using web search results for “${query}”`,
		useSelectReference: false
	});
}
BingGroundingFunctionButton.displayName = "BingGroundingFunctionButton";
function getBingGroundingReferenceData(webSearchResults) {
	return webSearchResults.map((result) => ({
		title: result.title,
		url: result.url,
		leadingIcon: result.reference_type === "bing_search" ? BingIcon : GlobeIcon
	}));
}
function CodeSearchButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	const query = skillArgs.query;
	let scopingQuery = "scopingQuery" in skillArgs ? skillArgs.scopingQuery : skillArgs.repoOwner && skillArgs.repoName ? `repo:${skillArgs.repoOwner}/${skillArgs.repoName}` : void 0;
	if (scopingQuery) scopingQuery = stripRepoQualifier(scopingQuery);
	const searchType = skillArgs.kind === "semantic-code-search" ? "semantic" : "lexical";
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: `An error occurred when searching for “${query}”`,
		errorTitle: "An error occurred when searching code",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: `${searchType.charAt(0).toUpperCase() + searchType.slice(1)} search`,
		functionCall,
		inProgressMessage: `Searching for “${query}”${scopingQuery && ` in ${scopingQuery}`}`,
		noResultsMessage: `No results were found when ${searchType} searching for “${query}”${scopingQuery && ` in ${scopingQuery}`}`,
		resultsMapper: snippetMapper,
		successButtonText: `Using ${searchType} search results for “${query}”${scopingQuery && ` in ${scopingQuery}`}`,
		useSelectReference
	});
}
CodeSearchButton.displayName = "CodeSearchButton";
function GetFileButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	const { path, repo, ref } = skillArgs;
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: withRefSuffix(`An error occurred when finding “${path}” in ${repo}`, ref),
		errorTitle: "An error occurred when finding a file",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: "Get file",
		functionCall,
		inProgressMessage: withRefSuffix(`File results for “${path}” in ${repo}`, ref),
		noResultsMessage: withRefSuffix(`No files matching “${path}” in ${repo} were found`, ref),
		resultsMapper: (execution) => {
			return (execution.references ?? []).map((reference) => reference.type === "file-v2" ? {
				description: `${reference.repoName}/${reference.path}`,
				leadingIcon: FileIcon,
				reference,
				title: referenceFileName(reference),
				url: reference.url
			} : void 0);
		},
		successButtonText: withRefSuffix(`Using results for “${path}” in ${repo}`, ref),
		useSelectReference
	});
}
GetFileButton.displayName = "GetFileButton";
function GetFileChangesButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	const { path, repo, ref } = skillArgs;
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: withRefSuffix(`An error occurred when finding file changes for “${path}” in ${repo}`, ref),
		errorTitle: "An error occurred when finding the file changes",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: "Get file changes",
		functionCall,
		inProgressMessage: withRefSuffix(`File changes results for “${path} in ${repo}`, ref),
		noResultsMessage: withRefSuffix(`No files changes were found for “${path}” in ${repo}`, ref),
		resultsMapper: (execution) => {
			return (execution.references ?? []).map((reference) => reference.type === "file-changes" ? {
				description: `${reference.repository.name}/${path}`,
				leadingIcon: FileIcon,
				reference,
				title: referenceFileName(reference),
				url: reference.url
			} : void 0);
		},
		successButtonText: withRefSuffix(`Using results for “${path}” in ${repo}`, ref),
		useSelectReference
	});
}
GetFileChangesButton.displayName = "GetFileChangesButton";
var withRefSuffix = (string, ref) => {
	return ref ? `${string} on ref ${ref}` : string;
};
function GetAlertButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: `An error occurred when fetching alert information for ${skillArgs.url}`,
		errorTitle: "An error occurred when fetching alert information",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: "Get alert information",
		functionCall,
		inProgressMessage: `Fetching alert information`,
		noResultsMessage: `Unable to fetch alert information`,
		resultsMapper: (execution) => {
			return (execution.references ?? []).map((reference) => reference.type === "alert.api" ? {
				description: `Alert`,
				leadingIcon: () => /* @__PURE__ */ jsx(ShieldIcon, {}),
				title: "Alert"
			} : void 0);
		},
		successButtonText: `Using alert information`,
		useSelectReference
	});
}
GetAlertButton.displayName = "GetAlertButton";
function GetDiscussionButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: "An error occurred when fetching discussion",
		errorTitle: "An error occurred when fetching discussion",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: "Get discussion",
		functionCall,
		inProgressMessage: `Fetching discussion ${skillArgs.discussionNumber}`,
		noResultsMessage: `Unable to fetch discussion ${skillArgs.discussionNumber}`,
		resultsMapper: (execution) => {
			return (execution.references ?? []).map((reference) => reference.type === "discussion" ? {
				title: reference.title ?? "Discussion",
				description: `Using discussion #${reference.number} for ${reference.repository.owner}/${reference.repository.name}`,
				url: reference.url,
				leadingIcon: CommentDiscussionIcon
			} : void 0);
		},
		successButtonText: `Using discussion #${skillArgs.discussionNumber}`,
		useSelectReference
	});
}
GetDiscussionButton.displayName = "GetDiscussionButton";
function FunctionLoading$1({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: FunctionLoadingUtils_module_default.functionLoading,
		children: [/* @__PURE__ */ jsx("span", {
			className: FunctionLoadingUtils_module_default.spinner,
			children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
		}), /* @__PURE__ */ jsx("span", { children })]
	});
}
FunctionLoading$1.displayName = "FunctionLoading";
function PlanButton({ functionCall }) {
	const { status } = functionCall;
	if (status === "started") return /* @__PURE__ */ jsx(FunctionLoading$1, { children: "Coming up with a plan" });
}
PlanButton.displayName = "PlanButton";
function GetJobLogsButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	const topic = getJobLogsSkillExecutionTopic(skillArgs);
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: `An error occurred when fetching logs for ${topic} in ${skillArgs.repo}`,
		errorTitle: "An error occurred when fetching a commit",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName: "Get job logs",
		functionCall,
		inProgressMessage: `Fetching logs for ${topic} in ${skillArgs.repo}`,
		noResultsMessage: `Unable to fetch logs for ${topic} in ${skillArgs.repo}`,
		resultsMapper: (execution) => {
			return (execution.references ?? []).filter((ref) => ref.type === "job").map((reference) => ({
				description: `${reference.id} · ${reference.repoOwner}/${reference.repoName}`,
				leadingIcon: PlayIcon,
				title: "Job"
			}));
		},
		successButtonText: `Using logs for ${topic} in ${skillArgs.repo}`,
		useSelectReference
	});
}
GetJobLogsButton.displayName = "GetJobLogsButton";
function getJobLogsSkillExecutionTopic(skillArgs) {
	if (skillArgs.jobId) return `job ${skillArgs.jobId}`;
	if (skillArgs.runId) return `workflow run ${skillArgs.runId}`;
	if (skillArgs.pullRequestNumber) return `pull request ${skillArgs.pullRequestNumber}`;
	if (skillArgs.workflowPath) return `workflow ${skillArgs.workflowPath}`;
	return "unknown job";
}
function ExpandableFunctionButton(t0) {
	const $ = c$1(19);
	const { additionalFooterContent, chatManager, errorButtonText, errorTitle, functionCall, inProgressMessage, noResultsMessage, resultsMapper, successButtonText, toolLink, toolName, useSelectReference } = t0;
	const [expanded, setExpanded] = useState(false);
	const containerId = useId();
	let t1;
	let t2;
	if ($[0] !== additionalFooterContent || $[1] !== chatManager || $[2] !== containerId || $[3] !== errorButtonText || $[4] !== errorTitle || $[5] !== expanded || $[6] !== functionCall || $[7] !== inProgressMessage || $[8] !== noResultsMessage || $[9] !== resultsMapper || $[10] !== successButtonText || $[11] !== toolLink || $[12] !== toolName || $[13] !== useSelectReference) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const results = resultsMapper(functionCall);
			let { status, errorMessage } = functionCall;
			if (functionCall.references?.length === 1) {
				const reference = functionCall.references[0];
				if (reference) bb1: switch (reference.type) {
					case "text":
						status = "error";
						errorMessage = reference.text;
						break bb1;
					case "unsupported":
						status = "unsupported";
						errorMessage = reference.text;
				}
			}
			if (status === "started") {
				let t3;
				if ($[16] !== inProgressMessage) {
					t3 = jsx(FunctionLoading$1, { children: inProgressMessage });
					$[16] = inProgressMessage;
					$[17] = t3;
				} else t3 = $[17];
				t2 = t3;
				break bb0;
			}
			let t3;
			if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
				t3 = () => setExpanded(_temp$1);
				$[18] = t3;
			} else t3 = $[18];
			t1 = jsxs(Fragment$1, { children: [jsx(ButtonComponent, {
				"aria-expanded": expanded,
				"aria-controls": containerId,
				className: clsx(FunctionLoadingUtils_module_default.functionReferenceButton, FunctionCallButton_module_default.functionCallButton),
				leadingVisual: expanded ? ChevronUpIcon : ChevronDownIcon,
				onClick: t3,
				variant: "invisible",
				children: jsx("span", {
					className: FunctionLoadingUtils_module_default.functionReferenceButtonContents,
					children: status === "error" ? errorButtonText : status === "unsupported" ? noResultsMessage : successButtonText
				})
			}), expanded && jsxs("div", {
				id: containerId,
				className: FunctionLoadingUtils_module_default.functionReferenceListContainer,
				children: [jsx(ActionList, { children: status === "error" ? jsxs(ActionList.Item, { children: [errorTitle, jsx(ActionList.Description, {
					variant: "block",
					children: errorMessage
				})] }) : status === "unsupported" ? jsxs(ActionList.Item, { children: [errorMessage, jsx(ActionList.Description, {
					truncate: true,
					children: ""
				})] }) : results.length === 0 ? jsxs(ActionList.Item, { children: [noResultsMessage, jsx(ActionList.Description, {
					truncate: true,
					children: "Try modifying your query by reframing your question."
				})] }) : results.map((res, i) => res && jsxs(ActionList.LinkItem, {
					className: "width-fit",
					href: res.url,
					onClick: (e) => {
						if (useSelectReference && res.reference) {
							chatManager.selectReference(res.reference);
							e.preventDefault();
						}
					},
					target: "_blank",
					rel: "noopener",
					children: [
						res.leadingIcon && jsx(ActionList.LeadingVisual, {
							style: res.leadingIconColor ? { color: res.leadingIconColor } : void 0,
							children: jsx(Octicon, { icon: res.leadingIcon })
						}),
						jsx(Truncate, {
							className: FunctionLoadingUtils_module_default.functionReferenceTitle,
							title: res.title,
							children: res.title
						}),
						jsx(ActionList.Description, {
							variant: "block",
							children: res.description
						})
					]
				}, i)) }), jsxs("span", {
					className: FunctionLoadingUtils_module_default.functionReferenceListFooter,
					children: [
						"Copilot used the",
						" ",
						jsx("a", {
							href: toolLink,
							target: "_blank",
							rel: "noopener noreferrer",
							children: toolName
						}),
						" ",
						"tool",
						additionalFooterContent && jsxs(Fragment$1, { children: [". ", additionalFooterContent] })
					]
				})]
			})] });
		}
		$[0] = additionalFooterContent;
		$[1] = chatManager;
		$[2] = containerId;
		$[3] = errorButtonText;
		$[4] = errorTitle;
		$[5] = expanded;
		$[6] = functionCall;
		$[7] = inProgressMessage;
		$[8] = noResultsMessage;
		$[9] = resultsMapper;
		$[10] = successButtonText;
		$[11] = toolLink;
		$[12] = toolName;
		$[13] = useSelectReference;
		$[14] = t1;
		$[15] = t2;
	} else {
		t1 = $[14];
		t2 = $[15];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
ExpandableFunctionButton.displayName = "ExpandableFunctionButton";
function _temp$1(exp) {
	return !exp;
}
function GetGitHubDataButton({ chatManager, functionCall, skillArgs, useSelectReference }) {
	let toolName = "GitHub API";
	const firstReference = functionCall.references?.[0];
	if (firstReference) {
		const referenceType = firstReference.type;
		if (referenceType.endsWith(".api")) {
			const refName = referenceType.split(".")[0];
			if (refName) toolName = `${refName.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")} API`;
		} else if (firstReference.type === "api-response") toolName = `${firstReference.resourceType} API`;
	}
	const messages = skillArgs.endpointDescription ? {
		errorButtonText: `An error occurred when using the GitHub API to ${skillArgs.endpointDescription}`,
		inProgressMessage: `Using the GitHub API to ${skillArgs.endpointDescription}`,
		noResultsMessage: `Unable to use the GitHub API to ${skillArgs.endpointDescription}`,
		successButtonText: `Using the GitHub API to ${skillArgs.endpointDescription}`
	} : {
		errorButtonText: `An error occurred when fetching from ${skillArgs.endpoint}`,
		inProgressMessage: `Fetching endpoint ${skillArgs.endpoint}`,
		noResultsMessage: `Unable to fetch from ${skillArgs.endpoint}`,
		successButtonText: `Using endpoint ${skillArgs.endpoint}`
	};
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorTitle: "An error occurred when fetching data from the GitHub API",
		toolLink: "https://docs.github.com/en/enterprise-cloud@latest/copilot/github-copilot-enterprise/copilot-chat-in-github/using-github-copilot-chat-in-githubcom#currently-available-skills",
		toolName,
		functionCall,
		errorButtonText: messages.errorButtonText,
		inProgressMessage: messages.inProgressMessage,
		noResultsMessage: messages.noResultsMessage,
		successButtonText: messages.successButtonText,
		useSelectReference,
		resultsMapper: (execution) => execution.references?.filter((ref) => ref.type !== "text").map((reference) => getAPIReferenceDisplayData(reference, skillArgs)) ?? []
	});
}
GetGitHubDataButton.displayName = "GetGitHubDataButton";
function getAPIReferenceDisplayData(reference, skillArgs) {
	switch (reference.type) {
		case "release.api": return {
			description: `Release ${reference.tag_name} · ${skillArgs.repo}`,
			leadingIcon: TagIcon,
			title: reference.name ?? "Release",
			url: reference.html_url
		};
		case "issue.api": return {
			description: `#${reference.number} · ${skillArgs.repo}`,
			leadingIcon: IssueOpenedIcon,
			title: reference.title ?? "Issue",
			url: reference.html_url
		};
		case "pull-request.api": return {
			description: `#${reference.number} · ${skillArgs.repo}`,
			leadingIcon: GitPullRequestIcon,
			title: reference.title ?? "Pull request",
			url: reference.html_url
		};
		case "repository.api": return {
			description: reference.description || "",
			title: reference.name,
			leadingIcon: RepoIcon,
			url: reference.html_url
		};
		case "commit.api": return {
			description: `${reference.sha} · ${skillArgs.repo}`,
			leadingIcon: GitCommitIcon,
			title: reference.commit.message ?? "Commit",
			url: reference.html_url
		};
		case "topic.api": return {
			description: reference.short_description || "",
			leadingIcon: HashIcon,
			title: reference.display_name ?? reference.name
		};
		case "api-response": switch (reference.resourceType) {
			case "Repository": return {
				description: reference.data.description || "",
				title: reference.data.name,
				leadingIcon: RepoIcon,
				url: reference.data.html_url
			};
			case "Issue": return {
				description: `#${reference.data.number} · ${skillArgs.repo}`,
				leadingIcon: IssueOpenedIcon,
				title: reference.data.title ?? "Issue",
				url: reference.data.html_url
			};
			case "Release": return {
				description: `Release ${reference.data.tag_name} · ${skillArgs.repo}`,
				leadingIcon: TagIcon,
				title: reference.data.name ?? "Release",
				url: reference.data.html_url
			};
			case "PullRequest": return {
				description: `#${reference.data.number} · ${skillArgs.repo}`,
				leadingIcon: GitPullRequestIcon,
				title: reference.data.title ?? "Pull request",
				url: reference.data.html_url
			};
			case "Commit": return {
				description: `${reference.data.sha} · ${skillArgs.repo}`,
				leadingIcon: GitCommitIcon,
				title: reference.data.commit.message ?? "Commit",
				url: reference.data.html_url
			};
			case "Topic": return {
				description: reference.data.short_description || "",
				leadingIcon: HashIcon,
				title: reference.data.display_name ?? reference.data.name
			};
			default: return {
				description: "API endpoint returned results successfully",
				leadingIcon: InfoIcon,
				title: "API results"
			};
		}
		default: return {
			description: "API endpoint returned results successfully",
			leadingIcon: InfoIcon,
			title: "API results"
		};
	}
}
function FigmaButton({ chatManager, functionCall, skillArgs }) {
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		chatManager,
		errorButtonText: `An error occurred when retrieving “${skillArgs.name}”`,
		errorTitle: "An error occurred retrieving Figma file",
		toolLink: "https://figma.com",
		toolName: "Get Figma",
		functionCall,
		inProgressMessage: `Getting Figma file “${skillArgs.name}”`,
		noResultsMessage: `Unable to retrieve “${skillArgs.name}”`,
		resultsMapper: (execution) => {
			const result = execution.references?.[0];
			return [{
				title: result?.title || "",
				url: result?.url || "",
				description: ""
			}];
		},
		successButtonText: `Using result from “${skillArgs.name}”`,
		useSelectReference: false
	});
}
FigmaButton.displayName = "FigmaButton";
var copilotInGithubSupportLink = "https://docs.github.com/en/support/contacting-github-support/using-copilot-in-github-support";
function SupportSearchButton({ chatManager, functionCall, skillArgs }) {
	const query = skillArgs.rawUserQuery;
	return /* @__PURE__ */ jsx(ExpandableFunctionButton, {
		additionalFooterContent: /* @__PURE__ */ jsx(Link, {
			href: copilotInGithubSupportLink,
			rel: "nofollow",
			target: "_blank",
			children: "Information on using Copilot in GitHub Support"
		}),
		chatManager,
		errorButtonText: `An error occurred when searching for “${query}”`,
		errorTitle: "An error occurred when searching support documents",
		toolLink: copilotInGithubSupportLink,
		toolName: "Support Search",
		functionCall,
		inProgressMessage: `Searching support documents for “${query}”`,
		noResultsMessage: `No support documents for “${query}” were found`,
		resultsMapper: (execution) => {
			return (execution.references?.[0]?.results ?? []).map((result) => ({
				title: result.title,
				url: result.url,
				description: result.url
			}));
		},
		successButtonText: `Using support search results for “${query}”`,
		useSelectReference: false
	});
}
/**
* Remove the 'repo:' that's likely at the beginning of the scoping query
*/
SupportSearchButton.displayName = "SupportSearchButton";
function stripRepoQualifier(scopingQuery) {
	if (scopingQuery.startsWith("repo:")) return scopingQuery.substring(5);
	else return scopingQuery;
}
function snippetMapper(execution) {
	return (execution.references ?? []).map((reference) => reference.type === "file" || reference.type === "snippet" ? {
		description: referencePath(reference),
		leadingIcon: CodeIcon,
		reference,
		title: referenceName(reference),
		url: reference.url
	} : void 0);
}
var CodeSearchIcon = () => /* @__PURE__ */ jsx(SearchIcon, {});
CodeSearchIcon.displayName = "CodeSearchIcon";
var GetFileIcon = () => /* @__PURE__ */ jsx(FileIcon, {});
GetFileIcon.displayName = "GetFileIcon";
var ReleaseIcon = () => /* @__PURE__ */ jsx(TagIcon, {});
ReleaseIcon.displayName = "ReleaseIcon";
var JobIcon = () => /* @__PURE__ */ jsx(PlayIcon, {});
JobIcon.displayName = "JobIcon";
var SearchBookIcon = () => /* @__PURE__ */ jsx(BookIcon, {});
SearchBookIcon.displayName = "SearchBookIcon";
var DiscussionIcon = () => /* @__PURE__ */ jsx(CommentDiscussionIcon, {});
DiscussionIcon.displayName = "DiscussionIcon";
var PlanIcon = () => /* @__PURE__ */ jsx(TasklistIcon, {});
PlanIcon.displayName = "PlanIcon";
var IssueDraftIcon = () => /* @__PURE__ */ jsx(IssueDraftIcon, {});
IssueDraftIcon.displayName = "IssueDraftIcon";
var AgentTaskIcon = () => /* @__PURE__ */ jsx(AgentIcon, {});
AgentTaskIcon.displayName = "AgentTaskIcon";
var DEFAULT_RESPONDING_MESSAGE = "planning response";
var functionMetadataCollection = (args) => {
	switch (args.kind) {
		case "bing-search": return {
			id: "bing-search",
			callId: args.callId,
			referenceType: "web-search",
			loadingText: `Using Bing to search ${args.user_prompt ? `for "${args.user_prompt}"` : "the web"}`,
			completedText: `Bing results ${args.user_prompt ? `for "${args.user_prompt}"` : "from the web"}`,
			icon: BingIcon,
			name: "Bing search",
			activeSkillText: "searching Bing"
		};
		case "lexical-code-search-githubread":
		case "lexical-code-search": return {
			id: "lexical-codesearch",
			callId: args.callId,
			loadingText: `Search for "${args.query}" in "${args.scopingQuery}"`,
			completedText: `Search results for "${args.query}" in "${args.scopingQuery}"`,
			icon: CodeSearchIcon,
			name: "Code search",
			activeSkillText: "searching the codebase"
		};
		case "semantic-code-search": return {
			id: "semantic-codesearch",
			callId: args.callId,
			loadingText: `Search for "${args.query}" in "${args.repoOwner}/${args.repoName}"`,
			completedText: `Search results for "${args.query}" in "${args.repoOwner}/${args.repoName}"`,
			icon: CodeSearchIcon,
			name: "Code search",
			activeSkillText: "searching the codebase"
		};
		case "getalert": return {
			id: "getalert",
			callId: args.callId,
			loadingText: `Retrieving information about alerts`,
			completedText: `Including information about alerts`,
			icon: () => /* @__PURE__ */ jsx(ShieldIcon, {}),
			name: "Get alert",
			activeSkillText: "getting alert"
		};
		case "get-github-data": return {
			id: "get-github-data",
			callId: args.callId,
			loadingText: `Fetching ${args.endpoint}`,
			completedText: `Results of ${args.endpoint}`,
			icon: ReleaseIcon,
			name: "Get GitHub Data",
			activeSkillText: "getting data"
		};
		case "get-actions-job-logs": {
			const topic = getJobLogsSkillExecutionTopic(args);
			const capitalizedTopic = topic.charAt(0).toUpperCase() + topic.slice(1);
			return {
				id: "get-actions-jog-logs",
				callId: args.callId,
				loadingText: `Retrieving ${topic} in ${args.repo}`,
				completedText: `${capitalizedTopic} in ${args.repo}`,
				icon: JobIcon,
				name: "Get job logs",
				activeSkillText: "getting job logs"
			};
		}
		case "getdiscussion": return {
			id: "getdiscussion",
			callId: args.callId,
			loadingText: `Fetching discussion ${args.discussionNumber}`,
			completedText: `Details about discussion #${args.discussionNumber}`,
			icon: DiscussionIcon,
			name: "Get discussion",
			activeSkillText: "getting discussion"
		};
		case "getfile": return {
			id: "getfile",
			callId: args.callId,
			loadingText: `Searching for file`,
			completedText: `Using results of get file`,
			icon: GetFileIcon,
			name: "Get file",
			activeSkillText: "searching for file"
		};
		case "getfilechanges": return {
			id: "getfilechanges",
			callId: args.callId,
			loadingText: `Searching for file changes`,
			completedText: `File changes for ${args.path} in ${args.repo}`,
			icon: GetFileIcon,
			name: "Get file changes",
			activeSkillText: "searching for file changes"
		};
		case "planskill": return {
			id: "planskill",
			callId: args.callId,
			loadingText: `Planning response...`,
			completedText: `Plan created`,
			icon: PlanIcon,
			name: "Plan skill",
			activeSkillText: "planning response"
		};
		case "support-search": return {
			id: "supportsearch",
			callId: args.callId,
			loadingText: `Searching for support documents`,
			completedText: `Using results of support search`,
			icon: SearchBookIcon,
			name: "Support search",
			activeSkillText: "searching for support documents"
		};
		case "get-figma": return {
			id: "getfigma",
			callId: args.callId,
			loadingText: "Analyzing Figma file",
			completedText: "Using results of Figma file",
			icon: SearchBookIcon,
			name: "Get Figma",
			activeSkillText: "analyzing Figma file"
		};
		case "codesearchagentskill": return {
			id: "codesearchagentskill",
			callId: args.callId,
			loadingText: "Using the code search agent",
			completedText: "Using results of code search agent",
			icon: SearchBookIcon,
			name: "Code Search Agent",
			activeSkillText: "searching the codebase"
		};
		case "github-draft-issue_draft-issue": {
			let loadingText;
			let completedText;
			if (args.issueNumber) {
				loadingText = args.repository ? `Drafting update for @${args.repository}/issues/${args.issueNumber}` : "Drafting update";
				completedText = args.repository ? `Drafted update for @${args.repository}/issues/${args.issueNumber}` : "Drafted update";
			} else {
				loadingText = args.repository ? `Drafting issue in ${args.repository}` : "Drafting issue";
				completedText = args.repository ? `Drafted issue in ${args.repository}` : "Drafted issue";
			}
			return {
				id: "github-draft-issue_draft-issue",
				callId: args.callId,
				loadingText,
				completedText,
				icon: IssueDraftIcon,
				name: "GitHub Draft Issue Step: Draft Issue",
				activeSkillText: loadingText.toLowerCase()
			};
		}
		case "github-draft-issue_existing-issue": {
			const loadingText = args.repository ? `Drafting issue in ${args.repository}` : "Drafting issue";
			const completedText = args.repository ? `Drafted issue in ${args.repository}` : "Drafted issue";
			return {
				id: "github-draft-issue_existing-issue",
				callId: args.callId,
				loadingText,
				completedText,
				icon: IssueDraftIcon,
				name: "GitHub Draft Issue Step: Existing Issue",
				activeSkillText: loadingText.toLowerCase()
			};
		}
		case "github-draft-issue_repository-metadata": {
			const loadingText = `Fetching metadata from ${args.repository}`;
			const completedText = `Using metadata from ${args.repository}`;
			return {
				id: "github-draft-issue_repository-metadata",
				callId: args.callId,
				loadingText,
				completedText,
				icon: IssueDraftIcon,
				name: "GitHub Draft Issue Step: Repository Metadata",
				activeSkillText: loadingText.toLowerCase()
			};
		}
		case "github-draft-issue_get-issues": {
			const loadingText = (args.issueRefs || []).length > 1 ? "Fetching issues" : "Fetching issue";
			const completedText = (args.issueRefs || []).length > 1 ? "Fetched issues" : "Fetched issue";
			return {
				id: "github-draft-issue_get-issues",
				callId: args.callId,
				loadingText,
				completedText,
				icon: IssueDraftIcon,
				name: "GitHub Draft Issue Step: Get Issues",
				activeSkillText: loadingText.toLowerCase()
			};
		}
		case "github-coding-agent-immersive":
		case "github-coding-agent": {
			const loadingText = `Creating agent task in ${args.repository}`;
			const completedText = `Created agent task in ${args.repository}`;
			return {
				id: args.kind,
				callId: args.callId,
				loadingText,
				completedText,
				icon: AgentTaskIcon,
				name: "Copilot Coding Agent",
				activeSkillText: loadingText.toLowerCase()
			};
		}
		case "load_ability": return {
			id: "load_ability",
			callId: args.callId,
			loadingText: "Gathering what I need...",
			completedText: "Gathered additional information",
			icon: SearchBookIcon,
			name: "Gather Context",
			activeSkillText: "Gathering what I need..."
		};
	}
};
function FunctionCompleted({ maxWidth, functionMetadata }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [functionMetadata.icon(), /* @__PURE__ */ jsx(Truncate, {
		title: functionMetadata.completedText,
		maxWidth,
		children: functionMetadata.completedText
	})] });
}
FunctionCompleted.displayName = "FunctionCompleted";
function FunctionLoading({ maxWidth, functionMetadata }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [functionMetadata.icon(), /* @__PURE__ */ jsx(Truncate, {
		title: functionMetadata.loadingText,
		maxWidth,
		children: functionMetadata.loadingText
	})] });
}
FunctionLoading.displayName = "FunctionLoading";
function FunctionError({ functionCall, functionMetadata }) {
	return /* @__PURE__ */ jsxs("div", {
		className: FunctionLoadingUtils_module_default.errorContainer,
		children: [
			/* @__PURE__ */ jsxs(Heading$2, {
				as: "h3",
				className: FunctionLoadingUtils_module_default.errorHeading,
				children: ["An error occurred while ", functionMetadata.activeSkillText]
			}),
			/* @__PURE__ */ jsx("p", {
				className: FunctionLoadingUtils_module_default.errorMessage,
				children: functionCall.errorMessage
			}),
			/* @__PURE__ */ jsxs("p", {
				className: FunctionLoadingUtils_module_default.toolDescriptionText,
				children: [
					"Copilot used the ",
					/* @__PURE__ */ jsx("span", {
						className: FunctionLoadingUtils_module_default.toolNameHighlight,
						children: functionMetadata.name
					}),
					" tool"
				]
			})
		]
	});
}
FunctionError.displayName = "FunctionError";
function FunctionTitle({ functionCall, functionMetadata, panelWidth }) {
	const maxWidth = panelWidth ? panelWidth - 130 : copilotLocalStorage.DEFAULT_PANEL_WIDTH;
	const innerElement = functionCall?.status === "error" ? /* @__PURE__ */ jsx(FunctionError, {
		functionCall,
		functionMetadata
	}) : functionCall?.status === "completed" ? /* @__PURE__ */ jsx(FunctionCompleted, {
		maxWidth,
		functionMetadata
	}) : /* @__PURE__ */ jsx(FunctionLoading, {
		maxWidth,
		functionMetadata
	});
	return /* @__PURE__ */ jsx("div", {
		className: FunctionLoadingUtils_module_default.functionTitleContainer,
		children: innerElement
	});
}
FunctionTitle.displayName = "FunctionTitle";
function messageFromFunctionCall(functionCall) {
	if (!functionCall) return DEFAULT_RESPONDING_MESSAGE;
	const functionMetadata = metadataFromFunctionCall(functionCall);
	return functionCall.statusMessage ?? functionMetadata?.activeSkillText ?? DEFAULT_RESPONDING_MESSAGE;
}
function loadingMessageFromFunctionCall(functionCall) {
	if (!functionCall) return DEFAULT_RESPONDING_MESSAGE;
	return metadataFromFunctionCall(functionCall)?.loadingText ?? DEFAULT_RESPONDING_MESSAGE;
}
function metadataFromFunctionCall(functionCall) {
	if (!functionCall) return void 0;
	return functionMetadataCollection({
		...JSON.parse(functionCall?.arguments || "{}"),
		kind: functionCall.slug,
		callId: functionCall.callId
	});
}
var InterruptedBanner_module_default = {
	hasContent: "InterruptedBanner-module_RBlada_hasContent",
	interruptedBanner: "InterruptedBanner-module_RBlada_interruptedBanner"
};
function InterruptedBanner({ messageHasContent }) {
	return /* @__PURE__ */ jsx(Banner, {
		className: clsx(InterruptedBanner_module_default.interruptedBanner, messageHasContent && InterruptedBanner_module_default.hasContent),
		"data-testid": "chat-message-interrupted",
		description: "Copilot was interrupted before it could finish this message.",
		hideTitle: true,
		title: "Message interrupted",
		variant: "info"
	});
}
InterruptedBanner.displayName = "InterruptedBanner";
function RetryButton({ handleRetryMessage, disabled = false, showModelPicker = false, model, navigateToNewThread }) {
	const handleClick = () => {
		handleRetryMessage(model);
	};
	if (showModelPicker && (!navigateToNewThread || !model)) throw new Error("navigateToNewThread and model must be provided in order to show the model picker");
	return showModelPicker ? /* @__PURE__ */ jsx(ModelPicker, {
		onNewThreadSelected: navigateToNewThread,
		type: "message-retry",
		selectedModel: model,
		onModelSelected: handleRetryMessage,
		disabled
	}) : /* @__PURE__ */ jsx(IconButton, {
		variant: "invisible",
		"aria-label": "Retry",
		"data-testid": "retry-button",
		onClick: handleClick,
		icon: SyncIcon,
		disabled
	});
}
RetryButton.displayName = "RetryButton";
/** Renders a user message. */
function UserMessage(t0) {
	const $ = c$1(8);
	const { className, accessibleHeader } = t0;
	const { message } = useChatMessage();
	const text = message.content ?? "";
	let t1;
	if ($[0] !== text) {
		t1 = hasPotentialAgentMention(text);
		$[0] = text;
		$[1] = t1;
	} else t1 = $[1];
	const { availableAgents: t2 } = useAvailableAgents(t1);
	let t3;
	if ($[2] !== accessibleHeader || $[3] !== className || $[4] !== message.references || $[5] !== t2 || $[6] !== text) {
		const availableAgents = t2 === void 0 ? [] : t2;
		const messageTree = unified().use(userMessageParser, {
			references: message.references ?? [],
			agents: availableAgents,
			commands: []
		}).parse(text);
		t3 = jsxs(Fragment$1, { children: [accessibleHeader && jsx("h3", {
			className: "sr-only",
			children: accessibleHeader
		}), jsx("div", {
			className: clsx(UserMessage_module_default.container, className),
			children: messageTree.children.map(_temp)
		})] });
		$[2] = accessibleHeader;
		$[3] = className;
		$[4] = message.references;
		$[5] = t2;
		$[6] = text;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
/** Renders as link with hovercard if slug is valid; otherwise renders as plain text. */
UserMessage.displayName = "UserMessage";
function _temp(node, i) {
	switch (node.type) {
		case "text":
		case "command": return node.value;
		case "agent-mention": return jsx(AgentLink, {
			agent: node.data.mentionedAgent,
			children: node.value
		}, i);
		case "reference-mention": return node.data.mentionedReferenceId !== void 0 ? jsx("span", {
			className: UserMessage_module_default.mention,
			children: node.value
		}, i) : node.value;
	}
}
function AgentLink(t0) {
	const $ = c$1(5);
	const { agent, children } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	if ($[0] !== agent.integrationUrl || $[1] !== agent.slug || $[2] !== children || $[3] !== getHovercardAttributesForType) {
		const hovercardAttrs = getHovercardAttributesForType("copilot", { botSlug: agent.slug });
		t1 = jsx(Link, {
			href: agent.integrationUrl,
			...hovercardAttrs,
			className: UserMessage_module_default.mention,
			children
		});
		$[0] = agent.integrationUrl;
		$[1] = agent.slug;
		$[2] = children;
		$[3] = getHovercardAttributesForType;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
AgentLink.displayName = "AgentLink";
var CopilotSuggestions_module_default = {
	suggestionItem: "CopilotSuggestions-module_bGqrAa_suggestionItem",
	suggestionListHeading: "CopilotSuggestions-module_bGqrAa_suggestionListHeading",
	suggestionsList: "CopilotSuggestions-module_bGqrAa_suggestionsList"
};
var CopilotSuggestion = memo(function CopilotSuggestion({ suggestion, onSelect }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		onSelect: () => onSelect(suggestion),
		className: CopilotSuggestions_module_default.suggestionItem,
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: PaperAirplaneIcon }) }), /* @__PURE__ */ jsxs("span", { children: [" ", suggestion.question] })]
	});
});
CopilotSuggestion.displayName = "CopilotSuggestion";
var CopilotSuggestions = (t0) => {
	const $ = c$1(8);
	const { suggestionKind } = t0;
	const state = useChatState();
	const manager = useChatManager();
	let t1;
	if ($[0] !== manager || $[1] !== state) {
		t1 = (suggestion) => {
			manager.sendChatMessage({
				thread: getSelectedThread(state),
				content: suggestion.prompt ?? suggestion.question,
				intent: suggestion.intent,
				modeOverride: suggestion.mode,
				references: state.currentReferences,
				topic: state.currentTopic,
				context: state.context
			});
			sendEvent("copilot_generated_suggestion_click", {
				intent: suggestion.intent,
				mode: suggestion.mode,
				contextType: state.context?.[0]?.type,
				content: suggestion.question
			});
		};
		$[0] = manager;
		$[1] = state;
		$[2] = t1;
	} else t1 = $[2];
	const onClickSuggestion = t1;
	const isLoading = state.messagesLoading.state === "loading" || !!state.streamingMessage;
	const { suggestions } = state;
	const firstReference = state.currentReferences[0];
	const onlyReferenceIsRepo = state.currentReferences.length === 1 && firstReference?.type === "repository";
	const showCopilotSuggestions = Boolean(!isLoading && (onlyReferenceIsRepo || state.currentReferences.length === 0));
	let t2;
	if ($[3] !== onClickSuggestion || $[4] !== showCopilotSuggestions || $[5] !== suggestionKind || $[6] !== suggestions) {
		t2 = showCopilotSuggestions && !!suggestions && !!suggestions.suggestions ? jsxs(ActionList, {
			className: clsx("copilot-suggestions", CopilotSuggestions_module_default.suggestionsList),
			children: [suggestionKind === "initial" && jsx(ActionList.Heading, {
				as: "h2",
				className: CopilotSuggestions_module_default.suggestionListHeading,
				children: suggestionHeadingForReferenceType(suggestions.referenceType)
			}), suggestions?.suggestions.map((s) => jsx(CopilotSuggestion, {
				suggestion: s,
				onSelect: onClickSuggestion
			}, s.question))]
		}) : null;
		$[3] = onClickSuggestion;
		$[4] = showCopilotSuggestions;
		$[5] = suggestionKind;
		$[6] = suggestions;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
};
CopilotSuggestions.displayName = "CopilotSuggestions";
function suggestionHeadingForReferenceType(referenceType) {
	if (!referenceType) return "Ask anything:";
	return `Ask about the ${referenceType.replace(/-/g, " ")}:`;
}
var CopilotSuggestions_default = memo(CopilotSuggestions);
var LegalDisclaimer_module_default = { container: "LegalDisclaimer-module_Eu-kIa_container" };
var LegalDisclaimer = () => {
	return /* @__PURE__ */ jsxs("span", {
		className: LegalDisclaimer_module_default.container,
		children: [
			/* @__PURE__ */ jsx(Link, {
				href: "https://docs.github.com/en/copilot/responsible-use-of-github-copilot-features/responsible-use-of-github-copilot-chat-in-githubcom",
				inline: true,
				muted: true,
				children: "Copilot"
			}),
			" ",
			"uses AI. Check for mistakes."
		]
	});
};
LegalDisclaimer.displayName = "LegalDisclaimer";
function CopilotIconAnimation({ hidden }) {
	return /* @__PURE__ */ jsx("div", {
		"aria-hidden": hidden,
		children: /* @__PURE__ */ jsx(CopilotAnimation, {
			animationType: CopilotAnimationType.Idle,
			loopAnimation: true,
			size: 64
		})
	});
}
CopilotIconAnimation.displayName = "CopilotIconAnimation";
var ExperimentsDialog_module_default = {
	dialogContentContainer: "ExperimentsDialog-module_djTLEW_dialogContentContainer",
	experimentsInput: "ExperimentsDialog-module_djTLEW_experimentsInput"
};
var experimentsQuery = "repo:github/copilot-api path:experiments.go";
var ExperimentsDialog = ({ onDismiss, experimentsDialogRef }) => {
	const [experiments, setExperiments] = useState(() => getCopilotExperiments().join(","));
	const [statusMessage, setStatusMessage] = useState(void 0);
	const statusMessageAriaHack = useRef("​");
	const saveExperiments = () => {
		const experimentsArray = [];
		for (const pair of experiments.split(",")) {
			if (pair.trim() === "") continue;
			if (pair.split("=").length !== 2) {
				setStatusMessage(`Invalid experiment key=value pair${statusMessageAriaHack.current}`);
				statusMessageAriaHack.current += "​";
				return;
			} else setStatusMessage("");
			experimentsArray.push(pair);
		}
		setCopilotExperiments(experimentsArray);
		onDismiss();
	};
	const clearExperiments = () => {
		setExperiments("");
		setCopilotExperiments([]);
		setStatusMessage("");
		onDismiss();
	};
	return /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsxs(Dialog, {
		ref: experimentsDialogRef,
		onClose: onDismiss,
		title: "Experiments",
		width: "xlarge",
		children: [/* @__PURE__ */ jsx(Dialog.Body, { children: /* @__PURE__ */ jsx("div", {
			className: ExperimentsDialog_module_default.dialogContentContainer,
			children: /* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Experiments" }),
				/* @__PURE__ */ jsx(FormControl$1.Caption, { children: /* @__PURE__ */ jsxs("span", { children: [
					"List experiments as comma separated ",
					/* @__PURE__ */ jsx("code", { children: "key=value" }),
					" pairs. To see available experiments,",
					" ",
					/* @__PURE__ */ jsx(Link, {
						inline: true,
						target: "_blank",
						href: `/search?q=${encodeURIComponent(experimentsQuery)}`,
						children: "read this code"
					}),
					"."
				] }) }),
				/* @__PURE__ */ jsx(TextInput$1, {
					"aria-label": "Experiments",
					name: "experiments",
					value: experiments,
					onChange: (e) => setExperiments(e.target.value),
					onKeyDown: (e_0) => {
						if (e_0.key === "Enter") saveExperiments();
					},
					className: ExperimentsDialog_module_default.experimentsInput
				}),
				statusMessage && /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: statusMessage
				})
			] })
		}) }), /* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsx(Dialog.Buttons, { buttons: [
			{
				type: "button",
				onClick: clearExperiments,
				content: "Clear all",
				buttonType: "danger"
			},
			{
				type: "button",
				onClick: onDismiss,
				content: "Cancel"
			},
			{
				type: "button",
				onClick: saveExperiments,
				content: "Save",
				buttonType: "primary"
			}
		] }) })]
	}) });
};
ExperimentsDialog.displayName = "ExperimentsDialog";
var PromptDialog_module_default = {
	deleteToolButton: "PromptDialog-module_jsOvua_deleteToolButton",
	Dialog: "PromptDialog-module_jsOvua_Dialog",
	systemInstructionsTextarea: "PromptDialog-module_jsOvua_systemInstructionsTextarea",
	temperatureFormControl: "PromptDialog-module_jsOvua_temperatureFormControl",
	toolsSectionHeader: "PromptDialog-module_jsOvua_toolsSectionHeader"
};
var PromptDialog = ({ onDismiss, promptDialogRef }) => {
	const manager = useChatManager();
	const initialState = copilotLocalStorage.settings;
	const [systemInstructions, setSystemInstructions] = useState(initialState?.instructionPrompt || void 0);
	const [tools, setTools] = useState(initialState?.skillOverrides ?? []);
	const [temperature, setTemperature] = useState(initialState?.temperature || .7);
	const baseSystemPrompt = useRef(void 0);
	const savePrompt = () => {
		const toolsArray = tools.filter((tool) => tool.slug && tool.description);
		manager.setCopilotSettings({
			instructionPrompt: systemInstructions || "",
			skillOverrides: toolsArray,
			temperature
		});
		onDismiss();
	};
	const getAndSetSystemPrompt = useCallback(async () => {
		if (baseSystemPrompt.current) {
			setSystemInstructions(baseSystemPrompt.current);
			return;
		}
		const sysPrompt = await manager.getSystemPrompt();
		baseSystemPrompt.current = sysPrompt;
		setSystemInstructions(sysPrompt);
	}, [manager]);
	useEffect(() => {
		const getPrompt = async () => {
			if (systemInstructions === void 0) await getAndSetSystemPrompt();
		};
		getPrompt();
	}, [
		getAndSetSystemPrompt,
		manager,
		systemInstructions
	]);
	const onReset = useCallback(() => {
		getAndSetSystemPrompt();
		setTools([]);
		setTemperature(.7);
	}, [getAndSetSystemPrompt]);
	return /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsxs(Dialog, {
		ref: promptDialogRef,
		onClose: onDismiss,
		title: "Prompt Settings",
		width: "xlarge",
		className: PromptDialog_module_default.Dialog,
		children: [/* @__PURE__ */ jsxs(Dialog.Body, { children: [
			/* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, { children: "System Instructions" }),
				/* @__PURE__ */ jsx(FormControl$1.Caption, { children: /* @__PURE__ */ jsx("span", { children: "Make adjustments to the system instructions or add new instructions." }) }),
				/* @__PURE__ */ jsx(Textarea, {
					block: true,
					"aria-label": "Prompt",
					name: "Prompt",
					value: systemInstructions,
					onChange: (e) => setSystemInstructions(e.target.value),
					className: PromptDialog_module_default.systemInstructionsTextarea
				})
			] }),
			/* @__PURE__ */ jsxs(FormControl$1, {
				className: PromptDialog_module_default.temperatureFormControl,
				children: [
					/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Temperature" }),
					/* @__PURE__ */ jsx(FormControl$1.Caption, { children: "Controls the randomness of the model's responses. Lower temperatures are more deterministic, while higher temperatures are more random." }),
					/* @__PURE__ */ jsx(TextInput$1, {
						type: "number",
						min: "0",
						max: "1",
						step: "0.01",
						block: true,
						value: temperature,
						onChange: (e_0) => setTemperature(Number(e_0.target.value))
					})
				]
			}),
			/* @__PURE__ */ jsx("div", {
				className: PromptDialog_module_default.toolsSectionHeader,
				children: "Tools"
			}),
			tools.map((tool_0, key) => /* @__PURE__ */ jsxs(React.Fragment, { children: [/* @__PURE__ */ jsxs(Stack, {
				direction: "horizontal",
				className: "py-2",
				children: [
					/* @__PURE__ */ jsxs(FormControl$1, { children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Name" }),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: /* @__PURE__ */ jsx("span", { children: "Slug of tool you want to adjust" }) }),
						/* @__PURE__ */ jsx(TextInput$1, {
							defaultValue: tool_0.slug,
							onChange: (e_1) => {
								tools.map((t, index) => {
									if (index === key) t.slug = e_1.target.value;
								});
							}
						})
					] }),
					/* @__PURE__ */ jsxs(FormControl$1, { children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Description" }),
						/* @__PURE__ */ jsx(FormControl$1.Caption, { children: /* @__PURE__ */ jsx("span", { children: "Make changes to the tool description" }) }),
						/* @__PURE__ */ jsx(TextInput$1, {
							defaultValue: tool_0.description,
							onChange: (e_2) => {
								tools.map((t_0, index_0) => {
									if (index_0 === key) tool_0.description = e_2.target.value;
								});
							}
						})
					] }),
					/* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
						id: "toggle",
						children: "Enabled?"
					}), /* @__PURE__ */ jsx(ToggleSwitch, {
						size: "small",
						"aria-labelledby": "toggle",
						defaultChecked: tool_0.enabled,
						onChange: (newValue) => {
							tools.map((t_1, index_1) => {
								if (index_1 === key) t_1.enabled = newValue;
							});
						}
					})] }),
					/* @__PURE__ */ jsx(IconButton, {
						icon: TrashIcon,
						"aria-label": "Delete tool",
						variant: "invisible",
						onClick: () => {
							const newTools = [...tools];
							if (tools.length === 1) setTools([]);
							else {
								newTools.splice(key, 1);
								setTools(newTools);
							}
						},
						className: PromptDialog_module_default.deleteToolButton
					})
				]
			}), key === tools.length - 1 && /* @__PURE__ */ jsx(ButtonComponent, {
				leadingVisual: /* @__PURE__ */ jsx(PlusIcon, {}),
				onClick: () => setTools([...tools, {
					slug: "",
					description: "",
					enabled: true
				}]),
				variant: "invisible",
				size: "small",
				children: "Add another tool"
			})] }, `tool-${tool_0.slug}-${key}`)),
			tools.length === 0 && /* @__PURE__ */ jsx(ButtonComponent, {
				leadingVisual: /* @__PURE__ */ jsx(PlusIcon, {}),
				onClick: () => setTools([...tools, {
					slug: "",
					description: "",
					enabled: true
				}]),
				variant: "invisible",
				size: "small",
				children: "Add a tool"
			})
		] }), /* @__PURE__ */ jsx(Dialog.Footer, { children: /* @__PURE__ */ jsx(Dialog.Buttons, { buttons: [
			{
				type: "button",
				onClick: onDismiss,
				content: "Cancel"
			},
			{
				type: "button",
				onClick: onReset,
				content: "Reset"
			},
			{
				type: "button",
				onClick: savePrompt,
				content: "Save",
				buttonType: "primary"
			}
		] }) })]
	}) });
};
PromptDialog.displayName = "PromptDialog";
var StaffDialogs = ({ dialogType, onDismiss, staffDialogRef }) => {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [dialogType === DialogType.Experiments && /* @__PURE__ */ jsx(ExperimentsDialog, {
		experimentsDialogRef: staffDialogRef,
		onDismiss
	}), dialogType === DialogType.Prompt && /* @__PURE__ */ jsx(PromptDialog, {
		promptDialogRef: staffDialogRef,
		onDismiss
	})] });
};
StaffDialogs.displayName = "StaffDialogs";
var ThreadListView_module_default = {
	ActionList: "ThreadListView-module_E9mRua_ActionList",
	deleteAllButton: "ThreadListView-module_E9mRua_deleteAllButton",
	emptyStateContainer: "ThreadListView-module_E9mRua_emptyStateContainer",
	errorStateContainer: "ThreadListView-module_E9mRua_errorStateContainer",
	loadingStateContainer: "ThreadListView-module_E9mRua_loadingStateContainer"
};
function ThreadListView() {
	const state = useChatState();
	const manager = useChatManager();
	const threads = useMemo(() => manager.sortAndFilterThreads(state.threads, (thread) => thread.customCopilotID === void 0), [state.threads, manager]);
	const [shouldShowDeleteAllConfirmation, setShouldShowDeleteAllConfirmation] = useState(false);
	const returnFocusRef = useRef(null);
	const showDeleteAllButton = copilotFeatureFlags.deleteAllConversations;
	if (state.threadsLoading.state === "loading" && threads.length < 2) return /* @__PURE__ */ jsxs("div", {
		className: ThreadListView_module_default.loadingStateContainer,
		children: [/* @__PURE__ */ jsx(Spinner, {}), "Loading threads…"]
	});
	return /* @__PURE__ */ jsx(Fragment$1, { children: state.threadsLoading.state === "error" ? /* @__PURE__ */ jsx(ErrorView, { threadsLoading: state.threadsLoading }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [threads.length > 0 && /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(ActionList, {
		className: ThreadListView_module_default.ActionList,
		children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [
			/* @__PURE__ */ jsx(ActionList.GroupHeading, {
				as: "h3",
				children: "All conversations"
			}),
			/* @__PURE__ */ jsx(ListView, {
				threads,
				manager
			}),
			threads.length > 1 && showDeleteAllButton && /* @__PURE__ */ jsx(DeleteAll, {
				threads,
				manager,
				shouldDeleteAllThreads: shouldShowDeleteAllConfirmation,
				setShouldDeleteAllThreads: setShouldShowDeleteAllConfirmation,
				returnFocusRef
			})
		] })
	}) }), threads.length === 0 && /* @__PURE__ */ jsxs("div", {
		className: ThreadListView_module_default.emptyStateContainer,
		children: [/* @__PURE__ */ jsx("p", {
			className: "tmp-mb-3",
			children: "There are no conversations at the moment."
		}), /* @__PURE__ */ jsx(ButtonComponent, {
			onClick: () => manager.selectThread(null),
			block: true,
			children: "Start a new conversation"
		})]
	})] }) });
}
ThreadListView.displayName = "ThreadListView";
var ErrorView = ({ threadsLoading }) => {
	return /* @__PURE__ */ jsx("div", {
		className: ThreadListView_module_default.errorStateContainer,
		children: /* @__PURE__ */ jsxs(Flash, {
			variant: "warning",
			children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }), threadsLoading.state === "error" ? threadsLoading.error : "Something went wrong. Please try again later."]
		})
	});
};
ErrorView.displayName = "ErrorView";
var ListView = ({ threads, manager }) => {
	return /* @__PURE__ */ jsx(Fragment$1, { children: threads.map((thread) => {
		return /* @__PURE__ */ jsxs(ActionList.Item, {
			onSelect: () => manager.selectThread(thread),
			className: "mr-0 pr-2",
			children: [
				/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CommentIcon, {}) }),
				threadName(thread),
				/* @__PURE__ */ jsx(ActionList.Description, {
					variant: "inline",
					className: "flex-shrink-0",
					children: /* @__PURE__ */ jsx(RelativeTime, {
						date: new Date(Date.parse(thread.updatedAt)),
						format: "relative"
					})
				}),
				/* @__PURE__ */ jsx(ActionList.TrailingAction, {
					icon: TrashIcon,
					label: `Delete conversation: "${threadName(thread)}"`,
					onClick: async () => manager.deleteThreadKeepSelection(thread)
				})
			]
		}, thread.id);
	}) });
};
ListView.displayName = "ListView";
var DeleteAll = ({ threads, manager, shouldDeleteAllThreads, setShouldDeleteAllThreads, returnFocusRef }) => {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ButtonComponent, {
		"data-testid": `delete-all-threads-button`,
		ref: returnFocusRef,
		onClick: () => setShouldDeleteAllThreads(true),
		className: ThreadListView_module_default.deleteAllButton,
		children: "Delete all conversations"
	}), shouldDeleteAllThreads === true && /* @__PURE__ */ jsx("div", {
		"data-testid": `delete-all-threads-dialog`,
		children: /* @__PURE__ */ jsxs(Dialog, {
			title: "Delete all conversations",
			width: "small",
			onClose: () => setShouldDeleteAllThreads(false),
			returnFocusRef,
			footerButtons: [{
				buttonType: "default",
				content: "Cancel",
				onClick: () => setShouldDeleteAllThreads(false)
			}, {
				buttonType: "danger",
				content: "Delete",
				onClick: async () => {
					await manager.deleteAllThreadKeepSelection(threads);
					setShouldDeleteAllThreads(false);
				},
				autoFocus: true
			}],
			children: [
				"You are trying to delete ",
				threads.length,
				" conversations. Are you sure? This can’t be undone."
			]
		})
	})] });
};
DeleteAll.displayName = "DeleteAll";
export { loadingMessageFromFunctionCall as C, useChatMessageBehavior as D, useChat as E, useDetails as O, UserMessage as S, metadataFromFunctionCall as T, ReferencesList as _, ChatMessageReferencesList as a, ThreadListView as b, CodeMirrorDiff as c, CopilotIconAnimation as d, CopilotSuggestions_default as f, LegalDisclaimer as g, InterruptedBanner as h, ChatMessageReferenceTokens as i, useGroupedMessages as k, Confirmation as l, Feedback as m, AmbientErrorBanner as n, ChatMessage_module_default as o, ErrorMessage as p, ChatImage as r, ChatMessagesGroup as s, AgentErrors as t, CopilotBadge as u, RetryButton as v, messageFromFunctionCall as w, Toolbar as x, StaffDialogs as y };
