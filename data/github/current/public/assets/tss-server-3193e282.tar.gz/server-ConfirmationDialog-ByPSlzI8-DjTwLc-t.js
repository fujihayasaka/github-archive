import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { useCallback } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { createRoot } from "react-dom/client";
var classes = { "BaseStyles": "prc-src-BaseStyles-aopSS" };
function BaseStyles(t0) {
	const $ = c(20);
	let children;
	let className;
	let color;
	let rest;
	let style;
	let t1;
	if ($[0] !== t0) {
		({children, color, className, as: t1, style, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = color;
		$[4] = rest;
		$[5] = style;
		$[6] = t1;
	} else {
		children = $[1];
		className = $[2];
		color = $[3];
		rest = $[4];
		style = $[5];
		t1 = $[6];
	}
	const Component = t1 === void 0 ? "div" : t1;
	let t2;
	if ($[7] !== className) {
		t2 = clsx(classes.BaseStyles, className);
		$[7] = className;
		$[8] = t2;
	} else t2 = $[8];
	const newClassName = t2;
	let t3;
	if ($[9] !== color) {
		t3 = { "--BaseStyles-fgColor": color };
		$[9] = color;
		$[10] = t3;
	} else t3 = $[10];
	const baseStyles = t3;
	let t4;
	if ($[11] !== baseStyles || $[12] !== style) {
		t4 = {
			...baseStyles,
			...style
		};
		$[11] = baseStyles;
		$[12] = style;
		$[13] = t4;
	} else t4 = $[13];
	let t5;
	if ($[14] !== Component || $[15] !== children || $[16] !== newClassName || $[17] !== rest || $[18] !== t4) {
		t5 = /* @__PURE__ */ jsx(Component, {
			className: newClassName,
			"data-portal-root": true,
			style: t4,
			...rest,
			children
		});
		$[14] = Component;
		$[15] = children;
		$[16] = newClassName;
		$[17] = rest;
		$[18] = t4;
		$[19] = t5;
	} else t5 = $[19];
	return t5;
}
/**
* A ConfirmationDialog is a special kind of dialog with more rigid behavior. It
* is used to confirm a user action. ConfirmationDialogs always have exactly
* two buttons: one to cancel the action and one to confirm it. No custom
* rendering capabilities are provided for ConfirmationDialog.
*/
var ConfirmationDialog = (props) => {
	const { onClose, title, cancelButtonContent = "Cancel", confirmButtonContent = "OK", confirmButtonType = "normal", cancelButtonLoading = false, confirmButtonLoading = false, children, className, width = "medium", height, overrideButtonFocus } = props;
	const onCancelButtonClick = useCallback(() => {
		onClose("cancel");
	}, [onClose]);
	const onConfirmButtonClick = useCallback(() => {
		onClose("confirm");
	}, [onClose]);
	const buttonToFocus = overrideButtonFocus !== void 0 ? overrideButtonFocus : confirmButtonType === "danger" ? "cancel" : "confirm";
	return /* @__PURE__ */ jsx(Dialog, {
		onClose,
		title,
		footerButtons: [{
			content: cancelButtonContent,
			onClick: onCancelButtonClick,
			autoFocus: buttonToFocus === "cancel",
			loading: cancelButtonLoading
		}, {
			content: confirmButtonContent,
			buttonType: confirmButtonType,
			onClick: onConfirmButtonClick,
			autoFocus: buttonToFocus === "confirm",
			loading: confirmButtonLoading
		}],
		role: "alertdialog",
		width,
		height,
		className,
		children
	});
};
ConfirmationDialog.displayName = "ConfirmationDialog";
var hostElement = null;
async function confirm(options) {
	const { content, ...confirmationDialogProps } = options;
	return new Promise((resolve) => {
		hostElement ||= document.createElement("div");
		if (!hostElement.isConnected) document.body.append(hostElement);
		const root = createRoot(hostElement);
		const onClose = (gesture) => {
			root.unmount();
			if (gesture === "confirm") resolve(true);
			else resolve(false);
		};
		root.render(/* @__PURE__ */ jsx(BaseStyles, { children: /* @__PURE__ */ jsx(ConfirmationDialog, {
			...confirmationDialogProps,
			onClose,
			children: content
		}) }));
	});
}
/**
* This hook takes no parameters and returns an `async` function, `confirm`. When `confirm`
* is called, it shows the confirmation dialog. When the dialog is dismissed, a promise is
* resolved with `true` or `false` depending on whether or not the confirm button was used.
*/
function useConfirm() {
	return useCallback((options) => {
		return confirm(options);
	}, []);
}
export { useConfirm as n, ConfirmationDialog as t };
