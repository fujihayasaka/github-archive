import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { jsx } from "react/jsx-runtime";
var LoadingFallback = () => {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-column flex-items-center pr-py-3",
		children: /* @__PURE__ */ jsx(Spinner, { "aria-label": "Loading" })
	});
};
LoadingFallback.displayName = "LoadingFallback";
export { LoadingFallback as t };
