import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { n as LabelWithLink, t as FeedbackLink } from "./server-LabelWithLink-B6_1EdmD-Ce_5nDOi.js";
import { jsx } from "react/jsx-runtime";
/** Indicates a feature that is only available internally to GitHub staff. */
var AlphaLabel = ({ children = "Private preview", feedbackUrl, className }) => /* @__PURE__ */ jsx(LabelWithLink, {
	className,
	label: /* @__PURE__ */ jsx(Label, {
		variant: "secondary",
		children
	}),
	link: feedbackUrl ? /* @__PURE__ */ jsx(FeedbackLink, { feedbackUrl }) : void 0
});
AlphaLabel.displayName = "AlphaLabel";
export { AlphaLabel as t };
