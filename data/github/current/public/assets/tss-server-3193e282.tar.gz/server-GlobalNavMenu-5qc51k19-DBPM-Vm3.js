performance.mark("js-parse-end:server-GlobalNavMenu-5qc51k19-DBPM-Vm3.js");
import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { i as VisuallyHidden, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { An as McpIcon, Bt as GiftIcon, Dn as MarkGithubIcon, Hr as SparkleIcon, J as CodespacesIcon, Jt as GitPullRequestIcon, Mi as XIcon, R as ChevronUpIcon, X as CommentDiscussionIcon, Yt as GlobeIcon, an as IconButton, bn as Link, et as CopilotIcon, fn as IssueOpenedIcon, gr as RepoIcon, n as ActionList, nn as HomeIcon, oi as TelescopeIcon, qr as Stack, ri as TableIcon, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { i as reactFetchJSON, o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as useInfiniteQuery, l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { R as dismissUserNoticePath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { n as getCookie, r as setCookie, t as deleteCookie } from "./server-cookies-DndQO37X-vNR87gG9.js";
import { t as hotkey_exports } from "./server-hotkey-CjmZAe2y-CaimUUmF.js";
import { t as createPersister } from "./server-react-query-persister-D24LKcxB-BQe2u09x.js";
import { n as Type, t as Compile } from "./server-typebox-DK1Y6Tz8-C4QyQJfa.js";
import { a as GlobalCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { t as useExternalAnchor } from "./server-react-partial-anchor-DSxm7g5E-DAe-R2_8.js";
import { t as NavList } from "./server-NavList-D8uWdChJ-BgWGw1cA.js";
import { n as analyticsCategory, r as useGlobalNavAnalytics, t as GlobalNavAnalyticsProvider } from "./server-constants-BeftNbDC-CL1QQX4_.js";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:GlobalNavMenu-5qc51k19.js");
var styles_module_default = {
	groupHeading: "styles-module_dA-zVa_groupHeading",
	searchSpinner: "styles-module_dA-zVa_searchSpinner"
};
function buildQueryParams(params) {
	const queryString = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([, v]) => v !== null && v !== void 0).map(([k, v]) => [k, String(v)]))).toString();
	return queryString ? `?${queryString}` : "";
}
var DynamicSidePanelItemSchema = Type.Object({
	id: Type.Number(),
	value: Type.String(),
	url: Type.String(),
	avatar_url: Type.String(),
	has_more: Type.Optional(Type.Boolean())
});
function SidePanelItemsList({ items, onItemClick }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: items.flat().map((item) => /* @__PURE__ */ jsxs(NavList.Item, {
		href: item.url,
		onClick: onItemClick,
		children: [/* @__PURE__ */ jsx(NavList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, {
			size: 16,
			src: item.avatar_url
		}) }), item.value]
	}, item.value)) });
}
SidePanelItemsList.displayName = "SidePanelItemsList";
function useSidePanelSearch(t0) {
	const $ = c(17);
	const { items, searchUrl, itemsPerPage, initialItemsPerPage, maxPages } = t0;
	const [searchMode, setSearchMode] = useState(false);
	const [searchTerm, setSearchTerm] = useState("");
	const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (value) => setDebouncedSearchTerm(value);
		$[0] = t1;
	} else t1 = $[0];
	const debouncedSetSearchTerm = useDebounce(t1, 150);
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => {
			setSearchMode(true);
		};
		$[1] = t2;
	} else t2 = $[1];
	const activateSearch = t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			setSearchMode(false);
			setSearchTerm("");
			setDebouncedSearchTerm("");
		};
		$[2] = t3;
	} else t3 = $[2];
	const deactivateSearch = t3;
	let t4;
	if ($[3] !== debouncedSetSearchTerm) {
		t4 = (e) => {
			const value_0 = e.target.value;
			setSearchTerm(value_0);
			debouncedSetSearchTerm(value_0);
		};
		$[3] = debouncedSetSearchTerm;
		$[4] = t4;
	} else t4 = $[4];
	const handleSearchTermChange = t4;
	const t5 = searchUrl || "";
	let t6;
	if ($[5] !== debouncedSearchTerm || $[6] !== initialItemsPerPage || $[7] !== itemsPerPage || $[8] !== maxPages || $[9] !== t5) {
		t6 = {
			searchUrl: t5,
			searchTerm: debouncedSearchTerm,
			itemsPerPage,
			initialItemsPerPage,
			maxPages
		};
		$[5] = debouncedSearchTerm;
		$[6] = initialItemsPerPage;
		$[7] = itemsPerPage;
		$[8] = maxPages;
		$[9] = t5;
		$[10] = t6;
	} else t6 = $[10];
	const searchQuery = useSidePanelItemsSearch(t6);
	const renderedItems = searchMode && debouncedSearchTerm && searchQuery.data ? searchQuery.data : items;
	let t7;
	if ($[11] !== handleSearchTermChange || $[12] !== renderedItems || $[13] !== searchMode || $[14] !== searchQuery || $[15] !== searchTerm) {
		t7 = {
			searchMode,
			searchTerm,
			searchQuery,
			activateSearch,
			deactivateSearch,
			handleSearchTermChange,
			renderedItems
		};
		$[11] = handleSearchTermChange;
		$[12] = renderedItems;
		$[13] = searchMode;
		$[14] = searchQuery;
		$[15] = searchTerm;
		$[16] = t7;
	} else t7 = $[16];
	return t7;
}
function DynamicSidePanelItems(props) {
	const $ = c(26);
	const { items, title, hasNextPage, itemsPerPage, initialItemsPerPage, maxPages, isLoading, fetchNextPage, analytics, searchLabel, searchUrl } = props;
	const { sendItemClick } = useGlobalNavAnalytics(props.analytics.subCategory);
	const [showMoreClickCount, setShowMoreClickCount] = useState(0);
	let t0;
	if ($[0] !== initialItemsPerPage || $[1] !== items || $[2] !== itemsPerPage || $[3] !== maxPages || $[4] !== searchUrl) {
		t0 = {
			items,
			searchUrl,
			itemsPerPage,
			initialItemsPerPage,
			maxPages
		};
		$[0] = initialItemsPerPage;
		$[1] = items;
		$[2] = itemsPerPage;
		$[3] = maxPages;
		$[4] = searchUrl;
		$[5] = t0;
	} else t0 = $[5];
	const { searchMode, searchTerm, searchQuery, activateSearch, deactivateSearch, handleSearchTermChange, renderedItems } = useSidePanelSearch(t0);
	let t1;
	if ($[6] !== activateSearch || $[7] !== analytics || $[8] !== deactivateSearch || $[9] !== fetchNextPage || $[10] !== handleSearchTermChange || $[11] !== hasNextPage || $[12] !== isLoading || $[13] !== renderedItems || $[14] !== searchLabel || $[15] !== searchMode || $[16] !== searchQuery || $[17] !== searchTerm || $[18] !== searchUrl || $[19] !== sendItemClick || $[20] !== showMoreClickCount || $[21] !== title) {
		let t2;
		if ($[23] !== analytics || $[24] !== sendItemClick) {
			t2 = () => sendItemClick(analytics.itemAction);
			$[23] = analytics;
			$[24] = sendItemClick;
			$[25] = t2;
		} else t2 = $[25];
		t1 = jsxs(Fragment$1, { children: [jsxs(NavList.Group, { children: [
			jsxs(NavList.GroupHeading, {
				as: "h3",
				className: styles_module_default.groupHeading,
				children: [jsx("div", { children: title }), searchUrl && searchLabel && !searchMode ? jsx(IconButton, {
					size: "small",
					variant: "invisible",
					"aria-label": searchLabel,
					icon: SearchIcon,
					"data-testid": "dynamic-side-panel-items-search-button",
					onClick: activateSearch
				}) : searchMode ? jsx(IconButton, {
					size: "small",
					variant: "invisible",
					"aria-label": "Close search",
					icon: ChevronUpIcon,
					onClick: deactivateSearch
				}) : null]
			}),
			searchMode && jsx(Fragment$1, { children: jsx(NavList.Item, { children: jsxs("div", {
				className: "d-flex width-full position-relative",
				children: [jsx(TextInput$1, {
					autoFocus: true,
					"aria-label": searchLabel,
					placeholder: searchLabel,
					value: searchTerm,
					onChange: handleSearchTermChange,
					leadingVisual: SearchIcon,
					className: "mr-1 flex-auto"
				}, "search-input"), searchQuery.isLoading && jsx("div", {
					className: styles_module_default.searchSpinner,
					children: jsx(Spinner, { size: "small" })
				})]
			}) }) }),
			jsx(SidePanelItemsList, {
				items: renderedItems,
				onItemClick: t2
			}),
			!isLoading && !searchMode && hasNextPage && fetchNextPage && jsx(ActionList.Item, {
				onSelect: () => {
					sendItemClick(analytics.showMoreAction);
					setShowMoreClickCount(_temp);
					fetchNextPage();
				},
				"data-testid": "dynamic-side-panel-items-show-more",
				children: jsx("span", {
					className: "color-fg-muted f6",
					children: showMoreClickCount >= 2 ? "Show even more" : "Show more"
				})
			})
		] }), isLoading && jsx(NavList.Group, {
			className: "d-flex flex-justify-center width-full tmp-my-3",
			children: jsx(Spinner, {
				"data-testid": "dynamic-side-panel-items-loader",
				size: "small"
			})
		})] });
		$[6] = activateSearch;
		$[7] = analytics;
		$[8] = deactivateSearch;
		$[9] = fetchNextPage;
		$[10] = handleSearchTermChange;
		$[11] = hasNextPage;
		$[12] = isLoading;
		$[13] = renderedItems;
		$[14] = searchLabel;
		$[15] = searchMode;
		$[16] = searchQuery;
		$[17] = searchTerm;
		$[18] = searchUrl;
		$[19] = sendItemClick;
		$[20] = showMoreClickCount;
		$[21] = title;
		$[22] = t1;
	} else t1 = $[22];
	return t1;
}
DynamicSidePanelItems.displayName = "DynamicSidePanelItems";
function _temp(prevCount) {
	return prevCount + 1;
}
function useSidePanelItemsQuery(props) {
	const $ = c(26);
	const { searchUrl, itemsPerPage: t0, initialItems, initialItemsPerPage, maxPages: t1 } = props;
	const itemsPerPage = t0 === void 0 ? 5 : t0;
	const maxPages = t1 === void 0 ? 20 : t1;
	const queryClient = useQueryClient();
	let t2;
	if ($[0] !== initialItemsPerPage || $[1] !== itemsPerPage || $[2] !== maxPages || $[3] !== searchUrl) {
		t2 = [
			"global-nav-side-panel-items",
			searchUrl,
			itemsPerPage,
			initialItemsPerPage,
			maxPages
		];
		$[0] = initialItemsPerPage;
		$[1] = itemsPerPage;
		$[2] = maxPages;
		$[3] = searchUrl;
		$[4] = t2;
	} else t2 = $[4];
	const t3 = initialItems ? 2 : 1;
	let t4;
	if ($[5] !== initialItems) {
		t4 = {
			pages: initialItems ? [initialItems] : [],
			pageParams: initialItems ? [1] : []
		};
		$[5] = initialItems;
		$[6] = t4;
	} else t4 = $[6];
	let t5;
	if ($[7] !== initialItemsPerPage || $[8] !== itemsPerPage || $[9] !== maxPages || $[10] !== searchUrl) {
		t5 = async (t6) => {
			const { pageParam } = t6;
			const response = await reactFetchJSON(`${searchUrl}${buildQueryParams({
				page: pageParam,
				items_per_page: itemsPerPage.toString(),
				initial_items_per_page: initialItemsPerPage,
				max_pages: maxPages
			})}`);
			if (!response.ok) throw new Error(`Failed to fetch: ${response.statusText}`);
			return await response.json();
		};
		$[7] = initialItemsPerPage;
		$[8] = itemsPerPage;
		$[9] = maxPages;
		$[10] = searchUrl;
		$[11] = t5;
	} else t5 = $[11];
	let t6;
	if ($[12] !== itemsPerPage || $[13] !== maxPages) {
		t6 = (lastPage, pages, lastPageParam) => {
			if (maxPages && lastPageParam >= maxPages) return null;
			if (typeof lastPage[0]?.has_more !== "undefined") return lastPage[0]?.has_more ? lastPageParam + 1 : null;
			else if (lastPage.length < itemsPerPage) return null;
			return lastPageParam + 1;
		};
		$[12] = itemsPerPage;
		$[13] = maxPages;
		$[14] = t6;
	} else t6 = $[14];
	let t7;
	if ($[15] !== t2 || $[16] !== t3 || $[17] !== t4 || $[18] !== t5 || $[19] !== t6) {
		t7 = {
			queryKey: t2,
			initialPageParam: t3,
			initialData: t4,
			staleTime: 1e3,
			refetchOnMount: false,
			queryFn: t5,
			getNextPageParam: t6
		};
		$[15] = t2;
		$[16] = t3;
		$[17] = t4;
		$[18] = t5;
		$[19] = t6;
		$[20] = t7;
	} else t7 = $[20];
	const query = useInfiniteQuery(t7);
	let t8;
	let t9;
	if ($[21] !== query.isFetched || $[22] !== queryClient || $[23] !== searchUrl) {
		t8 = () => () => {
			if (query.isFetched) queryClient.resetQueries({ queryKey: ["global-nav-side-panel-items", searchUrl] });
		};
		t9 = [
			queryClient,
			query.isFetched,
			searchUrl
		];
		$[21] = query.isFetched;
		$[22] = queryClient;
		$[23] = searchUrl;
		$[24] = t8;
		$[25] = t9;
	} else {
		t8 = $[24];
		t9 = $[25];
	}
	useEffect(t8, t9);
	return query;
}
function useSidePanelItemsSearch(props) {
	const $ = c(14);
	const { searchUrl, searchTerm, itemsPerPage: t0, initialItemsPerPage, maxPages: t1 } = props;
	const itemsPerPage = t0 === void 0 ? 5 : t0;
	const maxPages = t1 === void 0 ? 20 : t1;
	let t2;
	let t3;
	if ($[0] !== initialItemsPerPage || $[1] !== itemsPerPage || $[2] !== maxPages || $[3] !== searchTerm || $[4] !== searchUrl) {
		t2 = [
			"global-nav-side-panel-items-search",
			searchUrl,
			searchTerm,
			itemsPerPage,
			initialItemsPerPage,
			maxPages
		];
		t3 = async () => {
			if (!searchTerm) return [];
			const response = await reactFetchJSON(`${searchUrl}${buildQueryParams({
				q: encodeURIComponent(searchTerm),
				items_per_page: itemsPerPage.toString(),
				initial_items_per_page: initialItemsPerPage,
				max_pages: maxPages
			})}`);
			if (!response.ok) throw new Error(`Failed to fetch: ${response.statusText}`);
			return await response.json();
		};
		$[0] = initialItemsPerPage;
		$[1] = itemsPerPage;
		$[2] = maxPages;
		$[3] = searchTerm;
		$[4] = searchUrl;
		$[5] = t2;
		$[6] = t3;
	} else {
		t2 = $[5];
		t3 = $[6];
	}
	let t4;
	if ($[7] !== searchTerm || $[8] !== searchUrl) {
		t4 = Boolean(searchTerm?.trim()) && Boolean(searchUrl?.trim());
		$[7] = searchTerm;
		$[8] = searchUrl;
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== t2 || $[11] !== t3 || $[12] !== t4) {
		t5 = {
			queryKey: t2,
			queryFn: t3,
			enabled: t4
		};
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
		$[13] = t5;
	} else t5 = $[13];
	return useQuery(t5);
}
function TeamsBanner(t0) {
	const $ = c(11);
	const { showTeamsBanner } = t0;
	const { sendItemClick } = useGlobalNavAnalytics();
	const [showBanner, setShowBanner] = useState(showTeamsBanner);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {
			setShowBanner(false);
			verifiedFetch(dismissUserNoticePath({ noticeName: "global_nav_teams_banner" }), { method: "POST" });
			deleteCookie("dismissed_teams_banner");
		};
		$[0] = t1;
	} else t1 = $[0];
	const dismissTeamsBanner = t1;
	let t2;
	if ($[1] !== sendItemClick) {
		t2 = () => {
			sendItemClick("TEAMS_BANNER_LINK");
		};
		$[1] = sendItemClick;
		$[2] = t2;
	} else t2 = $[2];
	const onClick = t2;
	let t3;
	if ($[3] !== sendItemClick) {
		t3 = () => {
			dismissTeamsBanner();
			sendItemClick("TEAMS_BANNER_DISMISS");
		};
		$[3] = sendItemClick;
		$[4] = t3;
	} else t3 = $[4];
	const onClickDismiss = t3;
	let t4;
	let t5;
	if ($[5] !== showBanner) {
		t4 = () => {
			if (showBanner) {
				const today = Date.now();
				const twoWeeksAgo = today - 12096e5;
				const dismissedBannerDate = getCookie("dismissed_teams_banner")?.value;
				if (dismissedBannerDate && parseInt(dismissedBannerDate, 10) < twoWeeksAgo) dismissTeamsBanner();
				else if (!dismissedBannerDate) setCookie("dismissed_teams_banner", today.toString());
			}
		};
		t5 = [dismissTeamsBanner, showBanner];
		$[5] = showBanner;
		$[6] = t4;
		$[7] = t5;
	} else {
		t4 = $[6];
		t5 = $[7];
	}
	useEffect(t4, t5);
	if (!showBanner) return null;
	let t6;
	if ($[8] !== onClick || $[9] !== onClickDismiss) {
		t6 = jsx(Banner, {
			variant: "info",
			title: "Teams have moved",
			hideTitle: true,
			onDismiss: onClickDismiss,
			className: "mx-2 tmp-my-3",
			children: jsxs(Banner.Description, { children: [
				"Teams have moved to",
				" ",
				jsx(Link, {
					as: Link$1,
					onClick,
					to: "/settings/teams",
					inline: true,
					children: "settings"
				})
			] })
		});
		$[8] = onClick;
		$[9] = onClickDismiss;
		$[10] = t6;
	} else t6 = $[10];
	return t6;
}
TeamsBanner.displayName = "TeamsBanner";
var RichTextDataValidator = Compile(Type.Object({
	repositories: Type.Optional(Type.Array(DynamicSidePanelItemSchema)),
	show_teams_banner: Type.Optional(Type.Boolean())
}));
function useRichContent(props) {
	const $ = c(17);
	const { sendAnalyticsEvent } = useAnalytics();
	const queryUrl = props.richContentUrl ?? "/_side-panels/global.json";
	const itemsPerPage = props.itemsPerPage ?? 5;
	const maxPages = props.additionalRepositoryParams?.maxPages ?? 20;
	const t0 = props.additionalRepositoryParams?.initialItemsPerPage;
	let t1;
	if ($[0] !== itemsPerPage || $[1] !== maxPages || $[2] !== props.additionalRepositoryParams || $[3] !== queryUrl || $[4] !== t0) {
		t1 = [
			"global-nav-side-panel",
			queryUrl,
			itemsPerPage,
			maxPages,
			props.additionalRepositoryParams,
			t0
		];
		$[0] = itemsPerPage;
		$[1] = maxPages;
		$[2] = props.additionalRepositoryParams;
		$[3] = queryUrl;
		$[4] = t0;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== itemsPerPage || $[7] !== maxPages || $[8] !== props.additionalRepositoryParams?.initialItemsPerPage || $[9] !== queryUrl) {
		t2 = async () => {
			if (!queryUrl) return null;
			const response = await reactFetchJSON(`${queryUrl}${buildQueryParams({
				items_per_page: itemsPerPage.toString(),
				initial_items_per_page: props.additionalRepositoryParams?.initialItemsPerPage,
				max_pages: maxPages.toString()
			})}`);
			if (!response.ok) throw new Error("Failed to fetch");
			return response.json();
		};
		$[6] = itemsPerPage;
		$[7] = maxPages;
		$[8] = props.additionalRepositoryParams?.initialItemsPerPage;
		$[9] = queryUrl;
		$[10] = t2;
	} else t2 = $[10];
	let t3;
	if ($[11] !== sendAnalyticsEvent) {
		t3 = createPersister({
			validator: RichTextDataValidator,
			sendAnalyticsEvent
		});
		$[11] = sendAnalyticsEvent;
		$[12] = t3;
	} else t3 = $[12];
	let t4;
	if ($[13] !== t1 || $[14] !== t2 || $[15] !== t3) {
		t4 = {
			queryKey: t1,
			queryFn: t2,
			persister: t3
		};
		$[13] = t1;
		$[14] = t2;
		$[15] = t3;
		$[16] = t4;
	} else t4 = $[16];
	return useQuery(t4);
}
function DynamicSidePanelContent(props) {
	const $ = c(5);
	const { data, isLoading, error } = useRichContent(props);
	if (error || isLoading || !data) {
		let t0;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t0 = jsx(NavList.Group, {
				className: "d-flex flex-justify-center width-full tmp-my-3",
				children: jsx(Spinner, {
					"data-testid": "dynamic-side-content-loader",
					size: "small"
				})
			});
			$[0] = t0;
		} else t0 = $[0];
		return t0;
	}
	let t0;
	if ($[1] !== data.repositories || $[2] !== data.show_teams_banner || $[3] !== props.repositoriesSearchUrl) {
		t0 = jsxs(Fragment$1, { children: [data.repositories && data.repositories.length > 0 && jsx(TopRepos, {
			initialItems: data.repositories,
			searchUrl: props.repositoriesSearchUrl ?? "/_side-panel-items/global/repositories"
		}), data.show_teams_banner !== void 0 && jsx(TeamsBanner, { showTeamsBanner: data.show_teams_banner })] });
		$[1] = data.repositories;
		$[2] = data.show_teams_banner;
		$[3] = props.repositoriesSearchUrl;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
DynamicSidePanelContent.displayName = "DynamicSidePanelContent";
function TopRepos(props) {
	const $ = c(9);
	const { fetchNextPage, hasNextPage, isLoading, data, error } = useSidePanelItemsQuery(props);
	if (error) return null;
	let t0;
	if ($[0] !== data.pages || $[1] !== fetchNextPage || $[2] !== hasNextPage || $[3] !== isLoading || $[4] !== props.initialItemsPerPage || $[5] !== props.itemsPerPage || $[6] !== props.maxPages || $[7] !== props.searchUrl) {
		t0 = jsx(DynamicSidePanelItems, {
			title: "Top repositories",
			items: data.pages,
			searchLabel: "Search for repositories",
			itemsPerPage: props.itemsPerPage,
			initialItemsPerPage: props.initialItemsPerPage,
			maxPages: props.maxPages,
			searchUrl: props.searchUrl,
			isLoading,
			hasNextPage,
			fetchNextPage,
			analytics: {
				subCategory: "REPOSITORIES",
				showMoreAction: "SHOW_MORE_REPOS",
				itemAction: "REPOSITORY_ITEM"
			}
		});
		$[0] = data.pages;
		$[1] = fetchNextPage;
		$[2] = hasNextPage;
		$[3] = isLoading;
		$[4] = props.initialItemsPerPage;
		$[5] = props.itemsPerPage;
		$[6] = props.maxPages;
		$[7] = props.searchUrl;
		$[8] = t0;
	} else t0 = $[8];
	return t0;
}
TopRepos.displayName = "TopRepos";
function normalizePathEnding(path) {
	return path.endsWith("/") ? path : `${path}/`;
}
function isMenuItemActive(currentLocation, href, activePath) {
	if (!href || !currentLocation?.origin) return false;
	const targetPath = normalizePathEnding(new URL(href, currentLocation.origin).pathname);
	const currentPath = normalizePathEnding(currentLocation.pathname);
	if (currentPath === targetPath) return true;
	if (targetPath !== "/" && activePath?.includeSubpaths && currentPath.startsWith(targetPath)) return true;
	if (activePath?.additionalPathnames?.includes(currentPath)) return true;
	return false;
}
function SideNavMenuItem({ href, icon: Icon, label, analyticsKey, hotkey, activePath, commandId, ...rest }) {
	const { sendItemClick } = useGlobalNavAnalytics();
	const itemRef = useRef(null);
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	useEffect(() => {
		if (uiCommandsEnabled) return;
		const { current: menuItemElement } = itemRef;
		if (hotkey && menuItemElement) {
			if (document.querySelector(`[data-hotkey="${hotkey}"]`)) return;
			(0, hotkey_exports.install)(menuItemElement, hotkey);
			return () => {
				(0, hotkey_exports.uninstall)(menuItemElement);
			};
		}
	}, [hotkey, uiCommandsEnabled]);
	const isActiveRoute = useMemo(() => {
		return Boolean(href) && isMenuItemActive(ssrSafeLocation, href, activePath);
	}, [activePath, href]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(NavList.Item, {
		ref: itemRef,
		href,
		"data-testid": `side-nav-menu-item-${analyticsKey}`,
		"aria-current": isActiveRoute ? "page" : void 0,
		onClick: () => {
			sendItemClick(analyticsKey);
		},
		...rest,
		children: [/* @__PURE__ */ jsx(NavList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }), label]
	}), uiCommandsEnabled && commandId && /* @__PURE__ */ jsx(GlobalCommands, { commands: { [commandId]: () => itemRef.current?.click() } })] });
}
SideNavMenuItem.displayName = "SideNavMenuItem";
function SideNavMenuHeader(props) {
	const $ = c(3);
	const { sendItemClick } = useGlobalNavAnalytics();
	let t0;
	if ($[0] !== props || $[1] !== sendItemClick) {
		t0 = jsxs(Stack, {
			align: "stretch",
			direction: "horizontal",
			justify: "space-between",
			padding: "normal",
			children: [
				jsx(VisuallyHidden, { children: jsx("h2", {
					id: props.dialogLabelId,
					children: "Global Navigation Menu"
				}) }),
				jsx(MarkGithubIcon, { size: "medium" }),
				jsx(IconButton, {
					size: "medium",
					variant: "invisible",
					icon: XIcon,
					onClick: () => {
						sendItemClick("CLOSE_MENU");
						props.onClose("close-button");
					},
					"aria-label": "Close menu"
				})
			]
		});
		$[0] = props;
		$[1] = sendItemClick;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
SideNavMenuHeader.displayName = "SideNavMenuHeader";
function DialogBody(props) {
	return /* @__PURE__ */ jsx("div", {
		className: "p-2",
		children: props.children
	});
}
DialogBody.displayName = "DialogBody";
function SideNavMenu(props) {
	const { onClose } = props;
	return /* @__PURE__ */ jsx(Dialog, {
		onClose,
		width: "medium",
		position: "left",
		renderHeader: SideNavMenuHeader,
		renderBody: DialogBody,
		children: /* @__PURE__ */ jsx(NavList, { children: props.children })
	});
}
SideNavMenu.displayName = "SideNavMenu";
/**
* The main navigation menu component for the application.
* It renders a side navigation menu with support for rich content.
*
* Handling for specific menu-items can be controlled via the individual props:
* i.e.
* ```tsx
* <GlobalNavMenu
*   home={{ show: true, href: '/custom-home', hotkey: 'h' }}
*   issues={{ show: false }}
* />
* ```
*
*/
function GlobalNavMenu(props) {
	const { open = true, onClose, richContent } = props;
	const [mainGroup, secondaryGroup] = GlobalMenuItems.map((group) => {
		return group.filter((item) => {
			if (props[item.key]?.show !== void 0) return props[item.key]?.show;
			return item.show !== false;
		}).map(({ show: _show, ...item }) => {
			const { show, ...overrides } = props[item.key] ?? {};
			const copilotExperimentOverride = {};
			if (item.key === "copilot") {
				let analyticsKey = item.analyticsKey;
				if (isFeatureEnabled("copilot_default_to_task_input")) {
					analyticsKey += "_TASK";
					Object.assign(copilotExperimentOverride, { href: "/copilot/agents" });
				}
				if (isFeatureEnabled("copilot_default_to_task_input_control_group")) analyticsKey += "_TASK_EXPERIMENT_CONTROL";
				Object.assign(copilotExperimentOverride, { analyticsKey });
			}
			return {
				...item,
				...overrides,
				...copilotExperimentOverride
			};
		});
	});
	if (!open) return /* @__PURE__ */ jsx(GlobalNavAnalyticsProvider, {
		category: analyticsCategory,
		children: /* @__PURE__ */ jsx(GlobalNavHotKeys, { menuItems: [...mainGroup ?? [], ...secondaryGroup ?? []] })
	});
	return /* @__PURE__ */ jsx(GlobalNavAnalyticsProvider, {
		category: analyticsCategory,
		children: /* @__PURE__ */ jsxs(SideNavMenu, {
			onClose,
			children: [
				/* @__PURE__ */ jsx(NavList.Group, { children: mainGroup?.map(({ key, ...item }) => {
					return /* @__PURE__ */ jsx(SideNavMenuItem, { ...item }, key);
				}) }),
				(secondaryGroup?.length ?? 0) > 0 && /* @__PURE__ */ jsx(NavList.Group, { children: secondaryGroup?.map(({ key, ...item }) => {
					return /* @__PURE__ */ jsx(SideNavMenuItem, { ...item }, key);
				}) }),
				richContent?.show && richContent.contentUrl && /* @__PURE__ */ jsx(DynamicSidePanelContent, {
					richContentUrl: richContent.contentUrl,
					repositoriesSearchUrl: richContent.repositoriesSearchUrl
				})
			]
		})
	});
}
/**
* Renders a hidden version of the GlobalNavMenu to support keyboard shortcuts for any menu item
* that has a hotkey or, when the `global_nav_ui_commands` feature flag is enabled, a `commandId`.
* This component does not render anything visual, and should be used when the menu is collapsed.
*/
GlobalNavMenu.displayName = "GlobalNavMenu";
function GlobalNavHotKeys({ menuItems }) {
	const uiCommandsEnabled = isFeatureEnabled("global_nav_ui_commands");
	return /* @__PURE__ */ jsx("div", {
		className: "d-none",
		children: menuItems.map(({ key, ...item }) => {
			if (!(uiCommandsEnabled ? !!item.commandId : !!item.hotkey)) return null;
			return /* @__PURE__ */ jsx(SideNavMenuItem, { ...item }, key);
		})
	});
}
GlobalNavHotKeys.displayName = "GlobalNavHotKeys";
function GlobalNavMenuPartial(t0) {
	const $ = c(2);
	const { reactPartialAnchor, ...props } = t0;
	const { ref: anchorRef, open, setOpen } = useExternalAnchor(reactPartialAnchor);
	let t1;
	if ($[0] !== setOpen) {
		t1 = () => {
			setOpen(false);
		};
		$[0] = setOpen;
		$[1] = t1;
	} else t1 = $[1];
	return jsx(GlobalNavMenu, {
		returnFocusRef: anchorRef,
		open,
		onClose: t1,
		...props
	});
}
GlobalNavMenuPartial.displayName = "GlobalNavMenuPartial";
var GlobalMenuItems = [[
	{
		href: "/dashboard",
		key: "home",
		icon: HomeIcon,
		label: "Home",
		analyticsKey: "HOME",
		show: true,
		activePath: { additionalPathnames: ["/"] }
	},
	{
		href: "/feed",
		key: "feed",
		icon: GlobeIcon,
		label: "Feed",
		analyticsKey: "FEED",
		show: false
	},
	{
		href: "/issues",
		key: "issues",
		icon: IssueOpenedIcon,
		label: "Issues",
		analyticsKey: "ISSUES",
		show: true,
		activePath: { includeSubpaths: true }
	},
	{
		href: "/pulls",
		key: "pulls",
		icon: GitPullRequestIcon,
		label: "Pull requests",
		analyticsKey: "PULL_REQUESTS",
		show: true,
		activePath: { includeSubpaths: true }
	},
	{
		href: "/repos",
		key: "contributedRepos",
		label: "Repositories",
		analyticsKey: "CONTRIBUTED_REPOS",
		icon: RepoIcon,
		show: false
	},
	{
		href: "/projects",
		key: "projects",
		icon: TableIcon,
		label: "Projects",
		analyticsKey: "PROJECTS",
		show: true
	},
	{
		href: "/discussions",
		key: "discussions",
		icon: CommentDiscussionIcon,
		label: "Discussions",
		analyticsKey: "DISCUSSIONS",
		show: false,
		activePath: { includeSubpaths: true }
	},
	{
		href: "/codespaces",
		key: "codespaces",
		icon: CodespacesIcon,
		label: "Codespaces",
		analyticsKey: "CODESPACES",
		show: false,
		activePath: { includeSubpaths: true }
	},
	{
		href: "/copilot",
		key: "copilot",
		icon: CopilotIcon,
		label: "Copilot",
		analyticsKey: "COPILOT",
		show: false
	},
	{
		href: "/spark",
		key: "spark",
		icon: SparkleIcon,
		label: "Spark",
		analyticsKey: "SPARK",
		show: false
	}
], [
	{
		href: "/explore",
		key: "explore",
		icon: TelescopeIcon,
		label: "Explore",
		analyticsKey: "EXPLORE",
		show: false
	},
	{
		href: "/marketplace",
		key: "marketplace",
		icon: GiftIcon,
		label: "Marketplace",
		analyticsKey: "MARKETPLACE",
		show: false
	},
	{
		href: "/mcp",
		key: "mcp",
		icon: McpIcon,
		label: "MCP registry",
		analyticsKey: "MCP_REGISTRY",
		show: false,
		activePath: { includeSubpaths: true }
	}
]];
export { GlobalNavMenu };
