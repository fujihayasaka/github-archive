import { i as isLoggedIn } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { F as ChevronDownIcon, Jt as GitPullRequestIcon, Kt as GitPullRequestClosedIcon, L as ChevronRightIcon, Qt as Heading$2, Wt as GitMergeIcon, an as IconButton, bn as Link, et as CopilotIcon, fn as IssueOpenedIcon, hi as TriangleDownIcon, ir as PlusCircleIcon, m as ArrowUpRightIcon, n as ActionList, o as AlertIcon, pi as Tooltip$1, qt as GitPullRequestDraftIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { b as useTheme } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { n as useConfirm } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { n as TreeView } from "./server-TreeView-BeVCvZ0v-BAEuIsb-.js";
import { n as COPILOT_PATH } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as announceFromElement$1, t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as isMacOS$1 } from "./server-get-os-Ck0WulB4-pSskfK2H.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { a as GlobalCommands, i as CommandKeybindingHint, n as CommandButton, o as ScopedCommands, t as CommandActionListItem } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as Octicon } from "./server-deprecated-NWt92s1C-CJVCDSxf.js";
import { n as md2html } from "./server-md2html-TgcTyYQC-DzwxtslQ.js";
import { o as require_react_relay, s as require_relay_runtime } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { n as clientSideRelayFetchQueryRetained } from "./server-relay-environment-37zIk8_--Ci7dtWT_.js";
import { r as RepositoryAndIssuePicker } from "./server-RepositoryAndIssuePicker-pJUBAgRS-Bhe6Vlwu.js";
import { c as require_hooks, m as useShouldShowCopilotFunctionalityInIssues, p as useNamedColor } from "./server-use-issue-pr-state-Ca7HKQL5-BTNcVLo6.js";
import { t as useIntersectionObserver } from "./server-use-intersection-observer-B95-tqzf-CUpd9cN-.js";
import { i as useDragAndDrop, n as DragAndDrop, o as useSyncedState, r as drag_and_drop_exports, t as ActionBar } from "./server-drag-and-drop-ekoR4DH7-Bqpb-P1q.js";
import { n as useAlert, t as RelationshipsAlertDialog } from "./server-use-alert-DENoqsF4-DQy6Y9S2.js";
import { Children, Fragment, Suspense, createContext, isValidElement, use, useCallback, useEffect, useId, useMemo, useRef, useState, useTransition } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { iterateFocusableElements } from "@primer/behaviors/utils";
import { c } from "react/compiler-runtime";
var ItemsContext = createContext({
	anyItemsWithActionBar: false,
	setAnyItemsWithActionBar: noop,
	hasResizableActionsWithActionBar: false,
	setHasResizableActionsWithActionBar: noop
});
ItemsContext.displayName = "ItemsContext";
var ItemsProvider = (t0) => {
	const $ = c(6);
	const { children } = t0;
	const [anyItemsWithActionBar, setAnyItemsWithActionBar] = useState(false);
	const [hasResizableActionsWithActionBar, setHasResizableActionsWithActionBar] = useState(false);
	let t1;
	if ($[0] !== anyItemsWithActionBar || $[1] !== hasResizableActionsWithActionBar) {
		t1 = {
			anyItemsWithActionBar,
			setAnyItemsWithActionBar,
			hasResizableActionsWithActionBar,
			setHasResizableActionsWithActionBar
		};
		$[0] = anyItemsWithActionBar;
		$[1] = hasResizableActionsWithActionBar;
		$[2] = t1;
	} else t1 = $[2];
	const contextProps = t1;
	let t2;
	if ($[3] !== children || $[4] !== contextProps) {
		t2 = jsx(ItemsContext, {
			value: contextProps,
			children
		});
		$[3] = children;
		$[4] = contextProps;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
};
ItemsProvider.displayName = "ItemsProvider";
ItemsProvider.displayName = "NestedListViewItemsProvider";
var useNestedListViewItems = () => {
	return use(ItemsContext);
};
var PropertiesContext = createContext(void 0);
PropertiesContext.displayName = "PropertiesContext";
var PropertiesProvider = (t0) => {
	const $ = c(8);
	const { children, isCollapsible: t1, isReadOnly: t2 } = t0;
	const isCollapsible = t1 === void 0 ? false : t1;
	const isReadOnly = t2 === void 0 ? false : t2;
	const idPrefix = useId();
	const [isExpanded, setIsExpanded] = useState(true);
	let t3;
	if ($[0] !== idPrefix || $[1] !== isCollapsible || $[2] !== isExpanded || $[3] !== isReadOnly) {
		t3 = {
			idPrefix,
			isExpanded,
			setIsExpanded,
			isCollapsible,
			isReadOnly
		};
		$[0] = idPrefix;
		$[1] = isCollapsible;
		$[2] = isExpanded;
		$[3] = isReadOnly;
		$[4] = t3;
	} else t3 = $[4];
	const contextProps = t3;
	let t4;
	if ($[5] !== children || $[6] !== contextProps) {
		t4 = jsx(PropertiesContext, {
			value: contextProps,
			children
		});
		$[5] = children;
		$[6] = contextProps;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
};
PropertiesProvider.displayName = "PropertiesProvider";
PropertiesProvider.displayName = "NestedListViewPropertiesProvider";
var useNestedListViewProperties = () => {
	const context = use(PropertiesContext);
	if (!context) throw new Error("useNestedListViewProperties must be used with PropertiesProvider.");
	return context;
};
var HeaderTags = [
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
];
var HeaderTagLevels = [
	"nested-list-view",
	"nested-list-view-metadata",
	"nested-listitem"
];
var defaultHeaderTags = {
	"nested-list-view": "h2",
	"nested-list-view-metadata": "h3",
	"nested-listitem": "h3"
};
var defaultSingularUnits = "list item";
var defaultPluralUnits = "list items";
var SelectionContext = createContext({
	selectedCount: 0,
	setSelectedCount: noop,
	countOnPage: 0,
	isSelectAllChecked: false,
	anyItemsSelected: false,
	singularUnits: defaultSingularUnits,
	pluralUnits: defaultPluralUnits,
	isSelectable: false
});
SelectionContext.displayName = "SelectionContext";
var SelectionProvider = ({ children, countOnPage = 0, singularUnits = defaultSingularUnits, pluralUnits = defaultPluralUnits, totalCount, selectedCount: externalSelectedCount = 0, isSelectable = false } = {
	singularUnits: defaultSingularUnits,
	pluralUnits: defaultPluralUnits,
	selectedCount: 0,
	countOnPage: 0,
	isSelectable: false
}) => {
	const [selectedCount, setSelectedCount] = useSyncedState(externalSelectedCount);
	const isSelectAllChecked = selectedCount > 0 && selectedCount >= countOnPage;
	const anyItemsSelected = selectedCount > 0;
	return /* @__PURE__ */ jsx(SelectionContext, {
		value: useMemo(() => {
			return {
				totalCount,
				countOnPage,
				selectedCount,
				setSelectedCount,
				isSelectAllChecked,
				anyItemsSelected,
				singularUnits,
				pluralUnits,
				isSelectable
			};
		}, [
			totalCount,
			countOnPage,
			selectedCount,
			setSelectedCount,
			isSelectAllChecked,
			anyItemsSelected,
			singularUnits,
			pluralUnits,
			isSelectable
		]),
		children
	});
};
SelectionProvider.displayName = "SelectionProvider";
SelectionProvider.displayName = "NestedListViewSelectionProvider";
var useNestedListViewSelection = () => {
	return use(SelectionContext);
};
var TitleContext = createContext(void 0);
TitleContext.displayName = "TitleContext";
var TitleProvider = (t0) => {
	const $ = c(9);
	const { children, title, titleHeaderTag: t1 } = t0;
	const titleHeaderTag = t1 === void 0 ? "h2" : t1;
	const [hasMetadataTitle, setHasMetadataTitle] = useState(false);
	let t2;
	if ($[0] !== title) {
		t2 = title.trim() || "List view";
		$[0] = title;
		$[1] = t2;
	} else t2 = $[1];
	let t3;
	if ($[2] !== hasMetadataTitle || $[3] !== t2 || $[4] !== titleHeaderTag) {
		t3 = {
			title: t2,
			titleHeaderTag,
			hasMetadataTitle,
			setHasMetadataTitle
		};
		$[2] = hasMetadataTitle;
		$[3] = t2;
		$[4] = titleHeaderTag;
		$[5] = t3;
	} else t3 = $[5];
	const contextProps = t3;
	let t4;
	if ($[6] !== children || $[7] !== contextProps) {
		t4 = jsx(TitleContext, {
			value: contextProps,
			children
		});
		$[6] = children;
		$[7] = contextProps;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
};
TitleProvider.displayName = "TitleProvider";
TitleProvider.displayName = "NestedListViewTitleProvider";
var useNestedListViewTitle = () => {
	const context = use(TitleContext);
	if (!context) throw new Error("useNestedListViewTitle must be used with TitleProvider.");
	return context;
};
var NestedListViewErrorBoundary = (t0) => {
	const $ = c(6);
	const { children, onError } = t0;
	const [loadingError, setLoadingError] = useState("An error occured while loading items");
	let t1;
	if ($[0] !== children || $[1] !== loadingError || $[2] !== onError) {
		let t2;
		if ($[4] !== onError) {
			t2 = (error) => {
				if (error instanceof Error) setLoadingError(error.message);
				onError?.();
			};
			$[4] = onError;
			$[5] = t2;
		} else t2 = $[5];
		t1 = jsx(ErrorBoundary, {
			fallback: jsxs(BlankslateContainer, { children: [
				jsx(BlankslateContainer.Visual, { children: jsx(AlertIcon, {}) }),
				jsx(BlankslateContainer.Heading, { children: loadingError }),
				jsx(BlankslateContainer.Description, { children: "There was an issue loading Sub issues" }),
				jsx(BlankslateContainer.SecondaryAction, {
					href: "https://www.githubstatus.com/",
					children: "GitHub status"
				})
			] }),
			onError: t2,
			children
		});
		$[0] = children;
		$[1] = loadingError;
		$[2] = onError;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
NestedListViewErrorBoundary.displayName = "NestedListViewErrorBoundary";
var NestedListView_module_default = {
	collapsible: "NestedListView-module_Tgo-oG_collapsible",
	container: "NestedListView-module_Tgo-oG_container",
	responsiveContainer: "NestedListView-module_Tgo-oG_responsiveContainer"
};
var defaultDragAndDropProps = {
	onDrop: () => {},
	renderOverlay: () => /* @__PURE__ */ jsx(Fragment$1, {}),
	items: []
};
var keyboardCodes = {
	start: [drag_and_drop_exports.KeyboardCode.Space],
	cancel: [drag_and_drop_exports.KeyboardCode.Esc],
	end: [drag_and_drop_exports.KeyboardCode.Space]
};
var NestedListView = (t0) => {
	const $ = c(4);
	let t1;
	if ($[0] !== t0) {
		const { title, titleHeaderTag, children, totalCount, selectedCount: t2, singularUnits, pluralUnits, isSelectable, isCollapsible: t3, isReadOnly: t4, ...rest } = t0;
		const selectedCount = t2 === void 0 ? 0 : t2;
		const isCollapsible = t3 === void 0 ? false : t3;
		const isReadOnly = t4 === void 0 ? false : t4;
		let t5;
		if ($[2] !== children) {
			t5 = Children.toArray(children);
			$[2] = children;
			$[3] = t5;
		} else t5 = $[3];
		const countOnPage = t5.length;
		t1 = jsx(PropertiesProvider, {
			isCollapsible,
			isReadOnly,
			children: jsx(TitleProvider, {
				title,
				titleHeaderTag,
				children: jsx(SelectionProvider, {
					countOnPage,
					selectedCount,
					totalCount,
					singularUnits,
					pluralUnits,
					isSelectable: isSelectable && !isReadOnly,
					children: jsx(ItemsProvider, { children: jsx(NestedListViewInternal, {
						...rest,
						children
					}) })
				})
			})
		});
		$[0] = t0;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
};
NestedListView.displayName = "NestedListView";
var NestedListViewInternal = (t0) => {
	const { header, children, ariaLabelledBy: externalAriaLabelledBy, className, dragAndDropProps: t1, ...rest } = t0;
	const dragAndDropProps = t1 === void 0 ? defaultDragAndDropProps : t1;
	const { idPrefix, isExpanded, isCollapsible, isReadOnly } = useNestedListViewProperties();
	const { title, titleHeaderTag } = useNestedListViewTitle();
	const nestedListViewContainerTitleId = externalAriaLabelledBy ?? `${idPrefix}-nested-list-view-container-title`;
	return jsxs("div", {
		...testIdProps(`${idPrefix}-nested-list-view-container`),
		className: clsx(NestedListView_module_default.container, NestedListView_module_default.responsiveContainer, isCollapsible && isReadOnly && NestedListView_module_default.collapsible, className),
		children: [
			!externalAriaLabelledBy && jsx(Heading$2, {
				className: "sr-only",
				as: titleHeaderTag,
				id: nestedListViewContainerTitleId,
				...testIdProps("list-view-title"),
				children: title
			}),
			header,
			isExpanded && jsx(NestedListViewErrorBoundary, { children: jsx(DragAndDrop, {
				as: "div",
				keyboardCodes,
				...dragAndDropProps,
				children: jsx(TreeView, {
					"aria-labelledby": nestedListViewContainerTitleId,
					...testIdProps("list-view-items"),
					...rest,
					children
				})
			}) })
		]
	});
};
NestedListViewInternal.displayName = "NestedListViewInternal";
var ActionBar_module_default$1 = {
	container: "ActionBar-module_dLX-fW_container",
	withoutActions: "ActionBar-module_dLX-fW_withoutActions"
};
var SuppressSecondaryActionsContext = createContext(false);
SuppressSecondaryActionsContext.displayName = "SuppressSecondaryActionsContext";
var SuppressSecondaryActionsProvider = SuppressSecondaryActionsContext;
/**
* Hide all interactive elements inside the container from accessibility technologies by making them unfocusable and
* adding `aria-hidden` to the container. Will not have any effect unless used inside a `SuppressSecondaryActionsProvider`
* with `value={true}`.
*
* https://ui.githubapp.com/storybook/?path=/docs/recipes-nested-list-view-documentation-accessibility-listitem--docs#suppression-of-secondary-info-and-actions
*/
function useSuppressActions(containerRef) {
	const $ = c(4);
	const shouldSuppress = use(SuppressSecondaryActionsContext);
	let t0;
	let t1;
	if ($[0] !== containerRef || $[1] !== shouldSuppress) {
		t0 = () => {
			const container = containerRef.current;
			if (container && shouldSuppress) {
				const updatedElements = [];
				const containerAriaHidden = container.getAttribute("aria-hidden");
				container.setAttribute("aria-hidden", "true");
				for (const el of iterateFocusableElements(container)) {
					updatedElements.push([el, el.tabIndex]);
					el.tabIndex = -1;
				}
				return () => {
					if (containerAriaHidden) container.setAttribute("aria-hidden", containerAriaHidden);
					else container.removeAttribute("aria-hidden");
					for (const [el_0, tabIndex] of updatedElements) el_0.tabIndex = tabIndex;
				};
			}
		};
		t1 = [containerRef, shouldSuppress];
		$[0] = containerRef;
		$[1] = shouldSuppress;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
}
function NestedListItemActionBar({ anchorIcon, label = "list item action bar", className, ...props }) {
	const actionBarContainerRef = useRef(null);
	const { setAnyItemsWithActionBar, setHasResizableActionsWithActionBar } = useNestedListViewItems();
	useEffect(() => setAnyItemsWithActionBar(true), [setAnyItemsWithActionBar]);
	useEffect(() => {
		if (props.actions) setHasResizableActionsWithActionBar(true);
	}, [props.actions, setHasResizableActionsWithActionBar]);
	useSuppressActions(actionBarContainerRef);
	return /* @__PURE__ */ jsx("div", {
		ref: actionBarContainerRef,
		"aria-hidden": "true",
		className: clsx(ActionBar_module_default$1.container, !props.actions && ActionBar_module_default$1.withoutActions, className),
		...testIdProps("nested-list-view-item-action-bar-container"),
		children: /* @__PURE__ */ jsx(ActionBar, {
			...props,
			label,
			variant: "menu",
			overflowMenuToggleProps: anchorIcon ? { icon: anchorIcon } : void 0
		})
	});
}
NestedListItemActionBar.displayName = "NestedListItemActionBar";
var NestedListItemActionsContext = createContext({
	actionsOpen: false,
	setActionsOpen: noop
});
NestedListItemActionsContext.displayName = "NestedListItemActionsContext";
var NestedListItemActionsProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [actionsOpen, setActionsOpen] = useState(false);
	let t1;
	if ($[0] !== actionsOpen) {
		t1 = {
			actionsOpen,
			setActionsOpen
		};
		$[0] = actionsOpen;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemActionsContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemActionsProvider.displayName = "NestedListItemActionsProvider";
var NestedListItemCompletionContext = createContext(void 0);
NestedListItemCompletionContext.displayName = "NestedListItemCompletionContext";
var NestedListItemCompletionProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [completion, setCompletion] = useState("");
	let t1;
	if ($[0] !== completion) {
		t1 = {
			completion,
			setCompletion
		};
		$[0] = completion;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemCompletionContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemCompletionProvider.displayName = "NestedListItemCompletionProvider";
var useNestedListItemCompletion = () => {
	return use(NestedListItemCompletionContext);
};
var NestedListItemControlsDialogContext = createContext({
	controlsDialogOpen: false,
	setControlsDialogOpen: noop
});
NestedListItemControlsDialogContext.displayName = "NestedListItemControlsDialogContext";
var NestedListItemControlsDialogProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [controlsDialogOpen, setControlsDialogOpen] = useState(false);
	let t1;
	if ($[0] !== controlsDialogOpen) {
		t1 = {
			controlsDialogOpen,
			setControlsDialogOpen
		};
		$[0] = controlsDialogOpen;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemControlsDialogContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemControlsDialogProvider.displayName = "NestedListItemControlsDialogProvider";
var useNestedListItemControlsDialog = () => {
	return use(NestedListItemControlsDialogContext);
};
var NestedListItemDescriptionContext = createContext(void 0);
NestedListItemDescriptionContext.displayName = "NestedListItemDescriptionContext";
var NestedListItemDescriptionProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [description, setDescription] = useState("");
	let t1;
	if ($[0] !== description) {
		t1 = {
			description,
			setDescription
		};
		$[0] = description;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemDescriptionContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemDescriptionProvider.displayName = "NestedListItemDescriptionProvider";
var useNestedListItemDescription = () => {
	const context = use(NestedListItemDescriptionContext);
	if (!context) throw new Error("useNestedListItemDescription must be used with NestedListItemDescriptionProvider.");
	return context;
};
var NestedListItemLeadingBadgeContext = createContext(void 0);
NestedListItemLeadingBadgeContext.displayName = "NestedListItemLeadingBadgeContext";
var NestedListItemLeadingBadgeProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [leadingBadge, setLeadingBadge] = useState("");
	let t1;
	if ($[0] !== leadingBadge) {
		t1 = {
			leadingBadge,
			setLeadingBadge
		};
		$[0] = leadingBadge;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemLeadingBadgeContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemLeadingBadgeProvider.displayName = "NestedListItemLeadingBadgeProvider";
var useNestedListItemLeadingBadge = () => {
	const context = use(NestedListItemLeadingBadgeContext);
	if (!context) throw new Error("useNestedListItemLeadingBadge must be used with NestedListItemLeadingBadgeProvider.");
	return context;
};
var NestedListItemNewActivityContext = createContext(void 0);
NestedListItemNewActivityContext.displayName = "NestedListItemNewActivityContext";
var NestedListItemNewActivityProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [hasNewActivity, setHasNewActivity] = useState(false);
	let t1;
	if ($[0] !== hasNewActivity) {
		t1 = {
			hasNewActivity,
			setHasNewActivity
		};
		$[0] = hasNewActivity;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemNewActivityContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemNewActivityProvider.displayName = "NestedListItemNewActivityProvider";
var useNestedListItemNewActivity = () => {
	const context = use(NestedListItemNewActivityContext);
	if (!context) throw new Error("useNestedListItemNewActivity must be used with NewActivityProvider.");
	return context;
};
var NestedListItemTitleContext = createContext(void 0);
NestedListItemTitleContext.displayName = "NestedListItemTitleContext";
var NestedListItemTitleProvider = (t0) => {
	const $ = c(7);
	const { children } = t0;
	const [title, setTitle] = useState("");
	const [titleAction, setTitleAction] = useState(null);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (newTitle) => setTitle(newTitle.trim());
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== title || $[2] !== titleAction) {
		t2 = {
			title,
			setTitle: t1,
			titleAction,
			setTitleAction
		};
		$[1] = title;
		$[2] = titleAction;
		$[3] = t2;
	} else t2 = $[3];
	const contextProps = t2;
	let t3;
	if ($[4] !== children || $[5] !== contextProps) {
		t3 = jsx(NestedListItemTitleContext, {
			value: contextProps,
			children
		});
		$[4] = children;
		$[5] = contextProps;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
};
NestedListItemTitleProvider.displayName = "NestedListItemTitleProvider";
var useNestedListItemTitle = () => {
	const context = use(NestedListItemTitleContext);
	if (!context) throw new Error("useNestedListItemTitle must be used with NestedListItemTitleProvider.");
	return context;
};
var NestedListItemSelectionContext = createContext({
	isSelected: false,
	onSelect: noop
});
NestedListItemSelectionContext.displayName = "NestedListItemSelectionContext";
var NestedListItemSelectionProvider = (t0) => {
	const $ = c(9);
	const { children, value: t1 } = t0;
	const { isSelected, onSelect } = t1;
	const { title } = useNestedListItemTitle();
	let t2;
	if ($[0] !== onSelect || $[1] !== title) {
		t2 = (selected) => {
			announce$1(selected ? `Selected. ${title}.` : `Unselected. ${title}.`);
			onSelect(selected);
		};
		$[0] = onSelect;
		$[1] = title;
		$[2] = t2;
	} else t2 = $[2];
	const onSelectAndAnnounce = t2;
	let t3;
	if ($[3] !== isSelected || $[4] !== onSelectAndAnnounce) {
		t3 = {
			isSelected,
			onSelect: onSelectAndAnnounce
		};
		$[3] = isSelected;
		$[4] = onSelectAndAnnounce;
		$[5] = t3;
	} else t3 = $[5];
	const contextProps = t3;
	let t4;
	if ($[6] !== children || $[7] !== contextProps) {
		t4 = jsx(NestedListItemSelectionContext, {
			value: contextProps,
			children
		});
		$[6] = children;
		$[7] = contextProps;
		$[8] = t4;
	} else t4 = $[8];
	return t4;
};
NestedListItemSelectionProvider.displayName = "NestedListItemSelectionProvider";
var useNestedListItemSelection = () => {
	return use(NestedListItemSelectionContext);
};
var NestedListItemStatusContext = createContext(void 0);
NestedListItemStatusContext.displayName = "NestedListItemStatusContext";
var NestedListItemStatusProvider = (t0) => {
	const $ = c(5);
	const { children } = t0;
	const [status, setStatus] = useState("");
	let t1;
	if ($[0] !== status) {
		t1 = {
			status,
			setStatus
		};
		$[0] = status;
		$[1] = t1;
	} else t1 = $[1];
	const contextProps = t1;
	let t2;
	if ($[2] !== children || $[3] !== contextProps) {
		t2 = jsx(NestedListItemStatusContext, {
			value: contextProps,
			children
		});
		$[2] = children;
		$[3] = contextProps;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
NestedListItemStatusProvider.displayName = "NestedListItemStatusProvider";
var useNestedListItemStatus = () => {
	const context = use(NestedListItemStatusContext);
	if (!context) throw new Error("useNestedListItemStatus must be used with NestedListItemStatusProvider.");
	return context;
};
var ControlsDialog_module_default = { Dialog: "ControlsDialog-module_MRakaa_Dialog" };
var MetadataContainer_module_default = { metadataContainer: "MetadataContainer-module_ACw7da_metadataContainer" };
function NestedListItemMetadataContainer({ children, className }) {
	const metadataContainerRef = useRef(null);
	const { controlsDialogOpen } = useNestedListItemControlsDialog();
	useSuppressActions(metadataContainerRef);
	return /* @__PURE__ */ jsx("div", {
		ref: metadataContainerRef,
		"aria-hidden": !controlsDialogOpen,
		...testIdProps("nested-list-view-item-metadata"),
		className: clsx(MetadataContainer_module_default.metadataContainer, className),
		children
	});
}
NestedListItemMetadataContainer.displayName = "NestedListItemMetadataContainer";
var NestedListItem_module_default = {
	dragHandle: "NestedListItem-module_32jqbG_dragHandle",
	hasResizableActionsWithActionBar: "NestedListItem-module_32jqbG_hasResizableActionsWithActionBar",
	item: "NestedListItem-module_32jqbG_item",
	itemGrid: "NestedListItem-module_32jqbG_itemGrid",
	selected: "NestedListItem-module_32jqbG_selected"
};
var ControlsDialog = ({ onClose, title, metadata, secondaryActions, children }) => /* @__PURE__ */ jsx(Dialog, {
	title: "Manage item",
	onClose,
	footerButtons: [{
		content: "Ok",
		onClick: onClose
	}],
	className: ControlsDialog_module_default.Dialog,
	children: /* @__PURE__ */ jsx(SuppressSecondaryActionsProvider, {
		value: false,
		children: /* @__PURE__ */ jsx("div", {
			className: NestedListView_module_default.responsiveContainer,
			children: /* @__PURE__ */ jsxs("div", {
				className: NestedListItem_module_default.itemGrid,
				children: [
					title,
					children,
					/* @__PURE__ */ jsx(NestedListItemMetadataContainer, { children: metadata }),
					secondaryActions
				]
			})
		})
	})
});
ControlsDialog.displayName = "ControlsDialog";
var ControlsDialogHint_module_default = { hint: "ControlsDialogHint-module_p8LWPq_hint" };
function ControlsDialogHint() {
	return /* @__PURE__ */ jsxs("div", {
		className: ControlsDialogHint_module_default.hint,
		children: [
			/* @__PURE__ */ jsx("span", { children: "Manage this item" }),
			" ",
			/* @__PURE__ */ jsx(CommandKeybindingHint, {
				commandId: "list-views:open-manage-item-dialog",
				format: "condensed"
			})
		]
	});
}
ControlsDialogHint.displayName = "ControlsDialogHint";
var Selection_module_default = {
	checkbox: "Selection-module_kHkGDq_checkbox",
	container: "Selection-module_kHkGDq_container"
};
var NestedListItemSelection = () => {
	const $ = c(7);
	const { isSelectable } = useNestedListViewSelection();
	const { isSelected, onSelect } = useNestedListItemSelection();
	const { title } = useNestedListItemTitle();
	if (!isSelectable) return null;
	let t0;
	if ($[0] !== isSelected || $[1] !== onSelect || $[2] !== title) {
		let t1;
		if ($[4] !== isSelected || $[5] !== onSelect) {
			t1 = () => onSelect(!isSelected);
			$[4] = isSelected;
			$[5] = onSelect;
			$[6] = t1;
		} else t1 = $[6];
		t0 = jsx("div", {
			className: Selection_module_default.container,
			...testIdProps("list-view-item-selection"),
			children: jsx(Checkbox, {
				checked: isSelected,
				onChange: t1,
				"aria-label": `Select: ${title}`,
				className: Selection_module_default.checkbox,
				...testIdProps("list-view-item-selection-input")
			})
		});
		$[0] = isSelected;
		$[1] = onSelect;
		$[2] = title;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
};
NestedListItemSelection.displayName = "NestedListItemSelection";
var NestedListItemInternal = ({ children, isActive = false, title, metadata, secondaryActions, subItemsCount, subItems, loadSubItems, defaultExpanded = false, className, metadataContainerClassName, dragAndDropProps, ...props }) => {
	const { idPrefix, isReadOnly } = useNestedListViewProperties();
	const { isSelectable } = useNestedListViewSelection();
	const { anyItemsWithActionBar, hasResizableActionsWithActionBar } = useNestedListViewItems();
	const uniqueIdSuffix = useId();
	const { isSelected, onSelect: itemOnSelect } = useNestedListItemSelection();
	const { status: labelStatus } = useNestedListItemStatus();
	const { title: labelTitle, titleAction } = useNestedListItemTitle();
	const { description: labelDescription } = useNestedListItemDescription();
	const { leadingBadge: labelLeadingBadge } = useNestedListItemLeadingBadge();
	const completionContext = useNestedListItemCompletion();
	const { hasNewActivity } = useNestedListItemNewActivity();
	const itemRef = useRef(null);
	const [subItemsLoadingState, setSubItemsLoadingState] = useState("initial");
	const [itemExpanded, setItemExpanded] = useState(defaultExpanded);
	const { isInDragMode } = useDragAndDrop();
	const { controlsDialogOpen, setControlsDialogOpen } = useNestedListItemControlsDialog();
	const triggerRef = useRef(null);
	const hasSubItems = subItemsCount && subItemsCount > 0;
	useEffect(() => {
		if (!itemRef.current) return;
		if (isActive && document.activeElement?.tagName === "BODY") itemRef.current.focus();
	});
	const onSelect = useCallback((e) => {
		if (e.nativeEvent instanceof KeyboardEvent) {
			const event = e;
			switch (event.key) {
				case "Enter":
					if (itemRef?.current === document.activeElement && titleAction) titleAction(event);
					break;
				case " ":
					if (itemRef?.current !== document.activeElement) break;
					event.preventDefault();
					if (!isReadOnly) {
						if (triggerRef.current && !event.nativeEvent.ctrlKey && !isInDragMode) {
							lastFocusedElementRef.current = document.activeElement;
							triggerRef.current?.focus();
							triggerRef.current?.click();
							event.preventDefault();
							break;
						}
						if (isSelectable) {
							itemOnSelect(!isSelected);
							break;
						}
					}
					if (titleAction) {
						titleAction(event);
						break;
					}
					if (hasSubItems || subItems) {
						setItemExpanded(!itemExpanded);
						break;
					}
					break;
				case "Escape":
					itemRef?.current?.focus();
					break;
				default: break;
			}
		}
	}, [
		titleAction,
		isReadOnly,
		hasSubItems,
		subItems,
		isInDragMode,
		isSelectable,
		itemOnSelect,
		isSelected,
		itemExpanded
	]);
	const getAriaLabel = useCallback(() => {
		const labelSelected = isSelected ? "Selected" : "";
		const labelNewActivity = hasNewActivity ? "New activity" : "";
		const labelAdditionalInfo = `Press ${isMacOS$1() ? "Command" : "Control"}, Shift, U for more actions`;
		let labelCompletion = "";
		if (completionContext) labelCompletion = completionContext.completion;
		let main = [
			labelSelected,
			labelLeadingBadge,
			labelTitle,
			labelStatus
		].filter((str) => str.trim()).join(": ");
		try {
			main = main.replace(/(?<!\.)\.+$/, "");
		} catch {
			while (main.endsWith(".")) main = main.substring(0, main.length - 1);
		}
		const ariaLabel = [
			main,
			labelDescription,
			labelNewActivity,
			labelCompletion,
			labelAdditionalInfo
		].filter((str_0) => str_0.trim()).join(". ");
		return ariaLabel.endsWith(".") ? ariaLabel : `${ariaLabel}.`;
	}, [
		hasNewActivity,
		isSelected,
		completionContext,
		labelDescription,
		labelLeadingBadge,
		labelStatus,
		labelTitle
	]);
	const [isPending, startTransition] = useTransition();
	const loadItems = useCallback(() => {
		if (isPending) return;
		setSubItemsLoadingState("loading");
		startTransition(() => {
			loadSubItems?.();
		});
	}, [
		loadSubItems,
		isPending,
		setSubItemsLoadingState
	]);
	useEffect(() => {
		if (isPending) setSubItemsLoadingState("loading");
		else setSubItemsLoadingState("done");
	}, [isPending]);
	const lastFocusedElementRef = useRef(null);
	useEffect(() => {
		if (!isInDragMode && lastFocusedElementRef.current) {
			lastFocusedElementRef.current.focus();
			lastFocusedElementRef.current = null;
		}
	}, [isInDragMode]);
	return /* @__PURE__ */ jsx(NestedListViewErrorBoundary, {
		onError: () => {
			setSubItemsLoadingState("error");
		},
		onDismiss: () => {
			setSubItemsLoadingState("initial");
		},
		children: /* @__PURE__ */ jsx(ScopedCommands, {
			commands: { "list-views:open-manage-item-dialog": () => setControlsDialogOpen(true) },
			children: /* @__PURE__ */ jsxs(TreeView.Item, {
				onSelect,
				defaultExpanded,
				expanded: itemExpanded && !isInDragMode,
				onExpandedChange: (expanded) => {
					setItemExpanded(expanded);
					if (expanded && hasSubItems && !subItems) loadItems();
				},
				ref: itemRef,
				id: `${idPrefix}-list-view-node-${uniqueIdSuffix}`,
				"aria-label": getAriaLabel(),
				...props,
				children: [
					dragAndDropProps?.showTrigger && !isReadOnly && /* @__PURE__ */ jsx(TreeView.LeadingAction, { children: /* @__PURE__ */ jsx(DragAndDrop.DragTrigger, {
						className: clsx(NestedListItem_module_default.dragHandle),
						ref: triggerRef
					}) }),
					/* @__PURE__ */ jsx("div", {
						className: clsx(NestedListItem_module_default.item, NestedListItem_module_default.itemGrid, isSelected && NestedListItem_module_default.selected, anyItemsWithActionBar && hasResizableActionsWithActionBar && NestedListItem_module_default.hasResizableActionsWithActionBar, className),
						tabIndex: -1,
						children: /* @__PURE__ */ jsxs(SuppressSecondaryActionsProvider, {
							value: true,
							children: [
								title,
								/* @__PURE__ */ jsx(NestedListItemSelection, {}),
								children,
								Array.isArray(metadata) && metadata.length > 0 ? /* @__PURE__ */ jsx(NestedListItemMetadataContainer, {
									className: metadataContainerClassName,
									children: metadata.map((metadataItem, index) => /* @__PURE__ */ jsx(Fragment, { children: metadataItem }, index))
								}) : Boolean(metadata && !Array.isArray(metadata)) && /* @__PURE__ */ jsx(NestedListItemMetadataContainer, {
									className: metadataContainerClassName,
									children: metadata
								}),
								secondaryActions ?? (anyItemsWithActionBar && /* @__PURE__ */ jsx(NestedListItemActionBar, {}))
							]
						})
					}),
					/* @__PURE__ */ jsx(ControlsDialogHint, {}),
					controlsDialogOpen && /* @__PURE__ */ jsx(ControlsDialog, {
						onClose: () => setControlsDialogOpen(false),
						title,
						metadata,
						secondaryActions,
						children
					}),
					(hasSubItems || subItems) && /* @__PURE__ */ jsx(TreeView.SubTree, {
						state: subItemsLoadingState,
						count: subItemsCount,
						children: subItems
					})
				]
			})
		})
	});
};
NestedListItemInternal.displayName = "NestedListItemInternal";
var NestedListItem = (t0) => {
	const $ = c(12);
	const { children, isSelected: t1, onSelect: t2, ...rest } = t0;
	const isSelected = t1 === void 0 ? false : t1;
	const onSelect = t2 === void 0 ? noop : t2;
	const { setSelectedCount } = useNestedListViewSelection();
	const isSelectedRef = useRef(isSelected);
	let t3;
	if ($[0] !== isSelected) {
		t3 = () => {
			isSelectedRef.current = isSelected;
		};
		$[0] = isSelected;
		$[1] = t3;
	} else t3 = $[1];
	useEffect(t3);
	let t4;
	let t5;
	if ($[2] !== isSelected || $[3] !== setSelectedCount) {
		t4 = () => {
			setSelectedCount((count) => isSelected ? count + 1 : Math.max(0, count - 1));
		};
		t5 = [isSelected, setSelectedCount];
		$[2] = isSelected;
		$[3] = setSelectedCount;
		$[4] = t4;
		$[5] = t5;
	} else {
		t4 = $[4];
		t5 = $[5];
	}
	useEffect(t4, t5);
	let t6;
	let t7;
	if ($[6] !== setSelectedCount) {
		t6 = () => () => {
			if (isSelectedRef.current) setSelectedCount(_temp$2);
		};
		t7 = [setSelectedCount];
		$[6] = setSelectedCount;
		$[7] = t6;
		$[8] = t7;
	} else {
		t6 = $[7];
		t7 = $[8];
	}
	useEffect(t6, t7);
	let t8;
	if ($[9] !== isSelected || $[10] !== onSelect) {
		t8 = {
			isSelected,
			onSelect
		};
		$[9] = isSelected;
		$[10] = onSelect;
		$[11] = t8;
	} else t8 = $[11];
	return jsx(NestedListItemControlsDialogProvider, { children: jsx(NestedListItemCompletionProvider, { children: jsx(NestedListItemActionsProvider, { children: jsx(NestedListItemLeadingBadgeProvider, { children: jsx(NestedListItemTitleProvider, { children: jsx(NestedListItemSelectionProvider, {
		value: t8,
		children: jsx(NestedListItemNewActivityProvider, { children: jsx(NestedListItemDescriptionProvider, { children: jsx(NestedListItemStatusProvider, { children: jsx(DragAndDrop.Item, {
			id: rest.dragAndDropProps?.itemId || "",
			index: 0,
			title: rest.dragAndDropProps?.itemId || "",
			as: "div",
			hideTrigger: true,
			isDragOverlay: rest.dragAndDropProps?.isOverlay ?? false,
			children: jsx(NestedListItemInternal, {
				...rest,
				children
			})
		}) }) }) })
	}) }) }) }) }) });
};
NestedListItem.displayName = "NestedListItem";
function _temp$2(count_0) {
	return Math.max(0, count_0 - 1);
}
var LeadingContent_module_default = { container: "LeadingContent-module_E0YgzW_container" };
function NestedListItemLeadingContent({ children, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(LeadingContent_module_default.container, className),
		...testIdProps("nested-list-view-item-leading-content"),
		children
	});
}
NestedListItemLeadingContent.displayName = "NestedListItemLeadingContent";
var LeadingVisual_module_default = {
	container: "LeadingVisual-module_GDZy_a_container",
	hasNewActivity: "LeadingVisual-module_GDZy_a_hasNewActivity",
	visualContainer: "LeadingVisual-module_GDZy_a_visualContainer"
};
var UnreadIndicator_module_default = { container: "UnreadIndicator-module_RBvPEq_container" };
var NestedListItemUnreadIndicator = () => {
	return /* @__PURE__ */ jsx("div", {
		className: UnreadIndicator_module_default.container,
		children: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			...testIdProps("list-view-item-unread-indicator"),
			children: "New activity."
		})
	});
};
NestedListItemUnreadIndicator.displayName = "NestedListItemUnreadIndicator";
function NestedListItemLeadingVisual(t0) {
	const $ = c(10);
	const { icon, color, description, newActivity: t1, children, className, ...props } = t0;
	const newActivity = t1 === void 0 ? false : t1;
	const { setStatus } = useNestedListItemStatus();
	const { setHasNewActivity } = useNestedListItemNewActivity();
	let t2;
	if ($[0] !== description) {
		t2 = description?.trim();
		$[0] = description;
		$[1] = t2;
	} else t2 = $[1];
	const trimmedDescription = t2;
	const iconAriaLabel = trimmedDescription ? { "aria-label": void 0 } : {};
	let t3;
	let t4;
	if ($[2] !== newActivity || $[3] !== setHasNewActivity) {
		t3 = () => {
			setHasNewActivity(newActivity);
		};
		t4 = [newActivity, setHasNewActivity];
		$[2] = newActivity;
		$[3] = setHasNewActivity;
		$[4] = t3;
		$[5] = t4;
	} else {
		t3 = $[4];
		t4 = $[5];
	}
	useEffect(t3, t4);
	let t5;
	let t6;
	if ($[6] !== setStatus || $[7] !== trimmedDescription) {
		t5 = () => {
			if (trimmedDescription) setStatus(trimmedDescription);
		};
		t6 = [setStatus, trimmedDescription];
		$[6] = setStatus;
		$[7] = trimmedDescription;
		$[8] = t5;
		$[9] = t6;
	} else {
		t5 = $[8];
		t6 = $[9];
	}
	useEffect(t5, t6);
	return jsxs("div", {
		className: clsx(LeadingVisual_module_default.container, newActivity && LeadingVisual_module_default.hasNewActivity, className),
		...props,
		children: [jsxs("div", {
			className: LeadingVisual_module_default.visualContainer,
			...testIdProps("nested-list-view-leading-visual"),
			children: [
				icon && jsx(Octicon, {
					...iconAriaLabel,
					icon,
					color
				}),
				children,
				trimmedDescription && jsx("span", {
					className: "sr-only",
					...testIdProps("leading-visual-text-description"),
					children: trimmedDescription
				})
			]
		}), newActivity && jsx(NestedListItemUnreadIndicator, {})]
	});
}
NestedListItemLeadingVisual.displayName = "NestedListItemLeadingVisual";
var Title_module_default$1 = {
	anchor: "Title-module__9byHG_anchor",
	container: "Title-module__9byHG_container",
	trailingBadges: "Title-module__9byHG_trailingBadges",
	truncate: "Title-module__9byHG_truncate"
};
function NestedListItemTitle({ additionalLinkProps = {}, anchorRef: forwardedAnchorRef, anchorClassName, children, containerClassName, href, leadingBadge, onClick, tooltip, trailingBadges, value }) {
	const { setTitle, setTitleAction } = useNestedListItemTitle();
	const { controlsDialogOpen } = useNestedListItemControlsDialog();
	const fallbackAnchorRef = useRef(null);
	const anchorRef = forwardedAnchorRef || fallbackAnchorRef;
	useEffect(() => {
		setTitle(typeof anchorRef !== "function" && anchorRef?.current?.textContent || value);
	}, [
		anchorRef,
		setTitle,
		value
	]);
	useEffect(() => {
		if ((href || onClick) && typeof anchorRef !== "function" && anchorRef?.current) setTitleAction(() => (e) => {
			if (href && (e.metaKey || e.ctrlKey)) window.open(href, "_blank");
			else anchorRef?.current?.click();
		});
	}, [
		anchorRef,
		href,
		onClick,
		setTitleAction
	]);
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("nested-list-view-item-primary-container"),
		className: clsx(Title_module_default$1.container, containerClassName),
		"data-nested-list-view-component": "title-container",
		children: [
			leadingBadge,
			/* @__PURE__ */ jsx(Link, {
				...!controlsDialogOpen ? { role: "none" } : {},
				ref: anchorRef,
				className: clsx(Title_module_default$1.anchor, Title_module_default$1.truncate, anchorClassName),
				href,
				onClick,
				...additionalLinkProps,
				...testIdProps("listitem-title-link"),
				"data-nested-list-view-component": "title-link",
				children: /* @__PURE__ */ jsx(UnsafeHTMLText, {
					html: value,
					title: tooltip
				})
			}),
			trailingBadges && /* @__PURE__ */ jsx("span", {
				className: clsx(Title_module_default$1.trailingBadges, Title_module_default$1.truncate),
				children: trailingBadges
			}),
			children
		]
	});
}
NestedListItemTitle.displayName = "NestedListItemTitle";
var ActionBar_module_default = {
	actionBar: "ActionBar-module_skcqMq_actionBar",
	condensedDensity: "ActionBar-module_skcqMq_condensedDensity",
	noneDensity: "ActionBar-module_skcqMq_noneDensity",
	normalDensity: "ActionBar-module_skcqMq_normalDensity",
	spaciousDensity: "ActionBar-module_skcqMq_spaciousDensity"
};
var NestedListViewHeaderActionBar = ({ actions, children, density = "normal", actionsLabel, className }) => {
	const nonCollapsibleActions = children;
	if (actions && actions.length > 0) return /* @__PURE__ */ jsx(ActionBar, {
		label: actionsLabel?.trim(),
		actions,
		density,
		className,
		...testIdProps("list-view-actions"),
		children: nonCollapsibleActions
	});
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("list-view-actions"),
		className: clsx(ActionBar_module_default.actionBar, ActionBar_module_default[`${density}Density`], className),
		children: nonCollapsibleActions
	});
};
NestedListViewHeaderActionBar.displayName = "NestedListViewHeaderActionBar";
var NestedListViewHeader_module_default = { container: "NestedListViewHeader-module_e_kCiG_container" };
var SectionFilters_module_default = { list: "SectionFilters-module_Z0q-Ra_list" };
var NestedListViewHeaderSectionFilters = ({ links, className }) => {
	if (links.length < 1) return null;
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("nested-list-view-section-filters"),
		children: /* @__PURE__ */ jsx("ul", {
			className: clsx(SectionFilters_module_default.list, className),
			children: links.map((sectionFilterLink, index) => /* @__PURE__ */ jsx("li", {
				...testIdProps(`nested-list-view-section-filter-${index}`),
				children: sectionFilterLink
			}, `section-filter-${index}`))
		})
	});
};
NestedListViewHeaderSectionFilters.displayName = "NestedListViewHeaderSectionFilters";
var SelectAllCheckbox_module_default = {
	checkboxContainer: "SelectAllCheckbox-module_abZ3AG_checkboxContainer",
	container: "SelectAllCheckbox-module_abZ3AG_container",
	count: "SelectAllCheckbox-module_abZ3AG_count"
};
var NestedListViewHeaderSelectAllCheckbox = ({ onToggle, className }) => {
	const { title } = useNestedListViewTitle();
	const { isSelectable, selectedCount, totalCount, countOnPage, isSelectAllChecked, anyItemsSelected, singularUnits, pluralUnits } = useNestedListViewSelection();
	const idPrefix = useId();
	const checkboxRef = useRef(null);
	const srRef = useRef(null);
	const notAllItemsSelected = useMemo(() => {
		return selectedCount < countOnPage;
	}, [countOnPage, selectedCount]);
	const isIndeterminate = anyItemsSelected && notAllItemsSelected;
	const units = selectedCount === 1 ? singularUnits : pluralUnits;
	const suffix = typeof totalCount === "number" ? `of ${totalCount} selected` : "selected";
	const srString = `${selectedCount} ${units} ${suffix}`;
	const handleBulkSelectToggle = useCallback(() => {
		if (!onToggle) return;
		if (isIndeterminate) onToggle(false);
		else onToggle(!isSelectAllChecked);
	}, [
		isIndeterminate,
		isSelectAllChecked,
		onToggle
	]);
	useEffect(() => {
		if (srRef.current) announceFromElement$1(srRef.current);
	}, [srRef, srString]);
	if (!isSelectable) return null;
	const checkboxId = `${idPrefix}-nested-list-view-select-all`;
	const onKeyDown = (event) => {
		if (event.key === "Enter" || event.key === " ") {
			event.preventDefault();
			handleBulkSelectToggle();
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(SelectAllCheckbox_module_default.container, className),
		...testIdProps("nested-list-view-select-all-container"),
		id: `${idPrefix}-nested-list-view-select-all-container`,
		children: [/* @__PURE__ */ jsx("div", {
			className: SelectAllCheckbox_module_default.checkboxContainer,
			children: /* @__PURE__ */ jsxs(FormControl$1, {
				id: checkboxId,
				children: [/* @__PURE__ */ jsx(Checkbox, {
					onChange: handleBulkSelectToggle,
					value: "default",
					checked: isSelectAllChecked,
					indeterminate: isIndeterminate,
					onKeyDown,
					tabIndex: 0,
					ref: checkboxRef,
					...testIdProps("select-all-checkbox")
				}), /* @__PURE__ */ jsxs(FormControl$1.Label, {
					visuallyHidden: true,
					...testIdProps("select-all-label"),
					children: [
						"Select all ",
						pluralUnits,
						": ",
						title
					]
				})]
			})
		}), /* @__PURE__ */ jsxs("p", {
			className: clsx(SelectAllCheckbox_module_default.count, { "sr-only": !anyItemsSelected }),
			...testIdProps("select-all-selected-count"),
			children: [/* @__PURE__ */ jsxs("span", {
				"aria-hidden": "true",
				className: clsx({ "sr-only": !anyItemsSelected }),
				...testIdProps("select-all-selected-count-without-units"),
				children: [
					selectedCount,
					" ",
					suffix
				]
			}), /* @__PURE__ */ jsx("span", {
				className: "sr-only",
				ref: srRef,
				...testIdProps("sr-content"),
				children: srString
			})]
		})]
	});
};
NestedListViewHeaderSelectAllCheckbox.displayName = "NestedListViewHeaderSelectAllCheckbox";
var NestedListViewAnnouncements = ({ idPrefix, assistiveAnnouncement }) => {
	return /* @__PURE__ */ jsx("div", {
		id: `${idPrefix}-nested-list-view-announcements`,
		role: "status",
		"aria-live": "polite",
		"aria-atomic": "true",
		className: "sr-only",
		...testIdProps("nested-list-view-announcement-container"),
		children: assistiveAnnouncement
	});
};
NestedListViewAnnouncements.displayName = "NestedListViewAnnouncements";
var NestedListViewHeader = (t0) => {
	const $ = c(9);
	const { title, completionPill, assistiveAnnouncement, sectionFilters, children, className, actionBarClassName, onToggleSelectAll, actions, actionsLabel, ...actionBarProps } = t0;
	const { idPrefix } = useNestedListViewProperties();
	const { setHasMetadataTitle } = useNestedListViewTitle();
	const { anyItemsSelected } = useNestedListViewSelection();
	let t1;
	if ($[0] !== setHasMetadataTitle || $[1] !== title) {
		t1 = () => {
			setHasMetadataTitle(!!title);
		};
		$[0] = setHasMetadataTitle;
		$[1] = title;
		$[2] = t1;
	} else t1 = $[2];
	useEffect(t1);
	let t2;
	bb0: {
		if (!sectionFilters) {
			t2 = null;
			break bb0;
		}
		if (Array.isArray(sectionFilters)) {
			let t3;
			if ($[3] !== sectionFilters) {
				t3 = jsx(NestedListViewHeaderSectionFilters, { links: sectionFilters });
				$[3] = sectionFilters;
				$[4] = t3;
			} else t3 = $[4];
			t2 = t3;
			break bb0;
		} else if (isValidElement(sectionFilters)) {
			let t3;
			if ($[5] !== sectionFilters) {
				t3 = jsx(Fragment$1, { children: sectionFilters });
				$[5] = sectionFilters;
				$[6] = t3;
			} else t3 = $[6];
			t2 = t3;
			break bb0;
		}
		t2 = null;
	}
	const listFilters = t2;
	const actionsProps = actions && actionsLabel ? {
		actions,
		actionsLabel
	} : {};
	let t3;
	if ($[7] !== onToggleSelectAll) {
		t3 = (isSelectAllChecked) => {
			if (onToggleSelectAll) onToggleSelectAll(isSelectAllChecked);
		};
		$[7] = onToggleSelectAll;
		$[8] = t3;
	} else t3 = $[8];
	return jsxs("div", {
		id: `${idPrefix}-nested-list-view-metadata`,
		className: clsx(NestedListViewHeader_module_default.container, className),
		...testIdProps("nested-list-view-metadata"),
		children: [
			jsx(NestedListViewHeaderSelectAllCheckbox, { onToggle: t3 }),
			listFilters,
			!anyItemsSelected && title,
			completionPill,
			jsx(NestedListViewHeaderActionBar, {
				className: actionBarClassName,
				...actionsProps,
				...actionBarProps,
				children
			}),
			assistiveAnnouncement && jsx(NestedListViewAnnouncements, {
				idPrefix,
				assistiveAnnouncement
			})
		]
	});
};
NestedListViewHeader.displayName = "NestedListViewHeader";
function useNextHeaderTag(level) {
	const { titleHeaderTag, hasMetadataTitle } = useNestedListViewTitle();
	let t0;
	bb0: {
		const levelIndex = HeaderTagLevels.findIndex((e) => e === level);
		const headerIndex = HeaderTags.indexOf(titleHeaderTag) + (hasMetadataTitle ? levelIndex : levelIndex - 1);
		if (headerIndex > HeaderTags.length - 1) {
			t0 = "h6";
			break bb0;
		}
		t0 = HeaderTags[headerIndex] || defaultHeaderTags[level];
	}
	return t0;
}
var Title_module_default = {
	container: "Title-module_65LmZa_container",
	expandButton: "Title-module_65LmZa_expandButton",
	header: "Title-module_65LmZa_header"
};
var NestedListViewHeaderTitle = ({ title, children, className, scrollToOnCollapseOffset }) => {
	const titleTag = useNextHeaderTag("nested-list-view-metadata");
	const { isCollapsible, isExpanded, setIsExpanded } = useNestedListViewProperties();
	const containerRef = useRef(null);
	useEffect(() => {
		const { current } = containerRef;
		if (scrollToOnCollapseOffset !== void 0 && current !== null && !isExpanded) {
			const top = current.getBoundingClientRect().top + window.scrollY + scrollToOnCollapseOffset;
			window.scrollTo({
				top,
				behavior: "instant"
			});
		}
	}, [isExpanded, scrollToOnCollapseOffset]);
	return /* @__PURE__ */ jsxs("div", {
		ref: containerRef,
		className: clsx(Title_module_default.container, className),
		children: [/* @__PURE__ */ jsxs(Heading$2, {
			as: titleTag,
			className: Title_module_default.header,
			...testIdProps("nested-list-view-header-title"),
			children: [isCollapsible && /* @__PURE__ */ jsx(IconButton, {
				icon: isExpanded ? ChevronDownIcon : ChevronRightIcon,
				onClick: () => {
					setIsExpanded(!isExpanded);
				},
				"aria-label": isExpanded ? `Collapse ${title}` : `Expand ${title}`,
				size: "small",
				variant: "invisible",
				"aria-expanded": isExpanded,
				className: Title_module_default.expandButton,
				tooltipDirection: "n"
			}), title]
		}), children]
	});
};
NestedListViewHeaderTitle.displayName = "NestedListViewHeaderTitle";
var node$8 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v1 = [v0];
	return {
		"argumentDefinitions": [{
			"defaultValue": null,
			"kind": "LocalArgument",
			"name": "fetchSubIssues"
		}],
		"kind": "Fragment",
		"metadata": null,
		"name": "AddSubIssueButtonGroup",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "databaseId",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "number",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameWithOwner",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "visibility",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "viewerCanPush",
						"storageKey": null
					},
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "login",
							"storageKey": null
						}],
						"storageKey": null
					}
				],
				"storageKey": null
			},
			{
				"condition": "fetchSubIssues",
				"kind": "Condition",
				"passingValue": true,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "parent",
					"plural": false,
					"selections": v1,
					"storageKey": null
				}, {
					"alias": null,
					"args": [{
						"kind": "Literal",
						"name": "first",
						"value": 100
					}],
					"concreteType": "IssueConnection",
					"kind": "LinkedField",
					"name": "subIssues",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": v1,
						"storageKey": null
					}],
					"storageKey": "subIssues(first:100)"
				}]
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$8.hash = "239db2e3ca979fe1e0d0334848047c46";
var node$7 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"concreteType": "SubIssuesSummary",
		"kind": "LinkedField",
		"name": "subIssuesSummary",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "total",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "completed",
			"storageKey": null
		}],
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "addSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddSubIssuePayload",
				"kind": "LinkedField",
				"name": "addSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [v2, {
						"args": [{
							"kind": "Literal",
							"name": "fetchSubIssues",
							"value": false
						}],
						"kind": "FragmentSpread",
						"name": "useSubIssuesSummary"
					}],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "subIssue",
					"plural": false,
					"selections": [v2, {
						"args": null,
						"kind": "FragmentSpread",
						"name": "SubIssuesListItem"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "addSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "AddSubIssuePayload",
				"kind": "LinkedField",
				"name": "addSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [v2, v3],
					"storageKey": null
				}, {
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "subIssue",
					"plural": false,
					"selections": [
						v2,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "state",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "stateReason",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueDependenciesSummary",
							"kind": "LinkedField",
							"name": "issueDependenciesSummary",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "blockedBy",
								"storageKey": null
							}],
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 10
							}],
							"concreteType": "UserConnection",
							"kind": "LinkedField",
							"name": "assignees",
							"plural": false,
							"selections": [v4, {
								"alias": null,
								"args": null,
								"concreteType": "UserEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "User",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v2,
										v5,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "avatarUrl",
											"storageKey": null
										}
									],
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "assignees(first:10)"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "url",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "repository",
							"plural": false,
							"selections": [
								v6,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "__typename",
											"storageKey": null
										},
										v5,
										v2
									],
									"storageKey": null
								},
								v2
							],
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "databaseId",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "number",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "title",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "titleHTML",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueType",
							"kind": "LinkedField",
							"name": "issueType",
							"plural": false,
							"selections": [
								v2,
								v6,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "color",
									"storageKey": null
								}
							],
							"storageKey": null
						},
						v3,
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 0
							}, {
								"kind": "Literal",
								"name": "includeClosedPrs",
								"value": true
							}],
							"concreteType": "PullRequestConnection",
							"kind": "LinkedField",
							"name": "closedByPullRequestsReferences",
							"plural": false,
							"selections": [v4],
							"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
						}
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "ecc648a121b38054fc44c2bf0a057b22",
			"metadata": {},
			"name": "addSubIssueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$7.hash = "7fbac255a319dc6053973f5181fb85a4";
var import_react_relay = require_react_relay();
function getSubIssuesConnection(parentRecord) {
	return parentRecord.getLinkedRecord("subIssues", { first: 100 }) || null;
}
function getSubIssuesConnectionAlias(parentRecord) {
	return parentRecord.getLinkedRecord("subIssuesConnection") || null;
}
function ensureSubIssueRequiredFields(store, subIssueRecord) {
	const subIssueId = subIssueRecord.getDataID();
	if (!subIssueRecord.getValue("titleHTML")) {
		const title = subIssueRecord.getValue("title");
		if (typeof title === "string") subIssueRecord.setValue(md2html(title), "titleHTML");
	}
	if (!subIssueRecord.getLinkedRecord("assignees", { first: 10 })) {
		const placeholderAssignees = store.create(`${subIssueId}:assignees:optimistic`, "UserConnection");
		placeholderAssignees.setLinkedRecords([], "nodes");
		placeholderAssignees.setValue(0, "totalCount");
		subIssueRecord.setLinkedRecord(placeholderAssignees, "assignees", { first: 10 });
	}
	if (!subIssueRecord.getLinkedRecord("issueDependenciesSummary")) {
		const placeholderDependenciesSummary = store.create(`${subIssueId}:issueDependenciesSummary:optimistic`, "IssueDependenciesSummary");
		placeholderDependenciesSummary.setValue(0, "openBlockedByCount");
		placeholderDependenciesSummary.setValue(0, "closedBlockedByCount");
		placeholderDependenciesSummary.setValue(0, "openBlockingCount");
		placeholderDependenciesSummary.setValue(0, "closedBlockingCount");
		subIssueRecord.setLinkedRecord(placeholderDependenciesSummary, "issueDependenciesSummary");
	}
	if (!subIssueRecord.getLinkedRecord("subIssuesSummary")) {
		const placeholderSubIssuesSummary = store.create(`${subIssueId}:subIssuesSummary:optimistic`, "SubIssuesSummary");
		placeholderSubIssuesSummary.setValue(0, "total");
		placeholderSubIssuesSummary.setValue(0, "completed");
		placeholderSubIssuesSummary.setValue(0, "percentCompleted");
		subIssueRecord.setLinkedRecord(placeholderSubIssuesSummary, "subIssuesSummary");
	}
	if (!subIssueRecord.getLinkedRecord("closedByPullRequestsReferences", {
		first: 0,
		includeClosedPrs: true
	})) {
		const placeholderClosedByPRs = store.create(`${subIssueId}:closedByPullRequestsReferences:optimistic`, "IssueClosedByPullRequestsReferencesConnection");
		placeholderClosedByPRs.setLinkedRecords([], "nodes");
		placeholderClosedByPRs.setValue(0, "totalCount");
		subIssueRecord.setLinkedRecord(placeholderClosedByPRs, "closedByPullRequestsReferences", {
			first: 0,
			includeClosedPrs: true
		});
	}
}
function optimisticUpdateSubIssuesConnection(store, input) {
	if (!input.subIssueId) return;
	const parentRecord = store.get(input.issueId);
	if (!parentRecord) return;
	const subIssueRecord = store.get(input.subIssueId);
	if (!subIssueRecord) return;
	const subIssuesConnection = getSubIssuesConnection(parentRecord);
	if (!subIssuesConnection) return;
	ensureSubIssueRequiredFields(store, subIssueRecord);
	const currentNodes = subIssuesConnection.getLinkedRecords("nodes") || [];
	if (!currentNodes.some((node) => node?.getValue("id") === input.subIssueId)) {
		const newNodes = [...currentNodes, subIssueRecord];
		subIssuesConnection.setLinkedRecords(newNodes, "nodes");
		const currentTotalCount = subIssuesConnection.getValue("totalCount");
		if (typeof currentTotalCount === "number") subIssuesConnection.setValue(currentTotalCount + 1, "totalCount");
		else subIssuesConnection.setValue(currentNodes.length + 1, "totalCount");
	}
	const subIssuesSummary = parentRecord.getLinkedRecord("subIssuesSummary");
	if (subIssuesSummary) {
		const currentTotal = subIssuesSummary.getValue("total");
		if (typeof currentTotal === "number") subIssuesSummary.setValue(currentTotal + 1, "total");
		if (subIssueRecord.getValue("closed") === true) {
			const currentCompleted = subIssuesSummary.getValue("completed");
			if (typeof currentCompleted === "number") subIssuesSummary.setValue(currentCompleted + 1, "completed");
		}
	}
	const subIssuesConnectionRecord = getSubIssuesConnectionAlias(parentRecord);
	if (subIssuesConnectionRecord) {
		const connectionTotalCount = subIssuesConnectionRecord.getValue("totalCount");
		if (typeof connectionTotalCount === "number") subIssuesConnectionRecord.setValue(connectionTotalCount + 1, "totalCount");
	}
}
function addSubIssueToConnectionFromResponse(store, input) {
	const payload = store.getRootField("addSubIssue");
	if (!payload) return;
	const subIssueRecord = payload.getLinkedRecord("subIssue");
	if (!subIssueRecord) return;
	const parentRecord = store.get(input.issueId);
	if (!parentRecord) return;
	const subIssuesConnection = getSubIssuesConnection(parentRecord);
	if (!subIssuesConnection) return;
	const currentNodes = subIssuesConnection.getLinkedRecords("nodes") || [];
	if (!currentNodes.some((node) => node?.getDataID() === subIssueRecord.getDataID())) {
		subIssuesConnection.setLinkedRecords([...currentNodes, subIssueRecord], "nodes");
		const currentTotalCount = subIssuesConnection.getValue("totalCount");
		if (typeof currentTotalCount === "number") subIssuesConnection.setValue(currentTotalCount + 1, "totalCount");
	}
}
function addSubIssueMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$7,
		variables: { input },
		optimisticUpdater: (store) => optimisticUpdateSubIssuesConnection(store, input),
		updater: (store) => addSubIssueToConnectionFromResponse(store, input),
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
/**
* Context sub-issues-related state in the issue viewer.
*/
var SubIssueStateContext = createContext(void 0);
SubIssueStateContext.displayName = "SubIssueStateContext";
function SubIssueStateProvider(t0) {
	const $ = c(8);
	const { children } = t0;
	const [activeIssueId, setActiveIssueId] = useState(void 0);
	const createDialogOpen = activeIssueId !== void 0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (issueId) => setActiveIssueId(issueId);
		$[0] = t1;
	} else t1 = $[0];
	const openCreateDialog = t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => setActiveIssueId(void 0);
		$[1] = t2;
	} else t2 = $[1];
	const closeCreateDialog = t2;
	let t3;
	if ($[2] !== activeIssueId || $[3] !== createDialogOpen) {
		t3 = {
			createDialogOpen,
			activeIssueId,
			closeCreateDialog,
			openCreateDialog
		};
		$[2] = activeIssueId;
		$[3] = createDialogOpen;
		$[4] = t3;
	} else t3 = $[4];
	const t4 = t3;
	let t5;
	if ($[5] !== children || $[6] !== t4) {
		t5 = jsx(SubIssueStateContext, {
			value: t4,
			children
		});
		$[5] = children;
		$[6] = t4;
		$[7] = t5;
	} else t5 = $[7];
	return t5;
}
SubIssueStateProvider.displayName = "SubIssueStateProvider";
var useSubIssueState = () => {
	const context = use(SubIssueStateContext);
	if (!context) throw new Error("useSubIssueState must be used within a SubIssueStateContext");
	return context;
};
var AddSubIssueButtonGroup_module_default = { Box: "AddSubIssueButtonGroup-module_2EFd7q_Box" };
var SUB_ISSUES_BREADTH_LIMIT = 100;
function AddSubIssueButtonGroup({ issue, insideSidePanel }) {
	const [open, setOpen] = useState(false);
	const { alert, resetAlert, showBreadthLimitAlert, showServerAlert } = useAlert();
	const [pickerType, setPickerType] = useState(null);
	const { openCreateDialog, createDialogOpen } = useSubIssueState();
	const { addToast } = useToastContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const anchorRef = useRef(null);
	const returnFocusRef = useRef(null);
	const confirm = useConfirm();
	const { sendAnalyticsEvent } = useAnalytics();
	const navigate = useNavigate$1();
	const data = (0, import_react_relay.useFragment)(node$8, issue);
	const subIssuesBreadthLimitReached = (data.subIssues?.nodes?.length || 0) >= SUB_ISSUES_BREADTH_LIMIT;
	const showSubIssuesCopilotMenuItem = useShouldShowCopilotFunctionalityInIssues({
		repositoryVisibility: data.repository.visibility,
		userCanPushToRepo: data.repository.viewerCanPush
	});
	const addSubIssue = useCallback(async ({ subIssue, onError }) => {
		if (!(!subIssue.hasParent || await confirm({
			title: "Are you sure?",
			content: "Sub-issues are limited to one parent. Confirm you want to proceed with this change.",
			confirmButtonType: "primary",
			confirmButtonContent: "Change parent issue"
		}))) return;
		addSubIssueMutation({
			environment,
			input: {
				issueId: data.id,
				subIssueId: subIssue.id,
				replaceParent: true
			},
			onError: (error) => {
				onError?.(error);
			}
		});
	}, [
		confirm,
		data.id,
		environment
	]);
	const onIssueSelection = useCallback((issues) => {
		const [subIssue_0] = issues;
		if (!subIssue_0) return;
		addSubIssue({
			subIssue: {
				hasParent: Boolean(subIssue_0.parent?.id),
				...subIssue_0
			},
			onError: (error_0) => {
				if (!showServerAlert(error_0)) addToast({
					type: "error",
					message: error_0.message
				});
			}
		});
	}, [
		addSubIssue,
		addToast,
		showServerAlert
	]);
	const onPickerTypeChange = useCallback((type) => {
		if (type === null && returnFocusRef?.current) returnFocusRef.current.focus();
		setPickerType(type);
	}, [setPickerType]);
	const onAlertClose = useCallback(() => resetAlert(), [resetAlert]);
	const navigateToSubIssuesCopilot = useCallback(() => {
		sendAnalyticsEvent("analytics.click", "ISSUES_SUB_ISSUES_COPILOT_BUTTON", {
			issueId: data.databaseId,
			issueNumber: data.number,
			repoNWO: data.repository.nameWithOwner
		});
		const prompt = `Create me a sub-issue for @${data.repository.nameWithOwner}/issues/${data.number} to `;
		navigate(`${COPILOT_PATH}?${new URLSearchParams({ prompt }).toString()}`);
	}, [
		sendAnalyticsEvent,
		data.databaseId,
		data.repository.nameWithOwner,
		data.number,
		navigate
	]);
	/**
	* When the issue-viewer is rendered within the side-panel, two issue-viewers are rendered at a time. This results
	* in `<GlobalCommands>` activating both pickers at once. To remedy this, we check if the side-panel is open and
	* whether or not the current issue-viewer is within the side-panel.
	*
	* Commands are only accepted when both the picker and create dialog are closed.
	*
	* If insideSidePanel is false, the issue-viewer is not inside the open side-panel.
	* If insideSidePanel is undefined, the side panel is not open.
	*/
	const shouldAcceptCommand = (insideSidePanel || insideSidePanel === void 0) && pickerType === null && !createDialogOpen;
	const hiddenIssueIds = data.subIssues?.nodes?.filter((node) => !!node).map((i) => i.id) ?? [];
	hiddenIssueIds.push(data.id);
	if (data.parent) hiddenIssueIds.push(data.parent.id);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [alert && /* @__PURE__ */ jsx(RelationshipsAlertDialog, {
		title: alert.title,
		onClose: onAlertClose,
		children: alert.body
	}), /* @__PURE__ */ jsxs("div", {
		className: AddSubIssueButtonGroup_module_default.Box,
		children: [
			shouldAcceptCommand && /* @__PURE__ */ jsx(GlobalCommands, { commands: {
				"sub-issues:add-existing-issue": () => {
					if (subIssuesBreadthLimitReached) showBreadthLimitAlert(SUB_ISSUES_BREADTH_LIMIT);
					else setPickerType("Issue");
				},
				"sub-issues:create-sub-issue": () => {
					if (subIssuesBreadthLimitReached) showBreadthLimitAlert(SUB_ISSUES_BREADTH_LIMIT);
					else {
						setOpen(false);
						setPickerType(null);
						openCreateDialog(data.id);
					}
				}
			} }),
			/* @__PURE__ */ jsxs(ButtonGroup, {
				ref: anchorRef,
				children: [/* @__PURE__ */ jsx(CommandButton, {
					size: "small",
					commandId: "sub-issues:create-sub-issue",
					children: "Create sub-issue"
				}), /* @__PURE__ */ jsx(IconButton, {
					unsafeDisableTooltip: true,
					size: "small",
					icon: TriangleDownIcon,
					"aria-label": "View more sub-issue options",
					ref: returnFocusRef,
					onClick: () => {
						setOpen((o) => !o);
						setPickerType(null);
					}
				})]
			}),
			/* @__PURE__ */ jsx(ActionMenu, {
				open,
				onOpenChange: setOpen,
				anchorRef,
				children: /* @__PURE__ */ jsx(ActionMenu.Overlay, {
					width: "small",
					returnFocusRef,
					children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsxs(ActionList.Group, { children: [
						/* @__PURE__ */ jsx(CommandActionListItem, {
							role: "button",
							commandId: "sub-issues:create-sub-issue",
							leadingVisual: /* @__PURE__ */ jsx(PlusCircleIcon, {}),
							children: "Create sub-issue"
						}),
						/* @__PURE__ */ jsx(CommandActionListItem, {
							commandId: "sub-issues:add-existing-issue",
							leadingVisual: /* @__PURE__ */ jsx(IssueOpenedIcon, {}),
							role: "button",
							children: "Add existing issue"
						}),
						showSubIssuesCopilotMenuItem && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ActionList.Divider, {}), /* @__PURE__ */ jsxs(ActionList.Item, {
							role: "button",
							onSelect: navigateToSubIssuesCopilot,
							children: [
								/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CopilotIcon, {}) }),
								"Draft with Copilot",
								/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(ArrowUpRightIcon, {}) })
							]
						})] })
					] }) })
				})
			}),
			/* @__PURE__ */ jsx(RepositoryAndIssuePicker, {
				selectedIssueIds: [],
				hiddenIssueIds,
				onPickerTypeChange,
				onIssueSelection,
				defaultRepositoryNameWithOwner: data.repository.nameWithOwner,
				organization: data.repository.owner.login,
				pickerType,
				withParent: true,
				anchorElement: (props) => {
					const { ref } = props;
					if (ref) ref.current = anchorRef.current;
					return /* @__PURE__ */ jsx(Fragment$1, {});
				}
			})
		]
	})] });
}
AddSubIssueButtonGroup.displayName = "AddSubIssueButtonGroup";
var INTERNAL_ONLY_ATTRIBUTES = {
	EXCLUDE_FROM_CACHE_KEY: "exclude_from_cache_key",
	SKIP_NETWORK: "skip_network"
};
var DEFAULT_RELAY_CACHE_TTL = 336 * 60 * 60 * 1e3;
function getDefaultValues(query) {
	const defaultValues = {};
	if ("operation" in query) {
		const argumentDefinitions = query.operation.argumentDefinitions;
		for (const argDef of argumentDefinitions) if (argDef.defaultValue !== void 0 && argDef.defaultValue !== null) defaultValues[argDef.name] = argDef.defaultValue;
	}
	return Object.keys(defaultValues).length > 0 ? defaultValues : void 0;
}
var MAX_CACHE_SIZE = 250;
var LRUCache = class {
	#cache;
	#maxSize;
	constructor(maxSize) {
		this.#cache = /* @__PURE__ */ new Map();
		this.#maxSize = maxSize;
	}
	get(key) {
		const value = this.#cache.get(key);
		if (value !== void 0) {
			this.#cache.delete(key);
			this.#cache.set(key, value);
		}
		return value;
	}
	set(key, value) {
		if (this.#cache.has(key)) this.#cache.delete(key);
		this.#cache.set(key, value);
		if (this.#cache.size > this.#maxSize) {
			const firstKey = this.#cache.keys().next().value;
			if (firstKey !== void 0) this.#cache.delete(firstKey);
		}
	}
	delete(key) {
		this.#cache.delete(key);
	}
	clear() {
		this.#cache.clear();
	}
	get size() {
		return this.#cache.size;
	}
};
new LRUCache(MAX_CACHE_SIZE);
var DEFAULT_OPTIONS = {
	root: null,
	rootMargin: "0px",
	threshold: [0, 1]
};
/**
* Hook that detects whether a sensor element has scrolled out of view,
* indicating a sticky header should be in its "stuck" state.
*
* Returns a callback ref (`sensorRef`) that should be placed on a sentinel
* element at the sticky attachment point.
*
* @param observerOptions  Optional IntersectionObserver options override
*/
function useStickyHeader(t0) {
	const $ = c(5);
	const observerOptions = t0 === void 0 ? DEFAULT_OPTIONS : t0;
	const [isSticky, setIsSticky] = useState(false);
	const [hasRoots, setHasRoots] = useState(false);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (entries) => {
			const entry = entries[entries.length - 1];
			if (entry) {
				setIsSticky(entry.intersectionRatio < 1);
				setHasRoots((entry.rootBounds?.height ?? 0) > 0);
			}
		};
		$[0] = t1;
	} else t1 = $[0];
	const sensorRef = useIntersectionObserver(t1, observerOptions);
	let t2;
	if ($[1] !== hasRoots || $[2] !== isSticky || $[3] !== sensorRef) {
		t2 = {
			isSticky,
			hasRoots,
			sensorRef
		};
		$[1] = hasRoots;
		$[2] = isSticky;
		$[3] = sensorRef;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
var import_relay_runtime = require_relay_runtime();
function fetchQueryWithCache(...args) {
	const [environment, query, variables, options, ttl, preheatSource, skipCache, excludeFromCacheKey, skipNetwork] = args;
	const defaultValues = getDefaultValues(query);
	return (0, import_relay_runtime.fetchQuery)(environment, query, variables, {
		...options,
		networkCacheConfig: { metadata: {
			ttl,
			defaultValues,
			preheatSource,
			skipCache,
			[INTERNAL_ONLY_ATTRIBUTES.EXCLUDE_FROM_CACHE_KEY]: excludeFromCacheKey,
			[INTERNAL_ONLY_ATTRIBUTES.SKIP_NETWORK]: skipNetwork
		} }
	});
}
function clientSideRelayFetchQueryRetainedWithCache(...args) {
	const [options, ttl, excludeFromCacheKey] = args;
	const defaultValues = getDefaultValues(options.query);
	return clientSideRelayFetchQueryRetained({
		...options,
		metadata: {
			...options.metadata,
			ttl,
			defaultValues,
			[INTERNAL_ONLY_ATTRIBUTES.EXCLUDE_FROM_CACHE_KEY]: excludeFromCacheKey
		}
	});
}
function cacheForceRefresh(relayEnvironment, { query, number, owner, repo }) {
	fetchQueryWithCache(relayEnvironment, query, {
		owner,
		repo,
		number,
		count: 15
	}, { fetchPolicy: "network-only" }, DEFAULT_RELAY_CACHE_TTL, "force_refresh", true).toPromise();
}
var PREHEAT_REQUESTS_BATCH_SIZE = 4;
var HOT_CACHE_PREHEAT_BATCH_SIZE = 10;
var RelayCachePreheatContext = createContext(null);
RelayCachePreheatContext.displayName = "RelayCachePreheatContext";
function RelayCachePreheatContextProvider({ children }) {
	const relayEnvironment = (0, import_react_relay.useRelayEnvironment)();
	const queriesToPreheatRef = useRef({});
	const queriesToPreheatInHotCacheRef = useRef({});
	const keysRef = useRef(/* @__PURE__ */ new Set());
	const prioritizedKeysRef = useRef(/* @__PURE__ */ new Set());
	const preheatedRef = useRef(/* @__PURE__ */ new Set());
	const keysForHotCacheRef = useRef(/* @__PURE__ */ new Set());
	const preheatedHotCacheRef = useRef(/* @__PURE__ */ new Set());
	const [pending, setPending] = useState(false);
	const [pendingHotCache, setPendingHotCache] = useState(false);
	const preheatQuery = useCallback(async (key, forHotCache) => {
		if (!(forHotCache ? preheatedHotCacheRef.current.has(key) : preheatedRef.current.has(key))) {
			const queryToPreheat = forHotCache ? queriesToPreheatInHotCacheRef.current[key] : queriesToPreheatRef.current[key];
			if (queryToPreheat) {
				if (!forHotCache) preheatedRef.current.add(key);
				preheatedHotCacheRef.current.add(key);
				try {
					await fetchQueryWithCache(relayEnvironment, queryToPreheat.query, queryToPreheat.variables, { fetchPolicy: "store-or-network" }, DEFAULT_RELAY_CACHE_TTL, queryToPreheat.source, false, queryToPreheat.excludeFromCacheKey, forHotCache).toPromise();
				} catch {}
				return true;
			}
		}
		return false;
	}, [relayEnvironment]);
	const markQueryForPreheating = useCallback((query, variables, source, excludeFromCacheKey, highPriority) => {
		const queryName = query.fragment.name;
		const filteredVariables = { ...variables };
		if (excludeFromCacheKey && excludeFromCacheKey.length > 0) for (const key_0 of excludeFromCacheKey) delete filteredVariables[key_0];
		const key_1 = `${queryName}#${JSON.stringify(Object.fromEntries(Object.entries(filteredVariables).sort(([a], [b]) => a < b ? -1 : 1)))}`;
		if (!keysForHotCacheRef.current.has(key_1)) {
			queriesToPreheatInHotCacheRef.current[key_1] = {
				query,
				variables,
				source,
				excludeFromCacheKey
			};
			keysForHotCacheRef.current.add(key_1);
		}
		if (highPriority) {
			if (!prioritizedKeysRef.current.has(key_1)) {
				queriesToPreheatRef.current[key_1] = {
					query,
					variables,
					source,
					excludeFromCacheKey
				};
				prioritizedKeysRef.current.add(key_1);
			}
		} else if (!keysRef.current.has(key_1)) {
			queriesToPreheatRef.current[key_1] = {
				query,
				variables,
				source,
				excludeFromCacheKey
			};
			keysRef.current.add(key_1);
		}
		setPendingHotCache(true);
		setPending(true);
	}, []);
	const preheatQuerySet = useCallback((promises, querySet) => {
		for (const key_2 of querySet) {
			if (promises.length >= PREHEAT_REQUESTS_BATCH_SIZE) break;
			if (!preheatedRef.current.has(key_2)) promises.push(preheatQuery(key_2, false));
		}
		return promises;
	}, [preheatQuery]);
	const preHeatQueries = useCallback(async () => {
		const promises_0 = preheatQuerySet([], prioritizedKeysRef.current);
		preheatQuerySet(promises_0, keysRef.current);
		await Promise.all(promises_0);
		if (preheatedRef.current.size >= prioritizedKeysRef.current.size + keysRef.current.size) setPending(false);
	}, [preheatQuerySet]);
	const deferHotCachePreheating = isFeatureEnabled("issues_react_defer_hot_cache_preheating");
	useEffect(() => {
		let cancelled = false;
		const scheduleNextPreheat = () => {
			if (cancelled || !("requestIdleCallback" in window)) return;
			requestIdleCallback(() => {
				if (cancelled || !pending) return;
				const runPreheat = async () => {
					await preHeatQueries();
					scheduleNextPreheat();
				};
				runPreheat();
			});
		};
		scheduleNextPreheat();
		return () => {
			cancelled = true;
		};
	}, [preHeatQueries, pending]);
	useEffect(() => {
		if (!pendingHotCache) return;
		let cancelled_0 = false;
		const waitForIdle = () => new Promise((resolve) => {
			if ("requestIdleCallback" in window) requestIdleCallback(() => resolve());
			else resolve();
		});
		const run = async () => {
			const keys = [...keysForHotCacheRef.current].filter((key_3) => !preheatedHotCacheRef.current.has(key_3));
			if (deferHotCachePreheating) for (let i = 0; i < keys.length; i += HOT_CACHE_PREHEAT_BATCH_SIZE) {
				if (cancelled_0) return;
				await waitForIdle();
				if (cancelled_0) return;
				const batch = keys.slice(i, i + HOT_CACHE_PREHEAT_BATCH_SIZE);
				await Promise.all(batch.map((key_4) => preheatQuery(key_4, true)));
			}
			else await Promise.all(keys.map((key_5) => preheatQuery(key_5, true)));
			setPendingHotCache(false);
		};
		run();
		return () => {
			cancelled_0 = true;
		};
	}, [
		pendingHotCache,
		preheatQuery,
		deferHotCachePreheating
	]);
	return /* @__PURE__ */ jsx(RelayCachePreheatContext, {
		value: useMemo(() => {
			return {
				markQueryForPreheating,
				preHeatQueries
			};
		}, [markQueryForPreheating, preHeatQueries]),
		children
	});
}
RelayCachePreheatContextProvider.displayName = "RelayCachePreheatContextProvider";
var useRelayCachePreheatContext = () => {
	const context = use(RelayCachePreheatContext);
	if (!context) {
		console.warn("useRelayCachePreheatContext must be used within a RelayCachePreheatContextProvider");
		return {
			markQueryForPreheating: () => {},
			preHeatQueries: () => {}
		};
	}
	return context;
};
function useCachePreheatQuery(t0) {
	const $ = c(10);
	const { query, variables, source, enabled: t1, excludeFromCacheKey, highPriority } = t0;
	const enabled = t1 === void 0 ? true : t1;
	const { markQueryForPreheating } = useRelayCachePreheatContext();
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = !isFeatureEnabled("disable_preheating_for_issues") && isLoggedIn();
		$[0] = t2;
	} else t2 = $[0];
	const preHeatingEnabled = t2;
	let t3;
	let t4;
	if ($[1] !== enabled || $[2] !== excludeFromCacheKey || $[3] !== highPriority || $[4] !== markQueryForPreheating || $[5] !== query || $[6] !== source || $[7] !== variables) {
		t3 = () => {
			if (!enabled || !query || !preHeatingEnabled) return;
			markQueryForPreheating(query, variables, source, excludeFromCacheKey, highPriority);
		};
		t4 = [
			markQueryForPreheating,
			variables,
			query,
			source,
			enabled,
			excludeFromCacheKey,
			highPriority,
			preHeatingEnabled
		];
		$[1] = enabled;
		$[2] = excludeFromCacheKey;
		$[3] = highPriority;
		$[4] = markQueryForPreheating;
		$[5] = query;
		$[6] = source;
		$[7] = variables;
		$[8] = t3;
		$[9] = t4;
	} else {
		t3 = $[8];
		t4 = $[9];
	}
	useEffect(t3, t4);
}
function useCachePreheatQueries(t0) {
	const $ = c(5);
	const { queries } = t0;
	const { markQueryForPreheating } = useRelayCachePreheatContext();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = !isFeatureEnabled("disable_preheating_for_issues") && isLoggedIn();
		$[0] = t1;
	} else t1 = $[0];
	const preHeatingEnabled = t1;
	let t2;
	let t3;
	if ($[1] !== markQueryForPreheating || $[2] !== queries) {
		t2 = () => {
			for (const query of queries) {
				if (!(query.enabled ?? true) || !query.query || !preHeatingEnabled) continue;
				markQueryForPreheating(query.query, query.variables, query.source, query.excludeFromCacheKey, query.highPriority);
			}
		};
		t3 = [
			markQueryForPreheating,
			queries,
			preHeatingEnabled
		];
		$[1] = markQueryForPreheating;
		$[2] = queries;
		$[3] = t2;
		$[4] = t3;
	} else {
		t2 = $[3];
		t3 = $[4];
	}
	useEffect(t2, t3);
}
function getIssueTitle(title, titleHTML) {
	if (isFeatureEnabled("issues_react_prohibit_title_fallback")) return titleHTML;
	return titleHTML || title;
}
var getIssueSearchURL = ({ owner, repo }, field, value) => {
	if (!owner || !repo) return "";
	const baseUrl = `/${owner}/${repo}/issues`;
	if (!field || !value) return baseUrl;
	value = value.includes(" ") ? `"${value}"` : value;
	return `${baseUrl}?q=${encodeURIComponent(`${field}:${value}`)}`;
};
/**
* Gathers all issue link hrefs (elements with class "issue-link") from a container element.
* Issue links are server-rendered anchors that reference issues/PRs.
*/
function gatherIssueLinks(container) {
	if (!container) return [];
	const issueLinks = container.querySelectorAll("a.issue-link");
	return Array.from(issueLinks).map((link) => link.href);
}
var ProgressCircle_module_default = {
	animatedCircle: "ProgressCircle-module_kqIxoq_animatedCircle",
	circle: "ProgressCircle-module_kqIxoq_circle",
	circleProgress: "ProgressCircle-module_kqIxoq_circleProgress",
	circleProgressShade: "ProgressCircle-module_kqIxoq_circleProgressShade",
	completedIcon: "ProgressCircle-module_kqIxoq_completedIcon",
	ringSvg: "ProgressCircle-module_kqIxoq_ringSvg"
};
function CompletedIcon({ size, accent }) {
	return /* @__PURE__ */ jsxs("svg", {
		"aria-hidden": "true",
		focusable: "false",
		width: size,
		height: size,
		viewBox: `0 0 16 16`,
		className: ProgressCircle_module_default.completedIcon,
		children: [/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M10.0206 11.1074C9.68518 11.3949 9.18014 11.3561 8.8926 11.0206L5.8926 7.52061C5.62055 7.20322 5.63873 6.72989 5.93432 6.4343L7.43432 4.9343C7.74674 4.62188 8.25327 4.62188 8.56569 4.9343C8.87811 5.24672 8.87811 5.75325 8.56569 6.06567L7.58953 7.04182L10.1074 9.97935C10.3949 10.3148 10.3561 10.8198 10.0206 11.1074Z",
			fill: accent
		}), /* @__PURE__ */ jsx("circle", {
			className: ProgressCircle_module_default.animatedCircle,
			stroke: accent,
			strokeWidth: "2",
			fill: "transparent",
			cx: "50%",
			cy: "50%",
			r: Math.floor(size / 2) - 1
		})]
	});
}
CompletedIcon.displayName = "CompletedIcon";
var ProgressCircleInternal = (t0) => {
	const $ = c(15);
	const { percentCompleted, size, accent, svgClassName } = t0;
	const { theme } = useTheme();
	const radius = Math.floor(85) / 2;
	const lineCapRadius = Math.ceil(7.5);
	const percentCompletedCalculated = percentCompleted >= 100 ? 100 : Math.max(percentCompleted - lineCapRadius, 1);
	const t1 = theme?.colors.border.default;
	let t2;
	if ($[0] !== t1) {
		t2 = jsx("circle", {
			className: ProgressCircle_module_default.circle,
			cx: "50",
			cy: "50",
			r: radius,
			fill: "none",
			stroke: t1,
			strokeWidth: 15
		});
		$[0] = t1;
		$[1] = t2;
	} else t2 = $[1];
	const Background = t2;
	const t3 = percentCompletedCalculated === 100 ? 0 : 100 - percentCompletedCalculated - lineCapRadius;
	let t4;
	if ($[2] !== accent || $[3] !== t3) {
		t4 = jsx("circle", {
			className: ProgressCircle_module_default.circleProgressShade,
			cx: "50",
			cy: "50",
			r: "20",
			fill: "none",
			pathLength: "100",
			stroke: accent,
			strokeDasharray: "100",
			strokeDashoffset: t3,
			strokeWidth: "40",
			style: { transform: "rotate(-90deg)" }
		});
		$[2] = accent;
		$[3] = t3;
		$[4] = t4;
	} else t4 = $[4];
	const Shade = t4;
	const t5 = 100 - percentCompletedCalculated;
	let t6;
	if ($[5] !== accent || $[6] !== t5) {
		t6 = jsx("circle", {
			className: ProgressCircle_module_default.circleProgress,
			cx: "50",
			cy: "50",
			r: radius,
			fill: "none",
			pathLength: "100",
			stroke: accent,
			strokeDasharray: "100",
			strokeDashoffset: t5,
			strokeLinecap: "round",
			strokeWidth: 15,
			style: { transform: "rotate(-75deg)" }
		});
		$[5] = accent;
		$[6] = t5;
		$[7] = t6;
	} else t6 = $[7];
	const Ring = t6;
	let t7;
	if ($[8] !== Background || $[9] !== Ring || $[10] !== Shade || $[11] !== percentCompleted || $[12] !== size || $[13] !== svgClassName) {
		t7 = jsxs("svg", {
			className: clsx(ProgressCircle_module_default.ringSvg, svgClassName),
			height: size,
			width: size,
			role: "presentation",
			viewBox: "0 0 100 100",
			"aria-hidden": "true",
			focusable: "false",
			children: [
				percentCompleted > 0 ? Shade : null,
				Background,
				percentCompleted > 0 ? Ring : null
			]
		});
		$[8] = Background;
		$[9] = Ring;
		$[10] = Shade;
		$[11] = percentCompleted;
		$[12] = size;
		$[13] = svgClassName;
		$[14] = t7;
	} else t7 = $[14];
	return t7;
};
ProgressCircleInternal.displayName = "ProgressCircleInternal";
function ProgressCircle(t0) {
	const $ = c(5);
	const { percentCompleted, size: t1, color: t2, svgClassName } = t0;
	const size = t1 === void 0 ? 16 : t1;
	const { accent } = useNamedColor(t2 === void 0 ? "PURPLE" : t2);
	if (!accent) return null;
	let t3;
	if ($[0] !== accent || $[1] !== percentCompleted || $[2] !== size || $[3] !== svgClassName) {
		t3 = percentCompleted === 100 ? jsx(CompletedIcon, {
			size,
			accent
		}) : jsx(ProgressCircleInternal, {
			percentCompleted,
			size,
			accent,
			svgClassName
		});
		$[0] = accent;
		$[1] = percentCompleted;
		$[2] = size;
		$[3] = svgClassName;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
}
ProgressCircle.displayName = "ProgressCircle";
var node$6 = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "useSubIssuesSummary_issueState",
	"selections": [{
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "closed",
		"storageKey": null
	}],
	"type": "Issue",
	"abstractKey": null
};
node$6.hash = "515e31dab563432fdb7cf114f8ecc2d8";
var node$5 = {
	"argumentDefinitions": [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "fetchSubIssues"
	}],
	"kind": "Fragment",
	"metadata": null,
	"name": "useSubIssuesSummary",
	"selections": [{
		"condition": "fetchSubIssues",
		"kind": "Condition",
		"passingValue": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "SubIssuesSummary",
			"kind": "LinkedField",
			"name": "subIssuesSummary",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "total",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "completed",
				"storageKey": null
			}],
			"storageKey": null
		}]
	}, {
		"condition": "fetchSubIssues",
		"kind": "Condition",
		"passingValue": true,
		"selections": [{
			"alias": "subIssuesConnection",
			"args": null,
			"concreteType": "IssueConnection",
			"kind": "LinkedField",
			"name": "subIssues",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "totalCount",
				"storageKey": null
			}],
			"storageKey": null
		}, {
			"alias": null,
			"args": [{
				"kind": "Literal",
				"name": "first",
				"value": 100
			}],
			"concreteType": "IssueConnection",
			"kind": "LinkedField",
			"name": "subIssues",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "Issue",
				"kind": "LinkedField",
				"name": "nodes",
				"plural": true,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "closed",
					"storageKey": null
				}, {
					"args": null,
					"kind": "FragmentSpread",
					"name": "useSubIssuesSummary_issueState"
				}],
				"storageKey": null
			}],
			"storageKey": "subIssues(first:100)"
		}]
	}],
	"type": "Issue",
	"abstractKey": null
};
node$5.hash = "b8c7a5a9e14e324b17a4626afdfd5b10";
/**
* `subIssuesSummary` is updated asynchronously, meaning that it is not guarunteed to be synchronized with `subIssues`.
* This can cause issues when the sub-issues list is visible, as `subIssuesSummary` may not align with the list of
* visible issues. To resolve this, we calculate the summary on the client side if the sub-issues list is loaded.
*
* Consumers should *always* prefer calling `useSubIssuesSummary` over reading the `subIssuesSummary` field directly.
*
* Note: this would work much better as a [derived field](https://relay.dev/docs/guides/relay-resolvers/derived-fields/)
* but that's an experimental v17 Relay feature we don't have access to yet.
*/
function useSubIssuesSummary(issueKey) {
	const $ = c(9);
	const data = (0, import_react_relay.useFragment)(node$5, issueKey);
	let t0;
	if ($[0] !== data) {
		t0 = data || {};
		$[0] = data;
		$[1] = t0;
	} else t0 = $[1];
	const { subIssuesSummary, subIssues, subIssuesConnection } = t0;
	const total = subIssues?.nodes?.length ?? subIssuesConnection?.totalCount ?? subIssuesSummary?.total ?? 0;
	let t1;
	if ($[2] !== subIssues?.nodes || $[3] !== subIssuesSummary?.completed) {
		t1 = subIssues?.nodes?.filter(_temp$1).length ?? subIssuesSummary?.completed ?? 0;
		$[2] = subIssues?.nodes;
		$[3] = subIssuesSummary?.completed;
		$[4] = t1;
	} else t1 = $[4];
	const completed = t1;
	const t2 = total !== 0 ? Math.floor(completed / total * 100) : 0;
	let t3;
	if ($[5] !== completed || $[6] !== t2 || $[7] !== total) {
		t3 = {
			total,
			completed,
			percentCompleted: t2
		};
		$[5] = completed;
		$[6] = t2;
		$[7] = total;
		$[8] = t3;
	} else t3 = $[8];
	return t3;
}
function _temp$1(issue) {
	return issue?.closed;
}
var node$4 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [v2], v4 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "first",
			"value": 100
		}],
		"concreteType": "IssueConnection",
		"kind": "LinkedField",
		"name": "subIssues",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "nodes",
			"plural": true,
			"selections": v3,
			"storageKey": null
		}],
		"storageKey": "subIssues(first:100)"
	}, v5 = {
		"alias": null,
		"args": null,
		"concreteType": "Issue",
		"kind": "LinkedField",
		"name": "subIssue",
		"plural": false,
		"selections": [v2, {
			"alias": null,
			"args": null,
			"concreteType": "Issue",
			"kind": "LinkedField",
			"name": "parent",
			"plural": false,
			"selections": v3,
			"storageKey": null
		}],
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "totalCount",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "removeSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "RemoveSubIssuePayload",
				"kind": "LinkedField",
				"name": "removeSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "SubIssuesListItem"
					}, v4],
					"storageKey": null
				}, v5],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "removeSubIssueMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "RemoveSubIssuePayload",
				"kind": "LinkedField",
				"name": "removeSubIssue",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "issue",
					"plural": false,
					"selections": [
						v2,
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "state",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "stateReason",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueDependenciesSummary",
							"kind": "LinkedField",
							"name": "issueDependenciesSummary",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "blockedBy",
								"storageKey": null
							}],
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 10
							}],
							"concreteType": "UserConnection",
							"kind": "LinkedField",
							"name": "assignees",
							"plural": false,
							"selections": [v6, {
								"alias": null,
								"args": null,
								"concreteType": "UserEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "User",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v2,
										v7,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "avatarUrl",
											"storageKey": null
										}
									],
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "assignees(first:10)"
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "url",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "repository",
							"plural": false,
							"selections": [
								v8,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "__typename",
											"storageKey": null
										},
										v7,
										v2
									],
									"storageKey": null
								},
								v2
							],
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "databaseId",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "number",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "title",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"kind": "ScalarField",
							"name": "titleHTML",
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "IssueType",
							"kind": "LinkedField",
							"name": "issueType",
							"plural": false,
							"selections": [
								v2,
								v8,
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "color",
									"storageKey": null
								}
							],
							"storageKey": null
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "SubIssuesSummary",
							"kind": "LinkedField",
							"name": "subIssuesSummary",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "total",
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "completed",
								"storageKey": null
							}],
							"storageKey": null
						},
						{
							"alias": null,
							"args": [{
								"kind": "Literal",
								"name": "first",
								"value": 0
							}, {
								"kind": "Literal",
								"name": "includeClosedPrs",
								"value": true
							}],
							"concreteType": "PullRequestConnection",
							"kind": "LinkedField",
							"name": "closedByPullRequestsReferences",
							"plural": false,
							"selections": [v6],
							"storageKey": "closedByPullRequestsReferences(first:0,includeClosedPrs:true)"
						},
						v4
					],
					"storageKey": null
				}, v5],
				"storageKey": null
			}]
		},
		"params": {
			"id": "a6735256121a21650fb892cad79c1c63",
			"metadata": {},
			"name": "removeSubIssueMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node$4.hash = "3e41422515e6f86a4588c5f1e596869e";
function commitRemoveSubIssueMutation({ environment, input, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node$4,
		variables: { input },
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var node$3 = {
	"argumentDefinitions": [{
		"defaultValue": 0,
		"kind": "LocalArgument",
		"name": "first"
	}],
	"kind": "Fragment",
	"metadata": null,
	"name": "ClosedByPullRequestsReferences",
	"selections": [{
		"alias": null,
		"args": [{
			"kind": "Variable",
			"name": "first",
			"variableName": "first"
		}, {
			"kind": "Literal",
			"name": "includeClosedPrs",
			"value": true
		}],
		"concreteType": "PullRequestConnection",
		"kind": "LinkedField",
		"name": "closedByPullRequestsReferences",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "totalCount",
			"storageKey": null
		}],
		"storageKey": null
	}],
	"type": "Issue",
	"abstractKey": null
};
node$3.hash = "d13c832969ca720e1f332e81bbc80289";
var node$2 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 10
	}, {
		"kind": "Literal",
		"name": "includeClosedPrs",
		"value": true
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "ClosedByPullRequestsReferencesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ClosedByPullRequestsReferencesList"
					}],
					"type": "Issue",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "ClosedByPullRequestsReferencesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					{
						"kind": "InlineFragment",
						"selections": [{
							"alias": null,
							"args": v3,
							"concreteType": "PullRequestConnection",
							"kind": "LinkedField",
							"name": "closedByPullRequestsReferences",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "PullRequestEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "PullRequest",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v4,
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "title",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "number",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "merged",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "closed",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "isDraft",
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"concreteType": "Repository",
											"kind": "LinkedField",
											"name": "repository",
											"plural": false,
											"selections": [
												{
													"alias": null,
													"args": null,
													"kind": "ScalarField",
													"name": "name",
													"storageKey": null
												},
												{
													"alias": null,
													"args": null,
													"concreteType": null,
													"kind": "LinkedField",
													"name": "owner",
													"plural": false,
													"selections": [
														v2,
														{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "login",
															"storageKey": null
														},
														v4
													],
													"storageKey": null
												},
												v4
											],
											"storageKey": null
										},
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "url",
											"storageKey": null
										},
										v2
									],
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "cursor",
									"storageKey": null
								}],
								"storageKey": null
							}, {
								"alias": null,
								"args": null,
								"concreteType": "PageInfo",
								"kind": "LinkedField",
								"name": "pageInfo",
								"plural": false,
								"selections": [{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "endCursor",
									"storageKey": null
								}, {
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "hasNextPage",
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": "closedByPullRequestsReferences(first:10,includeClosedPrs:true)"
						}, {
							"alias": null,
							"args": v3,
							"filters": ["includeClosedPrs"],
							"handle": "connection",
							"key": "ClosedByPullRequestsReferences__closedByPullRequestsReferences",
							"kind": "LinkedHandle",
							"name": "closedByPullRequestsReferences"
						}],
						"type": "Issue",
						"abstractKey": null
					},
					v4
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "74ac1485e4aba9457c658e9890e4c2a0",
			"metadata": {},
			"name": "ClosedByPullRequestsReferencesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$2.hash = "a26154da51344169d8643d06240034ca";
var node$1 = {
	"argumentDefinitions": [{
		"defaultValue": 10,
		"kind": "LocalArgument",
		"name": "first"
	}],
	"kind": "Fragment",
	"metadata": { "connection": [{
		"count": "first",
		"cursor": null,
		"direction": "forward",
		"path": ["closedByPullRequestsReferences"]
	}] },
	"name": "ClosedByPullRequestsReferencesList",
	"selections": [{
		"alias": "closedByPullRequestsReferences",
		"args": [{
			"kind": "Literal",
			"name": "includeClosedPrs",
			"value": true
		}],
		"concreteType": "PullRequestConnection",
		"kind": "LinkedField",
		"name": "__ClosedByPullRequestsReferences__closedByPullRequestsReferences_connection",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "PullRequestEdge",
			"kind": "LinkedField",
			"name": "edges",
			"plural": true,
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "PullRequest",
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "id",
						"storageKey": null
					},
					{
						"args": null,
						"kind": "FragmentSpread",
						"name": "PullRequest"
					},
					{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "__typename",
						"storageKey": null
					}
				],
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "cursor",
				"storageKey": null
			}],
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"concreteType": "PageInfo",
			"kind": "LinkedField",
			"name": "pageInfo",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "endCursor",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "hasNextPage",
				"storageKey": null
			}],
			"storageKey": null
		}],
		"storageKey": "__ClosedByPullRequestsReferences__closedByPullRequestsReferences_connection(includeClosedPrs:true)"
	}],
	"type": "Issue",
	"abstractKey": null
};
node$1.hash = "c00ad6168f42bc8f268666e9ba0d54e6";
var ClosedByPullRequestsReferences_module_default = {
	linkedPullRequestsBtn: "ClosedByPullRequestsReferences-module_GCBLjq_linkedPullRequestsBtn",
	loadingSpinnerContainer: "ClosedByPullRequestsReferences-module_GCBLjq_loadingSpinnerContainer",
	pullRequestCountAnchor: "ClosedByPullRequestsReferences-module_GCBLjq_pullRequestCountAnchor",
	pullRequestCountText: "ClosedByPullRequestsReferences-module_GCBLjq_pullRequestCountText",
	pullRequestsDropdown: "ClosedByPullRequestsReferences-module_GCBLjq_pullRequestsDropdown"
};
var node = {
	"argumentDefinitions": [],
	"kind": "Fragment",
	"metadata": null,
	"name": "PullRequest",
	"selections": [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "id",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "title",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "number",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "merged",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "closed",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "isDraft",
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"concreteType": "Repository",
			"kind": "LinkedField",
			"name": "repository",
			"plural": false,
			"selections": [{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "name",
				"storageKey": null
			}, {
				"alias": null,
				"args": null,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "owner",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "login",
					"storageKey": null
				}],
				"storageKey": null
			}],
			"storageKey": null
		},
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "url",
			"storageKey": null
		}
	],
	"type": "PullRequest",
	"abstractKey": null
};
node.hash = "070dcbf85630ee9d2e1fc4bb18f732ba";
var PullRequest_module_default = {
	countText: "PullRequest-module_9VCI4a_countText",
	draftIcon: "PullRequest-module_9VCI4a_draftIcon",
	hovercardLink: "PullRequest-module_9VCI4a_hovercardLink",
	pullRequestItemContent: "PullRequest-module_9VCI4a_pullRequestItemContent",
	repositoryInfo: "PullRequest-module_9VCI4a_repositoryInfo"
};
var import_hooks = require_hooks();
var PullRequestFragment = node;
function PullRequest(t0) {
	const $ = c(19);
	const { pullRequest, hovercard } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const { id, number, title, repository: t1, url, merged, closed, isDraft } = (0, import_hooks.useFragment)(PullRequestFragment, pullRequest);
	const { owner, name } = t1;
	const { login } = owner;
	const { theme } = useTheme();
	let t2;
	if ($[0] !== closed || $[1] !== isDraft || $[2] !== merged || $[3] !== theme?.colors) {
		t2 = () => {
			if (merged) return jsx(Octicon, {
				icon: GitMergeIcon,
				size: 16,
				sx: { color: theme?.colors.done.fg }
			});
			else if (closed) return jsx(Octicon, {
				icon: GitPullRequestClosedIcon,
				size: 16,
				sx: { color: theme?.colors.closed.fg }
			});
			else if (isDraft) return jsx(Octicon, {
				icon: GitPullRequestDraftIcon,
				size: 16,
				className: PullRequest_module_default.draftIcon
			});
			else return jsx(Octicon, {
				icon: GitPullRequestIcon,
				size: 16,
				sx: { color: theme?.colors.open.fg }
			});
		};
		$[0] = closed;
		$[1] = isDraft;
		$[2] = merged;
		$[3] = theme?.colors;
		$[4] = t2;
	} else t2 = $[4];
	const getIcon = t2;
	if (hovercard) {
		let t3;
		if ($[5] !== getHovercardAttributesForType || $[6] !== login || $[7] !== name || $[8] !== number || $[9] !== title || $[10] !== url) {
			t3 = jsxs(Link, {
				href: url,
				target: "_blank",
				...getHovercardAttributesForType("pull_request", {
					owner: login,
					repo: name,
					pullRequestNumber: number
				}),
				"aria-label": `link to the pull request #${title}`,
				className: PullRequest_module_default.hovercardLink,
				children: [jsx(GitPullRequestIcon, { size: 16 }), jsx("span", {
					className: PullRequest_module_default.countText,
					children: "1"
				})]
			});
			$[5] = getHovercardAttributesForType;
			$[6] = login;
			$[7] = name;
			$[8] = number;
			$[9] = title;
			$[10] = url;
			$[11] = t3;
		} else t3 = $[11];
		return t3;
	}
	let t3;
	if ($[12] !== getIcon || $[13] !== id || $[14] !== name || $[15] !== number || $[16] !== title || $[17] !== url) {
		t3 = jsxs(ActionList.Item, { children: [jsx(ActionList.LeadingVisual, { children: getIcon() }), jsxs("a", {
			href: url,
			"aria-label": `link to the issue #${title}`,
			className: PullRequest_module_default.pullRequestItemContent,
			children: [jsx("span", { children: title }), jsx("span", {
				className: PullRequest_module_default.repositoryInfo,
				children: `${name}#${number}`
			})]
		})] }, id);
		$[12] = getIcon;
		$[13] = id;
		$[14] = name;
		$[15] = number;
		$[16] = title;
		$[17] = url;
		$[18] = t3;
	} else t3 = $[18];
	return t3;
}
PullRequest.displayName = "PullRequest";
function ClosedByPullRequestsReferences(t0) {
	const $ = c(4);
	const { issueId, closedByPullRequestsReferencesKey } = t0;
	const totalCount = (0, import_react_relay.useFragment)(node$3, closedByPullRequestsReferencesKey)?.closedByPullRequestsReferences?.totalCount ?? 0;
	const [isClosedByPRRequested, setIsClosedByPRRequested] = useState(false);
	if (totalCount === 0) return null;
	let t1;
	if ($[0] !== isClosedByPRRequested || $[1] !== issueId || $[2] !== totalCount) {
		t1 = totalCount === 1 ? jsx(Suspense, {
			fallback: jsxs("div", { children: [jsx(GitPullRequestIcon, { size: 16 }), jsx("span", {
				className: ClosedByPullRequestsReferences_module_default.pullRequestCountText,
				children: totalCount.toString()
			})] }),
			children: isClosedByPRRequested ? jsx(ClosedByPullRequestsReferencesInternal, {
				issueId,
				totalCount
			}) : jsx(ButtonComponent, {
				className: ClosedByPullRequestsReferences_module_default.linkedPullRequestsBtn,
				variant: "link",
				leadingVisual: GitPullRequestIcon,
				onMouseEnter: () => {
					setIsClosedByPRRequested(true);
				},
				onFocus: () => {
					setIsClosedByPRRequested(true);
				},
				"aria-label": "1 linked PR",
				children: totalCount.toString()
			})
		}) : jsxs(ActionMenu, { children: [jsx(ActionMenu.Anchor, { children: jsx(Tooltip$1, {
			direction: "w",
			text: `${totalCount} linked PRs`,
			type: "description",
			children: jsx(ButtonComponent, {
				variant: "link",
				leadingVisual: GitPullRequestIcon,
				className: ClosedByPullRequestsReferences_module_default.linkedPullRequestsBtn,
				"aria-label": `${totalCount} linked PRs`,
				children: totalCount.toString()
			})
		}) }), jsx(ActionMenu.Overlay, { children: jsx(ActionList, {
			className: ClosedByPullRequestsReferences_module_default.pullRequestsDropdown,
			children: jsx(Suspense, {
				fallback: jsx(CenteredLoadingSpinner, {}),
				children: jsx(ClosedByPullRequestsReferencesInternal, {
					issueId,
					totalCount
				})
			})
		}) })] });
		$[0] = isClosedByPRRequested;
		$[1] = issueId;
		$[2] = totalCount;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
ClosedByPullRequestsReferences.displayName = "ClosedByPullRequestsReferences";
function ClosedByPullRequestsReferencesInternal(t0) {
	const $ = c(3);
	const { issueId, ...props } = t0;
	let t1;
	if ($[0] !== issueId) {
		t1 = { id: issueId };
		$[0] = issueId;
		$[1] = t1;
	} else t1 = $[1];
	const data = (0, import_react_relay.useLazyLoadQuery)(node$2, t1);
	if (!data.node) {
		let t2;
		if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = jsx(Fragment$1, { children: "no data" });
			$[2] = t2;
		} else t2 = $[2];
		return t2;
	}
	return jsx(ClosedByPullRequestsReferencesList, {
		closedByPullRequestsReferencesKey: data.node,
		...props
	});
}
ClosedByPullRequestsReferencesInternal.displayName = "ClosedByPullRequestsReferencesInternal";
function ClosedByPullRequestsReferencesList(t0) {
	const $ = c(3);
	const { closedByPullRequestsReferencesKey, totalCount } = t0;
	const data = (0, import_react_relay.useFragment)(node$1, closedByPullRequestsReferencesKey);
	let t1;
	if ($[0] !== data.closedByPullRequestsReferences?.edges || $[1] !== totalCount) {
		const pullRequests = (data.closedByPullRequestsReferences?.edges || []).flatMap(_temp);
		t1 = jsxs(Fragment$1, { children: [totalCount === 1 && jsx(PullRequest, {
			pullRequest: pullRequests[0],
			hovercard: true
		}, "pr0"), totalCount > 1 && jsx(Fragment$1, { children: pullRequests.map(_temp2) })] });
		$[0] = data.closedByPullRequestsReferences?.edges;
		$[1] = totalCount;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
ClosedByPullRequestsReferencesList.displayName = "ClosedByPullRequestsReferencesList";
function _temp2(pr) {
	return jsx(PullRequest, { pullRequest: pr }, `pr${pr.id}`);
}
function _temp(a) {
	return a && a.node ? a.node : [];
}
function CenteredLoadingSpinner() {
	return /* @__PURE__ */ jsx("div", {
		"data-testid": "loading-pulls",
		className: ClosedByPullRequestsReferences_module_default.loadingSpinnerContainer,
		children: /* @__PURE__ */ jsx(Spinner, {})
	});
}
CenteredLoadingSpinner.displayName = "CenteredLoadingSpinner";
export { useSubIssuesSummary as A, useCachePreheatQueries as C, useNestedListViewSelection as D, useNestedListItemLeadingBadge as E, useStickyHeader as O, getIssueTitle as S, useNestedListItemCompletion as T, clientSideRelayFetchQueryRetainedWithCache as _, NestedListItem as a, getDefaultValues as b, NestedListItemLeadingVisual as c, NestedListViewHeader as d, NestedListViewHeaderTitle as f, cacheForceRefresh as g, SubIssueStateProvider as h, INTERNAL_ONLY_ATTRIBUTES as i, useSuppressActions as j, useSubIssueState as k, NestedListItemTitle as l, RelayCachePreheatContextProvider as m, ClosedByPullRequestsReferences as n, NestedListItemActionBar as o, ProgressCircle as p, DEFAULT_RELAY_CACHE_TTL as r, NestedListItemLeadingContent as s, AddSubIssueButtonGroup as t, NestedListView as u, commitRemoveSubIssueMutation as v, useCachePreheatQuery as w, getIssueSearchURL as x, gatherIssueLinks as y };
