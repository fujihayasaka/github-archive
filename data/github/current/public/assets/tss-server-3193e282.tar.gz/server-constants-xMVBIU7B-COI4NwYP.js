/**
* Package-wide constants for the global-sso-banner package
*/
var ANALYTICS_CATEGORY = "global_sso_banner";
var COOKIE_NAME = "dismissed_sso_orgs";
export { COOKIE_NAME as n, ANALYTICS_CATEGORY as t };
