import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { r as fileTreeQuery } from "./server-file-tree-query-BoZ7HlYc-BElKzBR6.js";
var codeViewBlobRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewBlobRoute", {
	path: "/:owner/:repo/blob/:branch/*",
	queries: [mainQuery({
		queryDeps: ({ pathname, searchParams }) => ({
			pathname,
			searchParams
		}),
		encodeFetchPath: true
	}), fileTreeQuery]
});
export { codeViewBlobRoute as t };
