import { useEffect } from "react";
import { c } from "react/compiler-runtime";
function useHideFooter(hide) {
	const $ = c(3);
	let t0;
	let t1;
	if ($[0] !== hide) {
		t0 = () => {
			if (!hide) return;
			const footer = document.querySelector(".footer");
			if (!footer) return;
			footer.hidden = true;
			return () => {
				footer.hidden = false;
			};
		};
		t1 = [hide];
		$[0] = hide;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
}
export { useHideFooter as t };
