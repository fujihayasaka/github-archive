import { Gt as GitMergeQueueIcon, Ir as SkipIcon, Jt as GitPullRequestIcon, Kt as GitPullRequestClosedIcon, Wt as GitMergeIcon, fn as IssueOpenedIcon, qt as GitPullRequestDraftIcon, un as IssueClosedIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { jsx } from "react/jsx-runtime";
var IssueStateIcons = {
	OPEN: ({ className = "", ...props }) => /* @__PURE__ */ jsx(IssueOpenedIcon, {
		"aria-label": "Open",
		...props,
		className: `fgColor-open ${className}`
	}),
	COMPLETED: ({ className = "", ...props }) => /* @__PURE__ */ jsx(IssueClosedIcon, {
		"aria-label": "Completed",
		...props,
		className: `fgColor-done ${className}`
	}),
	NOT_PLANNED: ({ className = "", ...props }) => /* @__PURE__ */ jsx(SkipIcon, {
		"aria-label": "Not planned",
		...props,
		className: `fgColor-muted ${className}`
	}),
	DUPLICATE: ({ className = "", ...props }) => /* @__PURE__ */ jsx(SkipIcon, {
		"aria-label": "Duplicate",
		...props,
		className: `fgColor-muted ${className}`
	})
};
var PullRequestStateIcons = {
	MERGED: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitMergeIcon, {
		"aria-label": "Merged",
		...props,
		className: `fgColor-done ${className}`
	}),
	IN_MERGE_QUEUE: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitMergeQueueIcon, {
		"aria-label": "In merge queue",
		...props,
		className: `fgColor-attention ${className}`
	}),
	QUEUED: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitMergeQueueIcon, {
		"aria-label": "Queued",
		...props,
		className: `fgColor-attention ${className}`
	}),
	OPEN: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitPullRequestIcon, {
		"aria-label": "Open",
		...props,
		className: `fgColor-open ${className}`
	}),
	CLOSED: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitPullRequestClosedIcon, {
		"aria-label": "Closed",
		...props,
		className: `fgColor-closed ${className}`
	}),
	DRAFT: ({ className = "", ...props }) => /* @__PURE__ */ jsx(GitPullRequestDraftIcon, {
		"aria-label": "Draft",
		...props,
		className: `fgColor-draft ${className}`
	})
};
export { PullRequestStateIcons as n, IssueStateIcons as t };
