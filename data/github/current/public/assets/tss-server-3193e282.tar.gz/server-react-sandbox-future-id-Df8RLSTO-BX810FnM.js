performance.mark("js-parse-end:server-react-sandbox-future-id-Df8RLSTO-BX810FnM.js");
import { s as getAuthContext } from "./server-auth-CdSUgQ-0-DHDnXnPo.js";
import { jsxs } from "react/jsx-runtime";
import { getRouteApi } from "@tanstack/react-router";
performance.mark("js-parse-end:react-sandbox-future-id-Df8RLSTO.js");
function getAuthLogin() {
	const getUserLogin = () => {
		return getAuthContext()?.userLogin;
	};
	return getUserLogin();
}
function ReactSandboxFutureId() {
	const routeApi = getRouteApi("/_nav/_react_sandbox_future/react_sandbox_future/$id");
	const { serverTime, someField: message } = routeApi.useLoaderData();
	const userLogin = getAuthLogin();
	const { id } = routeApi.useParams();
	return /* @__PURE__ */ jsxs("main", { children: [
		/* @__PURE__ */ jsxs("h2", { children: ["Welcome to the React Sandbox Future Id: ", id] }),
		/* @__PURE__ */ jsxs("p", { children: ["User: ", userLogin] }),
		/* @__PURE__ */ jsxs("p", { children: ["Server message: ", message] }),
		/* @__PURE__ */ jsxs("p", { children: ["Server time: ", serverTime] })
	] });
}
ReactSandboxFutureId.displayName = "ReactSandboxFutureId";
var SplitComponent = ReactSandboxFutureId;
export { SplitComponent as component };
