performance.mark("js-parse-end:server-blob-BZ3Z5N8V-C1ZyIB3V.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:blob-BZ3Z5N8V.js");
var codeViewBlobServerFn_createServerFn_handler = createServerRpc({
	id: "93143f62fd7abef2b06e315700aa1d9d03a0b62a785fe928a82638f4879af70a",
	name: "codeViewBlobServerFn",
	filename: "src/routes/code-view/blob.tsx"
}, (opts) => codeViewBlobServerFn.__executeServer(opts));
var codeViewBlobServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(codeViewBlobServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		params: data.searchParams,
		service: "dotcom"
	}, "codeViewBlobRoute");
});
export { codeViewBlobServerFn_createServerFn_handler };
