import { Compile } from "typebox/compile";
import { Type } from "typebox";
export { Type as n, Compile as t };
