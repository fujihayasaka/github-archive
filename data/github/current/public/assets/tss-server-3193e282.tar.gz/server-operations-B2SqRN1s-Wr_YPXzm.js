performance.mark("js-parse-end:server-operations-B2SqRN1s-Wr_YPXzm.js");
import { gfm } from "micromark-extension-gfm";
import remarkGfm from "remark-gfm";
import { remark } from "remark";
performance.mark("js-parse-end:operations-B2SqRN1s.js");
function getListItems(list) {
	return list.children.filter((child) => child.type === "listItem");
}
function appendItem(source, position, value) {
	transform(source, (ast) => {
		const block = getTasklistBlocks(ast)[position];
		if (!block) return;
		block.value = transformBlock(block.value, (list) => {
			list.children.push({
				type: "listItem",
				checked: false,
				children: transformText(value)
			});
		});
		source = replaceBlock(source, block);
	});
	return source;
}
function removeItem(source, position) {
	transform(source, (ast) => {
		const block = getTasklistBlocks(ast)[position[0]];
		if (!block) return;
		block.value = transformBlock(block.value, (list) => {
			list.children.splice(position[1], 1);
		});
		source = replaceBlock(source, block);
	});
	return source;
}
function removeTasklistBlock(source, position) {
	transform(source, (ast) => {
		const block = getTasklistBlocks(ast)[position];
		if (!block) return;
		const index = ast.children.indexOf(block);
		ast.children.splice(index, 1);
		source = removeBlock(source, block);
	});
	return source;
}
function updateItemPosition(source, src, dst) {
	transform(source, (ast) => {
		const srcBlock = getTasklistBlocks(ast)[src[0]];
		const dstBlock = getTasklistBlocks(ast)[dst[0]];
		if (!srcBlock || !dstBlock) return;
		let item;
		srcBlock.value = transformBlock(srcBlock.value, (list) => {
			item = getListItems(list)[src[1]];
			list.children.splice(src[1], 1);
		});
		dstBlock.value = transformBlock(dstBlock.value, (list) => {
			if (item) list.children.splice(dst[1], 0, item);
		});
		if (srcBlock === dstBlock) source = replaceBlock(source, srcBlock);
		else if (src[0] < dst[0]) {
			source = replaceBlock(source, dstBlock);
			source = replaceBlock(source, srcBlock);
		} else {
			source = replaceBlock(source, srcBlock);
			source = replaceBlock(source, dstBlock);
		}
	});
	return source;
}
function updateItemState(source, position, closed) {
	transform(source, (ast) => {
		const block = getTasklistBlocks(ast)[position[0]];
		if (!block) return;
		block.value = transformBlock(block.value, (list) => {
			const item = getListItems(list)[position[1]];
			if (!item) return;
			item.checked = closed;
		});
		source = replaceBlock(source, block);
	});
	return source;
}
function updateItemTitle(source, position, value) {
	transform(source, (ast) => {
		const block = getTasklistBlocks(ast)[position[0]];
		if (!block) return;
		block.value = transformBlock(block.value, (list) => {
			const item = getListItems(list)[position[1]];
			if (!item) return;
			item.children = transformText(value);
		});
		source = replaceBlock(source, block);
	});
	return source;
}
function updateTasklistTitle(source, position, value) {
	transform(source, (ast) => {
		const cleanTitle = value.trim();
		const block = getTasklistBlocks(ast)[position];
		if (!block) return;
		block.value = transformBlock(block.value, (_, root, heading) => {
			if (!cleanTitle) {
				const index = root.children.findIndex((node) => node.type === "heading");
				if (index > -1) root.children.splice(index, 1);
				return;
			}
			if (!heading) {
				heading = {
					type: "heading",
					depth: 3,
					children: []
				};
				root.children.unshift(heading);
			}
			heading.children = [{
				type: "raw",
				value: cleanTitle
			}];
		});
		source = replaceBlock(source, block);
	});
	return source;
}
function getTasklistBlocks(ast) {
	return ast.children.filter((node) => node.type === "code" && node.lang === "[tasklist]");
}
function removeBlock(source, block) {
	const before = source.slice(0, block.position.start.offset);
	const after = source.slice(block.position.end.offset);
	return [before.trimEnd(), after.trimStart()].filter(Boolean).join("\n\n");
}
function replaceBlock(source, block) {
	const before = source.slice(0, block.position.start.offset);
	const after = source.slice(block.position.end.offset);
	return `${before}\`\`\`[tasklist]\n${block.value}\n\`\`\`${after}`;
}
function transform(source, callback) {
	return remark().use(remarkGfm).use(() => callback).data("settings", {
		bullet: "-",
		listItemIndent: "one",
		join: [(left, right) => {
			if (left.type === "heading" && right.type === "list") return 0;
		}],
		handlers: { raw: (node) => node.value }
	}).processSync(source).toString();
}
function transformBlock(source, callback) {
	return transform(source, (root) => {
		let list = root.children.find((node) => node.type === "list");
		const heading = root.children.find((node) => node.type === "heading");
		if (!list) {
			list = {
				type: "list",
				children: []
			};
			root.children.push(list);
		}
		for (const listItem of getListItems(list)) for (const paragraph of listItem.children) if (paragraph.type === "paragraph") paragraph.children = paragraph.children.map((child) => ({
			type: "raw",
			value: source.slice(child.position.start.offset, child.position.end.offset)
		}));
		callback(list, root, heading);
	}).replace(/\n+$/, "");
}
function transformText(text) {
	return [{
		type: "paragraph",
		children: [{
			type: "raw",
			value: text.trim()
		}]
	}];
}
export { appendItem, removeItem, removeTasklistBlock, updateItemPosition, updateItemState, updateItemTitle, updateTasklistTitle };
