import { i as VisuallyHidden } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { c as Text$1, l as VisuallyHidden$1, n as AriaStatus } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ai as XCircleFillIcon, Br as SortDescIcon, Gr as SquareFillIcon, I as ChevronLeftIcon, L as ChevronRightIcon, O as CheckIcon, V as ClockIcon, lr as QuestionIcon, pt as DotFillIcon, si as TerminalIcon, zr as SortAscIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as ScrollableRegion } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { r as viewportRanges } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { n as buildPaginationModel } from "./server-model-C1V5yRLd-cRkMt6Ep.js";
import { n as SessionState } from "./server-session-CpgPVfEW-Bkmi4-Or.js";
import React, { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
function ErrorDialog(t0) {
	const $ = c(7);
	const { title: t1, children, onRetry, onDismiss } = t0;
	const title = t1 === void 0 ? "Error" : t1;
	let t2;
	if ($[0] !== onDismiss || $[1] !== onRetry) {
		t2 = (gesture) => {
			if (gesture === "confirm") onRetry === null || onRetry === void 0 || onRetry();
			else onDismiss === null || onDismiss === void 0 || onDismiss();
		};
		$[0] = onDismiss;
		$[1] = onRetry;
		$[2] = t2;
	} else t2 = $[2];
	let t3;
	if ($[3] !== children || $[4] !== t2 || $[5] !== title) {
		t3 = /* @__PURE__ */ jsx(ConfirmationDialog, {
			title,
			onClose: t2,
			confirmButtonContent: "Retry",
			cancelButtonContent: "Dismiss",
			children
		});
		$[3] = children;
		$[4] = t2;
		$[5] = title;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
var SortDirection = {
	ASC: "ASC",
	DESC: "DESC",
	NONE: "NONE"
};
var DEFAULT_SORT_DIRECTION = SortDirection.ASC;
function transition(direction) {
	if (direction === SortDirection.ASC) return SortDirection.DESC;
	return SortDirection.ASC;
}
/**
* A sort strategy for comparing any two values
*/
function basic(a, b) {
	return a === b ? 0 : a < b ? -1 : 1;
}
/**
* A sort strategy for comparing two `Date` values. Also includes support for
* values from `Date.now()`
*/
function datetime(a, b) {
	const timeA = a instanceof Date ? a.getTime() : a;
	const timeB = b instanceof Date ? b.getTime() : b;
	return timeA > timeB ? 1 : timeA < timeB ? -1 : 0;
}
/**
* Compare two numbers using alphanumeric, or natural order, sorting. This
* sorting function breaks up the inputs into groups of text and numbers and
* compares the different sub-groups of each to determine the order of a set of
* strings
*
* @see https://en.wikipedia.org/wiki/Natural_sort_order
*/
function alphanumeric(inputA, inputB) {
	const groupsA = getAlphaNumericGroups(inputA);
	const groupsB = getAlphaNumericGroups(inputB);
	while (groupsA.length !== 0 && groupsB.length !== 0) {
		const a = groupsA.shift();
		const b = groupsB.shift();
		if (a === b) continue;
		else if (typeof a === "string" && typeof b === "string") return a.localeCompare(b);
		else if (typeof a === "number" && typeof b === "number") return a > b ? 1 : -1;
		else if (typeof a === "number" && typeof b === "string") return -1;
		else if (typeof a === "string" && typeof b === "number") return 1;
		else if (a === void 0 || b === void 0) break;
	}
	return groupsA.length > groupsB.length ? 1 : -1;
}
/**
* Break up the given input string into groups of text and numbers
*/
function getAlphaNumericGroups(input) {
	const groups = [];
	let i = 0;
	while (i < input.length) {
		let group = input[i];
		if (isNumeric(group)) {
			while (i + 1 < input.length && isNumeric(input[i + 1])) {
				group = group + input[i + 1];
				i++;
			}
			groups.push(parseInt(group, 10));
		} else {
			while (i + 1 < input.length && !isNumeric(input[i + 1])) {
				group = group + input[i + 1];
				i++;
			}
			groups.push(group);
		}
		i++;
	}
	return groups;
}
/**
* Determine if the given value is a number
*/
function isNumeric(value) {
	return !Number.isNaN(parseInt(value, 10));
}
var strategies = {
	alphanumeric,
	basic,
	datetime
};
function useTable(t0) {
	const $ = c(21);
	const { columns, data, initialSortColumn, initialSortDirection, externalSorting, getRowId } = t0;
	const [rowOrder, setRowOrder] = useState(data);
	const [prevData, setPrevData] = useState(data);
	const [prevColumns, setPrevColumns] = useState(columns);
	let t1;
	if ($[0] !== columns || $[1] !== initialSortColumn || $[2] !== initialSortDirection) {
		t1 = () => getInitialSortState(columns, initialSortColumn, initialSortDirection);
		$[0] = columns;
		$[1] = initialSortColumn;
		$[2] = initialSortDirection;
		$[3] = t1;
	} else t1 = $[3];
	const [sortByColumn, setSortByColumn] = useState(t1);
	const { gridTemplateColumns } = useTableLayout(columns);
	if (columns !== prevColumns) {
		setPrevColumns(columns);
		if (sortByColumn) {
			if (!columns.find((column) => {
				var _column$id;
				const id = (_column$id = column.id) !== null && _column$id !== void 0 ? _column$id : column.field;
				return sortByColumn.id === id;
			})) setSortByColumn(null);
		}
	}
	let t2;
	let t3;
	let t4;
	if ($[4] !== columns || $[5] !== data || $[6] !== externalSorting || $[7] !== getRowId || $[8] !== prevData || $[9] !== rowOrder || $[10] !== sortByColumn) {
		let t5;
		if ($[14] !== sortByColumn) {
			t5 = (column_1) => {
				var _column_1$id;
				const id_0 = (_column_1$id = column_1.id) !== null && _column_1$id !== void 0 ? _column_1$id : column_1.field;
				if (id_0 === void 0) throw new Error("Expected either an `id` or `field` to be defined for a Column");
				const sortable = column_1.sortBy !== void 0 && column_1.sortBy !== false;
				return {
					id: id_0,
					column: column_1,
					isSortable() {
						return sortable;
					},
					getSortDirection() {
						if (sortByColumn && sortByColumn.id === id_0) return sortByColumn.direction;
						return SortDirection.NONE;
					}
				};
			};
			$[14] = sortByColumn;
			$[15] = t5;
		} else t5 = $[15];
		const headers = columns.map(t5);
		if (data !== prevData) {
			setPrevData(data);
			setRowOrder(data);
			if (sortByColumn) sortRows(sortByColumn);
		}
		const sortBy = function sortBy(header) {
			const sortState = {
				id: header.id,
				direction: sortByColumn && sortByColumn.id === header.id ? transition(sortByColumn.direction) : DEFAULT_SORT_DIRECTION
			};
			setSortByColumn(sortState);
			sortRows(sortState);
		};
		function sortRows(state) {
			const header_1 = headers.find((header_0) => header_0.id === state.id);
			if (!header_1) throw new Error(`Unable to find header with id: ${state.id}`);
			if (header_1.column.sortBy === false || header_1.column.sortBy === void 0) throw new Error("The column for this header is not sortable");
			if (externalSorting) return;
			const sortMethod = header_1.column.sortBy === true ? strategies.basic : typeof header_1.column.sortBy === "string" ? strategies[header_1.column.sortBy] : header_1.column.sortBy;
			setRowOrder((rowOrder_0) => rowOrder_0.slice().sort((a, b) => {
				if (header_1.column.field === void 0) return 0;
				if (typeof header_1.column.sortBy === "function") {
					if (state.direction === SortDirection.ASC) return sortMethod(a, b);
					return sortMethod(b, a);
				}
				const valueA = get(a, header_1.column.field);
				const valueB = get(b, header_1.column.field);
				if (valueA && valueB) {
					if (state.direction === SortDirection.ASC) return sortMethod(valueA, valueB);
					return sortMethod(valueB, valueA);
				}
				if (valueA) return -1;
				if (valueB) return 1;
				return 0;
			}));
		}
		t2 = headers;
		t3 = rowOrder.map((row) => {
			const rowId = getRowId(row);
			return {
				id: `${rowId}`,
				getValue() {
					return row;
				},
				getCells() {
					return headers.map((header_2) => {
						var _header_2$column$rowH;
						return {
							id: `${rowId}:${header_2.id}`,
							column: header_2.column,
							rowHeader: (_header_2$column$rowH = header_2.column.rowHeader) !== null && _header_2$column$rowH !== void 0 ? _header_2$column$rowH : false,
							getValue() {
								if (header_2.column.field !== void 0) return get(row, header_2.column.field);
								throw new Error(`Unable to get value for column header ${header_2.id}`);
							}
						};
					});
				}
			};
		});
		t4 = { sortBy };
		$[4] = columns;
		$[5] = data;
		$[6] = externalSorting;
		$[7] = getRowId;
		$[8] = prevData;
		$[9] = rowOrder;
		$[10] = sortByColumn;
		$[11] = t2;
		$[12] = t3;
		$[13] = t4;
	} else {
		t2 = $[11];
		t3 = $[12];
		t4 = $[13];
	}
	let t5;
	if ($[16] !== gridTemplateColumns || $[17] !== t2 || $[18] !== t3 || $[19] !== t4) {
		t5 = {
			headers: t2,
			rows: t3,
			actions: t4,
			gridTemplateColumns
		};
		$[16] = gridTemplateColumns;
		$[17] = t2;
		$[18] = t3;
		$[19] = t4;
		$[20] = t5;
	} else t5 = $[20];
	return t5;
}
function getInitialSortState(columns, initialSortColumn, initialSortDirection) {
	if (initialSortColumn !== void 0) {
		const column = columns.find((column) => {
			return column.id === initialSortColumn || column.field === initialSortColumn;
		});
		if (column === void 0) return null;
		if (column.sortBy === false || column.sortBy === void 0) return null;
		return {
			id: `${initialSortColumn}`,
			direction: initialSortDirection !== null && initialSortDirection !== void 0 ? initialSortDirection : DEFAULT_SORT_DIRECTION
		};
	}
	if (initialSortDirection !== void 0) {
		var _column$id2;
		const column = columns.find((column) => {
			return column.sortBy !== false && column.sortBy !== void 0;
		});
		if (!column) return null;
		const id = (_column$id2 = column.id) !== null && _column$id2 !== void 0 ? _column$id2 : column.field;
		if (id === void 0) return null;
		return {
			id,
			direction: initialSortDirection
		};
	}
	return null;
}
function useTableLayout(columns) {
	return { gridTemplateColumns: getGridTemplateFromColumns(columns).join(" ") };
}
function getGridTemplateFromColumns(columns) {
	return columns.map((column) => {
		var _column$width;
		const columnWidth = (_column$width = column.width) !== null && _column$width !== void 0 ? _column$width : "grow";
		let minWidth = "auto";
		let maxWidth = "1fr";
		if (columnWidth === "auto") maxWidth = "auto";
		if (columnWidth === "grow" && !column.maxWidth) minWidth = "max-content";
		if (columnWidth === "growCollapse") minWidth = "0";
		if (column.minWidth) minWidth = typeof column.minWidth === "number" ? `${column.minWidth}px` : column.minWidth;
		if (column.maxWidth) maxWidth = typeof column.maxWidth === "number" ? `${column.maxWidth}px` : column.maxWidth;
		if (typeof columnWidth !== "number" && [
			"grow",
			"growCollapse",
			"auto"
		].includes(columnWidth)) return minWidth === maxWidth ? minWidth : `minmax(${minWidth}, ${maxWidth})`;
		return typeof columnWidth === "number" ? `${columnWidth}px` : columnWidth;
	});
}
function get(object, path) {
	return path.split(".").reduce((value, key) => {
		return value[key];
	}, object);
}
var classes$2 = { "ButtonReset": "prc-components-ButtonReset-O-bEI" };
var Button = (t0) => {
	const $ = c(10);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx(className, classes$2.ButtonReset);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== children || $[7] !== rest || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsx("button", {
			className: t1,
			type: "button",
			...rest,
			children
		});
		$[6] = children;
		$[7] = rest;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
};
var classes$1 = {
	"TableContainer": "prc-DataTable-TableContainer-hn0p3",
	"TableTitle": "prc-DataTable-TableTitle-nM43N",
	"TableSubtitle": "prc-DataTable-TableSubtitle--L6Ho",
	"TableActions": "prc-DataTable-TableActions-fkc2b",
	"TableDivider": "prc-DataTable-TableDivider-TRc3b",
	"TableOverflowWrapper": "prc-DataTable-TableOverflowWrapper-bSqT-",
	"Table": "prc-DataTable-Table-7ux1n",
	"TableCell": "prc-DataTable-TableCell-Fk4ve",
	"TableHeader": "prc-DataTable-TableHeader-eyTab",
	"TableSortButton": "prc-DataTable-TableSortButton--aq0y",
	"TableHead": "prc-DataTable-TableHead-4FaBf",
	"TableRow": "prc-DataTable-TableRow-Icc7F",
	"TableBody": "prc-DataTable-TableBody-QKQy2",
	"TableCellSkeletonItem": "prc-DataTable-TableCellSkeletonItem-bGhwZ",
	"TableCellSkeleton": "prc-DataTable-TableCellSkeleton-DMdM5",
	"TableSortIcon": "prc-DataTable-TableSortIcon-wHvJw",
	"TableSortIcon--ascending": "prc-DataTable-TableSortIcon--ascending-Lpx6z",
	"TableSortIcon--descending": "prc-DataTable-TableSortIcon--descending-hHJGo",
	"TableCellSkeletonItems": "prc-DataTable-TableCellSkeletonItems-Ljhq5",
	"PlaceholderText": "prc-DataTable-PlaceholderText-8bHo7"
};
var Table$1 = /* @__PURE__ */ React.forwardRef(function Table(t0, ref) {
	const $ = c(21);
	let className;
	let gridTemplateColumns;
	let labelledby;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({"aria-labelledby": labelledby, cellPadding: t1, className, gridTemplateColumns, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = gridTemplateColumns;
		$[3] = labelledby;
		$[4] = rest;
		$[5] = t1;
	} else {
		className = $[1];
		gridTemplateColumns = $[2];
		labelledby = $[3];
		rest = $[4];
		t1 = $[5];
	}
	const cellPadding = t1 === void 0 ? "normal" : t1;
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = clsx("TableOverflowWrapper", classes$1.TableOverflowWrapper);
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== className) {
		t3 = clsx(className, "Table", classes$1.Table);
		$[7] = className;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== gridTemplateColumns) {
		t4 = { "--grid-template-columns": gridTemplateColumns };
		$[9] = gridTemplateColumns;
		$[10] = t4;
	} else t4 = $[10];
	const t5 = t4;
	let t6;
	if ($[11] !== cellPadding || $[12] !== labelledby || $[13] !== ref || $[14] !== rest || $[15] !== t3 || $[16] !== t5) {
		t6 = /* @__PURE__ */ jsx("table", {
			...rest,
			"aria-labelledby": labelledby,
			"data-cell-padding": cellPadding,
			className: t3,
			role: "table",
			ref,
			style: t5
		});
		$[11] = cellPadding;
		$[12] = labelledby;
		$[13] = ref;
		$[14] = rest;
		$[15] = t3;
		$[16] = t5;
		$[17] = t6;
	} else t6 = $[17];
	let t7;
	if ($[18] !== labelledby || $[19] !== t6) {
		t7 = /* @__PURE__ */ jsx(ScrollableRegion, {
			"aria-labelledby": labelledby,
			className: t2,
			children: t6
		});
		$[18] = labelledby;
		$[19] = t6;
		$[20] = t7;
	} else t7 = $[20];
	return t7;
});
function TableHead(t0) {
	const $ = c(3);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableHead", classes$1.TableHead);
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== children) {
		t2 = /* @__PURE__ */ jsx("thead", {
			className: t1,
			role: "rowgroup",
			children
		});
		$[1] = children;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function TableBody(t0) {
	const $ = c(3);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableBody", classes$1.TableBody);
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== children) {
		t2 = /* @__PURE__ */ jsx("tbody", {
			className: t1,
			role: "rowgroup",
			children
		});
		$[1] = children;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function TableHeader(t0) {
	const $ = c(9);
	let align;
	let children;
	let rest;
	if ($[0] !== t0) {
		({align, children, ...rest} = t0);
		$[0] = t0;
		$[1] = align;
		$[2] = children;
		$[3] = rest;
	} else {
		align = $[1];
		children = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableHeader", classes$1.TableHeader);
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== align || $[6] !== children || $[7] !== rest) {
		t2 = /* @__PURE__ */ jsx("th", {
			...rest,
			className: t1,
			role: "columnheader",
			scope: "col",
			"data-cell-align": align,
			children
		});
		$[5] = align;
		$[6] = children;
		$[7] = rest;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
function TableSortHeader(t0) {
	const $ = c(23);
	let align;
	let children;
	let direction;
	let onToggleSort;
	let rest;
	if ($[0] !== t0) {
		({align, children, direction, onToggleSort, ...rest} = t0);
		$[0] = t0;
		$[1] = align;
		$[2] = children;
		$[3] = direction;
		$[4] = onToggleSort;
		$[5] = rest;
	} else {
		align = $[1];
		children = $[2];
		direction = $[3];
		onToggleSort = $[4];
		rest = $[5];
	}
	const ariaSort = direction === "DESC" ? "descending" : direction === "ASC" ? "ascending" : void 0;
	let t1;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableSortButton", classes$1.TableSortButton);
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== onToggleSort) {
		t2 = () => {
			onToggleSort();
		};
		$[7] = onToggleSort;
		$[8] = t2;
	} else t2 = $[8];
	let t3;
	if ($[9] !== direction) {
		t3 = direction === SortDirection.NONE || direction === SortDirection.ASC ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SortAscIcon, { className: clsx("TableSortIcon", "TableSortIcon--ascending", classes$1.TableSortIcon, classes$1["TableSortIcon--ascending"]) }), direction === SortDirection.NONE ? /* @__PURE__ */ jsx(VisuallyHidden$1, { children: "sort ascending" }) : null] }) : null;
		$[9] = direction;
		$[10] = t3;
	} else t3 = $[10];
	let t4;
	if ($[11] !== direction) {
		t4 = direction === SortDirection.DESC ? /* @__PURE__ */ jsx(SortDescIcon, { className: clsx("TableSortIcon", "TableSortIcon--descending", classes$1.TableSortIcon, classes$1["TableSortIcon--descending"]) }) : null;
		$[11] = direction;
		$[12] = t4;
	} else t4 = $[12];
	let t5;
	if ($[13] !== children || $[14] !== t2 || $[15] !== t3 || $[16] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Button, {
			type: "button",
			className: t1,
			onClick: t2,
			children: [
				children,
				t3,
				t4
			]
		});
		$[13] = children;
		$[14] = t2;
		$[15] = t3;
		$[16] = t4;
		$[17] = t5;
	} else t5 = $[17];
	let t6;
	if ($[18] !== align || $[19] !== ariaSort || $[20] !== rest || $[21] !== t5) {
		t6 = /* @__PURE__ */ jsx(TableHeader, {
			...rest,
			"aria-sort": ariaSort,
			align,
			children: t5
		});
		$[18] = align;
		$[19] = ariaSort;
		$[20] = rest;
		$[21] = t5;
		$[22] = t6;
	} else t6 = $[22];
	return t6;
}
function TableRow(t0) {
	const $ = c(7);
	let children;
	let rest;
	if ($[0] !== t0) {
		({children, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = rest;
	} else {
		children = $[1];
		rest = $[2];
	}
	let t1;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableRow", classes$1.TableRow);
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] !== children || $[5] !== rest) {
		t2 = /* @__PURE__ */ jsx("tr", {
			...rest,
			className: t1,
			role: "row",
			children
		});
		$[4] = children;
		$[5] = rest;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
function TableCell(t0) {
	const $ = c(16);
	let align;
	let children;
	let className;
	let rest;
	let scope;
	if ($[0] !== t0) {
		({align, className, children, scope, ...rest} = t0);
		$[0] = t0;
		$[1] = align;
		$[2] = children;
		$[3] = className;
		$[4] = rest;
		$[5] = scope;
	} else {
		align = $[1];
		children = $[2];
		className = $[3];
		rest = $[4];
		scope = $[5];
	}
	const BaseComponent = scope ? "th" : "td";
	const role = scope ? "rowheader" : "cell";
	let t1;
	if ($[6] !== className) {
		t1 = clsx("TableCell", className, classes$1.TableCell);
		$[6] = className;
		$[7] = t1;
	} else t1 = $[7];
	let t2;
	if ($[8] !== BaseComponent || $[9] !== align || $[10] !== children || $[11] !== rest || $[12] !== role || $[13] !== scope || $[14] !== t1) {
		t2 = /* @__PURE__ */ jsx(BaseComponent, {
			...rest,
			className: t1,
			scope,
			role,
			"data-cell-align": align,
			children
		});
		$[8] = BaseComponent;
		$[9] = align;
		$[10] = children;
		$[11] = rest;
		$[12] = role;
		$[13] = scope;
		$[14] = t1;
		$[15] = t2;
	} else t2 = $[15];
	return t2;
}
function TableCellPlaceholder(t0) {
	const $ = c(2);
	const { children } = t0;
	let t1;
	if ($[0] !== children) {
		t1 = /* @__PURE__ */ jsx(Text$1, {
			className: classes$1.PlaceholderText,
			children
		});
		$[0] = children;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
function TableContainer(t0) {
	const $ = c(12);
	let as;
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({children, className, as, ...rest} = t0);
		$[0] = t0;
		$[1] = as;
		$[2] = children;
		$[3] = className;
		$[4] = rest;
	} else {
		as = $[1];
		children = $[2];
		className = $[3];
		rest = $[4];
	}
	const Component = as || "div";
	let t1;
	if ($[5] !== className) {
		t1 = clsx(className, classes$1.TableContainer);
		$[5] = className;
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== Component || $[8] !== children || $[9] !== rest || $[10] !== t1) {
		t2 = /* @__PURE__ */ jsx(Component, {
			...rest,
			className: t1,
			children
		});
		$[7] = Component;
		$[8] = children;
		$[9] = rest;
		$[10] = t1;
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
var TableTitle = /* @__PURE__ */ React.forwardRef(function TableTitle(t0, ref) {
	const $ = c(6);
	const { as: t1, children, id } = t0;
	const BaseComponent = t1 === void 0 ? "h2" : t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = clsx("TableTitle", classes$1.TableTitle);
		$[0] = t2;
	} else t2 = $[0];
	let t3;
	if ($[1] !== BaseComponent || $[2] !== children || $[3] !== id || $[4] !== ref) {
		t3 = /* @__PURE__ */ jsx(BaseComponent, {
			className: t2,
			id,
			ref,
			children
		});
		$[1] = BaseComponent;
		$[2] = children;
		$[3] = id;
		$[4] = ref;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
});
function TableSubtitle(t0) {
	const $ = c(5);
	const { as: t1, children, id } = t0;
	const BaseComponent = t1 === void 0 ? "div" : t1;
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = clsx("TableSubtitle", classes$1.TableSubtitle);
		$[0] = t2;
	} else t2 = $[0];
	let t3;
	if ($[1] !== BaseComponent || $[2] !== children || $[3] !== id) {
		t3 = /* @__PURE__ */ jsx(BaseComponent, {
			className: t2,
			id,
			children
		});
		$[1] = BaseComponent;
		$[2] = children;
		$[3] = id;
		$[4] = t3;
	} else t3 = $[4];
	return t3;
}
function TableDivider() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsx("div", {
			className: clsx("TableDivider", classes$1.TableDivider),
			role: "presentation"
		});
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
function TableActions(t0) {
	const $ = c(3);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TableActions", classes$1.TableActions);
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== children) {
		t2 = /* @__PURE__ */ jsx("div", {
			className: t1,
			children
		});
		$[1] = children;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function TableSkeleton(t0) {
	const $ = c(20);
	let cellPadding;
	let columns;
	let rest;
	let t1;
	if ($[0] !== t0) {
		({cellPadding, columns, rows: t1, ...rest} = t0);
		$[0] = t0;
		$[1] = cellPadding;
		$[2] = columns;
		$[3] = rest;
		$[4] = t1;
	} else {
		cellPadding = $[1];
		columns = $[2];
		rest = $[3];
		t1 = $[4];
	}
	const rows = t1 === void 0 ? 10 : t1;
	const { gridTemplateColumns } = useTableLayout(columns);
	let t2;
	if ($[5] !== columns) {
		t2 = Array.isArray(columns) ? columns.map(_temp) : null;
		$[5] = columns;
		$[6] = t2;
	} else t2 = $[6];
	let t3;
	if ($[7] !== t2) {
		t3 = /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsx(TableRow, { children: t2 }) });
		$[7] = t2;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== columns.length) {
		t4 = Array.from({ length: columns.length });
		$[9] = columns.length;
		$[10] = t4;
	} else t4 = $[10];
	let t5;
	if ($[11] !== rows || $[12] !== t4) {
		t5 = /* @__PURE__ */ jsx(TableBody, { children: /* @__PURE__ */ jsx(TableRow, { children: t4.map((_, i_0) => /* @__PURE__ */ jsxs(TableCell, {
			className: clsx("TableCellSkeleton", classes$1.TableCellSkeleton),
			children: [/* @__PURE__ */ jsx(VisuallyHidden$1, { children: "Loading" }), /* @__PURE__ */ jsx("div", {
				className: clsx("TableCellSkeletonItems", classes$1.TableCellSkeletonItems),
				children: Array.from({ length: rows }).map(_temp2)
			})]
		}, i_0)) }) });
		$[11] = rows;
		$[12] = t4;
		$[13] = t5;
	} else t5 = $[13];
	let t6;
	if ($[14] !== cellPadding || $[15] !== gridTemplateColumns || $[16] !== rest || $[17] !== t3 || $[18] !== t5) {
		t6 = /* @__PURE__ */ jsxs(Table$1, {
			...rest,
			cellPadding,
			gridTemplateColumns,
			children: [t3, t5]
		});
		$[14] = cellPadding;
		$[15] = gridTemplateColumns;
		$[16] = rest;
		$[17] = t3;
		$[18] = t5;
		$[19] = t6;
	} else t6 = $[19];
	return t6;
}
function _temp2(__0, i_1) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx("TableCellSkeletonItem", classes$1.TableCellSkeletonItem),
		children: /* @__PURE__ */ jsx(SkeletonText, {})
	}, i_1);
}
_temp2.displayName = "_temp2";
function _temp(column, i) {
	return /* @__PURE__ */ jsx(TableHeader, { children: typeof column.header === "string" ? column.header : column.header() }, i);
}
_temp.displayName = "_temp";
var classes = {
	"TablePagination": "prc-DataTable-TablePagination-AJ0K7",
	"TablePaginationSteps": "prc-DataTable-TablePaginationSteps-Vxbth",
	"TablePaginationRange": "prc-DataTable-TablePaginationRange-R7KK2",
	"TablePaginationStep": "prc-DataTable-TablePaginationStep-jdto6",
	"TablePaginationAction": "prc-DataTable-TablePaginationAction-SPa7Q",
	"TablePaginationPage": "prc-DataTable-TablePaginationPage-Fn3s-",
	"TablePaginationTruncationStep": "prc-DataTable-TablePaginationTruncationStep-gRyLp"
};
var defaultShowPages = { narrow: false };
function Pagination(t0) {
	const $ = c(60);
	const { "aria-label": label, defaultPageIndex, id, onChange, pageSize: t1, showPages: t2, totalCount } = t0;
	const pageSize = t1 === void 0 ? 25 : t1;
	const showPages = t2 === void 0 ? defaultShowPages : t2;
	let t3;
	if ($[0] !== defaultPageIndex || $[1] !== onChange || $[2] !== pageSize || $[3] !== totalCount) {
		t3 = {
			defaultPageIndex,
			onChange,
			pageSize,
			totalCount
		};
		$[0] = defaultPageIndex;
		$[1] = onChange;
		$[2] = pageSize;
		$[3] = totalCount;
		$[4] = t3;
	} else t3 = $[4];
	const { pageIndex, pageStart, pageEnd, pageCount, hasPreviousPage, hasNextPage, selectPage, selectNextPage, selectPreviousPage } = usePagination(t3);
	let t4;
	if ($[5] !== showPages) {
		t4 = () => {
			if (typeof showPages !== "boolean") return Object.keys(showPages).filter((key) => !showPages[key]);
			if (showPages) return [];
			else return Object.keys(viewportRanges);
		};
		$[5] = showPages;
		$[6] = t4;
	} else t4 = $[6];
	const getViewportRangesToHidePages = t4;
	const t5 = pageIndex + 1;
	const t6 = !!showPages;
	let t7;
	if ($[7] !== pageCount || $[8] !== t5 || $[9] !== t6) {
		t7 = buildPaginationModel(pageCount, t5, t6, 1, 2);
		$[7] = pageCount;
		$[8] = t5;
		$[9] = t6;
		$[10] = t7;
	} else t7 = $[10];
	const model = t7;
	let t8;
	if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = clsx("TablePagination", classes.TablePagination);
		$[11] = t8;
	} else t8 = $[11];
	let t9;
	if ($[12] !== pageEnd || $[13] !== pageStart || $[14] !== totalCount) {
		t9 = /* @__PURE__ */ jsx(Range, {
			pageStart,
			pageEnd,
			totalCount
		});
		$[12] = pageEnd;
		$[13] = pageStart;
		$[14] = totalCount;
		$[15] = t9;
	} else t9 = $[15];
	let t10;
	if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = clsx("TablePaginationSteps", classes.TablePaginationSteps);
		$[16] = t10;
	} else t10 = $[16];
	let t11;
	if ($[17] !== getViewportRangesToHidePages) {
		t11 = getViewportRangesToHidePages();
		$[17] = getViewportRangesToHidePages;
		$[18] = t11;
	} else t11 = $[18];
	const t12 = t11.join(" ");
	let t13;
	if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = clsx("TablePaginationAction", classes.TablePaginationAction);
		$[19] = t13;
	} else t13 = $[19];
	const t14 = hasPreviousPage ? true : void 0;
	const t15 = !hasPreviousPage ? true : void 0;
	let t16;
	if ($[20] !== hasPreviousPage || $[21] !== selectPreviousPage) {
		t16 = () => {
			if (!hasPreviousPage) return;
			selectPreviousPage();
		};
		$[20] = hasPreviousPage;
		$[21] = selectPreviousPage;
		$[22] = t16;
	} else t16 = $[22];
	let t17;
	if ($[23] !== hasPreviousPage) {
		t17 = hasPreviousPage ? /* @__PURE__ */ jsx(ChevronLeftIcon, {}) : null;
		$[23] = hasPreviousPage;
		$[24] = t17;
	} else t17 = $[24];
	let t18;
	let t19;
	if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
		t18 = /* @__PURE__ */ jsx("span", { children: "Previous" });
		t19 = /* @__PURE__ */ jsx(VisuallyHidden, { children: "\xA0page" });
		$[25] = t18;
		$[26] = t19;
	} else {
		t18 = $[25];
		t19 = $[26];
	}
	let t20;
	if ($[27] !== t14 || $[28] !== t15 || $[29] !== t16 || $[30] !== t17) {
		t20 = /* @__PURE__ */ jsx(Step, { children: /* @__PURE__ */ jsxs(Button, {
			className: t13,
			type: "button",
			"data-has-page": t14,
			"aria-disabled": t15,
			onClick: t16,
			children: [
				t17,
				t18,
				t19
			]
		}) });
		$[27] = t14;
		$[28] = t15;
		$[29] = t16;
		$[30] = t17;
		$[31] = t20;
	} else t20 = $[31];
	let t21;
	if ($[32] !== model || $[33] !== selectPage) {
		let t22;
		if ($[35] !== selectPage) {
			t22 = (page, i) => {
				if (page.type === "BREAK") return /* @__PURE__ */ jsx(TruncationStep, {}, `truncation-${i}`);
				else if (page.type === "NUM") return /* @__PURE__ */ jsx(Step, { children: /* @__PURE__ */ jsxs(Page, {
					active: !!page.selected,
					onClick: () => {
						selectPage(page.num - 1);
					},
					children: [page.num, page.precedesBreak ? /* @__PURE__ */ jsx(VisuallyHidden, { children: "…" }) : null]
				}) }, i);
			};
			$[35] = selectPage;
			$[36] = t22;
		} else t22 = $[36];
		t21 = model.map(t22);
		$[32] = model;
		$[33] = selectPage;
		$[34] = t21;
	} else t21 = $[34];
	let t22;
	if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
		t22 = clsx("TablePaginationAction", classes.TablePaginationAction);
		$[37] = t22;
	} else t22 = $[37];
	const t23 = hasNextPage ? true : void 0;
	const t24 = !hasNextPage ? true : void 0;
	let t25;
	if ($[38] !== hasNextPage || $[39] !== selectNextPage) {
		t25 = () => {
			if (!hasNextPage) return;
			selectNextPage();
		};
		$[38] = hasNextPage;
		$[39] = selectNextPage;
		$[40] = t25;
	} else t25 = $[40];
	let t26;
	let t27;
	if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
		t26 = /* @__PURE__ */ jsx("span", { children: "Next" });
		t27 = /* @__PURE__ */ jsx(VisuallyHidden, { children: "\xA0page" });
		$[41] = t26;
		$[42] = t27;
	} else {
		t26 = $[41];
		t27 = $[42];
	}
	let t28;
	if ($[43] !== hasNextPage) {
		t28 = hasNextPage ? /* @__PURE__ */ jsx(ChevronRightIcon, {}) : null;
		$[43] = hasNextPage;
		$[44] = t28;
	} else t28 = $[44];
	let t29;
	if ($[45] !== t23 || $[46] !== t24 || $[47] !== t25 || $[48] !== t28) {
		t29 = /* @__PURE__ */ jsx(Step, { children: /* @__PURE__ */ jsxs(Button, {
			className: t22,
			type: "button",
			"data-has-page": t23,
			"aria-disabled": t24,
			onClick: t25,
			children: [
				t26,
				t27,
				t28
			]
		}) });
		$[45] = t23;
		$[46] = t24;
		$[47] = t25;
		$[48] = t28;
		$[49] = t29;
	} else t29 = $[49];
	let t30;
	if ($[50] !== t12 || $[51] !== t20 || $[52] !== t21 || $[53] !== t29) {
		t30 = /* @__PURE__ */ jsxs("ol", {
			className: t10,
			"data-hidden-viewport-ranges": t12,
			children: [
				t20,
				t21,
				t29
			]
		});
		$[50] = t12;
		$[51] = t20;
		$[52] = t21;
		$[53] = t29;
		$[54] = t30;
	} else t30 = $[54];
	let t31;
	if ($[55] !== id || $[56] !== label || $[57] !== t30 || $[58] !== t9) {
		t31 = /* @__PURE__ */ jsxs("nav", {
			"aria-label": label,
			className: t8,
			id,
			children: [t9, t30]
		});
		$[55] = id;
		$[56] = label;
		$[57] = t30;
		$[58] = t9;
		$[59] = t31;
	} else t31 = $[59];
	return t31;
}
function Range(t0) {
	const $ = c(14);
	const { pageStart, pageEnd, totalCount } = t0;
	const start = pageStart + 1;
	const end = pageEnd;
	let t1;
	if ($[0] !== end || $[1] !== start || $[2] !== totalCount) {
		t1 = /* @__PURE__ */ jsx(VisuallyHidden, { children: /* @__PURE__ */ jsxs(AriaStatus, { children: [
			"Showing ",
			start,
			" through ",
			end,
			" of ",
			totalCount
		] }) });
		$[0] = end;
		$[1] = start;
		$[2] = totalCount;
		$[3] = t1;
	} else t1 = $[3];
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = clsx("TablePaginationRange", classes.TablePaginationRange);
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	let t4;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ jsx(VisuallyHidden, { children: "\xA0through\xA0" });
		t4 = /* @__PURE__ */ jsx("span", {
			"aria-hidden": "true",
			children: "‒"
		});
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	let t5;
	if ($[7] !== end || $[8] !== start || $[9] !== totalCount) {
		t5 = /* @__PURE__ */ jsxs("p", {
			className: t2,
			children: [
				start,
				t3,
				t4,
				end,
				" of ",
				totalCount
			]
		});
		$[7] = end;
		$[8] = start;
		$[9] = totalCount;
		$[10] = t5;
	} else t5 = $[10];
	let t6;
	if ($[11] !== t1 || $[12] !== t5) {
		t6 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t1, t5] });
		$[11] = t1;
		$[12] = t5;
		$[13] = t6;
	} else t6 = $[13];
	return t6;
}
function TruncationStep() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsx("li", {
			"aria-hidden": "true",
			className: clsx("TablePaginationTruncationStep", classes.TablePaginationTruncationStep),
			children: "…"
		});
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
function Step(t0) {
	const $ = c(3);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TablePaginationStep", classes.TablePaginationStep);
		$[0] = t1;
	} else t1 = $[0];
	let t2;
	if ($[1] !== children) {
		t2 = /* @__PURE__ */ jsx("li", {
			className: t1,
			children
		});
		$[1] = children;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function Page(t0) {
	const $ = c(7);
	const { active, children, onClick } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx("TablePaginationPage", classes.TablePaginationPage);
		$[0] = t1;
	} else t1 = $[0];
	const t2 = active ? true : void 0;
	const t3 = active ? true : void 0;
	let t4;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = /* @__PURE__ */ jsx(VisuallyHidden, { children: "Page\xA0" });
		$[1] = t4;
	} else t4 = $[1];
	let t5;
	if ($[2] !== children || $[3] !== onClick || $[4] !== t2 || $[5] !== t3) {
		t5 = /* @__PURE__ */ jsxs(Button, {
			className: t1,
			type: "button",
			"data-active": t2,
			"aria-current": t3,
			onClick,
			children: [t4, children]
		});
		$[2] = children;
		$[3] = onClick;
		$[4] = t2;
		$[5] = t3;
		$[6] = t5;
	} else t5 = $[6];
	return t5;
}
function usePagination(config) {
	const $ = c(24);
	const { defaultPageIndex, onChange, pageSize, totalCount } = config;
	const pageCount = Math.ceil(totalCount / pageSize);
	let t0;
	if ($[0] !== defaultPageIndex || $[1] !== pageCount) {
		t0 = () => {
			if (defaultPageIndex !== void 0) {
				if (defaultPageIndex >= 0 && defaultPageIndex < pageCount) return defaultPageIndex;
			}
			return 0;
		};
		$[0] = defaultPageIndex;
		$[1] = pageCount;
		$[2] = t0;
	} else t0 = $[2];
	const [defaultIndex, setDefaultIndex] = useState(t0);
	const [pageIndex, setPageIndex] = useState(defaultIndex);
	if (defaultPageIndex !== void 0 && defaultPageIndex >= 0 && defaultPageIndex < pageCount && defaultIndex !== defaultPageIndex) {
		setDefaultIndex(defaultPageIndex);
		setPageIndex(defaultPageIndex);
		onChange === null || onChange === void 0 || onChange({ pageIndex: defaultPageIndex });
	}
	const pageStart = pageIndex * pageSize;
	const pageEnd = Math.min((pageIndex + 1) * pageSize, totalCount);
	const hasNextPage = pageIndex + 1 < pageCount;
	const hasPreviousPage = pageIndex > 0;
	let t1;
	if ($[3] !== onChange || $[4] !== pageIndex) {
		t1 = function selectPage(newPageIndex) {
			if (pageIndex !== newPageIndex) {
				setPageIndex(newPageIndex);
				onChange === null || onChange === void 0 || onChange({ pageIndex: newPageIndex });
			}
		};
		$[3] = onChange;
		$[4] = pageIndex;
		$[5] = t1;
	} else t1 = $[5];
	const selectPage = t1;
	let t2;
	if ($[6] !== hasPreviousPage || $[7] !== pageIndex || $[8] !== selectPage) {
		t2 = function selectPreviousPage() {
			if (hasPreviousPage) selectPage(pageIndex - 1);
		};
		$[6] = hasPreviousPage;
		$[7] = pageIndex;
		$[8] = selectPage;
		$[9] = t2;
	} else t2 = $[9];
	const selectPreviousPage = t2;
	let t3;
	if ($[10] !== hasNextPage || $[11] !== pageIndex || $[12] !== selectPage) {
		t3 = function selectNextPage() {
			if (hasNextPage) selectPage(pageIndex + 1);
		};
		$[10] = hasNextPage;
		$[11] = pageIndex;
		$[12] = selectPage;
		$[13] = t3;
	} else t3 = $[13];
	const selectNextPage = t3;
	let t4;
	if ($[14] !== hasNextPage || $[15] !== hasPreviousPage || $[16] !== pageCount || $[17] !== pageEnd || $[18] !== pageIndex || $[19] !== pageStart || $[20] !== selectNextPage || $[21] !== selectPage || $[22] !== selectPreviousPage) {
		t4 = {
			pageIndex,
			pageStart,
			pageEnd,
			pageCount,
			hasNextPage,
			hasPreviousPage,
			selectPage,
			selectPreviousPage,
			selectNextPage
		};
		$[14] = hasNextPage;
		$[15] = hasPreviousPage;
		$[16] = pageCount;
		$[17] = pageEnd;
		$[18] = pageIndex;
		$[19] = pageStart;
		$[20] = selectNextPage;
		$[21] = selectPage;
		$[22] = selectPreviousPage;
		$[23] = t4;
	} else t4 = $[23];
	return t4;
}
var Table = Object.assign(Table$1, {
	Container: TableContainer,
	Title: TableTitle,
	Subtitle: TableSubtitle,
	Actions: TableActions,
	Divider: TableDivider,
	Skeleton: TableSkeleton,
	Head: TableHead,
	Body: TableBody,
	Header: TableHeader,
	Row: TableRow,
	Cell: TableCell,
	CellPlaceholder: TableCellPlaceholder,
	Pagination,
	ErrorDialog
});
function getSessionStatusIcon(status, isCLI = false) {
	if (isCLI) return /* @__PURE__ */ jsx(TerminalIcon, {
		className: "fgColor-attention",
		"aria-label": "CLI session running"
	});
	switch (status) {
		case SessionState.InProgress: return /* @__PURE__ */ jsx(InProgressSpinner, {});
		case SessionState.Completed: return /* @__PURE__ */ jsx(CheckIcon, {
			className: "fgColor-success",
			"aria-label": "Completed"
		});
		case SessionState.Failed:
		case SessionState.TimedOut: return /* @__PURE__ */ jsx(XCircleFillIcon, {
			className: "fgColor-danger",
			"aria-label": "Failed"
		});
		case SessionState.Idle: return /* @__PURE__ */ jsx(DotFillIcon, {
			className: "fgColor-attention",
			"aria-label": "Idle"
		});
		case SessionState.WaitingForUser: return /* @__PURE__ */ jsx(QuestionIcon, {
			className: "fgColor-attention",
			"aria-label": "Waiting for user"
		});
		case SessionState.Cancelled: return /* @__PURE__ */ jsx(SquareFillIcon, {
			className: "fgColor-muted",
			"aria-label": "Cancelled"
		});
		case SessionState.Queued: return /* @__PURE__ */ jsx(ClockIcon, {
			className: "fgColor-attention",
			"aria-label": "Queued"
		});
		default: return null;
	}
}
function InProgressSpinner() {
	return /* @__PURE__ */ jsxs("svg", {
		role: "img",
		"aria-label": "Currently running",
		width: "16px",
		height: "16px",
		fill: "none",
		viewBox: "0 0 16 16",
		className: "anim-rotate",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			/* @__PURE__ */ jsx("path", {
				fill: "none",
				stroke: "var(--color-fg-attention, #bf8700)",
				strokeWidth: "2",
				d: "M3.05 3.05a7 7 0 1 1 9.9 9.9 7 7 0 0 1-9.9-9.9Z",
				opacity: ".5"
			}),
			/* @__PURE__ */ jsx("path", {
				fill: "var(--color-fg-attention, #bf8700)",
				fillRule: "evenodd",
				d: "M8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z",
				clipRule: "evenodd"
			}),
			/* @__PURE__ */ jsx("path", {
				fill: "var(--color-fg-attention, #bf8700)",
				d: "M14 8a6 6 0 0 0-6-6V0a8 8 0 0 1 8 8h-2Z"
			})
		]
	});
}
InProgressSpinner.displayName = "InProgressSpinner";
export { TableCell as a, TableRow as c, useTable as d, TableBody as i, TableSortHeader as l, Table as n, TableHead as o, Table$1 as r, TableHeader as s, InProgressSpinner as t, getSessionStatusIcon as u };
