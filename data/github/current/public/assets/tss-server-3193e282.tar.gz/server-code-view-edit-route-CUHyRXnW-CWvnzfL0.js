import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewEditRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewEditRoute", {
	path: "/:owner/:repo/edit/:branch/*",
	queries: [mainQuery({
		navigationBehavior: "network-first",
		encodeFetchPath: true
	})]
});
export { codeViewEditRoute as t };
