import { n as isDev } from "./server-env-CmF5Q86i-CMsKyIar.js";
/**
* TSS Server configuration
* Centralized configuration for environment-specific URLs and settings.
*
* URL Resolution Priority:
* 1. Environment variable override (if set)
* 2. Development URL (if isDev())
* 3. Production URL (default)
*/
/**
* ServerConfig centralizes all URL and configuration logic.
* It handles environment detection and env variable fallbacks,
* providing a consistent interface for accessing configuration values.
*/
var ServerConfig = class {
	/**
	* Resolves a URL based on environment variable override and dev/prod defaults.
	*/
	#resolveUrl(config) {
		return process.env[config.envVar] || (isDev() ? config.development : config.production);
	}
	/** Browser stats API endpoint for sending performance statistics */
	get browserStatsUrl() {
		return this.#resolveUrl({
			envVar: "BROWSER_STATS_URL",
			development: "http://api.github.localhost/_private/browser/stats",
			production: "https://api.github.com/_private/browser/stats"
		});
	}
	/** Browser errors API endpoint for sending client error reports */
	get browserErrorsUrl() {
		return this.#resolveUrl({
			envVar: "BROWSER_ERRORS_URL",
			development: "http://api.github.localhost/_private/browser/errors",
			production: "https://api.github.com/_private/browser/errors"
		});
	}
	/** Hydro analytics collector endpoint */
	get hydroCollectorUrl() {
		return this.#resolveUrl({
			envVar: "HYDRO_COLLECTOR_URL",
			development: "http://collector.github.localhost/github/collect",
			production: "https://collector.github.com/github/collect"
		});
	}
	/** Asset host for static assets (CSS, JS, images) */
	get assetHost() {
		return this.#resolveUrl({
			envVar: "ASSET_HOST",
			development: "https://github.githubassets.com",
			production: "https://github.githubassets.com"
		});
	}
	/** Avatars host for user profile images */
	get avatarsHost() {
		return this.#resolveUrl({
			envVar: "AVATARS_HOST",
			development: "http://alambic.github.localhost",
			production: "https://githubusercontent.com"
		});
	}
	/** Uploads host for user-uploaded content */
	get uploadsHost() {
		return this.#resolveUrl({
			envVar: "UPLOADS_HOST",
			development: "https://*.githubusercontent.com",
			production: "https://*.githubusercontent.com"
		});
	}
	/** API host for GitHub API requests */
	get apiHost() {
		return this.#resolveUrl({
			envVar: "API_HOST",
			development: "http://api.github.localhost",
			production: "https://api.github.com"
		});
	}
	/** Collector host for analytics and metrics collection */
	get collectHost() {
		return this.#resolveUrl({
			envVar: "COLLECT_HOST",
			development: "http://collector.github.localhost",
			production: "https://collector.github.com"
		});
	}
	/** Alive host for WebSocket connections */
	get aliveHost() {
		return this.#resolveUrl({
			envVar: "ALIVE_HOST",
			development: "ws://alive.github.localhost",
			production: "wss://alive.github.com"
		});
	}
	get hostName() {
		return this.#resolveUrl({
			envVar: "HOST_NAME",
			development: "github.localhost",
			production: "github.com"
		});
	}
	/** GitHub domain for form actions */
	get githubDomain() {
		return this.#resolveUrl({
			envVar: "GITHUB_DOMAIN",
			development: "http://github.localhost",
			production: "https://github.com"
		});
	}
	/** Viewscreen host used for CSP frame-src allowlisting */
	get viewscreenHost() {
		return this.#resolveUrl({
			envVar: "VIEWSCREEN_HOST",
			development: "http://viewscreen.githubusercontent.localhost:9494",
			production: "viewscreen.githubusercontent.com"
		});
	}
	/** Notebooks host used for CSP frame-src allowlisting */
	get notebooksHost() {
		return this.#resolveUrl({
			envVar: "NOTEBOOKS_HOST",
			development: "http://notebooks.githubusercontent.localhost:8888",
			production: "notebooks.githubusercontent.com"
		});
	}
	/** CSP report URI for Content Security Policy violation reporting */
	get cspReportUri() {
		return process.env.CSP_REPORT_URI;
	}
};
/** Singleton instance of ServerConfig */
var serverConfig = new ServerConfig();
export { serverConfig as t };
