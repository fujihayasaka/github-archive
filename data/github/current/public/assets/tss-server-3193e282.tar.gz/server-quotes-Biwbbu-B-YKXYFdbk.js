function indexInList(li) {
	const parent = li.parentNode;
	if (parent === null || !(parent instanceof HTMLElement)) throw new Error();
	let start = 0;
	if (parent instanceof HTMLOListElement && parent.start !== 1) start = parent.start - 1;
	const ref = parent.children;
	for (let i = 0; i < ref.length; ++i) if (ref[i] === li) return start + i;
	return start;
}
function skipNode(node) {
	if (node instanceof HTMLAnchorElement && node.childNodes.length === 1) {
		const first = node.childNodes[0];
		if (first instanceof HTMLImageElement) return first.src === node.href;
	}
	return false;
}
function hasContent(node) {
	return node.nodeName === "IMG" || node.firstChild != null;
}
function isCheckbox(node) {
	return node.nodeName === "INPUT" && node instanceof HTMLInputElement && node.type === "checkbox";
}
var listIndexOffset = 0;
function nestedListExclusive(li) {
	const first = li.childNodes[0];
	const second = li.childNodes[1];
	if (first && li.childNodes.length < 3) return (first.nodeName === "OL" || first.nodeName === "UL") && (!second || second.nodeType === Node.TEXT_NODE && !(second.textContent || "").trim());
	return false;
}
function escapeAttribute(text) {
	return text.replace(/&/g, "&amp;").replace(/'/g, "&apos;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var filters = {
	INPUT(el) {
		if (el instanceof HTMLInputElement && el.checked) return "[x] ";
		return "[ ] ";
	},
	CODE(el) {
		const text = el.textContent || "";
		if (el.parentNode && el.parentNode.nodeName === "PRE") {
			el.textContent = `\`\`\`\n${text.replace(/\n+$/, "")}\n\`\`\`\n\n`;
			return el;
		}
		if (text.indexOf("`") >= 0) return `\`\` ${text} \`\``;
		return `\`${text}\``;
	},
	P(el) {
		const pElement = document.createElement("p");
		pElement.textContent = (el.textContent || "").replace(/<(\/?)(pre|strong|weak|em)>/g, "\\<$1$2\\>");
		return pElement;
	},
	STRONG(el) {
		return `**${el.textContent || ""}**`;
	},
	EM(el) {
		return `_${el.textContent || ""}_`;
	},
	DEL(el) {
		return `~${el.textContent || ""}~`;
	},
	BLOCKQUOTE(el) {
		const text = (el.textContent || "").trim().replace(/^/gm, "> ");
		const pre = document.createElement("pre");
		pre.textContent = `${text}\n\n`;
		return pre;
	},
	A(el) {
		const text = el.textContent || "";
		const href = el.getAttribute("href");
		if (/^https?:/.test(text) && text === href) return text;
		else if (href) return `[${text}](${href})`;
		else return text;
	},
	IMG(el) {
		const alt = el.getAttribute("alt") || "";
		const src = el.getAttribute("src");
		if (!src) throw new Error();
		const widthAttr = el.hasAttribute("width") ? ` width="${escapeAttribute(el.getAttribute("width") || "")}"` : "";
		const heightAttr = el.hasAttribute("height") ? ` height="${escapeAttribute(el.getAttribute("height") || "")}"` : "";
		if (widthAttr || heightAttr) return `<img alt="${escapeAttribute(alt)}"${widthAttr}${heightAttr} src="${escapeAttribute(src)}">`;
		else return `![${alt}](${src})`;
	},
	LI(el) {
		const list = el.parentNode;
		if (!list) throw new Error();
		let bullet = "";
		if (!nestedListExclusive(el)) if (list.nodeName === "OL") if (listIndexOffset > 0 && !list.previousSibling) bullet = `${indexInList(el) + listIndexOffset + 1}\\. `;
		else bullet = `${indexInList(el) + 1}. `;
		else bullet = "* ";
		const indent = bullet.replace(/\S/g, " ");
		const text = (el.textContent || "").trim().replace(/^/gm, indent);
		const pre = document.createElement("pre");
		pre.textContent = text.replace(indent, bullet);
		return pre;
	},
	OL(el) {
		const li = document.createElement("li");
		li.appendChild(document.createElement("br"));
		el.append(li);
		return el;
	},
	H1(el) {
		const level = parseInt(el.nodeName.slice(1));
		el.prepend(`${Array(level + 1).join("#")} `);
		return el;
	},
	UL(el) {
		return el;
	}
};
filters.UL = filters.OL;
for (let level = 2; level <= 6; ++level) filters[`H${level}`] = filters.H1;
function insertMarkdownSyntax(root) {
	const nodeIterator = document.createNodeIterator(root, NodeFilter.SHOW_ELEMENT, { acceptNode(node) {
		if (node.nodeName in filters && !skipNode(node) && (hasContent(node) || isCheckbox(node))) return NodeFilter.FILTER_ACCEPT;
		return NodeFilter.FILTER_SKIP;
	} });
	const results = [];
	let node = nodeIterator.nextNode();
	while (node) {
		if (node instanceof HTMLElement) results.push(node);
		node = nodeIterator.nextNode();
	}
	results.reverse();
	for (const el of results) el.replaceWith(filters[el.nodeName](el));
}
function extractFragment(range, selector) {
	const startNode = range.startContainer;
	if (!startNode || !startNode.parentNode || !(startNode.parentNode instanceof HTMLElement)) throw new Error("the range must start within an HTMLElement");
	const parent = startNode.parentNode;
	let fragment = range.cloneContents();
	if (selector) {
		const contentElement = fragment.querySelector(selector);
		if (contentElement) {
			fragment = document.createDocumentFragment();
			fragment.appendChild(contentElement);
		}
	}
	listIndexOffset = 0;
	const li = parent.closest("li");
	if (parent.closest("pre")) {
		const pre = document.createElement("pre");
		pre.appendChild(fragment);
		fragment = document.createDocumentFragment();
		fragment.appendChild(pre);
	} else if (li && li.parentNode) {
		if (li.parentNode.nodeName === "OL") listIndexOffset = indexInList(li);
		if (!fragment.querySelector("li")) {
			const item = document.createElement("li");
			if (!li.parentNode) throw new Error();
			const list = document.createElement(li.parentNode.nodeName);
			item.appendChild(fragment);
			list.appendChild(item);
			fragment = document.createDocumentFragment();
			fragment.appendChild(list);
		}
	}
	return fragment;
}
var Quote = class {
	constructor() {
		this.selection = window.getSelection();
		this.processSelectionText = (str) => str;
	}
	closest(selector) {
		const startContainer = this.range.startContainer;
		const startElement = startContainer instanceof Element ? startContainer : startContainer.parentElement;
		if (!startElement) return null;
		return startElement.closest(selector);
	}
	get active() {
		var _a;
		return (((_a = this.selection) === null || _a === void 0 ? void 0 : _a.rangeCount) || 0) > 0;
	}
	get range() {
		var _a;
		return ((_a = this.selection) === null || _a === void 0 ? void 0 : _a.rangeCount) ? this.selection.getRangeAt(0) : new Range();
	}
	set range(range) {
		var _a, _b;
		(_a = this.selection) === null || _a === void 0 || _a.removeAllRanges();
		(_b = this.selection) === null || _b === void 0 || _b.addRange(range);
	}
	set processSelectionTextFn(fn) {
		this.processSelectionText = fn;
	}
	get selectionText() {
		var _a;
		return this.processSelectionText(((_a = this.selection) === null || _a === void 0 ? void 0 : _a.toString().trim()) || "");
	}
	get quotedText() {
		return `> ${this.selectionText.replace(/\n/g, "\n> ")}\n\n`;
	}
	select(element) {
		if (this.selection) {
			this.selection.removeAllRanges();
			this.selection.selectAllChildren(element);
		}
	}
	insert(field) {
		if (field.value) field.value = `${field.value}\n\n${this.quotedText}`;
		else field.value = this.quotedText;
		field.dispatchEvent(new CustomEvent("change", {
			bubbles: true,
			cancelable: false
		}));
		field.focus();
		field.selectionStart = field.value.length;
		field.scrollTop = field.scrollHeight;
	}
};
var MarkdownQuote = class extends Quote {
	constructor(scopeSelector = "", callback) {
		super();
		this.scopeSelector = scopeSelector;
		this.callback = callback;
	}
	get selectionText() {
		var _a, _b;
		if (!this.selection) return "";
		const fragment = extractFragment(this.range, (_a = this.scopeSelector) !== null && _a !== void 0 ? _a : "");
		(_b = this.callback) === null || _b === void 0 || _b.call(this, fragment);
		insertMarkdownSyntax(fragment);
		const body = document.body;
		if (!body) return "";
		const div = document.createElement("div");
		div.appendChild(fragment);
		div.style.cssText = "position:absolute;left:-9999px;";
		body.appendChild(div);
		let selectionText = "";
		try {
			const range = document.createRange();
			range.selectNodeContents(div);
			this.selection.removeAllRanges();
			this.selection.addRange(range);
			selectionText = this.selection.toString();
			this.selection.removeAllRanges();
			range.detach();
		} finally {
			body.removeChild(div);
		}
		return this.processSelectionText(selectionText.trim());
	}
};
var CLASS_NAMES = {
	issueComment: "react-issue-comment",
	commentsContainer: "react-comments-container",
	markdownBody: "markdown-body",
	issueBody: "react-issue-body"
};
var IDS = { issueCommentComposer: "react-issue-comment-composer" };
function withIDSelector(id) {
	return `#${id}`;
}
function getMostRelevantComposer() {
	const commentComposerInsideSidePanel = document.querySelector(`${withClassSelector(CLASS_NAMES.commentsContainer)} ${withIDSelector(IDS.issueCommentComposer)}[data-inside-side-panel=true]`);
	if (commentComposerInsideSidePanel) return commentComposerInsideSidePanel;
	return document.querySelector(withIDSelector(IDS.issueCommentComposer));
}
function withClassSelector(className) {
	return `.${className}`;
}
var ERRORS = {
	couldNotComment: "There was a problem saving your comment. Please try again.",
	couldNotCloseIssue: "Could not close issue",
	couldNotDeleteComment: "Could not delete this comment",
	couldNotEditComment: "Could not edit issue comment",
	couldNotEditCommentStale: "The content you are editing has changed. Please copy your edits and refresh the page.",
	couldNotReact: "Could not add reaction. Please try again.",
	couldNotSubscribe: "Could not subscribe. Please try again.",
	couldNotUnsubscribe: "Could not unsubscribe. Please try again."
};
var LABELS = {
	canNotComment: (subjectType) => subjectType ? `You do not have permissions to comment on this ${subjectType}.` : "You do not have permissions to comment.",
	confirmations: {
		deleteCommentTitle: "Delete comment",
		deleteCommentContent: "Are you sure you'd like to delete this comment?",
		deleteCommentConfirmButtonContent: "Delete"
	},
	lowQualityCommentWarning: {
		title: "Consider using reactions instead",
		message: "To help keep issues focused, consider reacting or adding more details to your comment.",
		likeAction: "Like issue instead 👍",
		reactedTitle: "Success",
		reactedMessage: "Added a 👍 to this issue.",
		likedAndSubscribedMessage: "Added a 👍 to this issue and subscribed to updates.",
		subscribeAction: "Subscribe",
		subscribedTitle: "Subscribed",
		subscribedMessage: "Subscribed to updates.",
		unsubscribeAction: "Unsubscribe",
		unsubscribedTitle: "Unsubscribed",
		unsubscribedMessage: "Unsubscribed from updates.",
		noActionsMessage: "To help keep issues focused, consider adding more details to your comment."
	},
	hiddenComment: "Hidden comment",
	hiddenCommentWithReason: "Hidden as",
	issueLockedToCollaborators: "This conversation has been locked and limited to collaborators.",
	repoArchived: "This repository has been archived.",
	repoLockedForMigration: "This repository is being migrated.",
	sentViaEmail: "via email",
	commentAuthor: "Author",
	spammyBadge: "Spammy",
	spammyBadgeTooltip: "This user is marked as spammy. Their comments will only show in staff mode.",
	sponsorBadge: "Sponsor",
	newComment: "new Comment",
	newCommentPlaceholder: "Use Markdown to format your comment",
	commentSubjectAuthor: (viewerDidAuthor, subjectType) => `${viewerDidAuthor ? "You are the" : "This user is the"} author${subjectType ? ` of this ${subjectType}` : ""}`,
	sponsor: (owner, since) => `${owner}'s sponsor since ${since}`,
	noDescriptionProvided: "No description provided.",
	staleCommentErrorPrefix: "GraphQL error: STALE_DATA",
	issueConvertedToDiscussion: "Commenting has been disabled because this issue was converted to a",
	authorLabel: (isBot, isCopilot) => `${isBot ? isCopilot ? "AI" : "bot" : "mannequin"}`
};
var TEST_IDS = {
	avatarLink: "avatar-link",
	avatarName: "avatar-name",
	commentAuthorAssociation: "comment-author-association",
	commentSubjectAuthor: "comment-subject-author",
	spammyLabel: "spammy-label",
	sponsorLabel: "sponsor-label",
	commentHeader: "comment-header",
	commentHeaderLeftSideItems: "comment-header-left-side-items",
	commentHeaderRightSideItems: "comment-header-right-side-items",
	commentHeaderHamburger: "comment-header-hamburger",
	commentHeaderHamburgerOpen: "comment-header-hamburger-open",
	commentMenuRefComment: "comment-menu-ref-comment",
	commentViewerOuterBox: (id) => {
		return id ? `comment-viewer-outer-box-${id}` : "comment-viewer-outer-box";
	},
	commentComposer: "comment-composer",
	markdownBody: "markdown-body",
	commentBox: (postFix = "") => `markdown-editor-${postFix}`,
	readonlyCommentBox: (postFix = "") => `readonly-markdown-editor-${postFix}`,
	commentSkeleton: "comment-skeleton"
};
function getQuotedText(text) {
	if (!text) return text;
	const lines = text.split("\n");
	let quotes = "";
	for (const line of lines) quotes = quotes.concat(`> ${line}\n`);
	return quotes;
}
var replaceCommentAssets = (commentBodyContent) => (selection) => {
	const links = commentBodyContent.matchAll(/(!\[[^[]+?\]\([^()]+\/)([\w\d-]+)(.+)/g);
	for (const link of links) {
		const beforeUuid = link[1];
		const uuid = link[2];
		const afterUuid = link[3];
		if (!beforeUuid || !uuid || !afterUuid) continue;
		const url = `${beforeUuid}${uuid}${afterUuid.split(")")[0]})`;
		const selectionMatches = selection.split(uuid);
		if (selectionMatches.length < 2) continue;
		const toReplace = `${selectionMatches[0]?.match(/!\[[^[]+$/)}${uuid}${selectionMatches[1]?.split(")")[0]})`;
		selection = selection.replaceAll(toReplace, url);
	}
	return selection;
};
var isElementHidden = (element) => {
	return element.style.display === "none" || element.style.visibility === "hidden" || element.ariaHidden === "true";
};
var removeHiddenElements = (fragment) => {
	const nodeIterator = document.createNodeIterator(fragment, NodeFilter.SHOW_ELEMENT, { acceptNode() {
		return NodeFilter.FILTER_ACCEPT;
	} });
	let node = nodeIterator.nextNode();
	while (node) {
		if (node instanceof HTMLElement && isElementHidden(node)) node.remove();
		node = nodeIterator.nextNode();
	}
};
function selectQuoteFromComment(comment, selection, commentBodyContent) {
	if (!comment) return void 0;
	const commentBody = comment.querySelector(withClassSelector(CLASS_NAMES.markdownBody));
	const quote = new MarkdownQuote("", removeHiddenElements);
	if (selection && commentBody.contains(selection.anchorNode) && commentBody.contains(selection.range.startContainer) && commentBody.contains(selection.range.endContainer) && !selection.range.collapsed && selection.range.toString().trim() !== "") quote.range = selection.range;
	else quote.select(commentBody);
	if (commentBodyContent) quote.processSelectionTextFn = replaceCommentAssets(commentBodyContent);
	const commentComposer = getMostRelevantComposer();
	if (commentComposer) {
		const commentComposerTextArea = commentComposer?.querySelector("textarea");
		const commentComposerButton = commentComposer?.querySelector("button");
		if (commentComposerTextArea) {
			quote.insert(commentComposerTextArea);
			return commentComposerTextArea.value;
		} else if (commentComposerButton) return quote.quotedText;
	}
}
export { TEST_IDS as a, withClassSelector as c, LABELS as i, ERRORS as n, getQuotedText as o, IDS as r, selectQuoteFromComment as s, CLASS_NAMES as t };
