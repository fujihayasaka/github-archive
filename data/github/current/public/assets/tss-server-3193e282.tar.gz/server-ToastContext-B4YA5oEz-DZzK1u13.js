import { Wi as useSafeTimeout } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as noop } from "./server-noop-Cx1vkacJ-BvDXUo6b.js";
import { createContext, use, useCallback, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var TOAST_SHOW_TIME = 5e3;
var ToastContext = createContext({
	addToast: noop,
	addPersistedToast: noop,
	clearPersistedToast: noop
});
ToastContext.displayName = "ToastContext";
var InternalToastsContext = createContext({
	toasts: [],
	persistedToast: null
});
InternalToastsContext.displayName = "InternalToastsContext";
function ToastContextProvider(t0) {
	const $ = c(15);
	const { children } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [toasts, setToasts] = useState(t1);
	const [persistedToast, setPersistedToast] = useState(null);
	const { safeSetTimeout } = useSafeTimeout();
	let t2;
	if ($[1] !== safeSetTimeout || $[2] !== toasts) {
		t2 = function(toast) {
			setToasts([...toasts, toast]);
			safeSetTimeout(() => setToasts(toasts.slice(1)), TOAST_SHOW_TIME);
		};
		$[1] = safeSetTimeout;
		$[2] = toasts;
		$[3] = t2;
	} else t2 = $[3];
	const addToast = t2;
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = function(toast_0) {
			setPersistedToast(toast_0);
		};
		$[4] = t3;
	} else t3 = $[4];
	const addPersistedToast = t3;
	let t4;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = function() {
			setPersistedToast(null);
		};
		$[5] = t4;
	} else t4 = $[5];
	const clearPersistedToast = t4;
	let t5;
	if ($[6] !== addToast) {
		t5 = {
			addToast,
			addPersistedToast,
			clearPersistedToast
		};
		$[6] = addToast;
		$[7] = t5;
	} else t5 = $[7];
	const contextValue = t5;
	let t6;
	if ($[8] !== persistedToast || $[9] !== toasts) {
		t6 = {
			toasts,
			persistedToast
		};
		$[8] = persistedToast;
		$[9] = toasts;
		$[10] = t6;
	} else t6 = $[10];
	const internalToastsContext = t6;
	let t7;
	if ($[11] !== children || $[12] !== contextValue || $[13] !== internalToastsContext) {
		t7 = jsx(ToastContext, {
			value: contextValue,
			children: jsx(InternalToastsContext, {
				value: internalToastsContext,
				children
			})
		});
		$[11] = children;
		$[12] = contextValue;
		$[13] = internalToastsContext;
		$[14] = t7;
	} else t7 = $[14];
	return t7;
}
ToastContextProvider.displayName = "ToastContextProvider";
function useToastContext() {
	return use(ToastContext);
}
export { useToastContext as i, TOAST_SHOW_TIME as n, ToastContextProvider as r, InternalToastsContext as t };
