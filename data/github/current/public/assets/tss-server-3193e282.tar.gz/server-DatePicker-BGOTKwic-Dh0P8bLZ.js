import { i as ButtonComponent, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, I as ChevronLeftIcon, L as ChevronRightIcon, Mi as XIcon, O as CheckIcon, T as CalendarIcon, an as IconButton, mi as TrashIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as useResizeObserver, t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { c as useFormControlForwardedProps } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as ConfirmationDialog } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { n as CommandButton, o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { createContext, use, useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { flushSync } from "react-dom";
import { c } from "react/compiler-runtime";
import { add, addBusinessDays, addDays, addMonths, addWeeks, addYears, differenceInDays, eachDayOfInterval, endOfWeek, format, getDaysInMonth, isAfter, isBefore, isEqual, isFriday, isMonday, isSameMonth, isSaturday, isSunday, isToday, isValid, isWeekend, lastDayOfMonth, nextFriday, nextMonday, nextSaturday, parse, previousFriday, previousMonday, previousSunday, setDate, startOfMonth, startOfWeek, sub, subBusinessDays, subDays, subMonths, subWeeks, subYears } from "date-fns";
import { format as format$1 } from "date-fns/format";
import chunk from "lodash-es/chunk.js";
function isSingleSelection(selection) {
	return selection === null || selection instanceof Date;
}
function isRangeSelection(selection) {
	return selection === null || !!selection.from;
}
function isCompleteRangeSelection(selection) {
	return isRangeSelection(selection) && (selection === null || selection.to !== null);
}
var sanitizeDate = (date) => new Date(new Date(date).toDateString());
var sanitizeSelection = (selection) => {
	if (selection instanceof Date) return sanitizeDate(selection);
	else if (selection && isRangeSelection(selection)) return {
		from: sanitizeDate(selection.from),
		to: selection.to && sanitizeDate(selection.to)
	};
	return null;
};
var getFocusDate = (selection, activeRangeEnd = null) => {
	if (!selection) return sanitizeDate(/* @__PURE__ */ new Date());
	if (selection instanceof Date) return sanitizeDate(selection);
	else if (isRangeSelection(selection)) return activeRangeEnd === "to" && selection.to ? sanitizeDate(selection.to) : sanitizeDate(selection.from);
	else return null;
};
/**
* Clamp the date to the given range. Unlike date-fns `clamp`, this supports optional
* start and end dates.
*/
var clamp = (date, { minDate: min, maxDate: max }) => min && isBefore(date, min) ? min : max && isAfter(date, max) ? max : date;
var closestWeekday = (date, direction = "auto") => {
	if (!isWeekend(date)) return date;
	switch (direction) {
		case "forward": return nextMonday(date);
		case "backward": return previousFriday(date);
		case "auto": return isSunday(date) ? nextMonday(date) : previousFriday(date);
	}
};
var nextValidDay = (date, disableWeekends) => disableWeekends ? closestWeekday(date, "forward") : date;
var prevValidDay = (date, disableWeekends) => disableWeekends ? closestWeekday(date, "backward") : date;
var closestValidDay = (date, disableWeekends) => disableWeekends ? closestWeekday(date, "auto") : date;
var addValidDays = (date, days, disableWeekends) => disableWeekends ? addBusinessDays(date, days) : addDays(date, days);
var subValidDays = (date, days, disableWeekends) => disableWeekends ? subBusinessDays(date, days) : subDays(date, days);
/** Clamp the day to the given range while also forcing the result to fall on a weekday if weekends are disabled. */
var clampValid = (date, { minDate, maxDate }, disableWeekends) => {
	return closestValidDay(clamp(date, {
		minDate: minDate && nextValidDay(minDate, disableWeekends),
		maxDate: maxDate && prevValidDay(maxDate, disableWeekends)
	}), disableWeekends);
};
var maxTo = (validFrom, { maxRangeSize }, disableWeekends) => maxRangeSize !== void 0 ? addValidDays(validFrom, maxRangeSize - 1, disableWeekends) : void 0;
var minFrom = (validTo, { maxRangeSize }, disableWeekends) => maxRangeSize !== void 0 ? subValidDays(validTo, maxRangeSize - 1, disableWeekends) : void 0;
var minTo = (validFrom, { minRangeSize }, disableWeekends) => minRangeSize !== void 0 ? addValidDays(validFrom, minRangeSize - 1, disableWeekends) : void 0;
var maxFrom = (validTo, { minRangeSize }, disableWeekends) => minRangeSize !== void 0 ? subValidDays(validTo, minRangeSize - 1, disableWeekends) : void 0;
/**
* Ensure that the range is 'forward' by making the 'to' date fall after the 'from' date. If the range is flipped, also
* flips the active range end.
*/
var ensureForwardRange = (range, adjustableRangeEnd) => range.to && isAfter(range.from, range.to) ? [{
	...range,
	from: range.to,
	to: range.from
}, adjustableRangeEnd === "from" ? "to" : "from"] : [range, adjustableRangeEnd];
/**
* Adjust the active range end to fit the range to the allowed size.
*/
var adjustRangeToSize = (range, { disableWeekends = false, adjustableRangeEnd = "to", ...rangeSizeLimits }) => {
	const validFrom = closestValidDay(range.from, disableWeekends);
	if (!range.to) return {
		...range,
		from: validFrom
	};
	const validTo = closestValidDay(range.to, disableWeekends);
	switch (adjustableRangeEnd) {
		case "from": return {
			...range,
			from: clampValid(range.from, {
				minDate: minFrom(validTo, rangeSizeLimits, disableWeekends),
				maxDate: maxFrom(validTo, rangeSizeLimits, disableWeekends)
			}, disableWeekends),
			to: validTo
		};
		case "to": return {
			...range,
			from: validFrom,
			to: clampValid(range.to, {
				minDate: minTo(validFrom, rangeSizeLimits, disableWeekends),
				maxDate: maxTo(validFrom, rangeSizeLimits, disableWeekends)
			}, disableWeekends)
		};
	}
};
/**
* Shift the range to fit within the allowed dates. If the allowed date range is too short to fit the range, the result
* will overflow past the `maxDate`.
*/
var shiftRangeToFit = (range, { disableWeekends = false, ...limits }) => {
	if (!range.to) return {
		...range,
		from: clampValid(range.from, limits, disableWeekends)
	};
	const size = differenceInDays(range.to, range.from);
	const validFrom = clampValid(subDays(clampValid(range.to, limits, disableWeekends), size), limits, disableWeekends);
	const newTo = addDays(validFrom, size);
	return {
		...range,
		from: validFrom,
		to: newTo
	};
};
var fitRange = (range, params) => {
	const [forwardRange, newadjustableRangeEnd] = ensureForwardRange(range, params.adjustableRangeEnd ?? "to");
	const newParams = {
		...params,
		adjustableRangeEnd: newadjustableRangeEnd
	};
	return shiftRangeToFit(adjustRangeToSize(forwardRange, newParams), newParams);
};
var rangeSide = (date, range) => {
	if (isEqual(date, range.from)) return "from";
	if (!range.to) return null;
	if (isEqual(date, range.to)) return "to";
	if (isAfter(date, range.from) && isBefore(date, range.to)) return "middle";
	return null;
};
var Context = createContext(null);
Context.displayName = "Context";
var useDatePickerContext = () => {
	const context = use(Context);
	if (!context) throw new Error("useDatePickerContext must be used inside a DatePickerProvider");
	return context;
};
var DatePickerProvider = ({ children, anchor: externalAnchor = "button", anchorClassName, forwardedAnchorRef = null, confirmation: externalConfirmation = false, confirmUnsavedClose = false, compressedHeader = false, dateFormat = "short", disabled, disableWeekends = false, fieldName = "Date", iconPlacement = "start", maxDate: externalMaxDate, minDate: externalMinDate, showTodayButton = true, showClearButton = false, view: externalView = "1-month", weekStartsOn = "Sunday", open: externalOpen, onClose: externalOnClose, onOpen: externalOnOpen, placeholder = "Choose Date...", value: unsanitizedExternalValue, showInputs: externalShowInputs = true, ...variantSpecificProps }) => {
	const externalValue = useMemo(() => sanitizeSelection(unsanitizedExternalValue), [unsanitizedExternalValue]);
	/**
	* Send an onChange event to the outside world. If the `selection` type does not match
	* the variant of this datepicker, the event will be ignored.
	*/
	const onChange = useCallback((selection) => {
		if (!variantSpecificProps.onChange) return;
		if (!variantSpecificProps.variant && isSingleSelection(selection)) variantSpecificProps.onChange(selection);
		else if (variantSpecificProps.variant === "single" && isSingleSelection(selection)) variantSpecificProps.onChange(selection);
		else if (variantSpecificProps.variant === "range" && isCompleteRangeSelection(selection)) variantSpecificProps.onChange(selection);
	}, [variantSpecificProps.variant, variantSpecificProps.onChange]);
	const [previousSelection, setPreviousSelection] = useState(externalValue);
	const [selection, _setSelection] = useState(externalValue);
	const [isDirty, setIsDirty] = useState(false);
	const setSelection = useCallback((s) => {
		_setSelection(s);
		setIsDirty(s === null || !isRangeSelection(s) || s.to !== null);
	}, []);
	const [hoverRange, setHoverRange] = useState(null);
	const [currentViewingDate, setCurrentViewingDate] = useState(() => getFocusDate(externalValue) ?? sanitizeDate(/* @__PURE__ */ new Date()));
	const [multiMonthSupport, setMultiMonthSupport] = useState(true);
	const [confirmingCloseGesture, setConfirmingCloseGesture] = useState(void 0);
	const confirmation = externalConfirmation || confirmUnsavedClose;
	const maxDate = useMemo(() => {
		if (!externalMaxDate) return;
		const sanitized = sanitizeDate(externalMaxDate);
		return disableWeekends ? closestWeekday(sanitized, "backward") : sanitized;
	}, [externalMaxDate, disableWeekends]);
	const minDate = useMemo(() => {
		if (!externalMinDate) return;
		const sanitized = sanitizeDate(externalMinDate);
		return disableWeekends ? closestWeekday(sanitized, "forward") : sanitized;
	}, [externalMinDate, disableWeekends]);
	const view = multiMonthSupport ? externalView : "1-month";
	const [focusDate, _setFocusDate] = useState(currentViewingDate);
	const setFocusDate = useCallback((newFocusDate) => {
		setCurrentViewingDate((prevViewingDate) => {
			if (view === "1-month") if (prevViewingDate.getMonth() === newFocusDate.getMonth() && prevViewingDate.getFullYear() === newFocusDate.getFullYear()) return prevViewingDate;
			else return setDate(newFocusDate, 1);
			/**
			* This logic is rough, so buckle up.
			* We want to set the currently shown months based on what has focus. If the focus leaves what we're able to view,
			* we want to be able to change the currently shown month. However, this gets complicated with the 2-month view.
			* FIRST: If it's the same month/year: Easy
			* SECOND: If it's the next month, but same year: Done
			* THIRD: If it's the next month AND next year, but it's January (i.e. we're viewing Dec/Jan): Good to go
			*/
			if (prevViewingDate.getMonth() === newFocusDate.getMonth() && prevViewingDate.getFullYear() === newFocusDate.getFullYear() || addMonths(prevViewingDate, 1).getMonth() === newFocusDate.getMonth() && prevViewingDate.getFullYear() === newFocusDate.getFullYear() || addMonths(prevViewingDate, 1).getMonth() === newFocusDate.getMonth() && newFocusDate.getMonth() === 0 && addYears(prevViewingDate, 1).getFullYear() === newFocusDate.getFullYear()) return prevViewingDate;
			else return setDate(newFocusDate, 1);
		});
		_setFocusDate(newFocusDate);
	}, [view]);
	const variant = variantSpecificProps.variant ?? "single";
	const maxRangeSize = variantSpecificProps.variant === "range" ? variantSpecificProps.maxRangeSize : void 0;
	const minRangeSize = variantSpecificProps.variant === "range" ? variantSpecificProps.minRangeSize : void 0;
	const showInputs = externalShowInputs && confirmation;
	const [activeRangeEnd, setActiveRangeEnd] = useState(variant === "range" ? "from" : null);
	/**
	* The end of the range that can be adjusted to make the range fit within the allowed size. When inputs are enabled,
	* we adjust the other end of the range so that the user can still make changes to the current input. When inputs
	* are disabled, we adjust the current end of the range so that we stop accepting changes to indicate invalidity.
	*/
	const adjustableRangeEnd = showInputs ? activeRangeEnd === "to" ? "from" : "to" : activeRangeEnd ?? "from";
	const inputRef = useRef(null);
	const focusInput = () => setTimeout(() => inputRef.current?.focus());
	const internalAnchorRef = useRef(null);
	const [anchorRef, anchor] = typeof externalAnchor === "string" || typeof externalAnchor === "function" ? [internalAnchorRef, externalAnchor] : [externalAnchor, null];
	useRefObjectAsForwardedRef(forwardedAnchorRef, anchorRef);
	const [isOpen, setIsOpen] = useState(externalOpen ?? false);
	useEffect(() => {
		if (externalOpen !== void 0) setIsOpen(externalOpen);
	}, [externalOpen]);
	const onOpen = useCallback((gesture) => {
		if (disabled) return;
		if (externalOpen === void 0) setIsOpen(true);
		externalOnOpen?.(gesture);
		focusInput();
	}, [
		externalOpen,
		externalOnOpen,
		disabled
	]);
	const onClose = useCallback((gesture) => {
		if (externalOpen === void 0) setIsOpen(false);
		externalOnClose?.(gesture);
	}, [externalOpen, externalOnClose]);
	/**
	* When the selection changes, set the focus to that date and fire the callback
	*/
	useEffect(() => {
		const newFocusDate = getFocusDate(selection, activeRangeEnd);
		if (newFocusDate) setFocusDate(newFocusDate);
	}, [
		selection,
		activeRangeEnd,
		setFocusDate
	]);
	useEffect(() => {
		if (JSON.stringify(externalValue) !== JSON.stringify(selection)) {
			setSelection(externalValue);
			setPreviousSelection(externalValue);
			setIsDirty(false);
		}
	}, [externalValue]);
	/**
	* Jump to a specific month/year
	*/
	const goToMonth = useCallback((date) => {
		let newDate = date;
		if (minDate && isBefore(date, minDate)) newDate = minDate;
		else if (maxDate && isAfter(date, maxDate)) newDate = maxDate;
		setCurrentViewingDate(sanitizeDate(newDate));
	}, [minDate, maxDate]);
	const saveValue = useCallback((updatedSelection, submitGesture) => {
		if (updatedSelection) {
			setSelection(updatedSelection);
			setPreviousSelection(updatedSelection);
		}
		setIsDirty(false);
		onChange(updatedSelection);
		if (isOpen) onClose(submitGesture ?? "submit-click");
	}, [
		onClose,
		onChange,
		setSelection,
		isOpen
	]);
	const saveValueHandler = useCallback((updatedSelection) => {
		saveValue(updatedSelection ?? selection);
	}, [saveValue, selection]);
	const revertValue = useCallback(() => {
		setSelection(previousSelection ?? null);
		setIsDirty(false);
		setActiveRangeEnd(variant === "range" ? "from" : null);
		focusInput();
	}, [
		previousSelection,
		variant,
		setSelection
	]);
	/**
	* When the datepicker attempts to close, if confirmUnsavedChanges is enabled, this will fire the modal
	*/
	const closeHandler = useCallback((gesture) => {
		if (confirmingCloseGesture !== void 0) return;
		if (isDirty && confirmUnsavedClose) setConfirmingCloseGesture(gesture);
		else if (isDirty && !confirmation) saveValue(selection);
		else {
			onClose(gesture);
			revertValue();
		}
	}, [
		confirmingCloseGesture,
		isDirty,
		confirmUnsavedClose,
		confirmation,
		saveValue,
		selection,
		onClose,
		revertValue
	]);
	/**
	* Handle the confirm dialog closing (either confirming or discarding).
	*/
	const confirmCloseHandler = useCallback((action) => {
		if (confirmingCloseGesture === void 0) return;
		if (action === "confirm") saveValue(selection);
		else {
			onClose(confirmingCloseGesture);
			revertValue();
		}
		setConfirmingCloseGesture(void 0);
	}, [
		confirmingCloseGesture,
		saveValue,
		onClose,
		revertValue,
		selection
	]);
	/**
	* This handles input when using a text input
	*/
	const inputHandler = useCallback((updatedSelection) => {
		let newSelection;
		switch (variant) {
			case "single":
				if (!(updatedSelection instanceof Date)) break;
				newSelection = clamp(updatedSelection, {
					minDate,
					maxDate
				});
				break;
			case "range":
				if (!isRangeSelection(updatedSelection) || updatedSelection === null) break;
				newSelection = fitRange(updatedSelection, {
					maxDate,
					minDate,
					maxRangeSize,
					minRangeSize,
					adjustableRangeEnd,
					disableWeekends
				});
				break;
		}
		if (newSelection) if (isOpen) setSelection(newSelection);
		else saveValue(newSelection);
	}, [
		maxDate,
		minDate,
		variant,
		maxRangeSize,
		minRangeSize,
		isOpen,
		saveValue,
		setSelection,
		adjustableRangeEnd,
		disableWeekends
	]);
	const clearSelectionHandler = useCallback(() => {
		setSelection(null);
		saveValue(null);
	}, [setSelection, saveValue]);
	/**
	* Handles all selection events, both keyboard and mouse related
	* @param preserveFocus If true, user focus will not be reset when selecting. This is useful
	* for keyboard users, especially when range selection would auto-move focus to the end-date
	* input box.
	*/
	const selectionHandler = useCallback((date, preserveFocus = false, submitGesture) => {
		if (variant === "range" && isRangeSelection(selection)) {
			if (selection?.to && isEqual(selection.from, date)) {
				setActiveRangeEnd("from");
				focusInput();
				return;
			} else if (selection?.to && isEqual(selection.to, date)) {
				setActiveRangeEnd("to");
				focusInput();
				return;
			}
			const corrected = fitRange(activeRangeEnd === "to" && selection ? {
				from: selection.from,
				to: date
			} : {
				from: date,
				to: showInputs ? selection?.to ?? null : null
			}, {
				minDate,
				maxDate,
				maxRangeSize,
				minRangeSize,
				disableWeekends,
				adjustableRangeEnd
			});
			const nextActiveRangeEnd = activeRangeEnd === "to" && selection ? "from" : "to";
			setHoverRange(corrected.to ? null : {
				from: corrected.from,
				to: null
			});
			setSelection(corrected);
			setActiveRangeEnd(nextActiveRangeEnd);
			if (!confirmation && corrected.to) saveValue(corrected);
			else if (!preserveFocus) focusInput();
		} else {
			setSelection(date);
			if (!confirmation) saveValue(date, submitGesture);
			else if (!preserveFocus) focusInput();
		}
	}, [
		selection,
		setSelection,
		minDate,
		maxDate,
		adjustableRangeEnd,
		activeRangeEnd,
		showInputs,
		maxRangeSize,
		minRangeSize,
		disableWeekends,
		confirmation,
		saveValue,
		variant
	]);
	/**
	* Handler for hover events
	*/
	const hoverHandler = useCallback((date) => {
		if (!selection) return;
		if (variant === "range" && isRangeSelection(selection) && hoverRange && !showInputs) setHoverRange(fitRange({
			from: selection.from,
			to: date
		}, {
			minDate,
			maxDate,
			maxRangeSize,
			minRangeSize,
			adjustableRangeEnd,
			disableWeekends
		}));
	}, [
		disableWeekends,
		hoverRange,
		maxDate,
		maxRangeSize,
		minRangeSize,
		minDate,
		selection,
		variant,
		showInputs,
		adjustableRangeEnd
	]);
	/**
	* Callback for when the window resizes
	* @param windowEntry The window observer object
	*/
	const onResize = ([windowEntry]) => {
		if (!windowEntry) return;
		const { width } = windowEntry.contentRect;
		setMultiMonthSupport(width > 640);
	};
	useResizeObserver(onResize);
	return /* @__PURE__ */ jsx(Context, {
		value: useMemo(() => ({
			configuration: {
				anchor,
				anchorClassName,
				confirmation,
				confirmUnsavedClose,
				compressedHeader,
				dateFormat,
				disabled,
				disableWeekends,
				fieldName,
				iconPlacement,
				maxDate,
				minDate,
				placeholder,
				showInputs,
				showTodayButton,
				showClearButton,
				view,
				weekStartsOn,
				variant
			},
			activeRangeEnd,
			setActiveRangeEnd,
			anchorRef,
			close: closeHandler,
			confirmingClose: confirmingCloseGesture !== void 0,
			currentViewingDate,
			focusDate,
			goToMonth,
			hoverRange,
			inputRef,
			isDirty,
			isOpen,
			onClearSelection: clearSelectionHandler,
			onConfirmClose: confirmCloseHandler,
			onDateHover: hoverHandler,
			onDateInput: inputHandler,
			onDateSelection: selectionHandler,
			open: onOpen,
			saveValue: saveValueHandler,
			selection,
			selectionActive: false,
			setFocusDate,
			setHoverRange
		}), [
			activeRangeEnd,
			anchor,
			anchorRef,
			anchorClassName,
			clearSelectionHandler,
			closeHandler,
			compressedHeader,
			confirmCloseHandler,
			confirmUnsavedClose,
			confirmation,
			confirmingCloseGesture,
			currentViewingDate,
			dateFormat,
			disableWeekends,
			disabled,
			focusDate,
			fieldName,
			goToMonth,
			hoverHandler,
			hoverRange,
			iconPlacement,
			inputHandler,
			isDirty,
			isOpen,
			maxDate,
			minDate,
			onOpen,
			placeholder,
			saveValueHandler,
			selection,
			selectionHandler,
			setFocusDate,
			showClearButton,
			showInputs,
			showTodayButton,
			variant,
			view,
			weekStartsOn
		]),
		children
	});
};
DatePickerProvider.displayName = "DatePickerProvider";
/**
* Handle actions on an anchor element that might open the datepicker.
*/
var useOnAnchorAction = () => {
	const $ = c(4);
	const { isOpen, open, close } = useDatePickerContext();
	let t0;
	if ($[0] !== close || $[1] !== isOpen || $[2] !== open) {
		t0 = (event) => {
			if ("key" in event) {
				if (![
					" ",
					"Enter",
					"ArrowDown"
				].includes(event.key)) return;
				event.preventDefault();
				open("anchor-key-press");
			} else if (isOpen) close("anchor-click");
			else open("anchor-click");
		};
		$[0] = close;
		$[1] = isOpen;
		$[2] = open;
		$[3] = t0;
	} else t0 = $[3];
	return t0;
};
var DateResources = {
	invalidConfiguration: "Invalid configuration",
	invalidDate: "Invalid date",
	invalidSelection: "Invalid selection",
	weekend: "Must not fall on a weekend",
	beforeMinDate: (minDate) => `Must be on or after ${format$1(minDate, "PP")}`,
	afterMaxDate: (maxDate) => `Must be on or before ${format$1(maxDate, "PP")}`,
	shortcutInputDescription: "Use arrow keys to select a date, or type a date like \"Dec 28, 2020\" or \"12/28/2020\".",
	dateInputDescription: "Type a date, like \"Dec 28, 2020\" or \"12/28/2020\".",
	monthSingleDescription: "Select a date from the grid.",
	monthRangeDescription: {
		from: "Select a start date from the grid.",
		to: "Select an end date from the grid."
	}
};
var SHORT_FORMAT = "MMM d";
var LONG_FORMAT = "MMM d, yyyy";
var INPUT_FORMAT = "MM/dd/yyyy";
var getDateFormat = (userFormat) => {
	return userFormat === "short" ? SHORT_FORMAT : userFormat === "long" ? LONG_FORMAT : userFormat;
};
var parseDate = (dateString, additionalFormats = []) => {
	const reference = sanitizeDate(/* @__PURE__ */ new Date());
	for (const format of [
		"P",
		"PP",
		SHORT_FORMAT,
		LONG_FORMAT,
		INPUT_FORMAT,
		"MMMM d",
		"MMMM d, yyyy",
		...additionalFormats.map(getDateFormat)
	]) {
		const date = parse(dateString, format, reference);
		if (isValid(date)) return sanitizeDate(date);
	}
	return null;
};
var formatDate = (date, dateFormat) => {
	const today = sanitizeDate(/* @__PURE__ */ new Date());
	if (dateFormat !== SHORT_FORMAT && dateFormat !== LONG_FORMAT) return format(date, dateFormat);
	if (dateFormat === SHORT_FORMAT && date.getUTCFullYear() !== today.getUTCFullYear()) return format(date, LONG_FORMAT);
	return format(date, dateFormat);
};
var formatSelection = ({ selection, dateFormat, placeholder = "Choose Date", rawFormat = false, variant = "single" }) => {
	if (!selection) {
		if (rawFormat) return "";
		return placeholder;
	}
	let template = "MMM d";
	if (!rawFormat && dateFormat) template = getDateFormat(dateFormat);
	else template = INPUT_FORMAT;
	switch (variant) {
		case "single": if (selection instanceof Date) return formatDate(selection, template);
		else if (isRangeSelection(selection)) return formatDate(selection.from, template);
		else return DateResources.invalidSelection;
		case "range": if (isRangeSelection(selection)) return Object.entries(selection).map(([, date]) => date ? formatDate(date, template) : "").join(" - ");
		else if (selection instanceof Date) return Object.entries({
			from: selection,
			to: null
		}).map(([, date]) => date ? formatDate(date, template) : "").join(" - ");
		else return DateResources.invalidSelection;
		default: return DateResources.invalidConfiguration;
	}
};
var Anchor_module_default = { calendarIcon: "Anchor-module_aewZIa_calendarIcon" };
/**
* Returns a function that can be called to select all text in the given input or textarea.
*/
function selectAll(ref) {
	if (!ref.current) return;
	ref.current.setSelectionRange(0, ref.current.value.length, "forward");
}
var ValidationErrorPopover_module_default = {
	aboveCaret: "ValidationErrorPopover-module_BOd5va_aboveCaret",
	belowCaret: "ValidationErrorPopover-module_BOd5va_belowCaret",
	Popover: "ValidationErrorPopover-module_BOd5va_Popover",
	PopoverContent: "ValidationErrorPopover-module_BOd5va_PopoverContent"
};
/**
* Returns the closest parent that would clip the popover, or the page `body` if there is none.
*/
var getClippingParent = (popover) => {
	let parent = popover.parentElement;
	while (parent) {
		const computedStyles = getComputedStyle(parent);
		if (computedStyles.overflow !== "visible" && computedStyles.position !== "static") return parent;
		parent = parent.parentElement;
	}
	return document.body;
};
/**
* Shows a validation error without breaking the surrounding layout.
* This component should be used inside a container with `position: relative` (along with
* the annotated input element) to position it properly.
*
* For accessibility, it is better for this component to always be mounted in the
* document even if the relevant input is valid, and for the ID of this component to remain
* constant. Instead of conditionally rendering this component, hide it by setting the `message`
* to `undefined`.
*
* It is not inserted at the document root like overlays, so it is more accessible to screen
* readers by remaining in the right place in the document flow. However, it is more succeptible
* to clipping issues. The popover will make a 'best effort' to position itself so that it won't
* get clipped by a container, but it's not foolproof so try to set containing elements to
* `overflow: visible` if they are not `position: static`.
*/
var ValidationErrorPopover = ({ id, message, testId, margin = 4, position = "below" }) => {
	const containerRef = useRef(null);
	const open = message !== void 0;
	useLayoutEffect(() => {
		if (!open) return;
		const popover = containerRef.current;
		if (!popover) return;
		const clippingParentRect = getClippingParent(popover).getBoundingClientRect();
		const maxWidth = clippingParentRect.width - margin * 2;
		if (popover.style.maxWidth !== `${maxWidth}px`) popover.style.maxWidth = `${maxWidth}px`;
		const popoverRect = popover.getBoundingClientRect();
		const leftDistance = popoverRect.left - clippingParentRect.left;
		const rightDistance = clippingParentRect.right - popoverRect.right;
		const xOffset = leftDistance < margin ? -leftDistance + margin : rightDistance < margin ? rightDistance - margin : 0;
		const xOffsetValue = `${xOffset}px`;
		if (popover.style.getPropertyValue("--x-offset") !== xOffsetValue) popover.style.setProperty("--x-offset", xOffsetValue);
		const caretOffset = `${-xOffset}px`;
		if (popover.style.getPropertyValue("--caret-offset") !== caretOffset) popover.style.setProperty("--caret-offset", caretOffset);
	}, [
		open,
		message,
		margin,
		position === "above"
	]);
	return /* @__PURE__ */ jsx(Popover_default, {
		open,
		caret: position === "above" ? "bottom" : "top",
		className: clsx(ValidationErrorPopover_module_default.Popover, position === "above" ? ValidationErrorPopover_module_default.aboveCaret : ValidationErrorPopover_module_default.belowCaret),
		ref: containerRef,
		children: /* @__PURE__ */ jsx(Popover_default.Content, {
			as: "p",
			"aria-live": "polite",
			id,
			className: clsx(ValidationErrorPopover_module_default.PopoverContent, position === "above" ? ValidationErrorPopover_module_default.aboveCaret : ValidationErrorPopover_module_default.belowCaret),
			...testIdProps(testId ?? "validation-error-popover"),
			children: message
		})
	});
};
ValidationErrorPopover.displayName = "ValidationErrorPopover";
/**
* Returns a function that accepts a date and a keyboard event and returns the date that
* should be the new value (if the keyboard event is a valid shortcut, otherwise returns
* `null`).
*
* Requires `DatePickerContext` to be available.
*/
var useShortcutCalculator = () => {
	const $ = c(4);
	const { configuration: t0 } = useDatePickerContext();
	const { minDate, maxDate, disableWeekends } = t0;
	let t1;
	if ($[0] !== disableWeekends || $[1] !== maxDate || $[2] !== minDate) {
		t1 = (fromDate, event) => {
			let newDate = null;
			bb2: switch (event.key) {
				case "ArrowRight":
					newDate = addDays(fromDate, 1);
					if (disableWeekends && isWeekend(newDate)) newDate = nextMonday(newDate);
					break bb2;
				case "ArrowLeft":
					newDate = subDays(fromDate, 1);
					if (disableWeekends && isWeekend(newDate)) newDate = previousFriday(newDate);
					break bb2;
				case "ArrowUp":
					newDate = subWeeks(fromDate, 1);
					break bb2;
				case "ArrowDown":
					newDate = addWeeks(fromDate, 1);
					break bb2;
				case "Home":
					if (disableWeekends) newDate = isMonday(fromDate) ? fromDate : previousMonday(fromDate);
					else newDate = isSunday(fromDate) ? fromDate : previousSunday(fromDate);
					break bb2;
				case "End":
					if (disableWeekends) newDate = isFriday(fromDate) ? fromDate : nextFriday(fromDate);
					else newDate = isSaturday(fromDate) ? fromDate : nextSaturday(fromDate);
					break bb2;
				case "PageUp":
					newDate = event.shiftKey ? subYears(fromDate, 1) : subMonths(fromDate, 1);
					break bb2;
				case "PageDown": newDate = event.shiftKey ? addYears(fromDate, 1) : addMonths(fromDate, 1);
			}
			return newDate && sanitizeDate(clamp(newDate, {
				minDate,
				maxDate
			}));
		};
		$[0] = disableWeekends;
		$[1] = maxDate;
		$[2] = minDate;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
};
/** Visually hidden text that will still be read by a screen reader. Link with aria-describedby. */
var HiddenDescription = ({ children, id }) => /* @__PURE__ */ jsx("span", {
	className: "sr-only",
	id,
	"aria-live": "polite",
	children
});
HiddenDescription.displayName = "HiddenDescription";
var Input_module_default = {
	activeRangeEnd: "Input-module_832eYW_activeRangeEnd",
	calendarIconButton: "Input-module_832eYW_calendarIconButton",
	container: "Input-module_832eYW_container",
	dangerIcon: "Input-module_832eYW_dangerIcon",
	FormControl: "Input-module_832eYW_FormControl",
	fullWidth: "Input-module_832eYW_fullWidth",
	hasCalendarButton: "Input-module_832eYW_hasCalendarButton",
	rangeInputs: "Input-module_832eYW_rangeInputs",
	rangeInputsSeparator: "Input-module_832eYW_rangeInputsSeparator",
	singleDateInput: "Input-module_832eYW_singleDateInput",
	singleDateInputContainer: "Input-module_832eYW_singleDateInputContainer",
	successIcon: "Input-module_832eYW_successIcon"
};
var ValidityIndicator = ({ status }) => {
	if (status === "success") return /* @__PURE__ */ jsx(Octicon, {
		icon: CheckIcon,
		className: Input_module_default.successIcon
	});
	else if (status === "error") return /* @__PURE__ */ jsx(Octicon, {
		icon: XIcon,
		className: Input_module_default.dangerIcon
	});
	else return null;
};
/**
* Generate props for an input where the user can type anything, but `onChange` will only
* be called when the user has typed a valid date.
*/
ValidityIndicator.displayName = "ValidityIndicator";
var useFreeformDateInput = (t0, forwardedRef) => {
	const $ = c(51);
	const { value, onChange, calendarButton } = t0;
	const inputRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, inputRef);
	const { configuration: t1 } = useDatePickerContext();
	const { dateFormat, minDate, maxDate, disableWeekends } = t1;
	let t2;
	if ($[0] !== dateFormat) {
		t2 = (date) => date ? formatDate(date, getDateFormat(dateFormat)) : "";
		$[0] = dateFormat;
		$[1] = t2;
	} else t2 = $[1];
	const format = t2;
	let t3;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = {};
		$[2] = t3;
	} else t3 = $[2];
	const [validity, setValidity] = useState(t3);
	let t4;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => setValidity({});
		$[3] = t4;
	} else t4 = $[3];
	const clearValidity = t4;
	let t5;
	if ($[4] !== format || $[5] !== value) {
		t5 = () => format(value);
		$[4] = format;
		$[5] = value;
		$[6] = t5;
	} else t5 = $[6];
	const [text, setText] = useState(t5);
	let t6;
	if ($[7] !== format || $[8] !== value) {
		t6 = (t7) => {
			setText(format(t7 === void 0 ? value : t7));
			clearValidity();
		};
		$[7] = format;
		$[8] = value;
		$[9] = t6;
	} else t6 = $[9];
	const resetText = t6;
	let t7;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = () => inputRef.current !== null && document.activeElement === inputRef.current;
		$[10] = t7;
	} else t7 = $[10];
	const isFocused = t7;
	let t8;
	if ($[11] !== dateFormat) {
		t8 = (s) => parseDate(s, [dateFormat]);
		$[11] = dateFormat;
		$[12] = t8;
	} else t8 = $[12];
	const parse = t8;
	let t10;
	let t9;
	if ($[13] !== format || $[14] !== parse || $[15] !== value) {
		t9 = () => {
			setText((current) => !isFocused() || parse(current)?.valueOf() !== value?.valueOf() ? format(value) : current);
		};
		t10 = [
			value,
			format,
			isFocused,
			parse
		];
		$[13] = format;
		$[14] = parse;
		$[15] = value;
		$[16] = t10;
		$[17] = t9;
	} else {
		t10 = $[16];
		t9 = $[17];
	}
	useEffect(t9, t10);
	let t11;
	if ($[18] !== disableWeekends || $[19] !== maxDate || $[20] !== minDate || $[21] !== onChange || $[22] !== parse || $[23] !== text) {
		t11 = () => {
			if (!text) {
				setValidity({});
				onChange(null);
				return null;
			}
			const parsed = parse(text);
			if (!parsed) {
				setValidity({ status: "error" });
				onChange(null);
			} else if (minDate && isBefore(parsed, minDate)) {
				setValidity({
					status: "error",
					message: DateResources.beforeMinDate(minDate)
				});
				onChange(null);
			} else if (maxDate && isAfter(parsed, maxDate)) {
				setValidity({
					status: "error",
					message: DateResources.afterMaxDate(maxDate)
				});
				onChange(null);
			} else if (disableWeekends && isWeekend(parsed)) {
				setValidity({
					status: "error",
					message: DateResources.weekend
				});
				onChange(null);
			} else {
				setValidity({ status: "success" });
				onChange(parsed);
			}
			return parsed;
		};
		$[18] = disableWeekends;
		$[19] = maxDate;
		$[20] = minDate;
		$[21] = onChange;
		$[22] = parse;
		$[23] = text;
		$[24] = t11;
	} else t11 = $[24];
	const debouncedParseAndValidate = useDebounce(t11, 500);
	let t12;
	if ($[25] !== debouncedParseAndValidate) {
		t12 = (t13) => {
			const { target } = t13;
			setText(target.value);
			debouncedParseAndValidate();
		};
		$[25] = debouncedParseAndValidate;
		$[26] = t12;
	} else t12 = $[26];
	const changeHandler = t12;
	let t13;
	if ($[27] !== text) {
		t13 = () => {
			if (text) setValidity({ status: "success" });
			else setValidity({});
		};
		$[27] = text;
		$[28] = t13;
	} else t13 = $[28];
	const onFocus = t13;
	let t14;
	if ($[29] !== debouncedParseAndValidate) {
		t14 = () => debouncedParseAndValidate.flush();
		$[29] = debouncedParseAndValidate;
		$[30] = t14;
	} else t14 = $[30];
	const flushValidate = t14;
	let t15;
	if ($[31] !== validity) {
		t15 = () => jsx(ValidityIndicator, { ...validity });
		$[31] = validity;
		$[32] = t15;
	} else t15 = $[32];
	const ValidIcon = t15;
	let t16;
	if ($[33] !== ValidIcon || $[34] !== calendarButton) {
		t16 = calendarButton?.position === "end" ? [ValidIcon, calendarButton.Component] : [calendarButton?.Component, ValidIcon];
		$[33] = ValidIcon;
		$[34] = calendarButton;
		$[35] = t16;
	} else t16 = $[35];
	const [leadingVisual, trailingVisual] = t16;
	let t17;
	if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
		t17 = () => clearValidity();
		$[36] = t17;
	} else t17 = $[36];
	const t18 = validity.status === "error" ? "error" : void 0;
	const t19 = validity.status === "error";
	let t20;
	if ($[37] !== changeHandler || $[38] !== leadingVisual || $[39] !== onFocus || $[40] !== t18 || $[41] !== t19 || $[42] !== text || $[43] !== trailingVisual) {
		t20 = {
			value: text,
			onChange: changeHandler,
			onFocus,
			onBlur: t17,
			ref: inputRef,
			leadingVisual,
			trailingVisual,
			validationStatus: t18,
			"aria-invalid": t19
		};
		$[37] = changeHandler;
		$[38] = leadingVisual;
		$[39] = onFocus;
		$[40] = t18;
		$[41] = t19;
		$[42] = text;
		$[43] = trailingVisual;
		$[44] = t20;
	} else t20 = $[44];
	let t21;
	if ($[45] !== flushValidate || $[46] !== format || $[47] !== resetText || $[48] !== t20 || $[49] !== validity) {
		t21 = {
			inputProps: t20,
			format,
			flushValidate,
			resetText,
			inputRef,
			validity,
			isFocused
		};
		$[45] = flushValidate;
		$[46] = format;
		$[47] = resetText;
		$[48] = t20;
		$[49] = validity;
		$[50] = t21;
	} else t21 = $[50];
	return t21;
};
var SingleDateInput = ({ ref: forwardedRef, value, onChange, placeholder, "aria-label": ariaLabel, onFocus, fullWidth, disableShortcuts = false, calendarButton, activeRangeEnd = false, className, disabled, labelVisible = false, isAnchor }) => {
	const { inputProps, resetText, flushValidate, inputRef, validity } = useFreeformDateInput({
		value,
		onChange: (d) => d && onChange(d),
		calendarButton
	}, forwardedRef);
	const withFormControlProps = useFormControlForwardedProps(inputProps);
	/**
	* In arrow key mode, all text is always selected and the arrow keys can be used to
	* increment/decrement the value. Typing or clicking again exits arrow key mode.
	*/
	const arrowKeyModeRef = useRef(false);
	setTimeout(() => {
		if (arrowKeyModeRef.current) selectAll(inputRef);
	});
	const calculateShortcut = useShortcutCalculator();
	const keyDownHandler = (e) => {
		if (e.defaultPrevented || !arrowKeyModeRef.current || !value) return;
		const newValue = calculateShortcut(value, e);
		if (newValue) {
			e.preventDefault();
			onChange(newValue);
			resetText(newValue);
		}
	};
	const descriptionId = useId();
	const errorId = useId();
	const input = /* @__PURE__ */ jsx(TextInput$1, {
		...isAnchor ? withFormControlProps : inputProps,
		onFocus: (e_0) => {
			inputProps.onFocus?.(e_0);
			if (!disableShortcuts) arrowKeyModeRef.current = true;
			onFocus?.();
		},
		onBlur: (e_1) => {
			arrowKeyModeRef.current = false;
			inputProps.onBlur?.(e_1);
			flushValidate();
			setTimeout(() => resetText());
		},
		onChange: (e_2) => {
			inputProps.onChange?.(e_2);
			arrowKeyModeRef.current = false;
		},
		onKeyDown: keyDownHandler,
		onMouseDown: () => arrowKeyModeRef.current = false,
		onMouseUp: () => {
			if (arrowKeyModeRef.current) selectAll(inputRef);
		},
		size: "small",
		placeholder,
		"aria-describedby": descriptionId,
		"aria-errormessage": errorId,
		ref: inputRef,
		className: clsx(Input_module_default.singleDateInput, activeRangeEnd && Input_module_default.activeRangeEnd, className),
		disabled,
		"aria-label": ariaLabel
	});
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(Input_module_default.singleDateInputContainer, fullWidth && Input_module_default.fullWidth, calendarButton && Input_module_default.hasCalendarButton),
		children: [
			isAnchor ? input : /* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, {
				visuallyHidden: !labelVisible,
				children: ariaLabel
			}), input] }),
			/* @__PURE__ */ jsx(ValidationErrorPopover, {
				id: errorId,
				message: validity.message,
				position: "above"
			}),
			/* @__PURE__ */ jsx(HiddenDescription, {
				id: descriptionId,
				children: !disableShortcuts ? DateResources.shortcutInputDescription : DateResources.dateInputDescription
			})
		]
	});
};
SingleDateInput.displayName = "SingleDateInput";
var CalendarIconButton = ({ onAction }) => /* @__PURE__ */ jsx(IconButton, {
	variant: "invisible",
	icon: CalendarIcon,
	"aria-label": "Open date picker",
	type: "button",
	onClick: onAction,
	onKeyDown: onAction,
	size: "small",
	className: Input_module_default.calendarIconButton
});
/** Internal text box(es) to show inside the datepicker panel. */
CalendarIconButton.displayName = "CalendarIconButton";
var DatePickerTextInput = ({ ref, fullWidth, anchorRef, className, disabled }) => {
	const { selection, onDateInput, activeRangeEnd, setActiveRangeEnd, configuration: { variant, iconPlacement } } = useDatePickerContext();
	const isAnchor = anchorRef !== void 0;
	const firstRef = useRef(null);
	const secondRef = useRef(null);
	useImperativeHandle(ref, () => ({ focus: () => activeRangeEnd === "to" ? secondRef.current?.focus() : firstRef.current?.focus() }));
	const onAction = useOnAnchorAction();
	const calendarButtonProps = useMemo(() => isAnchor && iconPlacement !== "none" ? {
		Component: () => /* @__PURE__ */ jsx(CalendarIconButton, { onAction }),
		position: iconPlacement
	} : void 0, [
		iconPlacement,
		isAnchor,
		onAction
	]);
	const rangeEndCalendarButtonProps = useMemo(() => isAnchor && iconPlacement !== "none" ? {
		Component: () => /* @__PURE__ */ jsx(CalendarIconButton, { onAction: (event) => {
			setActiveRangeEnd("to");
			onAction(event);
		} }),
		position: iconPlacement
	} : void 0, [
		iconPlacement,
		isAnchor,
		onAction,
		setActiveRangeEnd
	]);
	const input = isRangeSelection(selection) && variant === "range" ? /* @__PURE__ */ jsxs("div", {
		ref: anchorRef,
		className: Input_module_default.rangeInputs,
		children: [
			/* @__PURE__ */ jsx(SingleDateInput, {
				"aria-label": "Start date",
				ref: firstRef,
				value: selection?.from ?? null,
				onChange: (from) => onDateInput({
					from,
					to: selection?.to ?? null
				}),
				onFocus: () => setActiveRangeEnd("from"),
				fullWidth,
				isAnchor,
				disableShortcuts: isAnchor,
				activeRangeEnd: !isAnchor && activeRangeEnd === "from",
				calendarButton: calendarButtonProps,
				className,
				disabled,
				labelVisible: !isAnchor
			}),
			/* @__PURE__ */ jsx("span", {
				className: Input_module_default.rangeInputsSeparator,
				children: " - "
			}),
			/* @__PURE__ */ jsx(SingleDateInput, {
				"aria-label": "End date",
				ref: secondRef,
				value: selection?.to ?? null,
				onChange: (to) => onDateInput({
					from: selection?.from ?? to,
					to
				}),
				onFocus: () => setActiveRangeEnd("to"),
				fullWidth,
				isAnchor,
				disableShortcuts: isAnchor,
				activeRangeEnd: !isAnchor && activeRangeEnd === "to",
				calendarButton: rangeEndCalendarButtonProps,
				className,
				disabled,
				labelVisible: !isAnchor
			})
		]
	}) : isSingleSelection(selection) && variant === "single" ? /* @__PURE__ */ jsx(SingleDateInput, {
		"aria-label": isAnchor ? void 0 : "Selected date",
		ref: anchorRef ?? firstRef,
		value: selection,
		onChange: onDateInput,
		fullWidth,
		isAnchor,
		disableShortcuts: isAnchor,
		calendarButton: calendarButtonProps,
		className,
		disabled
	}) : null;
	return isAnchor ? input : /* @__PURE__ */ jsx("div", {
		className: Input_module_default.container,
		children: input
	});
};
DatePickerTextInput.displayName = "DatePickerTextInput";
DatePickerTextInput.displayName = "DatePickerTextInput";
var ExternalDatePickerAnchor = ({ ref, render, children }) => {
	const onAction = useOnAnchorAction();
	const { configuration: { disabled } } = useDatePickerContext();
	return render({
		ref,
		"aria-haspopup": "true",
		tabIndex: 0,
		onClick: onAction,
		onKeyDown: onAction,
		children,
		disabled,
		"aria-disabled": disabled
	});
};
ExternalDatePickerAnchor.displayName = "ExternalDatePickerAnchor";
ExternalDatePickerAnchor.displayName = "ExternalDatePickerAnchor";
var StyledCalendarIcon = () => /* @__PURE__ */ jsx(Octicon, {
	icon: CalendarIcon,
	className: Anchor_module_default.calendarIcon
});
StyledCalendarIcon.displayName = "StyledCalendarIcon";
var DefaultDatePickerAnchor = ({ ref, anchorVariant, children }) => {
	const { configuration: { iconPlacement, anchorClassName, fieldName, disabled }, selection } = useDatePickerContext();
	const onAction = useOnAnchorAction();
	const ariaLabel = useMemo(() => !!selection, [selection]) ? `${fieldName} - Open date picker (currently selected: ${children})` : `${fieldName} - Choose date...`;
	return anchorVariant === "input" ? /* @__PURE__ */ jsx(DatePickerTextInput, {
		anchorRef: ref,
		fullWidth: true,
		className: anchorClassName,
		disabled
	}) : anchorVariant === "icon-only" ? /* @__PURE__ */ jsx(IconButton, {
		onClick: onAction,
		onKeyDown: onAction,
		type: "button",
		className: anchorClassName,
		...testIdProps("anchor-button"),
		icon: CalendarIcon,
		ref,
		disabled,
		"aria-label": ariaLabel
	}) : /* @__PURE__ */ jsx(ButtonComponent, {
		"aria-label": ariaLabel,
		onClick: onAction,
		onKeyDown: onAction,
		type: "button",
		className: anchorClassName,
		...testIdProps("anchor-button"),
		ref,
		disabled,
		leadingVisual: iconPlacement === "start" ? StyledCalendarIcon : void 0,
		trailingVisual: iconPlacement === "end" ? StyledCalendarIcon : void 0,
		children
	});
};
DefaultDatePickerAnchor.displayName = "DefaultDatePickerAnchor";
var DatePickerAnchor = () => {
	const $ = c(13);
	const { configuration: t0, anchorRef, selection } = useDatePickerContext();
	const { anchor, placeholder, variant, dateFormat } = t0;
	let t1;
	if ($[0] !== dateFormat || $[1] !== placeholder || $[2] !== selection || $[3] !== variant) {
		t1 = formatSelection({
			selection,
			dateFormat,
			placeholder,
			rawFormat: false,
			variant
		});
		$[0] = dateFormat;
		$[1] = placeholder;
		$[2] = selection;
		$[3] = variant;
		$[4] = t1;
	} else t1 = $[4];
	const formattedSelection = t1;
	if (anchor === null) return null;
	if (typeof anchor === "function") {
		let t2;
		if ($[5] !== anchor || $[6] !== anchorRef || $[7] !== formattedSelection) {
			t2 = jsx(ExternalDatePickerAnchor, {
				render: anchor,
				ref: anchorRef,
				children: formattedSelection
			});
			$[5] = anchor;
			$[6] = anchorRef;
			$[7] = formattedSelection;
			$[8] = t2;
		} else t2 = $[8];
		return t2;
	}
	let t2;
	if ($[9] !== anchor || $[10] !== anchorRef || $[11] !== formattedSelection) {
		t2 = jsx(DefaultDatePickerAnchor, {
			anchorVariant: anchor,
			ref: anchorRef,
			children: formattedSelection
		});
		$[9] = anchor;
		$[10] = anchorRef;
		$[11] = formattedSelection;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
};
DatePickerAnchor.displayName = "DatePickerAnchor";
var ConfirmCloseDialog_module_default = { labelText: "ConfirmCloseDialog-module_wBCYzG_labelText" };
/**
* Shown to the user to confirm that they want to discard their changes.
*/
var DatePickerConfirmCloseDialog = () => {
	const $ = c(5);
	const { onConfirmClose, confirmingClose } = useDatePickerContext();
	let t0;
	if ($[0] !== onConfirmClose) {
		t0 = (gesture) => {
			onConfirmClose(gesture === "confirm" ? "confirm" : "discard");
		};
		$[0] = onConfirmClose;
		$[1] = t0;
	} else t0 = $[1];
	const onClose = t0;
	let t1;
	if ($[2] !== confirmingClose || $[3] !== onClose) {
		t1 = confirmingClose ? jsx(ConfirmationDialog, {
			title: "Save Changes?",
			confirmButtonContent: jsxs(Fragment$1, { children: [jsx(CheckIcon, {}), jsx("span", {
				className: ConfirmCloseDialog_module_default.labelText,
				children: "Save"
			})] }),
			cancelButtonContent: jsxs(Fragment$1, { children: [jsx(TrashIcon, {}), jsx("span", {
				className: ConfirmCloseDialog_module_default.labelText,
				children: "Discard"
			})] }),
			onClose,
			children: "You have unsaved changes, would you like to save them?"
		}) : null;
		$[2] = confirmingClose;
		$[3] = onClose;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
};
DatePickerConfirmCloseDialog.displayName = "DatePickerConfirmCloseDialog";
var Overlay_module_default = { overlay: "Overlay-module_4UaEmq_overlay" };
var Day_module_default = {
	activeRangeEnd: "Day-module_45v8Qq_activeRangeEnd",
	date: "Day-module_45v8Qq_date",
	day: "Day-module_45v8Qq_day",
	header: "Day-module_45v8Qq_header",
	range: "Day-module_45v8Qq_range",
	rangeFrom: "Day-module_45v8Qq_rangeFrom",
	rangeMiddle: "Day-module_45v8Qq_rangeMiddle",
	rangeTo: "Day-module_45v8Qq_rangeTo",
	selected: "Day-module_45v8Qq_selected",
	today: "Day-module_45v8Qq_today"
};
var Day = (t0) => {
	const $ = c(47);
	const { date, parentMonth } = t0;
	const { configuration: t1, hoverRange, selection, onDateHover, onDateSelection, activeRangeEnd, currentViewingDate } = useDatePickerContext();
	const { disableWeekends, minDate, maxDate, variant, showInputs, view } = t1;
	let t2;
	if ($[0] !== date) {
		t2 = isToday(date);
		$[0] = date;
		$[1] = t2;
	} else t2 = $[1];
	const today = t2;
	let t3;
	bb0: {
		const t4 = isRangeSelection(selection);
		switch (true) {
			case !selection:
				t3 = false;
				break bb0;
			case t4: {
				let t5;
				if ($[2] !== date || $[3] !== selection) {
					t5 = rangeSide(date, selection) ?? false;
					$[2] = date;
					$[3] = selection;
					$[4] = t5;
				} else t5 = $[4];
				t3 = t5;
				break bb0;
			}
			default: {
				let t5;
				if ($[5] !== date || $[6] !== selection) {
					t5 = isEqual(date, selection);
					$[5] = date;
					$[6] = selection;
					$[7] = t5;
				} else t5 = $[7];
				t3 = t5;
			}
		}
	}
	const selected = t3;
	let t4;
	bb1: {
		if (!hoverRange) {
			t4 = selected;
			break bb1;
		}
		let t5;
		if ($[8] !== date || $[9] !== hoverRange) {
			t5 = rangeSide(date, hoverRange) ?? false;
			$[8] = date;
			$[9] = hoverRange;
			$[10] = t5;
		} else t5 = $[10];
		t4 = t5;
	}
	const previewSelected = t4;
	let t5;
	if ($[11] !== date || $[12] !== parentMonth) {
		t5 = isSameMonth(date, parentMonth);
		$[11] = date;
		$[12] = parentMonth;
		$[13] = t5;
	} else t5 = $[13];
	const outsideCurrentMonth = !t5;
	let t6;
	if ($[14] !== date || $[15] !== disableWeekends || $[16] !== maxDate || $[17] !== minDate || $[18] !== outsideCurrentMonth) {
		t6 = outsideCurrentMonth || (minDate ? isBefore(date, minDate) : false) || (maxDate ? isAfter(date, maxDate) : false) || (disableWeekends ? isWeekend(date) : false);
		$[14] = date;
		$[15] = disableWeekends;
		$[16] = maxDate;
		$[17] = minDate;
		$[18] = outsideCurrentMonth;
		$[19] = t6;
	} else t6 = $[19];
	const disabled = t6;
	let t7;
	if ($[20] !== showInputs) {
		t7 = (event) => {
			if (showInputs) event.preventDefault();
		};
		$[20] = showInputs;
		$[21] = t7;
	} else t7 = $[21];
	const mouseDownHandler = t7;
	let t8;
	if ($[22] !== date || $[23] !== disabled || $[24] !== onDateSelection) {
		t8 = (event_0) => {
			if (disabled) return;
			if ("key" in event_0) {
				if ([" ", "Enter"].includes(event_0.key)) {
					onDateSelection(date, true, "submit-key-press");
					event_0.preventDefault();
					event_0.stopPropagation();
				}
			} else onDateSelection(date);
		};
		$[22] = date;
		$[23] = disabled;
		$[24] = onDateSelection;
		$[25] = t8;
	} else t8 = $[25];
	const actionHandler = t8;
	const todayLabel = today ? " (Today)" : "";
	const selectedLabel = selected === "from" ? " (Start of selected range)" : selected === "to" ? " (End of selected range)" : selected === "middle" ? " (Inside selected range)" : "";
	const minMaxLabel = minDate && isEqual(date, minDate) ? " (Minimum allowed date)" : maxDate && isEqual(date, maxDate) ? " (Maximum allowed date)" : "";
	let t9;
	if ($[26] !== date) {
		t9 = format(date, "EEEE, MMMM d");
		$[26] = date;
		$[27] = t9;
	} else t9 = $[27];
	const label = `${t9}${todayLabel}${minMaxLabel}${selectedLabel}`;
	let t10;
	bb2: {
		if (view !== "2-month" || !outsideCurrentMonth) {
			t10 = false;
			break bb2;
		}
		const side = isSameMonth(parentMonth, currentViewingDate) ? "left" : "right";
		t10 = side === "left" && isAfter(date, parentMonth) || side === "right" && isBefore(date, parentMonth);
	}
	if (t10) {
		let t11;
		if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
			t11 = jsx(BlankDay, {});
			$[28] = t11;
		} else t11 = $[28];
		return t11;
	}
	const t11 = selected !== false;
	let t12;
	if ($[29] !== actionHandler || $[30] !== activeRangeEnd || $[31] !== date || $[32] !== disabled || $[33] !== label || $[34] !== mouseDownHandler || $[35] !== onDateHover || $[36] !== outsideCurrentMonth || $[37] !== previewSelected || $[38] !== t11 || $[39] !== today || $[40] !== variant) {
		const t13 = format(date, "MM/dd/yyyy");
		let t14;
		if ($[42] !== date) {
			t14 = format(date, "MM/dd/yyyy");
			$[42] = date;
			$[43] = t14;
		} else t14 = $[43];
		let t15;
		if ($[44] !== date || $[45] !== onDateHover) {
			t15 = () => onDateHover(date);
			$[44] = date;
			$[45] = onDateHover;
			$[46] = t15;
		} else t15 = $[46];
		t12 = jsx("div", {
			"aria-disabled": disabled,
			"aria-selected": t11,
			"aria-label": label,
			"aria-hidden": outsideCurrentMonth,
			"data-date": t13,
			"data-disabled": disabled ? "true" : void 0,
			...testIdProps(`day-${t14}`),
			onClick: actionHandler,
			onMouseDown: mouseDownHandler,
			onKeyDown: actionHandler,
			onMouseEnter: t15,
			onFocus: _temp$1,
			role: "gridcell",
			tabIndex: -1,
			className: clsx(Day_module_default.day, {
				[Day_module_default.today]: today,
				[Day_module_default.selected]: !!previewSelected,
				[Day_module_default.range]: variant === "range",
				[Day_module_default.activeRangeEnd]: previewSelected === activeRangeEnd,
				[Day_module_default.rangeFrom]: previewSelected === "from",
				[Day_module_default.rangeMiddle]: previewSelected === "middle",
				[Day_module_default.rangeTo]: previewSelected === "to"
			}),
			children: jsx("span", {
				className: Day_module_default.date,
				children: date.getDate()
			})
		});
		$[29] = actionHandler;
		$[30] = activeRangeEnd;
		$[31] = date;
		$[32] = disabled;
		$[33] = label;
		$[34] = mouseDownHandler;
		$[35] = onDateHover;
		$[36] = outsideCurrentMonth;
		$[37] = previewSelected;
		$[38] = t11;
		$[39] = today;
		$[40] = variant;
		$[41] = t12;
	} else t12 = $[41];
	return t12;
};
Day.displayName = "Day";
var BlankDay = () => /* @__PURE__ */ jsx("div", {
	role: "gridcell",
	className: Day_module_default.day,
	"aria-disabled": true,
	"aria-hidden": true,
	children: "•"
});
BlankDay.displayName = "BlankDay";
var WeekdayHeaderDay = ({ date }) => /* @__PURE__ */ jsx("div", {
	role: "columnheader",
	className: clsx(Day_module_default.day, Day_module_default.header),
	"aria-label": format(date, "EEEE"),
	...testIdProps("weekday-header"),
	children: format(date, "EEEEEE")
});
WeekdayHeaderDay.displayName = "WeekdayHeaderDay";
function _temp$1(e) {
	return e.currentTarget.scrollIntoView({
		block: "nearest",
		inline: "nearest"
	});
}
var Month_module_default = {
	compressedHeader: "Month-module_YwuRCa_compressedHeader",
	container: "Month-module_YwuRCa_container",
	grid: "Month-module_YwuRCa_grid",
	row: "Month-module_YwuRCa_row",
	title: "Month-module_YwuRCa_title"
};
var weekdayEnum = {
	Sunday: 0,
	Monday: 1,
	Tuesday: 2,
	Wednesday: 3,
	Thursday: 4,
	Friday: 5,
	Saturday: 6
};
var rowCount = 6;
var Month = (t0) => {
	const $ = c(15);
	const { date, "aria-describedby": descriptionId } = t0;
	const { configuration: t1 } = useDatePickerContext();
	const { weekStartsOn, compressedHeader } = t1;
	let t2;
	if ($[0] !== date) {
		t2 = format(date, "MMMM yyyy");
		$[0] = date;
		$[1] = t2;
	} else t2 = $[1];
	const title = t2;
	let t3;
	if ($[2] !== date || $[3] !== weekStartsOn) {
		const now = new Date(date);
		const weekOptions = { weekStartsOn: weekdayEnum[weekStartsOn] };
		t3 = eachDayOfInterval({
			start: startOfWeek(now, weekOptions),
			end: endOfWeek(now, weekOptions)
		}).map(_temp);
		$[2] = date;
		$[3] = weekStartsOn;
		$[4] = t3;
	} else t3 = $[4];
	const weekdayHeaders = t3;
	let t4;
	if ($[5] !== date || $[6] !== weekStartsOn) {
		const components = [];
		const firstDay = startOfMonth(date);
		const preBlanks = (firstDay.getDay() + (7 - weekdayEnum[weekStartsOn])) % 7;
		const prevMonthLastDay = sub(firstDay, { days: 1 });
		for (let i = 0; i < preBlanks; i++) {
			const day = sub(prevMonthLastDay, { days: preBlanks - i - 1 });
			components.push(jsx(Day, {
				date: day,
				parentMonth: date
			}, `day-component-${day.toString()}`));
		}
		for (let i_0 = 1; i_0 <= getDaysInMonth(firstDay); i_0++) {
			const day_0 = new Date(date.getFullYear(), date.getMonth(), i_0);
			components.push(jsx(Day, {
				date: day_0,
				parentMonth: date
			}, `day-component-${day_0.toString()}`));
		}
		let lastDay = lastDayOfMonth(firstDay);
		while (components.length < rowCount * 7) {
			lastDay = add(lastDay, { days: 1 });
			components.push(jsx(Day, {
				date: lastDay,
				parentMonth: date
			}, `day-component-${lastDay.toString()}`));
		}
		t4 = chunk(components, 7).map(_temp2);
		$[5] = date;
		$[6] = weekStartsOn;
		$[7] = t4;
	} else t4 = $[7];
	const dayComponents = t4;
	const labelId = useId();
	let t5;
	if ($[8] !== compressedHeader || $[9] !== dayComponents || $[10] !== descriptionId || $[11] !== labelId || $[12] !== title || $[13] !== weekdayHeaders) {
		t5 = jsxs("div", {
			className: Month_module_default.container,
			"aria-labelledby": labelId,
			"aria-describedby": descriptionId,
			role: "dialog",
			...testIdProps("month"),
			children: [jsx("span", {
				className: clsx(Month_module_default.title, compressedHeader && Month_module_default.compressedHeader),
				"aria-live": "polite",
				id: labelId,
				children: title
			}), jsxs("div", {
				role: "grid",
				className: Month_module_default.grid,
				children: [jsx("div", {
					className: Month_module_default.row,
					role: "row",
					"aria-hidden": true,
					children: weekdayHeaders
				}), dayComponents]
			})]
		});
		$[8] = compressedHeader;
		$[9] = dayComponents;
		$[10] = descriptionId;
		$[11] = labelId;
		$[12] = title;
		$[13] = weekdayHeaders;
		$[14] = t5;
	} else t5 = $[14];
	return t5;
};
Month.displayName = "Month";
function _temp(d) {
	return jsx(WeekdayHeaderDay, { date: d }, `weekday-${d.toISOString()}-header`);
}
function _temp2(days, index) {
	return jsx("div", {
		className: Month_module_default.row,
		role: "row",
		"aria-label": `Week ${index + 1}`,
		children: days
	}, `month-week-${index}`);
}
var Panel_module_default = {
	arrowButton: "Panel-module_xwws4W_arrowButton",
	container: "Panel-module_xwws4W_container",
	footer: "Panel-module_xwws4W_footer",
	footerButtons: "Panel-module_xwws4W_footerButtons",
	footerRow: "Panel-module_xwws4W_footerRow",
	icon: "Panel-module_xwws4W_icon",
	months: "Panel-module_xwws4W_months",
	option: "Panel-module_xwws4W_option",
	picker: "Panel-module_xwws4W_picker",
	pickers: "Panel-module_xwws4W_pickers",
	topNav: "Panel-module_xwws4W_topNav",
	twoMonthInputs: "Panel-module_xwws4W_twoMonthInputs"
};
var months = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
var getDateElement = (panelRef, date) => panelRef.current?.querySelector(`[data-date="${format(date, "MM/dd/yyyy")}"]`) ?? void 0;
var getFirstEnabledDate = (panelRef) => panelRef.current?.querySelector("[data-date][aria-disabled=\"false\"]") ?? void 0;
var DatePickerPanel = () => {
	const { configuration: { minDate, maxDate, confirmation, view, showTodayButton: configShowTodayButton, showClearButton, compressedHeader, showInputs, variant }, isDirty, saveValue, currentViewingDate, goToMonth, onClearSelection, onDateHover, setFocusDate, inputRef, focusDate, activeRangeEnd } = useDatePickerContext();
	const panelRef = useRef(null);
	const datePanelRef = useRef(null);
	const shouldFocusTodayRef = useRef(false);
	useEffect(() => {
		if (shouldFocusTodayRef.current) {
			const todayElement = getDateElement(panelRef, focusDate);
			if (todayElement) todayElement.focus();
			shouldFocusTodayRef.current = false;
		}
	}, [focusDate]);
	const calculateShortcutDate = useShortcutCalculator();
	const getNextFocusable = useCallback((_, from, event) => {
		const rawFromDate = from?.getAttribute("data-date");
		const fromDate = sanitizeDate(rawFromDate ? new Date(rawFromDate) : /* @__PURE__ */ new Date());
		const newDate = calculateShortcutDate(fromDate, event) ?? fromDate;
		onDateHover(newDate);
		flushSync(() => setFocusDate(newDate));
		return getDateElement(panelRef, newDate);
	}, [
		calculateShortcutDate,
		onDateHover,
		setFocusDate
	]);
	useFocusZone({
		containerRef: datePanelRef,
		bindKeys: FocusKeys.ArrowAll | FocusKeys.HomeAndEnd | FocusKeys.PageUpDown,
		focusInStrategy: () => getDateElement(panelRef, focusDate) ?? getFirstEnabledDate(panelRef),
		getNextFocusable
	}, [getNextFocusable, focusDate]);
	const previousDisabled = useMemo(() => {
		if (!minDate) return false;
		const previous = subMonths(currentViewingDate, 1);
		return minDate.getFullYear() >= previous.getFullYear() && minDate.getMonth() > previous.getMonth();
	}, [minDate, currentViewingDate]);
	const nextDisabled = useMemo(() => {
		if (!maxDate) return false;
		const next = addMonths(currentViewingDate, view === "2-month" ? 2 : 1);
		return maxDate.getFullYear() <= next.getFullYear() && maxDate.getMonth() < next.getMonth();
	}, [
		maxDate,
		view,
		currentViewingDate
	]);
	const showTodayButton = useMemo(() => {
		if (!configShowTodayButton) return false;
		const today = sanitizeDate(/* @__PURE__ */ new Date());
		if (minDate && isAfter(minDate, today)) return false;
		if (maxDate && isBefore(maxDate, today)) return false;
		return true;
	}, [
		maxDate,
		minDate,
		configShowTodayButton
	]);
	const showApplyButton = confirmation;
	const currentMonth = useMemo(() => currentViewingDate.getMonth(), [currentViewingDate]);
	const currentYear = useMemo(() => currentViewingDate.getFullYear(), [currentViewingDate]);
	const headerSelectionHandler = useCallback((e) => {
		const int = parseInt(e.currentTarget.value, 10);
		if (e.currentTarget.id === "picker-header-year") goToMonth(new Date(int, currentMonth));
		else goToMonth(new Date(currentYear, int));
	}, [
		currentMonth,
		currentYear,
		goToMonth
	]);
	const getMonthPicker = useMemo(() => {
		let filteredMonths = months;
		const monthElements = [];
		if (minDate && currentYear === minDate.getFullYear()) filteredMonths = filteredMonths.filter((month) => months.indexOf(month) >= minDate.getMonth());
		if (maxDate && currentYear === maxDate.getFullYear()) filteredMonths = filteredMonths.filter((month_0) => months.indexOf(month_0) <= maxDate.getMonth());
		for (const month_1 of filteredMonths) monthElements.push(/* @__PURE__ */ jsx("option", {
			className: Panel_module_default.option,
			value: months.indexOf(month_1),
			children: month_1
		}, month_1));
		return /* @__PURE__ */ jsx("select", {
			id: "picker-header-month",
			onChange: headerSelectionHandler,
			className: Panel_module_default.picker,
			value: currentMonth,
			"aria-label": "Go to month",
			children: monthElements
		});
	}, [
		minDate,
		maxDate,
		currentMonth,
		currentYear,
		headerSelectionHandler
	]);
	const getYearPicker = useMemo(() => {
		const years = [];
		const todaysYear = sanitizeDate(/* @__PURE__ */ new Date()).getFullYear();
		const minYear = minDate ? minDate.getFullYear() : todaysYear - 200;
		const maxYear = maxDate ? maxDate.getFullYear() : todaysYear + 200;
		for (let i = minYear; i <= maxYear; i++) years.push(/* @__PURE__ */ jsx("option", {
			className: Panel_module_default.option,
			value: i,
			children: i
		}, i));
		return /* @__PURE__ */ jsx("select", {
			className: Panel_module_default.picker,
			id: "picker-header-year",
			onChange: headerSelectionHandler,
			value: currentYear,
			"aria-label": "Go to year",
			children: years
		});
	}, [
		minDate,
		maxDate,
		currentYear,
		headerSelectionHandler
	]);
	const secondMonthDate = useMemo(() => view === "2-month" ? addMonths(currentViewingDate, 1) : null, [view, currentViewingDate]);
	const showButtons = showClearButton || showTodayButton || showApplyButton;
	const saveIfDirty = () => {
		if (isDirty) saveValue();
	};
	const goToToday = useCallback(() => {
		const today_0 = sanitizeDate(/* @__PURE__ */ new Date());
		shouldFocusTodayRef.current = true;
		setFocusDate(today_0);
	}, [setFocusDate]);
	const clearDate = useCallback(() => {
		onClearSelection();
	}, [onClearSelection]);
	const descriptionId = useId();
	const description = variant === "single" ? DateResources.monthSingleDescription : variant === "range" && activeRangeEnd !== null ? DateResources.monthRangeDescription[activeRangeEnd] : "";
	return /* @__PURE__ */ jsxs(ScopedCommands, {
		as: "div",
		commands: { "github:submit-form": saveIfDirty },
		className: Panel_module_default.container,
		ref: panelRef,
		...testIdProps("datepicker-panel"),
		children: [
			/* @__PURE__ */ jsxs("header", {
				className: Panel_module_default.topNav,
				children: [
					compressedHeader && /* @__PURE__ */ jsxs("div", {
						...testIdProps("datepicker-compressed-header"),
						className: Panel_module_default.pickers,
						children: [getMonthPicker, getYearPicker]
					}),
					/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						className: Panel_module_default.arrowButton,
						onClick: () => goToMonth(subMonths(currentViewingDate, 1)),
						disabled: previousDisabled,
						"aria-label": "Go to previous month",
						...testIdProps("previous-button"),
						children: /* @__PURE__ */ jsx(Octicon, {
							icon: ChevronLeftIcon,
							className: Panel_module_default.icon
						})
					}),
					/* @__PURE__ */ jsx(ButtonComponent, {
						size: "small",
						className: Panel_module_default.arrowButton,
						onClick: () => goToMonth(addMonths(currentViewingDate, 1)),
						disabled: nextDisabled,
						"aria-label": "Go to next month",
						...testIdProps("next-button"),
						children: /* @__PURE__ */ jsx(Octicon, {
							icon: ChevronRightIcon,
							className: Panel_module_default.icon
						})
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: Panel_module_default.months,
				ref: datePanelRef,
				children: [
					/* @__PURE__ */ jsx(HiddenDescription, {
						id: descriptionId,
						children: description
					}),
					/* @__PURE__ */ jsx(Month, {
						date: currentViewingDate,
						"aria-describedby": descriptionId
					}),
					secondMonthDate && /* @__PURE__ */ jsx(Month, {
						date: secondMonthDate,
						"aria-describedby": descriptionId
					})
				]
			}),
			(showButtons || showInputs) && /* @__PURE__ */ jsxs("footer", {
				className: Panel_module_default.footer,
				children: [(view === "1-month" || !showButtons) && showInputs && /* @__PURE__ */ jsx("div", {
					className: Panel_module_default.footerRow,
					children: /* @__PURE__ */ jsx(DatePickerTextInput, {
						ref: inputRef,
						fullWidth: true
					})
				}), showButtons && /* @__PURE__ */ jsxs("div", {
					className: Panel_module_default.footerRow,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: Panel_module_default.footerButtons,
							children: [showClearButton && /* @__PURE__ */ jsx(ButtonComponent, {
								variant: "invisible",
								size: "small",
								onClick: clearDate,
								"aria-label": "Clear selected date",
								disabled: !currentViewingDate,
								children: "Clear"
							}), showTodayButton && /* @__PURE__ */ jsx(ButtonComponent, {
								variant: "invisible",
								size: "small",
								onClick: goToToday,
								"aria-label": "Go to today's date",
								disabled: currentViewingDate.getFullYear() === (/* @__PURE__ */ new Date()).getFullYear() && currentViewingDate.getMonth() === (/* @__PURE__ */ new Date()).getMonth(),
								children: "Today"
							})]
						}),
						view === "2-month" && showInputs && /* @__PURE__ */ jsx(DatePickerTextInput, {
							ref: inputRef,
							className: Panel_module_default.twoMonthInputs
						}),
						showApplyButton && /* @__PURE__ */ jsx(CommandButton, {
							variant: "primary",
							size: "small",
							disabled: !isDirty,
							commandId: "github:submit-form",
							"aria-label": "Apply selection and close",
							type: "submit",
							...testIdProps("datepicker-apply"),
							children: "Apply"
						})
					]
				})]
			})
		]
	});
};
DatePickerPanel.displayName = "DatePickerPanel";
var DatePickerOverlay = (t0) => {
	const { className, ...externalProps } = t0;
	const { isOpen, close, open, anchorRef } = useDatePickerContext();
	return jsx(AnchoredOverlay, {
		focusTrapSettings: { restoreFocusOnCleanUp: true },
		focusZoneSettings: { disabled: true },
		open: isOpen,
		onClose: close,
		onOpen: open,
		renderAnchor: null,
		anchorRef,
		overlayProps: {
			"aria-label": "Date Picker",
			role: "dialog",
			"aria-modal": "true"
		},
		...externalProps,
		className: clsx(Overlay_module_default.overlay, className),
		children: jsx(DatePickerPanel, {})
	});
};
DatePickerOverlay.displayName = "DatePickerOverlay";
/**
* A form input for accepting date values (including date ranges). Provides
* a consistent and user-friendly experience across all browsers.
*/
var DatePicker = ({ ref: forwardedAnchorRef, anchoredOverlayProps, configuration, ...topLevelConfiguration }) => {
	return /* @__PURE__ */ jsxs(DatePickerProvider, {
		...configuration,
		...topLevelConfiguration,
		forwardedAnchorRef,
		children: [
			/* @__PURE__ */ jsx(DatePickerConfirmCloseDialog, {}),
			/* @__PURE__ */ jsx(DatePickerAnchor, {}),
			/* @__PURE__ */ jsx(DatePickerOverlay, { ...anchoredOverlayProps })
		]
	});
};
DatePicker.displayName = "DatePicker";
DatePicker.displayName = "DatePicker";
export { DatePicker as t };
