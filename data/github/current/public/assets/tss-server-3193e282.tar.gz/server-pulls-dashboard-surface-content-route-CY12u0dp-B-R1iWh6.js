import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { r as mainQuery, t as DataRouterApplicationBuilder } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
var dashboardSurfaceAppBuilder = DataRouterApplicationBuilder.create("dashboard-surface");
var PULLS_PATH = "/pulls";
function queryMap() {
	const addArchivedFalse = isFeatureEnabled("pulls_add_archived_false");
	const addUpdatedDesc = isFeatureEnabled("dashboard_add_updated_desc");
	function buildQuery(base) {
		let q = base;
		if (addArchivedFalse) q += " archived:false";
		if (addUpdatedDesc) q += " sort:updated-desc";
		return q;
	}
	return {
		authored: buildQuery("is:pr author:@me state:open"),
		assigned: buildQuery("is:pr assignee:@me state:open"),
		involves: buildQuery("is:pr involves:@me state:open"),
		"on-my-behalf": buildQuery("is:pr author:@copilot assignee:@me state:open"),
		reviews: buildQuery("is:pr review-requested:@me state:open")
	};
}
var queryResolver = ({ searchParams, params }) => {
	const map = queryMap();
	let q = "";
	if (searchParams.get("q")) q = searchParams.get("q");
	else if (params.mode && map[params.mode]) q = map[params.mode];
	return q;
};
var pullsDashboardSurfaceContentRoute = dashboardSurfaceAppBuilder.createQueryRouteConfig("pullsDashboardSurfaceContentRoute", {
	path: `${PULLS_PATH}/:mode`,
	queries: [mainQuery({ queryDeps: ({ searchParams, params }) => {
		return {
			pathname: PULLS_PATH,
			searchParams: {
				q: queryResolver({
					searchParams,
					params
				}),
				page: searchParams.get("page") || "1"
			}
		};
	} }), {
		queryName: "deferred",
		queryDeps: ({ searchParams, params }) => {
			const q = queryResolver({
				searchParams,
				params
			});
			return {
				pathname: `${PULLS_PATH}/deferred`,
				searchParams: {
					q,
					page: searchParams.get("page") || "1"
				}
			};
		},
		queryFn: async (queryKey) => queryFnFetch(queryKey)
	}]
});
export { queryResolver as a, queryMap as i, dashboardSurfaceAppBuilder as n, pullsDashboardSurfaceContentRoute as r, PULLS_PATH as t };
