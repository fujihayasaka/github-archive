import { i as VisuallyHidden$1, o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import React, { Fragment, forwardRef, memo, useEffect, useImperativeHandle, useRef, useState, useSyncExternalStore } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isMacOS } from "@primer/behaviors/utils";
import { isElement } from "react-is";
import { announceFromElement } from "@primer/live-region-element";
/**
* Use a ref object as the imperative handle for a forwarded ref. This can be used to
* synchronize the ref object with the forwarded ref and allow local access the reference
* instance with `.current`.
*
* **NOTE**: The `refObject` should be passed to the underlying element, NOT the `forwardedRef`.
*/
function useRefObjectAsForwardedRef(forwardedRef, refObject) {
	const $ = c(2);
	let t0;
	if ($[0] !== refObject.current) {
		t0 = () => refObject.current;
		$[0] = refObject.current;
		$[1] = t0;
	} else t0 = $[1];
	useImperativeHandle(forwardedRef, t0);
}
var ConditionalWrapper = (props) => {
	const $ = c(9);
	let children;
	let condition;
	let rest;
	if ($[0] !== props) {
		({if: condition, children, ...rest} = props);
		$[0] = props;
		$[1] = children;
		$[2] = condition;
		$[3] = rest;
	} else {
		children = $[1];
		condition = $[2];
		rest = $[3];
	}
	if (condition) {
		let t0;
		if ($[4] !== children || $[5] !== rest) {
			t0 = /* @__PURE__ */ jsx("div", {
				...rest,
				children
			});
			$[4] = children;
			$[5] = rest;
			$[6] = t0;
		} else t0 = $[6];
		return t0;
	} else {
		let t0;
		if ($[7] !== children) {
			t0 = /* @__PURE__ */ jsx(Fragment$1, { children });
			$[7] = children;
			$[8] = t0;
		} else t0 = $[8];
		return t0;
	}
};
var classes$5 = {
	"ButtonBase": "prc-Button-ButtonBase-9n-Xk",
	"CounterLabel": "prc-Button-CounterLabel-5hAs4",
	"Visual": "prc-Button-Visual-YNt2F",
	"VisualWrap": "prc-Button-VisualWrap-E4cnq",
	"IconButton": "prc-Button-IconButton-fyge7",
	"ButtonContent": "prc-Button-ButtonContent-Iohp5",
	"Label": "prc-Button-Label-FWkx3",
	"LoadingSpinner": "prc-Button-LoadingSpinner-6KfaT",
	"ConditionalWrapper": "prc-Button-ConditionalWrapper-Rvbgb"
};
function useEffectOnce(callback) {
	const $ = c(2);
	const savedCallback = useRef(callback);
	const called = useRef(false);
	let t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			if (called.current === true) return;
			called.current = true;
			savedCallback.current();
		};
		t1 = [];
		$[0] = t0;
		$[1] = t1;
	} else {
		t0 = $[0];
		t1 = $[1];
	}
	useEffect(t0, t1);
}
/**
* Create a callback that can be used within an effect without re-running the
* effect when the values used change. The callback passed to this hook will
* always see the latest snapshot of values that it uses and does not need to
* use a dependency array.
*/
function useEffectCallback(callback) {
	const $ = c(4);
	const savedCallback = useRef(callback);
	let t0;
	let t1;
	if ($[0] !== callback) {
		t0 = () => {
			savedCallback.current = callback;
		};
		t1 = [callback];
		$[0] = callback;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (...t3) => {
			const args = t3;
			return savedCallback.current(...args);
		};
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
/**
* `Announce` is a component that will announce the text content of the
* `children` passed in to screen readers using the given politeness level. It
* will also announce any changes to the text content of `children`
*/
function Announce(props) {
	const $ = c(25);
	let children;
	let delayMs;
	let rest;
	let t0;
	let t1;
	let t2;
	let t3;
	if ($[0] !== props) {
		({as: t0, announceOnShow: t1, children, delayMs, hidden: t2, politeness: t3, ...rest} = props);
		$[0] = props;
		$[1] = children;
		$[2] = delayMs;
		$[3] = rest;
		$[4] = t0;
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
	} else {
		children = $[1];
		delayMs = $[2];
		rest = $[3];
		t0 = $[4];
		t1 = $[5];
		t2 = $[6];
		t3 = $[7];
	}
	const BaseComponent = t0 === void 0 ? "div" : t0;
	const announceOnShow = t1 === void 0 ? true : t1;
	const hidden = t2 === void 0 ? false : t2;
	const politeness = t3 === void 0 ? "polite" : t3;
	const ref = useRef(null);
	const [previousAnnouncementText, setPreviousAnnouncementText] = useState(null);
	const savedAnnouncement = useRef(null);
	let t4;
	if ($[8] !== delayMs || $[9] !== hidden || $[10] !== politeness || $[11] !== previousAnnouncementText) {
		t4 = () => {
			var _savedAnnouncement$cu;
			const { current: element } = ref;
			if (!element) return;
			if (hidden) return;
			const textContent = getTextContent(element);
			if (!textContent) return;
			if (textContent === previousAnnouncementText) return;
			const style = window.getComputedStyle(element);
			if (style.display === "none") return;
			if (style.visibility === "hidden") return;
			(_savedAnnouncement$cu = savedAnnouncement.current) === null || _savedAnnouncement$cu === void 0 || _savedAnnouncement$cu.cancel();
			savedAnnouncement.current = announceFromElement(element, politeness === "assertive" ? { politeness } : {
				politeness,
				delayMs
			});
			setPreviousAnnouncementText(textContent);
		};
		$[8] = delayMs;
		$[9] = hidden;
		$[10] = politeness;
		$[11] = previousAnnouncementText;
		$[12] = t4;
	} else t4 = $[12];
	const announce = useEffectCallback(t4);
	let t5;
	if ($[13] !== announce || $[14] !== announceOnShow) {
		t5 = () => {
			if (announceOnShow) announce();
		};
		$[13] = announce;
		$[14] = announceOnShow;
		$[15] = t5;
	} else t5 = $[15];
	useEffectOnce(t5);
	let t6;
	let t7;
	if ($[16] !== announce) {
		t6 = () => {
			const { current: container } = ref;
			if (container === null) return;
			const observer = new MutationObserver(() => {
				announce();
			});
			observer.observe(container, {
				subtree: true,
				childList: true,
				characterData: true
			});
			return () => {
				observer.disconnect();
			};
		};
		t7 = [announce];
		$[16] = announce;
		$[17] = t6;
		$[18] = t7;
	} else {
		t6 = $[17];
		t7 = $[18];
	}
	useEffect(t6, t7);
	let t8;
	let t9;
	if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = () => () => {
			if (savedAnnouncement.current !== null) {
				savedAnnouncement.current.cancel();
				savedAnnouncement.current = null;
			}
		};
		t9 = [];
		$[19] = t8;
		$[20] = t9;
	} else {
		t8 = $[19];
		t9 = $[20];
	}
	useEffect(t8, t9);
	let t10;
	if ($[21] !== BaseComponent || $[22] !== children || $[23] !== rest) {
		t10 = /* @__PURE__ */ jsx(BaseComponent, {
			...rest,
			ref,
			children
		});
		$[21] = BaseComponent;
		$[22] = children;
		$[23] = rest;
		$[24] = t10;
	} else t10 = $[24];
	return t10;
}
function getTextContent(element) {
	let value = "";
	if (element.hasAttribute("aria-label")) value = element.getAttribute("aria-label");
	else if (element.textContent) value = element.textContent;
	return value ? value.trim() : "";
}
function AriaStatus(props) {
	var _props$announceOnShow;
	const $ = c(3);
	const t0 = (_props$announceOnShow = props.announceOnShow) !== null && _props$announceOnShow !== void 0 ? _props$announceOnShow : false;
	let t1;
	if ($[0] !== props || $[1] !== t0) {
		t1 = /* @__PURE__ */ jsx(Announce, {
			...props,
			announceOnShow: t0,
			politeness: "polite"
		});
		$[0] = props;
		$[1] = t0;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
var classes$4 = { "CounterLabel": "prc-CounterLabel-CounterLabel-X-kRU" };
var CounterLabel = /* @__PURE__ */ forwardRef((t0, forwardedRef) => {
	const $ = c(21);
	let children;
	let className;
	let rest;
	let scheme;
	let variant;
	if ($[0] !== t0) {
		({variant, scheme, className, children, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
		$[4] = scheme;
		$[5] = variant;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
		scheme = $[4];
		variant = $[5];
	}
	let t1;
	if ($[6] !== children) {
		t1 = /* @__PURE__ */ jsxs(VisuallyHidden$1, { children: [
			"\xA0(",
			children,
			")"
		] });
		$[6] = children;
		$[7] = t1;
	} else t1 = $[7];
	const label = t1;
	const inferredVariant = variant || scheme || "secondary";
	let t2;
	if ($[8] !== forwardedRef || $[9] !== inferredVariant || $[10] !== rest) {
		t2 = {
			ref: forwardedRef,
			"aria-hidden": "true",
			"data-variant": inferredVariant,
			...rest
		};
		$[8] = forwardedRef;
		$[9] = inferredVariant;
		$[10] = rest;
		$[11] = t2;
	} else t2 = $[11];
	const counterProps = t2;
	let t3;
	if ($[12] !== className) {
		t3 = clsx(className, classes$4.CounterLabel);
		$[12] = className;
		$[13] = t3;
	} else t3 = $[13];
	let t4;
	if ($[14] !== children || $[15] !== counterProps || $[16] !== t3) {
		t4 = /* @__PURE__ */ jsx("span", {
			...counterProps,
			className: t3,
			children
		});
		$[14] = children;
		$[15] = counterProps;
		$[16] = t3;
		$[17] = t4;
	} else t4 = $[17];
	let t5;
	if ($[18] !== label || $[19] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t4, label] });
		$[18] = label;
		$[19] = t4;
		$[20] = t5;
	} else t5 = $[20];
	return t5;
});
CounterLabel.displayName = "CounterLabel";
var renderModuleVisual = (Visual, loading, visualName, counterLabel) => /* @__PURE__ */ jsx("span", {
	"data-component": visualName,
	className: clsx(!counterLabel && classes$5.Visual, loading ? classes$5.LoadingSpinner : classes$5.VisualWrap),
	children: loading ? /* @__PURE__ */ jsx(Spinner, { size: "small" }) : isElement(Visual) ? Visual : /* @__PURE__ */ jsx(Visual, {})
});
renderModuleVisual.displayName = "renderModuleVisual";
var ButtonBase = /* @__PURE__ */ forwardRef(({ children, as: Component = "button", ...props }, forwardedRef) => {
	const { leadingVisual: LeadingVisual, trailingVisual: TrailingVisual, trailingAction: TrailingAction, ["aria-describedby"]: ariaDescribedBy, ["aria-labelledby"]: ariaLabelledBy, count, icon: Icon, id, variant = "default", size = "medium", alignContent = "center", block = false, loading, loadingAnnouncement = "Loading", inactive, onClick, labelWrap, className, ...rest } = props;
	const innerRef = React.useRef(null);
	useRefObjectAsForwardedRef(forwardedRef, innerRef);
	const uuid = useId$1(id);
	const loadingAnnouncementID = `${uuid}-loading-announcement`;
	const ariaDescribedByIds = loading ? [loadingAnnouncementID, ariaDescribedBy] : [ariaDescribedBy];
	return /* @__PURE__ */ jsxs(ConditionalWrapper, {
		if: typeof loading !== "undefined",
		className: block ? classes$5.ConditionalWrapper : void 0,
		"data-loading-wrapper": true,
		children: [/* @__PURE__ */ jsx(Component, {
			"aria-disabled": loading ? true : void 0,
			...rest,
			ref: innerRef,
			className: clsx(classes$5.ButtonBase, className),
			"data-block": block ? "block" : null,
			"data-inactive": inactive ? true : void 0,
			"data-loading": Boolean(loading),
			"data-no-visuals": !LeadingVisual && !TrailingVisual && !TrailingAction ? true : void 0,
			"data-size": size,
			"data-variant": variant,
			"data-label-wrap": labelWrap,
			"data-has-count": count !== void 0 ? true : void 0,
			"aria-describedby": ariaDescribedByIds.filter((descriptionID) => Boolean(descriptionID)).join(" ") || void 0,
			"aria-labelledby": loading ? [`${uuid}-label`, ariaLabelledBy].filter((labelID) => Boolean(labelID)).join(" ") : ariaLabelledBy,
			id,
			onClick: loading ? void 0 : onClick,
			children: Icon ? loading ? /* @__PURE__ */ jsx(Spinner, { size: "small" }) : isElement(Icon) ? Icon : /* @__PURE__ */ jsx(Icon, {}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("span", {
				"data-component": "buttonContent",
				"data-align": alignContent,
				className: classes$5.ButtonContent,
				children: [
					loading && !LeadingVisual && !TrailingVisual && !TrailingAction && count === void 0 && renderModuleVisual(Spinner, loading, "loadingSpinner", false),
					LeadingVisual && renderModuleVisual(LeadingVisual, Boolean(loading), "leadingVisual", false),
					children && /* @__PURE__ */ jsx("span", {
						"data-component": "text",
						className: classes$5.Label,
						id: loading ? `${uuid}-label` : void 0,
						children
					}),
					count !== void 0 && !TrailingVisual ? renderModuleVisual(/* @__PURE__ */ jsx(CounterLabel, {
						className: classes$5.CounterLabel,
						"data-component": "ButtonCounter",
						children: count
					}), Boolean(loading) && !LeadingVisual, "trailingVisual", true) : TrailingVisual ? renderModuleVisual(TrailingVisual, Boolean(loading) && !LeadingVisual, "trailingVisual", false) : null
				]
			}), TrailingAction && renderModuleVisual(TrailingAction, Boolean(loading) && !LeadingVisual && !TrailingVisual, "trailingAction", false)] })
		}), loading && /* @__PURE__ */ jsx(VisuallyHidden$1, { children: /* @__PURE__ */ jsx(AriaStatus, {
			id: loadingAnnouncementID,
			children: loadingAnnouncement
		}) })]
	});
});
var classes$3 = { "InternalVisuallyHidden": "prc-src-InternalVisuallyHidden-2YaI6" };
function VisuallyHidden(t0) {
	const $ = c(14);
	let as;
	let children;
	let className;
	let isVisible;
	let rest;
	if ($[0] !== t0) {
		({isVisible, children, as, className, ...rest} = t0);
		$[0] = t0;
		$[1] = as;
		$[2] = children;
		$[3] = className;
		$[4] = isVisible;
		$[5] = rest;
	} else {
		as = $[1];
		children = $[2];
		className = $[3];
		isVisible = $[4];
		rest = $[5];
	}
	const Component = as || "span";
	const t1 = !isVisible;
	let t2;
	if ($[6] !== className || $[7] !== t1) {
		t2 = clsx(className, { [classes$3.InternalVisuallyHidden]: t1 });
		$[6] = className;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	let t3;
	if ($[9] !== Component || $[10] !== children || $[11] !== rest || $[12] !== t2) {
		t3 = /* @__PURE__ */ jsx(Component, {
			className: t2,
			...rest,
			children
		});
		$[9] = Component;
		$[10] = children;
		$[11] = rest;
		$[12] = t2;
		$[13] = t3;
	} else t3 = $[13];
	return t3;
}
var subscribe = () => () => {};
var getServerSnapshot = () => false;
/**
* SSR-safe hook for determining if the current platform is MacOS.
*
* Uses `useSyncExternalStore` to read the platform value:
*
* - On the **client**, `ssrUnsafeIsMacOS` reads `navigator.userAgent` and
*   returns the real value immediately, with no extra render pass.
*
* - On the **server**, returns `false`. During hydration, if the snapshots
*   differ, React handles the mismatch internally in a single synchronous
*   pass, avoiding the layout shift that a deferred `useEffect` + `setState`
*   would cause.
*
* Previous implementation used `useState` + `useEffect`, which caused an
* unconditional second render on every mount (even on the client where the
* initial value was already correct).
*/
function useIsMacOS() {
	return useSyncExternalStore(subscribe, isMacOS, getServerSnapshot);
}
/** Converts the first character of the string to upper case and the remaining to lower case. */
var capitalize = ([first, ...rest]) => {
	var _first$toUpperCase;
	return ((_first$toUpperCase = first === null || first === void 0 ? void 0 : first.toUpperCase()) !== null && _first$toUpperCase !== void 0 ? _first$toUpperCase : "") + rest.join("").toLowerCase();
};
/**
* Short-form iconic versions of keys. These should be intuitive (not archaic) and match icons on keyboards.
*/
var condensedKeyName = (key, isMacOS) => {
	var _alt$control$shift$me;
	return (_alt$control$shift$me = {
		alt: isMacOS ? "⌥" : "Alt",
		control: "⌃",
		shift: "⇧",
		meta: isMacOS ? "⌘" : "Win",
		mod: isMacOS ? "⌘" : "⌃",
		pageup: "PgUp",
		pagedown: "PgDn",
		arrowup: "↑",
		arrowdown: "↓",
		arrowleft: "←",
		arrowright: "→",
		plus: "+",
		backspace: "⌫",
		delete: "Del",
		space: "␣",
		tab: "⇥",
		enter: "⏎",
		escape: "Esc",
		function: "Fn",
		capslock: "CapsLock",
		insert: "Ins",
		printscreen: "PrtScn"
	}[key]) !== null && _alt$control$shift$me !== void 0 ? _alt$control$shift$me : capitalize(key);
};
/**
* Specific key displays for 'full' format. We still do show some icons (ie punctuation)
* because that's more intuitive, but for the rest of keys we show the standard key name.
*/
var fullKeyName = (key, isMacOS) => {
	var _alt$mod$$pageup$pag;
	return (_alt$mod$$pageup$pag = {
		alt: isMacOS ? "Option" : "Alt",
		mod: isMacOS ? "Command" : "Control",
		"+": "Plus",
		pageup: "Page Up",
		pagedown: "Page Down",
		arrowup: "Up Arrow",
		arrowdown: "Down Arrow",
		arrowleft: "Left Arrow",
		arrowright: "Right Arrow",
		capslock: "Caps Lock",
		printscreen: "Print Screen"
	}[key]) !== null && _alt$mod$$pageup$pag !== void 0 ? _alt$mod$$pageup$pag : capitalize(key);
};
/**
* Accessible key names intended to be read by a screen reader. This prevents screen
* readers from expressing punctuation in speech, ie, reading a long pause instead of the
* word "period".
*/
var accessibleKeyName = (key, isMacOS) => {
	var _alt$meta$mod$pageup$;
	return (_alt$meta$mod$pageup$ = {
		alt: isMacOS ? "option" : "alt",
		meta: isMacOS ? "command" : "Windows",
		mod: isMacOS ? "command" : "control",
		pageup: "page up",
		pagedown: "page down",
		arrowup: "up arrow",
		arrowdown: "down arrow",
		arrowleft: "left arrow",
		arrowright: "right arrow",
		capslock: "caps lock",
		printscreen: "print screen",
		"`": "backtick",
		"~": "tilde",
		"!": "exclamation point",
		"@": "at",
		"#": "hash",
		$: "dollar sign",
		"%": "percent",
		"^": "caret",
		"&": "ampersand",
		"*": "asterisk",
		"(": "left parenthesis",
		")": "right parenthesis",
		_: "underscore",
		"-": "dash",
		"+": "plus",
		"=": "equals",
		"[": "left bracket",
		"{": "left curly brace",
		"]": "right bracket",
		"}": "right curly brace",
		"\\": "backslash",
		"|": "pipe",
		";": "semicolon",
		":": "colon",
		"'": "single quote",
		"\"": "double quote",
		",": "comma",
		"<": "left angle bracket",
		".": "period",
		">": "right angle bracket",
		"/": "forward slash",
		"?": "question mark",
		" ": "space"
	}[key]) !== null && _alt$meta$mod$pageup$ !== void 0 ? _alt$meta$mod$pageup$ : key.toLowerCase();
};
/** Renders a single key with accessible alternative text. */
var Key = (t0) => {
	const $ = c(14);
	const { name, format } = t0;
	const isMacOS = useIsMacOS();
	let t1;
	if ($[0] !== isMacOS || $[1] !== name) {
		t1 = accessibleKeyName(name, isMacOS);
		$[0] = isMacOS;
		$[1] = name;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== t1) {
		t2 = /* @__PURE__ */ jsx(VisuallyHidden, { children: t1 });
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== format || $[6] !== isMacOS || $[7] !== name) {
		t3 = format === "condensed" ? condensedKeyName(name, isMacOS) : fullKeyName(name, isMacOS);
		$[5] = format;
		$[6] = isMacOS;
		$[7] = name;
		$[8] = t3;
	} else t3 = $[8];
	let t4;
	if ($[9] !== t3) {
		t4 = /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			children: t3
		});
		$[9] = t3;
		$[10] = t4;
	} else t4 = $[10];
	let t5;
	if ($[11] !== t2 || $[12] !== t4) {
		t5 = /* @__PURE__ */ jsxs(Fragment$1, { children: [t2, t4] });
		$[11] = t2;
		$[12] = t4;
		$[13] = t5;
	} else t5 = $[13];
	return t5;
};
var classes$2 = {
	"Chord": "prc-components-Chord-DdhWN",
	"ChordNormal": "prc-components-ChordNormal-Ov9XG",
	"ChordOnEmphasis": "prc-components-ChordOnEmphasis-O-4BS",
	"ChordOnPrimary": "prc-components-ChordOnPrimary-J2XUj",
	"ChordSmall": "prc-components-ChordSmall-c-P-x"
};
var classes$1 = { "Text": "prc-Text-Text-9mHv3" };
/**
* Distributive Omit utility type that works correctly with union types
*/
/**
* Fixed version of forwardRef that provides better type inference for polymorphic components
*/
/**
* Cast forwardRef to the fixed version with better type inference
*/
var fixedForwardRef = forwardRef;
function Text(props, ref) {
	const $ = c(15);
	let className;
	let rest;
	let size;
	let t0;
	let weight;
	if ($[0] !== props) {
		({as: t0, className, size, weight, ...rest} = props);
		$[0] = props;
		$[1] = className;
		$[2] = rest;
		$[3] = size;
		$[4] = t0;
		$[5] = weight;
	} else {
		className = $[1];
		rest = $[2];
		size = $[3];
		t0 = $[4];
		weight = $[5];
	}
	const Component = t0 === void 0 ? "span" : t0;
	let t1;
	if ($[6] !== className) {
		t1 = clsx(className, classes$1.Text);
		$[6] = className;
		$[7] = t1;
	} else t1 = $[7];
	let t2;
	if ($[8] !== Component || $[9] !== ref || $[10] !== rest || $[11] !== size || $[12] !== t1 || $[13] !== weight) {
		t2 = /* @__PURE__ */ jsx(Component, {
			className: t1,
			"data-size": size,
			"data-weight": weight,
			...rest,
			ref
		});
		$[8] = Component;
		$[9] = ref;
		$[10] = rest;
		$[11] = size;
		$[12] = t1;
		$[13] = weight;
		$[14] = t2;
	} else t2 = $[14];
	return t2;
}
Text.displayName = "Text";
var Text$1 = fixedForwardRef(Text);
var keySortPriorities = {
	control: 1,
	meta: 2,
	alt: 3,
	option: 4,
	shift: 5,
	function: 6
};
var keySortPriority = (priority) => {
	var _keySortPriorities$pr;
	return (_keySortPriorities$pr = keySortPriorities[priority]) !== null && _keySortPriorities$pr !== void 0 ? _keySortPriorities$pr : Infinity;
};
var compareLowercaseKeys = (a, b) => keySortPriority(a) - keySortPriority(b);
/** Split and sort the chord keys in standard order. */
var splitChord = (chord) => chord.split("+").map((k) => k.toLowerCase()).sort(compareLowercaseKeys);
var Chord = (t0) => {
	const $ = c(13);
	const { keys, format: t1, variant: t2, size: t3 } = t0;
	const format = t1 === void 0 ? "condensed" : t1;
	const variant = t2 === void 0 ? "normal" : t2;
	const size = t3 === void 0 ? "normal" : t3;
	const t4 = variant === "normal";
	const t5 = variant === "onEmphasis";
	const t6 = variant === "onPrimary";
	const t7 = size === "small";
	let t8;
	if ($[0] !== t4 || $[1] !== t5 || $[2] !== t6 || $[3] !== t7) {
		t8 = clsx(classes$2.Chord, {
			[classes$2.ChordNormal]: t4,
			[classes$2.ChordOnEmphasis]: t5,
			[classes$2.ChordOnPrimary]: t6,
			[classes$2.ChordSmall]: t7
		});
		$[0] = t4;
		$[1] = t5;
		$[2] = t6;
		$[3] = t7;
		$[4] = t8;
	} else t8 = $[4];
	let t9;
	if ($[5] !== format || $[6] !== keys) {
		let t10;
		if ($[8] !== format) {
			t10 = (k, i) => /* @__PURE__ */ jsxs(Fragment, { children: [i > 0 && format === "full" ? /* @__PURE__ */ jsx("span", {
				"aria-hidden": true,
				children: " + "
			}) : " ", /* @__PURE__ */ jsx(Key, {
				name: k,
				format
			})] }, i);
			$[8] = format;
			$[9] = t10;
		} else t10 = $[9];
		t9 = splitChord(keys).map(t10);
		$[5] = format;
		$[6] = keys;
		$[7] = t9;
	} else t9 = $[7];
	let t10;
	if ($[10] !== t8 || $[11] !== t9) {
		t10 = /* @__PURE__ */ jsx(Text$1, {
			"data-kbd-chord": true,
			className: t8,
			children: t9
		});
		$[10] = t8;
		$[11] = t9;
		$[12] = t10;
	} else t10 = $[12];
	return t10;
};
/** Plain string version of `Chord` for use in `aria` string attributes. */
var accessibleChordString = (chord, isMacOS) => splitChord(chord).map((key) => accessibleKeyName(key, isMacOS)).join(" ");
var splitSequence = (sequence) => sequence.split(" ");
var Sequence = ({ keys, ...chordProps }) => splitSequence(keys).map((c, i) => /* @__PURE__ */ jsxs(Fragment, { children: [i > 0 && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(VisuallyHidden, { children: "then" }), " "] }), /* @__PURE__ */ jsx(Chord, {
	keys: c,
	...chordProps
})] }, i));
/** Plain string version of `Sequence` for use in `aria` string attributes. */
var accessibleSequenceString = (sequence, isMacOS) => splitSequence(sequence).map((chord) => accessibleChordString(chord, isMacOS)).join(" then ");
var classes = { "KeybindingHint": "prc-KeybindingHint-KeybindingHint-qpYIs" };
var Kbd = (t0) => {
	const $ = c(5);
	const { children, className } = t0;
	let t1;
	if ($[0] !== className) {
		t1 = clsx(className, classes.KeybindingHint);
		$[0] = className;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== children || $[3] !== t1) {
		t2 = /* @__PURE__ */ jsx(Text$1, {
			as: "kbd",
			className: t1,
			"data-testid": "keybinding-hint",
			children
		});
		$[2] = children;
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
};
/** Indicates the presence of an available keybinding. */
var KeybindingHint = /* @__PURE__ */ memo((t0) => {
	const $ = c(8);
	let className;
	let props;
	if ($[0] !== t0) {
		({className, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = props;
	} else {
		className = $[1];
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ jsx(Sequence, { ...props });
		$[3] = props;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== className || $[6] !== t1) {
		t2 = /* @__PURE__ */ jsx(Kbd, {
			className,
			children: t1
		});
		$[5] = className;
		$[6] = t1;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
});
KeybindingHint.displayName = "KeybindingHint";
/**
* AVOID: `KeybindingHint` is nearly always sufficient for providing both visible and accessible keyboard hints.
* However, there may be cases where we need a plain string version, such as when building `aria-label` or
* `aria-description`. In that case, this plain string builder can be used instead.
*
* NOTE that this string should _only_ be used when building `aria-label` or `aria-description` props (never rendered
* visibly) and should nearly always also be paired with a visible hint for sighted users.
*/
var getAccessibleKeybindingHintString = accessibleSequenceString;
var ButtonComponent = /* @__PURE__ */ forwardRef(({ children, ...props }, forwardedRef) => {
	return /* @__PURE__ */ jsx(ButtonBase, {
		ref: forwardedRef,
		as: "button",
		type: "button",
		...props,
		children
	});
});
ButtonComponent.displayName = "Button";
ButtonComponent.__SLOT__ = Symbol("Button");
export { ConditionalWrapper as a, Text$1 as c, fixedForwardRef as d, getAccessibleKeybindingHintString as f, ButtonComponent as i, VisuallyHidden as l, useRefObjectAsForwardedRef as m, AriaStatus as n, CounterLabel as o, useIsMacOS as p, ButtonBase as r, KeybindingHint as s, Announce as t, classes$5 as u };
