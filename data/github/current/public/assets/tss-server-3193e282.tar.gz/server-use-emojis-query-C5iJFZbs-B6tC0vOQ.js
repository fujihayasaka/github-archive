import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { c } from "react/compiler-runtime";
function useEmojisQuery(enabled) {
	const $ = c(3);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["autocomplete-emojis-for-editor"];
		$[0] = t0;
	} else t0 = $[0];
	let t1;
	if ($[1] !== enabled) {
		t1 = {
			queryKey: t0,
			enabled,
			queryFn: _temp2,
			staleTime: Infinity
		};
		$[1] = enabled;
		$[2] = t1;
	} else t1 = $[2];
	return useQuery(t1);
}
async function _temp2() {
	const data = await queryFnFetch({ queryDeps: { pathname: "/autocomplete/emojis_for_editor" } });
	return Object.entries(data).map(_temp);
}
function _temp(t0) {
	const [name, t1] = t0;
	const [url, character] = t1;
	return {
		name,
		character,
		url
	};
}
export { useEmojisQuery as t };
