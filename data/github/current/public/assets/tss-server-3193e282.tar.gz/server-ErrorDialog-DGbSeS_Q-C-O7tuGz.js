import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { $n as PersonAddIcon, Pr as SignOutIcon, an as IconButton, f as ArrowSwitchIcon, n as ActionList, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { useMemo, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
function AccountSwitcher(t0) {
	const $ = c(10);
	const { addAccountPath, canAddAccount, switchAccountPath, stashedAccounts, loginAccountPath, setError } = t0;
	const [isOpen, setIsOpen] = useState(false);
	const isLoading = stashedAccounts === null;
	const hasAccounts = !isLoading && stashedAccounts.length > 0;
	let t1;
	if ($[0] !== addAccountPath || $[1] !== canAddAccount || $[2] !== hasAccounts || $[3] !== isLoading || $[4] !== isOpen || $[5] !== loginAccountPath || $[6] !== setError || $[7] !== stashedAccounts || $[8] !== switchAccountPath) {
		t1 = jsxs(ActionMenu, {
			open: isOpen,
			onOpenChange: setIsOpen,
			children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
				icon: ArrowSwitchIcon,
				"aria-label": "Account switcher",
				variant: "invisible",
				tooltipDirection: "s"
			}) }), isLoading ? jsx(AccountSwitcherOverlayLoading, {}) : hasAccounts ? jsx(AccountSwitcherOverlayHasAccounts, {
				stashedAccounts,
				canAddAccount,
				addAccountPath,
				switchAccountPath,
				loginAccountPath,
				setError
			}) : jsx(AccountSwitcherOverlayEmpty, { addAccountPath })]
		});
		$[0] = addAccountPath;
		$[1] = canAddAccount;
		$[2] = hasAccounts;
		$[3] = isLoading;
		$[4] = isOpen;
		$[5] = loginAccountPath;
		$[6] = setError;
		$[7] = stashedAccounts;
		$[8] = switchAccountPath;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
AccountSwitcher.displayName = "AccountSwitcher";
function AccountSwitcherOverlayLoading() {
	return /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		align: "end",
		children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsxs(ActionList.Item, { children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Spinner, { size: "small" }) }), "Loading..."] }) })
	});
}
AccountSwitcherOverlayLoading.displayName = "AccountSwitcherOverlayLoading";
function AccountSwitcherOverlayEmpty({ addAccountPath }) {
	return /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		align: "end",
		children: /* @__PURE__ */ jsx(ActionList, { children: /* @__PURE__ */ jsx(AddAccountLinkItem, { href: addAccountPath }) })
	});
}
AccountSwitcherOverlayEmpty.displayName = "AccountSwitcherOverlayEmpty";
function AddAccountLinkItem({ href, inactive }) {
	return /* @__PURE__ */ jsxs(ActionList.LinkItem, {
		href: href || void 0,
		inactiveText: inactive || void 0,
		children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PersonAddIcon, {}) }), "Add account"]
	});
}
AddAccountLinkItem.displayName = "AddAccountLinkItem";
function AccountSwitcherOverlayHasAccounts({ addAccountPath, canAddAccount, switchAccountPath, stashedAccounts, loginAccountPath, setError }) {
	return /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		align: "end",
		width: "small",
		children: /* @__PURE__ */ jsxs(ActionList, { children: [
			/* @__PURE__ */ jsxs(ActionList.Group, { children: [
				/* @__PURE__ */ jsx(ActionList.GroupHeading, { children: "Switch account" }),
				stashedAccounts.map((account) => isActiveAccount(account) ? /* @__PURE__ */ jsx(StashedAccountItem, {
					switchAccountPath,
					account,
					setError
				}, account.login) : /* @__PURE__ */ jsx(InactiveStashedAccountItem, {
					loginAccountPath,
					account
				}, account.login)),
				/* @__PURE__ */ jsx(ActionList.Divider, {})
			] }),
			/* @__PURE__ */ jsx(AddAccountLinkItem, {
				href: canAddAccount ? addAccountPath : void 0,
				inactive: canAddAccount ? void 0 : "Maximum accounts reached"
			}),
			/* @__PURE__ */ jsxs(ActionList.LinkItem, {
				href: "/logout",
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(SignOutIcon, {}) }), "Sign out..."]
			})
		] })
	});
}
AccountSwitcherOverlayHasAccounts.displayName = "AccountSwitcherOverlayHasAccounts";
function isActiveAccount(account) {
	return typeof account.userSessionId === "number";
}
function StashedAccountItem({ account, switchAccountPath, setError }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		onSelect: () => switchAccount(switchAccountPath, account.userSessionId, setError),
		children: [
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, {
				src: account.avatarUrl,
				size: 20
			}) }),
			account.login,
			/* @__PURE__ */ jsx(ActionList.Description, {
				truncate: true,
				children: account.name
			})
		]
	});
}
StashedAccountItem.displayName = "StashedAccountItem";
function InactiveStashedAccountItem(t0) {
	const $ = c(8);
	const { account, loginAccountPath } = t0;
	useLocation$1();
	let t1;
	if ($[0] !== account.login || $[1] !== loginAccountPath) {
		const ssrSafeLocationString = ssrSafeLocation.toString();
		const url = new URL(loginAccountPath, ssrSafeLocationString);
		url.searchParams.set("login", account.login);
		url.searchParams.set("return_to", ssrSafeLocationString);
		t1 = url.toString();
		$[0] = account.login;
		$[1] = loginAccountPath;
		$[2] = t1;
	} else t1 = $[2];
	const href = t1;
	let t2;
	if ($[3] !== account.avatarUrl || $[4] !== account.login || $[5] !== account.name || $[6] !== href) {
		t2 = jsxs(ActionList.LinkItem, {
			href,
			children: [
				jsx(ActionList.LeadingVisual, { children: jsx(GitHubAvatar, {
					src: account.avatarUrl,
					size: 20,
					className: "inactive-user-avatar"
				}) }),
				account.login,
				jsx(ActionList.Description, {
					truncate: true,
					children: account.name
				})
			]
		});
		$[3] = account.avatarUrl;
		$[4] = account.login;
		$[5] = account.name;
		$[6] = href;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
InactiveStashedAccountItem.displayName = "InactiveStashedAccountItem";
async function switchAccount(switchAccountPath, userSessionId, setError) {
	try {
		const body = new FormData();
		body.append("user_session_id", String(userSessionId));
		body.append("from", "nav_panel");
		const response = await verifiedFetch(switchAccountPath, {
			method: "POST",
			body,
			headers: { Accept: "application/json" }
		});
		if (response.ok) {
			const resp = await response.json();
			if (resp.success) window.location.reload();
			else if (resp.reason === "emu_sso_redirect" && resp.redirect_to) window.location.href = resp.redirect_to;
			else setError(errorProps("An error has occurred while switching accounts. Please try again."));
		} else {
			const { error, reason } = await response.json();
			setError(errorProps(error, reason));
		}
	} catch {
		setError(errorProps("An error occurred while switching accounts. Please try again."));
	}
}
function errorProps(error, reason) {
	return {
		title: "Switch account",
		error: reason === "enterprise access denied" ? /* @__PURE__ */ jsx(BlankslateContainer.Description, { children: error }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: "Unable to switch to the selected account." }), /* @__PURE__ */ jsx(BlankslateContainer.Description, { children: "Please try again. If the issue persists, try adding the account again." })] })
	};
}
function ErrorDialog({ title, error, onClose }) {
	return /* @__PURE__ */ jsx(Dialog, {
		onClose,
		title,
		children: /* @__PURE__ */ jsx(Dialog.Body, { children: /* @__PURE__ */ jsxs(BlankslateContainer, { children: [/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(AlertIcon, {
			size: "medium",
			className: "fgColor-danger"
		}) }), error] }) })
	});
}
ErrorDialog.displayName = "ErrorDialog";
export { isActiveAccount as i, ErrorDialog as n, StashedAccountItem as r, AccountSwitcher as t };
