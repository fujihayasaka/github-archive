import { Hi as useProvidedRefOrCreate } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useOnOutsideClick } from "./server-useOnOutsideClick-DKLusJ3D-nDHIGoWL.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import React, { useContext } from "react";
import { focusTrap } from "@primer/behaviors";
import { createPortal } from "react-dom";
/**
* Hook used to trap focus inside a container. Returns a ref that can be added to the container
* that should trap focus.
* @param settings {FocusTrapHookSettings}
*/
function useFocusTrap(settings, dependencies = []) {
	const [outsideClicked, setOutsideClicked] = React.useState(false);
	const containerRef = useProvidedRefOrCreate(settings === null || settings === void 0 ? void 0 : settings.containerRef);
	const initialFocusRef = useProvidedRefOrCreate(settings === null || settings === void 0 ? void 0 : settings.initialFocusRef);
	const disabled = settings === null || settings === void 0 ? void 0 : settings.disabled;
	const abortController = React.useRef();
	const previousFocusedElement = React.useRef(null);
	if (!previousFocusedElement.current && !disabled) previousFocusedElement.current = document.activeElement;
	function disableTrap() {
		var _abortController$curr;
		(_abortController$curr = abortController.current) === null || _abortController$curr === void 0 || _abortController$curr.abort();
		if (settings !== null && settings !== void 0 && settings.allowOutsideClick && outsideClicked) return;
		if (settings !== null && settings !== void 0 && settings.returnFocusRef && settings.returnFocusRef.current instanceof HTMLElement) settings.returnFocusRef.current.focus();
		else if (settings !== null && settings !== void 0 && settings.restoreFocusOnCleanUp && previousFocusedElement.current instanceof HTMLElement) {
			previousFocusedElement.current.focus();
			previousFocusedElement.current = null;
		}
	}
	React.useEffect(() => {
		if (containerRef.current instanceof HTMLElement) if (!disabled) {
			var _initialFocusRef$curr;
			abortController.current = focusTrap(containerRef.current, (_initialFocusRef$curr = initialFocusRef.current) !== null && _initialFocusRef$curr !== void 0 ? _initialFocusRef$curr : void 0);
			return () => {
				disableTrap();
			};
		} else disableTrap();
	}, [
		containerRef,
		initialFocusRef,
		disabled,
		...dependencies
	]);
	useOnOutsideClick({
		containerRef,
		onClickOutside: () => {
			setOutsideClicked(true);
			if (settings !== null && settings !== void 0 && settings.allowOutsideClick) {
				var _abortController$curr2;
				if (settings.returnFocusRef) settings.returnFocusRef = void 0;
				settings.restoreFocusOnCleanUp = false;
				(_abortController$curr2 = abortController.current) === null || _abortController$curr2 === void 0 || _abortController$curr2.abort();
			}
		}
	});
	return {
		containerRef,
		initialFocusRef
	};
}
var PRIMER_PORTAL_ROOT_ID = "__primerPortalRoot__";
var DEFAULT_PORTAL_CONTAINER_NAME = "__default__";
var portalRootRegistry = {};
/**
* Register a container to serve as a portal root.
* @param root The element that will be the root for portals created in this container
* @param name The name of the container, to be used with the `containerName` prop on the Portal Component.
* If name is not specified, registers the default portal root.
*/
function registerPortalRoot(root, name = DEFAULT_PORTAL_CONTAINER_NAME) {
	portalRootRegistry[name] = root;
}
function ensureDefaultPortal() {
	const existingDefaultPortalContainer = portalRootRegistry[DEFAULT_PORTAL_CONTAINER_NAME];
	if (!existingDefaultPortalContainer || !document.body.contains(existingDefaultPortalContainer)) {
		let defaultPortalContainer = document.getElementById(PRIMER_PORTAL_ROOT_ID);
		if (!(defaultPortalContainer instanceof Element)) {
			defaultPortalContainer = document.createElement("div");
			defaultPortalContainer.setAttribute("id", PRIMER_PORTAL_ROOT_ID);
			defaultPortalContainer.style.position = "absolute";
			defaultPortalContainer.style.top = "0";
			defaultPortalContainer.style.left = "0";
			defaultPortalContainer.style.width = "100%";
			const suitablePortalRoot = document.querySelector("[data-portal-root]");
			if (suitablePortalRoot) suitablePortalRoot.appendChild(defaultPortalContainer);
			else document.body.appendChild(defaultPortalContainer);
		}
		registerPortalRoot(defaultPortalContainer);
	}
}
/**
* Provides the ability for component trees to override the portal root container for a sub-set of the experience.
* The portal will prioritize the context value unless overridden by their own `containerName` prop, and fallback to the default root if neither are specified
*/
var PortalContext = /* @__PURE__ */ React.createContext({});
/**
* Creates a React Portal, placing all children in a separate physical DOM root node.
* @see https://reactjs.org/docs/portals.html
*/
var Portal = ({ children, onMount, containerName: _containerName }) => {
	const { portalContainerName } = useContext(PortalContext);
	const elementRef = React.useRef(null);
	if (!elementRef.current) {
		const div = document.createElement("div");
		div.style.position = "relative";
		div.style.zIndex = "1";
		elementRef.current = div;
	}
	const element = elementRef.current;
	useIsomorphicLayoutEffect(() => {
		let containerName = _containerName !== null && _containerName !== void 0 ? _containerName : portalContainerName;
		if (containerName === void 0) {
			containerName = DEFAULT_PORTAL_CONTAINER_NAME;
			ensureDefaultPortal();
		}
		const parentElement = portalRootRegistry[containerName];
		if (!parentElement) throw new Error(`Portal container '${containerName}' is not yet registered. Container must be registered with registerPortalRoot before use.`);
		parentElement.appendChild(element);
		onMount === null || onMount === void 0 || onMount();
		return () => {
			parentElement.removeChild(element);
		};
	}, [
		element,
		_containerName,
		portalContainerName
	]);
	return /* @__PURE__ */ createPortal(children, element);
};
export { registerPortalRoot as n, useFocusTrap as r, Portal as t };
