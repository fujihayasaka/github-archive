import React, { useMemo, useSyncExternalStore } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
/**
* ScreenSizeStore provides a useSyncExternalStore-compatible interface
* for tracking viewport size changes and mapping them to screen breakpoints.
*
* Uses ResizeObserver on document.documentElement to track viewport size changes.
*/
var ScreenSizeStore = class {
	/**
	* Current screen size breakpoint.
	* `null` indicates the size hasn't been initialized yet.
	* Initialized lazily on first call to getSnapshot() or when observer starts.
	*/
	#currentSize = null;
	#observer = null;
	#subscribers = /* @__PURE__ */ new Set();
	#breakpoints;
	#defaultSize;
	constructor(breakpoints, defaultSize) {
		this.#breakpoints = [...breakpoints].sort((a, b) => b - a);
		this.#defaultSize = defaultSize;
	}
	/**
	* Subscribe to viewport size changes.
	* Compatible with useSyncExternalStore's subscribe parameter.
	*/
	subscribe = (notify) => {
		if (typeof document === "undefined") throw new Error("ScreenSizeStore.subscribe() cannot be called on the server");
		this.#subscribers.add(notify);
		this.#startObserving();
		return () => {
			this.#subscribers.delete(notify);
			this.#stopObserving();
		};
	};
	/**
	* Get the current screen size.
	* Compatible with useSyncExternalStore's getSnapshot parameter.
	*/
	getSnapshot = () => {
		if (typeof document === "undefined") throw new Error("ScreenSizeStore.getSnapshot() cannot be called on the server");
		if (this.#currentSize === null) return this.#initializeCurrentSize();
		return this.#currentSize;
	};
	/**
	* Compute the screen size for a given width.
	* Public method for external use.
	*/
	computeSize(width) {
		return this.#computeSize(width);
	}
	#handleResize = (entries) => {
		const entry = entries[0];
		if (!entry) return;
		const newSize = this.#computeSize(entry.contentRect.width);
		if (this.#currentSize === null || newSize !== this.#currentSize) {
			this.#currentSize = newSize;
			for (const callback of this.#subscribers) callback();
		}
	};
	#computeSize(width) {
		for (const breakpoint of this.#breakpoints) if (width >= breakpoint) return breakpoint;
		return this.#defaultSize;
	}
	#initializeCurrentSize() {
		if (typeof document === "undefined" || !document.documentElement) {
			this.#currentSize = this.#defaultSize;
			return this.#defaultSize;
		}
		let width = document.documentElement.clientWidth;
		if (width === 0 && typeof window !== "undefined" && typeof window.innerWidth === "number") width = window.innerWidth;
		const size = this.#computeSize(width);
		this.#currentSize = size;
		return size;
	}
	#startObserving() {
		if (!this.#observer) {
			this.#observer = new ResizeObserver(this.#handleResize);
			this.#observer.observe(document.documentElement);
			if (this.#currentSize === null) this.#initializeCurrentSize();
		}
	}
	#stopObserving() {
		if (this.#subscribers.size === 0 && this.#observer) {
			this.#observer.disconnect();
			this.#observer = null;
		}
	}
};
var ScreenSize = {
	small: 1,
	medium: 544,
	large: 768,
	xlarge: 1012,
	xxlarge: 1280,
	xxxlarge: 1350,
	xxxxlarge: 1440
};
var screenSizeStore = new ScreenSizeStore([
	ScreenSize.xxxxlarge,
	ScreenSize.xxxlarge,
	ScreenSize.xxlarge,
	ScreenSize.xlarge,
	ScreenSize.large,
	ScreenSize.medium,
	ScreenSize.small
], ScreenSize.small);
var ScreenContext = React.createContext({ screenSize: ScreenSize.small });
ScreenContext.displayName = "ScreenContext";
function useScreenSize() {
	return React.use(ScreenContext);
}
function ScreenSizeProvider(t0) {
	const $ = c(7);
	const { children, initialValue: t1 } = t0;
	const initialValue = t1 === void 0 ? ScreenSize.small : t1;
	let t2;
	if ($[0] !== initialValue) {
		t2 = () => initialValue;
		$[0] = initialValue;
		$[1] = t2;
	} else t2 = $[1];
	const screenSize = useSyncExternalStore(screenSizeStore.subscribe, screenSizeStore.getSnapshot, t2);
	let t3;
	if ($[2] !== screenSize) {
		t3 = { screenSize };
		$[2] = screenSize;
		$[3] = t3;
	} else t3 = $[3];
	const contextValue = t3;
	let t4;
	if ($[4] !== children || $[5] !== contextValue) {
		t4 = jsx(ScreenContext, {
			value: contextValue,
			children
		});
		$[4] = children;
		$[5] = contextValue;
		$[6] = t4;
	} else t4 = $[6];
	return t4;
}
/**
* Compute the screen size breakpoint for a given width.
*/
ScreenSizeProvider.displayName = "ScreenSizeProvider";
function getCurrentSize(elementWidth) {
	return screenSizeStore.computeSize(elementWidth);
}
export { useScreenSize as i, ScreenSizeProvider as n, getCurrentSize as r, ScreenSize as t };
