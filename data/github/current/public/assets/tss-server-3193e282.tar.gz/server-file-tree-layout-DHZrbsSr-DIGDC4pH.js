performance.mark("js-parse-end:server-file-tree-layout-DHZrbsSr-DIGDC4pH.js");
import { n as Outlet$1, v as useMatches$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { a as ReposFileTreePane } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { n as getQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { q as textAreaId } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { i as loadFileTreePath, n as fileTreeCacheKey, t as codeViewFileTreeLayoutRoute } from "./server-file-tree-query-BoZ7HlYc-BElKzBR6.js";
import { t as useHideFooter } from "./server-use-hide-footer-Bird5Mmf-emmURaoK.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { t as codeViewTreeRoute } from "./server-code-view-tree-route-DaWFX48b-q_Z2gZhH.js";
import { t as codeViewBlameRoute } from "./server-code-view-blame-route-CBnG62NQ-C6WKn_o_.js";
import { t as codeViewBlobRoute } from "./server-code-view-blob-route-BXbxJsMG-BeLOpqoP.js";
import { t as codeViewDeleteRoute } from "./server-code-view-delete-route-DHSuVl8s-8Ntctk0M.js";
import { t as codeViewEditRoute } from "./server-code-view-edit-route-CUHyRXnW-CWvnzfL0.js";
import { n as isFileOverviewPayload } from "./server-overview-types-BCkg03zy-KrP1i6Gn.js";
import { t as codeViewRepoRoute } from "./server-code-view-repo-route-BsNI4mmi-Czvdqq85.js";
import { t as codeViewNewRoute } from "./server-code-view-new-route-CPa0iN_Q-Rsso1z4C.js";
import { t as codeViewTreeDeleteRoute } from "./server-code-view-tree-delete-route-BKfSJUYK-C-1_W8Qg.js";
import { t as SharedPageLayout } from "./server-SharedPageLayout-CICF2ah5-T37hahkR.js";
import { useCallback, useEffect, useLayoutEffect, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:file-tree-layout-DHZrbsSr.js");
function setUserContentScrolling(setting) {}
function useDisableUserContentScrolling() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = [];
		$[0] = t0;
	} else t0 = $[0];
	useLayoutEffect(_temp2$1, t0);
}
function _temp2$1() {
	setUserContentScrolling(false);
	return _temp$2;
}
function _temp$2() {
	setUserContentScrolling(true);
}
function useIsFilePage() {
	const $ = c(2);
	const matches = useMatches$1();
	let t0;
	if ($[0] !== matches) {
		t0 = matches.some(_temp$1);
		$[0] = matches;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
function _temp$1(match) {
	return match.id === codeViewBlameRoute.id || match.id === codeViewBlobRoute.id || match.id === codeViewDeleteRoute.id || match.id === codeViewEditRoute.id || match.id === codeViewNewRoute.id || match.id === codeViewTreeDeleteRoute.id;
}
function ReposFileTreePaneWrapper(t0) {
	const { fileTree, ...props } = t0;
	const { data: t1 } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { findFileWorkerPath, refInfo } = t1;
	const repo = useCurrentRepository();
	const isFilePage = useIsFilePage();
	const path = usePath();
	if (!refInfo || !repo || !fileTree) return null;
	return jsx(ReposFileTreePane, {
		...props,
		fileTree,
		repo,
		refInfo,
		path,
		isFilePath: isFilePage,
		findFileWorkerPath,
		incompleteFileTree: false
	});
}
ReposFileTreePaneWrapper.displayName = "ReposFileTreePaneWrapper";
/**
* Reads accumulated file tree data from the dedicated cache, seeded from the
* layout on first access. Returns `loadPath` to fetch missing tree segments
* on demand.
*/
function useFileTree() {
	const $ = c(29);
	const { data: t0 } = useRouteQuery(codeViewFileTreeLayoutRoute, "mainQuery");
	const { fileTree: layoutFileTree, foldersToFetch: layoutFoldersToFetch, fileTreeProcessingTime } = t0;
	const { data: t1 } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { refInfo } = t1;
	const repo = useCurrentRepository();
	const path = usePath();
	const queryClient = useQueryClient();
	const owner = repo.ownerLogin;
	const repoName = repo.name;
	const branch = refInfo.name;
	let cacheKey;
	let initialFileTreeData;
	if ($[0] !== branch || $[1] !== fileTreeProcessingTime || $[2] !== layoutFileTree || $[3] !== layoutFoldersToFetch || $[4] !== owner || $[5] !== queryClient || $[6] !== repoName) {
		cacheKey = fileTreeCacheKey(owner, repoName, branch);
		initialFileTreeData = {
			fileTree: layoutFileTree,
			foldersToFetch: layoutFoldersToFetch,
			fileTreeProcessingTime
		};
		if (!queryClient.getQueryData(cacheKey)) queryClient.setQueryData(cacheKey, initialFileTreeData);
		$[0] = branch;
		$[1] = fileTreeProcessingTime;
		$[2] = layoutFileTree;
		$[3] = layoutFoldersToFetch;
		$[4] = owner;
		$[5] = queryClient;
		$[6] = repoName;
		$[7] = cacheKey;
		$[8] = initialFileTreeData;
	} else {
		cacheKey = $[7];
		initialFileTreeData = $[8];
	}
	let t2;
	if ($[9] !== queryClient) {
		t2 = (t3) => {
			const { queryKey } = t3;
			return queryClient.getQueryData(queryKey);
		};
		$[9] = queryClient;
		$[10] = t2;
	} else t2 = $[10];
	let t3;
	if ($[11] !== cacheKey || $[12] !== initialFileTreeData || $[13] !== t2) {
		t3 = {
			queryKey: cacheKey,
			queryFn: t2,
			staleTime: Infinity,
			initialData: initialFileTreeData
		};
		$[11] = cacheKey;
		$[12] = initialFileTreeData;
		$[13] = t2;
		$[14] = t3;
	} else t3 = $[14];
	const { data } = useQuery(t3);
	let t4;
	if ($[15] !== branch || $[16] !== owner || $[17] !== repoName) {
		t4 = async (targetPath) => {
			await loadFileTreePath({
				owner,
				repo: repoName,
				branch,
				path: targetPath
			});
		};
		$[15] = branch;
		$[16] = owner;
		$[17] = repoName;
		$[18] = t4;
	} else t4 = $[18];
	const loadPath = t4;
	const previousPathRef = useRef(path);
	let t5;
	let t6;
	if ($[19] !== data.fileTree || $[20] !== loadPath || $[21] !== path) {
		t5 = () => {
			if (previousPathRef.current !== path || !data.fileTree[path]) {
				previousPathRef.current = path;
				loadPath(path);
			}
		};
		t6 = [
			path,
			loadPath,
			data.fileTree
		];
		$[19] = data.fileTree;
		$[20] = loadPath;
		$[21] = path;
		$[22] = t5;
		$[23] = t6;
	} else {
		t5 = $[22];
		t6 = $[23];
	}
	useEffect(t5, t6);
	let t7;
	if ($[24] !== data.fileTree || $[25] !== data.fileTreeProcessingTime || $[26] !== data.foldersToFetch || $[27] !== loadPath) {
		t7 = {
			fileTree: data.fileTree,
			foldersToFetch: data.foldersToFetch,
			fileTreeProcessingTime: data.fileTreeProcessingTime,
			loadPath
		};
		$[24] = data.fileTree;
		$[25] = data.fileTreeProcessingTime;
		$[26] = data.foldersToFetch;
		$[27] = loadPath;
		$[28] = t7;
	} else t7 = $[28];
	return t7;
}
/**
* Determines if the current view is an overview page.
*/
function useIsOverview() {
	const $ = c(5);
	const matches = useMatches$1();
	let t0;
	if ($[0] !== matches) {
		t0 = matches.some(_temp);
		$[0] = matches;
		$[1] = t0;
	} else t0 = $[1];
	const overviewMatch = t0;
	let t1;
	if ($[2] !== matches || $[3] !== overviewMatch) {
		t1 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const treeMatch = matches.find(_temp2);
			if (overviewMatch) {
				t1 = true;
				break bb0;
			}
			if (treeMatch) {
				const queryClient = getQueryClient();
				const queryKey = treeMatch.loaderData?.queries?.mainQuery?.queryConfig?.queryKey;
				const data = queryClient.getQueryData(queryKey);
				t1 = data ? isFileOverviewPayload(data.payload) : false;
				break bb0;
			}
		}
		$[2] = matches;
		$[3] = overviewMatch;
		$[4] = t1;
	} else t1 = $[4];
	if (t1 !== Symbol.for("react.early_return_sentinel")) return t1;
	return false;
}
function _temp2(match_0) {
	return match_0.id === codeViewTreeRoute.id;
}
function _temp(match) {
	return match.id === codeViewRepoRoute.id;
}
var CodeViewFileTreeLayout_module_default = {
	heading: "CodeViewFileTreeLayout-module_tX_ofa_heading",
	sidebar: "CodeViewFileTreeLayout-module_tX_ofa_sidebar"
};
var REPOS_FILE_TREE_ID = "repos-file-tree";
function CodeViewFileTreeLayout() {
	const treeRef = useRef(null);
	const isOverview = useIsOverview();
	useDisableUserContentScrolling();
	useHideFooter(true);
	const treePaneState = useTreePaneContext();
	const { fileTree, foldersToFetch, fileTreeProcessingTime } = useFileTree();
	const onTreeItemSelected = useCallback(() => {
		if (window.matchMedia(`(max-width: ${ScreenSize.large - 1}px)`).matches) treePaneState.collapseTree({ focus: null });
	}, [treePaneState]);
	const sidebar = isOverview ? void 0 : /* @__PURE__ */ jsx("div", {
		ref: treeRef,
		className: CodeViewFileTreeLayout_module_default.sidebar,
		tabIndex: 0,
		children: /* @__PURE__ */ jsx(ReposFileTreePaneWrapper, {
			id: REPOS_FILE_TREE_ID,
			fileTree,
			foldersToFetch,
			processingTime: fileTreeProcessingTime,
			collapseTree: treePaneState.collapseTree,
			showTree: treePaneState.isTreeExpanded,
			onItemSelected: onTreeItemSelected,
			treeToggleElement: treePaneState.treeToggleElement,
			treeToggleRef: treePaneState.treeToggleRef,
			searchBoxRef: treePaneState.searchBoxRef,
			onFindFilesShortcut: treePaneState.onFindFilesShortcut,
			textAreaId,
			headerContent: /* @__PURE__ */ jsxs("div", {
				className: "d-flex width-full pr-mb-3 flex-items-center",
				children: [treePaneState.isTreeExpanded && treePaneState.treeToggleElement, /* @__PURE__ */ jsx("h2", {
					className: CodeViewFileTreeLayout_module_default.heading,
					children: "Files"
				})]
			})
		})
	});
	return /* @__PURE__ */ jsx(SharedPageLayout, {
		narrow: treePaneState.isTreeExpanded,
		sidebar,
		children: /* @__PURE__ */ jsx(Outlet$1, {})
	});
}
CodeViewFileTreeLayout.displayName = "CodeViewFileTreeLayout";
var SplitComponent = CodeViewFileTreeLayout;
export { SplitComponent as component };
