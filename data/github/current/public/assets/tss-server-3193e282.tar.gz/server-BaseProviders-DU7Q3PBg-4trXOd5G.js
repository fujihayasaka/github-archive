import { i as getEnabledFeatures } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { c as isRouteErrorResponse, x as useRouteError } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { d as ThemeProvider } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { n as IsDataRouterEnabledContextProvider } from "./server-IsDataRouterEnabled-BOg76Qw5-CRZJ8YK-.js";
import { r as ToastContextProvider } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { t as isResponseError } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as getQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { t as FeatureFlags } from "./server-FeatureFlags-C1NipJFp-82e1Xac8.js";
import { t as use_color_modes_default } from "./server-use-color-modes-BJr-aSEY-DXLeA1jq.js";
import { t as reportError } from "./server-failbot-DcTQsQvG-1jpM1RlB.js";
import { n as setTitle, t as addGitHubToTitle } from "./server-document-metadata-T1_tkk9h-DjLTfGyB.js";
import { t as AnalyticsProvider } from "./server-AnalyticsProvider-D0POAVQk-B5tW16h5.js";
import React, { createContext, memo, use, useCallback, useEffect, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
import { QueryClientProvider } from "@tanstack/react-query";
/**
* If a loader throws a route error, because of a non-OK response, this hook
* will update the document title based on the status code of the response.
*/
function useSetTitleOnResponseError(responseError) {
	const $ = c(3);
	const responseErrorStatusCode = responseError.response.status;
	let t0;
	let t1;
	if ($[0] !== responseErrorStatusCode) {
		t0 = () => {
			setTitle(getTitleForStatus(responseErrorStatusCode));
		};
		t1 = [responseErrorStatusCode];
		$[0] = responseErrorStatusCode;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
}
/**
* Build a string that can be used for the title, based on a
* non-OK status code.
* If the user is logged out, we'll also append "· GitHub"
*/
function getTitleForStatus(responseStatus) {
	return addGitHubToTitle(responseStatus === 404 ? "404 Page not found" : responseStatus === 500 ? "500 Internal server error" : `Error ${responseStatus}`);
}
var reportedErrors = /* @__PURE__ */ new WeakSet();
function handleIfNotReported(error, report) {
	if (!reportedErrors.has(error)) {
		reportedErrors.add(error);
		report(error);
	}
}
function isNoRouteFoundError(routeError) {
	return isRouteErrorResponse(routeError) && routeError.status === 404;
}
/**
*
* Ensure that all render/loader/action errors are handled except a global 404
* which can only happen in instances where the app is unmounting.
*/
var UnhandledRouteError = (t0) => {
	const $ = c(3);
	const { appName } = t0;
	const routeError = useRouteError();
	let t1;
	if ($[0] !== appName || $[1] !== routeError) {
		t1 = jsx(UnhandledRouteErrorInner, {
			routeError,
			appName
		});
		$[0] = appName;
		$[1] = routeError;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
/**
* Extracted from RootAppRouteErrorElement for compatibility with TanStack Router errorComponent,
* which passes error directly rather than using useRouteError.
*/
UnhandledRouteError.displayName = "UnhandledRouteError";
var UnhandledRouteErrorInner = ({ routeError, appName }) => {
	if (isNoRouteFoundError(routeError)) return null;
	return /* @__PURE__ */ jsx(BaseRouteErrorBoundary, {
		appName,
		routeError
	});
};
UnhandledRouteErrorInner.displayName = "UnhandledRouteErrorInner";
function BaseRouteErrorBoundary(t0) {
	const $ = c(6);
	const { appName, routeError } = t0;
	const appNameRef = useRef(appName);
	let t1;
	if ($[0] !== appName) {
		t1 = () => {
			appNameRef.current = appName;
		};
		$[0] = appName;
		$[1] = t1;
	} else t1 = $[1];
	useEffect(t1);
	let t2;
	let t3;
	if ($[2] !== routeError) {
		t2 = () => {
			if (routeError) handleIfNotReported(routeError, (error) => {
				reportError(error, {
					critical: true,
					reactAppName: appNameRef.current
				});
			});
		};
		t3 = [routeError];
		$[2] = routeError;
		$[3] = t2;
		$[4] = t3;
	} else {
		t2 = $[3];
		t3 = $[4];
	}
	useEffect(t2, t3);
	let t4;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = jsxs(BlankslateContainer, {
			border: false,
			spacious: false,
			children: [jsx(BlankslateContainer.Heading, { children: "Unable to load page." }), jsx(BlankslateContainer.Description, { children: "Please reload page and try again" })]
		});
		$[5] = t4;
	} else t4 = $[5];
	return t4;
}
/**
* The RootAppRouteErrorElement is used to handle errors that occur in application code and routes.
* ResponseErrors (thrown from loaders/actions) are handled by the ResponseErrorElement.
* All other errors are handled by the BaseRouteErrorBoundary.
*/
BaseRouteErrorBoundary.displayName = "BaseRouteErrorBoundary";
var RootAppRouteErrorElement = (t0) => {
	const $ = c(3);
	const { appName } = t0;
	const routeError = useRouteError();
	let t1;
	if ($[0] !== appName || $[1] !== routeError) {
		t1 = jsx(RootAppRouteErrorInner, {
			routeError,
			appName
		});
		$[0] = appName;
		$[1] = routeError;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
};
/**
* Extracted from RootAppRouteErrorElement for compatibility with TanStack Router errorComponent,
* which passes error directly rather than using useRouteError.
*/
RootAppRouteErrorElement.displayName = "RootAppRouteErrorElement";
var RootAppRouteErrorInner = ({ routeError, appName }) => {
	if (isResponseError(routeError)) return /* @__PURE__ */ jsx(ResponseErrorElement, {
		appName,
		responseError: routeError
	});
	return /* @__PURE__ */ jsx(BaseRouteErrorBoundary, {
		routeError,
		appName
	});
};
RootAppRouteErrorInner.displayName = "RootAppRouteErrorInner";
function ResponseErrorElement(t0) {
	const $ = c(8);
	const { appName, responseError } = t0;
	useSetTitleOnResponseError(responseError);
	const appNameRef = useRef(appName);
	let t1;
	if ($[0] !== appName) {
		t1 = () => {
			appNameRef.current = appName;
		};
		$[0] = appName;
		$[1] = t1;
	} else t1 = $[1];
	useEffect(t1);
	let t2;
	let t3;
	if ($[2] !== responseError) {
		t2 = () => {
			handleIfNotReported(responseError, (error) => {
				reportError(error, {
					critical: true,
					reactAppName: appNameRef.current
				});
			});
		};
		t3 = [responseError];
		$[2] = responseError;
		$[3] = t2;
		$[4] = t3;
	} else {
		t2 = $[3];
		t3 = $[4];
	}
	useEffect(t2, t3);
	let t4;
	if ($[5] !== responseError.message || $[6] !== responseError.response.status) {
		t4 = jsxs(BlankslateContainer, {
			border: false,
			spacious: false,
			children: [
				jsx(BlankslateContainer.Heading, { children: "Unable to load page." }),
				jsx(BlankslateContainer.Description, { children: `Status: ${responseError.response.status} Message: ${responseError.message}` }),
				jsx(BlankslateContainer.Description, { children: "Please reload page and try again" })
			]
		});
		$[5] = responseError.message;
		$[6] = responseError.response.status;
		$[7] = t4;
	} else t4 = $[7];
	return t4;
}
ResponseErrorElement.displayName = "ResponseErrorElement";
var ReportErrorContext = createContext(null);
ReportErrorContext.displayName = "ReportErrorContext";
var ReportErrorContextProvider = memo(function ReportErrorContextProvider({ appName: reactAppName, children, critical }) {
	const ref = useRef({
		reactAppName,
		critical
	});
	useEffect(() => {
		ref.current = {
			reactAppName,
			critical
		};
	});
	return /* @__PURE__ */ jsx(ReportErrorContext, {
		value: useCallback((error, context) => {
			if (!error) return;
			return handleIfNotReported(error, (err) => {
				reportError(err, {
					critical: ref.current.critical,
					reactAppName: ref.current.reactAppName,
					...context
				});
			});
			/**
			* this should never get dependencies, since we don't want to re-create the function.
			* This may be called in effects and we want to make sure we don't re-run them if this changes
			* you may need to stash things in the ref above to get the values you need into this method
			* when it's called
			*/
		}, []),
		children
	});
});
/**
*
* Errors reported in this context will be reported to the failbot service.
* Do not re-throw the error after calling this function
*
* @returns The `reportError` function from `@github-ui/failbot` that can be used to report errors.
* @throws An error if the context is not used within a `ReportErrorContextProvider`.
*/
ReportErrorContextProvider.displayName = "ReportErrorContextProvider";
function PrimerFeatureFlags(t0) {
	const $ = c(3);
	const { children } = t0;
	let result;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		const featureFlags = getEnabledFeatures();
		result = {};
		for (const flag of featureFlags) if (flag.startsWith("primer_react_")) result[flag] = true;
		$[0] = result;
	} else result = $[0];
	const flags = result;
	let t1;
	if ($[1] !== children) {
		t1 = jsx(FeatureFlags, {
			flags,
			children
		});
		$[1] = children;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
PrimerFeatureFlags.displayName = "PrimerFeatureFlags";
var metadata = {};
/**
* This component provides the _base_ context for both apps and partials.
* It should provide everything needed to render with styles, themes, and i18n.
*/
function BaseProviders(t0) {
	const $ = c(7);
	const { appName, children, dataRouterEnabled } = t0;
	const { colorMode, dayScheme, nightScheme } = use_color_modes_default();
	let t1;
	if ($[0] !== appName || $[1] !== children || $[2] !== colorMode || $[3] !== dataRouterEnabled || $[4] !== dayScheme || $[5] !== nightScheme) {
		t1 = jsx(QueryClientProvider, {
			client: getQueryClient(),
			children: jsx(AnalyticsProvider, {
				appName,
				category: "",
				metadata,
				children: jsx(PrimerFeatureFlags, { children: jsx(ThemeProvider, {
					colorMode,
					dayScheme,
					nightScheme,
					preventSSRMismatch: true,
					children: jsx(IsDataRouterEnabledContextProvider, {
						enabled: dataRouterEnabled,
						children: jsx(ReportErrorContextProvider, {
							appName,
							children: jsx(ToastContextProvider, { children })
						})
					})
				}) })
			})
		});
		$[0] = appName;
		$[1] = children;
		$[2] = colorMode;
		$[3] = dataRouterEnabled;
		$[4] = dayScheme;
		$[5] = nightScheme;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
BaseProviders.displayName = "BaseProviders";
export { BaseProviders as t };
