import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ct as FileDiffIcon, D as CheckCircleIcon, E as CheckCircleFillIcon, Fr as SingleSelectIcon, Ft as FlameIcon, In as MoonIcon, Ir as SkipIcon, Jt as GitPullRequestIcon, Kr as SquirrelIcon, Mn as MeterIcon, Ni as ZapIcon, O as CheckIcon, Qn as PeopleIcon, Rr as SmileyIcon, S as BriefcaseIcon, Sn as LinkIcon, T as CalendarIcon, Un as NumberIcon, V as ClockIcon, Vn as NorthStarIcon, W as CodeReviewIcon, Wn as OrganizationIcon, X as CommentDiscussionIcon, Yt as GlobeIcon, Z as CommentIcon, Zn as PencilIcon, _n as KebabHorizontalIcon, _r as RepoLockedIcon, an as IconButton, at as DependabotIcon, c as ArchiveIcon, di as ToolsIcon, er as PersonIcon, et as CopilotIcon, f as ArrowSwitchIcon, fn as IssueOpenedIcon, gr as RepoIcon, h as BeakerIcon, hr as RepoForkedIcon, in as HubotIcon, ir as PlusCircleIcon, jn as MentionIcon, mi as TrashIcon, n as ActionList, nn as HomeIcon, o as AlertIcon, oi as TelescopeIcon, pi as Tooltip$1, q as CodescanIcon, si as TerminalIcon, sn as InboxIcon, ti as SunIcon, un as IssueClosedIcon, vi as TypographyIcon, w as BugIcon, x as BookmarkIcon, xr as RocketIcon, yr as RepoTemplateIcon, yt as EyeIcon, z as CircleIcon, zt as GearIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { n as useConfirm } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { s as useMutation } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { Rt as shortcutsPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as hasMatch } from "./server-fzy.js-7qhjn37q.js";
import { r as fuzzyScore } from "./server-fuzzy-score-D3vjDzrR-C9sMCWdL.js";
import { $ as isFilterBlock, C as TRUE_FALSE_FILTER_VALUES, F as findExistingValueUsage, K as getHasValueSuggestion$1, M as defaultFilterProviderOptions, O as capitalize, P as escapeString, Q as isEmptyFilterBlockValue, T as ValidationTypes, U as getFilterValue, V as getExcludeKeySuggestion, W as getFilterValuesByStateType, X as getUnescapedFilterValue, Y as getNoValueSuggestion, a as FILTER_VALUES, b as Strings, c as FilterProviderType, d as FilterValueType, f as INDETERMINANT, h as LINKED_FILTER_PROVIDER_VALUES, i as FILTER_KEYS, k as caseInsensitiveStringCompare, m as IS_FILTER_PROVIDER_VALUES, o as FilterOperator, p as IN_FILTER_PROVIDER_VALUES, q as getLastFilterBlockValue, st as singleFilterProviderOptions, t as AvatarType, v as SORT_FILTER_PROVIDER_VALUES, w as USER_FILTERS, y as SORT_REACTIONS_FILTER_PROVIDER_VALUES, z as getDefaultValueVisualDescriptors } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { i as RootFilterProvider, t as AsyncFilterProvider } from "./server-repository-CE0zbnIG-CI4ka2FT.js";
import { useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { c } from "react/compiler-runtime";
var defaultIcon = "bookmark";
var defaultColor = "gray";
function getIconColorClassName(color) {
	return (colorMap[color?.toLowerCase()] || colorMap[defaultColor]).foreground;
}
function getBackgroundIconColorClassName(color) {
	return (colorMap[color?.toLowerCase()] || colorMap[defaultColor]).background;
}
function getIconComponent(name) {
	return iconMap[name?.toLowerCase()] || iconMap[defaultIcon];
}
function getDisplayName(name) {
	return `${name.charAt(0).toUpperCase() + name.slice(1).replaceAll("_", " ")}`;
}
var colorMap = {
	["gray"]: {
		foreground: "color-fg-muted",
		background: "color-bg-emphasis"
	},
	["blue"]: {
		foreground: "color-fg-accent",
		background: "color-bg-accent-emphasis"
	},
	["green"]: {
		foreground: "color-fg-success",
		background: "color-bg-success-emphasis"
	},
	["orange"]: {
		foreground: "color-fg-severe",
		background: "color-bg-severe-emphasis"
	},
	["red"]: {
		foreground: "color-fg-danger",
		background: "color-bg-danger-emphasis"
	},
	["pink"]: {
		foreground: "color-fg-sponsors",
		background: "color-bg-sponsors-emphasis"
	},
	["purple"]: {
		foreground: "color-fg-done",
		background: "color-bg-done-emphasis"
	}
};
var supportedIconColors = Object.keys(colorMap);
var iconMap = {
	["people"]: PeopleIcon,
	["smiley"]: SmileyIcon,
	["mention"]: MentionIcon,
	["clock"]: ClockIcon,
	["git_pull_request"]: GitPullRequestIcon,
	["zap"]: ZapIcon,
	["issue_opened"]: IssueOpenedIcon,
	["person"]: PersonIcon,
	["comment_discussion"]: CommentDiscussionIcon,
	["organization"]: OrganizationIcon,
	["briefcase"]: BriefcaseIcon,
	["file_diff"]: FileDiffIcon,
	["code_review"]: CodeReviewIcon,
	["codescan"]: CodescanIcon,
	["terminal"]: TerminalIcon,
	["tools"]: ToolsIcon,
	["beaker"]: BeakerIcon,
	["alert"]: AlertIcon,
	["eye"]: EyeIcon,
	["telescope"]: TelescopeIcon,
	["bookmark"]: BookmarkIcon,
	["calendar"]: CalendarIcon,
	["meter"]: MeterIcon,
	["moon"]: MoonIcon,
	["sun"]: SunIcon,
	["flame"]: FlameIcon,
	["bug"]: BugIcon,
	["north_star"]: NorthStarIcon,
	["rocket"]: RocketIcon,
	["squirrel"]: SquirrelIcon,
	["hubot"]: HubotIcon,
	["dependabot"]: DependabotIcon,
	["repo"]: RepoIcon,
	["repo_locked"]: RepoLockedIcon,
	["link"]: LinkIcon,
	["repo_forked"]: RepoForkedIcon,
	["repo_template"]: RepoTemplateIcon,
	["archive"]: ArchiveIcon,
	["home"]: HomeIcon,
	["inbox"]: InboxIcon,
	["gear"]: GearIcon,
	["copilot"]: CopilotIcon,
	["globe"]: GlobeIcon,
	["comment"]: CommentIcon
};
var supportedIconNames = Object.keys(iconMap);
function isValidShortcutName(shortcut) {
	return !!shortcut.name && shortcut.name.trim().length > 0;
}
function isValidShortcutQuery(shortcut) {
	return !!shortcut.query && shortcut.query.trim().length > 0;
}
function isValidShortcutIcon(shortcut) {
	return supportedIconNames.includes(shortcut.icon);
}
function isValidShortcutColor(shortcut) {
	return supportedIconColors.includes(shortcut.color);
}
function isValidShortcut(shortcut) {
	return isValidShortcutName(shortcut) && isValidShortcutQuery(shortcut) && isValidShortcutIcon(shortcut) && isValidShortcutColor(shortcut);
}
function getShortcutsWithSaved(existingShortcuts, savedShortcut) {
	if (existingShortcuts.some((shortcut) => shortcut.id === savedShortcut.id)) return existingShortcuts.map((shortcut) => shortcut.id === savedShortcut.id ? savedShortcut : shortcut);
	else return [...existingShortcuts, savedShortcut];
}
var IconAndColorPicker_module_default = { gap_2: "IconAndColorPicker-module_ivDQla_gap_2" };
function IconAndColorPicker(t0) {
	const $ = c(29);
	const { selectedColor, selectedIcon, onApply } = t0;
	const [isOpen, setIsOpen] = useState(false);
	const [currentColor, setCurrentColor] = useState(selectedColor);
	const [currentIcon, setCurrentIcon] = useState(selectedIcon);
	let t1;
	if ($[0] !== currentColor) {
		t1 = getBackgroundIconColorClassName(currentColor);
		$[0] = currentColor;
		$[1] = t1;
	} else t1 = $[1];
	const currentColorClassName = `${t1} color-fg-on-emphasis`;
	let t2;
	if ($[2] !== selectedColor || $[3] !== selectedIcon) {
		t2 = function onOpen() {
			setCurrentColor(selectedColor);
			setCurrentIcon(selectedIcon);
			setIsOpen(true);
		};
		$[2] = selectedColor;
		$[3] = selectedIcon;
		$[4] = t2;
	} else t2 = $[4];
	const onOpen = t2;
	let t3;
	if ($[5] !== currentColor || $[6] !== currentIcon || $[7] !== onApply) {
		t3 = function onApplyClick() {
			onApply(currentColor, currentIcon);
			setIsOpen(false);
		};
		$[5] = currentColor;
		$[6] = currentIcon;
		$[7] = onApply;
		$[8] = t3;
	} else t3 = $[8];
	const onApplyClick = t3;
	let t4;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => setIsOpen(false);
		$[9] = t4;
	} else t4 = $[9];
	let t5;
	if ($[10] !== currentColor || $[11] !== currentColorClassName || $[12] !== currentIcon || $[13] !== isOpen || $[14] !== onApplyClick || $[15] !== onOpen || $[16] !== selectedColor || $[17] !== selectedIcon) {
		let t6;
		if ($[19] !== selectedColor || $[20] !== selectedIcon) {
			t6 = (anchorProps) => jsx(IconButton, {
				...anchorProps,
				icon: getIconComponent(selectedIcon),
				className: getIconColorClassName(selectedColor),
				"aria-label": "Change icon"
			});
			$[19] = selectedColor;
			$[20] = selectedIcon;
			$[21] = t6;
		} else t6 = $[21];
		let t7;
		if ($[22] !== currentColor || $[23] !== currentColorClassName) {
			t7 = (color) => jsx(Tooltip$1, {
				text: `${getDisplayName(color)} color`,
				direction: "n",
				delay: "long",
				children: jsx(IconButton, {
					icon: color === currentColor ? CheckCircleFillIcon : CircleIcon,
					variant: "invisible",
					className: color === currentColor ? currentColorClassName : getIconColorClassName(color),
					role: "radio",
					"aria-label": `${getDisplayName(color)} color`,
					"aria-checked": color === currentColor,
					onClick: () => setCurrentColor(color)
				}, color)
			}, color);
			$[22] = currentColor;
			$[23] = currentColorClassName;
			$[24] = t7;
		} else t7 = $[24];
		let t8;
		if ($[25] !== currentColorClassName || $[26] !== currentIcon) {
			t8 = (iconName) => jsx(Tooltip$1, {
				text: `${getDisplayName(iconName)} icon`,
				direction: "n",
				delay: "long",
				children: jsx(IconButton, {
					icon: getIconComponent(iconName),
					variant: "invisible",
					className: iconName === currentIcon ? currentColorClassName : "color-fg-muted",
					role: "radio",
					"aria-checked": iconName === currentIcon,
					"aria-label": `${getDisplayName(iconName)} icon`,
					onClick: () => setCurrentIcon(iconName)
				}, iconName)
			}, iconName);
			$[25] = currentColorClassName;
			$[26] = currentIcon;
			$[27] = t8;
		} else t8 = $[27];
		let t9;
		if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
			t9 = () => setIsOpen(false);
			$[28] = t9;
		} else t9 = $[28];
		t5 = jsx(AnchoredOverlay, {
			open: isOpen,
			onOpen,
			onClose: t4,
			focusZoneSettings: { bindKeys: FocusKeys.ArrowAll | FocusKeys.Tab },
			renderAnchor: t6,
			children: jsxs("div", {
				className: "p-2 mx-auto",
				style: { maxWidth: "420px" },
				children: [jsxs("div", {
					className: "p-1",
					children: [
						jsx("div", {
							className: "color-fg-muted text-bold",
							children: "Color"
						}),
						jsx("div", {
							className: clsx("d-flex flex-wrap my-1", IconAndColorPicker_module_default.gap_2),
							role: "radiogroup",
							"aria-label": "Color selection",
							children: supportedIconColors.map(t7)
						}),
						jsx("div", {
							className: "color-fg-muted text-bold",
							children: "Icon"
						}),
						jsx("div", {
							className: clsx("d-flex flex-wrap my-1", IconAndColorPicker_module_default.gap_2),
							role: "radiogroup",
							"aria-label": "Icon selection",
							children: supportedIconNames.map(t8)
						})
					]
				}), jsxs("div", {
					className: clsx("d-flex flex-justify-end p-1", IconAndColorPicker_module_default.gap_2),
					children: [jsx(ButtonComponent, {
						onClick: t9,
						children: "Cancel"
					}), jsx(ButtonComponent, {
						variant: "primary",
						onClick: onApplyClick,
						children: "Apply"
					})]
				})]
			})
		});
		$[10] = currentColor;
		$[11] = currentColorClassName;
		$[12] = currentIcon;
		$[13] = isOpen;
		$[14] = onApplyClick;
		$[15] = onOpen;
		$[16] = selectedColor;
		$[17] = selectedIcon;
		$[18] = t5;
	} else t5 = $[18];
	return t5;
}
IconAndColorPicker.displayName = "IconAndColorPicker";
var ShortcutEditingHeader_module_default = {
	gap_1: "ShortcutEditingHeader-module_KUsNvG_gap_1",
	gap_2: "ShortcutEditingHeader-module_KUsNvG_gap_2"
};
/**
* Editing header component for creating or editing a saved view.
*
* All props can be passed in directly from the `useShortcutEditor` hook, apart from `renderFilter`, which is a
* render prop for rendering a Filter component specific to the page in which this component is used.
*
* The filter component is intended to be shared between this component and the page's default filter UI,
* to keep the query state consistent between the shortcut editor being open or closed.
*/
function ShortcutEditingHeader({ renderFilter, onDismiss, onSave, shortcut, setShortcutValue, isSaving = false, errorMessage }) {
	const titleRef = useRef(null);
	const filterRef = useRef(null);
	const [hasInteractedWithTitle, setHasInteractedWithTitle] = useState(false);
	function onSaveButtonClick() {
		if (!shortcut) throw new Error("Editing shortcut is undefined while submitting.");
		if (!isValidShortcutName(shortcut)) {
			setHasInteractedWithTitle(true);
			titleRef.current?.focus();
			return;
		}
		if (!isValidShortcutQuery(shortcut)) {
			filterRef.current?.focus();
			return;
		}
		onSave();
	}
	return /* @__PURE__ */ jsxs("form", {
		className: clsx("d-flex flex-column", ShortcutEditingHeader_module_default.gap_2),
		children: [
			errorMessage && /* @__PURE__ */ jsx(Flash, {
				variant: "danger",
				children: errorMessage
			}),
			/* @__PURE__ */ jsxs("div", {
				className: clsx("d-flex flex-items-start", ShortcutEditingHeader_module_default.gap_2),
				children: [/* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Icon" }), /* @__PURE__ */ jsx(IconAndColorPicker, {
					selectedColor: shortcut.color,
					selectedIcon: shortcut.icon,
					onApply: (color, icon) => {
						setShortcutValue("color", color);
						setShortcutValue("icon", icon);
					}
				})] }), /* @__PURE__ */ jsxs(FormControl$1, {
					required: true,
					className: "flex-grow-1 width-full",
					children: [
						/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Title" }),
						/* @__PURE__ */ jsx(TextInput$1, {
							autoFocus: true,
							ref: titleRef,
							className: "width-full",
							placeholder: "Title",
							value: shortcut.name,
							onChange: ({ target }) => {
								setHasInteractedWithTitle(true);
								setShortcutValue("name", target.value);
							}
						}),
						!isValidShortcutName(shortcut) && hasInteractedWithTitle && /* @__PURE__ */ jsx(FormControl$1.Validation, {
							variant: "error",
							children: "Title can not be empty"
						})
					]
				})]
			}),
			/* @__PURE__ */ jsxs(FormControl$1, { children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Description" }), /* @__PURE__ */ jsx(TextInput$1, {
				className: "width-full",
				placeholder: "Add a description",
				value: shortcut.description,
				onChange: ({ target: target_0 }) => setShortcutValue("description", target_0.value)
			})] }),
			/* @__PURE__ */ jsxs(FormControl$1, {
				required: true,
				children: [/* @__PURE__ */ jsx(FormControl$1.Label, { children: "Query" }), /* @__PURE__ */ jsxs("div", {
					className: clsx("d-flex flex-items-start width-full flex-wrap flex-lg-nowrap", ShortcutEditingHeader_module_default.gap_2),
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: clsx("d-flex flex-column width-full", ShortcutEditingHeader_module_default.gap_1),
							children: [renderFilter({
								inputRef: filterRef,
								className: "width-full"
							}), !isValidShortcutQuery(shortcut) && /* @__PURE__ */ jsx(FormControl$1.Validation, {
								variant: "error",
								children: "Query can not be empty"
							})]
						}),
						/* @__PURE__ */ jsx(ButtonComponent, {
							type: "button",
							onClick: onDismiss,
							disabled: isSaving,
							children: "Cancel"
						}),
						/* @__PURE__ */ jsx(ButtonComponent, {
							type: "button",
							variant: "primary",
							onClick: onSaveButtonClick,
							disabled: isSaving,
							children: isSaving ? "Saving..." : "Save view"
						})
					]
				})]
			})
		]
	});
}
ShortcutEditingHeader.displayName = "ShortcutEditingHeader";
var ShortcutOptionsButton_module_default = { notificationIndicator: "ShortcutOptionsButton-module_CwEFQa_notificationIndicator" };
function ShortcutOptionsButton({ onEditView, onDeleteView, onUpdateQueryView, isQueryModified = false }) {
	const ariaLabel = isQueryModified ? "Saved view menu (update available)" : "Saved view menu";
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
		icon: KebabHorizontalIcon,
		"aria-label": ariaLabel,
		variant: "invisible",
		className: isQueryModified ? ShortcutOptionsButton_module_default.notificationIndicator : void 0
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		width: "small",
		children: /* @__PURE__ */ jsxs(ActionList, { children: [
			isQueryModified && /* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: onUpdateQueryView,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(CheckIcon, {}) }), "Update view with current query"]
			}),
			/* @__PURE__ */ jsxs(ActionList.Item, {
				onSelect: onEditView,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(PencilIcon, {}) }), "Edit view"]
			}),
			/* @__PURE__ */ jsx(ActionList.Divider, {}),
			/* @__PURE__ */ jsxs(ActionList.Item, {
				variant: "danger",
				onSelect: onDeleteView,
				children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(TrashIcon, {}) }), "Delete"]
			})
		] })
	})] });
}
ShortcutOptionsButton.displayName = "ShortcutOptionsButton";
async function extractResponseErrorMessage(response, fallbackMessage) {
	try {
		return (await response.json())?.error?.message || fallbackMessage;
	} catch {
		return fallbackMessage;
	}
}
var defaultErrorMessage$1 = "Failed to delete shortcut";
/**
* Hook to manage deletion of user shortcuts (saved views).
*
* @param onShortcutDeleted Callback invoked after a shortcut is successfully deleted.
*
* @returns An object containing resources and methods for managing shortcut deletion.
*/
function useShortcutDeletion(onShortcutDeleted) {
	const $ = c(12);
	const confirm = useConfirm();
	let t0;
	if ($[0] !== onShortcutDeleted) {
		t0 = {
			mutationFn: _temp$1,
			onSuccess: onShortcutDeleted
		};
		$[0] = onShortcutDeleted;
		$[1] = t0;
	} else t0 = $[1];
	const deleteMutation = useMutation(t0);
	let t1;
	if ($[2] !== confirm || $[3] !== deleteMutation) {
		t1 = async function deleteShortcut(shortcut_0) {
			deleteMutation.reset();
			if (!await confirm({
				title: "Delete view",
				content: `Are you sure you want to delete view '${shortcut_0.name}'?`,
				confirmButtonContent: "Delete",
				confirmButtonType: "danger"
			})) return;
			deleteMutation.mutate(shortcut_0);
		};
		$[2] = confirm;
		$[3] = deleteMutation;
		$[4] = t1;
	} else t1 = $[4];
	const deleteShortcut = t1;
	const t2 = deleteMutation.error?.message;
	let t3;
	if ($[5] !== deleteMutation) {
		t3 = () => deleteMutation.reset();
		$[5] = deleteMutation;
		$[6] = t3;
	} else t3 = $[6];
	let t4;
	if ($[7] !== deleteMutation.isPending || $[8] !== deleteShortcut || $[9] !== t2 || $[10] !== t3) {
		t4 = {
			deleteShortcut,
			errorMessage: t2,
			isDeleting: deleteMutation.isPending,
			reset: t3
		};
		$[7] = deleteMutation.isPending;
		$[8] = deleteShortcut;
		$[9] = t2;
		$[10] = t3;
		$[11] = t4;
	} else t4 = $[11];
	return t4;
}
async function _temp$1(shortcut) {
	const response = await verifiedFetch(shortcutsPath(shortcut.id), { method: "DELETE" });
	if (!response.ok) throw new Error(await extractResponseErrorMessage(response, defaultErrorMessage$1));
	return shortcut;
}
var defaultErrorMessage = "Failed to save shortcut";
/**
* Hook for creating and editing user shortcuts (saved views). Designed to be used in conjunction with the
* `ShortcutEditingHeader` component.
*
* @param type The type of shortcut being used: one of 'repositories', 'issues' or 'pull-requests'.
* @param onShortcutSaved Callback invoked when a shortcut is successfully created or updated.
*
* @returns An object containing resources and methods for managing shortcut creation and editing.
*/
function useShortcutEditor(t0) {
	const $ = c(20);
	const { type, onShortcutSaved } = t0;
	const confirm = useConfirm();
	const [shortcut, setShortcut] = useState(void 0);
	const [isDirty, setIsDirty] = useState(false);
	const saveAndDismissMutation = useMutation({
		mutationFn: _temp,
		onSuccess: (savedShortcut_0) => {
			onShortcutSaved({
				...savedShortcut_0,
				source: "user"
			});
			doDismiss();
		}
	});
	let t1;
	if ($[0] !== saveAndDismissMutation || $[1] !== type) {
		t1 = function create(query, baseShortcut) {
			const newShortcut = {
				id: "",
				name: "",
				searchType: type,
				query,
				description: "",
				icon: "bookmark",
				color: "gray"
			};
			if (baseShortcut) {
				newShortcut.icon = baseShortcut.icon;
				newShortcut.color = baseShortcut.color;
			}
			setShortcut(newShortcut);
			setIsDirty(false);
			saveAndDismissMutation.reset();
		};
		$[0] = saveAndDismissMutation;
		$[1] = type;
		$[2] = t1;
	} else t1 = $[2];
	const create = t1;
	let t2;
	if ($[3] !== shortcut) {
		t2 = function edit(shortcutToEdit, query_0) {
			if (shortcut) throw new Error("A shortcut is already being edited. Cannot edit another one simultaneously.");
			setShortcut({
				...shortcutToEdit,
				query: query_0
			});
			setIsDirty(false);
		};
		$[3] = shortcut;
		$[4] = t2;
	} else t2 = $[4];
	const edit = t2;
	const dismiss = async function dismiss() {
		if (!(!isDirty || await confirm({
			title: "Discard changes",
			content: "Are you sure you want to discard changes?",
			confirmButtonContent: "Discard",
			confirmButtonType: "danger"
		}))) return false;
		doDismiss();
		return true;
	};
	function doDismiss() {
		setShortcut(void 0);
		saveAndDismissMutation.reset();
	}
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = function setValue(fieldName, value) {
			setShortcut((prevShortcut) => {
				if (!prevShortcut) throw new Error("No shortcut is being edited currently. Updating should not be possible.");
				return {
					...prevShortcut,
					[fieldName]: value
				};
			});
			setIsDirty(true);
		};
		$[5] = t3;
	} else t3 = $[5];
	const setValue = t3;
	let t4;
	if ($[6] !== saveAndDismissMutation || $[7] !== shortcut) {
		t4 = async function saveAndDismiss() {
			if (!shortcut) throw new Error("No shortcut is being edited currently. Saving should not be possible.");
			if (saveAndDismissMutation.isPending) return;
			if (!isValidShortcut(shortcut)) return;
			saveAndDismissMutation.mutate(shortcut);
		};
		$[6] = saveAndDismissMutation;
		$[7] = shortcut;
		$[8] = t4;
	} else t4 = $[8];
	const saveAndDismiss = t4;
	let t5;
	if ($[9] !== saveAndDismissMutation) {
		t5 = async function updateQuery(shortcutToUpdate, newQuery) {
			const updatedShortcut = {
				...shortcutToUpdate,
				query: newQuery
			};
			saveAndDismissMutation.mutate(updatedShortcut);
		};
		$[9] = saveAndDismissMutation;
		$[10] = t5;
	} else t5 = $[10];
	const updateQuery = t5;
	const t6 = saveAndDismissMutation.error?.message;
	let t7;
	if ($[11] !== create || $[12] !== dismiss || $[13] !== edit || $[14] !== saveAndDismiss || $[15] !== saveAndDismissMutation.isPending || $[16] !== shortcut || $[17] !== t6 || $[18] !== updateQuery) {
		t7 = {
			shortcut,
			setValue,
			create,
			edit,
			dismiss,
			saveAndDismiss,
			updateQuery,
			isSaving: saveAndDismissMutation.isPending,
			errorMessage: t6
		};
		$[11] = create;
		$[12] = dismiss;
		$[13] = edit;
		$[14] = saveAndDismiss;
		$[15] = saveAndDismissMutation.isPending;
		$[16] = shortcut;
		$[17] = t6;
		$[18] = updateQuery;
		$[19] = t7;
	} else t7 = $[19];
	return t7;
}
async function _temp(shortcutToSave) {
	const response = await verifiedFetchJSON(shortcutsPath(shortcutToSave.id), {
		method: shortcutToSave.id ? "PUT" : "POST",
		body: { view: shortcutToSave }
	});
	if (!response.ok) throw new Error(await extractResponseErrorMessage(response, defaultErrorMessage));
	return (await response.json()).shortcut;
}
var operators$2 = [
	">=",
	"<=",
	">",
	"<"
];
var StaticFilterProvider = class extends RootFilterProvider {
	filterValues;
	constructor(filterKey, filterValues, options) {
		super(filterKey, options);
		this.filterValues = filterValues.map((fv) => ({
			...fv,
			ariaLabel: `${fv.displayName}, ${this.displayName}`
		}));
	}
	getfilterKeys() {
		return [{
			key: this.key,
			aliases: this.aliases,
			displayName: this.displayName,
			description: this.description,
			priority: this.priority,
			icon: this.icon,
			options: this.options
		}];
	}
	getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		if (!this.shouldGetSuggestions(filterBlock)) return null;
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		const filterProviderKey = filterBlock.provider.key;
		const suggestions = [];
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.valueless && !filterBlock.raw.startsWith("-")) suggestions.push(getNoValueSuggestion(this.displayName, this.icon));
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.hasValue && !filterBlock.raw.startsWith("-")) suggestions.push(getHasValueSuggestion$1(this.displayName, this.icon));
		if (this.options.filterTypes.exclusive && lastValue === "" && isFilterBlock(filterBlock) && !filterBlock.raw.startsWith("-")) {
			const excludeKeySuggestion = getExcludeKeySuggestion(filterProviderKey);
			suggestions.unshift(excludeKeySuggestion);
		}
		if (!this.allowsFilterValues()) return suggestions;
		const inputOperator = operators$2.find((operator) => lastValue === operator || lastValue === `${operator}@`);
		if (!lastValue && !inputOperator) return suggestions.concat(this.filterValues);
		for (const filterValue of this.filterValues) {
			const { value: fValue, displayName } = filterValue;
			const value = getFilterValue(fValue);
			const suggestion = {
				...filterValue,
				type: FilterValueType.Value
			};
			const hasOperator = value && !operators$2.find((operator) => value.startsWith(operator));
			if (this.type === FilterProviderType.Date && hasOperator) suggestion.value = `${inputOperator ?? ""}${value}`;
			else {
				const matchesValue = !!value && hasMatch(lastValue, value);
				const matchesAlias = !!config.aliasMatching && filterValue.aliases && filterValue.aliases.some((alias) => hasMatch(lastValue, alias));
				const matchesDisplayName = !!displayName && hasMatch(lastValue, displayName);
				if (!value || !matchesValue && !matchesDisplayName && !matchesAlias) continue;
			}
			filterValue.priority -= fuzzyScore(lastValue, value);
			suggestions.push(suggestion);
		}
		return suggestions;
	}
	validateFilterBlockValues(filterQuery, block, values, _) {
		return values.map((v, i) => {
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			if (!this.options.filterTypes.multiValue && (block.operator === FilterOperator.Between && i > 1 || block.operator !== FilterOperator.Between && i > 0)) return getMultiValueValidation(v, this.key);
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!extractedValue) return getEmptyValueValidation(v, this.key);
			if (block.operator === FilterOperator.Between && operators$2.some((op) => extractedValue.startsWith(op))) return getInvalidValueValidation(v, extractedValue, this.key);
			return {
				...v,
				valid: true
			};
		});
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value)
		};
	}
};
var getMultiValueValidation = (blockValueItem, key) => {
	return {
		...blockValueItem,
		valid: false,
		validations: [{
			type: ValidationTypes.MultiValueUnsupported,
			message: Strings.filterMultiValueFalse(key)
		}]
	};
};
var getEmptyValueValidation = (blockValueItem, key) => {
	return {
		...blockValueItem,
		valid: false,
		validations: [{
			type: ValidationTypes.EmptyValue,
			message: Strings.filterValueEmpty(key)
		}]
	};
};
var getInvalidValueValidation = (blockValueItem, extractedValue, key) => {
	return {
		...blockValueItem,
		valid: false,
		validations: [{
			type: ValidationTypes.InvalidValue,
			message: Strings.filterInvalidValue(key, extractedValue)
		}]
	};
};
var BooleanFilterProvider = class extends StaticFilterProvider {
	constructor(filter, filterValues = TRUE_FALSE_FILTER_VALUES, options) {
		super(filter, filterValues, {
			...singleFilterProviderOptions,
			...options,
			filterTypes: {
				...singleFilterProviderOptions.filterTypes,
				...options?.filterTypes
			}
		});
		this.type = FilterProviderType.Boolean;
	}
	validateFilterBlockValues(filterQuery, block, values, config) {
		return values.map((v, i) => {
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			if (!this.options.filterTypes.multiValue && i > 0) return getMultiValueValidation(v, this.key);
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!extractedValue) return getEmptyValueValidation(v, this.key);
			const typeValidity = this.filterValues.find((fv) => {
				return getFilterValue(fv.value) === extractedValue || config?.aliasMatching && fv.aliases?.includes(extractedValue);
			}) !== void 0;
			const suggestion = this.filterValues.find((fv) => caseInsensitiveStringCompare(getFilterValue(fv.value) ?? "", extractedValue));
			if (suggestion) return {
				...v,
				...suggestion,
				valid: true,
				value: v.value
			};
			else return {
				...v,
				valid: typeValidity
			};
		});
	}
};
var ArchivedFilterProvider = class extends BooleanFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.archived, FILTER_VALUES.archived, {
			...options,
			filterTypes: {
				...options?.filterTypes,
				multiValue: false,
				valueless: false
			}
		});
	}
};
var DraftFilterProvider = class extends BooleanFilterProvider {
	constructor(options) {
		const defaultOptions = { filterTypes: {
			multiValue: false,
			valueless: false
		} };
		super(FILTER_KEYS.draft, FILTER_VALUES.draft, {
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
		this.type = FilterProviderType.Boolean;
	}
};
var DATE_REGEX = /^(?:>|<|>=|<=)?(\d{4}-\d{1,2}-\d{1,2})?$/;
var DATE_YEAR_MONTH_REGEX = /^(?:>|<|>=|<=)?(\d{4}-\d{1,2})?$/;
var DATE_YEAR_REGEX = /^(?:>|<|>=|<=)?(\d{4})?$/;
var DATE_TIME_REGEX = /^(?:>|<|>=|<=)?(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z?)$/;
var DATE_TIME_TZ_REGEX = /^(?:>|<|>=|<=)?(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+\d{2}:\d{2})$/;
var DYNAMIC_DATE_REGEX = /^(?:>|<|>=|<=)?(@[A-Za-z]+)([+-]\d+[mdwqy])?$/;
var operators$1 = [
	">=",
	"<=",
	">",
	"<"
];
var DateFilterProvider = class extends StaticFilterProvider {
	constructor(filterKey, filterValues, options) {
		super(filterKey, filterValues, {
			...defaultFilterProviderOptions,
			...options,
			filterTypes: {
				...defaultFilterProviderOptions.filterTypes,
				multiKey: false,
				multiValue: false,
				...options?.filterTypes
			}
		});
		this.type = FilterProviderType.Date;
		this.filterValues = filterValues.map((fv) => ({
			...fv,
			ariaLabel: `${fv.displayName}, ${this.displayName}`
		}));
	}
	validateFilterBlockValues(filterQuery, block, values, _) {
		return values.map((v, i) => {
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			if (!this.options.filterTypes.multiValue && (block.operator === FilterOperator.Between && i > 1 || block.operator !== FilterOperator.Between && i > 0)) return getMultiValueValidation(v, this.key);
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!extractedValue) return getEmptyValueValidation(v, this.key);
			if (block.operator === FilterOperator.Between && operators$1.some((op) => extractedValue.startsWith(op))) return getInvalidValueValidation(v, extractedValue, this.key);
			let typeValidity = true;
			if (extractedValue) if (extractedValue === "*") typeValidity = true;
			else if (DYNAMIC_DATE_REGEX.test(extractedValue)) {
				const [, date] = DYNAMIC_DATE_REGEX.exec(extractedValue) ?? [];
				typeValidity = this.filterValues.find((fv) => getFilterValue(fv.value) === date) !== void 0;
			} else {
				let date = null;
				if (DATE_TIME_TZ_REGEX.test(extractedValue)) date = DATE_TIME_TZ_REGEX.exec(extractedValue)?.[1] ?? null;
				else if (DATE_TIME_REGEX.test(extractedValue)) date = DATE_TIME_REGEX.exec(extractedValue)?.[1] ?? null;
				else if (DATE_REGEX.test(extractedValue)) date = DATE_REGEX.exec(extractedValue)?.[1] ?? null;
				else if (DATE_YEAR_MONTH_REGEX.test(extractedValue)) date = DATE_YEAR_MONTH_REGEX.exec(extractedValue)?.[1] ?? null;
				else if (DATE_YEAR_REGEX.test(extractedValue)) date = DATE_YEAR_REGEX.exec(extractedValue)?.[1] ?? null;
				typeValidity = date ? !isNaN(Date.parse(date)) : false;
			}
			return {
				...v,
				valid: typeValidity
			};
		});
	}
};
var ClosedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.closed, FILTER_VALUES.closed, options);
		this.type = FilterProviderType.Date;
	}
};
var CreatedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		const defaultOptions = { filterTypes: { valueless: false } };
		super(FILTER_KEYS.created, FILTER_VALUES.created, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
		this.type = FilterProviderType.Date;
	}
};
var MergedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		const opts = {
			...options,
			filterTypes: {
				...options?.filterTypes,
				multiValue: false
			}
		};
		super(FILTER_KEYS.merged, FILTER_VALUES.merged, opts);
		this.type = FilterProviderType.Date;
	}
};
var UpdatedFilterProvider = class extends DateFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.updated, FILTER_VALUES.updated, {
			...options,
			filterTypes: {
				hasValue: false,
				...options?.filterTypes
			}
		});
		this.type = FilterProviderType.Date;
	}
};
var FILTER_KEY_MAP = {
	[FilterValueType.HasValue]: FILTER_KEYS.has,
	[FilterValueType.NoValue]: FILTER_KEYS.no
};
var ValuePresenceFilterProvider = class extends RootFilterProvider {
	filterValues;
	constructor(filterValues, valueType, options) {
		const filterKey = FILTER_KEY_MAP[valueType];
		super(filterKey, options);
		this.options = {
			...defaultFilterProviderOptions,
			...options,
			filterTypes: {
				...defaultFilterProviderOptions.filterTypes,
				valueless: false,
				...options?.filterTypes
			}
		};
		this.type = FilterProviderType.Select;
		this.filterValues = filterValues.map((fv) => ({
			...fv,
			ariaLabel: `${fv.displayName}, ${this.displayName}`
		}));
	}
	getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		if (!this.shouldGetSuggestions(filterBlock)) return null;
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		const suggestions = [];
		if (!lastValue) return this.filterValues.filter((fv) => {
			return findExistingValueUsage(filterQuery, this.key, getUnescapedFilterValue(fv.value)).length < 1;
		});
		for (const filterValue of this.filterValues) {
			const { value: fValue, displayName } = filterValue;
			const value = getFilterValue(fValue);
			const matchesValue = !!value && hasMatch(lastValue, value);
			const matchesDisplayName = !!displayName && hasMatch(lastValue, displayName);
			if (findExistingValueUsage(filterQuery, this.key, getUnescapedFilterValue(value)).length > 0) continue;
			if (!value || !matchesValue && !matchesDisplayName) continue;
			filterValue.priority -= fuzzyScore(lastValue, value);
			suggestions.push({
				...filterValue,
				type: FilterValueType.Value
			});
		}
		return suggestions;
	}
	validateFilterBlockValues(filterQuery, block, values) {
		return values.map((v, i) => {
			const extractedValue = getFilterValue(v.value);
			const existingBlocks = findExistingValueUsage(filterQuery, this.key, getUnescapedFilterValue(extractedValue)).sort((a, b) => a.id - b.id);
			let valid = !!extractedValue && !!this.filterValues.find((fv) => caseInsensitiveStringCompare(getFilterValue(fv.value) ?? "", extractedValue));
			if (existingBlocks[0]?.id !== void 0 && (block.id !== existingBlocks[0].id || values.findIndex((val) => val.value === extractedValue) < i)) valid = false;
			return {
				...v,
				valid
			};
		});
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value)
		};
	}
};
var HasFilterProvider = class extends ValuePresenceFilterProvider {
	constructor(filterValues, options) {
		super(filterValues, FilterValueType.HasValue, options);
	}
};
var ISSUE_SUGGESTION_ENDPOINT = "/_filter/issues";
var ISSUE_VALIDATION_ENDPOINT = "/_filter/issues/validate";
var IssueState = {
	Open: "open",
	Closed: "closed"
};
var IssueStateReason = {
	NotPlanned: "not_planned",
	Completed: "completed",
	Reopened: "reopened",
	Duplicate: "duplicate"
};
var BaseIssueFilterProvider = class extends AsyncFilterProvider {
	constructor(filterKey, options) {
		super(filterKey, options);
		this.suggestionEndpoint = ISSUE_SUGGESTION_ENDPOINT;
		this.validationEndpoint = ISSUE_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	getIconData(issue) {
		if (issue.state === IssueState.Open) return {
			icon: IssueOpenedIcon,
			iconColor: "var(--fgColor-success, var(--color-success-fg))"
		};
		if (issue.stateReason === IssueStateReason.NotPlanned) return {
			icon: SkipIcon,
			iconColor: "var(-fgColor-muted, var(--color-neutral-emphasis))"
		};
		return {
			icon: IssueClosedIcon,
			iconColor: "var(--fgColor-done, var(--color-done-fg))"
		};
	}
	rankSuggestion(query, suggestion) {
		const { ariaLabel, description: nwoReference } = suggestion;
		const title = ariaLabel?.split(",")[0] ?? "";
		let priority = 3;
		if (query) {
			if (title) priority -= fuzzyScore(query, title);
			if (nwoReference) priority -= fuzzyScore(query, nwoReference);
		}
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(issue, query) {
		const { title, titleHtml, nwoReference } = issue;
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: title,
			displayNameHtml: titleHtml,
			ariaLabel: `${title}, ${this.displayName}`,
			description: nwoReference,
			inlineDescription: false,
			value: nwoReference ?? "",
			...this.getIconData(issue)
		});
	}
	validateValue(filterQuery, value, issue) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!extractedValue) return false;
		if (issue) return {
			displayName: issue.title,
			value: extractedValue
		};
		if (!filterQuery.context.repo && !filterQuery.context.org) return { value: INDETERMINANT };
		return false;
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon, true)
		};
	}
};
var ParentIssueFilterProvider = class extends BaseIssueFilterProvider {
	constructor(filterKey, options) {
		super(filterKey || FILTER_KEYS.parentIssue, options);
		this.providerContext = new URLSearchParams({ parent: "true" });
	}
};
var BlockingSearchFilterProvider = class extends BaseIssueFilterProvider {
	constructor(filterKey, options) {
		super(filterKey || FILTER_KEYS.blocking, {
			filterTypes: { hasValue: true },
			...options
		});
	}
};
var BlockedBySearchFilterProvider = class extends BaseIssueFilterProvider {
	constructor(filterKey, options) {
		super(filterKey || FILTER_KEYS.blockedBy, {
			filterTypes: { hasValue: true },
			...options
		});
	}
};
var KeyOnlyFilterProvider = class extends RootFilterProvider {
	constructor(filterKey, options) {
		super(filterKey, options);
		Object.assign(this, filterKey);
		this.key = filterKey.key;
		this.icon = filterKey.icon;
		this.displayName = filterKey.displayName ?? capitalize(filterKey.key);
		this.options = {
			...defaultFilterProviderOptions,
			...options,
			filterTypes: {
				...defaultFilterProviderOptions.filterTypes,
				multiValue: false,
				valueless: false,
				...options?.filterTypes
			}
		};
		this.priority = this.options.priority;
	}
	getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		if (!this.shouldGetSuggestions(filterBlock)) return null;
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		const filterProviderKey = filterBlock.provider.key;
		const suggestions = [];
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.valueless && !filterBlock.raw.startsWith("-")) suggestions.push(getNoValueSuggestion(this.displayName, this.icon));
		if (isEmptyFilterBlockValue(filterBlock) && this.options.filterTypes.hasValue && !filterBlock.raw.startsWith("-")) suggestions.push(getHasValueSuggestion$1(this.displayName, this.icon));
		if (this.options.filterTypes.exclusive && lastValue === "" && isFilterBlock(filterBlock) && !filterBlock.raw.startsWith("-")) {
			const excludeKeySuggestion = getExcludeKeySuggestion(filterProviderKey);
			suggestions.unshift(excludeKeySuggestion);
		}
		return suggestions;
	}
	validateFilterBlockValues(filterQuery, block, values) {
		return values.map((value) => {
			return {
				...value,
				valid: true
			};
		});
	}
	getValueRowProps() {
		return { text: "" };
	}
};
var BaseFilterProvider = class extends KeyOnlyFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.base, options);
	}
};
var HeadFilterProvider = class extends KeyOnlyFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.head, options);
	}
};
var ShaFilterProvider = class extends KeyOnlyFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.sha, options);
	}
};
var LABEL_SUGGESTIONS_ENDPOINT = "/_filter/labels";
var LABEL_VALIDATION_ENDPOINT = "/_filter/labels/validate";
var LabelFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.label, options);
		this.suggestionEndpoint = LABEL_SUGGESTIONS_ENDPOINT;
		this.validationEndpoint = LABEL_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.processSuggestion.bind(this), caretIndex);
	}
	getIconData(label, context) {
		if (!context["repo"]) return { icon: this.icon };
		else return {
			iconColor: label.color?.startsWith("#") ? label.color : `#${label.color}`,
			description: label.description,
			inlineDescription: false
		};
	}
	rankSuggestion(query, suggestion) {
		const { value } = suggestion;
		const name = getUnescapedFilterValue(value) || "";
		let priority = 3;
		if (query && name) priority -= fuzzyScore(query, name);
		return {
			...suggestion,
			priority
		};
	}
	processSuggestion(label, query, filterQuery) {
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: label.name,
			displayNameHtml: label.nameHtml,
			ariaLabel: `${label.name}, ${this.displayName}`,
			value: label.name ?? "",
			...this.getIconData(label, filterQuery.context)
		});
	}
	validateValue(filterQuery, value, label) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!extractedValue) return false;
		if (label) return {
			iconColor: label.color?.startsWith("#") ? label.color : `#${label.color}`,
			value: extractedValue,
			displayName: label.name,
			...this.getIconData(label, filterQuery.context)
		};
		if (!filterQuery.context.repo) return { value: INDETERMINANT };
		return false;
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon)
		};
	}
};
var LANGUAGE_SUGGESTION_ENDPOINT = "/_filter/languages";
var LANGUAGE_VALIDATION_ENDPOINT = "/_filter/languages/validate";
var LanguageFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.language, options);
		this.suggestionEndpoint = LANGUAGE_SUGGESTION_ENDPOINT;
		this.validationEndpoint = LANGUAGE_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	rankSuggestion(query, suggestion) {
		const name = getUnescapedFilterValue(suggestion.value);
		let priority = 3;
		if (query && name) priority -= fuzzyScore(query, name);
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(language, query) {
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: language.name,
			ariaLabel: `${language.name}, ${this.displayName}`,
			value: language.name ?? "",
			iconColor: language.color?.startsWith("#") ? language.color : `#${language.color}`
		});
	}
	validateValue(filterQuery, value, language) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!language || !extractedValue) return false;
		return {
			iconColor: language.color?.startsWith("#") ? language.color : `#${language.color}`,
			value: extractedValue,
			displayName: language.name
		};
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon)
		};
	}
};
var MILESTONE_SUGGESTION_ENDPOINT = "/_filter/milestones";
var MILESTONE_VALIDATION_ENDPOINT = "/_filter/milestones/validate";
var MilestoneFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.milestone, options);
		this.suggestionEndpoint = MILESTONE_SUGGESTION_ENDPOINT;
		this.validationEndpoint = MILESTONE_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	rankSuggestion(query, suggestion) {
		const title = getUnescapedFilterValue(suggestion.value);
		let priority = 3;
		if (query && title) priority -= fuzzyScore(query, title);
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(milestone, query) {
		const { id, title, description } = milestone;
		return this.rankSuggestion(query, {
			id,
			type: FilterValueType.Value,
			displayName: title,
			ariaLabel: `${title}, ${this.displayName}`,
			value: title,
			description,
			inlineDescription: false,
			icon: this.icon
		});
	}
	validateValue(filterQuery, value, milestone) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!extractedValue) return false;
		if (milestone) return {
			value: extractedValue,
			displayName: milestone.title,
			description: milestone.description
		};
		if (!filterQuery.context.repo && !filterQuery.context.org) return { value: INDETERMINANT };
		return false;
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon, true)
		};
	}
};
var POSITIVE_NUMBER_REGEX = /^(?!-)(?:>|<|>=|<=)?(\d+)$/;
var NEGATIVE_NUMBER_REGEX = /^(?:>|<|>=|<=)?-(\d+)$/;
var POSITIVE_DECIMAL_NUMBER_REGEX = /^(?:>|<|>=|<=)?(\d+\.\d+|\d+)$/;
var NEGATIVE_DECIMAL_NUMBER_REGEX = /^(?:>|<|>=|<=)?-(\d+\.\d+|\d+)$/;
var operators = [
	">=",
	"<=",
	">",
	"<"
];
var NumericFilterProvider = class extends StaticFilterProvider {
	positive;
	negative;
	decimal;
	constructor(filterKey, filterValues, options) {
		super(filterKey, filterValues, {
			...defaultFilterProviderOptions,
			...options,
			filterTypes: {
				...defaultFilterProviderOptions.filterTypes,
				valueless: false,
				exclusive: false,
				multiKey: false,
				multiValue: false,
				...options?.filterTypes
			}
		});
		this.positive = options?.positive ?? true;
		this.negative = options?.negative ?? false;
		this.decimal = options?.decimal ?? false;
		this.filterValues = filterValues.map((fv) => ({
			...fv,
			ariaLabel: `${fv.displayName}, ${this.displayName}`
		}));
		this.type = FilterProviderType.Number;
	}
	validateFilterBlockValues(filterQuery, block, values) {
		return values.map((v, i) => {
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			if (!this.options.filterTypes.multiValue && (block.operator === FilterOperator.Between && i > 1 || block.operator !== FilterOperator.Between && i > 0)) return getMultiValueValidation(v, this.key);
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!extractedValue) return getEmptyValueValidation(v, this.key);
			if (block.operator === FilterOperator.Between && operators.some((op) => extractedValue.startsWith(op))) return getInvalidValueValidation(v, extractedValue, this.key);
			let isPositiveNumber = false;
			let isNegativeNumber = false;
			let isDecimalNumber = false;
			if (this.decimal) {
				const positiveDecimalMatch = extractedValue.match(POSITIVE_DECIMAL_NUMBER_REGEX);
				isPositiveNumber = (positiveDecimalMatch?.length ?? 0) > 0 && positiveDecimalMatch?.[0] === extractedValue;
				isDecimalNumber = isPositiveNumber && extractedValue.includes(".");
			} else {
				const positiveMatch = extractedValue.match(POSITIVE_NUMBER_REGEX);
				isPositiveNumber = (positiveMatch?.length ?? 0) > 0 && positiveMatch?.[0] === extractedValue;
			}
			if (this.decimal) {
				const negativeDecimalMatch = extractedValue.match(NEGATIVE_DECIMAL_NUMBER_REGEX);
				isNegativeNumber = (negativeDecimalMatch?.length ?? 0) > 0 && negativeDecimalMatch?.[0] === extractedValue;
				if (isNegativeNumber && extractedValue.includes(".")) isDecimalNumber = true;
			} else {
				const negativeMatch = extractedValue.match(NEGATIVE_NUMBER_REGEX);
				isNegativeNumber = (negativeMatch?.length ?? 0) > 0 && negativeMatch?.[0] === extractedValue;
			}
			const isValidNumberFormat = isPositiveNumber || isNegativeNumber;
			const isValidSign = this.positive && isPositiveNumber || this.negative && isNegativeNumber;
			const isValidDecimal = this.decimal || !isDecimalNumber;
			const typeValidity = isValidNumberFormat && isValidSign && isValidDecimal;
			return {
				...v,
				valid: typeValidity
			};
		});
	}
};
var CommentsFilterProvider = class extends NumericFilterProvider {
	constructor(options) {
		const defaultOptions = { filterTypes: {
			multiValue: false,
			valueless: false
		} };
		super(FILTER_KEYS.comments, FILTER_VALUES.comments, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
	}
};
var InteractionsFilterProvider = class extends NumericFilterProvider {
	constructor(options) {
		const defaultOptions = { filterTypes: {
			multiValue: false,
			valueless: false
		} };
		super(FILTER_KEYS.interactions, FILTER_VALUES.interactions, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
	}
};
var ReactionsFilterProvider = class extends NumericFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.reactions, FILTER_VALUES.reactions, {
			...options,
			filterTypes: {
				multiValue: false,
				valueless: false,
				...options?.filterTypes
			}
		});
	}
};
var SelectFilterProvider = class extends StaticFilterProvider {
	strictMatching;
	constructor(filterKey, filterValues, options) {
		super(filterKey, filterValues, options);
		this.filterValues = filterValues.map((fv) => ({
			...fv,
			ariaLabel: `${fv.displayName}, ${this.displayName}`
		}));
		this.strictMatching = options?.strictMatching ?? true;
		this.type = this.strictMatching ? FilterProviderType.Select : FilterProviderType.Text;
	}
	validateFilterBlockValues(filterQuery, block, values, config) {
		return values.map((v, i) => {
			if (!this.allowsFilterValues()) return {
				...v,
				valid: false,
				validations: [{
					type: ValidationTypes.InvalidValue,
					message: Strings.filterValuesUnsupported(this.key)
				}]
			};
			if (!this.options.filterTypes.multiValue && i > 0) return getMultiValueValidation(v, this.key);
			const extractedValue = getUnescapedFilterValue(v.value);
			if (!extractedValue) return getEmptyValueValidation(v, this.key);
			const typeValidity = this.filterValues.find((fv) => {
				return getFilterValue(fv.value) === extractedValue || config?.aliasMatching && fv.aliases?.includes(extractedValue);
			}) !== void 0;
			const suggestion = this.filterValues.find((fv) => caseInsensitiveStringCompare(getFilterValue(fv.value) ?? "", extractedValue));
			if (suggestion) return {
				...v,
				...suggestion,
				valid: true,
				value: v.value
			};
			else return {
				...v,
				valid: this.strictMatching ? typeValidity : true
			};
		});
	}
};
var IsFilterProvider = class extends SelectFilterProvider {
	constructor(valueIds, options) {
		const values = valueIds?.map((id) => IS_FILTER_PROVIDER_VALUES[id]).filter(Boolean) ?? [];
		const defaultOptions = { filterTypes: { valueless: false } };
		super(FILTER_KEYS.is, values?.length > 0 ? values : FILTER_VALUES.is, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				hasValue: false,
				...options?.filterTypes
			}
		});
	}
};
var InFilterProvider = class extends SelectFilterProvider {
	constructor(valueIds, options) {
		const values = valueIds?.map((id) => IN_FILTER_PROVIDER_VALUES[id]).filter(Boolean) ?? [];
		const defaultOptions = { filterTypes: {
			valueless: false,
			multiValue: true
		} };
		super(FILTER_KEYS.in, values?.length > 0 ? values : FILTER_VALUES.in, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
	}
};
var LinkedFilterProvider = class extends SelectFilterProvider {
	constructor(valueIds, options) {
		const opts = {
			...options,
			filterTypes: {
				...options?.filterTypes,
				multiValue: false,
				valueless: false
			}
		};
		const values = valueIds?.map((id) => LINKED_FILTER_PROVIDER_VALUES[id]).filter(Boolean) ?? [];
		super(FILTER_KEYS.linked, values?.length > 0 ? values : FILTER_VALUES.linked, opts);
	}
};
var ReasonFilterProvider = class extends SelectFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.reason, FILTER_VALUES.reason, {
			...options,
			filterTypes: {
				hasValue: false,
				...options?.filterTypes
			}
		});
	}
};
var ReviewFilterProvider = class extends SelectFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.review, FILTER_VALUES.review, options);
	}
};
var SortFilterProvider = class extends SelectFilterProvider {
	constructor(valueIds, options) {
		const sortValues = valueIds.map((id) => SORT_FILTER_PROVIDER_VALUES[id]).flat().filter(Boolean) ?? [];
		const reactionValues = valueIds?.includes("reactions") ? SORT_REACTIONS_FILTER_PROVIDER_VALUES : [];
		const values = [...sortValues, ...reactionValues];
		super(FILTER_KEYS.sort, values?.length > 0 ? values : FILTER_VALUES.sort, options);
	}
};
var StateFilterProvider = class extends SelectFilterProvider {
	stateContext;
	constructor(type = "mixed", options) {
		const values = getFilterValuesByStateType(type);
		const defaultOptions = { filterTypes: { valueless: false } };
		super(FILTER_KEYS.state, values, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				hasValue: false,
				...options?.filterTypes
			}
		});
		this.stateContext = type;
	}
};
var StatusFilterProvider = class extends SelectFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.status, FILTER_VALUES.status, options);
	}
};
var subKeyIcons = {
	boolean: CheckCircleIcon,
	select: SingleSelectIcon,
	text: TypographyIcon,
	date: CalendarIcon,
	number: NumberIcon
};
var NestedFilterProvider = class {
	subKeys;
	filterProviders;
	constructor(filterKey, options) {
		const { subKeys, ...rest } = filterKey;
		this.subKeys = subKeys;
		this.filterProviders = subKeys.map((subKey) => {
			const subKeyObject = {
				...subKey,
				type: subKey.type,
				key: `${rest.key}.${subKey.key}`,
				displayName: subKey.displayName ?? subKey.key,
				description: subKey.description,
				priority: 10,
				icon: subKey.icon ?? subKeyIcons[subKey.type]
			};
			if (subKey.type === FilterProviderType.Boolean) return new BooleanFilterProvider(subKeyObject, void 0, options);
			else if (subKey.type === FilterProviderType.Select) return new SelectFilterProvider(subKeyObject, subKey.values, {
				...subKey.options,
				filterTypes: {
					...defaultFilterProviderOptions.filterTypes,
					...subKey.options?.filterTypes
				}
			});
			else if (subKey.type === FilterProviderType.Text) return new KeyOnlyFilterProvider(subKeyObject, subKey.options);
			else if (subKey.type === FilterProviderType.Date) return new DateFilterProvider(subKeyObject, subKey.values || [], {
				...subKey.options,
				filterTypes: {
					...defaultFilterProviderOptions.filterTypes,
					...subKey.options?.filterTypes
				}
			});
			else if (subKey.type === FilterProviderType.Number) return new NumericFilterProvider(subKeyObject, subKey.values || [], {
				...subKey.options,
				filterTypes: {
					...defaultFilterProviderOptions.filterTypes,
					...subKey.options?.filterTypes
				}
			});
			else {
				const staticFilterProvider = new StaticFilterProvider(subKeyObject, subKey.values || [], {
					...subKey.options,
					filterTypes: {
						...defaultFilterProviderOptions.filterTypes,
						...subKey.options?.filterTypes
					}
				});
				staticFilterProvider.type = subKeyObject.type;
				return staticFilterProvider;
			}
		});
		this.filterProviders.push(new StaticFilterProvider({
			...rest,
			key: `${rest.key}.`
		}, [], options));
	}
};
var PROJECT_SUGGESTION_ENDPOINT = "/_filter/projects";
var PROJECT_VALIDATION_ENDPOINT = "/_filter/projects/validate";
var ProjectFilterProvider = class extends AsyncFilterProvider {
	constructor(options) {
		super(FILTER_KEYS.project, options);
		this.suggestionEndpoint = PROJECT_SUGGESTION_ENDPOINT;
		this.validationEndpoint = PROJECT_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	rankSuggestion(query, suggestion) {
		const { description: url, displayName: title } = suggestion;
		let priority = 3;
		if (query) {
			if (title) priority -= fuzzyScore(query, title);
			if (url) priority -= fuzzyScore(query, url);
		}
		return {
			...suggestion,
			priority
		};
	}
	#processSuggestion(project, query) {
		const { title, value: url } = project;
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: title,
			ariaLabel: `${title}, ${this.displayName}`,
			value: escapeString(url) ?? "",
			description: url,
			inlineDescription: false
		});
	}
	validateValue(filterQuery, value, project) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!extractedValue) return false;
		if (project) return {
			displayName: project.title,
			value: extractedValue
		};
		if (!filterQuery.context.repo && !filterQuery.context.org) return { value: INDETERMINANT };
		return false;
	}
	getValueRowProps(value) {
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "block"
		};
	}
};
var TEAM_SUGGESTION_ENDPOINT = "/_filter/teams";
var TEAM_VALIDATION_ENDPOINT = "/_filter/teams/validate";
var BaseTeamFilterProvider = class extends AsyncFilterProvider {
	constructor(filterKey, staticScope, options) {
		super(filterKey, options);
		this.suggestionEndpoint = TEAM_SUGGESTION_ENDPOINT;
		this.validationEndpoint = TEAM_VALIDATION_ENDPOINT;
		this.type = FilterProviderType.Select;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		return this.processSuggestions(filterQuery, filterBlock, this.#processSuggestion.bind(this), caretIndex);
	}
	#processSuggestion(team, query) {
		const { name, combinedSlug, avatarUrl } = team;
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			displayName: name,
			value: escapeString(combinedSlug) ?? "",
			ariaLabel: `${name}, ${this.displayName}`,
			description: combinedSlug,
			inlineDescription: true,
			icon: !avatarUrl ? this.icon : void 0,
			avatar: avatarUrl ? {
				url: avatarUrl,
				type: AvatarType.Team
			} : void 0
		});
	}
	rankSuggestion(query, suggestion) {
		const { displayName: name, description: combinedSlug } = suggestion;
		let priority = 3;
		if (query) {
			if (name) priority -= fuzzyScore(query, name);
			if (combinedSlug) priority -= fuzzyScore(query, combinedSlug);
		}
		return {
			...suggestion,
			priority
		};
	}
	validateValue(filterQuery, value, team) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (!extractedValue) return false;
		if (team) return {
			avatar: team.avatarUrl ? {
				url: team.avatarUrl,
				type: AvatarType.Team
			} : void 0,
			value: extractedValue,
			displayName: team.name
		};
		if (!filterQuery.context.repo && !filterQuery.context.org) return { value: INDETERMINANT };
		return false;
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "inline",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon)
		};
	}
};
var TeamFilterProvider = class extends BaseTeamFilterProvider {
	constructor(repositoryScope, options) {
		super(FILTER_KEYS.team, repositoryScope, options);
	}
};
var TeamReviewRequestedFilterProvider = class extends BaseTeamFilterProvider {
	constructor(repositoryScope, options) {
		super(FILTER_KEYS.teamReviewRequested, repositoryScope, options);
	}
};
var USER_SUGGESTION_ENDPOINT = "/_filter/users";
var USER_VALIDATION_ENDPOINT = "/_filter/users/validate";
var AT_ME_VALUE = "@me";
var AT_COPILOT_VALUE = "@copilot";
var AT_ME_SUGGESTION = {
	type: FilterValueType.Value,
	value: AT_ME_VALUE,
	ariaLabel: `${AT_ME_VALUE}, Signed-in user`,
	displayName: "Me",
	description: "Signed-in user",
	inlineDescription: true,
	priority: 1,
	icon: ArrowSwitchIcon,
	iconColor: "var(--fgColor-done, var(--color-done-fg))"
};
var getCopilotSuggestion = (displayName, avatarUrl) => ({
	type: FilterValueType.Value,
	value: AT_COPILOT_VALUE,
	ariaLabel: `${AT_COPILOT_VALUE}, Your AI pair programmer`,
	displayName,
	description: "Your AI pair programmer",
	inlineDescription: true,
	priority: 1,
	icon: CopilotIcon,
	avatarUrl: avatarUrl ? {
		url: avatarUrl,
		type: AvatarType.User
	} : void 0,
	iconColor: "var(--fgColor-done, var(--color-done-fg))"
});
var WILDCARD_HAS_VALUE = "*";
var getHasValueSuggestion = (displayName) => ({
	type: FilterValueType.Value,
	value: WILDCARD_HAS_VALUE,
	displayName: `Has ${displayName.toLocaleLowerCase()}`,
	ariaLabel: `Has ${displayName}, ${displayName}`,
	priority: 1,
	icon: PlusCircleIcon
});
var BaseUserFilterProvider = class extends AsyncFilterProvider {
	showAtMe;
	showAtCopilot;
	currentUserLogin;
	currentUserAvatarUrl;
	includeBots;
	copilotQueryParamKey;
	constructor(filterKey, filterParams, options) {
		super(filterKey, options);
		this.suggestionEndpoint = USER_SUGGESTION_ENDPOINT;
		this.validationEndpoint = USER_VALIDATION_ENDPOINT;
		this.currentUserLogin = filterParams?.currentUserLogin;
		this.currentUserAvatarUrl = filterParams?.currentUserAvatarUrl;
		this.includeBots = filterParams?.includeBots ?? false;
		this.type = FilterProviderType.User;
		this.showAtMe = filterParams?.showAtMe ?? true;
		this.showAtCopilot = filterParams?.showAtCopilot ?? false;
	}
	async getSuggestions(filterQuery, filterBlock, config, caretIndex) {
		if (this.includeBots) filterQuery.addQueryParam("include_bots", "1");
		if (this.copilotQueryParamKey) filterQuery.addQueryParam(this.copilotQueryParamKey, "1");
		const suggestions = await this.processSuggestions(filterQuery, filterBlock, this.processSuggestion.bind(this), caretIndex) ?? [];
		const lastValue = getLastFilterBlockValue(filterBlock, caretIndex);
		let spliceIndex = suggestions[0]?.type === FilterValueType.NoValue ? 1 : 0;
		if (this.showAtMe && (lastValue === "" || hasMatch(lastValue, AT_ME_VALUE)) && isFilterBlock(filterBlock) && filterBlock.value?.values.findIndex((v) => v.value === AT_ME_VALUE) < 0 && this.allowsFilterValues()) {
			suggestions.splice(spliceIndex, 0, AT_ME_SUGGESTION);
			spliceIndex++;
		}
		if ((lastValue === "" || hasMatch(lastValue, "@copilot")) && isFilterBlock(filterBlock) && filterBlock.value?.values.findIndex((v) => v.value === "@copilot") < 0 && this.allowsFilterValues()) {
			const copilotIndex = suggestions.findIndex((v) => v.value === AT_COPILOT_VALUE);
			if (copilotIndex > -1) {
				const [copilotSuggestion] = suggestions.splice(copilotIndex, 1);
				if (this.showAtCopilot && copilotSuggestion) {
					suggestions.splice(spliceIndex, 0, copilotSuggestion);
					spliceIndex++;
				}
			}
		}
		return suggestions;
	}
	processSuggestion(user, query) {
		const { login, name, avatarUrl, isCopilot } = user;
		if (isCopilot) return getCopilotSuggestion(login, avatarUrl);
		return this.rankSuggestion(query, {
			type: FilterValueType.Value,
			value: login,
			ariaLabel: `${login}, ${name}, ${this.displayName}`,
			description: name,
			inlineDescription: true,
			icon: !avatarUrl ? this.icon : void 0,
			avatar: avatarUrl ? {
				url: avatarUrl,
				type: AvatarType.User
			} : void 0
		});
	}
	rankSuggestion(query, suggestion) {
		const { value, description: name } = suggestion;
		const login = getUnescapedFilterValue(value);
		let priority = 3;
		if (query) {
			const loginWeighting = .75;
			if (login) {
				const loginScore = fuzzyScore(query, login);
				priority -= (loginScore !== -Infinity ? loginScore : 1) * loginWeighting;
			}
			if (name) {
				const nameScore = fuzzyScore(query, name);
				priority -= (nameScore !== -Infinity ? nameScore : 1) * (1 - loginWeighting);
			}
		}
		if (login === AT_ME_VALUE) priority = 1;
		return {
			...suggestion,
			priority
		};
	}
	getMetaSuggestions(value) {
		const suggestions = [];
		if (this.showAtMe && AT_ME_VALUE.startsWith(value)) suggestions.push(AT_ME_SUGGESTION);
		if (this.options.filterTypes.hasValue && WILDCARD_HAS_VALUE.startsWith(value)) suggestions.push(getHasValueSuggestion(this.displayName));
		return suggestions;
	}
	validateValue(filterQuery, value, user) {
		const extractedValue = getUnescapedFilterValue(value.value);
		if (extractedValue === AT_ME_VALUE) return {
			avatar: this.currentUserAvatarUrl ? {
				url: this.currentUserAvatarUrl,
				type: AvatarType.User
			} : void 0,
			value: extractedValue
		};
		if (this.options.filterTypes.hasValue && extractedValue === WILDCARD_HAS_VALUE) return {
			avatar: void 0,
			value: extractedValue
		};
		if (user && this.showAtCopilot && extractedValue === "@copilot") return {
			avatar: void 0,
			value: extractedValue
		};
		if (user && extractedValue) return {
			avatar: user.avatarUrl ? {
				url: user.avatarUrl,
				type: AvatarType.User
			} : void 0,
			value: extractedValue,
			displayName: user.name
		};
		if (!filterQuery.context.repo && !filterQuery.context.org) return { value: INDETERMINANT };
		return false;
	}
	validateFilterValue(value, fetchParams, filterQuery) {
		const params = new URLSearchParams(fetchParams);
		if (this.copilotQueryParamKey) params.append(this.copilotQueryParamKey, "1");
		return super.validateFilterValue(value, params, filterQuery);
	}
	getValueRowProps(value) {
		const customLeadingVisual = this.options.renderValueVisual?.(value);
		return {
			text: value.displayName ?? getFilterValue(value.value) ?? "",
			description: value.description,
			descriptionVariant: "inline",
			leadingVisual: this.options.renderValueVisual ? customLeadingVisual ?? null : getDefaultValueVisualDescriptors(value, this.icon)
		};
	}
};
var AssigneeFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.assignee, filterParams, options);
		this.copilotQueryParamKey = filterParams?.showAtCopilot ? "show_assignee_copilot" : void 0;
	}
};
var AuthorFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		const defaultOptions = { filterTypes: {
			multiValue: false,
			valueless: false
		} };
		super(USER_FILTERS.author, {
			...filterParams,
			includeBots: true
		}, {
			...defaultOptions,
			...options,
			filterTypes: {
				...defaultOptions.filterTypes,
				...options?.filterTypes
			}
		});
		this.copilotQueryParamKey = filterParams?.showAtCopilot ? "show_author_copilot" : void 0;
	}
};
var CommenterFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.commenter, filterParams, options);
	}
};
var InvolvesFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.involves, filterParams, options);
		this.copilotQueryParamKey = filterParams?.showAtCopilot ? "show_involves_copilot" : void 0;
	}
};
var MentionsFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.mentions, filterParams, options);
	}
};
var ReviewedByFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.reviewedBy, filterParams, options);
		this.copilotQueryParamKey = filterParams?.showAtCopilot ? "show_pull_request_reviewer_copilot" : void 0;
	}
};
var ReviewRequestedFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.reviewRequested, filterParams, options);
		this.copilotQueryParamKey = filterParams?.showAtCopilot ? "show_pull_request_reviewer_copilot" : void 0;
	}
};
var UserFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.user, filterParams, options);
	}
};
var UserReviewRequestedFilterProvider = class extends BaseUserFilterProvider {
	constructor(filterParams, options) {
		super(USER_FILTERS.userReviewRequested, filterParams, options);
	}
};
export { useShortcutEditor as $, ReactionsFilterProvider as A, StateFilterProvider as B, MentionsFilterProvider as C, NumericFilterProvider as D, NestedFilterProvider as E, SelectFilterProvider as F, UpdatedFilterProvider as G, StatusFilterProvider as H, ShaFilterProvider as I, ValuePresenceFilterProvider as J, UserFilterProvider as K, ShortcutEditingHeader as L, ReviewFilterProvider as M, ReviewRequestedFilterProvider as N, ParentIssueFilterProvider as O, ReviewedByFilterProvider as P, useShortcutDeletion as Q, ShortcutOptionsButton as R, LinkedFilterProvider as S, MilestoneFilterProvider as T, TeamFilterProvider as U, StaticFilterProvider as V, TeamReviewRequestedFilterProvider as W, getIconComponent as X, getIconColorClassName as Y, getShortcutsWithSaved as Z, InteractionsFilterProvider as _, BlockedBySearchFilterProvider as a, LabelFilterProvider as b, ClosedFilterProvider as c, CreatedFilterProvider as d, DateFilterProvider as f, InFilterProvider as g, HeadFilterProvider as h, BaseFilterProvider as i, ReasonFilterProvider as j, ProjectFilterProvider as k, CommenterFilterProvider as l, HasFilterProvider as m, AssigneeFilterProvider as n, BlockingSearchFilterProvider as o, DraftFilterProvider as p, UserReviewRequestedFilterProvider as q, AuthorFilterProvider as r, BooleanFilterProvider as s, ArchivedFilterProvider as t, CommentsFilterProvider as u, InvolvesFilterProvider as v, MergedFilterProvider as w, LanguageFilterProvider as x, IsFilterProvider as y, SortFilterProvider as z };
