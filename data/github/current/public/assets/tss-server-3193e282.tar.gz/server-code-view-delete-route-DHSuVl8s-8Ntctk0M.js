import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
var codeViewDeleteRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewDeleteRoute", {
	path: "/:owner/:repo/delete/:branch/*",
	queries: [mainQuery({ encodeFetchPath: true })]
});
export { codeViewDeleteRoute as t };
