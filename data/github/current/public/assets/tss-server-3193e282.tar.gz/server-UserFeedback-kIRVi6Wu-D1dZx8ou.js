import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { O as CheckIcon, bn as Link, li as ThumbsdownIcon, pi as Tooltip$1, tt as CopyIcon, ui as ThumbsupIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { useEffect, useImperativeHandle, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var UserFeedback_module_default = {
	bodyContainer: "UserFeedback-module_D0Lzgq_bodyContainer",
	copyLogsSuccessIcon: "UserFeedback-module_D0Lzgq_copyLogsSuccessIcon",
	Dialog: "UserFeedback-module_D0Lzgq_Dialog",
	footerActionButtonGroup: "UserFeedback-module_D0Lzgq_footerActionButtonGroup",
	footerContainer: "UserFeedback-module_D0Lzgq_footerContainer",
	messageContainer: "UserFeedback-module_D0Lzgq_messageContainer",
	privacyText: "UserFeedback-module_D0Lzgq_privacyText",
	ratingButton: "UserFeedback-module_D0Lzgq_ratingButton",
	ratingCaption: "UserFeedback-module_D0Lzgq_ratingCaption",
	ratingContainer: "UserFeedback-module_D0Lzgq_ratingContainer",
	ratingOption: "UserFeedback-module_D0Lzgq_ratingOption",
	thumbsDownIcon: "UserFeedback-module_D0Lzgq_thumbsDownIcon",
	thumbsUpIcon: "UserFeedback-module_D0Lzgq_thumbsUpIcon",
	validationError: "UserFeedback-module_D0Lzgq_validationError"
};
var UserFeedbackColors_module_default = {
	bad: "UserFeedbackColors-module_pAqxEG_bad",
	dissatisfied: "UserFeedbackColors-module_pAqxEG_dissatisfied",
	good: "UserFeedbackColors-module_pAqxEG_good",
	satisfied: "UserFeedbackColors-module_pAqxEG_satisfied",
	veryDissatisfied: "UserFeedbackColors-module_pAqxEG_veryDissatisfied",
	verySatisfied: "UserFeedbackColors-module_pAqxEG_verySatisfied"
};
function UserFeedback(t0) {
	const $ = c(43);
	const { title: t1, requestID, options, returnFocusRef, placeholderText: t2, onSubmit, onClose, ref } = t0;
	const title = t1 === void 0 ? "Give feedback" : t1;
	const placeholderText = t2 === void 0 ? "Tell us what you liked or what could be better" : t2;
	const [selectedRating, setSelectedRating] = useState(null);
	const [feedbackText, setFeedbackText] = useState("");
	let t3;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = [];
		$[0] = t3;
	} else t3 = $[0];
	const [errors, setErrors] = useState(t3);
	const [errorKey, setErrorKey] = useState(0);
	const [isOpen, setIsOpen] = useState(false);
	const [copiedLogs, setCopiedLogs] = useState(false);
	let t4;
	if ($[1] !== errors.length) {
		t4 = () => {
			if (errors.length > 0) setErrorKey(_temp);
		};
		$[1] = errors.length;
		$[2] = t4;
	} else t4 = $[2];
	let t5;
	if ($[3] !== errors) {
		t5 = [errors];
		$[3] = errors;
		$[4] = t5;
	} else t5 = $[4];
	useEffect(t4, t5);
	let t6;
	if ($[5] !== options) {
		t6 = () => ({ openDialog: (initialOptionValue) => {
			if (initialOptionValue != null) {
				if (!options.some((option) => option.value === initialOptionValue)) throw new Error("invalid initial option value");
				setSelectedRating(initialOptionValue);
			}
			setIsOpen(true);
		} });
		$[5] = options;
		$[6] = t6;
	} else t6 = $[6];
	useImperativeHandle(ref, t6);
	let t7;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = () => {
			setSelectedRating(null);
			setFeedbackText("");
			setErrors([]);
		};
		$[7] = t7;
	} else t7 = $[7];
	const resetForm = t7;
	let t8;
	if ($[8] !== onClose) {
		t8 = (reason) => {
			resetForm();
			setIsOpen(false);
			onClose?.(reason);
		};
		$[8] = onClose;
		$[9] = t8;
	} else t8 = $[9];
	const closeDialog = t8;
	let t9;
	if ($[10] !== closeDialog || $[11] !== feedbackText || $[12] !== onSubmit || $[13] !== selectedRating) {
		t9 = async (e) => {
			e.preventDefault();
			let newErrors;
			try {
				newErrors = await onSubmit(selectedRating, feedbackText);
			} catch {
				newErrors = ["An error occurred while submitting your feedback."];
			}
			setErrors(newErrors);
			if (newErrors.length === 0) closeDialog("submit");
		};
		$[10] = closeDialog;
		$[11] = feedbackText;
		$[12] = onSubmit;
		$[13] = selectedRating;
		$[14] = t9;
	} else t9 = $[14];
	const handleSubmit = t9;
	let t10;
	if ($[15] !== closeDialog) {
		t10 = () => closeDialog("dismiss");
		$[15] = closeDialog;
		$[16] = t10;
	} else t10 = $[16];
	const handleDialogClose = t10;
	let t11;
	if ($[17] !== closeDialog) {
		t11 = () => closeDialog("cancel");
		$[17] = closeDialog;
		$[18] = t11;
	} else t11 = $[18];
	const handleCancelClick = t11;
	let t12;
	if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = (rating) => {
			setSelectedRating(rating);
			setErrors([]);
		};
		$[19] = t12;
	} else t12 = $[19];
	const handleRatingSelect = t12;
	let t13;
	if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = (e_0) => {
			setFeedbackText(e_0.target.value);
			setErrors([]);
		};
		$[20] = t13;
	} else t13 = $[20];
	const handleFeedbackChange = t13;
	let t14;
	if ($[21] !== requestID) {
		t14 = async () => {
			if (!requestID) return;
			try {
				await navigator.clipboard.writeText(`Request ID: ${requestID}`);
			} catch {
				setErrors(_temp2);
				return;
			}
			setCopiedLogs(true);
			announce$1("Copied!");
			setTimeout(() => {
				setCopiedLogs(false);
			}, 1e3);
		};
		$[21] = requestID;
		$[22] = t14;
	} else t14 = $[22];
	const handleCopyLogs = t14;
	let t15;
	if ($[23] !== errorKey || $[24] !== errors || $[25] !== feedbackText || $[26] !== options || $[27] !== placeholderText || $[28] !== selectedRating) {
		t15 = () => jsxs("div", {
			className: UserFeedback_module_default.bodyContainer,
			children: [jsxs(FormControl$1, {
				required: true,
				children: [jsx(FormControl$1.Label, {
					visuallyHidden: true,
					children: "Rating"
				}), jsx("div", {
					className: UserFeedback_module_default.ratingContainer,
					children: options.map((rating_0) => jsxs("div", {
						className: UserFeedback_module_default.ratingOption,
						children: [jsx("button", {
							type: "button",
							role: "radio",
							"aria-label": rating_0.name,
							"aria-checked": selectedRating === rating_0.value,
							onClick: () => handleRatingSelect(rating_0.value),
							className: clsx(UserFeedback_module_default.ratingButton, UserFeedbackColors_module_default[rating_0.color]),
							children: rating_0.icon
						}), jsx("span", {
							className: UserFeedback_module_default.ratingCaption,
							children: rating_0.name
						})]
					}, rating_0.name))
				})]
			}), jsxs("div", {
				className: UserFeedback_module_default.messageContainer,
				children: [jsxs(FormControl$1, { children: [
					jsx(FormControl$1.Label, { children: "Message" }),
					jsx(Textarea, {
						placeholder: placeholderText,
						value: feedbackText,
						onChange: handleFeedbackChange,
						resize: "vertical",
						block: true,
						rows: 5
					}),
					jsxs(FormControl$1.Caption, {
						className: UserFeedback_module_default.privacyText,
						children: [
							"Please don't include sensitive, confidential, or personal data. Your feedback helps us improve our services in line with our",
							" ",
							jsx(Link, {
								href: "https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement",
								inline: true,
								muted: true,
								children: "Privacy Policy"
							}),
							"."
						]
					})
				] }), jsx("div", {
					className: UserFeedback_module_default.validationError,
					role: "alert",
					children: errors.map(_temp3)
				}, errorKey)]
			})]
		});
		$[23] = errorKey;
		$[24] = errors;
		$[25] = feedbackText;
		$[26] = options;
		$[27] = placeholderText;
		$[28] = selectedRating;
		$[29] = t15;
	} else t15 = $[29];
	const renderBody = t15;
	let t16;
	if ($[30] !== copiedLogs || $[31] !== handleCancelClick || $[32] !== handleCopyLogs || $[33] !== handleSubmit || $[34] !== requestID) {
		t16 = () => jsxs("div", {
			className: UserFeedback_module_default.footerContainer,
			children: [jsx("div", { children: requestID && jsx(Tooltip$1, {
				text: "Copy logs to add in feedback",
				direction: "n",
				children: jsx(ButtonComponent, {
					leadingVisual: copiedLogs ? jsx(CheckIcon, {
						className: UserFeedback_module_default.copyLogsSuccessIcon,
						size: 16
					}) : jsx(CopyIcon, { size: 16 }),
					onClick: handleCopyLogs,
					variant: "default",
					children: copiedLogs ? "Copied!" : "Copy logs"
				})
			}) }), jsxs("div", {
				className: UserFeedback_module_default.footerActionButtonGroup,
				children: [jsx(ButtonComponent, {
					onClick: handleCancelClick,
					children: "Cancel"
				}), jsx(ButtonComponent, {
					variant: "primary",
					type: "submit",
					onClick: handleSubmit,
					children: "Send"
				})]
			})]
		});
		$[30] = copiedLogs;
		$[31] = handleCancelClick;
		$[32] = handleCopyLogs;
		$[33] = handleSubmit;
		$[34] = requestID;
		$[35] = t16;
	} else t16 = $[35];
	const renderFooter = t16;
	let t17;
	if ($[36] !== handleDialogClose || $[37] !== isOpen || $[38] !== renderBody || $[39] !== renderFooter || $[40] !== returnFocusRef || $[41] !== title) {
		t17 = jsx(Fragment$1, { children: isOpen && jsx(Dialog, {
			onClose: handleDialogClose,
			title,
			renderBody,
			renderFooter,
			className: UserFeedback_module_default.Dialog,
			returnFocusRef
		}) });
		$[36] = handleDialogClose;
		$[37] = isOpen;
		$[38] = renderBody;
		$[39] = renderFooter;
		$[40] = returnFocusRef;
		$[41] = title;
		$[42] = t17;
	} else t17 = $[42];
	return t17;
}
UserFeedback.displayName = "UserFeedback";
function _temp3(error) {
	return jsx("div", { children: error }, error);
}
function _temp2(prevErrors) {
	return [...prevErrors, "Failed to copy logs."];
}
function _temp(prev) {
	return prev + 1;
}
var thumbsDownIcon = /* @__PURE__ */ jsx(ThumbsdownIcon, { className: UserFeedback_module_default.thumbsDownIcon });
var thumbsUpIcon = /* @__PURE__ */ jsx(ThumbsupIcon, { className: UserFeedback_module_default.thumbsUpIcon });
var frustratedIcon = /* @__PURE__ */ jsxs("svg", {
	width: "16",
	height: "16",
	"aria-hidden": "true",
	viewBox: "0 0 16 16",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M5.65646 10.7C6.15313 9.85483 7.09616 9.3 8 9.3C8.47794 9.3 9.0345 9.50535 9.54632 9.9146C9.83116 10.1424 10.0753 10.4124 10.2645 10.7H5.65646ZM11.8447 11.016C11.3379 9.39273 9.66897 8 8 8C6.30092 8 4.60185 9.23723 4.12902 11.011C3.98676 11.5446 4.44771 12 5 12H11C11.5523 12 12.0093 11.5432 11.8447 11.016Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M3.89649 4.7586C4.02981 4.42529 4.40809 4.26317 4.7414 4.39649L7.00928 5.30364C7.63789 5.55509 7.6379 6.44491 7.00928 6.69636L4.7414 7.60351C4.40809 7.73683 4.02981 7.57471 3.89649 7.2414C3.76317 6.90809 3.92529 6.52981 4.2586 6.39649L5.24982 6L4.2586 5.60351C3.92529 5.47019 3.76317 5.09191 3.89649 4.7586Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M12.1035 4.7586C11.9702 4.42529 11.5919 4.26317 11.2586 4.39649L8.99072 5.30364C8.36211 5.55509 8.3621 6.44491 8.99072 6.69636L11.2586 7.60351C11.5919 7.73683 11.9702 7.57471 12.1035 7.2414C12.2368 6.90809 12.0747 6.52981 11.7414 6.39649L10.7502 6L11.7414 5.60351C12.0747 5.47019 12.2368 5.09191 12.1035 4.7586Z"
		})
	]
});
var frownIcon = /* @__PURE__ */ jsxs("svg", {
	width: "16",
	height: "16",
	"aria-hidden": "true",
	viewBox: "0 0 16 16",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z"
		}),
		/* @__PURE__ */ jsx("path", { d: "M6.5 6.5C6.5 7.05228 6.05228 7.5 5.5 7.5C4.94772 7.5 4.5 7.05228 4.5 6.5C4.5 5.94772 4.94772 5.5 5.5 5.5C6.05228 5.5 6.5 5.94772 6.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", { d: "M11.5 6.5C11.5 7.05228 11.0523 7.5 10.5 7.5C9.94772 7.5 9.5 7.05228 9.5 6.5C9.5 5.94772 9.94772 5.5 10.5 5.5C11.0523 5.5 11.5 5.94772 11.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M10.3416 11.8591C9.33064 10.0058 6.66936 10.0058 5.65842 11.8591C5.46007 12.2228 5.0045 12.3568 4.64086 12.1584C4.27722 11.9601 4.14323 11.5045 4.34158 11.1409C5.92104 8.24518 10.079 8.24518 11.6584 11.1409C11.8568 11.5045 11.7228 11.9601 11.3591 12.1584C10.9955 12.3568 10.5399 12.2228 10.3416 11.8591Z"
		})
	]
});
var neutralIcon = /* @__PURE__ */ jsxs("svg", {
	width: "16",
	"aria-hidden": "true",
	height: "16",
	viewBox: "0 0 16 16",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z"
		}),
		/* @__PURE__ */ jsx("path", { d: "M6.5 6.5C6.5 7.05228 6.05228 7.5 5.5 7.5C4.94772 7.5 4.5 7.05228 4.5 6.5C4.5 5.94772 4.94772 5.5 5.5 5.5C6.05228 5.5 6.5 5.94772 6.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", { d: "M11.5 6.5C11.5 7.05228 11.0523 7.5 10.5 7.5C9.94772 7.5 9.5 7.05228 9.5 6.5C9.5 5.94772 9.94772 5.5 10.5 5.5C11.0523 5.5 11.5 5.94772 11.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M5 11C5 10.5858 5.33579 10.25 5.75 10.25H10.25C10.6642 10.25 11 10.5858 11 11C11 11.4142 10.6642 11.75 10.25 11.75H5.75C5.33579 11.75 5 11.4142 5 11Z"
		})
	]
});
var smileIcon = /* @__PURE__ */ jsxs("svg", {
	width: "16",
	"aria-hidden": "true",
	height: "16",
	viewBox: "0 0 16 16",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z"
		}),
		/* @__PURE__ */ jsx("path", { d: "M6.5 6.5C6.5 7.05228 6.05228 7.5 5.5 7.5C4.94772 7.5 4.5 7.05228 4.5 6.5C4.5 5.94772 4.94772 5.5 5.5 5.5C6.05228 5.5 6.5 5.94772 6.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", { d: "M11.5 6.5C11.5 7.05228 11.0523 7.5 10.5 7.5C9.94772 7.5 9.5 7.05228 9.5 6.5C9.5 5.94772 9.94772 5.5 10.5 5.5C11.0523 5.5 11.5 5.94772 11.5 6.5Z" }),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M10.3569 9.61413C9.28933 11.3934 6.71067 11.3934 5.64312 9.61413C5.43001 9.25894 4.96931 9.14377 4.61413 9.35688C4.25894 9.56999 4.14377 10.0307 4.35688 10.3859C6.00704 13.1361 9.99296 13.1361 11.6431 10.3859C11.8562 10.0307 11.7411 9.56999 11.3859 9.35688C11.0307 9.14377 10.57 9.25894 10.3569 9.61413Z"
		})
	]
});
var grinIcon = /* @__PURE__ */ jsxs("svg", {
	width: "16",
	"aria-hidden": "true",
	height: "16",
	viewBox: "0 0 16 16",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	children: [
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M5.65646 10.3C6.15313 11.1452 7.09616 11.7 8 11.7C8.47794 11.7 9.0345 11.4947 9.54632 11.0854C9.83116 10.8576 10.0753 10.5876 10.2645 10.3H5.65646ZM11.8447 9.98403C11.3379 11.6073 9.66897 13 8 13C6.30092 13 4.60185 11.7628 4.12902 9.98904C3.98676 9.45539 4.44771 9 5 9H11C11.5523 9 12.0093 9.45684 11.8447 9.98403Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M11.3292 6.83541C10.9875 6.15213 10.0125 6.15213 9.67082 6.83541C9.48558 7.20589 9.03507 7.35606 8.66459 7.17082C8.29411 6.98558 8.14394 6.53507 8.32918 6.16459C9.22361 4.37574 11.7764 4.37574 12.6708 6.16459C12.8561 6.53507 12.7059 6.98558 12.3354 7.17082C11.9649 7.35606 11.5144 7.20589 11.3292 6.83541Z"
		}),
		/* @__PURE__ */ jsx("path", {
			fillRule: "evenodd",
			clipRule: "evenodd",
			d: "M6.32918 6.83541C5.98754 6.15213 5.01246 6.15213 4.67082 6.83541C4.48558 7.20589 4.03507 7.35606 3.66459 7.17082C3.29411 6.98558 3.14394 6.53507 3.32918 6.16459C4.22361 4.37574 6.77639 4.37574 7.67082 6.16459C7.85606 6.53507 7.70589 6.98558 7.33541 7.17082C6.96493 7.35606 6.51442 7.20589 6.32918 6.83541Z"
		})
	]
});
export { neutralIcon as a, thumbsUpIcon as c, grinIcon as i, frownIcon as n, smileIcon as o, frustratedIcon as r, thumbsDownIcon as s, UserFeedback as t };
