import { useCallback, useEffect, useEffectEvent, useState } from "react";
import { c } from "react/compiler-runtime";
/**
* Observe a single element with an IntersectionObserver.
*
* Returns a callback ref that should be attached to the target element.
* When the element mounts, unmounts, or is swapped, the observer is
* automatically re-created / cleaned up.
*
* @param callback      Called when the intersection observer fires
* @param options       IntersectionObserver options (root, rootMargin, threshold)
*/
function useIntersectionObserver(callback, options) {
	const $ = c(8);
	const callbackRef = useEffectEvent(callback);
	const [element, setElement] = useState(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (node) => {
			setElement(node);
		};
		$[0] = t0;
	} else t0 = $[0];
	const ref = t0;
	let t1;
	if ($[1] !== callbackRef || $[2] !== element || $[3] !== options) {
		t1 = () => {
			if (!element) return;
			const observer = new IntersectionObserver((entries) => callbackRef(entries), options);
			observer.observe(element);
			return () => observer.disconnect();
		};
		$[1] = callbackRef;
		$[2] = element;
		$[3] = options;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== element || $[6] !== options) {
		t2 = [element, options];
		$[5] = element;
		$[6] = options;
		$[7] = t2;
	} else t2 = $[7];
	useEffect(t1, t2);
	return ref;
}
export { useIntersectionObserver as t };
