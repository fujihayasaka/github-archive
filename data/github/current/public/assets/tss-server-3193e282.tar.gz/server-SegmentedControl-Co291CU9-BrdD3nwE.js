import { o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Fi as getResponsiveAttributes, Ri as isSlot, n as ActionList, pi as Tooltip$1 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import React, { useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isElement } from "react-is";
var classes = {
	"SegmentedControl": "prc-SegmentedControl-SegmentedControl-lqIXp",
	"Text": "prc-SegmentedControl-Text-7S2y2",
	"DropdownContainer": "prc-SegmentedControl-DropdownContainer-ZaPMn",
	"Item": "prc-SegmentedControl-Item-tSCQh",
	"Counter": "prc-SegmentedControl-Counter-GmZOI",
	"Button": "prc-SegmentedControl-Button-E48xz",
	"IconButton": "prc-SegmentedControl-IconButton-tlzDE",
	"Content": "prc-SegmentedControl-Content-1COlk",
	"LeadingIcon": "prc-SegmentedControl-LeadingIcon-74n5s"
};
var SegmentedControlButton = (t0) => {
	var _leadingVisual;
	const $ = c(36);
	let children;
	let className;
	let count;
	let disabled;
	let leadingIcon;
	let leadingVisual;
	let props;
	let selected;
	if ($[0] !== t0) {
		const { children: t1, leadingVisual: t2, leadingIcon: t3, selected: t4, className: t5, disabled: t6, defaultSelected: _defaultSelected, count: t7, ...t8 } = t0;
		children = t1;
		leadingVisual = t2;
		leadingIcon = t3;
		selected = t4;
		className = t5;
		disabled = t6;
		count = t7;
		props = t8;
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = count;
		$[4] = disabled;
		$[5] = leadingIcon;
		$[6] = leadingVisual;
		$[7] = props;
		$[8] = selected;
	} else {
		children = $[1];
		className = $[2];
		count = $[3];
		disabled = $[4];
		leadingIcon = $[5];
		leadingVisual = $[6];
		props = $[7];
		selected = $[8];
	}
	let ariaDisabled;
	let rest;
	if ($[9] !== props) {
		({"aria-disabled": ariaDisabled, ...rest} = props);
		$[9] = props;
		$[10] = ariaDisabled;
		$[11] = rest;
	} else {
		ariaDisabled = $[10];
		rest = $[11];
	}
	const LeadingVisual = (_leadingVisual = leadingVisual) !== null && _leadingVisual !== void 0 ? _leadingVisual : leadingIcon;
	let t1;
	if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = clsx(classes.Item);
		$[12] = t1;
	} else t1 = $[12];
	const t2 = selected ? "" : void 0;
	const t3 = disabled || ariaDisabled || void 0;
	let t4;
	if ($[13] !== className) {
		t4 = clsx(classes.Button, className);
		$[13] = className;
		$[14] = t4;
	} else t4 = $[14];
	let t5;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = clsx(classes.Content, "segmentedControl-content");
		$[15] = t5;
	} else t5 = $[15];
	let t6;
	if ($[16] !== LeadingVisual) {
		t6 = LeadingVisual && /* @__PURE__ */ jsx("div", {
			className: classes.LeadingIcon,
			children: isElement(LeadingVisual) ? LeadingVisual : /* @__PURE__ */ jsx(LeadingVisual, {})
		});
		$[16] = LeadingVisual;
		$[17] = t6;
	} else t6 = $[17];
	let t7;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = clsx(classes.Text, "segmentedControl-text");
		$[18] = t7;
	} else t7 = $[18];
	let t8;
	if ($[19] !== children) {
		t8 = /* @__PURE__ */ jsx("div", {
			className: t7,
			"data-text": children,
			children
		});
		$[19] = children;
		$[20] = t8;
	} else t8 = $[20];
	let t9;
	if ($[21] !== count) {
		t9 = count !== void 0 && /* @__PURE__ */ jsx("span", {
			className: classes.Counter,
			children: /* @__PURE__ */ jsx(CounterLabel, { children: count })
		});
		$[21] = count;
		$[22] = t9;
	} else t9 = $[22];
	let t10;
	if ($[23] !== t6 || $[24] !== t8 || $[25] !== t9) {
		t10 = /* @__PURE__ */ jsxs("span", {
			className: t5,
			children: [
				t6,
				t8,
				t9
			]
		});
		$[23] = t6;
		$[24] = t8;
		$[25] = t9;
		$[26] = t10;
	} else t10 = $[26];
	let t11;
	if ($[27] !== rest || $[28] !== selected || $[29] !== t10 || $[30] !== t3 || $[31] !== t4) {
		t11 = /* @__PURE__ */ jsx("button", {
			"aria-current": selected,
			"aria-disabled": t3,
			className: t4,
			type: "button",
			...rest,
			children: t10
		});
		$[27] = rest;
		$[28] = selected;
		$[29] = t10;
		$[30] = t3;
		$[31] = t4;
		$[32] = t11;
	} else t11 = $[32];
	let t12;
	if ($[33] !== t11 || $[34] !== t2) {
		t12 = /* @__PURE__ */ jsx("li", {
			className: t1,
			"data-selected": t2,
			children: t11
		});
		$[33] = t11;
		$[34] = t2;
		$[35] = t12;
	} else t12 = $[35];
	return t12;
};
SegmentedControlButton.__SLOT__ = Symbol("SegmentedControl.Button");
var SegmentedControlIconButton = (t0) => {
	const $ = c(35);
	let Icon;
	let ariaLabel;
	let className;
	let description;
	let disabled;
	let props;
	let selected;
	let tooltipDirection;
	if ($[0] !== t0) {
		({"aria-label": ariaLabel, icon: Icon, selected, className, description, tooltipDirection, disabled, ...props} = t0);
		$[0] = t0;
		$[1] = Icon;
		$[2] = ariaLabel;
		$[3] = className;
		$[4] = description;
		$[5] = disabled;
		$[6] = props;
		$[7] = selected;
		$[8] = tooltipDirection;
	} else {
		Icon = $[1];
		ariaLabel = $[2];
		className = $[3];
		description = $[4];
		disabled = $[5];
		props = $[6];
		selected = $[7];
		tooltipDirection = $[8];
	}
	let ariaDisabled;
	let rest;
	if ($[9] !== props) {
		({"aria-disabled": ariaDisabled, ...rest} = props);
		$[9] = props;
		$[10] = ariaDisabled;
		$[11] = rest;
	} else {
		ariaDisabled = $[10];
		rest = $[11];
	}
	let t1;
	if ($[12] !== className) {
		t1 = clsx(classes.Item, className);
		$[12] = className;
		$[13] = t1;
	} else t1 = $[13];
	const t2 = selected || void 0;
	const t3 = description ? void 0 : "label";
	const t4 = description ? description : ariaLabel;
	const t5 = description ? ariaLabel : void 0;
	const t6 = disabled || ariaDisabled || void 0;
	let t7;
	if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = clsx(classes.Button, classes.IconButton);
		$[14] = t7;
	} else t7 = $[14];
	let t8;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = clsx(classes.Content, "segmentedControl-content");
		$[15] = t8;
	} else t8 = $[15];
	let t9;
	if ($[16] !== Icon) {
		t9 = isElement(Icon) ? Icon : /* @__PURE__ */ jsx(Icon, {});
		$[16] = Icon;
		$[17] = t9;
	} else t9 = $[17];
	let t10;
	if ($[18] !== t9) {
		t10 = /* @__PURE__ */ jsx("span", {
			className: t8,
			children: t9
		});
		$[18] = t9;
		$[19] = t10;
	} else t10 = $[19];
	let t11;
	if ($[20] !== rest || $[21] !== selected || $[22] !== t10 || $[23] !== t5 || $[24] !== t6) {
		t11 = /* @__PURE__ */ jsx("button", {
			type: "button",
			"aria-current": selected,
			"aria-label": t5,
			"aria-disabled": t6,
			className: t7,
			...rest,
			children: t10
		});
		$[20] = rest;
		$[21] = selected;
		$[22] = t10;
		$[23] = t5;
		$[24] = t6;
		$[25] = t11;
	} else t11 = $[25];
	let t12;
	if ($[26] !== t11 || $[27] !== t3 || $[28] !== t4 || $[29] !== tooltipDirection) {
		t12 = /* @__PURE__ */ jsx(Tooltip$1, {
			type: t3,
			text: t4,
			direction: tooltipDirection,
			children: t11
		});
		$[26] = t11;
		$[27] = t3;
		$[28] = t4;
		$[29] = tooltipDirection;
		$[30] = t12;
	} else t12 = $[30];
	let t13;
	if ($[31] !== t1 || $[32] !== t12 || $[33] !== t2) {
		t13 = /* @__PURE__ */ jsx("li", {
			className: t1,
			"data-selected": t2,
			children: t12
		});
		$[31] = t1;
		$[32] = t12;
		$[33] = t2;
		$[34] = t13;
	} else t13 = $[34];
	return t13;
};
SegmentedControlIconButton.__SLOT__ = Symbol("SegmentedControl.IconButton");
var Root = (t0) => {
	const $ = c(54);
	let ariaLabel;
	let ariaLabelledby;
	let children;
	let className;
	let fullWidth;
	let onChange;
	let rest;
	let size;
	let t1;
	if ($[0] !== t0) {
		({"aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, children, fullWidth, onChange, size, variant: t1, className, ...rest} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = ariaLabelledby;
		$[3] = children;
		$[4] = className;
		$[5] = fullWidth;
		$[6] = onChange;
		$[7] = rest;
		$[8] = size;
		$[9] = t1;
	} else {
		ariaLabel = $[1];
		ariaLabelledby = $[2];
		children = $[3];
		className = $[4];
		fullWidth = $[5];
		onChange = $[6];
		rest = $[7];
		size = $[8];
		t1 = $[9];
	}
	const variant = t1 === void 0 ? "default" : t1;
	const segmentedControlContainerRef = useRef(null);
	let t2;
	if ($[10] !== children || $[11] !== onChange) {
		t2 = onChange === void 0 || React.Children.toArray(children).some(_temp);
		$[10] = children;
		$[11] = onChange;
		$[12] = t2;
	} else t2 = $[12];
	const isUncontrolled = t2;
	let t3;
	if ($[13] !== children) {
		const selectedSegments = React.Children.toArray(children).map(_temp2);
		t3 = selectedSegments.some(_temp3) ? selectedSegments.indexOf(true) : 0;
		$[13] = children;
		$[14] = t3;
	} else t3 = $[14];
	const selectedIndexExternal = t3;
	const [selectedIndexInternalState, setSelectedIndexInternalState] = useState(selectedIndexExternal);
	const selectedIndex = isUncontrolled ? selectedIndexInternalState : selectedIndexExternal;
	let hasDropdownVariant;
	let t4;
	if ($[15] !== ariaLabel || $[16] !== ariaLabelledby || $[17] !== children || $[18] !== isUncontrolled || $[19] !== onChange || $[20] !== selectedIndex || $[21] !== variant) {
		const selectedChild = /* @__PURE__ */ React.isValidElement(React.Children.toArray(children)[selectedIndex]) ? React.Children.toArray(children)[selectedIndex] : void 0;
		const getChildIcon = _temp4;
		const getChildText = _temp5;
		if (!ariaLabel && !ariaLabelledby) console.warn("Use the `aria-label` or `aria-labelledby` prop to provide an accessible label for assistive technologies");
		const responsiveVariant = typeof variant === "object" ? variant : void 0;
		let t5;
		if ($[24] !== responsiveVariant) {
			t5 = responsiveVariant ? Object.values(responsiveVariant).includes("dropdown") : false;
			$[24] = responsiveVariant;
			$[25] = t5;
		} else t5 = $[25];
		hasDropdownVariant = t5;
		t4 = hasDropdownVariant && /* @__PURE__ */ jsx("div", {
			className: classes.DropdownContainer,
			...getResponsiveAttributes("variant", variant),
			children: /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Button, {
				"aria-label": ariaLabel && `${getChildText(selectedChild)}, ${ariaLabel}`,
				leadingVisual: getChildIcon(selectedChild),
				children: getChildText(selectedChild)
			}), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
				"aria-labelledby": ariaLabelledby,
				children: /* @__PURE__ */ jsx(ActionList, {
					selectionVariant: "single",
					children: React.Children.map(children, (child_1, index) => {
						const ChildIcon = getChildIcon(child_1);
						if (!/* @__PURE__ */ React.isValidElement(child_1)) return null;
						return /* @__PURE__ */ jsxs(ActionList.Item, {
							selected: index === selectedIndex,
							onSelect: (event) => {
								isUncontrolled && setSelectedIndexInternalState(index);
								onChange && onChange(index);
								child_1.props.onClick && child_1.props.onClick(event);
							},
							children: [
								ChildIcon,
								" ",
								getChildText(child_1)
							]
						}, `segmented-control-action-btn-${index}`);
					})
				})
			})] })
		});
		$[15] = ariaLabel;
		$[16] = ariaLabelledby;
		$[17] = children;
		$[18] = isUncontrolled;
		$[19] = onChange;
		$[20] = selectedIndex;
		$[21] = variant;
		$[22] = hasDropdownVariant;
		$[23] = t4;
	} else {
		hasDropdownVariant = $[22];
		t4 = $[23];
	}
	const dropdownContent = t4;
	let t5;
	if ($[26] !== className) {
		t5 = clsx(classes.SegmentedControl, className);
		$[26] = className;
		$[27] = t5;
	} else t5 = $[27];
	let t6;
	if ($[28] !== fullWidth) {
		t6 = getResponsiveAttributes("full-width", fullWidth);
		$[28] = fullWidth;
		$[29] = t6;
	} else t6 = $[29];
	let t7;
	if ($[30] !== variant) {
		t7 = getResponsiveAttributes("variant", variant);
		$[30] = variant;
		$[31] = t7;
	} else t7 = $[31];
	let t8;
	if ($[32] !== children || $[33] !== isUncontrolled || $[34] !== onChange || $[35] !== selectedIndex) {
		let t9;
		if ($[37] !== isUncontrolled || $[38] !== onChange || $[39] !== selectedIndex) {
			t9 = (child_2, index_0) => {
				if (!/* @__PURE__ */ React.isValidElement(child_2)) return null;
				const sharedChildProps = {
					onClick: onChange ? (event_0) => {
						if (!(child_2.props.disabled === true || child_2.props["aria-disabled"] === "true" || child_2.props["aria-disabled"] === true)) {
							onChange(index_0);
							isUncontrolled && setSelectedIndexInternalState(index_0);
							child_2.props.onClick && child_2.props.onClick(event_0);
						}
					} : (event_1) => {
						if (!(child_2.props.disabled === true || child_2.props["aria-disabled"] === "true" || child_2.props["aria-disabled"] === true)) {
							child_2.props.onClick && child_2.props.onClick(event_1);
							isUncontrolled && setSelectedIndexInternalState(index_0);
						}
					},
					selected: index_0 === selectedIndex,
					style: {
						"--separator-color": index_0 === selectedIndex || index_0 === selectedIndex - 1 ? "transparent" : "var(--borderColor-default)",
						...child_2.props.style
					}
				};
				return /* @__PURE__ */ React.cloneElement(child_2, sharedChildProps);
			};
			$[37] = isUncontrolled;
			$[38] = onChange;
			$[39] = selectedIndex;
			$[40] = t9;
		} else t9 = $[40];
		t8 = React.Children.map(children, t9);
		$[32] = children;
		$[33] = isUncontrolled;
		$[34] = onChange;
		$[35] = selectedIndex;
		$[36] = t8;
	} else t8 = $[36];
	let t9;
	if ($[41] !== ariaLabel || $[42] !== ariaLabelledby || $[43] !== rest || $[44] !== size || $[45] !== t5 || $[46] !== t6 || $[47] !== t7 || $[48] !== t8) {
		t9 = /* @__PURE__ */ jsx("ul", {
			"aria-label": ariaLabel,
			"aria-labelledby": ariaLabelledby,
			ref: segmentedControlContainerRef,
			className: t5,
			...t6,
			...t7,
			"data-size": size,
			...rest,
			children: t8
		});
		$[41] = ariaLabel;
		$[42] = ariaLabelledby;
		$[43] = rest;
		$[44] = size;
		$[45] = t5;
		$[46] = t6;
		$[47] = t7;
		$[48] = t8;
		$[49] = t9;
	} else t9 = $[49];
	const segmentedControlContent = t9;
	let t10;
	if ($[50] !== dropdownContent || $[51] !== hasDropdownVariant || $[52] !== segmentedControlContent) {
		t10 = hasDropdownVariant ? /* @__PURE__ */ jsxs(Fragment$1, { children: [dropdownContent, segmentedControlContent] }) : segmentedControlContent;
		$[50] = dropdownContent;
		$[51] = hasDropdownVariant;
		$[52] = segmentedControlContent;
		$[53] = t10;
	} else t10 = $[53];
	return t10;
};
Root.displayName = "SegmentedControl";
var SegmentedControl = Object.assign(Root, {
	__SLOT__: Symbol("SegmentedControl"),
	Button: SegmentedControlButton,
	IconButton: SegmentedControlIconButton
});
function _temp(child) {
	return /* @__PURE__ */ React.isValidElement(child) && child.props.defaultSelected !== void 0;
}
function _temp2(child_0) {
	return /* @__PURE__ */ React.isValidElement(child_0) && (child_0.props.defaultSelected || child_0.props.selected);
}
function _temp3(isSelected) {
	return isSelected;
}
function _temp4(childArg) {
	if (/* @__PURE__ */ React.isValidElement(childArg) && (childArg.type === SegmentedControlButton || isSlot(childArg, SegmentedControlButton))) {
		var _childArg$props$leadi;
		const leadingVisual = (_childArg$props$leadi = childArg.props.leadingVisual) !== null && _childArg$props$leadi !== void 0 ? _childArg$props$leadi : childArg.props.leadingIcon;
		if (leadingVisual) if (isElement(leadingVisual)) return leadingVisual;
		else return /* @__PURE__ */ jsx(leadingVisual, {});
	}
	if (/* @__PURE__ */ React.isValidElement(childArg) && (childArg.type === SegmentedControlIconButton || isSlot(childArg, SegmentedControlIconButton))) if (isElement(childArg.props.icon));
	else {
		const Icon = childArg.props.icon;
		return /* @__PURE__ */ jsx(Icon, {});
	}
	return null;
}
function _temp5(childArg_0) {
	if (/* @__PURE__ */ React.isValidElement(childArg_0) && (childArg_0.type === SegmentedControlButton || isSlot(childArg_0, SegmentedControlButton))) return childArg_0.props.children;
	return /* @__PURE__ */ React.isValidElement(childArg_0) ? childArg_0.props["aria-label"] : null;
}
export { SegmentedControl as t };
