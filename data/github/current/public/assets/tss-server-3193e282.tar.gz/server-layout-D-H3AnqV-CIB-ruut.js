performance.mark("js-parse-end:server-layout-D-H3AnqV-CIB-ruut.js");
import { n as Outlet$1, t as Link$1, v as useMatches$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { t as CurrentRepositoryProvider } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as AppPayloadContext } from "./server-use-app-payload-vEq4Cwev-CPfLvO1p.js";
import { t as FileQueryProvider } from "./server-find-file-BEBNNIhZ-BiOBklr2.js";
import { t as PathProvider } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { t as RefInfoProvider } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator, i as CurrentUserProvider, r as AllShortcutsEnabledProvider, t as ActionProvider } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as EditPermissionsProvider } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { n as ScreenSizeProvider, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { a as useShortcut, t as CodeViewOptionsProvider } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { d as useTreePane, i as OpenPanelProvider, n as FileTreeControlProvider, t as DuplicateOnKeydownButton } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { t as useRoutePayload } from "./server-use-route-payload-MAZr7zfl-DL3BDU9L.js";
import { n as codeViewLayoutRoute } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { t as addUrlToHistoryStack } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { q as textAreaId } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { t as CodeViewBannersProvider } from "./server-CodeViewBannersContext-CEdzkK6e-znl4nx1w.js";
import { t as AnalyticsProvider } from "./server-AnalyticsProvider-D0POAVQk-B5tW16h5.js";
import { t as ScrollMarksContainer } from "./server-ScrollMarksContainer-C_JiMHdh-BpHhqDYB.js";
import { n as updateExpandPreferences, t as CodeNavProvider } from "./server-CodeNavContext-B-HlTATD-BC-PDvfx.js";
import { t as TreePaneProvider } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { t as codeViewBlameRoute } from "./server-code-view-blame-route-CBnG62NQ-C6WKn_o_.js";
import { r as symbolsHeaderId } from "./server-CodeNavSymbolNavigation-Dwn78xI--DkG4V6h8.js";
import { t as codeViewBlobRoute } from "./server-code-view-blob-route-BXbxJsMG-BeLOpqoP.js";
import { t as codeViewEditRoute } from "./server-code-view-edit-route-CUHyRXnW-CWvnzfL0.js";
import { t as codeViewRepoRoute } from "./server-code-view-repo-route-BsNI4mmi-Czvdqq85.js";
import { t as codeViewNewRoute } from "./server-code-view-new-route-CPa0iN_Q-Rsso1z4C.js";
import React, { useCallback, useEffect, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:layout-D-H3AnqV.js");
function App(t0) {
	const $ = c(4);
	const { children } = t0;
	const payload = useRoutePayload();
	const [repo] = React.useState(payload?.repo);
	let t1;
	if ($[0] !== children || $[1] !== payload || $[2] !== repo) {
		t1 = jsx(AppWrapper, {
			payload,
			repo,
			children
		});
		$[0] = children;
		$[1] = payload;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
App.displayName = "App";
function AppWrapper(t0) {
	const $ = c(6);
	const { children, payload, repo } = t0;
	const [user] = React.useState(payload?.currentUser);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {};
		$[0] = t1;
	} else t1 = $[0];
	const metadata = t1;
	let t2;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = [];
		$[1] = t2;
	} else t2 = $[1];
	useEffect(_temp$2, t2);
	let t3;
	if ($[2] !== children || $[3] !== repo || $[4] !== user) {
		t3 = jsxs(Fragment$1, { children: [jsx("meta", {
			name: "github-code-view-meta-stats",
			id: "github-code-view-meta-stats",
			"data-hydrostats": "publish"
		}), jsx(ScreenSizeProvider, {
			initialValue: ScreenSize.xxxlarge,
			children: jsx(AnalyticsProvider, {
				appName: "react-code-view",
				category: "",
				metadata,
				children: jsx(CurrentUserProvider, {
					user,
					children: jsx(CurrentRepositoryProvider, {
						repository: repo,
						children: jsx(CodeViewOptionsProvider, { children })
					})
				})
			})
		})] });
		$[2] = children;
		$[3] = repo;
		$[4] = user;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
AppWrapper.displayName = "AppWrapper";
function _temp$2() {
	const footer = document.querySelector(".footer");
	if (footer) {
		footer.querySelector(".mt-6")?.classList.replace("tmp-mt-6", "mt-0");
		footer.querySelector(".border-top")?.classList.remove("border-top");
	}
}
function PermalinkShortcut() {
	const $ = c(7);
	const urlCreator = useUrlCreator();
	const { permalinkShortcut } = useShortcut();
	if (urlCreator.isCurrentPagePermalink()) {
		let t0;
		if ($[0] !== permalinkShortcut.hotkey) {
			t0 = jsx(DuplicateOnKeydownButton, {
				buttonFocusId: textAreaId,
				buttonHotkey: permalinkShortcut.hotkey,
				buttonTestLabel: "header-permalink-button",
				onlyAddHotkeyScopeButton: true,
				onButtonClick: _temp$1
			});
			$[0] = permalinkShortcut.hotkey;
			$[1] = t0;
		} else t0 = $[1];
		return t0;
	}
	let t0;
	if ($[2] !== urlCreator) {
		t0 = () => {
			const permalink = urlCreator.createPermalink();
			if (window.location.href.indexOf(permalink) < 0) addUrlToHistoryStack(permalink);
		};
		$[2] = urlCreator;
		$[3] = t0;
	} else t0 = $[3];
	let t1;
	if ($[4] !== permalinkShortcut.hotkey || $[5] !== t0) {
		t1 = jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: permalinkShortcut.hotkey,
			buttonTestLabel: "header-permalink-button",
			onButtonClick: t0
		});
		$[4] = permalinkShortcut.hotkey;
		$[5] = t0;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
PermalinkShortcut.displayName = "PermalinkShortcut";
function _temp$1() {}
function useRouteAction() {
	const $ = c(2);
	const matches = useMatches$1();
	let t0;
	if ($[0] !== matches) {
		t0 = Symbol.for("react.early_return_sentinel");
		bb0: for (const match of matches) {
			if (match.id === codeViewBlameRoute.id) {
				t0 = "blame";
				break bb0;
			}
			if (match.id === codeViewBlobRoute.id) {
				t0 = "blob";
				break bb0;
			}
			if (match.id === codeViewEditRoute.id) {
				t0 = "edit";
				break bb0;
			}
			if (match.id === codeViewNewRoute.id) {
				t0 = "new";
				break bb0;
			}
		}
		$[0] = matches;
		$[1] = t0;
	} else t0 = $[1];
	if (t0 !== Symbol.for("react.early_return_sentinel")) return t0;
	return "tree";
}
var REPOS_FILE_TREE_ID = "repos-file-tree";
function CodeViewLayout() {
	const $ = c(3);
	const { data } = useRouteQuery(codeViewLayoutRoute, "mainQuery");
	const { data: appPayload } = useLayoutAppPayload();
	let t0;
	if ($[0] !== appPayload || $[1] !== data) {
		t0 = jsx(AppPayloadContext, {
			value: appPayload,
			children: jsxs(AppWrapper, {
				payload: data,
				repo: data.repo,
				children: [jsx(Link$1, {
					to: codeViewRepoRoute.generatePath({
						owner: data.repo.ownerLogin,
						repo: data.repo.name
					}),
					hidden: true,
					id: "code-view-repo-link"
				}), jsx(CodeViewLayoutInternal, { data })]
			})
		});
		$[0] = appPayload;
		$[1] = data;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
CodeViewLayout.displayName = "CodeViewLayout";
function useLayoutAppPayload() {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { select: _temp };
		$[0] = t0;
	} else t0 = $[0];
	return useRouteQuery(codeViewLayoutRoute, "mainQuery", t0);
}
function _temp(t0) {
	const { payload: t1 } = t0;
	const { helpUrl, findFileWorkerPath, findInFileWorkerPath, githubDevUrl } = t1;
	return {
		helpUrl,
		findFileWorkerPath,
		findInFileWorkerPath,
		githubDevUrl
	};
}
function CodeViewLayoutInternal({ data }) {
	const openPanelRef = useRef(void 0);
	const treeRef = useRef(null);
	const contentFocusedRef = useRef(false);
	const textAreaFocusedRef = useRef(false);
	const contentFocusTargetRef = useRef(null);
	const treeFocusTargetRef = useRef(null);
	const updateTreeExpandedPreference = (isTreeExpanded) => {
		updateExpandPreferences(isTreeExpanded, null, null);
	};
	const treePaneState = useTreePane(REPOS_FILE_TREE_ID, openPanelRef, data.treeExpanded, textAreaId, updateTreeExpandedPreference);
	const onFindFilesShortcut = useCallback(() => {
		if (window.matchMedia(`(max-width: ${ScreenSize.large - 1}px)`).matches) treePaneState.expandTree({ focus: "search" });
	}, [treePaneState]);
	const { toggleFocusedPaneShortcut } = useShortcut();
	function toggleFocus() {
		const contentElement = document.querySelector("[data-selector=\"repos-split-pane-content\"]");
		const symbolsPaneElement = document.getElementById(symbolsHeaderId);
		const textAreaElement = document.getElementById(textAreaId);
		if (document.activeElement?.id === "read-only-cursor-text-area") textAreaFocusedRef.current = true;
		if (contentElement?.contains(document.activeElement) && !textAreaFocusedRef.current) contentFocusedRef.current = true;
		else if (treeRef.current?.contains(document.activeElement)) contentFocusedRef.current = false;
		if (!contentFocusedRef.current && !textAreaFocusedRef.current) {
			const focusTarget = textAreaElement || contentElement;
			treeFocusTargetRef.current = treeRef.current?.contains(document.activeElement) ? document.activeElement : null;
			contentFocusedRef.current = false;
			focusTarget?.focus();
		} else if (textAreaFocusedRef.current) {
			const focusTarget_0 = contentFocusTargetRef.current || symbolsPaneElement || contentElement;
			contentFocusedRef.current = true;
			textAreaFocusedRef.current = false;
			focusTarget_0?.focus();
		} else {
			const focusTarget_1 = treeFocusTargetRef.current || treeRef.current;
			contentFocusTargetRef.current = contentElement?.contains(document.activeElement) ? document.activeElement : null;
			contentFocusedRef.current = false;
			textAreaFocusedRef.current = false;
			focusTarget_1?.focus();
		}
	}
	const action = useRouteAction();
	return /* @__PURE__ */ jsx(AllShortcutsEnabledProvider, {
		allShortcutsEnabled: data.allShortcutsEnabled,
		children: /* @__PURE__ */ jsx(FileTreeControlProvider, { children: /* @__PURE__ */ jsx(FileQueryProvider, { children: /* @__PURE__ */ jsx(CodeNavProvider, { children: /* @__PURE__ */ jsx(TreePaneProvider, {
			treePaneState,
			onFindFilesShortcut,
			children: /* @__PURE__ */ jsx(PathProvider, {
				path: data.path,
				children: /* @__PURE__ */ jsx(ActionProvider, {
					action,
					children: /* @__PURE__ */ jsx(RefInfoProvider, {
						refInfo: data.refInfo,
						children: /* @__PURE__ */ jsxs(EditPermissionsProvider, {
							canEdit: data.refInfo.canEdit,
							canEditOnDefaultBranch: data.refInfo.canEditOnDefaultBranch,
							fileExistsOnDefault: data.refInfo.fileExistsOnDefault,
							children: [/* @__PURE__ */ jsx(PermalinkShortcut, {}), /* @__PURE__ */ jsxs("div", { children: [
								/* @__PURE__ */ jsx(OpenPanelProvider, {
									payload: data,
									openPanelRef,
									action,
									children: /* @__PURE__ */ jsx(CodeViewBannersProvider, { children: /* @__PURE__ */ jsx(Outlet$1, {}) })
								}),
								/* @__PURE__ */ jsx(ScrollMarksContainer, {}),
								/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
									buttonFocusId: textAreaId,
									buttonHotkey: toggleFocusedPaneShortcut.hotkey,
									onButtonClick: () => toggleFocus()
								})
							] })]
						})
					})
				})
			})
		}) }) }) })
	});
}
CodeViewLayoutInternal.displayName = "CodeViewLayoutInternal";
var SplitComponent = CodeViewLayout;
export { SplitComponent as component };
