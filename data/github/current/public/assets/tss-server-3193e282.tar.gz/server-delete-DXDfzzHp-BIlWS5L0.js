performance.mark("js-parse-end:server-delete-DXDfzzHp-BIlWS5L0.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:delete-DXDfzzHp.js");
var codeViewDeleteServerFn_createServerFn_handler = createServerRpc({
	id: "8a17754e5d26e19e0c86f0f44a9d847ecc33a7285eb228ef9c1b69805a32feee",
	name: "codeViewDeleteServerFn",
	filename: "src/routes/code-view/delete.tsx"
}, (opts) => codeViewDeleteServerFn.__executeServer(opts));
var codeViewDeleteServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewDeleteServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewDeleteRoute");
});
export { codeViewDeleteServerFn_createServerFn_handler };
