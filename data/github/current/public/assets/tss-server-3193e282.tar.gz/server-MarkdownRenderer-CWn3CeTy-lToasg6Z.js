import { L as ChevronRightIcon, Or as ShieldIcon, an as IconButton, n as ActionList, o as AlertIcon, vn as LawIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as rehype, t as all } from "./server-lowlight-Dh7yBHKt-DO4QO0C5.js";
import { n as getLanguageInfo } from "./server-language-info-CBuUUErk-BvCk1GBy.js";
import { createContext, createElement, use, useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
import { SKIP, visit } from "unist-util-visit";
import { h } from "hastscript";
import { visitParents } from "unist-util-visit-parents";
import { source } from "unist-util-source";
import { findAndReplace } from "mdast-util-find-and-replace";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkCjkFriendly from "remark-cjk-friendly";
import remarkCjkFriendlyGfmStrikethrough from "remark-cjk-friendly-gfm-strikethrough";
/**
* Parse a JSON string property from a props object.
*/
function parseJsonAttribute(props, propertyName) {
	return propertyName in props && typeof props[propertyName] === "string" ? JSON.parse(props[propertyName]) : null;
}
/** Convert kebab-case data- attribute name to camelCase property name for hProperties. */
var dataAttrToPropName = (attributeName) => attributeName.replaceAll(/-\w/g, (match) => match[1]?.toUpperCase() ?? "");
var CodeBlock_module_default = {
	assistive: "CodeBlock-module_gAoy9G_assistive",
	code: "CodeBlock-module_gAoy9G_code",
	codeContainer: "CodeBlock-module_gAoy9G_codeContainer",
	codeWrap: "CodeBlock-module_gAoy9G_codeWrap",
	container: "CodeBlock-module_gAoy9G_container",
	copyButton: "CodeBlock-module_gAoy9G_copyButton",
	copyContainer: "CodeBlock-module_gAoy9G_copyContainer",
	copyContent: "CodeBlock-module_gAoy9G_copyContent",
	header: "CodeBlock-module_gAoy9G_header",
	immersive: "CodeBlock-module_gAoy9G_immersive",
	languageName: "CodeBlock-module_gAoy9G_languageName"
};
var LanguageDot_module_default = {
	languageDot: "LanguageDot-module_-Wuv8a_languageDot",
	languageDotCompact: "LanguageDot-module_-Wuv8a_languageDotCompact"
};
function LanguageDot({ color, variant }) {
	return /* @__PURE__ */ jsx("span", {
		style: { backgroundColor: color },
		className: variant === "compact" ? LanguageDot_module_default.languageDotCompact : LanguageDot_module_default.languageDot
	});
}
LanguageDot.displayName = "LanguageDot";
/**
* Shared context for React blocks to get state.
*/
var ExtensionContext = createContext({});
ExtensionContext.displayName = "ExtensionContext";
function useFilteredCopilotAnnotations(copilotAnnotations, startOffset, endOffset) {
	const $ = c(19);
	let t0;
	bb0: {
		if (startOffset === void 0 || endOffset === void 0 || !copilotAnnotations) {
			let t1;
			if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
				t1 = {
					publicCodeReferences: [],
					codeVulnerabilities: []
				};
				$[0] = t1;
			} else t1 = $[0];
			t0 = t1;
			break bb0;
		}
		const { PublicCodeReference, CodeVulnerability } = copilotAnnotations;
		let t1;
		if ($[1] !== PublicCodeReference || $[2] !== endOffset || $[3] !== startOffset) {
			t1 = PublicCodeReference?.filter((r) => r.startOffset >= startOffset && r.endOffset <= endOffset);
			$[1] = PublicCodeReference;
			$[2] = endOffset;
			$[3] = startOffset;
			$[4] = t1;
		} else t1 = $[4];
		let t2;
		if ($[5] !== CodeVulnerability || $[6] !== endOffset || $[7] !== startOffset) {
			t2 = CodeVulnerability?.filter((v) => v.startOffset >= startOffset && v.endOffset <= endOffset);
			$[5] = CodeVulnerability;
			$[6] = endOffset;
			$[7] = startOffset;
			$[8] = t2;
		} else t2 = $[8];
		let t3;
		if ($[9] !== t1 || $[10] !== t2) {
			t3 = {
				publicCodeReferences: t1,
				codeVulnerabilities: t2
			};
			$[9] = t1;
			$[10] = t2;
			$[11] = t3;
		} else t3 = $[11];
		t0 = t3;
	}
	const { publicCodeReferences: t1, codeVulnerabilities: t2 } = t0;
	let t3;
	if ($[12] !== t1) {
		t3 = t1 === void 0 ? [] : t1;
		$[12] = t1;
		$[13] = t3;
	} else t3 = $[13];
	const publicCodeReferences = t3;
	let t4;
	if ($[14] !== t2) {
		t4 = t2 === void 0 ? [] : t2;
		$[14] = t2;
		$[15] = t4;
	} else t4 = $[15];
	const codeVulnerabilities = t4;
	let t5;
	if ($[16] !== codeVulnerabilities || $[17] !== publicCodeReferences) {
		t5 = {
			publicCodeReferences,
			codeVulnerabilities
		};
		$[16] = codeVulnerabilities;
		$[17] = publicCodeReferences;
		$[18] = t5;
	} else t5 = $[18];
	return t5;
}
var AnnotationsList_module_default = {
	chevron: "AnnotationsList-module_wd45QW_chevron",
	items: "AnnotationsList-module_wd45QW_items",
	summary: "AnnotationsList-module_wd45QW_summary",
	summaryText: "AnnotationsList-module_wd45QW_summaryText"
};
function AnnotationsList({ summary, icon, children }) {
	return /* @__PURE__ */ jsxs("details", { children: [/* @__PURE__ */ jsxs("summary", {
		className: AnnotationsList_module_default.summary,
		children: [
			/* @__PURE__ */ jsx("span", {
				className: AnnotationsList_module_default.chevron,
				children: /* @__PURE__ */ jsx(ChevronRightIcon, { size: "small" })
			}),
			icon,
			" ",
			/* @__PURE__ */ jsx("span", {
				className: AnnotationsList_module_default.summaryText,
				children: summary
			})
		]
	}), /* @__PURE__ */ jsx("div", {
		className: AnnotationsList_module_default.items,
		children: /* @__PURE__ */ jsx(ActionList, {
			variant: "full",
			children
		})
	})] });
}
AnnotationsList.displayName = "AnnotationsList";
/**
* Extracts owner/repo (nwo) and repository name from a GitHub URL
* @param url GitHub URL
* @returns Object containing nwo and repo name, or null if URL doesn't match expected format
*/
function extractRepoInfo(url) {
	const match = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)/.exec(url);
	if (!match || !match[1] || !match[2]) return null;
	return {
		owner: match[1],
		name: match[2]
	};
}
function referencesToRepos(references) {
	const repos = /* @__PURE__ */ new Map();
	for (const annotation of references) {
		const repo = extractRepoInfo(annotation.sourceURL);
		if (!repo) continue;
		const { owner, name } = repo;
		repos.set(name, {
			name,
			owner,
			url: `https://github.com/${owner}/${name}`,
			license: annotation.license === "NOASSERTION" ? null : annotation.license
		});
	}
	return Array.from(repos.values()).sort((a, b) => a.name.localeCompare(b.name));
}
function ReferenceAnnotations({ references }) {
	const repositories = referencesToRepos(references);
	return /* @__PURE__ */ jsx(AnnotationsList, {
		icon: /* @__PURE__ */ jsx("span", {
			style: { color: "var(--fgColor-muted)" },
			children: /* @__PURE__ */ jsx(LawIcon, {})
		}),
		summary: `Public code references from ${repositories.length} ${repositories.length === 1 ? "repository" : "repositories"}`,
		children: repositories.map((repo) => /* @__PURE__ */ jsxs(ActionList.LinkItem, {
			href: repo.url,
			tabIndex: void 0,
			children: [
				/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(GitHubAvatar, {
					src: `https://github.com/${repo.owner}.png`,
					alt: `@${repo.owner} avatar`,
					size: 20
				}) }),
				repo.owner,
				"/",
				repo.name,
				/* @__PURE__ */ jsx(ActionList.Description, { children: repo.license ? `${repo.license} license` : "No license" })
			]
		}, repo.name))
	});
}
ReferenceAnnotations.displayName = "ReferenceAnnotations";
function VulnerabilityAnnotations({ vulnerabilities }) {
	return /* @__PURE__ */ jsx(AnnotationsList, {
		icon: /* @__PURE__ */ jsx("span", {
			style: { color: "var(--fgColor-attention)" },
			children: /* @__PURE__ */ jsx(AlertIcon, {})
		}),
		summary: `${vulnerabilities.length} ${vulnerabilities.length === 1 ? "vulnerability" : "vulnerabilities"} detected`,
		children: vulnerabilities.map((vulnerability, i) => /* @__PURE__ */ jsxs(ActionList.Item, { children: [vulnerability.uiType, /* @__PURE__ */ jsx(ActionList.Description, {
			variant: "block",
			children: vulnerability.uiDescription
		})] }, i))
	});
}
VulnerabilityAnnotations.displayName = "VulnerabilityAnnotations";
var CodeInsightsDialog = ({ publicCodeReferences, codeVulnerabilities, onClose }) => {
	const handleClose = () => {
		onClose();
	};
	return /* @__PURE__ */ jsxs(Dialog, {
		title: "Code insights",
		subtitle: "Find matches across our platform or check for code vulnerabilities.",
		onClose: handleClose,
		width: "xlarge",
		children: [publicCodeReferences && publicCodeReferences.length > 0 && /* @__PURE__ */ jsx(ReferenceAnnotations, { references: publicCodeReferences.map((r) => r.details) }), codeVulnerabilities && codeVulnerabilities.length > 0 && /* @__PURE__ */ jsx(VulnerabilityAnnotations, { vulnerabilities: codeVulnerabilities.map((v) => v.details) })]
	});
};
CodeInsightsDialog.displayName = "CodeInsightsDialog";
var UnwrapIcon = () => /* @__PURE__ */ jsx("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "16",
	height: "16",
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	children: /* @__PURE__ */ jsx("path", {
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		strokeWidth: "1.5",
		d: "M1 13h3M1 8h14M1 3h14"
	})
});
UnwrapIcon.displayName = "UnwrapIcon";
var WrapIcon = () => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "16",
	height: "16",
	fill: "none",
	viewBox: "0 0 16 16",
	"aria-hidden": "true",
	children: [/* @__PURE__ */ jsx("path", {
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		strokeWidth: "1.5",
		d: "M1 13h3M1 3h14"
	}), /* @__PURE__ */ jsx("path", {
		fill: "currentColor",
		fillRule: "evenodd",
		d: "M1 7.25a.75.75 0 0 0 0 1.5h11.5a1.75 1.75 0 1 1 0 3.5H9.536v-.464a.679.679 0 0 0-1.086-.543l-1.619 1.214a.68.68 0 0 0 0 1.086l1.619 1.214a.679.679 0 0 0 1.086-.543v-.464H12.5a3.25 3.25 0 0 0 0-6.5z",
		clipRule: "evenodd"
	})]
});
WrapIcon.displayName = "WrapIcon";
function CodeBlock(t0) {
	const $ = c(6);
	const { language, children, code, startOffset, endOffset } = t0;
	const { color, name: displayName } = getLanguageInfo(language);
	const codeBlockLabelId = useId();
	const { copilotAnnotations, chatMode, wrapCodeLines, onWrapCodeLinesChange } = use(ExtensionContext);
	const [isDialogOpen, setIsDialogOpen] = useState(false);
	const { publicCodeReferences, codeVulnerabilities } = useFilteredCopilotAnnotations(copilotAnnotations, startOffset, endOffset);
	let t1;
	if ($[0] !== chatMode || $[1] !== onWrapCodeLinesChange || $[2] !== wrapCodeLines) {
		t1 = () => {
			onWrapCodeLinesChange?.(!wrapCodeLines);
			sendEvent("dotcom_chat.activate", {
				target: wrapCodeLines ? "CODE_BLOCK_UNWRAP" : "CODE_BLOCK_WRAP",
				mode: chatMode
			});
		};
		$[0] = chatMode;
		$[1] = onWrapCodeLinesChange;
		$[2] = wrapCodeLines;
		$[3] = t1;
	} else t1 = $[3];
	const onWrapToggle = t1;
	let t2;
	if ($[4] !== chatMode) {
		t2 = () => {
			sendEvent("dotcom_chat.activate", {
				target: "CODE_BLOCK_COPY",
				mode: chatMode
			});
		};
		$[4] = chatMode;
		$[5] = t2;
	} else t2 = $[5];
	return jsxs(Fragment$1, { children: [jsxs("figure", {
		className: clsx(CodeBlock_module_default.container, {
			[CodeBlock_module_default.immersive]: chatMode === "immersive",
			[CodeBlock_module_default.assistive]: chatMode === "assistive"
		}),
		"aria-labelledby": codeBlockLabelId,
		children: [
			jsxs("div", {
				className: CodeBlock_module_default.header,
				children: [
					jsx(LanguageDot, { color }),
					jsx("span", {
						id: codeBlockLabelId,
						className: CodeBlock_module_default.languageName,
						children: displayName || "Code"
					}),
					onWrapCodeLinesChange && jsx(IconButton, {
						variant: "invisible",
						icon: wrapCodeLines ? UnwrapIcon : WrapIcon,
						"aria-label": wrapCodeLines ? "Unwrap" : "Wrap",
						onClick: onWrapToggle
					}),
					(publicCodeReferences.length > 0 || codeVulnerabilities.length > 0) && jsx(IconButton, {
						variant: "invisible",
						icon: ShieldIcon,
						"aria-label": "Code insights",
						onClick: () => {
							setIsDialogOpen(true);
							sendEvent("dotcom_chat.activate", {
								target: "CODE_BLOCK_SHIELD",
								mode: chatMode
							});
						}
					})
				]
			}),
			jsx("div", {
				className: CodeBlock_module_default.copyContainer,
				children: jsx("div", {
					className: CodeBlock_module_default.copyContent,
					children: jsx(CopyToClipboardButton, {
						textToCopy: code,
						ariaLabel: "Copy code",
						className: CodeBlock_module_default.copyButton,
						onCopy: t2
					})
				})
			}),
			jsx("div", {
				className: CodeBlock_module_default.codeContainer,
				children: jsx("pre", {
					className: CodeBlock_module_default.code,
					tabIndex: 0,
					children: jsx("code", {
						className: clsx(wrapCodeLines && CodeBlock_module_default.codeWrap),
						children
					})
				})
			})
		]
	}), isDialogOpen && jsx(CodeInsightsDialog, {
		publicCodeReferences,
		codeVulnerabilities,
		onClose: () => setIsDialogOpen(false)
	})] });
}
CodeBlock.displayName = "CodeBlock";
var codeblockAttribute = "data-codeblock-props";
var codeblockProperty = dataAttrToPropName(codeblockAttribute);
var reactComponents$1 = { code: (props, fallthrough) => {
	const codeblockProps = parseJsonAttribute(props, codeblockAttribute);
	if (!codeblockProps) return fallthrough;
	return /* @__PURE__ */ jsx(CodeBlock, {
		...codeblockProps,
		children: props.children
	});
} };
function codeBlocksExtension() {
	return {
		transformMarkdown: (tree) => visit(tree, "code", (node) => {
			node.data = {
				...node.data,
				hName: "code",
				hProperties: { [codeblockProperty]: JSON.stringify({
					language: node.lang ?? "",
					code: node.value,
					startOffset: node.position?.start.offset ?? -1,
					endOffset: node.position?.end.offset ?? -1
				}) }
			};
		}),
		transformHtml: (tree) => visit(tree, "element", (node, i, parent) => {
			const child = node.children?.[0];
			if (parent && i !== void 0 && node.tagName === "pre" && node.children?.length === 1 && child?.type === "element" && child.tagName === "code" && codeblockProperty in child.properties) parent.children.splice(i, 1, child);
		}),
		reactComponents: reactComponents$1
	};
}
/**
* Source: https://github.com/github/copilot/blob/main/docs/client-guidance/rendering-and-ingestion-guidelines.md#image-rendering
*/
var trustedDomains = [
	"raw.githubusercontent.com/",
	"private-user-images.githubusercontent.com/",
	"avatars.githubusercontent.com/",
	"gist.github.com/assets/",
	"github.com/user-attachments/assets/",
	"github.localhost/user-attachments/assets/"
];
/**
* Requires that images in rendered markdown come from an explicitly allow-listed domain.
*/
var ensureTrustedSource = (tree, file) => visit(tree, (node, index, parent) => {
	if (node.type !== "element") return;
	if (node.tagName === "img" && "src" in node.properties) {
		const src = node.properties.src;
		let url = void 0;
		try {
			url = new URL(src, window.location.origin);
		} catch {}
		const path = url ? url.hostname + url.pathname : "";
		if (!url || !trustedDomains.some((domain) => path.startsWith(domain))) {
			const spanNode = {
				type: "element",
				tagName: "span",
				properties: {},
				children: [{
					type: "text",
					value: source(file, node) ?? ""
				}]
			};
			if (parent && typeof index === "number") {
				parent.children[index] = spanNode;
				return [SKIP, index];
			}
		}
	}
});
function imagesExtension() {
	return { transformHtml: ensureTrustedSource };
}
var defaultDisplayDelimiters = [{
	open: /(?:^|\\n)\$\$/,
	close: /\$\$/
}];
/**
* By default we support:
* 1. Single dollar signs without inside whitespace: `$x$` but not `$ x $`
* 2. Double dollar signs without inside whitespace: `$$x$$` but not `$$ x $$`. NOTE this is an exception to (1) since
*    we technically have single dollar signs without leading whitespace here!
* 3. Dollar-backticks with or without inside whitespace: ``$`x`$``
*/
var defaultInlineDelimiters = [
	{
		open: /\$`/,
		close: /`\$/
	},
	{
		open: /\$\$(?! )/,
		close: /(?<! )\$\$/
	},
	{
		open: /\$(?![ $])/,
		close: /(?<![ $])\$/
	}
];
var defaultCodeBlockLanguages = new Set(["math"]);
function buildDisplayNode(math) {
	return {
		type: "displaymath",
		value: math,
		data: {
			hName: "math-renderer",
			hProperties: {
				className: "js-display-math",
				style: "display: block; text-align: center;"
			},
			hChildren: [{
				type: "text",
				value: math
			}]
		}
	};
}
var displaymath = (delimiters) => {
	const expressions = delimiters.map(({ open, close }) => new RegExp(`(?:^|\\n) *${open.source}((?:\n|.)+?)${close.source}(?= *(?:\\n|$))`, "g"));
	return (tree) => findAndReplace(tree, expressions.map((regex) => [regex, (_, math) => buildDisplayNode(math)]));
};
var codemath = (languages) => (tree) => visit(tree, "code", (node, i, parent) => {
	if (!node.lang || !languages.has(node.lang) || !parent || i === void 0) return;
	parent.children.splice(i, 1, buildDisplayNode(node.value));
});
function buildInlineNode(math) {
	return {
		type: "inlinemath",
		value: math,
		data: {
			hName: "math-renderer",
			hProperties: {
				className: "js-inline-math",
				style: "display: inline-block;"
			},
			hChildren: [{
				type: "text",
				value: math
			}]
		}
	};
}
var inlinemath = (delimiters) => {
	const expressions = delimiters.map(({ open, close }) => new RegExp(`(?<![a-z0-9])${open.source}(.+?)${close.source}(?![a-z0-9])`, "g"));
	return (tree) => findAndReplace(tree, expressions.map((regex) => [regex, (_, math) => buildInlineNode(math)]));
};
/**
* Remark extension for rendering LaTeX mathematics. Supports display / block math, inline math, and code block
* math. Applies config to prepare for transformation to HTML using `mdast-util-to-hast`.
*/
var remarkMath = ({ displayDelimiters = defaultDisplayDelimiters, inlineDelimiters = defaultInlineDelimiters, codeBlockLanguages = defaultCodeBlockLanguages } = {}) => (tree) => {
	displaymath(displayDelimiters)(tree);
	codemath(codeBlockLanguages)(tree);
	inlinemath(inlineDelimiters)(tree);
};
var remarkOptions = {
	displayDelimiters: [...defaultDisplayDelimiters, {
		open: /\[\s/,
		close: /\s\]/
	}],
	inlineDelimiters: [...defaultInlineDelimiters, {
		open: /\( /,
		close: / \)/
	}]
};
var reactComponents = { ["math-renderer"]: ({ node, children, className, ...props }) => createElement("math-renderer", {
	...props,
	class: className
}, children) };
function mathExtension() {
	return {
		transformMarkdown: remarkMath(remarkOptions),
		reactComponents
	};
}
var hastOpenLinksInNewTab = (tree) => visit(tree, (node) => {
	if (node.type !== "element") return;
	if (node.tagName === "a" && "href" in node.properties) {
		if (node.properties.href.startsWith("#")) return;
	}
	if (node.tagName === "a" || "target" in node.properties) {
		node.properties.target = "_blank";
		node.properties.rel = "noopener noreferrer";
	}
	if (!("target" in node.properties) && ("xlink:href" in node.properties || "href" in node.properties)) node.properties["xlink:show"] = "new";
});
function linksExtension({ openLinksInCurrentTab }) {
	return { transformHtml: openLinksInCurrentTab ? void 0 : hastOpenLinksInNewTab };
}
var MarkdownRenderer_module_default = {
	container: "MarkdownRenderer-module_UIpw6W_container",
	contentContainer: "MarkdownRenderer-module_UIpw6W_contentContainer",
	fadeInContent: "MarkdownRenderer-module_UIpw6W_fadeInContent",
	noFade: "MarkdownRenderer-module_UIpw6W_noFade"
};
var renderFallthrough = Symbol("renderFallthrough");
var ReactComponentsExtension = { entries: (extension) => Object.entries(extension) };
function combineComponents(extensions) {
	const result = {};
	for (const components of extensions) for (const [Element, renderer] of ReactComponentsExtension.entries(components)) if (renderer) {
		const fallthroughRenderer = result[Element];
		result[Element] = (props) => {
			const renderResult = renderer(props, renderFallthrough);
			if (renderResult !== renderFallthrough) return renderResult;
			return fallthroughRenderer?.(props) ?? createElement(Element, props);
		};
	}
	return result;
}
function getComponents(extensions) {
	return extensions.map((e) => e.reactComponents).filter((e) => !!e);
}
/**
* Ensures the components configuration changes as little as possible. Changes are particularly expensive because they
* cause a remount of all react components rendered in Markdown. This also causes animations to restart and just
* general jankiness. This does still rely on all components ensuring that their `reactComponents` field remains
* constant - if it changes we will log a warning to the console. We still respect these changes to avoid bugs.
*/
function useCombinedComponents(extensions) {
	const $ = c(5);
	let t0;
	if ($[0] !== extensions) {
		t0 = () => combineComponents(getComponents(extensions));
		$[0] = extensions;
		$[1] = t0;
	} else t0 = $[1];
	const [combinedComponents, setCombinedComponents] = useState(t0);
	const prevExtensions = useRef(extensions);
	let t1;
	let t2;
	if ($[2] !== extensions) {
		t1 = () => {
			const prevComponents = getComponents(prevExtensions.current);
			const currentComponents = getComponents(extensions);
			prevExtensions.current = extensions;
			let error = null;
			if (prevComponents.length !== currentComponents.length) error = /* @__PURE__ */ new Error("A `MarkdownRenderer` extension containing a `reactComponents` field was added or removed. React extensions must remain referentially constant.");
			for (const [i, prevComponent] of prevComponents.entries()) if (prevComponent !== currentComponents[i]) error = /* @__PURE__ */ new Error("The `reactComponents` field in at least one `MarkdownRenderer` extension changed, or extensions containing `reactComponent` fields were reordered. React extensions must remain referentially constant.\nNOTE: This error may be safely ignored if it occurs due to hot-reloading in local development.");
			if (error) {
				setCombinedComponents(combineComponents(currentComponents));
				(async () => {
					throw error;
				})();
			}
		};
		t2 = [extensions];
		$[2] = extensions;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	useEffect(t1, t2);
	return combinedComponents;
}
/** Indicates the termination of streaming markdown. */
var streamingIndicatorChar = "";
var emptyOrWhitespaceRegex = /^\s*$/;
/** RegExes must match a 3-char sliding window and be start-anchored. */
var autoClosableDelimiters = [
	[
		/^\s`/,
		/^[^\s]`/,
		"`"
	],
	[
		/^\s_/,
		/^[^\s]_/,
		"_"
	],
	[
		/^\s\*\*/,
		/^[^\s]\*\*/,
		"**"
	],
	[
		/^\s~~/,
		/^[^\s]~~/,
		"~~"
	],
	[
		/^\s\*/,
		/^[^\s]\*/,
		"*"
	],
	[
		/^\s\[/,
		/^[^\s]\]/,
		"](#)"
	],
	[
		/^\]\(/,
		/^[^\s]\)/,
		")"
	]
];
/**
* Attempt to identify common unclosed formatting tags and replace them with nodes. Only looks at the
* currently-streaming text node, so will only apply basic inline formatting without nested tags. This isn't perfect,
* but it doesn't have to be because any issues will resolve themselves as the content keeps streaming. This just
* improves the appearance of streaming markdown by minimizing reformatting (which causes flickering).
*/
function applyUnclosedFormatting(text) {
	const delimiterQueue = /* @__PURE__ */ new Set();
	for (let i = -1, window = ` ${text.slice(0, 2)}`; i <= text.length - 3; i++, window = text.slice(i, i + 3)) for (const [openRegex, closeRegex, closeDelimiter] of autoClosableDelimiters) if (!delimiterQueue.has(closeDelimiter) && openRegex.test(window)) {
		delimiterQueue.add(closeDelimiter);
		break;
	} else if (delimiterQueue.has(closeDelimiter) && closeRegex.test(window)) {
		delimiterQueue.delete(closeDelimiter);
		break;
	}
	for (const delimiter of Array.from(delimiterQueue).reverse()) text += delimiter;
	return text;
}
/**
* Applies styles and properties for streaming Markdown content.
*/
function streamingExtension({ isStreaming }) {
	if (!isStreaming) return {};
	return {
		preprocessMarkdown: (md) => `${applyUnclosedFormatting(md)}\n${streamingIndicatorChar}`,
		transformMarkdown: (tree) => visitParents(tree, (node, ancestors) => {
			if ("value" in node && node.value?.includes(streamingIndicatorChar)) {
				node.value = node.value.replace(streamingIndicatorChar, "");
				node.isStreaming = true;
				for (const ancestor of ancestors) ancestor.isStreaming = true;
			}
		}),
		transformHtml: (tree) => visit(tree, "text", (textNode, nodeIndex, parent) => {
			if (parent === void 0 || nodeIndex === void 0 || emptyOrWhitespaceRegex.test(textNode.value)) return;
			const wordNodes = textNode.value.split(" ").map((w, i, { length }) => {
				const content = i < length - 1 ? `${w} ` : w;
				if (emptyOrWhitespaceRegex.test(content)) return {
					type: "text",
					value: content
				};
				else return h("span", content);
			});
			parent.children.splice(nodeIndex, 1, ...wordNodes);
			return nodeIndex + wordNodes.length;
		})
	};
}
/**
* Apply this class to elements to suppress the fade-in animation. This should only be done as a workaround if there
* is a conflicting animation already applied (ie, to `Spinner` components).
*/
var disableStreamingFadeIn = MarkdownRenderer_module_default.noFade;
var emptyArray = [];
function MarkdownRenderer({ ref, className, markdown, chatMode, openLinksInCurrentTab, onLinkClick, extensions: additionalExtensions = emptyArray, isStreaming, accessibleHeader, copilotAnnotations, wrapCodeLines, onWrapCodeLinesChange }) {
	const [fadingInContent, setFadingInContent] = useState(isStreaming ?? false);
	useEffect(() => {
		if (!isStreaming) {
			const timeout = setTimeout(() => {
				setFadingInContent(false);
			}, 750);
			return () => clearTimeout(timeout);
		} else setFadingInContent(true);
	}, [isStreaming]);
	const extensions = useMemo(() => {
		return [
			codeBlocksExtension(),
			mathExtension(),
			linksExtension({ openLinksInCurrentTab }),
			streamingExtension({ isStreaming: fadingInContent }),
			imagesExtension(),
			...additionalExtensions
		];
	}, [
		additionalExtensions,
		openLinksInCurrentTab,
		fadingInContent
	]);
	const remarkPlugins = [
		remarkGfm,
		remarkCjkFriendly,
		remarkCjkFriendlyGfmStrikethrough,
		...extensions.map((e) => e.transformMarkdown ? () => e.transformMarkdown : void 0).filter((e_0) => !!e_0)
	];
	const { isBrowser } = useRuntimeEnvironment();
	const rehypePlugins = useMemo(() => {
		return isBrowser ? [[rehype, { languages: all }], ...extensions.map((e_1) => e_1.transformHtml ? () => e_1.transformHtml : void 0).filter((e_2) => !!e_2)] : [];
	}, [extensions, isBrowser]);
	const components = useCombinedComponents(extensions);
	const preprocessedMarkdown = extensions.reduce((md, ext) => ext.preprocessMarkdown?.(md) ?? md, markdown);
	const containerRef = useRef(null);
	const mergedRef = useCallback((node) => {
		containerRef.current = node;
		if (typeof ref === "function") ref(node);
		else if (ref) ref.current = node;
	}, [ref]);
	useEffect(() => {
		if (!onLinkClick) return;
		const container = containerRef.current;
		if (!container) return;
		const handleClick = (event) => {
			const target = event.target.closest("a");
			if (target && container.contains(target)) onLinkClick(event);
		};
		container.addEventListener("click", handleClick);
		return () => container.removeEventListener("click", handleClick);
	}, [onLinkClick]);
	return /* @__PURE__ */ jsxs(ExtensionContext, {
		value: useMemo(() => ({
			isStreaming,
			chatMode,
			copilotAnnotations,
			wrapCodeLines,
			onWrapCodeLinesChange
		}), [
			isStreaming,
			chatMode,
			copilotAnnotations,
			wrapCodeLines,
			onWrapCodeLinesChange
		]),
		children: [accessibleHeader && /* @__PURE__ */ jsx("h3", {
			className: "sr-only",
			children: accessibleHeader
		}), /* @__PURE__ */ jsx("div", {
			ref: mergedRef,
			className: clsx("markdown-body", MarkdownRenderer_module_default.container, className, fadingInContent && MarkdownRenderer_module_default.fadeInContent),
			style: { "--MarkdownRenderer_streaming-fade-duration": `750ms` },
			"data-copilot-markdown": true,
			children: /* @__PURE__ */ jsx(ReactMarkdown, {
				remarkPlugins,
				rehypePlugins,
				components,
				children: preprocessedMarkdown
			})
		})]
	});
}
MarkdownRenderer.displayName = "MarkdownRenderer";
export { parseJsonAttribute as a, disableStreamingFadeIn as i, MarkdownRenderer as n, useFilteredCopilotAnnotations as o, dataAttrToPropName as r, CodeInsightsDialog as t };
