import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { hi as TriangleDownIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { t as CoreSsoBanner } from "./server-CoreSsoBanner-BLGiDntO-CUANB3R8.js";
import { Suspense, lazy, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var SuspendingLazyBanner = lazy(async () => {
	return { default: (await import("./server-GlobalSsoBanner-DmRvabMe-BzVFNYw3.js")).GlobalSsoBanner };
});
/**
* Lazily rendered SSO banner which avoids importing the full banner component unless it will actually be rendered.
* Displays a high-fidelity fallback while loading to hide the laziness from the user. Hides itself automatically if
* lazy-loading fails. Provides its own Suspense boundary so that parent components will not be suspended.
*/
SuspendingLazyBanner.displayName = "SuspendingLazyBanner";
function LazyGlobalSsoBanner(t0) {
	const $ = c(4);
	const { ssoOrgs, onConfirm } = t0;
	const [dismissedBeforeLoad, setDismissedBeforeLoad] = useState(false);
	if (!ssoOrgs || ssoOrgs.length === 0 || dismissedBeforeLoad) return null;
	let t1;
	if ($[0] !== onConfirm || $[1] !== ssoOrgs) {
		let t2;
		if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = () => setDismissedBeforeLoad(true);
			$[3] = t2;
		} else t2 = $[3];
		t1 = jsx(ErrorBoundary, {
			fallback: null,
			children: jsx(Suspense, {
				fallback: jsx(CoreSsoBanner, {
					ssoOrgs,
					onDismiss: t2,
					primaryAction: ssoOrgs.length === 1 ? jsx(ButtonComponent, {
						disabled: true,
						children: "Single sign-on"
					}) : jsx(ButtonComponent, {
						disabled: true,
						size: "small",
						trailingVisual: TriangleDownIcon,
						children: "Single sign-on"
					})
				}),
				children: jsx(SuspendingLazyBanner, {
					ssoOrgs,
					onConfirm
				})
			})
		});
		$[0] = onConfirm;
		$[1] = ssoOrgs;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
LazyGlobalSsoBanner.displayName = "LazyGlobalSsoBanner";
export { LazyGlobalSsoBanner as t };
