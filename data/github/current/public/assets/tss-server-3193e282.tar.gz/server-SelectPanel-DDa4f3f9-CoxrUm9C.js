import { a as useFeatureFlag, i as VisuallyHidden, o as useId$1, r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { c as Text$1, i as ButtonComponent, r as ButtonBase } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Hi as useProvidedRefOrCreate, Jr as Stack$1, Mi as XIcon, Qt as Heading$2, Wi as useSafeTimeout, an as IconButton, hi as TriangleDownIcon, n as ActionList, o as AlertIcon, r as ActionListContainerContext, wr as SearchIcon, zi as sharedClasses } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { r as useProvidedStateOrCreate, t as isAlphabetKey } from "./server-useMnemonics-D3ntHtHT-ctYxUroX.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import React, { createContext, forwardRef, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { isValidElementType } from "react-is";
import { announce, announceFromElement } from "@primer/live-region-element";
import { FocusKeys, scrollIntoView } from "@primer/behaviors";
import { useVirtualizer } from "@tanstack/react-virtual";
var CheckboxGroupContext = /* @__PURE__ */ createContext({});
var classes$4 = {
	"Checkbox": "prc-Checkbox-Checkbox-jjOgT",
	"checkmarkOut": "prc-Checkbox-checkmarkOut-mrgEX",
	"checkmarkIn": "prc-Checkbox-checkmarkIn-73iWj"
};
/**
* An accessible, native checkbox component
*/
var Checkbox = /* @__PURE__ */ React.forwardRef(({ checked, className, defaultChecked, indeterminate, disabled, onChange, required, validationStatus, value, ...rest }, ref) => {
	const checkboxRef = useProvidedRefOrCreate(ref);
	const checkboxGroupContext = useContext(CheckboxGroupContext);
	const handleOnChange = (e) => {
		checkboxGroupContext.onChange && checkboxGroupContext.onChange(e);
		onChange && onChange(e);
	};
	const inputProps = {
		type: "checkbox",
		disabled,
		ref: checkboxRef,
		checked: indeterminate ? false : checked,
		defaultChecked,
		required,
		["aria-required"]: required ? "true" : "false",
		["aria-invalid"]: validationStatus === "error" ? "true" : "false",
		onChange: handleOnChange,
		value,
		name: value,
		...rest
	};
	useIsomorphicLayoutEffect(() => {
		if (checkboxRef.current) checkboxRef.current.indeterminate = indeterminate || false;
	}, [
		indeterminate,
		checked,
		checkboxRef
	]);
	useEffect(() => {
		const { current: checkbox } = checkboxRef;
		if (!checkbox) return;
		if (indeterminate) checkbox.setAttribute("aria-checked", "mixed");
		else checkbox.setAttribute("aria-checked", checkbox.checked ? "true" : "false");
	});
	return /* @__PURE__ */ jsx("input", {
		...inputProps,
		className: clsx(className, sharedClasses.Input, classes$4.Checkbox)
	});
});
Checkbox.displayName = "Checkbox";
Checkbox.__SLOT__ = Symbol("Checkbox");
var FormControlContext = /* @__PURE__ */ createContext(null);
var FormControlContextProvider = FormControlContext.Provider;
/** This is the private/internal interface for subcomponents of `FormControl`. */
function useFormControlContext() {
	var _useContext;
	return (_useContext = useContext(FormControlContext)) !== null && _useContext !== void 0 ? _useContext : {};
}
/**
* Make any component compatible with `FormControl`'s automatic wiring up of accessibility attributes & validation by
* reading the props from this hook and merging them with the passed-in props. If used outside of `FormControl`, this
* hook has no effect.
*
* @param externalProps The external props passed to this component. If provided, these props will be merged with the
* `FormControl` props, with external props taking priority.
*/
function useFormControlForwardedProps(externalProps) {
	const $ = c(9);
	const context = useContext(FormControlContext);
	if (!context) return externalProps;
	let t0;
	if ($[0] !== context.captionId || $[1] !== context.validationMessageId) {
		t0 = [context.validationMessageId, context.captionId].filter(Boolean).join(" ") || void 0;
		$[0] = context.captionId;
		$[1] = context.validationMessageId;
		$[2] = t0;
	} else t0 = $[2];
	let t1;
	if ($[3] !== context.disabled || $[4] !== context.id || $[5] !== context.required || $[6] !== externalProps || $[7] !== t0) {
		t1 = {
			disabled: context.disabled,
			id: context.id,
			required: context.required,
			"aria-describedby": t0,
			...externalProps
		};
		$[3] = context.disabled;
		$[4] = context.id;
		$[5] = context.required;
		$[6] = externalProps;
		$[7] = t0;
		$[8] = t1;
	} else t1 = $[8];
	return t1;
}
var classes$3 = {
	"Overlay": "prc-SelectPanel-Overlay-tEbxh",
	"Wrapper": "prc-SelectPanel-Wrapper-OD-e6",
	"Header": "prc-SelectPanel-Header-p2DSz",
	"Title": "prc-SelectPanel-Title-4cax5",
	"Subtitle": "prc-SelectPanel-Subtitle-5L2Fr",
	"Notice": "prc-SelectPanel-Notice-zIRk9",
	"Footer": "prc-SelectPanel-Footer-Rxa8K",
	"FilteredActionList": "prc-SelectPanel-FilteredActionList--VY7U",
	"Message": "prc-SelectPanel-Message-4RsG4",
	"MessageTitle": "prc-SelectPanel-MessageTitle-mTq0E",
	"MessageBody": "prc-SelectPanel-MessageBody-zVnxH",
	"MessageIcon": "prc-SelectPanel-MessageIcon-gpYuP",
	"MessageAction": "prc-SelectPanel-MessageAction-zx88f",
	"ResponsiveCloseButton": "prc-SelectPanel-ResponsiveCloseButton-uA7Py",
	"ResponsiveFooter": "prc-SelectPanel-ResponsiveFooter-qnA4v",
	"SecondaryAction": "prc-SelectPanel-SecondaryAction-AFlHt",
	"CancelSaveButtons": "prc-SelectPanel-CancelSaveButtons-DvvZo",
	"ResponsiveCancelSaveButtons": "prc-SelectPanel-ResponsiveCancelSaveButtons-e8Csd",
	"ResponsiveSaveButton": "prc-SelectPanel-ResponsiveSaveButton-6If1k",
	"Backdrop": "prc-SelectPanel-Backdrop-ukvA6",
	"TextInput": "prc-SelectPanel-TextInput--Qqkq"
};
var SelectPanelMessage = ({ variant, title, children, className, icon: CustomIcon, action }) => {
	const IconComponent = CustomIcon || (variant !== "empty" ? AlertIcon : void 0);
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(classes$3.Message, className),
		children: [
			IconComponent && /* @__PURE__ */ jsx(Octicon, {
				icon: IconComponent,
				className: classes$3.MessageIcon,
				"data-variant": variant
			}),
			/* @__PURE__ */ jsx(Text$1, {
				className: classes$3.MessageTitle,
				children: title
			}),
			/* @__PURE__ */ jsx(Text$1, {
				className: classes$3.MessageBody,
				children
			}),
			action && /* @__PURE__ */ jsx("div", {
				className: classes$3.MessageAction,
				children: action
			})
		]
	});
};
SelectPanelMessage.displayName = "SelectPanelMessage";
var LinkButton = /* @__PURE__ */ forwardRef(({ children, as: Component = "a", ...props }, forwardedRef) => {
	return /* @__PURE__ */ jsx(ButtonBase, {
		as: Component,
		ref: forwardedRef,
		...props,
		children
	});
});
var classes$2 = {
	"SkeletonBox": "prc-Skeleton-SkeletonBox-e93nW",
	"shimmer": "prc-Skeleton-shimmer---lzU"
};
var SkeletonBox = /* @__PURE__ */ React.forwardRef(function SkeletonBox(t0, ref) {
	const $ = c(23);
	let className;
	let delay;
	let height;
	let props;
	let style;
	let width;
	if ($[0] !== t0) {
		({height, width, className, style, delay, ...props} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = delay;
		$[3] = height;
		$[4] = props;
		$[5] = style;
		$[6] = width;
	} else {
		className = $[1];
		delay = $[2];
		height = $[3];
		props = $[4];
		style = $[5];
		width = $[6];
	}
	const [isVisible, setIsVisible] = useState(!delay);
	let t1;
	let t2;
	if ($[7] !== delay) {
		t1 = () => {
			if (delay) {
				const timeoutId = setTimeout(() => {
					setIsVisible(true);
				}, typeof delay === "number" ? delay : delay === "short" ? 300 : 1e3);
				return () => clearTimeout(timeoutId);
			}
		};
		t2 = [delay];
		$[7] = delay;
		$[8] = t1;
		$[9] = t2;
	} else {
		t1 = $[8];
		t2 = $[9];
	}
	useEffect(t1, t2);
	if (!isVisible) return null;
	const t3 = ref;
	let t4;
	if ($[10] !== className) {
		t4 = clsx(className, classes$2.SkeletonBox);
		$[10] = className;
		$[11] = t4;
	} else t4 = $[11];
	let t5;
	if ($[12] !== style) {
		t5 = style || {};
		$[12] = style;
		$[13] = t5;
	} else t5 = $[13];
	let t6;
	if ($[14] !== height || $[15] !== t5 || $[16] !== width) {
		t6 = {
			height,
			width,
			...t5
		};
		$[14] = height;
		$[15] = t5;
		$[16] = width;
		$[17] = t6;
	} else t6 = $[17];
	let t7;
	if ($[18] !== props || $[19] !== t3 || $[20] !== t4 || $[21] !== t6) {
		t7 = /* @__PURE__ */ jsx("div", {
			ref: t3,
			className: t4,
			style: t6,
			...props
		});
		$[18] = props;
		$[19] = t3;
		$[20] = t4;
		$[21] = t6;
		$[22] = t7;
	} else t7 = $[22];
	return t7;
});
var classes$1 = {
	"LoadingSkeleton": "prc-FilteredActionList-LoadingSkeleton-VKyQq",
	"LoadingSpinner": "prc-FilteredActionList-LoadingSpinner-I3a7Y",
	"LoadingSkeletonContainer": "prc-FilteredActionList-LoadingSkeletonContainer-FMeRG"
};
var FilteredActionListLoadingType = class {
	constructor(name, appearsInBody) {
		this.name = name;
		this.appearsInBody = appearsInBody;
	}
};
var FilteredActionListLoadingTypes = {
	bodySpinner: new FilteredActionListLoadingType("body-spinner", true),
	bodySkeleton: new FilteredActionListLoadingType("body-skeleton", true),
	input: new FilteredActionListLoadingType("input", false)
};
var SKELETON_ROW_HEIGHT = 24;
var SKELETON_MIN_ROWS = 3;
function FilteredActionListBodyLoader(t0) {
	const $ = c(4);
	const { loadingType, height } = t0;
	switch (loadingType) {
		case FilteredActionListLoadingTypes.bodySpinner: {
			let t1;
			if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
				t1 = /* @__PURE__ */ jsx(LoadingSpinner, { "data-testid": "filtered-action-list-spinner" });
				$[0] = t1;
			} else t1 = $[0];
			return t1;
		}
		case FilteredActionListLoadingTypes.bodySkeleton: {
			const rows = height < SKELETON_ROW_HEIGHT ? SKELETON_MIN_ROWS : height / SKELETON_ROW_HEIGHT;
			let t1;
			if ($[1] !== rows) {
				t1 = /* @__PURE__ */ jsx(LoadingSkeleton, {
					"data-testid": "filtered-action-list-skeleton",
					rows
				});
				$[1] = rows;
				$[2] = t1;
			} else t1 = $[2];
			return t1;
		}
		default: {
			let t1;
			if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
				t1 = /* @__PURE__ */ jsx(Fragment$1, {});
				$[3] = t1;
			} else t1 = $[3];
			return t1;
		}
	}
}
function LoadingSpinner(t0) {
	const $ = c(4);
	let props;
	if ($[0] !== t0) {
		({...props} = t0);
		$[0] = t0;
		$[1] = props;
	} else props = $[1];
	let t1;
	if ($[2] !== props) {
		t1 = /* @__PURE__ */ jsx("div", {
			className: classes$1.LoadingSpinner,
			children: /* @__PURE__ */ jsx(Spinner, { ...props })
		});
		$[2] = props;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
function LoadingSkeleton(t0) {
	const $ = c(8);
	let props;
	let t1;
	if ($[0] !== t0) {
		({rows: t1, ...props} = t0);
		$[0] = t0;
		$[1] = props;
		$[2] = t1;
	} else {
		props = $[1];
		t1 = $[2];
	}
	const rows = t1 === void 0 ? 10 : t1;
	let t2;
	if ($[3] !== rows) {
		t2 = Array.from({ length: rows }, _temp$1);
		$[3] = rows;
		$[4] = t2;
	} else t2 = $[4];
	let t3;
	if ($[5] !== props || $[6] !== t2) {
		t3 = /* @__PURE__ */ jsx("div", {
			className: classes$1.LoadingSkeletonContainer,
			children: /* @__PURE__ */ jsx(Stack$1, {
				direction: "vertical",
				justify: "center",
				gap: "condensed",
				...props,
				children: t2
			})
		});
		$[5] = props;
		$[6] = t2;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
function _temp$1(_, i) {
	return /* @__PURE__ */ jsxs(Stack$1, {
		direction: "horizontal",
		gap: "condensed",
		align: "center",
		children: [/* @__PURE__ */ jsx(SkeletonBox, {
			width: "16px",
			height: "16px"
		}), /* @__PURE__ */ jsx(SkeletonBox, {
			height: "10px",
			width: `${Math.random() * 60 + 20}%`,
			className: classes$1.LoadingSkeleton
		})]
	}, i);
}
_temp$1.displayName = "_temp";
/**
* This hook will flash the scrollbars for a ref of a container that has scrollable overflow
* @param scrollContainerRef The ref of the scrollable content
*/
function useScrollFlash(scrollContainerRef) {
	useEffect(() => {
		const scrollContainer = scrollContainerRef.current;
		if (!scrollContainer) return;
		const id = requestAnimationFrame(() => {
			const currentScroll = scrollContainer.scrollTop;
			scrollContainer.scrollTop = currentScroll < 1 ? currentScroll + 1 : currentScroll - 1;
			scrollContainer.scrollTop = currentScroll;
		});
		return () => cancelAnimationFrame(id);
	}, [scrollContainerRef]);
}
var classes = {
	"Root": "prc-FilteredActionList-Root-QgIk1",
	"Header": "prc-FilteredActionList-Header-y6ihu",
	"Container": "prc-FilteredActionList-Container-647gF",
	"ActionListItem": "prc-FilteredActionList-ActionListItem-RSinr",
	"ActionList": "prc-FilteredActionList-ActionList-3-Bxb",
	"FullScreenTextInput": "prc-FilteredActionList-FullScreenTextInput-CJvWO",
	"SelectAllContainer": "prc-FilteredActionList-SelectAllContainer-X2ij0",
	"SelectAllCheckbox": "prc-FilteredActionList-SelectAllCheckbox-Axs5l",
	"SelectAllLabel": "prc-FilteredActionList-SelectAllLabel-Bi-PZ"
};
var delayMs = 500;
var useFirstRender = () => {
	const firstRender = useRef(true);
	useEffect(() => {
		firstRender.current = false;
	}, []);
	return firstRender.current;
};
var getItemWithActiveDescendant = (listRef, items) => {
	const listElement = listRef.current;
	const activeItemElement = listElement === null || listElement === void 0 ? void 0 : listElement.querySelector("[data-is-active-descendant]");
	if (!listElement || !(activeItemElement !== null && activeItemElement !== void 0 && activeItemElement.textContent)) return;
	const optionElements = listElement.querySelectorAll("[role=\"option\"]");
	const index = Array.from(optionElements).indexOf(activeItemElement);
	const activeItem = items[index];
	return {
		index,
		text: activeItem === null || activeItem === void 0 ? void 0 : activeItem.text,
		selected: activeItem === null || activeItem === void 0 ? void 0 : activeItem.selected
	};
};
var useAnnouncements = (items, listContainerRef, inputRef, t0, t1, message, focusManagement) => {
	const $ = c(33);
	const enabled = t0 === void 0 ? true : t0;
	const loading = t1 === void 0 ? false : t1;
	const usingRovingTabindex = focusManagement === "roving-tabindex";
	let t2;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = document.querySelector("live-region");
		$[0] = t2;
	} else t2 = $[0];
	const liveRegion = t2;
	let t3;
	if ($[1] !== items) {
		t3 = items.filter(_temp);
		$[1] = items;
		$[2] = t3;
	} else t3 = $[2];
	const selectedItems = t3.length;
	let t4;
	if ($[3] !== enabled) {
		t4 = (...t5) => {
			const args = t5;
			if (enabled) return announce(...args);
		};
		$[3] = enabled;
		$[4] = t4;
	} else t4 = $[4];
	const announce$1 = t4;
	let t5;
	let t6;
	if ($[5] !== announce$1 || $[6] !== inputRef || $[7] !== items || $[8] !== listContainerRef || $[9] !== selectedItems || $[10] !== usingRovingTabindex) {
		t5 = function announceInitialFocus() {
			const focusHandler = () => {
				if (usingRovingTabindex) announce$1(`${items.length} item${items.length > 1 ? "s" : ""} available, ${selectedItems} selected.`, {
					delayMs,
					from: liveRegion ? liveRegion : void 0
				});
				else window.requestAnimationFrame(() => {
					const activeItem = getItemWithActiveDescendant(listContainerRef, items);
					if (!activeItem) return;
					const { index, text, selected } = activeItem;
					announce$1([
						"Focus on filter text box and list of items",
						`Focused item: ${text}`,
						`${selected ? "selected" : "not selected"}`,
						`${index + 1} of ${items.length}`
					].join(", "), {
						delayMs,
						from: liveRegion ? liveRegion : void 0
					});
				});
			};
			const inputElement = inputRef.current;
			inputElement === null || inputElement === void 0 || inputElement.addEventListener("focus", focusHandler);
			return () => inputElement === null || inputElement === void 0 ? void 0 : inputElement.removeEventListener("focus", focusHandler);
		};
		t6 = [
			listContainerRef,
			inputRef,
			items,
			liveRegion,
			announce$1,
			usingRovingTabindex,
			selectedItems
		];
		$[5] = announce$1;
		$[6] = inputRef;
		$[7] = items;
		$[8] = listContainerRef;
		$[9] = selectedItems;
		$[10] = usingRovingTabindex;
		$[11] = t5;
		$[12] = t6;
	} else {
		t5 = $[11];
		t6 = $[12];
	}
	useEffect(t5, t6);
	const isFirstRender = useFirstRender();
	let t7;
	if ($[13] !== announce$1 || $[14] !== isFirstRender || $[15] !== items || $[16] !== listContainerRef || $[17] !== loading || $[18] !== (message === null || message === void 0 ? void 0 : message.description) || $[19] !== (message === null || message === void 0 ? void 0 : message.title) || $[20] !== selectedItems || $[21] !== usingRovingTabindex) {
		t7 = function announceListUpdates() {
			if (isFirstRender) return;
			liveRegion === null || liveRegion === void 0 || liveRegion.clear();
			if (items.length === 0 && !loading) {
				announce$1(`${message === null || message === void 0 ? void 0 : message.title}. ${message === null || message === void 0 ? void 0 : message.description}`, { delayMs });
				return;
			}
			if (usingRovingTabindex) announce$1(`${items.length} item${items.length > 1 ? "s" : ""} available, ${selectedItems} selected.`, {
				delayMs,
				from: liveRegion ? liveRegion : void 0
			});
			else window.requestAnimationFrame(() => {
				const activeItem_0 = getItemWithActiveDescendant(listContainerRef, items);
				if (!activeItem_0) return;
				const { index: index_0, text: text_0, selected: selected_0 } = activeItem_0;
				announce$1([
					"List updated",
					`Focused item: ${text_0}`,
					`${selected_0 ? "selected" : "not selected"}`,
					`${index_0 + 1} of ${items.length}`
				].join(", "), {
					delayMs,
					from: liveRegion ? liveRegion : void 0
				});
			});
		};
		$[13] = announce$1;
		$[14] = isFirstRender;
		$[15] = items;
		$[16] = listContainerRef;
		$[17] = loading;
		$[18] = message === null || message === void 0 ? void 0 : message.description;
		$[19] = message === null || message === void 0 ? void 0 : message.title;
		$[20] = selectedItems;
		$[21] = usingRovingTabindex;
		$[22] = t7;
	} else t7 = $[22];
	const t8 = message === null || message === void 0 ? void 0 : message.title;
	const t9 = message === null || message === void 0 ? void 0 : message.description;
	let t10;
	if ($[23] !== announce$1 || $[24] !== isFirstRender || $[25] !== items || $[26] !== listContainerRef || $[27] !== loading || $[28] !== selectedItems || $[29] !== t8 || $[30] !== t9 || $[31] !== usingRovingTabindex) {
		t10 = [
			announce$1,
			isFirstRender,
			items,
			listContainerRef,
			liveRegion,
			usingRovingTabindex,
			t8,
			t9,
			loading,
			selectedItems
		];
		$[23] = announce$1;
		$[24] = isFirstRender;
		$[25] = items;
		$[26] = listContainerRef;
		$[27] = loading;
		$[28] = selectedItems;
		$[29] = t8;
		$[30] = t9;
		$[31] = usingRovingTabindex;
		$[32] = t10;
	} else t10 = $[32];
	useEffect(t7, t10);
};
function _temp(item) {
	return item.selected;
}
var menuScrollMargins = {
	startMargin: 0,
	endMargin: 8
};
function FilteredActionList({ loading = false, placeholderText, filterValue: externalFilterValue, loadingType = FilteredActionListLoadingTypes.bodySpinner, onFilterChange, onListContainerRefChanged, onInputRefChanged, items, textInputProps, inputRef: providedInputRef, scrollContainerRef: providedScrollContainerRef, groupMetadata, showItemDividers, message, messageText, className, selectionVariant, announcementsEnabled = true, fullScreenOnNarrow, onSelectAllChange, actionListProps, focusOutBehavior = "wrap", _PrivateFocusManagement = "active-descendant", onActiveDescendantChanged, disableSelectOnHover = false, setInitialFocus = false, focusPrependedElements, scrollBehavior, virtualized = false, ...listProps }) {
	const isVirtualized = virtualized && !(groupMetadata !== null && groupMetadata !== void 0 && groupMetadata.length);
	const [filterValue, setInternalFilterValue] = useProvidedStateOrCreate(externalFilterValue, void 0, "");
	const onInputChange = useCallback((e) => {
		const value = e.target.value;
		onFilterChange(value, e);
		setInternalFilterValue(value);
	}, [onFilterChange, setInternalFilterValue]);
	const inputAndListContainerRef = useRef(null);
	const listRef = useRef(null);
	const scrollContainerRef = useProvidedRefOrCreate(providedScrollContainerRef);
	const inputRef = useProvidedRefOrCreate(providedInputRef);
	const usingRovingTabindex = _PrivateFocusManagement === "roving-tabindex";
	const [listContainerElement, setListContainerElement] = useState(null);
	const activeDescendantRef = useRef();
	const listId = useId$1(actionListProps === null || actionListProps === void 0 ? void 0 : actionListProps.id);
	const inputDescriptionTextId = useId$1();
	const [isInputFocused, setIsInputFocused] = useState(false);
	const selectAllChecked = items.length > 0 && items.every((item) => item.selected);
	const selectAllIndeterminate = !selectAllChecked && items.some((item_0) => item_0.selected);
	const selectAllLabelText = selectAllChecked ? "Deselect all" : "Select all";
	const getItemListForEachGroup = useCallback((groupId) => {
		const itemsInGroup = [];
		for (const item_1 of items) if (item_1.groupId === groupId) itemsInGroup.push(item_1);
		return itemsInGroup;
	}, [items]);
	const onInputKeyDown = useCallback((event) => {
		if (event.key === "ArrowDown") {
			if (listRef.current) {
				const firstSelectedItem = listRef.current.querySelector("[role=\"option\"]");
				firstSelectedItem === null || firstSelectedItem === void 0 || firstSelectedItem.focus();
				event.preventDefault();
			}
		} else if (event.key === "Enter") {
			let firstItem;
			if (groupMetadata) {
				let firstGroupIndex = 0;
				for (let i = 0; i < groupMetadata.length; i++) if (getItemListForEachGroup(groupMetadata[i].groupId).length > 0) break;
				else firstGroupIndex++;
				const firstGroup = groupMetadata[firstGroupIndex].groupId;
				firstItem = items.filter((item_2) => item_2.groupId === firstGroup)[0];
			} else firstItem = items[0];
			if (firstItem.onAction) {
				firstItem.onAction(firstItem, event);
				event.preventDefault();
			}
		}
	}, [
		items,
		groupMetadata,
		getItemListForEachGroup
	]);
	const onInputKeyPress = useCallback((event_0) => {
		if (event_0.key === "Enter" && activeDescendantRef.current) {
			event_0.preventDefault();
			event_0.nativeEvent.stopImmediatePropagation();
			const activeDescendantEvent = new KeyboardEvent(event_0.type, event_0.nativeEvent);
			activeDescendantRef.current.dispatchEvent(activeDescendantEvent);
		}
	}, [activeDescendantRef]);
	const listContainerRefCallback = useCallback((node) => {
		setListContainerElement(node);
		onListContainerRefChanged === null || onListContainerRefChanged === void 0 || onListContainerRefChanged(node);
	}, [onListContainerRefChanged]);
	useEffect(() => {
		onInputRefChanged === null || onInputRefChanged === void 0 || onInputRefChanged(inputRef);
	}, [inputRef, onInputRefChanged]);
	const DEFAULT_VIRTUAL_ITEM_HEIGHT = 32;
	const virtualizer = useVirtualizer({
		count: items.length,
		getScrollElement: () => scrollContainerRef.current,
		estimateSize: () => DEFAULT_VIRTUAL_ITEM_HEIGHT,
		overscan: 10,
		enabled: isVirtualized,
		getItemKey: (index) => {
			var _ref, _item_3$key, _item_3$id;
			const item_3 = items[index];
			return (_ref = (_item_3$key = item_3.key) !== null && _item_3$key !== void 0 ? _item_3$key : (_item_3$id = item_3.id) === null || _item_3$id === void 0 ? void 0 : _item_3$id.toString()) !== null && _ref !== void 0 ? _ref : index.toString();
		},
		measureElement: (el) => el.scrollHeight
	});
	const virtualItems = isVirtualized ? virtualizer.getVirtualItems() : void 0;
	const virtualizedItemEntries = useMemo(() => {
		if (!isVirtualized || !virtualItems) return void 0;
		return virtualItems.map((virtualItem) => {
			return {
				virtualItem,
				item: items[virtualItem.index],
				index: virtualItem.index
			};
		});
	}, [
		isVirtualized,
		virtualItems,
		items
	]);
	useFocusZone(!usingRovingTabindex ? {
		containerRef: { current: listContainerElement },
		bindKeys: FocusKeys.ArrowVertical | FocusKeys.PageUpDown,
		focusOutBehavior: isVirtualized ? "stop" : focusOutBehavior,
		focusableElementFilter: (element) => {
			return !(element instanceof HTMLInputElement);
		},
		activeDescendantFocus: inputRef,
		onActiveDescendantChanged: (current, previous, directlyActivated) => {
			activeDescendantRef.current = current;
			if (isVirtualized && current) {
				const index_0 = current.getAttribute("data-index");
				const range = virtualizer.range;
				if (index_0 !== null && range && (Number(index_0) < range.startIndex || Number(index_0) >= range.endIndex)) virtualizer.scrollToIndex(Number(index_0), { align: "auto" });
			}
			if (current && scrollContainerRef.current && (directlyActivated || focusPrependedElements)) scrollIntoView(current, scrollContainerRef.current, {
				...menuScrollMargins,
				behavior: scrollBehavior
			});
			onActiveDescendantChanged === null || onActiveDescendantChanged === void 0 || onActiveDescendantChanged(current, previous, directlyActivated);
		},
		focusInStrategy: setInitialFocus ? "initial" : "previous",
		ignoreHoverEvents: disableSelectOnHover,
		focusPrependedElements
	} : void 0, [
		listContainerElement,
		usingRovingTabindex,
		onActiveDescendantChanged,
		focusPrependedElements,
		isVirtualized
	]);
	useEffect(() => {
		if (activeDescendantRef.current && scrollContainerRef.current) scrollIntoView(activeDescendantRef.current, scrollContainerRef.current, {
			...menuScrollMargins,
			behavior: scrollBehavior
		});
	}, [
		items,
		inputRef,
		scrollContainerRef,
		scrollBehavior
	]);
	useEffect(() => {
		if (usingRovingTabindex) {
			const inputAndListContainerElement = inputAndListContainerRef.current;
			if (!inputAndListContainerElement) return;
			const list = listRef.current;
			if (!list) return;
			const handleFocusIn = (event_1) => {
				if (event_1.target === inputRef.current || list.contains(event_1.target)) setIsInputFocused(inputRef.current && inputRef.current === document.activeElement ? true : false);
			};
			inputAndListContainerElement.addEventListener("focusin", handleFocusIn);
			return () => {
				inputAndListContainerElement.removeEventListener("focusin", handleFocusIn);
			};
		}
	}, [
		items,
		inputRef,
		listContainerElement,
		usingRovingTabindex
	]);
	useEffect(() => {
		if (usingRovingTabindex && !loading) setIsInputFocused(inputRef.current && inputRef.current === document.activeElement ? true : false);
	}, [
		loading,
		inputRef,
		usingRovingTabindex
	]);
	useAnnouncements(items, usingRovingTabindex ? listRef : { current: listContainerElement }, inputRef, announcementsEnabled, loading, messageText, _PrivateFocusManagement);
	useScrollFlash(scrollContainerRef);
	const handleSelectAllChange = useCallback((e_0) => {
		if (onSelectAllChange) onSelectAllChange(e_0.target.checked);
	}, [onSelectAllChange]);
	function getBodyContent() {
		if (loading && scrollContainerRef.current && loadingType.appearsInBody) return /* @__PURE__ */ jsx(FilteredActionListBodyLoader, {
			loadingType,
			height: scrollContainerRef.current.clientHeight
		});
		if (message) return message;
		let firstGroupIndex_0 = 0;
		const renderListItems = () => {
			if (groupMetadata !== null && groupMetadata !== void 0 && groupMetadata.length) return groupMetadata.map((group, index_1) => {
				var _group$header, _group$header2;
				if (index_1 === firstGroupIndex_0 && getItemListForEachGroup(group.groupId).length === 0) firstGroupIndex_0++;
				return /* @__PURE__ */ jsxs(ActionList.Group, { children: [/* @__PURE__ */ jsx(ActionList.GroupHeading, {
					variant: (_group$header = group.header) !== null && _group$header !== void 0 && _group$header.variant ? group.header.variant : void 0,
					children: (_group$header2 = group.header) !== null && _group$header2 !== void 0 && _group$header2.title ? group.header.title : `Group ${group.groupId}`
				}), getItemListForEachGroup(group.groupId).map(({ key: itemKey, ...item_5 }, itemIndex) => {
					var _ref2, _item_5$id;
					const key = (_ref2 = itemKey !== null && itemKey !== void 0 ? itemKey : (_item_5$id = item_5.id) === null || _item_5$id === void 0 ? void 0 : _item_5$id.toString()) !== null && _ref2 !== void 0 ? _ref2 : itemIndex.toString();
					return /* @__PURE__ */ jsx(MappedActionListItem, {
						className: clsx(classes.ActionListItem, "className" in item_5 ? item_5.className : void 0),
						"data-input-focused": isInputFocused ? "" : void 0,
						"data-first-child": index_1 === firstGroupIndex_0 && itemIndex === 0 ? "" : void 0,
						...item_5,
						renderItem: listProps.renderItem
					}, key);
				})] }, index_1);
			});
			if (isVirtualized && virtualizedItemEntries) return virtualizedItemEntries.map(({ virtualItem: virtualItem_0, item: { key: itemKey_0, ...item_6 }, index: index_2 }) => {
				var _ref3, _item_6$id;
				const key_0 = (_ref3 = itemKey_0 !== null && itemKey_0 !== void 0 ? itemKey_0 : (_item_6$id = item_6.id) === null || _item_6$id === void 0 ? void 0 : _item_6$id.toString()) !== null && _ref3 !== void 0 ? _ref3 : index_2.toString();
				return /* @__PURE__ */ jsx(MappedActionListItem, {
					className: clsx(classes.ActionListItem, "className" in item_6 ? item_6.className : void 0),
					"data-input-focused": isInputFocused ? "" : void 0,
					"data-first-child": index_2 === 0 ? "" : void 0,
					"data-index": virtualItem_0.index,
					ref: (node_0) => {
						if (node_0) virtualizer.measureElement(node_0);
					},
					style: {
						position: "absolute",
						top: 0,
						left: 0,
						right: 0,
						transform: `translateY(${virtualItem_0.start}px)`
					},
					...item_6,
					renderItem: listProps.renderItem
				}, key_0);
			});
			return items.map(({ key: itemKey_1, ...item_7 }, index_3) => {
				var _ref4, _item_7$id;
				const key_1 = (_ref4 = itemKey_1 !== null && itemKey_1 !== void 0 ? itemKey_1 : (_item_7$id = item_7.id) === null || _item_7$id === void 0 ? void 0 : _item_7$id.toString()) !== null && _ref4 !== void 0 ? _ref4 : index_3.toString();
				return /* @__PURE__ */ jsx(MappedActionListItem, {
					className: clsx(classes.ActionListItem, "className" in item_7 ? item_7.className : void 0),
					"data-input-focused": isInputFocused ? "" : void 0,
					"data-first-child": index_3 === 0 ? "" : void 0,
					...item_7,
					renderItem: listProps.renderItem
				}, key_1);
			});
		};
		const actionListContent = /* @__PURE__ */ jsx(ActionList, {
			ref: usingRovingTabindex ? listRef : listContainerRefCallback,
			showDividers: showItemDividers,
			selectionVariant,
			...listProps,
			...actionListProps,
			role: "listbox",
			id: listId,
			className: clsx(classes.ActionList, actionListProps === null || actionListProps === void 0 ? void 0 : actionListProps.className),
			style: isVirtualized ? {
				...actionListProps === null || actionListProps === void 0 ? void 0 : actionListProps.style,
				height: virtualizer.getTotalSize(),
				position: "relative"
			} : actionListProps === null || actionListProps === void 0 ? void 0 : actionListProps.style,
			children: renderListItems()
		});
		if (usingRovingTabindex) return /* @__PURE__ */ jsx(ActionListContainerContext.Provider, {
			value: {
				container: "FilteredActionList",
				listRole: "listbox",
				selectionAttribute: "aria-selected",
				selectionVariant,
				enableFocusZone: true
			},
			children: actionListContent
		});
		else return actionListContent;
	}
	const { className: textInputClassName, ...restTextInputProps } = textInputProps || {};
	return /* @__PURE__ */ jsxs("div", {
		ref: inputAndListContainerRef,
		className: clsx(className, classes.Root),
		"data-testid": "filtered-action-list",
		children: [
			/* @__PURE__ */ jsx("div", {
				className: classes.Header,
				children: /* @__PURE__ */ jsx(TextInput$1, {
					ref: inputRef,
					block: true,
					width: "auto",
					color: "fg.default",
					value: filterValue,
					onChange: onInputChange,
					onKeyPress: onInputKeyPress,
					onKeyDown: usingRovingTabindex ? onInputKeyDown : () => {},
					placeholder: placeholderText,
					role: "combobox",
					"aria-expanded": "true",
					"aria-autocomplete": "list",
					"aria-controls": listId,
					"aria-label": placeholderText,
					"aria-describedby": inputDescriptionTextId,
					loaderPosition: "leading",
					loading: loading && !loadingType.appearsInBody,
					className: clsx(textInputClassName, { [classes.FullScreenTextInput]: fullScreenOnNarrow }),
					...restTextInputProps
				})
			}),
			/* @__PURE__ */ jsx(VisuallyHidden, {
				id: inputDescriptionTextId,
				children: "Items will be filtered as you type"
			}),
			onSelectAllChange !== void 0 && /* @__PURE__ */ jsxs("div", {
				className: classes.SelectAllContainer,
				children: [/* @__PURE__ */ jsx(Checkbox, {
					id: "select-all-checkbox",
					className: classes.SelectAllCheckbox,
					checked: selectAllChecked,
					indeterminate: selectAllIndeterminate,
					onChange: handleSelectAllChange
				}), /* @__PURE__ */ jsx("label", {
					className: classes.SelectAllLabel,
					htmlFor: "select-all-checkbox",
					children: selectAllLabelText
				})]
			}),
			/* @__PURE__ */ jsx("div", {
				ref: scrollContainerRef,
				className: classes.Container,
				children: getBodyContent()
			})
		]
	});
}
FilteredActionList.displayName = "FilteredActionList";
var MappedActionListItem = /* @__PURE__ */ forwardRef((item, ref) => {
	const $ = c(36);
	if (typeof item.renderItem === "function") {
		let t0;
		if ($[0] !== item) {
			t0 = item.renderItem(item);
			$[0] = item;
			$[1] = t0;
		} else t0 = $[1];
		return t0;
	}
	let LeadingVisual;
	let TrailingIcon;
	let TrailingVisual;
	let children;
	let description;
	let descriptionVariant;
	let id;
	let onAction;
	let rest;
	let text;
	let trailingText;
	if ($[2] !== item) {
		({id, description, descriptionVariant, text, trailingVisual: TrailingVisual, leadingVisual: LeadingVisual, trailingText, trailingIcon: TrailingIcon, onAction, children, ...rest} = item);
		$[2] = item;
		$[3] = LeadingVisual;
		$[4] = TrailingIcon;
		$[5] = TrailingVisual;
		$[6] = children;
		$[7] = description;
		$[8] = descriptionVariant;
		$[9] = id;
		$[10] = onAction;
		$[11] = rest;
		$[12] = text;
		$[13] = trailingText;
	} else {
		LeadingVisual = $[3];
		TrailingIcon = $[4];
		TrailingVisual = $[5];
		children = $[6];
		description = $[7];
		descriptionVariant = $[8];
		id = $[9];
		onAction = $[10];
		rest = $[11];
		text = $[12];
		trailingText = $[13];
	}
	let t0;
	if ($[14] !== item || $[15] !== onAction) {
		t0 = (e) => {
			if (typeof onAction === "function") onAction(item, e);
		};
		$[14] = item;
		$[15] = onAction;
		$[16] = t0;
	} else t0 = $[16];
	let t1;
	if ($[17] !== LeadingVisual) {
		t1 = LeadingVisual ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(LeadingVisual, {}) }) : null;
		$[17] = LeadingVisual;
		$[18] = t1;
	} else t1 = $[18];
	let t2;
	if ($[19] !== description || $[20] !== descriptionVariant) {
		t2 = description ? /* @__PURE__ */ jsx(ActionList.Description, {
			variant: descriptionVariant,
			children: description
		}) : null;
		$[19] = description;
		$[20] = descriptionVariant;
		$[21] = t2;
	} else t2 = $[21];
	let t3;
	if ($[22] !== TrailingIcon || $[23] !== TrailingVisual || $[24] !== trailingText) {
		t3 = TrailingVisual ? /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: typeof TrailingVisual !== "string" && isValidElementType(TrailingVisual) ? /* @__PURE__ */ jsx(TrailingVisual, {}) : TrailingVisual }) : TrailingIcon || trailingText ? /* @__PURE__ */ jsxs(ActionList.TrailingVisual, { children: [trailingText, TrailingIcon && /* @__PURE__ */ jsx(TrailingIcon, {})] }) : null;
		$[22] = TrailingIcon;
		$[23] = TrailingVisual;
		$[24] = trailingText;
		$[25] = t3;
	} else t3 = $[25];
	let t4;
	if ($[26] !== children || $[27] !== id || $[28] !== ref || $[29] !== rest || $[30] !== t0 || $[31] !== t1 || $[32] !== t2 || $[33] !== t3 || $[34] !== text) {
		t4 = /* @__PURE__ */ jsxs(ActionList.Item, {
			role: "option",
			onSelect: t0,
			"data-id": id,
			ref,
			...rest,
			children: [
				t1,
				children,
				text,
				t2,
				t3
			]
		});
		$[26] = children;
		$[27] = id;
		$[28] = ref;
		$[29] = rest;
		$[30] = t0;
		$[31] = t1;
		$[32] = t2;
		$[33] = t3;
		$[34] = text;
		$[35] = t4;
	} else t4 = $[35];
	return t4;
});
FilteredActionList.displayName = "FilteredActionList";
var SHORT_DELAY_MS = 500;
var LONG_DELAY_MS = 1e3;
var EMPTY_MESSAGE = {
	title: "No items available",
	description: ""
};
var DefaultEmptyMessage = /* @__PURE__ */ jsx(SelectPanelMessage, {
	variant: "empty",
	title: EMPTY_MESSAGE.title,
	children: EMPTY_MESSAGE.description
}, "empty-message");
async function announceText(text, delayMs = SHORT_DELAY_MS) {
	const liveRegion = document.querySelector("live-region");
	liveRegion === null || liveRegion === void 0 || liveRegion.clear();
	await announce(text, {
		delayMs,
		from: liveRegion ? liveRegion : void 0
	});
}
async function announceLoading() {
	await announceText("Loading.");
}
function isMultiSelectVariant(selected) {
	return Array.isArray(selected);
}
var focusZoneSettings = { disabled: true };
var closeButtonProps = { "aria-label": "Cancel and close" };
var areItemsEqual = (itemA, itemB) => {
	if (typeof itemA.id !== "undefined") return itemA.id === itemB.id;
	else return itemA === itemB;
};
var doesItemsIncludeItem = (items, item) => {
	return items.some((i) => areItemsEqual(i, item));
};
var defaultRenderAnchor = (props) => {
	const { children, ...rest } = props;
	return /* @__PURE__ */ jsx(ButtonComponent, {
		trailingAction: TriangleDownIcon,
		...rest,
		children
	});
};
defaultRenderAnchor.displayName = "defaultRenderAnchor";
function Panel({ open, onOpenChange, renderAnchor = defaultRenderAnchor, anchorRef: externalAnchorRef, placeholder, placeholderText = "Filter items", inputLabel = placeholderText, selected, title = isMultiSelectVariant(selected) ? "Select items" : "Select an item", subtitle, onSelectedChange, filterValue: externalFilterValue, onFilterChange: externalOnFilterChange, items, footer, textInputProps, overlayProps, loading, initialLoadingType = "spinner", className, height, width, id, message, notice, onCancel, variant = "anchored", secondaryAction, showSelectedOptionsFirst = true, disableFullscreenOnNarrow, align, showSelectAll = false, focusPrependedElements, virtualized, ...listProps }) {
	var _listProps$groupMetad;
	const titleId = useId$1();
	const subtitleId = useId$1();
	const [dataLoadedOnce, setDataLoadedOnce] = useState(false);
	const [isLoading, setIsLoading] = useState(false);
	const [filterValue, setInternalFilterValue] = useProvidedStateOrCreate(externalFilterValue, void 0, "");
	const { safeSetTimeout, safeClearTimeout } = useSafeTimeout();
	const loadingDelayTimeoutId = useRef(null);
	const loadingManagedInternally = loading === void 0;
	const loadingManagedExternally = !loadingManagedInternally;
	const [inputRef, setInputRef] = React.useState(null);
	const [listContainerElement, setListContainerElement] = useState(null);
	const [needsNoItemsAnnouncement, setNeedsNoItemsAnnouncement] = useState(false);
	const isNarrowScreenSize = useResponsiveValue({
		narrow: true,
		regular: false,
		wide: false
	}, false);
	const [selectedOnSort, setSelectedOnSort] = useState([]);
	const initialHeightRef = useRef(0);
	const initialScaleRef = useRef(1);
	const noticeRef = useRef(null);
	const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
	const [availablePanelHeight, setAvailablePanelHeight] = useState(void 0);
	const KEYBOARD_VISIBILITY_THRESHOLD = 10;
	const featureFlagFullScreenOnNarrow = useFeatureFlag("primer_react_select_panel_fullscreen_on_narrow");
	const usingFullScreenOnNarrow = disableFullscreenOnNarrow ? false : featureFlagFullScreenOnNarrow;
	const shouldOrderSelectedFirst = useFeatureFlag("primer_react_select_panel_order_selected_at_top") && showSelectedOptionsFirst;
	const { isReferenced, labelId } = useFormControlContext();
	const selectedValueId = id ? `${id}-selected-value` : void 0;
	const isSingleSelectModal = variant === "modal" && !isMultiSelectVariant(selected);
	const [intermediateSelected, setIntermediateSelected] = useState(isSingleSelectModal ? selected : void 0);
	useEffect(() => {
		setIntermediateSelected(isSingleSelectModal ? selected : void 0);
	}, [
		isSingleSelectModal,
		open,
		selected
	]);
	const onListContainerRefChanged = useCallback((node) => {
		setListContainerElement(node);
		if (!node && needsNoItemsAnnouncement) setNeedsNoItemsAnnouncement(false);
	}, [needsNoItemsAnnouncement]);
	const onInputRefChanged = useCallback((ref) => {
		setInputRef(ref);
	}, [setInputRef]);
	const resetSort = useCallback(() => {
		if (isMultiSelectVariant(selected)) setSelectedOnSort(selected);
		else if (selected) setSelectedOnSort([selected]);
		else setSelectedOnSort([]);
	}, [selected]);
	const onFilterChange = useCallback((value, e) => {
		if (loadingManagedInternally) {
			if (loadingDelayTimeoutId.current) safeClearTimeout(loadingDelayTimeoutId.current);
			if (dataLoadedOnce) loadingDelayTimeoutId.current = safeSetTimeout(() => {
				setIsLoading(true);
				announceLoading();
			}, LONG_DELAY_MS);
			else {
				if (items.length === 0) setIsLoading(true);
				loadingDelayTimeoutId.current = safeSetTimeout(() => {
					announceLoading();
				}, LONG_DELAY_MS);
			}
		}
		externalOnFilterChange(value, e);
		setInternalFilterValue(value);
		if (!value) resetSort();
	}, [
		loadingManagedInternally,
		externalOnFilterChange,
		setInternalFilterValue,
		dataLoadedOnce,
		safeSetTimeout,
		safeClearTimeout,
		items.length,
		resetSort
	]);
	const itemsInViewSet = useMemo(() => {
		const set = /* @__PURE__ */ new Set();
		for (const item of items) if (item.id !== void 0) set.add(item.id);
		else set.add(item);
		return set;
	}, [items]);
	const handleSelectAllChange = useCallback((checked) => {
		if (!isMultiSelectVariant(selected)) return;
		const multiSelectOnChange = onSelectedChange;
		const selectedItemsNotInFilteredView = selected.filter((selectedItem) => {
			if (selectedItem.id !== void 0) return !itemsInViewSet.has(selectedItem.id);
			return !itemsInViewSet.has(selectedItem);
		});
		if (checked) multiSelectOnChange([...selectedItemsNotInFilteredView, ...items]);
		else multiSelectOnChange(selectedItemsNotInFilteredView);
	}, [
		items,
		itemsInViewSet,
		onSelectedChange,
		selected
	]);
	useEffect(() => {
		if (open && isNarrowScreenSize && usingFullScreenOnNarrow) {
			const bodyOverflowStyle = document.body.style.overflow || "";
			if (bodyOverflowStyle === "hidden") return;
			document.body.style.overflow = "hidden";
			return () => {
				document.body.style.overflow = bodyOverflowStyle;
			};
		}
	}, [
		isNarrowScreenSize,
		open,
		usingFullScreenOnNarrow
	]);
	useEffect(() => {
		if (open) {
			if (items.length === 0 && !(isLoading || loading)) setNeedsNoItemsAnnouncement(true);
		}
		if (loadingManagedExternally) {
			if (items.length > 0) setDataLoadedOnce(true);
			return;
		}
		if (isLoading || items.length > 0) {
			setIsLoading(false);
			setDataLoadedOnce(true);
		}
		if (loadingDelayTimeoutId.current) safeClearTimeout(loadingDelayTimeoutId.current);
	}, [items]);
	useEffect(() => {
		if (inputRef !== null && inputRef !== void 0 && inputRef.current) {
			const ref = inputRef.current;
			if (open) ref.focus();
		}
	}, [inputRef, open]);
	useEffect(() => {
		if (loadingManagedExternally) {
			if (isLoading) loadingDelayTimeoutId.current = safeSetTimeout(() => {
				announceLoading();
			}, LONG_DELAY_MS);
			else if (loadingDelayTimeoutId.current) safeClearTimeout(loadingDelayTimeoutId.current);
		}
	}, [
		isLoading,
		loadingManagedExternally,
		safeSetTimeout,
		safeClearTimeout
	]);
	useEffect(() => {
		if (loadingManagedExternally) return;
		if (dataLoadedOnce) return;
		if (open) {
			if (items.length === 0) onFilterChange(filterValue, null);
		}
	}, [
		open,
		dataLoadedOnce,
		onFilterChange,
		filterValue,
		items,
		loadingManagedExternally,
		listContainerElement
	]);
	useEffect(() => {
		if (!window.visualViewport || !open || !isNarrowScreenSize) return;
		initialHeightRef.current = window.visualViewport.height;
		initialScaleRef.current = window.visualViewport.scale;
		const handleViewportChange = debounce(() => {
			if (window.visualViewport) {
				if (!(window.visualViewport.scale !== initialScaleRef.current)) {
					const currentHeight = window.visualViewport.height;
					const keyboardVisible = initialHeightRef.current - currentHeight > KEYBOARD_VISIBILITY_THRESHOLD;
					setIsKeyboardVisible(keyboardVisible);
					setAvailablePanelHeight(keyboardVisible ? currentHeight : void 0);
				}
			}
		}, 100);
		if (window.visualViewport) {
			window.visualViewport.addEventListener("resize", handleViewportChange);
			window.visualViewport.addEventListener("scroll", handleViewportChange);
		}
		return () => {
			if (window.visualViewport) {
				window.visualViewport.removeEventListener("resize", handleViewportChange);
				window.visualViewport.removeEventListener("scroll", handleViewportChange);
			}
			handleViewportChange.cancel();
		};
	}, [open, isNarrowScreenSize]);
	useEffect(() => {
		const announceNotice = async () => {
			if (!noticeRef.current) return;
			const liveRegion = document.querySelector("live-region");
			liveRegion === null || liveRegion === void 0 || liveRegion.clear();
			await announceFromElement(noticeRef.current, { from: liveRegion ? liveRegion : void 0 });
		};
		if (open && notice) announceNotice();
	}, [notice, open]);
	const anchorRef = useProvidedRefOrCreate(externalAnchorRef);
	const onOpen = useCallback((gesture) => onOpenChange(true, gesture), [onOpenChange]);
	const onCancelRequested = useCallback(() => {
		onOpenChange(false, "cancel");
	}, [onOpenChange]);
	const onClose = useCallback((gesture) => {
		if (variant === "modal" && gesture === "click-outside") onCancel === null || onCancel === void 0 || onCancel();
		if (gesture === "close") {
			onCancel === null || onCancel === void 0 || onCancel();
			onCancelRequested();
		} else onOpenChange(false, gesture);
	}, [
		onOpenChange,
		variant,
		onCancel,
		onCancelRequested
	]);
	const renderMenuAnchor = useMemo(() => {
		if (renderAnchor === null) return null;
		const selectedItems = Array.isArray(selected) ? selected : [...selected ? [selected] : []];
		const selectedValueText = selectedItems.length ? selectedItems.map((item) => item.text).join(", ") : placeholder;
		const shouldAutoWireLabel = isReferenced === false && Boolean(labelId) && Boolean(selectedValueId);
		return (props) => {
			return renderAnchor({
				...props,
				...shouldAutoWireLabel ? { "aria-labelledby": [labelId, selectedValueId].filter(Boolean).join(" ") } : {},
				children: shouldAutoWireLabel ? /* @__PURE__ */ jsx("span", {
					id: selectedValueId,
					children: selectedValueText
				}) : selectedValueText
			});
		};
	}, [
		placeholder,
		renderAnchor,
		selected,
		isReferenced,
		labelId,
		selectedValueId
	]);
	const selectedItemsSet = useMemo(() => {
		const set = /* @__PURE__ */ new Set();
		if (isMultiSelectVariant(selected)) for (const item of selected) if (item.id !== void 0) set.add(item.id);
		else set.add(item);
		return set;
	}, [selected]);
	const isItemCurrentlySelected = useCallback((item) => {
		if (isMultiSelectVariant(selected)) {
			if (item.id !== void 0) return selectedItemsSet.has(item.id);
			return selectedItemsSet.has(item);
		}
		if (isSingleSelectModal) return (intermediateSelected === null || intermediateSelected === void 0 ? void 0 : intermediateSelected.id) !== void 0 ? intermediateSelected.id === item.id : intermediateSelected === item;
		return (selected === null || selected === void 0 ? void 0 : selected.id) !== void 0 ? selected.id === item.id : selected === item;
	}, [
		selected,
		selectedItemsSet,
		intermediateSelected,
		isSingleSelectModal
	]);
	const itemsToRender = useMemo(() => {
		const selectedOnSortSet = /* @__PURE__ */ new Set();
		for (const item of selectedOnSort) if (item.id !== void 0) selectedOnSortSet.add(item.id);
		else selectedOnSortSet.add(item);
		const isSelectedForSort = (item) => {
			if (item.id !== void 0) return selectedOnSortSet.has(item.id);
			return selectedOnSortSet.has(item);
		};
		return items.map((item) => {
			return {
				...item,
				role: "option",
				id: item.id,
				selected: "selected" in item && item.selected === void 0 ? void 0 : isItemCurrentlySelected(item),
				onAction: (itemFromAction, event) => {
					var _item$onAction;
					(_item$onAction = item.onAction) === null || _item$onAction === void 0 || _item$onAction.call(item, itemFromAction, event);
					if (event.defaultPrevented) return;
					if (isMultiSelectVariant(selected)) {
						const otherSelectedItems = selected.filter((selectedItem) => !areItemsEqual(selectedItem, item));
						onSelectedChange(doesItemsIncludeItem(selected, item) ? otherSelectedItems : [...otherSelectedItems, item]);
						return;
					}
					if (isSingleSelectModal) {
						if ((intermediateSelected === null || intermediateSelected === void 0 ? void 0 : intermediateSelected.id) === item.id) setIntermediateSelected(void 0);
						else setIntermediateSelected(item);
						return;
					}
					onSelectedChange(item === selected ? void 0 : item);
					onClose("selection");
				}
			};
		}).sort((itemA, itemB) => {
			if (shouldOrderSelectedFirst) {
				const itemASelected = isSelectedForSort(itemA);
				const itemBSelected = isSelectedForSort(itemB);
				if (itemASelected && !itemBSelected) return -1;
				else if (!itemASelected && itemBSelected) return 1;
			}
			return 0;
		});
	}, [
		onClose,
		onSelectedChange,
		items,
		selected,
		isItemCurrentlySelected,
		isSingleSelectModal,
		intermediateSelected,
		shouldOrderSelectedFirst,
		selectedOnSort
	]);
	const prevItemsRef = useRef(items);
	useEffect(() => {
		if (prevItemsRef.current !== items) {
			if (prevItemsRef.current.length === 0 && items.length > 0) resetSort();
			prevItemsRef.current = items;
		}
	}, [items, resetSort]);
	const prevOpenRef = useRef(open);
	useEffect(() => {
		if (prevOpenRef.current !== open) {
			resetSort();
			prevOpenRef.current = open;
		}
	}, [open, resetSort]);
	const focusTrapSettings = useMemo(() => ({ initialFocusRef: inputRef || void 0 }), [inputRef]);
	const extendedTextInputProps = useMemo(() => {
		return {
			className: classes$3.TextInput,
			contrast: true,
			leadingVisual: SearchIcon,
			"aria-label": inputLabel,
			...textInputProps
		};
	}, [inputLabel, textInputProps]);
	const loadingType = () => {
		if (dataLoadedOnce) return FilteredActionListLoadingTypes.input;
		else if (initialLoadingType === "spinner") return FilteredActionListLoadingTypes.bodySpinner;
		else return FilteredActionListLoadingTypes.bodySkeleton;
	};
	function getMessage() {
		if (items.length === 0 && !message) return DefaultEmptyMessage;
		else if (message) return /* @__PURE__ */ jsx(SelectPanelMessage, {
			title: message.title,
			variant: message.variant,
			icon: message.icon,
			action: message.action,
			children: message.body
		});
	}
	const showPermanentCancelSaveButtons = variant === "modal";
	const showResponsiveCancelSaveButtons = variant !== "modal" && usingFullScreenOnNarrow && isMultiSelectVariant(selected) && onCancel !== void 0;
	const showResponsiveSaveAndCloseButton = variant !== "modal" && usingFullScreenOnNarrow && isMultiSelectVariant(selected) && onCancel === void 0;
	const renderFooter = secondaryAction !== void 0 || showPermanentCancelSaveButtons || showResponsiveSaveAndCloseButton || showResponsiveCancelSaveButtons;
	const displayFooter = secondaryAction !== void 0 || showPermanentCancelSaveButtons ? "always" : showResponsiveSaveAndCloseButton || showResponsiveCancelSaveButtons ? "only-small" : void 0;
	const stretchSecondaryAction = showResponsiveSaveAndCloseButton || showResponsiveCancelSaveButtons ? "only-big" : showPermanentCancelSaveButtons ? "never" : "always";
	const stretchSaveButton = showResponsiveSaveAndCloseButton && secondaryAction === void 0 ? "only-small" : "never";
	const showXCloseIcon = (onCancel !== void 0 || !isMultiSelectVariant(selected)) && usingFullScreenOnNarrow;
	const currentResponsiveVariant = useResponsiveValue(usingFullScreenOnNarrow ? {
		regular: "anchored",
		narrow: "fullscreen"
	} : void 0, "anchored");
	const preventBubbling = useCallback((event) => {
		var _overlayProps$onKeyDo;
		overlayProps === null || overlayProps === void 0 || (_overlayProps$onKeyDo = overlayProps.onKeyDown) == null || _overlayProps$onKeyDo.call(overlayProps, event);
		const activeElement = document.activeElement;
		if (activeElement.tagName === "INPUT" || activeElement.tagName === "TEXTAREA") return;
		if (event.ctrlKey || event.altKey || event.metaKey) return;
		if (event.key !== "/" && !isAlphabetKey(event.nativeEvent)) return;
		event.stopPropagation();
	}, [overlayProps]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(AnchoredOverlay, {
		renderAnchor: renderMenuAnchor,
		anchorRef,
		align,
		open,
		onOpen,
		onClose,
		overlayProps: useMemo(() => ({
			role: "dialog",
			"aria-labelledby": titleId,
			"aria-describedby": subtitle ? subtitleId : void 0,
			...overlayProps,
			...variant === "modal" ? {
				top: "50vh",
				left: "50vw",
				anchorSide: void 0
			} : {},
			style: {
				transform: variant === "modal" ? "translate(-50%, -50%)" : void 0,
				...isKeyboardVisible ? { maxHeight: availablePanelHeight !== void 0 ? `${availablePanelHeight}px` : "auto" } : {}
			},
			onKeyDown: preventBubbling
		}), [
			titleId,
			subtitle,
			subtitleId,
			overlayProps,
			variant,
			isKeyboardVisible,
			availablePanelHeight,
			preventBubbling
		]),
		focusTrapSettings,
		focusZoneSettings,
		height,
		width,
		anchorId: id,
		variant: usingFullScreenOnNarrow ? {
			regular: "anchored",
			narrow: "fullscreen"
		} : void 0,
		pinPosition: !height,
		className: classes$3.Overlay,
		displayCloseButton: showXCloseIcon,
		closeButtonProps,
		children: /* @__PURE__ */ jsxs("div", {
			className: classes$3.Wrapper,
			"data-variant": variant,
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: classes$3.Header,
					"data-variant": currentResponsiveVariant,
					children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Heading$2, {
						as: "h1",
						id: titleId,
						className: classes$3.Title,
						children: title
					}), subtitle ? /* @__PURE__ */ jsx("div", {
						id: subtitleId,
						className: classes$3.Subtitle,
						children: subtitle
					}) : null] }), variant === "modal" && !isNarrowScreenSize ? /* @__PURE__ */ jsx(IconButton, {
						type: "button",
						variant: "invisible",
						icon: XIcon,
						"aria-label": "Cancel and close",
						className: classes$3.ResponsiveCloseButton,
						onClick: () => {
							onCancel === null || onCancel === void 0 || onCancel();
							onCancelRequested();
						}
					}) : null]
				}),
				notice && /* @__PURE__ */ jsx("div", {
					ref: noticeRef,
					children: /* @__PURE__ */ jsx(Banner, {
						variant: notice.variant === "error" ? "critical" : notice.variant,
						description: notice.text,
						title: "Notice",
						hideTitle: true,
						className: classes$3.Notice,
						layout: "compact"
					})
				}),
				/* @__PURE__ */ jsx(FilteredActionList, {
					filterValue,
					onFilterChange,
					onListContainerRefChanged,
					onInputRefChanged,
					placeholderText,
					...listProps,
					variant: (_listProps$groupMetad = listProps.groupMetadata) !== null && _listProps$groupMetad !== void 0 && _listProps$groupMetad.length ? "horizontal-inset" : "inset",
					role: "listbox",
					"aria-labelledby": listProps["aria-label"] ? void 0 : titleId,
					"aria-multiselectable": isMultiSelectVariant(selected) ? "true" : "false",
					selectionVariant: isSingleSelectModal ? "radio" : isMultiSelectVariant(selected) ? "multiple" : "single",
					items: itemsToRender,
					textInputProps: extendedTextInputProps,
					loading: loading || isLoading && !message,
					loadingType: loadingType(),
					onSelectAllChange: showSelectAll ? handleSelectAllChange : void 0,
					message: getMessage(),
					messageText: {
						title: (message === null || message === void 0 ? void 0 : message.title) || EMPTY_MESSAGE.title,
						description: typeof (message === null || message === void 0 ? void 0 : message.body) === "string" ? message.body : EMPTY_MESSAGE.description
					},
					fullScreenOnNarrow: usingFullScreenOnNarrow,
					className: clsx(className, classes$3.FilteredActionList),
					focusPrependedElements,
					virtualized
				}),
				footer ? /* @__PURE__ */ jsx("div", {
					className: classes$3.Footer,
					children: footer
				}) : renderFooter ? /* @__PURE__ */ jsxs("div", {
					"data-display-footer": displayFooter,
					"data-stretch-secondary-action": stretchSecondaryAction,
					"data-stretch-save-button": stretchSaveButton,
					className: clsx(classes$3.Footer, classes$3.ResponsiveFooter),
					children: [
						/* @__PURE__ */ jsx("div", {
							"data-stretch-secondary-action": stretchSecondaryAction,
							className: classes$3.SecondaryAction,
							children: secondaryAction
						}),
						showPermanentCancelSaveButtons || showResponsiveCancelSaveButtons ? /* @__PURE__ */ jsxs("div", {
							"data-stretch-save-button": stretchSaveButton,
							className: clsx(classes$3.CancelSaveButtons, { [classes$3.ResponsiveSaveButton]: showResponsiveCancelSaveButtons }),
							children: [/* @__PURE__ */ jsx(ButtonComponent, {
								size: "medium",
								onClick: () => {
									onCancel === null || onCancel === void 0 || onCancel();
									onCancelRequested();
								},
								children: "Cancel"
							}), /* @__PURE__ */ jsx(ButtonComponent, {
								block: onCancel === void 0,
								variant: "primary",
								size: "medium",
								onClick: () => {
									if (isSingleSelectModal) onSelectedChange(intermediateSelected);
									onClose(variant === "modal" ? "selection" : "click-outside");
								},
								children: "Save"
							})]
						}) : null,
						showResponsiveSaveAndCloseButton ? /* @__PURE__ */ jsx("div", {
							className: classes$3.ResponsiveSaveButton,
							"data-stretch-save-button": stretchSaveButton,
							children: /* @__PURE__ */ jsx(ButtonComponent, {
								block: true,
								variant: "primary",
								size: "medium",
								onClick: () => {
									onClose("click-outside");
								},
								children: "Save and close"
							})
						}) : null
					]
				}) : null
			]
		})
	}), variant === "modal" && open ? /* @__PURE__ */ jsx("div", { className: classes$3.Backdrop }) : null] });
}
var SecondaryButton = (props) => {
	return /* @__PURE__ */ jsx(ButtonComponent, {
		block: true,
		...props,
		children: props.children
	});
};
SecondaryButton.displayName = "SecondaryButton";
var SecondaryLink = (props) => {
	return /* @__PURE__ */ jsx(LinkButton, {
		...props,
		variant: "invisible",
		block: true,
		children: props.children
	});
};
SecondaryLink.displayName = "SecondaryLink";
var SelectPanel = Object.assign(Panel, {
	__SLOT__: Symbol("SelectPanel"),
	SecondaryActionButton: SecondaryButton,
	SecondaryActionLink: SecondaryLink
});
export { SelectPanel as a, useFormControlForwardedProps as c, LinkButton as i, CheckboxGroupContext as n, SkeletonBox as o, FormControlContextProvider as r, useFormControlContext as s, Checkbox as t };
