import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var HELLO_TIMEOUT = 1e4;
var LOAD_TIMEOUT = 45e3;
var RenderState = {
	ERROR: "ERROR",
	LOADING: "LOADING",
	LOADED: "LOADED",
	READY: "READY"
};
function useFileRenderer(origin, uuid) {
	const [renderStateRef, setRenderState] = useStatefulRef(RenderState.LOADING);
	const errorMsg = useRef(null);
	const iFrameRef = useRef(null);
	const containerRef = useRef(null);
	const renderTiming = useRef({ untimed: true });
	const messageListener = useCallback((event) => onMessage(event, origin, uuid, iFrameRef, containerRef, renderTiming, setRenderState, (error) => errorMsg.current = error), [
		origin,
		setRenderState,
		uuid
	]);
	useEffect(() => {
		resetTiming(renderTiming.current);
		const timeoutWatchdog = (checkHello) => {
			if (renderStateRef.current !== RenderState.LOADING && renderStateRef.current !== RenderState.LOADED || checkHello && !renderTiming.current.hello) return;
			setRenderState(RenderState.ERROR);
		};
		renderTiming.current = {
			load: Date.now(),
			hello: null,
			helloTimer: window.setTimeout(timeoutWatchdog, HELLO_TIMEOUT, true),
			loadTimer: window.setTimeout(timeoutWatchdog, LOAD_TIMEOUT)
		};
		return () => {
			resetTiming(renderTiming.current);
		};
	}, [renderStateRef, setRenderState]);
	useEffect(() => {
		window.addEventListener("message", messageListener);
		return () => window.removeEventListener("message", messageListener);
	}, [messageListener]);
	return {
		renderState: renderStateRef.current,
		errorMsg: errorMsg.current,
		iFrameRef,
		containerRef
	};
}
function onMessage(event, origin, uuid, iFrameRef, containerRef, renderTiming, setRenderState, setError) {
	if (event.origin !== origin) return;
	const renderMessage = getRenderMessage(event);
	if (!renderMessage) {
		setRenderState(RenderState.ERROR);
		return;
	}
	if (renderMessage.identity !== uuid) return;
	const body = renderMessage.body;
	const payload = renderMessage.payload != null ? renderMessage.payload : void 0;
	const renderWindow = iFrameRef.current?.contentWindow;
	switch (body) {
		case "hello":
			{
				const timingData = renderTiming.current ?? { untimed: true };
				timingData.hello = Date.now();
				const ackmsg = {
					type: "render:cmd",
					body: {
						cmd: "ack",
						ack: true
					}
				};
				const msg = {
					type: "render:cmd",
					body: {
						cmd: "branding",
						branding: false
					}
				};
				sendRenderCommand(renderWindow, ackmsg);
				sendRenderCommand(renderWindow, msg);
			}
			break;
		case "error":
		case "error:fatal":
		case "error:invalid":
			if (payload) {
				setError(payload.error ?? null);
				setRenderState(RenderState.ERROR);
			} else setRenderState(RenderState.ERROR);
			break;
		case "loading":
			setRenderState(RenderState.LOADING);
			break;
		case "loaded":
			setRenderState(RenderState.LOADED);
			break;
		case "ready":
			if (payload && typeof payload.height === "number" && containerRef.current) containerRef.current.style.height = `${payload.height}px`;
			setRenderState(RenderState.READY);
			break;
		case "resize":
			if (payload && typeof payload.height === "number" && containerRef.current) containerRef.current.style.height = `${payload.height}px`;
			break;
		case "code_rendering_service:container:get_size":
			sendRenderCommand(renderWindow, {
				type: "render:cmd",
				body: {
					cmd: "code_rendering_service:container:size",
					"code_rendering_service:container:size": { width: containerRef.current?.getBoundingClientRect().width }
				}
			});
			break;
		case "code_rendering_service:markdown:get_data":
			if (!iFrameRef.current || !containerRef.current) return;
			sendIFrameDataToIFrame(iFrameRef.current, containerRef.current);
			break;
		default: break;
	}
}
function useStatefulRef(initialState) {
	const $ = c(1);
	const [renderStateInt, setRenderStateInt] = useState(initialState);
	const renderStateRef = useRef(renderStateInt);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		const setRenderState = (state) => {
			renderStateRef.current = state;
			setRenderStateInt(state);
		};
		t0 = [renderStateRef, setRenderState];
		$[0] = t0;
	} else t0 = $[0];
	return t0;
}
function resetTiming(renderTiming) {
	if (!renderTiming) return;
	renderTiming.load = renderTiming.hello = null;
	if (renderTiming.helloTimer) {
		clearTimeout(renderTiming.helloTimer);
		renderTiming.helloTimer = null;
	}
	if (renderTiming.loadTimer) {
		clearTimeout(renderTiming.loadTimer);
		renderTiming.loadTimer = null;
	}
}
function sendIFrameDataToIFrame(iframe, container) {
	const data = iframe.getAttribute("data-content");
	if (!data) return;
	const msg = {
		type: "render:cmd",
		body: {
			cmd: "code_rendering_service:data:ready",
			"code_rendering_service:data:ready": {
				data: JSON.parse(data).data,
				width: container.getBoundingClientRect().width
			}
		}
	};
	sendRenderCommand(iframe.contentWindow, msg);
}
function sendRenderCommand(renderWindow, message) {
	if (renderWindow && renderWindow.postMessage) renderWindow.postMessage(JSON.stringify(message), "*");
}
function getRenderMessage(event) {
	let data = event.data;
	if (!data) return null;
	if (typeof data === "string") try {
		data = JSON.parse(data);
	} catch {
		return null;
	}
	if (!isRenderMessage(data)) return null;
	return data;
}
function isRenderMessage(data) {
	if (typeof data !== "object" || !data) return false;
	const messageData = data;
	return messageData.type === "render" && typeof messageData.body === "string" && typeof messageData.payload === "object";
}
var FileRendererBlob_module_default = {
	errorMessageHeading: "FileRendererBlob-module_Z3vGIG_errorMessageHeading",
	fileContentFrame: "FileRendererBlob-module_Z3vGIG_fileContentFrame",
	fileContentFrameNotReady: "FileRendererBlob-module_Z3vGIG_fileContentFrameNotReady",
	FileRendererViewport: "FileRendererBlob-module_Z3vGIG_FileRendererViewport",
	FileRendererViewportNonError: "FileRendererBlob-module_Z3vGIG_FileRendererViewportNonError",
	FileRendererViewportReady: "FileRendererBlob-module_Z3vGIG_FileRendererViewportReady",
	FileRendererWrapper: "FileRendererBlob-module_Z3vGIG_FileRendererWrapper",
	loadingIndicator: "FileRendererBlob-module_Z3vGIG_loadingIndicator"
};
var MAX_BLOB_SIZE = 2e8;
var MAX_NOTEBOOK_SIZE = 3e7;
function FileRendererBlob(t0) {
	const $ = c(15);
	const { identityUuid, size, type, url, iframeClassName, viewportClassName } = t0;
	const { isBrowser } = useRuntimeEnvironment();
	const tempOrigin = isBrowser ? ssrSafeLocation?.origin ?? "https://www.github.com" : "https://www.github.com";
	let t1;
	if ($[0] !== tempOrigin || $[1] !== url) {
		t1 = new URL(url, tempOrigin);
		$[0] = tempOrigin;
		$[1] = url;
		$[2] = t1;
	} else t1 = $[2];
	const origin = t1.origin;
	const { renderState, errorMsg, iFrameRef, containerRef } = useFileRenderer(origin, identityUuid);
	if (type === "ipynb" && size > MAX_NOTEBOOK_SIZE || size > MAX_BLOB_SIZE) {
		let t2;
		if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = jsx(Flash, {
				variant: "danger",
				children: "Sorry, this is too big to display."
			});
			$[3] = t2;
		} else t2 = $[3];
		return t2;
	}
	let t2;
	if ($[4] !== containerRef || $[5] !== errorMsg || $[6] !== iFrameRef || $[7] !== identityUuid || $[8] !== iframeClassName || $[9] !== origin || $[10] !== renderState || $[11] !== type || $[12] !== url || $[13] !== viewportClassName) {
		t2 = jsx("div", {
			className: FileRendererBlob_module_default.FileRendererWrapper,
			children: jsxs("div", {
				"data-hpc": true,
				"data-host": origin,
				"data-type": type,
				ref: containerRef,
				className: clsx(FileRendererBlob_module_default.FileRendererViewport, {
					[FileRendererBlob_module_default.FileRendererViewportNonError]: renderState !== RenderState.ERROR,
					[FileRendererBlob_module_default.FileRendererViewportReady]: renderState === RenderState.READY
				}, viewportClassName),
				children: [renderState === RenderState.ERROR ? jsx(FileRendererErrorMessage, { error: errorMsg }) : renderState !== RenderState.READY ? jsx(Spinner, {
					size: "large",
					className: FileRendererBlob_module_default.loadingIndicator
				}) : null, renderState !== RenderState.ERROR && jsx("iframe", {
					ref: iFrameRef,
					src: `${url}#${identityUuid}`,
					sandbox: "allow-scripts allow-same-origin allow-top-navigation",
					name: identityUuid,
					title: "File display",
					className: clsx(FileRendererBlob_module_default.fileContentFrame, { [FileRendererBlob_module_default.fileContentFrameNotReady]: renderState !== RenderState.READY }, iframeClassName),
					children: "Viewer requires iframe."
				})]
			})
		});
		$[4] = containerRef;
		$[5] = errorMsg;
		$[6] = iFrameRef;
		$[7] = identityUuid;
		$[8] = iframeClassName;
		$[9] = origin;
		$[10] = renderState;
		$[11] = type;
		$[12] = url;
		$[13] = viewportClassName;
		$[14] = t2;
	} else t2 = $[14];
	return t2;
}
FileRendererBlob.displayName = "FileRendererBlob";
function FileRendererErrorMessage({ error }) {
	if (!error) return /* @__PURE__ */ jsx(Flash, {
		variant: "danger",
		children: "Unable to render code block"
	});
	const msgLines = error.split("\n");
	return /* @__PURE__ */ jsxs(Flash, {
		variant: "danger",
		children: [/* @__PURE__ */ jsx("p", {
			className: FileRendererBlob_module_default.errorMessageHeading,
			children: "Error rendering embedded code"
		}), /* @__PURE__ */ jsx("p", { children: msgLines.map((line, index) => /* @__PURE__ */ jsxs(React.Fragment, { children: [line, /* @__PURE__ */ jsx("br", {})] }, `error-line-${index}`)) })]
	});
}
FileRendererErrorMessage.displayName = "FileRendererErrorMessage";
export { FileRendererBlob as t };
