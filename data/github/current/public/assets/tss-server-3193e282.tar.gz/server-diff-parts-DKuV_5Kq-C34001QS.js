import { _n as KebabHorizontalIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { r as VerifiedHTMLDiv } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
/**
* Prefix the line anchor to prevent the browser from jumping to the element when we update the hash.
*/
function lineIdentifierFrom(anchor) {
	return `line-${anchor}`;
}
/**
* Returns the line anchor based on the file anchor, orientation, and line number
*/
function lineAnchorFrom(fileAnchor, orientation, lineNumber) {
	return `${fileAnchor}${orientation === "left" ? "L" : "R"}${lineNumber}`;
}
/**
* Returns the line orientation from the diff line type
*/
function lineOrientationFrom(type) {
	return type === "DELETION" ? "left" : "right";
}
/**
* Returns the background color based on the line type
*/
function getBackgroundColor(lineType, isNumber = false, isHighlighted = false) {
	if (isHighlighted) return "var(--bgColor-attention-muted, var(--color-attention-subtle))";
	switch (lineType) {
		case "ADDITION": return isNumber ? "var(--diffBlob-additionNum-bgColor, var(--diffBlob-addition-bgColor-num))" : "var(--diffBlob-additionLine-bgColor, var(--diffBlob-addition-bgColor-line))";
		case "DELETION": return isNumber ? "var(--diffBlob-deletionNum-bgColor, var(--diffBlob-deletion-bgColor-num))" : "var(--diffBlob-deletionLine-bgColor, var(--diffBlob-deletion-bgColor-line))";
		case "HUNK": return isNumber ? "var(--diffBlob-hunkNum-bgColor, var(--diffBlob-hunk-bgColor-num))" : "var(--diffBlob-hunkLine-bgColor, var(--bgColor-accent-muted))";
		case "EMPTY": return isNumber ? "var(--diffBlob-emptyNum-bgColor, var(--diffBlob-hunk-bgColor-num))" : "var(--diffBlob-emptyLine-bgColor, var(--bgColor-accent-muted))";
		default: return;
	}
}
/**
* Get the largest line number, then return the width of the line number column using it
*/
function getLineNumberWidth(lines) {
	let maxLineNumber = 0;
	if (lines) for (const line of lines) maxLineNumber = Math.max(maxLineNumber, line?.left ?? 0, line?.right ?? 0);
	const lineNumberPxWidth = maxLineNumber.toString().length * 8 + 20;
	return Math.max(lineNumberPxWidth, 40).toString();
}
/**
* Renders the diff text
*/
var DiffText = (props) => {
	const { dragging, isHighlighted, isLeftColumn, colSpan, line, lineAnchor } = props;
	let lineHTML = line.html;
	let lineTypeChar = "";
	if (["ADDITION", "DELETION"].includes(line.type) && ["+", "-"].includes(lineHTML[0])) {
		lineTypeChar = lineHTML[0];
		lineHTML = lineHTML.slice(1);
	}
	return /* @__PURE__ */ jsx("td", {
		className: clsx("diff-text-cell", {
			"border-left color-border-accent-emphasis": dragging && isHighlighted,
			"border-right": isLeftColumn && line.type !== "HUNK"
		}),
		colSpan,
		id: lineAnchor ? lineIdentifierFrom(lineAnchor) : void 0,
		style: { backgroundColor: getBackgroundColor(line.type, false, isHighlighted) },
		children: /* @__PURE__ */ jsxs("code", {
			"data-code-marker": lineTypeChar,
			className: clsx("diff-text syntax-highlighted-line", {
				addition: line.type === "ADDITION",
				deletion: line.type === "DELETION"
			}),
			children: [props.lineChild, /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
				className: clsx("diff-text-inner", { "color-fg-muted": line.type === "HUNK" }),
				html: lineHTML,
				style: { marginLeft: line.type === "CONTEXT" ? "-7px" : void 0 }
			})]
		})
	});
};
DiffText.displayName = "DiffText";
/**
* Renders the line number on a diff line
*/
var LineNumber = ({ ariaLabel, children, hasExpanderButton, lineType, colSpan, interactiveProps, isHighlighted, ...rest }) => {
	let wrappedChildren = /* @__PURE__ */ jsx("code", {
		className: "pr-2",
		children
	});
	if (interactiveProps) wrappedChildren = /* @__PURE__ */ jsx("button", {
		className: "diff-line-number-button",
		...interactiveProps,
		"aria-label": ariaLabel,
		children: wrappedChildren
	});
	return /* @__PURE__ */ jsx("td", {
		"aria-label": !interactiveProps ? ariaLabel : void 0,
		"data-line-number": true,
		className: clsx("diff-line-number", {
			"has-expander": hasExpanderButton,
			clickable: !!interactiveProps
		}),
		colSpan: colSpan || 1,
		style: { backgroundColor: getBackgroundColor(lineType, true, isHighlighted) },
		...rest,
		children: wrappedChildren
	});
};
LineNumber.displayName = "LineNumber";
/**
* Basic unit of a diffline,
* conditionally shows the left and right line numbers, as well as the diff text
*/
var DiffLinePart = ({ dragging, isHighlighted, isLeftColumn, isSplit, lineAnchor, line, lineChild, onLineNumberClick }) => {
	const isContext = line.type === "CONTEXT" || line.type === "INJECTED_CONTEXT";
	const showLeftNumber = line.type !== "ADDITION";
	const showLeftNumberCell = showLeftNumber || !isSplit;
	const showRightNumber = line.type !== "DELETION";
	const showRightNumberCell = showRightNumber && !isContext || !isSplit;
	const firstLineNumber = isSplit && isContext ? isLeftColumn ? line.left : line.right : line.left;
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		showLeftNumberCell && /* @__PURE__ */ jsx(LineNumber, {
			ariaLabel: `Line ${showLeftNumber ? line.left?.toString() : line.right?.toString()}`,
			lineType: line.type,
			interactiveProps: onLineNumberClick ? { onClick: onLineNumberClick } : null,
			isHighlighted,
			children: showLeftNumber && firstLineNumber
		}),
		showRightNumberCell && /* @__PURE__ */ jsx(LineNumber, {
			ariaLabel: `Line ${showRightNumber ? line.right?.toString() : line.left?.toString()}`,
			lineType: line.type,
			interactiveProps: onLineNumberClick ? { onClick: onLineNumberClick } : null,
			isHighlighted,
			children: showRightNumber && line.right
		}),
		/* @__PURE__ */ jsx(DiffText, {
			dragging,
			isHighlighted,
			isLeftColumn,
			line,
			lineAnchor,
			lineChild
		})
	] });
};
DiffLinePart.displayName = "DiffLinePart";
var DiffPlaceholder_module_default = { DiffPlaceholderSVG: "DiffPlaceholder-module_s2Anua_DiffPlaceholderSVG" };
function DiffPlaceholder() {
	return /* @__PURE__ */ jsx("svg", {
		"aria-hidden": "true",
		version: "1.1",
		viewBox: "0 0 340 84",
		xmlns: "http://www.w3.org/2000/svg",
		className: DiffPlaceholder_module_default.DiffPlaceholderSVG,
		children: /* @__PURE__ */ jsxs("defs", { children: [/* @__PURE__ */ jsxs("clipPath", {
			id: "diff-placeholder",
			children: [
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "67.0175439",
					x: "0",
					y: "0"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "100.701754",
					x: "18.9473684",
					y: "47.7194983"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "37.8947368",
					x: "0",
					y: "71.930126"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "53.3333333",
					x: "127.017544",
					y: "48.0703769"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "72.9824561",
					x: "187.719298",
					y: "48.0703769"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "140.350877",
					x: "76.8421053",
					y: "0"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "140.350877",
					x: "17.8947368",
					y: "23.8597491"
				}),
				/* @__PURE__ */ jsx("rect", {
					height: "11.9298746",
					rx: "2",
					width: "173.684211",
					x: "166.315789",
					y: "23.8597491"
				})
			]
		}), /* @__PURE__ */ jsxs("linearGradient", {
			id: "animated-diff-gradient",
			spreadMethod: "reflect",
			x1: "0",
			x2: "0",
			y1: "0",
			y2: "1",
			children: [
				/* @__PURE__ */ jsx("stop", {
					offset: "0",
					stopColor: "#eee"
				}),
				/* @__PURE__ */ jsx("stop", {
					offset: "0.2",
					stopColor: "#eee"
				}),
				/* @__PURE__ */ jsx("stop", {
					offset: "0.5",
					stopColor: "#ddd"
				}),
				/* @__PURE__ */ jsx("stop", {
					offset: "0.8",
					stopColor: "#eee"
				}),
				/* @__PURE__ */ jsx("stop", {
					offset: "1",
					stopColor: "#eee"
				}),
				/* @__PURE__ */ jsx("animateTransform", {
					attributeName: "y1",
					dur: "1s",
					repeatCount: "3",
					values: "0%; 100%; 0"
				}),
				/* @__PURE__ */ jsx("animateTransform", {
					attributeName: "y2",
					dur: "1s",
					repeatCount: "3",
					values: "100%; 200%; 0"
				})
			]
		})] })
	});
}
DiffPlaceholder.displayName = "DiffPlaceholder";
var DiffSquares_module_default = {
	addition: "DiffSquares-module_2WUtEq_addition",
	deletion: "DiffSquares-module_2WUtEq_deletion",
	diffSquare: "DiffSquares-module_2WUtEq_diffSquare",
	neutral: "DiffSquares-module_2WUtEq_neutral"
};
function DiffSquares({ squares }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex",
		children: squares.map((diffStatType, i) => /* @__PURE__ */ jsx("div", {
			"data-testid": `${diffStatType} diffstat`,
			className: clsx(DiffSquares_module_default.diffSquare, DiffSquares_module_default[diffStatType])
		}, i))
	});
}
DiffSquares.displayName = "DiffSquares";
var DiffStat = {
	addition: "addition",
	deletion: "deletion",
	neutral: "neutral"
};
function buildScreenReaderHint({ linesAdded, linesDeleted }) {
	let labelText = "Lines changed: ";
	labelText += `${linesAdded} ${linesAdded === 1 ? "addition" : "additions"} & `;
	labelText += `${linesDeleted} ${linesDeleted === 1 ? "deletion" : "deletions"}`;
	return labelText;
}
function DiffStats({ linesAdded = 0, linesDeleted = 0, linesChanged = 0, hideSquares = false }) {
	if (!linesAdded && !linesDeleted && !linesChanged || linesChanged === 0) return null;
	const { greenSquares, redSquares, graySquares } = calculateDiffSquareCounts(linesAdded, linesDeleted, linesChanged);
	const squares = [
		...Array(greenSquares).fill(DiffStat.addition),
		...Array(redSquares).fill(DiffStat.deletion),
		...Array(graySquares).fill(DiffStat.neutral)
	];
	return /* @__PURE__ */ jsxs("div", {
		className: "d-flex flex-items-center gap-1 pl-1",
		children: [
			linesAdded > 0 && /* @__PURE__ */ jsxs("span", {
				"aria-hidden": "true",
				className: "f6 text-bold fgColor-success",
				children: ["+", linesAdded.toLocaleString()]
			}),
			linesDeleted > 0 && /* @__PURE__ */ jsxs("span", {
				"aria-hidden": "true",
				className: "f6 text-bold fgColor-danger",
				children: ["-", linesDeleted.toLocaleString()]
			}),
			/* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: buildScreenReaderHint({
					linesAdded,
					linesDeleted
				})
			}),
			!hideSquares && /* @__PURE__ */ jsx(DiffSquares, { squares })
		]
	});
}
DiffStats.displayName = "DiffStats";
function calculateDiffSquareCounts(linesAdded, linesDeleted, linesChanged) {
	const totalSquares = 5;
	const adjust = linesChanged > totalSquares ? totalSquares / linesChanged : 1;
	const greenSquares = Math.floor(linesAdded * adjust);
	const redSquares = Math.floor(linesDeleted * adjust);
	return {
		greenSquares,
		redSquares,
		graySquares: totalSquares - greenSquares - redSquares
	};
}
/**
* Renders the hunk header diff line
*/
function HunkHeaderDiffLine({ currentLine, hunkButton, isLeftColumn, isSplit }) {
	if (isSplit && !isLeftColumn) return null;
	return /* @__PURE__ */ jsxs(Fragment, { children: [hunkButton ? /* @__PURE__ */ jsx(LineNumber, {
		colSpan: isSplit ? 1 : 2,
		hasExpanderButton: true,
		lineType: currentLine.type,
		children: hunkButton
	}) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(LineNumber, {
		lineType: currentLine.type,
		children: /* @__PURE__ */ jsx(KebabHorizontalIcon, {})
	}), !isSplit && /* @__PURE__ */ jsx(LineNumber, {
		lineType: currentLine.type,
		children: /* @__PURE__ */ jsx(KebabHorizontalIcon, {})
	})] }), /* @__PURE__ */ jsx(DiffText, {
		isHighlighted: false,
		isLeftColumn: true,
		colSpan: isSplit ? 3 : void 0,
		line: currentLine
	})] });
}
HunkHeaderDiffLine.displayName = "HunkHeaderDiffLine";
function HunkKebabIcon() {
	return /* @__PURE__ */ jsx("div", {
		className: "hunk-kebab-icon pr-2 pb-1",
		children: /* @__PURE__ */ jsx(KebabHorizontalIcon, {})
	});
}
HunkKebabIcon.displayName = "HunkKebabIcon";
/**
* Renders an empty diffline
*/
function EmptyDiffLine({ isLeftColumn }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(LineNumber, { lineType: "EMPTY" }), /* @__PURE__ */ jsx("td", {
		className: clsx("empty-diff-line", { "border-right": isLeftColumn }),
		colSpan: 1
	})] });
}
EmptyDiffLine.displayName = "EmptyDiffLine";
function SplitDiffTable(props) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("thead", {
			className: "sr-only",
			children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Original file line number"
				}),
				/* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Original file line"
				}),
				/* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Diff line number"
				}),
				/* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Diff line change"
				})
			] })
		}),
		/* @__PURE__ */ jsxs("colgroup", { children: [
			/* @__PURE__ */ jsx("col", { width: props.lineWidth }),
			/* @__PURE__ */ jsx("col", {}),
			/* @__PURE__ */ jsx("col", { width: props.lineWidth }),
			/* @__PURE__ */ jsx("col", {})
		] }),
		/* @__PURE__ */ jsx("tbody", { children: props.children })
	] });
}
SplitDiffTable.displayName = "SplitDiffTable";
function UnifiedDiffTable(props) {
	const showLineNumbers = props.showLineNumbers ?? true;
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("thead", {
			className: "sr-only",
			children: /* @__PURE__ */ jsxs("tr", { children: [
				showLineNumbers && /* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Original file line number"
				}),
				showLineNumbers && /* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Diff line number"
				}),
				/* @__PURE__ */ jsx("th", {
					scope: "col",
					children: "Diff line change"
				})
			] })
		}),
		/* @__PURE__ */ jsxs("colgroup", { children: [
			showLineNumbers && /* @__PURE__ */ jsx("col", { width: props.lineWidth }),
			showLineNumbers && /* @__PURE__ */ jsx("col", { width: props.lineWidth }),
			/* @__PURE__ */ jsx("col", { width: "100%" })
		] }),
		/* @__PURE__ */ jsx("tbody", { children: props.children })
	] });
}
UnifiedDiffTable.displayName = "UnifiedDiffTable";
var UnifiedDiffLines_module_default = {
	diffHunkCell: "UnifiedDiffLines-module_6ADWuG_diffHunkCell",
	diffHunkText: "UnifiedDiffLines-module_6ADWuG_diffHunkText",
	diffLineNumber: "UnifiedDiffLines-module_6ADWuG_diffLineNumber",
	diffTextCell: "UnifiedDiffLines-module_6ADWuG_diffTextCell",
	diffTextInner: "UnifiedDiffLines-module_6ADWuG_diffTextInner",
	diffTextMarker: "UnifiedDiffLines-module_6ADWuG_diffTextMarker",
	syntaxHighlightedAdditionLine: "UnifiedDiffLines-module_6ADWuG_syntaxHighlightedAdditionLine",
	syntaxHighlightedDeletionLine: "UnifiedDiffLines-module_6ADWuG_syntaxHighlightedDeletionLine",
	unifiedDiffLines: "UnifiedDiffLines-module_6ADWuG_unifiedDiffLines"
};
/**
* Presentational component for a non-interactive line number cell
*/
function LineNumberCell({ line, children }) {
	return /* @__PURE__ */ jsx("td", {
		className: UnifiedDiffLines_module_default.diffLineNumber,
		style: {
			backgroundColor: getBackgroundColor(line.type, true),
			textAlign: "center"
		},
		children: /* @__PURE__ */ jsx("code", { children })
	});
}
/**
* Presentational component for a non-interactive hunk cell
* Note that it spans the entire table row
*/
LineNumberCell.displayName = "LineNumberCell";
function HunkCell({ line, showLineNumbers }) {
	return /* @__PURE__ */ jsx("td", {
		colSpan: showLineNumbers ? 4 : 2,
		className: UnifiedDiffLines_module_default.diffHunkCell,
		valign: "top",
		children: /* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-row",
			children: [/* @__PURE__ */ jsx(HunkKebabIcon, {}), /* @__PURE__ */ jsx("code", {
				className: UnifiedDiffLines_module_default.diffHunkText,
				children: /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
					className: clsx(UnifiedDiffLines_module_default.diffTextInner, "color-fg-muted"),
					html: line.html
				})
			})]
		})
	});
}
/**
* Renders a non-interactive row of a unified diff line
* Specifically for use in outdated threads, which return a slightly different set of difflines
* This component was derived from the interactive version (CodeDiffLine) in DiffLineTableRow.tsx
*/
HunkCell.displayName = "HunkCell";
function UnifiedDiffRow({ line, showLineNumbers }) {
	const isHunkRow = line.type === "HUNK";
	const showLeftNumber = line.type !== "ADDITION";
	const showRightNumber = line.type !== "DELETION";
	const lineMarker = line.type === "ADDITION" ? "+" : line.type === "DELETION" ? "-" : void 0;
	const showLineMarker = !!lineMarker;
	let lineHTML = line.html;
	if (showLineMarker && lineHTML[0] === lineMarker) lineHTML = lineHTML.slice(1);
	return /* @__PURE__ */ jsxs("tr", { children: [isHunkRow && /* @__PURE__ */ jsx(HunkCell, {
		line,
		showLineNumbers
	}), !isHunkRow && /* @__PURE__ */ jsxs(Fragment, { children: [
		showLineNumbers && /* @__PURE__ */ jsx(LineNumberCell, {
			line,
			children: showLeftNumber && line.left
		}),
		showLineNumbers && /* @__PURE__ */ jsx(LineNumberCell, {
			line,
			children: showRightNumber && line.right
		}),
		/* @__PURE__ */ jsx("td", {
			className: UnifiedDiffLines_module_default.diffTextCell,
			style: { backgroundColor: getBackgroundColor(line.type, false) },
			children: /* @__PURE__ */ jsxs("code", {
				className: clsx(line.type === "ADDITION" && UnifiedDiffLines_module_default.syntaxHighlightedAdditionLine, line.type === "DELETION" && UnifiedDiffLines_module_default.syntaxHighlightedDeletionLine),
				children: [showLineMarker && /* @__PURE__ */ jsx("span", {
					className: UnifiedDiffLines_module_default.diffTextMarker,
					children: lineMarker
				}), /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
					className: UnifiedDiffLines_module_default.diffTextInner,
					html: lineHTML,
					style: { backgroundColor: getBackgroundColor(line.type, false) }
				})]
			})
		})
	] })] });
}
UnifiedDiffRow.displayName = "UnifiedDiffRow";
function UnifiedDiffLines({ className, lines, lineWidth, tabSize }) {
	const hasLineNumbers = lines.some((line) => line.left !== null || line.right !== null);
	const diffRows = lines.map((diffline, index) => {
		return /* @__PURE__ */ jsx(UnifiedDiffRow, {
			line: diffline,
			showLineNumbers: hasLineNumbers
		}, index);
	});
	return /* @__PURE__ */ jsx("table", {
		className: clsx(UnifiedDiffLines_module_default.unifiedDiffLines, className, "tab-size"),
		"data-tab-size": tabSize,
		children: /* @__PURE__ */ jsx(UnifiedDiffTable, {
			lineWidth,
			showLineNumbers: hasLineNumbers,
			children: diffRows
		})
	});
}
UnifiedDiffLines.displayName = "UnifiedDiffLines";
export { EmptyDiffLine as a, UnifiedDiffLines as c, lineAnchorFrom as d, lineOrientationFrom as f, DiffStats as i, UnifiedDiffTable as l, DiffPlaceholder as n, HunkHeaderDiffLine as o, DiffSquares as r, SplitDiffTable as s, DiffLinePart as t, getLineNumberWidth as u };
