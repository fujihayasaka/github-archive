import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { x as useRouteError } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { n as getAppTypeHeader } from "./server-fetch-headers-BkLy5xY3-D29EGvJJ.js";
import { M as deferredMetadataPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as queryFnFetch } from "./server-query-fn-fetch-BcXqGEZV-8_IVUjEO.js";
import { n as QueryRouteQueryType, r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { t as codeViewAppBuilder } from "./server-code-view-layout-route-B5EhdulZ-CpVJHwZC.js";
import { t as latestCommitQuery } from "./server-tree-commit-info-query-Bp7ncbtC-DjEhc-v4.js";
import { t as CodeViewError } from "./server-CodeViewError-DTMNTptz-DKXztgzD.js";
import { t as codeViewTreeRoute } from "./server-code-view-tree-route-DaWFX48b-q_Z2gZhH.js";
import { useEffect } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CodeViewPathIsDirectoryError = class extends Error {
	constructor() {
		super("Path is a directory");
		this.name = "CodeViewPathIsDirectoryError";
	}
};
var ERROR = { type: "badResponseError" };
function CodeViewBlobLayoutErrorBoundary() {
	const $ = c(6);
	const error = useRouteError();
	const navigate = useNavigate$1();
	let t0;
	let t1;
	if ($[0] !== error || $[1] !== navigate) {
		t0 = () => {
			if (error instanceof CodeViewPathIsDirectoryError) navigate(window.location.pathname.replace("/blob", "/tree"), { replace: true });
		};
		t1 = [error, navigate];
		$[0] = error;
		$[1] = navigate;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
	let t2;
	if ($[4] !== error) {
		t2 = error instanceof CodeViewPathIsDirectoryError ? null : jsx(CodeViewError, { ...ERROR });
		$[4] = error;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
CodeViewBlobLayoutErrorBoundary.displayName = "CodeViewBlobLayoutErrorBoundary";
function throwError(json, routeId) {
	if (json.payload?.[codeViewTreeRoute.id]) throw new CodeViewPathIsDirectoryError();
	throw new Error(`Unable to find payload for id: ${routeId}`);
}
var codeViewBlobLayoutRoute = codeViewAppBuilder.createQueryRouteConfig("codeViewBlobLayoutRoute", {
	path: "",
	queries: [
		mainQuery({
			queryDeps: (deps) => {
				const params = deps.params;
				return { pathname: `/${params.owner}/${params.repo}/_layout/${params.branch}/${params["*"]}` };
			},
			queryFn: async ({ routeId, queryDeps }) => {
				const appTypeHeader = getAppTypeHeader("dataRouter");
				const json = await queryFnFetch({ queryDeps: {
					...queryDeps,
					init: {
						...queryDeps?.init,
						headers: {
							...appTypeHeader,
							...queryDeps?.init?.headers
						}
					}
				} }, { encodePath: true });
				const routePayload = json.payload?.[routeId];
				if (!routePayload) throwError(json, routeId);
				return {
					meta: json.meta,
					payload: routePayload
				};
			}
		}),
		{
			queryName: "codeViewBlobLayoutRoute.StyledBlob",
			queryDeps: (deps) => {
				const params = deps.params;
				return { pathname: `/${params.owner}/${params.repo}/_styled/${params.branch}/${params["*"]}` };
			},
			queryFn: async (queryKey) => {
				const json = await queryFnFetch(queryKey, { encodePath: true });
				const payload = json.payload?.[queryKey.queryName];
				if (payload === void 0 || payload === null) throwError(json, queryKey.queryName);
				return payload;
			},
			type: QueryRouteQueryType.Blocking
		},
		{
			queryName: "deferredMetadata",
			queryDeps: ({ params: routeParams }) => {
				const params = routeParams;
				return { pathname: deferredMetadataPath({
					repo: {
						ownerLogin: params.owner,
						name: params.repo
					},
					commitish: params.branch,
					path: params["*"] || ""
				}) };
			},
			queryFn: async (queryKey) => queryFnFetch(queryKey),
			type: QueryRouteQueryType.Deferred
		},
		latestCommitQuery
	],
	shouldRevalidate: ({ currentParams, nextParams }) => {
		return currentParams.owner !== nextParams.owner || currentParams.repo !== nextParams.repo || currentParams.branch !== nextParams.branch || currentParams["*"] !== nextParams["*"];
	}
});
export { codeViewBlobLayoutRoute as t };
