import { t as debounce$1 } from "./server-dist-CJwx2KGE.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { n as COPILOT_AUTH_TOKEN_KEY } from "./server-copilot-auth-token-BzqAQyH0-Dwg6bEJM.js";
import { Z as referenceID, b as copilotFeatureFlags } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { useCallback, useState } from "react";
import { c } from "react/compiler-runtime";
function debounce(wait = 0, opts = {}) {
	return (proto, name, descriptor) => {
		if (!descriptor || typeof descriptor.value !== "function") throw new Error("debounce can only decorate functions");
		const fn = descriptor.value;
		descriptor.value = debounce$1(fn, wait, opts);
		Object.defineProperty(proto, name, descriptor);
	};
}
function __decorate(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
}
var CopilotLocalStorage = class {
	COPILOT_REPO_CUSTOM_INSTRUCTIONS_STATE_KEY = "COPILOT_REPO_CUSTOM_INSTRUCTIONS_STATE_KEY";
	COPILOT_SELECTED_THREAD_ID_STORAGE_KEY = "COPILOT_SELECTED_THREAD_ID_STORAGE_KEY";
	COPILOT_COLLAPSED_STATE_KEY = "COPILOT_COLLAPSED_STATE_KEY";
	COPILOT_IMMERSIVE_SIDEBAR_COLLAPSED_STATE_KEY = "COPILOT_IMMERSIVE_SIDEBAR_COLLAPSED_STATE_KEY";
	COPILOT_PANEL_HEIGHT = "COPILOT_PANEL_HEIGHT";
	DEFAULT_PANEL_HEIGHT = 600;
	COPILOT_PANEL_WIDTH = "COPILOT_PANEL_WIDTH";
	COPILOT_ENTRYPOINT_MESSAGE_KEY = (threadID) => threadID ? `COPILOT_ENTRYPOINT_MESSAGE_KEY_${threadID}` : "COPILOT_ENTRYPOINT_MESSAGE_KEY";
	COPILOT_TASK_ENTRYPOINT_MESSAGE_KEY = "COPILOT_TASK_ENTRYPOINT_MESSAGE_KEY";
	COPILOT_LOOP_ENTRYPOINT_MESSAGE_KEY = "COPILOT_LOOP_ENTRYPOINT_MESSAGE_KEY";
	COPILOT_SPARK_ENTRYPOINT_MESSAGE_KEY = "COPILOT_SPARK_ENTRYPOINT_MESSAGE_KEY";
	COPILOT_MESSAGE_REQUEST_ID_KEY = "COPILOT_MESSAGE_REQUEST_ID_KEY";
	COPILOT_METER_BANNER_FLAG = "COPILOT_METER_BANNER_FLAG";
	COPILOT_QUOTA_EXCEEDED_BANNER_FLAG = "COPILOT_QUOTA_EXCEEDED_BANNER_FLAG";
	COPILOT_CODING_AGENT_QUOTA_BANNER_DISMISSED_PREFIX = "COPILOT_CODING_AGENT_QUOTA_BANNER_DISMISSED_";
	COPILOT_ANIMATION_FLAG = "COPILOT_ANIMATION_FLAG";
	COPILOT_WRAP_CODE_LINES_KEY = "COPILOT_WRAP_CODE_LINES_KEY";
	COPILOT_TRACING_REQUESTED_FLAG = "COPILOT_TRACING_REQUESTED_FLAG";
	COPILOT_DIFF_REFERENCES_KEY = "COPILOT_DIFF_REFERENCES_KEY";
	COPILOT_SPACES_MCP_BANNER_DISMISSAL_COUNT = "COPILOT_SPACES_MCP_BANNER_DISMISSAL_COUNT";
	COPILOT_SPACES_SOURCES_TIP_DISMISSAL_COUNT = "COPILOT_SPACES_SOURCES_TIP_DISMISSAL_COUNT";
	COPILOT_AGENT_CAPABILITIES_TOOLTIP_DISMISSED = "COPILOT_AGENT_CAPABILITIES_TOOLTIP_DISMISSED";
	COPILOT_SPACES_SELECTED_TAB = "COPILOT_SPACES_SELECTED_TAB";
	COPILOT_SPACES_SELECTION_MENU_LAST_SELECTED_SPACE = "COPILOT_SPACES_SELECTION_MENU_LAST_SELECTED_SPACE";
	COPILOT_LAST_USED_REPOSITORY_KEY = "COPILOT_LAST_USED_REPOSITORY_KEY";
	COPILOT_ACTIVE_MODE_KEY = "COPILOT_ACTIVE_MODE_KEY";
	COPILOT_SELECTED_MODEL_VERSION_KEY = "COPILOT_SELECTED_MODEL_VERSION";
	COPILOT_LANDED_ON_AGENTS_VIEW_KEY = "COPILOT_LANDED_ON_AGENTS_VIEW_KEY";
	lastCheckedModelVersion = null;
	MAX_MESSAGE_REQUEST_ID_STORAGE_COUNT = 100;
	DEFAULT_PANEL_WIDTH = 480;
	CURRENT_MODEL_STORAGE_VERSION = "12";
	COPILOT_SELECTED_MODEL_STORAGE_KEY = (threadID) => `COPILOT_SELECTED_MODEL_${threadID}`;
	COPILOT_SETTINGS_STORAGE_KEY = (threadID) => `COPILOT_SETTINGS_${threadID}`;
	COPILOT_SAVED_USER_MESSAGE_KEY = (threadID, source) => `COPILOT_SAVED_USER_MESSAGE_${source}_${threadID}`;
	COPILOT_SAVED_USER_MESSAGE_ON_ERROR_KEY = (threadID) => `COPILOT_SAVED_USER_MESSAGE_ON_ERROR_${threadID}`;
	COPILOT_CURRENT_REFERENCES_KEY = (threadID) => `COPILOT_CURRENT_REFERENCES_${threadID}`;
	COPILOT_SELECTED_TOPIC_STORAGE_KEY = (threadId) => `COPILOT_SELECTED_TOPIC_${threadId}`;
	localStorage = safeStorage("localStorage", {
		throwQuotaErrorsOnSet: false,
		ttl: 1e3 * 60 * 60 * 24
	});
	mediumStorage = safeStorage("localStorage", {
		throwQuotaErrorsOnSet: false,
		ttl: 1e3 * 60 * 60 * 24 * 28
	});
	longStorage = safeStorage("localStorage", { throwQuotaErrorsOnSet: false });
	tempStorage = safeStorage("localStorage", {
		throwQuotaErrorsOnSet: false,
		ttl: 1e3 * 60 * 30
	});
	sessionStorage = safeStorage("sessionStorage", {
		throwQuotaErrorsOnSet: false,
		ttl: 1e3 * 60 * 60 * 24
	});
	get selectedThreadID() {
		return this.localStorage.getItem(this.COPILOT_SELECTED_THREAD_ID_STORAGE_KEY);
	}
	set selectedThreadID(threadID) {
		const key = this.COPILOT_SELECTED_THREAD_ID_STORAGE_KEY;
		if (threadID == null) {
			this.localStorage.removeItem(key);
			return;
		}
		this.localStorage.setItem(key, threadID);
	}
	getModel(threadID) {
		if (this.lastCheckedModelVersion !== this.CURRENT_MODEL_STORAGE_VERSION && threadID === null) this.checkAndClearModelSelection();
		const json = this.mediumStorage.getItem(this.COPILOT_SELECTED_MODEL_STORAGE_KEY(threadID));
		return json === null ? json : JSON.parse(json);
	}
	setModel(threadID, value, updateDefault = true) {
		this.mediumStorage.setItem(this.COPILOT_SELECTED_MODEL_STORAGE_KEY(threadID), JSON.stringify(value));
		if (threadID && updateDefault) this.mediumStorage.setItem(this.COPILOT_SELECTED_MODEL_STORAGE_KEY(null), JSON.stringify(value));
	}
	/**
	* Clears cached model selection for new threads when version changes.
	* Only runs when clearModelSelectionForDefaultChange FF is enabled.
	* Only clears null thread to allow existing threads to keep their selections.
	*/
	checkAndClearModelSelection() {
		this.lastCheckedModelVersion = this.CURRENT_MODEL_STORAGE_VERSION;
		if (!copilotFeatureFlags.clearModelSelectionForDefaultChange) return;
		if (this.longStorage.getItem(this.COPILOT_SELECTED_MODEL_VERSION_KEY) !== this.CURRENT_MODEL_STORAGE_VERSION) {
			this.mediumStorage.removeItem(this.COPILOT_SELECTED_MODEL_STORAGE_KEY(null));
			this.longStorage.setItem(this.COPILOT_SELECTED_MODEL_VERSION_KEY, this.CURRENT_MODEL_STORAGE_VERSION);
		}
	}
	get settings() {
		const json = this.localStorage.getItem(this.COPILOT_SETTINGS_STORAGE_KEY(this.selectedThreadID));
		return json === null ? json : JSON.parse(json);
	}
	set settings(value) {
		this.localStorage.setItem(this.COPILOT_SETTINGS_STORAGE_KEY(this.selectedThreadID), JSON.stringify(value));
	}
	getPanelHeight() {
		const val = this.localStorage.getItem(this.COPILOT_PANEL_HEIGHT);
		return val ? parseInt(val) : this.DEFAULT_PANEL_HEIGHT;
	}
	setPanelHeight(height) {
		const key = this.COPILOT_PANEL_HEIGHT;
		this.localStorage.setItem(key, height.toString());
	}
	getPanelWidth() {
		const val = this.localStorage.getItem(this.COPILOT_PANEL_WIDTH);
		return val ? parseInt(val) : this.DEFAULT_PANEL_WIDTH;
	}
	setPanelWidth(width) {
		const key = this.COPILOT_PANEL_WIDTH;
		this.localStorage.setItem(key, width.toString());
	}
	getRepoCustomInstructionsState() {
		return this.localStorage.getItem(this.COPILOT_REPO_CUSTOM_INSTRUCTIONS_STATE_KEY) !== "false";
	}
	setRepoCustomInstructionsState(enabled) {
		const key = this.COPILOT_REPO_CUSTOM_INSTRUCTIONS_STATE_KEY;
		this.localStorage.setItem(key, enabled.toString());
	}
	getCollapsedState() {
		return this.sessionStorage.getItem(this.COPILOT_COLLAPSED_STATE_KEY) !== "false";
	}
	setCollapsedState(collapsed) {
		const key = this.COPILOT_COLLAPSED_STATE_KEY;
		this.sessionStorage.setItem(key, collapsed.toString());
	}
	getSelectedTopic(threadID) {
		return this.localStorage.getItem(this.COPILOT_SELECTED_TOPIC_STORAGE_KEY(threadID));
	}
	setSelectedTopic(threadID, topic) {
		if (topic == null) {
			this.localStorage.removeItem(this.COPILOT_SELECTED_TOPIC_STORAGE_KEY(threadID));
			return;
		}
		const key = this.COPILOT_SELECTED_TOPIC_STORAGE_KEY(threadID);
		this.localStorage.setItem(key, topic);
	}
	getSavedMessage(threadID, source) {
		return this.localStorage.getItem(this.COPILOT_SAVED_USER_MESSAGE_KEY(threadID, source));
	}
	setSavedMessage(threadID, source, message) {
		this.setSavedMessageFast(threadID, source, message);
	}
	setSavedMessageFast(threadID, source, message) {
		const key = this.COPILOT_SAVED_USER_MESSAGE_KEY(threadID, source);
		if (message == null) {
			this.localStorage.removeItem(key);
			return;
		}
		this.localStorage.setItem(key, message);
	}
	clearSavedUserMessage(threadID, source) {
		this.localStorage.removeItem(this.COPILOT_SAVED_USER_MESSAGE_KEY(threadID, source));
	}
	getSavedUserMessageOnError(threadID) {
		return this.localStorage.getItem(this.COPILOT_SAVED_USER_MESSAGE_ON_ERROR_KEY(threadID));
	}
	setSavedUserMessageOnError(threadID, message) {
		const key = this.COPILOT_SAVED_USER_MESSAGE_ON_ERROR_KEY(threadID);
		if (message == null) {
			this.localStorage.removeItem(key);
			return;
		}
		this.localStorage.setItem(key, message);
	}
	clearSavedUserMessageOnError(threadID) {
		this.localStorage.removeItem(this.COPILOT_SAVED_USER_MESSAGE_ON_ERROR_KEY(threadID));
	}
	getEntrypointMessage(threadID) {
		return this.getEntrypointMessageImpl(this.COPILOT_ENTRYPOINT_MESSAGE_KEY(threadID));
	}
	getEntrypointMessageImpl(key) {
		const entrypointMessage = this.localStorage.getItem(key);
		if (entrypointMessage == null) return null;
		let parsedMessage;
		try {
			parsedMessage = JSON.parse(entrypointMessage);
		} catch {
			return null;
		}
		if (!parsedMessage || !parsedMessage.message) return null;
		return {
			message: parsedMessage.message,
			references: parsedMessage.references,
			model: parsedMessage.model,
			mediaContent: parsedMessage.mediaContent,
			branch: parsedMessage.branch
		};
	}
	clearEntrypointMessage(threadID) {
		this.localStorage.removeItem(this.COPILOT_ENTRYPOINT_MESSAGE_KEY(threadID));
	}
	setEntrypointMessage({ message, references, model, mediaContent, threadID }) {
		this.setEntrypointMessageImpl({
			message,
			references,
			model,
			mediaContent,
			key: this.COPILOT_ENTRYPOINT_MESSAGE_KEY(threadID)
		});
	}
	setEntrypointMessageImpl({ message, references, model, mediaContent, branch, key }) {
		if (message == null) {
			this.localStorage.removeItem(key);
			return;
		}
		this.localStorage.setItem(key, JSON.stringify({
			message,
			references,
			model,
			mediaContent,
			branch
		}));
	}
	getTaskEntrypointMessage() {
		return this.getEntrypointMessageImpl(this.COPILOT_TASK_ENTRYPOINT_MESSAGE_KEY);
	}
	setTaskEntrypointMessage(message, references, branch) {
		this.setEntrypointMessageImpl({
			message,
			references,
			branch,
			key: this.COPILOT_TASK_ENTRYPOINT_MESSAGE_KEY
		});
	}
	getLoopEntrypointMessage() {
		return this.getEntrypointMessageImpl(this.COPILOT_LOOP_ENTRYPOINT_MESSAGE_KEY);
	}
	setLoopEntrypointMessage(message, references) {
		this.setEntrypointMessageImpl({
			message,
			references,
			key: this.COPILOT_LOOP_ENTRYPOINT_MESSAGE_KEY
		});
	}
	getSparkEntrypointMessage() {
		return this.getEntrypointMessageImpl(this.COPILOT_SPARK_ENTRYPOINT_MESSAGE_KEY);
	}
	setSparkEntrypointMessage(message) {
		this.setEntrypointMessageImpl({
			message,
			key: this.COPILOT_SPARK_ENTRYPOINT_MESSAGE_KEY
		});
	}
	getLastUsedRepository() {
		const val = this.localStorage.getItem(this.COPILOT_LAST_USED_REPOSITORY_KEY);
		if (!val) return null;
		try {
			return JSON.parse(val);
		} catch {
			return null;
		}
	}
	setLastUsedRepository(reference) {
		this.localStorage.setItem(this.COPILOT_LAST_USED_REPOSITORY_KEY, JSON.stringify(reference));
	}
	getCurrentReferences(threadID) {
		const key = this.COPILOT_CURRENT_REFERENCES_KEY(threadID);
		const val = this.localStorage.getItem(key);
		if (!val) return null;
		return JSON.parse(val);
	}
	setCurrentReferences(threadID, references) {
		const key = this.COPILOT_CURRENT_REFERENCES_KEY(threadID);
		const uniqueReferences = references.filter((ref, index) => {
			return index === references.findIndex((r) => referenceID(ref) === referenceID(r));
		});
		this.localStorage.setItem(key, JSON.stringify(uniqueReferences));
	}
	clearCurrentReferences(threadID) {
		const key = this.COPILOT_CURRENT_REFERENCES_KEY(threadID);
		this.localStorage.removeItem(key);
	}
	migrateNullThreadToNewThread(newThreadID, source) {
		const savedMessage = this.getSavedMessage(null, source);
		this.setSavedMessageFast(null, source, null);
		if (savedMessage) this.setSavedMessageFast(newThreadID, source, savedMessage);
		const savedRefs = this.getCurrentReferences(null);
		this.clearCurrentReferences(null);
		if (savedRefs) this.setCurrentReferences(newThreadID, savedRefs);
		const nullThreadSettings = this.settings;
		if (nullThreadSettings) this.localStorage.setItem(this.COPILOT_SETTINGS_STORAGE_KEY(newThreadID), JSON.stringify(nullThreadSettings));
		this.selectedThreadID = newThreadID;
		this.localStorage.removeItem(this.COPILOT_SETTINGS_STORAGE_KEY(null));
	}
	getImmersiveSidebarCollapsedState() {
		const item = this.localStorage.getItem(this.COPILOT_IMMERSIVE_SIDEBAR_COLLAPSED_STATE_KEY);
		return item === null || item === "true";
	}
	setImmersiveSidebarCollapsedState(state) {
		this.localStorage.setItem(this.COPILOT_IMMERSIVE_SIDEBAR_COLLAPSED_STATE_KEY, String(state));
	}
	getCopilotDiffReferences() {
		const val = this.localStorage.getItem(this.COPILOT_DIFF_REFERENCES_KEY);
		if (!val) return null;
		return JSON.parse(val);
	}
	setCopilotDiffReferences(fileDiffReferences) {
		const referencesArray = Array.isArray(fileDiffReferences) ? fileDiffReferences : [fileDiffReferences];
		this.localStorage.setItem(this.COPILOT_DIFF_REFERENCES_KEY, JSON.stringify(referencesArray));
	}
	removeCopilotDiffReferences() {
		this.localStorage.removeItem(this.COPILOT_DIFF_REFERENCES_KEY);
	}
	clearAuthToken() {
		this.localStorage.removeItem(COPILOT_AUTH_TOKEN_KEY);
	}
	getMeterBannerFlag() {
		const value = this.localStorage.getItem(this.COPILOT_METER_BANNER_FLAG);
		if (value === null) return null;
		return value === "true";
	}
	setMeterBannerFlag(state) {
		this.localStorage.setItem(this.COPILOT_METER_BANNER_FLAG, String(state));
	}
	removeMeterBannerFlag() {
		this.localStorage.removeItem(this.COPILOT_METER_BANNER_FLAG);
	}
	getQuotaExceededBannerFlag() {
		const value = this.tempStorage.getItem(this.COPILOT_QUOTA_EXCEEDED_BANNER_FLAG);
		if (value === null) return null;
		return value === "true";
	}
	setQuotaExceededBannerFlag(state) {
		this.tempStorage.setItem(this.COPILOT_QUOTA_EXCEEDED_BANNER_FLAG, String(state));
	}
	removeQuotaExceededBannerFlag() {
		this.tempStorage.removeItem(this.COPILOT_QUOTA_EXCEEDED_BANNER_FLAG);
	}
	/**
	* Get the dismissed state for the Copilot Coding Agent quota banner.
	* Uses reset date in key so it auto-expires when a new billing cycle starts.
	*/
	getCodingAgentQuotaBannerDismissed(resetDate) {
		if (!resetDate) return false;
		const key = `${this.COPILOT_CODING_AGENT_QUOTA_BANNER_DISMISSED_PREFIX}${resetDate}`;
		return this.localStorage.getItem(key) === "true";
	}
	/**
	* Set the dismissed state for the Copilot Coding Agent quota banner.
	* Uses reset date in key so it auto-expires when a new billing cycle starts.
	*/
	setCodingAgentQuotaBannerDismissed(resetDate) {
		if (!resetDate) return;
		const key = `${this.COPILOT_CODING_AGENT_QUOTA_BANNER_DISMISSED_PREFIX}${resetDate}`;
		this.localStorage.setItem(key, "true");
	}
	getSkuSuccessBannerFlag(skuType) {
		return this.getBooleanFlag(this.skuSuccessBannerKey(skuType));
	}
	setSkuSuccessBannerFlag(skuType, state) {
		this.tempStorage.setItem(this.skuSuccessBannerKey(skuType), String(state));
	}
	removeSkuSuccessBannerFlag(skuType) {
		this.tempStorage.removeItem(this.skuSuccessBannerKey(skuType));
	}
	getAnimationFlag() {
		return this.getBooleanFlag(this.COPILOT_ANIMATION_FLAG);
	}
	setAnimationFlag(state) {
		this.tempStorage.setItem(this.COPILOT_ANIMATION_FLAG, String(state));
	}
	removeAnimationFlag() {
		this.tempStorage.removeItem(this.COPILOT_ANIMATION_FLAG);
	}
	getTracingRequestedFlag() {
		return this.localStorage.getItem(this.COPILOT_TRACING_REQUESTED_FLAG) === "true";
	}
	setTracingRequestedFlag(state) {
		this.localStorage.setItem(this.COPILOT_TRACING_REQUESTED_FLAG, String(state));
	}
	getWrapCodeLines() {
		return this.localStorage.getItem(this.COPILOT_WRAP_CODE_LINES_KEY) === "true";
	}
	setWrapCodeLines(state) {
		this.localStorage.setItem(this.COPILOT_WRAP_CODE_LINES_KEY, String(state));
	}
	getBooleanFlag(key, storage = this.tempStorage) {
		const value = storage.getItem(key);
		if (value === null) return null;
		return value === "true";
	}
	getSpacesMcpBannerDismissalCount() {
		const val = this.localStorage.getItem(this.COPILOT_SPACES_MCP_BANNER_DISMISSAL_COUNT);
		return val ? parseInt(val, 10) : 0;
	}
	setSpacesMcpBannerDismissalCount(count) {
		const key = this.COPILOT_SPACES_MCP_BANNER_DISMISSAL_COUNT;
		this.localStorage.setItem(key, count.toString());
	}
	getSpacesSourcesTipDismissalCount() {
		const val = this.localStorage.getItem(this.COPILOT_SPACES_SOURCES_TIP_DISMISSAL_COUNT);
		return val ? parseInt(val, 10) : 0;
	}
	setSpacesSourcesTipDismissalCount(count) {
		const key = this.COPILOT_SPACES_SOURCES_TIP_DISMISSAL_COUNT;
		this.localStorage.setItem(key, count.toString());
	}
	getAgentCapabilitiesTooltipDismissed() {
		return this.longStorage.getItem(this.COPILOT_AGENT_CAPABILITIES_TOOLTIP_DISMISSED) === "true";
	}
	setAgentCapabilitiesTooltipDismissed() {
		this.longStorage.setItem(this.COPILOT_AGENT_CAPABILITIES_TOOLTIP_DISMISSED, "true");
	}
	getSpacesSelectedTab() {
		return this.localStorage.getItem(this.COPILOT_SPACES_SELECTED_TAB) || "personal";
	}
	setSpacesSelectedTab(tab) {
		const key = this.COPILOT_SPACES_SELECTED_TAB;
		this.localStorage.setItem(key, tab);
	}
	getLastSelectedSpace() {
		const val = this.localStorage.getItem(this.COPILOT_SPACES_SELECTION_MENU_LAST_SELECTED_SPACE);
		if (!val) return void 0;
		try {
			return JSON.parse(val);
		} catch {
			return;
		}
	}
	setLastSelectedSpace(space) {
		const key = this.COPILOT_SPACES_SELECTION_MENU_LAST_SELECTED_SPACE;
		if (space === void 0) {
			this.localStorage.removeItem(key);
			return;
		}
		this.localStorage.setItem(key, JSON.stringify(space));
	}
	getActiveMode() {
		return this.longStorage.getItem(this.COPILOT_ACTIVE_MODE_KEY);
	}
	setActiveMode(modeName) {
		this.longStorage.setItem(this.COPILOT_ACTIVE_MODE_KEY, modeName);
	}
	getLandedOnAgentsView() {
		return this.sessionStorage.getItem(this.COPILOT_LANDED_ON_AGENTS_VIEW_KEY) === "true";
	}
	setLandedOnAgentsView(state) {
		this.sessionStorage.setItem(this.COPILOT_LANDED_ON_AGENTS_VIEW_KEY, String(state));
	}
	skuSuccessBannerKey(skuType) {
		return `COPILOT_${skuType.toUpperCase()}_SUCCESS_BANNER_FLAG`;
	}
	/**
	* @returns an array of objects with messageID and requestID
	* @description This function retrieves the message request IDs from local storage and validates them.
	* It ensures that the data is in the expected format and filters out any invalid entries.
	*/
	retrieveAndValidateRequestIDs() {
		const currentIDs = this.localStorage.getItem(this.COPILOT_MESSAGE_REQUEST_ID_KEY);
		try {
			const parsedValues = JSON.parse(currentIDs || "[]");
			if (!Array.isArray(parsedValues) || parsedValues.length === 0) return [];
			return parsedValues.filter((item) => {
				return typeof item.messageID === "string" && typeof item.requestID === "string";
			});
		} catch {
			return [];
		}
	}
	/**
	* Adds a requestID keyed on messageID to localstorage.
	* The tuple of (requestID, messageID) is stored in localstorage.
	* If the messageID already exists, it will be replaced with the new requestID.
	* If the number of stored requestIDs exceeds the maximum limit, the oldest one will be removed.
	* @param messageID messageID
	* @param requestID requestID -- Assigned by the server to each request
	*/
	addRequestID(messageID, requestID) {
		const currentIDs = this.retrieveAndValidateRequestIDs();
		const existingIndex = currentIDs.findIndex((item) => item.messageID === messageID);
		if (existingIndex !== -1) currentIDs.splice(existingIndex, 1);
		currentIDs.push({
			messageID,
			requestID
		});
		if (currentIDs.length > this.MAX_MESSAGE_REQUEST_ID_STORAGE_COUNT) currentIDs.shift();
		this.localStorage.setItem(this.COPILOT_MESSAGE_REQUEST_ID_KEY, JSON.stringify(currentIDs));
	}
	/**
	* Retrieved the requestID for a given messageID if it exists
	* @param messageID messageID for which you want to get the requestID
	* @returns requestID or undefined
	*/
	getRequestID(messageID) {
		const foundID = this.retrieveAndValidateRequestIDs().find((item) => item.messageID === messageID);
		return foundID ? foundID.requestID : void 0;
	}
};
__decorate([debounce(100)], CopilotLocalStorage.prototype, "setSavedMessage", null);
var copilotLocalStorage = new CopilotLocalStorage();
export { copilotLocalStorage as t };
