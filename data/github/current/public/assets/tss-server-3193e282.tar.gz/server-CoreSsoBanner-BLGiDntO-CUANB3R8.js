import { kr as ShieldLockIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var CoreSsoBanner_module_default = { banner: "CoreSsoBanner-module_FzDBZa_banner" };
function Description({ ssoOrgs }) {
	if (ssoOrgs.length === 0) return /* @__PURE__ */ jsx(Fragment, { children: "Single sign-on to see results" });
	const displayOrgs = ssoOrgs.slice(0, 3);
	const remainingCount = ssoOrgs.length - 3;
	const organizationText = ssoOrgs.length === 1 ? "organization" : "organizations";
	const formatOrgList = () => {
		const formattedOrgNames = displayOrgs.map((org) => /* @__PURE__ */ jsx("strong", { children: org.name }, org.login));
		if (formattedOrgNames.length === 1) return formattedOrgNames[0];
		else if (formattedOrgNames.length === 2) return /* @__PURE__ */ jsxs(Fragment, { children: [
			formattedOrgNames[0],
			" and ",
			formattedOrgNames[1]
		] });
		else {
			const lastIndex = formattedOrgNames.length - 1;
			const baseList = /* @__PURE__ */ jsxs(Fragment, { children: [
				formattedOrgNames[0],
				", ",
				formattedOrgNames[1],
				", and ",
				formattedOrgNames[lastIndex]
			] });
			return remainingCount > 0 ? /* @__PURE__ */ jsxs(Fragment, { children: [
				baseList,
				", and ",
				remainingCount,
				" more"
			] }) : baseList;
		}
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		"Single sign-on to see results in the ",
		formatOrgList(),
		" ",
		organizationText
	] });
}
/**
* Bare minimum UI to display a non-interactive SSO banner, shared between suspense fallback and main component.
* The goal here is to look almost identical to the fully rendered banner while requiring as few bytes as possible to
* show. So this component eliminates all dependencies and interactivity, restricting code to just the top-level
* visible UI.
*/
Description.displayName = "Description";
function CoreSsoBanner({ ssoOrgs, onDismiss, primaryAction }) {
	return /* @__PURE__ */ jsx(Banner, {
		title: "Single sign-on",
		className: CoreSsoBanner_module_default.banner,
		hideTitle: true,
		icon: /* @__PURE__ */ jsx(ShieldLockIcon, {}),
		description: /* @__PURE__ */ jsx(Description, { ssoOrgs }),
		onDismiss,
		primaryAction,
		"data-testid": "global-sso-banner"
	});
}
CoreSsoBanner.displayName = "CoreSsoBanner";
export { CoreSsoBanner as t };
