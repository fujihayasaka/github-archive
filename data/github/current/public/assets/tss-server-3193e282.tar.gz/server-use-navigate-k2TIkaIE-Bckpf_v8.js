import { useCallback } from "react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { c } from "react/compiler-runtime";
var PREVENT_AUTOFOCUS_KEY = "__gh__react-core-preventAutofocus";
/**
* Check if a path is external to the app (not defined in our route tree).
* Returns true if the path should be handled by a full page reload,
* false if it can be handled by TanStack Router client-side navigation.
*/
function isExternalToApp(router, path) {
	try {
		const cleanPath = path.split("?")[0]?.split("#")[0];
		if (!cleanPath) return true;
		const matches = router.matchRoutes(cleanPath, {});
		if (!matches || matches.length === 0) return true;
		const normalizedCleanPath = cleanPath.length > 1 ? cleanPath.replace(/\/$/, "") : cleanPath;
		return !matches.some((match) => {
			const routeId = match.routeId;
			const normalizedMatchPath = match.pathname.length > 1 ? match.pathname.replace(/\/$/, "") : match.pathname;
			return routeId !== "__root__" && normalizedMatchPath === normalizedCleanPath;
		});
	} catch {
		return true;
	}
}
/**
* Translates React Router navigation calls to TanStack Router format.
*
* Forwarded compatible options:
* - replace: replace history instead of push.
* - state: stored in location state.
* - viewTransition: document view transitions.
* - reloadDocument: forwarded & force-set to true for routes detected as external to this app.
* Mapped options:
* - preventScrollReset: mapped to TanStack `resetScroll` (inverted value).
* - relative: mapped to TanStack `unsafeRelative` when set to 'path'.
* - preventAutofocus: mapped to a location state flag used by focus management.
* Ignored options:
* - preventTurbo: TanStack routing is not integrated with Turbo.
* - flushSync: accepted for parity but currently a noop in this adapter.
*/
var useNavigate$1 = () => {
	const $ = c(6);
	const navigate = useNavigate();
	const router = useRouter();
	let t0;
	if ($[0] !== router) {
		t0 = (path) => router ? isExternalToApp(router, path) : true;
		$[0] = router;
		$[1] = t0;
	} else t0 = $[1];
	const isExternalToApp$1 = t0;
	let t1;
	if ($[2] !== isExternalToApp$1 || $[3] !== navigate || $[4] !== router) {
		t1 = (to, options) => {
			let targetPath;
			if (typeof to === "string") targetPath = to;
			else if (to && typeof to === "object" && to.pathname) targetPath = to.pathname;
			const { preventScrollReset, relative, flushSync: _flushSync, preventAutofocus, preventTurbo: _preventTurbo, state, ...compatibleOptions } = options ?? {};
			const finalOptions = { ...compatibleOptions };
			if (state !== void 0) finalOptions.state = state;
			if (preventScrollReset !== void 0) finalOptions.resetScroll = !preventScrollReset;
			if (relative === "path") finalOptions.unsafeRelative = "path";
			if (preventAutofocus) finalOptions.state = {
				[PREVENT_AUTOFOCUS_KEY]: true,
				...state ?? {}
			};
			if (targetPath && isExternalToApp$1(targetPath)) finalOptions.reloadDocument = true;
			if (typeof to === "string") {
				navigate({
					to,
					...finalOptions
				});
				return;
			}
			if (to && typeof to === "object") {
				const { pathname, search, hash, ...rest } = to;
				const tsrNavigation = { ...rest };
				if (pathname) tsrNavigation.to = pathname;
				if (search !== void 0) if (typeof search === "string") tsrNavigation.search = router.options.parseSearch(search);
				else tsrNavigation.search = search;
				if (hash) tsrNavigation.hash = hash;
				navigate({
					...tsrNavigation,
					...finalOptions
				});
				return;
			}
			navigate({
				to,
				...finalOptions
			});
		};
		$[2] = isExternalToApp$1;
		$[3] = navigate;
		$[4] = router;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
};
export { isExternalToApp as n, useNavigate$1 as r, PREVENT_AUTOFOCUS_KEY as t };
