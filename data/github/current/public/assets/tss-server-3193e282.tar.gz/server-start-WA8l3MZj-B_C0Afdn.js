performance.mark("js-parse-end:server-start-WA8l3MZj-B_C0Afdn.js");
import { t as setServerLocationGetter } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { n as getEnv } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { n as getFetchNonce, t as FETCH_NONCE_HEADER } from "./server-fetch-nonce-CQRTCHX--Bxo3Ybl_.js";
import { n as isDev, t as canAccessUIRuntimeStaging } from "./server-env-CmF5Q86i-CMsKyIar.js";
import { t as serverConfig } from "./server-config-fAGtGEuQ-g7WI1iQy.js";
import { i as getParsedRequestUrl, t as getCookie } from "./server-request-C9AEnFH8-C42vJH27.js";
import { c as getDataFetchMetrics, d as issueSignedAuthToken, f as logger, g as verifySignedAuthToken, h as runWithDataFetchMetricsContext, i as StatsTimer, l as increment, m as runWithAuthContext, o as coerceToError, p as reportError, r as ServiceFetchError, s as getAuthContext, t as APP_NAME, u as isStaff } from "./server-auth-CdSUgQ-0-DHDnXnPo.js";
import { n as fetchServiceJSON, t as fetchFromService } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as getRouteIdFromPassThroughResponse } from "./server-dotcom-pass-through-LDRpZga1-DQ9ZcIX-.js";
import { a as turboShortCircuitResponse, n as jsFeatureFlags, r as serverOnlyFeatureFlags, t as isTurboShortCircuit } from "./server-turbo-Cr1W-fWB-D8daiiIn.js";
import { AsyncLocalStorage } from "node:async_hooks";
import { SpanStatusCode, trace } from "@opentelemetry/api";
var createMiddleware = (options, __opts) => {
	const resolvedOptions = {
		type: "request",
		...__opts || options
	};
	return {
		options: resolvedOptions,
		middleware: (middleware) => {
			return createMiddleware({}, Object.assign(resolvedOptions, { middleware }));
		},
		inputValidator: (inputValidator) => {
			return createMiddleware({}, Object.assign(resolvedOptions, { inputValidator }));
		},
		client: (client) => {
			return createMiddleware({}, Object.assign(resolvedOptions, { client }));
		},
		server: (server) => {
			return createMiddleware({}, Object.assign(resolvedOptions, { server }));
		}
	};
};
function dedupeSerializationAdapters(deduped, serializationAdapters) {
	for (let i = 0, len = serializationAdapters.length; i < len; i++) {
		const current = serializationAdapters[i];
		if (!deduped.has(current)) {
			deduped.add(current);
			if (current.extends) dedupeSerializationAdapters(deduped, current.extends);
		}
	}
}
var createStart = (getOptions) => {
	return {
		getOptions: async () => {
			const options = await getOptions();
			if (options.serializationAdapters) {
				const deduped = /* @__PURE__ */ new Set();
				dedupeSerializationAdapters(deduped, options.serializationAdapters);
				options.serializationAdapters = Array.from(deduped);
			}
			return options;
		},
		createMiddleware
	};
};
performance.mark("js-parse-end:start-WA8l3MZj.js");
/**
* Returns true if the thrown value is a TanStack redirect or a Response used
* for control flow (e.g., dotcomPassThrough). These are not real errors and must not be logged.
*/
function isControlFlowResponse(value) {
	if (value instanceof Response) return true;
	if (typeof value === "object" && value !== null && "isRedirect" in value) return true;
	return false;
}
function getStatusClass(status) {
	if (status >= 500) return "5xx";
	if (status >= 400) return "4xx";
	if (status >= 300) return "3xx";
	if (status >= 200) return "2xx";
	return "1xx";
}
/**
* Central error handler middleware for the TSS server request pipeline.
*/
var errorHandlerMiddleware = createMiddleware({ type: "request" }).server(async ({ next, request }) => {
	const pathname = new URL(request.url).pathname;
	const method = request.method;
	try {
		const result = await next();
		const status = (result instanceof Response ? result : result.response).status;
		increment("http.requests", 1, {
			status_code: String(status),
			status_class: getStatusClass(status),
			method
		});
		if (status >= 500) logger.error({
			event: "tss_server_error_response",
			status,
			method,
			pathname,
			error_category: "response_5xx"
		}, `[tss-server] 5xx response: ${status} for ${method} ${pathname}`);
		return result;
	} catch (error) {
		if (isControlFlowResponse(error)) throw error;
		increment("http.requests", 1, {
			status_code: "500",
			status_class: "5xx",
			method
		});
		const coerced = coerceToError(error);
		logger.error({
			event: "tss_server_unhandled_error",
			method,
			pathname,
			error_name: coerced.name,
			error_message: coerced.message,
			error_stack: coerced.stack,
			...coerced instanceof ServiceFetchError ? {
				upstream_status: coerced.status,
				upstream_service: coerced.service
			} : {}
		}, `[tss-server] Unhandled error: ${coerced.message} for ${method} ${pathname}`);
		throw error;
	}
});
function formatServerTimingHeader(metrics) {
	const entries = Object.entries(metrics);
	if (!entries.length) return void 0;
	return entries.map(([metric, duration]) => `${metric};dur=${duration.toFixed(2)}`).join(",");
}
var serverTimingMiddleware = createMiddleware({ type: "request" }).server(async ({ next }) => {
	return runWithDataFetchMetricsContext(async () => {
		const startTime = performance.now();
		const result = await next();
		const totalDuration = performance.now() - startTime;
		const { response } = result;
		const headerValue = formatServerTimingHeader({
			...getDataFetchMetrics(),
			"server.total": totalDuration
		});
		if (!headerValue) return result;
		const existing = response.headers.get("Server-Timing");
		response.headers.set("Server-Timing", existing ? `${existing},${headerValue}` : headerValue);
		return result;
	});
});
var targetHeaderMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const fetchNonce = getFetchNonce();
	return next({ headers: {
		"X-GitHub-Target": "ui",
		...fetchNonce ? { [FETCH_NONCE_HEADER]: fetchNonce } : {}
	} });
});
var tracer = trace.getTracer(APP_NAME);
var tracingMiddleware = createMiddleware().server(async ({ next, request }) => {
	const url = new URL(request.url);
	return tracer.startActiveSpan(`${request.method} ${url.pathname}`, async (span) => {
		span.setAttributes({
			"http.method": request.method,
			"http.url": request.url,
			"http.route": url.pathname
		});
		try {
			const response = await next();
			span.setAttribute("http.status_code", response.response.status);
			return response;
		} catch (error) {
			if (error instanceof Error) {
				span.recordException(error);
				span.setStatus({
					code: SpanStatusCode.ERROR,
					message: error.message
				});
			} else {
				const message = String(error);
				span.recordException(message);
				span.setStatus({
					code: SpanStatusCode.ERROR,
					message
				});
			}
			throw error;
		} finally {
			span.end();
		}
	});
});
/**
* Check if feature flag overrides are allowed for the current request.
* Overrides are allowed in development mode OR for staff users (staffonly cookie present).
*
* Must be called within a request context.
*/
function areOverridesAllowed() {
	if (isDev()) return true;
	try {
		return isStaff();
	} catch {
		return false;
	}
}
/**
* Get the _features query parameter value from the current request.
* Returns null if overrides are not allowed, if not present, if empty/whitespace-only,
* or if request context is unavailable.
*
* Must be called within a request context.
*/
function getFeaturesQueryFromRequest() {
	if (!areOverridesAllowed()) return null;
	try {
		const value = getParsedRequestUrl().searchParams.get("_features");
		if (value === null || value.trim() === "") return null;
		return value.trim();
	} catch {
		return null;
	}
}
/**
* Get the _features cookie value from the current request.
* Returns null if overrides are not allowed, if not present, if empty/whitespace-only,
* or if request context is unavailable.
*
* Must be called within a request context.
*/
function getFeaturesCookieFromRequest() {
	if (!areOverridesAllowed()) return null;
	try {
		const value = getCookie("_features");
		if (value === null || value.trim() === "") return null;
		return value.trim();
	} catch {
		return null;
	}
}
/**
* Actor ID factory functions for creating type-safe actor IDs.
*/
var Actor = {
	user: (id) => `User:${id}`,
	org: (id) => `Organization:${id}`
};
/**
* Fetches the list of enabled feature flags for the given flags and actor IDs.
*
* This function will automatically include the current user's actor ID from the request
* context when available. Additional actor IDs can be provided to evaluate flags for
* organizations, teams, or other entities.
*
* @param flags - The list of flag names to check.
* @param actorIds - Optional list of additional actor IDs to evaluate flags against.
*                   The current user actor is automatically included when available.
* @returns An array of flag names that are enabled.
*
* @example
* ```ts
* // Current user actor will be auto-included when available
* const enabledFlags = await getEnabledFlags(['my_feature'])
*
* // With additional actors
* const enabledFlags = await getEnabledFlags(
*   ['my_feature', 'another_feature'],
*   [Actor.user(12345), Actor.org(67890)],
* )
* ```
*/
/**
* Build the list of actor IDs for a feature flag request.
* Combines the auto-detected current user actor with any explicitly provided actors.
*/
function buildActorIds(actorIds) {
	const actors = [];
	try {
		const actorId = getAuthContext()?.actorId;
		if (actorId) actors.push(Actor.user(actorId));
	} catch {}
	actors.push(...actorIds ?? []);
	return actors;
}
/**
* A pattern is considered a wildcard if it contains a "*" character.
*/
var WILDCARD_CHARS = /\*/;
/**
* Parse a comma-separated feature overrides string into an ordered list of tokens.
* Supports optional negation using "!" prefix and "*" wildcard patterns.
* Pure function with no request dependency.
*
* Wildcard patterns:
* - "*" matches all flags
* - "prefix_*" matches all flags starting with "prefix_"
*
* Examples:
* - "flag_a,flag_b" -> [{flag: "flag_a", enabled: true, isWildcard: false}, ...]
* - "!flag_a" -> [{flag: "flag_a", enabled: false, isWildcard: false}]
* - "flag_a,!flag_b" -> [{flag: "flag_a", enabled: true, isWildcard: false}, {flag: "flag_b", enabled: false, isWildcard: false}]
* - "*" -> [{flag: "*", enabled: true, isWildcard: true}]
* - "prefix_*" -> [{flag: "prefix_*", enabled: true, isWildcard: true}]
*
* @param value - Comma-separated feature overrides string
* @returns Ordered list of override tokens
*/
function parseFeaturesOverridesString(value) {
	const overrides = [];
	const features = value.split(",").map((f) => f.trim()).filter(Boolean);
	for (const feature of features) {
		const negated = feature.startsWith("!");
		const name = negated ? feature.slice(1).trim() : feature;
		if (!name) continue;
		overrides.push({
			flag: name,
			enabled: !negated,
			isWildcard: WILDCARD_CHARS.test(name)
		});
	}
	return overrides;
}
/**
* Collect all feature flag override tokens from the current request.
* Reads from both the _features cookie and _features query parameter.
* Query parameter overrides are applied after cookie overrides,
* so the last occurrence wins, matching dotcom's Overrider behavior.
*
* @returns Ordered list of override tokens to apply sequentially
*/
function getFeatureOverrides() {
	const cookieValue = getFeaturesCookieFromRequest();
	const queryValue = getFeaturesQueryFromRequest();
	const overrides = [];
	if (cookieValue) overrides.push(...parseFeaturesOverridesString(cookieValue));
	if (queryValue) overrides.push(...parseFeaturesOverridesString(queryValue));
	return overrides;
}
/**
* Convert a wildcard pattern (with * only) to a RegExp.
* "*" matches any sequence of characters.
* All other characters are treated as literals.
*/
var WILDCARD_CACHE_MAX_SIZE = 1e3;
var wildcardRegExpCache = /* @__PURE__ */ new Map();
function wildcardToRegExp(pattern) {
	const cached = wildcardRegExpCache.get(pattern);
	if (cached) return cached;
	const regexStr = pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\\\*/g, ".*");
	const re = new RegExp(`^${regexStr}$`);
	if (wildcardRegExpCache.size >= WILDCARD_CACHE_MAX_SIZE) {
		const firstKey = wildcardRegExpCache.keys().next().value;
		if (firstKey !== void 0) wildcardRegExpCache.delete(firstKey);
	}
	wildcardRegExpCache.set(pattern, re);
	return re;
}
/**
* Apply feature flag overrides from _features query parameter and/or cookie.
* Wildcard overrides are applied first, then exact overrides are applied on top.
* For any given flag, an exact override always takes precedence over any matching
* wildcard overrides, regardless of the order in which the overrides were specified.
*
* Precedence model:
* 1. Apply all wildcard overrides (in their specified order) across all known flags.
* 2. Apply all exact overrides (in their specified order); these always win over
*    any wildcard-derived state for the same flag.
*
* Only flags in the knownFlags list can be affected by overrides.
*
* @param baseFlags - The base list of enabled flags (e.g., from sidecar)
* @param knownFlags - The full list of flag names that were requested
* @returns The modified list with overrides applied
*/
function applyFeatureOverrides(baseFlags, knownFlags) {
	const overrides = getFeatureOverrides();
	if (overrides.length === 0) return baseFlags;
	const knownSet = new Set(knownFlags);
	const wildcardOverrides = overrides.filter((o) => o.isWildcard);
	const exactOverrides = overrides.filter((o) => !o.isWildcard);
	const flagSet = new Set(baseFlags);
	for (const override of wildcardOverrides) {
		const re = wildcardToRegExp(override.flag);
		for (const flagName of knownFlags) if (re.test(flagName)) if (override.enabled) flagSet.add(flagName);
		else flagSet.delete(flagName);
	}
	for (const { flag, enabled } of exactOverrides) {
		if (!knownSet.has(flag)) continue;
		if (enabled) flagSet.add(flag);
		else flagSet.delete(flag);
	}
	return Array.from(flagSet);
}
async function getEnabledFlags(flags, actorIds) {
	try {
		const allActorIds = buildActorIds(actorIds);
		return applyFeatureOverrides((await fetchServiceJSON({
			service: "feature-flags",
			path: "/api/v1/featureflags/batch-check",
			metricTag: "getEnabledFlags",
			method: "POST",
			body: {
				featureFlags: flags,
				...allActorIds.length && { actorIds: allActorIds }
			}
		})).enabledFlags, flags);
	} catch (error) {
		reportError(error);
		throw error;
	}
}
var locationStorage = new AsyncLocalStorage();
/**
* Binds the provided URL to the current async execution context using AsyncLocalStorage
* for the duration of the given callback.
*
* This should be called from server-side request handlers or middleware so that TSS
* and other SSR utilities can reliably access the current request location, even
* across asynchronous boundaries. The URL stored here is later read via the
* `setServerLocationGetter` configured in this module.
*
* @typeParam T - The return type of the callback.
* @param url - The request URL to associate with the current async context.
* @param callback - A function to execute while the URL is set in AsyncLocalStorage.
* @returns The value returned by the callback.
*/
function setLocationAsyncLocalStorage(url, callback) {
	return locationStorage.run(url, callback);
}
setServerLocationGetter(() => {
	return locationStorage.getStore();
});
var fetchFeatureFlags = async () => {
	try {
		return await getEnabledFlags([...jsFeatureFlags, ...serverOnlyFeatureFlags]);
	} catch {
		return [];
	}
};
async function generateClientEnv() {
	return {
		locale: "en",
		featureFlags: await fetchFeatureFlags(),
		login: getAuthContext()?.userLogin,
		copilotApiOverrideUrl: void 0
	};
}
var uiContextMiddleware = createMiddleware({ type: "request" }).server(async ({ next, request }) => {
	const clientEnv = await generateClientEnv();
	const url = new URL(request.url);
	const { setClientEnvAsyncLocalStorage } = await import("./server-client-env.server-BYsPeFAn-DewWSZRv.js");
	return setLocationAsyncLocalStorage(url, () => setClientEnvAsyncLocalStorage(clientEnv, next));
});
function generateNonce() {
	return Buffer.from(crypto.getRandomValues(new Uint8Array(24))).toString("base64");
}
var getCSPDirectives = (nonce, isDevelopment, copilotApiUrl) => {
	const { assetHost, apiHost, collectHost, uploadsHost, aliveHost, githubDomain, avatarsHost, viewscreenHost, notebooksHost, cspReportUri } = serverConfig;
	const directives = {
		"default-src": ["'none'"],
		"base-uri": ["'self'"],
		"child-src": ["'self'"],
		"connect-src": [
			"'self'",
			assetHost,
			apiHost,
			collectHost,
			uploadsHost,
			aliveHost
		],
		"font-src": [
			"'self'",
			assetHost,
			"data:"
		],
		"form-action": ["'self'", githubDomain],
		"frame-ancestors": ["'none'"],
		"frame-src": [
			"'self'",
			"https://www.youtube-nocookie.com",
			viewscreenHost,
			notebooksHost
		],
		"img-src": [
			"'self'",
			assetHost,
			avatarsHost,
			uploadsHost,
			"data:",
			"blob:",
			"https:"
		],
		"manifest-src": ["'self'"],
		"media-src": [
			"'self'",
			assetHost,
			uploadsHost
		],
		"object-src": ["'none'"],
		"script-src": [
			"'self'",
			assetHost,
			`'nonce-${nonce}'`,
			"'strict-dynamic'",
			"'unsafe-inline'",
			"https:"
		],
		"script-src-elem": [
			`'nonce-${nonce}'`,
			"'unsafe-inline'",
			assetHost
		],
		"style-src": [
			"'self'",
			"'unsafe-inline'",
			assetHost
		],
		"style-src-elem": [
			"'self'",
			"'unsafe-inline'",
			assetHost
		],
		"style-src-attr": ["'unsafe-inline'"],
		"worker-src": [
			...isDevelopment ? ["'self'"] : [],
			...!isDevelopment ? [assetHost] : [],
			`${githubDomain}/assets-cdn/worker/`,
			...isDevelopment ? [`${githubDomain}/webpack/`, `${githubDomain}/vite/`] : []
		]
	};
	if (copilotApiUrl) directives["connect-src"].push(copilotApiUrl);
	if (cspReportUri) directives["report-uri"] = [cspReportUri];
	if (!isDevelopment) directives["upgrade-insecure-requests"] = [];
	return directives;
};
function buildCSPHeader(directives) {
	const parts = [];
	for (const [headerName, value] of Object.entries(directives)) parts.push([headerName, ...value].join(" "));
	return parts.join("; ");
}
var cspMiddleware = createMiddleware({ type: "request" }).server(async ({ next }) => {
	const nonce = generateNonce();
	const result = await next({ context: { nonce } });
	const copilotApiUrl = getEnv().copilotApiOverrideUrl;
	const cspHeader = buildCSPHeader(getCSPDirectives(nonce, isDev(), copilotApiUrl));
	result.response.headers.set("Content-Security-Policy", cspHeader);
	return result;
});
/**
* Middleware that sets up a per-request QueryClient context using AsyncLocalStorage.
*
* This ensures each request gets its own isolated QueryClient instance,
* preventing data leakage between concurrent requests during SSR.
*
* The QueryClient can be accessed anywhere in the request lifecycle via
* `getServerQueryClient()` from `@github-ui/query-client/server`.
*/
var queryClientMiddleware = createMiddleware({ type: "request" }).server(async ({ next, request }) => {
	const url = new URL(request.url);
	const { runWithQueryClientContext } = await import("./server-query-client.server-BgYVkGBL-DB1iqVL0.js");
	return setLocationAsyncLocalStorage(url, () => runWithQueryClientContext(() => next()));
});
var authMiddleware = createMiddleware({ type: "request" }).server(async ({ next }) => {
	return runWithAuthContext(() => next());
});
var HOP_BY_HOP_HEADERS = new Set([
	"connection",
	"keep-alive",
	"proxy-authenticate",
	"proxy-authorization",
	"te",
	"trailer",
	"transfer-encoding",
	"upgrade",
	"content-encoding",
	"content-length"
]);
var UPSTREAM_REQUEST_EXCLUDE_HEADERS = new Set([...HOP_BY_HOP_HEADERS, "host"]);
function getConnectionExtras(source) {
	const connectionExtras = /* @__PURE__ */ new Set();
	for (const [key, value] of source) if (key.toLowerCase() === "connection") for (const name of value.split(",")) connectionExtras.add(name.trim().toLowerCase());
	return connectionExtras;
}
function forwardHeaders(source) {
	const connectionExtras = getConnectionExtras(source);
	const headers = new Headers();
	for (const [key, value] of source) {
		const lower = key.toLowerCase();
		if (!HOP_BY_HOP_HEADERS.has(lower) && !connectionExtras.has(lower)) headers.append(key, value);
	}
	return headers;
}
function forwardRequestHeaders(source) {
	const connectionExtras = getConnectionExtras(source);
	const headers = {};
	for (const [key, value] of source) {
		const lower = key.toLowerCase();
		if (!UPSTREAM_REQUEST_EXCLUDE_HEADERS.has(lower) && !connectionExtras.has(lower)) headers[key] = value;
	}
	return headers;
}
/**
* Stream a response from an upstream service back to the client.
*
* UI Service acts as a reverse proxy: it fetches the page from the upstream
* service via the service mesh and streams the status code, headers, and body
* back unchanged.
*/
async function servicePassThrough(serviceName, routeId, request, options) {
	const timer = new StatsTimer("ui_routes.pass_through_time", {
		route: routeId,
		service: serviceName
	});
	try {
		const url = new URL(request.url);
		const headers = forwardRequestHeaders(request.headers);
		if (options?.additionalHeaders) Object.assign(headers, options.additionalHeaders);
		const upstreamResponse = await fetchFromService({
			service: serviceName,
			path: url.pathname + url.search,
			metricTag: "pass_through",
			method: request.method,
			redirect: "manual",
			rawBody: request.body,
			headers,
			skipAdditionalHeaders: true
		});
		const responseHeaders = forwardHeaders(upstreamResponse.headers);
		const response = new Response(upstreamResponse.body, {
			status: upstreamResponse.status,
			statusText: upstreamResponse.statusText,
			headers: responseHeaders
		});
		const status = String(upstreamResponse.status);
		timer.send({ status });
		logger.info({
			routeId,
			service: serviceName,
			responseCode: upstreamResponse.status
		}, `[service-pass-through] Successfully proxied response from ${serviceName}`);
		return response;
	} catch (err) {
		const error = err;
		timer.send({ status: "error" });
		reportError(error);
		logger.error({
			routeId,
			service: serviceName,
			error: error.message
		}, `[service-pass-through] Failed to proxy response from ${serviceName}`);
		return new Response(`Bad Gateway: UI Service could not reach ${serviceName}`, { status: 502 });
	}
}
/**
* Stream a response from Dotcom back to the client.
*
* UI Service acts as a reverse proxy: it fetches the page from Dotcom via the
* service mesh and streams the status code, headers, and body back unchanged.
*/
async function dotcomPassThrough(routeId, request) {
	return servicePassThrough("dotcom", routeId, request, { additionalHeaders: { "x-github-ui-pass-through": "true" } });
}
var TSS_SUPPORTED_METHODS = new Set(["GET", "HEAD"]);
function rejectsHtml(request) {
	const accept = request.headers.get("accept");
	if (!accept || accept.includes("*/*") || accept.includes("text/html")) return false;
	return true;
}
function isTssInternalRequest(request) {
	const { pathname } = new URL(request.url);
	return pathname.startsWith("/_serverFn") || pathname.startsWith("/_ui/_serverFn");
}
var uiRoutesMiddleware = createMiddleware({ type: "request" }).server(async ({ next, request }) => {
	if (isTssInternalRequest(request)) return next();
	if (!TSS_SUPPORTED_METHODS.has(request.method)) return dotcomPassThrough("non_get", request);
	if (rejectsHtml(request)) return dotcomPassThrough("non_html", request);
	try {
		const result = await next();
		const response = result instanceof Response ? result : result.response;
		const routeId = getRouteIdFromPassThroughResponse(response);
		if (routeId && response.status === 307) return dotcomPassThrough(routeId, request);
		if (isTurboShortCircuit(response)) return turboShortCircuitResponse();
		if (response.status === 406) return dotcomPassThrough("not_acceptable", request);
		if (response.status === 404) return dotcomPassThrough("not_found", request);
		return result;
	} catch (e) {
		reportError(e, request.url);
		if (e instanceof ServiceFetchError) return dotcomPassThrough("service_fetch_error", request);
		return new Response("Internal Server Error", { status: 500 });
	}
});
var SHA_PATTERN = /^[0-9a-f]{40}$/;
var SAT_SCOPE_PREFIX = "StaffOnlyUISha:";
var SAT_EXPIRY_SECONDS = 3600;
var enabled = canAccessUIRuntimeStaging();
function makeCookieAttributes(maxAgeSeconds) {
	return `Path=/; Max-Age=${maxAgeSeconds}; SameSite=Lax; Secure; HttpOnly; Domain=.${serverConfig.hostName}`;
}
function makeClearCookieHeader() {
	return `_ui_sha=; ${makeCookieAttributes(0)}`;
}
function makeCookieHeader(sha, token) {
	logger.info({
		event: "preview.issue_cookie",
		sha,
		token,
		domain: serverConfig.hostName
	}, "Issuing preview cookie");
	return `_ui_sha=${sha}--${token}; ${makeCookieAttributes(SAT_EXPIRY_SECONDS)}`;
}
async function clearPreviewCookie(next) {
	const result = await next();
	result.response.headers.append("set-cookie", makeClearCookieHeader());
	return result;
}
async function mintToken(sha) {
	try {
		return await issueSignedAuthToken({
			scope: `${SAT_SCOPE_PREFIX}${sha}`,
			expiresInSeconds: SAT_EXPIRY_SECONDS
		});
	} catch (err) {
		logger.warn({
			event: "preview.issue_sat_failed",
			error: err.message
		}, "Failed to issue SAT for _ui_sha");
		return;
	}
}
var previewMiddleware = createMiddleware({ type: "request" }).server(async ({ next, request }) => {
	if (!enabled) return next();
	if (!getCookie("staffonly")) return next();
	const url = new URL(request.url);
	if (url.searchParams.has("_clear_ui_sha")) return clearPreviewCookie(next);
	const uiShaParam = url.searchParams.get("_ui_sha");
	const uiShaCookie = getCookie("_ui_sha");
	if (!uiShaParam && !uiShaCookie) return next();
	let sha;
	if (uiShaParam) {
		sha = uiShaParam;
		if (!SHA_PATTERN.test(sha)) return next();
	} else {
		const [cookieSha = "", token = ""] = (uiShaCookie || "").split("--");
		if (!SHA_PATTERN.test(cookieSha) || !token) return next();
		if (!(await verifySignedAuthToken(token, `${SAT_SCOPE_PREFIX}${cookieSha}`)).valid) return clearPreviewCookie(next);
		sha = cookieSha;
	}
	const [token, response] = await Promise.all([mintToken(sha), servicePassThrough("ui-runtime-staging", "preview", request)]);
	if (token) response.headers.append("set-cookie", makeCookieHeader(sha, token));
	return response;
});
var startInstance = createStart(() => ({
	functionMiddleware: [targetHeaderMiddleware],
	requestMiddleware: [
		errorHandlerMiddleware,
		tracingMiddleware,
		serverTimingMiddleware,
		authMiddleware,
		previewMiddleware,
		uiContextMiddleware,
		uiRoutesMiddleware,
		queryClientMiddleware,
		cspMiddleware
	]
}));
export { startInstance };
