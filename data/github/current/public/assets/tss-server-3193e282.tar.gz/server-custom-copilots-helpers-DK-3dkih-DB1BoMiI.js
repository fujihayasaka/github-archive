import { g as useLocation$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { r as COPILOT_SPACES_PATH } from "./server-copilot-chat-helpers-CUNqKoZ6-DiXl11NO.js";
import { useMemo } from "react";
import { c } from "react/compiler-runtime";
var SLUG_ERROR_MESSAGE = "The name of this space is too close to another existing space. Please modify the name and try again.";
var SPACE_OWNER_PATTERN = "[a-zA-Z0-9-_]+";
var SPACE_ID_PATTERN = "[0-9]+";
/**
* Returns a path for showing an individual space.
*/
function getCopilotSpacePath(space) {
	const { id, owner } = space;
	return `${COPILOT_SPACES_PATH}/${owner}/${id}`;
}
/**
* Returns if a path matches the Copilot Spaces list path.
*/
function isCopilotSpacesListPath(path) {
	return path === COPILOT_SPACES_PATH || path === `${COPILOT_SPACES_PATH}/`;
}
/**
* Hook to keep track of whether the current path matches the Copilot Spaces list path.
*/
function useIsCopilotSpacesListPath() {
	const $ = c(2);
	const path = useLocation$1().pathname;
	let t0;
	if ($[0] !== path) {
		t0 = isCopilotSpacesListPath(path);
		$[0] = path;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
/**
* Returns true for /copilot/spaces/:owner/:id style path
* @param allowEdit If true, also matches paths ending with /edit
* @param path path to check
* @returns true if the current path matches the defined space path formats
*/
function isCopilotSpacePath(path, allowEdit = false) {
	const spaceOwnerPattern = `${COPILOT_SPACES_PATH}/${SPACE_OWNER_PATTERN}/${SPACE_ID_PATTERN}`;
	const spaceOwnerPathRegex = new RegExp(`^${spaceOwnerPattern}${allowEdit ? "(/edit)?" : ""}$`);
	const isSpacePath = path.match(spaceOwnerPathRegex);
	return Boolean(isSpacePath);
}
/**
* Hook to keep track of whether the current path matches an individual space.
* @param location the react router location for when the ssrSafeLocation is undefined.
* @param allowEdit if true, also matches paths ending with /edit
* @returns true if the current path matches the spaces list or an individual space path.
*/
function useIsCopilotSpacePath(t0) {
	const $ = c(3);
	const allowEdit = t0 === void 0 ? false : t0;
	const path = useLocation$1().pathname;
	let t1;
	if ($[0] !== allowEdit || $[1] !== path) {
		t1 = isCopilotSpacePath(path, allowEdit);
		$[0] = allowEdit;
		$[1] = path;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
/**
* Hook to keep track of whether the current path matches the Spaces list page or an individual page.
* @param location the react router location for when the ssrSafeLocation is undefined.
* @returns true if the current path matches the spaces list or an individual space path.
*/
function useIsCopilotSpacesPage() {
	const isListPage = useIsCopilotSpacesListPath();
	const isSpacePath = useIsCopilotSpacePath();
	return isListPage || isSpacePath;
}
/**
* Parses the space ID from the current URL and returns it.
* We have to rely on the URL from the browser history because the space ID in the React Router state may be stale
* since we manually push a history entry when creating a new thread and don't perform a navigation.
*/
function useRouteSpaceId() {
	const $ = c(5);
	const pathname = useLocation$1().pathname;
	let t0;
	bb0: {
		let t1;
		if ($[0] !== pathname) {
			t1 = pathname.match(new RegExp(`${COPILOT_SPACES_PATH}/(${SPACE_OWNER_PATTERN})/(${SPACE_ID_PATTERN})`));
			$[0] = pathname;
			$[1] = t1;
		} else t1 = $[1];
		const ownerMatch = t1;
		if (ownerMatch) {
			const [, owner, spaceId] = ownerMatch;
			if (owner && spaceId) {
				const id = parseInt(spaceId, 10);
				if (!isNaN(id)) {
					let t2;
					if ($[2] !== id || $[3] !== owner) {
						t2 = {
							id,
							owner
						};
						$[2] = id;
						$[3] = owner;
						$[4] = t2;
					} else t2 = $[4];
					t0 = t2;
					break bb0;
				}
			}
		}
		t0 = null;
	}
	return t0;
}
function customCopilotIdsAreEqual(a, b) {
	if (a === b) return true;
	if (a === null || b === null) return false;
	return a.id === b.id && a.owner === b.owner;
}
/**
* Checks if a custom copilot matches the provided copilot ID.
* @param customCopilot - The custom copilot to check
* @param customCopilotId - The ID to match against
* @returns True if the copilot matches the ID, false otherwise
*
* Returns true if both ID and owner match
*/
function customCopilotMatchesId(customCopilot, customCopilotId) {
	return customCopilot.id === customCopilotId.id && customCopilot.owner === customCopilotId.owner;
}
/**
* Generates the custom copilot API path using URL structure with owner/number format if an id is provided.
* If CopilotSpaceId is null it returns a path appropriate for POST requests
*/
function customCopilotApiPath(id) {
	if (!id) return COPILOT_SPACES_PATH;
	return `${COPILOT_SPACES_PATH}/${id.owner}/${id.id}`;
}
/**
* Checks if the custom copilot size percentage is greater than 100
* @param customCopilot
* @returns true if the custom copilot has exceeded the size limit
*/
function spaceSizeExceeded(customCopilot) {
	return (customCopilot?.sizePercentage ?? 0) > 100;
}
export { getCopilotSpacePath as a, useIsCopilotSpacesPage as c, customCopilotMatchesId as i, useRouteSpaceId as l, customCopilotApiPath as n, spaceSizeExceeded as o, customCopilotIdsAreEqual as r, useIsCopilotSpacePath as s, SLUG_ERROR_MESSAGE as t };
