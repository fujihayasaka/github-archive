import { i as ButtonComponent, m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ai as XCircleFillIcon, Hi as useProvidedRefOrCreate, Mi as XIcon, Nt as FilterIcon, an as IconButton, ar as PlusIcon, bn as Link, hi as TriangleDownIcon, n as ActionList, wr as SearchIcon, yi as UndoIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as useResizeObserver } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { n as useConfirm } from "./server-ConfirmationDialog-ByPSlzI8-DjTwLc-t.js";
import { t as testIdProps } from "./server-test-id-props-ZLBPsWK0-X4JMe-ts.js";
import { i as VerifiedHTMLText } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { r as UnsafeHTMLText } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { t as hasMatch } from "./server-fzy.js-7qhjn37q.js";
import { n as useClickAnalytics, t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as FeatureFlags } from "./server-FeatureFlags-C1NipJFp-82e1Xac8.js";
import { t as AvatarStack } from "./server-AvatarStack-DOkoT87C-BbROVIWO.js";
import { t as LoadingSkeleton } from "./server-LoadingSkeleton-Dd8-Bxdj-C5S_-f5d.js";
import { $ as isFilterBlock, A as checkFilterQuerySync, B as getEscapedFilterValue, D as buildRawBlockString, E as ValueOperators, G as getFlatSuggestionsList, H as getFilterBlockChunkByCaret, I as findMatchedQuotes, J as getMutableFilterBlocks, L as getAllFilterOperators, N as defaultFilterSettings, O as capitalize, R as getBlockKey, U as getFilterValue, X as getUnescapedFilterValue, Z as getUniqueReactKey, _ as RawTextProvider, b as Strings, c as FilterProviderType, d as FilterValueType, et as isIndexedFilterBlock, g as ProviderSupportStatus, it as promiseTimeout, j as defaultFilterConfig, l as FilterQuery, n as BlockType, nt as isMutableFilterBlock, o as FilterOperator, q as getLastFilterBlockValue, r as DYNAMIC_VALUE_CHARS, rt as isNestedFilterProvider, s as FilterOperators, tt as isIndexedGroupBlock, u as FilterQueryParser, x as SubmitEvent, z as getDefaultValueVisualDescriptors } from "./server-parser-B_jVbaDq-DE0xr9zk.js";
import { t as AnalyticsProvider } from "./server-AnalyticsProvider-D0POAVQk-B5tW16h5.js";
import { J as ValuePresenceFilterProvider, m as HasFilterProvider } from "./server-providers-w0hxsmcG-B_8wxADa.js";
import { createContext, memo, use, useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useMemo, useReducer, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { getAnchoredPosition } from "@primer/behaviors";
import memoize from "lodash-es/memoize.js";
var NoFilterProviderV2 = class extends ValuePresenceFilterProvider {
	constructor(filterValues, options) {
		super(filterValues, FilterValueType.NoValue, options);
	}
};
var SCREEN_READER_FEEDBACK_TIMEOUT_MS = 150;
var screenReaderTimeout;
var updateScreenReaderFeedback = (message = "", assertive = true) => {
	if (screenReaderTimeout) clearTimeout(screenReaderTimeout);
	screenReaderTimeout = setTimeout(() => {
		announce$1(message, { assertive });
	}, SCREEN_READER_FEEDBACK_TIMEOUT_MS);
};
var lastDelimiterRegex = /:|,|\s(?=(?:[^"]*"[^"]*")*[^"]*$)/g;
/**
* Calculates the top and left values for an absolutely-positioned floating element
* to be anchored to some anchor element. Returns refs for the floating element
* and the anchor element, along with the position.
* @param settings Settings for calculating the anchored position.
* @param dependencies Dependencies to determine when to re-calculate the position.
* @returns An object of {top: number, left: number} to absolutely-position the
* floating element.
*/
function useDelimiterAnchorPosition(settings, dependencies = []) {
	const floatingElementRef = useProvidedRefOrCreate(settings?.floatingElementRef);
	const caretElementRef = useProvidedRefOrCreate(settings?.caretElementRef);
	const inputElementRef = useProvidedRefOrCreate(settings?.inputElementRef);
	const [position, setPosition] = useState(void 0);
	const closestDelimiter = () => {
		const inputElement = inputElementRef.current;
		if (!inputElement) return null;
		const delimiters = Array.from(inputElement.closest(".styled-input-container")?.querySelectorAll(".delimiter") ?? []);
		const filter = inputElement.value;
		if (!filter || !inputElement.selectionStart) return null;
		const matches = [...filter.slice(0, inputElement.selectionStart).matchAll(lastDelimiterRegex)];
		if (matches.length < 1) return inputElement;
		let match;
		for (let i = matches.length ?? 0; i > 0; i--) {
			const delimiter = delimiters?.[i - 1];
			if (delimiter && !delimiter?.classList.contains("text-delimiter")) {
				match = delimiter;
				break;
			}
		}
		return match ?? inputElement;
	};
	const updatePosition = useCallback(() => {
		const delimiter = closestDelimiter() ?? inputElementRef.current;
		if (floatingElementRef.current instanceof Element && delimiter instanceof Element) setPosition(getAnchoredPosition(floatingElementRef.current, delimiter, settings));
		else setPosition(void 0);
	}, [
		floatingElementRef,
		caretElementRef,
		...dependencies
	]);
	useLayoutEffect(updatePosition, [updatePosition]);
	useResizeObserver(updatePosition);
	return {
		floatingElementRef,
		caretElementRef,
		position,
		updatePosition
	};
}
var SuggestionsContext = createContext(void 0);
SuggestionsContext.displayName = "SuggestionsContext";
var useSuggestions = () => {
	const context = use(SuggestionsContext);
	if (!context) throw new Error("useSuggestions must be used inside a SuggestionsContext");
	return context;
};
function excludeUsedSuggestions(suggestionGroup, activeFilterBlock) {
	let suggestions = [];
	if (activeFilterBlock) suggestions = suggestionGroup.suggestions?.filter((suggestion) => activeFilterBlock.value.values.findIndex((value) => getUnescapedFilterValue(value.value) === suggestion.value && !value.hasCaret) < 0).sort((a, b) => a.priority - b.priority) ?? [];
	return {
		...suggestionGroup,
		suggestions
	};
}
var SuggestionsContextProvider = ({ children, caretRef, inputRef }) => {
	const { config, inputContextRef } = useFilter();
	const { filterQuery, filterProviders, insertIntoQuery, rawFilterRef, replaceActiveBlockWithPresenceBlock, updateFilter, updateFromExternal } = useFilterQuery();
	const activeSuggestionRef = useRef(null);
	const suggestionsListRef = useRef(null);
	const { position, updatePosition } = useDelimiterAnchorPosition({
		caretElementRef: caretRef,
		floatingElementRef: suggestionsListRef,
		inputElementRef: inputRef,
		side: "outside-bottom",
		align: "start",
		alignmentOffset: -16,
		allowOutOfBounds: false
	}, [suggestionsListRef, inputContextRef]);
	const [isFetchingSuggestions, setIsFetchingSuggestions] = useState(false);
	const [suggestionsVisible, setSuggestionsVisible] = useState(false);
	const [suggestionGroups, setSuggestionGroups] = useState([]);
	const [activeSuggestion, setActiveSuggestion] = useState(-1);
	const showSuggestions = useCallback(() => {
		if (suggestionsVisible) return;
		setSuggestionsVisible(true);
	}, [suggestionsVisible]);
	const hideSuggestions = useCallback(() => {
		setSuggestionsVisible(false);
		setActiveSuggestion(-1);
	}, []);
	const debounceScreenReaderFeedback = debounce(updateScreenReaderFeedback, 500, { start: false });
	const updateSuggestions = useCallback(async (filter, caret) => {
		let internalShouldShowSuggestions = true;
		if (config.variant === "button") return;
		if (inputContextRef.current?.isComposing) return;
		setSuggestionGroups([]);
		updatePosition();
		const query = filter ?? filterQuery;
		const caretIndex = caret ?? inputRef.current?.selectionStart ?? -1;
		let cachedSuggestionGroup = {
			id: "cached-suggestions",
			suggestions: []
		};
		let cachedWithoutUsedSuggestionGroup = cachedSuggestionGroup;
		let aggregatedSuggestionGroups = [];
		const activeBlock = query.activeBlock;
		const activeFilterBlock = activeBlock && isIndexedFilterBlock(activeBlock) ? activeBlock : void 0;
		const queryValue = activeBlock ? getLastFilterBlockValue(activeBlock, caretIndex) : "";
		const isCompleteResultSetQueryOrTextBlockOrOtherTypeOfNonSpecificBlock = queryValue && activeFilterBlock && activeFilterBlock.provider?.isCompleteResultSetQuery?.(queryValue);
		if (activeFilterBlock) {
			const [type] = getFilterBlockChunkByCaret(activeFilterBlock, caretIndex);
			if (type === "value" && queryValue) {
				cachedSuggestionGroup = {
					id: "cached-suggestions",
					suggestions: activeFilterBlock.provider?.findPrefetchedSuggestions?.(queryValue) ?? []
				};
				cachedWithoutUsedSuggestionGroup = excludeUsedSuggestions(cachedSuggestionGroup, activeFilterBlock);
				if (cachedWithoutUsedSuggestionGroup && cachedWithoutUsedSuggestionGroup.suggestions.length > 0) {
					showSuggestions();
					debounceScreenReaderFeedback(`${cachedWithoutUsedSuggestionGroup.suggestions.length} ${cachedWithoutUsedSuggestionGroup.suggestions.length === 1 ? "suggestion" : "suggestions"}`);
					setSuggestionGroups([cachedWithoutUsedSuggestionGroup]);
				}
			}
		}
		if (cachedWithoutUsedSuggestionGroup.suggestions.length < 25 && !isCompleteResultSetQueryOrTextBlockOrOtherTypeOfNonSpecificBlock) {
			if (activeFilterBlock && activeFilterBlock.provider?.isCompleteResultSetQuery?.(queryValue) !== void 0) setIsFetchingSuggestions(true);
			aggregatedSuggestionGroups = await query.getSuggestions(caretIndex, filterProviders, config);
			aggregatedSuggestionGroups[0]?.suggestions.unshift(...cachedSuggestionGroup.suggestions);
			const seen = /* @__PURE__ */ new Set();
			if (aggregatedSuggestionGroups[0]) aggregatedSuggestionGroups[0].suggestions = aggregatedSuggestionGroups[0]?.suggestions.filter((suggestion) => {
				const key = getFilterValue(suggestion.value) ?? "";
				return seen.has(key) ? false : seen.add(key);
			});
			if (aggregatedSuggestionGroups[0] && activeBlock?.type === BlockType.Text && activeBlock.raw.startsWith("-")) aggregatedSuggestionGroups[0].title = Strings.exclude;
		} else aggregatedSuggestionGroups = [cachedSuggestionGroup];
		if (activeFilterBlock) {
			const indexedValue = getLastFilterBlockValue(activeFilterBlock, caretIndex);
			const firstGroupsSuggestions = aggregatedSuggestionGroups[0]?.suggestions;
			if (aggregatedSuggestionGroups.length === 1 && firstGroupsSuggestions && getFilterValue(firstGroupsSuggestions[0]?.value) === indexedValue && indexedValue.length > 0) {
				if (firstGroupsSuggestions.length === 1) internalShouldShowSuggestions = false;
			}
		}
		if (activeFilterBlock && aggregatedSuggestionGroups[0]) {
			aggregatedSuggestionGroups[0] = excludeUsedSuggestions(aggregatedSuggestionGroups[0], activeFilterBlock);
			aggregatedSuggestionGroups[0].suggestions = aggregatedSuggestionGroups[0].suggestions.slice(0, 25);
		}
		if (checkFilterQuerySync(query, rawFilterRef?.current) && query.isValidated) {
			const suggestionCounts = aggregatedSuggestionGroups.reduce((n, group) => n + group.suggestions.length, 0);
			if (document.activeElement === inputRef.current && suggestionCounts > 0) debounceScreenReaderFeedback(`${suggestionCounts} ${suggestionCounts === 1 ? "suggestion" : "suggestions"}`, false);
			setSuggestionGroups(aggregatedSuggestionGroups);
			if (cachedSuggestionGroup.suggestions.length === 0) setActiveSuggestion(-1);
			if (aggregatedSuggestionGroups.length > 0 && internalShouldShowSuggestions && inputContextRef.current?.inputHasFocus) showSuggestions();
			else hideSuggestions();
		}
		setIsFetchingSuggestions(false);
	}, [
		config,
		filterQuery,
		inputRef,
		filterProviders,
		showSuggestions,
		updatePosition,
		rawFilterRef,
		inputContextRef,
		hideSuggestions,
		debounceScreenReaderFeedback
	]);
	const suggestionSelected = useCallback((suggestion) => {
		setActiveSuggestion(-1);
		const currentBlock = filterQuery.activeBlock;
		const isExcludeKeySuggestion = suggestion.value.toString().startsWith("-");
		let suggestedValue;
		let shouldSubmit = false;
		if (suggestion.value === Strings.dividerValue) return;
		if (suggestion.type === "keyword") suggestedValue = getEscapedFilterValue(suggestion.value);
		else if (!currentBlock || currentBlock.type !== BlockType.Filter) {
			suggestedValue = getEscapedFilterValue(suggestion.value);
			if (suggestedValue !== "-" && !suggestedValue?.endsWith(".")) suggestedValue += config.filterDelimiter;
		} else if (isExcludeKeySuggestion) suggestedValue = getEscapedFilterValue(suggestion.value);
		else {
			suggestedValue = getEscapedFilterValue(suggestion.value);
			shouldSubmit = true;
			hideSuggestions();
		}
		const caretIndex = inputRef.current?.selectionStart ?? -1;
		if (suggestion.type === FilterValueType.NoValue) replaceActiveBlockWithPresenceBlock("no");
		else if (suggestion.type === FilterValueType.HasValue) replaceActiveBlockWithPresenceBlock("has");
		else if (suggestedValue) insertIntoQuery(suggestedValue, caretIndex, shouldSubmit);
		else updateFilter();
	}, [
		config.filterDelimiter,
		filterQuery.activeBlock,
		hideSuggestions,
		inputRef,
		insertIntoQuery,
		replaceActiveBlockWithPresenceBlock,
		updateFilter
	]);
	useLayoutEffect(() => {
		updateFromExternal(async (query) => {
			if (checkFilterQuerySync(query, rawFilterRef?.current)) await updateSuggestions(query, inputRef.current?.selectionStart ?? -1);
		});
	}, [
		rawFilterRef,
		updateSuggestions,
		filterQuery.raw,
		filterQuery,
		updateFromExternal,
		inputRef
	]);
	return /* @__PURE__ */ jsx(SuggestionsContext, {
		value: useMemo(() => ({
			activeSuggestion,
			hideSuggestions,
			isFetchingSuggestions,
			position,
			showSuggestions,
			suggestionGroups,
			suggestionsListRef,
			suggestionSelected,
			suggestionsVisible,
			setActiveSuggestion,
			updateSuggestions,
			activeSuggestionRef
		}), [
			activeSuggestion,
			activeSuggestionRef,
			hideSuggestions,
			isFetchingSuggestions,
			position,
			showSuggestions,
			suggestionGroups,
			suggestionSelected,
			suggestionsVisible,
			updateSuggestions
		]),
		children
	});
};
SuggestionsContextProvider.displayName = "SuggestionsContextProvider";
var InputContext = createContext(void 0);
InputContext.displayName = "InputContext";
var useInput = () => {
	const context = use(InputContext);
	if (!context) throw new Error("useInput must be used inside a InputContext");
	return context;
};
var updateNativeInputElement = (input, value, selectionStartIndex, selectionEndIndex) => {
	const nativeInputValueProperty = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
	const nativeInputValueSetter = (v) => nativeInputValueProperty?.set?.call(input, v);
	nativeInputValueSetter(value);
	input.setSelectionRange(selectionStartIndex, selectionEndIndex ?? selectionStartIndex);
	input.dispatchEvent(new Event("input", { bubbles: true }));
	input.value = value;
};
var InputContextProvider = ({ ref, caretRef: forwardedCaretRef = null, children, inputRef: forwardedInputRef = null, value: externalValue = "", filterConfig }) => {
	const caretRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedCaretRef, caretRef);
	const inputRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedInputRef, inputRef);
	const [isInteractingWithSuggestions, setIsInteractingWithSuggestions] = useState(false);
	const [isInputFocused, setIsInputFocused] = useState(false);
	const [inputSelectionStart, setInputSelectionStart] = useState(-1);
	const [inputSelectionEnd, setInputSelectionEnd] = useState(-1);
	const isComposingRef = useRef(false);
	const [filterValue, setFilterValue] = useState(externalValue);
	const styledInputBlockCountRef = useRef(0);
	const { hideSuggestions, suggestionGroups: suggestions, activeSuggestion, setActiveSuggestion, suggestionsVisible, suggestionSelected, updateSuggestions } = useSuggestions();
	const { forceReparse, onSubmit, rawFilterRef, updateFilter } = useFilterQuery();
	const { config } = useFilter();
	const updateInputSelection = useCallback((selectionStart, selectionEnd) => {
		setInputSelectionStart(selectionStart);
		setInputSelectionEnd(selectionEnd ?? selectionStart);
	}, []);
	const updateRawFilterValue = useCallback((value) => {
		if (value === filterValue) return;
		setFilterValue(value);
		updateFilter(value, -1);
	}, [filterValue, updateFilter]);
	useImperativeHandle(ref, () => ({
		caretStart: inputSelectionStart,
		caretEnd: inputSelectionEnd,
		isComposing: isComposingRef.current,
		inputHasFocus: isInputFocused,
		styledInputBlockCount: styledInputBlockCountRef.current,
		updateCaretPosition: updateInputSelection,
		updateRawFilterValue
	}));
	const inputKeyDown = useCallback((event) => {
		if (isComposingRef.current) return;
		const flatSuggestions = getFlatSuggestionsList(suggestions);
		if (event.key === "ArrowLeft" || event.key === "ArrowRight") hideSuggestions();
		else if (event.key === "ArrowDown") {
			if (activeSuggestion + 1 >= flatSuggestions.length) setActiveSuggestion(-1);
			else setActiveSuggestion(activeSuggestion + 1);
			event.preventDefault();
		} else if (event.key === "ArrowUp") {
			if (activeSuggestion < 0) setActiveSuggestion(flatSuggestions.length - 1);
			else setActiveSuggestion(activeSuggestion - 1);
			event.preventDefault();
		} else if (event.key === "Enter") {
			if (suggestionsVisible && activeSuggestion !== null) {
				const suggestion = flatSuggestions[activeSuggestion];
				if (suggestion) {
					event.preventDefault();
					suggestionSelected(suggestion);
					inputRef.current?.focus();
					return;
				}
			}
			onSubmit(SubmitEvent.ExplicitSubmit, "input_with_enter");
			hideSuggestions();
		} else if (event.key === "Escape") {
			if (suggestionsVisible) {
				hideSuggestions();
				event.stopPropagation();
			}
		} else if (event.key === "Home" || event.key === "End") setActiveSuggestion(-1);
		else if (filterConfig.groupAndKeywordSupport && ["("].includes(event.key) || event.key === "\"") {
			const input = event.currentTarget;
			const keyPressed = event.key;
			if (input.selectionStart !== input.selectionEnd && ["(", "\""].includes(keyPressed)) {
				const closing = keyPressed === "(" ? ")" : "\"";
				updateNativeInputElement(input, `${input.value.slice(0, inputSelectionStart)}${keyPressed}${input.value.slice(inputSelectionStart, inputSelectionEnd)}${closing}${input.value.slice(inputSelectionEnd)}`, inputSelectionStart + 1, inputSelectionEnd + 1);
				event.preventDefault();
				return;
			}
			const caretIndex = input.selectionEnd ?? input.selectionStart ?? -1;
			if (keyPressed === "\"" && input.value.charAt(caretIndex) === "\"") {
				updateNativeInputElement(input, input.value, inputSelectionStart + 1);
				event.preventDefault();
				return;
			}
			if (input.value.charAt(caretIndex).match(/\w/g) || input.value.charAt(caretIndex - 1).match(/[\w"]/g)) return;
			if (keyPressed === "(") {
				const matchedQuotes = findMatchedQuotes(input.value);
				for (const [openQuoteIndex, closeQuoteIndex] of matchedQuotes) if (caretIndex > openQuoteIndex && caretIndex <= closeQuoteIndex) return;
			}
			event.preventDefault();
			const closing = keyPressed === "(" ? ")" : "\"";
			updateNativeInputElement(input, `${input.value.slice(0, caretIndex)}${keyPressed}${closing}${input.value.slice(caretIndex)}`, caretIndex + 1);
		} else if (event.key === "Backspace") {
			const input = event.currentTarget;
			const caretIndex = input.selectionEnd ?? -1;
			if (filterConfig.groupAndKeywordSupport && input.value.charAt(caretIndex - 1) === "(" && input.value.charAt(caretIndex) === ")" || input.value.charAt(caretIndex - 1) === "\"" && input.value.charAt(caretIndex) === "\"") {
				event.preventDefault();
				updateNativeInputElement(input, `${input.value.slice(0, caretIndex - 1)}${input.value.slice(caretIndex + 1)}`, caretIndex - 1);
			}
		}
	}, [
		activeSuggestion,
		filterConfig.groupAndKeywordSupport,
		hideSuggestions,
		inputSelectionEnd,
		inputSelectionStart,
		onSubmit,
		setActiveSuggestion,
		suggestionSelected,
		suggestions,
		suggestionsVisible
	]);
	const inputOnFocus = useCallback(() => {
		setIsInputFocused(true);
		if (isInteractingWithSuggestions) setIsInteractingWithSuggestions(false);
		else forceReparse(-1, async (query) => {
			if (checkFilterQuerySync(query, rawFilterRef?.current)) await updateSuggestions(query, inputSelectionStart);
		});
	}, [
		isInteractingWithSuggestions,
		forceReparse,
		rawFilterRef,
		updateSuggestions,
		inputSelectionStart
	]);
	const inputOnBlur = useCallback(() => {
		if (isInteractingWithSuggestions) return;
		setIsInputFocused(false);
		forceReparse(-1);
		hideSuggestions();
	}, [
		isInteractingWithSuggestions,
		forceReparse,
		hideSuggestions
	]);
	const inputOnCompositionStart = useCallback(() => {
		isComposingRef.current = true;
		hideSuggestions();
	}, [hideSuggestions]);
	const inputOnCompositionEnd = useCallback(() => {
		isComposingRef.current = false;
	}, []);
	const inputOnChange = useCallback((e) => {
		const input = e.currentTarget;
		const currentValue = input.value;
		if (currentValue === filterValue) return;
		setFilterValue(currentValue);
		e.preventDefault();
		const caretStartIndex = config.variant !== "button" ? input.selectionStart ?? -1 : -1;
		const caretEndIndex = config.variant !== "button" ? input.selectionEnd ?? -1 : -1;
		updateFilter(currentValue, caretStartIndex, (query) => {
			updateSuggestions(query, caretStartIndex);
		});
		updateInputSelection(caretStartIndex, caretEndIndex);
	}, [
		config.variant,
		updateFilter,
		updateInputSelection,
		updateSuggestions,
		filterValue
	]);
	const updateStyledInputBlockCount = useCallback((count) => {
		styledInputBlockCountRef.current = count;
	}, []);
	const suspendFocus = useCallback(() => {
		setIsInteractingWithSuggestions(true);
	}, []);
	return /* @__PURE__ */ jsx(InputContext, {
		value: useMemo(() => ({
			caretRef,
			inputFocused: isInputFocused,
			inputKeyDown,
			inputOnBlur,
			inputOnCompositionStart,
			inputOnCompositionEnd,
			inputOnChange,
			inputOnFocus,
			inputRef,
			inputSelectionEnd,
			inputSelectionStart,
			inputValue: filterValue,
			suspendFocus,
			updateInputSelection,
			updateStyledInputBlockCount
		}), [
			isInputFocused,
			inputKeyDown,
			inputOnBlur,
			inputOnCompositionStart,
			inputOnCompositionEnd,
			inputOnChange,
			inputOnFocus,
			inputSelectionEnd,
			inputSelectionStart,
			filterValue,
			suspendFocus,
			updateInputSelection,
			updateStyledInputBlockCount
		]),
		children
	});
};
InputContextProvider.displayName = "InputContextProvider";
InputContextProvider.displayName = "InputContextProvider";
var FilterContext = createContext(void 0);
FilterContext.displayName = "FilterContext";
var useFilter = () => {
	const context = use(FilterContext);
	if (!context) throw new Error("useFilter must be used inside a FilterProvider");
	return context;
};
var FilterContextProvider = ({ children, context, customParser, rawFilter, filterDelimiter = defaultFilterConfig.filterDelimiter, inputRef: forwardedInputRef, onChange, onParse, onSubmit, onValidation, providers, settings: suppliedSettings, valueDelimiter = defaultFilterConfig.valueDelimiter, variant }) => {
	const filterConfig = useMemo(() => {
		return {
			filterDelimiter,
			valueDelimiter,
			...defaultFilterSettings,
			...suppliedSettings,
			variant
		};
	}, [
		filterDelimiter,
		suppliedSettings,
		valueDelimiter,
		variant
	]);
	const inputRef = useRef(null);
	useRefObjectAsForwardedRef(forwardedInputRef ?? null, inputRef);
	const caretRef = useRef(null);
	const inputContextRef = useRef(null);
	const id = useId();
	const contextValue = useMemo(() => ({
		config: filterConfig,
		id,
		inputContextRef
	}), [
		filterConfig,
		id,
		inputContextRef
	]);
	useEffect(() => {
		inputContextRef.current?.updateRawFilterValue(rawFilter);
	}, [rawFilter]);
	return /* @__PURE__ */ jsx(FilterContext, {
		value: contextValue,
		children: /* @__PURE__ */ jsx(FilterQueryContextProvider, {
			customParser,
			context,
			filterConfig,
			providers,
			inputRef,
			onChange,
			onParse,
			onSubmit,
			onValidation,
			rawFilter,
			children: /* @__PURE__ */ jsx(SuggestionsContextProvider, {
				caretRef,
				inputRef,
				children: /* @__PURE__ */ jsx(InputContextProvider, {
					caretRef,
					inputRef,
					ref: inputContextRef,
					value: rawFilter,
					filterConfig,
					children
				})
			})
		})
	});
};
FilterContextProvider.displayName = "FilterContextProvider";
var FilterQueryContext = createContext(void 0);
FilterQueryContext.displayName = "FilterQueryContext";
var useFilterQuery = () => {
	const context = use(FilterQueryContext);
	if (!context) throw new Error("useFilterQuery must be used inside a FilterQueryContext");
	return context;
};
var FilterQueryContextProvider = ({ children, context: externalContext, customParser, filterConfig, providers: externalProviders, inputRef, onChange, onParse, onSubmit, onValidation, rawFilter }) => {
	const latestRawFilterRef = useRef(rawFilter ?? "");
	const parserRef = useRef(customParser ?? new FilterQueryParser(externalProviders.filter((p) => !isNestedFilterProvider(p)), filterConfig));
	const [filterQuery, setFilterQuery] = useState(() => parserRef.current.parse(rawFilter, new FilterQuery(), -1));
	const [isInitialValidation, setIsInitialValidation] = useState(true);
	const { inputContextRef, config } = useFilter();
	const variant = config.variant === "full" ? "button_and_input" : config.variant === "input" ? "input_only" : "button_only";
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	useEffect(() => {
		filterQuery.staticContext = externalContext;
	}, [externalContext, filterQuery]);
	const clearFilter = useCallback(() => {
		onChange("");
		onSubmit?.(new FilterQuery(), SubmitEvent.Clear);
		inputRef.current?.focus();
	}, [
		inputRef,
		onChange,
		onSubmit
	]);
	const filterProviders = useMemo(() => {
		const record = {};
		const noProviders = [];
		const hasProviders = [];
		externalProviders.map((provider) => {
			if (isNestedFilterProvider(provider)) for (const subProvider of provider.filterProviders) {
				record[subProvider.key] = subProvider;
				if (subProvider.options.filterTypes.valueless) noProviders.push(subProvider);
				if (subProvider.options.filterTypes.hasValue) hasProviders.push(subProvider);
			}
			else {
				record[provider.key] = provider;
				if (provider.options.filterTypes.valueless) noProviders.push(provider);
				if (provider.options.filterTypes.hasValue) hasProviders.push(provider);
			}
		});
		if (noProviders.length) record.no = new NoFilterProviderV2(noProviders.sort((a, b) => (a.displayName ?? a.key)?.localeCompare(b.displayName ?? b.key) ?? 0).map((provider) => ({
			value: provider.key,
			priority: 5,
			displayName: provider.displayName,
			type: FilterValueType.Value,
			icon: provider.icon
		})));
		if (hasProviders.length) record.has = new HasFilterProvider(hasProviders.sort((a, b) => (a.displayName ?? a.key)?.localeCompare(b.displayName ?? b.key) ?? 0).map((provider) => ({
			value: provider.key,
			priority: 5,
			displayName: provider.displayName,
			type: FilterValueType.Value,
			icon: provider.icon
		})));
		parserRef.current.filterProviders = Object.values(record);
		return record;
	}, [externalProviders]);
	const postQueryValidate = useCallback((request, showAllErrors = false) => {
		onValidation(request.getErrors(showAllErrors || document.activeElement !== inputRef.current), new FilterQuery(request.raw, request.blocks, filterConfig, request.activeBlock));
	}, [
		filterConfig,
		inputRef,
		onValidation
	]);
	const parseAndValidate = useCallback((caret, callback, newRaw) => {
		setIsInitialValidation(false);
		new Promise((resolve, reject) => {
			const query = parserRef.current.parse(newRaw ?? rawFilter, filterQuery, caret);
			if (checkFilterQuerySync(query, latestRawFilterRef.current)) {
				setFilterQuery(query);
				resolve(query);
			} else reject(/* @__PURE__ */ new Error("Query out of sync, Aborted..."));
		}).then((query) => parserRef.current.validateFilterQuery(query)).then((newQuery) => {
			return new Promise((resolve, reject) => {
				if (newQuery && checkFilterQuerySync(newQuery)) {
					setFilterQuery(newQuery);
					return resolve(newQuery);
				}
				return reject(/* @__PURE__ */ new Error(newQuery ? "Out of sync" : "Empty Query, Aborted..."));
			});
		}).then((query) => {
			callback?.(query);
		}).catch(() => {});
	}, [filterQuery, rawFilter]);
	const forceReparse = useCallback((cursorLocation, callback) => {
		parseAndValidate(cursorLocation ? cursorLocation : inputContextRef.current?.caretStart ?? -1, (query) => {
			postQueryValidate(query);
			callback?.(query);
		});
	}, [
		inputContextRef,
		parseAndValidate,
		postQueryValidate
	]);
	const onSubmitHandler = useCallback(async (eventType, analyticsName, updatedQuery) => {
		const query = updatedQuery ?? filterQuery;
		query.clearActiveBlock();
		let retry = 0;
		let hasSubmitted = false;
		const rawValueForSync = inputRef.current?.value ?? rawFilter;
		while (retry <= 3) if (checkFilterQuerySync(query, rawValueForSync)) {
			onSubmit?.(query, eventType);
			postQueryValidate(query, true);
			hasSubmitted = true;
			break;
		} else {
			retry += 1;
			await promiseTimeout(10);
		}
		if (!hasSubmitted) parseAndValidate(inputContextRef.current?.caretStart ?? -1, (q) => {
			if (checkFilterQuerySync(q, rawValueForSync)) {
				onSubmit?.(q, eventType);
				postQueryValidate(query, true);
			}
		});
		sendClickAnalyticsEvent({
			action: "submit_filter_query",
			label: `variant:${variant};event_type:${eventType};used_filter_providers:${filterQuery.filtersUsed.length > 0 ? filterQuery.filtersUsed.join(",") : ""};nested_group_depth:${filterQuery.nestedGroupCount};submitted_by:${analyticsName ?? "unnamed_submit_method"}`
		});
	}, [
		filterQuery,
		inputContextRef,
		inputRef,
		onSubmit,
		parseAndValidate,
		postQueryValidate,
		rawFilter,
		sendClickAnalyticsEvent,
		variant
	]);
	const updateFilter = useCallback((unparsedFilter, caret = -1, callback, eventType) => {
		const updatedRaw = unparsedFilter ?? filterQuery.raw;
		onChange?.(updatedRaw);
		if (eventType) {
			latestRawFilterRef.current = updatedRaw;
			parseAndValidate(caret, (query) => {
				if (checkFilterQuerySync(query, latestRawFilterRef.current)) {
					callback?.(query);
					onSubmit?.(query, eventType);
					onParse?.(query);
				}
			}, updatedRaw);
		}
	}, [
		filterQuery.raw,
		onChange,
		onParse,
		onSubmit,
		parseAndValidate
	]);
	const replaceActiveBlockWithPresenceBlock = useCallback((type) => {
		const [raw, cursorIndex] = parserRef.current.replaceActiveBlockWithPresenceBlock(filterQuery, type);
		inputContextRef.current?.updateCaretPosition(cursorIndex);
		updateFilter(raw, cursorIndex);
	}, [
		filterQuery,
		inputContextRef,
		updateFilter
	]);
	const insertIntoQuery = useCallback((value, caretIndex, triggerSubmit = false) => {
		const [raw, cursorIndex] = parserRef.current.insertSuggestion(filterQuery, value, caretIndex);
		inputContextRef.current?.updateCaretPosition(cursorIndex);
		inputContextRef.current?.updateRawFilterValue(raw);
		updateFilter(raw, cursorIndex, void 0, triggerSubmit ? SubmitEvent.SuggestionSelected : void 0);
	}, [
		filterQuery,
		inputContextRef,
		updateFilter
	]);
	const updateFromExternal = useCallback((callback) => {
		if (rawFilter !== latestRawFilterRef.current || isInitialValidation) {
			latestRawFilterRef.current = rawFilter;
			parseAndValidate(inputContextRef.current?.caretStart ?? -1, (query) => {
				postQueryValidate(query);
				onParse?.(query);
				callback(query);
			});
		}
	}, [
		inputContextRef,
		isInitialValidation,
		onParse,
		parseAndValidate,
		postQueryValidate,
		rawFilter
	]);
	return /* @__PURE__ */ jsx(FilterQueryContext, {
		value: useMemo(() => ({
			clearFilter,
			filterQuery,
			filterProviders,
			forceReparse,
			insertIntoQuery,
			onSubmit: onSubmitHandler,
			rawFilterRef: latestRawFilterRef,
			replaceActiveBlockWithPresenceBlock,
			updateFilter,
			updateFromExternal
		}), [
			clearFilter,
			filterProviders,
			filterQuery,
			forceReparse,
			insertIntoQuery,
			onSubmitHandler,
			replaceActiveBlockWithPresenceBlock,
			updateFilter,
			updateFromExternal
		]),
		children
	});
};
FilterQueryContextProvider.displayName = "FilterQueryContextProvider";
var AddFilterButton_module_default = {
	ActionList_0: "AddFilterButton-module_m0jwQG_ActionList_0",
	ActionList_Item_0: "AddFilterButton-module_m0jwQG_ActionList_Item_0",
	ActionMenu_Overlay_0: "AddFilterButton-module_m0jwQG_ActionMenu_Overlay_0",
	Octicon_0: "AddFilterButton-module_m0jwQG_Octicon_0"
};
var AddFilterButton = ({ ref, size, filterProviders, addNewFilterBlock }) => {
	const [addFilterMenuOpen, setAddFilterMenuOpen] = useState(false);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(ButtonComponent, {
		size,
		ref,
		onClick: () => setAddFilterMenuOpen(!addFilterMenuOpen),
		...testIdProps("afd-add-filter"),
		children: [/* @__PURE__ */ jsx(PlusIcon, { className: AddFilterButton_module_default.Octicon_0 }), "Add a filter"]
	}), /* @__PURE__ */ jsx(ActionMenu, {
		anchorRef: ref,
		open: addFilterMenuOpen,
		onOpenChange: setAddFilterMenuOpen,
		children: /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			className: AddFilterButton_module_default.ActionMenu_Overlay_0,
			children: /* @__PURE__ */ jsx(ActionList, {
				...testIdProps("afd-add-filter-options"),
				className: AddFilterButton_module_default.ActionList_0,
				children: filterProviders.map((provider) => {
					const { icon: Icon } = provider;
					return /* @__PURE__ */ jsxs(ActionList.Item, {
						onSelect: () => addNewFilterBlock(provider),
						role: "menuitem",
						className: AddFilterButton_module_default.ActionList_Item_0,
						children: [Icon && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }), provider.displayName ?? provider.key]
					}, `advanced-filter-add-provider-${provider.key}`);
				})
			})
		})
	})] });
};
AddFilterButton.displayName = "AddFilterButton";
AddFilterButton.displayName = "AddFilterButton";
var AdvancedFilterDialog_module_default = {
	Box_0: "AdvancedFilterDialog-module_NxZRJG_Box_0",
	Box_1: "AdvancedFilterDialog-module_NxZRJG_Box_1",
	Box_2: "AdvancedFilterDialog-module_NxZRJG_Box_2",
	Box_3: "AdvancedFilterDialog-module_NxZRJG_Box_3",
	Box_4: "AdvancedFilterDialog-module_NxZRJG_Box_4",
	Button_0: "AdvancedFilterDialog-module_NxZRJG_Button_0",
	nonEmpty: "AdvancedFilterDialog-module_NxZRJG_nonEmpty",
	standaloneButton: "AdvancedFilterDialog-module_NxZRJG_standaloneButton"
};
var BlankState_module_default = {
	Box_0: "BlankState-module_Q9pVYG_Box_0",
	Box_1: "BlankState-module_Q9pVYG_Box_1",
	Box_2: "BlankState-module_Q9pVYG_Box_2",
	Box_3: "BlankState-module_Q9pVYG_Box_3"
};
var BlankState = ({ isNarrowBreakpoint, addFilterButtonMobileRef, filterProviders, addNewFilterBlock }) => {
	return /* @__PURE__ */ jsxs("div", {
		className: BlankState_module_default.Box_0,
		...testIdProps("afd-no-content"),
		children: [
			/* @__PURE__ */ jsx("div", {
				className: BlankState_module_default.Box_1,
				children: "Build complex filter queries"
			}),
			/* @__PURE__ */ jsx("div", {
				className: BlankState_module_default.Box_2,
				children: "To start building your query add your first filter using the button below."
			}),
			/* @__PURE__ */ jsx("div", {
				className: BlankState_module_default.Box_3,
				children: /* @__PURE__ */ jsx(AddFilterButton, {
					size: isNarrowBreakpoint ? "medium" : "small",
					ref: addFilterButtonMobileRef,
					filterProviders,
					addNewFilterBlock
				})
			})
		]
	});
};
BlankState.displayName = "BlankState";
var normalizeVisuals = (visuals) => {
	if (!visuals) return [];
	return Array.isArray(visuals) ? visuals : [visuals];
};
var resolveValueVisualDescriptor = (visuals, providerIcon) => {
	for (const visual of normalizeVisuals(visuals)) switch (visual.kind) {
		case "avatar":
			if (visual.url) return {
				kind: "avatar",
				url: visual.url,
				alt: visual.alt ?? "User Avatar",
				square: visual.square
			};
			break;
		case "color-swatch":
			if (visual.color) return {
				kind: "color-swatch",
				color: visual.color
			};
			break;
		case "octicon":
			if (visual.icon) return {
				kind: "octicon",
				icon: visual.icon,
				color: visual.color
			};
			break;
		case "provider-icon": {
			const icon = visual.icon ?? providerIcon;
			if (icon) return {
				kind: "octicon",
				icon
			};
			break;
		}
		default: break;
	}
	return null;
};
var ValueIcon_module_default = {
	Box_0: "ValueIcon-module__y0ZqG_Box_0",
	GitHubAvatar_0: "ValueIcon-module__y0ZqG_GitHubAvatar_0"
};
var ValueIcon = ({ visuals, providerIcon }) => {
	const visual = resolveValueVisualDescriptor(visuals, providerIcon);
	if (!visual) return null;
	if (visual.kind === "avatar") return /* @__PURE__ */ jsx(GitHubAvatar, {
		src: visual.url,
		alt: visual.alt,
		square: visual.square ?? false,
		className: ValueIcon_module_default.GitHubAvatar_0
	});
	if (visual.kind === "color-swatch") return /* @__PURE__ */ jsx("div", {
		style: { backgroundColor: visual.color },
		className: ValueIcon_module_default.Box_0
	});
	const cssIconColor = visual.color ? `${visual.color} !important` : "currentcolor";
	const VisualIcon = visual.icon;
	return /* @__PURE__ */ jsx(VisualIcon, { fill: cssIconColor });
};
ValueIcon.displayName = "ValueIcon";
var AdvancedFilterItem_module_default = {
	Box_0: "AdvancedFilterItem-module_M6sbWa_Box_0",
	Box_1: "AdvancedFilterItem-module_M6sbWa_Box_1",
	Box_2: "AdvancedFilterItem-module_M6sbWa_Box_2",
	Box_3: "AdvancedFilterItem-module_M6sbWa_Box_3",
	Box_4: "AdvancedFilterItem-module_M6sbWa_Box_4",
	Box_5: "AdvancedFilterItem-module_M6sbWa_Box_5",
	Box_6: "AdvancedFilterItem-module_M6sbWa_Box_6",
	Box_7: "AdvancedFilterItem-module_M6sbWa_Box_7",
	Box_8: "AdvancedFilterItem-module_M6sbWa_Box_8",
	RemoveFilterButton_0: "AdvancedFilterItem-module_M6sbWa_RemoveFilterButton_0",
	Text_0: "AdvancedFilterItem-module_M6sbWa_Text_0",
	Text_1: "AdvancedFilterItem-module_M6sbWa_Text_1"
};
var OperatorSelect_module_default = {
	Button_0: "OperatorSelect-module_hXFCgW_Button_0",
	Octicon_0: "OperatorSelect-module_hXFCgW_Octicon_0"
};
var OperatorSelect = ({ filterBlock, index, setFilterOperator }) => {
	const title = filterBlock.operator ? FilterOperators[filterBlock.operator] : FilterOperators[FilterOperator.Is];
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(ButtonComponent, {
		size: "small",
		disabled: !filterBlock.provider,
		id: `afd-row-${index}-operator`,
		"aria-label": `${title && title.trim() ? `${title.trim()}, ` : ""}Operator ${index + 1}`,
		className: OperatorSelect_module_default.Button_0,
		block: true,
		alignContent: "start",
		trailingAction: () => /* @__PURE__ */ jsx(TriangleDownIcon, { className: OperatorSelect_module_default.Octicon_0 }),
		children: title
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		width: "auto",
		children: /* @__PURE__ */ jsx(ActionList, {
			selectionVariant: "single",
			children: getAllFilterOperators(filterBlock.provider).map((operator) => /* @__PURE__ */ jsx(ActionList.Item, {
				onSelect: () => setFilterOperator(operator),
				selected: operator === filterBlock.operator,
				children: FilterOperators[operator]
			}, `advanced-filter-item-${filterBlock.id}-operator-${operator}`))
		})
	})] });
};
OperatorSelect.displayName = "OperatorSelect";
var QualifierSelect_module_default = {
	ActionList_0: "QualifierSelect-module_4voyOa_ActionList_0",
	ActionMenu_Overlay_0: "QualifierSelect-module_4voyOa_ActionMenu_Overlay_0",
	Button_0: "QualifierSelect-module_4voyOa_Button_0",
	Octicon_0: "QualifierSelect-module_4voyOa_Octicon_0"
};
var QualifierSelect = ({ filterBlock, filterProviders, index, setFilterProvider }) => {
	const LeadingIcon = filterBlock?.provider?.icon;
	const title = filterBlock?.provider?.displayName ?? filterBlock?.provider?.key;
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(ButtonComponent, {
		id: `afd-row-${index}-qualifier`,
		"aria-label": `${title && title.trim() ? `${title.trim()}, ` : ""}Qualifier ${index + 1}`,
		className: clsx("advanced-filter-item-qualifier", QualifierSelect_module_default.Button_0),
		size: "small",
		block: true,
		alignContent: "start",
		leadingVisual: () => LeadingIcon ? /* @__PURE__ */ jsx(LeadingIcon, { className: QualifierSelect_module_default.Octicon_0 }) : null,
		trailingAction: () => /* @__PURE__ */ jsx(TriangleDownIcon, { className: QualifierSelect_module_default.Octicon_0 }),
		children: title ?? "Select a filter"
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
		className: QualifierSelect_module_default.ActionMenu_Overlay_0,
		children: /* @__PURE__ */ jsx(ActionList, {
			selectionVariant: "single",
			className: QualifierSelect_module_default.ActionList_0,
			children: filterProviders.map((provider, id) => {
				const { icon: Icon } = provider;
				return /* @__PURE__ */ jsxs(ActionList.Item, {
					onSelect: () => setFilterProvider(provider),
					selected: provider.key === filterBlock.provider?.key,
					children: [Icon && /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Icon, {}) }), provider.displayName ?? provider.key]
				}, `advanced-filter-item-${filterBlock.id}-provider-${provider.key}-${id}`);
			})
		})
	})] });
};
QualifierSelect.displayName = "QualifierSelect";
var RemoveFilterButton_module_default = { IconButton_0: "RemoveFilterButton-module_90KUHa_IconButton_0" };
var RemoveFilterButton = ({ ariaLabel, onClick, className, testId = "" }) => {
	return /* @__PURE__ */ jsx(IconButton, {
		icon: XIcon,
		size: "small",
		variant: "invisible",
		"aria-label": ariaLabel,
		onClick,
		className: clsx(className, RemoveFilterButton_module_default.IconButton_0),
		...testIdProps(testId)
	});
};
RemoveFilterButton.displayName = "RemoveFilterButton";
var BooleanValueSelect_module_default = {
	Button_0: "BooleanValueSelect-module_OpH4aG_Button_0",
	Octicon_0: "BooleanValueSelect-module_OpH4aG_Octicon_0"
};
var ValuePlaceholder_module_default = {
	AvatarStack: "ValuePlaceholder-module_PoMBmG_AvatarStack",
	Box_0: "ValuePlaceholder-module_PoMBmG_Box_0",
	Box_1: "ValuePlaceholder-module_PoMBmG_Box_1",
	Octicon_0: "ValuePlaceholder-module_PoMBmG_Octicon_0"
};
var getValueText = (filterBlock) => {
	const validValues = filterBlock.value?.values.filter((v) => v.valid && v.value !== "") ?? [];
	if (validValues.length === 0) return "Make a selection";
	const displayName = filterBlock.value?.values?.[0]?.displayName;
	const userName = filterBlock.value?.values?.[0]?.name;
	const description = filterBlock.value?.values?.[0]?.description;
	const value = getFilterValue(filterBlock.value?.values?.[0]?.value);
	let displayValue = `${validValues.length} selected`;
	if (validValues.length === 1) displayValue = displayName ?? userName ?? description ?? value;
	return displayValue;
};
var ValuePlaceholder = ({ filterBlock }) => {
	const validValues = filterBlock.value?.values.filter((v) => v.valid && v.value !== "") ?? [];
	return /* @__PURE__ */ jsxs("div", {
		className: clsx({
			[ValuePlaceholder_module_default.Box_0]: validValues.length === 0,
			[ValuePlaceholder_module_default.Box_1]: validValues.length > 0
		}),
		children: [/* @__PURE__ */ jsx(ValuePlaceholderIcon, { filterBlock }), getValueText(filterBlock)]
	});
};
ValuePlaceholder.displayName = "ValuePlaceholder";
var ValuePlaceholderIcon = ({ filterBlock }) => {
	if (!filterBlock.value?.values || filterBlock.value.values.length < 1) return null;
	if (filterBlock.provider?.type === FilterProviderType.User) {
		const avatars = [];
		for (const value of filterBlock.value?.values ?? []) {
			const avatar = value?.avatar?.url ?? value?.avatarUrl;
			if (avatar) avatars.push(/* @__PURE__ */ jsx(GitHubAvatar, {
				src: avatar,
				size: 16,
				alt: value.displayName ?? getFilterValue(value.value) ?? ""
			}, `${filterBlock.provider.key}-${filterBlock.id}-avatar-${getFilterValue(value.value)}`));
		}
		if (avatars.length > 0) return /* @__PURE__ */ jsx(AvatarStack, {
			disableExpand: true,
			size: 16,
			className: ValuePlaceholder_module_default.AvatarStack,
			children: avatars
		});
	}
	if (filterBlock.value?.values?.length === 1) {
		const Icon = (filterBlock.provider?.filterValues?.find((v) => v.value === filterBlock.value?.values?.[0]?.value))?.icon;
		if (Icon) return /* @__PURE__ */ jsx(Icon, { className: ValuePlaceholder_module_default.Octicon_0 });
	}
	return null;
};
ValuePlaceholderIcon.displayName = "ValuePlaceholderIcon";
var getBooleanValueLabel = (filterBlock, index) => {
	const value = getFilterValue(filterBlock.value?.values[0]?.value);
	if (value === "true" || value === "false") return `${capitalize(value)}, Value ${index + 1}`;
	return `Value ${index + 1}`;
};
var BooleanValueSelect = ({ index, filterBlock, setFilterValues }) => {
	return /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(ButtonComponent, {
		size: "small",
		className: BooleanValueSelect_module_default.Button_0,
		"aria-label": getBooleanValueLabel(filterBlock, index),
		trailingVisual: () => /* @__PURE__ */ jsx(TriangleDownIcon, { className: BooleanValueSelect_module_default.Octicon_0 }),
		...testIdProps("afd-row-value-select-boolean-button"),
		children: /* @__PURE__ */ jsx(ValuePlaceholder, { filterBlock })
	}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, {
		selectionVariant: "single",
		...testIdProps("afd-row-value-select-list"),
		children: [/* @__PURE__ */ jsx(ActionList.Item, {
			onSelect: () => setFilterValues(true),
			selected: getFilterValue(filterBlock.value?.values[0]?.value) === void 0 || getFilterValue(filterBlock.value?.values[0]?.value) === "true",
			children: "True"
		}), /* @__PURE__ */ jsx(ActionList.Item, {
			onSelect: () => setFilterValues(false),
			selected: getFilterValue(filterBlock.value?.values[0]?.value) === "false",
			children: "False"
		})]
	}) })] });
};
BooleanValueSelect.displayName = "BooleanValueSelect";
var ValueSelect_module_default = {
	Box_0: "ValueSelect-module_zTtwHG_Box_0",
	Box_1: "ValueSelect-module_zTtwHG_Box_1",
	Button_0: "ValueSelect-module_zTtwHG_Button_0",
	Octicon_0: "ValueSelect-module_zTtwHG_Octicon_0",
	Overlay: "ValueSelect-module_zTtwHG_Overlay",
	TextInput_0: "ValueSelect-module_zTtwHG_TextInput_0",
	TextInput_1: "ValueSelect-module_zTtwHG_TextInput_1"
};
var selectValueTypeOptions = new Set([FilterProviderType.Select, FilterProviderType.User]);
var isSelectValueType = (type) => type && selectValueTypeOptions.has(type);
var isDateValueType = (type) => type && type === FilterProviderType.Date;
var inputValueTypeOptions = new Set([
	FilterProviderType.Number,
	FilterProviderType.Date,
	FilterProviderType.Text
]);
var isInputValueType = (type) => type && inputValueTypeOptions.has(type);
var ValueSelect = ({ filterBlock, setValuesFilter, setFilterValues, setFilterFrom, setFilterText, setFilterTo, valueElements, index, selectedFilteredValues }) => {
	const [filterValuesOpen, setFilterValuesOpen] = useState(false);
	const [initiallySelectedValues, setInitiallySelectedValues] = useState([]);
	useEffect(() => {
		if (!filterValuesOpen) setValuesFilter("");
	}, [filterValuesOpen, setValuesFilter]);
	const onOpenChange = useCallback((openState) => {
		if (openState) setInitiallySelectedValues(selectedFilteredValues ?? []);
		setFilterValuesOpen(openState);
	}, [selectedFilteredValues]);
	const onCancel = useCallback(() => {
		setFilterValues(initiallySelectedValues);
	}, [initiallySelectedValues, setFilterValues]);
	const selectPanelProps = useMemo(() => ({
		renderAnchor: ({ ...anchorProps }) => /* @__PURE__ */ jsx(ButtonComponent, {
			...anchorProps,
			id: `afd-row-${index}-value`,
			size: "small",
			alignContent: "start",
			disabled: !filterBlock.operator,
			"aria-label": `${getValueText(filterBlock)}, Value ${index + 1}`,
			className: clsx("advanced-filter-item-value", ValueSelect_module_default.Button_0),
			trailingVisual: () => /* @__PURE__ */ jsx(TriangleDownIcon, { className: ValueSelect_module_default.Octicon_0 }),
			...testIdProps("afd-row-value-select-button"),
			children: /* @__PURE__ */ jsx("div", {
				className: ValueSelect_module_default.Box_0,
				children: /* @__PURE__ */ jsx(ValuePlaceholder, { filterBlock })
			})
		}),
		placeholderText: `Filter values`,
		open: filterValuesOpen,
		onOpenChange,
		items: valueElements,
		onFilterChange: setValuesFilter,
		showItemDividers: false,
		overlayProps: {
			width: "small",
			className: ValueSelect_module_default.Overlay
		},
		...testIdProps("afd-row-value-select")
	}), [
		filterValuesOpen,
		valueElements,
		setValuesFilter,
		index,
		filterBlock,
		onOpenChange
	]);
	if (isSelectValueType(filterBlock.provider?.type)) {
		/**
		* NOTE: While the below looks identical, this has to be broken out so that the typings will deterministically
		* set the props as either a single value or an array
		*/
		if (Array.isArray(selectedFilteredValues)) return /* @__PURE__ */ jsx(FeatureFlags, {
			flags: { primer_react_select_panel_fullscreen_on_narrow: true },
			children: /* @__PURE__ */ jsx(SelectPanel, {
				...selectPanelProps,
				onCancel,
				selected: selectedFilteredValues,
				onSelectedChange: setFilterValues
			})
		});
		return /* @__PURE__ */ jsx(FeatureFlags, {
			flags: { primer_react_select_panel_fullscreen_on_narrow: true },
			children: /* @__PURE__ */ jsx(SelectPanel, {
				...selectPanelProps,
				onCancel,
				selected: selectedFilteredValues,
				onSelectedChange: setFilterValues
			})
		});
	}
	if (filterBlock.provider?.type === FilterProviderType.Boolean) return /* @__PURE__ */ jsx(BooleanValueSelect, {
		index,
		filterBlock,
		setFilterValues
	});
	if (isInputValueType(filterBlock.provider?.type)) {
		if (filterBlock.operator === FilterOperator.Between) return /* @__PURE__ */ jsx(BetweenFilterInputs, {
			index,
			fromValue: getFilterValue(filterBlock.value?.values[0]?.value) ?? "",
			toValue: getFilterValue(filterBlock.value?.values[1]?.value) ?? "",
			setFromValue: setFilterFrom,
			setToValue: setFilterTo
		});
		const placeholder = isDateValueType(filterBlock.provider?.type) ? "YYYY-MM-DD" : `Enter a ${filterBlock.provider?.type.toString().toLowerCase() ?? "value"}`;
		const inputType = filterBlock.provider?.type === FilterProviderType.Number ? "number" : "text";
		return /* @__PURE__ */ jsx(TextInput$1, {
			"aria-label": `Value ${index + 1}`,
			size: "small",
			type: inputType,
			value: filterBlock.value?.raw,
			onChange: setFilterText,
			placeholder,
			className: ValueSelect_module_default.TextInput_0,
			...testIdProps(`afd-row-${index}`)
		});
	}
	return /* @__PURE__ */ jsx(TextInput$1, {
		"aria-label": `Value ${index + 1}`,
		size: "small",
		value: filterBlock.value?.raw,
		onChange: setFilterText,
		placeholder: "Enter search text",
		className: ValueSelect_module_default.TextInput_0,
		...testIdProps(`afd-row-${index}`)
	});
};
ValueSelect.displayName = "ValueSelect";
var BetweenFilterInputs = ({ index, fromValue, toValue, setFromValue, setToValue }) => /* @__PURE__ */ jsxs("div", {
	className: ValueSelect_module_default.Box_1,
	children: [
		/* @__PURE__ */ jsx(TextInput$1, {
			"aria-label": `Value ${index + 1} From`,
			size: "small",
			value: fromValue,
			onChange: setFromValue,
			placeholder: "From",
			className: ValueSelect_module_default.TextInput_1,
			...testIdProps(`afd-row-${index}-from`)
		}),
		/* @__PURE__ */ jsx("span", { children: "-" }),
		/* @__PURE__ */ jsx(TextInput$1, {
			"aria-label": `Value ${index + 1} To`,
			size: "small",
			value: toValue,
			onChange: setToValue,
			placeholder: "To",
			className: ValueSelect_module_default.TextInput_1,
			...testIdProps(`afd-row-${index}-to`)
		})
	]
});
BetweenFilterInputs.displayName = "BetweenFilterInputs";
var AdvancedFilterItem = ({ index, filterBlock, filterProviders, updateFilterBlock, deleteFilterBlock }) => {
	const { config } = useFilter();
	const { filterQuery } = useFilterQuery();
	const [values, setValues] = useState(filterBlock.provider?.filterValues ?? []);
	const [valuesFilter, setValuesFilter] = useState("");
	const [selectedFilteredValues, setSelectedFilteredValues] = useState(filterBlock.provider?.options?.filterTypes.multiValue ? [] : void 0);
	const filteredValues = useMemo(() => {
		if (!isMutableFilterBlock(filterBlock)) return [];
		return values.filter((value) => valuesFilter.length > 0 ? hasMatch(valuesFilter, getFilterValue(value.value) ?? "") || hasMatch(valuesFilter, value.displayName ?? "") : true);
	}, [
		filterBlock,
		valuesFilter,
		values
	]);
	const amendedFilterProviders = useMemo(() => {
		const providers = Array.from(filterProviders);
		if (filterBlock.provider && !filterProviders.find((p) => p.key === filterBlock.provider?.key)) providers.push(filterBlock.provider);
		return providers.sort((a, b) => (a.displayName ?? a.key)?.localeCompare(b.displayName ?? b.key) ?? 0);
	}, [filterBlock.provider, filterProviders]);
	const valueElements = useMemo(() => {
		const initialValueElements = Array.isArray(selectedFilteredValues) ? [...selectedFilteredValues] : selectedFilteredValues ? [selectedFilteredValues] : [];
		const providerIcon = filterBlock.provider?.icon;
		return filteredValues?.reduce((elements, value) => {
			const row = filterBlock.provider?.getValueRowProps(value);
			if ((elements.findIndex((v) => v.text === row?.text) ?? -1) === -1) {
				const leadingVisual = row?.leadingVisual ? /* @__PURE__ */ jsx(ValueIcon, {
					visuals: row.leadingVisual,
					providerIcon
				}) : null;
				const trailingVisual = row?.trailingVisual ? /* @__PURE__ */ jsx(ValueIcon, {
					visuals: row.trailingVisual,
					providerIcon
				}) : null;
				elements.push({
					...row,
					leadingVisual: leadingVisual ? () => leadingVisual : void 0,
					trailingVisual: trailingVisual ? () => trailingVisual : void 0
				});
			}
			return elements;
		}, initialValueElements);
	}, [
		filterBlock.provider,
		filteredValues,
		selectedFilteredValues
	]);
	const setFilterProvider = useCallback((provider) => {
		if (provider.type !== FilterProviderType.RawText) {
			const isRawTextToText = filterBlock.provider?.type === FilterProviderType.RawText && provider.type === FilterProviderType.Text;
			const isSameType = provider.type === filterBlock.provider?.type;
			const newValue = isSameType || isRawTextToText ? filterBlock.value : {
				raw: "",
				values: []
			};
			if (!isSameType && !isRawTextToText) setSelectedFilteredValues(filterBlock.provider?.options?.filterTypes.multiValue ? [] : void 0);
			updateFilterBlock({
				...filterBlock,
				key: {
					value: provider.key,
					valid: true
				},
				provider,
				operator: getAllFilterOperators(provider)[0],
				value: newValue
			});
		} else {
			const newValue = filterBlock.provider?.type === FilterProviderType.Text && filterBlock.value ? filterBlock.value : {
				raw: "",
				values: []
			};
			if (filterBlock.provider?.type !== FilterProviderType.Text) setSelectedFilteredValues(provider.options.filterTypes.multiValue ? [] : void 0);
			updateFilterBlock({
				...filterBlock,
				key: void 0,
				provider: RawTextProvider,
				operator: getAllFilterOperators(RawTextProvider)[0],
				raw: newValue.raw,
				value: newValue
			});
		}
	}, [filterBlock, updateFilterBlock]);
	const setFilterOperator = useCallback((operator) => {
		let valueObj = {};
		if (filterBlock.value && !ValueOperators.includes(operator)) {
			const updatedRaw = [];
			valueObj = { value: {
				values: filterBlock.value.values.map((v) => {
					const newValue = getUnescapedFilterValue(v.value)?.replace(/^[<>]=?/g, "").replaceAll("..", "") ?? "";
					updatedRaw.push(newValue);
					return {
						...v,
						value: newValue
					};
				}) ?? [],
				raw: updatedRaw.join(config.valueDelimiter)
			} };
		}
		updateFilterBlock({
			...filterBlock,
			operator,
			...valueObj
		});
	}, [
		config.valueDelimiter,
		filterBlock,
		updateFilterBlock
	]);
	const setFilterValues = useCallback((selected) => {
		let newValues = [];
		if (selected === void 0) newValues = [];
		else if (typeof selected === "boolean") newValues = [{
			value: selected.toString(),
			displayName: capitalize(selected.toString())
		}];
		else if (!filterBlock.provider?.options?.filterTypes.multiValue || !Array.isArray(selected)) {
			const itemValue = selected.text;
			const value = values.find((v) => v.displayName === itemValue || v.value === itemValue);
			if (value === void 0) return;
			newValues = [value];
		} else {
			const invisibleSelections = filterBlock.value?.values.filter((v) => !hasMatch(valuesFilter, getFilterValue(v.value) ?? "") && !hasMatch(valuesFilter, v.displayName ?? ""));
			if (invisibleSelections) newValues = invisibleSelections;
			for (const selectedItem of selected) {
				const foundValue = values.find((v) => v.displayName === selectedItem.text || v.value === selectedItem.text);
				if (foundValue) newValues.push(foundValue);
			}
		}
		newValues = newValues.filter((v) => v.value.length > 0);
		setSelectedFilteredValues(typeof selected === "boolean" ? void 0 : selected);
		updateFilterBlock({
			...filterBlock,
			value: {
				...filterBlock.value,
				raw: newValues.map((v) => getFilterValue(v.value)).join(config.valueDelimiter),
				values: newValues.map((v) => ({
					...v,
					valid: true
				}))
			}
		});
	}, [
		config.valueDelimiter,
		filterBlock,
		updateFilterBlock,
		values,
		valuesFilter
	]);
	const setFilterFrom = useCallback((e) => {
		const blockValues = [{
			value: e.target.value,
			valid: true
		}, filterBlock.value?.values?.[1] ?? {
			value: "",
			valid: true
		}];
		const raw = `${getFilterValue(blockValues[0]?.value)}..${getFilterValue(blockValues[1]?.value)}`;
		updateFilterBlock({
			...filterBlock,
			value: {
				values: blockValues,
				raw
			}
		});
	}, [filterBlock, updateFilterBlock]);
	const setFilterTo = useCallback((e) => {
		const blockValues = [filterBlock.value?.values?.[0] ?? {
			value: "",
			valid: true
		}, {
			value: e.target.value,
			valid: true
		}];
		const raw = `${getFilterValue(blockValues[0]?.value)}..${getFilterValue(blockValues[1]?.value)}`;
		updateFilterBlock({
			...filterBlock,
			value: {
				values: blockValues,
				raw
			}
		});
	}, [filterBlock, updateFilterBlock]);
	const setFilterText = useCallback((e) => {
		updateFilterBlock({
			...filterBlock,
			value: {
				values: [{
					value: e.target.value,
					valid: true
				}],
				raw: e.target.value
			}
		});
	}, [filterBlock, updateFilterBlock]);
	useEffect(() => {
		const getSuggestions = async () => {
			if (filterBlock.provider) {
				const suggestions = await filterBlock.provider.getSuggestions(filterQuery, {
					...filterBlock,
					value: {
						values: [{
							value: valuesFilter,
							valid: true
						}],
						raw: valuesFilter
					}
				}, config);
				setValues(suggestions ? suggestions.filter((suggestion) => suggestion.type !== FilterValueType.NoValue && !suggestion.displayName?.startsWith("Exclude")) : []);
			}
		};
		getSuggestions();
	}, [
		config,
		filterBlock,
		filterBlock.provider,
		filterQuery,
		valuesFilter
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("fieldset", {
		className: clsx(`advanced-filter-item-${index}`, AdvancedFilterItem_module_default.Box_0),
		...testIdProps("afd-filter-row"),
		children: [
			/* @__PURE__ */ jsx("legend", {
				className: AdvancedFilterItem_module_default.Box_1,
				children: /* @__PURE__ */ jsx("h2", { children: `Row ${index + 1}` })
			}),
			/* @__PURE__ */ jsx("span", {
				className: AdvancedFilterItem_module_default.Text_0,
				children: index + 1
			}),
			/* @__PURE__ */ jsxs("div", {
				className: AdvancedFilterItem_module_default.Box_2,
				children: [/* @__PURE__ */ jsxs("div", {
					className: AdvancedFilterItem_module_default.Box_3,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: AdvancedFilterItem_module_default.Box_4,
							children: [/* @__PURE__ */ jsx("span", {
								className: AdvancedFilterItem_module_default.Text_1,
								children: "Qualifier"
							}), /* @__PURE__ */ jsx(QualifierSelect, {
								filterBlock,
								index,
								filterProviders: amendedFilterProviders,
								setFilterProvider
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: AdvancedFilterItem_module_default.Box_4,
							children: [/* @__PURE__ */ jsx("span", {
								className: AdvancedFilterItem_module_default.Text_1,
								children: "Operator"
							}), /* @__PURE__ */ jsx(OperatorSelect, {
								setFilterOperator,
								filterBlock,
								index
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: AdvancedFilterItem_module_default.Box_4,
							children: [/* @__PURE__ */ jsx("span", {
								className: AdvancedFilterItem_module_default.Text_1,
								children: "Value"
							}), /* @__PURE__ */ jsx(ValueSelect, {
								filterBlock,
								index,
								setValuesFilter,
								valueElements,
								selectedFilteredValues,
								setFilterValues,
								setFilterFrom,
								setFilterText,
								setFilterTo
							})]
						}),
						/* @__PURE__ */ jsx(RemoveFilterButton, {
							onClick: () => deleteFilterBlock(index),
							ariaLabel: `Delete filter ${index + 1}: ${filterBlock.provider?.displayName ?? filterBlock.provider?.key}, ${filterBlock.operator}, ${filterBlock.value?.raw}`,
							testId: `afd-filter-row-delete-${index}`,
							className: AdvancedFilterItem_module_default.RemoveFilterButton_0
						})
					]
				}), /* @__PURE__ */ jsxs("div", {
					className: AdvancedFilterItem_module_default.Box_5,
					children: [/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(RemoveFilterButton, {
						onClick: () => deleteFilterBlock(index),
						ariaLabel: `Delete filter ${index + 1}: ${filterBlock.provider?.displayName ?? filterBlock.provider?.key}, ${filterBlock.operator}, ${filterBlock.value?.raw}`
					}) }), /* @__PURE__ */ jsx("div", {
						className: AdvancedFilterItem_module_default.Box_6,
						children: index + 1
					})]
				})]
			})
		]
	}), /* @__PURE__ */ jsx("div", {
		className: AdvancedFilterItem_module_default.Box_7,
		children: /* @__PURE__ */ jsx("div", { className: AdvancedFilterItem_module_default.Box_8 })
	})] });
};
AdvancedFilterItem.displayName = "AdvancedFilterItem";
var FilterList_module_default = {
	Box_0: "FilterList-module_R0WXPG_Box_0",
	Box_1: "FilterList-module_R0WXPG_Box_1",
	Box_2: "FilterList-module_R0WXPG_Box_2",
	Box_3: "FilterList-module_R0WXPG_Box_3",
	Box_4: "FilterList-module_R0WXPG_Box_4",
	Text_0: "FilterList-module_R0WXPG_Text_0"
};
var FilterList = ({ filterBlocks, filterProviders, updateFilterBlock, deleteFilterBlock, isNarrowBreakpoint, addFilterButtonMobileLastRowRef, addNewFilterBlock }) => {
	return /* @__PURE__ */ jsxs("div", {
		className: FilterList_module_default.Box_0,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: FilterList_module_default.Box_1,
				children: [
					/* @__PURE__ */ jsx("div", { className: FilterList_module_default.Box_2 }),
					/* @__PURE__ */ jsx("div", { className: FilterList_module_default.Box_3 }),
					/* @__PURE__ */ jsx("span", {
						className: FilterList_module_default.Box_3,
						children: "Qualifier"
					}),
					/* @__PURE__ */ jsx("span", {
						className: FilterList_module_default.Text_0,
						children: "Operator"
					}),
					/* @__PURE__ */ jsx("span", {
						className: FilterList_module_default.Box_3,
						children: "Value"
					}),
					/* @__PURE__ */ jsx("div", {})
				]
			}),
			filterBlocks.map((filterBlock, index) => /* @__PURE__ */ jsx(AdvancedFilterItem, {
				filterBlock,
				filterProviders,
				updateFilterBlock,
				index,
				deleteFilterBlock
			}, `advanced-filter-item-${index}`)),
			/* @__PURE__ */ jsx("div", {
				className: FilterList_module_default.Box_4,
				children: /* @__PURE__ */ jsx(AddFilterButton, {
					size: isNarrowBreakpoint ? "medium" : "small",
					ref: addFilterButtonMobileLastRowRef,
					filterProviders,
					addNewFilterBlock
				})
			})
		]
	});
};
FilterList.displayName = "FilterList";
var renumberBlocks = (blocks) => {
	return blocks.map((b, i) => ({
		...b,
		id: i
	}));
};
var getWithUpdatedRawValues = memoize((config) => {
	return (_current, updated) => updated.map((block) => {
		const raw = buildRawBlockString(block, config);
		return block.raw === raw ? block : {
			...block,
			raw
		};
	});
});
var AdvancedFilterDialog = ({ filterButtonVariant = "normal", isStandalone = false, dialogOpen, setDialogOpen }) => {
	const { config } = useFilter();
	const { filterQuery, filterProviders, updateFilter } = useFilterQuery();
	const { hideSuggestions } = useSuggestions();
	const buttonRef = useRef(null);
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const addFilterButtonRef = useRef(null);
	const addFilterButtonMobileRef = useRef(null);
	const addFilterButtonMobileLastRowRef = useRef(null);
	const isNarrowBreakpoint = useResponsiveValue({
		regular: false,
		narrow: true
	}, false);
	const amendedFilterBlocks = getMutableFilterBlocks(filterQuery.blocks);
	const [filterBlocks, setFilterBlocks] = useReducer(getWithUpdatedRawValues(config), amendedFilterBlocks);
	const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
	const confirm = useConfirm();
	const confirmUnsavedChanges = useCallback(async () => !hasUnsavedChanges || await confirm({
		...Strings.advancedFilterDialogCloseConfirmation,
		confirmButtonType: "danger"
	}), [confirm, hasUnsavedChanges]);
	const amendedFilterProviders = useMemo(() => {
		const filteredProviders = Object.values(filterProviders).filter((provider) => (provider.options.filterTypes.multiKey || filterBlocks.filter((block) => isMutableFilterBlock(block) && block.provider?.key === provider.key).length < 1) && provider.options.support.status === ProviderSupportStatus.Supported);
		if (!(config.disableAdvancedTextFilter && config.variant === "button")) filteredProviders.push(RawTextProvider);
		return filteredProviders.sort((a, b) => (a.displayName ?? a.key ?? "").localeCompare(b.displayName ?? b.key ?? ""));
	}, [
		config.disableAdvancedTextFilter,
		config.variant,
		filterBlocks,
		filterProviders
	]);
	const resetFilterBlocks = useCallback(() => {
		setFilterBlocks(amendedFilterBlocks);
		setHasUnsavedChanges(false);
	}, [amendedFilterBlocks]);
	const addNewFilterBlock = useCallback((provider) => {
		setFilterBlocks([...filterBlocks, {
			id: filterBlocks.length,
			type: BlockType.Filter,
			provider,
			key: getBlockKey(provider),
			operator: getAllFilterOperators(provider)[0],
			value: {
				raw: "",
				values: [{
					value: "",
					valid: true
				}]
			}
		}]);
		setHasUnsavedChanges(true);
		setTimeout(() => {
			const lastItem = document.querySelectorAll(`.advanced-filter-item-qualifier`);
			lastItem[lastItem.length - 1]?.focus();
		}, 10);
	}, [filterBlocks]);
	const updateFilterBlock = useCallback((filterBlock) => {
		setHasUnsavedChanges(true);
		setFilterBlocks(filterBlocks.map((block) => block.id === filterBlock.id ? filterBlock : block));
	}, [filterBlocks]);
	const deleteFilterBlock = useCallback((index) => {
		const newFilterBlocks = filterBlocks.filter((_, i) => i !== index);
		setFilterBlocks(renumberBlocks(newFilterBlocks));
		let focusingRef;
		if (isNarrowBreakpoint) focusingRef = newFilterBlocks.length > 0 ? addFilterButtonMobileLastRowRef : addFilterButtonMobileRef;
		else focusingRef = addFilterButtonRef;
		setTimeout(() => focusingRef.current?.focus(), 20);
	}, [filterBlocks, isNarrowBreakpoint]);
	const variant = isStandalone ? "button_only" : "button_and_input";
	const openDialog = useCallback(() => {
		resetFilterBlocks();
		hideSuggestions();
		setDialogOpen(true);
		sendClickAnalyticsEvent({
			action: "open_advanced_filter_dialog",
			label: `variant:${variant}`
		});
	}, [
		hideSuggestions,
		resetFilterBlocks,
		setDialogOpen,
		sendClickAnalyticsEvent,
		variant
	]);
	const closeDialog = useCallback(async (skipConfirmation) => {
		if (!skipConfirmation && !await confirmUnsavedChanges()) return;
		setDialogOpen(false);
		resetFilterBlocks();
		setTimeout(() => {
			buttonRef.current?.focus();
		}, 20);
	}, [
		confirmUnsavedChanges,
		setDialogOpen,
		resetFilterBlocks
	]);
	const sendApplyAnalyticsEvent = useCallback((query) => {
		const filtersUsed = query.filtersUsed.length > 0 ? query.filtersUsed.join(",") : "";
		sendClickAnalyticsEvent({
			action: "submit_filter_query",
			label: `variant:${variant};event_type:${SubmitEvent.DialogSubmit};used_filter_providers:${filtersUsed};nested_group_depth:${query.nestedGroupCount};submitted_by:filter_dialog`
		});
	}, [sendClickAnalyticsEvent, variant]);
	const applyFilterBlocks = useCallback(async () => {
		const unparsedFilter = filterBlocks.map(({ raw }) => raw).join(" ");
		updateFilter(unparsedFilter, unparsedFilter.length, sendApplyAnalyticsEvent, SubmitEvent.DialogSubmit);
		await closeDialog(true);
	}, [
		closeDialog,
		filterBlocks,
		sendApplyAnalyticsEvent,
		updateFilter
	]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ButtonComponent, {
		ref: buttonRef,
		onClick: openDialog,
		...testIdProps("advanced-filter-button"),
		"aria-label": "Advanced filter dialog",
		leadingVisual: FilterIcon,
		count: filterQuery.filterCount > 0 ? filterQuery.filterCount : void 0,
		className: clsx(AdvancedFilterDialog_module_default.Button_0, isStandalone && AdvancedFilterDialog_module_default.standaloneButton),
		children: filterButtonVariant === "normal" && "Filter"
	}), dialogOpen && /* @__PURE__ */ jsx(Dialog, {
		onClose: () => closeDialog(),
		role: "dialog",
		title: "Advanced filters",
		position: {
			narrow: "fullscreen",
			regular: "center"
		},
		renderFooter: () => /* @__PURE__ */ jsxs("div", {
			className: AdvancedFilterDialog_module_default.Box_0,
			children: [/* @__PURE__ */ jsx("div", {
				className: AdvancedFilterDialog_module_default.Box_1,
				children: /* @__PURE__ */ jsx(AddFilterButton, {
					size: isNarrowBreakpoint ? "medium" : "small",
					ref: addFilterButtonRef,
					filterProviders: amendedFilterProviders,
					addNewFilterBlock
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: AdvancedFilterDialog_module_default.Box_2,
				children: [/* @__PURE__ */ jsx(ButtonComponent, {
					size: isNarrowBreakpoint ? "medium" : "small",
					onClick: () => closeDialog(),
					...testIdProps("afd-cancel"),
					children: "Cancel"
				}), /* @__PURE__ */ jsx(ButtonComponent, {
					size: isNarrowBreakpoint ? "medium" : "small",
					variant: "primary",
					onClick: applyFilterBlocks,
					...testIdProps("afd-apply"),
					children: "Apply"
				})]
			})]
		}),
		renderBody: () => /* @__PURE__ */ jsx("div", {
			className: clsx("advanced-filter-dialog-content", AdvancedFilterDialog_module_default.Box_4, filterBlocks.length && AdvancedFilterDialog_module_default.nonEmpty),
			...testIdProps("advanced-filter-dialog-content"),
			children: /* @__PURE__ */ jsxs("div", {
				className: AdvancedFilterDialog_module_default.Box_3,
				children: [filterBlocks.length < 1 && /* @__PURE__ */ jsx(BlankState, {
					isNarrowBreakpoint,
					addFilterButtonMobileRef,
					filterProviders: amendedFilterProviders,
					addNewFilterBlock
				}), filterBlocks.length > 0 && /* @__PURE__ */ jsx(FilterList, {
					addFilterButtonMobileLastRowRef,
					addNewFilterBlock,
					deleteFilterBlock,
					filterBlocks,
					filterProviders: amendedFilterProviders,
					isNarrowBreakpoint,
					updateFilterBlock
				})]
			})
		})
	})] });
};
AdvancedFilterDialog.displayName = "AdvancedFilterDialog";
var ClearButton_module_default = { clearButton: "ClearButton-module_WFx5Qq_clearButton" };
var ClearButton = memo(() => {
	const { suspendFocus } = useInput();
	const { rawFilterRef, clearFilter } = useFilterQuery();
	if (rawFilterRef?.current.length === 0) return;
	return /* @__PURE__ */ jsx(IconButton, {
		...testIdProps("filter-clear-query"),
		as: "button",
		className: ClearButton_module_default.clearButton,
		"aria-label": "Clear filter",
		onMouseDown: (e) => suspendFocus(e.currentTarget),
		onKeyDown: (e) => suspendFocus(e.currentTarget),
		onClick: () => clearFilter(),
		icon: XCircleFillIcon,
		variant: "invisible",
		size: "small"
	});
});
ClearButton.displayName = "ClearButton";
ClearButton.displayName = "ClearButton";
var Filter_module_default = {
	Box_0: "Filter-module_DL7GAa_Box_0",
	Box_1: "Filter-module_DL7GAa_Box_1",
	Box_2: "Filter-module_DL7GAa_Box_2",
	hasSubmit: "Filter-module_DL7GAa_hasSubmit",
	leftRounded: "Filter-module_DL7GAa_leftRounded",
	rightRounded: "Filter-module_DL7GAa_rightRounded",
	trailingVisual: "Filter-module_DL7GAa_trailingVisual"
};
var FilterInputIcon_module_default = {
	Box_0: "FilterInputIcon-module_Re8FBG_Box_0",
	Octicon_0: "FilterInputIcon-module_Re8FBG_Octicon_0"
};
var FilterInputIcon = () => {
	return /* @__PURE__ */ jsx("div", {
		className: FilterInputIcon_module_default.Box_0,
		children: /* @__PURE__ */ jsx(SearchIcon, {
			"aria-label": "Search",
			className: FilterInputIcon_module_default.Octicon_0
		})
	});
};
FilterInputIcon.displayName = "FilterInputIcon";
var FilterInputWrapper_module_default = {
	Box_0: "FilterInputWrapper-module_ztaHvG_Box_0",
	Box_1: "FilterInputWrapper-module_ztaHvG_Box_1"
};
var FilterInputWrapper = ({ children, isStandalone = false }) => {
	if (isStandalone) return /* @__PURE__ */ jsx("div", {
		...testIdProps("filter-bar"),
		className: FilterInputWrapper_module_default.Box_0,
		children
	});
	return /* @__PURE__ */ jsx("div", {
		...testIdProps("filter-bar"),
		className: FilterInputWrapper_module_default.Box_1,
		children
	});
};
FilterInputWrapper.displayName = "FilterInputWrapper";
var Input_module_default = {
	Box_0: "Input-module_G4IQ6q_Box_0",
	Box_1: "Input-module_G4IQ6q_Box_1",
	Box_2: "Input-module_G4IQ6q_Box_2",
	Box_3: "Input-module_G4IQ6q_Box_3",
	Box_4: "Input-module_G4IQ6q_Box_4"
};
var StyledInput_module_default = {
	Box_0: "StyledInput-module_GrRTUW_Box_0",
	Box_1: "StyledInput-module_GrRTUW_Box_1",
	Box_2: "StyledInput-module_GrRTUW_Box_2",
	KeyBlock_0: "StyledInput-module_GrRTUW_KeyBlock_0"
};
var StyledInputBlocks_module_default = { Text_0: "StyledInputBlocks-module_IMT6xa_Text_0" };
var TextBlock = ({ text }) => /* @__PURE__ */ jsx("span", {
	className: "text-block",
	children: text
});
TextBlock.displayName = "TextBlock";
var SpaceBlock = ({ text }) => /* @__PURE__ */ jsx("span", {
	className: "delimiter space-delimiter",
	children: text
});
SpaceBlock.displayName = "SpaceBlock";
var Delimiter = ({ delimiter }) => /* @__PURE__ */ jsx("span", {
	className: "delimiter",
	children: delimiter
});
Delimiter.displayName = "Delimiter";
var KeywordBlock = ({ keyword }) => /* @__PURE__ */ jsx("span", {
	className: clsx("keyword-block", StyledInputBlocks_module_default.Text_0),
	children: keyword
});
KeywordBlock.displayName = "KeywordBlock";
var KeyBlock = ({ text, className }) => /* @__PURE__ */ jsx("span", {
	"data-type": "filter",
	className,
	children: text
});
KeyBlock.displayName = "KeyBlock";
var OneCharModifiers = [
	FilterOperator.GreaterThan,
	FilterOperator.LessThan,
	FilterOperator.Before,
	FilterOperator.After
];
var TwoCharModifiers = [
	FilterOperator.GreaterThanOrEqualTo,
	FilterOperator.LessThanOrEqualTo,
	FilterOperator.BeforeAndIncluding,
	FilterOperator.AfterAndIncluding
];
var StyledInput = () => {
	const { config } = useFilter();
	const { inputFocused, updateStyledInputBlockCount } = useInput();
	const { rawFilterRef, filterQuery } = useFilterQuery();
	const cachedNodesRef = useRef([]);
	const getValueElement = (element, blockValue, index, position) => {
		const { id, key, operator } = element;
		const { value, valid } = blockValue;
		if (valid) {
			let dynamicPosition = 0;
			if (OneCharModifiers.includes(operator)) dynamicPosition = 1;
			else if (TwoCharModifiers.includes(operator)) dynamicPosition = 2;
			const dynamicValueChar = getFilterValue(value)?.charAt(dynamicPosition);
			if (dynamicValueChar && DYNAMIC_VALUE_CHARS.includes(dynamicValueChar)) return /* @__PURE__ */ jsx("span", {
				"data-type": "filter-value",
				className: clsx(`valid-filter-value`, StyledInput_module_default.Box_0),
				children: getFilterValue(value)
			}, `filter-block-${index}-${key.value}-${position ? `${position}-` : ""}${getFilterValue(value)}`);
			else return /* @__PURE__ */ jsx("span", {
				"data-type": "filter-value",
				className: clsx(`valid-filter-value`, StyledInput_module_default.Box_1),
				children: getFilterValue(value)
			}, `filter-block-${index}-${key.value}-${position ? `${position}-` : ""}${getFilterValue(value)}`);
		} else if (valid !== void 0 && (valid === false && filterQuery.activeBlock?.id !== id || !inputFocused)) return /* @__PURE__ */ jsx("span", {
			"data-type": "filter-value",
			className: clsx(`invalid-filter-value`, StyledInput_module_default.Box_2),
			children: getFilterValue(value)
		}, `filter-block-${index}-${key.value}-${position ? `${position}-` : ""}${getFilterValue(value)}`);
		return /* @__PURE__ */ jsx("span", {
			"data-type": "filter-value",
			children: getFilterValue(value)
		}, `filter-block-${index}-${key.value}-${position ? `${position}-` : ""}${getFilterValue(value)}`);
	};
	const styledInput = useMemo(() => {
		const inputParts = [];
		if (!checkFilterQuerySync(filterQuery, rawFilterRef?.current)) return cachedNodesRef.current;
		function getStyledInputs(subBlocks, parentKey) {
			for (const [index, element] of subBlocks.entries()) {
				let queryItem;
				if (isFilterBlock(element)) {
					const { key, operator, value } = element;
					const isInvalidFilterValue = key.valid === false && (filterQuery.activeBlock?.id !== element.id || !inputFocused);
					const filterKey = /* @__PURE__ */ jsx(KeyBlock, {
						text: key.value,
						className: clsx(isInvalidFilterValue && StyledInput_module_default.KeyBlock_0)
					}, `filter-block-${index}-key`);
					const filterDelimiter = /* @__PURE__ */ jsx(Delimiter, { delimiter: config.filterDelimiter }, `filter-block-${index}-delimiter`);
					let filterValues = [];
					if (operator === FilterOperator.Between) {
						const value1 = value.values[0];
						const value2 = value.values[1];
						if (value1) filterValues.push(getValueElement(element, value1, index, 1));
						filterValues.push(/* @__PURE__ */ jsx("span", {
							className: `delimiter`,
							children: ".."
						}, `filter-block-${index}-${key.value}-delimiter-1`));
						if (value2) filterValues.push(getValueElement(element, value2, index, 2));
					} else filterValues = value.values.map((v, i) => {
						return /* @__PURE__ */ jsxs("span", { children: [i > 0 && /* @__PURE__ */ jsx("span", {
							className: `delimiter`,
							children: config.valueDelimiter
						}), getValueElement(element, v, index)] }, `filter-block-${index}-${key.value}-values-${i}}`);
					});
					queryItem = /* @__PURE__ */ jsxs("span", {
						"data-type": "filter-expression",
						children: [
							filterKey,
							filterDelimiter,
							filterValues
						]
					}, `filter-block-${parentKey}-${index}-${key.value}`);
				} else if (element.type === BlockType.Space) queryItem = /* @__PURE__ */ jsx(SpaceBlock, { text: element.raw }, `space-block-${parentKey}-${index}`);
				else if (element.type === BlockType.Keyword) queryItem = /* @__PURE__ */ jsx(KeywordBlock, { keyword: element.raw }, `keyword-block-${parentKey}-${index}`);
				else if (isIndexedGroupBlock(element)) {
					inputParts.push(/* @__PURE__ */ jsx(TextBlock, { text: "(" }, `text-open-${parentKey}-${index}`));
					getStyledInputs(element.blocks, parentKey ? `${parentKey}-${index}` : `${index}`);
					inputParts.push(/* @__PURE__ */ jsx(TextBlock, { text: ")" }, `text-close-${parentKey}-${index}`));
				} else queryItem = /* @__PURE__ */ jsx(TextBlock, { text: element.raw }, `text-block-${parentKey}-${index}`);
				inputParts.push(queryItem);
			}
		}
		getStyledInputs(filterQuery.blocks, "root");
		cachedNodesRef.current = inputParts;
		return inputParts;
	}, [
		filterQuery.raw,
		filterQuery.blocks,
		filterQuery.activeBlock,
		filterQuery.isValidated,
		inputFocused,
		config.filterDelimiter,
		config.valueDelimiter
	]);
	useEffect(() => {
		updateStyledInputBlockCount(styledInput.length);
	}, [styledInput.length, updateStyledInputBlockCount]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: styledInput });
};
StyledInput.displayName = "StyledInput";
var Input = ({ id, hasValidationMessage = false, placeholder = "Search or filter", onKeyDown }) => {
	const { suggestionsVisible, activeSuggestion, suggestionGroups } = useSuggestions();
	const { caretRef, inputFocused, inputKeyDown, inputOnBlur, inputOnCompositionStart, inputOnCompositionEnd, inputOnChange, inputOnFocus, inputRef, inputSelectionEnd, inputSelectionStart, inputValue, updateInputSelection } = useInput();
	const sizerRef = useRef(null);
	const [inputScrollLeft, setInputScrollLeft] = useState(0);
	const styledInputContainerRef = useRef(null);
	const checkCursorPosition = useCallback((el) => {
		updateInputSelection(el.selectionStart ?? 0, el.selectionEnd ?? 0);
	}, [updateInputSelection]);
	const onKeyDownHandler = useCallback((e) => {
		checkCursorPosition(e.currentTarget);
		inputKeyDown(e);
		onKeyDown?.(e);
	}, [
		checkCursorPosition,
		inputKeyDown,
		onKeyDown
	]);
	const onClickHandler = useCallback((e) => {
		checkCursorPosition(e.currentTarget);
	}, [checkCursorPosition]);
	const inputWidth = useMemo(() => {
		const currentSizerScrollWidth = sizerRef.current?.scrollWidth ?? 0;
		return `${Math.max(currentSizerScrollWidth + 2, 100)}px`;
	}, [
		inputSelectionStart,
		sizerRef.current?.scrollWidth,
		inputValue
	]);
	useLayoutEffect(() => {
		const cursor = caretRef.current;
		const styledInputContainer = styledInputContainerRef.current;
		if (cursor && styledInputContainer) if (cursor.offsetLeft < inputScrollLeft) setInputScrollLeft(cursor.offsetLeft - styledInputContainer.clientWidth - 100);
		else if (cursor.offsetLeft > inputScrollLeft + styledInputContainer.clientWidth) setInputScrollLeft(cursor.offsetLeft - styledInputContainer.clientWidth + 100);
		else styledInputContainer.scrollLeft = inputScrollLeft;
	}, [
		caretRef,
		inputScrollLeft,
		inputSelectionStart,
		inputValue
	]);
	const shadowInput = useMemo(() => {
		return /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx("span", { children: inputSelectionStart ? inputValue.substring(0, inputSelectionStart) : inputValue }),
			/* @__PURE__ */ jsx("span", {
				...testIdProps("filter-cursor"),
				ref: caretRef
			}),
			/* @__PURE__ */ jsx("span", { children: inputSelectionStart ? inputValue.substring(inputSelectionStart) : null })
		] });
	}, [
		caretRef,
		inputSelectionStart,
		inputValue
	]);
	const ariaExpandedValue = useMemo(() => {
		return suggestionsVisible && suggestionGroups.some((s) => s.suggestions.length > 0);
	}, [suggestionGroups, suggestionsVisible]);
	useEffect(() => {
		if (inputRef.current && inputSelectionStart > -1 && inputFocused) {
			inputRef.current.selectionStart = inputSelectionStart;
			inputRef.current.selectionEnd = inputSelectionEnd;
		}
	}, [
		inputRef,
		inputSelectionStart,
		inputSelectionEnd,
		inputValue
	]);
	return /* @__PURE__ */ jsxs("div", {
		...testIdProps("styled-input-container"),
		ref: styledInputContainerRef,
		tabIndex: -1,
		className: clsx("styled-input-container", Input_module_default.Box_0),
		children: [/* @__PURE__ */ jsx("div", {
			...testIdProps("styled-input-content"),
			"aria-hidden": "true",
			className: clsx("styled-input-content", Input_module_default.Box_1),
			children: /* @__PURE__ */ jsx(StyledInput, {})
		}), /* @__PURE__ */ jsxs("div", {
			...testIdProps("filter-input-wrapper"),
			className: Input_module_default.Box_2,
			children: [/* @__PURE__ */ jsx("div", {
				...testIdProps("filter-sizer"),
				ref: sizerRef,
				"aria-hidden": "true",
				className: Input_module_default.Box_3,
				children: shadowInput
			}), /* @__PURE__ */ jsx("input", {
				id: `${id}-input`,
				role: "combobox",
				"aria-expanded": ariaExpandedValue,
				"aria-autocomplete": "list",
				"aria-haspopup": "listbox",
				"aria-controls": `${id}-results`,
				"aria-activedescendant": activeSuggestion !== null && activeSuggestion !== -1 && suggestionsVisible ? `suggestion-${activeSuggestion}` : void 0,
				"aria-describedby": hasValidationMessage ? `${id}-validation-message` : "",
				placeholder,
				ref: inputRef,
				value: inputValue,
				onFocus: inputOnFocus,
				onBlur: inputOnBlur,
				onCompositionStart: inputOnCompositionStart,
				onCompositionEnd: inputOnCompositionEnd,
				onKeyDown: onKeyDownHandler,
				onClick: onClickHandler,
				onChange: inputOnChange,
				name: `${id}-inputname`,
				autoComplete: "off",
				spellCheck: "false",
				style: { width: inputWidth },
				className: Input_module_default.Box_4,
				...testIdProps("filter-input")
			})]
		})]
	});
};
Input.displayName = "Input";
var SubmitButton_module_default = { IconButton_0: "SubmitButton-module_MOmmva_IconButton_0" };
var SubmitButton = () => {
	const { onSubmit } = useFilterQuery();
	return /* @__PURE__ */ jsx(IconButton, {
		"aria-label": "Search",
		size: "medium",
		icon: SearchIcon,
		variant: "default",
		onClick: () => {
			onSubmit(SubmitEvent.ExplicitSubmit, "input_with_button");
		},
		className: SubmitButton_module_default.IconButton_0
	});
};
SubmitButton.displayName = "SubmitButton";
var SuggestionItem_module_default = {
	ActionList_Description: "SuggestionItem-module_a7sD2a_ActionList_Description",
	boldText: "SuggestionItem-module_a7sD2a_boldText",
	Box_0: "SuggestionItem-module_a7sD2a_Box_0",
	Box_1: "SuggestionItem-module_a7sD2a_Box_1",
	displayName: "SuggestionItem-module_a7sD2a_displayName",
	GitHubAvatar_0: "SuggestionItem-module_a7sD2a_GitHubAvatar_0",
	item: "SuggestionItem-module_a7sD2a_item",
	normalText: "SuggestionItem-module_a7sD2a_normalText"
};
var SuggestionItem = (suggestion) => {
	const { suggestionId, active, value, type, description, displayName, displayNameHtml, inlineDescription, ariaLabel } = suggestion;
	const { suggestionSelected, activeSuggestionRef } = useSuggestions();
	const { inputRef } = useInput();
	const { filterProviders, filterQuery } = useFilterQuery();
	const provider = (() => {
		if (type === FilterValueType.Key) {
			const rawValue = getFilterValue(value) ?? "";
			return filterProviders[rawValue.startsWith("-") ? rawValue.slice(1) : rawValue];
		}
		if (type === "keyword") return void 0;
		const activeBlock = filterQuery.activeBlock;
		return activeBlock && isIndexedFilterBlock(activeBlock) ? activeBlock.provider : void 0;
	})();
	const renderValueVisual = type === FilterValueType.Key ? void 0 : provider?.options.renderValueVisual;
	const customLeadingVisual = renderValueVisual ? renderValueVisual(suggestion) ?? null : null;
	const resolvedLeadingVisual = resolveValueVisualDescriptor(renderValueVisual ? customLeadingVisual : getDefaultValueVisualDescriptors(suggestion, provider?.icon), provider?.icon);
	const onSuggestionSelectHandler = useCallback(() => {
		suggestionSelected(suggestion);
		inputRef.current?.focus();
	}, [
		inputRef,
		suggestion,
		suggestionSelected
	]);
	const setActiveSuggestionRef = useCallback((node) => {
		if (active && node) {
			activeSuggestionRef.current = node;
			node.scrollIntoView({ block: "nearest" });
		} else activeSuggestionRef.current = null;
	}, [active, activeSuggestionRef]);
	const displayNameClass = clsx(SuggestionItem_module_default.displayName, description ? SuggestionItem_module_default.boldText : SuggestionItem_module_default.normalText);
	const renderSuggestionVisual = (visual) => {
		if (visual.kind === "avatar") return /* @__PURE__ */ jsx(GitHubAvatar, {
			src: visual.url,
			alt: visual.alt,
			square: visual.square ?? false,
			className: SuggestionItem_module_default.GitHubAvatar_0
		});
		if (visual.kind === "color-swatch") return /* @__PURE__ */ jsx("div", {
			style: { backgroundColor: visual.color },
			className: SuggestionItem_module_default.Box_1
		});
		const cssIconColor = visual.color ?? "currentcolor";
		const VisualIcon = visual.icon;
		return /* @__PURE__ */ jsx(VisualIcon, { fill: cssIconColor });
	};
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		id: `suggestion-${suggestionId}`,
		onSelect: onSuggestionSelectHandler,
		active,
		role: "option",
		"aria-label": ariaLabel,
		"aria-selected": active,
		tabIndex: -1,
		"aria-labelledby": void 0,
		ref: setActiveSuggestionRef,
		className: SuggestionItem_module_default.item,
		children: [
			resolvedLeadingVisual ? /* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx("div", {
				className: SuggestionItem_module_default.Box_0,
				children: renderSuggestionVisual(resolvedLeadingVisual)
			}) }) : null,
			displayNameHtml !== void 0 ? /* @__PURE__ */ jsx(VerifiedHTMLText, {
				html: displayNameHtml,
				className: displayNameClass
			}) : /* @__PURE__ */ jsx("span", {
				className: displayNameClass,
				children: displayName ?? getFilterValue(value) ?? ""
			}),
			description && inlineDescription !== void 0 && /* @__PURE__ */ jsx(ActionList.Description, {
				variant: inlineDescription ? "inline" : "block",
				className: SuggestionItem_module_default.ActionList_Description,
				truncate: !!inlineDescription,
				children: description
			})
		]
	});
};
SuggestionItem.displayName = "SuggestionItem";
var SuggestionsList_module_default = {
	ActionList_0: "SuggestionsList-module_H6a0Sa_ActionList_0",
	Box_0: "SuggestionsList-module_H6a0Sa_Box_0",
	Box_1: "SuggestionsList-module_H6a0Sa_Box_1",
	Box_3: "SuggestionsList-module_H6a0Sa_Box_3",
	showOverlay: "SuggestionsList-module_H6a0Sa_showOverlay"
};
var SuggestionsList = ({ id }) => {
	const { id: filterContextId } = useFilter();
	id = id ?? filterContextId;
	const { suggestionsListRef, activeSuggestion, isFetchingSuggestions, position, suggestionGroups, suggestionsVisible } = useSuggestions();
	const { suspendFocus } = useInput();
	const skeletonRow = (key, animationStyle = "wave") => {
		return /* @__PURE__ */ jsxs("div", {
			className: SuggestionsList_module_default.Box_0,
			children: [/* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "elliptical",
				width: "20px",
				height: "20px",
				animationStyle
			}), /* @__PURE__ */ jsx(LoadingSkeleton, {
				variant: "rounded",
				width: "random",
				height: "16px",
				animationStyle
			})]
		}, key);
	};
	const blankSlateSkeletons = useMemo(() => /* @__PURE__ */ jsx("div", { children: Array(8).fill(1).map((_, i) => skeletonRow(`loading-skeleton-${i}`)) }), []);
	const partialResultSkeletons = useMemo(() => skeletonRow(`prefetched-loading-skeleton`, "pulse"), []);
	const showSuggestionsOverlay = suggestionsVisible && suggestionGroups.some((s) => s.suggestions.length > 0) || isFetchingSuggestions;
	const generatedSuggestions = useMemo(() => {
		let rowIndex = -1;
		const renderedSuggestions = [];
		suggestionGroups.map((suggestionGroup, groupIndex) => {
			if (suggestionGroup.suggestions.length > 0) {
				renderedSuggestions.push(/* @__PURE__ */ jsxs(ActionList.Group, { children: [suggestionGroup.title && /* @__PURE__ */ jsx(ActionList.GroupHeading, {
					...testIdProps("suggestions-heading"),
					"aria-hidden": "true",
					children: suggestionGroup.title
				}), suggestionGroup.suggestions.map((suggestion) => {
					rowIndex++;
					return /* @__PURE__ */ jsx(SuggestionItem, {
						...suggestion,
						suggestionId: rowIndex,
						active: rowIndex === activeSuggestion
					}, getUniqueReactKey("suggestion", suggestion.id, `${getFilterValue(suggestion.value)}-${suggestion.displayName}-${suggestion.description}`));
				})] }, getUniqueReactKey("group", suggestionGroup.id)));
				if (groupIndex++ < suggestionGroups.length - 1 && (suggestionGroups[groupIndex++]?.suggestions ?? []).length > 0) renderedSuggestions.push(/* @__PURE__ */ jsx(ActionList.Divider, {}, getUniqueReactKey("divider", suggestionGroup.id)));
			}
		});
		return renderedSuggestions;
	}, [activeSuggestion, suggestionGroups]);
	return /* @__PURE__ */ jsx("div", {
		className: SuggestionsList_module_default.Box_1,
		...testIdProps("backdrop-anchor"),
		children: /* @__PURE__ */ jsx("div", {
			id: `${id}-suggestions`,
			ref: suggestionsListRef,
			className: clsx(SuggestionsList_module_default.Box_3, showSuggestionsOverlay && SuggestionsList_module_default.showOverlay),
			style: { left: `${position ? position.left : 0}px` },
			children: /* @__PURE__ */ jsxs(ActionList, {
				...testIdProps("filter-results"),
				"aria-label": isFetchingSuggestions ? "Loading Suggestions" : "Suggestions",
				role: "listbox",
				id: `${id}-results`,
				className: SuggestionsList_module_default.ActionList_0,
				onMouseDown: (e) => suspendFocus(e.currentTarget),
				children: [showSuggestionsOverlay && suggestionGroups.some((s) => s.suggestions.length > 0) && generatedSuggestions, showSuggestionsOverlay && isFetchingSuggestions && /* @__PURE__ */ jsx("div", { children: suggestionGroups.some((s) => s.suggestions.length > 0) ? partialResultSkeletons : blankSlateSkeletons })]
			})
		})
	});
};
SuggestionsList.displayName = "SuggestionsList";
var ValidationMessage_module_default = {
	Banner: "ValidationMessage-module_Q7DkSG_Banner",
	Box_0: "ValidationMessage-module_Q7DkSG_Box_0",
	Box_2: "ValidationMessage-module_Q7DkSG_Box_2",
	VerifiedHTMLBox_0: "ValidationMessage-module_Q7DkSG_VerifiedHTMLBox_0"
};
var ValidationMessage = ({ id, messages }) => {
	const { sendAnalyticsEvent } = useAnalytics();
	useEffect(() => {
		if (messages && messages.length > 0) {
			const userFriendlyMessage = messages.map((s) => s.replaceAll(/<pre>|<\/pre>/g, "'")).join(". ").trim();
			announce$1(`${Strings.filterInvalid(messages.length)} ${userFriendlyMessage}.`);
			sendAnalyticsEvent("filter.validation_errors", "FILTER_VALIDATION_ERRORS", { messages: userFriendlyMessage });
		}
	}, [sendAnalyticsEvent, messages]);
	if (!messages || messages.length < 1) return null;
	return /* @__PURE__ */ jsxs(Banner, {
		id,
		variant: "warning",
		className: ValidationMessage_module_default.Banner,
		children: [/* @__PURE__ */ jsx(Banner.Title, { children: /* @__PURE__ */ jsx("span", {
			...testIdProps("validation-error-count"),
			children: Strings.filterInvalid(messages.length)
		}) }), /* @__PURE__ */ jsx("div", {
			className: ValidationMessage_module_default.Box_0,
			children: /* @__PURE__ */ jsx("ul", {
				className: ValidationMessage_module_default.Box_2,
				...testIdProps("validation-error-list"),
				children: messages.map((message) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(UnsafeHTMLText, {
					html: message,
					domPurifyConfig: {
						ALLOWED_TAGS: ["pre"],
						ALLOWED_ATTR: [],
						ALLOW_DATA_ATTR: false
					},
					className: ValidationMessage_module_default.VerifiedHTMLBox_0
				}) }, message.replaceAll(" ", "-")))
			})
		})]
	});
};
ValidationMessage.displayName = "ValidationMessage";
var FilterRevert_module_default = {
	Link_0: "FilterRevert-module_mjzJwq_Link_0",
	Octicon_0: "FilterRevert-module_mjzJwq_Octicon_0"
};
var FilterRevert = ({ className, as, onClick, href }) => {
	return /* @__PURE__ */ jsxs(Link, {
		...testIdProps("filter-revert-query"),
		as: as || "a",
		href,
		onClick,
		className: clsx(className, FilterRevert_module_default.Link_0),
		children: [/* @__PURE__ */ jsx(UndoIcon, { className: FilterRevert_module_default.Octicon_0 }), "Revert filter changes"]
	});
};
FilterRevert.displayName = "FilterRevert";
var defaultFilterQuery = new FilterQuery();
var FilterInternal = ({ advancedFilterDialogRef, className, context, customParser, "data-testid": dataTestId, filterButtonVariant = "normal", filterValue, id, initialFilterValue, inputRef, label, onChange, onParse, onSubmit, onKeyDown, onValidation, placeholder, providers, settings, showClearButton = true, showValidationMessage = true, trailingVisual, variant = "full", visuallyHideLabel = true }) => {
	const [validationMessage, setValidationMessage] = useState([]);
	const hasValidationMessage = showValidationMessage && validationMessage.length > 0;
	const validationCallback = useCallback((messages = [], filterQuery = defaultFilterQuery) => {
		if (JSON.stringify(validationMessage) !== JSON.stringify(messages)) setValidationMessage(messages);
		onValidation?.(messages, filterQuery);
	}, [onValidation, validationMessage]);
	const filterButtonResponsive = useResponsiveValue({
		regular: filterButtonVariant,
		narrow: variant === "button" ? "normal" : "compact"
	}, filterButtonVariant);
	const externallyControlled = typeof filterValue === "string";
	const [innerValue, setInnerValue] = useState(initialFilterValue || "");
	const changeCallback = useCallback((value) => {
		if (!externallyControlled) setInnerValue(value);
		onChange?.(value);
	}, [externallyControlled, onChange]);
	const leftRounded = variant === "input";
	const rightRounded = variant === "input" && !onSubmit || variant !== "input" && !onSubmit;
	const [isAdvancedFilterDialogOpen, setIsAdvancedFilterDialogOpen] = useState(false);
	useImperativeHandle(advancedFilterDialogRef, () => ({
		isAdvancedFilterDialogOpen,
		toggleAdvancedFilterDialog: (open) => setIsAdvancedFilterDialogOpen(open ?? !isAdvancedFilterDialogOpen)
	}), [isAdvancedFilterDialogOpen]);
	return /* @__PURE__ */ jsx(FilterContextProvider, {
		context,
		customParser,
		inputRef,
		rawFilter: externallyControlled ? filterValue : innerValue,
		onChange: changeCallback,
		onParse,
		onSubmit,
		onValidation: validationCallback,
		providers,
		settings: {
			...defaultFilterSettings,
			...settings
		},
		variant,
		children: /* @__PURE__ */ jsxs("div", {
			id,
			role: "form",
			"aria-label": label,
			className: clsx("FormControl FormControl--fullWidth", className, Filter_module_default.Box_1),
			...testIdProps(dataTestId ?? "filter"),
			children: [/* @__PURE__ */ jsx("label", {
				id: `${id}-label`,
				htmlFor: `${id}-input`,
				className: `FormControl-label ${visuallyHideLabel ? "sr-only" : ""}`,
				...testIdProps("filter-bar-label"),
				children: label
			}), /* @__PURE__ */ jsxs("div", {
				className: Filter_module_default.Box_0,
				children: [
					/* @__PURE__ */ jsxs(FilterInputWrapper, {
						isStandalone: variant === "button",
						children: [variant !== "input" && /* @__PURE__ */ jsx(AdvancedFilterDialog, {
							isStandalone: variant === "button",
							filterButtonVariant: filterButtonResponsive,
							dialogOpen: isAdvancedFilterDialogOpen,
							setDialogOpen: setIsAdvancedFilterDialogOpen
						}), variant !== "button" && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
							className: clsx(Filter_module_default.Box_2, leftRounded && Filter_module_default.leftRounded, rightRounded && Filter_module_default.rightRounded, onSubmit && Filter_module_default.hasSubmit),
							children: [
								!onSubmit && /* @__PURE__ */ jsx(FilterInputIcon, {}),
								/* @__PURE__ */ jsx(Input, {
									id,
									placeholder,
									onKeyDown,
									hasValidationMessage
								}),
								trailingVisual && /* @__PURE__ */ jsx("div", {
									className: Filter_module_default.trailingVisual,
									children: trailingVisual
								}),
								showClearButton && /* @__PURE__ */ jsx(ClearButton, {})
							]
						}), onSubmit && /* @__PURE__ */ jsx(SubmitButton, {})] })]
					}),
					/* @__PURE__ */ jsx(SuggestionsList, { id }),
					showValidationMessage && /* @__PURE__ */ jsx(ValidationMessage, {
						messages: validationMessage,
						id: `${id}-validation-message`
					})
				]
			})]
		})
	});
};
FilterInternal.displayName = "FilterInternal";
var analyticsMetadata = {};
var Filter = (props) => /* @__PURE__ */ jsx(AnalyticsProvider, {
	appName: "shared_components",
	category: "filter",
	metadata: analyticsMetadata,
	children: /* @__PURE__ */ jsx(FilterInternal, { ...props })
});
Filter.displayName = "Filter";
Filter.displayName = "Filter";
export { Filter as t };
