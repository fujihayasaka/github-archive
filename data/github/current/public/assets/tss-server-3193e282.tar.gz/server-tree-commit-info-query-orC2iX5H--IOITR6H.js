performance.mark("js-parse-end:server-tree-commit-info-query-orC2iX5H--IOITR6H.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
performance.mark("js-parse-end:tree-commit-info-query-orC2iX5H.js");
var treeCommitInfoServerFn_createServerFn_handler = createServerRpc({
	id: "1900fd1372f2c4547c9dabe0cb6c502a5f5cba01a8e66c69a6397b1bad093695",
	name: "treeCommitInfoServerFn",
	filename: "src/routes/code-view/queries/tree-commit-info-query.ts"
}, (opts) => treeCommitInfoServerFn.__executeServer(opts));
var treeCommitInfoServerFn = createServerFn().inputValidator(queryValidator.base).handler(treeCommitInfoServerFn_createServerFn_handler, async ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		metricTag: "dr_treeCommitInfo"
	});
});
export { treeCommitInfoServerFn_createServerFn_handler };
