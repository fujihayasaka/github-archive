import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Ir as SkipIcon, Tn as LockIcon, a as AlertFillIcon, an as IconButton, bn as Link, fn as IssueOpenedIcon, gr as RepoIcon, hi as TriangleDownIcon, u as ArrowLeftIcon, un as IssueClosedIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { l as useItemPickersContext, r as ItemPicker, s as getIssueSearchQueries, t as ERRORS } from "./server-ItemPicker-ILw4RsMA-BLDIejLk.js";
import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { n as clientSideRelayFetchQueryRetained } from "./server-relay-environment-37zIk8_--Ci7dtWT_.js";
import { useCallback, useEffect, useEffectEvent, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var node$11 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "ids"
	}], v1 = [{
		"kind": "Variable",
		"name": "ids",
		"variableName": "ids"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "title",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "state",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "stateReason",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"concreteType": "Repository",
		"kind": "LinkedField",
		"name": "repository",
		"plural": false,
		"selections": [v2, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "nameWithOwner",
			"storageKey": null
		}],
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "number",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "url",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "IssuePickerSelectedIssuesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "nodes",
				"plural": true,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [
						v2,
						v3,
						v4,
						v5,
						v6,
						v7,
						v8,
						v9,
						v10
					],
					"type": "Issue",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "IssuePickerSelectedIssuesQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "nodes",
				"plural": true,
				"selections": [
					v10,
					v2,
					{
						"kind": "InlineFragment",
						"selections": [
							v3,
							v4,
							v5,
							v6,
							v7,
							v8,
							v9
						],
						"type": "Issue",
						"abstractKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "ab7e8eddc2f0411413899568c6f97ae4",
			"metadata": {},
			"name": "IssuePickerSelectedIssuesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$11.hash = "c4d195f7754769a3937a686385b27e39";
var node$10 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "IssuePickerIssue",
		"selections": [
			v0,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "title",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "state",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "stateReason",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [v0, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "nameWithOwner",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "databaseId",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "number",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__typename",
				"storageKey": null
			}
		],
		"type": "Issue",
		"abstractKey": null
	};
})();
node$10.hash = "196c5dfa10bac249c09a7e5a825a3eb9";
var LABELS = {
	noAssignees: "Assignee",
	assignees: "Assignees",
	assigneesHeader: "Select assignees",
	cantEditItems: (itemType) => `Cannot edit ${itemType} right now`,
	copilotDisplayName: "Copilot",
	copilotDescription: "Your AI pair programmer",
	noLabels: "Label",
	labels: "Labels",
	labelsHeader: "Apply labels to this issue",
	editLabels: "Edit labels",
	noProjects: "Project",
	noMilestones: "Milestone",
	milestonesHeader: "Set milestone",
	issueHeader: "Choose issue",
	noIssues: "Issue",
	noIssueTypes: "Issue type",
	filterOrganizations: "Filter organizations",
	organizationLabel: "Organization",
	selectAssignees: "Select assignees",
	selectMilestones: "Select milestone",
	selectIssue: "Select issue",
	selectIssueTypes: "Select issue type",
	typesHeader: "Select issue type",
	fieldsHeader: "Select issue field",
	fieldSingleSelectHeader: "Select an option",
	fieldSingleSelectHeaderWithName: (fieldName) => `Select ${fieldName}`,
	selectProjects: "Select projects",
	selectLabels: "Select labels",
	selectRepository: "Select repository",
	selectBranch: "Select a branch",
	selectPr: "Select a pull request",
	searchPr: "Search pull requests",
	maxPRsLinkingWarning: "You may only link 10 pull requests to this issue across all repositories.",
	filterUsers: (title) => `Filter ${title.toLowerCase()}s`,
	filterMilestones: "Filter milestones",
	filterIssueTypes: "Filter issue types",
	filterProjects: "Filter projects",
	noPullRequest: "no pull request",
	milestones: {
		pastDue: "Past due by",
		milestoneClosed: "Closed",
		milestoneDue: "Due by",
		noDueDate: "No due date",
		progressPercentage: (progress) => progress ? `, ${Math.round(progress)}% complete` : ", not started"
	},
	testIds: { relativeTimeDescription: "relative-time-description" },
	getNumberOfSelectedPrsLabel: (count) => count === 1 ? `${count} pull request selected` : `${count} pull requests selected`,
	projectItemsLimitReached: "This project has reached the maximum of 50,000 items. To add more, please delete existing items from the project.",
	closeButton: "Close dialog",
	projectItemsLimitReachedDialogLabel: "Project items limit reached dialog",
	projectItemsLimitReachedDialogTitle: "Project limits reached",
	projectItemsLimitReachedDialogMessage: "One or more of the projects you selected has reached the maximum of 50,000 items. To add more, please delete existing items from the selected project(s).",
	limitWarning: (count) => count === 1 ? `You have reached the limit of ${count} assignee` : `You have reached the limit of ${count} assignees`
};
var ErrorWithRetry_module_default = {
	errorAlertIcon: "ErrorWithRetry-module_K45ALG_errorAlertIcon",
	errorMessage: "ErrorWithRetry-module_K45ALG_errorMessage",
	ErrorWithRetryContainer: "ErrorWithRetry-module_K45ALG_ErrorWithRetryContainer",
	retryActionLink: "ErrorWithRetry-module_K45ALG_retryActionLink"
};
function ErrorWithRetry({ message, retry, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(ErrorWithRetry_module_default.ErrorWithRetryContainer, className),
		children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Octicon, {
			icon: AlertFillIcon,
			className: clsx("mr-1", ErrorWithRetry_module_default.errorAlertIcon)
		}), /* @__PURE__ */ jsx("span", {
			className: ErrorWithRetry_module_default.errorMessage,
			children: message
		})] }), /* @__PURE__ */ jsx(Link, {
			as: "button",
			inline: true,
			onClick: retry,
			className: ErrorWithRetry_module_default.retryActionLink,
			children: /* @__PURE__ */ jsx("span", {
				className: ErrorWithRetry_module_default.retryActionLink,
				children: "Try again"
			})
		})]
	});
}
ErrorWithRetry.displayName = "ErrorWithRetry";
var useItemPickerErrorFallback_module_default = {
	errorOverlayContainer: "useItemPickerErrorFallback-module_Ug2fkW_errorOverlayContainer",
	errorWithRetry: "useItemPickerErrorFallback-module_Ug2fkW_errorWithRetry"
};
function useItemPickerErrorFallback(t0) {
	const $ = c(6);
	const { errorMessage, anchorElement, open: t1 } = t0;
	const [errorOverlayOpened, setErrorOverlayOpened] = useState(t1 === void 0 ? false : t1);
	let t2;
	if ($[0] !== anchorElement || $[1] !== errorMessage || $[2] !== errorOverlayOpened) {
		t2 = (retry) => {
			if (!anchorElement) return null;
			return jsx(AnchoredOverlay, {
				width: "medium",
				height: "small",
				open: errorOverlayOpened,
				onOpen: () => setErrorOverlayOpened(true),
				onClose: () => setErrorOverlayOpened(false),
				renderAnchor: anchorElement,
				children: jsx("div", {
					className: useItemPickerErrorFallback_module_default.errorOverlayContainer,
					children: jsx(ErrorWithRetry, {
						message: errorMessage,
						retry,
						className: useItemPickerErrorFallback_module_default.errorWithRetry
					})
				})
			});
		};
		$[0] = anchorElement;
		$[1] = errorMessage;
		$[2] = errorOverlayOpened;
		$[3] = t2;
	} else t2 = $[3];
	const createFallbackComponent = t2;
	let t3;
	if ($[4] !== createFallbackComponent) {
		t3 = { createFallbackComponent };
		$[4] = createFallbackComponent;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
var node$9 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "assignee"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "author"
	}, v2 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "commenters"
	}, v3 = {
		"defaultValue": 10,
		"kind": "LocalArgument",
		"name": "first"
	}, v4 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "mentions"
	}, v5 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "other"
	}, v6 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "queryIsUrl"
	}, v7 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "resource"
	}, v8 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "withParent"
	}, v9 = {
		"kind": "Variable",
		"name": "first",
		"variableName": "first"
	}, v10 = {
		"kind": "Literal",
		"name": "type",
		"value": "ISSUE"
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v12 = [v11], v13 = [
		{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "__typename",
			"storageKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": [
				v11,
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "title",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "state",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "stateReason",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"concreteType": "Repository",
					"kind": "LinkedField",
					"name": "repository",
					"plural": false,
					"selections": [v11, {
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "nameWithOwner",
						"storageKey": null
					}],
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "databaseId",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "number",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "url",
					"storageKey": null
				},
				{
					"condition": "withParent",
					"kind": "Condition",
					"passingValue": true,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "Issue",
						"kind": "LinkedField",
						"name": "parent",
						"plural": false,
						"selections": v12,
						"storageKey": null
					}]
				}
			],
			"type": "Issue",
			"abstractKey": null
		},
		{
			"kind": "InlineFragment",
			"selections": v12,
			"type": "Node",
			"abstractKey": "__isNode"
		}
	], v14 = [{
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "nodes",
		"plural": true,
		"selections": v13,
		"storageKey": null
	}];
	return {
		"fragment": {
			"argumentDefinitions": [
				v0,
				v1,
				v2,
				v3,
				v4,
				v5,
				v6,
				v7,
				v8
			],
			"kind": "Fragment",
			"metadata": null,
			"name": "useIssueFilteringQuery",
			"selections": [{
				"args": null,
				"kind": "FragmentSpread",
				"name": "useIssueFilteringFragment"
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [
				v2,
				v4,
				v0,
				v1,
				v5,
				v3,
				v7,
				v6,
				v8
			],
			"kind": "Operation",
			"name": "useIssueFilteringQuery",
			"selections": [
				{
					"alias": "commenters",
					"args": [
						v9,
						{
							"kind": "Variable",
							"name": "query",
							"variableName": "commenters"
						},
						v10
					],
					"concreteType": "SearchResultItemConnection",
					"kind": "LinkedField",
					"name": "search",
					"plural": false,
					"selections": v14,
					"storageKey": null
				},
				{
					"alias": "mentions",
					"args": [
						v9,
						{
							"kind": "Variable",
							"name": "query",
							"variableName": "mentions"
						},
						v10
					],
					"concreteType": "SearchResultItemConnection",
					"kind": "LinkedField",
					"name": "search",
					"plural": false,
					"selections": v14,
					"storageKey": null
				},
				{
					"alias": "assignee",
					"args": [
						v9,
						{
							"kind": "Variable",
							"name": "query",
							"variableName": "assignee"
						},
						v10
					],
					"concreteType": "SearchResultItemConnection",
					"kind": "LinkedField",
					"name": "search",
					"plural": false,
					"selections": v14,
					"storageKey": null
				},
				{
					"alias": "author",
					"args": [
						v9,
						{
							"kind": "Variable",
							"name": "query",
							"variableName": "author"
						},
						v10
					],
					"concreteType": "SearchResultItemConnection",
					"kind": "LinkedField",
					"name": "search",
					"plural": false,
					"selections": v14,
					"storageKey": null
				},
				{
					"alias": "other",
					"args": [
						v9,
						{
							"kind": "Variable",
							"name": "query",
							"variableName": "other"
						},
						v10
					],
					"concreteType": "SearchResultItemConnection",
					"kind": "LinkedField",
					"name": "search",
					"plural": false,
					"selections": v14,
					"storageKey": null
				},
				{
					"condition": "queryIsUrl",
					"kind": "Condition",
					"passingValue": true,
					"selections": [{
						"alias": null,
						"args": [{
							"kind": "Variable",
							"name": "url",
							"variableName": "resource"
						}],
						"concreteType": null,
						"kind": "LinkedField",
						"name": "resource",
						"plural": false,
						"selections": v13,
						"storageKey": null
					}]
				}
			]
		},
		"params": {
			"id": "0461d285f545c937fe73e13b494d2ac0",
			"metadata": {},
			"name": "useIssueFilteringQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$9.hash = "85841f601364e1e7fcbbc0b1d97a1f38";
var node$8 = (function() {
	var v0 = {
		"kind": "Variable",
		"name": "first",
		"variableName": "first"
	}, v1 = {
		"kind": "Literal",
		"name": "type",
		"value": "ISSUE"
	}, v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v3 = [{
		"kind": "InlineFragment",
		"selections": [
			v2,
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "title",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "state",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "stateReason",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [v2, {
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "nameWithOwner",
					"storageKey": null
				}],
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "databaseId",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "number",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "url",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "__typename",
				"storageKey": null
			},
			{
				"condition": "withParent",
				"kind": "Condition",
				"passingValue": true,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": "Issue",
					"kind": "LinkedField",
					"name": "parent",
					"plural": false,
					"selections": [v2],
					"storageKey": null
				}]
			}
		],
		"type": "Issue",
		"abstractKey": null
	}], v4 = [{
		"alias": null,
		"args": null,
		"concreteType": null,
		"kind": "LinkedField",
		"name": "nodes",
		"plural": true,
		"selections": v3,
		"storageKey": null
	}];
	return {
		"argumentDefinitions": [
			{
				"kind": "RootArgument",
				"name": "assignee"
			},
			{
				"kind": "RootArgument",
				"name": "author"
			},
			{
				"kind": "RootArgument",
				"name": "commenters"
			},
			{
				"kind": "RootArgument",
				"name": "first"
			},
			{
				"kind": "RootArgument",
				"name": "mentions"
			},
			{
				"kind": "RootArgument",
				"name": "other"
			},
			{
				"kind": "RootArgument",
				"name": "queryIsUrl"
			},
			{
				"kind": "RootArgument",
				"name": "resource"
			},
			{
				"kind": "RootArgument",
				"name": "withParent"
			}
		],
		"kind": "Fragment",
		"metadata": null,
		"name": "useIssueFilteringFragment",
		"selections": [
			{
				"alias": "commenters",
				"args": [
					v0,
					{
						"kind": "Variable",
						"name": "query",
						"variableName": "commenters"
					},
					v1
				],
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": v4,
				"storageKey": null
			},
			{
				"alias": "mentions",
				"args": [
					v0,
					{
						"kind": "Variable",
						"name": "query",
						"variableName": "mentions"
					},
					v1
				],
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": v4,
				"storageKey": null
			},
			{
				"alias": "assignee",
				"args": [
					v0,
					{
						"kind": "Variable",
						"name": "query",
						"variableName": "assignee"
					},
					v1
				],
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": v4,
				"storageKey": null
			},
			{
				"alias": "author",
				"args": [
					v0,
					{
						"kind": "Variable",
						"name": "query",
						"variableName": "author"
					},
					v1
				],
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": v4,
				"storageKey": null
			},
			{
				"alias": "other",
				"args": [
					v0,
					{
						"kind": "Variable",
						"name": "query",
						"variableName": "other"
					},
					v1
				],
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": v4,
				"storageKey": null
			},
			{
				"condition": "queryIsUrl",
				"kind": "Condition",
				"passingValue": true,
				"selections": [{
					"alias": null,
					"args": [{
						"kind": "Variable",
						"name": "url",
						"variableName": "resource"
					}],
					"concreteType": null,
					"kind": "LinkedField",
					"name": "resource",
					"plural": false,
					"selections": v3,
					"storageKey": null
				}]
			}
		],
		"type": "Query",
		"abstractKey": null
	};
})();
node$8.hash = "e4b7c756e5b5cc087490f02768b41f63";
var VALUES = {
	pickerDebounceTime: 200,
	labelsPageSize: 50,
	labelsInitialLoadCount: 100,
	milestonesPageSize: 100,
	milestonesMaxPreloadCount: 1e3,
	organizationsMaxPreloadCount: 1e3,
	organizationsPageSize: 100,
	maximumSuggestedUsers: 30
};
var import_react_relay = require_react_relay();
var useIssueFilteringQueryGraphQLQuery = node$9;
var UseIssueFilteringGraphQLFragment = node$8;
var useIssueFiltering = (filter, t0, repositoryNameWithOwner, hiddenIssueIds, t1) => {
	const $ = c(40);
	const owner = t0 === void 0 ? "" : t0;
	const withParent = t1 === void 0 ? false : t1;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [isLoading, setIsLoading] = useState(true);
	const [isError, setIsError] = useState(false);
	const [data, setData] = useState(null);
	const activeSubscriptionRef = useRef(null);
	let t2;
	if ($[0] !== environment || $[1] !== owner || $[2] !== repositoryNameWithOwner || $[3] !== withParent) {
		t2 = (nextFilter) => {
			setIsLoading(true);
			activeSubscriptionRef.current?.unsubscribe();
			activeSubscriptionRef.current = clientSideRelayFetchQueryRetained({
				environment,
				query: useIssueFilteringQueryGraphQLQuery,
				variables: {
					...getIssueSearchQueries(owner, nextFilter, repositoryNameWithOwner),
					withParent
				}
			}).subscribe({
				next: (innerData) => {
					setData(innerData ?? null);
					setIsLoading(false);
					setIsError(false);
				},
				error: () => {
					setIsError(true);
					setIsLoading(false);
				}
			});
		};
		$[0] = environment;
		$[1] = owner;
		$[2] = repositoryNameWithOwner;
		$[3] = withParent;
		$[4] = t2;
	} else t2 = $[4];
	const fetchSearchData = t2;
	let t3;
	if ($[5] !== fetchSearchData) {
		t3 = (nextValue) => fetchSearchData(nextValue);
		$[5] = fetchSearchData;
		$[6] = t3;
	} else t3 = $[6];
	const debounceFetchSearchData = useDebounce(t3, VALUES.pickerDebounceTime);
	let t4;
	let t5;
	if ($[7] !== debounceFetchSearchData || $[8] !== filter) {
		t4 = () => {
			debounceFetchSearchData(filter);
		};
		t5 = [debounceFetchSearchData, filter];
		$[7] = debounceFetchSearchData;
		$[8] = filter;
		$[9] = t4;
		$[10] = t5;
	} else {
		t4 = $[9];
		t5 = $[10];
	}
	useEffect(t4, t5);
	let t6;
	let t7;
	if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => () => {
			activeSubscriptionRef.current?.unsubscribe();
		};
		t7 = [];
		$[11] = t6;
		$[12] = t7;
	} else {
		t6 = $[11];
		t7 = $[12];
	}
	useEffect(t6, t7);
	const issues = (0, import_react_relay.useFragment)(UseIssueFilteringGraphQLFragment, data);
	let t8;
	bb0: if (!issues) {
		let t9;
		if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
			t9 = /* @__PURE__ */ new Map();
			$[13] = t9;
		} else t9 = $[13];
		t8 = t9;
	} else {
		if (issues.resource?.__typename === "Issue") {
			const t9 = issues.resource?.id;
			let t10;
			if ($[14] !== issues.resource || $[15] !== t9) {
				t10 = new Map([[t9, issues.resource]]);
				$[14] = issues.resource;
				$[15] = t9;
				$[16] = t10;
			} else t10 = $[16];
			t8 = t10;
			break bb0;
		}
		let t9;
		if ($[17] !== issues.commenters?.nodes) {
			t9 = issues.commenters?.nodes || [];
			$[17] = issues.commenters?.nodes;
			$[18] = t9;
		} else t9 = $[18];
		let t10;
		if ($[19] !== issues.mentions?.nodes) {
			t10 = issues.mentions?.nodes || [];
			$[19] = issues.mentions?.nodes;
			$[20] = t10;
		} else t10 = $[20];
		let t11;
		if ($[21] !== issues.assignee?.nodes) {
			t11 = issues.assignee?.nodes || [];
			$[21] = issues.assignee?.nodes;
			$[22] = t11;
		} else t11 = $[22];
		let t12;
		if ($[23] !== issues.author?.nodes) {
			t12 = issues.author?.nodes || [];
			$[23] = issues.author?.nodes;
			$[24] = t12;
		} else t12 = $[24];
		let t13;
		if ($[25] !== issues.other?.nodes) {
			t13 = issues.other?.nodes || [];
			$[25] = issues.other?.nodes;
			$[26] = t13;
		} else t13 = $[26];
		let t14;
		if ($[27] !== t10 || $[28] !== t11 || $[29] !== t12 || $[30] !== t13 || $[31] !== t9) {
			t14 = [
				...t9,
				...t10,
				...t11,
				...t12,
				...t13
			].filter(_temp$2);
			$[27] = t10;
			$[28] = t11;
			$[29] = t12;
			$[30] = t13;
			$[31] = t9;
			$[32] = t14;
		} else t14 = $[32];
		const issueNodes = t14;
		let issuesMap;
		if ($[33] !== hiddenIssueIds || $[34] !== issueNodes) {
			issuesMap = /* @__PURE__ */ new Map();
			for (const issue of issueNodes) {
				if (hiddenIssueIds?.some((id) => id === issue.id)) continue;
				issuesMap.set(issue.id, issue);
			}
			$[33] = hiddenIssueIds;
			$[34] = issueNodes;
			$[35] = issuesMap;
		} else issuesMap = $[35];
		t8 = issuesMap;
	}
	const items = t8;
	let t9;
	if ($[36] !== isError || $[37] !== isLoading || $[38] !== items) {
		t9 = {
			isLoading,
			isError,
			items
		};
		$[36] = isError;
		$[37] = isLoading;
		$[38] = items;
		$[39] = t9;
	} else t9 = $[39];
	return t9;
};
function _temp$2(node) {
	return node?.__typename === "Issue";
}
function getIssueIconAndFill(state, stateReason) {
	let icon = IssueOpenedIcon;
	let fill = "var(--fgColor-open)";
	if (state === "CLOSED") {
		icon = stateReason === "COMPLETED" ? IssueClosedIcon : SkipIcon;
		fill = stateReason === "COMPLETED" ? "var(--fgColor-done)" : "var(--fgColor-muted)";
	}
	return {
		icon,
		fill
	};
}
var IssuePicker_module_default = {
	issueItem: "IssuePicker-module_MB5NJa_issueItem",
	issueNumberText: "IssuePicker-module_MB5NJa_issueNumberText"
};
var getItemKey = (issue) => issue.id;
var selectedGroup = {
	groupId: "selected",
	header: { title: "Selected" }
};
var suggestionGroup = {
	groupId: "suggestions",
	header: {
		title: "Suggestions",
		variant: "filled"
	}
};
var groups = [selectedGroup, suggestionGroup];
var IssuePickerSelectedIssuesGraphQLQuery = node$11;
var emptyMap = /* @__PURE__ */ new Map();
function IssuePicker(t0) {
	const $ = c(2);
	const { onIssueSelection, selectedIssueIds, hiddenIssueIds, owner, repositoryNameWithOwner, pickerId, isLoading: t1, withParent: t2, ...rest } = t0;
	const isLoadingExternally = t1 === void 0 ? false : t1;
	const withParent = t2 === void 0 ? false : t2;
	const [filter, setFilter] = useState("");
	const { isLoading, isError, items } = useIssueFiltering(filter, owner, repositoryNameWithOwner, hiddenIssueIds, withParent);
	const { createFallbackComponent } = useItemPickerErrorFallback({
		errorMessage: LABELS.cantEditItems("issues"),
		anchorElement: rest.anchorElement,
		open: true
	});
	if (isError) {
		let t3;
		if ($[0] !== createFallbackComponent) {
			t3 = createFallbackComponent(_temp$1);
			$[0] = createFallbackComponent;
			$[1] = t3;
		} else t3 = $[1];
		return t3;
	}
	return jsx(IssuePickerInternal, {
		items: isLoadingExternally ? emptyMap : items,
		isLoading: isLoading || isLoadingExternally,
		...rest,
		selectedIssueIds,
		hiddenIssueIds,
		filter,
		setFilter,
		onIssueSelection,
		repositoryNameWithOwner,
		pickerId
	});
}
IssuePicker.displayName = "IssuePicker";
function _temp$1() {}
function IssuePickerInternal({ items, onIssueSelection, anchorElement, setFilter, isLoading, title, onClose, triggerOpen, selectedIssueIds, filter, pickerId, selectionVariant = "single", subtitle, className, notice, insidePortal, responsiveOnNarrow, onItemSelect }) {
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const [fetchedSelectedIssues, setFetchedSelectedIssues] = useState({});
	const fetchSelectedIssues = useCallback((ids) => {
		return new Promise((resolve, reject) => {
			clientSideRelayFetchQueryRetained({
				environment,
				query: IssuePickerSelectedIssuesGraphQLQuery,
				variables: { ids }
			}).subscribe({
				next: (fetchedData) => {
					if (fetchedData !== null) resolve(fetchedData);
				},
				error: (error) => {
					reject(error);
				}
			});
		});
	}, [environment]);
	const syncSelectedIssues = useEffectEvent(() => {
		async function doFetch(missingIssueIds) {
			const { nodes = [] } = await fetchSelectedIssues(missingIssueIds);
			for (const node of nodes) {
				if (!node || node.__typename !== "Issue") continue;
				setFetchedSelectedIssues((loadedSelectedIssuesMap) => {
					return {
						...loadedSelectedIssuesMap,
						[node.id]: node
					};
				});
			}
		}
		if (selectedIssueIds) {
			const missingIssueIds_0 = [];
			for (const selectedIssueId of selectedIssueIds) {
				const foundSelectedIssue = items.get(selectedIssueId);
				if (foundSelectedIssue) setFetchedSelectedIssues((loadedSelectedIssuesMap_0) => {
					return {
						...loadedSelectedIssuesMap_0,
						[selectedIssueId]: foundSelectedIssue
					};
				});
				else if (!fetchedSelectedIssues?.[selectedIssueId]) missingIssueIds_0.push(selectedIssueId);
			}
			if (missingIssueIds_0.length > 0) doFetch(missingIssueIds_0);
		}
	});
	useEffect(() => {
		if (isLoading) return;
		syncSelectedIssues();
	}, [isLoading, items]);
	const mergedItems = new Map(items);
	for (const [id, issue] of Object.entries(fetchedSelectedIssues)) mergedItems.set(id, issue);
	const allIssues = Array.from(mergedItems.values());
	const foundIssueNumberIndex = allIssues.findIndex((i) => i.number === Number(filter));
	if (foundIssueNumberIndex > 0) {
		const [issue_0] = allIssues.splice(foundIssueNumberIndex, 1);
		if (issue_0) allIssues.unshift(issue_0);
	}
	const convertToItemProps = useCallback((issue_1) => {
		const { icon: Icon, fill } = getIssueIconAndFill(issue_1.state, issue_1.stateReason);
		const issueIsSelected = selectedIssueIds?.includes(issue_1.id);
		return {
			id: issue_1.id,
			text: issue_1.title,
			className: IssuePicker_module_default.issueItem,
			source: issue_1,
			groupId: issueIsSelected ? selectedGroup.groupId : suggestionGroup.groupId,
			leadingVisual: () => /* @__PURE__ */ jsx("span", {
				style: { color: fill },
				children: /* @__PURE__ */ jsx(Icon, { size: 16 })
			}),
			trailingVisual: () => /* @__PURE__ */ jsx("span", {
				className: IssuePicker_module_default.issueNumberText,
				children: `#${issue_1.number}`
			}),
			description: issueIsSelected ? issue_1.repository.nameWithOwner : void 0,
			descriptionVariant: "block",
			onAction: onItemSelect
		};
	}, [selectedIssueIds, onItemSelect]);
	const issuePickerRef = useRef(null);
	const itemPickerGroups = useMemo(() => selectedIssueIds?.length ? groups : groups.filter((group) => group.groupId !== selectedGroup.groupId), [selectedIssueIds]);
	const showNoMatchMessage = useMemo(() => allIssues.length === 0, [allIssues.length]);
	return /* @__PURE__ */ jsx(ItemPicker, {
		loading: isLoading,
		items: allIssues,
		initialSelectedItems: selectedIssueIds || [],
		filterItems: setFilter,
		title: title || LABELS.issueHeader,
		getItemKey,
		convertToItemProps,
		placeholderText: "Search issues",
		selectionVariant,
		onSelectionChange: onIssueSelection,
		renderAnchor: anchorElement,
		height: "large",
		width: "medium",
		maxVisibleItems: -1,
		resultListAriaLabel: "issue results",
		selectPanelRef: issuePickerRef,
		triggerOpen,
		groups: itemPickerGroups,
		onClose,
		pickerId,
		subtitle,
		className,
		notice,
		suppressNoMatchItem: true,
		improvedNoMatchAccessibility: showNoMatchMessage,
		noMatchMessage: showNoMatchMessage ? {
			title: "No issues found",
			body: "Try changing your search term or selecting a different repository.",
			variant: "empty"
		} : void 0,
		insidePortal,
		responsiveOnNarrow
	});
}
IssuePickerInternal.displayName = "IssuePickerInternal";
var RepositoryAndIssuePicker_module_default = { BackToRepositorySelectionButton: "RepositoryAndIssuePicker-module_jBUErG_BackToRepositorySelectionButton" };
var node$7 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "name"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "owner"
	}, v2 = [{
		"kind": "Variable",
		"name": "name",
		"variableName": "name"
	}, {
		"kind": "Variable",
		"name": "owner",
		"variableName": "owner"
	}], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "issueTypesEnabled",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isLocked",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "visibility",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "slashCommandsEnabled",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanPush",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isBlankIssuesEnabled",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "action",
			"value": "create an issue"
		}],
		"kind": "ScalarField",
		"name": "viewerInteractionLimitReasonHTML",
		"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
	}, v21 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueCreationPermissions",
		"kind": "LinkedField",
		"name": "viewerIssueCreationPermissions",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "labelable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "milestoneable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "assignable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "triageable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "typeable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "canSetIssueFields",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v22 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "RepositoryPickerCurrentRepoQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [{
					"kind": "InlineDataFragmentSpread",
					"name": "RepositoryPickerRepository",
					"selections": [
						v3,
						v4,
						v5,
						v6,
						{
							"alias": null,
							"args": null,
							"concreteType": null,
							"kind": "LinkedField",
							"name": "owner",
							"plural": false,
							"selections": [
								v4,
								v7,
								v8,
								v9
							],
							"storageKey": null
						},
						v10,
						v11,
						v12,
						v13,
						v14,
						v15,
						v16,
						v17,
						v18,
						v19,
						v20,
						v21,
						v22
					],
					"args": null,
					"argumentDefinitions": []
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "RepositoryPickerCurrentRepoQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "Repository",
				"kind": "LinkedField",
				"name": "repository",
				"plural": false,
				"selections": [
					v3,
					v4,
					v5,
					v6,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "owner",
						"plural": false,
						"selections": [
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "__typename",
								"storageKey": null
							},
							v4,
							v7,
							v8,
							v9,
							v3
						],
						"storageKey": null
					},
					v10,
					v11,
					v12,
					v13,
					v14,
					v15,
					v16,
					v17,
					v18,
					v19,
					v20,
					v21,
					v22
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "6f97fe17551e28ee464f439a52e3bf88",
			"metadata": {},
			"name": "RepositoryPickerCurrentRepoQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$7.hash = "9a52cb1e86ad007165589ba8bfc9e6a1";
var node$6 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "hasIssuesEnabled"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "owner"
	}, v2 = {
		"defaultValue": 10,
		"kind": "LocalArgument",
		"name": "topRepositoriesFirst"
	}, v3 = {
		"kind": "Variable",
		"name": "hasIssuesEnabled",
		"variableName": "hasIssuesEnabled"
	}, v4 = {
		"kind": "Variable",
		"name": "owner",
		"variableName": "owner"
	}, v5 = [
		{
			"kind": "Variable",
			"name": "first",
			"variableName": "topRepositoriesFirst"
		},
		v3,
		{
			"kind": "Literal",
			"name": "orderBy",
			"value": {
				"direction": "DESC",
				"field": "UPDATED_AT"
			}
		},
		v4
	], v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "issueTypesEnabled",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isLocked",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "visibility",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "slashCommandsEnabled",
		"storageKey": null
	}, v21 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanPush",
		"storageKey": null
	}, v22 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isBlankIssuesEnabled",
		"storageKey": null
	}, v23 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "action",
			"value": "create an issue"
		}],
		"kind": "ScalarField",
		"name": "viewerInteractionLimitReasonHTML",
		"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
	}, v24 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueCreationPermissions",
		"kind": "LinkedField",
		"name": "viewerIssueCreationPermissions",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "labelable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "milestoneable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "assignable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "triageable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "typeable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "canSetIssueFields",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v25 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [
				v0,
				v1,
				v2
			],
			"kind": "Fragment",
			"metadata": null,
			"name": "RepositoryPickerTopRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "viewer",
				"plural": false,
				"selections": [{
					"kind": "InlineDataFragmentSpread",
					"name": "RepositoryPickerTopRepositories",
					"selections": [{
						"alias": null,
						"args": v5,
						"concreteType": "RepositoryConnection",
						"kind": "LinkedField",
						"name": "topRepositories",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "RepositoryEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "Repository",
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [{
									"kind": "InlineDataFragmentSpread",
									"name": "RepositoryPickerRepository",
									"selections": [
										v6,
										v7,
										v8,
										v9,
										{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "owner",
											"plural": false,
											"selections": [
												v7,
												v10,
												v11,
												v12
											],
											"storageKey": null
										},
										v13,
										v14,
										v15,
										v16,
										v17,
										v18,
										v19,
										v20,
										v21,
										v22,
										v23,
										v24,
										v25
									],
									"args": null,
									"argumentDefinitions": []
								}],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"args": [
						v3,
						v4,
						{
							"kind": "Variable",
							"name": "topRepositoriesFirst",
							"variableName": "topRepositoriesFirst"
						}
					],
					"argumentDefinitions": [
						{
							"defaultValue": true,
							"kind": "LocalArgument",
							"name": "hasIssuesEnabled"
						},
						v1,
						v2
					]
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [
				v2,
				v0,
				v1
			],
			"kind": "Operation",
			"name": "RepositoryPickerTopRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": null,
				"concreteType": "User",
				"kind": "LinkedField",
				"name": "viewer",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": v5,
					"concreteType": "RepositoryConnection",
					"kind": "LinkedField",
					"name": "topRepositories",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"concreteType": "RepositoryEdge",
						"kind": "LinkedField",
						"name": "edges",
						"plural": true,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "Repository",
							"kind": "LinkedField",
							"name": "node",
							"plural": false,
							"selections": [
								v6,
								v7,
								v8,
								v9,
								{
									"alias": null,
									"args": null,
									"concreteType": null,
									"kind": "LinkedField",
									"name": "owner",
									"plural": false,
									"selections": [
										{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "__typename",
											"storageKey": null
										},
										v7,
										v10,
										v11,
										v12,
										v6
									],
									"storageKey": null
								},
								v13,
								v14,
								v15,
								v16,
								v17,
								v18,
								v19,
								v20,
								v21,
								v22,
								v23,
								v24,
								v25
							],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"storageKey": null
				}, v6],
				"storageKey": null
			}]
		},
		"params": {
			"id": "ad2fbb26834e37b0c82c4cc765372b0f",
			"metadata": {},
			"name": "RepositoryPickerTopRepositoriesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$6.hash = "73e96d7c429663ba233d926c532b97e4";
var node$5 = {
	"kind": "InlineDataFragment",
	"name": "RepositoryPickerTopRepositories"
};
node$5.hash = "e0e9b7e454f1af88664982ac1af0ab15";
var node$4 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "after"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "searchQuery"
	}, v2 = [
		{
			"kind": "Variable",
			"name": "after",
			"variableName": "after"
		},
		{
			"kind": "Literal",
			"name": "first",
			"value": 10
		},
		{
			"kind": "Variable",
			"name": "query",
			"variableName": "searchQuery"
		},
		{
			"kind": "Literal",
			"name": "type",
			"value": "REPOSITORY"
		}
	], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "repositoryCount",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"concreteType": "PageInfo",
		"kind": "LinkedField",
		"name": "pageInfo",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "hasNextPage",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "endCursor",
			"storageKey": null
		}],
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "issueTypesEnabled",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isLocked",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "visibility",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "slashCommandsEnabled",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanPush",
		"storageKey": null
	}, v21 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isBlankIssuesEnabled",
		"storageKey": null
	}, v22 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "action",
			"value": "create an issue"
		}],
		"kind": "ScalarField",
		"name": "viewerInteractionLimitReasonHTML",
		"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
	}, v23 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueCreationPermissions",
		"kind": "LinkedField",
		"name": "viewerIssueCreationPermissions",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "labelable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "milestoneable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "assignable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "triageable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "typeable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "canSetIssueFields",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v24 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	}, v25 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "RepositoryPickerSearchRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": [
					v3,
					v4,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [{
							"kind": "InlineFragment",
							"selections": [{
								"kind": "InlineDataFragmentSpread",
								"name": "RepositoryPickerRepository",
								"selections": [
									v5,
									v6,
									v7,
									v8,
									{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "owner",
										"plural": false,
										"selections": [
											v6,
											v9,
											v10,
											v11
										],
										"storageKey": null
									},
									v12,
									v13,
									v14,
									v15,
									v16,
									v17,
									v18,
									v19,
									v20,
									v21,
									v22,
									v23,
									v24
								],
								"args": null,
								"argumentDefinitions": []
							}],
							"type": "Repository",
							"abstractKey": null
						}],
						"storageKey": null
					}
				],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "RepositoryPickerSearchRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": [
					v3,
					v4,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [
							v25,
							{
								"kind": "InlineFragment",
								"selections": [
									v5,
									v6,
									v7,
									v8,
									{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "owner",
										"plural": false,
										"selections": [
											v25,
											v6,
											v9,
											v10,
											v11,
											v5
										],
										"storageKey": null
									},
									v12,
									v13,
									v14,
									v15,
									v16,
									v17,
									v18,
									v19,
									v20,
									v21,
									v22,
									v23,
									v24
								],
								"type": "Repository",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": [v5],
								"type": "Node",
								"abstractKey": "__isNode"
							}
						],
						"storageKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "d6cf5beffa038ed4dce88d843c5482b3",
			"metadata": {},
			"name": "RepositoryPickerSearchRepositoriesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$4.hash = "d55c88eae1b92354a9ca57beeaa62299";
var node$3 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "after"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "searchQuery"
	}, v2 = [
		{
			"kind": "Variable",
			"name": "after",
			"variableName": "after"
		},
		{
			"kind": "Literal",
			"name": "first",
			"value": 10
		},
		{
			"kind": "Variable",
			"name": "query",
			"variableName": "searchQuery"
		},
		{
			"kind": "Literal",
			"name": "type",
			"value": "REPOSITORY"
		}
	], v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "repositoryCount",
		"storageKey": null
	}, v4 = {
		"alias": null,
		"args": null,
		"concreteType": "PageInfo",
		"kind": "LinkedField",
		"name": "pageInfo",
		"plural": false,
		"selections": [{
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "hasNextPage",
			"storageKey": null
		}, {
			"alias": null,
			"args": null,
			"kind": "ScalarField",
			"name": "endCursor",
			"storageKey": null
		}],
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "RepositoryPickerSearchRepositoriesFastQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": [
					v3,
					v4,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [{
							"kind": "InlineFragment",
							"selections": [{
								"kind": "InlineDataFragmentSpread",
								"name": "RepositoryPickerRepositoryLight",
								"selections": [
									v5,
									v6,
									v7,
									v8,
									v9,
									v10,
									{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "owner",
										"plural": false,
										"selections": [
											v6,
											v11,
											v12
										],
										"storageKey": null
									},
									v13
								],
								"args": null,
								"argumentDefinitions": []
							}],
							"type": "Repository",
							"abstractKey": null
						}],
						"storageKey": null
					}
				],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "RepositoryPickerSearchRepositoriesFastQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": "SearchResultItemConnection",
				"kind": "LinkedField",
				"name": "search",
				"plural": false,
				"selections": [
					v3,
					v4,
					{
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [
							v14,
							{
								"kind": "InlineFragment",
								"selections": [
									v5,
									v6,
									v7,
									v8,
									v9,
									v10,
									{
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "owner",
										"plural": false,
										"selections": [
											v14,
											v6,
											v11,
											v12,
											v5
										],
										"storageKey": null
									},
									v13
								],
								"type": "Repository",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": [v5],
								"type": "Node",
								"abstractKey": "__isNode"
							}
						],
						"storageKey": null
					}
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "f40b058e47eb5adac153653f1cfb99ab",
			"metadata": {},
			"name": "RepositoryPickerSearchRepositoriesFastQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$3.hash = "0cae848d6ab13dfa967d3f8a0f3fb664";
var node$2 = (function() {
	var v0 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "issueId"
	}, v1 = {
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "searchQuery"
	}, v2 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "issueId"
	}], v3 = [{
		"kind": "Literal",
		"name": "first",
		"value": 10
	}, {
		"kind": "Variable",
		"name": "query",
		"variableName": "searchQuery"
	}], v4 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	}, v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "databaseId",
		"storageKey": null
	}, v6 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "name",
		"storageKey": null
	}, v7 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "nameWithOwner",
		"storageKey": null
	}, v8 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v9 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "size",
			"value": 64
		}],
		"kind": "ScalarField",
		"name": "avatarUrl",
		"storageKey": "avatarUrl(size:64)"
	}, v10 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "issueTypesEnabled",
		"storageKey": null
	}, v11 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isLocked",
		"storageKey": null
	}, v12 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isPrivate",
		"storageKey": null
	}, v13 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "visibility",
		"storageKey": null
	}, v14 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isArchived",
		"storageKey": null
	}, v15 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isInOrganization",
		"storageKey": null
	}, v16 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasIssuesEnabled",
		"storageKey": null
	}, v17 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "hasAnyTemplates",
		"storageKey": null
	}, v18 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "slashCommandsEnabled",
		"storageKey": null
	}, v19 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "viewerCanPush",
		"storageKey": null
	}, v20 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "isBlankIssuesEnabled",
		"storageKey": null
	}, v21 = {
		"alias": null,
		"args": [{
			"kind": "Literal",
			"name": "action",
			"value": "create an issue"
		}],
		"kind": "ScalarField",
		"name": "viewerInteractionLimitReasonHTML",
		"storageKey": "viewerInteractionLimitReasonHTML(action:\"create an issue\")"
	}, v22 = {
		"alias": null,
		"args": null,
		"concreteType": "IssueCreationPermissions",
		"kind": "LinkedField",
		"name": "viewerIssueCreationPermissions",
		"plural": false,
		"selections": [
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "labelable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "milestoneable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "assignable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "triageable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "typeable",
				"storageKey": null
			},
			{
				"alias": null,
				"args": null,
				"kind": "ScalarField",
				"name": "canSetIssueFields",
				"storageKey": null
			}
		],
		"storageKey": null
	}, v23 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "shortDescriptionHTML",
		"storageKey": null
	}, v24 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": [v0, v1],
			"kind": "Fragment",
			"metadata": null,
			"name": "RepositoryPickerPossibleTransferRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"alias": null,
						"args": v3,
						"concreteType": "RepositoryConnection",
						"kind": "LinkedField",
						"name": "possibleTransferRepositoriesForViewer",
						"plural": false,
						"selections": [{
							"alias": null,
							"args": null,
							"concreteType": "RepositoryEdge",
							"kind": "LinkedField",
							"name": "edges",
							"plural": true,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "Repository",
								"kind": "LinkedField",
								"name": "node",
								"plural": false,
								"selections": [{
									"kind": "InlineDataFragmentSpread",
									"name": "RepositoryPickerRepository",
									"selections": [
										v4,
										v5,
										v6,
										v7,
										{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "owner",
											"plural": false,
											"selections": [
												v5,
												v8,
												v9,
												v10
											],
											"storageKey": null
										},
										v11,
										v12,
										v13,
										v14,
										v15,
										v16,
										v17,
										v18,
										v19,
										v20,
										v21,
										v22,
										v23
									],
									"args": null,
									"argumentDefinitions": []
								}],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"storageKey": null
					}],
					"type": "Issue",
					"abstractKey": null
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": [v1, v0],
			"kind": "Operation",
			"name": "RepositoryPickerPossibleTransferRepositoriesQuery",
			"selections": [{
				"alias": null,
				"args": v2,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v24,
					{
						"kind": "InlineFragment",
						"selections": [{
							"alias": null,
							"args": v3,
							"concreteType": "RepositoryConnection",
							"kind": "LinkedField",
							"name": "possibleTransferRepositoriesForViewer",
							"plural": false,
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "RepositoryEdge",
								"kind": "LinkedField",
								"name": "edges",
								"plural": true,
								"selections": [{
									"alias": null,
									"args": null,
									"concreteType": "Repository",
									"kind": "LinkedField",
									"name": "node",
									"plural": false,
									"selections": [
										v4,
										v5,
										v6,
										v7,
										{
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "owner",
											"plural": false,
											"selections": [
												v24,
												v5,
												v8,
												v9,
												v10,
												v4
											],
											"storageKey": null
										},
										v11,
										v12,
										v13,
										v14,
										v15,
										v16,
										v17,
										v18,
										v19,
										v20,
										v21,
										v22,
										v23
									],
									"storageKey": null
								}],
								"storageKey": null
							}],
							"storageKey": null
						}],
						"type": "Issue",
						"abstractKey": null
					},
					v4
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "67c702954fca6487e02f5109a105bbbb",
			"metadata": {},
			"name": "RepositoryPickerPossibleTransferRepositoriesQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$2.hash = "1ef5b2852bfdfa6a351139b04aa4fefc";
var node$1 = {
	"kind": "InlineDataFragment",
	"name": "RepositoryPickerRepository"
};
node$1.hash = "dfd45483ab590eed11b9231050fc1ebd";
var node = {
	"kind": "InlineDataFragment",
	"name": "RepositoryPickerRepositoryLight"
};
node.hash = "c3603a4ea1983f86e0cfa857c837defe";
function getRepositorySearchQuery(queryString, options) {
	const orgIndexSplit = queryString.indexOf("/");
	let query = "in:name archived:false";
	if (options?.excludeRepo) query = `${query} -repo:${options.excludeRepo}`;
	if (options?.includeForks) query = `${query} fork:true`;
	if (options?.repositoryVisibility && options.repositoryVisibility !== "PUBLIC") query = `${query} -visibility:public`;
	if (orgIndexSplit > 0 && queryString.split("/").length === 2) {
		const orgSearchName = queryString.split("/")[0];
		const repoSearchName = queryString.split("/")[1];
		return `${query} org:${orgSearchName} ${repoSearchName}`;
	}
	if (options?.organization) return `${query} org:${options.organization} ${queryString}`;
	return `${query} ${queryString}`;
}
var RepositoryPicker_module_default = {
	hideContainer: "RepositoryPicker-module_W4vHTW_hideContainer",
	Item: "RepositoryPicker-module_W4vHTW_Item",
	repositoryPickerContainer: "RepositoryPicker-module_W4vHTW_repositoryPickerContainer"
};
function readRepositoryFromFragment(key) {
	return (0, import_react_relay.readInlineData)(RepositoryFragment, key);
}
function readTopRepositoriesFromFragment(key) {
	return ((0, import_react_relay.readInlineData)(TopRepositoriesFragment, key).topRepositories.edges || []).flatMap((a) => a?.node ? [readRepositoryFromFragment(a.node)] : []);
}
var CurrentRepository = node$7;
var TopRepositories = node$6;
var TopRepositoriesFragment = node$5;
var SearchRepositories = node$4;
var PossibleTransferRepositories = node$2;
var RepositoryFragment = node$1;
async function fetchRepository(environment, owner, name) {
	const data = await (0, import_react_relay.fetchQuery)(environment, CurrentRepository, {
		owner,
		name
	}, { fetchPolicy: "store-or-network" }).toPromise();
	if (data?.repository != null) return readRepositoryFromFragment(data.repository);
	return null;
}
async function fetchTopRepositories(environment, options = {}) {
	const { first = 10, hasIssuesEnabled, owner } = options;
	const queryData = await (0, import_react_relay.fetchQuery)(environment, TopRepositories, {
		topRepositoriesFirst: first,
		hasIssuesEnabled,
		owner
	}, { fetchPolicy: "store-or-network" }).toPromise();
	if (queryData?.viewer == null) return [];
	return readTopRepositoriesFromFragment(queryData.viewer);
}
function RepositoryPicker({ initialRepository, onSelect, preventDefault, organization, topRepositories, focusRepositoryPicker, enforceAtleastOneSelected, options: { hasIssuesEnabled, readonly, includeForks } = {
	hasIssuesEnabled: void 0,
	readonly: false,
	includeForks: false
}, renderTrailingVisual, exclude, "aria-labelledby": ariaLabelledBy, "aria-describedby": ariaDescribedBy, anchorElement, title, subtitle, preventClose, triggerOpen, onOpen, onClose, ignoredRepositories, repositoryFilter, customNoResultsItem, customNoResultsTitle, repoNameOnly, pickerId, currentRepoVisibility, issueId, responsiveOnNarrow, notice, insidePortal, hideContainer }) {
	const { addToast } = useToastContext();
	const [initiallySelectedRepo, _] = useState(initialRepository);
	const [filter, setFilter] = useState("");
	const [searchResults, setSearchResults] = useState(void 0);
	const [searchLoading, setSearchLoading] = useState(topRepositories == null);
	const filterRef = useRef(filter);
	const [previousTopRepositories, setPreviousTopRepositories] = useState(topRepositories);
	if (topRepositories !== previousTopRepositories) {
		setPreviousTopRepositories(topRepositories);
		if (topRepositories != null) setSearchLoading(false);
	}
	const relayEnvironment = (0, import_react_relay.useRelayEnvironment)();
	const fetchPossibleTransferRepos = useCallback((searchQuery) => {
		if (!issueId) return;
		if (searchQuery.trim() === "") {
			setSearchResults(void 0);
			setSearchLoading(false);
			return;
		}
		setSearchLoading(true);
		(0, import_react_relay.fetchQuery)(relayEnvironment, PossibleTransferRepositories, {
			searchQuery,
			issueId
		}).subscribe({
			next: (data) => {
				if (data !== null) {
					const fetchedRepos = (data.node?.possibleTransferRepositoriesForViewer?.edges || []).flatMap((node) => node?.node ? [readRepositoryFromFragment(node.node)] : []);
					const currentFilter = filterRef.current;
					if (searchQuery.trim() === currentFilter.trim()) {
						setSearchResults(fetchedRepos);
						setSearchLoading(false);
					}
				}
			},
			error: () => {
				setSearchLoading(false);
			}
		});
	}, [relayEnvironment, issueId]);
	const fetchRepos = useCallback((searchQuery_0, orgs) => {
		if (searchQuery_0.trim() === "") {
			setSearchResults(void 0);
			setSearchLoading(false);
			return;
		}
		setSearchLoading(true);
		(0, import_react_relay.fetchQuery)(relayEnvironment, SearchRepositories, { searchQuery: getRepositorySearchQuery(searchQuery_0, {
			organization,
			excludeRepo: exclude,
			includeForks,
			repositoryVisibility: currentRepoVisibility
		}) }).subscribe({
			next: (data_0) => {
				if (data_0 !== null) {
					let fetchedRepos_0 = (data_0.search.nodes || []).flatMap((node_0) => node_0 ? [readRepositoryFromFragment(node_0)] : []);
					fetchedRepos_0 = fetchedRepos_0.filter((repo) => !repo.isLocked && !repo.isArchived);
					if (hasIssuesEnabled) fetchedRepos_0 = fetchedRepos_0.filter((repo_0) => repo_0.hasIssuesEnabled === hasIssuesEnabled);
					let sortedNextSearchResults = fetchedRepos_0.sort((a, b) => {
						if (orgs.includes(a.owner.login) && !orgs.includes(b.owner.login)) return -1;
						else if (!orgs.includes(a.owner.login) && orgs.includes(b.owner.login)) return 1;
						else return a.owner.login.localeCompare(b.owner.login);
					});
					if (ignoredRepositories) {
						const ignoredSet = new Set(ignoredRepositories);
						sortedNextSearchResults = sortedNextSearchResults.filter((repo_1) => !ignoredSet.has(repo_1.nameWithOwner));
					}
					if (repositoryFilter) sortedNextSearchResults = sortedNextSearchResults.filter(repositoryFilter);
					const currentFilter_0 = filterRef.current;
					if (searchQuery_0.trim() === currentFilter_0.trim()) {
						setSearchResults(sortedNextSearchResults);
						setSearchLoading(false);
					}
				}
			},
			error: () => {
				setSearchLoading(false);
				addToast({
					type: "error",
					message: ERRORS.couldNotSearchRepositories
				});
			}
		});
	}, [
		relayEnvironment,
		organization,
		exclude,
		includeForks,
		currentRepoVisibility,
		hasIssuesEnabled,
		ignoredRepositories,
		repositoryFilter,
		addToast
	]);
	const fetchedRepos_1 = useMemo(() => {
		let nodes = topRepositories || [];
		if (initiallySelectedRepo) {
			if (!nodes.find((node_1) => node_1.id === initiallySelectedRepo.id)) nodes = [initiallySelectedRepo, ...nodes];
		}
		if (initialRepository) {
			if (!nodes.find((node_2) => node_2.id === initialRepository.id)) nodes = [initialRepository, ...nodes];
		}
		if (organization) nodes = nodes.filter((repo_2) => repo_2.owner.login === organization);
		if (exclude) nodes = nodes.filter((repo_3) => repo_3.nameWithOwner !== exclude);
		if (ignoredRepositories) {
			const ignoredSet_0 = new Set(ignoredRepositories);
			nodes = nodes.filter((repo_4) => !ignoredSet_0.has(repo_4.nameWithOwner));
		}
		return nodes.slice(0, 10);
	}, [
		topRepositories,
		initiallySelectedRepo,
		initialRepository,
		organization,
		exclude,
		ignoredRepositories
	]);
	const knownOrgs = useMemo(() => [...new Set(fetchedRepos_1.map((repo_5) => repo_5.owner.login))], [fetchedRepos_1]);
	const debounceFetchRepo = useDebounce((nextValue) => {
		if (issueId) fetchPossibleTransferRepos(nextValue);
		else fetchRepos(nextValue, knownOrgs);
	}, VALUES.pickerDebounceTime);
	const getItemKey = useCallback((o) => o.id, []);
	const repositoryPickerRef = useRef(null);
	useEffect(() => {
		if (focusRepositoryPicker) repositoryPickerRef.current?.focus();
	}, [repositoryPickerRef, focusRepositoryPicker]);
	const renderAnchor = useCallback(({ ...anchorProps }) => {
		if (anchorElement) return anchorElement(anchorProps);
		const repositoryValue = initialRepository ? repoNameOnly ? initialRepository.name : initialRepository.nameWithOwner : "No repository selected";
		const label = initialRepository ? `Selected repository: ${repositoryValue}` : LABELS.selectRepository;
		return /* @__PURE__ */ jsx(ButtonComponent, {
			leadingVisual: RepoIcon,
			trailingVisual: TriangleDownIcon,
			"aria-label": label,
			"aria-labelledby": ariaLabelledBy,
			"aria-describedby": ariaDescribedBy,
			...anchorProps,
			disabled: readonly,
			ref: repositoryPickerRef,
			children: initialRepository ? /* @__PURE__ */ jsx("span", { children: repoNameOnly ? initialRepository.name : `${initialRepository.owner.login}/${initialRepository.name}` }) : LABELS.selectRepository
		});
	}, [
		anchorElement,
		ariaDescribedBy,
		ariaLabelledBy,
		initialRepository,
		readonly,
		repoNameOnly
	]);
	const convertToItemProps = useCallback((repo_6) => ({
		id: `${repo_6.id}_${repo_6.databaseId}_${repo_6.slashCommandsEnabled}`,
		text: repoNameOnly ? repo_6.name : `${repo_6.owner.login}/${repo_6.name}`,
		source: repo_6,
		leadingVisual: () => repo_6.isPrivate ? /* @__PURE__ */ jsx(LockIcon, { size: 12 }) : /* @__PURE__ */ jsx(RepoIcon, { size: 12 }),
		trailingVisual: renderTrailingVisual?.(repo_6.id),
		className: RepositoryPicker_module_default.Item
	}), [renderTrailingVisual, repoNameOnly]);
	const items = useMemo(() => {
		if (searchResults) return searchResults;
		const filteredItems = fetchedRepos_1.filter((repo_7) => !repo_7.isArchived && !repo_7.isLocked);
		if (repositoryFilter) return filteredItems.filter(repositoryFilter);
		return filteredItems;
	}, [
		fetchedRepos_1,
		repositoryFilter,
		searchResults
	]);
	const autoSelectFirstRepo = useEffectEvent(() => {
		if (!initialRepository && items.length > 0 && !preventDefault) onSelect(items[0]);
	});
	useEffect(() => {
		autoSelectFirstRepo();
	}, []);
	const filterItems = useCallback((value) => {
		if (readonly) return;
		const trimmedValue = value.trim();
		if (filter === trimmedValue) return;
		debounceFetchRepo(trimmedValue);
		setFilter(trimmedValue);
		filterRef.current = trimmedValue;
	}, [
		readonly,
		filter,
		debounceFetchRepo
	]);
	const showNoMatchMessage = useMemo(() => items.length === 0, [items.length]);
	const message = useMemo(() => showNoMatchMessage ? {
		title: customNoResultsTitle ?? "No repositories match",
		body: customNoResultsItem ?? "Try searching with a different query for results.",
		variant: "empty"
	} : void 0, [
		showNoMatchMessage,
		customNoResultsTitle,
		customNoResultsItem
	]);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(RepositoryPicker_module_default.repositoryPickerContainer, hideContainer && RepositoryPicker_module_default.hideContainer),
		"data-testid": "repository-picker-container",
		children: /* @__PURE__ */ jsx(ItemPicker, {
			items,
			initialSelectedItems: initialRepository ? [initialRepository] : [],
			filterItems,
			getItemKey,
			convertToItemProps,
			placeholderText: LABELS.selectRepository,
			selectionVariant: "single",
			onSelectionChange: ([firstRepo]) => {
				return onSelect(firstRepo);
			},
			loading: searchLoading,
			renderAnchor,
			selectPanelRef: repositoryPickerRef,
			enforceAtleastOneSelected,
			resultListAriaLabel: "Repository results",
			height: "large",
			width: "medium",
			title,
			subtitle,
			preventClose,
			triggerOpen,
			onOpen,
			onClose,
			pickerId,
			improvedNoMatchAccessibility: showNoMatchMessage,
			noMatchMessage: message,
			notice,
			responsiveOnNarrow,
			insidePortal
		})
	});
}
RepositoryPicker.displayName = "RepositoryPicker";
var REPOSITORY_PICKER_ID = "repository-picker";
var ISSUE_PICKER_ID = "issue-picker";
function RepositoryAndIssuePicker(t0) {
	const $ = c(14);
	const { pickerType: t1, anchorElement, onPickerTypeChange, selectedIssueIds, hiddenIssueIds, withParent, ...rest } = t0;
	const propsPickerType = t1 === void 0 ? null : t1;
	const [pickerType, setPickerType] = useState(propsPickerType);
	let t2;
	let t3;
	if ($[0] !== propsPickerType) {
		t2 = () => {
			setPickerType(propsPickerType);
		};
		t3 = [propsPickerType];
		$[0] = propsPickerType;
		$[1] = t2;
		$[2] = t3;
	} else {
		t2 = $[1];
		t3 = $[2];
	}
	useEffect(t2, t3);
	let t4;
	if ($[3] !== onPickerTypeChange || $[4] !== propsPickerType) {
		t4 = (type) => {
			if (propsPickerType === type) return;
			onPickerTypeChange?.(type);
		};
		$[3] = onPickerTypeChange;
		$[4] = propsPickerType;
		$[5] = t4;
	} else t4 = $[5];
	const notifyPickerTypeChange = useEffectEvent(t4);
	let t5;
	if ($[6] !== notifyPickerTypeChange || $[7] !== pickerType) {
		t5 = () => {
			notifyPickerTypeChange(pickerType);
		};
		$[6] = notifyPickerTypeChange;
		$[7] = pickerType;
		$[8] = t5;
	} else t5 = $[8];
	let t6;
	if ($[9] !== pickerType) {
		t6 = [pickerType];
		$[9] = pickerType;
		$[10] = t6;
	} else t6 = $[10];
	useEffect(t5, t6);
	if (pickerType === null) {
		let t7;
		if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
			t7 = () => setPickerType("Issue");
			$[11] = t7;
		} else t7 = $[11];
		let t8;
		if ($[12] !== anchorElement) {
			t8 = anchorElement({ onClick: t7 });
			$[12] = anchorElement;
			$[13] = t8;
		} else t8 = $[13];
		return t8;
	}
	return jsx(RepositoryAndIssuePickerInternal, {
		anchorElement,
		selectedIssueIds,
		hiddenIssueIds,
		withParent,
		...rest,
		setPickerType,
		pickerType
	});
}
RepositoryAndIssuePicker.displayName = "RepositoryAndIssuePicker";
function RepositoryAndIssuePickerInternal(t0) {
	const $ = c(41);
	const { anchorElement, onIssueSelection, organization, defaultRepositoryNameWithOwner, pickerType, setPickerType, selectedIssueIds, hiddenIssueIds, withParent, issuePickerProps, repositoryPickerProps } = t0;
	const [currentRepositoryNameWithOwner, setCurrentRepositoryNameWithOwner] = useState(defaultRepositoryNameWithOwner);
	const [initialRepository, setInitialRepository] = useState(void 0);
	const [topRepositories, setTopRepositories] = useState(null);
	const { updateOpenState } = useItemPickersContext();
	const environment = (0, import_react_relay.useRelayEnvironment)();
	let t1;
	if ($[0] !== setPickerType) {
		t1 = () => {
			setPickerType("Repository");
		};
		$[0] = setPickerType;
		$[1] = t1;
	} else t1 = $[1];
	const onBackClick = t1;
	let t2;
	if ($[2] !== setPickerType || $[3] !== updateOpenState) {
		t2 = () => {
			setPickerType(_temp);
			updateOpenState(REPOSITORY_PICKER_ID, false);
		};
		$[2] = setPickerType;
		$[3] = updateOpenState;
		$[4] = t2;
	} else t2 = $[4];
	const onRepoClose = t2;
	let t3;
	if ($[5] !== setPickerType || $[6] !== updateOpenState) {
		t3 = () => {
			setPickerType(_temp2);
			updateOpenState(ISSUE_PICKER_ID, false);
		};
		$[5] = setPickerType;
		$[6] = updateOpenState;
		$[7] = t3;
	} else t3 = $[7];
	const onIssueClose = t3;
	let t4;
	if ($[8] !== currentRepositoryNameWithOwner || $[9] !== setPickerType) {
		t4 = (repository) => {
			if (repository?.nameWithOwner) setCurrentRepositoryNameWithOwner(repository?.nameWithOwner);
			if (currentRepositoryNameWithOwner || repository?.nameWithOwner) setPickerType("Issue");
		};
		$[8] = currentRepositoryNameWithOwner;
		$[9] = setPickerType;
		$[10] = t4;
	} else t4 = $[10];
	const setRepository = t4;
	let t5;
	if ($[11] !== onIssueSelection || $[12] !== setPickerType) {
		t5 = (issues) => {
			onIssueSelection(issues);
			setPickerType(null);
		};
		$[11] = onIssueSelection;
		$[12] = setPickerType;
		$[13] = t5;
	} else t5 = $[13];
	const localOnIssueSelection = t5;
	let t6;
	if ($[14] !== environment) {
		t6 = async () => {
			setTopRepositories(await fetchTopRepositories(environment, {
				first: 5,
				hasIssuesEnabled: true
			}));
		};
		$[14] = environment;
		$[15] = t6;
	} else t6 = $[15];
	const fetchInitialRepos = useEffectEvent(t6);
	let t7;
	if ($[16] !== fetchInitialRepos) {
		t7 = () => {
			fetchInitialRepos();
		};
		$[16] = fetchInitialRepos;
		$[17] = t7;
	} else t7 = $[17];
	let t8;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = [];
		$[18] = t8;
	} else t8 = $[18];
	useEffect(t7, t8);
	let t10;
	let t9;
	if ($[19] !== currentRepositoryNameWithOwner || $[20] !== environment) {
		t9 = () => {
			(async function fetchData() {
				const [organizationLogin, repositoryName] = currentRepositoryNameWithOwner.split("/");
				if (organizationLogin && repositoryName) {
					const repository_0 = await fetchRepository(environment, organizationLogin, repositoryName);
					if (repository_0 != null) setInitialRepository(repository_0);
				}
			})();
		};
		t10 = [currentRepositoryNameWithOwner, environment];
		$[19] = currentRepositoryNameWithOwner;
		$[20] = environment;
		$[21] = t10;
		$[22] = t9;
	} else {
		t10 = $[21];
		t9 = $[22];
	}
	useEffect(t9, t10);
	switch (pickerType) {
		case "Repository": {
			if (!topRepositories) return null;
			let t11;
			if ($[23] !== anchorElement || $[24] !== initialRepository || $[25] !== onRepoClose || $[26] !== organization || $[27] !== repositoryPickerProps || $[28] !== setRepository || $[29] !== topRepositories) {
				t11 = jsx(RepositoryPicker, {
					initialRepository,
					preventDefault: true,
					onSelect: setRepository,
					organization,
					topRepositories,
					anchorElement,
					onClose: onRepoClose,
					triggerOpen: true,
					title: "Select a repository",
					pickerId: REPOSITORY_PICKER_ID,
					...repositoryPickerProps
				});
				$[23] = anchorElement;
				$[24] = initialRepository;
				$[25] = onRepoClose;
				$[26] = organization;
				$[27] = repositoryPickerProps;
				$[28] = setRepository;
				$[29] = topRepositories;
				$[30] = t11;
			} else t11 = $[30];
			return t11;
		}
		case "Issue": {
			let t11;
			if ($[31] !== anchorElement || $[32] !== currentRepositoryNameWithOwner || $[33] !== hiddenIssueIds || $[34] !== issuePickerProps || $[35] !== localOnIssueSelection || $[36] !== onBackClick || $[37] !== onIssueClose || $[38] !== selectedIssueIds || $[39] !== withParent) {
				t11 = jsx(IssuePicker, {
					selectedIssueIds,
					hiddenIssueIds,
					onIssueSelection: localOnIssueSelection,
					anchorElement,
					repositoryNameWithOwner: currentRepositoryNameWithOwner,
					onClose: onIssueClose,
					withParent,
					title: jsxs("div", {
						className: RepositoryAndIssuePicker_module_default.BackToRepositorySelectionButton,
						children: [jsx(IconButton, {
							icon: ArrowLeftIcon,
							variant: "invisible",
							"data-testid": "back-to-repo-selection-button",
							"aria-label": "Back to repository selection",
							tooltipDirection: "n",
							onClick: onBackClick
						}), jsx("span", { children: currentRepositoryNameWithOwner })]
					}),
					triggerOpen: true,
					pickerId: ISSUE_PICKER_ID,
					...issuePickerProps
				});
				$[31] = anchorElement;
				$[32] = currentRepositoryNameWithOwner;
				$[33] = hiddenIssueIds;
				$[34] = issuePickerProps;
				$[35] = localOnIssueSelection;
				$[36] = onBackClick;
				$[37] = onIssueClose;
				$[38] = selectedIssueIds;
				$[39] = withParent;
				$[40] = t11;
			} else t11 = $[40];
			return t11;
		}
	}
}
RepositoryAndIssuePickerInternal.displayName = "RepositoryAndIssuePickerInternal";
function _temp2(t_0) {
	return t_0 === "Repository" ? "Repository" : null;
}
function _temp(t) {
	return t === "Issue" ? "Issue" : null;
}
export { VALUES as a, readRepositoryFromFragment as c, RepositoryPicker as i, readTopRepositoriesFromFragment as l, LABELS as n, fetchRepository as o, RepositoryAndIssuePicker as r, fetchTopRepositories as s, ErrorWithRetry as t, useItemPickerErrorFallback as u };
