import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Bi as useFocusZone, Rr as SmileyIcon, an as IconButton, n as ActionList, pi as Tooltip$1 } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as AnchoredOverlay } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { o as require_react_relay } from "./server-react-relay-DbAeH2_y-Bc9bIoJB.js";
import { t as addReactionMutation } from "./server-add-reaction-mutation-B36mKh3K-Co_JID-q.js";
import { useCallback, useId, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { FocusKeys } from "@primer/behaviors";
import { c } from "react/compiler-runtime";
var EMOJI_MAP = {
	CONFUSED: "😕",
	EYES: "👀",
	HEART: "❤️",
	HOORAY: "🎉",
	LAUGH: "😄",
	THUMBS_DOWN: "👎",
	THUMBS_UP: "👍",
	ROCKET: "🚀"
};
function summarizeReactors(reactors, totalReactedUsers) {
	if (reactors.length === 0 || totalReactedUsers === 0) return "";
	const summary = reactors.slice(0);
	if (summary.length === 1) return summary[0];
	if (summary.length === 2) return summary.join(" and ");
	if (totalReactedUsers > reactors.length) summary.push(`${totalReactedUsers - reactors.length} more`);
	const last = summary.pop();
	summary.push(`${summary.pop()} and ${last}`);
	return summary.join(", ");
}
function constructReactionButtonDescription(reaction, reacted) {
	return `${reacted ? "Unreact" : "React"} with ${EMOJI_MAP[reaction]}`;
}
function constructReactionButtonLabel(content, totalCount) {
	return `${EMOJI_MAP[content]} ${totalCount} reaction${totalCount === 1 ? "" : "s"}`;
}
var ReactionButton_module_default = {
	reactionToggleButton: "ReactionButton-module_xCU-Rq_reactionToggleButton",
	reactionToggleButtonReacted: "ReactionButton-module_xCU-Rq_reactionToggleButtonReacted"
};
function ReactionButton(t0) {
	const $ = c(14);
	const { reactionGroup, disabled, onReact } = t0;
	const { content, viewerHasReacted } = reactionGroup.reaction;
	const { reactors, totalCount } = reactionGroup;
	const id = useId();
	if (totalCount === 0) return null;
	let t1;
	if ($[0] !== content || $[1] !== disabled || $[2] !== id || $[3] !== onReact || $[4] !== reactors || $[5] !== totalCount || $[6] !== viewerHasReacted) {
		const reactorLogins = reactors.flatMap(_temp$1);
		const description = constructReactionButtonDescription(content, viewerHasReacted);
		const label = constructReactionButtonLabel(content, totalCount);
		let t2;
		if ($[8] !== content) {
			t2 = () => jsx(Fragment$1, { children: EMOJI_MAP[content] });
			$[8] = content;
			$[9] = t2;
		} else t2 = $[9];
		let t3;
		if ($[10] !== content || $[11] !== onReact || $[12] !== viewerHasReacted) {
			t3 = () => onReact(content, viewerHasReacted);
			$[10] = content;
			$[11] = onReact;
			$[12] = viewerHasReacted;
			$[13] = t3;
		} else t3 = $[13];
		t1 = jsx(Tooltip$1, {
			text: summarizeReactors(reactorLogins, totalCount),
			type: "description",
			direction: "ne",
			children: jsxs(ButtonComponent, {
				size: "small",
				"aria-label": label,
				role: "switch",
				"aria-checked": viewerHasReacted,
				leadingVisual: t2,
				onClick: t3,
				inactive: disabled,
				className: clsx(ReactionButton_module_default.reactionToggleButton, viewerHasReacted && ReactionButton_module_default.reactionToggleButtonReacted),
				"aria-describedby": id,
				children: [jsx("span", {
					className: "sr-only",
					id,
					children: description
				}), totalCount]
			})
		});
		$[0] = content;
		$[1] = disabled;
		$[2] = id;
		$[3] = onReact;
		$[4] = reactors;
		$[5] = totalCount;
		$[6] = viewerHasReacted;
		$[7] = t1;
	} else t1 = $[7];
	return t1;
}
ReactionButton.displayName = "ReactionButton";
function _temp$1(reactor) {
	return reactor.typeName !== "Other" ? [reactor.login] : [];
}
var ReactionsMenuItem_module_default = {
	ReactionsMenuOption: "ReactionsMenuItem-module_NqcgFa_ReactionsMenuOption",
	viewerHasReacted: "ReactionsMenuItem-module_NqcgFa_viewerHasReacted"
};
function ReactionsMenuItem({ onReact, reaction }) {
	const { content, viewerHasReacted } = reaction;
	return /* @__PURE__ */ jsx(ActionList.Item, {
		role: "menuitemcheckbox",
		"aria-checked": viewerHasReacted,
		onSelect: () => onReact(content, viewerHasReacted),
		className: clsx(ReactionsMenuItem_module_default.ReactionsMenuOption, viewerHasReacted && ReactionsMenuItem_module_default.viewerHasReacted),
		children: EMOJI_MAP[content]
	}, content);
}
ReactionsMenuItem.displayName = "ReactionsMenuItem";
var VALUES = {
	react: "React",
	reactionsUnavailable: "Reactions are currently unavailable",
	copilotDisplayName: "Copilot"
};
var ReactionViewerAnchor_module_default = { ReactionViewerAnchorButton: "ReactionViewerAnchor-module_NH0hva_ReactionViewerAnchorButton" };
var ReactionViewerAnchor = ({ ref, renderAnchorProps, reactionsAvailable }) => {
	const { ref: anchorRef, ...restAnchorProps } = renderAnchorProps ?? {};
	return /* @__PURE__ */ jsx(IconButton, {
		size: "small",
		icon: SmileyIcon,
		...restAnchorProps,
		"aria-label": reactionsAvailable ? VALUES.react : VALUES.reactionsUnavailable,
		inactive: !reactionsAvailable,
		"aria-labelledby": void 0,
		className: ReactionViewerAnchor_module_default.ReactionViewerAnchorButton,
		ref: mergeRefs([ref, anchorRef])
	});
};
/** Merges multiple refs into a single ref callback. */
ReactionViewerAnchor.displayName = "ReactionViewerAnchor";
function mergeRefs(refs) {
	return (value) => {
		for (const r of refs) if (typeof r === "function") r(value);
		else if (r != null) r.current = value;
	};
}
ReactionViewerAnchor.displayName = "ReactionViewerAnchor";
var ReactionViewerBase = ({ ref, reactionGroups, canReact = true, onReact }) => {
	const [isOpen, setOpen] = useState(false);
	const reactionsAvailable = reactionGroups.length > 0;
	const { containerRef } = useFocusZone({
		bindKeys: FocusKeys.HomeAndEnd | FocusKeys.ArrowHorizontal,
		focusOutBehavior: "wrap"
	});
	return /* @__PURE__ */ jsxs("div", {
		role: "toolbar",
		"aria-label": "Reactions",
		ref: containerRef,
		className: "d-flex gap-1 flex-wrap",
		children: [canReact && /* @__PURE__ */ jsx(AnchoredOverlay, {
			open: isOpen,
			onOpen: () => setOpen(reactionsAvailable),
			onClose: () => setOpen(false),
			focusZoneSettings: {
				bindKeys: FocusKeys.ArrowAll | FocusKeys.HomeAndEnd,
				focusOutBehavior: "wrap"
			},
			renderAnchor: (p) => /* @__PURE__ */ jsx(ReactionViewerAnchor, {
				renderAnchorProps: p,
				reactionsAvailable,
				ref
			}),
			children: /* @__PURE__ */ jsx(ActionList, {
				className: "d-flex flex-row p-1 gap-1",
				role: "menu",
				"aria-orientation": "horizontal",
				children: (reactionGroups || []).map((reactionGroup, index) => /* @__PURE__ */ jsx(ReactionsMenuItem, {
					reaction: reactionGroup.reaction,
					onReact: (reaction, viewerHasReacted) => {
						onReact(reaction, viewerHasReacted);
						setOpen(false);
					}
				}, index))
			})
		}), (reactionGroups || []).map((reactionGroup_0, index_0) => /* @__PURE__ */ jsx(ReactionButton, {
			reactionGroup: reactionGroup_0,
			disabled: !canReact,
			onReact: (reaction_0, viewerHasReacted_0) => onReact(reaction_0, viewerHasReacted_0)
		}, index_0))]
	});
};
ReactionViewerBase.displayName = "ReactionViewerBase";
ReactionViewerBase.displayName = "ReactionViewerBase";
var node$2 = (function() {
	var v0 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v1 = [v0];
	return {
		"argumentDefinitions": [],
		"kind": "Fragment",
		"metadata": null,
		"name": "ReactionViewerRelayGroups",
		"selections": [{
			"alias": null,
			"args": null,
			"concreteType": "ReactionGroup",
			"kind": "LinkedField",
			"name": "reactionGroups",
			"plural": true,
			"selections": [
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "content",
					"storageKey": null
				},
				{
					"alias": null,
					"args": null,
					"kind": "ScalarField",
					"name": "viewerHasReacted",
					"storageKey": null
				},
				{
					"alias": null,
					"args": [{
						"kind": "Literal",
						"name": "first",
						"value": 5
					}],
					"concreteType": "ReactorConnection",
					"kind": "LinkedField",
					"name": "reactors",
					"plural": false,
					"selections": [{
						"alias": null,
						"args": null,
						"kind": "ScalarField",
						"name": "totalCount",
						"storageKey": null
					}, {
						"alias": null,
						"args": null,
						"concreteType": null,
						"kind": "LinkedField",
						"name": "nodes",
						"plural": true,
						"selections": [
							{
								"alias": null,
								"args": null,
								"kind": "ScalarField",
								"name": "__typename",
								"storageKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v1,
								"type": "User",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": [
									v0,
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "isCopilot",
										"storageKey": null
									},
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "isAgent",
										"storageKey": null
									},
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "displayName",
										"storageKey": null
									}
								],
								"type": "Bot",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v1,
								"type": "Organization",
								"abstractKey": null
							},
							{
								"kind": "InlineFragment",
								"selections": v1,
								"type": "Mannequin",
								"abstractKey": null
							}
						],
						"storageKey": null
					}],
					"storageKey": "reactors(first:5)"
				}
			],
			"storageKey": null
		}],
		"type": "Reactable",
		"abstractKey": "__isReactable"
	};
})();
node$2.hash = "caa12ca1dcd3ac3335452a70daf0312a";
var node$1 = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "id"
	}], v1 = [{
		"kind": "Variable",
		"name": "id",
		"variableName": "id"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v4 = [v3], v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "ReactionViewerRelayLazyQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [{
					"kind": "InlineFragment",
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ReactionViewerRelayGroups"
					}],
					"type": "Comment",
					"abstractKey": "__isComment"
				}],
				"storageKey": null
			}],
			"type": "Query",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "ReactionViewerRelayLazyQuery",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": null,
				"kind": "LinkedField",
				"name": "node",
				"plural": false,
				"selections": [
					v2,
					{
						"kind": "InlineFragment",
						"selections": [{
							"kind": "InlineFragment",
							"selections": [{
								"alias": null,
								"args": null,
								"concreteType": "ReactionGroup",
								"kind": "LinkedField",
								"name": "reactionGroups",
								"plural": true,
								"selections": [
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "content",
										"storageKey": null
									},
									{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "viewerHasReacted",
										"storageKey": null
									},
									{
										"alias": null,
										"args": [{
											"kind": "Literal",
											"name": "first",
											"value": 5
										}],
										"concreteType": "ReactorConnection",
										"kind": "LinkedField",
										"name": "reactors",
										"plural": false,
										"selections": [{
											"alias": null,
											"args": null,
											"kind": "ScalarField",
											"name": "totalCount",
											"storageKey": null
										}, {
											"alias": null,
											"args": null,
											"concreteType": null,
											"kind": "LinkedField",
											"name": "nodes",
											"plural": true,
											"selections": [
												v2,
												{
													"kind": "InlineFragment",
													"selections": v4,
													"type": "User",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [
														v3,
														{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "isCopilot",
															"storageKey": null
														},
														{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "isAgent",
															"storageKey": null
														},
														{
															"alias": null,
															"args": null,
															"kind": "ScalarField",
															"name": "displayName",
															"storageKey": null
														}
													],
													"type": "Bot",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": v4,
													"type": "Organization",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": v4,
													"type": "Mannequin",
													"abstractKey": null
												},
												{
													"kind": "InlineFragment",
													"selections": [v5],
													"type": "Node",
													"abstractKey": "__isNode"
												}
											],
											"storageKey": null
										}],
										"storageKey": "reactors(first:5)"
									}
								],
								"storageKey": null
							}],
							"type": "Reactable",
							"abstractKey": "__isReactable"
						}],
						"type": "Comment",
						"abstractKey": "__isComment"
					},
					v5
				],
				"storageKey": null
			}]
		},
		"params": {
			"id": "0cd5eed9279c836f76bb3bbe66b4fc38",
			"metadata": {},
			"name": "ReactionViewerRelayLazyQuery",
			"operationKind": "query",
			"text": null
		}
	};
})();
node$1.hash = "37ec1495c4c7ace448e859305895ad0e";
var node = (function() {
	var v0 = [{
		"defaultValue": null,
		"kind": "LocalArgument",
		"name": "input"
	}], v1 = [{
		"kind": "Variable",
		"name": "input",
		"variableName": "input"
	}], v2 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "__typename",
		"storageKey": null
	}, v3 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "login",
		"storageKey": null
	}, v4 = [v3], v5 = {
		"alias": null,
		"args": null,
		"kind": "ScalarField",
		"name": "id",
		"storageKey": null
	};
	return {
		"fragment": {
			"argumentDefinitions": v0,
			"kind": "Fragment",
			"metadata": null,
			"name": "removeReactionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "RemoveReactionPayload",
				"kind": "LinkedField",
				"name": "removeReaction",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subject",
					"plural": false,
					"selections": [{
						"args": null,
						"kind": "FragmentSpread",
						"name": "ReactionViewerRelayGroups"
					}],
					"storageKey": null
				}],
				"storageKey": null
			}],
			"type": "Mutation",
			"abstractKey": null
		},
		"kind": "Request",
		"operation": {
			"argumentDefinitions": v0,
			"kind": "Operation",
			"name": "removeReactionMutation",
			"selections": [{
				"alias": null,
				"args": v1,
				"concreteType": "RemoveReactionPayload",
				"kind": "LinkedField",
				"name": "removeReaction",
				"plural": false,
				"selections": [{
					"alias": null,
					"args": null,
					"concreteType": null,
					"kind": "LinkedField",
					"name": "subject",
					"plural": false,
					"selections": [
						v2,
						{
							"kind": "TypeDiscriminator",
							"abstractKey": "__isReactable"
						},
						{
							"alias": null,
							"args": null,
							"concreteType": "ReactionGroup",
							"kind": "LinkedField",
							"name": "reactionGroups",
							"plural": true,
							"selections": [
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "content",
									"storageKey": null
								},
								{
									"alias": null,
									"args": null,
									"kind": "ScalarField",
									"name": "viewerHasReacted",
									"storageKey": null
								},
								{
									"alias": null,
									"args": [{
										"kind": "Literal",
										"name": "first",
										"value": 5
									}],
									"concreteType": "ReactorConnection",
									"kind": "LinkedField",
									"name": "reactors",
									"plural": false,
									"selections": [{
										"alias": null,
										"args": null,
										"kind": "ScalarField",
										"name": "totalCount",
										"storageKey": null
									}, {
										"alias": null,
										"args": null,
										"concreteType": null,
										"kind": "LinkedField",
										"name": "nodes",
										"plural": true,
										"selections": [
											v2,
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "User",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [
													v3,
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "isCopilot",
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "isAgent",
														"storageKey": null
													},
													{
														"alias": null,
														"args": null,
														"kind": "ScalarField",
														"name": "displayName",
														"storageKey": null
													}
												],
												"type": "Bot",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "Organization",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": v4,
												"type": "Mannequin",
												"abstractKey": null
											},
											{
												"kind": "InlineFragment",
												"selections": [v5],
												"type": "Node",
												"abstractKey": "__isNode"
											}
										],
										"storageKey": null
									}],
									"storageKey": "reactors(first:5)"
								}
							],
							"storageKey": null
						},
						v5
					],
					"storageKey": null
				}],
				"storageKey": null
			}]
		},
		"params": {
			"id": "b37799b042f0454edce6e855c46421e4",
			"metadata": {},
			"name": "removeReactionMutation",
			"operationKind": "mutation",
			"text": null
		}
	};
})();
node.hash = "8e28d0138da52c07bb0e64eda432f580";
var import_react_relay = require_react_relay();
function removeReactionMutation({ environment, input: { subject, content }, onError, onCompleted }) {
	return (0, import_react_relay.commitMutation)(environment, {
		mutation: node,
		variables: { input: {
			subjectId: subject,
			content
		} },
		optimisticUpdater: (store) => {
			const subjectRecord = store.get(subject);
			if (!subjectRecord) return;
			const reactionGroups = subjectRecord.getLinkedRecords("reactionGroups");
			if (!reactionGroups) return;
			const reactionGroupIndex = reactionGroups.findIndex((r) => r.getValue("content") === content);
			const reactionGroup = reactionGroups[reactionGroupIndex];
			if (reactionGroup) {
				reactionGroup.setValue(false, "viewerHasReacted");
				const connectionId = `client:${subject}:reactionGroups:${reactionGroupIndex}:reactors(first:5)`;
				const connection = store.get(connectionId);
				if (connection) {
					const totalCount = connection.getValue("totalCount");
					connection.setValue(totalCount && totalCount > 0 ? totalCount - 1 : 0, "totalCount");
				}
			}
		},
		onError: (error) => onError && onError(error),
		onCompleted: (response) => onCompleted && onCompleted(response)
	});
}
var ReactionGroupsFragment = node$2;
function ReactionViewerRelay(t0) {
	const $ = c(8);
	const { reactionGroups, subjectId, canReact: t1 } = t0;
	const canReact = t1 === void 0 ? true : t1;
	const environment = (0, import_react_relay.useRelayEnvironment)();
	const reactionGroupsData = (0, import_react_relay.useFragment)(ReactionGroupsFragment, reactionGroups);
	let t2;
	if ($[0] !== canReact || $[1] !== environment || $[2] !== subjectId) {
		t2 = (reaction, viewerHasReacted) => {
			if (!canReact) return;
			if (viewerHasReacted) removeReactionMutation({
				environment,
				input: {
					subject: subjectId,
					content: reaction
				}
			});
			else addReactionMutation({
				environment,
				input: {
					subject: subjectId,
					content: reaction
				}
			});
		};
		$[0] = canReact;
		$[1] = environment;
		$[2] = subjectId;
		$[3] = t2;
	} else t2 = $[3];
	const onReact = t2;
	let t3;
	if ($[4] !== canReact || $[5] !== onReact || $[6] !== reactionGroupsData.reactionGroups) {
		t3 = jsx(ReactionViewerBase, {
			reactionGroups: (reactionGroupsData.reactionGroups || []).filter(_temp).map(_temp3),
			canReact,
			onReact
		});
		$[4] = canReact;
		$[5] = onReact;
		$[6] = reactionGroupsData.reactionGroups;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
/**
* Query component for the ReactionViewer, used to fetch the reaction groups for a given subject.
* @param id The relay ID of the subject to fetch reactions for.
* @param subjectLocked Whether the subject is locked and reactions should not be allowed.
* @returns The ReactionViewer component with the fetched reaction groups.
*/
ReactionViewerRelay.displayName = "ReactionViewerRelay";
function _temp3(reactionGroup_0) {
	return {
		reaction: {
			content: reactionGroup_0.content,
			viewerHasReacted: reactionGroup_0.viewerHasReacted
		},
		reactors: reactionGroup_0.reactors?.nodes?.map(_temp2) || [],
		totalCount: reactionGroup_0.reactors?.totalCount || 0
	};
}
function _temp2(reactor) {
	if (!reactor || reactor.__typename === "%other") return {
		login: "",
		typeName: "Other"
	};
	let displayName = reactor.login;
	if (reactor.__typename === "Bot") {
		if (reactor.isCopilot) displayName = VALUES.copilotDisplayName;
		else if (reactor.isAgent && reactor.displayName) displayName = reactor.displayName;
	}
	return {
		login: displayName,
		typeName: reactor.__typename
	};
}
function _temp(reactionGroup) {
	return Boolean(reactionGroup);
}
function ReactionViewerRelayQueryComponent(t0) {
	const $ = c(7);
	const { id, subjectLocked } = t0;
	let t1;
	if ($[0] !== id) {
		t1 = { id };
		$[0] = id;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = { fetchPolicy: "store-or-network" };
		$[2] = t2;
	} else t2 = $[2];
	const data = (0, import_react_relay.useLazyLoadQuery)(node$1, t1, t2);
	if (!data.node) return null;
	const t3 = !subjectLocked;
	let t4;
	if ($[3] !== data.node || $[4] !== id || $[5] !== t3) {
		t4 = jsx(ReactionViewerRelay, {
			subjectId: id,
			reactionGroups: data.node,
			canReact: t3
		});
		$[3] = data.node;
		$[4] = id;
		$[5] = t3;
		$[6] = t4;
	} else t4 = $[6];
	return t4;
}
ReactionViewerRelayQueryComponent.displayName = "ReactionViewerRelayQueryComponent";
export { ReactionViewerRelayQueryComponent as i, ReactionViewerBase as n, ReactionViewerRelay as r, ReactionViewerAnchor as t };
