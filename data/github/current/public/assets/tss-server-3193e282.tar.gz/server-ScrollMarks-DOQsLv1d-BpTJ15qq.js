performance.mark("js-parse-end:server-ScrollMarks-DOQsLv1d-BpTJ15qq.js");
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as scrollLineIntoView, r as useCurrentStyledBlob } from "./server-use-scroll-line-into-view-DttIeP88-D69hX7MG.js";
import { n as scrollMarksContainerID } from "./server-ScrollMarksContainer-C_JiMHdh-BpHhqDYB.js";
import { jsx } from "react/jsx-runtime";
import { clsx } from "clsx";
import { createPortal } from "react-dom";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:ScrollMarks-DOQsLv1d.js");
var ScrollMarks_module_default = {
	scrollMark: "ScrollMarks-module_xOc8Qq_scrollMark",
	scrollMarksParent: "ScrollMarks-module_xOc8Qq_scrollMarksParent"
};
function ScrollMarks(t0) {
	const $ = c(5);
	const { definitionsOrReferences } = t0;
	const totalLineCount = useCurrentStyledBlob().rawLines?.length ?? 0;
	const { isBrowser } = useRuntimeEnvironment();
	let t1;
	let t2;
	if ($[0] !== definitionsOrReferences || $[1] !== isBrowser || $[2] !== totalLineCount) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const container = isBrowser ? document.getElementById(scrollMarksContainerID) : null;
			const windowHasVerticalScroll = isBrowser ? document.body.scrollHeight > window.innerHeight : false;
			if (!container) {
				t2 = null;
				break bb0;
			}
			t1 = createPortal(jsx(ScrollMarksDesign, {
				totalLineCount,
				windowHasVerticalScroll,
				definitionsOrReferences
			}), container);
		}
		$[0] = definitionsOrReferences;
		$[1] = isBrowser;
		$[2] = totalLineCount;
		$[3] = t1;
		$[4] = t2;
	} else {
		t1 = $[3];
		t2 = $[4];
	}
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
	return t1;
}
ScrollMarks.displayName = "ScrollMarks";
function ScrollMarksDesign({ definitionsOrReferences, totalLineCount, windowHasVerticalScroll }) {
	if (!windowHasVerticalScroll) return null;
	if (definitionsOrReferences.length === 0) return null;
	const marks = definitionsOrReferences.map((result) => ({
		location: result.lineNumber / totalLineCount,
		key: `find-in-file-mark:${result.path}:${result.lineNumber},${result.ident.start.column}`,
		line: result.lineNumber
	}));
	const seenLocations = /* @__PURE__ */ new Set();
	const dedupedMarks = marks.filter((mark) => {
		if (seenLocations.has(mark.location)) return false;
		seenLocations.add(mark.location);
		return true;
	});
	return /* @__PURE__ */ jsx("div", {
		"data-testid": "scroll-marks-parent",
		className: clsx("react-blob-scroll-marks", ScrollMarks_module_default.scrollMarksParent),
		children: dedupedMarks.map((mark) => /* @__PURE__ */ jsx(ScrollMark, {
			onClick: () => scrollLineIntoView({ line: mark.line }),
			markLocation: mark.location
		}, mark.key))
	});
}
ScrollMarksDesign.displayName = "ScrollMarksDesign";
function ScrollMark({ markLocation, onClick }) {
	return /* @__PURE__ */ jsx("button", {
		type: "button",
		"aria-label": "Scroll to symbol",
		"data-testid": "scroll-mark",
		className: ScrollMarks_module_default.scrollMark,
		onClick,
		style: { top: `${markLocation * 100}%` }
	});
}
ScrollMark.displayName = "ScrollMark";
export { ScrollMarksDesign, ScrollMarks as default };
