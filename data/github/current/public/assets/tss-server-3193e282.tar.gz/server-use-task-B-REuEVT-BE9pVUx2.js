import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as useDebounce } from "./server-use-debounce-Dt6MnWBo-w50nX1cm.js";
import { a as useCAPIQuery, r as fetchCAPI } from "./server-useCAPIQuery-8cpYwLDa-3T_GyMOO.js";
import { p as taskApiPath, v as useAgentSessionsAlive } from "./server-TaskLeadingVisual-DlKGcMc6-CLgHXns0.js";
import React, { createContext, use, useCallback, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CurrentUserContext = React.createContext(void 0);
CurrentUserContext.displayName = "CurrentUserContext";
function CurrentUserProvider(t0) {
	const $ = c(8);
	const { currentUser, currentUserIsSessionOwner, optedInToFeedback: t1, children } = t0;
	const optedInToFeedback = t1 === void 0 ? false : t1;
	const isSingleSessionView = !currentUserIsSessionOwner;
	let t2;
	if ($[0] !== currentUser || $[1] !== currentUserIsSessionOwner || $[2] !== isSingleSessionView || $[3] !== optedInToFeedback) {
		t2 = {
			currentUser,
			currentUserIsSessionOwner,
			isSingleSessionView,
			optedInToFeedback
		};
		$[0] = currentUser;
		$[1] = currentUserIsSessionOwner;
		$[2] = isSingleSessionView;
		$[3] = optedInToFeedback;
		$[4] = t2;
	} else t2 = $[4];
	const value = t2;
	let t3;
	if ($[5] !== children || $[6] !== value) {
		t3 = jsxs(CurrentUserContext, {
			value,
			children: [
				" ",
				children,
				" "
			]
		});
		$[5] = children;
		$[6] = value;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
CurrentUserProvider.displayName = "CurrentUserProvider";
function useCurrentUser() {
	const context = React.use(CurrentUserContext);
	if (!context) throw new Error("useCurrentUser must be used within a CurrentUserProvider");
	return context;
}
var ChatStreamContext = createContext(void 0);
ChatStreamContext.displayName = "ChatStreamContext";
function ChatStreamProvider({ children }) {
	const [streamingState, setStreamingState] = useState("closed");
	const [chatHistoryBySession, setChatHistoryBySession] = useState({});
	const [pendingChatMessage, setPendingChatMessage] = useState(null);
	const pendingChatMessageRef = useRef(null);
	const [latestChatSessionId, setLatestChatSessionId] = useState(null);
	const setPendingChat = useCallback((chat) => {
		if (chat) {
			const msg = {
				role: "user",
				content: chat,
				id: "",
				threadID: ""
			};
			pendingChatMessageRef.current = msg;
			setPendingChatMessage(msg);
		}
	}, []);
	const clearPendingChat = useCallback(() => {
		pendingChatMessageRef.current = null;
		setPendingChatMessage(null);
	}, []);
	const setStreamingChatResponse = useCallback((sessionId, response) => {
		if (response) {
			setStreamingState("receiving");
			if (sessionId) setLatestChatSessionId(sessionId);
			const pending = pendingChatMessageRef.current;
			pendingChatMessageRef.current = null;
			setChatHistoryBySession((prev) => {
				const sessionHistory = prev[sessionId] ?? [];
				if (pending) return {
					...prev,
					[sessionId]: [
						...sessionHistory,
						pending,
						{
							role: "assistant",
							content: response,
							id: "",
							threadID: ""
						}
					]
				};
				const last = sessionHistory[sessionHistory.length - 1];
				if (last && last.role === "assistant") return {
					...prev,
					[sessionId]: [...sessionHistory.slice(0, -1), {
						role: "assistant",
						content: response,
						id: "",
						threadID: ""
					}]
				};
				return {
					...prev,
					[sessionId]: [...sessionHistory, {
						role: "assistant",
						content: response,
						id: "",
						threadID: ""
					}]
				};
			});
			setPendingChatMessage(null);
		}
	}, []);
	const getChatMessageHistory = useCallback((sessionId_0) => {
		const history = chatHistoryBySession[sessionId_0] ?? [];
		if (pendingChatMessage && sessionId_0 === latestChatSessionId) return [...history, pendingChatMessage];
		return history;
	}, [
		chatHistoryBySession,
		pendingChatMessage,
		latestChatSessionId
	]);
	return /* @__PURE__ */ jsx(ChatStreamContext, {
		value: useMemo(() => ({
			setPendingChat,
			clearPendingChat,
			setStreamingChatResponse,
			setStreamingState,
			streamingState,
			getChatMessageHistory,
			pendingChatMessage,
			latestChatSessionId
		}), [
			setPendingChat,
			clearPendingChat,
			setStreamingChatResponse,
			streamingState,
			getChatMessageHistory,
			pendingChatMessage,
			latestChatSessionId
		]),
		children
	});
}
ChatStreamProvider.displayName = "ChatStreamProvider";
function useChatStreamContext() {
	const context = use(ChatStreamContext);
	if (!context) throw new Error("useChatStreamContext must be used within a ChatStreamProvider");
	return context;
}
/**
* Normalizes a Task API session (with structured objects) to the standard Session type.
* Strips the structured `user`, `owner`, and `repository` fields and replaces them with flat IDs.
*/
function normalizeTaskAPISession(raw) {
	const { user, owner, repository, ...rest } = raw;
	return {
		...rest,
		user_id: user?.id,
		owner_id: owner?.id,
		repo_id: repository?.id
	};
}
/**
* Normalizes a raw Task API response to a HydratedAPITask with standard Session objects.
*/
function normalizeHydratedAPITask(raw) {
	return {
		...raw,
		sessions: (raw.sessions ?? []).map(normalizeTaskAPISession)
	};
}
var agentTaskQueryKey = (owner, repo, taskId) => [
	"agent-task",
	taskId,
	owner,
	repo
];
var fetchTask = async ({ owner, repo, taskId }) => {
	const data = await (await fetchCAPI({ path: taskApiPath(owner, repo, taskId) })).json();
	return normalizeHydratedAPITask(data.task ?? data);
};
function useTask(t0) {
	const $ = c(30);
	const { owner, repo, taskId, initialTask, sessionsPollingInterval: t1 } = t0;
	const sessionsPollingInterval = t1 === void 0 ? 3e3 : t1;
	const queryClient = useQueryClient();
	let t2;
	if ($[0] !== owner || $[1] !== queryClient || $[2] !== repo || $[3] !== taskId) {
		t2 = (payload) => {
			if (payload?.task_id === taskId) queryClient.invalidateQueries({ queryKey: agentTaskQueryKey(owner, repo, taskId) });
		};
		$[0] = owner;
		$[1] = queryClient;
		$[2] = repo;
		$[3] = taskId;
		$[4] = t2;
	} else t2 = $[4];
	const handleAliveUpdate = t2;
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { maxWait: 1e4 };
		$[5] = t3;
	} else t3 = $[5];
	const debouncedHandleAliveUpdate = useDebounce(handleAliveUpdate, sessionsPollingInterval, t3);
	let t4;
	if ($[6] !== owner || $[7] !== repo || $[8] !== taskId) {
		t4 = isFeatureEnabled("copilot_mission_control_task_alive_updates") && !!owner && !!repo && !!taskId;
		$[6] = owner;
		$[7] = repo;
		$[8] = taskId;
		$[9] = t4;
	} else t4 = $[9];
	const isTaskAliveEnabled = t4;
	let t5;
	if ($[10] !== debouncedHandleAliveUpdate || $[11] !== isTaskAliveEnabled) {
		t5 = {
			onEvent: debouncedHandleAliveUpdate,
			enableCreateEvents: false,
			enableUpdateEvents: false,
			enableLogUpdates: false,
			enableTaskUpdates: true,
			enabled: isTaskAliveEnabled
		};
		$[10] = debouncedHandleAliveUpdate;
		$[11] = isTaskAliveEnabled;
		$[12] = t5;
	} else t5 = $[12];
	useAgentSessionsAlive(t5);
	let t6;
	if ($[13] !== owner || $[14] !== repo || $[15] !== taskId) {
		t6 = agentTaskQueryKey(owner, repo, taskId);
		$[13] = owner;
		$[14] = repo;
		$[15] = taskId;
		$[16] = t6;
	} else t6 = $[16];
	let t7;
	if ($[17] !== owner || $[18] !== repo || $[19] !== taskId) {
		t7 = () => {
			if (!owner || !repo) throw new Error("owner and repo are required");
			if (!taskId) throw new Error("taskId is required");
			return fetchTask({
				taskId,
				owner,
				repo
			});
		};
		$[17] = owner;
		$[18] = repo;
		$[19] = taskId;
		$[20] = t7;
	} else t7 = $[20];
	const t8 = !!taskId && !!owner && !!repo;
	let t9;
	if ($[21] !== initialTask || $[22] !== t6 || $[23] !== t7 || $[24] !== t8) {
		t9 = {
			queryKey: t6,
			queryFn: t7,
			initialData: initialTask,
			enabled: t8
		};
		$[21] = initialTask;
		$[22] = t6;
		$[23] = t7;
		$[24] = t8;
		$[25] = t9;
	} else t9 = $[25];
	const query = useCAPIQuery(t9);
	const t10 = query.isLoading && !query.data;
	let t11;
	if ($[26] !== query.data || $[27] !== query.isError || $[28] !== t10) {
		t11 = {
			data: query.data,
			isLoading: t10,
			isError: query.isError
		};
		$[26] = query.data;
		$[27] = query.isError;
		$[28] = t10;
		$[29] = t11;
	} else t11 = $[29];
	return t11;
}
export { useCurrentUser as a, useChatStreamContext as i, CurrentUserProvider as n, useTask as o, agentTaskQueryKey as r, ChatStreamProvider as t };
