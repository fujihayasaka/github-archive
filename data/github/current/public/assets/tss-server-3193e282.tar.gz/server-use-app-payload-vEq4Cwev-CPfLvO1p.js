import { createContext, use } from "react";
/**
* Shim for @github-ui/react-core/use-app-payload
* Returns hardcoded values for the app payload since tss-server doesn't use
* the Data Router's app payload mechanism.
*/
var AppPayloadContext = createContext(void 0);
/**
* Stub implementation of useAppPayload.
* Returns hardcoded values for development purposes.
*
* Temporary workaround pending https://github.com/github/react-platform/issues/1524
*/
AppPayloadContext.displayName = "AppPayloadContext";
function useAppPayload() {
	const contextValue = use(AppPayloadContext);
	if (contextValue !== void 0) return contextValue;
	return {
		helpUrl: "https://docs.github.com",
		findFileWorkerPath: "",
		findInFileWorkerPath: "",
		githubDevUrl: "https://github.dev"
	};
}
export { useAppPayload as n, AppPayloadContext as t };
