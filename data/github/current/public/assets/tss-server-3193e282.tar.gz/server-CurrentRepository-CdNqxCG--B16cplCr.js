import React from "react";
import { jsxs } from "react/jsx-runtime";
var CurrentRepositoryContext = React.createContext({});
CurrentRepositoryContext.displayName = "CurrentRepositoryContext";
function CurrentRepositoryProvider({ repository, children }) {
	return /* @__PURE__ */ jsxs(CurrentRepositoryContext, {
		value: repository,
		children: [
			" ",
			children,
			" "
		]
	});
}
CurrentRepositoryProvider.displayName = "CurrentRepositoryProvider";
function useCurrentRepository() {
	return React.use(CurrentRepositoryContext);
}
export { useCurrentRepository as n, CurrentRepositoryProvider as t };
