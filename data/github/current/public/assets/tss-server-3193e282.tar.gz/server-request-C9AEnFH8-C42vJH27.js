import { t as FETCH_NONCE_HEADER } from "./server-fetch-nonce-CQRTCHX--Bxo3Ybl_.js";
import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";
var requestAsyncLocalStorage = new AsyncLocalStorage();
/**
* Run a function with a request context.
* This should be called at the server entry point to set the current request.
*
* @param request - The current HTTP request
* @param fn - The function to run with the request context
* @returns The result of the function
*/
function runWithRequestContext(request, fn) {
	return requestAsyncLocalStorage.run({ request }, fn);
}
/**
* Get the current request from the async local storage context.
*
* @returns The current request
* @throws {Error} If not called within a request context
*/
function getCurrentRequest() {
	const context = requestAsyncLocalStorage.getStore();
	if (!context) throw new Error("getCurrentRequest() must be called within a request context");
	return context.request;
}
/**
* Get the parsed URL for the current request.
* The result is cached on the request context so the URL is parsed at most once per request.
*
* @returns The parsed URL
* @throws {Error} If not called within a request context
*/
function getParsedRequestUrl() {
	const context = requestAsyncLocalStorage.getStore();
	if (!context) throw new Error("getParsedRequestUrl() must be called within a request context");
	if (!context.parsedUrl) context.parsedUrl = new URL(context.request.url);
	return context.parsedUrl;
}
/**
* Get normalized host information for the current request.
* The result is cached on the request context so it is derived at most once per request.
*
* Trust incoming x-forwarded-* values only when the full host/proto/port tuple is present.
* Otherwise fall back to the current request's Host header and parsed URL.
*
* @returns The normalized host info for the current request
* @throws {Error} If not called within a request context
*/
function getRequestHostInfo() {
	const context = requestAsyncLocalStorage.getStore();
	if (!context) throw new Error("getRequestHostInfo() must be called within a request context");
	if (!context.requestHostInfo) {
		const forwardedHost = context.request.headers.get("x-forwarded-host");
		const forwardedProto = context.request.headers.get("x-forwarded-proto");
		const forwardedPort = context.request.headers.get("x-forwarded-port");
		if (forwardedHost && forwardedProto && forwardedPort) context.requestHostInfo = {
			host: forwardedHost,
			proto: forwardedProto,
			port: forwardedPort
		};
		else {
			const requestUrl = getParsedRequestUrl();
			context.requestHostInfo = {
				host: context.request.headers.get("host") || requestUrl.host,
				proto: requestUrl.protocol.replace(":", ""),
				port: requestUrl.port || (requestUrl.protocol === "https:" ? "443" : "80")
			};
		}
	}
	return context.requestHostInfo;
}
/**
* Get a header value from the current request.
*
* @param name - The header name to retrieve
* @returns The header value, or null if not found
* @throws {Error} If not called within a request context
*/
function getRequestHeader(name) {
	return getCurrentRequest().headers.get(name);
}
/**
* Get a cookie value from the current request.
*
* @param name - The cookie name to retrieve
* @returns The cookie value, or null if not found
* @throws {Error} If not called within a request context
*/
function getCookie(name) {
	const context = requestAsyncLocalStorage.getStore();
	if (!context) throw new Error("getCookie() must be called within a request context");
	context.parsedCookies ??= parseCookieHeader(context.request.headers.get("cookie"));
	context.decodedCookies ??= /* @__PURE__ */ new Map();
	if (context.decodedCookies.has(name)) return context.decodedCookies.get(name) ?? null;
	const rawValue = context.parsedCookies.get(name);
	const decoded = rawValue !== void 0 ? decodeURIComponent(rawValue) : null;
	context.decodedCookies.set(name, decoded);
	return decoded;
}
function parseCookieHeader(cookieHeader) {
	const result = /* @__PURE__ */ new Map();
	if (!cookieHeader) return result;
	const cookies = cookieHeader.split(";").map((c) => c.trim());
	for (const cookie of cookies) {
		const parts = cookie.split("=");
		const key = parts[0]?.trim();
		if (key) result.set(key, parts.slice(1).join("=").trim());
	}
	return result;
}
/**
* Get the current request's fetch nonce.
*
* Uses the inbound `x-fetch-nonce` header if present, otherwise lazily generates
* and memoizes a nonce for the current request context.
*
* @returns The request-scoped fetch nonce
* @throws {Error} If not called within a request context
*/
function getOrCreateRequestFetchNonce() {
	const context = requestAsyncLocalStorage.getStore();
	if (!context) throw new Error("getOrCreateRequestFetchNonce() must be called within a request context");
	if (context.fetchNonce) return context.fetchNonce;
	const requestNonce = context.request.headers.get(FETCH_NONCE_HEADER);
	if (requestNonce) {
		context.fetchNonce = requestNonce;
		return requestNonce;
	}
	const generatedNonce = `v2:${randomUUID()}`;
	context.fetchNonce = generatedNonce;
	return generatedNonce;
}
export { getRequestHeader as a, getParsedRequestUrl as i, getCurrentRequest as n, getRequestHostInfo as o, getOrCreateRequestFetchNonce as r, runWithRequestContext as s, getCookie as t };
