import React from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var classes = { "Flash": "prc-Flash-Flash-q6HW0" };
var Flash = /* @__PURE__ */ React.forwardRef(function Flash(t0, ref) {
	const $ = c(15);
	let className;
	let full;
	let rest;
	let t1;
	let t2;
	if ($[0] !== t0) {
		({as: t1, className, variant: t2, full, ...rest} = t0);
		$[0] = t0;
		$[1] = className;
		$[2] = full;
		$[3] = rest;
		$[4] = t1;
		$[5] = t2;
	} else {
		className = $[1];
		full = $[2];
		rest = $[3];
		t1 = $[4];
		t2 = $[5];
	}
	const BaseComponent = t1 === void 0 ? "div" : t1;
	const variant = t2 === void 0 ? "default" : t2;
	let t3;
	if ($[6] !== className) {
		t3 = clsx(classes.Flash, className);
		$[6] = className;
		$[7] = t3;
	} else t3 = $[7];
	const t4 = full ? "" : void 0;
	let t5;
	if ($[8] !== BaseComponent || $[9] !== ref || $[10] !== rest || $[11] !== t3 || $[12] !== t4 || $[13] !== variant) {
		t5 = /* @__PURE__ */ jsx(BaseComponent, {
			...rest,
			ref,
			className: t3,
			"data-full": t4,
			"data-variant": variant
		});
		$[8] = BaseComponent;
		$[9] = ref;
		$[10] = rest;
		$[11] = t3;
		$[12] = t4;
		$[13] = variant;
		$[14] = t5;
	} else t5 = $[14];
	return t5;
});
export { Flash as t };
