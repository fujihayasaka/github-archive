import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
/**
* AuthToken represents an authentication token that is passed to CAPI, which is used to pull resources
* from the monolith.
*
* It is capable of determining which authorization scheme to use (Bearer for SSATs or our own
* GitHub-Bearer for user tokens).
*
* It also can tell if it needs refreshing, i.e. if it is expired or if the SSO orgs have changed since
* it was minted.
*
* AuthToken doesn't care where the list of SSO orgs comes from.  Typically they are hydrated into a React
* partial/component via props sent from the server, which would require a page refresh to receive the
* current list, but they could theoretically come from other places too, like API calls...
*
* Finally, it can convert itself to/from ordinary JS objects that can be stored/retrieved from
* local storage.
*/
var AuthToken = class AuthToken {
	value;
	expiration;
	ssoOrgIDs;
	constructor(value, expiration, ssoOrgIDs) {
		this.value = value;
		this.expiration = expiration;
		this.ssoOrgIDs = ssoOrgIDs;
	}
	/**
	* Returns a formatted string to be used as the value of an `Authorization` header
	* to be "GitHub-Bearer <encrypted token>"
	*/
	get authorizationHeaderValue() {
		return `GitHub-Bearer ${this.value}`;
	}
	/**
	* Returns true if this auth token needs to be refreshed.
	*/
	needsRefreshing(providerSsoOrgIds) {
		return this.isExpired || this.ssoChanged(providerSsoOrgIds);
	}
	/**
	* Returns true if this auth token is expired.
	*/
	get isExpired() {
		const expirationDateString = new Date(this.expiration);
		return new Date(Date.UTC(expirationDateString.getUTCFullYear(), expirationDateString.getUTCMonth(), expirationDateString.getUTCDate(), expirationDateString.getUTCHours(), expirationDateString.getUTCMinutes(), expirationDateString.getUTCSeconds(), expirationDateString.getUTCMilliseconds())) < new Date(Date.now() + 15 * 1e3);
	}
	/**
	* Returns true if the session's SSO'd organizations have changed since the token was originally issued.
	*
	* Technically the set of orgs is inverted, representing the orgs that are *not* SSO'd, but functionally
	* it will operate the same.
	*/
	ssoChanged(providerSsoOrgIds) {
		return !(this.ssoOrgIDs.every((org) => providerSsoOrgIds.includes(org)) && providerSsoOrgIds.every((org) => this.ssoOrgIDs.includes(org)));
	}
	/**
	* Build a new AuthToken from the results of a call to the token API endpoint.
	*/
	static fromResult(result, providerSsoOrgIds) {
		return new AuthToken(result.token, result.expiration, result.ssoOrgIDs ?? providerSsoOrgIds);
	}
	/**
	* Convert this token into a plain JS object, which can be stringified and put into localStorage.
	*/
	serialize() {
		return {
			value: this.value,
			expiration: this.expiration,
			ssoOrgIDs: this.ssoOrgIDs
		};
	}
	/**
	* Build a new auth token from a plain JS object, i.e. one parsed from localStorage.
	*/
	static deserialize(serialized) {
		return new AuthToken(serialized.value, serialized.expiration, serialized.ssoOrgIDs);
	}
};
var COPILOT_AUTH_TOKEN_KEY = "COPILOT_AUTH_TOKEN";
var CopilotAuthTokenProvider = class {
	tokenEndpoint;
	storageKey;
	ssoOrgIDs;
	currentAuthTokenRequest;
	isUnlicensed;
	copilotLocalStorage;
	constructor(ssoOrgIDs, tokenEndpoint = "/github-copilot/chat/token", storageKey = COPILOT_AUTH_TOKEN_KEY) {
		this.ssoOrgIDs = ssoOrgIDs;
		this.currentAuthTokenRequest = null;
		this.isUnlicensed = false;
		this.copilotLocalStorage = safeStorage("localStorage", {
			throwQuotaErrorsOnSet: false,
			ttl: 1e3 * 60 * 60 * 24
		});
		this.storageKey = storageKey;
		this.tokenEndpoint = tokenEndpoint;
	}
	/**
	* Get the current auth token, either from local storage or by minting a new one from dotcom.
	*/
	async getAuthToken() {
		if (this.isUnlicensed) throw new CopilotAuthTokenUnlicensedError("User is not licensed for Copilot");
		const token = this.getLocalStorageAuthToken();
		return token ? this.validateAuthToken(token) : this.fetchAuthToken();
	}
	setLocalStorageAuthToken(token) {
		this.copilotLocalStorage.setItem(this.storageKey, JSON.stringify(token.serialize()));
	}
	getLocalStorageAuthToken() {
		const value = this.copilotLocalStorage.getItem(this.storageKey);
		return value ? AuthToken.deserialize(JSON.parse(value)) : null;
	}
	removeLocalStorageAuthToken() {
		this.copilotLocalStorage.removeItem(this.storageKey);
	}
	/**
	* Validate the given auth token.  If it's all good, return it, otherwise, go mint a new one from
	* dotcom and return it instead.
	*/
	async validateAuthToken(token) {
		return token.needsRefreshing(this.ssoOrgIDs) ? this.fetchAuthToken() : token;
	}
	/**
	* Return the current auth token request, or start a new one.
	*
	* The inner workings of the chat app can cause multiple requests to CAPI in quick succession.  If we
	* do not have an auth token available in local storage, each of those requests will trigger their own
	* token fetch, hence the storing of the current request on `this`.
	*
	* @param forceRefresh - If true, bypasses server-side caching (e.g., after a 401 due to token eviction)
	*/
	fetchAuthToken(forceRefresh = false) {
		if (forceRefresh) this.currentAuthTokenRequest = null;
		if (!this.currentAuthTokenRequest) this.currentAuthTokenRequest = this._fetchAuthToken(forceRefresh);
		return this.currentAuthTokenRequest;
	}
	/**
	* Start a new auth token request, parsing the result, persisting it in local storage,
	* and clearing the current request once finished.
	*
	* @param forceRefresh - If true, appends force_refresh=true to the request URL
	*/
	async _fetchAuthToken(forceRefresh = false) {
		try {
			const response = await verifiedFetchJSON(forceRefresh ? `${this.tokenEndpoint}?force_refresh=true` : this.tokenEndpoint, { method: "POST" });
			if (response.ok) {
				const result = await response.json();
				const token = AuthToken.fromResult(result, this.ssoOrgIDs);
				this.ssoOrgIDs = token.ssoOrgIDs;
				this.setLocalStorageAuthToken(token);
				this.isUnlicensed = false;
				return token;
			} else {
				if (response.status === 404) {
					this.isUnlicensed = true;
					throw new CopilotAuthTokenUnlicensedError("Copilot auth token endpoint not found (404)");
				}
				throw new Error("Failed to mint new auth token");
			}
		} finally {
			this.currentAuthTokenRequest = null;
		}
	}
};
var CopilotAuthTokenUnlicensedError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "CopilotAuthTokenUnlicensedError";
	}
};
export { COPILOT_AUTH_TOKEN_KEY as n, CopilotAuthTokenProvider as r, AuthToken as t };
