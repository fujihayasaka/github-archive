import { m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Hi as useProvidedRefOrCreate } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { n as throttle } from "./server-dist-CJwx2KGE.js";
import { c as useFormControlForwardedProps } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { a as getSuggestionValue, i as getSuggestionKey, n as augmentHandler, o as isNullSuggestion, r as calculateSuggestionsQuery, s as requireChildrenToBeInput, t as AutocompleteSuggestions } from "./server-AutocompleteSuggestions-BusBaWrA-D-epQMWF.js";
import { o as ScopedCommands } from "./server-ui-commands-h-3UYCUO-BOqB1_nM.js";
import { cloneElement, useCallback, useEffect, useId, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { InputRange } from "dom-input-range";
var calculateNewCaretPosition = (originalCaretPosition, replaceRange, insertLength) => {
	const lengthDifference = insertLength - (replaceRange[1] - replaceRange[0]);
	return originalCaretPosition < replaceRange[0] ? originalCaretPosition : originalCaretPosition < replaceRange[1] ? replaceRange[0] + insertLength : originalCaretPosition + lengthDifference;
};
/**
* Builds a fake `React.ChangeEvent` from a dispatched `InputEvent` instance.
* This is only used as a fallback in cases where browsers don't support `execCommand`.
*/
var SyntheticChangeEvent = (dispatchedEvent, target) => ({
	...dispatchedEvent,
	nativeEvent: dispatchedEvent,
	target,
	currentTarget: target,
	preventDefault: () => dispatchedEvent.preventDefault(),
	isDefaultPrevented: () => dispatchedEvent.defaultPrevented,
	isPropagationStopped: () => false,
	persist: () => ({})
});
/**
* Returns a function that will synthetically change the input, attempting to maintain caret position and undo history
* as though the user had typed using a keyboard.
*
* Will first attempt to use the non-standard browser `execCommmand` API to simulate a typing
* action. Failing this (ie, in test environments or certain browsers), the fallback handler
* will be called with a fake constructed `ChangeEvent` that looks like a real event.
*/
SyntheticChangeEvent.displayName = "SyntheticChangeEvent";
var useSyntheticChange = ({ inputRef, fallbackEventHandler }) => useCallback((insertValue, replaceRange_, newSelection_) => {
	const input = inputRef.current;
	if (!input) return;
	const previousActiveElement = document.activeElement;
	input.focus();
	const replaceRange = replaceRange_ ?? [input.selectionStart ?? input.value.length, input.selectionEnd ?? input.value.length];
	const newSelectionStart = newSelection_ === void 0 ? calculateNewCaretPosition(input.selectionStart ?? input.value.length, replaceRange, insertValue.length) : Array.isArray(newSelection_) ? newSelection_[0] : newSelection_;
	const newSelectionEnd = Array.isArray(newSelection_) ? newSelection_[1] : newSelectionStart;
	let execCommandResult = false;
	try {
		if (document.activeElement !== input) throw new Error("Input must be focused to use execCommand");
		input.setSelectionRange(replaceRange[0], replaceRange[1]);
		execCommandResult = insertValue === "" ? document.execCommand("delete", false) : document.execCommand("insertText", false, insertValue);
		input.setSelectionRange(newSelectionStart, newSelectionEnd);
	} catch {
		execCommandResult = false;
	}
	if (previousActiveElement instanceof HTMLInputElement || previousActiveElement instanceof HTMLTextAreaElement) previousActiveElement.focus();
	if (!execCommandResult) {
		const newValue = input.value.slice(0, replaceRange[0]) + insertValue + input.value.slice(replaceRange[1]);
		const event = new InputEvent("input", { bubbles: false });
		input.value = newValue;
		input.setSelectionRange(newSelectionStart, newSelectionEnd);
		input.dispatchEvent(event);
		fallbackEventHandler(SyntheticChangeEvent(event, input));
	}
}, [inputRef, fallbackEventHandler]);
var InlineAutocomplete_module_default = {
	container: "InlineAutocomplete-module_fZ-cTq_container",
	fullWidth: "InlineAutocomplete-module_fZ-cTq_fullWidth"
};
var getSelectionStart = (element) => {
	try {
		return element.selectionStart;
	} catch (e) {
		if (e instanceof TypeError) return null;
		throw e;
	}
};
var noop = () => {};
/**
* Shows suggestions to complete the current word/phrase the user is actively typing.
*/
var InlineAutocomplete = ({ inputRef: externalInputRef, containerClassName = "", triggers, suggestions, onShowSuggestions, onHideSuggestions, onSelectSuggestion, shouldReplaceText, style, children, tabInsertsSuggestions = false, suggestionsPlacement = "below", portalName, fullWidth = false, title: menuTitle, asMenu, ...externalInputProps }) => {
	const [, setScrollKey] = useState(0);
	const inputProps = useFormControlForwardedProps(externalInputProps);
	const inputRef = useProvidedRefOrCreate(externalInputRef);
	useRefObjectAsForwardedRef(children.props.ref ?? noop, inputRef);
	const externalInput = requireChildrenToBeInput(children, inputRef);
	const emitSyntheticChange = useSyntheticChange({
		inputRef,
		fallbackEventHandler: externalInput.props.onChange ?? noop
	});
	/** Stores the query that caused the current suggestion list to appear. */
	const showEventRef = useRef(null);
	const { isBrowser } = useRuntimeEnvironment();
	const suggestionsVisible = isBrowser && suggestions !== null && suggestions.length > 0;
	const [activeSuggestionKey, setActiveSuggestionKey] = useState();
	const activeSuggestion = Array.isArray(suggestions) ? suggestions.find((s) => getSuggestionKey(s) === activeSuggestionKey) ?? suggestions[0] : void 0;
	if (activeSuggestionKey && !suggestionsVisible) setActiveSuggestionKey(void 0);
	useEffect(() => {
		if (suggestionsVisible) {
			const onScroll = throttle(() => setScrollKey((current) => current + 1), 100);
			document.addEventListener("scroll", onScroll, { capture: true });
			return () => {
				document.removeEventListener("scroll", onScroll, { capture: true });
			};
		}
	}, [suggestionsVisible]);
	const triggerCharCoords = inputRef.current && showEventRef.current && suggestionsVisible ? new InputRange(inputRef.current, (getSelectionStart(inputRef.current) ?? 0) - showEventRef.current.query.length).getBoundingClientRect() : {
		top: 0,
		left: 0,
		height: 0
	};
	const onBlur = () => {
		onHideSuggestions();
	};
	const navigate = (direction) => {
		if (!activeSuggestion || !Array.isArray(suggestions)) return;
		const setActiveSuggestion = (suggestion) => {
			setActiveSuggestionKey(suggestion ? getSuggestionKey(suggestion) : void 0);
		};
		switch (direction) {
			case "up":
				setActiveSuggestion(suggestions[suggestions.indexOf(activeSuggestion) - 1] ?? suggestions.at(-1));
				break;
			case "down":
				setActiveSuggestion(suggestions[suggestions.indexOf(activeSuggestion) + 1] ?? suggestions[0]);
				break;
			case "start":
				setActiveSuggestion(suggestions[0]);
				break;
			case "end":
				setActiveSuggestion(suggestions.at(-1));
				break;
		}
	};
	const onKeyDown = (event) => {
		if (!suggestionsVisible) return;
		switch (event.key) {
			case "ArrowRight":
			case "ArrowLeft":
				onHideSuggestions();
				break;
			case "Tab": if (!tabInsertsSuggestions) {
				onHideSuggestions();
				break;
			}
		}
	};
	const onChange = (event_0) => {
		const selectionStart = getSelectionStart(event_0.currentTarget);
		if (selectionStart === null) {
			onHideSuggestions();
			return;
		}
		const query = calculateSuggestionsQuery(triggers, event_0.currentTarget.value, selectionStart);
		showEventRef.current = query && {
			...query,
			target: event_0.currentTarget
		};
		if (showEventRef.current) onShowSuggestions(showEventRef.current);
		else onHideSuggestions();
	};
	const onCommit = (suggestion_0 = activeSuggestion) => {
		if (!suggestion_0) return;
		const isMultistep = isNullSuggestion(suggestion_0);
		const value = getSuggestionValue(suggestion_0) ?? "";
		if (!inputRef.current || !showEventRef.current) return;
		const { query: query_0, trigger } = showEventRef.current;
		const currentCaretPosition = getSelectionStart(inputRef.current) ?? 0;
		const deleteLength = query_0.length + trigger.triggerChar.length;
		const startIndex = currentCaretPosition - deleteLength;
		const selectEvent = {
			suggestion: suggestion_0,
			trigger,
			query: query_0,
			target: inputRef.current
		};
		const shouldReplace = shouldReplaceText?.(selectEvent) ?? true;
		let replacement;
		if (shouldReplace) replacement = `${isMultistep || (trigger.keepTriggerCharOnCommit ?? true) ? trigger.triggerChar : ""}${value}${!isMultistep && (trigger.insertSpaceOnCommit ?? true) ? " " : ""}`;
		else replacement = "";
		onHideSuggestions();
		emitSyntheticChange(replacement, [startIndex, startIndex + deleteLength]);
		onSelectSuggestion?.(selectEvent);
	};
	const listId = useId();
	const getSuggestionId = (suggestion_1) => `${listId}-${getSuggestionKey(suggestion_1)}`;
	const asCombobox = !asMenu;
	const input = cloneElement(externalInput, {
		...inputProps,
		onBlur: augmentHandler(externalInput.props.onBlur, onBlur),
		onKeyDownCapture: augmentHandler(externalInput.props.onKeyDownCapture, onKeyDown),
		onChange: augmentHandler(externalInput.props.onChange, onChange),
		ref: inputRef,
		role: suggestionsVisible && asCombobox ? "combobox" : externalInput.props.role,
		["aria-expanded"]: suggestionsVisible && asCombobox ? "true" : externalInput.props["aria-expanded"],
		["aria-activedescendant"]: activeSuggestion ? getSuggestionId(activeSuggestion) : externalInput.props["aria-activedescendant"],
		["aria-controls"]: suggestionsVisible && asCombobox ? listId : externalInput.props["aria-controls"],
		["aria-owns"]: suggestionsVisible && asMenu ? listId : externalInput.props["aria-owns"],
		["aria-autocomplete"]: suggestionsVisible && asCombobox ? "list" : externalInput.props["aria-autocomplete"],
		["aria-haspopup"]: suggestionsVisible && asCombobox ? "listbox" : externalInput.props["aria-haspopup"]
	});
	return /* @__PURE__ */ jsxs(ScopedCommands, {
		commands: suggestionsVisible ? {
			"github:cancel": () => onHideSuggestions(),
			"github:select": () => onCommit(),
			"github:focus-next": tabInsertsSuggestions ? () => onCommit() : void 0,
			"github:down": () => navigate("down"),
			"github:up": () => navigate("up"),
			"github:go-to-start": () => navigate("start"),
			"github:go-to-end": () => navigate("end")
		} : {},
		className: clsx(InlineAutocomplete_module_default.container, fullWidth && InlineAutocomplete_module_default.fullWidth, containerClassName),
		style,
		children: [input, /* @__PURE__ */ jsx(AutocompleteSuggestions, {
			id: listId,
			suggestions,
			inputRef,
			onCommit,
			onClose: onHideSuggestions,
			triggerCharCoords,
			visible: suggestionsVisible,
			defaultPlacement: suggestionsPlacement,
			portalName,
			activeSuggestion,
			getSuggestionId,
			menuTitle,
			role: asMenu ? "menu" : "listbox",
			tabInsertsSuggestions
		})]
	});
};
InlineAutocomplete.displayName = "InlineAutocomplete";
export { useSyntheticChange as n, InlineAutocomplete as t };
