import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as getCurrentReactAppName, u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
var { getItem, setItem, removeItem } = safeStorage("sessionStorage");
var SOFT_NAV_FAIL = "soft-nav:fail";
var SOFT_NAV_FAIL_REFERRER = "soft-nav:fail-referrer";
var SOFT_NAV_REFERRER = "soft-nav:referrer";
var SOFT_NAV_MARK = "soft-nav:marker";
var SOFT_NAV_REACT_APP_NAME = "soft-nav:react-app-name";
var SOFT_NAV_LATEST_MECHANISM = "soft-nav:latest-mechanism";
function clearSoftNav() {
	setItem(SOFT_NAV_MARK, "0");
	removeItem(SOFT_NAV_REFERRER);
	removeItem(SOFT_NAV_FAIL);
	removeItem(SOFT_NAV_FAIL_REFERRER);
	removeItem(SOFT_NAV_REACT_APP_NAME);
	removeItem(SOFT_NAV_LATEST_MECHANISM);
}
function setSoftNavMechanism(mechanism) {
	setItem(SOFT_NAV_MARK, mechanism);
}
function unsetSoftNav() {
	setItem(SOFT_NAV_MARK, "0");
}
function inSoftNav() {
	const softNav = getItem(SOFT_NAV_MARK);
	return softNav && softNav !== "0";
}
function getSoftNavMechanism() {
	return getItem(SOFT_NAV_MARK);
}
function getSoftNavFailReason() {
	return getItem(SOFT_NAV_FAIL);
}
function setSoftNavReferrer() {
	setItem(SOFT_NAV_REFERRER, window.location.href);
}
function getSoftNavReferrer() {
	return getItem("soft-nav:referrer") || document.referrer;
}
function setSoftNavReactAppName() {
	const appName = getCurrentReactAppName();
	if (appName) setItem(SOFT_NAV_REACT_APP_NAME, appName);
	else removeItem(SOFT_NAV_REACT_APP_NAME);
}
function getSoftNavReactAppName() {
	return getItem(SOFT_NAV_REACT_APP_NAME);
}
function reactAppPresent() {
	return !!ssrSafeDocument?.querySelector("react-app")?.getAttribute("app-name") || !!ssrSafeDocument?.querySelector("projects-v2");
}
function setLatestMechanism(mechanism) {
	setItem(SOFT_NAV_LATEST_MECHANISM, mechanism);
}
export { getSoftNavReactAppName as a, reactAppPresent as c, setLatestMechanism as d, setSoftNavMechanism as f, unsetSoftNav as h, getSoftNavMechanism as i, removeItem as l, setSoftNavReferrer as m, getItem as n, getSoftNavReferrer as o, setSoftNavReactAppName as p, getSoftNavFailReason as r, inSoftNav as s, clearSoftNav as t, setItem as u };
