performance.mark("js-parse-end:server-pulls-BuZP-j0g-Dd96NwAu.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:pulls-BuZP-j0g.js");
var pullsIndexServerFn_createServerFn_handler = createServerRpc({
	id: "180951b37fb889ea2e493ea1bafe7f5ab5f986463ee4bb5efb952295c78c841d",
	name: "pullsIndexServerFn",
	filename: "src/routes/pulls/index.tsx"
}, (opts) => pullsIndexServerFn.__executeServer(opts));
var pullsIndexServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(pullsIndexServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom",
		params: data.searchParams
	}, "pullsDashboardSurfaceContentRoute");
});
var pullsIndexDeferredServerFn_createServerFn_handler = createServerRpc({
	id: "794b44b5a606c614b0fdffa923edd1b2e81d253620199a4f9c920ed8b2abf094",
	name: "pullsIndexDeferredServerFn",
	filename: "src/routes/pulls/index.tsx"
}, (opts) => pullsIndexDeferredServerFn.__executeServer(opts));
var pullsIndexDeferredServerFn = createServerFn().inputValidator(queryValidator.withSearchParams).handler(pullsIndexDeferredServerFn_createServerFn_handler, ({ data }) => {
	return fetchServiceJSON({
		path: data.pathname,
		service: "dotcom",
		params: data.searchParams,
		metricTag: "dr_pullsDashboardSurfaceContentDeferredData"
	});
});
export { pullsIndexDeferredServerFn_createServerFn_handler, pullsIndexServerFn_createServerFn_handler };
