import { t as Box, u as Text } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { t as sanitize } from "./server-sanitize.server-b2h7HJ0t-CE6bPZBY.js";
import { jsx } from "react/jsx-runtime";
function getSanitizedHTMLAndProps(propsWithHtml) {
	const { html, domPurifyConfig, ...props } = propsWithHtml;
	return {
		sanitizedHTML: sanitize(html, {
			...domPurifyConfig,
			RETURN_DOM: false,
			RETURN_DOM_FRAGMENT: false
		}),
		props
	};
}
/**
* @deprecated Use `UnsafeHTMLDiv` or `UnsafeHTMLText` instead.
*
* `UnsafeHTMLBox` extends `Box` from `@primer/react` with props for rendering HTML strings
* that need to be sanitized. The HTML will always be run through DOMPurify before being rendered
* to prevent XSS attacks.
*/
var UnsafeHTMLBox = withSanitizedHTML(Box);
/**
* `UnsafeHTMLText` extends `Text` from `@primer/react` with props for rendering HTML strings
* that need to be sanitized. The HTML will always be run through DOMPurify before being rendered
* to prevent XSS attacks.
*/
var UnsafeHTMLText = withSanitizedHTML(Text);
var Div = ({ ref, ...props }) => /* @__PURE__ */ jsx("div", {
	...props,
	ref
});
Div.displayName = "Div";
/**
* `UnsafeHTMLDiv` extends `div` with props for rendering HTML strings
* that need to be sanitized. The HTML will always be run through DOMPurify before being rendered
* to prevent XSS attacks.
*/
var UnsafeHTMLDiv = withSanitizedHTML(Div);
/**
* A higher-order component that extends a basic component by offering
* an `html` prop that always sanitizes its content via DOMPurify.
*/
function withSanitizedHTML(Component) {
	const UnsafeHTMLComponent = (propsWithHtml) => {
		const { sanitizedHTML, props } = getSanitizedHTMLAndProps(propsWithHtml);
		return /* @__PURE__ */ jsx(Component, {
			...props,
			dangerouslySetInnerHTML: { __html: sanitizedHTML }
		});
	};
	UnsafeHTMLComponent.displayName = `UnsafeHTML${Component.displayName || Component.name}`;
	return UnsafeHTMLComponent;
}
export { UnsafeHTMLDiv as n, UnsafeHTMLText as r, UnsafeHTMLBox as t };
