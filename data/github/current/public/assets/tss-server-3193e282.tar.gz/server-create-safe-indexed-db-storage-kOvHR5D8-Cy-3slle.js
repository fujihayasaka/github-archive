import { t as getCurrentUserLogin } from "./server-client-env.server-CuUj6BGO-CZXDe7ld.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { createStore, del, entries, get, set } from "idb-keyval";
var trackStorage = async (storageKey, sendAnalyticsEvent) => {
	if (sendAnalyticsEvent && typeof navigator !== "undefined" && navigator.storage?.estimate) try {
		const estimate = await navigator.storage.estimate();
		const quota = estimate.quota ?? 0;
		const usage = estimate.usage ?? 0;
		sendAnalyticsEvent("offline_cache.storage_space", storageKey, {
			quota_bytes: quota,
			usage_bytes: usage,
			available_bytes: quota - usage,
			usage_percent: quota > 0 ? usage / quota * 100 : 0
		});
	} catch {}
};
var CACHE_EVENTS = {
	CACHE_HIT: "offline_cache.cache_hit",
	CACHE_MISS: "offline_cache.cache_miss",
	CACHE_EVICT: "offline_cache.cache_evict",
	CACHE_INVALID: "offline_cache.stale_structure",
	CACHE_EXPIRED: "offline_cache.expired_item",
	CACHE_SET: "offline_cache.cache_set",
	CACHE_TIMEOUT: "offline_cache.cache_timeout",
	CACHE_SESSION_DISABLED: "offline_cache.session_disabled",
	CACHE_READ_ERROR: "offline_cache.read_error",
	CACHE_EVICT_ERROR: "offline_cache.evict_error",
	CACHE_WRITE_ERROR: "offline_cache.write_error",
	CLEANUP_STARTED: "offline_cache.cleanup_started",
	CLEANUP_COMPLETED: "offline_cache.cleanup_completed",
	CLEANUP_ERROR: "offline_cache.cleanup_error",
	CLEANUP_ITEM_ERROR: "offline_cache.cleanup_item_error",
	ENTRIES_READ: "offline_cache.entries_read",
	ANY: "offline_cache.*",
	NONE: "offline_cache.none"
};
var INDEXEDDB_READ_TIMEOUT_MS = 500;
var INDEXEDDB_WRITE_TIMEOUT_MS = 2e3;
var NOT_AVAILABLE = "N/A";
var isIndexedDbDisabledForSession = false;
function isFatalIndexedDbError(error) {
	if (!(error instanceof Error)) return false;
	if ((typeof DOMException !== "undefined" ? error instanceof DOMException : false) && "name" in error) {
		const errorName = error.name;
		return errorName === "SecurityError" || errorName === "UnknownError" || errorName === "AbortError" || errorName === "QuotaExceededError" || errorName === "NotFoundError" || errorName === "VersionError";
	}
	return false;
}
function isIndexedDbAvailable() {
	try {
		return typeof globalThis !== "undefined" && typeof globalThis.indexedDB !== "undefined";
	} catch {
		return false;
	}
}
var IndexedDbTimeoutError = class extends Error {
	constructor(operation, key, timeoutMs) {
		super(`IndexedDB ${operation} operation timed out after ${timeoutMs}ms for key: ${key}`);
		this.name = "IndexedDbTimeoutError";
	}
};
var DBNAME_PREFIX = "offline_cache::";
var getDbName = () => DBNAME_PREFIX + getCurrentUserLogin();
var persisters = /* @__PURE__ */ new Map();
function createSafeIndexedDbPersister({ validator, sendAnalyticsEvent, storeName = "queries" }) {
	const persisterId = `${getDbName()}:${storeName}:${validator.Code()}`;
	const existingPersister = persisters.get(persisterId);
	if (existingPersister) return existingPersister;
	function isExpired(persistedQuery) {
		if (!persistedQuery || !persistedQuery.state) return true;
		if (persistedQuery.state.dataUpdatedAt && persistedQuery.state.ttl) {
			if (Date.now() - persistedQuery.state.dataUpdatedAt > persistedQuery.state.ttl) return true;
		}
		if (persistedQuery.state.cacheVersion !== void 0 && persistedQuery.state.cacheVersion !== 1) return true;
		return false;
	}
	let idbStore;
	try {
		idbStore = createStore(getDbName(), storeName);
	} catch (error) {
		if (isFatalIndexedDbError(error)) {
			isIndexedDbDisabledForSession = true;
			sendAnalyticsEvent(CACHE_EVENTS.CACHE_SESSION_DISABLED, "", {
				reason: "fatal_error_on_init",
				error_name: error.name
			});
		}
	}
	function isIndexedDbDisabled() {
		return isFeatureEnabled("disable-indexdb-operations") || isIndexedDbDisabledForSession;
	}
	async function withTimeout(promise, timeoutMs, operation, key) {
		let timeoutId = null;
		const timeoutPromise = new Promise((_, reject) => {
			timeoutId = setTimeout(() => {
				sendAnalyticsEvent(CACHE_EVENTS.CACHE_TIMEOUT, key, { operation });
				reject(new IndexedDbTimeoutError(operation, key, timeoutMs));
			}, timeoutMs);
		});
		try {
			const result = await Promise.race([promise, timeoutPromise]);
			if (timeoutId) clearTimeout(timeoutId);
			return result;
		} catch (error) {
			if (timeoutId) clearTimeout(timeoutId);
			throw error;
		}
	}
	async function cleanupExpiredEntries() {
		if (persister.isCleanupRunning) return;
		persister.isCleanupRunning = true;
		const startTime = Date.now();
		try {
			sendAnalyticsEvent(CACHE_EVENTS.CLEANUP_STARTED, "", {});
			if (!isIndexedDbAvailable()) return;
			const allEntries = await entries(idbStore);
			const totalEntries = allEntries.length;
			let removedCount = 0;
			for (const [key, value] of allEntries) try {
				if (isExpired(value)) {
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_EVICT, key.toString(), { reason: "periodic_cleanup" });
					del(key, idbStore).catch((error) => {
						sendAnalyticsEvent(CACHE_EVENTS.CLEANUP_ITEM_ERROR, key.toString(), { error: String(error) });
					});
					removedCount++;
				}
			} catch (error) {
				sendAnalyticsEvent(CACHE_EVENTS.CLEANUP_ITEM_ERROR, key.toString(), { error: String(error) });
			}
			sendAnalyticsEvent(CACHE_EVENTS.CLEANUP_COMPLETED, "", {
				removed_count: removedCount,
				total_entries: totalEntries,
				duration_ms: Date.now() - startTime
			});
		} catch (error) {
			try {
				sendAnalyticsEvent(CACHE_EVENTS.CLEANUP_ERROR, "", { error: String(error) });
			} catch {}
		} finally {
			persister.isCleanupRunning = false;
		}
	}
	function startPeriodicCleanup(intervalMs = 3600 * 1e3) {
		if (typeof window === "undefined") return;
		const scheduleCleanup = () => {
			const windowWithIdleCallback = window;
			if (typeof windowWithIdleCallback.requestIdleCallback === "function") windowWithIdleCallback.requestIdleCallback(() => void cleanupExpiredEntries(), { timeout: 1e4 });
			else setTimeout(() => void cleanupExpiredEntries(), 1e4);
		};
		scheduleCleanup();
		persister.cleanupIntervalId = window.setInterval(() => void cleanupExpiredEntries(), intervalMs);
	}
	function stopPeriodicCleanup() {
		if (persister.cleanupIntervalId !== void 0) {
			clearInterval(persister.cleanupIntervalId);
			persister.cleanupIntervalId = void 0;
		}
	}
	const persister = {
		cleanupIntervalId: void 0,
		isCleanupRunning: false,
		async getItem(key, attributes) {
			if (isIndexedDbDisabled() || !isIndexedDbAvailable()) return;
			const startTime = Date.now();
			try {
				const item = await withTimeout(get(key, idbStore), INDEXEDDB_READ_TIMEOUT_MS, "read", key);
				const readDurationMs = Date.now() - startTime;
				if (!item?.state?.data) {
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_MISS, key.toString(), {
						...attributes,
						read_duration_ms: readDurationMs
					});
					return;
				}
				if (isExpired(item)) {
					this.removeItem(key);
					sendAnalyticsEvent?.("offline_cache.expired_item", key.toString(), {
						...attributes,
						read_duration_ms: readDurationMs
					});
					return;
				}
				if (!validator.Check(item.state.data)) {
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_INVALID, key.toString(), {
						...attributes,
						errors: validator.Errors(item.state.data),
						read_duration_ms: readDurationMs
					});
					return;
				}
				const age = item.state.dataUpdatedAt ? Date.now() - item.state.dataUpdatedAt : NOT_AVAILABLE;
				const ttl = item.state.ttl ?? NOT_AVAILABLE;
				sendAnalyticsEvent(CACHE_EVENTS.CACHE_HIT, key.toString(), {
					...attributes,
					age,
					ttl,
					preheat_source: item.state.preheatSource,
					read_duration_ms: readDurationMs
				});
				return item;
			} catch (error) {
				const readDurationMs = Date.now() - startTime;
				if (error instanceof IndexedDbTimeoutError) {
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_MISS, key.toString(), {
						...attributes,
						read_duration_ms: readDurationMs,
						timeout: true
					});
					return;
				}
				if (isFatalIndexedDbError(error)) {
					isIndexedDbDisabledForSession = true;
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_SESSION_DISABLED, key.toString(), {
						reason: "fatal_error",
						error_name: error.name,
						read_duration_ms: readDurationMs
					});
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_READ_ERROR, key.toString(), {
						...attributes,
						session_disabled: true,
						error_name: error.name,
						read_duration_ms: readDurationMs
					});
					return;
				}
				throw error;
			}
		},
		async setItem(key, value, dataUpdatedAt, ttl, attributes) {
			if (isIndexedDbDisabled() || !isIndexedDbAvailable()) return Promise.resolve();
			const effectiveTtl = ttl ?? value.state.ttl;
			const valueToStore = {
				...value,
				state: {
					...value.state,
					dataUpdatedAt: dataUpdatedAt ?? value.state.dataUpdatedAt,
					ttl: effectiveTtl,
					cacheVersion: 1
				}
			};
			trackStorage(key, sendAnalyticsEvent);
			sendAnalyticsEvent(CACHE_EVENTS.CACHE_SET, key.toString(), {
				...attributes,
				ttl: effectiveTtl
			});
			try {
				await withTimeout(set(key, valueToStore, idbStore), INDEXEDDB_WRITE_TIMEOUT_MS, "write", key);
			} catch (error) {
				if (error instanceof IndexedDbTimeoutError) return;
				if (isFatalIndexedDbError(error)) {
					isIndexedDbDisabledForSession = true;
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_SESSION_DISABLED, key.toString(), {
						reason: "fatal_error",
						error_name: error.name
					});
					sendAnalyticsEvent(CACHE_EVENTS.CACHE_WRITE_ERROR, key.toString(), {
						...attributes,
						session_disabled: true,
						error_name: error.name
					});
					return;
				}
				throw error;
			}
		},
		async removeItem(key, attributes) {
			sendAnalyticsEvent(CACHE_EVENTS.CACHE_EVICT, key.toString(), attributes);
			if (!isIndexedDbAvailable()) return;
			return del(key, idbStore);
		},
		isBustedOrExpired(persistedQuery) {
			return isExpired(persistedQuery);
		},
		async entries() {
			if (!isIndexedDbAvailable()) return [];
			const startTime = Date.now();
			const things = await entries(idbStore);
			const durationMs = Date.now() - startTime;
			sendAnalyticsEvent(CACHE_EVENTS.ENTRIES_READ, "", {
				duration_ms: durationMs,
				entry_count: things.length
			});
			return things;
		},
		cleanupExpiredEntries,
		stopPeriodicCleanup
	};
	persisters.set(persisterId, persister);
	startPeriodicCleanup();
	return persister;
}
export { createSafeIndexedDbPersister as t };
