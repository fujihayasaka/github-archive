/**
* Inserts text into a text input and moves the cursor appropriately.
* If the cursor happens to be in the middle of a line, or the textarea isn't empty,
* we add a newline character before the inserted text. We also advance the cursor
* appropriately
* @param textarea an `<input>` or `<textarea>` element
* @param text The text to add
* @param appendNewline optionally adds a `\n` character after `text`
*/
function insertText(textarea, text, options = {}) {
	const point = textarea.selectionEnd || 0;
	const beginning = textarea.value.substring(0, point);
	const remaining = textarea.value.substring(point);
	const newline = textarea.value === "" || beginning.match(/\n$/) ? "" : "\n";
	const trailingNewline = options.appendNewline ? "\n" : "";
	const insertedText = newline + text + trailingNewline;
	textarea.value = beginning + insertedText + remaining;
	const newPoint = point + insertedText.length;
	textarea.selectionStart = newPoint;
	textarea.selectionEnd = newPoint;
	textarea.dispatchEvent(new CustomEvent("change", {
		bubbles: true,
		cancelable: false
	}));
	textarea.focus();
	return insertedText;
}
function GetCharIndexFromBytePosition(str, pos) {
	const contents = [...str];
	const encoder = new TextEncoder();
	const u8array = new Uint8Array(4);
	for (let i = 0; i < contents.length; i++) {
		const char = contents[i];
		const { written, read } = encoder.encodeInto(char, u8array);
		if (!written || !read) return -1;
		const diff = written - read;
		if (diff === 0) continue;
		if (i < pos) pos -= diff;
		if (i >= pos) break;
	}
	return pos;
}
export { insertText as n, GetCharIndexFromBytePosition as t };
