import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { n as splitHotkeyString, t as hotkey_exports } from "./server-hotkey-CjmZAe2y-CaimUUmF.js";
import { useEffect, useId } from "react";
import { c } from "react/compiler-runtime";
var { commands, services } = {
	services: {
		"commit-diff-view": {
			"id": "commit-diff-view",
			"name": "Commits",
			"commandIds": [
				"commit-diff-view:open-find",
				"commit-diff-view:create-permalink",
				"commit-diff-view:collapse-expand-comments"
			]
		},
		"copilot-chat": {
			"id": "copilot-chat",
			"name": "Copilot Chat",
			"commandIds": [
				"copilot-chat:open-assistive",
				"copilot-chat:open-immersive",
				"copilot-chat:continue-in-immersive",
				"copilot-chat:send-message",
				"copilot-chat:send-message-new-conversation",
				"copilot-chat:add-attachment",
				"copilot-chat:close-assistive",
				"copilot-chat:deep-codesearch",
				"copilot-chat:edit-last-message"
			]
		},
		"github": {
			"id": "github",
			"name": "GitHub (site-wide)",
			"commandIds": [
				"github:submit-form",
				"github:select",
				"github:select-multiple",
				"github:cancel",
				"github:go-to-start",
				"github:go-to-end",
				"github:up",
				"github:down",
				"github:focus-next"
			]
		},
		"global-navigation": {
			"id": "global-navigation",
			"name": "Global navigation",
			"commandIds": [
				"global-navigation:open-repo-picker",
				"global-navigation:show-shortcuts-dialog",
				"global-navigation:search",
				"global-navigation:go-to-dashboard",
				"global-navigation:go-to-notifications",
				"global-navigation:go-to-repositories",
				"global-navigation:go-to-issues",
				"global-navigation:go-to-pull-requests"
			]
		},
		"issue-body": {
			"id": "issue-body",
			"name": "Issues: issue body",
			"commandIds": ["issue-body:open-copilot-panel"]
		},
		"issue-create": {
			"id": "issue-create",
			"name": "Issue creation",
			"commandIds": [
				"issue-create:new",
				"issue-create:submit-and-create-more",
				"issue-create:open-fullscreen",
				"issue-create:edit-parent",
				"issue-create:mark-blocked-by",
				"issue-create:mark-blocking",
				"issue-create:open-copilot-panel"
			]
		},
		"issue-viewer": {
			"id": "issue-viewer",
			"name": "Issues: issue viewer",
			"commandIds": [
				"issue-viewer:edit-parent",
				"issue-viewer:edit-title-submit",
				"issue-viewer:close-edit-title",
				"issue-viewer:mark-blocked-by",
				"issue-viewer:mark-blocking",
				"issue-viewer:edit-security-alert"
			]
		},
		"issues-react": {
			"id": "issues-react",
			"name": "Issues",
			"commandIds": ["issues-react:focus-next-issue", "issues-react:focus-previous-issue"]
		},
		"item-pickers": {
			"id": "item-pickers",
			"name": "Item pickers",
			"commandIds": [
				"item-pickers:open-assignees",
				"item-pickers:open-development",
				"item-pickers:open-labels",
				"item-pickers:open-milestone",
				"item-pickers:open-projects",
				"item-pickers:open-issue-type",
				"item-pickers:open-author",
				"item-pickers:open-fields"
			]
		},
		"list-view-items-issues-prs": {
			"id": "list-view-items-issues-prs",
			"name": "Issue and pull request lists",
			"commandIds": ["list-view-items-issues-prs:open-focused-item", "list-view-items-issues-prs:toggle-focused-item-selection"]
		},
		"list-views": {
			"id": "list-views",
			"name": "List views",
			"commandIds": ["list-views:open-manage-item-dialog"]
		},
		"projects": {
			"id": "projects",
			"name": "Projects",
			"commandIds": ["projects:save-view", "projects:save-form"]
		},
		"pull-request-files-changed": {
			"id": "pull-request-files-changed",
			"name": "Pull Requests: 'files changed' view",
			"commandIds": [
				"pull-request-files-changed:collapse-expand-comments",
				"pull-request-files-changed:open-commits-list",
				"pull-request-files-changed:focus-file-tree-filter",
				"pull-request-files-changed:submit-review",
				"pull-request-files-changed:go-to-previous-commit",
				"pull-request-files-changed:go-to-next-commit"
			]
		},
		"pull-requests-conversations": {
			"id": "pull-requests-conversations",
			"name": "Pull Requests: conversations",
			"commandIds": ["pull-requests-conversations:submit-comment-and-review"]
		},
		"pull-requests-diff-file-tree": {
			"id": "pull-requests-diff-file-tree",
			"name": "Pull Requests: file tree",
			"commandIds": ["pull-requests-diff-file-tree:focus-file-tree"]
		},
		"pull-requests-diff-view": {
			"id": "pull-requests-diff-view",
			"name": "Pull Requests: diff view",
			"commandIds": [
				"pull-requests-diff-view:copy-anchor-link",
				"pull-requests-diff-view:copy-code",
				"pull-requests-diff-view:close-find",
				"pull-requests-diff-view:jump-to-next-result",
				"pull-requests-diff-view:jump-to-next-result-alternate",
				"pull-requests-diff-view:jump-to-previous-result",
				"pull-requests-diff-view:jump-to-previous-result-alternate",
				"pull-requests-diff-view:open-find",
				"pull-requests-diff-view:submit-comment-and-review",
				"pull-requests-diff-view:start-conversation-current",
				"pull-requests-diff-view:quote-reply"
			]
		},
		"react-sandbox": {
			"id": "react-sandbox",
			"name": "React Sandbox",
			"commandIds": ["react-sandbox:example-command"]
		},
		"repositories": {
			"id": "repositories",
			"name": "Repositories",
			"commandIds": [
				"repositories:go-to-code",
				"repositories:go-to-issues",
				"repositories:go-to-pull-requests",
				"repositories:go-to-discussions",
				"repositories:go-to-actions",
				"repositories:go-to-projects",
				"repositories:go-to-models",
				"repositories:go-to-agents",
				"repositories:go-to-wiki",
				"repositories:go-to-security",
				"repositories:go-to-insights",
				"repositories:go-to-settings"
			]
		},
		"repository-label": {
			"id": "repository-label",
			"name": "Repository label",
			"commandIds": ["repository-label:save-label-submit", "repository-label:cancel-save-label"]
		},
		"sub-issues": {
			"id": "sub-issues",
			"name": "Sub-issues",
			"commandIds": ["sub-issues:create-sub-issue", "sub-issues:add-existing-issue"]
		},
		"ui-commands": {
			"id": "ui-commands",
			"name": "UI Commands",
			"commandIds": [
				"ui-commands:test-chord",
				"ui-commands:test-sequence",
				"ui-commands:conflicting-chord",
				"ui-commands:flagged-command",
				"ui-commands:single-key"
			]
		},
		"workspace-editor": {
			"id": "workspace-editor",
			"name": "Workspace editor",
			"commandIds": [
				"workspace-editor:escape-editor--mac",
				"workspace-editor:escape-editor",
				"workspace-editor:toggle-file-tree-pane"
			]
		}
	},
	commands: /* @__PURE__ */ JSON.parse("{\"commit-diff-view:collapse-expand-comments\":{\"name\":\"Toggle comments\",\"description\":\"Toggle between collapsed and expanded comments\",\"defaultBinding\":\"i\"},\"commit-diff-view:create-permalink\":{\"name\":\"Create permalink\",\"description\":\"Expand the current URL to a full permalink\",\"defaultBinding\":\"y\"},\"commit-diff-view:open-find\":{\"name\":\"Open find and search on selection\",\"description\":\"Open the find widget with the current selection\",\"defaultBinding\":\"Mod+e\"},\"copilot-chat:add-attachment\":{\"name\":\"Add attachment\",\"description\":\"Add an attachment to the current message\",\"defaultBinding\":\"Mod+Shift+@\"},\"copilot-chat:close-assistive\":{\"name\":\"Close chat\",\"description\":\"Close the assistive chat\",\"defaultBinding\":\"Shift+Z\"},\"copilot-chat:continue-in-immersive\":{\"name\":\"Continue conversation in immersive\",\"description\":\"Continue the current assistive chat conversation in immersive mode\",\"defaultBinding\":\"Mod+Shift+C\"},\"copilot-chat:deep-codesearch\":{\"name\":\"Deep code search\",\"description\":\"Perform a deep code search for the current message if applicable\"},\"copilot-chat:edit-last-message\":{\"name\":\"Edit last message\",\"description\":\"Edit the last-sent message in the conversation\",\"defaultBinding\":\"ArrowUp\"},\"copilot-chat:open-assistive\":{\"name\":\"Open Copilot Chat (assistive mode)\",\"description\":\"Open Copilot Chat in the assistive overlay mode\"},\"copilot-chat:open-immersive\":{\"name\":\"Open Copilot Chat (immersive mode)\",\"description\":\"Open Copilot Chat in the full-page immersive mode\",\"defaultBinding\":\"Shift+C\"},\"copilot-chat:send-message\":{\"name\":\"Send message\",\"description\":\"Send the current message\",\"defaultBinding\":\"Enter\"},\"copilot-chat:send-message-new-conversation\":{\"name\":\"Send message to new conversation\",\"description\":\"Send the current message to a newly created conversation\",\"defaultBinding\":\"Mod+Shift+S\"},\"github:cancel\":{\"name\":\"Cancel\",\"description\":\"Cancel the current operation\",\"defaultBinding\":\"Escape\"},\"github:down\":{\"name\":\"Down\",\"description\":\"Navigate down\",\"defaultBinding\":\"ArrowDown\"},\"github:focus-next\":{\"name\":\"Focus next item\",\"description\":\"Navigate to the next focusable item\",\"defaultBinding\":\"Tab\"},\"github:go-to-end\":{\"name\":\"Go to end\",\"description\":\"Go to the last item in a list\",\"defaultBinding\":\"End\"},\"github:go-to-start\":{\"name\":\"Go to start\",\"description\":\"Go to the first item in a list\",\"defaultBinding\":\"Home\"},\"github:select\":{\"name\":\"Select item\",\"description\":\"Select the current item\",\"defaultBinding\":\"Enter\"},\"github:select-multiple\":{\"name\":\"Select multiple items\",\"description\":\"Add the current item to a multi-selection (or remove it if already added)\",\"defaultBinding\":\"Mod+Enter\"},\"github:submit-form\":{\"name\":\"Submit form\",\"description\":\"Submit the current form\",\"defaultBinding\":\"Mod+Enter\"},\"github:up\":{\"name\":\"Up\",\"description\":\"Navigate up\",\"defaultBinding\":\"ArrowUp\"},\"global-navigation:go-to-dashboard\":{\"name\":\"Go to dashboard\",\"description\":\"Navigate to the main dashboard\",\"defaultBinding\":\"g d\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:go-to-issues\":{\"name\":\"Go to your issues\",\"description\":\"Navigate to your issues dashboard page\",\"defaultBinding\":\"g i\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:go-to-notifications\":{\"name\":\"Go to notifications\",\"description\":\"Navigate to the notifications page\",\"defaultBinding\":\"g n\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:go-to-pull-requests\":{\"name\":\"Go to your pull requests\",\"description\":\"Navigate to your pull requests dashboard page\",\"defaultBinding\":\"g p\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:go-to-repositories\":{\"name\":\"Go to your repositories\",\"description\":\"Navigate to your repositories dashboard page\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:open-repo-picker\":{\"name\":\"Open repository switcher\",\"description\":\"Open the repository switcher to navigate between repositories\",\"defaultBinding\":\"Alt+Shift+R\"},\"global-navigation:search\":{\"name\":\"Open search bar\",\"description\":\"Opens and focus the search experience\",\"defaultBinding\":\"/,s\",\"featureFlag\":\"global_nav_ui_commands\"},\"global-navigation:show-shortcuts-dialog\":{\"name\":\"Show keyboard shortcuts dialog\",\"description\":\"Display the keyboard shortcuts help dialog\",\"defaultBinding\":\"Shift+?\"},\"issue-body:open-copilot-panel\":{\"name\":\"Open Write with Copilot panel\",\"description\":\"Open the Copilot panel to generate an issue description\",\"defaultBinding\":\"Mod+Shift+C\",\"featureFlag\":\"write_issue_body_with_copilot\"},\"issue-create:edit-parent\":{\"name\":\"Add or change parent issue\",\"description\":\"Open picker to add or change the parent issue\",\"defaultBinding\":\"Alt+Shift+P\",\"featureFlag\":\"issue_create_relationships\"},\"issue-create:mark-blocked-by\":{\"name\":\"Add or change blocked by\",\"description\":\"Add or change an issue that blocks the current issue\",\"defaultBinding\":\"b b\",\"featureFlag\":\"issue_create_relationships\"},\"issue-create:mark-blocking\":{\"name\":\"Add or change blocking\",\"description\":\"Add or change an issue that is blocked by the current issue\",\"defaultBinding\":\"b x\",\"featureFlag\":\"issue_create_relationships\"},\"issue-create:new\":{\"name\":\"Create issue\",\"description\":\"Open the new issue creation flow\",\"defaultBinding\":\"c\"},\"issue-create:open-copilot-panel\":{\"name\":\"Open Write with Copilot panel\",\"description\":\"Open the Copilot panel to generate an issue description\",\"defaultBinding\":\"Mod+Shift+C\",\"featureFlag\":\"write_issue_body_with_copilot\"},\"issue-create:open-fullscreen\":{\"name\":\"Open issue creation in fullscreen\",\"description\":\"Open the issue creation dialog in fullscreen mode\",\"defaultBinding\":\"Mod+Shift+Enter\"},\"issue-create:submit-and-create-more\":{\"name\":\"Submit and create more\",\"description\":\"Submit the current issue and create a new one\",\"defaultBinding\":\"Mod+Alt+Enter\"},\"issue-viewer:close-edit-title\":{\"name\":\"Cancel\",\"description\":\"Cancel out of editing an issue's title\",\"defaultBinding\":\"Escape\"},\"issue-viewer:edit-parent\":{\"name\":\"Edit parent issue\",\"description\":\"Change the parent issue\",\"defaultBinding\":\"Alt+Shift+P\"},\"issue-viewer:edit-security-alert\":{\"name\":\"Add or change security alert\",\"description\":\"Add or change a security alert related to the current issue\",\"featureFlag\":\"code_scanning_alert_tracking_links_phase_2\"},\"issue-viewer:edit-title-submit\":{\"name\":\"Save\",\"description\":\"Submit changes made to an issue's title\",\"defaultBinding\":\"Enter\"},\"issue-viewer:mark-blocked-by\":{\"name\":\"Add or change blocked by\",\"description\":\"Add or change an issue that blocks the current issue\",\"defaultBinding\":\"b b\"},\"issue-viewer:mark-blocking\":{\"name\":\"Add or change blocking\",\"description\":\"Add or change an issue that is blocked by the current issue\",\"defaultBinding\":\"b x\"},\"issues-react:focus-next-issue\":{\"name\":\"Focus next issue\",\"description\":\"Move focus to the next issue in the list, or the first if none are focused\",\"defaultBinding\":\"j\"},\"issues-react:focus-previous-issue\":{\"name\":\"Focus previous issue\",\"description\":\"Move focus to the previous issue in the list\",\"defaultBinding\":\"k\"},\"item-pickers:open-assignees\":{\"name\":\"Open assignees panel\",\"description\":\"Open panel to select assignees\",\"defaultBinding\":\"a\"},\"item-pickers:open-author\":{\"name\":\"Open author panel\",\"description\":\"Open panel to select author\",\"defaultBinding\":\"u\"},\"item-pickers:open-development\":{\"name\":\"Open development panel\",\"description\":\"Open panel to create or link a pull request\",\"defaultBinding\":\"d\"},\"item-pickers:open-fields\":{\"name\":\"Open fields panel\",\"description\":\"Open panel to select custom fields\",\"defaultBinding\":\"f\"},\"item-pickers:open-issue-type\":{\"name\":\"Open issue type panel\",\"description\":\"Open panel to select issue type\",\"defaultBinding\":\"t\"},\"item-pickers:open-labels\":{\"name\":\"Open labels panel\",\"description\":\"Open panel to select labels\",\"defaultBinding\":\"l\"},\"item-pickers:open-milestone\":{\"name\":\"Open milestone panel\",\"description\":\"Open panel to select milestone\",\"defaultBinding\":\"m\"},\"item-pickers:open-projects\":{\"name\":\"Open projects panel\",\"description\":\"Open panel to select projects\",\"defaultBinding\":\"p\"},\"list-view-items-issues-prs:open-focused-item\":{\"name\":\"Open focused item\",\"description\":\"Open the currently focused item\",\"defaultBinding\":\"o\"},\"list-view-items-issues-prs:toggle-focused-item-selection\":{\"name\":\"Toggle focused item selection\",\"description\":\"Toggle the selection state of the currently focused item for bulk actions\",\"defaultBinding\":\"x\"},\"list-views:open-manage-item-dialog\":{\"name\":\"Open manage item dialog\",\"defaultBinding\":\"Mod+Shift+U\",\"description\":\"Open a dialog to manage the currently focused item\"},\"projects:save-form\":{\"name\":\"Save\",\"description\":\"Submit the currently focused form\",\"defaultBinding\":\"Mod+Enter\"},\"projects:save-view\":{\"name\":\"Save view\",\"description\":\"Save any unsaved changes to the current project view\",\"defaultBinding\":\"Mod+s\"},\"pull-request-files-changed:collapse-expand-comments\":{\"name\":\"Toggle comments\",\"description\":\"Toggle between collapsed and expanded comments\",\"defaultBinding\":\"i\"},\"pull-request-files-changed:focus-file-tree-filter\":{\"name\":\"Focus file tree filter\",\"description\":\"Open the file tree and focus the filter input\",\"defaultBinding\":\"t\"},\"pull-request-files-changed:go-to-next-commit\":{\"name\":\"Go to next commit\",\"description\":\"Navigate to the next commit in the commit range\",\"defaultBinding\":\"n\"},\"pull-request-files-changed:go-to-previous-commit\":{\"name\":\"Go to previous commit\",\"description\":\"Navigate to the previous commit in the commit range\",\"defaultBinding\":\"p\"},\"pull-request-files-changed:open-commits-list\":{\"name\":\"Open commit selector\",\"description\":\"Open the commit selector dialog\",\"defaultBinding\":\"c\"},\"pull-request-files-changed:submit-review\":{\"name\":\"Submit review\",\"description\":\"Submit the current review\",\"defaultBinding\":\"Mod+Enter\"},\"pull-requests-conversations:submit-comment-and-review\":{\"name\":\"Submit comment and review\",\"description\":\"Submit the new comment and any pending review comments\",\"defaultBinding\":\"Mod+Shift+Enter\"},\"pull-requests-diff-file-tree:focus-file-tree\":{\"name\":\"Focus file tree\",\"description\":\"Move focus to the file tree\",\"defaultBinding\":\"Mod+F6\"},\"pull-requests-diff-view:close-find\":{\"name\":\"Close find\",\"description\":\"Close the find widget\",\"defaultBinding\":\"Escape\"},\"pull-requests-diff-view:copy-anchor-link\":{\"name\":\"Copy link\",\"description\":\"Copy link to the current line\",\"defaultBinding\":\"Mod+Alt+y\"},\"pull-requests-diff-view:copy-code\":{\"name\":\"Copy\",\"description\":\"Copy the code for the current line(s)\",\"defaultBinding\":\"Mod+c\"},\"pull-requests-diff-view:jump-to-next-result\":{\"name\":\"Jump to next result\",\"description\":\"Move to the next search result\",\"defaultBinding\":\"Enter\"},\"pull-requests-diff-view:jump-to-next-result-alternate\":{\"name\":\"Jump to next result\",\"description\":\"Move to the next search result\",\"defaultBinding\":\"Mod+g\"},\"pull-requests-diff-view:jump-to-previous-result\":{\"name\":\"Jump to previous result\",\"description\":\"Move to the previous search result\",\"defaultBinding\":\"Shift+Enter\"},\"pull-requests-diff-view:jump-to-previous-result-alternate\":{\"name\":\"Jump to previous result\",\"description\":\"Move to the previous search result\",\"defaultBinding\":\"Mod+Shift+G\"},\"pull-requests-diff-view:open-find\":{\"name\":\"Open find\",\"description\":\"Open the find widget\",\"defaultBinding\":\"Mod+f\"},\"pull-requests-diff-view:quote-reply\":{\"name\":\"Quote reply\",\"description\":\"Reply to a comment with quoted text\",\"defaultBinding\":\"r\"},\"pull-requests-diff-view:start-conversation-current\":{\"name\":\"Add comment on line\",\"description\":\"Add a comment on the current line\"},\"pull-requests-diff-view:submit-comment-and-review\":{\"name\":\"Submit comment and review\",\"description\":\"Submit the new comment and any pending review comments\",\"defaultBinding\":\"Mod+Shift+Enter\"},\"react-sandbox:example-command\":{\"name\":\"React Sandbox example command\",\"description\":\"Do something\",\"defaultBinding\":\"Mod+Shift+Enter\"},\"repositories:go-to-actions\":{\"name\":\"Go to actions\",\"description\":\"Navigate to the current repository's actions tab\",\"defaultBinding\":\"g a\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-agents\":{\"name\":\"Go to agents\",\"description\":\"Navigate to the current repository's AI agents tab\",\"defaultBinding\":\"g e\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-code\":{\"name\":\"Go to code\",\"description\":\"Navigate to the current repository's code tab\",\"defaultBinding\":\"g c\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-discussions\":{\"name\":\"Go to discussions\",\"description\":\"Navigate to the current repository's discussions tab\",\"defaultBinding\":\"g g\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-insights\":{\"name\":\"Go to insights\",\"description\":\"Navigate to the current repository's insights tab\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-issues\":{\"name\":\"Go to issues\",\"description\":\"Navigate to the current repository's issues tab\",\"defaultBinding\":\"g i\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-models\":{\"name\":\"Go to models\",\"description\":\"Navigate to the current repository's AI models tab\",\"defaultBinding\":\"g m\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-projects\":{\"name\":\"Go to projects\",\"description\":\"Navigate to the current repository's projects tab\",\"defaultBinding\":\"g b\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-pull-requests\":{\"name\":\"Go to pull requests\",\"description\":\"Navigate to the current repository's pull requests tab\",\"defaultBinding\":\"g p\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-security\":{\"name\":\"Go to security\",\"description\":\"Navigate to the current repository's security tab\",\"defaultBinding\":\"g s\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-settings\":{\"name\":\"Go to settings\",\"description\":\"Navigate to the current repository's settings tab\",\"featureFlag\":\"global_nav_ui_commands\"},\"repositories:go-to-wiki\":{\"name\":\"Go to wiki\",\"description\":\"Navigate to the current repository's wiki tab\",\"defaultBinding\":\"g w\",\"featureFlag\":\"global_nav_ui_commands\"},\"repository-label:cancel-save-label\":{\"name\":\"Cancel\",\"description\":\"Cancel out of editing a label\",\"defaultBinding\":\"Escape\"},\"repository-label:save-label-submit\":{\"name\":\"Create label\",\"description\":\"Submit changes made to a label\",\"defaultBinding\":\"Mod+Enter\"},\"sub-issues:add-existing-issue\":{\"name\":\"Add existing issue\",\"description\":\"Add an existing issue as a sub-issue\",\"defaultBinding\":\"Alt+Shift+A\"},\"sub-issues:create-sub-issue\":{\"name\":\"Create sub-issue\",\"description\":\"Create a new sub-issue\",\"defaultBinding\":\"Alt+Shift+C\"},\"ui-commands:conflicting-chord\":{\"name\":\"Conflicting Chord\",\"description\":\"This is just a test chord to test when there is a conflict\",\"defaultBinding\":\"Control+Shift+Enter\"},\"ui-commands:flagged-command\":{\"name\":\"Flagged command\",\"description\":\"This command is flagged\",\"defaultBinding\":\"a\",\"featureFlag\":\"test_feature\"},\"ui-commands:single-key\":{\"name\":\"Single-key\",\"description\":\"This is test command for a single-key keybinding\",\"defaultBinding\":\"a\"},\"ui-commands:test-chord\":{\"name\":\"Test chord\",\"description\":\"This is just a test chord for unit testing purposes\",\"defaultBinding\":\"Control+Shift+Enter\"},\"ui-commands:test-sequence\":{\"name\":\"Test sequence\",\"description\":\"This is just a test sequence for unit testing purposes\",\"defaultBinding\":\"g q\"},\"workspace-editor:escape-editor\":{\"name\":\"Move focus out of editor\",\"description\":\"Move focus out of the editor to other elements\",\"defaultBinding\":\"Mod+m\"},\"workspace-editor:escape-editor--mac\":{\"name\":\"Move focus out of editor\",\"description\":\"Move focus out of the editor to other elements\",\"defaultBinding\":\"Alt+Tab\"},\"workspace-editor:toggle-file-tree-pane\":{\"name\":\"Toggle file tree pane\",\"description\":\"Show or hide the file tree pane\",\"defaultBinding\":\"Mod+b\"}}")
};
var serviceCommandIds = new Set(Object.keys(commands));
var CommandId = {
	is: (str) => serviceCommandIds.has(str),
	getServiceId: (commandId) => commandId.split(":")[0]
};
/**
* Get the documentation metadata for the given command. Returns `undefined` if the command is
* disabled via feature flag.
*/
var getCommandMetadata = (commandId) => {
	const metadata = commands[commandId];
	return !metadata?.featureFlag || isFeatureEnabled(metadata.featureFlag) ? metadata : void 0;
};
/** Get the documentation metadata for the given service. */
var getServiceMetadata = (serviceId) => services[serviceId];
/** Get all normalized keybindings for a command. */
var getKeybindings = (commandId) => {
	const commandMeta = getCommandMetadata(commandId);
	if (!commandMeta?.defaultBinding) return [];
	return splitHotkeyString(commandMeta.defaultBinding).map(hotkey_exports.normalizeSequence);
};
/**
* Get the primary keybinding for a command.
* @note Most of the time, external consumers should not need this. Do not use this to bind keyboard event listeners
* (use `ScopedCommands` or `GlobalCommands` instead). If possible, do not use this to display keybinding hints (use
* `CommandKeybindingHint` instead). This is typically for cases where you need to display a keybinding hint but the
* destination can only take a plain string, as in the case of `IconButton`'s `keybindingHint` prop (but even then,
* prefer `CommandIconButton` if possible).
*/
var getPrimaryKeybinding = (commandId) => getKeybindings(commandId)[0];
/**
* Get all `[commandId, keybinding]` pairs. When a command has multiple comma-separated
* keybindings, multiple pairs are returned for that command.
*/
var getKeybindingsForCommands = (commandIds) => {
	const output = [];
	for (const id of commandIds) for (const keybinding of getKeybindings(id)) output.push([id, keybinding]);
	return output;
};
var CommandEvent = class {
	commandId;
	constructor(commandId) {
		this.commandId = commandId;
	}
};
var CommandEventHandlersMap = {
	entries: (map) => Object.entries(map).filter((entry) => CommandId.is(entry[0]) && entry[1] !== void 0),
	keys: (map) => Object.keys(map).filter(CommandId.is)
};
/**
* Registered command IDs. The key is a globally unique ID for each source that will be used to unregister or update
* the commands; this allows commands to be registered multiple times on a page (ie, in different scopes).
*/
var registeredCommands = /* @__PURE__ */ new Map();
/**
* Get the set of IDs of all commands currently registered on the page, regardless of scope. From these IDs the
* command metadata can be obtained with `getCommandMetadata(commandId)`, and the service metadata can be obtained with
* `getServiceMetadata(CommandId.getServiceId(commandId))`.
*/
function getAllRegisteredCommands() {
	const uiCommandGroupMap = /* @__PURE__ */ new Map();
	for (const commandId of new Set(Array.from(registeredCommands.values()).flat())) {
		const serviceId = CommandId.getServiceId(commandId);
		if (!uiCommandGroupMap.has(serviceId)) {
			const service = getServiceMetadata(serviceId);
			uiCommandGroupMap.set(serviceId, {
				service: {
					id: service.id,
					name: service.name
				},
				commands: []
			});
		}
		const command = getCommandMetadata(commandId);
		const keybindings = getKeybindings(commandId);
		if (command && keybindings.length > 0) uiCommandGroupMap.get(serviceId)?.commands.push({
			id: commandId,
			name: command.name,
			description: command.description,
			keybinding: keybindings.length > 1 ? keybindings : keybindings[0]
		});
	}
	return Array.from(uiCommandGroupMap.values());
}
/** Register commands into the global command registry for display in help dialog. */
var useRegisterCommands = (commands) => {
	const $ = c(4);
	const sourceId = useId();
	let t0;
	let t1;
	if ($[0] !== commands || $[1] !== sourceId) {
		t0 = () => {
			registeredCommands.set(sourceId, CommandEventHandlersMap.keys(commands));
			return () => {
				registeredCommands.delete(sourceId);
			};
		};
		t1 = [commands, sourceId];
		$[0] = commands;
		$[1] = sourceId;
		$[2] = t0;
		$[3] = t1;
	} else {
		t0 = $[2];
		t1 = $[3];
	}
	useEffect(t0, t1);
};
export { getKeybindings as a, useRegisterCommands as c, getCommandMetadata as i, CommandEventHandlersMap as n, getKeybindingsForCommands as o, getAllRegisteredCommands as r, getPrimaryKeybinding as s, CommandEvent as t };
