import { i as ssrSafeLocation } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Di as VersionsIcon, F as ChevronDownIcon, G as CodeSquareIcon, L as ChevronRightIcon, Lt as FoldIcon, Mi as XIcon, Qn as PeopleIcon, R as ChevronUpIcon, Vr as SpaceIcon, Xr as StarFillIcon, Zn as PencilIcon, _i as Truncate, _n as KebabHorizontalIcon, a as AlertFillIcon, an as IconButton, ar as PlusIcon, bi as UnfoldIcon, bn as Link, fi as Tooltip, hi as TriangleDownIcon, kr as ShieldLockIcon, lr as QuestionIcon, mt as DownloadIcon, n as ActionList, pi as Tooltip$1, qr as Stack, tt as CopyIcon, u as ArrowLeftIcon, wi as UploadIcon, wr as SearchIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { t as debounce } from "./server-dist-CJwx2KGE.js";
import { u as safeStorage } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { S as useSearchParams, g as useLocation$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as GitHubAvatar } from "./server-GitHubAvatar-CSt6P7Zp-lBYA2cd8.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { a as SelectPanel, i as LinkButton, t as Checkbox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { i as Textarea, t as FormControl$1 } from "./server-FormControl-D1WXsUe8-CBkEzHC9.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { t as ButtonGroup } from "./server-ButtonGroup-B8HQGNwD-DPxtw-G3.js";
import { n as useIsDataRouterEnabled } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as sendEvent } from "./server-hydro-analytics-C-E7ekRO-CKcOF9J1.js";
import { D as commitsPathByAuthor, a as blobPath, g as codeNavigationPath, h as codeNavSearchPath, r as blamePath, z as editBlobPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { i as VerifiedHTMLText, n as VerifiedHTMLBox, r as VerifiedHTMLDiv } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
import { t as copilotLocalStorage } from "./server-copilot-local-storage-CWle9ymQ-bOkiKB7N.js";
import { n as WebWorker } from "./server-find-file-BEBNNIhZ-BiOBklr2.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator, n as AllShortcutsEnabled, o as useCurrentUser, s as useReposAnalytics } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { n as useCopilotSettings } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { n as useEditPermissions } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { i as useScreenSize, t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { t as useIsPlatform } from "./server-use-is-platform-BI7nkjWR-DIY2sQH4.js";
import { t as NewAgentTaskButton } from "./server-NewAgentTaskButton-gbUWCBSY-Cu9_75w7.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { a as useShortcut, i as useCodeViewOptions, n as useBlobFocusedModifierShortcuts, r as useBlobFocusedShortcuts } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { i as useToastContext } from "./server-ToastContext-B4YA5oEz-DZzK1u13.js";
import { l as useOpenPanel, o as appendAndFocusSearchBar, t as DuplicateOnKeydownButton, u as useSetOpenPanel } from "./server-repos-file-tree-view-wiNE3n3Y-C6_7U3ky.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { t as Panel } from "./server-Panel-C4KaHVsW-jwL1gzzi.js";
import { t as CopilotPopover } from "./server-CopilotPopover-DZ8KZzV--BVOmP6Gt.js";
import { t as LoadingFallback } from "./server-SuspenseFallback-CKhZbbQP-DbruduCY.js";
import { u as useSplitCodeownersErrorsContext } from "./server-HiddenUnicodeCharacter-CZpsU1rI-DzV8Hc4a.js";
import { n as SymbolChangedEvent } from "./server-copilot-chat-events-CAR-de8z-CxKg4yWR.js";
import { t as qualifyRef } from "./server-ref-utils-DurADI35-f0lQqMVw.js";
import { A as expandRow, B as isSymbol, C as SelectAllShortcutButton, D as calculateLineNumberFromOffset, E as buildRowClass, F as getCopyStateUI, H as parseDirectives, J as useCodeHTML, K as showHiddenUnicodeCharactersRaw, L as hasHiddenUnicodeCharacters, M as forceAnnouncementToScreenReaders, N as formatBlobRange, O as copyText, P as getActualLineNumberBinarySearch, Q as useCurrentLineHeight, R as isHiddenUnicodeShown, S as SearchResultsProvider, T as applyStickyToParentStartLines, U as parseFileAnchor, V as measureMonospaceTextWidth, W as setKeyboardNavUsed, X as useCurrentBlame, Y as useCopyRawBlobContents, Z as useCurrentBlob, _ as HighlightedOverlay, a as CopilotCodeLinesMenu, b as LineNumberNoVirtualziation, c as CurrentLineRefMapProvider, ct as useLineElementMap, dt as useShouldDoNoVirtualization, et as useCursorNavigation, f as HiddenUnicodeAlert, g as HighlightedLinesProvider, h as HighlightedLinesOverlay, i as CopilotButtonContainer, it as useFocusSymbolPane, j as focusSymbolSearch, k as expandAllRows, lt as useLinesSubscription, m as HighlightedLineMenuContainer, n as CodeLines, ot as useIsCursorEnabled, p as HighlightedLineMenu, q as textAreaId, r as CodeLinesNoVirtualization, rt as useDeferredMetadata, st as useKeyboardNavUsed, t as CodeLine, ut as useSharedLineObserver, v as HighlightedSymbolsOverlay, w as SyntaxHighlightedOverlay, y as LineNumber, z as isLineInViewport } from "./server-CodeLine-DcomLxJz-08VzycLV.js";
import { t as CheckboxGroup_default } from "./server-CheckboxGroup-D-9z19be-BHUG_g4C.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { r as languageMap } from "./server-language-info-CBuUUErk-BvCk1GBy.js";
import { a as getCopilotSpacePath, n as customCopilotApiPath, t as SLUG_ERROR_MESSAGE } from "./server-custom-copilots-helpers-DK-3dkih-DB1BoMiI.js";
import { t as use_color_modes_default } from "./server-use-color-modes-BJr-aSEY-DXLeA1jq.js";
import { a as copilotSpacesCategoryQueryKey, c as resourceMetadataToRailsPayload, i as SpacesOwnerDropdown, n as COPILOT_SPACES_QUERY_KEY, o as copilotSpacesQueryKey, r as SpaceDialogFooter, t as COPILOT_SPACES_COUNT_QUERY_KEY } from "./server-SpacesOwnerDropdown-CTkfR2yL-BX_FStD5.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { t as useContributors } from "./server-use-contributors-pFlHrUQY-DveB_mcH.js";
import { t as AvatarStack } from "./server-AvatarStack-DOkoT87C-BbROVIWO.js";
import { t as reportError } from "./server-failbot-DcTQsQvG-1jpM1RlB.js";
import { t as useFeatureFlag } from "./server-use-feature-flag-CDC46uBu-B9UHPW6C.js";
import { t as useStickyObserver } from "./server-use-sticky-observer-CFnc-YRM-CDkfs7O1.js";
import { i as useScrollLineIntoView, n as scrollLineIntoView, r as useCurrentStyledBlob } from "./server-use-scroll-line-into-view-DttIeP88-D69hX7MG.js";
import { a as useSetSearchTerm, i as useSearchTerm, r as useFindInFileOpen } from "./server-FindInFileOpenContext-ugtnUwTQ-CmcTU3Zx.js";
import { n as updateExpandPreferences } from "./server-CodeNavContext-B-HlTATD-BC-PDvfx.js";
import { a as RawMenuActionItems, c as downloadFile, d as useAlertTooltip, f as useBlobRendererType, t as BlobDisplayType, u as qualifyRef$1 } from "./server-NavigationMenu-CKgcoy5c-Bbjbrr6N.js";
import { a as SharedMarkdownContent, l as TableOfContentsPanel, o as SkeletonText, r as LatestCommitSingleLine } from "./server-PublishBanners-D6t9Jc-5-BK-GhWxy.js";
import { i as TableOfContents, o as assertNever, r as FileNameStickyHeader, s as useStickyHeaderStyle } from "./server-CodeViewBanners-D01K_nCP-X3Rsq57I.js";
import { n as SymbolIndicator, t as CodeNavSymbolNavigation } from "./server-CodeNavSymbolNavigation-Dwn78xI--DkG4V6h8.js";
import React, { Suspense, lazy, startTransition, useCallback, useEffect, useEffectEvent, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { createPortal } from "react-dom";
import { c } from "react/compiler-runtime";
import { useWindowVirtualizer } from "@tanstack/react-virtual";
import isEqual from "lodash-es/isEqual.js";
var DebouncedWorkerManager = class {
	#currentRequest = void 0;
	#nextRequest = void 0;
	onResponse;
	#delayId;
	#worker;
	#delayMs;
	#debounceOverrideCondition;
	constructor(worker, delayMs = 200, debounceOverrideCondition) {
		this.#worker = worker;
		this.#delayMs = delayMs;
		this.#debounceOverrideCondition = debounceOverrideCondition;
		this.#worker.onmessage = ({ data }) => {
			if (this.onResponse) this.onResponse(data);
			if (this.#nextRequest) {
				this.#postNow(this.#nextRequest);
				this.#nextRequest = void 0;
			} else this.#currentRequest = void 0;
		};
	}
	post(request) {
		if (this.#debounceOverrideCondition && this.#debounceOverrideCondition(request)) {
			if (this.#delayId) clearTimeout(this.#delayId);
			return this.#postNow(request);
		}
		if (this.idle()) {
			if (this.#delayId) clearTimeout(this.#delayId);
			this.#delayId = setTimeout(() => {
				this.#postNow(request);
			}, this.#delayMs);
		} else this.#nextRequest = request;
	}
	#postNow(request) {
		this.#currentRequest = request;
		this.#worker.postMessage(request);
	}
	idle() {
		return !this.#currentRequest;
	}
	terminate() {
		this.#worker.terminate();
	}
};
var SymbolSource = {
	BLACKBIRD_SEARCH: "blackbird-search",
	BLACKBIRD_ANALYSIS: "blackbird-analysis",
	ALEPH_PRECISE: "aleph-precise",
	BLOB_CONTENT: "blob-content-search"
};
var SymbolKind = class {
	enumStringVal;
	fullName;
	shortName;
	plColor;
	rank;
	constructor({ kind }) {
		const [fullName, enumStringVal] = convertBlackbirdSymbolKind(kind);
		this.enumStringVal = enumStringVal;
		this.fullName = fullName;
		this.shortName = symbolKindShortName(fullName);
		this.plColor = symbolKindColor(fullName);
		this.rank = symbolKindRank(fullName);
	}
};
function convertBlackbirdSymbolKind(kind) {
	if (typeof kind === "string") {
		const name = kind.toString().replace("SYMBOL_KIND_", "").replace(/_DEF$/, "").replace(/_REF$/, "").toLowerCase();
		if (kind.startsWith("SYMBOL_KIND_")) return [name, kind.toString()];
		else if (kind !== "" && kind !== "unknown") {
			let enumVal = `SYMBOL_KIND_${kind.toUpperCase()}`;
			if (kind === "call") enumVal += "_REF";
			else enumVal += "_DEF";
			return [kind, enumVal];
		}
	}
	return ["unknown", "SYMBOL_KIND_UNKNOWN"];
}
function symbolKindShortName(fullName) {
	switch (fullName) {
		case "function":
		case "method": return "func";
		case "interface": return "intf";
		case "implementation": return "impl";
		case "constant": return "const";
		case "module": return "mod";
		case "section_1": return "h1";
		case "section_2": return "h2";
		case "section_3": return "h3";
		case "section_4": return "h4";
		case "section_5": return "h5";
		case "section_6": return "h6";
		case "class":
		case "call":
		case "enum":
		case "field":
		case "macro":
		case "struct":
		case "trait":
		case "type":
		case "union": return fullName;
		default: return fullName.substring(0, 1);
	}
}
function symbolKindColor(fullName) {
	switch (fullName) {
		case "function":
		case "method": return "prettylights.syntax.entity";
		case "class":
		case "enum":
		case "struct":
		case "union": return "prettylights.syntax.constant";
		case "interface":
		case "trait": return "prettylights.syntax.keyword";
		case "constant":
		case "field":
		case "enum member": return "prettylights.syntax.variable";
		case "implementation": return "prettylights.syntax.string";
		default: return "prettylights.syntax.entity";
	}
}
function symbolKindRank(kind) {
	return {
		class: 1,
		struct: 1,
		enum: 1,
		type: 2,
		interface: 3,
		trait: 3,
		module: 4,
		implementation: 5,
		function: 6,
		method: 7,
		call: 8,
		field: 9
	}[kind] || 9;
}
var CodeSymbol = class {
	ident;
	extent;
	kind;
	name;
	fullyQualifiedName;
	highlightedText;
	stylingDirectives;
	leadingWhitespace;
	source;
	constructor({ ident, extent, kind, name, fullyQualifiedName, source }) {
		this.ident = ident;
		this.extent = extent;
		this.kind = new SymbolKind({ kind });
		this.name = name;
		this.fullyQualifiedName = fullyQualifiedName;
		this.source = source;
	}
	setSymbolDepth(depth) {
		this.depth = depth;
	}
	setFileInfo(repo, refInfo, path) {
		this.repo = repo;
		this.refInfo = refInfo;
		this.path = path;
	}
	get lineNumber() {
		return this.ident.start.line + 1;
	}
	setSnippet(highlightedText, stylingDirectives, bodyText, leadingWhitespace) {
		this.highlightedText = highlightedText;
		this.stylingDirectives = stylingDirectives;
		this.bodyText = bodyText;
		this.leadingWhitespace = leadingWhitespace;
	}
	href() {
		if (!this.repo || !this.refInfo || !this.path) return `/${window.location.pathname}#L${this.lineNumber}`;
		const commitish = this.source === SymbolSource.BLACKBIRD_SEARCH ? this.repo.defaultBranch : this.refInfo.name || this.refInfo.currentOid;
		return blobPath({
			owner: this.repo.ownerLogin,
			repo: this.repo.name,
			commitish,
			filePath: this.path,
			lineNumber: this.lineNumber
		});
	}
	pathKey() {
		return `${this.repo.ownerLogin}/${this.repo.name}/${this.refInfo.currentOid}/${this.path}`;
	}
};
var CodeReference = class {
	ident;
	repo;
	refInfo;
	path;
	isPlain;
	highlightedText;
	stylingDirectives;
	source;
	leadingWhitespace;
	constructor({ ident, repo, refInfo, path, isPlain, source }) {
		this.ident = ident;
		this.repo = repo;
		this.refInfo = refInfo;
		this.path = path;
		this.isPlain = isPlain ?? false;
		this.source = source;
	}
	get lineNumber() {
		return this.ident.start.line + 1;
	}
	href(blame) {
		if (!this.repo || !this.refInfo || !this.path) return `/${window.location.pathname}#L${this.lineNumber}`;
		const commitish = this.source === SymbolSource.BLACKBIRD_SEARCH ? this.repo.defaultBranch : this.refInfo.name || this.refInfo.currentOid;
		const params = {
			owner: this.repo.ownerLogin,
			repo: this.repo.name,
			commitish,
			filePath: this.path,
			lineNumber: this.lineNumber,
			plain: this.isPlain ? 1 : void 0
		};
		return blame ? blamePath(params) : blobPath(params);
	}
	setSnippet(highlightedText, stylingDirectives, bodyText, leadingWhitespace) {
		this.highlightedText = highlightedText;
		this.stylingDirectives = stylingDirectives;
		this.bodyText = bodyText;
		this.leadingWhitespace = leadingWhitespace;
	}
	pathKey() {
		return `${this.repo.ownerLogin}/${this.repo.name}/${this.refInfo.currentOid}/${this.path}`;
	}
};
/**
* Lazy iterator that returns one match at a time
* @param regex regular expression used for the search
* @param text raw text blob
* @param startFromLine line in the text blob indexed from 0
*/
var MatchableType = {
	Text: "Text",
	Symbol: "Symbol"
};
function symbolMatchable(symbol) {
	const escapedRegex = `(\\W|^)${symbol.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\W|$)`;
	return {
		kind: MatchableType.Symbol,
		regexp: new RegExp(escapedRegex, "g")
	};
}
function textMatchable(query) {
	const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	return {
		kind: MatchableType.Text,
		regexp: new RegExp(escapedQuery, "gi")
	};
}
function* getMatchGenerator(regex, lines, startFromLine = 0) {
	for (let line = startFromLine; line < lines.length; line++) {
		const snippet = lines[line];
		let match;
		while ((match = regex.regexp.exec(snippet)) !== null) {
			let matchContent = match[0];
			let column = match.index;
			if (regex.kind === MatchableType.Symbol) {
				if (matchContent.length > 0 && /\W/.test(matchContent[0])) {
					matchContent = matchContent.substring(1);
					column += match[0].length - matchContent.length;
				}
				if (matchContent.length > 0 && /\W/.test(matchContent[matchContent.length - 1])) matchContent = matchContent.substring(0, matchContent.length - 1);
			}
			yield {
				line,
				column,
				columnEnd: column + matchContent.length,
				text: snippet
			};
		}
	}
}
/**
* A drop-in replacement for `Map<number, CodeSection[]>` that answers
* "which sections contain this interior line?" using sorted intervals
* and binary search instead of materializing an entry for every line.
*
* Construction is O(n log n) (sort) + O(n) (prefix-max).
* Lookup is O(log n + k) where k = number of containing sections,
* thanks to a prefix-max endLine array that enables early termination.
*
* A line is considered "interior" to a section when startLine < line < endLine,
* matching the original lineToSectionMap behavior.
*/
var SectionIntervalMap = class {
	/** Sections sorted by startLine ascending (for binary search). */
	#sections;
	/**
	* prefixMaxEnd[i] = max(sections[0].endLine, ..., sections[i].endLine).
	* Used to break early during the backward scan in get(): if
	* prefixMaxEnd[i] <= line, no section at index i or earlier can contain line.
	*/
	#prefixMaxEnd;
	constructor(sections) {
		this.#sections = sections.slice().sort((a, b) => a.startLine - b.startLine);
		const n = this.#sections.length;
		this.#prefixMaxEnd = new Array(n);
		if (n > 0) {
			this.#prefixMaxEnd[0] = this.#sections[0].endLine;
			for (let i = 1; i < n; i++) this.#prefixMaxEnd[i] = Math.max(this.#prefixMaxEnd[i - 1], this.#sections[i].endLine);
		}
	}
	/**
	* Returns all sections whose interior contains `line`
	* (i.e. section.startLine < line < section.endLine),
	* or undefined if none match.
	*
	* Matches the Map<number, CodeSection[]>.get() contract.
	*/
	get(line) {
		const firstNotBefore = this.#lowerBound(line);
		let result;
		for (let i = firstNotBefore - 1; i >= 0; i--) {
			if (this.#prefixMaxEnd[i] <= line) break;
			const section = this.#sections[i];
			if (line < section.endLine) {
				if (!result) result = [];
				result.push(section);
			}
		}
		if (result && result.length > 1) result.reverse();
		return result;
	}
	/**
	* Binary search: returns the index of the first section with startLine >= line.
	*/
	#lowerBound(line) {
		let lo = 0;
		let hi = this.#sections.length;
		while (lo < hi) {
			const mid = lo + hi >>> 1;
			if (this.#sections[mid].startLine < line) lo = mid + 1;
			else hi = mid;
		}
		return lo;
	}
};
function outlineSymbolToCodeSymbol(outlineSymbol, snippet, { stylingDirectives, repo, refInfo, path }) {
	const { extent_utf16: extentUtf16, ident_utf16: identUtf16 } = outlineSymbol;
	const codeSymbol = new CodeSymbol({
		kind: outlineSymbol.kind,
		fullyQualifiedName: outlineSymbol.fully_qualified_name,
		name: outlineSymbol.name,
		extent: {
			start: {
				line: extentUtf16.start.line_number,
				column: extentUtf16.start.utf16_col
			},
			end: {
				line: extentUtf16.end.line_number,
				column: extentUtf16.end.utf16_col
			}
		},
		ident: {
			start: {
				line: identUtf16.start.line_number,
				column: identUtf16.start.utf16_col
			},
			end: {
				line: identUtf16.end.line_number,
				column: identUtf16.end.utf16_col
			}
		},
		source: SymbolSource.BLACKBIRD_ANALYSIS
	});
	codeSymbol.setSnippet(void 0, stylingDirectives?.[identUtf16.start.line_number], snippet, void 0);
	codeSymbol.setFileInfo(repo, refInfo, path);
	return codeSymbol;
}
function alephSymbolToCodeSymbol(alephSymbol, { symbol, refInfo, repo, path, backend }) {
	const symbolStartIdx = alephSymbol.ident?.start?.character;
	const symbolEndIdx = alephSymbol.ident?.end?.character ?? alephSymbol.ident?.start?.character;
	const ident = {
		start: {
			line: alephSymbol.ident.start.line,
			column: symbolStartIdx ? symbolStartIdx - alephSymbol.leadingWhitespace : 0
		},
		end: {
			line: alephSymbol.ident?.end?.line ?? alephSymbol.ident.start.line,
			column: symbolEndIdx ? symbolEndIdx - alephSymbol.leadingWhitespace : 0
		}
	};
	const extentStartIdx = alephSymbol.extent?.start?.character;
	const extentEndIdx = alephSymbol.extent?.end?.character ?? alephSymbol.extent?.start?.character;
	const codeSymbol = new CodeSymbol({
		ident,
		extent: {
			start: {
				line: alephSymbol.extent.start.line,
				column: extentStartIdx ? extentStartIdx : 0
			},
			end: {
				line: alephSymbol.extent.end?.line ?? alephSymbol.extent.start.line,
				column: extentEndIdx ? extentEndIdx : 0
			}
		},
		kind: alephSymbol.symbolKind,
		name: symbol,
		fullyQualifiedName: symbol,
		source: backend === "search" ? SymbolSource.BLACKBIRD_SEARCH : SymbolSource.ALEPH_PRECISE
	});
	if (alephSymbol.local) codeSymbol.setFileInfo(repo, refInfo, path);
	else if (alephSymbol.commitOid && alephSymbol.path) {
		let symbolRefInfo = refInfo;
		if (alephSymbol.commitOid !== refInfo.currentOid) symbolRefInfo = {
			name: "",
			listCacheKey: alephSymbol.commitOid,
			currentOid: alephSymbol.commitOid,
			canEdit: false
		};
		codeSymbol.setFileInfo(alephSymbol.repo ?? repo, symbolRefInfo, alephSymbol.path);
	}
	const firstLineWithWhiteSpace = new Array(alephSymbol.leadingWhitespace).fill(" ").join("") + (alephSymbol.firstLine || "");
	codeSymbol.setSnippet(alephSymbol.highlightedText, void 0, firstLineWithWhiteSpace, alephSymbol.leadingWhitespace);
	return codeSymbol;
}
function alephSymbolToCodeReference(alephSymbol, { refInfo, path, repo, backend }) {
	let symbolRefInfo = refInfo;
	let symbolPath = path;
	if (!alephSymbol.local && alephSymbol.commitOid && alephSymbol.path) {
		symbolRefInfo = refInfo;
		symbolPath = alephSymbol.path;
		if (alephSymbol.commitOid !== refInfo.currentOid) symbolRefInfo = {
			name: "",
			listCacheKey: alephSymbol.commitOid,
			currentOid: alephSymbol.commitOid,
			canEdit: false
		};
	}
	const identStartSymbolIdx = alephSymbol.ident.start.character;
	const identEndSymbolIdx = alephSymbol.ident.end?.character;
	const codeReference = new CodeReference({
		repo,
		refInfo: symbolRefInfo,
		path: symbolPath,
		ident: {
			start: {
				line: alephSymbol.ident.start.line,
				column: identStartSymbolIdx ? identStartSymbolIdx - alephSymbol.leadingWhitespace : 0
			},
			end: {
				line: alephSymbol.ident.end?.line || alephSymbol.ident.start.line,
				column: identEndSymbolIdx ? identEndSymbolIdx - alephSymbol.leadingWhitespace : 0
			}
		},
		source: backend === "search" ? SymbolSource.BLACKBIRD_SEARCH : SymbolSource.ALEPH_PRECISE
	});
	const firstLineWithWhiteSpace = new Array(alephSymbol.leadingWhitespace).fill(" ").join("") + (alephSymbol.firstLine || "");
	codeReference.setSnippet(alephSymbol.highlightedText, void 0, firstLineWithWhiteSpace, alephSymbol.leadingWhitespace);
	return codeReference;
}
var SEARCH_RESULT_LIMIT = 200;
var CodeNavigationInfo = class {
	repo;
	refInfo;
	language;
	path;
	loggedIn;
	blobLines;
	symbols;
	lineIndexedSymbols = {};
	isPlain;
	#symbolTree;
	stylingDirectives;
	setLoading;
	codeSections;
	lineToSectionMap;
	constructor(repo, refInfo, path, loggedIn, rawLines, symbols, stylingDirectives, language, isPlain, setLoading) {
		this.setLoading = setLoading;
		this.repo = repo;
		this.refInfo = refInfo;
		this.path = path;
		this.loggedIn = loggedIn;
		this.language = language;
		this.blobLines = rawLines;
		this.stylingDirectives = stylingDirectives;
		this.isPlain = isPlain;
		this.symbols = this.initSymbols(symbols);
		this.#initSymbolDepths();
		const { codeSections, lineToSectionMap } = this.#initCodeSections();
		this.codeSections = codeSections;
		this.lineToSectionMap = lineToSectionMap;
	}
	get symbolTree() {
		if (!this.#symbolTree) this.#symbolTree = this.#buildSymbolTree();
		return this.#symbolTree;
	}
	#initSymbolDepths() {
		const tempParents = [];
		for (const symbol of this.symbols) {
			let depth = 0;
			for (let i = tempParents.length - 1; i >= 0; i--) {
				const parentSymbol = tempParents[i];
				if (isAfterSymbol(symbol, parentSymbol)) tempParents.pop();
				else {
					depth = tempParents.length;
					break;
				}
			}
			tempParents.push(symbol);
			symbol.setSymbolDepth(depth);
		}
	}
	#initCodeSections() {
		const m = /* @__PURE__ */ new Map();
		const allSections = [];
		for (let i = 0; i < this.symbols.length; i++) if (this.symbols[i].lineNumber < this.symbols[i].extent.end.line - 2) {
			const section = {
				startLine: this.symbols[i].lineNumber,
				endLine: this.symbols[i].extent.end.line,
				index: i,
				collapsed: false,
				level: this.symbols[i].depth
			};
			allSections.push(section);
			const startEntry = m.get(section.startLine);
			if (startEntry) startEntry.push(section);
			else m.set(section.startLine, [section]);
			const endEntry = m.get(section.endLine);
			if (endEntry) endEntry.push(section);
			else m.set(section.endLine, [section]);
		}
		return {
			lineToSectionMap: new SectionIntervalMap(allSections),
			codeSections: m
		};
	}
	initSymbols(symbols) {
		return symbols.map((outlineSymbol) => {
			const codeSymbol = outlineSymbolToCodeSymbol(outlineSymbol, this.blobLines[outlineSymbol.ident_utf16.start.line_number] || "", {
				stylingDirectives: this.stylingDirectives,
				repo: this.repo,
				refInfo: this.refInfo,
				path: this.path
			});
			this.lineIndexedSymbols[codeSymbol.lineNumber] = codeSymbol;
			return codeSymbol;
		});
	}
	getBlobLine(line) {
		return this.blobLines[line] || "";
	}
	getSymbolOnLine(lineNumber) {
		return this.lineIndexedSymbols[lineNumber];
	}
	#buildSymbolTree() {
		if (!this.symbols) return [];
		const symbolTree = this.symbols.filter((s) => s.kind.fullName !== "field").map((symbol) => ({
			symbol,
			depth: symbol.depth
		}));
		const result = [];
		for (let index = 0; index < symbolTree.length; index++) {
			const symbol = symbolTree[index];
			if (index + 1 < symbolTree.length) {
				if (symbolTree[index + 1].depth > symbol.depth) {
					const symbolChildren = buildSymbolTreeChildren(symbolTree, index);
					index += determineTotalNumberOfChildren(symbolChildren);
					result.push({
						symbol: symbol.symbol,
						isParent: true,
						children: symbolChildren
					});
					continue;
				}
			}
			result.push({
				symbol: symbol.symbol,
				isParent: false,
				children: []
			});
		}
		return result;
	}
	createReferences(matches) {
		return matches.map((match) => {
			const reference = new CodeReference({
				ident: match,
				repo: this.repo,
				refInfo: this.refInfo,
				path: this.path,
				isPlain: this.isPlain,
				source: SymbolSource.BLOB_CONTENT
			});
			reference.setSnippet(void 0, this.stylingDirectives?.[match.start.line], this.blobLines[match.start.line], void 0);
			return reference;
		});
	}
	getReferencesToSymbol(symbolName) {
		const ranges = searchInBlobContent(this.blobLines, symbolMatchable(symbolName));
		return this.createReferences(ranges);
	}
	getReferencesToSearch(term) {
		const ranges = searchInBlobContent(this.blobLines, textMatchable(term));
		return this.createReferences(ranges);
	}
	getDefinitionsAndReferences(text, row, column) {
		this.setLoading(true);
		const defs = (async () => {
			const selectedSymbol = this.getSymbolOnLine(row + 1);
			if (selectedSymbol && selectedSymbol.name === text) return {
				definitions: [selectedSymbol],
				backend: "search"
			};
			let [definitions, backend] = await this.getAlephDefinitions(text, row, column, this.loggedIn);
			if (backend === "search") {
				const localDefinitions = this.getLocalDefinitions(text);
				if (localDefinitions.length > 0) definitions = localDefinitions;
				const localDefinition = definitions.find((d) => d.path === this.path && d.repo === this.repo);
				if (localDefinition) definitions = [localDefinition];
				backend = "search";
			} else {
				const localDefinitionsForKindFallback = this.getLocalDefinitions(text, true);
				for (const definition of definitions) if (definition.kind.fullName === "" && definition.name === text) definition.kind = localDefinitionsForKindFallback[0] ? localDefinitionsForKindFallback[0].kind : new SymbolKind({ kind: "" });
			}
			return {
				definitions,
				backend
			};
		})();
		const localRefs = (async () => {
			const { definitions } = await defs;
			const definitionLines = definitions.map((d) => d.lineNumber);
			return {
				references: this.getReferencesToSymbol(text).filter((r) => !definitionLines.includes(r.lineNumber)),
				backend: "search"
			};
		})();
		const alephRefs = (async () => {
			let symbolKind = "SYMBOL_KIND_UNKNOWN";
			const sym = this.getSymbolOnLine(row + 1);
			if (sym) symbolKind = sym.kind.enumStringVal;
			else {
				const { definitions } = await defs;
				symbolKind = definitions[0]?.kind?.enumStringVal || symbolKind;
			}
			return this.getAlephReferences(text, row, column, this.loggedIn, symbolKind);
		})();
		return {
			definitions: defs,
			localReferences: localRefs,
			crossReferences: (async () => {
				const [references, backend] = await alephRefs;
				return {
					references,
					backend
				};
			})(),
			setLoading: this.setLoading
		};
	}
	getLocalDefinitions(text, getSymbolKind = false) {
		let bestRank = 9;
		let definitions = [];
		for (const sym of this.symbols) if (sym.name === text && (sym.kind.rank < bestRank || getSymbolKind)) {
			bestRank = sym.kind.rank;
			definitions = [sym];
		}
		return definitions;
	}
	async getAlephDefinitions(text, row, column, loggedIn) {
		let backend = "search";
		if (text === "" && row === -1 && column === -1 || !loggedIn) return [[], backend];
		const definitionsUrl = codeNavigationPath({
			repo: this.repo,
			type: "definition",
			q: text,
			language: this.language,
			row,
			column,
			ref: this.refInfo.name,
			path: this.path,
			codeNavContext: "BLOB_VIEW",
			symbolKind: null
		});
		let response;
		try {
			response = await verifiedFetchJSON(definitionsUrl);
		} catch {
			return [[], backend];
		}
		if (!response.ok) return [[], backend];
		let resultDetails;
		try {
			resultDetails = await response.json();
		} catch {
			return [[], backend];
		}
		backend = parseAlephBackendType(resultDetails.backend) ?? "search";
		return [resultDetails.payload.flatMap((refs) => refs).map((alephSymbol) => {
			return alephSymbolToCodeSymbol(alephSymbol, {
				stylingDirectives: this.stylingDirectives,
				repo: this.repo,
				refInfo: this.refInfo,
				path: this.path,
				symbol: text,
				backend
			});
		}), backend];
	}
	async getAlephReferences(text, row, column, loggedIn, symbolKind) {
		let backend = "search";
		if (text === "" && row === -1 && column === -1 || !loggedIn) return [[], backend];
		const partialResponse = await verifiedFetchJSON(codeNavigationPath({
			repo: this.repo,
			type: "references",
			q: text,
			language: this.language,
			row,
			column,
			ref: this.refInfo.name,
			path: this.path,
			codeNavContext: "BLOB_VIEW",
			symbolKind
		}));
		if (!partialResponse.ok) return [[], backend];
		let response;
		try {
			response = await partialResponse.json();
		} catch {
			return [[], backend];
		}
		backend = parseAlephBackendType(response.backend) ?? "search";
		const observedLines = /* @__PURE__ */ new Set();
		const isCheckedLine = (line) => {
			if (observedLines.has(line)) return true;
			else {
				observedLines.add(line);
				return false;
			}
		};
		return [response.payload.flatMap((refs) => refs).reduce((results, alephSymbol) => {
			if (alephSymbol.path === this.path) return results;
			const reference = alephSymbolToCodeReference(alephSymbol, {
				stylingDirectives: this.stylingDirectives,
				repo: this.repo,
				refInfo: this.refInfo,
				path: this.path,
				backend
			});
			if (isCheckedLine(reference.lineNumber)) return results;
			results.push(reference);
			return results;
		}, []).sort((a, b) => a.lineNumber - b.lineNumber), backend];
	}
};
function parseAlephBackendType(fromAleph) {
	switch (fromAleph) {
		case "ALEPH_PRECISE":
		case "ALEPH_PRECISE_PREVIEW":
		case "ALEPH_PRECISE_DEVELOPMENT": return "precise";
		case "BLACKBIRD": return "search";
		default: return null;
	}
}
function isAfterSymbol(symbolA, symbolB) {
	return symbolA.extent.start.line === symbolB.extent.end.line ? symbolA.extent.start.column >= symbolB.extent.end.column : symbolA.extent.start.line >= symbolB.extent.end.line;
}
function buildSymbolTreeChildren(symbolTree, currentIndex) {
	const symbolChildren = [];
	const symbol = symbolTree[currentIndex];
	for (let i = currentIndex + 1; i < symbolTree.length; i++) {
		const tempSymbol = symbolTree[i];
		if (tempSymbol.depth > symbol.depth) {
			const tempChildren = buildSymbolTreeChildren(symbolTree, i);
			i += determineTotalNumberOfChildren(tempChildren);
			symbolChildren.push({
				symbol: tempSymbol.symbol,
				children: tempChildren,
				isParent: tempChildren.length > 0
			});
		} else break;
	}
	return symbolChildren;
}
function determineTotalNumberOfChildren(node) {
	let total = node.length;
	for (let i = 0; i < node.length; i++) {
		const currNode = node[i];
		if (currNode.isParent) total += determineTotalNumberOfChildren(currNode.children);
	}
	return total;
}
function searchInBlobContent(lines, m) {
	const output = [];
	const matches = getMatchGenerator(m, lines);
	let match = matches.next();
	while (!match.done && output.length < SEARCH_RESULT_LIMIT) {
		const { column, columnEnd, line } = match.value;
		output.push({
			start: {
				line,
				column
			},
			end: {
				line,
				column: columnEnd
			}
		});
		match = matches.next();
	}
	return output;
}
function searchInBlobIncrementally(codeRefs, lines, matchable) {
	if (codeRefs.length === 0) return [];
	const startedAtResultLimit = codeRefs.length >= SEARCH_RESULT_LIMIT;
	const checkedLine = {};
	const searchResults = codeRefs.reduce((output, ref) => {
		if (checkedLine[ref.ident.start.line]) return output;
		checkedLine[ref.ident.start.line] = true;
		const matches = getMatchGenerator(matchable, [lines[ref.ident.start.line]]);
		let match = matches.next();
		while (!match.done && output.length < SEARCH_RESULT_LIMIT) {
			const { column, columnEnd } = match.value;
			output.push({
				start: {
					line: ref.ident.start.line,
					column
				},
				end: {
					line: ref.ident.start.line,
					column: columnEnd
				}
			});
			match = matches.next();
		}
		return output;
	}, []);
	if (searchResults.length < SEARCH_RESULT_LIMIT && startedAtResultLimit) {
		const startFromLine = codeRefs[codeRefs.length - 1].ident.start.line;
		const matchesInRawBlob = getMatchGenerator(matchable, lines, startFromLine);
		let match = matchesInRawBlob.next();
		while (!match.done && searchResults.length < SEARCH_RESULT_LIMIT) {
			const { line, column, columnEnd } = match.value;
			searchResults.push({
				start: {
					line,
					column
				},
				end: {
					line,
					column: columnEnd
				}
			});
			match = matchesInRawBlob.next();
		}
	}
	return searchResults;
}
function findInFileWorkerJob({ data }) {
	const { query, lines, currentCodeReferences } = data;
	let output = [];
	if (currentCodeReferences) output = searchInBlobIncrementally(currentCodeReferences, lines, textMatchable(query));
	else output = searchInBlobContent(lines, textMatchable(query));
	return {
		ranges: output,
		query
	};
}
function useInFileSearchResults(codeNavInfo, searchTerm) {
	const { findInFileWorkerPath } = useReposAppPayload();
	const [searchResults, setSearchResults] = useState([]);
	const [focusedSearchResult, setFocusedSearchResult] = useState(void 0);
	const [searchStatus, setSearchStatus] = useState("done");
	const workerManagerRef = React.useRef(null);
	const path = usePath();
	const refInfo = useRefInfo();
	if (!workerManagerRef.current && searchTerm) workerManagerRef.current = new DebouncedWorkerManager(new WebWorker(findInFileWorkerPath, findInFileWorkerJob), 200, (req) => req.query.length !== 1);
	const searchTermRef = useRef(searchTerm);
	searchTermRef.current = searchTerm;
	const lastSearchTerm = useRef("");
	useEffect(() => {
		return function destroy() {
			workerManagerRef.current?.terminate();
		};
	}, []);
	const lastCodeNavInfo = useRef(void 0);
	if (workerManagerRef.current && codeNavInfo !== lastCodeNavInfo.current) {
		workerManagerRef.current.onResponse = (data) => {
			if (data.query === searchTermRef.current) {
				setFocusedSearchResult(0);
				setSearchResults(codeNavInfo?.createReferences(data.ranges) || []);
				setSearchStatus("done");
				lastSearchTerm.current = searchTermRef.current;
			}
		};
		lastCodeNavInfo.current = codeNavInfo;
	}
	useEffect(() => {
		if (!codeNavInfo || !workerManagerRef.current || !lastSearchTerm.current || lastSearchTerm.current === "") {
			setSearchResults([]);
			setFocusedSearchResult(0);
			setSearchStatus("done");
			return;
		}
		setSearchResults([]);
		setFocusedSearchResult(0);
		setSearchStatus("pending");
		workerManagerRef.current.post({
			query: lastSearchTerm.current,
			lines: codeNavInfo.blobLines,
			currentCodeReferences: void 0
		});
	}, [refInfo.name, path]);
	useEffect(() => {
		if (!codeNavInfo || !workerManagerRef.current) return;
		if (searchTerm === "") {
			setSearchResults([]);
			setFocusedSearchResult(0);
			setSearchStatus("done");
			lastSearchTerm.current = "";
		} else if (lastSearchTerm.current === searchTerm || !validSearchTerm(searchTerm)) return;
		else {
			setSearchStatus("pending");
			const canDoIncrementalSearch = lastSearchTerm.current.length > 0 && searchTerm.startsWith(lastSearchTerm.current);
			workerManagerRef.current.post({
				query: searchTerm,
				lines: codeNavInfo.blobLines,
				currentCodeReferences: canDoIncrementalSearch ? searchResults : void 0
			});
		}
	}, [searchTerm]);
	return {
		focusedSearchResult,
		setFocusedSearchResult,
		searchResults,
		setSearchResults,
		searchStatus
	};
}
function validSearchTerm(searchTerm) {
	return searchTerm.length > 0 && searchTerm.length <= 1e3;
}
var EMPTY_SYMBOLS = [];
var EMPTY_RAW_LINES = [];
function useCodeNavigation(blob, onCodeNavActivated, setValidCodeNav, hash, hasBlame) {
	const nav = useNavigate$1();
	const repo = useCurrentRepository();
	const user = useCurrentUser();
	const path = usePath();
	const refInfo = useRefInfo();
	const { stylingDirectives, rawLines } = useCurrentStyledBlob();
	const [isCodeNavLoading, setIsCodeNavLoading] = useState(false);
	const normalizedStylingDirectives = useMemo(() => {
		return stylingDirectives?.map((directiveLine) => {
			return parseDirectives(directiveLine);
		});
	}, [stylingDirectives]);
	const [urlParams] = useSearchParams();
	const isPlain = urlParams.get("plain") === "1";
	const refInfoForCodeNav = refInfo;
	const symbols = blob.symbols?.symbols ?? EMPTY_SYMBOLS;
	const codeNavInfo = useMemo(() => {
		try {
			return new CodeNavigationInfo(repo, refInfoForCodeNav, path, !!user, rawLines || EMPTY_RAW_LINES, symbols, normalizedStylingDirectives, blob.language, isPlain, setIsCodeNavLoading);
		} catch {
			return;
		}
	}, [
		repo,
		refInfoForCodeNav,
		path,
		user,
		rawLines,
		symbols,
		blob.language,
		normalizedStylingDirectives,
		isPlain
	]);
	useEffect(() => {
		setValidCodeNav(codeNavInfo !== void 0);
	}, [codeNavInfo, setValidCodeNav]);
	const [searchingText, setSearchingText] = useState(() => {
		const anchInfo = parseFileAnchor(hash);
		if (!anchInfo.blobRange?.start?.line) return {
			selectedText: "",
			lineNumber: -1,
			offset: 0
		};
		if (!hasBlame && anchInfo.blobRange.start.line === anchInfo.blobRange.end.line && anchInfo.blobRange.start.column !== null && anchInfo.blobRange.end.column !== null && anchInfo.blobRange.end.column - anchInfo.blobRange.start.column > 2 && stylingDirectives && stylingDirectives[anchInfo.blobRange.start.line - 1]?.length && codeNavInfo?.blobLines[anchInfo.blobRange.start.line - 1]) {
			const highlightedText = codeNavInfo.blobLines[anchInfo.blobRange.start.line - 1]?.substring(anchInfo.blobRange.start.column - 1, anchInfo.blobRange.end.column - 1);
			const stylingDirective = normalizedStylingDirectives[anchInfo.blobRange.start.line - 1]?.find((directive) => directive.s === anchInfo.blobRange.start.column - 1 && directive.e === anchInfo.blobRange.end.column - 1);
			if (highlightedText && stylingDirective && isSymbol(highlightedText, stylingDirective.c)) return {
				selectedText: highlightedText,
				lineNumber: anchInfo.blobRange.start.line,
				offset: anchInfo.blobRange.start.column
			};
			else return {
				selectedText: "",
				lineNumber: -1,
				offset: 0
			};
		} else if (hash && codeNavInfo && !hasBlame) {
			const sym = codeNavInfo.getSymbolOnLine(Number(hash.substring(2)));
			if (!sym) return {
				selectedText: "",
				lineNumber: -1,
				offset: 0
			};
			return {
				selectedText: sym.name,
				lineNumber: sym.lineNumber,
				offset: sym.ident.start.column
			};
		} else return {
			selectedText: "",
			lineNumber: -1,
			offset: 0
		};
	});
	return {
		isCodeNavLoading,
		codeNavInfo,
		showCodeNavWithSymbol: useCallback((sym_0) => {
			setSearchingText({
				selectedText: sym_0.name,
				lineNumber: sym_0.lineNumber,
				offset: sym_0.ident.start.column
			});
			onCodeNavActivated();
			nav(sym_0.href());
			scrollLineIntoView({ line: sym_0.lineNumber });
		}, [onCodeNavActivated, nav]),
		showCodeNavForToken: useCallback((codeNavData) => {
			setSearchingText(codeNavData);
			onCodeNavActivated();
		}, [onCodeNavActivated]),
		setSearchingText,
		searchingText
	};
}
var stickyHeaderId = "repos-sticky-header";
var stickyHeaderHeightGuess = 102;
var updateStickyHeaderHeightEvent = "code_view_update_sticky_header_height_event";
var stickyHeaderObserver = null;
var lastTrackedStickyHeader = null;
var lastTrackedStickyHeaderHeight = null;
function trackStickyHeader(stickyHeader) {
	if (!stickyHeader || lastTrackedStickyHeader === stickyHeader) return;
	lastTrackedStickyHeader = stickyHeader;
	if (stickyHeaderObserver === null) stickyHeaderObserver = new ResizeObserver((entries) => {
		for (const entry of entries) if (entry.contentRect.height !== lastTrackedStickyHeaderHeight) {
			lastTrackedStickyHeaderHeight = entry.contentRect.height;
			window.dispatchEvent(new CustomEvent(updateStickyHeaderHeightEvent, { detail: entry.contentRect.height }));
		}
	});
	else stickyHeaderObserver.disconnect();
	stickyHeaderObserver.observe(stickyHeader);
}
function useStickyHeaderHeight() {
	const $ = c(2);
	const [stickyHeaderHeight, setStickyHeaderHeight] = useState(void 0);
	let t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => {
			const handleUpdateStickyHeaderHeight = function handleUpdateStickyHeaderHeight(event) {
				setStickyHeaderHeight(event.detail);
			};
			window.addEventListener(updateStickyHeaderHeightEvent, handleUpdateStickyHeaderHeight);
			if (lastTrackedStickyHeader) trackStickyHeader(lastTrackedStickyHeader);
			return () => {
				window.removeEventListener(updateStickyHeaderHeightEvent, handleUpdateStickyHeaderHeight);
			};
		};
		t1 = [];
		$[0] = t0;
		$[1] = t1;
	} else {
		t0 = $[0];
		t1 = $[1];
	}
	useEffect(t0, t1);
	if (stickyHeaderHeight !== void 0) return stickyHeaderHeight;
	return stickyHeaderHeightGuess;
}
function useStickyLines() {
	const $ = c(3);
	const [currentStickyLines, setCurrentStickyLines] = useState(_temp$5);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = (codeLineData, removeStickyLine) => {
			setCurrentStickyLines((prev) => {
				if (codeLineData === null && prev.size === 0) return prev;
				if (codeLineData === null && removeStickyLine) {
					if (prev.size === 0) return prev;
					return /* @__PURE__ */ new Map();
				}
				if (!codeLineData) return prev;
				const lineNumber = codeLineData.lineNumber;
				const next = new Map(prev);
				if (removeStickyLine) next.delete(lineNumber);
				else next.set(lineNumber, codeLineData);
				if (next.get(lineNumber)) for (const [otherLineNumber, otherStickyLine] of next) {
					if (otherLineNumber === lineNumber) continue;
					if (!otherStickyLine.ownedSection || otherStickyLine.ownedSection.endLine < lineNumber || lineNumber < otherStickyLine.lineNumber) next.delete(otherLineNumber);
				}
				return next;
			});
		};
		$[0] = t0;
	} else t0 = $[0];
	const setStickyLines = t0;
	let t1;
	if ($[1] !== currentStickyLines) {
		t1 = {
			currentStickyLines,
			setStickyLines
		};
		$[1] = currentStickyLines;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
function _temp$5() {
	return /* @__PURE__ */ new Map();
}
function MarkdownContent(props) {
	const markdownContainer = useRef(null);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SharedMarkdownContent, {
		...props,
		ref: markdownContainer
	}), /* @__PURE__ */ jsx(SelectAllShortcutButton, { containerRef: markdownContainer })] });
}
MarkdownContent.displayName = "MarkdownContent";
var BlobContent_module_default = {
	blobContentSection: "BlobContent-module_3JdjHW_blobContentSection",
	blobContentSectionMarkdown: "BlobContent-module_3JdjHW_blobContentSectionMarkdown",
	blobContentSectionOverflow: "BlobContent-module_3JdjHW_blobContentSectionOverflow",
	markdownBlob: "BlobContent-module_3JdjHW_markdownBlob",
	tooLargeError: "BlobContent-module_3JdjHW_tooLargeError"
};
function useManualRender() {
	const $ = c(2);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {};
		$[0] = t0;
	} else t0 = $[0];
	const [, setState] = useState(t0);
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => setState({});
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
function useSymbolUnderPointer(onSymbolChanged, validCodeNav) {
	const $ = c(6);
	const hasBlame = !!useCurrentBlame();
	const cursorEnabled = useIsCursorEnabled();
	let t0;
	let t1;
	if ($[0] !== cursorEnabled || $[1] !== hasBlame || $[2] !== onSymbolChanged || $[3] !== validCodeNav) {
		t0 = () => {
			if (hasBlame || !validCodeNav || cursorEnabled) return;
			let timer;
			const debouncedMouseMove = debounce((event) => {
				clearTimeout(timer);
				timer = setTimeout(() => {
					handleMouseMove(event, onSymbolChanged);
				}, 15);
			}, 5);
			window.addEventListener("mousemove", debouncedMouseMove);
			return () => {
				window.removeEventListener("mousemove", debouncedMouseMove);
			};
		};
		t1 = [
			onSymbolChanged,
			hasBlame,
			validCodeNav,
			cursorEnabled
		];
		$[0] = cursorEnabled;
		$[1] = hasBlame;
		$[2] = onSymbolChanged;
		$[3] = validCodeNav;
		$[4] = t0;
		$[5] = t1;
	} else {
		t0 = $[4];
		t1 = $[5];
	}
	useEffect(t0, t1);
}
function handleMouseMove(event, onSymbolChanged) {
	const range = matchFromPoint(/\w+[!?]?/g, event.clientX, event.clientY);
	if (!range) return null;
	const rangeElement = range.commonAncestorContainer.parentElement;
	if (!rangeElement) return;
	for (const className of rangeElement.classList) {
		if ([
			"pl-token",
			"pl-c",
			"pl-s",
			"pl-k"
		].includes(className)) return null;
		const text = range.toString();
		if (!text || text.match(/\n|\s|[();&.=",]/)) return null;
		const { lineNumber, offset, node } = getRowColumnNode(range);
		if (lineNumber === 0 && offset === 0) return null;
		if (!node) return null;
		return onSymbolChanged({
			lineNumber,
			offset,
			node
		});
	}
}
function getRowColumnNode(range) {
	let node = range.startContainer;
	let offset = range.startOffset;
	for (;;) {
		let prev = node.previousSibling;
		while (prev) {
			offset += (prev.textContent || "").length;
			prev = prev.previousSibling;
		}
		const parent = node.parentElement;
		if (parent) if (parent.classList.contains("react-file-line")) return {
			lineNumber: parseInt(parent.getAttribute("data-line-number") || "1", 10),
			offset,
			node
		};
		else node = parent;
		else return {
			lineNumber: 0,
			offset: 0,
			node: null
		};
	}
}
/**
* Returns matching text range given screen offsets.
* Examples
*
* Find nearest word under mouse cursor
* matchFromPoint(/\w+/g, event.clientX, event.clientY)
*
* Returns Range or null if nothing matches position.
*/
function matchFromPoint(regexp, x, y) {
	let textNode = void 0;
	let offset = void 0;
	if (document.caretPositionFromPoint) {
		const caret = document.caretPositionFromPoint(x, y);
		if (caret) {
			textNode = caret.offsetNode;
			offset = caret.offset;
		}
	} else if (document.caretRangeFromPoint) {
		const range = document.caretRangeFromPoint(x, y);
		if (range) {
			textNode = range.startContainer;
			offset = range.startOffset;
		}
	}
	if (!textNode || typeof offset !== "number" || textNode.nodeType !== Node.TEXT_NODE || !textNode.textContent) return null;
	const match = findNearestMatch(textNode.textContent, regexp, offset);
	if (!match) return null;
	const matchedRange = document.createRange();
	matchedRange.setStart(textNode, match[1]);
	matchedRange.setEnd(textNode, match[2]);
	return matchedRange;
}
/**
* Find nearest match in string given a starting offset.
*
* Similar to String#scan, but only returns one result around the given offset.
*
* Examples
*
* findNearestMatch("The quick brown fox jumps over the lazy dog", /\w+/g, 1)
* ["The", 0, 3]
*
* findNearestMatch("The quick brown fox jumps over the lazy dog", /\w+/g, 18)
* ["fox", 16, 19]
*
* Return matching string, start and end offsets. Otherwise returns null for no match.
*/
function findNearestMatch(str, regexp, offset) {
	let m;
	let lastIndex = null;
	while (m = regexp.exec(str)) {
		if (regexp.lastIndex === lastIndex) {
			reportError(/* @__PURE__ */ new Error("regexp did not advance in findNearestMatch()"));
			return null;
		}
		lastIndex = regexp.lastIndex;
		const len = m.index + m[0].length;
		if (m.index <= offset && offset <= len) return [
			m[0],
			m.index,
			len
		];
	}
	return null;
}
var recencyTimeRange = 2 * 365 * 24 * 60 * 60 * 1e3;
var blameAgeProportionBreakpoints = [
	.007,
	.014,
	.03,
	.049,
	.084,
	.14,
	.23,
	.38,
	.62,
	Number.MAX_VALUE
];
var scaleColor = (i) => `var(--display-orange-scale-${i})`;
function useBlameAgeColors() {
	return new Array(10).fill(null).map((_, i) => scaleColor(i));
}
function useBlameAgeColor(commitDate, repoCreationDate) {
	const defaultColor = scaleColor(0);
	if (commitDate < repoCreationDate) return defaultColor;
	const now = Date.now();
	const timeRange = Math.min(now - repoCreationDate.getTime(), recencyTimeRange);
	const proportion = (now - commitDate.getTime()) / timeRange;
	let i = 0;
	for (const breakpoint of blameAgeProportionBreakpoints) {
		if (proportion < breakpoint) return scaleColor(9 - i);
		++i;
	}
	return defaultColor;
}
var Blame_module_default = {
	commitMessage: "Blame-module_z0X2zG_commitMessage",
	commitMessageWrapper: "Blame-module_z0X2zG_commitMessageWrapper",
	reblameWrapper: "Blame-module_z0X2zG_reblameWrapper",
	RelativeTime: "Blame-module_z0X2zG_RelativeTime"
};
var codeRowHeightInPixels = 20;
var singleBlameLineHeightWide = 31;
var singleBlameLineHeightNarrow = 41;
var defaultOverscanAmount = 100;
function BlameLinesSSR({ copilotAccessAllowed, linesData, colorizedLines, tabSize, onLineNumberClick }) {
	const parentRef = useRef(null);
	const blameSegments = extractBlameSegments(useCurrentBlame(), linesData);
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-column",
		style: { tabSize },
		ref: parentRef,
		"data-hpc": true,
		children: blameSegments.map((segment, index) => /* @__PURE__ */ jsx(BlameSegment, {
			...segment,
			colorizedLines,
			index,
			copilotAccessAllowed,
			onLineNumberClick
		}, `blame-for-segment-${segment.range?.start ?? segment.linesData[0].lineNumber}`))
	});
}
BlameLinesSSR.displayName = "BlameLinesSSR";
function BlameLines({ copilotAccessAllowed, linesData, colorizedLines, tabSize, materializeAllLines, onLineNumberClick, ref }) {
	const parentRef = useRef(null);
	const blame = useCurrentBlame();
	const { screenSize } = useScreenSize();
	const [parentOffset, setParentOffset] = useState(0);
	useLayoutEffect(() => {
		setParentOffset(parentRef.current?.offsetTop ?? 0);
	}, []);
	/**
	* This size estimation function is used by the virtualizer to guess which elements should appear in the window.
	* It doesn't need to be perfect - it just needs to get close.
	*/
	const isWide = screenSize >= ScreenSize.medium;
	const estimateSize = useCallback((index) => {
		const line = linesData[index];
		const range = blame?.ranges[line.lineNumber];
		if (range && range.end === range.start) return isWide ? singleBlameLineHeightWide : singleBlameLineHeightNarrow;
		return codeRowHeightInPixels;
	}, [
		linesData,
		blame,
		isWide
	]);
	const virtualizer = useWindowVirtualizer({
		count: linesData.length,
		overscan: materializeAllLines ? Number.MAX_SAFE_INTEGER : defaultOverscanAmount,
		estimateSize,
		scrollMargin: parentOffset
	});
	const virtualLinesData = virtualizer.getVirtualItems().map((virtualItem) => ({
		...linesData[virtualItem.index],
		virtualOffset: virtualItem.start - virtualizer.options.scrollMargin
	}));
	useImperativeHandle(ref, () => ({
		scrollToTop: () => {
			if (isLineInViewport(0)) return;
			virtualizer.scrollToIndex(0, { align: "start" });
		},
		scrollToLine: (lineNumber) => {
			if (isLineInViewport(lineNumber)) return;
			virtualizer.scrollToIndex(lineNumber, { align: "center" });
		}
	}));
	const blameSegments = extractBlameSegments(blame, virtualLinesData);
	return /* @__PURE__ */ jsx("div", {
		style: {
			"--blame-segments-count": blameSegments.length,
			"--blame-virt-total-size": `${virtualizer.getTotalSize()}px`,
			tabSize
		},
		className: "virtual-blame-wrapper",
		ref: parentRef,
		"data-hpc": true,
		children: blameSegments.map((segment, index_0) => {
			let virtualOffset = segment.linesData[0].virtualOffset ?? 0;
			if (screenSize < ScreenSize.large) virtualOffset += (index_0 ?? 0) * singleBlameLineHeightNarrow;
			return /* @__PURE__ */ jsx(BlameSegment, {
				range: segment.range,
				commit: segment.commit,
				linesData: segment.linesData,
				colorizedLines,
				copilotAccessAllowed,
				onLineNumberClick,
				virtualOffset
			}, `blame-for-segment-${segment.range?.start ?? segment.linesData[0].lineNumber}`);
		})
	});
}
BlameLines.displayName = "BlameLines";
function BlameSegmentContent({ range, commit, linesData, colorizedLines, copilotAccessAllowed, onLineNumberClick }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [range && commit ? /* @__PURE__ */ jsx(BlameForRange, {
		range,
		commit
	}) : /* @__PURE__ */ jsx("div", { className: "height-full" }), /* @__PURE__ */ jsx("div", {
		className: "react-line-code-pairs d-flex flex-column",
		children: linesData.map((lineData) => /* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-row",
			children: [/* @__PURE__ */ jsx("div", {
				className: `react-line-numbers ${linesData.length > 1 ? "" : "react-blame-no-line-data"}`,
				children: /* @__PURE__ */ jsx(LineNumber, {
					codeLineData: lineData,
					onClick: onLineNumberClick
				}, `line-number-${lineData.lineNumber}-content-${lineData.rawText?.substring(0, 100)}`)
			}), /* @__PURE__ */ jsx("div", {
				className: `react-code-line ${linesData.length > 1 ? "" : "react-blame-no-line-data"}`,
				children: /* @__PURE__ */ jsx(CodeLine, {
					stylingDirectivesLine: lineData.stylingDirectivesLine,
					id: `LC${lineData.lineNumber}`,
					codeLineData: lineData,
					copilotAccessAllowed,
					shouldUseInert: false,
					colorizedLine: colorizedLines?.[lineData.lineNumber - 1]
				}, `code-line=${lineData.lineNumber}-content-${lineData.rawText?.substring(0, 100)}`)
			})]
		}, `line-pair-${lineData.lineNumber}`))
	})] });
}
BlameSegmentContent.displayName = "BlameSegmentContent";
var BlameSegment = React.memo(function BlameSegment({ range, commit, linesData, colorizedLines, virtualOffset, copilotAccessAllowed, onLineNumberClick }) {
	return /* @__PURE__ */ jsx("div", {
		className: "react-blame-segment-wrapper",
		style: virtualOffset !== void 0 ? {
			transform: `translateY(${virtualOffset}px)`,
			position: "absolute",
			top: 0
		} : void 0,
		children: /* @__PURE__ */ jsx(BlameSegmentContent, {
			range,
			commit,
			linesData,
			copilotAccessAllowed,
			colorizedLines,
			onLineNumberClick
		})
	});
}, (prevProps, nextProps) => {
	return prevProps.range === nextProps.range && prevProps.commit === nextProps.commit && prevProps.virtualOffset === nextProps.virtualOffset && isEqual(prevProps.linesData, nextProps.linesData) && isEqual(prevProps.colorizedLines, nextProps.colorizedLines);
});
BlameSegment.displayName = "BlameSegment";
function extractBlameSegments(blame, linesData) {
	if (!blame) return [{ linesData }];
	const segments = [];
	let current = null;
	let isFirst = true;
	for (const lineData of linesData) {
		if (!current) current = { linesData: [] };
		const range = isFirst ? Object.values(blame?.ranges ?? {}).find((r) => r.start <= lineData.lineNumber && r.end >= lineData.lineNumber) : blame?.ranges[lineData.lineNumber];
		if (range) {
			current.range = range;
			current.commit = blame.commits[range.commitOid];
		}
		current.linesData.push(lineData);
		if (current.range?.end === lineData.lineNumber) {
			segments.push(current);
			current = null;
		}
		isFirst = false;
	}
	if (current) {
		segments.push(current);
		current = null;
	}
	return segments;
}
var BlameForRange = React.memo(BlameForRangeUnmemoized);
BlameForRange.displayName = "BlameForRange";
function BlameForRangeUnmemoized(t0) {
	const $ = c(7);
	const { range, commit } = t0;
	const repo = useCurrentRepository();
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	let t1;
	if ($[0] !== commit || $[1] !== getHovercardAttributesForType || $[2] !== range || $[3] !== repo.createdAt || $[4] !== repo.name || $[5] !== repo.ownerLogin) {
		const commitDate = new Date(commit.committedDate);
		const repoCreationDate = new Date(repo.createdAt);
		const timestampAgoElement = jsx("div", {
			className: "timestamp-ago",
			children: jsx(RelativeTime, {
				date: commitDate,
				tense: "past",
				className: Blame_module_default.RelativeTime
			})
		});
		t1 = jsxs("div", {
			className: "react-blame-for-range d-flex",
			children: [
				jsx("div", {
					"aria-hidden": true,
					className: "age-indicator",
					children: jsx(BlameAgeIndicator, {
						commitDate,
						repoCreationDate
					})
				}),
				jsx("div", {
					className: "pt-1 timestamp-wrapper-desktop",
					children: timestampAgoElement
				}),
				jsx("div", {
					className: "author-avatar-wrapper",
					children: commit.authorAvatarUrl && jsx(GitHubAvatar, {
						src: commit.authorAvatarUrl,
						size: 18
					})
				}),
				jsx("div", {
					className: Blame_module_default.commitMessageWrapper,
					children: jsx("div", {
						className: "d-flex",
						children: jsx(VerifiedHTMLText, {
							html: commit.shortMessageHtmlLink,
							className: Blame_module_default.commitMessage,
							...getHovercardAttributesForType("commit", {
								owner: repo.ownerLogin,
								repo: repo.name,
								commitish: commit.oid
							})
						})
					})
				}),
				jsxs("div", {
					className: Blame_module_default.reblameWrapper,
					children: [jsx("div", {
						className: "pt-1 pr-pr-3 timestamp-wrapper-mobile",
						children: timestampAgoElement
					}), jsx(ReblameButton, {
						range,
						commit
					})]
				})
			]
		});
		$[0] = commit;
		$[1] = getHovercardAttributesForType;
		$[2] = range;
		$[3] = repo.createdAt;
		$[4] = repo.name;
		$[5] = repo.ownerLogin;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
BlameForRangeUnmemoized.displayName = "BlameForRangeUnmemoized";
function ReblameButton(t0) {
	const $ = c(13);
	const { range, commit } = t0;
	const repo = useCurrentRepository();
	if (!range.reblamePath) return null;
	let t1;
	if ($[0] !== commit.committedDate || $[1] !== commit.firstParentOid || $[2] !== commit.oid || $[3] !== range.reblamePath || $[4] !== repo.name || $[5] !== repo.ownerLogin) {
		const href = blamePath({
			owner: repo.ownerLogin,
			repo: repo.name,
			commitish: commit.firstParentOid,
			filePath: range.reblamePath
		});
		let shortSHA;
		let t2;
		if ($[7] !== commit.committedDate || $[8] !== commit.oid) {
			const longDateFormatter = new Intl.DateTimeFormat(void 0, {
				year: "numeric",
				month: "short",
				day: "numeric"
			});
			let t3;
			if ($[11] !== commit.oid) {
				t3 = commit.oid.slice(0, 7);
				$[11] = commit.oid;
				$[12] = t3;
			} else t3 = $[12];
			shortSHA = t3;
			t2 = longDateFormatter.format(new Date(commit.committedDate));
			$[7] = commit.committedDate;
			$[8] = commit.oid;
			$[9] = shortSHA;
			$[10] = t2;
		} else {
			shortSHA = $[9];
			t2 = $[10];
		}
		const blameLabel = `Blame prior to change ${shortSHA}, made on ${t2}`;
		const reblameId = `reblame-${shortSHA}`;
		t1 = jsx(Tooltip$1, {
			text: blameLabel,
			type: "label",
			id: reblameId,
			children: jsx(Link$1, {
				"aria-labelledby": reblameId,
				to: href,
				className: "Button Button--iconOnly Button--invisible Button--small",
				children: jsx(VersionsIcon, {})
			})
		});
		$[0] = commit.committedDate;
		$[1] = commit.firstParentOid;
		$[2] = commit.oid;
		$[3] = range.reblamePath;
		$[4] = repo.name;
		$[5] = repo.ownerLogin;
		$[6] = t1;
	} else t1 = $[6];
	return t1;
}
ReblameButton.displayName = "ReblameButton";
function BlameAgeIndicator(t0) {
	const $ = c(2);
	const { commitDate, repoCreationDate } = t0;
	const color = useBlameAgeColor(commitDate, repoCreationDate);
	let t1;
	if ($[0] !== color) {
		t1 = jsx("div", {
			className: "blame-age-indicator",
			style: { backgroundColor: color }
		});
		$[0] = color;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
}
BlameAgeIndicator.displayName = "BlameAgeIndicator";
var CodeBlob_module_default = {
	codeBlobInner: "CodeBlob-module_R1veHa_codeBlobInner",
	codeBlobInnerBlame: "CodeBlob-module_R1veHa_codeBlobInnerBlame",
	codeBlobWrapper: "CodeBlob-module_R1veHa_codeBlobWrapper",
	cursorContainer: "CodeBlob-module_R1veHa_cursorContainer"
};
var CodeLinesSSR_module_default = {
	codeFileContents: "CodeLinesSSR-module_rm1M-a_codeFileContents",
	viewRemainderLink: "CodeLinesSSR-module_rm1M-a_viewRemainderLink"
};
var CodeLinesSSR = React.memo(CodeLinesSSRUnmemoized);
CodeLinesSSR.displayName = "CodeLinesSSR";
function CodeLinesSSRUnmemoized(t0) {
	const $ = c(22);
	const { linesData, onLineNumberClick, codeSections, codeLineToSectionMap, onLineStickOrUnstick, tabSize, contentWidth, copilotAccessAllowed, onCollapseToggle } = t0;
	const wrapOptionEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	const { rawBlobUrl } = useCurrentBlob();
	let t1;
	if ($[0] !== codeLineToSectionMap || $[1] !== codeSections || $[2] !== contentWidth || $[3] !== copilotAccessAllowed || $[4] !== linesData || $[5] !== onCollapseToggle || $[6] !== onLineNumberClick || $[7] !== onLineStickOrUnstick || $[8] !== rawBlobUrl || $[9] !== tabSize || $[10] !== wrapOptionEnabled) {
		let t2;
		if ($[12] !== codeSections || $[13] !== onCollapseToggle || $[14] !== onLineNumberClick || $[15] !== onLineStickOrUnstick) {
			t2 = (lineData) => jsx(LineNumber, {
				codeLineData: lineData,
				onClick: onLineNumberClick,
				ownedCodeSections: codeSections,
				onLineStickOrUnstick,
				onCollapseToggle
			}, `line-number-${lineData.lineNumber}-content:${lineData.rawText?.substring(0, 100)}`);
			$[12] = codeSections;
			$[13] = onCollapseToggle;
			$[14] = onLineNumberClick;
			$[15] = onLineStickOrUnstick;
			$[16] = t2;
		} else t2 = $[16];
		let t3;
		if ($[17] !== codeLineToSectionMap || $[18] !== copilotAccessAllowed || $[19] !== onCollapseToggle || $[20] !== onLineStickOrUnstick) {
			t3 = (lineData_0) => jsx(CodeLine, {
				codeLineData: lineData_0,
				codeLineClassName: lineData_0.codeLineClassName,
				stylingDirectivesLine: lineData_0.stylingDirectivesLine,
				id: `LC${lineData_0.lineNumber}`,
				onLineStickOrUnstick,
				setIsCollapsed: onCollapseToggle,
				codeLineToSectionMap,
				copilotAccessAllowed,
				measureRef: void 0,
				shouldUseInert: false
			}, `line-data-${lineData_0.lineNumber}-content:${lineData_0.rawText?.substring(0, 100)}`);
			$[17] = codeLineToSectionMap;
			$[18] = copilotAccessAllowed;
			$[19] = onCollapseToggle;
			$[20] = onLineStickOrUnstick;
			$[21] = t3;
		} else t3 = $[21];
		t1 = jsxs(Fragment$1, { children: [jsxs("div", {
			className: clsx("react-code-file-contents", CodeLinesSSR_module_default.codeFileContents),
			role: "presentation",
			"aria-hidden": true,
			"data-tab-size": tabSize,
			"data-paste-markdown-skip": true,
			style: {
				tabSize,
				width: contentWidth,
				maxWidth: wrapOptionEnabled ? "100%" : "unset"
			},
			"data-hpc": true,
			children: [jsx("div", {
				className: "react-line-numbers",
				style: { pointerEvents: "auto" },
				children: linesData.map(t2)
			}), jsx("div", {
				className: "react-code-lines",
				children: linesData.map(t3)
			})]
		}), linesData.length === 1e3 && jsx("div", {
			className: CodeLinesSSR_module_default.viewRemainderLink,
			children: jsx(Link, {
				href: rawBlobUrl,
				children: "View remainder of file in raw view"
			})
		})] });
		$[0] = codeLineToSectionMap;
		$[1] = codeSections;
		$[2] = contentWidth;
		$[3] = copilotAccessAllowed;
		$[4] = linesData;
		$[5] = onCollapseToggle;
		$[6] = onLineNumberClick;
		$[7] = onLineStickOrUnstick;
		$[8] = rawBlobUrl;
		$[9] = tabSize;
		$[10] = wrapOptionEnabled;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
CodeLinesSSRUnmemoized.displayName = "CodeLinesSSRUnmemoized";
var CodeLinesSSRNoVirtualization_module_default = {
	codeFileContents: "CodeLinesSSRNoVirtualization-module_q425CG_codeFileContents",
	viewRemainderLink: "CodeLinesSSRNoVirtualization-module_q425CG_viewRemainderLink"
};
var CodeLinesSSRNoVirtualization = React.memo(CodeLinesSSRNoVirtualizationUnmemoized);
CodeLinesSSRNoVirtualization.displayName = "CodeLinesSSRNoVirtualization";
function CodeLinesSSRNoVirtualizationUnmemoized(t0) {
	const $ = c(16);
	const { linesData, onLineNumberClick, codeSections, nonTruncatedLinesData, colorizedLines, onLineStickOrUnstick, tabSize, contentWidth, copilotAccessAllowed, onCollapseToggle } = t0;
	const wrapOptionEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	const { rawBlobUrl } = useCurrentBlob();
	let t1;
	if ($[0] !== linesData.length) {
		t1 = [...Array(Math.floor(linesData.length / 60) + 1).keys()];
		$[0] = linesData.length;
		$[1] = t1;
	} else t1 = $[1];
	const lineArrayMap = t1;
	let t2;
	if ($[2] !== codeSections || $[3] !== colorizedLines || $[4] !== contentWidth || $[5] !== copilotAccessAllowed || $[6] !== lineArrayMap || $[7] !== linesData || $[8] !== nonTruncatedLinesData || $[9] !== onCollapseToggle || $[10] !== onLineNumberClick || $[11] !== onLineStickOrUnstick || $[12] !== rawBlobUrl || $[13] !== tabSize || $[14] !== wrapOptionEnabled) {
		t2 = jsxs("div", {
			className: clsx("react-code-file-contents", CodeLinesSSRNoVirtualization_module_default.codeFileContents),
			role: "presentation",
			"aria-hidden": true,
			"data-tab-size": tabSize,
			"data-paste-markdown-skip": true,
			style: {
				tabSize,
				width: contentWidth,
				maxWidth: wrapOptionEnabled ? "100%" : "unset"
			},
			"data-hpc": true,
			children: [jsx("div", {
				className: "react-line-numbers-no-virtualization",
				style: {
					pointerEvents: "auto",
					position: "relative",
					zIndex: 2
				},
				children: lineArrayMap.map((segmentCount) => {
					const tempLines = linesData.slice(segmentCount * 60, Math.min(segmentCount * 60 + 60, linesData.length));
					return jsx("div", {
						className: "react-no-virtualization-wrapper-lines-ssr",
						children: tempLines.map((lineData) => jsx(LineNumberNoVirtualziation, {
							codeLineData: lineData,
							onClick: onLineNumberClick,
							ownedCodeSections: codeSections,
							onLineStickOrUnstick,
							onCollapseToggle
						}, `line-number-${lineData.lineNumber}`))
					}, `line-number-wrapper-${segmentCount}-content:${tempLines[0]?.rawText?.substring(0, 100)}`);
				})
			}), jsxs("div", {
				className: "react-code-lines",
				children: [
					jsx(HighlightedSymbolsOverlay, { linesData }),
					jsx(HighlightedLinesOverlay, {
						linesData,
						copilotAccessAllowed
					}),
					jsx(SyntaxHighlightedOverlay, {
						linesData: nonTruncatedLinesData,
						colorizedLines
					}),
					linesData.length === 1e3 && jsx("div", {
						className: CodeLinesSSRNoVirtualization_module_default.viewRemainderLink,
						children: jsx(Link, {
							href: rawBlobUrl,
							children: "View remainder of file in raw view"
						})
					})
				]
			})]
		});
		$[2] = codeSections;
		$[3] = colorizedLines;
		$[4] = contentWidth;
		$[5] = copilotAccessAllowed;
		$[6] = lineArrayMap;
		$[7] = linesData;
		$[8] = nonTruncatedLinesData;
		$[9] = onCollapseToggle;
		$[10] = onLineNumberClick;
		$[11] = onLineStickOrUnstick;
		$[12] = rawBlobUrl;
		$[13] = tabSize;
		$[14] = wrapOptionEnabled;
		$[15] = t2;
	} else t2 = $[15];
	return t2;
}
CodeLinesSSRNoVirtualizationUnmemoized.displayName = "CodeLinesSSRNoVirtualizationUnmemoized";
function useCodeLines(rawLines, stylingDirectives, codeSections, splitCodeownersErrors, codeLineToSectionMap) {
	const nonTruncatedLinesData = useLinesData(rawLines, stylingDirectives, codeSections, splitCodeownersErrors, codeLineToSectionMap);
	const exposeHiddenUnicodeCharacters = isHiddenUnicodeShown();
	const collapsedLinesDependancyRef = useRef("");
	useLinesSubscription((collapsedSections) => collapsedLinesDependancyRef.current = createCollapsedLinesString(collapsedSections));
	const lines = useMemo(() => getLinesDataWithCollapsedSectionsExcluded(nonTruncatedLinesData, codeSections), [
		nonTruncatedLinesData,
		codeSections,
		collapsedLinesDependancyRef.current
	]);
	return {
		lines,
		plainTextLinesAsString: lines.map((line) => exposeHiddenUnicodeCharacters && line.rawText ? showHiddenUnicodeCharactersRaw(line.rawText) : line.rawText).join("\n"),
		nonTruncatedLinesData
	};
}
function useLinesData(rawLines, stylingDirectives, codeSections, splitCodeownersErrors, codeLineToSectionMap) {
	const $ = c(13);
	const { isServer } = useRuntimeEnvironment();
	const linesToRender = isServer ? Math.min(rawLines.length, 1e3) : rawLines.length;
	let t0;
	if ($[0] !== codeLineToSectionMap || $[1] !== codeSections || $[2] !== linesToRender || $[3] !== rawLines || $[4] !== splitCodeownersErrors || $[5] !== stylingDirectives) {
		const lineNumbers = new Array(linesToRender).fill(null).map(_temp$4);
		let t1;
		if ($[7] !== codeLineToSectionMap || $[8] !== codeSections || $[9] !== rawLines || $[10] !== splitCodeownersErrors || $[11] !== stylingDirectives) {
			t1 = (lineNumber) => {
				const stylingDirectivesLine = stylingDirectives?.[lineNumber - 1];
				let ownedSection = void 0;
				let isStartLine = false;
				let isEndLine = false;
				for (const section of codeSections?.get(lineNumber) ?? []) {
					if (section.startLine === lineNumber) {
						isStartLine = true;
						ownedSection = section;
					}
					if (section.endLine === lineNumber) isEndLine = true;
				}
				const rawText = rawLines[lineNumber - 1]?.replace(/[\n\r]/g, "") ?? "";
				return {
					stylingDirectivesLine,
					lineNumber,
					codeLineClassName: buildRowClass(codeLineToSectionMap ? codeLineToSectionMap.get(lineNumber) || [] : [], lineNumber, isEndLine, codeSections),
					isStartLine,
					isEndLine,
					ownedSection,
					rawText,
					hiddenUnicode: hasHiddenUnicodeCharacters(rawText),
					codeownersLineError: splitCodeownersErrors?.find((error) => error.line === lineNumber)
				};
			};
			$[7] = codeLineToSectionMap;
			$[8] = codeSections;
			$[9] = rawLines;
			$[10] = splitCodeownersErrors;
			$[11] = stylingDirectives;
			$[12] = t1;
		} else t1 = $[12];
		t0 = lineNumbers.map(t1);
		$[0] = codeLineToSectionMap;
		$[1] = codeSections;
		$[2] = linesToRender;
		$[3] = rawLines;
		$[4] = splitCodeownersErrors;
		$[5] = stylingDirectives;
		$[6] = t0;
	} else t0 = $[6];
	return t0;
}
function _temp$4(_, i) {
	return i + 1;
}
function getLinesDataWithCollapsedSectionsExcluded(fullLinesData, codeSections) {
	const excludedLines = /* @__PURE__ */ new Set();
	for (let i = 0; i < fullLinesData.length; i++) {
		if (excludedLines.has(i)) continue;
		const sections = codeSections?.get(i) ?? [];
		for (let j = 0; j < sections.length; j++) if (sections[j].collapsed) {
			for (let k = sections[j].startLine + 1; k <= sections[j].endLine; k++) excludedLines.add(k);
			if (sections[j].startLine === i) i = sections[j].endLine;
			break;
		}
	}
	return fullLinesData.filter((lineData) => !excludedLines.has(lineData.lineNumber));
}
function createCollapsedLinesString(collapsedLines) {
	const setArray = [...collapsedLines];
	setArray.sort();
	return setArray.join(",");
}
var NavigationCursor_module_default = { navigationCursor: "NavigationCursor-module_cWbSOW_navigationCursor" };
function NavigationCursor({ linesData, onCodeNavTokenSelected, onLineNumberClick, isBlame, isCursorVisible, isVirtualized, textAreaRef, shouldRenderOverlay, tabSize, optionalTestLeftOffsetFunction, textSelection, onCollapseToggle, onLineStickOrUnstick, optionalTestTopOffsetFunction, additionalTextAreaInstructions }) {
	const [leftOffset, setLeftOffset] = useState(0);
	const [topOffset, setTopOffset] = useState(0);
	const [shouldShowHighlightMenu, setShouldShowHighlightMenu] = useState(false);
	const lastKeyPressedRef = useRef("");
	const menuRef = useRef(null);
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { canEdit } = useEditPermissions();
	const { cursorNavigationHighlightLine, expandAndFocusLineContextMenu, cursorNavigationEnter, searchShortcut, cursorNavigationPageDown, cursorNavigationPageUp } = useShortcut();
	function onLineMenuClose(value, wasExpandCollapseCodeSection) {
		setShouldShowHighlightMenu(value);
		setTimeout(() => {
			if (wasExpandCollapseCodeSection) determineAndSetTextAreaCursorPosition();
			textAreaRef?.current?.focus();
		}, 300);
	}
	function showLineMenu(event) {
		event.preventDefault();
		event.stopPropagation();
		setShouldShowHighlightMenu(true);
		setTimeout(() => {
			menuRef.current?.setAnchor(cursorRef.current);
		}, 0);
		return false;
	}
	useEffect(() => {
		setLeftOffset(0);
		setTopOffset(0);
	}, [useLocation$1().key]);
	useEffect(() => {
		function keydownKeyChecking(event_0) {
			lastKeyPressedRef.current = event_0.key;
		}
		function contextMenuCheckDoNotTriggerBasicMenu(event_1) {
			if (lastKeyPressedRef.current === "ContextMenu" && event_1.button === -1 && document.activeElement?.className.indexOf("highlighted-line-menu-first-option") !== -1) {
				lastKeyPressedRef.current = "";
				event_1?.preventDefault();
				event_1?.stopPropagation();
				return false;
			}
		}
		window.oncontextmenu = contextMenuCheckDoNotTriggerBasicMenu;
		window.addEventListener("keydown", keydownKeyChecking);
		return () => {
			window.removeEventListener("keydown", keydownKeyChecking);
			window.oncontextmenu = null;
		};
	}, []);
	const minLeftOffset = isBlame ? 92 : 92;
	const cursorRef = useRef(null);
	const { onEnter, updateUrlForLineNumber, onPageUp, onPageDown, currentStartLine, currentStartChar, currentEndLine, currentEndChar, determineAndSetTextAreaCursorPosition, getCorrectLineNumberWithCollapsedSections } = useCursorNavigation(cursorRef, onCodeNavTokenSelected, optionalTestLeftOffsetFunction ?? setLeftOffset, optionalTestTopOffsetFunction ?? setTopOffset, linesData, isVirtualized, isBlame, onLineNumberClick, textAreaRef, tabSize, additionalTextAreaInstructions, textSelection);
	const isMobileRef = useRef(false);
	function determineClosestParentCodeSection() {
		if (currentStartLine.current !== currentEndLine.current) return null;
		const currentLineData = linesData[currentStartLine.current];
		if (!currentLineData) return null;
		if (currentLineData.isStartLine) return currentLineData;
		if (currentLineData.codeLineClassName === "") return null;
		const lineCodeSections = currentLineData.codeLineClassName?.split("child-of-line-");
		if (!lineCodeSections || currentLineData.codeLineClassName?.indexOf("child-of-line-") === -1) return null;
		const closestParentCodeSection = parseInt(lineCodeSections[lineCodeSections.length - 1]?.trim() ?? "undefined");
		if (closestParentCodeSection && !Number.isNaN(closestParentCodeSection)) {
			if (linesData[closestParentCodeSection - 1] && linesData[closestParentCodeSection - 1]?.lineNumber === closestParentCodeSection) return linesData[closestParentCodeSection - 1];
			return linesData[getActualLineNumberBinarySearch(closestParentCodeSection, linesData)];
		}
		return null;
	}
	useEffect(() => {
		isMobileRef.current = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
	}, []);
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const cursorStyle = isCursorVisible ? {
		height: `${lineHeight}px`,
		visibility: isMobileRef.current ? "hidden" : "visible"
	} : void 0;
	let editorLinkHash;
	if (currentStartLine.current === currentEndLine.current && currentStartChar.current === currentEndChar.current) editorLinkHash = `#L${currentStartLine.current + 1}C${currentStartChar.current}`;
	else editorLinkHash = `#${formatBlobRange({
		start: {
			line: currentStartLine.current + 1,
			column: currentStartChar.current
		},
		end: {
			line: currentEndLine.current + 1,
			column: currentEndChar.current
		}
	})}`;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("div", {
			"aria-hidden": true,
			style: {
				top: topOffset,
				left: minLeftOffset + leftOffset,
				...cursorStyle
			},
			ref: cursorRef,
			"data-testid": "navigation-cursor",
			className: clsx("code-navigation-cursor", isCursorVisible && NavigationCursor_module_default.navigationCursor),
			children: " "
		}),
		shouldRenderOverlay && /* @__PURE__ */ jsx("div", {
			style: {
				top: topOffset + lineHeight,
				left: minLeftOffset + leftOffset,
				zIndex: 2
			},
			className: "position-absolute border rounded-2 color-bg-subtle tmp-px-3 py-2",
			children: /* @__PURE__ */ jsxs("span", {
				style: { pointerEvents: "auto" },
				children: [
					"Code view is read-only.",
					" ",
					canEdit && /* @__PURE__ */ jsx(Link$1, {
						to: editBlobPath({
							owner: repo.ownerLogin,
							repo: repo.name,
							filePath: path,
							commitish: refInfo.name,
							hash: editorLinkHash
						}),
						children: "Switch to the editor."
					})
				]
			})
		}),
		shouldShowHighlightMenu && /* @__PURE__ */ jsx(HighlightedLineMenu, {
			ref: menuRef,
			rowBeginId: `LG${getCorrectLineNumberWithCollapsedSections(currentStartLine.current)}`,
			rowBeginNumber: getCorrectLineNumberWithCollapsedSections(currentStartLine.current),
			rowEndNumber: getCorrectLineNumberWithCollapsedSections(currentEndLine.current),
			rowEndId: `LG${getCorrectLineNumberWithCollapsedSections(currentEndLine.current)}`,
			openOnLoad: true,
			cursorRef,
			onCollapseToggle,
			onLineStickOrUnstick,
			lineData: determineClosestParentCodeSection(),
			onMenuClose: onLineMenuClose
		}),
		/* @__PURE__ */ jsx("button", {
			hidden: true,
			"data-testid": "NavigationCursorEnter",
			"data-hotkey": cursorNavigationEnter.hotkey,
			onClick: onEnter,
			"data-hotkey-scope": textAreaId
		}),
		/* @__PURE__ */ jsx("button", {
			hidden: true,
			"data-testid": "NavigationCursorSetHighlightedLine",
			"data-hotkey": cursorNavigationHighlightLine.hotkey,
			onClick: updateUrlForLineNumber,
			"data-hotkey-scope": textAreaId
		}),
		/* @__PURE__ */ jsx("button", {
			hidden: true,
			"data-testid": "NavigationCursorSetHighlightAndExpandMenu",
			"data-hotkey": expandAndFocusLineContextMenu.hotkey,
			onClick: (event_2) => showLineMenu(event_2),
			"data-hotkey-scope": textAreaId
		}),
		/* @__PURE__ */ jsx("button", {
			hidden: true,
			"data-testid": "NavigationCursorPageDown",
			"data-hotkey": cursorNavigationPageDown.hotkey,
			onClick: onPageDown,
			"data-hotkey-scope": textAreaId
		}),
		/* @__PURE__ */ jsx("button", {
			hidden: true,
			"data-testid": "NavigationCursorPageUp",
			"data-hotkey": cursorNavigationPageUp.hotkey,
			onClick: onPageUp,
			"data-hotkey-scope": textAreaId
		}),
		/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: searchShortcut.hotkey,
			onButtonClick: () => {
				appendAndFocusSearchBar({
					retainScrollPosition: true,
					returnTarget: textAreaRef?.current ?? void 0
				});
			},
			onlyAddHotkeyScopeButton: true
		})
	] });
}
NavigationCursor.displayName = "NavigationCursor";
function TextAreaHelpDialog(t0) {
	const $ = c(5);
	const { onDismiss } = t0;
	const { expandAndFocusLineContextMenu, cursorNavigationEnter, cursorNavigationHighlightLine } = useShortcut();
	let t1;
	if ($[0] !== cursorNavigationEnter.text || $[1] !== cursorNavigationHighlightLine.text || $[2] !== expandAndFocusLineContextMenu.text || $[3] !== onDismiss) {
		t1 = createPortal(jsx(Dialog, {
			width: "large",
			"aria-label": "Code Blob Focused Hotkeys",
			onClose: onDismiss,
			title: "Code Blob Focused Hotkeys",
			children: jsx("div", { children: jsxs("div", { children: [
				jsxs("div", {
					className: "p-1",
					children: ["Select the line the cursor is on ", jsx("kbd", { children: cursorNavigationHighlightLine.text })]
				}),
				jsxs("div", {
					className: "p-1",
					children: ["Select the symbol under the cursor ", jsx("kbd", { children: cursorNavigationEnter.text })]
				}),
				jsxs("div", {
					className: "p-1",
					children: ["Move focus to the highlighted line menu ", jsx("kbd", { children: expandAndFocusLineContextMenu.text })]
				})
			] }) })
		}), document.body);
		$[0] = cursorNavigationEnter.text;
		$[1] = cursorNavigationHighlightLine.text;
		$[2] = expandAndFocusLineContextMenu.text;
		$[3] = onDismiss;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
TextAreaHelpDialog.displayName = "TextAreaHelpDialog";
var approximateBlobYOffsetDesktop = 354;
var approximateBlobYOffsetMobile = 423;
function TextArea({ textAreaRef, setTextOverlayShouldBeVisible, setTextSelection, setAdditionalTextAreaInstructions, cursorClickStartRef, parentRef, tabSize, plainTextLinesAsString, numLines, setIsTextAreaFocused }) {
	const shouldUseCursor = useIsCursorEnabled();
	const wrapOption = useCodeViewOptions().codeWrappingOption;
	const blobFocusShortcuts = useBlobFocusedShortcuts();
	const blobFocusModifierShortcuts = useBlobFocusedModifierShortcuts();
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const textAreaHeight = lineHeight * (numLines + 1);
	const [helpDialogOpen, setHelpDialogOpen] = useState(false);
	const { cursorNavigationOpenHelpDialog } = useShortcut();
	const { colorMode, dayScheme, nightScheme } = use_color_modes_default();
	const isHighContrast = (colorMode === "night" ? nightScheme : dayScheme)?.endsWith("high_contrast");
	function exactRegexMatch(regex, text) {
		const match = regex.exec(text);
		return match && match[0] === text;
	}
	function handleKeydownWithinTextArea(e) {
		if (blobFocusShortcuts.includes(e.key) || blobFocusModifierShortcuts.includes(e.key) && (e.getModifierState("Control") || e.getModifierState("Alt") || e.getModifierState("Shift") || e.getModifierState("Meta"))) {
			if (e.key === " ") {
				e.preventDefault();
				if (e.shiftKey) setAdditionalTextAreaInstructions(`PageUp${Date.now()}`);
				else setAdditionalTextAreaInstructions(`PageDown${Date.now()}`);
			}
			if (e.altKey && e.ctrlKey && e.key === "˙") setHelpDialogOpen(true);
			setTextOverlayShouldBeVisible(false);
			requestAnimationFrame(() => {
				if (textAreaRef.current) setTextSelection({
					start: textAreaRef.current.selectionStart,
					end: textAreaRef.current.selectionEnd,
					keyboard: true,
					displayStart: false
				});
			});
		} else if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && (exactRegexMatch(/[a-zA-Z0-9-_ ]{1,1}/, e.key) || e.key === "Backspace" || e.key === "Enter")) {
			announce$1("Code view is read only.");
			setTextOverlayShouldBeVisible(true);
			e.preventDefault();
		}
	}
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx("textarea", {
			id: textAreaId,
			"data-testid": textAreaId,
			ref: textAreaRef,
			onMouseUp: (event) => mouseUpHandler(event, textAreaRef, setTextOverlayShouldBeVisible, setTextSelection, cursorClickStartRef, shouldUseCursor, parentRef, lineHeight),
			onMouseDown: (event_0) => mouseDownHandler(event_0, parentRef, shouldUseCursor, cursorClickStartRef, lineHeight),
			"aria-label": "file content",
			"aria-readonly": true,
			inputMode: "none",
			tabIndex: 0,
			"aria-multiline": true,
			"aria-haspopup": false,
			"data-gramm": "false",
			"data-gramm_editor": "false",
			"data-enable-grammarly": "false",
			style: {
				resize: "none",
				marginTop: -2,
				paddingLeft: 92,
				paddingRight: 70,
				display: "hidden",
				width: "100%",
				backgroundColor: "unset",
				boxSizing: "border-box",
				color: "transparent",
				position: "absolute",
				border: "none",
				tabSize,
				outline: "none",
				overflowX: "auto",
				height: textAreaHeight,
				fontSize: "12px",
				lineHeight: "20px",
				overflowY: "hidden",
				overflowWrap: wrapOption.enabled ? "anywhere" : "normal",
				overscrollBehaviorX: "none",
				whiteSpace: wrapOption.enabled ? "pre-wrap" : "pre",
				zIndex: 1
			},
			value: plainTextLinesAsString,
			onKeyDown: handleKeydownWithinTextArea,
			spellCheck: false,
			autoCorrect: "off",
			autoCapitalize: "off",
			autoComplete: "off",
			"data-ms-editor": "false",
			onDrop: (e_0) => {
				const text_0 = e_0.dataTransfer.getData("Text");
				try {
					const url = new URL(text_0);
					window.open(url, "_blank")?.focus();
				} catch {}
				return false;
			},
			onPaste: (e_1) => {
				e_1.preventDefault();
				return false;
			},
			onChange: () => {},
			className: `react-blob-textarea react-blob-print-hide${isHighContrast ? " select-contrast" : ""}`,
			onFocus: () => {
				setIsTextAreaFocused(true);
			}
		}),
		helpDialogOpen && /* @__PURE__ */ jsx(TextAreaHelpDialog, { onDismiss: () => {
			setHelpDialogOpen(false);
		} }),
		/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: cursorNavigationOpenHelpDialog.hotkey,
			onButtonClick: () => {
				setHelpDialogOpen(true);
			},
			onlyAddHotkeyScopeButton: true
		})
	] });
}
TextArea.displayName = "TextArea";
function mouseUpHandler(event, textAreaRef, setTextOverlayShouldBeVisible, setTextSelection, cursorClickStartRef, shouldUseCursor, parentRef, lineHeight) {
	if (!shouldUseCursor || event.defaultPrevented || !cursorClickStartRef) return;
	if (event.button === 2) {
		event.preventDefault();
		event.stopPropagation();
	} else if (event.button === 0) {
		setTextOverlayShouldBeVisible(false);
		const isSmallScreen = window.matchMedia(`(max-width: ${ScreenSize.medium - 1}px)`).matches;
		const parentRect = parentRef.current?.getBoundingClientRect();
		const scrollTopOffset = parentRect?.top ? window.scrollY + parentRect.top : isSmallScreen ? approximateBlobYOffsetMobile : approximateBlobYOffsetDesktop;
		if (parentRef.current && event.pageY > scrollTopOffset + parentRef.current?.clientHeight) {
			cursorClickStartRef.current = {
				startX: -2,
				startY: -2
			};
			return;
		}
		const lineNumberOfClick = calculateLineNumberFromOffset(event.pageY, scrollTopOffset, lineHeight);
		const leftClickOffset = parentRect?.left || 0;
		const xOffset = event.clientX - leftClickOffset - 92;
		let displayAtStart = false;
		if (lineNumberOfClick < cursorClickStartRef.current.startY || lineNumberOfClick === cursorClickStartRef.current.startY && xOffset < cursorClickStartRef.current.startX) displayAtStart = true;
		requestAnimationFrame(() => {
			if (textAreaRef && textAreaRef.current) setTextSelection({
				start: textAreaRef.current.selectionStart,
				end: textAreaRef.current.selectionEnd,
				keyboard: false,
				displayStart: displayAtStart
			});
		});
	}
}
function mouseDownHandler(event, parentRef, shouldUseCursor, cursorClickStartRef, lineHeight) {
	if (!shouldUseCursor || event.defaultPrevented || !cursorClickStartRef) return;
	if (event.button === 2) {
		event.preventDefault();
		event.stopPropagation();
		return;
	} else if (event.button === 0) {
		if (event.ctrlKey) {
			event.preventDefault();
			event.stopPropagation();
			return;
		}
		const isSmallScreen = window.matchMedia(`(max-width: ${ScreenSize.medium - 1}px)`).matches;
		const parentRect = parentRef.current?.getBoundingClientRect();
		const scrollTopOffset = parentRect?.top ? window.scrollY + parentRect.top : isSmallScreen ? approximateBlobYOffsetMobile : approximateBlobYOffsetDesktop;
		if (parentRef.current && event.pageY > scrollTopOffset + parentRef.current?.clientHeight) {
			cursorClickStartRef.current = {
				startX: -2,
				startY: -2
			};
			return;
		}
		const lineNumberOfClick = calculateLineNumberFromOffset(event.pageY, scrollTopOffset, lineHeight);
		const leftClickOffset = parentRect?.left || 0;
		cursorClickStartRef.current = {
			startX: event.clientX - leftClickOffset - 92,
			startY: lineNumberOfClick
		};
	}
}
var safeLocalStorage = safeStorage("localStorage");
function CodeBlob({ blobLinesHandle, onCodeNavTokenSelected, codeSections, codeLineToSectionMap, validCodeNav, onLineStickOrUnstick, searchResults, focusedSearchResult }) {
	const { rawLines, colorizedLines, stylingDirectives } = useCurrentStyledBlob();
	const { tabSize } = useCurrentBlob();
	const hasBlame = !!useCurrentBlame();
	const [shouldMaterializeAllLines, setShouldMaterializeAllLines] = useState(false);
	const shouldUseCursor = useIsCursorEnabled();
	const lineHeight = useCurrentLineHeight("react-line-numbers");
	const [highlightedLines, setHighlightedLines] = useState(void 0);
	const [textSelection, setTextSelection] = useState({
		start: -1,
		end: -1,
		keyboard: true,
		displayStart: false
	});
	const [additionalTextAreaInstructions, setAdditionalTextAreaInstructions] = useState("");
	const [isTextAreaFocused, setIsTextAreaFocused] = useState(false);
	const parentRef = useRef(null);
	const [textOverlayShouldBeVisible, setTextOverlayShouldBeVisible] = useState(false);
	const cursorClickStartRef = useRef({
		startX: 0,
		startY: 0
	});
	const { hash } = useLocation$1();
	const path = usePath();
	const { copilotAccessAllowed } = useCopilotSettings();
	const refInfo = useRefInfo();
	const textAreaRef = useRef(null);
	const [contentWidth, setContentWidth] = useState(void 0);
	const { isServer: isSSR } = useRuntimeEnvironment();
	const cursorContainerRef = useRef(null);
	const wordWrapEnabled = useCodeViewOptions().codeWrappingOption.enabled;
	const reRender = useManualRender();
	const currentLineRefMap = useLineElementMap();
	const sharedLineObserver = useSharedLineObserver(true, useStickyHeaderHeight(), onLineStickOrUnstick);
	const onLineNumberClick = useCallback(() => {
		setHighlightedLines(parseFileAnchor(window.location.hash)?.blobRange);
	}, []);
	const { findInFileOpen, setFindInFileOpen } = useFindInFileOpen();
	const splitCodeownersErrors = useSplitCodeownersErrorsContext();
	const { lines, plainTextLinesAsString, nonTruncatedLinesData } = useCodeLines(rawLines ?? [], stylingDirectives ?? null, codeSections ?? null, splitCodeownersErrors, codeLineToSectionMap);
	const doOverlay = useShouldDoNoVirtualization(nonTruncatedLinesData.length) && colorizedLines && colorizedLines.length !== 0;
	const linesRef = useRef(lines);
	linesRef.current = lines;
	useEffect(() => {
		expandAllRows();
	}, [refInfo.currentOid, path]);
	useEffect(() => {
		window.onbeforeprint = () => setShouldMaterializeAllLines(true);
		window.onafterprint = () => setShouldMaterializeAllLines(false);
	}, []);
	const collectWordWrapPreferencesOnLoad = useEffectEvent(() => {
		updateExpandPreferences(null, null, wordWrapEnabled);
	});
	useEffect(() => {
		collectWordWrapPreferencesOnLoad();
	}, []);
	useEffect(() => {
		if (!(safeLocalStorage.getItem("heardHelpAnnouncement") === "true")) {
			forceAnnouncementToScreenReaders("While the code is focused, press Alt+F1 for a menu of operations.", 2e3);
			safeLocalStorage.setItem("heardHelpAnnouncement", "true");
		}
	}, []);
	/**
	*  This useCallback is present to handle when the user hovers over a symbol
	*  and we add an on click event to that particular symbol. We add an attribute at
	*  the same time which we then later check for on future hovers to make sure we do
	*  not add the same event listener multiple times.
	*
	*  SymbolUnderPointer is changed constantly, basically whenever you move the mouse, so
	*  removing the event listener on a useEffect return does not work in this instance.
	*
	*  It is possible the entire thing can be refactored in some way to be able to remove
	*  the event listener on a useEffect return, but the only way this is a significant
	*  performance degradation is if a user systematically hovers over every symbol on the page, whereas
	*  this version saves us a lot of time on repeated hovers of the same symbol as well as time saved on
	*  moving the cursor around the page.
	*/
	useSymbolUnderPointer(useCallback((symbolUnderPointer) => {
		function onTokenClick(e) {
			const text = e.target.textContent ? e.target.textContent : "";
			if (onCodeNavTokenSelected && symbolUnderPointer) {
				onCodeNavTokenSelected({
					selectedText: text,
					lineNumber: symbolUnderPointer.lineNumber,
					offset: symbolUnderPointer.offset
				});
				if (findInFileOpen) setFindInFileOpen(false);
			}
		}
		if (symbolUnderPointer && symbolUnderPointer?.node && !hasBlame) {
			if (!symbolUnderPointer.node.textContent || symbolUnderPointer.node.textContent.length < 3) return;
			const element = symbolUnderPointer.node;
			if (!element || !element.hasAttribute || element.hasAttribute("clickadded")) return;
			element.classList.add("pl-token");
			element.setAttribute("clickadded", "true");
			element.addEventListener("click", onTokenClick);
		}
	}, [
		findInFileOpen,
		hasBlame,
		setFindInFileOpen,
		onCodeNavTokenSelected
	]), validCodeNav);
	const scrollSelectedLineIntoView = ({ line, column }) => {
		if (line < 10) blobLinesHandle.current?.scrollToTop();
		else if (blobLinesHandle.current) {
			if (getActualLineNumberBinarySearch(line, lines) === -1) {
				const sectionArray = codeLineToSectionMap?.get(line);
				for (const section of sectionArray ?? []) if (section && section.collapsed) {
					section.collapsed = false;
					expandRow(section?.startLine);
				}
				reRender();
			}
			setTimeout(() => {
				const updatedLineAccountingForCollapsedSections = getActualLineNumberBinarySearch(line, linesRef.current);
				blobLinesHandle.current?.scrollToLine(updatedLineAccountingForCollapsedSections, column);
			}, 0);
			if (currentLineRefMap && !isLineInViewport(line)) {
				onLineStickOrUnstick(null, true);
				applyStickyToParentStartLines(currentLineRefMap, line, codeLineToSectionMap, onLineStickOrUnstick);
			}
		}
	};
	useEffect(() => {
		const anchInfo = parseFileAnchor(hash);
		if (!anchInfo.blobRange?.start?.line) {
			setHighlightedLines(void 0);
			return;
		}
		setHighlightedLines(anchInfo.blobRange);
	}, [
		path,
		hash,
		lines.length
	]);
	const updateScrollPositionOnPathChange = useEffectEvent(() => {
		const anchInfo_0 = parseFileAnchor(hash);
		if (!anchInfo_0.blobRange?.start?.line) return;
		const timeout = window.setTimeout(() => scrollSelectedLineIntoView({ line: anchInfo_0.blobRange.start.line }), 0);
		return () => {
			window.clearTimeout(timeout);
		};
	});
	useEffect(() => {
		return updateScrollPositionOnPathChange();
	}, [path, hasBlame]);
	useEffect(() => {
		const currentTextArea = textAreaRef.current;
		if (!currentTextArea || !shouldUseCursor) {
			setContentWidth(void 0);
			return;
		}
		setContentWidth(currentTextArea.scrollWidth > currentTextArea.clientWidth ? currentTextArea.scrollWidth : void 0);
		const observer = new ResizeObserver((entries) => {
			for (const { target } of entries) setContentWidth(target.scrollWidth > target.clientWidth ? target.scrollWidth : void 0);
		});
		observer.observe(currentTextArea);
		return () => {
			observer.disconnect();
		};
	}, [shouldUseCursor, path]);
	useScrollLineIntoView(scrollSelectedLineIntoView);
	return /* @__PURE__ */ jsx(SearchResultsProvider, {
		searchResults,
		focusedSearchResult,
		children: /* @__PURE__ */ jsxs(HighlightedLinesProvider, {
			highlightedLines,
			children: [lines.some((line_0) => line_0.hiddenUnicode) && /* @__PURE__ */ jsx(HiddenUnicodeAlert, {}), /* @__PURE__ */ jsx("div", {
				className: CodeBlob_module_default.codeBlobWrapper,
				style: {
					paddingTop: hasBlame ? 0 : "8px",
					paddingBottom: hasBlame ? 0 : "8px"
				},
				children: /* @__PURE__ */ jsx(HighlightedLineMenuContainer, { children: /* @__PURE__ */ jsx(CopilotButtonContainer, { children: /* @__PURE__ */ jsxs("div", {
					className: clsx(CodeBlob_module_default.codeBlobInner, hasBlame && CodeBlob_module_default.codeBlobInnerBlame),
					ref: parentRef,
					onBlur: (e_0) => {
						if (e_0.currentTarget.contains(e_0.relatedTarget)) return;
						setIsTextAreaFocused(false);
					},
					children: [
						shouldUseCursor && /* @__PURE__ */ jsx("div", {
							ref: cursorContainerRef,
							className: CodeBlob_module_default.cursorContainer,
							children: /* @__PURE__ */ jsx("div", {
								style: {
									width: contentWidth,
									height: lineHeight * lines.length
								},
								children: /* @__PURE__ */ jsx(NavigationCursor, {
									linesData: lines,
									isBlame: false,
									onCodeNavTokenSelected,
									onLineNumberClick,
									isCursorVisible: !!isTextAreaFocused,
									isVirtualized: true,
									textAreaRef,
									onCollapseToggle: reRender,
									onLineStickOrUnstick,
									tabSize,
									textSelection,
									shouldRenderOverlay: !!textOverlayShouldBeVisible,
									additionalTextAreaInstructions: additionalTextAreaInstructions ?? ""
								})
							})
						}),
						shouldUseCursor && /* @__PURE__ */ jsx(TextArea, {
							textAreaRef,
							setTextOverlayShouldBeVisible,
							setTextSelection,
							setAdditionalTextAreaInstructions,
							cursorClickStartRef,
							parentRef,
							tabSize,
							plainTextLinesAsString,
							numLines: lines.length,
							setIsTextAreaFocused
						}),
						hasBlame ? !isSSR ? /* @__PURE__ */ jsx(BlameLines, {
							ref: blobLinesHandle,
							linesData: lines,
							colorizedLines: colorizedLines ? colorizedLines : void 0,
							tabSize,
							copilotAccessAllowed,
							onLineNumberClick
						}) : /* @__PURE__ */ jsx(BlameLinesSSR, {
							linesData: lines,
							colorizedLines: colorizedLines ? colorizedLines : void 0,
							tabSize,
							copilotAccessAllowed,
							onLineNumberClick
						}) : !isSSR ? doOverlay ? /* @__PURE__ */ jsx(CodeLinesNoVirtualization, {
							ref: blobLinesHandle,
							linesData: lines,
							nonTruncatedLinesData,
							onLineNumberClick,
							colorizedLines,
							codeSections,
							codeLineToSectionMap,
							onLineStickOrUnstick,
							sharedLineObserver,
							tabSize,
							textAreaRef,
							cursorContainerRef,
							contentWidth: contentWidth ?? textAreaRef.current?.clientWidth,
							onCollapseToggle: reRender,
							materializeAllLines: shouldMaterializeAllLines,
							copilotAccessAllowed
						}) : /* @__PURE__ */ jsx(CodeLines, {
							ref: blobLinesHandle,
							linesData: lines,
							onLineNumberClick,
							codeSections,
							codeLineToSectionMap,
							onLineStickOrUnstick,
							sharedLineObserver,
							tabSize,
							contentWidth,
							cursorContainerRef,
							onCollapseToggle: reRender,
							textAreaRef,
							materializeAllLines: shouldMaterializeAllLines,
							copilotAccessAllowed
						}) : doOverlay ? /* @__PURE__ */ jsx(CodeLinesSSRNoVirtualization, {
							linesData: lines,
							nonTruncatedLinesData,
							onLineNumberClick,
							colorizedLines,
							codeSections,
							codeLineToSectionMap,
							onLineStickOrUnstick,
							tabSize,
							contentWidth,
							copilotAccessAllowed,
							onCollapseToggle: reRender
						}) : /* @__PURE__ */ jsx(CodeLinesSSR, {
							linesData: lines,
							onLineNumberClick,
							codeSections,
							codeLineToSectionMap,
							onLineStickOrUnstick,
							tabSize,
							contentWidth,
							copilotAccessAllowed,
							onCollapseToggle: reRender
						})
					]
				}) }) })
			})]
		})
	});
}
CodeBlob.displayName = "CodeBlob";
function ImageBlob({ displayName, displayUrl }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-justify-center width-full",
		children: /* @__PURE__ */ jsx("img", {
			alt: displayName,
			src: displayUrl,
			"data-hpc": true,
			style: { maxWidth: "100%" }
		})
	});
}
ImageBlob.displayName = "ImageBlob";
var YamlTemplateContent_module_default = {
	CheckboxGroup: "YamlTemplateContent-module_Bk5UJW_CheckboxGroup",
	CheckboxGroup_Caption: "YamlTemplateContent-module_Bk5UJW_CheckboxGroup_Caption",
	CheckboxGroup_Label: "YamlTemplateContent-module_Bk5UJW_CheckboxGroup_Label",
	FormControl_Label: "YamlTemplateContent-module_Bk5UJW_FormControl_Label",
	metadataTable: "YamlTemplateContent-module_Bk5UJW_metadataTable",
	tableCell: "YamlTemplateContent-module_Bk5UJW_tableCell",
	templateWrapper: "YamlTemplateContent-module_Bk5UJW_templateWrapper"
};
var YamlTemplateType = {
	Issue: "issue",
	Discussion: "discussion"
};
function YamlTemplateContent({ issueTemplate, type }) {
	return /* @__PURE__ */ jsxs("div", {
		className: YamlTemplateContent_module_default.templateWrapper,
		children: [/* @__PURE__ */ jsxs("table", {
			className: YamlTemplateContent_module_default.metadataTable,
			children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				type === YamlTemplateType.Issue ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Name"
				}), /* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "About"
				})] }) : /* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Title"
				}),
				issueTemplate.type && /* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Type"
				}),
				/* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Labels"
				}),
				issueTemplate.projects && /* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Projects"
				}),
				type === YamlTemplateType.Issue && /* @__PURE__ */ jsx(MarkdownTableCell, {
					header: true,
					children: "Assignees"
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: /* @__PURE__ */ jsxs("tr", { children: [
				type === YamlTemplateType.Issue ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.name }), /* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.about })] }) : /* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.title }),
				issueTemplate.type && /* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.type }),
				/* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.labels }),
				issueTemplate.projects && /* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.projects }),
				type === YamlTemplateType.Issue && /* @__PURE__ */ jsx(MarkdownTableCell, { children: issueTemplate.assignees })
			] }) })]
		}), issueTemplate.inputs.map((input, index) => /* @__PURE__ */ jsx(TemplateInput, { input }, index))]
	});
}
YamlTemplateContent.displayName = "YamlTemplateContent";
function MarkdownTableCell({ children, header }) {
	return /* @__PURE__ */ jsx(header ? "th" : "td", {
		className: YamlTemplateContent_module_default.tableCell,
		children
	});
}
MarkdownTableCell.displayName = "MarkdownTableCell";
function TemplateInput(t0) {
	const $ = c(13);
	const { input } = t0;
	const uploadFieldEnabled = useFeatureFlag("issue_form_upload_field");
	switch (input.type) {
		case "markdown": {
			let t1;
			if ($[0] !== input) {
				t1 = jsx(MarkdownInput, { input });
				$[0] = input;
				$[1] = t1;
			} else t1 = $[1];
			return t1;
		}
		case "dropdown": {
			let t1;
			if ($[2] !== input) {
				t1 = jsx(DropdownInput, { input });
				$[2] = input;
				$[3] = t1;
			} else t1 = $[3];
			return t1;
		}
		case "input": {
			let t1;
			if ($[4] !== input) {
				t1 = jsx(InputInput, { input });
				$[4] = input;
				$[5] = t1;
			} else t1 = $[5];
			return t1;
		}
		case "textarea": {
			let t1;
			if ($[6] !== input) {
				t1 = jsx(TextareaInput, { input });
				$[6] = input;
				$[7] = t1;
			} else t1 = $[7];
			return t1;
		}
		case "checkboxes": {
			let t1;
			if ($[8] !== input) {
				t1 = jsx(CheckboxesInput, { input });
				$[8] = input;
				$[9] = t1;
			} else t1 = $[9];
			return t1;
		}
		case "upload": {
			let t1;
			if ($[10] !== input || $[11] !== uploadFieldEnabled) {
				t1 = uploadFieldEnabled ? jsx(UploadInput, { input }) : null;
				$[10] = input;
				$[11] = uploadFieldEnabled;
				$[12] = t1;
			} else t1 = $[12];
			return t1;
		}
		default: return null;
	}
}
TemplateInput.displayName = "TemplateInput";
function MarkdownInput({ input }) {
	if (!input.value) return null;
	return /* @__PURE__ */ jsx(VerifiedHTMLBox, { html: input.value });
}
MarkdownInput.displayName = "MarkdownInput";
function DropdownInput({ input }) {
	const options = input.options?.slice();
	if (!input.required) options?.unshift("None");
	let buttonText = input.multiple ? "Selections: " : "Selection: ";
	if (input.value) buttonText += input.value;
	return /* @__PURE__ */ jsx(InputWrapper, {
		input,
		style: { alignItems: "start" },
		children: /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Button, { children: buttonText }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
			width: "medium",
			children: /* @__PURE__ */ jsx(ActionList, {
				selectionVariant: input.multiple ? "multiple" : "single",
				children: options?.map((option, index) => /* @__PURE__ */ jsx(ActionList.Item, {
					selected: option === input.value,
					disabled: true,
					children: option
				}, index))
			})
		})] })
	});
}
DropdownInput.displayName = "DropdownInput";
function InputInput({ input }) {
	return /* @__PURE__ */ jsx(InputWrapper, {
		input,
		children: /* @__PURE__ */ jsx(TextInput$1, {
			placeholder: input.placeholder,
			value: input.value ?? ""
		})
	});
}
/**
* Since the blob viewer version is read only, we don't need the functionality to preserve content
* when switching to preview and on navigation.
*/
InputInput.displayName = "InputInput";
function TextareaInput({ input }) {
	return /* @__PURE__ */ jsx(InputWrapper, {
		input,
		children: /* @__PURE__ */ jsx(Textarea, {
			placeholder: input.placeholder,
			value: input.value ?? "",
			style: input.render ? { fontFamily: "mono" } : {}
		})
	});
}
TextareaInput.displayName = "TextareaInput";
function CheckboxesInput({ input }) {
	if (!input.checkboxes) return null;
	return /* @__PURE__ */ jsxs(CheckboxGroup_default, {
		disabled: true,
		className: YamlTemplateContent_module_default.CheckboxGroup,
		children: [
			/* @__PURE__ */ jsx(CheckboxGroup_default.Label, {
				className: YamlTemplateContent_module_default.CheckboxGroup_Label,
				children: input.label
			}),
			input.description && /* @__PURE__ */ jsx(CheckboxGroup_default.Caption, {
				className: YamlTemplateContent_module_default.CheckboxGroup_Caption,
				children: /* @__PURE__ */ jsx(VerifiedHTMLBox, { html: input.description })
			}),
			input.checkboxes.map((checkbox, index) => /* @__PURE__ */ jsxs(FormControl$1, {
				disabled: true,
				required: checkbox.required,
				children: [/* @__PURE__ */ jsx(Checkbox, {}), /* @__PURE__ */ jsx(FormControl$1.Label, { children: checkbox.label })]
			}, index))
		]
	});
}
CheckboxesInput.displayName = "CheckboxesInput";
function UploadInput({ input }) {
	return /* @__PURE__ */ jsx(InputWrapper, {
		input,
		children: /* @__PURE__ */ jsx(ButtonComponent, {
			disabled: true,
			leadingVisual: UploadIcon,
			children: "Upload files"
		})
	});
}
UploadInput.displayName = "UploadInput";
function InputWrapper({ children, input, style }) {
	return /* @__PURE__ */ jsxs(FormControl$1, {
		disabled: true,
		required: input.required,
		style: {
			marginLeft: "15px",
			marginRight: "15px",
			...style
		},
		children: [
			/* @__PURE__ */ jsx(FormControl$1.Label, {
				className: YamlTemplateContent_module_default.FormControl_Label,
				children: input.label
			}),
			input.description && /* @__PURE__ */ jsx(FormControl$1.Caption, { children: /* @__PURE__ */ jsx(VerifiedHTMLBox, { html: input.description }) }),
			children
		]
	});
}
InputWrapper.displayName = "InputWrapper";
var CSVBlob = lazy(() => import("./server-CSVBlob-D73uulHX-B8rAY-TC.js"));
CSVBlob.displayName = "CSVBlob";
var FileRendererBlob = lazy(() => import("./server-FileRendererBlob-DCjfCOez-BeX8rWbQ.js"));
FileRendererBlob.displayName = "FileRendererBlob";
function BlobContent(t0) {
	const $ = c(23);
	const { setOpenPanel, codeNavInfo, validCodeNav, onCodeNavTokenSelected, onLineStickOrUnstick, searchResults, blobLinesHandle, focusedSearchResult } = t0;
	const hasBlame = !!useCurrentBlame();
	const { rawLines } = useCurrentStyledBlob();
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const { findInFileShortcut } = useShortcut();
	const setSearchTerm = useSetSearchTerm();
	const blobRendererType = useBlobRendererType();
	const { setFindInFileOpen } = useFindInFileOpen();
	const isRenderingCode = blobRendererType === BlobDisplayType.Code;
	const findInFileHotkey = isRenderingCode && rawLines != null && validCodeNav ? findInFileShortcut.hotkey : "";
	const cursorEnabled = useIsCursorEnabled();
	let t1;
	let t2;
	if ($[0] !== isRenderingCode || $[1] !== setOpenPanel) {
		t1 = () => {
			if (!isRenderingCode) setOpenPanel(void 0);
		};
		t2 = [isRenderingCode, setOpenPanel];
		$[0] = isRenderingCode;
		$[1] = setOpenPanel;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] !== sendRepoKeyDownEvent || $[5] !== setFindInFileOpen || $[6] !== setSearchTerm) {
		t3 = function onHotkeyPressed() {
			setFindInFileOpen(true);
			sendRepoKeyDownEvent("BLOB_FIND_IN_FILE_MENU.OPEN");
			const selection = window.getSelection()?.toString();
			if (selection) setSearchTerm(selection);
		};
		$[4] = sendRepoKeyDownEvent;
		$[5] = setFindInFileOpen;
		$[6] = setSearchTerm;
		$[7] = t3;
	} else t3 = $[7];
	const onHotkeyPressed = t3;
	const hasOverflow = !isRenderingCode && blobRendererType !== BlobDisplayType.CSV && blobRendererType !== BlobDisplayType.Markdown;
	const isMarkdown = blobRendererType === BlobDisplayType.Markdown;
	let t4;
	if ($[8] !== blobLinesHandle || $[9] !== codeNavInfo || $[10] !== cursorEnabled || $[11] !== findInFileHotkey || $[12] !== focusedSearchResult || $[13] !== hasBlame || $[14] !== hasOverflow || $[15] !== isMarkdown || $[16] !== isRenderingCode || $[17] !== onCodeNavTokenSelected || $[18] !== onHotkeyPressed || $[19] !== onLineStickOrUnstick || $[20] !== searchResults || $[21] !== validCodeNav) {
		t4 = jsxs("section", {
			"aria-labelledby": "file-name-id-wide file-name-id-mobile",
			className: clsx(BlobContent_module_default.blobContentSection, isMarkdown && BlobContent_module_default.blobContentSectionMarkdown, hasOverflow && BlobContent_module_default.blobContentSectionOverflow),
			style: { marginTop: hasBlame ? "92px" : "46px" },
			children: [jsx(Blob, {
				blobLinesHandle,
				onCodeNavTokenSelected,
				codeSections: hasBlame ? void 0 : codeNavInfo?.codeSections,
				codeLineToSectionMap: codeNavInfo ? codeNavInfo.lineToSectionMap : void 0,
				validCodeNav,
				onLineStickOrUnstick,
				searchResults,
				focusedSearchResult
			}), isRenderingCode && !cursorEnabled && jsx(DuplicateOnKeydownButton, {
				buttonFocusId: "read-only-cursor-text-area",
				buttonHotkey: findInFileHotkey,
				onButtonClick: onHotkeyPressed,
				buttonTestLabel: "hotkey-button"
			})]
		});
		$[8] = blobLinesHandle;
		$[9] = codeNavInfo;
		$[10] = cursorEnabled;
		$[11] = findInFileHotkey;
		$[12] = focusedSearchResult;
		$[13] = hasBlame;
		$[14] = hasOverflow;
		$[15] = isMarkdown;
		$[16] = isRenderingCode;
		$[17] = onCodeNavTokenSelected;
		$[18] = onHotkeyPressed;
		$[19] = onLineStickOrUnstick;
		$[20] = searchResults;
		$[21] = validCodeNav;
		$[22] = t4;
	} else t4 = $[22];
	return t4;
}
BlobContent.displayName = "BlobContent";
var Blob = React.memo(function Blob(t0) {
	const $ = c(27);
	const { onCodeNavTokenSelected, codeSections, codeLineToSectionMap, validCodeNav, onLineStickOrUnstick, searchResults, blobLinesHandle, focusedSearchResult } = t0;
	const payload = useCurrentBlob();
	const displayType = useBlobRendererType();
	switch (displayType) {
		case BlobDisplayType.TooLargeError: {
			let t1;
			if ($[0] !== payload.large || $[1] !== payload.rawBlobUrl) {
				t1 = jsxs("div", {
					className: BlobContent_module_default.tooLargeError,
					"data-hpc": true,
					children: [jsx(Link, {
						href: payload.rawBlobUrl,
						children: "View raw"
					}), payload.large && jsx("p", { children: "(Sorry about that, but we can’t show files that are this big right now.)" })]
				});
				$[0] = payload.large;
				$[1] = payload.rawBlobUrl;
				$[2] = t1;
			} else t1 = $[2];
			return t1;
		}
		case BlobDisplayType.Code: {
			let t1;
			if ($[3] !== blobLinesHandle || $[4] !== codeLineToSectionMap || $[5] !== codeSections || $[6] !== focusedSearchResult || $[7] !== onCodeNavTokenSelected || $[8] !== onLineStickOrUnstick || $[9] !== searchResults || $[10] !== validCodeNav) {
				t1 = jsx(CodeBlob, {
					blobLinesHandle,
					onCodeNavTokenSelected,
					codeSections,
					codeLineToSectionMap,
					validCodeNav,
					onLineStickOrUnstick,
					searchResults,
					focusedSearchResult
				});
				$[3] = blobLinesHandle;
				$[4] = codeLineToSectionMap;
				$[5] = codeSections;
				$[6] = focusedSearchResult;
				$[7] = onCodeNavTokenSelected;
				$[8] = onLineStickOrUnstick;
				$[9] = searchResults;
				$[10] = validCodeNav;
				$[11] = t1;
			} else t1 = $[11];
			return t1;
		}
		case BlobDisplayType.Markdown: {
			let t1;
			if ($[12] !== payload.richText) {
				t1 = jsx(MarkdownContent, {
					richText: payload.richText,
					className: BlobContent_module_default.markdownBlob
				});
				$[12] = payload.richText;
				$[13] = t1;
			} else t1 = $[13];
			return t1;
		}
		case BlobDisplayType.CSV: {
			let t1;
			if ($[14] !== payload.csv) {
				t1 = jsx(Suspense, {
					fallback: jsx(LoadingFallback, {}),
					children: jsx(CSVBlob, { csv: payload.csv })
				});
				$[14] = payload.csv;
				$[15] = t1;
			} else t1 = $[15];
			return t1;
		}
		case BlobDisplayType.FileRenderer: {
			let t1;
			if ($[16] !== payload.displayUrl || $[17] !== payload.renderedFileInfo.identityUUID || $[18] !== payload.renderedFileInfo.renderFileType || $[19] !== payload.renderedFileInfo.size) {
				t1 = jsx(Suspense, {
					fallback: jsx(LoadingFallback, {}),
					children: jsx(FileRendererBlob, {
						identityUuid: payload.renderedFileInfo.identityUUID,
						size: payload.renderedFileInfo.size,
						type: payload.renderedFileInfo.renderFileType,
						url: payload.displayUrl
					}, payload.renderedFileInfo.identityUUID)
				});
				$[16] = payload.displayUrl;
				$[17] = payload.renderedFileInfo.identityUUID;
				$[18] = payload.renderedFileInfo.renderFileType;
				$[19] = payload.renderedFileInfo.size;
				$[20] = t1;
			} else t1 = $[20];
			return t1;
		}
		case BlobDisplayType.Image: {
			let t1;
			if ($[21] !== payload.displayName || $[22] !== payload.displayUrl) {
				t1 = jsx(ImageBlob, {
					displayName: payload.displayName,
					displayUrl: payload.displayUrl
				});
				$[21] = payload.displayName;
				$[22] = payload.displayUrl;
				$[23] = t1;
			} else t1 = $[23];
			return t1;
		}
		case BlobDisplayType.IssueTemplate: {
			const t1 = payload.issueTemplate ? payload.issueTemplate : payload.discussionTemplate;
			const t2 = payload.issueTemplate ? YamlTemplateType.Issue : YamlTemplateType.Discussion;
			let t3;
			if ($[24] !== t1 || $[25] !== t2) {
				t3 = jsx(YamlTemplateContent, {
					issueTemplate: t1,
					type: t2,
					"data-hpc": true
				});
				$[24] = t1;
				$[25] = t2;
				$[26] = t3;
			} else t3 = $[26];
			return t3;
		}
		default: assertNever(displayType);
	}
});
Blob.displayName = "Blob";
var BlobContent_default = BlobContent;
var BlobViewContent_module_default = {
	blobContainer: "BlobViewContent-module_NUrSfq_blobContainer",
	blobContainerWithPanel: "BlobViewContent-module_NUrSfq_blobContainerWithPanel",
	blobContentWrapper: "BlobViewContent-module_NUrSfq_blobContentWrapper",
	codeSizeDetails: "BlobViewContent-module_NUrSfq_codeSizeDetails",
	stickyHeader: "BlobViewContent-module_NUrSfq_stickyHeader",
	symbolsPanelSpacer: "BlobViewContent-module_NUrSfq_symbolsPanelSpacer"
};
var SpacesSelectionMenu_module_default = { starButton: "SpacesSelectionMenu-module_KXgJOq_starButton" };
var useUpsertCopilotSpace = (id) => {
	const queryClient = useQueryClient();
	const { mutateAsync: upsertCopilotSpace, ...rest } = useMutation({
		onSuccess: async () => {
			queryClient.invalidateQueries({ queryKey: COPILOT_SPACES_QUERY_KEY });
			if (id) await queryClient.invalidateQueries({ queryKey: copilotSpacesQueryKey(id) });
			await Promise.all([
				"starred",
				"user_owned",
				"org_owned",
				"shared_with_user"
			].map((category) => queryClient.invalidateQueries({ queryKey: copilotSpacesCategoryQueryKey(category) })));
			await queryClient.invalidateQueries({ queryKey: COPILOT_SPACES_COUNT_QUERY_KEY });
		},
		mutationFn: async (input) => {
			const response = await verifiedFetchJSON(id ? customCopilotApiPath(id) : "/custom_copilots", {
				method: id ? "PUT" : "POST",
				body: { custom_copilot: {
					name: input.name,
					owner_id: input.owner_id,
					owner_type: input.owner_type,
					resources_attributes: input.resources?.map((r) => ({
						id: r.databaseId,
						copilot_chat_attachment_id: r.copilotChatAttachmentId,
						resource_type: r.type,
						_destroy: r.markedForDestroy,
						metadata: resourceMetadataToRailsPayload(r)
					}))
				} }
			});
			const data = await response.json();
			if (!response.ok) throw data.errorMessages;
			return data;
		}
	});
	return {
		upsertCopilotSpace,
		...rest
	};
};
function SpacesSelectionCreateSpaceDialog({ closeDialog, currentFile, returnFocusRef }) {
	const nameInputRef = useRef(null);
	const [name, setName] = useState("");
	const [errorMessages, setErrorMessages] = useState({});
	const { upsertCopilotSpace, isPending: isSaving } = useUpsertCopilotSpace();
	const [owner, setOwner] = useState(null);
	const MAX_NAME_LENGTH = 255;
	const dropdownOnSelect = useCallback((newOwner) => setOwner(newOwner), []);
	const clearErrors = useCallback((fields) => {
		const updatedErrorMessages = { ...errorMessages };
		for (const field of fields) if (updatedErrorMessages[field]) delete updatedErrorMessages[field];
		setErrorMessages(updatedErrorMessages);
	}, [errorMessages]);
	const saveSpace = async () => {
		if (isSaving) return;
		try {
			const resources = [];
			if (currentFile) resources.push({
				id: "",
				repositoryId: currentFile.repoID,
				nwo: `${currentFile.repoOwner}/${currentFile.repoName}`,
				filePath: currentFile.path,
				sha: currentFile.commitOID,
				fileExists: true,
				type: "github_file",
				markedForDestroy: false
			});
			await upsertCopilotSpace({
				name,
				owner_id: owner?.id,
				owner_type: owner?.type,
				resources
			});
			setErrorMessages({});
			closeDialog();
			sendEvent("copilot_spaces.code_view", { target: "COPILOT_SPACES_CODE_VIEW_MENU_SPACE_CREATED" });
		} catch (errors) {
			setErrorMessages(errors ?? {});
		}
	};
	const handleCancel = () => {
		closeDialog();
	};
	return /* @__PURE__ */ jsx(Dialog, {
		position: { narrow: "fullscreen" },
		title: "Create a new Space",
		onClose: closeDialog,
		width: "large",
		"aria-label": "Create a new Space",
		returnFocusRef,
		renderFooter: () => /* @__PURE__ */ jsx(SpaceDialogFooter, {
			onCancel: handleCancel,
			onSave: saveSpace,
			isLoading: isSaving,
			saveButtonText: "Create"
		}),
		children: /* @__PURE__ */ jsx("form", {
			onSubmit: async (e) => {
				e.preventDefault();
				e.stopPropagation();
				await saveSpace();
			},
			children: /* @__PURE__ */ jsxs(Stack, { children: [/* @__PURE__ */ jsxs(FormControl$1, { children: [
				/* @__PURE__ */ jsx(FormControl$1.Label, {
					required: true,
					children: "Name"
				}),
				/* @__PURE__ */ jsx(TextInput$1, {
					ref: nameInputRef,
					autoFocus: true,
					block: true,
					"data-testid": "copilot-space-name-input",
					name: "copilot-space-name",
					maxLength: MAX_NAME_LENGTH,
					value: name,
					onChange: (e) => {
						setName(e.target.value);
						clearErrors(["name", "slug"]);
					}
				}),
				/* @__PURE__ */ jsxs(FormControl$1.Caption, { children: [
					name.length,
					"/",
					MAX_NAME_LENGTH
				] }),
				errorMessages.name ? /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: /* @__PURE__ */ jsxs("span", { children: ["Name ", errorMessages.name] })
				}) : errorMessages.slug ? /* @__PURE__ */ jsx(FormControl$1.Validation, {
					variant: "error",
					children: /* @__PURE__ */ jsx("span", { children: SLUG_ERROR_MESSAGE })
				}) : null
			] }), /* @__PURE__ */ jsx(SpacesOwnerDropdown, {
				onSelect: dropdownOnSelect,
				repoId: currentFile?.repoID
			})] })
		})
	});
}
SpacesSelectionCreateSpaceDialog.displayName = "SpacesSelectionCreateSpaceDialog";
function SpacesSelectionMenu({ repository, currentFile, onBannerChange }) {
	const [open, setOpen] = useState(false);
	const isUpsertingRef = useRef(false);
	const triggerButtonRef = useRef(null);
	const [filter, setFilter] = useState("");
	const [debouncedFilter, setDebouncedFilter] = useState("");
	const [loading, setLoading] = useState(false);
	const [filteredItems, setFilteredItems] = useState([]);
	const [initialSpaces, setInitialSpaces] = useState([]);
	const [initialSpacesLoaded, setInitialSpacesLoaded] = useState(false);
	const [showCreateSpaceDialog, setShowCreateSpaceDialog] = useState(false);
	const [selectedSpace, setSelectedSpace] = useState(void 0);
	const [hasError, setHasError] = useState(false);
	const { upsertCopilotSpace } = useUpsertCopilotSpace(selectedSpace);
	const isSupportedFile = useMemo(() => {
		const fileName = currentFile.path.split("/").pop() || "";
		const lastDotIndex = fileName.lastIndexOf(".");
		const fileExtension = lastDotIndex > 0 ? fileName.slice(lastDotIndex + 1) : "";
		if (fileExtension === "") return true;
		return Object.values(languageMap).some((lang) => lang.extensions?.includes(`.${fileExtension}`));
	}, [currentFile.path]);
	useEffect(() => {
		if (!isUpsertingRef.current || !selectedSpace) return;
		const fileResource = {
			id: "",
			repositoryId: currentFile.repoID,
			nwo: `${currentFile.repoOwner}/${currentFile.repoName}`,
			filePath: currentFile.path,
			sha: currentFile.commitOID,
			fileExists: true,
			type: "github_file",
			markedForDestroy: false
		};
		const performUpsert = async () => {
			try {
				await upsertCopilotSpace({ resources: [fileResource] });
				setHasError(false);
				setOpen(false);
				if (onBannerChange && selectedSpace) onBannerChange({
					variant: "success",
					onDismiss: () => onBannerChange(null),
					title: "none",
					description: /* @__PURE__ */ jsxs(Fragment$1, { children: [
						"File added to",
						" ",
						/* @__PURE__ */ jsx(Link, {
							href: getCopilotSpacePath({
								id: selectedSpace.id,
								owner: selectedSpace.owner
							}),
							inline: true,
							children: selectedSpace.name
						}),
						" ",
						"successfully"
					] }),
					hideTitle: true,
					style: { marginBottom: "16px" }
				});
				setFilter("");
				setDebouncedFilter("");
				setTimeout(() => announce$1(`File added to ${selectedSpace.name} successfully.`), 250);
			} catch {
				setHasError(true);
				if (onBannerChange) {
					onBannerChange({
						variant: "critical",
						onDismiss: () => onBannerChange(null),
						title: "none",
						description: "There was an error adding the file to the space.",
						hideTitle: true,
						style: { marginBottom: "16px" }
					});
					setTimeout(() => announce$1(`There was an error adding the file to the space`), 250);
				}
			} finally {
				isUpsertingRef.current = false;
			}
		};
		performUpsert();
	}, [
		selectedSpace,
		upsertCopilotSpace,
		currentFile,
		onBannerChange
	]);
	const fetchResults = useCallback(async () => {
		try {
			const res = await verifiedFetchJSON(`/github-copilot/chat/custom_copilots/search?${new URLSearchParams({
				q: debouncedFilter,
				owner: repository.private ? repository.ownerLogin : "",
				editable_only: "true"
			}).toString()}`);
			if (!res.ok) throw new Error("Failed to fetch spaces");
			return await res.json();
		} catch {
			return [];
		}
	}, [
		debouncedFilter,
		repository.private,
		repository.ownerLogin
	]);
	const handleSetFilteredItems = useCallback(() => {
		const lastSelectedSpace = copilotLocalStorage.getLastSelectedSpace();
		let newSpacesList = initialSpaces;
		if (lastSelectedSpace) {
			if (lastSelectedSpace.ownerIsOrg && lastSelectedSpace.owner !== repository.ownerLogin && repository.private) {
				copilotLocalStorage.setLastSelectedSpace(void 0);
				setFilteredItems(initialSpaces);
				return;
			}
			newSpacesList = newSpacesList.filter((s) => !(s.id === lastSelectedSpace.id && s.owner === lastSelectedSpace.owner));
			if (newSpacesList.length === initialSpaces.length) newSpacesList.pop();
			newSpacesList = [lastSelectedSpace, ...newSpacesList];
		}
		setFilteredItems(newSpacesList);
	}, [
		initialSpaces,
		repository.ownerLogin,
		repository.private
	]);
	useEffect(() => {
		let cancelled = false;
		const fetchAndSetSpaces = async () => {
			if (open === false) return;
			setLoading(true);
			if (debouncedFilter === "" && initialSpacesLoaded) {
				if (!cancelled) {
					handleSetFilteredItems();
					setLoading(false);
				}
				return;
			}
			const spaces = await fetchResults();
			if (!cancelled) {
				setFilteredItems(spaces);
				if (!initialSpacesLoaded) {
					setInitialSpaces(spaces);
					setInitialSpacesLoaded(true);
				}
				setLoading(false);
			}
		};
		fetchAndSetSpaces();
		return () => {
			cancelled = true;
		};
	}, [
		fetchResults,
		debouncedFilter,
		initialSpacesLoaded,
		open,
		handleSetFilteredItems
	]);
	useEffect(() => {
		return () => {
			if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
		};
	}, []);
	const items = filteredItems.map((space) => ({
		id: `${space.owner}-${space.id}`,
		key: `${space.owner}-${space.id}`,
		text: space.name,
		description: space.owner,
		descriptionVariant: "inline",
		value: `${space.owner}-${space.id}`,
		trailingVisual: space.starred ? () => /* @__PURE__ */ jsx(StarFillIcon, { className: SpacesSelectionMenu_module_default.starButton }) : void 0
	}));
	const onSelectedChange = (selectedItem) => {
		setHasError(false);
		const newSelectedSpace = filteredItems.find((space) => `${space.owner}-${space.id}` === selectedItem?.id);
		setSelectedSpace(newSelectedSpace);
		copilotLocalStorage.setLastSelectedSpace(newSelectedSpace);
		isUpsertingRef.current = true;
		sendEvent("copilot_spaces.code_view", { target: "COPILOT_SPACES_CODE_VIEW_MENU_SPACE_SELECTED" });
	};
	const handleCreateSpace = () => {
		setShowCreateSpaceDialog(true);
		sendEvent("copilot_spaces.code_view", { target: "COPILOT_SPACES_CODE_VIEW_MENU_CREATE_SPACE_CLICKED" });
		setOpen(false);
	};
	const handleMenuOpen = (value) => {
		if (!value && (hasError || isUpsertingRef.current)) return;
		setOpen(value);
		if (value) {
			sendEvent("copilot_spaces.code_view", { target: "COPILOT_SPACES_CODE_VIEW_MENU_OPENED" });
			setHasError(false);
		} else {
			setFilter("");
			setDebouncedFilter("");
		}
	};
	const singleSelectProps = {
		selected: void 0,
		onSelectedChange: (selectedItem) => onSelectedChange(selectedItem)
	};
	const debounceTimeoutRef = useRef(null);
	if (!isSupportedFile) return null;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(SelectPanel, {
		title: "Select a space",
		onCancel: () => setOpen(false),
		anchorRef: triggerButtonRef,
		renderAnchor: (anchorProps) => /* @__PURE__ */ jsx(IconButton, {
			icon: SpaceIcon,
			size: "small",
			"aria-label": "Add to space",
			tooltipDirection: "n",
			...anchorProps
		}),
		open,
		onOpenChange: handleMenuOpen,
		loading,
		items,
		filterValue: filter,
		onFilterChange: (value) => {
			setFilter(value);
			if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
			debounceTimeoutRef.current = setTimeout(() => {
				setDebouncedFilter(value);
			}, 350);
		},
		...singleSelectProps,
		overlayProps: {
			height: "auto",
			width: "large"
		},
		message: filteredItems.length === 0 && !loading ? {
			title: "No spaces found",
			body: "You can create a new space to get started.",
			variant: "empty",
			action: /* @__PURE__ */ jsx(ButtonComponent, {
				variant: "default",
				size: "small",
				leadingVisual: PlusIcon,
				onClick: handleCreateSpace,
				children: "Create a new space"
			})
		} : void 0,
		secondaryAction: filteredItems.length > 0 ? /* @__PURE__ */ jsx(SelectPanel.SecondaryActionButton, {
			onClick: handleCreateSpace,
			children: "Create a space"
		}) : void 0
	}), showCreateSpaceDialog && /* @__PURE__ */ jsx(SpacesSelectionCreateSpaceDialog, {
		closeDialog: () => setShowCreateSpaceDialog(false),
		currentFile,
		returnFocusRef: triggerButtonRef
	})] });
}
SpacesSelectionMenu.displayName = "SpacesSelectionMenu";
/**
* An icon button that can handle disabled accessibility
* This component does not support polymorphic forwarding refs (aka "as" prop) at this time
*/
function AccessibleIconButton({ disabled, ...props }) {
	const ariaDisabledProps = disabled ? {
		"aria-disabled": true,
		onClick: (e) => e.preventDefault()
	} : {};
	return /* @__PURE__ */ jsx(IconButton, {
		size: "small",
		...props,
		...ariaDisabledProps
	});
}
AccessibleIconButton.displayName = "AccessibleIconButton";
var FindInFilePopover_module_default = {
	closeButton: "FindInFilePopover-module_WhLppq_closeButton",
	findHeading: "FindInFilePopover-module_WhLppq_findHeading",
	headerLeft: "FindInFilePopover-module_WhLppq_headerLeft",
	headerRow: "FindInFilePopover-module_WhLppq_headerRow",
	helpText: "FindInFilePopover-module_WhLppq_helpText",
	helpTextHidden: "FindInFilePopover-module_WhLppq_helpTextHidden",
	inputWrapper: "FindInFilePopover-module_WhLppq_inputWrapper",
	navButton: "FindInFilePopover-module_WhLppq_navButton",
	resultCount: "FindInFilePopover-module_WhLppq_resultCount",
	spacer: "FindInFilePopover-module_WhLppq_spacer",
	textInput: "FindInFilePopover-module_WhLppq_textInput",
	trailingActions: "FindInFilePopover-module_WhLppq_trailingActions"
};
var ScrollMarks$1 = lazy(() => import("./server-ScrollMarks-DOQsLv1d-BpTJ15qq.js"));
ScrollMarks$1.displayName = "ScrollMarks";
function FindInFilePopover({ stickied, searchResults, focusedSearchResult, setFocusedSearchResult, onClose }) {
	const searchTerm = useSearchTerm();
	const setSearchTerm = useSetSearchTerm();
	const cursorEnabled = useIsCursorEnabled();
	const inputContainer = useRef(null);
	const { findInFileShortcut, findSelectionShortcut, findNextShortcut, findPrevShortcut } = useShortcut();
	const [escapeToBrowserOnNextKeyPress, setEscapeToBrowserOnNextKeyPress] = useState(true);
	const clearSearch = () => {
		setSearchTerm("");
		setFocusedSearchResult(0);
	};
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const onChange = (event) => {
		if (event.target.value) {
			setEscapeToBrowserOnNextKeyPress(false);
			setSearchTerm(event.target.value);
			if (focusedSearchResult === void 0) setFocusedSearchResult(0);
		} else {
			setEscapeToBrowserOnNextKeyPress(true);
			clearSearch();
		}
	};
	const jumpToResult = (direction) => {
		if (focusedSearchResult === void 0) {
			setFocusedSearchResult(0);
			return;
		}
		if (direction === 1) setFocusedSearchResult(focusedSearchResult === searchResults.length - 1 ? 0 : focusedSearchResult + 1);
		else setFocusedSearchResult(focusedSearchResult === 0 ? searchResults.length - 1 : focusedSearchResult - 1);
	};
	useEffect(() => {
		inputContainer.current?.focus();
		inputContainer.current?.select();
	}, []);
	const onHotkey = () => {
		const selected = window.getSelection()?.toString();
		if (selected?.length) {
			setSearchTerm(selected);
			setFocusedSearchResult(0);
			sendRepoKeyDownEvent("BLOB_FIND_IN_FILE_MENU.FIND_IN_FILE_FROM_SELECTION");
		}
		inputContainer.current?.focus();
		inputContainer.current?.select();
	};
	useEffect(() => {
		if (searchResults.length > 0 && focusedSearchResult !== void 0) scrollLineIntoView({
			line: searchResults[focusedSearchResult].lineNumber,
			column: searchResults[focusedSearchResult].ident.start.column
		});
	}, [searchResults, focusedSearchResult]);
	if (cursorEnabled) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: `find-in-file-popover ${stickied ? "find-in-file-popover-stickied" : "find-in-file-popover-not-stickied"}`,
		children: [/* @__PURE__ */ jsxs("div", {
			className: FindInFilePopover_module_default.headerRow,
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: FindInFilePopover_module_default.headerLeft,
					children: [/* @__PURE__ */ jsx("h5", {
						className: FindInFilePopover_module_default.findHeading,
						children: "Find"
					}), /* @__PURE__ */ jsxs("span", {
						className: clsx("find-text-help-tooltip", FindInFilePopover_module_default.helpText, !escapeToBrowserOnNextKeyPress && FindInFilePopover_module_default.helpTextHidden),
						children: [
							"Press ",
							/* @__PURE__ */ jsx(Label, { children: findInFileShortcut.text }),
							" again to open the browser's find menu"
						]
					})]
				}),
				/* @__PURE__ */ jsx("div", { className: FindInFilePopover_module_default.spacer }),
				/* @__PURE__ */ jsx(IconButton, {
					variant: "invisible",
					size: "small",
					onClick: onClose,
					icon: XIcon,
					className: FindInFilePopover_module_default.closeButton,
					"aria-label": "Close find in file"
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: FindInFilePopover_module_default.inputWrapper,
			children: [
				/* @__PURE__ */ jsx(TextInput$1, {
					ref: inputContainer,
					className: FindInFilePopover_module_default.textInput,
					validationStatus: searchResults.length > 1e3 ? "error" : void 0,
					type: "text",
					leadingVisual: () => /* @__PURE__ */ jsx(Octicon, {
						icon: SearchIcon,
						"aria-hidden": "true"
					}),
					"aria-labelledby": "find-in-file-label",
					"aria-expanded": "true",
					autoComplete: "off",
					name: "Find in file input",
					placeholder: "Search this file",
					value: searchTerm,
					block: true,
					onChange,
					trailingAction: /* @__PURE__ */ jsxs("div", {
						className: FindInFilePopover_module_default.trailingActions,
						children: [
							/* @__PURE__ */ jsxs("span", {
								className: clsx("text-small", FindInFilePopover_module_default.resultCount),
								children: [
									searchResults.length === 0 || focusedSearchResult === void 0 ? 0 : focusedSearchResult + 1,
									"/",
									searchResults.length
								]
							}),
							/* @__PURE__ */ jsx(IconButton, {
								size: "small",
								variant: "invisible",
								onClick: () => {
									jumpToResult(-1);
								},
								icon: ChevronUpIcon,
								"aria-label": "Up",
								"data-testid": "up-search",
								className: FindInFilePopover_module_default.navButton
							}),
							/* @__PURE__ */ jsx(IconButton, {
								size: "small",
								variant: "invisible",
								onClick: () => {
									jumpToResult(1);
								},
								icon: ChevronDownIcon,
								"aria-label": "Down",
								"data-testid": "down-search",
								className: FindInFilePopover_module_default.navButton
							})
						]
					}),
					onKeyDown: (keyboardEvent) => {
						if (keyboardEvent.code === "Enter" || keyboardEvent.code === "NumpadEnter") if (keyboardEvent.shiftKey) jumpToResult(-1);
						else jumpToResult(1);
						else if ((keyboardEvent.metaKey || keyboardEvent.ctrlKey) && (keyboardEvent.key === "g" || keyboardEvent.key === "G")) {
							keyboardEvent.preventDefault();
							if (keyboardEvent.shiftKey) jumpToResult(-1);
							else jumpToResult(1);
						} else if ((keyboardEvent.metaKey || keyboardEvent.ctrlKey) && (keyboardEvent.key === "f" || keyboardEvent.key === "F")) if (escapeToBrowserOnNextKeyPress) {
							sendRepoKeyDownEvent("BLOB_FIND_IN_FILE_MENU.FALLBACK_TO_BROWSER_SEARCH");
							onClose();
						} else {
							setEscapeToBrowserOnNextKeyPress(true);
							keyboardEvent.preventDefault();
							inputContainer.current?.focus();
							inputContainer.current?.select();
						}
						else if (keyboardEvent.key === "Escape") onClose();
					}
				}),
				/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
					buttonFocusId: textAreaId,
					buttonHotkey: findInFileShortcut.hotkey,
					onButtonClick: onHotkey,
					buttonTestLabel: "hotkey-button"
				}),
				/* @__PURE__ */ jsx("button", {
					hidden: true,
					"data-hotkey": findSelectionShortcut.hotkey,
					onClick: onHotkey,
					"data-testid": "selection-hotkey"
				}),
				/* @__PURE__ */ jsx("button", {
					hidden: true,
					"data-hotkey": findNextShortcut.hotkey,
					onClick: () => jumpToResult(1),
					"data-testid": "find-next-button"
				}),
				/* @__PURE__ */ jsx("button", {
					hidden: true,
					"data-hotkey": findPrevShortcut.hotkey,
					onClick: () => jumpToResult(-1),
					"data-testid": "find-prev-button"
				}),
				/* @__PURE__ */ jsx(Suspense, {
					fallback: null,
					children: /* @__PURE__ */ jsx(ScrollMarks$1, { definitionsOrReferences: searchResults })
				})
			]
		})]
	});
}
FindInFilePopover.displayName = "FindInFilePopover";
var ContributorsContext = React.createContext({
	contributors: void 0,
	error: void 0,
	loading: false
});
ContributorsContext.displayName = "ContributorsContext";
function ContributorsProvider(t0) {
	const $ = c(7);
	const { children, contributors, error, loading } = t0;
	let t1;
	if ($[0] !== contributors || $[1] !== error || $[2] !== loading) {
		t1 = {
			contributors,
			error,
			loading
		};
		$[0] = contributors;
		$[1] = error;
		$[2] = loading;
		$[3] = t1;
	} else t1 = $[3];
	const value = t1;
	let t2;
	if ($[4] !== children || $[5] !== value) {
		t2 = jsx(ContributorsContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
ContributorsProvider.displayName = "ContributorsProvider";
function useContributorsContext() {
	return React.use(ContributorsContext);
}
var Contributors_module_default = {
	avatarStackWrapper: "Contributors-module_0SqR_q_avatarStackWrapper",
	contributorAvatar: "Contributors-module_0SqR_q_contributorAvatar",
	contributorDialogList: "Contributors-module_0SqR_q_contributorDialogList",
	contributorLink: "Contributors-module_0SqR_q_contributorLink",
	contributorRow: "Contributors-module_0SqR_q_contributorRow",
	contributorsButton: "Contributors-module_0SqR_q_contributorsButton",
	contributorsRow: "Contributors-module_0SqR_q_contributorsRow",
	contributorsTitle: "Contributors-module_0SqR_q_contributorsTitle",
	counterLabel: "Contributors-module_0SqR_q_counterLabel",
	errorText: "Contributors-module_0SqR_q_errorText"
};
function ContributorAvatars(t0) {
	const $ = c(3);
	const { showTitle: t1 } = t0;
	const showTitle = t1 === void 0 ? true : t1;
	const isDataRouter = useIsDataRouterEnabled();
	let t2;
	if ($[0] !== isDataRouter || $[1] !== showTitle) {
		t2 = isDataRouter ? jsx(ContributorAvatarsWithProvider, { showTitle }) : jsx(ContributorAvatarsWithHook, { showTitle });
		$[0] = isDataRouter;
		$[1] = showTitle;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
ContributorAvatars.displayName = "ContributorAvatars";
function ContributorAvatarsWithHook(t0) {
	const $ = c(5);
	const { showTitle } = t0;
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { contributors, loading, error } = useContributors(repo.ownerLogin, repo.name, refInfo.name, path);
	let t1;
	if ($[0] !== contributors || $[1] !== error || $[2] !== loading || $[3] !== showTitle) {
		t1 = jsx(ContributorAvatarsInternal, {
			showTitle,
			contributors,
			loading,
			error
		});
		$[0] = contributors;
		$[1] = error;
		$[2] = loading;
		$[3] = showTitle;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
ContributorAvatarsWithHook.displayName = "ContributorAvatarsWithHook";
function ContributorAvatarsWithProvider(t0) {
	const $ = c(5);
	const { showTitle } = t0;
	const { contributors, loading, error } = useContributorsContext();
	const t1 = !!error;
	let t2;
	if ($[0] !== contributors || $[1] !== loading || $[2] !== showTitle || $[3] !== t1) {
		t2 = jsx(ContributorAvatarsInternal, {
			showTitle,
			contributors,
			loading,
			error: t1
		});
		$[0] = contributors;
		$[1] = loading;
		$[2] = showTitle;
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
ContributorAvatarsWithProvider.displayName = "ContributorAvatarsWithProvider";
function ContributorAvatarsInternal(t0) {
	const $ = c(14);
	const { showTitle: t1, contributors, loading, error } = t0;
	const showTitle = t1 === void 0 ? true : t1;
	const { sendRepoClickEvent } = useReposAnalytics();
	const [isDialogOpen, setDialogOpen] = useState(false);
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	if (error) {
		let t2;
		if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = jsx(ContributorsError, {});
			$[0] = t2;
		} else t2 = $[0];
		return t2;
	}
	if (loading) {
		let t2;
		if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = jsx(SkeletonText, {
				width: 100,
				"data-testid": "contributors-skeleton"
			});
			$[1] = t2;
		} else t2 = $[1];
		return t2;
	}
	if (!contributors || !contributors?.users.length) return null;
	const { users, totalCount } = contributors;
	let t2;
	if ($[2] !== contributors.totalCount || $[3] !== getHovercardAttributesForType || $[4] !== isDialogOpen || $[5] !== sendRepoClickEvent || $[6] !== showTitle || $[7] !== totalCount || $[8] !== users) {
		const countTitle = getCountWithUnit(totalCount, " contributor", "contributors");
		let t3;
		if ($[10] !== getHovercardAttributesForType) {
			t3 = (user, index) => jsx(GitHubAvatar, {
				className: index > 5 ? "AvatarShowLarge" : "AvatarShowMedium",
				src: user.primaryAvatarUrl,
				alt: user.login,
				"data-testid": "contributor-avatar",
				...getHovercardAttributesForType("user", { login: user.login })
			}, user.login);
			$[10] = getHovercardAttributesForType;
			$[11] = t3;
		} else t3 = $[11];
		let t4;
		if ($[12] !== sendRepoClickEvent) {
			t4 = () => {
				setDialogOpen(true);
				sendRepoClickEvent("CONTRIBUTORS.LIST.OPEN");
			};
			$[12] = sendRepoClickEvent;
			$[13] = t4;
		} else t4 = $[13];
		t2 = jsxs("div", {
			className: Contributors_module_default.contributorsRow,
			children: [
				jsx("div", {
					className: Contributors_module_default.avatarStackWrapper,
					children: jsx(AvatarStack, {
						alignRight: true,
						children: users.slice(0, 10).map(t3)
					})
				}),
				jsxs(Link, {
					as: "button",
					"aria-label": `Show ${countTitle}"`,
					onClick: t4,
					"data-testid": "contributors-count-button",
					className: Contributors_module_default.contributorsButton,
					children: [
						jsx(Octicon, { icon: PeopleIcon }),
						showTitle && jsx("span", {
							className: clsx("react-contributors-title", Contributors_module_default.contributorsTitle),
							children: "Contributors"
						}),
						jsx(CounterLabel, {
							className: Contributors_module_default.counterLabel,
							children: totalCount
						})
					]
				}),
				isDialogOpen && jsx(Dialog, {
					title: countTitle,
					onClose: () => setDialogOpen(false),
					width: "medium",
					height: contributors.totalCount >= 12 ? "small" : "auto",
					renderBody: () => jsx(ActionList, {
						className: Contributors_module_default.contributorDialogList,
						"data-testid": "contributor-dialog-list",
						children: users.map(_temp$3)
					})
				})
			]
		});
		$[2] = contributors.totalCount;
		$[3] = getHovercardAttributesForType;
		$[4] = isDialogOpen;
		$[5] = sendRepoClickEvent;
		$[6] = showTitle;
		$[7] = totalCount;
		$[8] = users;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
ContributorAvatarsInternal.displayName = "ContributorAvatarsInternal";
function _temp$3(user_0) {
	return jsx(ContributorRow, { user: user_0 }, user_0.login);
}
function ContributorRow(t0) {
	const $ = c(18);
	const { user } = t0;
	const { sendRepoClickEvent } = useReposAnalytics();
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== sendRepoClickEvent) {
		t1 = () => sendRepoClickEvent("CONTRIBUTORS.LIST.USER");
		$[0] = sendRepoClickEvent;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== path || $[3] !== refInfo.name || $[4] !== repo || $[5] !== sendRepoClickEvent || $[6] !== t1 || $[7] !== user.commitsCount || $[8] !== user.login || $[9] !== user.primaryAvatarUrl || $[10] !== user.profileLink) {
		let t3;
		if ($[12] !== sendRepoClickEvent) {
			t3 = () => sendRepoClickEvent("CONTRIBUTORS.LIST.USER");
			$[12] = sendRepoClickEvent;
			$[13] = t3;
		} else t3 = $[13];
		const t4 = jsxs(Link, {
			as: Link$1,
			className: Contributors_module_default.contributorLink,
			muted: true,
			to: user.profileLink,
			onClick: t3,
			children: [jsx(GitHubAvatar, {
				src: user.primaryAvatarUrl,
				alt: user.login,
				className: Contributors_module_default.contributorAvatar,
				"aria-hidden": "true"
			}), jsx(Truncate, {
				inline: true,
				title: user.login,
				children: user.login
			})]
		});
		const t5 = commitsPathByAuthor({
			repo,
			branch: refInfo.name,
			path,
			author: user.login
		});
		let t6;
		if ($[14] !== sendRepoClickEvent) {
			t6 = () => sendRepoClickEvent("CONTRIBUTORS.LIST.COMMITS");
			$[14] = sendRepoClickEvent;
			$[15] = t6;
		} else t6 = $[15];
		let t7;
		if ($[16] !== user.commitsCount) {
			t7 = getCountWithUnit(user.commitsCount, "commit", "commits");
			$[16] = user.commitsCount;
			$[17] = t7;
		} else t7 = $[17];
		t2 = jsxs(ActionList.Item, {
			className: Contributors_module_default.contributorRow,
			"data-testid": "contributor-dialog-row",
			onSelect: t1,
			children: [t4, jsx(ActionList.TrailingVisual, { children: jsx(Link, {
				as: Link$1,
				muted: true,
				to: t5,
				onClick: t6,
				"aria-label": `${t7} by ${user.login}`,
				"data-testid": "commit-link",
				children: getCountWithUnit(user.commitsCount, "commit", "commits")
			}) })]
		});
		$[2] = path;
		$[3] = refInfo.name;
		$[4] = repo;
		$[5] = sendRepoClickEvent;
		$[6] = t1;
		$[7] = user.commitsCount;
		$[8] = user.login;
		$[9] = user.primaryAvatarUrl;
		$[10] = user.profileLink;
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
ContributorRow.displayName = "ContributorRow";
function getCountWithUnit(count, singular, plural) {
	return `${count} ${count === 1 ? singular : plural}`;
}
function ContributorsError() {
	return /* @__PURE__ */ jsxs("span", {
		className: Contributors_module_default.errorText,
		children: [/* @__PURE__ */ jsx(Octicon, { icon: AlertFillIcon }), "\xA0Cannot retrieve contributors info at this time."]
	});
}
ContributorsError.displayName = "ContributorsError";
var BlobViewHeader_module_default = {
	ActionMenu_Overlay: "BlobViewHeader-module_OdKveq_ActionMenu_Overlay",
	Box: "BlobViewHeader-module_OdKveq_Box",
	Box_1: "BlobViewHeader-module_OdKveq_Box_1",
	Box_1_stickied: "BlobViewHeader-module_OdKveq_Box_1_stickied",
	Box_2: "BlobViewHeader-module_OdKveq_Box_2",
	Box_3: "BlobViewHeader-module_OdKveq_Box_3",
	Box_4: "BlobViewHeader-module_OdKveq_Box_4",
	Box_5: "BlobViewHeader-module_OdKveq_Box_5",
	Box_6: "BlobViewHeader-module_OdKveq_Box_6",
	downloadButton: "BlobViewHeader-module_OdKveq_downloadButton",
	IconButton: "BlobViewHeader-module_OdKveq_IconButton",
	IconButton_2: "BlobViewHeader-module_OdKveq_IconButton_2",
	LinkButton: "BlobViewHeader-module_OdKveq_LinkButton"
};
var BlameAgeLegend_module_default = {
	Box: "BlameAgeLegend-module_2XsGPa_Box",
	Box_1: "BlameAgeLegend-module_2XsGPa_Box_1",
	Text: "BlameAgeLegend-module_2XsGPa_Text",
	Text_1: "BlameAgeLegend-module_2XsGPa_Text_1"
};
var BlameAgeLegend_default = React.memo(BlameAgeLegend);
function BlameAgeLegend() {
	const $ = c(2);
	const colors = useBlameAgeColors();
	let t0;
	if ($[0] !== colors) {
		t0 = jsxs("div", {
			"aria-hidden": true,
			className: BlameAgeLegend_module_default.Box,
			children: [
				jsx("span", {
					className: BlameAgeLegend_module_default.Text,
					children: "Older"
				}),
				colors.map(_temp$2),
				jsx("span", {
					className: BlameAgeLegend_module_default.Text_1,
					children: "Newer"
				})
			]
		});
		$[0] = colors;
		$[1] = t0;
	} else t0 = $[1];
	return t0;
}
BlameAgeLegend.displayName = "BlameAgeLegend";
function _temp$2(color, i) {
	return jsx("div", {
		style: { backgroundColor: color },
		className: BlameAgeLegend_module_default.Box_1
	}, `blame-recency-color-${i}`);
}
var BlobTabButtons_module_default = { SegmentedControl: "BlobTabButtons-module_no8dpa_SegmentedControl" };
function BlobTabButtons() {
	const $ = c(23);
	const { headerInfo: t0, renderedFileInfo, image, isIssueTemplate, isDiscussionTemplate, viewable } = useCurrentBlob();
	const { isCSV, isRichtext, shortPath } = t0;
	const blame = useCurrentBlame();
	const [urlParams] = useSearchParams();
	const isPlain = urlParams.get("plain") === "1" || !!urlParams.get("short_path")?.length;
	const isOnlyPreviewable = renderedFileInfo && !viewable || image;
	const isPreviewable = isRichtext || isIssueTemplate || isDiscussionTemplate || isCSV || renderedFileInfo;
	const plainParams = renderedFileInfo ? `short_path=${shortPath}` : "plain=1";
	const { getUrl } = useUrlCreator();
	const initialSelectedTab = isPreviewable && !isPlain && !blame ? 0 : blame ? 2 : 1;
	const [selectedTab, setSelectedTab] = useState(initialSelectedTab);
	let t1;
	let t2;
	if ($[0] !== initialSelectedTab) {
		t1 = () => {
			setSelectedTab(initialSelectedTab);
		};
		t2 = [initialSelectedTab];
		$[0] = initialSelectedTab;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useLayoutEffect(t1, t2);
	const navigate = useNavigate$1();
	const { viewCodeShortcut, viewPreviewShortcut, viewBlameShortcut } = useShortcut();
	let t3;
	if ($[3] !== getUrl || $[4] !== isPreviewable || $[5] !== navigate || $[6] !== plainParams || $[7] !== selectedTab) {
		t3 = (selectedTabIndex) => {
			if (!isPreviewable) selectedTabIndex = selectedTabIndex + 1;
			setSelectedTab(selectedTabIndex);
			if (selectedTab !== selectedTabIndex) bb59: switch (selectedTabIndex) {
				case 0:
					navigate(getUrl({
						action: "blob",
						params: "",
						hash: ""
					}));
					break bb59;
				case 1: {
					const hash_0 = location.hash?.substring(1) ?? void 0;
					navigate(getUrl({
						action: "blob",
						params: isPreviewable ? plainParams : "",
						hash: hash_0
					}));
					break bb59;
				}
				case 2: navigate(getUrl({
					action: "blame",
					params: "",
					hash: location.hash?.substring(1) ?? void 0
				}));
			}
		};
		$[3] = getUrl;
		$[4] = isPreviewable;
		$[5] = navigate;
		$[6] = plainParams;
		$[7] = selectedTab;
		$[8] = t3;
	} else t3 = $[8];
	const handleSegmentChange = t3;
	if (isOnlyPreviewable) return null;
	let t4;
	if ($[9] !== handleSegmentChange || $[10] !== isOnlyPreviewable || $[11] !== isPreviewable || $[12] !== selectedTab || $[13] !== viewBlameShortcut.hotkey || $[14] !== viewCodeShortcut.hotkey || $[15] !== viewPreviewShortcut.hotkey) {
		const defaultButtons = [jsx(SegmentedControl.Button, {
			selected: selectedTab === 1,
			"data-hotkey": viewCodeShortcut.hotkey,
			children: "Code"
		}, "raw"), jsx(SegmentedControl.Button, {
			selected: selectedTab === 2,
			"data-hotkey": viewBlameShortcut.hotkey,
			children: "Blame"
		}, "blame")];
		const previewButton = jsx(SegmentedControl.Button, {
			selected: selectedTab === 0,
			"data-hotkey": viewPreviewShortcut.hotkey,
			children: "Preview"
		}, "preview'");
		let t5;
		if ($[17] !== handleSegmentChange || $[18] !== isPreviewable) {
			t5 = () => startTransition(() => handleSegmentChange(isPreviewable ? 1 : 0));
			$[17] = handleSegmentChange;
			$[18] = isPreviewable;
			$[19] = t5;
		} else t5 = $[19];
		let t6;
		if ($[20] !== handleSegmentChange || $[21] !== isPreviewable) {
			t6 = () => startTransition(() => handleSegmentChange(isPreviewable ? 2 : 1));
			$[20] = handleSegmentChange;
			$[21] = isPreviewable;
			$[22] = t6;
		} else t6 = $[22];
		const invisibleFocusButtons = jsxs(Fragment$1, { children: [
			jsx(DuplicateOnKeydownButton, {
				buttonFocusId: textAreaId,
				buttonHotkey: viewCodeShortcut.hotkey,
				onlyAddHotkeyScopeButton: true,
				onButtonClick: t5
			}),
			jsx(DuplicateOnKeydownButton, {
				buttonFocusId: textAreaId,
				buttonHotkey: viewBlameShortcut.hotkey,
				onlyAddHotkeyScopeButton: true,
				onButtonClick: t6
			}),
			isPreviewable && jsx(DuplicateOnKeydownButton, {
				buttonFocusId: "read-only-cursor-text-area",
				buttonHotkey: viewPreviewShortcut.hotkey,
				onlyAddHotkeyScopeButton: true,
				onButtonClick: () => startTransition(() => handleSegmentChange(0))
			})
		] });
		const buttons = isPreviewable ? isOnlyPreviewable ? [previewButton] : [previewButton, ...defaultButtons] : [...defaultButtons];
		t4 = jsxs(Fragment$1, { children: [jsx(SegmentedControl, {
			"aria-label": "File view",
			size: "small",
			onChange: handleSegmentChange,
			className: BlobTabButtons_module_default.SegmentedControl,
			children: buttons
		}), invisibleFocusButtons] });
		$[9] = handleSegmentChange;
		$[10] = isOnlyPreviewable;
		$[11] = isPreviewable;
		$[12] = selectedTab;
		$[13] = viewBlameShortcut.hotkey;
		$[14] = viewCodeShortcut.hotkey;
		$[15] = viewPreviewShortcut.hotkey;
		$[16] = t4;
	} else t4 = $[16];
	return t4;
}
BlobTabButtons.displayName = "BlobTabButtons";
var CodeSizeDetails_module_default = {
	Box: "CodeSizeDetails-module_IqmfTq_Box",
	Box_1: "CodeSizeDetails-module_IqmfTq_Box_1",
	codeOwnerAccent: "CodeSizeDetails-module_IqmfTq_codeOwnerAccent",
	PrimerLink: "CodeSizeDetails-module_IqmfTq_PrimerLink",
	PrimerLink_1: "CodeSizeDetails-module_IqmfTq_PrimerLink_1",
	Text: "CodeSizeDetails-module_IqmfTq_Text",
	Text_1: "CodeSizeDetails-module_IqmfTq_Text_1",
	Tooltip: "CodeSizeDetails-module_IqmfTq_Tooltip",
	Truncate: "CodeSizeDetails-module_IqmfTq_Truncate",
	Truncate_1: "CodeSizeDetails-module_IqmfTq_Truncate_1"
};
function CodeSizeDetails(t0) {
	const $ = c(15);
	const { className } = t0;
	const { codeownerInfo } = useDeferredMetadata();
	const { helpUrl } = useReposAppPayload();
	const payload = useCurrentBlob();
	const { rawLines } = useCurrentStyledBlob();
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	const blame = useCurrentBlame();
	const { headerInfo: t1, viewable } = payload;
	const { blobSize, isGitLfs, lineInfo: t2, mode } = t1;
	const { truncatedLoc, truncatedSloc } = t2;
	let t3;
	if ($[0] !== blame || $[1] !== blobSize || $[2] !== className || $[3] !== codeownerInfo || $[4] !== helpUrl || $[5] !== isGitLfs || $[6] !== mode || $[7] !== path || $[8] !== rawLines || $[9] !== refInfo || $[10] !== repo || $[11] !== truncatedLoc || $[12] !== truncatedSloc || $[13] !== viewable) {
		const symlinkUrl = mode === "symbolic link" ? getSymlinkUrl({
			rawLines,
			blame,
			repo,
			refInfo,
			path
		}) : void 0;
		t3 = jsx("div", {
			className: clsx(className, CodeSizeDetails_module_default.Box),
			children: jsxs("div", {
				className: clsx("text-mono", CodeSizeDetails_module_default.Box_1),
				children: [
					mode !== "file" && !symlinkUrl && jsxs(Fragment$1, { children: [jsx(Truncate, {
						title: mode,
						inline: true,
						className: CodeSizeDetails_module_default.Truncate,
						children: jsx("span", { children: mode })
					}), viewable && jsx("span", {
						className: CodeSizeDetails_module_default.Text,
						children: "·"
					})] }),
					viewable ? jsxs(Fragment$1, { children: [symlinkUrl && jsxs(Fragment$1, { children: [jsx(Link, {
						as: Link$1,
						muted: true,
						to: symlinkUrl,
						className: CodeSizeDetails_module_default.PrimerLink,
						children: "Symbolic Link"
					}), jsx("span", {
						className: CodeSizeDetails_module_default.Text,
						children: "·"
					})] }), jsx(Truncate, {
						maxWidth: "100%",
						title: blobSize,
						inline: true,
						"data-testid": "blob-size",
						className: CodeSizeDetails_module_default.Truncate_1,
						children: jsx("span", { children: `${truncatedLoc} lines (${truncatedSloc} loc) · ${blobSize}` })
					})] }) : jsx("span", { children: blobSize }),
					codeownerInfo && jsx(CodeOwnersBadge, { codeownerInfo }),
					isGitLfs && jsxs(Fragment$1, { children: [
						jsx("span", { className: "file-info-divider" }),
						jsx(Link, {
							muted: true,
							href: `${helpUrl}/articles/versioning-large-files/`,
							"aria-label": "Learn more about Git LFS",
							className: CodeSizeDetails_module_default.PrimerLink_1,
							children: jsx(Octicon, { icon: QuestionIcon })
						}),
						jsx("span", { children: " Stored with Git LFS" })
					] })
				]
			})
		});
		$[0] = blame;
		$[1] = blobSize;
		$[2] = className;
		$[3] = codeownerInfo;
		$[4] = helpUrl;
		$[5] = isGitLfs;
		$[6] = mode;
		$[7] = path;
		$[8] = rawLines;
		$[9] = refInfo;
		$[10] = repo;
		$[11] = truncatedLoc;
		$[12] = truncatedSloc;
		$[13] = viewable;
		$[14] = t3;
	} else t3 = $[14];
	return t3;
}
CodeSizeDetails.displayName = "CodeSizeDetails";
function CodeOwnersBadge({ codeownerInfo: { codeownerPath, ownedByCurrentUser, ownersForFile, ruleForPathLine } }) {
	if (!(ownedByCurrentUser || ownersForFile)) return null;
	const tooltipAriaLabel = getCodeownersText(ownedByCurrentUser, ownersForFile, ruleForPathLine);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		className: CodeSizeDetails_module_default.Text_1,
		children: " · "
	}), /* @__PURE__ */ jsx(Tooltip, {
		id: "codeowners-tooltip",
		"aria-label": tooltipAriaLabel,
		wrap: true,
		className: CodeSizeDetails_module_default.Tooltip,
		children: codeownerPath ? /* @__PURE__ */ jsx(Link, {
			"aria-labelledby": "codeowners-tooltip",
			href: codeownerPath,
			muted: !ownedByCurrentUser,
			className: ownedByCurrentUser ? CodeSizeDetails_module_default.codeOwnerAccent : void 0,
			children: /* @__PURE__ */ jsx(Octicon, { icon: ShieldLockIcon })
		}) : /* @__PURE__ */ jsx(Octicon, {
			icon: ShieldLockIcon,
			className: ownedByCurrentUser ? CodeSizeDetails_module_default.codeOwnerAccent : void 0
		})
	})] });
}
CodeOwnersBadge.displayName = "CodeOwnersBadge";
function getCodeownersText(ownedByCurrentUser, ownersForFile, ruleForPathLine) {
	let tooltipAriaLabel = "Owned by ";
	if (ownedByCurrentUser) {
		tooltipAriaLabel += "you";
		if (ownersForFile) tooltipAriaLabel += " along with ";
	}
	tooltipAriaLabel += ownersForFile;
	if (ruleForPathLine) tooltipAriaLabel += ` (from CODEOWNERS line ${ruleForPathLine})`;
	return tooltipAriaLabel;
}
function getSymlinkUrl({ rawLines, blame, repo, refInfo, path: currentPath }) {
	if (!rawLines || !rawLines[0]) return null;
	let filePath = rawLines[0];
	if (!filePath.startsWith("/") && !/^[a-zA-Z]:\\/.test(filePath)) filePath = `${currentPath}/../${filePath}`;
	const params = {
		owner: repo.ownerLogin,
		repo: repo.name,
		commitish: refInfo.name,
		filePath
	};
	return blame ? blamePath(params) : blobPath(params);
}
function OpenWithActionItems(t0) {
	const $ = c(9);
	const { editEnabled, githubDevUrl, ghDesktopPath, onBranch } = t0;
	const { sendRepoClickEvent } = useReposAnalytics();
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = ["windows", "mac"];
		$[0] = t1;
	} else t1 = $[0];
	const isMacOrWindows = useIsPlatform(t1);
	const { openWithGitHubDevShortcut } = useShortcut();
	let t2;
	if ($[1] !== editEnabled || $[2] !== ghDesktopPath || $[3] !== githubDevUrl || $[4] !== isMacOrWindows || $[5] !== onBranch || $[6] !== openWithGitHubDevShortcut || $[7] !== sendRepoClickEvent) {
		t2 = jsxs(ActionList.Group, { children: [
			jsx(ActionList.GroupHeading, { children: "Open with..." }),
			githubDevUrl ? jsxs(ActionList.LinkItem, {
				onClick: () => sendRepoClickEvent("BLOB_EDIT_DROPDOWN.DEV_LINK", { "edit_enabled": editEnabled }),
				className: "js-blob-dropdown-click js-github-dev-shortcut",
				href: githubDevUrl,
				"data-hotkey": openWithGitHubDevShortcut.hotkey,
				children: ["github.dev", jsx(ActionList.TrailingVisual, {
					"aria-hidden": "true",
					children: jsx(AllShortcutsEnabled, { children: jsx("kbd", { children: "." }) })
				})]
			}) : null,
			onBranch && isMacOrWindows && ghDesktopPath ? jsx(ActionList.LinkItem, {
				onClick: () => sendRepoClickEvent("BLOB_EDIT_DROPDOWN.DESKTOP"),
				href: ghDesktopPath,
				children: "GitHub Desktop"
			}) : null
		] });
		$[1] = editEnabled;
		$[2] = ghDesktopPath;
		$[3] = githubDevUrl;
		$[4] = isMacOrWindows;
		$[5] = onBranch;
		$[6] = openWithGitHubDevShortcut;
		$[7] = sendRepoClickEvent;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
OpenWithActionItems.displayName = "OpenWithActionItems";
function useHasOpenWithItems(githubDevUrl, onBranch, ghDesktopPath) {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = ["windows", "mac"];
		$[0] = t0;
	} else t0 = $[0];
	const isMacOrWindows = useIsPlatform(t0);
	return !!(githubDevUrl || onBranch && isMacOrWindows && ghDesktopPath);
}
function EditMenuActionItems(t0) {
	const $ = c(11);
	const { editAllowed, hasOpenWithItem } = t0;
	const payload = useCurrentBlob();
	const { name: refName } = useRefInfo();
	const { canEdit, canEditOnDefaultBranch } = useEditPermissions();
	const { githubDevUrl } = useReposAppPayload();
	const { sendRepoClickEvent } = useReposAnalytics();
	const { getUrl } = useUrlCreator();
	const { defaultBranch } = useCurrentRepository();
	const { headerInfo: t1 } = payload;
	const { ghDesktopPath, onBranch } = t1;
	const showDefaultBranchEditOption = !!canEditOnDefaultBranch && !(refName === defaultBranch);
	let t2;
	if ($[0] !== canEdit || $[1] !== defaultBranch || $[2] !== editAllowed || $[3] !== getUrl || $[4] !== ghDesktopPath || $[5] !== githubDevUrl || $[6] !== hasOpenWithItem || $[7] !== onBranch || $[8] !== sendRepoClickEvent || $[9] !== showDefaultBranchEditOption) {
		t2 = jsxs(Fragment$1, { children: [
			editAllowed && jsxs(ActionList.Group, { children: [jsx(ActionList.GroupHeading, { children: "Edit file..." }), showDefaultBranchEditOption ? jsxs(ActionList.LinkItem, {
				onClick: () => sendRepoClickEvent("BLOB_EDIT_DROPDOWN.ON_DEFAULT_BRANCH"),
				href: getUrl({
					action: "edit",
					commitish: defaultBranch
				}),
				children: [
					"On ",
					jsx("code", { children: defaultBranch }),
					" branch"
				]
			}) : jsxs(ActionList.LinkItem, {
				onClick: () => sendRepoClickEvent("BLOB_EDIT_DROPDOWN.IN_PLACE"),
				href: getUrl({ action: "edit" }),
				"data-hotkey": "e",
				children: ["In place", jsx(ActionList.TrailingVisual, {
					"aria-hidden": "true",
					children: jsx(AllShortcutsEnabled, { children: jsx("kbd", { children: "e" }) })
				})]
			})] }),
			editAllowed && hasOpenWithItem && jsx(ActionList.Divider, {}),
			hasOpenWithItem && jsx(OpenWithActionItems, {
				editEnabled: canEdit,
				githubDevUrl,
				ghDesktopPath,
				onBranch
			})
		] });
		$[0] = canEdit;
		$[1] = defaultBranch;
		$[2] = editAllowed;
		$[3] = getUrl;
		$[4] = ghDesktopPath;
		$[5] = githubDevUrl;
		$[6] = hasOpenWithItem;
		$[7] = onBranch;
		$[8] = sendRepoClickEvent;
		$[9] = showDefaultBranchEditOption;
		$[10] = t2;
	} else t2 = $[10];
	return t2;
}
EditMenuActionItems.displayName = "EditMenuActionItems";
var StickyLinesHeader_module_default = {
	Box: "StickyLinesHeader-module_4qHwvG_Box",
	Box_1: "StickyLinesHeader-module_4qHwvG_Box_1"
};
function StickyLinesHeader({ currentStickyLines, colorizedLines }) {
	const stickyLines = Array.from(currentStickyLines.values());
	return /* @__PURE__ */ jsxs("div", {
		className: StickyLinesHeader_module_default.Box,
		children: [/* @__PURE__ */ jsx("div", {
			className: clsx("react-line-numbers", StickyLinesHeader_module_default.Box_1),
			children: stickyLines.map((stickyLine) => {
				return /* @__PURE__ */ jsx(LineNumber, { codeLineData: stickyLine }, `sticky-header-line-number-${stickyLine.lineNumber}`);
			})
		}), /* @__PURE__ */ jsx("div", {
			className: "react-code-lines",
			children: stickyLines.map((stickyLine) => {
				if (colorizedLines && colorizedLines[stickyLine.lineNumber - 1]) return /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
					className: "react-code-text react-code-line-contents-no-virtualization react-file-line html-div",
					style: { paddingLeft: "18px" },
					html: colorizedLines[stickyLine.lineNumber - 1],
					onClick: () => scrollLineIntoView({ line: stickyLine.lineNumber })
				}, `sticky-header-line-${stickyLine.lineNumber}`);
				return /* @__PURE__ */ jsx(CodeLine, {
					codeLineData: stickyLine,
					stylingDirectivesLine: stickyLine.stylingDirectivesLine,
					codeLineToSectionMap: void 0,
					copilotAccessAllowed: false,
					onClick: () => scrollLineIntoView({ line: stickyLine.lineNumber }),
					shouldUseInert: false
				}, `sticky-header-line-${stickyLine.lineNumber}`);
			})
		})]
	});
}
StickyLinesHeader.displayName = "StickyLinesHeader";
function BlobViewHeader({ openPanel, setOpenPanel, showTree, validCodeNav, treeToggleElement, currentStickyLines, focusedSearchResult, setFocusedSearchResult, searchResults, searchingText, stickyHeaderElement, copilotInfo, colorizedLines, onBannerChange }) {
	const setSearchTerm = useSetSearchTerm();
	const payload = useCurrentBlob();
	const symbolsEnabled = payload.symbolsEnabled;
	const { isSticky: isStickied } = useStickyObserver(stickyHeaderElement);
	const path = usePath();
	const { copilotAccessAllowed, copilotSpacesEnabled } = useCopilotSettings();
	const refInfo = useRefInfo();
	const { canEdit, canEditOnDefaultBranch } = useEditPermissions();
	const displayType = useBlobRendererType();
	const { sendRepoClickEvent } = useReposAnalytics();
	const stickyHeaderHeight = useStickyHeaderHeight();
	const { copyFilePathShortcut } = useShortcut();
	const { copyPermalinkShortcut } = useShortcut();
	const repository = useCurrentRepository();
	const showAgentTaskButton = payload.copilotSWEAgentEnabled;
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const { githubDevUrl } = useReposAppPayload();
	const { headerInfo: { toc, onBranch, ghDesktopPath }, viewable } = payload;
	const hasOpenWithItem = useHasOpenWithItems(githubDevUrl, onBranch, ghDesktopPath);
	const blame = useCurrentBlame();
	const onCopy = useCopyRawBlobContents();
	const { createPermalink } = useUrlCreator();
	const { addToast } = useToastContext();
	const { findInFileOpen, setFindInFileOpen } = useFindInFileOpen();
	const rawActionsButtonRef = useRef(null);
	const [updateTooltipMessage, clearTooltipMessage, portalTooltip] = useAlertTooltip("raw-actions-message-tooltip", rawActionsButtonRef, { direction: "nw" });
	const { getUrl } = useUrlCreator();
	const blobUrl = getUrl();
	const { isServer } = useRuntimeEnvironment();
	const fileUrl = isServer ? blobUrl : ssrSafeLocation.origin + blobUrl;
	const fileReference = useMemo(() => ({
		type: "file",
		url: fileUrl,
		path,
		repoID: repository.id,
		repoOwner: repository.ownerLogin,
		repoName: repository.name,
		ref: qualifyRef$1(refInfo.name, refInfo.refType ?? "branch"),
		commitOID: refInfo.currentOid
	}), [
		fileUrl,
		path,
		repository.id,
		repository.ownerLogin,
		repository.name,
		refInfo.name,
		refInfo.refType,
		refInfo.currentOid
	]);
	const editAllowedOnDefaultBranch = viewable && canEditOnDefaultBranch;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs("div", {
			ref: trackStickyHeader,
			className: BlobViewHeader_module_default.Box,
			children: [
				/* @__PURE__ */ jsx("div", {
					className: "react-blob-sticky-header",
					children: /* @__PURE__ */ jsx(FileNameStickyHeader, {
						isStickied,
						showTree,
						treeToggleElement
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: clsx(BlobViewHeader_module_default.Box_1, isStickied && BlobViewHeader_module_default.Box_1_stickied),
					children: [
						/* @__PURE__ */ jsx(ScreenReaderHeading, {
							as: "h2",
							text: "File metadata and controls"
						}),
						/* @__PURE__ */ jsxs("div", {
							className: BlobViewHeader_module_default.Box_2,
							children: [
								/* @__PURE__ */ jsx(BlobTabButtons, {}),
								/* @__PURE__ */ jsx(CodeSizeDetails, { className: "react-code-size-details-in-header" }),
								/* @__PURE__ */ jsx(CopilotPopover, {
									copilotInfo,
									className: "react-code-size-details-in-header",
									view: blame ? "blame" : "preview"
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: BlobViewHeader_module_default.Box_3,
							children: [
								copyFilePathShortcut.hotkey && /* @__PURE__ */ jsx(KeyboardShortcut, {
									hotkey: copyFilePathShortcut.hotkey,
									onActivate: () => {
										copyText(path);
										addToast({
											type: "success",
											message: "Path copied!"
										});
									}
								}),
								copyPermalinkShortcut.hotkey && /* @__PURE__ */ jsx(KeyboardShortcut, {
									hotkey: copyPermalinkShortcut.hotkey,
									onActivate: () => {
										copyText(createPermalink({ absolute: true }));
										addToast({
											type: "success",
											message: "Permalink copied!"
										});
									}
								}),
								copilotAccessAllowed && copilotSpacesEnabled && /* @__PURE__ */ jsx(SpacesSelectionMenu, {
									repository,
									currentFile: fileReference,
									onBannerChange
								}),
								/* @__PURE__ */ jsx(CopilotCodeLinesMenu, {
									copilotAccessAllowed,
									messageReference: fileReference,
									hideDropdown: true,
									id: "blob-view-header-copilot-icon",
									decoupledModeEnabled
								}),
								showAgentTaskButton && /* @__PURE__ */ jsx(NewAgentTaskButton, {
									isIconButton: true,
									size: "small",
									tooltipDirection: "n",
									currentRepo: repository,
									currentReference: { path },
									hideRepoSelector: true,
									eventType: "new_agent_task_button_codeview",
									decoupledModeEnabled
								}),
								/* @__PURE__ */ jsxs("div", {
									className: clsx("react-blob-header-edit-and-raw-actions", BlobViewHeader_module_default.Box_4),
									children: [/* @__PURE__ */ jsx(RawGroup, {
										onCopy,
										fileName: payload.displayName
									}), /* @__PURE__ */ jsx(EditMenu, {})]
								}),
								displayType === BlobDisplayType.Code && !blame && validCodeNav && symbolsEnabled && /* @__PURE__ */ jsx(SymbolsButton, {
									isCodeNavOpen: openPanel === "codeNav",
									setCodeNavOpen: (open) => {
										if (open) sendRepoClickEvent("BLOB_SYMBOLS_MENU.OPEN");
										const value = open ? "codeNav" : "";
										requestIdleCallback(() => localStorage.setItem("codeNavOpen", value));
										updateExpandPreferences(null, open, null);
										setOpenPanel(open ? "codeNav" : void 0);
									},
									size: "small",
									searchingText: searchingText.selectedText
								}),
								!blame && /* @__PURE__ */ jsx(TableOfContents, {
									toc,
									openPanel,
									setOpenPanel
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "react-blob-header-edit-and-raw-actions-combined",
									children: [portalTooltip, /* @__PURE__ */ jsxs(ActionMenu, {
										anchorRef: rawActionsButtonRef,
										children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
											icon: KebabHorizontalIcon,
											tooltipDirection: "nw",
											"aria-label": "Edit and raw actions",
											className: clsx("js-blob-dropdown-click", BlobViewHeader_module_default.IconButton),
											size: "small",
											title: "More file actions",
											variant: "invisible",
											"data-testid": "more-file-actions-button",
											onBlur: clearTooltipMessage
										}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
											className: clsx("react-blob-header-edit-and-raw-actions-combined", BlobViewHeader_module_default.ActionMenu_Overlay),
											width: "small",
											children: /* @__PURE__ */ jsxs(ActionList, { children: [(canEdit && viewable || editAllowedOnDefaultBranch || hasOpenWithItem) && /* @__PURE__ */ jsxs("div", {
												className: "react-navigation-menu-edit-and-raw-actions",
												children: [/* @__PURE__ */ jsx(EditMenuActionItems, {
													editAllowed: !!(viewable && canEdit) || !!editAllowedOnDefaultBranch,
													hasOpenWithItem
												}), /* @__PURE__ */ jsx(ActionList.Divider, {})]
											}), /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(RawMenuActionItems, {
												viewable,
												onCopy,
												name: payload.displayName,
												updateTooltipMessage,
												all: true
											}) })] })
										})]
									})]
								})
							]
						})
					]
				}),
				blame && /* @__PURE__ */ jsxs("div", {
					className: BlobViewHeader_module_default.Box_5,
					children: [/* @__PURE__ */ jsx(BlameAgeLegend_default, {}), /* @__PURE__ */ jsx(ContributorAvatars, {})]
				})
			]
		}),
		findInFileOpen && /* @__PURE__ */ jsx(FindInFilePopover, {
			stickied: isStickied,
			focusedSearchResult,
			setFocusedSearchResult,
			searchResults,
			onClose: () => {
				setFindInFileOpen(false);
				if (openPanel === "codeNav") setSearchTerm(searchingText.selectedText);
			}
		}),
		/* @__PURE__ */ jsx("div", { children: !blame && currentStickyLines.size > 0 && /* @__PURE__ */ jsx("div", {
			style: { top: stickyHeaderHeight },
			className: BlobViewHeader_module_default.Box_6,
			children: /* @__PURE__ */ jsx(StickyLinesHeader, {
				currentStickyLines,
				colorizedLines
			})
		}) })
	] });
}
BlobViewHeader.displayName = "BlobViewHeader";
function EditMenu() {
	const $ = c(24);
	const payload = useCurrentBlob();
	const { getUrl } = useUrlCreator();
	const { canEdit, canEditOnDefaultBranch } = useEditPermissions();
	const { sendRepoClickEvent } = useReposAnalytics();
	const { githubDevUrl } = useReposAppPayload();
	const navigate = useNavigate$1();
	const { editFileShortcut, openWithGitHubDevShortcut, openWithGitHubDevInNewWindowShortcut } = useShortcut();
	const editAllowedOnDefaultBranch = !!canEditOnDefaultBranch;
	const { headerInfo: t0 } = payload;
	const { editTooltip, ghDesktopPath, onBranch } = t0;
	const hasOpenWithItem = useHasOpenWithItems(githubDevUrl, onBranch, ghDesktopPath);
	if (!canEdit && !hasOpenWithItem) return null;
	let t1;
	if ($[0] !== getUrl || $[1] !== navigate) {
		t1 = () => {
			navigate(getUrl({ action: "edit" }));
		};
		$[0] = getUrl;
		$[1] = navigate;
		$[2] = t1;
	} else t1 = $[2];
	const onEditClick = t1;
	let t2;
	if ($[3] !== githubDevUrl) {
		t2 = () => {
			window.open(githubDevUrl, "_blank");
		};
		$[3] = githubDevUrl;
		$[4] = t2;
	} else t2 = $[4];
	const openGitHubDevInNewWindow = t2;
	let t3;
	if ($[5] !== githubDevUrl || $[6] !== navigate) {
		t3 = () => {
			navigate(githubDevUrl + window.location.pathname.substring(1));
		};
		$[5] = githubDevUrl;
		$[6] = navigate;
		$[7] = t3;
	} else t3 = $[7];
	const openInGitHubDev = t3;
	let t4;
	if ($[8] !== canEdit || $[9] !== editAllowedOnDefaultBranch || $[10] !== editFileShortcut || $[11] !== editTooltip || $[12] !== getUrl || $[13] !== githubDevUrl || $[14] !== hasOpenWithItem || $[15] !== onEditClick || $[16] !== openGitHubDevInNewWindow || $[17] !== openInGitHubDev || $[18] !== openWithGitHubDevInNewWindowShortcut || $[19] !== openWithGitHubDevShortcut || $[20] !== sendRepoClickEvent) {
		let t5;
		if ($[22] !== sendRepoClickEvent) {
			t5 = (open) => open && sendRepoClickEvent("BLOB_EDIT_DROPDOWN");
			$[22] = sendRepoClickEvent;
			$[23] = t5;
		} else t5 = $[23];
		t4 = jsxs(Fragment$1, { children: [
			githubDevUrl && jsxs(Fragment$1, { children: [
				jsx(Link, {
					className: "js-github-dev-shortcut d-none",
					"data-hotkey": openWithGitHubDevShortcut.hotkey,
					href: githubDevUrl
				}),
				jsx(DuplicateOnKeydownButton, {
					buttonFocusId: "read-only-cursor-text-area",
					buttonHotkey: openWithGitHubDevShortcut.hotkey,
					onlyAddHotkeyScopeButton: true,
					onButtonClick: openInGitHubDev
				}),
				jsx(Link, {
					className: "js-github-dev-new-tab-shortcut d-none",
					"data-hotkey": openWithGitHubDevInNewWindowShortcut.hotkey,
					href: githubDevUrl,
					target: "_blank"
				}),
				jsx(DuplicateOnKeydownButton, {
					buttonFocusId: "read-only-cursor-text-area",
					buttonHotkey: openWithGitHubDevInNewWindowShortcut.hotkey,
					onlyAddHotkeyScopeButton: true,
					onButtonClick: openGitHubDevInNewWindow
				})
			] }),
			jsxs(ButtonGroup, { children: [canEdit ? jsx(IconButton, {
				as: Link$1,
				tooltipDirection: "nw",
				"aria-label": editTooltip,
				"data-hotkey": editFileShortcut.hotkey,
				icon: PencilIcon,
				to: getUrl({ action: "edit" }),
				size: "small",
				className: LinkButton_module_default.linkButton,
				"data-testid": "edit-button"
			}) : jsx(AccessibleIconButton, {
				icon: PencilIcon,
				"aria-label": editTooltip,
				disabled: true
			}), jsxs(ActionMenu, {
				onOpenChange: t5,
				children: [jsx(ActionMenu.Anchor, { children: jsx(IconButton, {
					tooltipDirection: "nw",
					icon: TriangleDownIcon,
					size: "small",
					"aria-label": "More edit options",
					"data-testid": "more-edit-button"
				}) }), jsx(ActionMenu.Overlay, {
					align: "end",
					children: jsx(ActionList, { children: jsx(EditMenuActionItems, {
						editAllowed: canEdit || editAllowedOnDefaultBranch,
						hasOpenWithItem
					}) })
				})]
			})] }),
			canEdit && jsx(DuplicateOnKeydownButton, {
				buttonFocusId: "read-only-cursor-text-area",
				buttonHotkey: "e,Shift+E",
				onlyAddHotkeyScopeButton: true,
				onButtonClick: onEditClick
			})
		] });
		$[8] = canEdit;
		$[9] = editAllowedOnDefaultBranch;
		$[10] = editFileShortcut;
		$[11] = editTooltip;
		$[12] = getUrl;
		$[13] = githubDevUrl;
		$[14] = hasOpenWithItem;
		$[15] = onEditClick;
		$[16] = openGitHubDevInNewWindow;
		$[17] = openInGitHubDev;
		$[18] = openWithGitHubDevInNewWindowShortcut;
		$[19] = openWithGitHubDevShortcut;
		$[20] = sendRepoClickEvent;
		$[21] = t4;
	} else t4 = $[21];
	return t4;
}
EditMenu.displayName = "EditMenu";
function RawGroup({ onCopy, fileName }) {
	const { viewRawContentShortcut, copyRawContentShortcut, downloadRawContentShortcut } = useShortcut();
	const { renderImageOrRaw, renderedFileInfo, viewable, image, rawBlobUrl, headerInfo: { isGitLfs: isLfs } } = useCurrentBlob();
	const navigate = useNavigate$1();
	const { addToast } = useToastContext();
	const copyButtonRef = useRef(null);
	const [updateTooltipMessage, clearTooltipMessage, portalTooltip] = useAlertTooltip("raw-copy-message-tooltip", copyButtonRef);
	const isOnlyPreviewable = !isLfs && (renderedFileInfo && !viewable || image);
	const downloadRawFile = async () => {
		await downloadFile(rawBlobUrl, fileName);
	};
	const navToRaw = () => navigate(rawBlobUrl);
	const copyFile = async () => {
		const { ariaLabel } = getCopyStateUI(await onCopy());
		updateTooltipMessage(ariaLabel);
	};
	const lfsDownloadUrl = new URL(rawBlobUrl, ssrSafeLocation.origin);
	lfsDownloadUrl.searchParams.set("download", "");
	const downloadButtonProps = {
		["aria-label"]: "Download raw file",
		["tooltipDirection"]: "n",
		icon: DownloadIcon,
		size: "small",
		onClick: async () => {
			if (!isLfs) await downloadFile(rawBlobUrl, fileName);
		},
		["data-testid"]: "download-raw-button",
		["data-hotkey"]: downloadRawContentShortcut.hotkey,
		className: BlobViewHeader_module_default.downloadButton
	};
	return isOnlyPreviewable ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
		"aria-label": "Download raw file",
		tooltipDirection: "n",
		icon: DownloadIcon,
		size: "small",
		onClick: downloadRawFile,
		"data-testid": "download-raw-button",
		"data-hotkey": downloadRawContentShortcut.hotkey
	}), /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
		buttonTestLabel: "download-raw-button-shortcut",
		buttonFocusId: textAreaId,
		buttonHotkey: downloadRawContentShortcut.hotkey,
		onlyAddHotkeyScopeButton: true,
		onButtonClick: downloadRawFile
	})] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs(ButtonGroup, { children: [
			/* @__PURE__ */ jsx(LinkButton, {
				href: rawBlobUrl,
				download: renderImageOrRaw ? "true" : void 0,
				size: "small",
				"data-testid": "raw-button",
				"data-hotkey": viewRawContentShortcut.hotkey,
				className: clsx(LinkButton_module_default.linkButton, BlobViewHeader_module_default.LinkButton),
				children: "Raw"
			}),
			!isLfs && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(IconButton, {
				ref: copyButtonRef,
				"aria-label": "Copy raw file",
				tooltipDirection: "n",
				icon: CopyIcon,
				size: "small",
				onMouseLeave: clearTooltipMessage,
				onClick: copyFile,
				"data-testid": "copy-raw-button",
				"data-hotkey": copyRawContentShortcut.hotkey,
				onBlur: clearTooltipMessage
			}), portalTooltip] }),
			isLfs ? /* @__PURE__ */ jsx(IconButton, {
				as: "a",
				"data-turbo": "false",
				href: lfsDownloadUrl.toString(),
				...downloadButtonProps
			}) : /* @__PURE__ */ jsx(IconButton, { ...downloadButtonProps })
		] }),
		/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: viewRawContentShortcut.hotkey,
			buttonTestLabel: "raw-button-shortcut",
			onlyAddHotkeyScopeButton: true,
			onButtonClick: navToRaw
		}),
		!isLfs && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonTestLabel: "copy-raw-button-shortcut",
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: copyRawContentShortcut.hotkey,
			onlyAddHotkeyScopeButton: true,
			onButtonClick: async () => {
				const { ariaLabel: ariaLabel_0, content } = getCopyStateUI(await onCopy());
				addToast({
					message: ariaLabel_0,
					icon: content
				});
			}
		}), /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
			buttonTestLabel: "download-raw-button-shortcut",
			buttonFocusId: "read-only-cursor-text-area",
			buttonHotkey: downloadRawContentShortcut.hotkey,
			onlyAddHotkeyScopeButton: true,
			onButtonClick: async () => {
				await downloadFile(rawBlobUrl, fileName);
			}
		})] })
	] });
}
RawGroup.displayName = "RawGroup";
function SymbolsButton(t0) {
	const $ = c(11);
	const { isCodeNavOpen, setCodeNavOpen, size, searchingText } = t0;
	const { toggleSymbolsShortcut } = useShortcut();
	const shouldShowIndicator = !useCodeViewOptions().openSymbolsOption.enabled && !isCodeNavOpen;
	let t1;
	if ($[0] !== isCodeNavOpen || $[1] !== setCodeNavOpen) {
		t1 = () => {
			setKeyboardNavUsed(true);
			setCodeNavOpen(!isCodeNavOpen);
		};
		$[0] = isCodeNavOpen;
		$[1] = setCodeNavOpen;
		$[2] = t1;
	} else t1 = $[2];
	const toggleCodeNav = t1;
	const t2 = isCodeNavOpen ? "Close symbols panel" : "Open symbols panel";
	let t3;
	if ($[3] !== isCodeNavOpen || $[4] !== searchingText || $[5] !== shouldShowIndicator || $[6] !== size || $[7] !== t2 || $[8] !== toggleCodeNav || $[9] !== toggleSymbolsShortcut.hotkey) {
		t3 = jsx(IconButton, {
			"aria-label": t2,
			tooltipDirection: "nw",
			"aria-pressed": isCodeNavOpen,
			"aria-expanded": isCodeNavOpen,
			"aria-controls": "symbols-pane",
			icon: CodeSquareIcon,
			className: clsx(shouldShowIndicator && searchingText ? "react-button-with-indicator" : "", BlobViewHeader_module_default.IconButton_2),
			"data-hotkey": toggleSymbolsShortcut.hotkey,
			onClick: toggleCodeNav,
			variant: "invisible",
			"data-testid": "symbols-button",
			id: "symbols-button",
			size
		});
		$[3] = isCodeNavOpen;
		$[4] = searchingText;
		$[5] = shouldShowIndicator;
		$[6] = size;
		$[7] = t2;
		$[8] = toggleCodeNav;
		$[9] = toggleSymbolsShortcut.hotkey;
		$[10] = t3;
	} else t3 = $[10];
	return t3;
}
SymbolsButton.displayName = "SymbolsButton";
function KeyboardShortcut({ hotkey, onActivate }) {
	return /* @__PURE__ */ jsx(DuplicateOnKeydownButton, {
		buttonFocusId: textAreaId,
		buttonHotkey: hotkey,
		onButtonClick: onActivate
	});
}
KeyboardShortcut.displayName = "KeyboardShortcut";
var emptyResults = {
	definitions: void 0,
	localReferences: void 0,
	crossReferences: void 0,
	error: false
};
function useCodeNav(codeNavInfo, text, row, column) {
	const [results, setResults] = useState(emptyResults);
	useEffect(() => {
		(async () => {
			if (row < 0 || column < 0) return;
			const { definitions, localReferences, crossReferences, setLoading } = codeNavInfo.getDefinitionsAndReferences(text, row, column);
			setResults(emptyResults);
			try {
				const defs = await definitions;
				setResults({
					definitions: defs,
					localReferences: void 0,
					crossReferences: void 0,
					error: false
				});
				setLoading(false);
				const [localRefs, crossRefs] = await Promise.all([localReferences, crossReferences]);
				setResults({
					definitions: defs,
					localReferences: localRefs,
					crossReferences: crossRefs,
					error: false
				});
			} catch {
				setResults({
					...emptyResults,
					error: true
				});
			} finally {
				setLoading(false);
			}
		})();
	}, [
		codeNavInfo,
		text,
		row,
		column
	]);
	return results;
}
var CodeNavCell_module_default = {
	blobNum: "CodeNavCell-module_sw8B5G_blobNum",
	cellInner: "CodeNavCell-module_sw8B5G_cellInner",
	cellInnerHighlighted: "CodeNavCell-module_sw8B5G_cellInnerHighlighted",
	cellLink: "CodeNavCell-module_sw8B5G_cellLink",
	codeContainer: "CodeNavCell-module_sw8B5G_codeContainer",
	verifiedHtml: "CodeNavCell-module_sw8B5G_verifiedHtml"
};
function CodeNavCellInner(t0) {
	const $ = c(26);
	const { reference, isHighlighted, href, onClick, role, ariaLevel, symbol, index, focusElement } = t0;
	const [offsetWidth, setOffsetWidth] = useState(null);
	let t1;
	if ($[0] !== reference || $[1] !== symbol) {
		t1 = getOffsetString(symbol, reference);
		$[0] = reference;
		$[1] = symbol;
		$[2] = t1;
	} else t1 = $[2];
	const text = t1;
	let t2;
	let t3;
	if ($[3] !== text) {
		t2 = () => {
			setOffsetWidth(measureMonospaceTextWidth(text));
		};
		t3 = [text];
		$[3] = text;
		$[4] = t2;
		$[5] = t3;
	} else {
		t2 = $[4];
		t3 = $[5];
	}
	useLayoutEffect(t2, t3);
	let t4;
	let t5;
	if ($[6] !== focusElement || $[7] !== index) {
		t4 = () => {
			if (focusElement) {
				const element = document.getElementById(`find-in-file-item-${index}`);
				if (element) element.focus();
			}
		};
		t5 = [focusElement, index];
		$[6] = focusElement;
		$[7] = index;
		$[8] = t4;
		$[9] = t5;
	} else {
		t4 = $[8];
		t5 = $[9];
	}
	useEffect(t4, t5);
	const { tabSize } = useCurrentBlob();
	let t6;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = isHiddenUnicodeShown();
		$[10] = t6;
	} else t6 = $[10];
	const hiddenUnicodeShown = t6;
	const codeHtml = useCodeHTML(reference.highlightedText, reference.stylingDirectives, reference.bodyText, "plain", tabSize, hiddenUnicodeShown);
	let t7;
	if ($[11] !== onClick) {
		t7 = (ev) => {
			if (!ev.ctrlKey && !ev.metaKey) onClick?.();
		};
		$[11] = onClick;
		$[12] = t7;
	} else t7 = $[12];
	const onClickHandler = t7;
	const t8 = `find-in-file-item-${index}`;
	const t9 = isHighlighted ? "location" : void 0;
	let t10;
	if ($[13] !== ariaLevel || $[14] !== codeHtml || $[15] !== href || $[16] !== isHighlighted || $[17] !== offsetWidth || $[18] !== onClick || $[19] !== onClickHandler || $[20] !== reference || $[21] !== role || $[22] !== symbol || $[23] !== t8 || $[24] !== t9) {
		t10 = jsx(Link, {
			as: Link$1,
			to: href,
			role,
			className: CodeNavCell_module_default.cellLink,
			onClick: onClickHandler,
			onSelect: onClick,
			id: t8,
			"aria-current": t9,
			"aria-level": ariaLevel,
			onKeyDown: _temp$1,
			children: jsx("div", {
				className: clsx(CodeNavCell_module_default.cellInner, isHighlighted && CodeNavCell_module_default.cellInnerHighlighted),
				children: jsxs("div", {
					className: "d-flex",
					children: [jsx("div", {
						className: clsx("text-small blob-num color-fg-muted", CodeNavCell_module_default.blobNum),
						children: reference.lineNumber
					}), jsx("div", {
						className: CodeNavCell_module_default.codeContainer,
						children: offsetWidth !== null && jsxs("div", {
							id: `offset-${reference.href(false)}`,
							style: { marginLeft: -offsetWidth },
							children: [symbol.length > 0 && jsx(HighlightedOverlay, {
								symbols: [reference],
								lineNumber: reference.lineNumber,
								style: { overflow: "initial" },
								isNotUsingWhitespace: true
							}), jsx(VerifiedHTMLText, {
								className: CodeNavCell_module_default.verifiedHtml,
								html: codeHtml,
								"aria-current": isHighlighted ? "location" : void 0
							})]
						})
					})]
				})
			})
		});
		$[13] = ariaLevel;
		$[14] = codeHtml;
		$[15] = href;
		$[16] = isHighlighted;
		$[17] = offsetWidth;
		$[18] = onClick;
		$[19] = onClickHandler;
		$[20] = reference;
		$[21] = role;
		$[22] = symbol;
		$[23] = t8;
		$[24] = t9;
		$[25] = t10;
	} else t10 = $[25];
	return t10;
}
CodeNavCellInner.displayName = "CodeNavCellInner";
function _temp$1(e) {
	if (e.key === "ArrowDown") {
		focusSibling("nextElementSibling");
		e.preventDefault();
	} else if (e.key === "ArrowUp") {
		focusSibling("previousElementSibling");
		e.preventDefault();
	}
}
var TOTAL_ALLOWED_CHARS = 34;
function getOffsetString(searchTerm, reference) {
	let canFitLength = TOTAL_ALLOWED_CHARS - searchTerm.length;
	const substringBeforeMatch = reference.bodyText.slice(0, reference.ident.start.column);
	if (canFitLength <= 0) return substringBeforeMatch;
	const substringAfterMatch = reference.bodyText.slice(reference.ident.start.column + searchTerm.length).trimEnd();
	canFitLength = Math.max(canFitLength / 2, canFitLength - substringAfterMatch.length);
	const wordsOffset = substringBeforeMatch.split(" ");
	const fit = [];
	for (let index = wordsOffset.length - 1; index >= 0; index--) {
		const word = wordsOffset[index];
		fit.unshift(word);
		if (fit.join(" ").length <= canFitLength) wordsOffset.pop();
		else break;
	}
	const offset = wordsOffset.join(" ");
	const whitespaceOffset = (substringBeforeMatch.slice(offset.length).match(/^[ \t]*/) || [])[0] ?? "";
	return `${wordsOffset.join(" ")}${whitespaceOffset}`;
}
function focusSibling(key) {
	const { activeElement } = document;
	const elementSibling = activeElement?.[key];
	if (elementSibling) if (elementSibling.role !== "treeitem" && key === "nextElementSibling") elementSibling.querySelector("[role=\"treeitem\"]")?.focus();
	else elementSibling.focus();
}
var CodeNavCell = React.memo(CodeNavCellInner);
CodeNavCell.displayName = "CodeNavCell";
var CodeNavFileInformation_module_default = {
	counterLabel: "CodeNavFileInformation-module_1L3jvW_counterLabel",
	expandButton: "CodeNavFileInformation-module_1L3jvW_expandButton",
	fileHeader: "CodeNavFileInformation-module_1L3jvW_fileHeader",
	fileHeaderExpandable: "CodeNavFileInformation-module_1L3jvW_fileHeaderExpandable",
	flexRow: "CodeNavFileInformation-module_1L3jvW_flexRow",
	repoAvatar: "CodeNavFileInformation-module_1L3jvW_repoAvatar",
	repoName: "CodeNavFileInformation-module_1L3jvW_repoName",
	resultsGroup: "CodeNavFileInformation-module_1L3jvW_resultsGroup",
	showMoreButton: "CodeNavFileInformation-module_1L3jvW_showMoreButton",
	showMoreWrapper: "CodeNavFileInformation-module_1L3jvW_showMoreWrapper",
	tableWrapper: "CodeNavFileInformation-module_1L3jvW_tableWrapper",
	truncatedPath: "CodeNavFileInformation-module_1L3jvW_truncatedPath"
};
var MaxReferences = 10;
function CodeNavFileInformation({ results, repo, filePath, highlightedIndex, isDefinition, onClick, offset, initiallyExpanded, enableExpandCollapse, symbol, setFocusOnFile }) {
	const hasBlame = !!useCurrentBlame();
	const [isExpanded, setIsExpanded] = useState(initiallyExpanded);
	const currentRepo = useCurrentRepository();
	const currentPath = usePath();
	const firstFileRef = React.useRef(null);
	const [showAllRefs, setShowAllRefs] = useState(false);
	const keyboardNavUsed = useKeyboardNavUsed();
	const initialVisibleRefs = results.slice(0, MaxReferences);
	const hiddenRefs = results.length > MaxReferences ? results.slice(MaxReferences) : [];
	const { sendRepoClickEvent } = useReposAnalytics();
	const isFromCurrentRepo = currentRepo.ownerLogin === repo.ownerLogin && currentRepo.name === repo.name;
	const onKeyDown = useCallback((e) => {
		if (e.key === "Enter" || e.key === " ") {
			setIsExpanded(!isExpanded);
			e.preventDefault();
		} else if (e.key === "ArrowLeft") setIsExpanded(false);
		else if (e.key === "ArrowRight") {
			setIsExpanded(true);
			if (isExpanded) firstFileRef.current?.focus();
		} else if (e.key === "ArrowDown") {
			focusSibling("nextElementSibling");
			e.preventDefault();
		} else if (e.key === "ArrowUp") {
			focusSibling("previousElementSibling");
			e.preventDefault();
		}
	}, [isExpanded]);
	useEffect(() => {
		if (highlightedIndex && highlightedIndex >= MaxReferences + offset) setShowAllRefs(true);
	}, [highlightedIndex, offset]);
	useEffect(() => {
		if (setFocusOnFile && keyboardNavUsed) firstFileRef.current?.focus();
	}, [setFocusOnFile, keyboardNavUsed]);
	useEffect(() => {
		if (!keyboardNavUsed) document.getElementById(textAreaId)?.focus();
	}, [keyboardNavUsed]);
	const groupId = `${filePath}-${isDefinition ? "definition" : "reference"}-group`;
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("div", {
		className: clsx(CodeNavFileInformation_module_default.fileHeader, enableExpandCollapse && CodeNavFileInformation_module_default.fileHeaderExpandable),
		onClick: enableExpandCollapse ? () => setIsExpanded(!isExpanded) : void 0,
		onKeyDown,
		ref: firstFileRef,
		role: enableExpandCollapse ? "button" : void 0,
		tabIndex: 0,
		children: [/* @__PURE__ */ jsxs("div", {
			className: CodeNavFileInformation_module_default.flexRow,
			children: [isDefinition && currentRepo.id !== repo.id && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(GitHubAvatar, {
				square: true,
				src: repo.ownerAvatar,
				className: CodeNavFileInformation_module_default.repoAvatar,
				size: 16
			}), /* @__PURE__ */ jsx("div", {
				className: CodeNavFileInformation_module_default.repoName,
				children: repo.name
			})] }), /* @__PURE__ */ jsxs("button", {
				"aria-expanded": isExpanded,
				"aria-controls": groupId,
				className: CodeNavFileInformation_module_default.expandButton,
				children: [enableExpandCollapse && /* @__PURE__ */ jsx(Octicon, {
					"aria-hidden": "true",
					icon: isExpanded ? ChevronDownIcon : ChevronRightIcon
				}), /* @__PURE__ */ jsx("div", {
					className: CodeNavFileInformation_module_default.tableWrapper,
					children: /* @__PURE__ */ jsxs(Truncate, {
						"aria-label": `${isDefinition ? "Definitions" : "References"} in ${filePath !== currentPath ? filePath : "this file"}`,
						title: filePath,
						className: CodeNavFileInformation_module_default.truncatedPath,
						children: [
							"‎",
							!isFromCurrentRepo || filePath !== currentPath ? filePath : "In this file",
							"‎"
						]
					})
				})]
			})]
		}), results && !isExpanded && /* @__PURE__ */ jsx(CounterLabel, {
			className: CodeNavFileInformation_module_default.counterLabel,
			children: results.length
		})]
	}), isExpanded && /* @__PURE__ */ jsxs("div", {
		"aria-label": `Results in ${filePath !== currentPath ? filePath : "this file"}`,
		id: groupId,
		className: clsx(CodeNavFileInformation_module_default.resultsGroup, "code-nav-file-information"),
		role: "group",
		children: [
			initialVisibleRefs.map((reference, i) => {
				return /* @__PURE__ */ jsx(CodeNavCell, {
					reference,
					isHighlighted: highlightedIndex === i + offset,
					href: reference.href(hasBlame),
					onClick: () => {
						if (onClick) onClick(i + offset);
						sendRepoClickEvent("BLOB_SYMBOLS_MENU.SYMBOL_DEFINITION_CLICK");
					},
					symbol,
					index: i + offset
				}, `codeNavigation${i + offset}`);
			}),
			showAllRefs && hiddenRefs.map((reference_0, i_0) => {
				return /* @__PURE__ */ jsx(CodeNavCell, {
					reference: reference_0,
					isHighlighted: highlightedIndex === i_0 + offset + MaxReferences,
					href: reference_0.href(hasBlame),
					onClick: () => {
						if (onClick) onClick(i_0 + offset + MaxReferences);
						sendRepoClickEvent("BLOB_SYMBOLS_MENU.SYMBOL_DEFINITION_CLICK");
					},
					symbol,
					index: i_0 + offset + MaxReferences,
					focusElement: i_0 === 0
				}, `codeNavigation${i_0 + offset + MaxReferences}`);
			}),
			hiddenRefs.length > 0 && /* @__PURE__ */ jsx("div", {
				className: CodeNavFileInformation_module_default.showMoreWrapper,
				children: /* @__PURE__ */ jsx(ButtonComponent, {
					leadingVisual: showAllRefs ? FoldIcon : UnfoldIcon,
					onClick: () => setShowAllRefs(!showAllRefs),
					className: CodeNavFileInformation_module_default.showMoreButton,
					variant: "invisible",
					size: "small",
					"aria-selected": false,
					children: showAllRefs ? "Show less" : "Show more"
				})
			})
		]
	})] }, filePath);
}
CodeNavFileInformation.displayName = "CodeNavFileInformation";
function CodeNavInfoPanelData(t0) {
	const $ = c(12);
	const { definitions, references, highlightedIndex, initiallyExpanded, enableExpandCollapse, onClick, symbol, setFocusOnFile } = t0;
	let grouped;
	if ($[0] !== definitions || $[1] !== references) {
		grouped = {};
		if (definitions) for (const def of definitions) {
			const key = def.pathKey();
			if (!grouped[key]) grouped[key] = [];
			grouped[key].push(def);
		}
		else if (references) for (const ref of references) {
			const key_0 = ref.pathKey();
			if (!grouped[key_0]) grouped[key_0] = [];
			grouped[key_0].push(ref);
		}
		$[0] = definitions;
		$[1] = references;
		$[2] = grouped;
	} else grouped = $[2];
	const pathGrouped = grouped;
	let t1;
	if ($[3] !== definitions || $[4] !== enableExpandCollapse || $[5] !== highlightedIndex || $[6] !== initiallyExpanded || $[7] !== onClick || $[8] !== pathGrouped || $[9] !== setFocusOnFile || $[10] !== symbol) {
		let offset = 0;
		t1 = jsx(Fragment$1, { children: Object.keys(pathGrouped).map((key_1, i) => {
			const results = pathGrouped[key_1];
			const info = jsx(CodeNavFileInformation, {
				repo: results[0].repo,
				filePath: results[0].path,
				results,
				highlightedIndex,
				isDefinition: definitions !== void 0 && definitions.length > 0,
				onClick,
				offset,
				initiallyExpanded,
				enableExpandCollapse,
				symbol,
				setFocusOnFile: i === 0 && setFocusOnFile
			}, key_1);
			offset = offset + results.length;
			return info;
		}) });
		$[3] = definitions;
		$[4] = enableExpandCollapse;
		$[5] = highlightedIndex;
		$[6] = initiallyExpanded;
		$[7] = onClick;
		$[8] = pathGrouped;
		$[9] = setFocusOnFile;
		$[10] = symbol;
		$[11] = t1;
	} else t1 = $[11];
	return t1;
}
CodeNavInfoPanelData.displayName = "CodeNavInfoPanelData";
var CodeNavSymbolDetails_module_default = {
	backButton: "CodeNavSymbolDetails-module_zi_Dga_backButton",
	backButtonInner: "CodeNavSymbolDetails-module_zi_Dga_backButtonInner",
	backIcon: "CodeNavSymbolDetails-module_zi_Dga_backIcon",
	backText: "CodeNavSymbolDetails-module_zi_Dga_backText",
	closeButton: "CodeNavSymbolDetails-module_zi_Dga_closeButton",
	definitionHeader: "CodeNavSymbolDetails-module_zi_Dga_definitionHeader",
	definitionHeaderWrapper: "CodeNavSymbolDetails-module_zi_Dga_definitionHeaderWrapper",
	detailsHeading: "CodeNavSymbolDetails-module_zi_Dga_detailsHeading",
	emptyState: "CodeNavSymbolDetails-module_zi_Dga_emptyState",
	footer: "CodeNavSymbolDetails-module_zi_Dga_footer",
	navButtonNext: "CodeNavSymbolDetails-module_zi_Dga_navButtonNext",
	navButtonPrev: "CodeNavSymbolDetails-module_zi_Dga_navButtonPrev",
	navButtonWrapper: "CodeNavSymbolDetails-module_zi_Dga_navButtonWrapper",
	searchButton: "CodeNavSymbolDetails-module_zi_Dga_searchButton",
	sectionHeader: "CodeNavSymbolDetails-module_zi_Dga_sectionHeader",
	sectionHeading: "CodeNavSymbolDetails-module_zi_Dga_sectionHeading",
	sectionSearchType: "CodeNavSymbolDetails-module_zi_Dga_sectionSearchType",
	showMoreButton: "CodeNavSymbolDetails-module_zi_Dga_showMoreButton",
	spinnerWrapper: "CodeNavSymbolDetails-module_zi_Dga_spinnerWrapper",
	symbolIndicatorRow: "CodeNavSymbolDetails-module_zi_Dga_symbolIndicatorRow",
	symbolSegment: "CodeNavSymbolDetails-module_zi_Dga_symbolSegment",
	symbolSegmentClickable: "CodeNavSymbolDetails-module_zi_Dga_symbolSegmentClickable",
	symbolTruncate: "CodeNavSymbolDetails-module_zi_Dga_symbolTruncate"
};
var nonWordBoundaryRegex = /(\W+)/;
var nonWordOnlyRegex = /^\W+$/;
var MaxCrossReferenceFiles = 5;
var ScrollMarks = lazy(() => import("./server-ScrollMarks-DOQsLv1d-BpTJ15qq.js"));
ScrollMarks.displayName = "ScrollMarks";
function CodeNavSymbolDetails({ codeNavInfo, selectedText, lineNumber, offset, onClose, onBackToSymbol, onSymbolSelect, isLoading, setSearchResults, setFocusedSearchResult }) {
	const { findNextShortcut, findPrevShortcut } = useShortcut();
	const hasBlame = !!useCurrentBlame();
	const { definitions: defsResponse, localReferences: localRefsResponse, crossReferences: crossRefsResponse, error } = useCodeNav(codeNavInfo, selectedText, lineNumber, offset);
	const { copilotAccessAllowed } = useCopilotSettings();
	const [highlightedIndex, setHighlightedIndex] = useState(-1);
	const [showAllCrossRefs, setShowAllCrossRefs] = useState(false);
	const repo = useCurrentRepository();
	const definitions = useMemo(() => defsResponse?.definitions || [], [defsResponse?.definitions]);
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const references = useMemo(() => localRefsResponse?.references || [], [localRefsResponse]);
	const crossReferences = useMemo(() => crossRefsResponse?.references || [], [crossRefsResponse?.references]);
	const startReferenceIndex = definitions.length;
	const allReferencesCount = references.length + crossReferences.length;
	const nav = useNavigate$1();
	const currentSymbol = definitions.length > 0 ? definitions[0] : void 0;
	const crossRefFiles = useMemo(() => crossReferences.map((r) => r.path).filter((v, i, a) => a.indexOf(v) === i), [crossReferences]);
	const shownReferences = showAllCrossRefs ? allReferencesCount : references.length;
	const backToSymbolsRef = useRef(null);
	const { language, languageID } = useCurrentBlob();
	const messageReference = useMemo(() => ({
		type: "symbol",
		kind: "codeNavSymbol",
		name: selectedText,
		languageID,
		languageName: language,
		codeNavDefinitions: definitions.map((d) => ({
			ident: d.ident,
			extent: d.extent,
			kind: d.kind.fullName,
			fullyQualifiedName: d.fullyQualifiedName,
			ref: getRefName(d.refInfo),
			commitOID: d.refInfo.currentOid,
			repoID: d.repo.id,
			repoName: d.repo.name,
			repoOwner: d.repo.ownerLogin,
			path: d.path
		})),
		codeNavReferences: [...references.map((r_0) => ({
			ident: r_0.ident,
			path: r_0.path,
			ref: getRefName(r_0.refInfo),
			commitOID: r_0.refInfo.currentOid,
			repoID: r_0.repo.id,
			repoName: r_0.repo.name,
			repoOwner: r_0.repo.ownerLogin
		})), ...crossReferences.map((c) => ({
			ident: c.ident,
			path: c.path,
			ref: getRefName(c.refInfo),
			commitOID: c.refInfo.currentOid,
			repoID: c.repo.id,
			repoName: c.repo.name,
			repoOwner: c.repo.ownerLogin
		}))]
	}), [
		crossReferences,
		definitions,
		language,
		languageID,
		references,
		selectedText
	]);
	useEffect(() => {
		if (currentSymbol && currentSymbol.repo.name === codeNavInfo.repo.name && currentSymbol.path === codeNavInfo.path) setSearchResults([currentSymbol, ...references]);
		else setSearchResults(references);
		setFocusedSearchResult(void 0);
		window.dispatchEvent(new SymbolChangedEvent(messageReference));
	}, [
		codeNavInfo.path,
		codeNavInfo.repo.name,
		currentSymbol,
		references,
		selectedText,
		setSearchResults,
		setFocusedSearchResult,
		messageReference
	]);
	useFocusSymbolPane((focusSymbolSearch) => {
		if (!focusSymbolSearch) backToSymbolsRef.current?.focus();
	});
	useEffect(() => {
		setHighlightedIndex(-1);
	}, [selectedText]);
	useEffect(() => {
		setShowAllCrossRefs(crossRefFiles.length > 0 && crossRefFiles.length <= MaxCrossReferenceFiles);
	}, [crossRefFiles.length]);
	const onHighlight = ({ index, direction, navigate }) => {
		if (index !== void 0) {
			const currentRef = index >= startReferenceIndex ? references[index - startReferenceIndex] : definitions[index];
			setHighlightedIndex(index);
			if (navigate) nav(currentRef.href(hasBlame));
			scrollLineIntoView({
				line: currentRef.lineNumber,
				column: currentRef.ident.start.column
			});
		}
		if (direction !== void 0) {
			const newIndex = Math.max(startReferenceIndex, highlightedIndex + direction);
			const highlightedSymbol = references[newIndex - startReferenceIndex];
			if (newIndex < references.length + definitions.length && highlightedSymbol) {
				setHighlightedIndex(newIndex);
				if (navigate) nav(highlightedSymbol.href(hasBlame));
				scrollLineIntoView({
					line: highlightedSymbol.lineNumber,
					column: highlightedSymbol.ident.start.column
				});
			}
		}
	};
	return /* @__PURE__ */ jsxs("div", { children: [
		/* @__PURE__ */ jsxs("h2", {
			className: CodeNavSymbolDetails_module_default.detailsHeading,
			role: "group",
			"aria-roledescription": "Symbol Navigation Details",
			children: [/* @__PURE__ */ jsx(ButtonComponent, {
				onClick: onBackToSymbol,
				onSelect: onBackToSymbol,
				id: "back-to-all-symbols",
				"aria-label": "Back to All Symbols",
				ref: backToSymbolsRef,
				variant: "invisible",
				className: CodeNavSymbolDetails_module_default.backButton,
				children: /* @__PURE__ */ jsxs("div", {
					className: CodeNavSymbolDetails_module_default.backButtonInner,
					children: [/* @__PURE__ */ jsx(Octicon, {
						icon: ArrowLeftIcon,
						className: CodeNavSymbolDetails_module_default.backIcon,
						size: 20
					}), /* @__PURE__ */ jsx("span", {
						className: CodeNavSymbolDetails_module_default.backText,
						children: "All Symbols"
					})]
				})
			}), /* @__PURE__ */ jsx(IconButton, {
				"aria-label": "Close symbols",
				tooltipDirection: "w",
				"data-hotkey": "Escape",
				icon: XIcon,
				className: CodeNavSymbolDetails_module_default.closeButton,
				onClick: onClose,
				variant: "invisible"
			})]
		}),
		/* @__PURE__ */ jsx("div", {
			className: CodeNavSymbolDetails_module_default.definitionHeaderWrapper,
			children: /* @__PURE__ */ jsx(CodeNavSymbolDefinitionHeader, {
				currentSymbol,
				selectedText,
				codeNavInfo,
				onSymbolSelect,
				children: definitions.length === 1 ? /* @__PURE__ */ jsx(CopilotCodeLinesMenu, {
					copilotAccessAllowed,
					messageReference,
					decoupledModeEnabled
				}) : void 0
			})
		}),
		isLoading && /* @__PURE__ */ jsx("div", {
			className: CodeNavSymbolDetails_module_default.spinnerWrapper,
			children: /* @__PURE__ */ jsx(Spinner, { size: "small" })
		}),
		!error && !isLoading && definitions && definitions.length > 0 ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CodeNavSymbolSectionHeader, {
			headerText: definitions.length > 1 ? "Definitions" : "Definition",
			searchType: defsResponse?.backend === "precise" ? "Precise" : "Search"
		}), /* @__PURE__ */ jsx("div", { children: definitions && /* @__PURE__ */ jsx(CodeNavInfoPanelData, {
			definitions,
			onClick: (index_0) => {
				onHighlight({ index: index_0 });
			},
			highlightedIndex,
			initiallyExpanded: true,
			enableExpandCollapse: definitions.length > 1,
			symbol: selectedText,
			setFocusOnFile: true
		}, "definitions") })] }) : null,
		!isLoading && (references.length > 0 || crossReferences.length > 0) && /* @__PURE__ */ jsx(CodeNavSymbolSectionHeader, {
			headerText: `${shownReferences} ${shownReferences > 1 ? "References" : "Reference"}`,
			searchType: "Search",
			className: CodeNavSymbolDetails_module_default.sectionHeader,
			extraStyle: { justifyContent: "space-between" },
			children: /* @__PURE__ */ jsxs("div", {
				className: CodeNavSymbolDetails_module_default.navButtonWrapper,
				children: [
					/* @__PURE__ */ jsx(IconButton, {
						unsafeDisableTooltip: true,
						"aria-label": "Previous reference",
						"data-hotkey": findPrevShortcut.hotkey,
						onClick: () => onHighlight({
							direction: -1,
							navigate: true
						}),
						className: CodeNavSymbolDetails_module_default.navButtonPrev,
						disabled: highlightedIndex <= definitions.length,
						icon: ChevronUpIcon,
						variant: "invisible",
						size: "small"
					}),
					/* @__PURE__ */ jsx(IconButton, {
						unsafeDisableTooltip: true,
						"aria-label": "Next reference",
						"data-hotkey": findNextShortcut.hotkey,
						onClick: () => onHighlight({
							direction: 1,
							navigate: true
						}),
						className: CodeNavSymbolDetails_module_default.navButtonNext,
						disabled: highlightedIndex >= references.length + definitions.length - 1,
						icon: ChevronDownIcon,
						variant: "invisible",
						size: "small"
					}),
					/* @__PURE__ */ jsx("button", {
						hidden: true,
						"data-hotkey": findNextShortcut.hotkey,
						onClick: () => onHighlight({
							direction: 1,
							navigate: true
						}),
						"data-testid": "find-next-button"
					}),
					/* @__PURE__ */ jsx("button", {
						hidden: true,
						"data-hotkey": findPrevShortcut.hotkey,
						onClick: () => onHighlight({
							direction: -1,
							navigate: true
						}),
						"data-testid": "find-prev-button"
					})
				]
			})
		}),
		error && /* @__PURE__ */ jsx("div", {
			className: CodeNavSymbolDetails_module_default.emptyState,
			children: "No references found"
		}),
		!isLoading && references.length > 0 && /* @__PURE__ */ jsx(CodeNavInfoPanelData, {
			initiallyExpanded: true,
			enableExpandCollapse: true,
			references,
			highlightedIndex: highlightedIndex - startReferenceIndex,
			onClick: (index_1) => {
				onHighlight({ index: startReferenceIndex + index_1 });
			},
			symbol: selectedText,
			setFocusOnFile: !(definitions && definitions.length > 0)
		}, "referencesInfoBox"),
		!isLoading && showAllCrossRefs && /* @__PURE__ */ jsx(CodeNavInfoPanelData, {
			initiallyExpanded: false,
			enableExpandCollapse: true,
			references: crossReferences,
			symbol: selectedText
		}, "crossReferencesInfoBox"),
		references.length === 0 && definitions.length === 0 && !error && !isLoading && /* @__PURE__ */ jsx("div", {
			className: CodeNavSymbolDetails_module_default.emptyState,
			children: "No definitions or references found"
		}),
		/* @__PURE__ */ jsxs("div", {
			className: CodeNavSymbolDetails_module_default.footer,
			children: [crossRefFiles.length > MaxCrossReferenceFiles && /* @__PURE__ */ jsx(ButtonComponent, {
				leadingVisual: showAllCrossRefs ? FoldIcon : UnfoldIcon,
				className: CodeNavSymbolDetails_module_default.showMoreButton,
				variant: "invisible",
				size: "small",
				onClick: () => setShowAllCrossRefs(!showAllCrossRefs),
				children: showAllCrossRefs ? "Show less" : "Show more"
			}), /* @__PURE__ */ jsx(ButtonComponent, {
				as: Link,
				leadingVisual: SearchIcon,
				className: CodeNavSymbolDetails_module_default.searchButton,
				variant: "invisible",
				size: "small",
				href: codeNavSearchPath({
					owner: repo.ownerLogin,
					repo: repo.name,
					searchTerm: selectedText
				}),
				children: "Search for this symbol"
			})]
		}),
		/* @__PURE__ */ jsx(Suspense, {
			fallback: null,
			children: /* @__PURE__ */ jsx(ScrollMarks, { definitionsOrReferences: [...definitions, ...references] })
		})
	] });
}
CodeNavSymbolDetails.displayName = "CodeNavSymbolDetails";
function CodeNavSymbolSectionHeader({ headerText, searchType, className, extraStyle, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(CodeNavSymbolDetails_module_default.sectionHeader, className),
		style: extraStyle,
		children: [/* @__PURE__ */ jsxs("h3", {
			className: CodeNavSymbolDetails_module_default.sectionHeading,
			children: [headerText, /* @__PURE__ */ jsx("span", {
				className: CodeNavSymbolDetails_module_default.sectionSearchType,
				children: searchType
			})]
		}), children]
	});
}
CodeNavSymbolSectionHeader.displayName = "CodeNavSymbolSectionHeader";
function CodeNavSymbolDefinitionHeader({ currentSymbol, selectedText, codeNavInfo, onSymbolSelect, children }) {
	const fullSymbolText = currentSymbol?.fullyQualifiedName ?? selectedText;
	const symbolSegments = fullSymbolText.split(nonWordBoundaryRegex).map((segment) => {
		const isSeparator = nonWordOnlyRegex.test(segment);
		const foundDefinitions = !isSeparator ? codeNavInfo.getLocalDefinitions(segment, true) : [];
		const foundSymbol = foundDefinitions.length === 1 ? foundDefinitions[0] : void 0;
		return {
			text: segment,
			symbol: foundSymbol,
			symbolColor: foundSymbol?.kind.plColor,
			isSeparator
		};
	});
	return /* @__PURE__ */ jsxs("h3", {
		className: CodeNavSymbolDetails_module_default.definitionHeader,
		"aria-label": `${currentSymbol?.kind.fullName || ""} ${fullSymbolText}`.trimStart(),
		children: [currentSymbol && /* @__PURE__ */ jsxs("div", {
			className: CodeNavSymbolDetails_module_default.symbolIndicatorRow,
			children: [/* @__PURE__ */ jsx(SymbolIndicator, {
				symbolKind: currentSymbol.kind,
				showFullSymbol: true
			}), children]
		}), /* @__PURE__ */ jsxs(Truncate, {
			title: fullSymbolText,
			className: CodeNavSymbolDetails_module_default.symbolTruncate,
			inline: true,
			children: [
				"‎",
				symbolSegments.map((segment, index) => {
					return /* @__PURE__ */ jsx("span", {
						role: "button",
						tabIndex: segment.isSeparator ? -1 : 0,
						className: clsx(CodeNavSymbolDetails_module_default.symbolSegment, segment.symbol && CodeNavSymbolDetails_module_default.symbolSegmentClickable),
						style: { color: segment.symbolColor },
						onClick: () => segment.symbol ? onSymbolSelect(segment.symbol) : void 0,
						onKeyDown: (keyboardEvent) => {
							if (segment.symbol && ["Enter", "Space"].includes(keyboardEvent.code)) onSymbolSelect(segment.symbol);
						},
						children: segment.text
					}, `${segment.text}-${index}`);
				}),
				"‎"
			]
		})]
	});
}
CodeNavSymbolDefinitionHeader.displayName = "CodeNavSymbolDefinitionHeader";
function getRefName(refInfo) {
	return refInfo.name === refInfo.currentOid ? refInfo.currentOid : refInfo.refType === "tree" ? `refs/heads/${refInfo.name}` : qualifyRef(refInfo.name, refInfo.refType ?? "branch");
}
function CodeNavInfoPanel({ selectedText, showCodeNavWithSymbol, lineNumber, offset, onClose, onClear, codeNavInfo, isLoading, setSearchResults, setFocusedSearchResult, autoFocusSearch }) {
	const showCodeNavWithSymbolRef = useRef(showCodeNavWithSymbol);
	useEffect(() => {
		showCodeNavWithSymbolRef.current = showCodeNavWithSymbol;
	}, [showCodeNavWithSymbol]);
	const [showSymbolTree, setShowSymbolTree] = useState(selectedText ? false : true);
	const onSymbolSelect = useCallback((sym) => {
		showCodeNavWithSymbolRef.current(sym);
		setShowSymbolTree(false);
	}, []);
	useFocusSymbolPane((focusSymbolSearch) => {
		if (focusSymbolSearch) {
			onClear();
			startTransition(() => setShowSymbolTree(true));
			setSearchResults([]);
		}
	});
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	const { language, languageID, displayUrl } = useCurrentBlob();
	const fileReference = useMemo(() => ({
		type: "file",
		languageID,
		languageName: language,
		path,
		ref: qualifyRef(refInfo.name, refInfo.refType),
		commitOID: refInfo.currentOid,
		repoID: repo.id,
		repoName: repo.name,
		repoOwner: repo.ownerLogin,
		url: displayUrl
	}), [
		languageID,
		language,
		path,
		refInfo.name,
		refInfo.refType,
		refInfo.currentOid,
		repo.id,
		repo.name,
		repo.ownerLogin,
		displayUrl
	]);
	const handleSymbolChange = useEffectEvent(() => {
		if (selectedText) setShowSymbolTree(false);
		else if (!showSymbolTree) {
			window.dispatchEvent(new SymbolChangedEvent(fileReference));
			setShowSymbolTree(true);
		}
	});
	useEffect(() => {
		handleSymbolChange();
	}, [selectedText, codeNavInfo]);
	return /* @__PURE__ */ jsx("div", {
		id: "symbols-pane",
		children: showSymbolTree ? codeNavInfo ? /* @__PURE__ */ jsx(CodeNavSymbolNavigation, {
			treeSymbols: codeNavInfo.symbolTree,
			onSymbolSelect,
			codeSymbols: codeNavInfo.symbols,
			onClose,
			autoFocusSearch
		}) : /* @__PURE__ */ jsx("div", { children: "Click on a symbol to see code navigation data" }) : /* @__PURE__ */ jsx(CodeNavSymbolDetails, {
			codeNavInfo,
			selectedText,
			lineNumber,
			offset,
			onBackToSymbol: () => {
				onClear();
				startTransition(() => setShowSymbolTree(true));
				setSearchResults([]);
				window.dispatchEvent(new SymbolChangedEvent(fileReference));
			},
			onClose: () => {
				onClose();
				onClear();
				setSearchResults([]);
				window.dispatchEvent(new SymbolChangedEvent(fileReference));
			},
			onSymbolSelect,
			isLoading,
			setSearchResults,
			setFocusedSearchResult
		})
	});
}
CodeNavInfoPanel.displayName = "CodeNavInfoPanel";
var PanelContent = React.memo(PanelContentUnmemoized);
PanelContent.displayName = "PanelContent";
function PanelContentUnmemoized(props) {
	const $ = c(3);
	const { ...innerProps } = props;
	const [isNarrow, setIsNarrow] = React.useState(false);
	const { screenSize } = useScreenSize();
	let t0;
	let t1;
	if ($[0] !== screenSize) {
		t0 = () => {
			setIsNarrow(screenSize < ScreenSize.large);
		};
		t1 = [screenSize];
		$[0] = screenSize;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	React.useEffect(t0, t1);
	return jsxs(Fragment$1, { children: [!isNarrow && jsx(InnerPanelContent, {
		className: "inner-panel-content-not-narrow",
		...props
	}), isNarrow && jsx(Dialog, {
		onClose: () => innerProps.setOpenPanel(void 0),
		renderHeader: _temp,
		renderBody: () => InnerPanelContent({ ...innerProps })
	})] });
}
PanelContentUnmemoized.displayName = "PanelContentUnmemoized";
function _temp() {
	return null;
}
function InnerPanelContent(t0) {
	const $ = c(15);
	const { stickyStyle, stickyHeaderElement, openPanel, isCodeNavLoading, codeNavInfo, setOpenPanel, showCodeNavWithSymbol, searchingText, setSearchingText, setSearchResults, setFocusedSearchResult, autoFocusSearch, className } = t0;
	const { headerInfo: t1 } = useCurrentBlob();
	const { toc } = t1;
	const isStickied = useStickyObserver(stickyHeaderElement);
	let t2;
	if ($[0] !== autoFocusSearch || $[1] !== className || $[2] !== codeNavInfo || $[3] !== isCodeNavLoading || $[4] !== isStickied || $[5] !== openPanel || $[6] !== searchingText || $[7] !== setFocusedSearchResult || $[8] !== setOpenPanel || $[9] !== setSearchResults || $[10] !== setSearchingText || $[11] !== showCodeNavWithSymbol || $[12] !== stickyStyle || $[13] !== toc) {
		const borderStyle = isStickied ? {
			borderRadius: "0px 0px 6px 6px",
			borderTop: 0
		} : {};
		t2 = jsx(Panel, {
			style: {
				...stickyStyle,
				...borderStyle
			},
			className: `panel-content-narrow-styles ${className ? className : ""}`,
			children: openPanel === "toc" ? jsx(TableOfContentsPanel, {
				toc,
				onClose: () => {
					setOpenPanel(void 0);
				}
			}) : openPanel === "codeNav" && jsx(CodeNavInfoPanel, {
				codeNavInfo,
				showCodeNavWithSymbol,
				selectedText: searchingText.selectedText,
				lineNumber: searchingText.lineNumber - 1,
				offset: searchingText.offset,
				onClose: () => {
					setOpenPanel(void 0);
					localStorage.setItem("codeNavOpen", "");
					updateExpandPreferences(null, false, null);
					document.getElementById("symbols-button")?.focus();
				},
				isLoading: isCodeNavLoading,
				onClear: () => setSearchingText({
					selectedText: "",
					lineNumber: 0,
					offset: -1
				}),
				setSearchResults,
				setFocusedSearchResult,
				autoFocusSearch
			})
		});
		$[0] = autoFocusSearch;
		$[1] = className;
		$[2] = codeNavInfo;
		$[3] = isCodeNavLoading;
		$[4] = isStickied;
		$[5] = openPanel;
		$[6] = searchingText;
		$[7] = setFocusedSearchResult;
		$[8] = setOpenPanel;
		$[9] = setSearchResults;
		$[10] = setSearchingText;
		$[11] = showCodeNavWithSymbol;
		$[12] = stickyStyle;
		$[13] = toc;
		$[14] = t2;
	} else t2 = $[14];
	return t2;
}
InnerPanelContent.displayName = "InnerPanelContent";
function BlobViewContent({ blame, blob, symbolsExpanded, setValidCodeNav, showTree, treeToggleElement, validCodeNav, copilotInfo }) {
	const searchTerm = useSearchTerm();
	const setSearchTerm = useSetSearchTerm();
	const path = usePath();
	const symbolsEnabled = blob.symbolsEnabled;
	const [stickyHeaderElement, stickyHeaderRef] = useState(null);
	const stickyStyle = useStickyHeaderStyle();
	const [autoFocusSearch, setAutoFocusSearch] = useState(false);
	const [bannerProps, setBannerProps] = useState(null);
	const { openPanel, setOpenPanel } = useOpenPanel();
	const codeLinesHandleRef = useRef(null);
	const shouldOpenPanel = useCodeViewOptions().openSymbolsOption.enabled && symbolsEnabled;
	const { stylingDirectives, rawLines, colorizedLines } = useCurrentStyledBlob();
	const { screenSize } = useScreenSize();
	useFocusSymbolPane((focusSearch) => {
		if (focusSearch) setAutoFocusSearch(true);
	});
	const { sendRepoClickEvent } = useReposAnalytics();
	const isFirstRenderRef = useRef(true);
	const onPathChange = useEffectEvent(() => {
		if (!isFirstRenderRef.current) {
			setStickyLines(null, true);
			setSearchTerm("");
			setAutoFocusSearch(false);
			setSearchingText({
				selectedText: "",
				lineNumber: -1,
				offset: 0
			});
		} else {
			isFirstRenderRef.current = false;
			if (searchingText.selectedText && !openPanel && shouldOpenPanel && symbolsExpanded) openCodeNav();
		}
	});
	useEffect(() => {
		onPathChange();
	}, [path]);
	const onScrollEvent = useEffectEvent(() => {
		if (window.scrollY < 300) setStickyLines(null, true);
	});
	useEffect(() => {
		let ticking = false;
		const handler = () => {
			if (!ticking) {
				requestAnimationFrame(() => {
					onScrollEvent();
					ticking = false;
				});
				ticking = true;
			}
		};
		window.addEventListener("scroll", handler);
		return () => {
			window.removeEventListener("scroll", handler);
		};
	}, []);
	const hasBlame = !!useCurrentBlame();
	const { currentStickyLines, setStickyLines } = useStickyLines();
	const openCodeNav = useCallback(() => {
		if (!hasBlame && shouldOpenPanel) {
			setOpenPanel("codeNav");
			sendRepoClickEvent("BLOB_SYMBOLS_MENU.OPEN_WITH_SYMBOL");
			requestIdleCallback(() => localStorage.setItem("codeNavOpen", "codeNav"));
			updateExpandPreferences(null, true, null);
		}
	}, [
		hasBlame,
		shouldOpenPanel,
		setOpenPanel,
		sendRepoClickEvent
	]);
	const { isCodeNavLoading, codeNavInfo, showCodeNavWithSymbol, showCodeNavForToken, searchingText, setSearchingText } = useCodeNavigation(blob, openCodeNav, setValidCodeNav, ssrSafeLocation.hash, hasBlame);
	const { searchStatus, searchResults, setSearchResults, focusedSearchResult, setFocusedSearchResult } = useInFileSearchResults(codeNavInfo, searchTerm);
	const { headerInfo: { toc } } = blob;
	const hasRenderedWithNoOpenPanel = useMemo(() => ({ value: false }), [codeNavInfo]);
	hasRenderedWithNoOpenPanel.value = !openPanel || hasRenderedWithNoOpenPanel.value;
	const showPanel = openPanel !== void 0 && codeNavInfo && validCodeNav && !(codeNavInfo.symbols.length === 0 && openPanel === "codeNav" && !hasRenderedWithNoOpenPanel.value) && !(!toc && openPanel === "toc") && !(openPanel === "edit") && !(!symbolsEnabled && openPanel === "codeNav");
	const actualOpenPanel = showPanel ? openPanel : void 0;
	useEffect(() => {
		if (openPanel && !showPanel) setOpenPanel(void 0);
	}, [
		openPanel,
		setOpenPanel,
		showPanel
	]);
	useEffect(() => {
		try {
			sendEvent("blob-size", {
				lines: stylingDirectives?.length,
				truncatedSloc: blob.headerInfo?.lineInfo.truncatedSloc,
				truncatedLoc: blob.headerInfo?.lineInfo.truncatedLoc,
				length: rawLines?.reduce((total, line) => total + line.length, 0) ?? 0,
				humanLength: blob.headerInfo?.blobSize
			});
		} catch {}
	}, [
		blob,
		stylingDirectives,
		rawLines
	]);
	return /* @__PURE__ */ jsxs(CurrentLineRefMapProvider, { children: [
		codeNavInfo && /* @__PURE__ */ jsx(FindSymbolShortcut, { codeNavInfo }),
		/* @__PURE__ */ jsx(LatestCommitSingleLine, {}),
		bannerProps && /* @__PURE__ */ jsx("div", {
			className: "pr-mb-3",
			children: /* @__PURE__ */ jsx(Banner, { ...bannerProps })
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "d-flex flex-row",
			children: [/* @__PURE__ */ jsxs("div", {
				className: clsx("container", BlobViewContent_module_default.blobContainer, actualOpenPanel && codeNavInfo && screenSize > ScreenSize.medium && BlobViewContent_module_default.blobContainerWithPanel),
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: clsx("react-code-size-details-banner", BlobViewContent_module_default.codeSizeDetails),
						children: [/* @__PURE__ */ jsx(CodeSizeDetails, { className: "react-code-size-details-banner" }), /* @__PURE__ */ jsx(CopilotPopover, {
							copilotInfo,
							className: "react-code-size-details-banner",
							view: blame ? "blame" : "preview"
						})]
					}),
					/* @__PURE__ */ jsx("div", {
						className: clsx("react-blob-view-header-sticky", BlobViewContent_module_default.stickyHeader),
						id: stickyHeaderId,
						ref: stickyHeaderRef,
						children: /* @__PURE__ */ jsx(BlobViewHeader, {
							currentStickyLines,
							focusedSearchResult,
							openPanel: actualOpenPanel,
							searchingText,
							searchResults,
							setFocusedSearchResult,
							setOpenPanel,
							showTree,
							stickyHeaderElement,
							treeToggleElement,
							validCodeNav,
							copilotInfo,
							colorizedLines,
							onBannerChange: setBannerProps
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: BlobViewContent_module_default.blobContentWrapper,
						children: /* @__PURE__ */ jsx(BlobContent_default, {
							blobLinesHandle: codeLinesHandleRef,
							setOpenPanel,
							validCodeNav,
							codeNavInfo,
							onCodeNavTokenSelected: showCodeNavForToken,
							onLineStickOrUnstick: setStickyLines,
							searchResults,
							focusedSearchResult
						})
					})
				]
			}), actualOpenPanel && codeNavInfo ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", { className: BlobViewContent_module_default.symbolsPanelSpacer }), /* @__PURE__ */ jsx(PanelContent, {
				stickyStyle,
				stickyHeaderElement,
				openPanel: actualOpenPanel,
				isCodeNavLoading,
				codeNavInfo,
				setOpenPanel,
				showCodeNavWithSymbol,
				searchingText,
				setSearchingText,
				searchResults,
				searchStatus,
				setSearchResults,
				setFocusedSearchResult,
				autoFocusSearch
			})] }) : null]
		})
	] });
}
BlobViewContent.displayName = "BlobViewContent";
function FindSymbolShortcut(t0) {
	const $ = c(6);
	const { codeNavInfo } = t0;
	const { sendRepoKeyDownEvent } = useReposAnalytics();
	const { findSymbolShortcut } = useShortcut();
	const setOpenPanel = useSetOpenPanel();
	if (codeNavInfo.symbols.length === 0) return null;
	let t1;
	if ($[0] !== sendRepoKeyDownEvent || $[1] !== setOpenPanel) {
		t1 = () => {
			setOpenPanel("codeNav");
			focusSymbolSearch();
			sendRepoKeyDownEvent("FIND_SYMBOL");
		};
		$[0] = sendRepoKeyDownEvent;
		$[1] = setOpenPanel;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== findSymbolShortcut.hotkey || $[4] !== t1) {
		t2 = jsx(DuplicateOnKeydownButton, {
			buttonFocusId: textAreaId,
			buttonHotkey: findSymbolShortcut.hotkey,
			onButtonClick: t1
		});
		$[3] = findSymbolShortcut.hotkey;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
FindSymbolShortcut.displayName = "FindSymbolShortcut";
export { ContributorsProvider as n, BlobViewContent as t };
