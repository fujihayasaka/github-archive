import { a as ssrSafeWindow } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { r as getFetchNonceHeaders } from "./server-fetch-nonce-CQRTCHX--Bxo3Ybl_.js";
var version = ssrSafeWindow?.document?.head?.querySelector("meta[name=\"release\"]")?.content || "";
var CLIENT_VERSION_HTTP_HEADER = "X-GitHub-Client-Version";
function getClientVersion() {
	return version;
}
function getBaseFetchHeaders(nonceToValidate) {
	let headers = {
		"X-Requested-With": "XMLHttpRequest",
		...getFetchNonceHeaders(nonceToValidate)
	};
	headers = {
		...headers,
		[CLIENT_VERSION_HTTP_HEADER]: getClientVersion()
	};
	return headers;
}
function addBaseFetchHeaders(headers, nonceToValidate) {
	const fetchHeaders = getBaseFetchHeaders(nonceToValidate);
	for (const [header, value] of Object.entries(fetchHeaders)) headers.set(header, value);
}
function getAppTypeHeader(appType) {
	return { "X-GitHub-App-Type": appType };
}
export { getClientVersion as i, getAppTypeHeader as n, getBaseFetchHeaders as r, addBaseFetchHeaders as t };
