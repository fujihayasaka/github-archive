import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { t as LoadingFallback } from "./server-SuspenseFallback-CKhZbbQP-DbruduCY.js";
import { n as useTreePaneContext } from "./server-TreePaneContext-MOIvJhA_-D8RrGzg2.js";
import { Suspense, lazy } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var BlobEditor = lazy(() => import("./server-BlobEditor-b_h3z-tU-Cb1RfzCf.js"));
BlobEditor.displayName = "BlobEditor";
function CodeViewEditor(t0) {
	const $ = c(10);
	const { editInfo, path, webCommitInfo, copilotInfo, copilotGenerateCommitMessageAuthInfo } = t0;
	const repo = useCurrentRepository();
	const { isTreeExpanded, collapseTree, treeToggleElement } = useTreePaneContext();
	let t1;
	if ($[0] !== collapseTree || $[1] !== copilotGenerateCommitMessageAuthInfo || $[2] !== copilotInfo || $[3] !== editInfo || $[4] !== isTreeExpanded || $[5] !== path || $[6] !== repo || $[7] !== treeToggleElement || $[8] !== webCommitInfo) {
		t1 = jsx(Suspense, {
			fallback: jsx(LoadingFallback, {}),
			children: jsx(BlobEditor, {
				collapseTree,
				editInfo,
				repo,
				showTree: isTreeExpanded,
				treeToggleElement,
				webCommitInfo,
				copilotInfo,
				copilotGenerateCommitMessageAuthInfo,
				isDataRouter: true
			}, `${path}_${editInfo.fileName}_${editInfo.isNewFile}`)
		});
		$[0] = collapseTree;
		$[1] = copilotGenerateCommitMessageAuthInfo;
		$[2] = copilotInfo;
		$[3] = editInfo;
		$[4] = isTreeExpanded;
		$[5] = path;
		$[6] = repo;
		$[7] = treeToggleElement;
		$[8] = webCommitInfo;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
CodeViewEditor.displayName = "CodeViewEditor";
export { CodeViewEditor as t };
