import { r as mainQuery } from "./server-data-router-application-BuxpKT7l-DbqISTam.js";
import { n as dashboardSurfaceAppBuilder, t as PULLS_PATH } from "./server-pulls-dashboard-surface-content-route-CY12u0dp-B-R1iWh6.js";
var pullsDashboardSurfaceLayoutRoute = dashboardSurfaceAppBuilder.createQueryRouteConfig("pullsDashboardSurfaceLayoutRoute", {
	path: PULLS_PATH,
	queries: [mainQuery({
		queryDeps: ({ pathname }) => ({ pathname: `${pathname}/_layout` }),
		staleTimeForNavigation: 36e4
	})]
});
export { pullsDashboardSurfaceLayoutRoute as t };
