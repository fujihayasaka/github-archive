import { n as getFetchNonce } from "./server-fetch-nonce-CQRTCHX--Bxo3Ybl_.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { jsx } from "react/jsx-runtime";
function IncludeFragment({ ref, children, src, ...props }) {
	const { isServer: isSSR } = useRuntimeEnvironment();
	return /* @__PURE__ */ jsx("include-fragment", {
		...props,
		ref,
		...isSSR ? {} : {
			src,
			"data-nonce": getFetchNonce()
		},
		children
	});
}
IncludeFragment.displayName = "IncludeFragment";
export { IncludeFragment as t };
