import { n as ssrSafeDocument } from "./server-ssr-globals-DlySjvFT-B6Cg9lQa.js";
import { t as announce$1 } from "./server-aria-live-CMK5TBsN-CVFXOjED.js";
function setTitle(title) {
	if (!ssrSafeDocument) return;
	const oldTitle = ssrSafeDocument.querySelector("title");
	const newTitle = ssrSafeDocument.createElement("title");
	newTitle.textContent = title;
	if (!oldTitle) {
		ssrSafeDocument.head.appendChild(newTitle);
		announce$1(title);
	} else if (oldTitle.textContent !== title) {
		oldTitle.replaceWith(newTitle);
		announce$1(title);
	}
}
function addGitHubToTitle(title) {
	if (document.body.classList.contains("logged-out")) return `${title} · GitHub`;
	return title;
}
export { setTitle as n, addGitHubToTitle as t };
