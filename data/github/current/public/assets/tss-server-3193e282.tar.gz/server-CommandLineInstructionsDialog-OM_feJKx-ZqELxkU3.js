performance.mark("js-parse-end:server-CommandLineInstructionsDialog-OM_feJKx-ZqELxkU3.js");
import { Qt as Heading$2, bn as Link, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { n as TextInput$1 } from "./server-TextInput-CcIRjeB_-6bd7WOts.js";
import { t as SegmentedControl } from "./server-SegmentedControl-Co291CU9-BrdD3nwE.js";
import { f as useSuspenseQuery, s as useMutation, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { i as usePageDataUrl, r as usePageDataContext, t as PageData } from "./server-use-page-data-url-DgRUryAI-B7V9LWvy.js";
import { n as fetchWithTracing, t as fetchWithErrorHandling } from "./server-fetch-with-tracing-3hVSSzDH-28Oq6ijK.js";
import { useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:CommandLineInstructionsDialog-OM_feJKx.js");
function useMergeInstructionsPageDataQueryKey(baseRefName) {
	const $ = c(3);
	const { basePageDataUrl } = usePageDataContext();
	const t0 = `basePageDataURL:${basePageDataUrl}`;
	const t1 = `baseRefName:${baseRefName}`;
	let t2;
	if ($[0] !== t0 || $[1] !== t1) {
		t2 = [
			PageData.mergeInstructions,
			t0,
			t1
		];
		$[0] = t0;
		$[1] = t1;
		$[2] = t2;
	} else t2 = $[2];
	return t2;
}
function useMergeInstructionsPageData(baseRefName) {
	const $ = c(7);
	const apiURL = usePageDataUrl(PageData.mergeInstructions);
	const queryKey = useMergeInstructionsPageDataQueryKey(baseRefName);
	const queryClient = useQueryClient();
	let t0;
	if ($[0] !== apiURL || $[1] !== queryClient || $[2] !== queryKey) {
		t0 = async () => fetchWithTracing(apiURL, queryKey, queryClient);
		$[0] = apiURL;
		$[1] = queryClient;
		$[2] = queryKey;
		$[3] = t0;
	} else t0 = $[3];
	let t1;
	if ($[4] !== queryKey || $[5] !== t0) {
		t1 = {
			queryKey,
			queryFn: t0,
			staleTime: Infinity
		};
		$[4] = queryKey;
		$[5] = t0;
		$[6] = t1;
	} else t1 = $[6];
	return useSuspenseQuery(t1);
}
function useSetDefaultProtocol(baseRefName) {
	const $ = c(3);
	const mergeInstructionsPageDataQueryKey = useMergeInstructionsPageDataQueryKey(baseRefName);
	const queryClient = useQueryClient();
	let t0;
	if ($[0] !== mergeInstructionsPageDataQueryKey || $[1] !== queryClient) {
		t0 = {
			mutationFn: _temp$1,
			onSuccess: () => queryClient.invalidateQueries({ queryKey: mergeInstructionsPageDataQueryKey }, { cancelRefetch: false })
		};
		$[0] = mergeInstructionsPageDataQueryKey;
		$[1] = queryClient;
		$[2] = t0;
	} else t0 = $[2];
	return useMutation(t0);
}
async function _temp$1(apiURL) {
	return fetchWithErrorHandling(apiURL, {
		method: "POST",
		headers: { Accept: "application/json" }
	});
}
var CommandLineInstructionsDialog_module_default = {
	commandWrapper: "CommandLineInstructionsDialog-module_BWzuyW_commandWrapper",
	header: "CommandLineInstructionsDialog-module_BWzuyW_header",
	instruction: "CommandLineInstructionsDialog-module_BWzuyW_instruction"
};
/**
* The outer command line instructions dialog, which contains an error boundary
*/
function CommandLineInstructionsDialog(props) {
	return /* @__PURE__ */ jsx(ErrorBoundary, {
		boundaryName: "CommandLineInstructionsDialog",
		fallback: /* @__PURE__ */ jsx(Dialog, {
			width: "xlarge",
			height: "auto",
			role: "dialog",
			onClose: props.onClose,
			returnFocusRef: props.returnFocusRef,
			title: "Merging via command line",
			children: /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
				/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(AlertIcon, {
					size: 24,
					className: "fgColor-muted tmp-mt-3 tmp-mb-3"
				}) }),
				/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: /* @__PURE__ */ jsx("strong", { children: "Unable to load the merge instructions" }) }),
				/* @__PURE__ */ jsx("div", {
					className: "mb-n2",
					children: /* @__PURE__ */ jsxs(BlankslateContainer.Description, { children: [
						"Try refreshing the page or if the problem persists",
						" ",
						/* @__PURE__ */ jsxs("a", {
							className: "fgColor-muted",
							href: "https://support.github.com/",
							children: [/* @__PURE__ */ jsx("u", { children: "contact support" }), " "]
						})
					] })
				})
			] })
		}),
		children: /* @__PURE__ */ jsx(CommandLineInstructionsDialogInner, { ...props })
	});
}
/**
* The inner command line instructions dialog, which fetches data
* Exists so that the `CommandLineInstructionsDialog` can manage its own error state
*/
CommandLineInstructionsDialog.displayName = "CommandLineInstructionsDialog";
function CommandLineInstructionsDialogInner(t0) {
	const $ = c(13);
	const { baseRefName, conflictsCondition, headRepository, isCrossRepo, onClose, returnFocusRef } = t0;
	const { data: t1 } = useMergeInstructionsPageData(baseRefName);
	const { crossRepoPatchUrl, patchUrl, pushProtocols, resolvingMergeConflictsDocsUrl, shellEscapingDocsUrl, shellSafeBaseRefName, shellSafeCrossRepoHeadRefName, shellSafeHeadRefName, shellSafeNamesIncludePlaceholders } = t1;
	let t2;
	if ($[0] !== pushProtocols) {
		t2 = pushProtocols.find(_temp);
		$[0] = pushProtocols;
		$[1] = t2;
	} else t2 = $[1];
	const [selectedProtocolType, setSelectedProtocolType] = useState(headRepository ? t2?.protocol ?? "PATCH" : "PATCH");
	const hasConflicts = conflictsCondition?.result === "FAILED";
	let t3;
	if ($[2] !== selectedProtocolType) {
		t3 = (p_0) => p_0.protocol === selectedProtocolType;
		$[2] = selectedProtocolType;
		$[3] = t3;
	} else t3 = $[3];
	const selectedProtocol = pushProtocols.find(t3);
	const httpProtocol = pushProtocols.find(_temp2);
	const sshProtocol = pushProtocols.find(_temp3);
	const sshIsAvailable = (headRepository && sshProtocol?.isAvailable) ?? false;
	const httpsIsAvailable = (headRepository && httpProtocol?.isAvailable) ?? false;
	const { mutate: setProtocolFromUrl } = useSetDefaultProtocol(baseRefName);
	const getCloneUrl = function getCloneUrl() {
		if (selectedProtocolType === "PATCH") return isCrossRepo ? crossRepoPatchUrl : patchUrl;
		else return selectedProtocol?.url ?? patchUrl;
	};
	let t4;
	if ($[4] !== pushProtocols || $[5] !== setProtocolFromUrl) {
		t4 = (protocol) => {
			setSelectedProtocolType(protocol);
			const apiURL = pushProtocols.find((p_3) => p_3.protocol === protocol)?.stickyUrl;
			if (apiURL) setProtocolFromUrl(apiURL);
		};
		$[4] = pushProtocols;
		$[5] = setProtocolFromUrl;
		$[6] = t4;
	} else t4 = $[6];
	const setPersistableProtocol = t4;
	const cloneUrl = getCloneUrl();
	let t5;
	if ($[7] !== hasConflicts || $[8] !== onClose || $[9] !== shellEscapingDocsUrl || $[10] !== shellSafeNamesIncludePlaceholders) {
		t5 = (t6) => {
			const { dialogDescriptionId, dialogLabelId } = t6;
			return jsx(Dialog.Header, {
				id: dialogLabelId,
				className: CommandLineInstructionsDialog_module_default.header,
				children: jsxs("div", {
					className: "d-flex",
					children: [jsxs("div", {
						className: "d-flex flex-column px-2 py-1 flex-grow-1",
						children: [jsx(Dialog.Title, { children: hasConflicts ? "Checkout via the command line" : "Merging via command line" }), jsxs(Dialog.Subtitle, {
							id: dialogDescriptionId,
							children: ["If you do not want to use the merge button or an automatic merge cannot be performed, you can perform a manual merge on the command line. However, the following steps are not applicable if the base branch is protected.", shellSafeNamesIncludePlaceholders && jsxs(Fragment$1, { children: [" ", jsx(Link, {
								href: shellEscapingDocsUrl,
								children: "Learn about dealing with special characters on the command line."
							})] })]
						})]
					}), jsx(Dialog.CloseButton, { onClose })]
				})
			});
		};
		$[7] = hasConflicts;
		$[8] = onClose;
		$[9] = shellEscapingDocsUrl;
		$[10] = shellSafeNamesIncludePlaceholders;
		$[11] = t5;
	} else t5 = $[11];
	let t6;
	if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => setSelectedProtocolType("PATCH");
		$[12] = t6;
	} else t6 = $[12];
	return jsxs(Dialog, {
		width: "xlarge",
		height: "auto",
		role: "dialog",
		onClose,
		returnFocusRef,
		renderHeader: t5,
		children: [
			jsx(Heading$2, {
				as: "h3",
				className: "h5 pb-1",
				children: "URL"
			}),
			jsxs("div", {
				className: "d-flex flex-items-center gap-2",
				children: [
					jsxs(SegmentedControl, {
						"aria-label": "Select merge option",
						children: [
							httpsIsAvailable && jsx(SegmentedControl.Button, {
								selected: "HTTP" === selectedProtocolType,
								onClick: () => setPersistableProtocol("HTTP"),
								children: "HTTPS"
							}),
							sshIsAvailable && jsx(SegmentedControl.Button, {
								selected: "SSH" === selectedProtocolType,
								onClick: () => setPersistableProtocol("SSH"),
								children: "SSH"
							}),
							jsx(SegmentedControl.Button, {
								selected: "PATCH" === selectedProtocolType,
								onClick: t6,
								children: "Patch"
							})
						]
					}),
					jsx(TextInput$1, {
						"aria-label": "Clone URL",
						className: "flex-1 f6",
						monospace: true,
						value: cloneUrl,
						readOnly: true
					}),
					jsx(CopyToClipboardButton, {
						ariaLabel: "Copy clone URL",
						textToCopy: cloneUrl
					})
				]
			}),
			jsx(Instructions, {
				cloneUrl,
				crossRepoPatchUrl,
				hasConflicts,
				isCrossRepo,
				resolvingMergeConflictsDocsUrl,
				selectedProtocolType,
				shellSafeBaseRefName,
				shellSafeCrossRepoHeadRefName,
				shellSafeHeadRefName
			})
		]
	});
}
/**
* Renders the correct instructions based on the pull request conditions
*/
CommandLineInstructionsDialogInner.displayName = "CommandLineInstructionsDialogInner";
function _temp3(p_2) {
	return p_2.protocol === "SSH";
}
function _temp2(p_1) {
	return p_1.protocol === "HTTP";
}
function _temp(p) {
	return p.isAvailable && p.isDefault;
}
function Instructions({ cloneUrl, crossRepoPatchUrl, hasConflicts, isCrossRepo, resolvingMergeConflictsDocsUrl, selectedProtocolType, shellSafeBaseRefName, shellSafeCrossRepoHeadRefName, shellSafeHeadRefName }) {
	switch (true) {
		case isCrossRepo: return /* @__PURE__ */ jsx(CrossRepoInstructions, {
			cloneUrl,
			crossRepoPatchUrl,
			selectedProtocolType,
			shellSafeBaseRefName,
			shellSafeCrossRepoHeadRefName,
			shellSafeHeadRefName
		});
		case hasConflicts: return /* @__PURE__ */ jsx(MergeConflictsInstructions, {
			shellSafeBaseRefName,
			shellSafeHeadRefName,
			resolvingMergeConflictsDocsUrl
		});
		default: return /* @__PURE__ */ jsx(StandardMergeInstructions, {
			shellSafeBaseRefName,
			shellSafeHeadRefName
		});
	}
}
/**
* Cross Repo Instructions
*/
Instructions.displayName = "Instructions";
function CrossRepoInstructions({ cloneUrl, crossRepoPatchUrl, selectedProtocolType, shellSafeBaseRefName, shellSafeCrossRepoHeadRefName, shellSafeHeadRefName }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(CommandLineInstructionStep, {
		stepNumber: 1,
		instruction: "From your project repository, check out a new branch and test the changes.",
		commands: [`git checkout -b ${shellSafeCrossRepoHeadRefName} ${shellSafeBaseRefName}`, selectedProtocolType === "PATCH" ? `curl -L ${crossRepoPatchUrl} | git am -3` : `git pull ${cloneUrl} ${shellSafeHeadRefName}`],
		copyButtonAriaLabel: "Copy command"
	}), /* @__PURE__ */ jsx(CommandLineInstructionStep, {
		stepNumber: 2,
		instruction: "Merge the changes and update on GitHub.",
		commands: [
			`git checkout ${shellSafeBaseRefName}`,
			`git merge --no-ff ${shellSafeCrossRepoHeadRefName}`,
			`git push origin ${shellSafeBaseRefName}`
		],
		copyButtonAriaLabel: "Copy command"
	})] });
}
/**
* Merge Conflicts Instructions
*/
CrossRepoInstructions.displayName = "CrossRepoInstructions";
function MergeConflictsInstructions({ resolvingMergeConflictsDocsUrl, shellSafeBaseRefName, shellSafeHeadRefName }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 1,
			instruction: "Clone the repository or update your local repository with the latest changes.",
			commands: [`git pull origin ${shellSafeBaseRefName}`],
			copyButtonAriaLabel: "Copy clone command"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 2,
			instruction: "Switch to the head branch of the pull request.",
			commands: [`git checkout ${shellSafeHeadRefName}`],
			copyButtonAriaLabel: "Copy checkout command"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 3,
			instruction: "Merge the base branch into the head branch.",
			commands: [`git merge ${shellSafeBaseRefName}`],
			copyButtonAriaLabel: "Copy merge command"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 4,
			instruction: "Fix the conflicts and commit the result.",
			customHelpText: /* @__PURE__ */ jsxs("span", { children: [
				"See ",
				/* @__PURE__ */ jsx("a", {
					href: resolvingMergeConflictsDocsUrl,
					children: "Resolving a merge conflict using the command line"
				}),
				" for step-by-step instructions on resolving merge conflicts."
			] })
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 5,
			instruction: "Push the changes.",
			commands: [`git push -u origin ${shellSafeHeadRefName}`],
			copyButtonAriaLabel: "Copy push command"
		})
	] });
}
/**
*
* Standard Merge Instructions
*/
MergeConflictsInstructions.displayName = "MergeConflictsInstructions";
function StandardMergeInstructions({ shellSafeHeadRefName, shellSafeBaseRefName }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 1,
			instruction: "Clone the repository or update your local repository with the latest changes.",
			commands: [`git pull origin ${shellSafeBaseRefName}`],
			copyButtonAriaLabel: "Copy clone command}"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 2,
			instruction: "Switch to the base branch of the pull request.",
			commands: [`git checkout ${shellSafeBaseRefName}`],
			copyButtonAriaLabel: "Copy checkout command"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 3,
			instruction: "Merge the head branch into the base branch.",
			commands: [`git merge ${shellSafeHeadRefName}`],
			copyButtonAriaLabel: "Copy merge command"
		}),
		/* @__PURE__ */ jsx(CommandLineInstructionStep, {
			stepNumber: 4,
			instruction: "Push the changes.",
			commands: [`git push -u origin ${shellSafeBaseRefName}`],
			copyButtonAriaLabel: "Copy push command"
		})
	] });
}
/**
* Displays an instruction with step and command information
*/
StandardMergeInstructions.displayName = "StandardMergeInstructions";
function CommandLineInstructionStep({ stepNumber, instruction, commands, copyButtonAriaLabel, customHelpText }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "tmp-mt-3",
		children: [
			/* @__PURE__ */ jsxs("p", { children: [
				/* @__PURE__ */ jsxs("span", {
					className: "text-bold",
					children: ["Step ", stepNumber]
				}),
				" ",
				instruction
			] }),
			commands && commands?.length > 0 && copyButtonAriaLabel && /* @__PURE__ */ jsxs("div", {
				className: "bgColor-muted rounded-2 d-flex flex-items-center flex-justify-between tmp-mb-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: clsx("text-mono f6 tmp-ml-3 tmp-my-3 pb-1 flex-shrink-1", CommandLineInstructionsDialog_module_default.commandWrapper),
					children: commands.map((command) => /* @__PURE__ */ jsx("span", {
						className: clsx(CommandLineInstructionsDialog_module_default.instruction, "d-block"),
						children: command
					}, command))
				}), /* @__PURE__ */ jsx(CopyToClipboardButton, {
					className: "tmp-m-3",
					ariaLabel: copyButtonAriaLabel,
					textToCopy: commands.join("\n"),
					variant: "invisible",
					size: "small"
				})]
			}),
			customHelpText
		]
	});
}
CommandLineInstructionStep.displayName = "CommandLineInstructionStep";
export { CommandLineInstructionsDialog as default };
