import { a as useFeatureFlag, o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, l as VisuallyHidden, o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Vi as useOnEscapePress, _n as KebabHorizontalIcon, an as IconButton, hi as TriangleDownIcon, n as ActionList } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useOnOutsideClick } from "./server-useOnOutsideClick-DKLusJ3D-nDHIGoWL.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { o as useResizeObserver } from "./server-AnchoredOverlay-CurqbfUb-D4bJVBOh.js";
import { n as useMergedRefs } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { i as UnderlineWrapper, n as UnderlineItem, r as UnderlineItemList, t as LoadingCounter } from "./server-UnderlineTabbedInterface-DC_dAMgC-BEh05ZXU.js";
import React, { createContext, forwardRef, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { getAnchoredPosition } from "@primer/behaviors";
var UnderlineNavContext = /* @__PURE__ */ createContext({
	setChildrenWidth: () => null,
	setNoIconChildrenWidth: () => null,
	loadingCounters: false,
	iconsVisible: true
});
var dividerStyles = {
	display: "inline-block",
	borderLeft: "1px solid",
	width: "1px",
	borderLeftColor: "var(--borderColor-muted)",
	marginRight: "var(--base-size-4)",
	height: "24px"
};
var menuItemStyles = {
	"& > span": { display: "none" },
	textDecoration: "none"
};
var classes$3 = {
	"MenuItemContent": "prc-UnderlineNav-MenuItemContent-3J7gB",
	"MoreButton": "prc-UnderlineNav-MoreButton-Y8soj"
};
var MORE_BTN_HEIGHT = 45;
var overflowEffect = (navWidth, moreMenuWidth, childArray, childWidthArray, noIconChildWidthArray, updateListAndMenu) => {
	let iconsVisible = true;
	if (childWidthArray.length === 0) {
		updateListAndMenu({
			items: childArray,
			menuItems: []
		}, iconsVisible, false);
		return;
	}
	const numberOfItemsPossible = calculatePossibleItems(childWidthArray, navWidth);
	const numberOfItemsWithoutIconPossible = calculatePossibleItems(noIconChildWidthArray, navWidth);
	const numberOfItemsPossibleWithMoreMenu = calculatePossibleItems(noIconChildWidthArray, navWidth, moreMenuWidth || 86);
	const items = [];
	const menuItems = [];
	if (childArray.length <= numberOfItemsPossible) items.push(...childArray);
	else if (childArray.length <= numberOfItemsWithoutIconPossible) {
		iconsVisible = false;
		items.push(...childArray);
	} else {
		iconsVisible = false;
		const numberOfListItems = childArray.length - numberOfItemsPossibleWithMoreMenu === 1 ? numberOfItemsPossibleWithMoreMenu - 1 : numberOfItemsPossibleWithMoreMenu;
		for (const [index, child] of childArray.entries()) if (index < numberOfListItems) items.push(child);
		else {
			const ariaCurrent = child.props["aria-current"];
			if (Boolean(ariaCurrent) && ariaCurrent !== "false" && numberOfListItems > 0) {
				const indexToReplaceAt = numberOfListItems - 1;
				const propsectiveAction = items.splice(indexToReplaceAt, 1, child)[0];
				menuItems.push(propsectiveAction);
			} else menuItems.push(child);
		}
	}
	updateListAndMenu({
		items,
		menuItems
	}, iconsVisible, true);
};
var getValidChildren$1 = (children) => {
	return React.Children.toArray(children).filter((child) => /* @__PURE__ */ React.isValidElement(child));
};
var calculatePossibleItems = (childWidthArray, navWidth, moreMenuWidth = 0) => {
	const widthToFit = navWidth - moreMenuWidth;
	let breakpoint = childWidthArray.length;
	let sumsOfChildWidth = 0;
	for (const [index, childWidth] of childWidthArray.entries()) {
		sumsOfChildWidth = sumsOfChildWidth + childWidth.width + 8;
		if (sumsOfChildWidth > widthToFit) {
			breakpoint = index;
			break;
		} else continue;
	}
	return breakpoint;
};
var baseMenuInlineStyles = {
	position: "absolute",
	zIndex: 1,
	top: "90%",
	boxShadow: "0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)",
	borderRadius: 12,
	background: "var(--overlay-bgColor)",
	listStyle: "none",
	minWidth: `192px`,
	maxWidth: "640px",
	right: 0
};
var UnderlineNav$1 = /* @__PURE__ */ forwardRef(({ as = "nav", "aria-label": ariaLabel, loadingCounters = false, variant = "inset", className, children }, forwardedRef) => {
	var _listRef$current2;
	const backupRef = useRef(null);
	const navRef = forwardedRef !== null && forwardedRef !== void 0 ? forwardedRef : backupRef;
	const listRef = useRef(null);
	const moreMenuRef = useRef(null);
	const moreMenuBtnRef = useRef(null);
	const containerRef = React.useRef(null);
	const disclosureWidgetId = useId$1();
	const [isWidgetOpen, setIsWidgetOpen] = useState(false);
	const [iconsVisible, setIconsVisible] = useState(true);
	const [childWidthArray, setChildWidthArray] = useState([]);
	const [noIconChildWidthArray, setNoIconChildWidthArray] = useState([]);
	const [isOverflowMeasured, setIsOverflowMeasured] = useState(false);
	const validChildren = getValidChildren$1(children);
	const [responsiveProps, setResponsiveProps] = useState({
		items: validChildren,
		menuItems: []
	});
	const listItems = responsiveProps.items.map((item) => {
		var _validChildren$find;
		return (_validChildren$find = validChildren.find((child) => child.key === item.key)) !== null && _validChildren$find !== void 0 ? _validChildren$find : item;
	});
	const menuItems = responsiveProps.menuItems.map((menuItem) => {
		var _validChildren$find2;
		return (_validChildren$find2 = validChildren.find((child) => child.key === menuItem.key)) !== null && _validChildren$find2 !== void 0 ? _validChildren$find2 : menuItem;
	});
	const onlyMenuVisible = responsiveProps.items.length === 0;
	function getItemsWidth(itemText) {
		var _noIconChildWidthArra, _noIconChildWidthArra2;
		return (_noIconChildWidthArra = (_noIconChildWidthArra2 = noIconChildWidthArray.find((item) => item.text === itemText)) === null || _noIconChildWidthArra2 === void 0 ? void 0 : _noIconChildWidthArra2.width) !== null && _noIconChildWidthArra !== void 0 ? _noIconChildWidthArra : 0;
	}
	const swapMenuItemWithListItem = (prospectiveListItem, indexOfProspectiveListItem, event, callback) => {
		var _navRef$current$getBo, _navRef$current, _listRef$current$getB, _listRef$current;
		const index = getBreakpointForItemSwapping(getItemsWidth(prospectiveListItem.props.children), ((_navRef$current$getBo = (_navRef$current = navRef.current) === null || _navRef$current === void 0 ? void 0 : _navRef$current.getBoundingClientRect().width) !== null && _navRef$current$getBo !== void 0 ? _navRef$current$getBo : 0) - ((_listRef$current$getB = (_listRef$current = listRef.current) === null || _listRef$current === void 0 ? void 0 : _listRef$current.getBoundingClientRect().width) !== null && _listRef$current$getB !== void 0 ? _listRef$current$getB : 0));
		const indexToSliceAt = responsiveProps.items.length - 1 - index;
		const updatedItemList = [...[...responsiveProps.items].slice(0, indexToSliceAt), prospectiveListItem];
		const itemsToAddToMenu = [...responsiveProps.items].slice(indexToSliceAt);
		const updatedMenuItems = [...menuItems];
		updatedMenuItems.splice(indexOfProspectiveListItem, 1, ...itemsToAddToMenu);
		callback({
			items: updatedItemList,
			menuItems: updatedMenuItems
		}, false, true);
	};
	function getBreakpointForItemSwapping(widthToFitIntoList, availableSpace) {
		let widthToSwap = 0;
		let breakpoint = 0;
		for (const [index, item] of [...responsiveProps.items].reverse().entries()) {
			widthToSwap += getItemsWidth(item.props.children);
			if (widthToFitIntoList < widthToSwap + availableSpace) {
				breakpoint = index;
				break;
			}
		}
		return breakpoint;
	}
	const updateListAndMenu = useCallback((props, displayIcons, overflowMeasured) => {
		setResponsiveProps(props);
		setIconsVisible(displayIcons);
		if (overflowMeasured) setIsOverflowMeasured(true);
	}, []);
	const setChildrenWidth = useCallback((size) => {
		setChildWidthArray((arr) => {
			return [...arr, size];
		});
	}, []);
	const setNoIconChildrenWidth = useCallback((size) => {
		setNoIconChildWidthArray((arr) => {
			return [...arr, size];
		});
	}, []);
	const closeOverlay = React.useCallback(() => {
		setIsWidgetOpen(false);
	}, [setIsWidgetOpen]);
	const focusOnMoreMenuBtn = React.useCallback(() => {
		var _moreMenuBtnRef$curre;
		(_moreMenuBtnRef$curre = moreMenuBtnRef.current) === null || _moreMenuBtnRef$curre === void 0 || _moreMenuBtnRef$curre.focus();
	}, []);
	const onAnchorClick = useCallback((event) => {
		if (event.defaultPrevented || event.button !== 0) return;
		setIsWidgetOpen((isWidgetOpen) => !isWidgetOpen);
	}, []);
	useOnEscapePress((event) => {
		if (isWidgetOpen) {
			event.preventDefault();
			closeOverlay();
			focusOnMoreMenuBtn();
		}
	}, [isWidgetOpen]);
	useOnOutsideClick({
		onClickOutside: closeOverlay,
		containerRef,
		ignoreClickRefs: [moreMenuBtnRef]
	});
	useResizeObserver((resizeObserverEntries) => {
		var _moreMenuRef$current$, _moreMenuRef$current;
		const navWidth = resizeObserverEntries[0].contentRect.width;
		const moreMenuWidth = (_moreMenuRef$current$ = (_moreMenuRef$current = moreMenuRef.current) === null || _moreMenuRef$current === void 0 ? void 0 : _moreMenuRef$current.getBoundingClientRect().width) !== null && _moreMenuRef$current$ !== void 0 ? _moreMenuRef$current$ : 0;
		navWidth !== 0 && overflowEffect(navWidth, moreMenuWidth, validChildren, childWidthArray, noIconChildWidthArray, updateListAndMenu);
	}, navRef);
	let menuInlineStyles = { ...baseMenuInlineStyles };
	if (containerRef.current && listRef.current) {
		const { left } = getAnchoredPosition(containerRef.current, listRef.current, {
			align: "start",
			side: "outside-bottom"
		});
		menuInlineStyles = {
			...baseMenuInlineStyles,
			right: void 0,
			left
		};
	}
	return /* @__PURE__ */ jsxs(UnderlineNavContext.Provider, {
		value: {
			setChildrenWidth,
			setNoIconChildrenWidth,
			loadingCounters,
			iconsVisible
		},
		children: [ariaLabel && /* @__PURE__ */ jsx(VisuallyHidden, {
			as: "h2",
			children: `${ariaLabel} navigation`
		}), /* @__PURE__ */ jsx(UnderlineWrapper, {
			as,
			"aria-label": ariaLabel,
			className,
			ref: navRef,
			"data-variant": variant,
			"data-overflow-measured": isOverflowMeasured ? "true" : "false",
			children: /* @__PURE__ */ jsxs(UnderlineItemList, {
				ref: listRef,
				role: "list",
				children: [listItems, menuItems.length > 0 && /* @__PURE__ */ jsxs("li", {
					ref: moreMenuRef,
					style: {
						display: "flex",
						alignItems: "center",
						height: `${MORE_BTN_HEIGHT}px`
					},
					children: [
						!onlyMenuVisible && /* @__PURE__ */ jsx("div", { style: dividerStyles }),
						/* @__PURE__ */ jsx(ButtonComponent, {
							ref: moreMenuBtnRef,
							className: classes$3.MoreButton,
							"aria-controls": disclosureWidgetId,
							"aria-expanded": isWidgetOpen,
							onClick: onAnchorClick,
							trailingAction: TriangleDownIcon,
							children: /* @__PURE__ */ jsx("span", { children: onlyMenuVisible ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs(VisuallyHidden, {
								as: "span",
								children: [`${ariaLabel}`, "\xA0"]
							}), "Menu"] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: ["More", /* @__PURE__ */ jsxs(VisuallyHidden, {
								as: "span",
								children: ["\xA0", `${ariaLabel} items`]
							})] }) })
						}),
						/* @__PURE__ */ jsx(ActionList, {
							selectionVariant: "single",
							ref: containerRef,
							id: disclosureWidgetId,
							style: {
								...(_listRef$current2 = listRef.current) !== null && _listRef$current2 !== void 0 && _listRef$current2.clientWidth && listRef.current.clientWidth >= 192 ? baseMenuInlineStyles : menuInlineStyles,
								display: isWidgetOpen ? "block" : "none"
							},
							children: menuItems.map((menuItem, index) => {
								const { children: menuItemChildren, counter, "aria-current": ariaCurrent, onSelect, ...menuItemProps } = menuItem.props;
								if (Boolean(ariaCurrent) && ariaCurrent !== "false") {
									const event = new MouseEvent("click");
									!onlyMenuVisible && swapMenuItemWithListItem(menuItem, index, event, updateListAndMenu);
								}
								return /* @__PURE__ */ jsx(ActionList.LinkItem, {
									style: menuItemStyles,
									onClick: (event) => {
										!onlyMenuVisible && swapMenuItemWithListItem(menuItem, index, event, updateListAndMenu);
										closeOverlay();
										focusOnMoreMenuBtn();
										typeof onSelect === "function" && onSelect(event);
									},
									...menuItemProps,
									children: /* @__PURE__ */ jsxs("span", {
										className: classes$3.MenuItemContent,
										children: [menuItemChildren, loadingCounters ? /* @__PURE__ */ jsx(LoadingCounter, {}) : counter !== void 0 && /* @__PURE__ */ jsx("span", {
											"data-component": "counter",
											children: /* @__PURE__ */ jsx(CounterLabel, { children: counter })
										})]
									})
								}, menuItemChildren);
							})
						})
					]
				})]
			})
		})]
	});
});
UnderlineNav$1.displayName = "UnderlineNav";
var classes$2 = { "UnderlineNavItem": "prc-UnderlineNav-UnderlineNavItem-syRjR" };
var UnderlineNavItem = /* @__PURE__ */ forwardRef(({ as: Component = "a", href = "#", children, counter, onSelect, "aria-current": ariaCurrent, icon: Icon, leadingVisual, ...props }, forwardedRef) => {
	const backupRef = useRef(null);
	const ref = forwardedRef !== null && forwardedRef !== void 0 ? forwardedRef : backupRef;
	const { setChildrenWidth, setNoIconChildrenWidth, loadingCounters, iconsVisible } = useContext(UnderlineNavContext);
	useIsomorphicLayoutEffect(() => {
		if (ref.current) {
			const domRect = ref.current.getBoundingClientRect();
			const icon = Array.from(ref.current.children).find((child) => child.getAttribute("data-component") === "icon");
			const text = Array.from(ref.current.children).find((child) => child.getAttribute("data-component") === "text").textContent;
			const iconWidthWithMargin = icon ? icon.getBoundingClientRect().width + Number(getComputedStyle(icon).marginRight.slice(0, -2)) + Number(getComputedStyle(icon).marginLeft.slice(0, -2)) : 0;
			setChildrenWidth({
				text,
				width: domRect.width
			});
			setNoIconChildrenWidth({
				text,
				width: domRect.width - iconWidthWithMargin
			});
		}
	}, [
		ref,
		setChildrenWidth,
		setNoIconChildrenWidth
	]);
	const keyDownHandler = React.useCallback((event) => {
		if ((event.key === " " || event.key === "Enter") && !event.defaultPrevented && typeof onSelect === "function") onSelect(event);
	}, [onSelect]);
	const clickHandler = React.useCallback((event) => {
		if (!event.defaultPrevented && typeof onSelect === "function") onSelect(event);
	}, [onSelect]);
	return /* @__PURE__ */ jsx("li", {
		className: classes$2.UnderlineNavItem,
		children: /* @__PURE__ */ jsx(UnderlineItem, {
			ref,
			as: Component,
			href,
			"aria-current": ariaCurrent,
			onKeyDown: keyDownHandler,
			onClick: clickHandler,
			counter,
			icon: leadingVisual !== null && leadingVisual !== void 0 ? leadingVisual : Icon,
			loadingCounters,
			iconsVisible,
			...props,
			children
		})
	});
});
UnderlineNavItem.displayName = "UnderlineNavItem";
var UnderlineNav = Object.assign(UnderlineNav$1, { Item: UnderlineNavItem });
var classes$1 = { "Details": "prc-Details-Details-GckmQ" };
var Root = /* @__PURE__ */ React.forwardRef((t0, forwardRef) => {
	const $ = c(13);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({className, children, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	const ref = useMergedRefs(forwardRef, React.useRef(null));
	let t1;
	let t2;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = () => {};
		t2 = [];
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	useEffect(t1, t2);
	let t3;
	if ($[6] !== className) {
		t3 = clsx(className, classes$1.Details);
		$[6] = className;
		$[7] = t3;
	} else t3 = $[7];
	let t4;
	if ($[8] !== children || $[9] !== ref || $[10] !== rest || $[11] !== t3) {
		t4 = /* @__PURE__ */ jsx("details", {
			className: t3,
			...rest,
			ref,
			children
		});
		$[8] = children;
		$[9] = ref;
		$[10] = rest;
		$[11] = t3;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
});
Root.displayName = "Details";
function Summary(t0) {
	var _as;
	const $ = c(9);
	let as;
	let children;
	let props;
	if ($[0] !== t0) {
		({as, children, ...props} = t0);
		$[0] = t0;
		$[1] = as;
		$[2] = children;
		$[3] = props;
	} else {
		as = $[1];
		children = $[2];
		props = $[3];
	}
	const Component = (_as = as) !== null && _as !== void 0 ? _as : "summary";
	const t1 = Component === "summary" ? null : "summary";
	let t2;
	if ($[4] !== Component || $[5] !== children || $[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ jsx(Component, {
			as: t1,
			...props,
			children
		});
		$[4] = Component;
		$[5] = children;
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
Summary.displayName = "Summary";
var Details = Object.assign(Root, { Summary });
var classes = {
	"BreadcrumbsBase": "prc-Breadcrumbs-BreadcrumbsBase-3Gb-B",
	"BreadcrumbsList": "prc-Breadcrumbs-BreadcrumbsList-BKjpe",
	"ItemSeparator": "prc-Breadcrumbs-ItemSeparator-kjXqh",
	"ItemWrapper": "prc-Breadcrumbs-ItemWrapper-k0NLn",
	"Item": "prc-Breadcrumbs-Item-jcraJ",
	"BreadcrumbsItem": "prc-Breadcrumbs-BreadcrumbsItem-L-Xrs",
	"MenuOverlay": "prc-Breadcrumbs-MenuOverlay--ayLx",
	"MenuDetails": "prc-Breadcrumbs-MenuDetails-JOGTj",
	"overlay-appear": "prc-Breadcrumbs-overlay-appear-CSLnF"
};
var BreadcrumbsList = (t0) => {
	const $ = c(2);
	const { children } = t0;
	let t1;
	if ($[0] !== children) {
		t1 = /* @__PURE__ */ jsx("ol", {
			className: classes.BreadcrumbsList,
			children
		});
		$[0] = children;
		$[1] = t1;
	} else t1 = $[1];
	return t1;
};
var BreadcrumbsMenuItem = /* @__PURE__ */ React.forwardRef((t0, menuRefCallback) => {
	const $ = c(25);
	let ariaLabel;
	let items;
	let rest;
	if ($[0] !== t0) {
		({items, "aria-label": ariaLabel, ...rest} = t0);
		$[0] = t0;
		$[1] = ariaLabel;
		$[2] = items;
		$[3] = rest;
	} else {
		ariaLabel = $[1];
		items = $[2];
		rest = $[3];
	}
	const [isOpen, setIsOpen] = useState(false);
	const detailsRef = useRef(null);
	const menuButtonRef = useRef(null);
	const menuContainerRef = useRef(null);
	let t1;
	if ($[4] !== menuRefCallback) {
		t1 = (element) => {
			detailsRef.current = element;
			if (typeof menuRefCallback === "function") menuRefCallback(element);
		};
		$[4] = menuRefCallback;
		$[5] = t1;
	} else t1 = $[5];
	const detailsRefCallback = t1;
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = (event) => {
			event.preventDefault();
			if (detailsRef.current) {
				const newOpenState = !detailsRef.current.open;
				detailsRef.current.open = newOpenState;
				setIsOpen(newOpenState);
			}
		};
		$[6] = t2;
	} else t2 = $[6];
	const handleSummaryClick = t2;
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			if (detailsRef.current) {
				detailsRef.current.open = false;
				setIsOpen(false);
			}
		};
		$[7] = t3;
	} else t3 = $[7];
	const closeOverlay = t3;
	let t4;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			var _menuButtonRef$curren;
			(_menuButtonRef$curren = menuButtonRef.current) === null || _menuButtonRef$curren === void 0 || _menuButtonRef$curren.focus();
		};
		$[8] = t4;
	} else t4 = $[8];
	const focusOnMenuButton = t4;
	let t5;
	let t6;
	if ($[9] !== isOpen) {
		t5 = (event_0) => {
			if (isOpen) {
				event_0.preventDefault();
				closeOverlay();
				focusOnMenuButton();
			}
		};
		t6 = [isOpen];
		$[9] = isOpen;
		$[10] = t5;
		$[11] = t6;
	} else {
		t5 = $[10];
		t6 = $[11];
	}
	useOnEscapePress(t5, t6);
	let t7;
	if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = {
			onClickOutside: closeOverlay,
			containerRef: menuContainerRef,
			ignoreClickRefs: [menuButtonRef]
		};
		$[12] = t7;
	} else t7 = $[12];
	useOnOutsideClick(t7);
	const t8 = ariaLabel || `${items.length} more breadcrumb items`;
	const t9 = isOpen ? "true" : "false";
	let t10;
	if ($[13] !== rest || $[14] !== t8 || $[15] !== t9) {
		t10 = /* @__PURE__ */ jsx(IconButton, {
			as: "summary",
			role: "button",
			ref: menuButtonRef,
			"aria-label": t8,
			"aria-expanded": t9,
			onClick: handleSummaryClick,
			variant: "invisible",
			size: "small",
			icon: KebabHorizontalIcon,
			tooltipDirection: "e",
			...rest
		});
		$[13] = rest;
		$[14] = t8;
		$[15] = t9;
		$[16] = t10;
	} else t10 = $[16];
	let t11;
	if ($[17] !== items) {
		t11 = items.map(_temp);
		$[17] = items;
		$[18] = t11;
	} else t11 = $[18];
	let t12;
	if ($[19] !== t11) {
		t12 = /* @__PURE__ */ jsx("div", {
			ref: menuContainerRef,
			className: classes.MenuOverlay,
			children: /* @__PURE__ */ jsx(ActionList, { children: t11 })
		});
		$[19] = t11;
		$[20] = t12;
	} else t12 = $[20];
	let t13;
	if ($[21] !== detailsRefCallback || $[22] !== t10 || $[23] !== t12) {
		t13 = /* @__PURE__ */ jsxs(Details, {
			ref: detailsRefCallback,
			className: classes.MenuDetails,
			children: [t10, t12]
		});
		$[21] = detailsRefCallback;
		$[22] = t10;
		$[23] = t12;
		$[24] = t13;
	} else t13 = $[24];
	return t13;
});
BreadcrumbsMenuItem.displayName = "Breadcrumbs.MenuItem";
var getValidChildren = (children) => {
	return React.Children.toArray(children).filter((child) => /* @__PURE__ */ React.isValidElement(child));
};
function Breadcrumbs({ className, children, style, overflow = "wrap", variant = "normal" }) {
	const overflowMenuEnabled = useFeatureFlag("primer_react_breadcrumbs_overflow_menu");
	const wrappedChildren = React.Children.map(children, (child) => /* @__PURE__ */ jsx("li", {
		className: classes.ItemWrapper,
		children: child
	}));
	const containerRef = useRef(null);
	const measureMenuButton = useCallback((element) => {
		if (element) {
			const iconButtonElement = element.querySelector("button[data-component=\"IconButton\"]");
			if (iconButtonElement) {
				const measuredWidth = iconButtonElement.offsetWidth;
				setMenuButtonWidth(measuredWidth);
			}
		}
	}, []);
	const hideRoot = !(overflow === "menu-with-root");
	const [effectiveHideRoot, setEffectiveHideRoot] = useState(hideRoot);
	const childArray = useMemo(() => getValidChildren(children), [children]);
	const rootItem = childArray[0];
	const [visibleItems, setVisibleItems] = useState(() => childArray);
	const [childArrayWidths, setChildArrayWidths] = useState(() => []);
	const [menuItems, setMenuItems] = useState([]);
	const [rootItemWidth, setRootItemWidth] = useState(0);
	const [menuButtonWidth, setMenuButtonWidth] = useState(32);
	useEffect(() => {
		var _containerRef$current;
		const listElement = (_containerRef$current = containerRef.current) === null || _containerRef$current === void 0 ? void 0 : _containerRef$current.querySelector("ol");
		if (overflowMenuEnabled && listElement && listElement.children.length > 0 && listElement.children.length === childArray.length) {
			const listElementArray = Array.from(listElement.children);
			setChildArrayWidths(listElementArray.map((child_0) => child_0.offsetWidth));
			setRootItemWidth(listElementArray[0].offsetWidth);
		}
	}, [childArray, overflowMenuEnabled]);
	const calculateOverflow = useCallback((availableWidth) => {
		let eHideRoot = effectiveHideRoot;
		const MENU_BUTTON_WIDTH = menuButtonWidth;
		const MIN_VISIBLE_ITEMS = !eHideRoot ? 3 : 4;
		const calculateVisibleItemsWidth = (w) => {
			const widths_0 = w.reduce((sum, width) => sum + width + 16, 0);
			return !eHideRoot ? rootItemWidth + widths_0 : widths_0;
		};
		let currentVisibleItems = [...childArray];
		let currentVisibleItemWidths = [...childArrayWidths];
		let currentMenuItems = [];
		let currentMenuItemsWidths = [];
		if (availableWidth > 0 && currentVisibleItemWidths.length > 0) {
			let visibleItemsWidthTotal = calculateVisibleItemsWidth(currentVisibleItemWidths);
			if (currentMenuItems.length > 0) visibleItemsWidthTotal += MENU_BUTTON_WIDTH;
			while ((overflow === "menu" || overflow === "menu-with-root") && (visibleItemsWidthTotal > availableWidth || currentVisibleItems.length > MIN_VISIBLE_ITEMS)) {
				const itemToHide = currentVisibleItems[0];
				const itemToHideWidth = currentVisibleItemWidths[0];
				currentMenuItems = [...currentMenuItems, itemToHide];
				currentMenuItemsWidths = [...currentMenuItemsWidths, itemToHideWidth];
				currentVisibleItems = currentVisibleItems.slice(1);
				currentVisibleItemWidths = currentVisibleItemWidths.slice(1);
				visibleItemsWidthTotal = calculateVisibleItemsWidth(currentVisibleItemWidths);
				if (currentMenuItems.length > 0) visibleItemsWidthTotal += MENU_BUTTON_WIDTH;
				if (currentVisibleItems.length === 1 && visibleItemsWidthTotal > availableWidth) {
					eHideRoot = true;
					break;
				} else eHideRoot = hideRoot;
			}
		}
		return {
			visibleItems: currentVisibleItems,
			menuItems: currentMenuItems,
			effectiveHideRoot: eHideRoot
		};
	}, [
		childArray,
		childArrayWidths,
		effectiveHideRoot,
		hideRoot,
		overflow,
		rootItemWidth,
		menuButtonWidth
	]);
	useResizeObserver(useCallback((entries) => {
		if (overflowMenuEnabled && entries[0]) {
			const containerWidth = entries[0].contentRect.width;
			const result = calculateOverflow(containerWidth);
			if (visibleItems.length !== result.visibleItems.length && menuItems.length !== result.menuItems.length || result.effectiveHideRoot !== effectiveHideRoot) {
				setVisibleItems(result.visibleItems);
				setMenuItems(result.menuItems);
				setEffectiveHideRoot(result.effectiveHideRoot);
			}
		}
	}, [
		calculateOverflow,
		effectiveHideRoot,
		menuItems.length,
		overflowMenuEnabled,
		visibleItems.length
	]), containerRef);
	useEffect(() => {
		if (overflowMenuEnabled && (overflow === "menu" || overflow === "menu-with-root") && childArray.length > 5 && menuItems.length === 0) {
			var _containerRef$current2;
			const result_0 = calculateOverflow(((_containerRef$current2 = containerRef.current) === null || _containerRef$current2 === void 0 ? void 0 : _containerRef$current2.offsetWidth) || 800);
			setVisibleItems(result_0.visibleItems);
			setMenuItems(result_0.menuItems);
			setEffectiveHideRoot(result_0.effectiveHideRoot);
		}
	}, [
		overflow,
		childArray,
		calculateOverflow,
		menuItems.length,
		overflowMenuEnabled
	]);
	const finalChildren = React.useMemo(() => {
		if (overflowMenuEnabled) {
			if (overflow === "wrap" || menuItems.length === 0) return React.Children.map(children, (child_1) => /* @__PURE__ */ jsx("li", {
				className: classes.ItemWrapper,
				children: child_1
			}));
			let effectiveMenuItems = [...menuItems];
			if (!effectiveHideRoot) effectiveMenuItems = [...menuItems.slice(1)];
			const menuElement = /* @__PURE__ */ jsxs("li", {
				className: classes.BreadcrumbsItem,
				children: [/* @__PURE__ */ jsx(BreadcrumbsMenuItem, {
					ref: measureMenuButton,
					items: effectiveMenuItems,
					"aria-label": `${effectiveMenuItems.length} more breadcrumb items`
				}), /* @__PURE__ */ jsx(ItemSeparator, {})]
			}, "breadcrumbs-menu");
			const visibleElements = visibleItems.map((child_2, index) => /* @__PURE__ */ jsxs("li", {
				className: classes.BreadcrumbsItem,
				children: [child_2, /* @__PURE__ */ jsx(ItemSeparator, {})]
			}, `visible + ${index}`));
			const rootElement = /* @__PURE__ */ jsxs("li", {
				className: classes.BreadcrumbsItem,
				children: [rootItem, /* @__PURE__ */ jsx(ItemSeparator, {})]
			}, `rootElement`);
			if (effectiveHideRoot) return [menuElement, ...visibleElements];
			else return [
				rootElement,
				menuElement,
				...visibleElements
			];
		}
	}, [
		overflowMenuEnabled,
		overflow,
		menuItems,
		effectiveHideRoot,
		measureMenuButton,
		visibleItems,
		rootItem,
		children
	]);
	return overflowMenuEnabled ? /* @__PURE__ */ jsx("nav", {
		className: clsx(className, classes.BreadcrumbsBase),
		"aria-label": "Breadcrumbs",
		style,
		ref: containerRef,
		"data-overflow": overflow,
		"data-variant": variant,
		children: /* @__PURE__ */ jsx(BreadcrumbsList, { children: finalChildren })
	}) : /* @__PURE__ */ jsx("nav", {
		className: clsx(className, classes.BreadcrumbsBase),
		"aria-label": "Breadcrumbs",
		style,
		"data-variant": variant,
		children: /* @__PURE__ */ jsx(BreadcrumbsList, { children: wrappedChildren })
	});
}
var ItemSeparator = () => {
	const $ = c(1);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ jsx("span", {
			className: classes.ItemSeparator,
			children: /* @__PURE__ */ jsx("svg", {
				width: "16",
				height: "16",
				viewBox: "0 0 16 16",
				xmlns: "http://www.w3.org/2000/svg",
				"aria-hidden": "true",
				children: /* @__PURE__ */ jsx("path", {
					d: "M10.956 1.27994L6.06418 14.7201L5 14.7201L9.89181 1.27994L10.956 1.27994Z",
					fill: "currentcolor"
				})
			})
		});
		$[0] = t0;
	} else t0 = $[0];
	return t0;
};
function BreadcrumbsItemComponent(props, ref) {
	const $ = c(14);
	let className;
	let rest;
	let selected;
	let t0;
	if ($[0] !== props) {
		({as: t0, selected, className, ...rest} = props);
		$[0] = props;
		$[1] = className;
		$[2] = rest;
		$[3] = selected;
		$[4] = t0;
	} else {
		className = $[1];
		rest = $[2];
		selected = $[3];
		t0 = $[4];
	}
	const Component = t0 === void 0 ? "a" : t0;
	const t1 = selected && "selected";
	let t2;
	if ($[5] !== className || $[6] !== t1) {
		t2 = clsx(className, classes.Item, t1);
		$[5] = className;
		$[6] = t1;
		$[7] = t2;
	} else t2 = $[7];
	const t3 = selected ? "page" : void 0;
	let t4;
	if ($[8] !== Component || $[9] !== ref || $[10] !== rest || $[11] !== t2 || $[12] !== t3) {
		t4 = /* @__PURE__ */ jsx(Component, {
			className: t2,
			"aria-current": t3,
			ref,
			...rest
		});
		$[8] = Component;
		$[9] = ref;
		$[10] = rest;
		$[11] = t2;
		$[12] = t3;
		$[13] = t4;
	} else t4 = $[13];
	return t4;
}
BreadcrumbsItemComponent.displayName = "Breadcrumbs.Item";
var BreadcrumbsItem = /* @__PURE__ */ React.forwardRef(BreadcrumbsItemComponent);
Breadcrumbs.displayName = "Breadcrumbs";
var Breadcrumbs_default = Object.assign(Breadcrumbs, { Item: BreadcrumbsItem });
Object.assign(Breadcrumbs, { Item: BreadcrumbsItem });
/**
* @deprecated Use the `BreadcrumbsProps` type instead
*/
/**
* @deprecated Use the `BreadcrumbsItemProps` type instead
*/
function _temp(item, index) {
	const href = item.props.href;
	const children = item.props.children;
	const selected = item.props.selected;
	return /* @__PURE__ */ jsx(ActionList.LinkItem, {
		href,
		"aria-current": selected ? "page" : void 0,
		children
	}, index);
}
_temp.displayName = "_temp";
export { Details as n, UnderlineNav as r, Breadcrumbs_default as t };
