import { t as Box, u as Text } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { jsx } from "react/jsx-runtime";
/**
* @deprecated Use `VerifiedHTMLDiv` or `VerifiedHTMLText` instead.
*
* `VerifiedHTMLBox` extends `Box` from `@primer/react` to allow injecting HTML strings
* into the DOM.
*
* This component should only be used with strings that have specifically been marked as verified,
* via the `SafeHTMLString` type.
*
* Only mark strings as `SafeHTMLString` if one of the following applies:
* - they come from a trusted source on the server (eg the HTML pipeline)
* - they have known static contents
* - they have been sanitized by DOMPurify.
*
* All other strings should use the `UnsafeHTMLBox` component instead.
*/
var VerifiedHTMLBox = withSafeHTML(Box);
/**
* `VerifiedHTMLText` extends `Text` from `@primer/react` to allow injecting HTML strings
* into the DOM.
*
* This component should only be used with strings that have specifically been marked as verified,
* via the `SafeHTMLString` type.
*
* Only mark strings as `SafeHTMLString` if one of the following applies:
* - they come from a trusted source on the server (eg the HTML pipeline)
* - they have known static contents
* - they have been sanitized by DOMPurify.
*
* All other strings should use the `UnsafeHTMLText` component instead.
*/
var VerifiedHTMLText = withSafeHTML(Text);
var Div = ({ ref, ...props }) => /* @__PURE__ */ jsx("div", {
	...props,
	ref
});
Div.displayName = "Div";
/**
* `VerifiedHTMLDiv` extends `div` with props for safely rendering HTML strings.
*
* This component should only be used with strings that have specifically been marked as verified,
* via the `SafeHTMLString` type.
*
* Only mark strings as `SafeHTMLString` if one of the following applies:
* - they come from a trusted source on the server (eg the HTML pipeline)
* - they have known static contents
* - they have been sanitized by DOMPurify.
*
* All other strings should use the `UnsafeHTMLDiv` component instead.
*/
var VerifiedHTMLDiv = withSafeHTML(Div);
var Bdi = ({ ref, ...props }) => /* @__PURE__ */ jsx("bdi", {
	...props,
	ref
});
Bdi.displayName = "Bdi";
/**
* `VerifiedHTMLBdi` extends `bdi` with props for safely rendering HTML strings.
*
* This component should only be used with strings that have specifically been marked as verified,
* via the `SafeHTMLString` type.
*
* Only mark strings as `SafeHTMLString` if one of the following applies:
* - they come from a trusted source on the server (eg the HTML pipeline)
* - they have known static contents
* - they have been sanitized by DOMPurify.
*
* All other strings should use the `UnsafeHTMLBdi` component instead.
*/
var VerifiedHTMLBdi = withSafeHTML(Bdi);
/**
* A higher-order component that extends a basic component to inject an
* `html` prop into the DOM via `dangerouslySetInnerHTML`.
*/
function withSafeHTML(Component) {
	const SafeHTMLComponent = ({ html, ...props }) => {
		return /* @__PURE__ */ jsx(Component, {
			...props,
			dangerouslySetInnerHTML: html ? { __html: html } : void 0
		});
	};
	SafeHTMLComponent.displayName = `SafeHTML${Component.displayName || Component.name}`;
	return SafeHTMLComponent;
}
export { VerifiedHTMLText as i, VerifiedHTMLBox as n, VerifiedHTMLDiv as r, VerifiedHTMLBdi as t };
