performance.mark("js-parse-end:server-FeaturePreviewDialog-DDZsvNNn-C_dbP94X.js");
import { i as VisuallyHidden, o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Hi as useProvidedRefOrCreate, Qt as Heading$2, an as IconButton, bn as Link, d as ArrowRightIcon, n as ActionList, qr as Stack, u as ArrowLeftIcon, vt as EyeClosedIcon, yt as EyeIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { n as useResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import { i as reactFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { o as SkeletonBox } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as useControllableState } from "./server-useControllableState-vGARN752-BYRiGAOs.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { l as useQuery, u as useQueryClient } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { n as UnsafeHTMLDiv } from "./server-UnsafeHTML-C2mRs2L2-BN15XGuv.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as ToggleSwitch } from "./server-ToggleSwitch-ouBLvY5S-LRpaQ39O.js";
import { t as InlineMessage } from "./server-InlineMessage-BhmmT-Sd-CKllIEFZ.js";
import React, { createContext, use, useCallback, useContext, useEffect, useId, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { c as c$1 } from "react/compiler-runtime";
import invariant from "tiny-invariant";
performance.mark("js-parse-end:FeaturePreviewDialog-DDZsvNNn.js");
/**
* The Tabs component provides the base structure for a tabbed interface, without providing any formal requirement on DOM structure or styling.
* It manages the state of the selected tab, handles tab ordering/selection and provides context to its child components to ensure an accessible experience.
*
* This is intended to be used in conjunction with the `useTab`, `useTabList`, and `useTabPanel` hooks to build a fully accessible tabs component.
* The `Tab`, `TabList`, and `TabPanel` components are provided for convenience to showcase the API & implementation.
*/
function Tabs$1(props) {
	var _props$defaultValue;
	const $ = c(13);
	const { children, onValueChange } = props;
	const groupId = useId();
	const t0 = (_props$defaultValue = props.defaultValue) !== null && _props$defaultValue !== void 0 ? _props$defaultValue : props.value;
	let t1;
	if ($[0] !== props.value || $[1] !== t0) {
		t1 = {
			name: "tab-selection",
			defaultValue: t0,
			value: props.value
		};
		$[0] = props.value;
		$[1] = t0;
		$[2] = t1;
	} else t1 = $[2];
	const [selectedValue, setSelectedValue] = useControllableState(t1);
	const savedOnValueChange = React.useRef(onValueChange);
	let t2;
	if ($[3] !== groupId || $[4] !== selectedValue || $[5] !== setSelectedValue) {
		t2 = {
			groupId,
			selectedValue,
			selectTab(value) {
				var _savedOnValueChange$c;
				setSelectedValue(value);
				(_savedOnValueChange$c = savedOnValueChange.current) === null || _savedOnValueChange$c === void 0 || _savedOnValueChange$c.call(savedOnValueChange, { value });
			}
		};
		$[3] = groupId;
		$[4] = selectedValue;
		$[5] = setSelectedValue;
		$[6] = t2;
	} else t2 = $[6];
	const contextValue = t2;
	let t3;
	let t4;
	if ($[7] !== onValueChange) {
		t3 = () => {
			savedOnValueChange.current = onValueChange;
		};
		t4 = [onValueChange];
		$[7] = onValueChange;
		$[8] = t3;
		$[9] = t4;
	} else {
		t3 = $[8];
		t4 = $[9];
	}
	useIsomorphicLayoutEffect(t3, t4);
	let t5;
	if ($[10] !== children || $[11] !== contextValue) {
		t5 = /* @__PURE__ */ jsx(TabsContext.Provider, {
			value: contextValue,
			children
		});
		$[10] = children;
		$[11] = contextValue;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
}
function useTabList(props) {
	const $ = c(9);
	const { "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, "aria-orientation": ariaOrientation } = props;
	const ref = useProvidedRefOrCreate(props.ref);
	let t0;
	if ($[0] !== ariaOrientation || $[1] !== ref) {
		t0 = (event) => {
			const { current: tablist } = ref;
			if (tablist === null) return;
			const tabs = getFocusableTabs(tablist);
			const isVertical = ariaOrientation === "vertical";
			const nextKey = isVertical ? "ArrowDown" : "ArrowRight";
			const prevKey = isVertical ? "ArrowUp" : "ArrowLeft";
			if (event.key === nextKey || event.key === prevKey || event.key === "Home" || event.key === "End") {
				event.preventDefault();
				event.stopPropagation();
			}
			if (event.key === nextKey) {
				const selectedTabIndex = tabs.findIndex(_temp$1);
				if (selectedTabIndex === -1) return;
				tabs[(selectedTabIndex + 1) % tabs.length].focus();
			} else if (event.key === prevKey) {
				const selectedTabIndex_0 = tabs.findIndex(_temp2);
				if (selectedTabIndex_0 === -1) return;
				tabs[(tabs.length + selectedTabIndex_0 - 1) % tabs.length].focus();
			} else if (event.key === "Home") {
				if (tabs[0]) tabs[0].focus();
			} else if (event.key === "End") {
				if (tabs.length > 0) tabs[tabs.length - 1].focus();
			}
		};
		$[0] = ariaOrientation;
		$[1] = ref;
		$[2] = t0;
	} else t0 = $[2];
	const onKeyDown = t0;
	const t1 = ariaOrientation !== null && ariaOrientation !== void 0 ? ariaOrientation : "horizontal";
	let t2;
	if ($[3] !== ariaLabel || $[4] !== ariaLabelledby || $[5] !== onKeyDown || $[6] !== ref || $[7] !== t1) {
		t2 = { tabListProps: {
			ref,
			"aria-label": ariaLabel,
			"aria-labelledby": ariaLabelledby,
			"aria-orientation": t1,
			role: "tablist",
			onKeyDown
		} };
		$[3] = ariaLabel;
		$[4] = ariaLabelledby;
		$[5] = onKeyDown;
		$[6] = ref;
		$[7] = t1;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
function _temp2(tab_0) {
	return tab_0.getAttribute("aria-selected") === "true";
}
function _temp$1(tab) {
	return tab.getAttribute("aria-selected") === "true";
}
function getFocusableTabs(tablist) {
	return Array.from(tablist.querySelectorAll("[role=\"tab\"]:not([aria-disabled])"));
}
/**
* A custom hook that provides the props needed for a tab component.
* The props returned should be spread onto the component (typically a button) with the `role=tab`, under a `tablist`.
*/
function useTab(props) {
	const $ = c(21);
	const { disabled, value } = props;
	const tabs = useTabs();
	const selected = tabs.selectedValue === value;
	const id = `${tabs.groupId}-tab-${value}`;
	const panelId = `${tabs.groupId}-panel-${value}`;
	let t0;
	if ($[0] !== tabs || $[1] !== value) {
		t0 = function onKeyDown(event) {
			if (event.key === " " || event.key === "Enter") tabs.selectTab(value);
		};
		$[0] = tabs;
		$[1] = value;
		$[2] = t0;
	} else t0 = $[2];
	const onKeyDown = t0;
	let t1;
	if ($[3] !== disabled || $[4] !== tabs || $[5] !== value) {
		t1 = function onMouseDown(event_0) {
			if (!disabled && event_0.button === 0 && event_0.ctrlKey === false) tabs.selectTab(value);
			else event_0.preventDefault();
		};
		$[3] = disabled;
		$[4] = tabs;
		$[5] = value;
		$[6] = t1;
	} else t1 = $[6];
	const onMouseDown = t1;
	let t2;
	if ($[7] !== disabled || $[8] !== selected || $[9] !== tabs || $[10] !== value) {
		t2 = function onFocus() {
			if (!selected && !disabled) tabs.selectTab(value);
		};
		$[7] = disabled;
		$[8] = selected;
		$[9] = tabs;
		$[10] = value;
		$[11] = t2;
	} else t2 = $[11];
	const onFocus = t2;
	const t3 = disabled ? true : void 0;
	const t4 = selected ? 0 : -1;
	let t5;
	if ($[12] !== id || $[13] !== onFocus || $[14] !== onKeyDown || $[15] !== onMouseDown || $[16] !== panelId || $[17] !== selected || $[18] !== t3 || $[19] !== t4) {
		t5 = { tabProps: {
			"aria-disabled": t3,
			"aria-controls": panelId,
			"aria-selected": selected,
			onKeyDown,
			onMouseDown,
			onFocus,
			id,
			role: "tab",
			tabIndex: t4
		} };
		$[12] = id;
		$[13] = onFocus;
		$[14] = onKeyDown;
		$[15] = onMouseDown;
		$[16] = panelId;
		$[17] = selected;
		$[18] = t3;
		$[19] = t4;
		$[20] = t5;
	} else t5 = $[20];
	return t5;
}
/** Utility hook for tab panels */
function useTabPanel(props) {
	const $ = c(5);
	const { value } = props;
	const tabs = useTabs();
	const id = `${tabs.groupId}-panel-${value}`;
	const tabId = `${tabs.groupId}-tab-${value}`;
	const t0 = tabs.selectedValue === value ? "" : void 0;
	const t1 = tabs.selectedValue !== value;
	let t2;
	if ($[0] !== id || $[1] !== t0 || $[2] !== t1 || $[3] !== tabId) {
		t2 = { tabPanelProps: {
			"aria-labelledby": tabId,
			"data-selected": t0,
			id,
			hidden: t1,
			role: "tabpanel"
		} };
		$[0] = id;
		$[1] = t0;
		$[2] = t1;
		$[3] = tabId;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
var TabsContext = /* @__PURE__ */ createContext(null);
function useTabs() {
	const context = useContext(TabsContext);
	if (context) return context;
	throw new Error("Component must be used within a <Tabs> component");
}
var FeatureIcon_module_default = { enrolledIcon: "FeatureIcon-module_U2menG_enrolledIcon" };
function FeatureIcon(props) {
	const { enrolled } = props;
	if (enrolled) return /* @__PURE__ */ jsx(EyeIcon, {
		"aria-label": "Feature enabled",
		className: FeatureIcon_module_default.enrolledIcon
	});
	return /* @__PURE__ */ jsx(EyeClosedIcon, { "aria-label": "Feature disabled" });
}
FeatureIcon.displayName = "FeatureIcon";
var CATEGORY = "FEATURE_PREVIEW";
function createEvent(config) {
	return {
		category: CATEGORY,
		...config
	};
}
function FeatureBanner({ type }) {
	if (!type) return null;
	return /* @__PURE__ */ jsx(InlineMessage, {
		variant: type === "reload" ? "success" : "critical",
		size: "small",
		children: type === "reload" ? /* @__PURE__ */ jsxs("span", { children: [
			"Changes saved! Please",
			" ",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				href: "#",
				onClick: (e) => {
					e.preventDefault();
					window.location.reload();
				},
				children: "reload"
			}),
			" ",
			"the page to view the changes."
		] }) : /* @__PURE__ */ jsx("span", { children: "Unable to save changes. Please try again." })
	});
}
FeatureBanner.displayName = "FeatureBanner";
var FeaturePreviewCard_module_default = {
	imageCard: "FeaturePreviewCard-module_ecos-q_imageCard",
	img: "FeaturePreviewCard-module_ecos-q_img"
};
var FeaturePreviewCard = (t0) => {
	const $ = c$1(3);
	const { ref, ...props } = t0;
	const { feature, onUpdate } = props;
	const headingId = `feature-preview-dialog-heading-${feature.slug}`;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const toggleLabel = `${feature.enrolled ? "Disable" : "Enable"} the ${feature.name} feature preview`;
	let t1;
	let t2;
	if ($[0] !== headingId) {
		t1 = () => ({ focusHeading: () => {
			const headingElement = document.getElementById(headingId);
			if (headingElement) headingElement.focus();
		} });
		t2 = [headingId];
		$[0] = headingId;
		$[1] = t1;
		$[2] = t2;
	} else {
		t1 = $[1];
		t2 = $[2];
	}
	useImperativeHandle(ref, t1, t2);
	return jsxs(Stack, {
		direction: "vertical",
		className: "width-full",
		gap: "none",
		padding: "normal",
		children: [jsxs(Stack, {
			direction: "horizontal",
			justify: "space-between",
			className: "width-full",
			children: [jsx(Heading$2, {
				as: "h1",
				variant: "small",
				id: headingId,
				tabIndex: -1,
				children: feature.name
			}), jsx(Stack, {
				direction: "vertical",
				align: "end",
				justify: "end",
				gap: "none",
				padding: "none",
				children: jsx(ToggleSwitch, {
					"aria-labelledby": headingId,
					"aria-label": toggleLabel,
					checked: feature.enrolled,
					size: "small",
					onClick: () => {
						sendClickAnalyticsEvent(createEvent({
							action: `${feature.enrolled ? "disable" : "enable"}_feature_preview:${feature.slug}`,
							label: toggleLabel
						}));
						onUpdate?.(!feature.enrolled);
					}
				})
			})]
		}), jsxs(Stack, {
			direction: "vertical",
			className: "width-full",
			gap: "normal",
			padding: "none",
			children: [
				jsx(Stack, {
					direction: "vertical",
					align: "end",
					justify: "end",
					padding: "none",
					gap: "none",
					children: jsx(FeatureBanner, { type: props.showBanner })
				}),
				jsx(ImageCard, {
					imageSrc: feature.image_link ?? void 0,
					altText: feature.name,
					feedbackLink: feature.feedback_link ?? void 0
				}),
				feature.description_html && jsx(UnsafeHTMLDiv, {
					className: "markdown-body",
					html: feature.description_html
				}),
				feature.documentation_link && jsx(Link, {
					href: feature.documentation_link,
					children: "Documentation"
				})
			]
		})]
	});
};
FeaturePreviewCard.displayName = "FeaturePreviewCard";
FeaturePreviewCard.displayName = "FeaturePreviewCard";
function ImageCard(props) {
	const $ = c$1(5);
	const feedbackDescId = useId();
	let t0;
	if ($[0] !== feedbackDescId || $[1] !== props.altText || $[2] !== props.feedbackLink || $[3] !== props.imageSrc) {
		t0 = jsxs(Stack, {
			direction: "vertical",
			gap: "none",
			className: FeaturePreviewCard_module_default.imageCard,
			children: [props.imageSrc && props.altText && jsx("img", {
				className: FeaturePreviewCard_module_default.img,
				src: props.imageSrc,
				alt: props.altText
			}), props.feedbackLink && jsxs(Stack, {
				direction: "horizontal",
				justify: "space-between",
				align: "center",
				className: "width-full tmp-p-3",
				children: [jsx("span", {
					id: feedbackDescId,
					children: "Help us improve this and make your experience even better."
				}), jsx(ButtonComponent, {
					as: "a",
					"aria-describedby": feedbackDescId,
					href: props.feedbackLink,
					variant: "default",
					size: "small",
					children: "Give feedback"
				})]
			})]
		});
		$[0] = feedbackDescId;
		$[1] = props.altText;
		$[2] = props.feedbackLink;
		$[3] = props.imageSrc;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
ImageCard.displayName = "ImageCard";
function FeaturePreviewLoadingCard() {
	return /* @__PURE__ */ jsxs(Stack, {
		direction: "vertical",
		className: "width-full",
		padding: "normal",
		children: [
			/* @__PURE__ */ jsx(SkeletonText, {}),
			/* @__PURE__ */ jsxs(Stack, {
				direction: "vertical",
				gap: "none",
				className: FeaturePreviewCard_module_default.imageCard,
				children: [/* @__PURE__ */ jsx("div", {
					className: FeaturePreviewCard_module_default.img,
					children: /* @__PURE__ */ jsx(SkeletonBox, {
						width: "100%",
						height: "180px"
					})
				}), /* @__PURE__ */ jsx(Stack, {
					direction: "horizontal",
					justify: "space-between",
					align: "center",
					className: "width-full tmp-p-3",
					children: /* @__PURE__ */ jsx(SkeletonText, {})
				})]
			}),
			/* @__PURE__ */ jsx(SkeletonText, { lines: 5 })
		]
	});
}
FeaturePreviewLoadingCard.displayName = "FeaturePreviewLoadingCard";
var Tabs_module_default = {
	tabContainer: "Tabs-module_hkummq_tabContainer",
	tabList: "Tabs-module_hkummq_tabList",
	tabPanel: "Tabs-module_hkummq_tabPanel"
};
function Tabs(props) {
	return /* @__PURE__ */ jsx(Tabs$1, {
		...props,
		children: /* @__PURE__ */ jsx("div", {
			className: Tabs_module_default.tabContainer,
			children: props.children
		})
	});
}
Tabs.displayName = "Tabs";
function TabList(props) {
	const $ = c$1(5);
	let t0;
	if ($[0] !== props) {
		t0 = {
			...props,
			"aria-orientation": "vertical"
		};
		$[0] = props;
		$[1] = t0;
	} else t0 = $[1];
	const { tabListProps } = useTabList(t0);
	let t1;
	if ($[2] !== props.children || $[3] !== tabListProps) {
		t1 = jsx(ActionList, {
			className: Tabs_module_default.tabList,
			...tabListProps,
			children: props.children
		});
		$[2] = props.children;
		$[3] = tabListProps;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
TabList.displayName = "TabList";
function Tab(props) {
	const $ = c$1(5);
	const { tabProps } = useTab(props);
	const t0 = String(tabProps["aria-selected"]) === "true";
	let t1;
	if ($[0] !== props.children || $[1] !== props.icon || $[2] !== t0 || $[3] !== tabProps) {
		t1 = jsxs(ActionList.Item, {
			active: t0,
			...tabProps,
			children: [props.children, props.icon && jsx(ActionList.LeadingVisual, { children: props.icon })]
		});
		$[0] = props.children;
		$[1] = props.icon;
		$[2] = t0;
		$[3] = tabProps;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
Tab.displayName = "Tab";
function TabPanel(props) {
	const $ = c$1(3);
	const { tabPanelProps } = useTabPanel(props);
	if (!props.value || tabPanelProps.hidden) return null;
	let t0;
	if ($[0] !== props.children || $[1] !== tabPanelProps) {
		t0 = jsx("div", {
			className: Tabs_module_default.tabPanel,
			...tabPanelProps,
			children: props.children
		});
		$[0] = props.children;
		$[1] = tabPanelProps;
		$[2] = t0;
	} else t0 = $[2];
	return t0;
}
TabPanel.displayName = "TabPanel";
var FeaturePreviewDialog_module_default = {
	dialog: "FeaturePreviewDialog-module__dGxXW_dialog",
	dialogHeaderContent: "FeaturePreviewDialog-module__dGxXW_dialogHeaderContent",
	dialogHeaderInner: "FeaturePreviewDialog-module__dGxXW_dialogHeaderInner"
};
function LoadingDialogMobile() {
	return /* @__PURE__ */ jsxs(ActionList, { children: [
		/* @__PURE__ */ jsx(LoadingActionItem, { isMobile: true }),
		/* @__PURE__ */ jsx(LoadingActionItem, { isMobile: true }),
		/* @__PURE__ */ jsx(LoadingActionItem, { isMobile: true }),
		/* @__PURE__ */ jsx(LoadingActionItem, { isMobile: true }),
		/* @__PURE__ */ jsx(LoadingActionItem, { isMobile: true })
	] });
}
LoadingDialogMobile.displayName = "LoadingDialogMobile";
function LoadingActionItem(props = { isMobile: false }) {
	return /* @__PURE__ */ jsxs(ActionList.Item, {
		"aria-busy": "true",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ jsx(VisuallyHidden, { children: "Loading feature preview item" }),
			/* @__PURE__ */ jsx(SkeletonText, {}),
			/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(EyeClosedIcon, {}) }),
			props.isMobile && /* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(ArrowRightIcon, {}) })
		]
	});
}
LoadingActionItem.displayName = "LoadingActionItem";
function LoadingDialogStationary() {
	return /* @__PURE__ */ jsxs("div", {
		className: Tabs_module_default.tabContainer,
		children: [/* @__PURE__ */ jsxs(ActionList, {
			className: Tabs_module_default.tabList,
			children: [
				/* @__PURE__ */ jsx(LoadingActionItem, {}),
				/* @__PURE__ */ jsx(LoadingActionItem, {}),
				/* @__PURE__ */ jsx(LoadingActionItem, {}),
				/* @__PURE__ */ jsx(LoadingActionItem, {}),
				/* @__PURE__ */ jsx(LoadingActionItem, {})
			]
		}), /* @__PURE__ */ jsx("div", {
			className: Tabs_module_default.tabPanel,
			children: /* @__PURE__ */ jsx(FeaturePreviewLoadingCard, {})
		})]
	});
}
LoadingDialogStationary.displayName = "LoadingDialogStationary";
function updateQueryData(oldData, feature) {
	if (!oldData) return oldData;
	return {
		...oldData,
		features: oldData.features.map((f) => {
			if (f.slug === feature.slug) return {
				...f,
				...feature
			};
			return f;
		})
	};
}
function useFeaturePreviewItemsQuery(config) {
	invariant(typeof config.login === "string", "login must be a string");
	const queryAPI = `/users/${config.login}/feature_previews`;
	const queryClient = useQueryClient();
	const featureQuery = useQuery({
		queryKey: ["feature-preview", queryAPI],
		queryFn: async () => {
			return await (await reactFetchJSON(queryAPI)).json();
		}
	});
	const toggleEnrollment = useCallback(async (feature, onShowBanner) => {
		invariant(feature.slug, "feature.slug is required to toggle a feature preview");
		const endpoint = feature.toggle_feature_path;
		invariant(endpoint, "endpoint is required to toggle a feature preview");
		const queryKey = ["feature-preview", queryAPI];
		onShowBanner(void 0);
		try {
			const responsePromise = reactFetchJSON(endpoint, { method: "POST" });
			queryClient.setQueryData(queryKey, (oldData_0) => {
				return updateQueryData(oldData_0, {
					slug: feature.slug,
					enrolled: !feature.enrolled
				});
			});
			const response_0 = await responsePromise;
			if (!response_0.ok) throw new Error(`Failed to toggle feature preview: ${response_0.statusText}`);
			onShowBanner("reload");
		} catch (error) {
			queryClient.setQueryData(queryKey, (oldData) => {
				return updateQueryData(oldData, {
					slug: feature.slug,
					enrolled: feature.enrolled
				});
			});
			onShowBanner("error");
		}
	}, [queryClient, queryAPI]);
	return {
		...featureQuery,
		toggleEnrollment
	};
}
function FeaturePreviewDialog({ ref, ...props }) {
	const { data, toggleEnrollment: toggleFeature } = useFeaturePreviewItemsQuery({ login: props.login });
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const isMobile = useResponsiveValue({
		regular: false,
		narrow: true
	}, false);
	const [selectedFeatureSlug, setSelectedFeatureSlug] = useState(null);
	const [bannerType, setBannerType] = useState(void 0);
	const selectedFeature = useMemo(() => {
		const selected = data?.features.find((feature) => feature.slug === selectedFeatureSlug);
		if (selected) return selected;
		if (!isMobile) return data?.features[0];
	}, [
		data,
		selectedFeatureSlug,
		isMobile
	]);
	const PreviewComponent = isMobile ? FeaturePreviewDialogMobile : FeaturePreviewDialogStationary;
	const LoadingComponent = isMobile ? LoadingDialogMobile : LoadingDialogStationary;
	const toggleEnrollment = useCallback((feature_0) => {
		toggleFeature(feature_0, (type) => {
			setBannerType(type);
		});
	}, [toggleFeature]);
	return /* @__PURE__ */ jsx(FeaturePreviewContext, {
		value: useMemo(() => {
			if (!data) return null;
			return {
				data,
				showBanner: bannerType,
				toggleEnrollment,
				selectedFeature,
				onSelectFeature: (feature_1) => {
					setBannerType(void 0);
					setSelectedFeatureSlug(feature_1?.slug ?? null);
				}
			};
		}, [
			data,
			toggleEnrollment,
			selectedFeature,
			bannerType
		]),
		children: /* @__PURE__ */ jsxs(Dialog, {
			ref,
			onClose: () => {
				sendClickAnalyticsEvent(createEvent({
					action: "close_feature_preview_dialog",
					label: "Close"
				}));
				props.onClose?.();
			},
			title: "Feature Preview",
			subtitle: "Get early access to new features and give feedback",
			height: "large",
			width: "xlarge",
			className: FeaturePreviewDialog_module_default.dialog,
			renderHeader: PreviewDialogHeader,
			children: [!data && /* @__PURE__ */ jsx(LoadingComponent, {}), data && /* @__PURE__ */ jsx(PreviewComponent, {
				data,
				showBanner: bannerType,
				toggleEnrollment,
				selectedFeature,
				onSelectFeature: (f) => {
					setBannerType(void 0);
					setSelectedFeatureSlug(f?.slug ?? null);
				}
			})]
		})
	});
}
FeaturePreviewDialog.displayName = "FeaturePreviewDialog";
var FeaturePreviewContext = createContext(null);
FeaturePreviewContext.displayName = "FeaturePreviewContext";
function FeaturePreviewDialogStationary(props) {
	const $ = c$1(14);
	const { data, toggleEnrollment, selectedFeature, onSelectFeature, showBanner } = props;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const t0 = selectedFeature?.slug ?? data.features[0]?.slug ?? "";
	let t1;
	if ($[0] !== data.features || $[1] !== onSelectFeature || $[2] !== selectedFeature || $[3] !== sendClickAnalyticsEvent) {
		t1 = (t2) => {
			const { value } = t2;
			const feature = data.features.find((f) => f.slug === value);
			if (feature && feature !== selectedFeature) {
				sendClickAnalyticsEvent(createEvent({
					action: "select_feature_preview_tab_stationary",
					label: feature.name
				}));
				onSelectFeature?.(feature);
			}
		};
		$[0] = data.features;
		$[1] = onSelectFeature;
		$[2] = selectedFeature;
		$[3] = sendClickAnalyticsEvent;
		$[4] = t1;
	} else t1 = $[4];
	let t2;
	if ($[5] !== data.features || $[6] !== showBanner || $[7] !== t0 || $[8] !== t1 || $[9] !== toggleEnrollment) {
		let t3;
		if ($[11] !== showBanner || $[12] !== toggleEnrollment) {
			t3 = (feature_1) => jsx(TabPanel, {
				value: feature_1.slug,
				"data-slug": feature_1.slug,
				children: jsx(FeaturePreviewCard, {
					showBanner,
					onUpdate: (enrolled) => {
						if (enrolled !== feature_1.enrolled) toggleEnrollment(feature_1);
					},
					feature: feature_1
				})
			}, feature_1.slug);
			$[11] = showBanner;
			$[12] = toggleEnrollment;
			$[13] = t3;
		} else t3 = $[13];
		t2 = jsxs(Tabs, {
			value: t0,
			onValueChange: t1,
			children: [jsx(TabList, {
				"aria-label": "Feature Preview",
				children: data.features.map(_temp)
			}), data.features.map(t3)]
		});
		$[5] = data.features;
		$[6] = showBanner;
		$[7] = t0;
		$[8] = t1;
		$[9] = toggleEnrollment;
		$[10] = t2;
	} else t2 = $[10];
	return t2;
}
FeaturePreviewDialogStationary.displayName = "FeaturePreviewDialogStationary";
function _temp(feature_0) {
	return jsx(Tab, {
		value: feature_0.slug,
		icon: jsx(FeatureIcon, { enrolled: feature_0.enrolled }),
		children: feature_0.name
	}, feature_0.slug);
}
function PreviewDialogHeader(props) {
	const $ = c$1(16);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			regular: false,
			narrow: true
		};
		$[0] = t0;
	} else t0 = $[0];
	const isMobile = useResponsiveValue(t0, false);
	const { title, onClose, dialogLabelId, subtitle, dialogDescriptionId } = props;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const previewContext = use(FeaturePreviewContext);
	let t1;
	if ($[1] !== previewContext || $[2] !== sendClickAnalyticsEvent) {
		t1 = () => {
			sendClickAnalyticsEvent(createEvent({
				action: "back_to_feature_preview_list",
				label: "Back"
			}));
			previewContext?.onSelectFeature?.(void 0);
		};
		$[1] = previewContext;
		$[2] = sendClickAnalyticsEvent;
		$[3] = t1;
	} else t1 = $[3];
	const onBackClick = t1;
	let t2;
	if ($[4] !== onClose || $[5] !== sendClickAnalyticsEvent) {
		t2 = () => {
			sendClickAnalyticsEvent(createEvent({
				action: "close_feature_preview_dialog",
				label: "Close"
			}));
			onClose("close-button");
		};
		$[4] = onClose;
		$[5] = sendClickAnalyticsEvent;
		$[6] = t2;
	} else t2 = $[6];
	const onCloseClick = t2;
	const showBackButton = isMobile && previewContext?.selectedFeature !== void 0;
	const showSubTitle = Boolean(subtitle) && !showBackButton;
	let t3;
	if ($[7] !== dialogDescriptionId || $[8] !== dialogLabelId || $[9] !== onBackClick || $[10] !== onCloseClick || $[11] !== showBackButton || $[12] !== showSubTitle || $[13] !== subtitle || $[14] !== title) {
		t3 = jsx(Dialog.Header, { children: jsxs("div", {
			className: FeaturePreviewDialog_module_default.dialogHeaderInner,
			children: [
				showBackButton && jsx(IconButton, {
					"aria-label": "Go back to the feature preview list",
					icon: ArrowLeftIcon,
					variant: "invisible",
					onClick: onBackClick
				}),
				jsxs("div", {
					className: FeaturePreviewDialog_module_default.dialogHeaderContent,
					children: [jsx(Dialog.Title, {
						id: dialogLabelId,
						children: title ?? "Feature Preview"
					}), showSubTitle && jsx(Dialog.Subtitle, {
						id: dialogDescriptionId,
						children: subtitle
					})]
				}),
				jsx(Dialog.CloseButton, {
					"aria-label": "Close the feature preview dialog",
					onClose: onCloseClick
				})
			]
		}) });
		$[7] = dialogDescriptionId;
		$[8] = dialogLabelId;
		$[9] = onBackClick;
		$[10] = onCloseClick;
		$[11] = showBackButton;
		$[12] = showSubTitle;
		$[13] = subtitle;
		$[14] = title;
		$[15] = t3;
	} else t3 = $[15];
	return t3;
}
PreviewDialogHeader.displayName = "PreviewDialogHeader";
function FeaturePreviewDialogMobile(props) {
	const { data, toggleEnrollment, onSelectFeature, selectedFeature, showBanner } = props;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const headingId = useId$1();
	const featureCardRef = useRef(null);
	const navListRef = useRef(null);
	const lastSelectedFeatureRef = useRef(null);
	const sendAnalytics = (featureName) => {
		sendClickAnalyticsEvent(createEvent({
			action: "select_feature_preview_tab_mobile",
			label: featureName
		}));
	};
	useEffect(() => {
		if (selectedFeature) featureCardRef.current?.focusHeading();
		else if (navListRef.current && lastSelectedFeatureRef.current) navListRef.current.querySelector(`[data-feature-slug="${lastSelectedFeatureRef.current.slug}"]`)?.focus();
	}, [selectedFeature, navListRef]);
	useEffect(() => {
		lastSelectedFeatureRef.current = selectedFeature ?? null;
	}, [selectedFeature]);
	if (selectedFeature) return /* @__PURE__ */ jsx(FeaturePreviewCard, {
		ref: featureCardRef,
		onUpdate: (enrolled) => {
			if (enrolled !== selectedFeature.enrolled) toggleEnrollment(selectedFeature);
		},
		feature: selectedFeature,
		showBanner
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(VisuallyHidden, {
		id: headingId,
		children: "Available Feature Previews"
	}), /* @__PURE__ */ jsx("nav", { children: /* @__PURE__ */ jsx(ActionList, {
		"aria-labelledby": headingId,
		ref: navListRef,
		children: data?.features.map((feature) => /* @__PURE__ */ jsxs(ActionList.Item, {
			as: "button",
			type: "button",
			"aria-current": selectedFeature === feature ? "page" : void 0,
			"data-feature-slug": feature.slug,
			onSelect: () => {
				sendAnalytics(feature.name);
				onSelectFeature?.(feature);
			},
			children: [
				/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(FeatureIcon, { enrolled: feature.enrolled }) }),
				feature.name,
				/* @__PURE__ */ jsx(ActionList.TrailingVisual, { children: /* @__PURE__ */ jsx(ArrowRightIcon, {}) })
			]
		}, feature.slug))
	}) })] });
}
FeaturePreviewDialogMobile.displayName = "FeaturePreviewDialogMobile";
export { FeaturePreviewDialog };
