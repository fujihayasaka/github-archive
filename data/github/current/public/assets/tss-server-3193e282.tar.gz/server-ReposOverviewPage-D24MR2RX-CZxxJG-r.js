import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { r as Spinner } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { i as ButtonComponent, o as CounterLabel } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { At as FileSubmoduleIcon, Dt as FileIcon, En as LogIcon, Hn as NoteIcon, Ht as GitBranchIcon, Jt as GitPullRequestIcon, Kn as PackageIcon, Mi as XIcon, O as CheckIcon, Qn as PeopleIcon, Qt as Heading$2, Sn as LinkIcon, U as CodeOfConductIcon, V as ClockIcon, Wt as GitMergeIcon, Zn as PencilIcon, Zr as StarIcon, _i as Truncate, _n as KebabHorizontalIcon, an as IconButton, ar as PlusIcon, b as BookIcon, bn as Link, cr as PulseIcon, d as ArrowRightIcon, hi as TriangleDownIcon, hr as RepoForkedIcon, ii as TagIcon, jt as FileSymlinkFileIcon, kr as ShieldLockIcon, n as ActionList, ni as SyncIcon, o as AlertIcon, rn as HourglassIcon, rr as PlayIcon, u as ArrowLeftIcon, vn as LawIcon, wi as UploadIcon, wn as ListUnorderedIcon, wr as SearchIcon, wt as FileDirectoryFillIcon, xr as RocketIcon, yt as EyeIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { t as ActionMenu } from "./server-ActionMenu-CeaVI7oy-B_gsgQaE.js";
import { t as Popover_default } from "./server-Popover-CbuhIBzm-B9ivPq9a.js";
import { t as BlankslateContainer } from "./server-Blankslate-8HM0OrMZ-BZ-CSYUQ.js";
import { r as useNavigate$1 } from "./server-use-navigate-k2TIkaIE-Bckpf_v8.js";
import { d as sendCustomMetric } from "./server-safe-storage-Bd1FitcD-D0XBNZLq.js";
import { g as useLocation$1, t as Link$1 } from "./server-tanstack-router-migrate-47bJs1NQ-BklTF88H.js";
import { o as verifiedFetch, s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Label } from "./server-Label-KYPOGwxZ-Bjfs94n8.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { r as UnderlineNav } from "./server-Breadcrumbs-BHfIwzps-DJGX-BGq.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as Flash } from "./server-Flash-BufRUJBu-hWAywcNZ.js";
import { t as BranchName_default } from "./server-BranchName-HKnig0CO-C3hpegKL.js";
import { n as useIsDataRouterEnabled, t as SplitPageLayout } from "./server-use-is-data-router-enabled-Dufngmtk-DukzS4Iz.js";
import { t as SkeletonText } from "./server-SkeletonText-CFAYwgCj-WoK7i_Z0.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { l as useQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { $ as migrationWorkflowsPath, Bt as tagsPath, G as invitationsPath, It as repositoryTreePath, L as dismissRepositoryNoticePathPath, Mt as repositoryDeployPath, O as comparePath, Ot as repoOverviewUrl, Pt as repositoryPath, Q as migrateImmutableActionsPath, St as repoAccessSettingsPath, V as fetchAndMergePath, X as marketplaceActionPath, Z as mergeabilityCheckPath, c as branchPath, ct as ownerPath, l as branchesPath, lt as parentPath, rt as newRulesetPath, s as branchAndTagCountPath, tt as newPullRequestPath, wt as repoContributorsPath, yt as pullRequestPath, z as editBlobPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as CopyToClipboardButton } from "./server-CopyToClipboardButton-BAAaQn7--CaVzrBSx.js";
import { r as VerifiedHTMLDiv } from "./server-VerifiedHTML-BeDAtx5N-DHDqriRw.js";
import { n as useClickAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath, t as PathProvider } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo, t as RefInfoProvider } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { c as useUrlCreator, n as AllShortcutsEnabled, o as useCurrentUser, s as useReposAnalytics, t as ActionProvider } from "./server-AllShortcutsEnabled-DqZQXHPE-BIu50HqI.js";
import { t as CopilotSettingsProvider } from "./server-CopilotSettingsContext-D-uRcI6J-B_6IGvvo.js";
import { n as useEditPermissions, t as EditPermissionsProvider } from "./server-EditPermissionsContext-C1tNsLzr-Ds8kkvsw.js";
import { t as ScreenSize } from "./server-ScreenSize-jkeRvJSx-C0oTJYQy.js";
import { t as NewAgentTaskButton } from "./server-NewAgentTaskButton-gbUWCBSY-Cu9_75w7.js";
import { t as useReposAppPayload } from "./server-FilesPageInfoContext-pcRQmONi-DRtL2hSP.js";
import { a as useShortcut } from "./server-CodeViewOptionsProvider-BbVEg22k-CSlAib5i.js";
import { t as ReposHeaderRefSelector } from "./server-ReposHeaderRefSelector-D_1tuOMj-sntynq8H.js";
import { t as ScreenReaderHeading } from "./server-ScreenReaderHeading-CZREyNIU-kim4uHeg.js";
import { n as useRouteQuery } from "./server-use-route-query-mtPj6e6Z-uTFJH38R.js";
import { o as updateUrl } from "./server-history-ZqKl5Xoa-B59LrJnd.js";
import { n as useCodeViewAddBanner, t as CodeViewBannersProvider } from "./server-CodeViewBannersContext-CEdzkK6e-znl4nx1w.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { t as RelativeTime } from "./server-RelativeTime-BT_t8X9a-iYCha0Qg.js";
import { t as useAlive } from "./server-use-alive-Bs0u94wF-BuNgouIr.js";
import { t as buildCodespacesPath } from "./server-use-codespaces-data-B_J5e7_J-CHke9Nch.js";
import { n as ErrorBoundary } from "./server-ErrorBoundary-BUKaa7iB-BbaB4hnb.js";
import { r as useGetHovercardAttributesForType } from "./server-use-get-hovercard-attributes-for-type-ksXwCZJz-DFu3IrzK.js";
import { i as LocalTab, n as CodeDropdownButton, r as CodespacesTab } from "./server-CodeDropdownButton-7kY3jLbT-Bq5YZEI7.js";
import { n as UserNameDisplayContextProvider } from "./server-ProfileReference-BiGysK1d-VyvZmlrw.js";
import { t as TransactionalMessageBanner } from "./server-in-product-targeting-CynopFUF-BI4HZUnA.js";
import { n as agoString, t as CircleOcticon } from "./server-CircleOcticon-D83QpGqs-DfofKsPF.js";
import { t as AddFileDropdownButton } from "./server-AddFileDropdownButton-B6k5ztd6-CTXTm663.js";
import { t as CodeViewError } from "./server-CodeViewError-DTMNTptz-DKXztgzD.js";
import { n as useLatestCommitContext } from "./server-LatestCommitContext-D4oQqyj7-DHpYqCjL.js";
import { a as SharedMarkdownContent, c as SpoofedCommitWarningBanner, d as useLatestCommitIsSpoofed, i as PublishBanners, l as TableOfContentsPanel, n as LatestCommitContent, o as SkeletonText$1, t as CurrentTreeProvider, u as useCurrentTree } from "./server-PublishBanners-D6t9Jc-5-BK-GhWxy.js";
import { n as useUpdateRefInfoAndPath, t as useCanonicalObject } from "./server-use-update-ref-info-and-path-CakYhmiE-CuwmSmVs.js";
import { t as PreferredFileTypes } from "./server-overview-types-BCkg03zy-KrP1i6Gn.js";
import { t as codeViewRepoRoute } from "./server-code-view-repo-route-BsNI4mmi-Czvdqq85.js";
import { t as useWebVitals } from "./server-use-web-vitals-ePxIuvZ_-Cf0rAEz6.js";
import React, { Suspense, lazy, memo, startTransition, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
import { c as c$1 } from "react/compiler-runtime";
var classes$1 = { "TopicTag": "prc-TopicTag-TopicTag-LS-jX" };
function TopicTag$1(t0) {
	var _as;
	const $ = c(12);
	let as;
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({as, children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = as;
		$[2] = children;
		$[3] = className;
		$[4] = rest;
	} else {
		as = $[1];
		children = $[2];
		className = $[3];
		rest = $[4];
	}
	const BaseComponent = (_as = as) !== null && _as !== void 0 ? _as : "a";
	let t1;
	if ($[5] !== className) {
		t1 = clsx(className, classes$1.TopicTag);
		$[5] = className;
		$[6] = t1;
	} else t1 = $[6];
	let t2;
	if ($[7] !== BaseComponent || $[8] !== children || $[9] !== rest || $[10] !== t1) {
		t2 = /* @__PURE__ */ jsx(BaseComponent, {
			...rest,
			className: t1,
			children
		});
		$[7] = BaseComponent;
		$[8] = children;
		$[9] = rest;
		$[10] = t1;
		$[11] = t2;
	} else t2 = $[11];
	return t2;
}
var classes = { "TopicTagGroup": "prc-TopicTag-TopicTagGroup-CPva9" };
function TopicTagGroup(t0) {
	const $ = c(10);
	let children;
	let className;
	let rest;
	if ($[0] !== t0) {
		({children, className, ...rest} = t0);
		$[0] = t0;
		$[1] = children;
		$[2] = className;
		$[3] = rest;
	} else {
		children = $[1];
		className = $[2];
		rest = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = clsx(className, classes.TopicTagGroup);
		$[4] = className;
		$[5] = t1;
	} else t1 = $[5];
	let t2;
	if ($[6] !== children || $[7] !== rest || $[8] !== t1) {
		t2 = /* @__PURE__ */ jsx("div", {
			...rest,
			className: t1,
			children
		});
		$[6] = children;
		$[7] = rest;
		$[8] = t1;
		$[9] = t2;
	} else t2 = $[9];
	return t2;
}
var TopicTag = Object.assign(TopicTag$1, { Group: TopicTagGroup });
var BranchAndTagCountContext = React.createContext(null);
BranchAndTagCountContext.displayName = "BranchAndTagCountContext";
function useBranchAndTagCount() {
	return React.use(BranchAndTagCountContext);
}
function BranchAndTagCountProvider({ count, children }) {
	return /* @__PURE__ */ jsx(BranchAndTagCountContext, {
		value: count,
		children
	});
}
BranchAndTagCountProvider.displayName = "BranchAndTagCountProvider";
var CommitInfoContext = React.createContext({
	commitInfo: void 0,
	error: void 0,
	loading: false
});
CommitInfoContext.displayName = "CommitInfoContext";
function CommitInfoProvider(t0) {
	const $ = c$1(7);
	const { children, commitInfo, error, loading } = t0;
	let t1;
	if ($[0] !== commitInfo || $[1] !== error || $[2] !== loading) {
		t1 = {
			commitInfo,
			error,
			loading
		};
		$[0] = commitInfo;
		$[1] = error;
		$[2] = loading;
		$[3] = t1;
	} else t1 = $[3];
	const value = t1;
	let t2;
	if ($[4] !== children || $[5] !== value) {
		t2 = jsx(CommitInfoContext, {
			value,
			children
		});
		$[4] = children;
		$[5] = value;
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
CommitInfoProvider.displayName = "CommitInfoProvider";
function useCommitInfoContext() {
	return React.use(CommitInfoContext);
}
var noop = () => {};
var defaultValue = {
	branches: null,
	channel: null,
	canCreatePullRequest: true,
	refetch: noop
};
var RecentlyTouchedBranchesContext = React.createContext(defaultValue);
RecentlyTouchedBranchesContext.displayName = "RecentlyTouchedBranchesContext";
function useRecentlyTouchedBranches() {
	return React.use(RecentlyTouchedBranchesContext);
}
function RecentlyTouchedBranchesProvider(t0) {
	const $ = c$1(8);
	const { branches, channel, canCreatePullRequest: t1, refetch, children } = t0;
	const canCreatePullRequest = t1 === void 0 ? true : t1;
	let t2;
	if ($[0] !== branches || $[1] !== canCreatePullRequest || $[2] !== channel || $[3] !== refetch) {
		t2 = {
			branches,
			channel,
			canCreatePullRequest,
			refetch
		};
		$[0] = branches;
		$[1] = canCreatePullRequest;
		$[2] = channel;
		$[3] = refetch;
		$[4] = t2;
	} else t2 = $[4];
	const value = t2;
	let t3;
	if ($[5] !== children || $[6] !== value) {
		t3 = jsx(RecentlyTouchedBranchesContext, {
			value,
			children
		});
		$[5] = children;
		$[6] = value;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
RecentlyTouchedBranchesProvider.displayName = "RecentlyTouchedBranchesProvider";
var RailsPartial_module_default = { "d-contents": "RailsPartial-module_QsSTmq_d-contents" };
var RailsPartialUnmemoized = (t0) => {
	const $ = c$1(2);
	const { ref, route, partialName, className, skeleton, ...props } = t0;
	const fullPartialName = `${route.id}.${partialName}`;
	const { data: html, refetch, isLoading } = useRouteQuery(route, fullPartialName);
	let t1;
	if ($[0] !== refetch) {
		t1 = () => ({ refetch });
		$[0] = refetch;
		$[1] = t1;
	} else t1 = $[1];
	useImperativeHandle(ref, t1);
	return jsx(RailsPartialHTML, {
		partialName: fullPartialName,
		html,
		className,
		skeleton,
		isLoading,
		...props
	});
};
RailsPartialUnmemoized.displayName = "RailsPartial";
var RailsPartialHTML = memo(function RailsPartialHTML({ partialName, html, className, skeleton, isLoading = false, ...props }) {
	if (!html) return isLoading ? skeleton : null;
	return /* @__PURE__ */ jsx("rails-partial", {
		"data-partial-name": partialName,
		class: clsx(RailsPartial_module_default["d-contents"], className),
		dangerouslySetInnerHTML: { __html: html },
		suppressHydrationWarning: true,
		...props
	});
});
RailsPartialHTML.displayName = "RailsPartialHTML";
var RailsPartial = memo(RailsPartialUnmemoized);
RailsPartial.displayName = "RailsPartial";
function useBranchInfoBar() {
	const [data, setData] = useState();
	const [error, setError] = useState();
	const path = usePath();
	const refInfo = useRefInfo();
	const url = repositoryTreePath({
		repo: useCurrentRepository(),
		action: "branch-infobar",
		commitish: refInfo.name,
		path
	});
	useEffect(() => {
		const update = async () => {
			setData(void 0);
			const response = await verifiedFetchJSON(url);
			try {
				if (response.ok) setData(await response.json());
				else setError(response.status === 422 ? "timeout" : response.statusText);
			} catch (e) {
				setError(e?.message || e?.toString());
			}
		};
		update();
	}, [url]);
	return [data, error];
}
var InfobarPopover_module_default = {
	Box: "InfobarPopover-module_66Mjfa_Box",
	CircleOcticon: "InfobarPopover-module_66Mjfa_CircleOcticon",
	success: "InfobarPopover-module_66Mjfa_success"
};
/**
* This collection of components creates a consistent UI for the branch info bar.
* Once can compose the layout in the following way:
*
* <PopoverContainer>
*  <PopoverIcon>
*   <Icon />
*  </PopoverIcon>
*  <PopoverContent
*    icon={<PopoverIcon icon={AlertIcon} />}
*    header={<Text>Popup header</Text>}
*    content={<Text>Content of the popup</Text>}
*  />
*  <PopoverActionContainer>
*   <Button>Discard</Button>
*   <Button as={Link} className={clsx(linkButtonStyles.linkButton, 'flex-1')}>Update</Button>
*  </PopoverActionContainer>
* </PopoverContainer>
*
*/
function PopoverContainer({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: clsx("popover-container-width", InfobarPopover_module_default.Box),
		children
	});
}
PopoverContainer.displayName = "PopoverContainer";
function PopoverContent({ icon, header, content, headerRef }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "d-flex tmp-p-3",
		children: [/* @__PURE__ */ jsx("div", {
			className: "mr-2",
			children: icon
		}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
			ref: headerRef,
			tabIndex: -1,
			className: "f5 mb-1",
			children: header
		}), /* @__PURE__ */ jsx("span", {
			className: "fgColor-muted f6",
			children: content
		})] })]
	});
}
PopoverContent.displayName = "PopoverContent";
function PopoverIcon({ icon: IconComponent, success }) {
	return /* @__PURE__ */ jsx(CircleOcticon, {
		size: 30,
		icon: () => /* @__PURE__ */ jsx(IconComponent, { size: 16 }),
		className: clsx(InfobarPopover_module_default.CircleOcticon, success && InfobarPopover_module_default.success)
	});
}
PopoverIcon.displayName = "PopoverIcon";
function PopoverActions({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: "d-flex flex-wrap flex-justify-between tmp-p-3 gap-3 border-top borderColor-muted",
		children
	});
}
PopoverActions.displayName = "PopoverActions";
function getCommitsCountText(value) {
	return `${value} ${value === 1 ? "commit" : "commits"}`;
}
function RefComparisonText(t0) {
	const $ = c$1(15);
	const { comparison, repo, linkify: t1 } = t0;
	const linkify = t1 === void 0 ? false : t1;
	const { sendRepoClickEvent } = useReposAnalytics();
	const { ahead, behind, baseBranch, baseBranchRange, currentRef } = comparison;
	let t2;
	if ($[0] !== ahead || $[1] !== baseBranch || $[2] !== baseBranchRange || $[3] !== behind || $[4] !== currentRef || $[5] !== linkify || $[6] !== repo || $[7] !== sendRepoClickEvent) {
		t2 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const aheadLink = comparePath({
				repo,
				base: baseBranchRange,
				head: currentRef
			});
			const behindLink = comparePath({
				repo,
				base: currentRef,
				head: baseBranchRange
			});
			let t3;
			if ($[9] !== repo || $[10] !== sendRepoClickEvent) {
				t3 = () => sendRepoClickEvent("AHEAD_BEHIND_LINK", {
					category: "Branch Infobar",
					action: "Ahead Compare",
					label: `ref_loc:bar;is_fork:${repo.isFork}`
				});
				$[9] = repo;
				$[10] = sendRepoClickEvent;
				$[11] = t3;
			} else t3 = $[11];
			const sendAheadLinkAnalytics = t3;
			let t4;
			if ($[12] !== repo || $[13] !== sendRepoClickEvent) {
				t4 = () => sendRepoClickEvent("AHEAD_BEHIND_LINK", {
					category: "Branch Infobar",
					action: "Behind Compare",
					label: `ref_loc:bar;is_fork:${repo.isFork}`
				});
				$[12] = repo;
				$[13] = sendRepoClickEvent;
				$[14] = t4;
			} else t4 = $[14];
			const sendBehindLinkAnalytics = t4;
			if (ahead === 0 && behind === 0) {
				t2 = jsxs("span", { children: [
					"This branch is up to date with ",
					jsx(BranchName_default, {
						as: "span",
						children: baseBranch
					}),
					"."
				] });
				break bb0;
			}
			if (ahead > 0 && behind > 0) {
				t2 = jsxs("span", { children: [
					"This branch is",
					" ",
					jsxs(LinkOrText, {
						linkify,
						href: aheadLink,
						onClick: sendAheadLinkAnalytics,
						children: [getCommitsCountText(ahead), " ahead of"]
					}),
					" and ",
					jsxs(LinkOrText, {
						linkify,
						href: behindLink,
						onClick: sendBehindLinkAnalytics,
						children: [getCommitsCountText(behind), " behind"]
					}),
					" ",
					jsx(BranchName_default, {
						as: "span",
						children: baseBranch
					}),
					"."
				] });
				break bb0;
			}
			if (ahead > 0) {
				t2 = jsxs("span", { children: [
					"This branch is",
					" ",
					jsxs(LinkOrText, {
						linkify,
						href: aheadLink,
						onClick: sendAheadLinkAnalytics,
						children: [getCommitsCountText(ahead), " ahead of"]
					}),
					" ",
					jsx(BranchName_default, {
						as: "span",
						children: baseBranch
					}),
					"."
				] });
				break bb0;
			} else {
				t2 = jsxs("span", { children: [
					"This branch is",
					" ",
					jsxs(LinkOrText, {
						linkify,
						href: behindLink,
						onClick: sendBehindLinkAnalytics,
						children: [getCommitsCountText(behind), " behind"]
					}),
					" ",
					jsx(BranchName_default, {
						as: "span",
						children: baseBranch
					}),
					"."
				] });
				break bb0;
			}
		}
		$[0] = ahead;
		$[1] = baseBranch;
		$[2] = baseBranchRange;
		$[3] = behind;
		$[4] = currentRef;
		$[5] = linkify;
		$[6] = repo;
		$[7] = sendRepoClickEvent;
		$[8] = t2;
	} else t2 = $[8];
	if (t2 !== Symbol.for("react.early_return_sentinel")) return t2;
}
RefComparisonText.displayName = "RefComparisonText";
function LinkOrText({ href, linkify, children, ...props }) {
	if (linkify) return /* @__PURE__ */ jsx(Link, {
		href,
		...props,
		children
	});
	return /* @__PURE__ */ jsx("span", { children });
}
LinkOrText.displayName = "LinkOrText";
function ContributePopoverContent(t0) {
	const $ = c$1(4);
	const { comparison } = t0;
	const repo = useCurrentRepository();
	const isAhead = comparison.ahead > 0;
	let t1;
	if ($[0] !== comparison || $[1] !== isAhead || $[2] !== repo) {
		const aheadLink = comparePath({
			repo,
			base: comparison.baseBranchRange,
			head: comparison.currentRef
		});
		t1 = jsxs(Fragment$1, { children: [jsx(PopoverContent, {
			icon: jsx(PopoverIcon, { icon: GitPullRequestIcon }),
			header: isAhead ? jsx(RefComparisonText, {
				repo,
				comparison: {
					...comparison,
					behind: 0
				}
			}) : jsxs("span", { children: [
				"This branch is not ahead of the upstream ",
				jsx(BranchName_default, {
					as: "span",
					children: comparison.baseBranch
				}),
				"."
			] }),
			content: jsx("p", { children: isAhead ? "Open a pull request to contribute your changes upstream." : "No new commits yet. Enjoy your day!" })
		}), isAhead && jsxs(PopoverActions, { children: [!repo.isFork && jsx(LinkButton, {
			className: clsx(LinkButton_module_default.linkButton, "flex-1"),
			href: aheadLink,
			"data-testid": "compare-button",
			children: "Compare"
		}), jsx(LinkButton, {
			className: clsx(LinkButton_module_default.linkButton, "flex-1"),
			href: `${aheadLink}?expand=1`,
			variant: "primary",
			"data-testid": "open-pr-button",
			children: "Open pull request"
		})] })] });
		$[0] = comparison;
		$[1] = isAhead;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
ContributePopoverContent.displayName = "ContributePopoverContent";
function ContributeButton(t0) {
	const $ = c$1(5);
	const { comparison } = t0;
	const { sendRepoClickEvent } = useReposAnalytics();
	let t1;
	if ($[0] !== sendRepoClickEvent) {
		t1 = (open) => open && sendRepoClickEvent("CONTRIBUTE_BUTTON", {
			category: "Branch Infobar",
			action: "Open Contribute dropdown",
			label: "ref_loc:contribute_dropdown"
		});
		$[0] = sendRepoClickEvent;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== comparison || $[3] !== t1) {
		t2 = jsxs(ActionMenu, {
			onOpenChange: t1,
			children: [jsx(ActionMenu.Anchor, { children: jsx(ButtonComponent, {
				leadingVisual: GitPullRequestIcon,
				trailingVisual: TriangleDownIcon,
				children: "Contribute"
			}) }), jsx(ActionMenu.Overlay, {
				align: "end",
				className: "mt-2",
				children: jsx(PopoverContainer, { children: jsx(ContributePopoverContent, { comparison }) })
			})]
		});
		$[2] = comparison;
		$[3] = t1;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
ContributeButton.displayName = "ContributeButton";
function useBranchUpdater() {
	const $ = c$1(13);
	const repo = useCurrentRepository();
	const { name } = useRefInfo();
	let t0;
	if ($[0] !== name || $[1] !== repo) {
		t0 = fetchAndMergePath({
			repo,
			refName: name,
			discard: true
		});
		$[0] = name;
		$[1] = repo;
		$[2] = t0;
	} else t0 = $[2];
	const discardPath = t0;
	let t1;
	if ($[3] !== name || $[4] !== repo) {
		t1 = fetchAndMergePath({
			repo,
			refName: name,
			discard: false
		});
		$[3] = name;
		$[4] = repo;
		$[5] = t1;
	} else t1 = $[5];
	const updatePath = t1;
	let t2;
	if ($[6] !== updatePath) {
		t2 = () => verifiedFetch(updatePath, { method: "POST" });
		$[6] = updatePath;
		$[7] = t2;
	} else t2 = $[7];
	const updateBranch = t2;
	let t3;
	if ($[8] !== discardPath) {
		t3 = () => verifiedFetch(discardPath, { method: "POST" });
		$[8] = discardPath;
		$[9] = t3;
	} else t3 = $[9];
	const discardChanges = t3;
	let t4;
	if ($[10] !== discardChanges || $[11] !== updateBranch) {
		t4 = {
			updateBranch,
			discardChanges
		};
		$[10] = discardChanges;
		$[11] = updateBranch;
		$[12] = t4;
	} else t4 = $[12];
	return t4;
}
function useMergeabilityCheck(t0) {
	const $ = c$1(11);
	const { head, base } = t0;
	const [data, setData] = useState();
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState();
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== base || $[1] !== head || $[2] !== repo) {
		t1 = mergeabilityCheckPath({
			repo,
			head,
			base
		});
		$[0] = base;
		$[1] = head;
		$[2] = repo;
		$[3] = t1;
	} else t1 = $[3];
	const url = t1;
	let t2;
	let t3;
	if ($[4] !== url) {
		t2 = () => {
			const update = async () => {
				setLoading(true);
				setData(void 0);
				const response = await verifiedFetchJSON(url);
				try {
					if (response.ok) setData((await response.json()).state);
					else setError(response.statusText);
				} catch (t4) {
					const e = t4;
					setError(e?.message || e?.toString());
				}
				setLoading(false);
			};
			update();
		};
		t3 = [url];
		$[4] = url;
		$[5] = t2;
		$[6] = t3;
	} else {
		t2 = $[5];
		t3 = $[6];
	}
	useEffect(t2, t3);
	let t4;
	if ($[7] !== data || $[8] !== error || $[9] !== loading) {
		t4 = [
			data,
			loading,
			error
		];
		$[7] = data;
		$[8] = error;
		$[9] = loading;
		$[10] = t4;
	} else t4 = $[10];
	return t4;
}
function useDisabledWithLabel(label, disabledLabel, action) {
	const $ = c$1(6);
	const [disabled, setDisabled] = useState(false);
	const t0 = disabled ? disabledLabel : label;
	let t1;
	if ($[0] !== action) {
		t1 = async () => {
			setDisabled(true);
			await action();
			setDisabled(false);
		};
		$[0] = action;
		$[1] = t1;
	} else t1 = $[1];
	let t2;
	if ($[2] !== disabled || $[3] !== t0 || $[4] !== t1) {
		t2 = {
			disabled,
			label: t0,
			action: t1
		};
		$[2] = disabled;
		$[3] = t0;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
var syncForkButtonEventPayload = {
	category: "Branch Infobar",
	label: `ref_loc:fetch_upstream_dropdown`
};
function FetchUpstreamPopoverContent({ comparison, discard, update }) {
	const repo = useCurrentRepository();
	const { helpUrl } = useReposAppPayload();
	const { sendRepoClickEvent } = useReposAnalytics();
	const syncingForkHelpUrl = `${helpUrl}/github/collaborating-with-issues-and-pull-requests/syncing-a-fork`;
	const compareBranchesPath = comparePath({
		repo,
		base: comparison.baseBranchRange,
		head: comparison.currentRef
	});
	const comparisonState = getComparisonState(comparison);
	const isBehind = comparison.behind > 0;
	const discardButton = useDisabledWithLabel(`Discard ${getCommitsCountText(comparison.ahead)}`, "Discarding changes...", discard);
	const updateButton = useDisabledWithLabel("Update branch", "Updating...", update);
	const visible = {
		compare: comparisonState === "behind",
		discard: comparisonState === "behind-and-ahead" && comparison.isTrackingBranch,
		update: ["behind", "behind-and-ahead"].includes(comparisonState)
	};
	const hasVisibleActions = Object.values(visible).some(Boolean);
	const headerRef = useRef(null);
	useEffect(() => {
		const timeout = window.setTimeout(() => headerRef.current?.focus());
		return () => {
			window.clearTimeout(timeout);
		};
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(PopoverContent, {
		icon: /* @__PURE__ */ jsx(PopoverIcon, {
			icon: isBehind ? GitMergeIcon : CheckIcon,
			success: !isBehind
		}),
		headerRef,
		header: /* @__PURE__ */ jsx(HeaderText, { comparison }),
		content: /* @__PURE__ */ jsx(ContentText, {
			comparison,
			helpUrl: syncingForkHelpUrl
		})
	}), hasVisibleActions && /* @__PURE__ */ jsxs(PopoverActions, { children: [
		visible.compare && /* @__PURE__ */ jsx(ButtonComponent, {
			as: Link,
			className: clsx(LinkButton_module_default.linkButton, "flex-1"),
			href: compareBranchesPath,
			onClick: () => sendRepoClickEvent("SYNC_FORK.COMPARE", {
				...syncForkButtonEventPayload,
				action: "Compare"
			}),
			"data-testid": "compare-button",
			children: "Compare"
		}),
		visible.discard && /* @__PURE__ */ jsx(ButtonComponent, {
			onClick: discardButton.action,
			className: "flex-1",
			"data-testid": "discard-button",
			variant: "danger",
			disabled: discardButton.disabled,
			children: discardButton.label
		}),
		visible.update && /* @__PURE__ */ jsx(ButtonComponent, {
			onClick: updateButton.action,
			disabled: updateButton.disabled,
			className: "flex-1",
			variant: "primary",
			"data-testid": "update-branch-button",
			children: updateButton.label
		})
	] })] });
}
FetchUpstreamPopoverContent.displayName = "FetchUpstreamPopoverContent";
function getComparisonState({ behind, ahead }) {
	if (behind === 0 && ahead === 0) return "sync";
	if (behind > 0 && ahead > 0) return "behind-and-ahead";
	if (behind > 0) return "behind";
	return "ahead";
}
function HeaderText({ comparison }) {
	switch (getComparisonState(comparison)) {
		case "behind":
		case "behind-and-ahead": return /* @__PURE__ */ jsx("span", { children: "This branch is out-of-date" });
		default: return /* @__PURE__ */ jsxs("span", { children: [
			"This branch is not behind the upstream ",
			/* @__PURE__ */ jsx(BranchName_default, {
				as: "span",
				children: comparison.baseBranch
			}),
			"."
		] });
	}
}
HeaderText.displayName = "HeaderText";
function ContentText({ comparison, helpUrl }) {
	switch (getComparisonState(comparison)) {
		case "sync":
		case "ahead": return /* @__PURE__ */ jsx("p", { children: "No new commits to fetch. Enjoy your day!" });
		case "behind": return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("p", { children: [
			"Update branch to keep this branch up-to-date by syncing ",
			getCommitsCountText(comparison.behind),
			" from the upstream repository."
		] }), /* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx(Link, {
			href: helpUrl,
			target: "_blank",
			rel: "noopener noreferrer",
			children: "Learn more about syncing a fork"
		}) })] });
		case "behind-and-ahead": return comparison.isTrackingBranch ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx("p", { children: "Update branch to merge the latest changes from the upstream repository into this branch." }),
			/* @__PURE__ */ jsxs("p", { children: [
				"Discard ",
				getCommitsCountText(comparison.ahead),
				" to make this branch match the upstream repository.",
				" ",
				getCommitsCountText(comparison.ahead),
				" will be removed from this branch."
			] }),
			/* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx(Link, {
				href: helpUrl,
				target: "_blank",
				rel: "noopener noreferrer",
				children: "Learn more about syncing a fork"
			}) })
		] }) : /* @__PURE__ */ jsx("p", { children: "Update branch to merge the latest changes from the upstream repository into this branch." });
	}
}
ContentText.displayName = "ContentText";
function FetchUpstreamWithConflictsPopoverContent(t0) {
	const $ = c$1(2);
	const { comparison, discard } = t0;
	const repo = useCurrentRepository();
	const { sendRepoClickEvent } = useReposAnalytics();
	const createPullRequestPath = newPullRequestPath({
		repo,
		refName: comparison.currentRef
	});
	const commitsCountText = getCommitsCountText(comparison.ahead);
	const discardButton = useDisabledWithLabel(`Discard ${commitsCountText}`, "Discarding changes...", discard);
	let t1;
	if ($[0] !== sendRepoClickEvent) {
		t1 = () => sendRepoClickEvent("SYNC_FORK.OPEN_PR", {
			...syncForkButtonEventPayload,
			action: "Open pull request"
		});
		$[0] = sendRepoClickEvent;
		$[1] = t1;
	} else t1 = $[1];
	return jsxs(Fragment$1, { children: [jsx(PopoverContent, {
		icon: jsx(PopoverIcon, { icon: AlertIcon }),
		header: "This branch has conflicts that must be resolved",
		content: jsxs(Fragment$1, { children: [jsxs("p", { children: [
			"Discard ",
			commitsCountText,
			" to make this branch match the upstream repository. ",
			commitsCountText,
			" will be removed from this branch."
		] }), jsx("p", { children: "You can resolve merge conflicts using the command line and a text editor." })] })
	}), jsxs(PopoverActions, { children: [jsx(ButtonComponent, {
		className: "flex-1",
		onClick: discardButton.action,
		disabled: discardButton.disabled,
		"data-testid": "discard-button",
		variant: "danger",
		children: discardButton.label
	}), jsx(ButtonComponent, {
		as: Link,
		className: clsx(LinkButton_module_default.linkButton, "flex-1"),
		href: createPullRequestPath,
		variant: "primary",
		"data-testid": "open-pr-button",
		onClick: t1,
		children: "Open pull request"
	})] })] });
}
FetchUpstreamWithConflictsPopoverContent.displayName = "FetchUpstreamWithConflictsPopoverContent";
function FetchPopoverContainer({ comparison }) {
	const [mergeabilityState, loading, error] = useMergeabilityCheck({
		base: comparison.currentRef,
		head: comparison.baseBranchRange
	});
	const { sendRepoClickEvent } = useReposAnalytics();
	const { discardChanges, updateBranch } = useBranchUpdater();
	const discardAndReload = async () => {
		sendRepoClickEvent("SYNC_FORK.DISCARD", {
			...syncForkButtonEventPayload,
			action: "Discard Conflicts"
		});
		const response = await discardChanges();
		if (response.ok && response.url) window.location.href = response.url;
	};
	const updateAndReload = async () => {
		sendRepoClickEvent("SYNC_FORK.UPDATE", {
			...syncForkButtonEventPayload,
			action: "Fetch and merge"
		});
		const response_0 = await updateBranch();
		if (response_0.ok && response_0.url) window.location.href = response_0.url;
	};
	if (comparison.behind === 0) return /* @__PURE__ */ jsx(FetchUpstreamPopoverContent, {
		update: updateAndReload,
		discard: discardAndReload,
		comparison
	});
	if (loading || error) return /* @__PURE__ */ jsx("div", {
		className: "tmp-p-4 d-flex flex-justify-center",
		children: /* @__PURE__ */ jsx(Spinner, {})
	});
	if (mergeabilityState === "clean") return /* @__PURE__ */ jsx(FetchUpstreamPopoverContent, {
		update: updateAndReload,
		discard: discardAndReload,
		comparison
	});
	return /* @__PURE__ */ jsx(FetchUpstreamWithConflictsPopoverContent, {
		discard: discardAndReload,
		comparison
	});
}
FetchPopoverContainer.displayName = "FetchPopoverContainer";
function FetchUpstreamButton(t0) {
	const $ = c$1(6);
	const { comparison } = t0;
	const { sendRepoClickEvent } = useReposAnalytics();
	let t1;
	if ($[0] !== comparison || $[1] !== sendRepoClickEvent) {
		t1 = (open) => open && sendRepoClickEvent("SYNC_FORK_BUTTON", {
			category: "Branch Infobar",
			action: "Open Fetch upstream dropdown",
			label: "ref_loc:fetch_upstream_dropdown",
			ahead: comparison.ahead,
			behind: comparison.behind
		});
		$[0] = comparison;
		$[1] = sendRepoClickEvent;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== comparison || $[4] !== t1) {
		t2 = jsxs(ActionMenu, {
			onOpenChange: t1,
			children: [jsx(ActionMenu.Anchor, { children: jsx(ButtonComponent, {
				leadingVisual: SyncIcon,
				trailingAction: TriangleDownIcon,
				children: "Sync fork"
			}) }), jsx(ActionMenu.Overlay, {
				align: "end",
				className: "mt-2",
				children: jsx(PopoverContainer, { children: jsx(FetchPopoverContainer, { comparison }) })
			})]
		});
		$[3] = comparison;
		$[4] = t1;
		$[5] = t2;
	} else t2 = $[5];
	return t2;
}
FetchUpstreamButton.displayName = "FetchUpstreamButton";
var PullRequestLink_module_default = { Link: "PullRequestLink-module_J7HxWq_Link" };
function PullRequestLink({ repo, pullRequestNumber }) {
	return /* @__PURE__ */ jsxs(Link, {
		href: pullRequestPath({
			repo,
			number: pullRequestNumber
		}),
		className: PullRequestLink_module_default.Link,
		children: [
			/* @__PURE__ */ jsx(GitPullRequestIcon, { size: 16 }),
			"#",
			pullRequestNumber
		]
	});
}
PullRequestLink.displayName = "PullRequestLink";
var BranchInfoBar_module_default = {
	branchInfoBarBase: "BranchInfoBar-module_3OXc0G_branchInfoBarBase",
	BranchInfoBarContainer: "BranchInfoBar-module_3OXc0G_BranchInfoBarContainer"
};
function BranchInfoBar(t0) {
	const $ = c$1(5);
	const { className } = t0;
	const [infoBar, error] = useBranchInfoBar();
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== className || $[1] !== error || $[2] !== infoBar || $[3] !== repo) {
		let content;
		if (error === "timeout") content = jsx(Fragment$1, { children: "Sorry, getting ahead/behind information for this branch is taking too long." });
		else if (!infoBar) content = jsxs(Fragment$1, { children: [jsx(SkeletonText$1, { width: "40%" }), jsx(SkeletonText$1, { width: "30%" })] });
		else if (!infoBar.refComparison) content = jsx(Fragment$1, { children: "Cannot retrieve ahead/behind information for this branch." });
		else content = jsxs(Fragment$1, { children: [jsx(RefComparisonText, {
			linkify: true,
			repo,
			comparison: infoBar.refComparison
		}), jsx("div", {
			className: "d-flex gap-2",
			children: infoBar.pullRequestNumber ? jsx(PullRequestLink, {
				repo,
				pullRequestNumber: infoBar.pullRequestNumber
			}) : jsxs(Fragment$1, { children: [repo.currentUserCanPush && jsx(ContributeButton, { comparison: infoBar.refComparison }), repo.isFork && repo.currentUserCanPush && jsx(FetchUpstreamButton, { comparison: infoBar.refComparison })] })
		})] });
		t1 = jsx(BranchInfoBarContainer, {
			className: clsx(BranchInfoBar_module_default.BranchInfoBarContainer, className),
			children: content
		});
		$[0] = className;
		$[1] = error;
		$[2] = infoBar;
		$[3] = repo;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
BranchInfoBar.displayName = "BranchInfoBar";
function BranchInfoBarContainer({ children, className }) {
	return /* @__PURE__ */ jsx("div", {
		"data-testid": "branch-info-bar",
		"aria-live": "polite",
		className: clsx(BranchInfoBar_module_default.branchInfoBarBase, className),
		children
	});
}
BranchInfoBarContainer.displayName = "BranchInfoBarContainer";
function BranchInfoBarErrorBanner() {
	return /* @__PURE__ */ jsx(Flash, {
		variant: "warning",
		className: "tmp-my-3",
		children: /* @__PURE__ */ jsx("span", { children: "Cannot retrieve comparison with upstream repository." })
	});
}
BranchInfoBarErrorBanner.displayName = "BranchInfoBarErrorBanner";
/**
* Unique ID counter for store instances.
*/
var storeId = 0;
/**
* Module-level store for ephemeral focus hints.
*
* Hints are set before navigation and consumed on the destination page.
* They automatically become invalid after subsequent navigation.
*/
var store = null;
function getLocationKey() {
	if (typeof window === "undefined") return "";
	return window.location.pathname + window.location.search;
}
/**
* Set a focus hint to be consumed on the next navigation.
*
* Call this BEFORE navigating (e.g., in an onClick handler before navigate()).
* The hint will be available on the destination page via useFocusHint().
*
* @example
* function MyComponent() {
*   const navigate = useNavigate()
*
*   return (
*     <button onClick={() => {
*       setFocusHint('my-button')
*       navigate('/next-page')
*     }}>
*       Go to next page
*     </button>
*   )
* }
*/
function setFocusHint(hint, context) {
	storeId++;
	store = {
		id: storeId,
		hint,
		context,
		setAt: getLocationKey(),
		consumedAt: null
	};
}
/**
* Read the current focus hint.
*
* Returns the hint if one was set on the previous page, null otherwise.
* The hint is ephemeral - valid only for the first navigation after
* it was set, and automatically cleared on subsequent navigations.
*
* @example
* function DestinationPage() {
*   const { focusHint } = useFocusHint()
*
*   return (
*     <button data-react-autofocus={focusHint === 'my-button' ? true : null}>
*       This will be focused if hint matches
*     </button>
*   )
* }
*/
function useFocusHint() {
	const $ = c$1(7);
	const location = useLocation$1();
	const currentLocation = location.pathname + location.search;
	const currentStoreId = store?.id ?? null;
	let t0;
	let t1;
	if ($[0] !== currentLocation) {
		t0 = () => {
			if (!store || store.id !== currentStoreId) return;
			if (store.setAt !== currentLocation) {
				if (store.consumedAt === null) store.consumedAt = currentLocation;
				else if (store.consumedAt !== currentLocation) store = null;
			}
		};
		t1 = [currentLocation, currentStoreId];
		$[0] = currentLocation;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	if (!store) {
		let t2;
		if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = {
				focusHint: null,
				context: void 0
			};
			$[3] = t2;
		} else t2 = $[3];
		return t2;
	}
	if (store.setAt === currentLocation) {
		let t2;
		if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = {
				focusHint: null,
				context: void 0
			};
			$[4] = t2;
		} else t2 = $[4];
		return t2;
	}
	if (store.consumedAt !== null && store.consumedAt !== currentLocation) {
		let t2;
		if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
			t2 = {
				focusHint: null,
				context: void 0
			};
			$[5] = t2;
		} else t2 = $[5];
		return t2;
	}
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = {
			focusHint: store.hint,
			context: store.context
		};
		$[6] = t2;
	} else t2 = $[6];
	return t2;
}
function useCommitInfo() {
	const $ = c$1(8);
	const path = usePath();
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = { loading: true };
		$[0] = t0;
	} else t0 = $[0];
	const [state, setState] = useState(t0);
	const addBanner = useCodeViewAddBanner();
	const repoName = repo.name;
	const repoOwner = repo.ownerLogin;
	const refName = refInfo.name;
	let t1;
	let t2;
	if ($[1] !== addBanner || $[2] !== path || $[3] !== refName || $[4] !== repoName || $[5] !== repoOwner) {
		t1 = () => {
			const commitPath = repositoryTreePath({
				repo: {
					name: repoName,
					ownerLogin: repoOwner
				},
				action: "tree-commit-info",
				commitish: refName,
				path
			});
			let cancelled = false;
			const update = async () => {
				setState({ loading: true });
				const response = await verifiedFetchJSON(commitPath);
				if (cancelled) return;
				try {
					if (response.ok) setState({ commitInfo: await response.json() });
					else {
						addBanner({
							variant: "warning",
							message: "Failed to load latest commit information."
						});
						setState({ error: true });
					}
				} catch {
					setState({ error: true });
				}
			};
			update();
			return function cancel() {
				cancelled = true;
			};
		};
		t2 = [
			addBanner,
			path,
			refName,
			repoName,
			repoOwner
		];
		$[1] = addBanner;
		$[2] = path;
		$[3] = refName;
		$[4] = repoName;
		$[5] = repoOwner;
		$[6] = t1;
		$[7] = t2;
	} else {
		t1 = $[6];
		t2 = $[7];
	}
	useEffect(t1, t2);
	return state;
}
/**
* Returns a list that is initially truncated to `initialCount` items, and then
* returns the full list after the initial paint. This is useful in cases where
* we want to display a large list of items, we don't want to virtualize (for
* UX or accessibility reasons), but we also don't want the DOM reconciliation
* for all of these elements to block the user from seeing the initial content.
*
* Uses `startTransition` so React can interrupt the full-list render to handle
* user interactions, improving INP.
*/
function useInitiallyTruncatedList(allItems, initialCount) {
	const $ = c$1(10);
	const [truncated, setTruncated] = useState(allItems.length > initialCount);
	let t0;
	let t1;
	if ($[0] !== truncated) {
		t0 = () => {
			if (truncated) startTransition(() => {
				setTruncated(false);
			});
		};
		t1 = [truncated];
		$[0] = truncated;
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	useEffect(t0, t1);
	let t2;
	if ($[3] !== allItems || $[4] !== initialCount || $[5] !== truncated) {
		t2 = truncated ? allItems.slice(0, initialCount) : allItems;
		$[3] = allItems;
		$[4] = initialCount;
		$[5] = truncated;
		$[6] = t2;
	} else t2 = $[6];
	const items = t2;
	let t3;
	if ($[7] !== items || $[8] !== truncated) {
		t3 = {
			truncated,
			items
		};
		$[7] = items;
		$[8] = truncated;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
function Dropzone({ uploadUrl }) {
	return /* @__PURE__ */ jsx("document-dropzone", { children: /* @__PURE__ */ jsx("div", {
		className: "repo-file-upload-tree-target js-upload-manifest-tree-view",
		"data-testid": "dragzone",
		"data-drop-url": uploadUrl,
		"data-target": "document-dropzone.dropContainer",
		children: /* @__PURE__ */ jsx("div", {
			className: "repo-file-upload-outline",
			children: /* @__PURE__ */ jsxs("div", {
				className: "repo-file-upload-slate",
				children: [/* @__PURE__ */ jsx("div", {
					className: "fgColor-muted",
					children: /* @__PURE__ */ jsx(FileIcon, { size: 32 })
				}), /* @__PURE__ */ jsx("h2", {
					"aria-hidden": "true",
					children: "Drop to upload your files"
				})]
			})
		})
	}) });
}
Dropzone.displayName = "Dropzone";
var contentTypeLabels = {
	directory: "Directory",
	submodule: "Submodule",
	["symlink_directory"]: "Symlink to directory",
	["symlink_file"]: "Symlink to file"
};
function getContentTypeLabel({ contentType }) {
	return `(${contentTypeLabels[contentType] || "File"})`;
}
function IconCell({ item }) {
	switch (item.contentType) {
		case "directory": return /* @__PURE__ */ jsx(FileDirectoryFillIcon, { className: "icon-directory" });
		case "submodule": return /* @__PURE__ */ jsx(FileSubmoduleIcon, { className: "icon-directory" });
		case "symlink_directory": return /* @__PURE__ */ jsx(FileSubmoduleIcon, { className: "icon-directory" });
		case "symlink_file": return /* @__PURE__ */ jsx(FileSymlinkFileIcon, { className: "icon-directory" });
		default: return /* @__PURE__ */ jsx(FileIcon, { className: "color-fg-muted" });
	}
}
IconCell.displayName = "IconCell";
function NameCell({ initialFocus, item, getItemUrl, onNavigate }) {
	let itemUrl = getItemUrl(item);
	const tooltipText = item.hasSimplifiedPath ? "This path skips through empty directories" : item.name;
	if (item.contentType === "submodule") {
		itemUrl = item.submoduleUrl ?? itemUrl;
		onNavigate = (e) => {
			e.preventDefault();
			if (item.submoduleUrl) window.location.href = item.submoduleUrl;
		};
	}
	return /* @__PURE__ */ jsx("div", {
		className: "overflow-hidden",
		children: /* @__PURE__ */ jsx("div", {
			className: "react-directory-filename-cell",
			children: /* @__PURE__ */ jsx("div", {
				className: "react-directory-truncate",
				children: /* @__PURE__ */ jsx(Link$1, {
					title: tooltipText,
					"aria-label": `${item.name}, ${getContentTypeLabel(item)}`,
					className: item.contentType !== "symlink_directory" && item.contentType !== "symlink_file" ? "Link--primary" : void 0,
					"data-react-autofocus": initialFocus ? true : null,
					onClick: onNavigate,
					to: itemUrl,
					children: /* @__PURE__ */ jsx(ItemPathName, { item })
				})
			})
		})
	});
}
NameCell.displayName = "NameCell";
function ItemPathName({ item }) {
	if (item.hasSimplifiedPath) return /* @__PURE__ */ jsx(Fragment$1, { children: item.name.split("/").map((dirName, index, array) => {
		const isLastItem = index === array.length - 1;
		return /* @__PURE__ */ jsx("span", {
			className: isLastItem ? "" : "react-directory-default-color",
			"data-testid": "path-name-segment",
			children: `${dirName}${isLastItem ? "" : "/"}`
		}, index);
	}) });
	return item.submoduleDisplayName ? /* @__PURE__ */ jsx("span", {
		style: { color: "var(--fgColor-accent, var(--color-accent-fg))" },
		children: item.submoduleDisplayName
	}) : /* @__PURE__ */ jsx(Fragment$1, { children: item.name });
}
ItemPathName.displayName = "ItemPathName";
function CommitMessageCell({ commit }) {
	if (!commit) return /* @__PURE__ */ jsx(SkeletonText$1, {});
	return commit.shortMessageHtmlLink ? /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(VerifiedHTMLDiv, {
		className: "react-directory-commit-message",
		html: commit.shortMessageHtmlLink
	}) }) : /* @__PURE__ */ jsx(Link, {
		className: "Link--secondary",
		href: commit.url,
		children: "No commit message"
	});
}
CommitMessageCell.displayName = "CommitMessageCell";
function CommitAgeCell({ commit }) {
	return /* @__PURE__ */ jsx("div", {
		className: "react-directory-commit-age",
		children: commit?.date ? !Number.isNaN(Date.parse(commit.date)) ? /* @__PURE__ */ jsx(RelativeTime, {
			datetime: commit.date,
			tense: "past"
		}) : "Invalid date" : /* @__PURE__ */ jsx(SkeletonText$1, {})
	});
}
CommitAgeCell.displayName = "CommitAgeCell";
var Table_module_default = {
	Box: "Table-module_RItxvG_Box",
	Box_1: "Table-module_RItxvG_Box_1",
	Box_2: "Table-module_RItxvG_Box_2",
	Box_3: "Table-module_RItxvG_Box_3",
	Box_4: "Table-module_RItxvG_Box_4"
};
/**
* Table Frame component
* @param as - Use `ul` only when all children are `li` items, otherwise add a nested `ul` at your convenience.
*/
function Table({ children, className, ...props }) {
	return /* @__PURE__ */ jsx("table", {
		className: clsx(Table_module_default.Box, className),
		...props,
		children
	});
}
Table.displayName = "Table";
var HeaderRow = ({ children, className }) => {
	return /* @__PURE__ */ jsx("thead", {
		className: clsx(className, Table_module_default.Box_1),
		children: /* @__PURE__ */ jsx("tr", {
			className: Table_module_default.Box_2,
			children
		})
	});
};
HeaderRow.displayName = "HeaderRow";
var Row = ({ children, onClick, index, id }) => {
	return /* @__PURE__ */ jsx("tr", {
		onClick,
		"data-index": index,
		id,
		className: Table_module_default.Box_3,
		children
	});
};
Row.displayName = "Row";
var TableFooter = ({ children }) => {
	return /* @__PURE__ */ jsx("tfoot", {
		className: Table_module_default.Box_4,
		children
	});
};
TableFooter.displayName = "TableFooter";
var DirectoryRow_module_default = {
	Box: "DirectoryRow-module_4HAKma_Box",
	Octicon: "DirectoryRow-module_4HAKma_Octicon",
	PrimerLink: "DirectoryRow-module_4HAKma_PrimerLink"
};
var RowContent = ({ className, onClickHandler, index, item, initialFocus, getItemUrl, onNavigate, commit }) => /* @__PURE__ */ jsxs("tr", {
	className: `react-directory-row ${className}`,
	onClick: onClickHandler,
	id: `folder-row-${index}`,
	children: [
		/* @__PURE__ */ jsx("td", {
			className: "react-directory-row-name-cell-small-screen",
			colSpan: 2,
			children: /* @__PURE__ */ jsxs("div", {
				className: "react-directory-filename-column",
				children: [/* @__PURE__ */ jsx(IconCell, { item }), /* @__PURE__ */ jsx(NameCell, {
					initialFocus,
					item,
					getItemUrl,
					onNavigate
				})]
			})
		}),
		/* @__PURE__ */ jsx("td", {
			className: "react-directory-row-name-cell-large-screen",
			colSpan: 1,
			children: /* @__PURE__ */ jsxs("div", {
				className: "react-directory-filename-column",
				children: [/* @__PURE__ */ jsx(IconCell, { item }), /* @__PURE__ */ jsx(NameCell, {
					initialFocus,
					item,
					getItemUrl,
					onNavigate
				})]
			})
		}),
		/* @__PURE__ */ jsx("td", {
			className: "react-directory-row-commit-cell",
			children: /* @__PURE__ */ jsx(CommitMessageCell, { commit })
		}),
		/* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx(CommitAgeCell, { commit }) })
	]
});
RowContent.displayName = "RowContent";
function WrappedDirectoryRow(t0) {
	const $ = c$1(13);
	const { initialFocus, item, commit, onNavigate, getItemUrl, navigate, index, className } = t0;
	let t1;
	if ($[0] !== getItemUrl || $[1] !== item || $[2] !== navigate) {
		t1 = (e) => {
			if (window.matchMedia(`(max-width: ${ScreenSize.small - 1}px)`).matches && !e.defaultPrevented) if (item.contentType === "submodule") {
				const submoduleUrl = item.submoduleUrl;
				if (submoduleUrl) startTransition(() => navigate(submoduleUrl));
			} else startTransition(() => navigate(getItemUrl(item)));
		};
		$[0] = getItemUrl;
		$[1] = item;
		$[2] = navigate;
		$[3] = t1;
	} else t1 = $[3];
	const onClickHandler = t1;
	let t2;
	if ($[4] !== className || $[5] !== commit || $[6] !== getItemUrl || $[7] !== index || $[8] !== initialFocus || $[9] !== item || $[10] !== onClickHandler || $[11] !== onNavigate) {
		t2 = jsx(RowContent, {
			className,
			onClickHandler,
			index,
			item,
			initialFocus,
			getItemUrl,
			onNavigate,
			commit
		});
		$[4] = className;
		$[5] = commit;
		$[6] = getItemUrl;
		$[7] = index;
		$[8] = initialFocus;
		$[9] = item;
		$[10] = onClickHandler;
		$[11] = onNavigate;
		$[12] = t2;
	} else t2 = $[12];
	return t2;
}
WrappedDirectoryRow.displayName = "WrappedDirectoryRow";
var DirectoryRow = React.memo(WrappedDirectoryRow);
DirectoryRow.displayName = "DirectoryRow";
function GoDirectoryUpRowInner(t0) {
	const $ = c$1(11);
	const { initialFocus, linkTo, linkRef, navigate } = t0;
	const path = usePath();
	let t1;
	if ($[0] !== linkTo || $[1] !== navigate) {
		t1 = () => {
			if (window.matchMedia(`(max-width: ${ScreenSize.medium - 1}px)`).matches) startTransition(() => navigate(linkTo));
		};
		$[0] = linkTo;
		$[1] = navigate;
		$[2] = t1;
	} else t1 = $[2];
	const onClickHandler = t1;
	let t2;
	if ($[3] !== initialFocus || $[4] !== linkRef || $[5] !== linkTo || $[6] !== onClickHandler || $[7] !== path) {
		let t3;
		if ($[9] !== path) {
			t3 = () => setFocusHint(path);
			$[9] = path;
			$[10] = t3;
		} else t3 = $[10];
		t2 = jsx(Row, {
			onClick: onClickHandler,
			id: "folder-row-0",
			children: jsxs("td", {
				colSpan: 3,
				className: "f5 text-normal tmp-px-3",
				children: [jsx(ScreenReaderHeading, {
					as: "h3",
					text: "parent directory"
				}), jsx(Link, {
					"aria-label": "Parent directory",
					"data-react-autofocus": initialFocus ? true : null,
					"data-testid": "up-tree",
					as: Link$1,
					muted: true,
					onClick: t3,
					ref: linkRef,
					rel: "nofollow",
					to: linkTo,
					className: DirectoryRow_module_default.PrimerLink,
					children: jsxs("div", {
						className: clsx("width-full", DirectoryRow_module_default.Box),
						children: [jsx(Octicon, {
							icon: FileDirectoryFillIcon,
							size: "small",
							className: DirectoryRow_module_default.Octicon
						}), ".."]
					})
				})]
			})
		});
		$[3] = initialFocus;
		$[4] = linkRef;
		$[5] = linkTo;
		$[6] = onClickHandler;
		$[7] = path;
		$[8] = t2;
	} else t2 = $[8];
	return t2;
}
GoDirectoryUpRowInner.displayName = "GoDirectoryUpRowInner";
var GoDirectoryUpRow = React.memo(GoDirectoryUpRowInner);
GoDirectoryUpRow.displayName = "GoDirectoryUpRow";
var DirectoryContent_module_default = {
	Box: "DirectoryContent-module_6nsluG_Box",
	Box_1: "DirectoryContent-module_6nsluG_Box_1",
	Box_2: "DirectoryContent-module_6nsluG_Box_2",
	Box_3: "DirectoryContent-module_6nsluG_Box_3",
	Box_4: "DirectoryContent-module_6nsluG_Box_4",
	Box_5: "DirectoryContent-module_6nsluG_Box_5",
	OverviewHeaderRow: "DirectoryContent-module_6nsluG_OverviewHeaderRow"
};
var TRUNCATION_THRESHOLD = 10;
function DirectoryContent(t0) {
	const $ = c$1(3);
	const { overview } = t0;
	const isDataRouter = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== isDataRouter || $[1] !== overview) {
		t1 = isDataRouter ? jsx(DirectoryContentWithProvider, { overview }) : jsx(DirectoryContentWithHook, { overview });
		$[0] = isDataRouter;
		$[1] = overview;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
DirectoryContent.displayName = "DirectoryContent";
function DirectoryContentWithHook(t0) {
	const $ = c$1(3);
	const { overview } = t0;
	const { commitInfo } = useCommitInfo();
	let t1;
	if ($[0] !== commitInfo || $[1] !== overview) {
		t1 = jsx(DirectoryContentInternal, {
			overview,
			commitInfo
		});
		$[0] = commitInfo;
		$[1] = overview;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
DirectoryContentWithHook.displayName = "DirectoryContentWithHook";
function DirectoryContentWithProvider(t0) {
	const $ = c$1(3);
	const { overview } = t0;
	const { commitInfo } = useCommitInfoContext();
	let t1;
	if ($[0] !== commitInfo || $[1] !== overview) {
		t1 = jsx(DirectoryContentInternal, {
			overview,
			commitInfo
		});
		$[0] = commitInfo;
		$[1] = overview;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
DirectoryContentWithProvider.displayName = "DirectoryContentWithProvider";
function DirectoryContentInternal({ overview, commitInfo }) {
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	const { items, templateDirectorySuggestionUrl, totalCount } = useCurrentTree();
	const { items: itemsToShow } = useInitiallyTruncatedList(items, 100);
	const codeTruncationEnabled = isFeatureEnabled("repo_home_code_truncation");
	const [isTruncated, setIsTruncated] = React.useState(!!overview);
	const omitted = totalCount - items.length;
	const isSubdirectory = path.length > 1;
	const parentUrl = parentPath(path);
	const parentPathHref = repositoryTreePath({
		repo,
		action: "tree",
		commitish: refInfo.name,
		path: parentUrl
	});
	const uploadUrl = repositoryTreePath({
		repo,
		commitish: refInfo.name,
		path,
		action: "upload"
	});
	const goToParentLinkRef = React.useRef(null);
	const { getItemUrl } = useUrlCreator();
	const navigate = useNavigate$1();
	const { focusHint } = useFocusHint();
	const focusedIndexRef = React.useRef(-1);
	const onNavigate = React.useCallback((e) => {
		if (e.screenX === 0 && e.screenY === 0) goToParentLinkRef.current?.focus();
	}, []);
	const onViewFilesButtonClick = React.useCallback(() => {
		setIsTruncated(false);
	}, []);
	const focusNextIndex = React.useCallback((nextIndex) => {
		focusedIndexRef.current = nextIndex;
		const row = document.getElementById(`folder-row-${nextIndex}`);
		let cell;
		if (window.matchMedia(`(max-width: ${ScreenSize.medium}px)`).matches) cell = row?.querySelector(".react-directory-row-name-cell-small-screen");
		else cell = row?.querySelector(".react-directory-row-name-cell-large-screen");
		if (!cell) cell = row;
		cell?.getElementsByTagName("a")[0]?.focus();
	}, []);
	return /* @__PURE__ */ jsxs("div", {
		"data-hpc": true,
		children: [
			/* @__PURE__ */ jsx("button", {
				hidden: true,
				"data-testid": "focus-next-element-button",
				"data-hotkey": "j",
				onClick: () => {
					focusNextIndex(Math.min(focusedIndexRef.current + 1, isSubdirectory ? itemsToShow.length : itemsToShow.length - 1));
				}
			}),
			/* @__PURE__ */ jsx("button", {
				hidden: true,
				"data-testid": "focus-previous-element-button",
				"data-hotkey": "k",
				onClick: () => {
					focusNextIndex(Math.max(focusedIndexRef.current - 1, 0));
				}
			}),
			/* @__PURE__ */ jsx(ScreenReaderHeading, {
				as: "h2",
				text: "Folders and files",
				id: "folders-and-files"
			}),
			/* @__PURE__ */ jsxs(Table, {
				"aria-labelledby": "folders-and-files",
				children: [
					/* @__PURE__ */ jsxs(HeaderRow, {
						className: clsx(overview && DirectoryContent_module_default.OverviewHeaderRow),
						children: [
							/* @__PURE__ */ jsx("th", {
								colSpan: 2,
								className: DirectoryContent_module_default.Box,
								children: /* @__PURE__ */ jsx("span", {
									className: "text-bold",
									children: "Name"
								})
							}),
							/* @__PURE__ */ jsx("th", {
								colSpan: 1,
								className: DirectoryContent_module_default.Box_1,
								children: /* @__PURE__ */ jsx("span", {
									className: "text-bold",
									children: "Name"
								})
							}),
							/* @__PURE__ */ jsx("th", {
								className: "hide-sm",
								children: /* @__PURE__ */ jsx(Truncate, {
									inline: true,
									title: "Last commit message",
									className: "width-fit",
									children: /* @__PURE__ */ jsx("span", {
										className: "text-bold",
										children: "Last commit message"
									})
								})
							}),
							/* @__PURE__ */ jsx("th", {
								colSpan: 1,
								className: DirectoryContent_module_default.Box_2,
								children: /* @__PURE__ */ jsx(Truncate, {
									inline: true,
									title: "Last commit date",
									className: "width-fit",
									children: /* @__PURE__ */ jsx("span", {
										className: "text-bold",
										children: "Last commit date"
									})
								})
							})
						]
					}),
					/* @__PURE__ */ jsxs("tbody", { children: [
						!!overview && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("tr", {
							className: DirectoryContent_module_default.Box_3,
							children: /* @__PURE__ */ jsx("td", {
								colSpan: 3,
								className: "bgColor-muted p-1 rounded-top-2",
								children: /* @__PURE__ */ jsx(LatestCommitContent, { commitCount: overview?.commitCount })
							})
						}), omitted > 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", {
							colSpan: 3,
							children: /* @__PURE__ */ jsxs(Flash, {
								variant: "warning",
								className: "rounded-0",
								children: [
									/* @__PURE__ */ jsx(Octicon, { icon: AlertIcon }),
									"Sorry, we had to truncate this directory to 1,000 files. ",
									omitted,
									" entries were omitted from the list."
								]
							})
						}) }) : null] }),
						isSubdirectory && /* @__PURE__ */ jsx(GoDirectoryUpRow, {
							initialFocus: !focusHint || !itemsToShow.some((i) => i.path === focusHint),
							linkTo: parentPathHref,
							linkRef: goToParentLinkRef,
							navigate
						}),
						itemsToShow.map((item, index) => /* @__PURE__ */ jsx(DirectoryRow, {
							initialFocus: item.path === focusHint,
							item,
							commit: (commitInfo || {})[item.name],
							onNavigate,
							getItemUrl,
							navigate,
							className: isTruncated && index >= TRUNCATION_THRESHOLD ? codeTruncationEnabled ? "d-none" : "truncate-for-mobile" : void 0,
							index: isSubdirectory ? index + 1 : index
						}, item.name)),
						/* @__PURE__ */ jsx("tr", {
							className: clsx(isTruncated && itemsToShow.length > TRUNCATION_THRESHOLD ? codeTruncationEnabled ? void 0 : "show-for-mobile" : "d-none", DirectoryContent_module_default.Box_4),
							"data-testid": "view-all-files-row",
							children: /* @__PURE__ */ jsx("td", {
								colSpan: 3,
								onClick: onViewFilesButtonClick,
								className: DirectoryContent_module_default.Box_5,
								children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Link, {
									as: "button",
									onClick: onViewFilesButtonClick,
									children: codeTruncationEnabled ? "Show all files" : "View all files"
								}) })
							})
						})
					] }),
					templateDirectorySuggestionUrl && /* @__PURE__ */ jsx(TableFooter, { children: /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsxs("td", {
						colSpan: 3,
						children: [
							"Customize the issue creation experience with a ",
							/* @__PURE__ */ jsx("code", { children: "config.yml" }),
							" file.",
							" ",
							/* @__PURE__ */ jsx(Link, {
								inline: true,
								href: templateDirectorySuggestionUrl,
								children: "Learn more about configuring a template chooser."
							})
						]
					}) }) })
				]
			}),
			repo.currentUserCanPush && /* @__PURE__ */ jsx(Dropzone, { uploadUrl })
		]
	});
}
DirectoryContentInternal.displayName = "DirectoryContentInternal";
function EditButton(t0) {
	const $ = c$1(8);
	const { editPath, editTooltip, className } = t0;
	const { editFileShortcut } = useShortcut();
	const navigate = useNavigate$1();
	if (!editPath) return null;
	let t1;
	if ($[0] !== editPath || $[1] !== navigate) {
		t1 = () => {
			navigate(editPath);
		};
		$[0] = editPath;
		$[1] = navigate;
		$[2] = t1;
	} else t1 = $[2];
	let t2;
	if ($[3] !== className || $[4] !== editFileShortcut.hotkey || $[5] !== editTooltip || $[6] !== t1) {
		t2 = jsx(IconButton, {
			icon: PencilIcon,
			className,
			"aria-label": editTooltip,
			onClick: t1,
			"data-hotkey": editFileShortcut.hotkey,
			size: "small",
			variant: "invisible"
		});
		$[3] = className;
		$[4] = editFileShortcut.hotkey;
		$[5] = editTooltip;
		$[6] = t1;
		$[7] = t2;
	} else t2 = $[7];
	return t2;
}
EditButton.displayName = "EditButton";
var DirectoryRichtextContent_module_default = { SharedMarkdownContent: "DirectoryRichtextContent-module_ArZdLq_SharedMarkdownContent" };
var DirectoryRichtextContent = memo(function DirectoryRichtextContent(t0) {
	const $ = c$1(10);
	const { errorMessage, onAnchorClick, path, richText, stickyHeaderHeight, timedOut } = t0;
	const repo = useCurrentRepository();
	const refInfo = useRefInfo();
	if (errorMessage) {
		let t1;
		if ($[0] !== errorMessage || $[1] !== path || $[2] !== refInfo || $[3] !== repo || $[4] !== timedOut) {
			t1 = jsxs("div", {
				className: "tmp-py-6 tmp-px-3 text-center",
				children: [
					timedOut && jsx(Octicon, {
						icon: HourglassIcon,
						size: 32
					}),
					jsx("div", {
						"data-testid": "directory-richtext-error-message",
						children: errorMessage
					}),
					timedOut && jsxs("div", { children: [
						"But you can view the",
						" ",
						jsx(Link, {
							inline: true,
							href: repositoryTreePath({
								repo,
								commitish: refInfo.name,
								action: "raw",
								path
							}),
							"data-testid": "directory-richtext-timeout-raw-link",
							children: "raw file"
						}),
						"."
					] })
				]
			});
			$[0] = errorMessage;
			$[1] = path;
			$[2] = refInfo;
			$[3] = repo;
			$[4] = timedOut;
			$[5] = t1;
		} else t1 = $[5];
		return t1;
	} else if (richText) {
		let t1;
		if ($[6] !== onAnchorClick || $[7] !== richText || $[8] !== stickyHeaderHeight) {
			t1 = jsx(SharedMarkdownContent, {
				onAnchorClick,
				richText,
				stickyHeaderHeight,
				className: DirectoryRichtextContent_module_default.SharedMarkdownContent
			});
			$[6] = onAnchorClick;
			$[7] = richText;
			$[8] = stickyHeaderHeight;
			$[9] = t1;
		} else t1 = $[9];
		return t1;
	}
	return null;
});
DirectoryRichtextContent.displayName = "DirectoryRichtextContent";
var OverviewRepoFiles_module_default = {
	ActionMenu_Button: "OverviewRepoFiles-module_pEDwGW_ActionMenu_Button",
	ActionMenu_Overlay: "OverviewRepoFiles-module_pEDwGW_ActionMenu_Overlay",
	Box: "OverviewRepoFiles-module_pEDwGW_Box",
	Box_1: "OverviewRepoFiles-module_pEDwGW_Box_1",
	Box_2: "OverviewRepoFiles-module_pEDwGW_Box_2",
	Box_3: "OverviewRepoFiles-module_pEDwGW_Box_3",
	Box_4: "OverviewRepoFiles-module_pEDwGW_Box_4",
	Box_5: "OverviewRepoFiles-module_pEDwGW_Box_5",
	editButton: "OverviewRepoFiles-module_pEDwGW_editButton",
	Heading: "OverviewRepoFiles-module_pEDwGW_Heading",
	Octicon: "OverviewRepoFiles-module_pEDwGW_Octicon",
	Text: "OverviewRepoFiles-module_pEDwGW_Text",
	UnderlineNav: "OverviewRepoFiles-module_pEDwGW_UnderlineNav"
};
function OverviewFiles({ initialFiles, shouldRecommendReadme, isPersonalRepo }) {
	const repo = useCurrentRepository();
	const refInfo = useRefInfo();
	const { data: deferredOverviewFiles } = useQuery({
		queryKey: [
			repo.ownerLogin,
			repo.name,
			"overview-files",
			refInfo.name
		],
		queryFn: async () => {
			const response = await verifiedFetchJSON(repositoryTreePath({
				repo: {
					ownerLogin: repo.ownerLogin,
					name: repo.name
				},
				action: "overview-files",
				commitish: refInfo.name
			}));
			if (response.ok) return (await response.json()).files;
			return null;
		},
		enabled: initialFiles?.some((file) => !file.loaded) ?? false
	});
	const overviewFiles = deferredOverviewFiles || initialFiles;
	const readme = overviewFiles?.find((file_0) => file_0.preferredFileType === PreferredFileTypes.README);
	const coc = overviewFiles?.find((file_1) => file_1.preferredFileType === PreferredFileTypes.CODE_OF_CONDUCT);
	const licenses = (overviewFiles ?? []).filter((file_2) => file_2.preferredFileType === PreferredFileTypes.LICENSE);
	const securityPolicy = overviewFiles?.find((file_3) => file_3.preferredFileType === PreferredFileTypes.SECURITY);
	const contributing = overviewFiles?.find((file_4) => file_4.preferredFileType === PreferredFileTypes.CONTRIBUTING);
	let initialSelectedTab = "readme-ov-file";
	if (!readme && !shouldRecommendReadme) {
		if (coc) initialSelectedTab = "coc-ov-file";
		else if (contributing) initialSelectedTab = "contributing-ov-file";
		else if (licenses.length > 0 && licenses[0]) initialSelectedTab = `${licenses[0].tabName}-1-ov-file`;
		else if (securityPolicy) initialSelectedTab = "security-ov-file";
	}
	const [selectedTab, setSelectedTab] = useState(initialSelectedTab);
	const containerRef = useRef(null);
	const { canEdit } = useEditPermissions();
	const getTabNames = useCallback(() => {
		const tabNames = [];
		if (readme || shouldRecommendReadme) tabNames.push("readme-ov-file");
		if (coc) tabNames.push("coc-ov-file");
		if (contributing) tabNames.push("contributing-ov-file");
		if (licenses.length) for (const [index, license] of licenses.entries()) tabNames.push(`${license.tabName}-${index + 1}-ov-file`);
		if (securityPolicy) tabNames.push("security-ov-file");
		return tabNames;
	}, [
		coc,
		licenses,
		contributing,
		readme,
		securityPolicy,
		shouldRecommendReadme
	]);
	const readmeRef = useRef(null);
	const contributingRef = useRef(null);
	const securityRef = useRef(null);
	const cocRef = useRef(null);
	const onHashChange = useCallback(() => {
		const hash = window.location.hash.replace("#", "");
		const tabNames_0 = getTabNames();
		if (hash && tabNames_0.includes(hash)) {
			updateUrl(`${window.location.protocol}//${window.location.host}${window.location.pathname}?tab=${hash}#readme`);
			setSelectedTab(hash);
		} else {
			const tabName = new URLSearchParams(window.location.search).get("tab");
			if (tabName && tabNames_0.includes(tabName)) setSelectedTab(tabName);
		}
		window.requestAnimationFrame(() => {
			if (containerRef.current && window.location.hash === "#readme") {
				containerRef.current.scrollIntoView();
				if (hash === "readme-ov-file" && readmeRef.current) readmeRef.current.focus();
				else if (hash === "coc-ov-file" && cocRef.current) cocRef.current.focus();
				else if (hash === "contributing-ov-file" && contributingRef.current) contributingRef.current.focus();
				else if (hash === "security-ov-file" && securityRef.current) securityRef.current.focus();
			}
		});
	}, [getTabNames]);
	useEffect(() => {
		onHashChange();
		window.addEventListener("hashchange", onHashChange);
		return () => {
			window.removeEventListener("hashchange", onHashChange);
		};
	}, [onHashChange]);
	const onSelect = useCallback((ev, tabId) => {
		ev.preventDefault();
		if (selectedTab === tabId) return;
		setSelectedTab(tabId);
		updateUrl(`${window.location.protocol}//${window.location.host}${window.location.pathname}?tab=${tabId}`);
	}, [selectedTab]);
	if (!readme && !coc && !licenses.length && !securityPolicy && !shouldRecommendReadme && !contributing) return null;
	let content = void 0;
	let blob = void 0;
	const selectedLicense = licenses.find((license_0, index_0) => `${license_0.tabName}-${index_0 + 1}-ov-file` === selectedTab);
	if (selectedTab === "readme-ov-file") {
		if (readme) blob = readme;
		else if (shouldRecommendReadme) content = /* @__PURE__ */ jsxs(BlankslateContainer, { children: [
			/* @__PURE__ */ jsx(BlankslateContainer.Visual, { children: /* @__PURE__ */ jsx(BookIcon, { size: "medium" }) }),
			/* @__PURE__ */ jsx(BlankslateContainer.Heading, { children: "Add a README" }),
			/* @__PURE__ */ jsx(BlankslateContainer.Description, { children: isPersonalRepo ? "Add a README with an overview of your project." : "Help people interested in this repository understand your project." }),
			/* @__PURE__ */ jsx(BlankslateContainer.PrimaryAction, {
				href: `${repositoryTreePath({
					repo,
					path: void 0,
					commitish: refInfo.name,
					action: "new"
				})}?filename=README.md`,
				children: "Add a README"
			})
		] });
	} else if (selectedTab === "coc-ov-file" && coc) blob = coc;
	else if (selectedTab === "contributing-ov-file" && contributing) blob = contributing;
	else if (selectedLicense) blob = selectedLicense;
	else if (securityPolicy) blob = securityPolicy;
	if (blob && blob.path) if (!blob.loaded) content = /* @__PURE__ */ jsx("div", {
		className: OverviewRepoFiles_module_default.Box,
		children: /* @__PURE__ */ jsx(Spinner, {})
	});
	else content = /* @__PURE__ */ jsx(DirectoryRichtextContent, {
		errorMessage: blob.errorMessage,
		onAnchorClick: () => {
			updateUrl(`${window.location.protocol}//${window.location.host}${window.location.pathname}?tab=${selectedTab}${window.location.hash}`);
		},
		path: blob.path,
		richText: blob.richText,
		stickyHeaderHeight: 50,
		timedOut: blob.timedOut
	});
	return /* @__PURE__ */ jsx("div", {
		className: OverviewRepoFiles_module_default.Box_1,
		children: /* @__PURE__ */ jsxs("div", {
			ref: containerRef,
			className: OverviewRepoFiles_module_default.Box_2,
			children: [/* @__PURE__ */ jsxs("div", {
				itemScope: true,
				itemType: "https://schema.org/abstract",
				className: OverviewRepoFiles_module_default.Box_3,
				children: [
					/* @__PURE__ */ jsxs(UnderlineNav, {
						"aria-label": "Repository files",
						className: OverviewRepoFiles_module_default.UnderlineNav,
						children: [
							(readme || shouldRecommendReadme) && /* @__PURE__ */ jsx(UnderlineNav.Item, {
								icon: BookIcon,
								ref: readmeRef,
								"aria-current": selectedTab === "readme-ov-file" ? "page" : void 0,
								onSelect: (ev_0) => onSelect(ev_0, "readme-ov-file"),
								children: readme?.tabName || "README"
							}),
							coc && /* @__PURE__ */ jsx(UnderlineNav.Item, {
								icon: CodeOfConductIcon,
								ref: cocRef,
								"aria-current": selectedTab === "coc-ov-file" ? "page" : void 0,
								onSelect: (ev_1) => onSelect(ev_1, "coc-ov-file"),
								children: coc?.tabName || "Code of conduct"
							}),
							contributing && /* @__PURE__ */ jsx(UnderlineNav.Item, {
								icon: PeopleIcon,
								ref: contributingRef,
								"aria-current": selectedTab === "contributing-ov-file" ? "page" : void 0,
								onSelect: (ev_2) => onSelect(ev_2, "contributing-ov-file"),
								children: contributing?.tabName || "Contributing"
							}),
							licenses.length ? licenses.map((license_1, index_1) => {
								const tabId_0 = `${license_1.tabName}-${index_1 + 1}-ov-file`;
								return /* @__PURE__ */ jsx(UnderlineNav.Item, {
									icon: LawIcon,
									"aria-current": selectedTab === tabId_0 ? "page" : void 0,
									onSelect: (ev_3) => onSelect(ev_3, tabId_0),
									children: license_1.tabName?.toLowerCase() !== "license" ? `${license_1.tabName} license` : "License"
								}, license_1.path);
							}) : null,
							securityPolicy && /* @__PURE__ */ jsx(UnderlineNav.Item, {
								icon: LawIcon,
								ref: securityRef,
								"aria-current": selectedTab === "security-ov-file" ? "page" : void 0,
								onSelect: (ev_4) => onSelect(ev_4, "security-ov-file"),
								children: securityPolicy?.tabName || "Security policy"
							})
						]
					}),
					canEdit && blob && /* @__PURE__ */ jsx(EditButton, {
						editPath: editBlobPath({
							owner: repo.ownerLogin,
							repo: blob.repoName,
							commitish: blob.refName,
							filePath: blob.path
						}),
						editTooltip: "Edit file",
						className: OverviewRepoFiles_module_default.editButton
					}),
					blob?.headerInfo?.toc && blob?.headerInfo?.toc?.length >= 2 && /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Button, {
						icon: ListUnorderedIcon,
						variant: "invisible",
						"aria-label": "Outline",
						className: OverviewRepoFiles_module_default.ActionMenu_Button,
						children: "Outline"
					}), /* @__PURE__ */ jsx(ActionMenu.Overlay, {
						align: "end",
						className: OverviewRepoFiles_module_default.ActionMenu_Overlay,
						children: /* @__PURE__ */ jsx(TableOfContentsPanel, { toc: blob.headerInfo.toc })
					})] })
				]
			}), content]
		})
	});
}
OverviewFiles.displayName = "OverviewFiles";
var RecentlyTouchedBranches_module_default = {
	Box: "RecentlyTouchedBranches-module_wHAEIa_Box",
	Flash: "RecentlyTouchedBranches-module_wHAEIa_Flash",
	Octicon: "RecentlyTouchedBranches-module_wHAEIa_Octicon"
};
function RecentlyTouchedBranches(t0) {
	const $ = c$1(3);
	const { repo } = t0;
	const isDataRouter = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== isDataRouter || $[1] !== repo) {
		t1 = isDataRouter ? jsx(RecentlyTouchedBranchesWithContext, { repo }) : jsx(RecentlyTouchedBranchesWithFetch, { repo });
		$[0] = isDataRouter;
		$[1] = repo;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
RecentlyTouchedBranches.displayName = "RecentlyTouchedBranches";
function RecentlyTouchedBranchesWithContext(t0) {
	const $ = c$1(6);
	const { repo } = t0;
	const { branches, channel: aliveChannel, canCreatePullRequest, refetch } = useRecentlyTouchedBranches();
	if (!aliveChannel || !branches) return null;
	let t1;
	if ($[0] !== aliveChannel || $[1] !== branches || $[2] !== canCreatePullRequest || $[3] !== refetch || $[4] !== repo) {
		t1 = jsx(RecentlyTouchedBranchesInner, {
			branches,
			canCreatePullRequest,
			channel: aliveChannel,
			fetchRecentlyTouchedBranches: refetch,
			repo
		});
		$[0] = aliveChannel;
		$[1] = branches;
		$[2] = canCreatePullRequest;
		$[3] = refetch;
		$[4] = repo;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
RecentlyTouchedBranchesWithContext.displayName = "RecentlyTouchedBranchesWithContext";
function RecentlyTouchedBranchesWithFetch(t0) {
	const $ = c$1(13);
	const { repo } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = [];
		$[0] = t1;
	} else t1 = $[0];
	const [branches, setBranches] = useState(t1);
	const [aliveChannel, setAliveChannel] = useState();
	const [canCreatePullRequest, setCanCreatePullRequest] = useState(true);
	let t2;
	if ($[1] !== repo.name || $[2] !== repo.ownerLogin) {
		t2 = async () => {
			const response = await verifiedFetchJSON(`/${repo.ownerLogin}/${repo.name}/recently-touched-branches`);
			if (response.ok) {
				const json = await response.json();
				if (json.channel) setAliveChannel(json.channel);
				setBranches(json.branches ?? []);
				setCanCreatePullRequest(json.canCreatePullRequest ?? true);
			}
		};
		$[1] = repo.name;
		$[2] = repo.ownerLogin;
		$[3] = t2;
	} else t2 = $[3];
	const fetchRecentlyTouchedBranches = t2;
	let t3;
	let t4;
	if ($[4] !== fetchRecentlyTouchedBranches) {
		t3 = () => {
			fetchRecentlyTouchedBranches();
		};
		t4 = [fetchRecentlyTouchedBranches];
		$[4] = fetchRecentlyTouchedBranches;
		$[5] = t3;
		$[6] = t4;
	} else {
		t3 = $[5];
		t4 = $[6];
	}
	useEffect(t3, t4);
	if (!aliveChannel) return null;
	let t5;
	if ($[7] !== aliveChannel || $[8] !== branches || $[9] !== canCreatePullRequest || $[10] !== fetchRecentlyTouchedBranches || $[11] !== repo) {
		t5 = jsx(RecentlyTouchedBranchesInner, {
			branches,
			canCreatePullRequest,
			channel: aliveChannel,
			fetchRecentlyTouchedBranches,
			repo
		});
		$[7] = aliveChannel;
		$[8] = branches;
		$[9] = canCreatePullRequest;
		$[10] = fetchRecentlyTouchedBranches;
		$[11] = repo;
		$[12] = t5;
	} else t5 = $[12];
	return t5;
}
RecentlyTouchedBranchesWithFetch.displayName = "RecentlyTouchedBranchesWithFetch";
function RecentlyTouchedBranchesInner(t0) {
	const $ = c$1(9);
	const { branches, canCreatePullRequest: t1, channel, fetchRecentlyTouchedBranches, repo } = t0;
	const canCreatePullRequest = t1 === void 0 ? true : t1;
	const timeout = useRef(null);
	let t2;
	if ($[0] !== fetchRecentlyTouchedBranches) {
		t2 = () => {
			if (timeout.current !== null) window.clearTimeout(timeout.current);
			timeout.current = window.setTimeout(() => {
				fetchRecentlyTouchedBranches();
			}, 500);
		};
		$[0] = fetchRecentlyTouchedBranches;
		$[1] = t2;
	} else t2 = $[1];
	useAlive(channel, t2);
	if (!branches) return null;
	let t3;
	if ($[2] !== branches || $[3] !== canCreatePullRequest || $[4] !== repo) {
		let t4;
		if ($[6] !== canCreatePullRequest || $[7] !== repo) {
			t4 = (branch, index) => jsxs(Flash, {
				variant: "warning",
				className: RecentlyTouchedBranches_module_default.Flash,
				children: [jsxs("div", {
					className: RecentlyTouchedBranches_module_default.Box,
					children: [
						jsx(Octicon, {
							icon: GitBranchIcon,
							className: RecentlyTouchedBranches_module_default.Octicon
						}),
						jsxs(Link$1, {
							to: branchPath({
								owner: branch.repoOwner,
								repo: branch.repoName,
								branch: branch.branchName
							}),
							reloadDocument: true,
							className: "text-bold",
							children: [repo.ownerLogin !== branch.repoOwner ? `${branch.repoOwner}:` : "", branch.branchName]
						}),
						` had recent pushes ${agoString(new Date(branch.date))}`
					]
				}), jsx(LinkButton, {
					href: branch.comparePath,
					variant: "primary",
					children: canCreatePullRequest ? "Compare & pull request" : "Compare"
				})]
			}, branch.branchName + index);
			$[6] = canCreatePullRequest;
			$[7] = repo;
			$[8] = t4;
		} else t4 = $[8];
		t3 = jsx(Fragment$1, { children: branches.map(t4) });
		$[2] = branches;
		$[3] = canCreatePullRequest;
		$[4] = repo;
		$[5] = t3;
	} else t3 = $[5];
	return t3;
}
RecentlyTouchedBranchesInner.displayName = "RecentlyTouchedBranchesInner";
var InterractionLimitsBanner_module_default = {
	Box: "InterractionLimitsBanner-module_OlOOga_Box",
	Box_1: "InterractionLimitsBanner-module_OlOOga_Box_1",
	Box_2: "InterractionLimitsBanner-module_OlOOga_Box_2",
	Box_3: "InterractionLimitsBanner-module_OlOOga_Box_3",
	Box_4: "InterractionLimitsBanner-module_OlOOga_Box_4",
	iconDanger: "InterractionLimitsBanner-module_OlOOga_iconDanger",
	iconSuccess: "InterractionLimitsBanner-module_OlOOga_iconSuccess",
	Label: "InterractionLimitsBanner-module_OlOOga_Label",
	Octicon: "InterractionLimitsBanner-module_OlOOga_Octicon"
};
function InterractionLimitsBanner(t0) {
	const $ = c$1(10);
	const { interactionLimitBanner } = t0;
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== interactionLimitBanner.adminLink || $[1] !== interactionLimitBanner.adminText || $[2] !== interactionLimitBanner.contributorsHaveAccess || $[3] !== interactionLimitBanner.currentExpiry || $[4] !== interactionLimitBanner.disablePath || $[5] !== interactionLimitBanner.inOrganization || $[6] !== interactionLimitBanner.limitTitle || $[7] !== interactionLimitBanner.usersHaveAccess || $[8] !== repo) {
		let description;
		if (interactionLimitBanner.usersHaveAccess) description = "Users that have recently created their account will be unable to interact with the repository.";
		else if (interactionLimitBanner.contributorsHaveAccess) description = jsxs(Fragment$1, { children: [
			"Users that have not previously",
			" ",
			jsx(Link, {
				inline: true,
				href: repoContributorsPath(repo),
				children: "committed"
			}),
			" ",
			"to the ",
			repo.defaultBranch,
			" branch of this repository will be unable to interact with the repository."
		] });
		else description = jsxs(Fragment$1, { children: [
			"Users that are not",
			" ",
			jsx(Link, {
				inline: true,
				href: repoAccessSettingsPath(repo),
				children: "collaborators"
			}),
			" ",
			"will not be able to interact with the repository."
		] });
		t1 = jsxs(Flash, { children: [
			jsxs("div", { children: [
				jsx(Octicon, {
					icon: ClockIcon,
					className: InterractionLimitsBanner_module_default.Octicon
				}),
				jsx("span", { children: interactionLimitBanner.limitTitle }),
				jsx(Label, {
					variant: "success",
					className: InterractionLimitsBanner_module_default.Label,
					children: `${interactionLimitBanner.currentExpiry} remaining`
				})
			] }),
			jsx("div", {
				className: InterractionLimitsBanner_module_default.Box,
				children: jsx("span", { children: description })
			}),
			jsxs("div", {
				className: InterractionLimitsBanner_module_default.Box_1,
				children: [
					jsx(RoleInteractionIndicator, {
						userRole: "New users",
						access: false
					}),
					jsx(RoleInteractionIndicator, {
						userRole: "Users",
						access: interactionLimitBanner.usersHaveAccess
					}),
					jsx(RoleInteractionIndicator, {
						userRole: "Contributors",
						access: interactionLimitBanner.contributorsHaveAccess
					}),
					jsx(RoleInteractionIndicator, {
						userRole: "Collaborators",
						access: true
					}),
					interactionLimitBanner.inOrganization && jsx(RoleInteractionIndicator, {
						userRole: "Organization members",
						access: true
					})
				]
			}),
			interactionLimitBanner.adminText && interactionLimitBanner.adminLink && interactionLimitBanner.disablePath && jsxs("div", {
				className: InterractionLimitsBanner_module_default.Box_2,
				children: [jsx(ButtonComponent, {
					onClick: async () => {
						const formData = new FormData();
						formData.append("interaction_setting", "NO_LIMIT");
						formData.append("_method", "put");
						if (interactionLimitBanner.disablePath) await verifiedFetch(interactionLimitBanner.disablePath, {
							body: formData,
							method: "POST",
							redirect: "manual"
						});
						window.location.reload();
					},
					children: "Disable"
				}), jsxs("div", {
					className: InterractionLimitsBanner_module_default.Box_3,
					children: ["\xA0or view\xA0", jsx(Link, {
						inline: true,
						href: interactionLimitBanner.adminLink,
						children: interactionLimitBanner.adminText
					})]
				})]
			})
		] });
		$[0] = interactionLimitBanner.adminLink;
		$[1] = interactionLimitBanner.adminText;
		$[2] = interactionLimitBanner.contributorsHaveAccess;
		$[3] = interactionLimitBanner.currentExpiry;
		$[4] = interactionLimitBanner.disablePath;
		$[5] = interactionLimitBanner.inOrganization;
		$[6] = interactionLimitBanner.limitTitle;
		$[7] = interactionLimitBanner.usersHaveAccess;
		$[8] = repo;
		$[9] = t1;
	} else t1 = $[9];
	return t1;
}
InterractionLimitsBanner.displayName = "InterractionLimitsBanner";
function RoleInteractionIndicator({ userRole, access }) {
	return /* @__PURE__ */ jsxs("div", {
		className: InterractionLimitsBanner_module_default.Box_4,
		children: [/* @__PURE__ */ jsx(Octicon, {
			icon: access ? CheckIcon : XIcon,
			className: access ? InterractionLimitsBanner_module_default.iconSuccess : InterractionLimitsBanner_module_default.iconDanger
		}), userRole]
	});
}
RoleInteractionIndicator.displayName = "RoleInteractionIndicator";
var PendingInvitationBanner_module_default = {
	Box: "PendingInvitationBanner-module_sXNeCq_Box",
	Box_1: "PendingInvitationBanner-module_sXNeCq_Box_1",
	Link: "PendingInvitationBanner-module_sXNeCq_Link"
};
function PendingInvitationBanner(t0) {
	const $ = c$1(5);
	const { inviterName } = t0;
	const getHovercardAttributesForType = useGetHovercardAttributesForType();
	const { ownerLogin, name } = useCurrentRepository();
	let t1;
	if ($[0] !== getHovercardAttributesForType || $[1] !== inviterName || $[2] !== name || $[3] !== ownerLogin) {
		t1 = jsx(Flash, { children: jsxs("div", {
			className: PendingInvitationBanner_module_default.Box,
			children: [jsxs("div", {
				className: PendingInvitationBanner_module_default.Box_1,
				children: [jsxs(Link, {
					href: ownerPath({ owner: inviterName }),
					...getHovercardAttributesForType("user", { login: inviterName }),
					className: PendingInvitationBanner_module_default.Link,
					children: ["@", inviterName]
				}), "\xA0has invited you to collaborate on this repository"]
			}), jsx(Fragment$1, { children: jsx(LinkButton, {
				href: invitationsPath({
					owner: ownerLogin,
					repo: name
				}),
				className: LinkButton_module_default.linkButton,
				children: "View invitation"
			}) })]
		}) });
		$[0] = getHovercardAttributesForType;
		$[1] = inviterName;
		$[2] = name;
		$[3] = ownerLogin;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
PendingInvitationBanner.displayName = "PendingInvitationBanner";
function ProtectBranchBanner(t0) {
	const $ = c$1(11);
	const { helpUrl } = t0;
	const [hidden, setHidden] = useState(false);
	const refInfo = useRefInfo();
	const repo = useCurrentRepository();
	const documentationHref = `${helpUrl}/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets`;
	const currentUser = useCurrentUser();
	let t1;
	if ($[0] !== currentUser || $[1] !== repo.id) {
		t1 = () => {
			if (!currentUser) return;
			const dismissPath = dismissRepositoryNoticePathPath({ login: currentUser.login });
			const form = new FormData();
			form.append("_method", "delete");
			form.append("repository_id", repo.id.toString());
			form.append("notice_name", "sculk_protect_this_branch");
			verifiedFetch(dismissPath, {
				method: "POST",
				body: form
			});
			setHidden(true);
		};
		$[0] = currentUser;
		$[1] = repo.id;
		$[2] = t1;
	} else t1 = $[2];
	const onDismissProtectBranchBanner = t1;
	const { isServer: isSSR } = useRuntimeEnvironment();
	let t2;
	let t3;
	if ($[3] !== documentationHref || $[4] !== hidden || $[5] !== isSSR || $[6] !== onDismissProtectBranchBanner || $[7] !== refInfo || $[8] !== repo) {
		t3 = Symbol.for("react.early_return_sentinel");
		bb0: {
			const learnMoreRulesetAnalytics = getAnalytics$1("click_to_learn_more_about_rulesets", "ref_cta:learn_more_about_rulesets", repo, isSSR);
			const protectBranchAnalytics = getAnalytics$1("click_to_add_a_rule", "ref_cta:protect_this_branch", repo, isSSR);
			const dismissAnalytics = getAnalytics$1("click_to_dismiss", "ref_cta:dismiss", repo, isSSR);
			const protectThisBranchHref = newRulesetPath({
				owner: repo.ownerLogin,
				repo: repo.name
			});
			if (hidden) {
				t3 = null;
				break bb0;
			}
			t2 = jsx(Banner, {
				icon: jsx(GitBranchIcon, {}),
				title: `Your ${refInfo.name} branch isn't protected`,
				description: jsxs("span", { children: ["Protect this branch from force pushing or deletion, or require status checks before merging.\xA0", jsx(Link, {
					inline: true,
					href: documentationHref,
					"data-analytics-event": learnMoreRulesetAnalytics,
					children: "View documentation."
				})] }),
				primaryAction: jsx(Banner.PrimaryAction, {
					as: "a",
					href: protectThisBranchHref,
					"data-analytics-event": protectBranchAnalytics,
					children: "Protect this branch"
				}),
				secondaryAction: jsx(Banner.SecondaryAction, {
					onClick: onDismissProtectBranchBanner,
					"data-analytics-event": dismissAnalytics,
					children: "Dismiss"
				})
			});
		}
		$[3] = documentationHref;
		$[4] = hidden;
		$[5] = isSSR;
		$[6] = onDismissProtectBranchBanner;
		$[7] = refInfo;
		$[8] = repo;
		$[9] = t2;
		$[10] = t3;
	} else {
		t2 = $[9];
		t3 = $[10];
	}
	if (t3 !== Symbol.for("react.early_return_sentinel")) return t3;
	return t2;
}
ProtectBranchBanner.displayName = "ProtectBranchBanner";
function getAnalytics$1(action, label, repo, isSSR) {
	return JSON.stringify({
		category: "Suggestions",
		action,
		label: `ref_page:${isSSR ? `https://github.com${repoOverviewUrl(repo)}` : window.location};${label};ref_loc:repo files listing;`
	});
}
var UseActionBanner_module_default = {
	Box: "UseActionBanner-module_f2dgEW_Box",
	Box_1: "UseActionBanner-module_f2dgEW_Box_1",
	Box_2: "UseActionBanner-module_f2dgEW_Box_2",
	Text: "UseActionBanner-module_f2dgEW_Text",
	Text_1: "UseActionBanner-module_f2dgEW_Text_1"
};
function UseActionBanner(t0) {
	const $ = c$1(7);
	const { actionSlug, actionId } = t0;
	const { sendMarketplaceActionEvent } = useReposAnalytics();
	let t1;
	if ($[0] !== actionId || $[1] !== actionSlug || $[2] !== sendMarketplaceActionEvent) {
		let t2;
		if ($[4] !== actionId || $[5] !== sendMarketplaceActionEvent) {
			t2 = () => sendMarketplaceActionEvent("MARKETPLACE.ACTION.CLICK", {
				repository_action_id: actionId,
				source_url: `${window.location}`,
				location: "files#overview"
			});
			$[4] = actionId;
			$[5] = sendMarketplaceActionEvent;
			$[6] = t2;
		} else t2 = $[6];
		t1 = jsx(Flash, { children: jsxs("div", {
			className: UseActionBanner_module_default.Box,
			children: [jsxs("div", {
				className: UseActionBanner_module_default.Box_1,
				children: [jsxs("div", {
					className: UseActionBanner_module_default.Box_2,
					children: [jsx(Octicon, {
						icon: PlayIcon,
						size: "small"
					}), jsx("span", {
						className: UseActionBanner_module_default.Text,
						children: "Use this GitHub action with your project"
					})]
				}), jsx("span", {
					className: UseActionBanner_module_default.Text_1,
					children: "Add this Action to an existing workflow or create a new one"
				})]
			}), jsx(LinkButton, {
				href: marketplaceActionPath({ slug: actionSlug }),
				className: LinkButton_module_default.linkButton,
				onClick: t2,
				children: "View on Marketplace"
			})]
		}) });
		$[0] = actionId;
		$[1] = actionSlug;
		$[2] = sendMarketplaceActionEvent;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
UseActionBanner.displayName = "UseActionBanner";
var ImmutableActionsMigrationDialog_module_default = {
	Box: "ImmutableActionsMigrationDialog-module_zUeBeq_Box",
	IconButton: "ImmutableActionsMigrationDialog-module_zUeBeq_IconButton",
	Link: "ImmutableActionsMigrationDialog-module_zUeBeq_Link",
	Octicon: "ImmutableActionsMigrationDialog-module_zUeBeq_Octicon",
	Text: "ImmutableActionsMigrationDialog-module_zUeBeq_Text"
};
function ImmutableActionsMigrationDialog({ repoName, releaseTags, nonSemverTags, migratePath, setMigrationDialogOpen, setHasUnmigratableTagsDialogOpen, setMigrationStatus }) {
	const returnFocusRef = useRef(null);
	const numOfSemVerTags = releaseTags.length - nonSemverTags.length;
	const [error, setError] = useState(null);
	const [errorCount, setErrorCount] = useState(0);
	useEffect(() => {
		if (errorCount > 3) window.location.reload();
	}, [errorCount]);
	async function handleSubmit() {
		if ((await verifiedFetch(migratePath, {
			method: "POST",
			body: new FormData()
		})).ok) {
			setMigrationStatus("in_progress");
			setMigrationDialogOpen(false);
		} else {
			setError("Failed to start migration, please try again. If this error persists, please ensure you are authenticated with the organization that owns this repository.");
			setErrorCount((prevCount) => prevCount + 1);
		}
	}
	return /* @__PURE__ */ jsx(Dialog, {
		returnFocusRef,
		onClose: () => {
			setMigrationDialogOpen(false);
			setError(null);
		},
		width: "large",
		"aria-labelledby": "header",
		title: /* @__PURE__ */ jsxs("div", {
			className: "d-flex",
			children: [nonSemverTags.length > 0 && /* @__PURE__ */ jsx(IconButton, {
				icon: ArrowLeftIcon,
				size: "small",
				className: clsx("mr-2", ImmutableActionsMigrationDialog_module_default.IconButton),
				"aria-labelledby": "back",
				variant: "invisible",
				"data-testid": "ia-migration-back",
				onClick: () => {
					setMigrationDialogOpen(false);
					setHasUnmigratableTagsDialogOpen(true);
					setError(null);
				}
			}), /* @__PURE__ */ jsx("span", {
				"data-testid": "ia-migration-title",
				className: ImmutableActionsMigrationDialog_module_default.Text,
				children: "Create immutable action"
			})]
		}),
		renderFooter: () => {
			return /* @__PURE__ */ jsxs(Dialog.Footer, { children: [
				/* @__PURE__ */ jsx(Link, {
					href: "https://docs.github.com/actions",
					className: ImmutableActionsMigrationDialog_module_default.Link,
					children: "Learn more"
				}),
				/* @__PURE__ */ jsx(ButtonComponent, {
					type: "button",
					onClick: () => setMigrationDialogOpen(false),
					children: "Cancel"
				}),
				/* @__PURE__ */ jsx(ButtonComponent, {
					type: "submit",
					variant: "primary",
					onClick: handleSubmit,
					"data-testid": "ia-migration-button-dialog",
					children: "Create immutable action"
				})
			] });
		},
		children: /* @__PURE__ */ jsxs("div", {
			"data-testid": "inner",
			children: [
				error && /* @__PURE__ */ jsx(Flash, {
					variant: "danger",
					className: "tmp-mb-3",
					children: error
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "d-flex my-2",
					style: {
						margin: "auto",
						justifyContent: "center"
					},
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: ImmutableActionsMigrationDialog_module_default.Box,
							children: [/* @__PURE__ */ jsx(Octicon, {
								icon: TagIcon,
								size: 16,
								className: clsx("mr-1", ImmutableActionsMigrationDialog_module_default.Octicon)
							}), pluralize$1("tag", numOfSemVerTags)]
						}),
						/* @__PURE__ */ jsx(Octicon, {
							icon: ArrowRightIcon,
							size: 16,
							className: clsx("mx-2", ImmutableActionsMigrationDialog_module_default.Text)
						}),
						/* @__PURE__ */ jsxs("div", {
							className: ImmutableActionsMigrationDialog_module_default.Box,
							children: [/* @__PURE__ */ jsx(Octicon, {
								icon: PackageIcon,
								size: 16,
								className: clsx("mr-1", ImmutableActionsMigrationDialog_module_default.Octicon)
							}), pluralize$1("version", numOfSemVerTags)]
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("p", { children: [
					/* @__PURE__ */ jsxs("strong", { children: [
						numOfSemVerTags,
						" out of ",
						releaseTags.length,
						" tags"
					] }),
					" ",
					"from ",
					/* @__PURE__ */ jsx("strong", { children: repoName }),
					" will be recreated as immutable package versions."
				] }), /* @__PURE__ */ jsx("p", { children: "After this process you can activate your package, at which point references to semantic versions of your action will be resolved from immutable package versions rather than git references. Non-semantic version references to your action will continue to be resolved from git references." })] })
			]
		})
	});
}
ImmutableActionsMigrationDialog.displayName = "ImmutableActionsMigrationDialog";
function pluralize$1(word, count) {
	return `${count} ${word}${count > 1 ? "s" : ""}`;
}
var ImmutableActionsHasUnmigratableTagsDialog_module_default = { Octicon: "ImmutableActionsHasUnmigratableTagsDialog-module_lW9Lma_Octicon" };
function ImmutableActionsHasUnmigratableTagsDialog({ releaseTags, nonSemverTags, setMigrationDialogOpen, setHasUnmigratableTagsDialogOpen }) {
	const returnFocusRef = useRef(null);
	const MAX_INVALID_TAGS_SHOWN = 100;
	return /* @__PURE__ */ jsx(Dialog, {
		returnFocusRef,
		onClose: () => setHasUnmigratableTagsDialogOpen(false),
		width: "large",
		"aria-labelledby": "header",
		title: /* @__PURE__ */ jsx("div", {
			"data-testid": "ia-unmigratable-tags-title",
			children: "Non-semantic version tags found"
		}),
		renderFooter: () => {
			return /* @__PURE__ */ jsxs(Dialog.Footer, { children: [/* @__PURE__ */ jsx(ButtonComponent, {
				type: "button",
				onClick: () => setHasUnmigratableTagsDialogOpen(false),
				children: "Cancel"
			}), /* @__PURE__ */ jsx(ButtonComponent, {
				type: "button",
				variant: "primary",
				onClick: () => {
					setHasUnmigratableTagsDialogOpen(false);
					setMigrationDialogOpen(true);
				},
				children: "Continue anyways"
			})] });
		},
		children: /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("div", {
			className: "mb-2",
			children: [nonSemverTags.length > 0 && /* @__PURE__ */ jsxs("p", { children: [
				/* @__PURE__ */ jsxs("strong", { children: [
					nonSemverTags.length,
					" out of ",
					releaseTags.length,
					" ",
					pluralize("tag", releaseTags.length)
				] }),
				" ",
				"cannot be recreated because they did not follow semantic versioning at the time of their release. To include these tags, re-release these versions following semantic versioning. You can still continue with the migration process without re-releasing these versions, but they will not be recreated as immutable package versions."
			] }), nonSemverTags.length > MAX_INVALID_TAGS_SHOWN && /* @__PURE__ */ jsxs("p", { children: [
				"Only the first ",
				MAX_INVALID_TAGS_SHOWN,
				" invalid tags are listed."
			] })]
		}), nonSemverTags.length > 0 && /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("ul", {
			className: "list-style-none",
			children: nonSemverTags.slice(0, MAX_INVALID_TAGS_SHOWN).map((tag) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx(Octicon, {
				icon: XIcon,
				className: clsx("mr-1", ImmutableActionsHasUnmigratableTagsDialog_module_default.Octicon)
			}), tag] }, tag))
		}) })] })
	});
}
ImmutableActionsHasUnmigratableTagsDialog.displayName = "ImmutableActionsHasUnmigratableTagsDialog";
function pluralize(word, count) {
	return `${word}${count > 1 ? "s" : ""}`;
}
var FULL_SEMVER_REGEX = /^(?<major>0|[1-9]\d*)\.(?<minor>0|[1-9]\d*)\.(?<patch>0|[1-9]\d*)(?:-(?<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
function isFullSemver(version) {
	const versionWithoutV = version.replace(/^v/, "");
	return FULL_SEMVER_REGEX.test(versionWithoutV);
}
var ImmutableActionsMigrationBanner_module_default = {
	Box: "ImmutableActionsMigrationBanner-module_mmY67G_Box",
	Box_1: "ImmutableActionsMigrationBanner-module_mmY67G_Box_1",
	Box_2: "ImmutableActionsMigrationBanner-module_mmY67G_Box_2",
	Text: "ImmutableActionsMigrationBanner-module_mmY67G_Text",
	Text_1: "ImmutableActionsMigrationBanner-module_mmY67G_Text_1"
};
function ImmutableActionsMigrationBanner({ releaseTags, initialMigrationStatus }) {
	const [isMigrationDialogOpen, setMigrationDialogOpen] = useState(false);
	const [isHasUnmigratableTagsDialogOpen, setHasUnmigratableTagsDialogOpen] = useState(false);
	const [migrationStatus, setMigrationStatus] = useState(initialMigrationStatus);
	const returnFocusRef = useRef(null);
	const repo = useCurrentRepository();
	const migratePath = migrateImmutableActionsPath({
		owner: repo.ownerLogin,
		repo: repo.name
	});
	const worfklowRunsPath = migrationWorkflowsPath({
		owner: repo.ownerLogin,
		repo: repo.name
	});
	const nonSemverTags = releaseTags.filter((tag) => !isFullSemver(tag));
	const bannerTitle = migrationStatus === "failed" ? "Immutable Action Migration Failed" : "Make your GitHub Action Immutable";
	const bannerText = migrationStatus === "failed" ? "One or more of your tags failed to be migrated to immutable action versions. You can try the migration again to migrate the remaining tags. " : "Upgrade to a newer, more secure, and more reliable way of releasing and referencing GitHub Actions by recreating your existing tags as immutable package versions. ";
	const buttonText = migrationStatus === "failed" ? "Retry migration" : "Create immutable action";
	return /* @__PURE__ */ jsxs(Flash, { children: [
		/* @__PURE__ */ jsxs("div", {
			className: ImmutableActionsMigrationBanner_module_default.Box,
			children: [migrationStatus === "in_progress" && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
				className: ImmutableActionsMigrationBanner_module_default.Box_1,
				children: /* @__PURE__ */ jsx("div", {
					className: ImmutableActionsMigrationBanner_module_default.Box_2,
					children: "Your Action is being migrated to an immutable package version."
				})
			}), /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(ButtonComponent, {
				as: "a",
				href: worfklowRunsPath,
				"data-testid": "ia-migration-progress-button",
				children: "View progress"
			}) })] }), (migrationStatus === null || migrationStatus === "failed") && /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
				className: ImmutableActionsMigrationBanner_module_default.Box_1,
				children: [/* @__PURE__ */ jsx("div", {
					className: ImmutableActionsMigrationBanner_module_default.Box_2,
					children: /* @__PURE__ */ jsx("span", {
						className: ImmutableActionsMigrationBanner_module_default.Text,
						children: bannerTitle
					})
				}), /* @__PURE__ */ jsxs("span", {
					className: ImmutableActionsMigrationBanner_module_default.Text_1,
					children: [bannerText, /* @__PURE__ */ jsx(Link, {
						inline: true,
						target: "_blank",
						href: "https://docs.github.com/actions",
						children: "Learn more about immutable actions."
					})]
				})]
			}), /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(ButtonComponent, {
				ref: returnFocusRef,
				"data-testid": "ia-migration-button-banner",
				onClick: () => {
					if (nonSemverTags.length > 0) setHasUnmigratableTagsDialogOpen(true);
					else setMigrationDialogOpen(true);
				},
				children: buttonText
			}) })] })]
		}),
		isHasUnmigratableTagsDialogOpen && /* @__PURE__ */ jsx(ImmutableActionsHasUnmigratableTagsDialog, {
			releaseTags,
			nonSemverTags,
			setMigrationDialogOpen,
			setHasUnmigratableTagsDialogOpen
		}),
		isMigrationDialogOpen && /* @__PURE__ */ jsx(ImmutableActionsMigrationDialog, {
			repoName: repo.name,
			releaseTags,
			nonSemverTags,
			migratePath,
			setMigrationDialogOpen,
			setHasUnmigratableTagsDialogOpen,
			setMigrationStatus
		})
	] });
}
ImmutableActionsMigrationBanner.displayName = "ImmutableActionsMigrationBanner";
var FRAMEWORKS = {
	vite: "Vite app",
	astro: "Astro app",
	nextjs: "Next.js app",
	gatsby: "Gatsby site",
	nuxtjs: "Nuxt.js app",
	eleventy: "Eleventy site"
};
function DeployBanner(t0) {
	const $ = c$1(3);
	const { detectedStack } = t0;
	const [hidden, setHidden] = useState(false);
	const currentUser = useCurrentUser();
	const repo = useCurrentRepository();
	const deployPath = repositoryDeployPath({
		owner: repo.ownerLogin,
		repo: repo.name,
		framework: detectedStack?.framework ?? void 0,
		packageManager: detectedStack?.packageManager ?? void 0
	});
	let t1;
	if ($[0] !== currentUser || $[1] !== repo.id) {
		t1 = async () => {
			if (!currentUser) return;
			const dismissPath = dismissRepositoryNoticePathPath({ login: currentUser.login });
			const form = new FormData();
			form.append("_method", "delete");
			form.append("repository_id", repo.id.toString());
			form.append("notice_name", "deploy_to_pages_banner");
			try {
				await verifiedFetch(dismissPath, {
					method: "POST",
					body: form
				});
			} catch {}
			setHidden(true);
		};
		$[0] = currentUser;
		$[1] = repo.id;
		$[2] = t1;
	} else t1 = $[2];
	const handleDismiss = t1;
	const { isServer: isSSR } = useRuntimeEnvironment();
	const framework = detectedStack?.framework;
	const description = `Deploy your ${framework && framework in FRAMEWORKS ? FRAMEWORKS[framework] : "project"} to GitHub Pages`;
	const deployClickAnalytics = getAnalytics("click_to_deploy", "ref_cta:deploy", repo, isSSR);
	const dismissClickAnalytics = getAnalytics("click_to_dismiss", "ref_cta:dismiss", repo, isSSR);
	if (hidden) return null;
	return jsx(Banner, {
		icon: jsx(RocketIcon, {}),
		title: jsx("span", {
			className: "text-normal",
			children: description
		}),
		primaryAction: jsxs("span", {
			className: "d-flex items-center gap-2",
			children: [jsx(Banner.PrimaryAction, {
				as: "a",
				href: deployPath,
				"data-analytics-event": deployClickAnalytics,
				children: "Deploy"
			}), jsx(IconButton, {
				icon: XIcon,
				onClick: handleDismiss,
				variant: "invisible",
				"aria-label": "Dismiss deploy banner",
				"data-analytics-event": dismissClickAnalytics
			})]
		})
	});
}
DeployBanner.displayName = "DeployBanner";
function getAnalytics(action, label, repo, isSSR) {
	return JSON.stringify({
		category: "Deploy to Pages",
		action,
		label: `ref_page:${isSSR ? `https://github.com${repoOverviewUrl(repo)}` : window.location};${label};ref_loc:repo files listing;`
	});
}
var OverviewHeader_module_default = {
	Box: "OverviewHeader-module_Z5HjGW_Box",
	PublishBanners: "OverviewHeader-module_Z5HjGW_PublishBanners"
};
function OverviewHeader(t0) {
	const $ = c$1(5);
	const { payload } = t0;
	const repo = useCurrentRepository();
	const user = useCurrentUser();
	const isDataRouter = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== isDataRouter || $[1] !== payload.overview || $[2] !== repo || $[3] !== user) {
		t1 = jsxs("div", {
			className: OverviewHeader_module_default.Box,
			children: [user && jsx(RecentlyTouchedBranches, { repo }), isDataRouter ? jsx(OverviewBanners, { overview: payload.overview }) : jsx(OverviewBannersWithFetch, { overview: payload.overview })]
		});
		$[0] = isDataRouter;
		$[1] = payload.overview;
		$[2] = repo;
		$[3] = user;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
OverviewHeader.displayName = "OverviewHeader";
function OverviewBanners(t0) {
	const $ = c$1(3);
	const { overview } = t0;
	const { latestCommit } = useLatestCommitContext();
	const isSpoofed = latestCommit?.isSpoofed ?? false;
	let t1;
	if ($[0] !== isSpoofed || $[1] !== overview) {
		t1 = jsx(OverviewBannersInternal, {
			overview,
			isSpoofed
		});
		$[0] = isSpoofed;
		$[1] = overview;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
OverviewBanners.displayName = "OverviewBanners";
function OverviewBannersWithFetch(t0) {
	const $ = c$1(3);
	const { overview } = t0;
	const isSpoofed = useLatestCommitIsSpoofed();
	let t1;
	if ($[0] !== isSpoofed || $[1] !== overview) {
		t1 = jsx(OverviewBannersInternal, {
			overview,
			isSpoofed
		});
		$[0] = isSpoofed;
		$[1] = overview;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
OverviewBannersWithFetch.displayName = "OverviewBannersWithFetch";
function OverviewBannersInternal(t0) {
	const $ = c$1(19);
	const { overview, isSpoofed } = t0;
	const { showUseActionBanner, showProtectBranchBanner, actionId, actionSlug, publishBannersInfo: t1, interactionLimitBanner, showInvitationBanner, inviterName, actionsMigrationBannerInfo, showDeployBanner, detectedStack, transactionalMessageBanner } = overview.banners;
	const { dismissActionNoticePath, releasePath, showPublishActionBanner } = t1;
	const { helpUrl } = useReposAppPayload();
	let t2;
	if ($[0] !== actionId || $[1] !== actionSlug || $[2] !== actionsMigrationBannerInfo.initialMigrationStatus || $[3] !== actionsMigrationBannerInfo.releaseTags || $[4] !== actionsMigrationBannerInfo.showImmutableActionsMigrationBanner || $[5] !== detectedStack || $[6] !== dismissActionNoticePath || $[7] !== helpUrl || $[8] !== interactionLimitBanner || $[9] !== inviterName || $[10] !== isSpoofed || $[11] !== releasePath || $[12] !== showDeployBanner || $[13] !== showInvitationBanner || $[14] !== showProtectBranchBanner || $[15] !== showPublishActionBanner || $[16] !== showUseActionBanner || $[17] !== transactionalMessageBanner) {
		t2 = jsxs(Fragment$1, { children: [
			isFeatureEnabled("ipm_global_transactional_message_repos") && transactionalMessageBanner ? jsx(TransactionalMessageBanner, { banner: transactionalMessageBanner }) : null,
			showDeployBanner && jsx(DeployBanner, { detectedStack }),
			isSpoofed && jsx(SpoofedCommitWarningBanner, {}),
			interactionLimitBanner && jsx(InterractionLimitsBanner, { interactionLimitBanner }),
			showInvitationBanner && inviterName && jsx(PendingInvitationBanner, { inviterName }),
			jsx(PublishBanners, {
				showPublishActionBanner,
				releasePath,
				dismissActionNoticePath,
				className: OverviewHeader_module_default.PublishBanners
			}),
			showUseActionBanner && actionSlug && actionId ? jsx(UseActionBanner, {
				actionSlug,
				actionId
			}) : null,
			showProtectBranchBanner && jsx(ProtectBranchBanner, { helpUrl }),
			actionsMigrationBannerInfo.showImmutableActionsMigrationBanner && jsx(ImmutableActionsMigrationBanner, {
				releaseTags: actionsMigrationBannerInfo.releaseTags,
				initialMigrationStatus: actionsMigrationBannerInfo.initialMigrationStatus
			})
		] });
		$[0] = actionId;
		$[1] = actionSlug;
		$[2] = actionsMigrationBannerInfo.initialMigrationStatus;
		$[3] = actionsMigrationBannerInfo.releaseTags;
		$[4] = actionsMigrationBannerInfo.showImmutableActionsMigrationBanner;
		$[5] = detectedStack;
		$[6] = dismissActionNoticePath;
		$[7] = helpUrl;
		$[8] = interactionLimitBanner;
		$[9] = inviterName;
		$[10] = isSpoofed;
		$[11] = releasePath;
		$[12] = showDeployBanner;
		$[13] = showInvitationBanner;
		$[14] = showProtectBranchBanner;
		$[15] = showPublishActionBanner;
		$[16] = showUseActionBanner;
		$[17] = transactionalMessageBanner;
		$[18] = t2;
	} else t2 = $[18];
	return t2;
}
OverviewBannersInternal.displayName = "OverviewBannersInternal";
var BranchRenamePopover_module_default = {
	Box: "BranchRenamePopover-module_P6XYfG_Box",
	BranchName: "BranchRenamePopover-module_P6XYfG_BranchName",
	Heading: "BranchRenamePopover-module_P6XYfG_Heading",
	Popover: "BranchRenamePopover-module_P6XYfG_Popover",
	Popover_Content: "BranchRenamePopover-module_P6XYfG_Popover_Content",
	Text: "BranchRenamePopover-module_P6XYfG_Text"
};
function BranchRenamePopover({ rename }) {
	const [hidden, setHidden] = useState(false);
	const commandsRef = useRef(null);
	const currentUser = useCurrentUser();
	const repo = useCurrentRepository();
	const onDismissPopover = () => {
		if (!currentUser) return;
		const dismissPath = dismissRepositoryNoticePathPath({ login: currentUser.login });
		const form = new FormData();
		form.append("_method", "delete");
		form.append("repository_id", repo.id.toString());
		form.append("notice_name", "repo_default_branch_rename");
		verifiedFetch(dismissPath, {
			method: "POST",
			body: form
		});
		setHidden(true);
	};
	return /* @__PURE__ */ jsx(Popover_default, {
		open: !hidden,
		caret: "top-left",
		className: BranchRenamePopover_module_default.Popover,
		children: /* @__PURE__ */ jsxs(Popover_default.Content, {
			className: BranchRenamePopover_module_default.Popover_Content,
			children: [
				/* @__PURE__ */ jsx(Heading$2, {
					as: "h4",
					className: BranchRenamePopover_module_default.Heading,
					children: "The default branch has been renamed!"
				}),
				/* @__PURE__ */ jsxs("p", { children: [
					/* @__PURE__ */ jsx(BranchName_default, { children: rename.oldName }),
					" is now named",
					" ",
					/* @__PURE__ */ jsx(BranchName_default, {
						className: BranchRenamePopover_module_default.BranchName,
						children: rename.newName
					})
				] }),
				/* @__PURE__ */ jsxs("p", {
					className: BranchRenamePopover_module_default.Text,
					children: ["If you have a local clone, you can update it by running the following commands.", rename.shellEscapingDocsURL ? /* @__PURE__ */ jsx(Link, {
						href: rename.shellEscapingDocsURL,
						children: "Learn about dealing with special characters on the command line."
					}) : null]
				}),
				/* @__PURE__ */ jsx(CopyToClipboardButton, {
					textToCopy: commandsRef.current?.textContent ?? "",
					tooltipProps: { style: {
						position: "absolute",
						right: "16px",
						top: "140px"
					} }
				}),
				/* @__PURE__ */ jsx("pre", {
					ref: commandsRef,
					className: BranchRenamePopover_module_default.Box,
					children: `git branch -m ${rename.shellOldName} ${rename.shellNewName}\ngit fetch origin\ngit branch -u origin/${rename.shellNewName} ${rename.shellNewName}\ngit remote set-head origin -a`
				}),
				/* @__PURE__ */ jsx(ButtonComponent, {
					onClick: onDismissPopover,
					children: "OK, got it"
				})
			]
		})
	});
}
BranchRenamePopover.displayName = "BranchRenamePopover";
var ParentBranchRenamePopover_module_default = {
	BranchName: "ParentBranchRenamePopover-module_-xYwfG_BranchName",
	Heading: "ParentBranchRenamePopover-module_-xYwfG_Heading",
	Popover: "ParentBranchRenamePopover-module_-xYwfG_Popover",
	Popover_Content: "ParentBranchRenamePopover-module_-xYwfG_Popover_Content"
};
function ParentBranchRenamePopover(t0) {
	const $ = c$1(10);
	const { branchName, nameWithOwner } = t0;
	const [hidden, setHidden] = useState(false);
	const currentUser = useCurrentUser();
	const repo = useCurrentRepository();
	let t1;
	if ($[0] !== currentUser || $[1] !== repo.id) {
		t1 = () => {
			if (!currentUser) return;
			const dismissPath = dismissRepositoryNoticePathPath({ login: currentUser.login });
			const form = new FormData();
			form.append("_method", "delete");
			form.append("repository_id", repo.id.toString());
			form.append("notice_name", "repo_parent_default_branch_rename");
			verifiedFetch(dismissPath, {
				method: "POST",
				body: form
			});
			setHidden(true);
		};
		$[0] = currentUser;
		$[1] = repo.id;
		$[2] = t1;
	} else t1 = $[2];
	const onDismissPopover = t1;
	const t2 = !hidden;
	let t3;
	if ($[3] !== branchName || $[4] !== nameWithOwner || $[5] !== onDismissPopover || $[6] !== repo.name || $[7] !== repo.ownerLogin || $[8] !== t2) {
		t3 = jsx(Popover_default, {
			open: t2,
			caret: "top-left",
			className: ParentBranchRenamePopover_module_default.Popover,
			children: jsxs(Popover_default.Content, {
				className: ParentBranchRenamePopover_module_default.Popover_Content,
				children: [
					jsx(Heading$2, {
						as: "h4",
						className: ParentBranchRenamePopover_module_default.Heading,
						children: "The default branch on the parent repository has been renamed!"
					}),
					jsxs("p", { children: [
						jsx(BranchName_default, { children: nameWithOwner }),
						" renamed its default branch",
						" ",
						jsx(BranchName_default, {
							className: ParentBranchRenamePopover_module_default.BranchName,
							children: branchName
						})
					] }),
					jsxs("p", { children: [
						"You can rename this fork's default branch to match in",
						" ",
						jsx(Link, {
							inline: true,
							href: repositoryPath({
								owner: repo.ownerLogin,
								repo: repo.name,
								action: "settings"
							}),
							children: "branch settings"
						})
					] }),
					jsx(ButtonComponent, {
						onClick: onDismissPopover,
						children: "OK, got it"
					})
				]
			})
		});
		$[3] = branchName;
		$[4] = nameWithOwner;
		$[5] = onDismissPopover;
		$[6] = repo.name;
		$[7] = repo.ownerLogin;
		$[8] = t2;
		$[9] = t3;
	} else t3 = $[9];
	return t3;
}
ParentBranchRenamePopover.displayName = "ParentBranchRenamePopover";
var OverviewContent_module_default = {
	Box: "OverviewContent-module_7QoTfq_Box",
	Box_1: "OverviewContent-module_7QoTfq_Box_1",
	Box_10: "OverviewContent-module_7QoTfq_Box_10",
	Box_11: "OverviewContent-module_7QoTfq_Box_11",
	Box_2: "OverviewContent-module_7QoTfq_Box_2",
	Box_3: "OverviewContent-module_7QoTfq_Box_3",
	Box_4: "OverviewContent-module_7QoTfq_Box_4",
	Box_5: "OverviewContent-module_7QoTfq_Box_5",
	Box_6: "OverviewContent-module_7QoTfq_Box_6",
	Box_7: "OverviewContent-module_7QoTfq_Box_7",
	Box_8: "OverviewContent-module_7QoTfq_Box_8",
	Box_9: "OverviewContent-module_7QoTfq_Box_9",
	Button: "OverviewContent-module_7QoTfq_Button",
	Button_1: "OverviewContent-module_7QoTfq_Button_1",
	FileResultsList: "OverviewContent-module_7QoTfq_FileResultsList"
};
var FileResultsList = lazy(() => import("./server-FileResultsList-DYbo1xg9-_OYhqhMF.js"));
FileResultsList.displayName = "FileResultsList";
function OverviewContent(t0) {
	const $ = c$1(4);
	const { payload, className } = t0;
	const isDataRouter = useIsDataRouterEnabled();
	let t1;
	if ($[0] !== className || $[1] !== isDataRouter || $[2] !== payload) {
		t1 = isDataRouter ? jsx(OverviewContentWithContext, {
			payload,
			className
		}) : jsx(OverviewContentWithFetch, {
			payload,
			className
		});
		$[0] = className;
		$[1] = isDataRouter;
		$[2] = payload;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
OverviewContent.displayName = "OverviewContent";
function OverviewContentWithContext(t0) {
	const $ = c$1(4);
	const { payload, className } = t0;
	const branchAndTagCount = useBranchAndTagCount();
	let t1;
	if ($[0] !== branchAndTagCount || $[1] !== className || $[2] !== payload) {
		t1 = jsx(OverviewContentInternal, {
			branchAndTagCount,
			payload,
			className
		});
		$[0] = branchAndTagCount;
		$[1] = className;
		$[2] = payload;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
OverviewContentWithContext.displayName = "OverviewContentWithContext";
function OverviewContentWithFetch(t0) {
	const $ = c$1(8);
	const { payload, className } = t0;
	const [branchAndTagCount, setBranchAndTagCount] = useState(null);
	const overview = payload.overview;
	const repo = useCurrentRepository();
	let t1;
	let t2;
	if ($[0] !== overview || $[1] !== repo) {
		t1 = () => {
			const fetchBranchAndTagCount = async () => {
				const response = await verifiedFetchJSON(branchAndTagCountPath(repo), { method: "get" });
				if (response.ok) setBranchAndTagCount(await response.json());
			};
			if (overview) fetchBranchAndTagCount();
		};
		t2 = [overview, repo];
		$[0] = overview;
		$[1] = repo;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] !== branchAndTagCount || $[5] !== className || $[6] !== payload) {
		t3 = jsx(OverviewContentInternal, {
			branchAndTagCount,
			payload,
			className
		});
		$[4] = branchAndTagCount;
		$[5] = className;
		$[6] = payload;
		$[7] = t3;
	} else t3 = $[7];
	return t3;
}
OverviewContentWithFetch.displayName = "OverviewContentWithFetch";
function OverviewContentInternal({ payload, branchAndTagCount, className }) {
	const { helpUrl } = useReposAppPayload();
	const repo = useCurrentRepository();
	const currentUser = useCurrentUser();
	const path = usePath();
	const refInfo = useRefInfo();
	const { findFileWorkerPath } = useReposAppPayload();
	const navigate = useNavigate$1();
	const { findFilesShortcut } = useShortcut();
	const inputRef = useRef(null);
	const decoupledModeEnabled = isFeatureEnabled("copilot_mission_control_decoupled_mode");
	const overview = payload.overview;
	const codeButton = overview.codeButton;
	const local = {
		...codeButton.local,
		helpUrl
	};
	const codespaces = {
		hasAccessToCodespaces: codeButton.hasAccessToCodespaces,
		repoPolicyInfo: codeButton.repoPolicyInfo,
		contactPath: codeButton.contactPath,
		currentUserIsEnterpriseManaged: codeButton.currentUserIsEnterpriseManaged,
		enterpriseManagedBusinessName: codeButton.enterpriseManagedBusinessName,
		newCodespacePath: codeButton.newCodespacePath,
		codespacesPath: buildCodespacesPath(repo.id, refInfo.name, { currentBranchName: refInfo.refType === "branch" ? refInfo.name : void 0 }),
		currentBranchName: refInfo.refType === "branch" ? refInfo.name : void 0,
		createRef: refInfo.name,
		isLoggedIn: !!currentUser
	};
	const isCopilotSWEAgentEnabled = overview.copilotSWEAgentEnabled ?? false;
	const isDataRouter = useIsDataRouterEnabled();
	const onFindFilesShortcut = React.useCallback(() => {
		if (window.innerWidth < ScreenSize.xlarge) navigate(isDataRouter ? `/${repo.ownerLogin}/${repo.name}/tree/${refInfo.name}?search=1` : `${window.location.pathname}?search=1`);
		else inputRef.current?.focus();
	}, [
		navigate,
		isDataRouter,
		repo.name,
		repo.ownerLogin,
		refInfo.name
	]);
	const navigateToSearch = useCallback(() => {
		navigate(isDataRouter ? `/${repo.ownerLogin}/${repo.name}/tree/${refInfo.name}?search=1` : `${window.location.pathname}?search=1`);
	}, [
		navigate,
		isDataRouter,
		repo.name,
		repo.ownerLogin,
		refInfo.name
	]);
	return /* @__PURE__ */ jsx(Fragment$1, { children: payload.error ? /* @__PURE__ */ jsx(CodeViewError, { ...payload.error }) : /* @__PURE__ */ jsxs("div", {
		className: clsx(OverviewContent_module_default.Box, className),
		children: [
			/* @__PURE__ */ jsx(OverviewHeader, { payload }),
			/* @__PURE__ */ jsxs("div", {
				className: OverviewContent_module_default.Box_1,
				children: [/* @__PURE__ */ jsxs("div", {
					className: OverviewContent_module_default.Box_2,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: OverviewContent_module_default.Box_3,
							children: [/* @__PURE__ */ jsx(ReposHeaderRefSelector, {
								buttonClassName: "overview-ref-selector width-full",
								allowResizing: true
							}), overview.popovers.rename ? /* @__PURE__ */ jsx(BranchRenamePopover, { rename: overview.popovers.rename }) : overview.popovers.renamedParentRepo ? /* @__PURE__ */ jsx(ParentBranchRenamePopover, {
								branchName: overview.popovers.renamedParentRepo.branchName,
								nameWithOwner: overview.popovers.renamedParentRepo.nameWithOwner
							}) : null]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: OverviewContent_module_default.Box_4,
							children: [/* @__PURE__ */ jsx(ButtonComponent, {
								as: "a",
								leadingVisual: GitBranchIcon,
								variant: "invisible",
								href: branchesPath({ repo }),
								className: OverviewContent_module_default.Button,
								children: branchAndTagCount ? /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsxs("strong", {
									className: "color-fg-default",
									children: [branchAndTagCount.branches, " "]
								}), branchAndTagCount.branches === 1 ? "Branch" : "Branches"] }) : "Branches"
							}), /* @__PURE__ */ jsx(ButtonComponent, {
								as: "a",
								leadingVisual: TagIcon,
								variant: "invisible",
								href: tagsPath({ repo }),
								className: OverviewContent_module_default.Button,
								children: branchAndTagCount ? /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsxs("strong", {
									className: "color-fg-default",
									children: [branchAndTagCount.tags, " "]
								}), branchAndTagCount.tags === 1 ? "Tag" : "Tags"] }) : "Tags"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: OverviewContent_module_default.Box_5,
							children: [/* @__PURE__ */ jsx(ButtonComponent, {
								as: "a",
								"aria-label": "Go to Branches page",
								icon: GitBranchIcon,
								variant: "invisible",
								href: branchesPath({ repo }),
								className: OverviewContent_module_default.Button_1
							}), /* @__PURE__ */ jsx(ButtonComponent, {
								as: "a",
								"aria-label": "Go to Tags page",
								icon: TagIcon,
								variant: "invisible",
								href: tagsPath({ repo }),
								className: OverviewContent_module_default.Button_1
							})]
						})
					]
				}), /* @__PURE__ */ jsxs("div", {
					className: OverviewContent_module_default.Box_6,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: OverviewContent_module_default.Box_7,
							children: [
								/* @__PURE__ */ jsx(AllShortcutsEnabled, { children: /* @__PURE__ */ jsx("button", {
									hidden: true,
									"data-hotkey": findFilesShortcut.hotkey,
									onClick: onFindFilesShortcut
								}) }),
								/* @__PURE__ */ jsx("div", {
									className: OverviewContent_module_default.Box_8,
									children: /* @__PURE__ */ jsx(Suspense, {
										fallback: null,
										children: /* @__PURE__ */ jsx(FileResultsList, {
											commitOid: refInfo.currentOid,
											findFileWorkerPath,
											searchBoxRef: inputRef,
											className: OverviewContent_module_default.FileResultsList
										})
									})
								}),
								/* @__PURE__ */ jsx("div", {
									className: OverviewContent_module_default.Box_9,
									children: /* @__PURE__ */ jsx(ButtonComponent, {
										onClick: navigateToSearch,
										children: "Go to file"
									})
								}),
								/* @__PURE__ */ jsx(AddFileDropdownButton, { useDynamicSizing: true })
							]
						}),
						isCopilotSWEAgentEnabled && /* @__PURE__ */ jsx(NewAgentTaskButton, {
							isIconButton: true,
							currentRepo: repo,
							hideRepoSelector: true,
							eventType: "new_agent_task_button_repo_overview",
							decoupledModeEnabled
						}),
						/* @__PURE__ */ jsx(CodeDropdownButton, {
							refName: refInfo.name,
							refType: refInfo.refType,
							currentBranchName: refInfo.refType === "branch" ? refInfo.name : void 0,
							createRef: refInfo.name,
							primary: !overview.templateButton,
							showCodespacesTab: codeButton.codespacesEnabled,
							isEnterprise: codeButton.isEnterprise,
							localTab: /* @__PURE__ */ jsx(LocalTab, { ...local }),
							codespacesTab: /* @__PURE__ */ jsx(CodespacesTab, { ...codespaces })
						}),
						/* @__PURE__ */ jsx("div", {
							className: OverviewContent_module_default.Box_10,
							children: /* @__PURE__ */ jsxs(ActionMenu, { children: [/* @__PURE__ */ jsx(ActionMenu.Anchor, { children: /* @__PURE__ */ jsx(IconButton, {
								tooltipDirection: "n",
								icon: KebabHorizontalIcon,
								"aria-label": "Open more actions menu"
							}) }), /* @__PURE__ */ jsx(ActionMenu.Overlay, { children: /* @__PURE__ */ jsxs(ActionList, { children: [
								/* @__PURE__ */ jsxs(ActionList.LinkItem, {
									href: branchesPath({ repo }),
									children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: GitBranchIcon }) }), "Branches"]
								}),
								/* @__PURE__ */ jsxs(ActionList.LinkItem, {
									href: tagsPath({ repo }),
									children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: TagIcon }) }), "Tags"]
								}),
								/* @__PURE__ */ jsx(ActionList.Divider, {}),
								/* @__PURE__ */ jsxs(ActionList.Item, {
									onSelect: navigateToSearch,
									children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: SearchIcon }) }), "Go to file"]
								}),
								/* @__PURE__ */ jsxs(ActionList.LinkItem, {
									as: Link$1,
									to: repositoryTreePath({
										repo,
										path,
										commitish: refInfo.name,
										action: "new"
									}),
									children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: PlusIcon }) }), "Create new file"]
								}),
								/* @__PURE__ */ jsxs(ActionList.LinkItem, {
									href: repositoryTreePath({
										repo,
										path,
										commitish: refInfo.name,
										action: "upload"
									}),
									children: [/* @__PURE__ */ jsx(ActionList.LeadingVisual, { children: /* @__PURE__ */ jsx(Octicon, { icon: UploadIcon }) }), "Upload file"]
								})
							] }) })] })
						})
					]
				})]
			}),
			payload.tree.showBranchInfobar && /* @__PURE__ */ jsx(ErrorBoundary, {
				fallback: /* @__PURE__ */ jsx(BranchInfoBarErrorBanner, {}),
				children: /* @__PURE__ */ jsx(BranchInfoBar, {})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: OverviewContent_module_default.Box_11,
				children: [/* @__PURE__ */ jsx(DirectoryContent, { overview: payload.overview }), /* @__PURE__ */ jsx(OverviewFiles, {
					initialFiles: overview.overviewFiles,
					shouldRecommendReadme: overview.banners.shouldRecommendReadme,
					isPersonalRepo: overview.banners.isPersonalRepo
				})]
			})
		]
	}) });
}
OverviewContentInternal.displayName = "OverviewContentInternal";
function ReposOverview(t0) {
	const $ = c$1(5);
	const { payload, className, tree } = t0;
	const refInfo = useCanonicalObject(payload.refInfo);
	useWebVitals("hpc", _temp);
	useWebVitals("inp", _temp2);
	let t1;
	if ($[0] !== className || $[1] !== payload || $[2] !== refInfo || $[3] !== tree) {
		t1 = jsx(PathProvider, {
			path: payload.path,
			children: jsx(ActionProvider, {
				action: "tree",
				children: jsx(CopilotSettingsProvider, {
					copilotAccessAllowed: payload.copilotAccessAllowed ?? false,
					children: jsx(RefInfoProvider, {
						refInfo,
						children: jsx(EditPermissionsProvider, {
							canEdit: refInfo.canEdit,
							canEditOnDefaultBranch: refInfo.canEditOnDefaultBranch,
							fileExistsOnDefault: refInfo.fileExistsOnDefault,
							children: jsx(CodeViewBannersProvider, { children: jsx(CurrentTreeProvider, {
								payload: tree,
								children: jsx(UserNameDisplayContextProvider, {
									value: payload.userNameDisplayConfiguration,
									children: jsx(OverviewContent, {
										payload,
										className
									})
								})
							}) })
						})
					})
				})
			})
		});
		$[0] = className;
		$[1] = payload;
		$[2] = refInfo;
		$[3] = tree;
		$[4] = t1;
	} else t1 = $[4];
	return t1;
}
ReposOverview.displayName = "ReposOverview";
function _temp2(event_0) {
	if (!event_0.detail.inp) return;
	sendCustomMetric({
		name: "CODE_VIEW_REPO_OVERVIEW_INP",
		value: event_0.detail.inp,
		tags: {
			app: "code-view",
			inpInteractionType: event_0.detail.inpInteractionType || "unknown",
			inpEventType: event_0.detail.inpEventType || "unknown",
			inpBottleneck: event_0.detail.inpBottleneck || "unknown"
		}
	});
}
function _temp(event) {
	if (!event.detail.hpc) return;
	sendCustomMetric({
		name: "CODE_VIEW_REPO_OVERVIEW_HPC",
		value: event.detail.hpc,
		tags: {
			app: "code-view",
			soft: String(event.detail.soft),
			ssr: String(event.detail.ssr),
			mechanism: String(event.detail.mechanism)
		}
	});
}
var SidebarSection_module_default = {
	headingLink: "SidebarSection-module_TOhNLG_headingLink",
	headingLinkWrapper: "SidebarSection-module_TOhNLG_headingLinkWrapper",
	moreLink: "SidebarSection-module_TOhNLG_moreLink",
	sectionHeading: "SidebarSection-module_TOhNLG_sectionHeading",
	sidebarSection: "SidebarSection-module_TOhNLG_sidebarSection"
};
/** Shared wrapper for sidebar sections: renders a heading (optionally linked with a counter), body, and optional "more" link. */
function SidebarSection({ title, href, count, moreCount, moreLabel, children, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(SidebarSection_module_default.sidebarSection, className),
		children: [
			title && /* @__PURE__ */ jsx(Heading$2, {
				as: "h2",
				variant: "small",
				className: SidebarSection_module_default.sectionHeading,
				children: href ? /* @__PURE__ */ jsxs("span", {
					className: SidebarSection_module_default.headingLinkWrapper,
					children: [/* @__PURE__ */ jsx(Link, {
						muted: true,
						as: Link$1,
						to: href,
						className: SidebarSection_module_default.headingLink,
						children: /* @__PURE__ */ jsx("span", { children: title })
					}), count != null && count > 0 && /* @__PURE__ */ jsx(CounterLabel, {
						className: "ml-1",
						children: count.toLocaleString()
					})]
				}) : /* @__PURE__ */ jsx("span", { children: title })
			}),
			children,
			moreCount != null && moreCount > 0 && href != null && /* @__PURE__ */ jsx("div", {
				className: SidebarSection_module_default.moreLink,
				children: /* @__PURE__ */ jsx(Link, {
					as: Link$1,
					to: href,
					className: "text-small",
					children: /* @__PURE__ */ jsx("span", { children: `+ ${moreCount.toLocaleString()} ${moreLabel ?? "more"}` })
				})
			})
		]
	});
}
SidebarSection.displayName = "SidebarSection";
/** Formats a large number with K/M suffixes for display. */
function socialCount(count) {
	if (count >= 1e6) return `${(count / 1e6).toFixed(1)}m`;
	if (count >= 1e3) return `${(count / 1e3).toFixed(1)}k`;
	return String(count);
}
var SAFE_PROTOCOLS = new Set([
	"http:",
	"https:",
	"mailto:"
]);
/**
* Returns the URL if it uses a safe protocol (http/https/mailto) or is an anchor (#),
* otherwise returns undefined. Prevents javascript: and data: scheme injection.
*/
function safeHref(url) {
	if (!url) return void 0;
	if (url.startsWith("#")) return url;
	try {
		const parsed = new URL(url, window.location.origin);
		return SAFE_PROTOCOLS.has(parsed.protocol) ? url : void 0;
	} catch {
		return;
	}
}
/** A link that automatically tracks clicks with sidebar analytics. */
function SidebarLink(t0) {
	const $ = c$1(18);
	const { to, href, analyticsLabel, reloadDocument, muted, inline, className, children } = t0;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	let t1;
	if ($[0] !== analyticsLabel || $[1] !== sendClickAnalyticsEvent) {
		t1 = analyticsLabel ? () => sendClickAnalyticsEvent({
			category: "REPOSITORY_OVERVIEW",
			action: "click",
			label: `location:sidebar;${analyticsLabel}`
		}) : void 0;
		$[0] = analyticsLabel;
		$[1] = sendClickAnalyticsEvent;
		$[2] = t1;
	} else t1 = $[2];
	const handleClick = t1;
	if (to) {
		let t2;
		if ($[3] !== children || $[4] !== className || $[5] !== handleClick || $[6] !== inline || $[7] !== muted || $[8] !== reloadDocument || $[9] !== to) {
			t2 = jsx(Link, {
				as: Link$1,
				to,
				reloadDocument,
				muted,
				inline,
				className,
				onClick: handleClick,
				children
			});
			$[3] = children;
			$[4] = className;
			$[5] = handleClick;
			$[6] = inline;
			$[7] = muted;
			$[8] = reloadDocument;
			$[9] = to;
			$[10] = t2;
		} else t2 = $[10];
		return t2;
	}
	let t2;
	if ($[11] !== children || $[12] !== className || $[13] !== handleClick || $[14] !== href || $[15] !== inline || $[16] !== muted) {
		t2 = jsx(Link, {
			href: safeHref(href),
			muted,
			inline,
			className,
			onClick: handleClick,
			children
		});
		$[11] = children;
		$[12] = className;
		$[13] = handleClick;
		$[14] = href;
		$[15] = inline;
		$[16] = muted;
		$[17] = t2;
	} else t2 = $[17];
	return t2;
}
SidebarLink.displayName = "SidebarLink";
/** An icon + label link row used in the About section for resources and metadata. */
function SidebarResourceLink({ icon: Icon, label, to, href, analyticsLabel, srHeading }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [srHeading != null && /* @__PURE__ */ jsx(Heading$2, {
		as: "h3",
		className: "sr-only",
		children: /* @__PURE__ */ jsx("span", { children: srHeading })
	}), /* @__PURE__ */ jsx("div", {
		className: "mt-2",
		children: /* @__PURE__ */ jsxs(SidebarLink, {
			to,
			href,
			muted: true,
			analyticsLabel,
			children: [/* @__PURE__ */ jsx(Icon, { className: "mr-2" }), /* @__PURE__ */ jsx("span", { children: label })]
		})
	})] });
}
SidebarResourceLink.displayName = "SidebarResourceLink";
var SidebarAbout_module_default = {
	description: "SidebarAbout-module_eqNI3a_description",
	noDescription: "SidebarAbout-module_eqNI3a_noDescription",
	websiteLink: "SidebarAbout-module_eqNI3a_websiteLink",
	websiteRow: "SidebarAbout-module_eqNI3a_websiteRow"
};
/** Renders the About section of the repository sidebar. */
function SidebarAbout(t0) {
	const $ = c$1(24);
	const { description, website, topics, hasReadme, license, hasCodeOfConduct, hasContributing, hasSecurityPolicy, showInsights, stargazerCount, watcherCount, forksCount, stargazersPath, watchersPath, forkNetworkPath, activityPath, customPropertiesPath, auditLogPath, reportPath, className } = t0;
	const { sendClickAnalyticsEvent } = useClickAnalytics();
	const hasDescription = !!description;
	const hasWebsite = !!website;
	let t1;
	if ($[0] !== activityPath || $[1] !== auditLogPath || $[2] !== className || $[3] !== customPropertiesPath || $[4] !== description || $[5] !== forkNetworkPath || $[6] !== forksCount || $[7] !== hasCodeOfConduct || $[8] !== hasContributing || $[9] !== hasDescription || $[10] !== hasReadme || $[11] !== hasSecurityPolicy || $[12] !== hasWebsite || $[13] !== license || $[14] !== reportPath || $[15] !== sendClickAnalyticsEvent || $[16] !== showInsights || $[17] !== stargazerCount || $[18] !== stargazersPath || $[19] !== topics || $[20] !== watcherCount || $[21] !== watchersPath || $[22] !== website) {
		const safeSite = website ? safeHref(website) : null;
		const hasTopics = topics && topics.length > 0;
		t1 = jsxs(SidebarSection, {
			title: "About",
			className,
			children: [
				!hasDescription && !hasWebsite && jsx("div", {
					className: SidebarAbout_module_default.noDescription,
					children: hasTopics ? jsx("span", { children: "No description or website provided." }) : jsx("span", { children: "No description, website, or topics provided." })
				}),
				hasDescription && jsx("p", {
					className: SidebarAbout_module_default.description,
					children: description
				}),
				hasWebsite && safeSite && jsxs("div", {
					className: SidebarAbout_module_default.websiteRow,
					children: [jsx(LinkIcon, { className: "flex-shrink-0" }), jsx(Truncate, {
						as: "span",
						className: SidebarAbout_module_default.websiteLink,
						title: website,
						maxWidth: "none",
						children: jsx(Link, {
							href: safeSite,
							target: "_blank",
							rel: "noopener noreferrer nofollow",
							className: "text-bold",
							children: website.replace(/^https?:\/\//, "")
						})
					})]
				}),
				hasTopics && jsxs(Fragment$1, { children: [jsx(Heading$2, {
					as: "h3",
					className: "sr-only",
					children: jsx("span", { children: "Topics" })
				}), jsx(TopicTag.Group, { children: topics.map((topic) => jsx(TopicTag, {
					as: Link$1,
					to: `/topics/${encodeURIComponent(topic.name)}`,
					onClick: () => sendClickAnalyticsEvent({
						category: "REPOSITORY_OVERVIEW",
						action: "click",
						label: "location:sidebar;section:topics"
					}),
					children: topic.name
				}, `topic-${topic.name}`)) })] }),
				hasReadme && jsx(SidebarResourceLink, {
					icon: BookIcon,
					label: "Readme",
					href: "#readme-ov-file",
					analyticsLabel: "file:readme",
					srHeading: "Resources"
				}),
				license?.name && !license.isLoading && jsx(SidebarResourceLink, {
					icon: LawIcon,
					label: license.name.toLowerCase().includes("license") ? license.name : `${license.name} license`,
					href: "#license-1-ov-file",
					analyticsLabel: "file:license"
				}),
				license?.isLoading && jsx("div", {
					className: "mt-2",
					children: jsx(SkeletonText, { lines: 1 })
				}),
				hasCodeOfConduct && jsx(SidebarResourceLink, {
					icon: CodeOfConductIcon,
					label: "Code of conduct",
					href: "#coc-ov-file",
					analyticsLabel: "file:code of conduct",
					srHeading: "Code of conduct"
				}),
				hasContributing && jsx(SidebarResourceLink, {
					icon: PeopleIcon,
					label: "Contributing",
					href: "#contributing-ov-file",
					analyticsLabel: "file:contributing",
					srHeading: "Contributing"
				}),
				hasSecurityPolicy && jsx(SidebarResourceLink, {
					icon: ShieldLockIcon,
					label: "Security policy",
					href: "#security-ov-file",
					analyticsLabel: "file:security policy",
					srHeading: "Security policy"
				}),
				showInsights && activityPath && jsx(SidebarResourceLink, {
					icon: PulseIcon,
					label: "Activity",
					to: activityPath,
					analyticsLabel: "section:activity"
				}),
				customPropertiesPath && showInsights && jsx(SidebarResourceLink, {
					icon: NoteIcon,
					label: "Custom properties",
					to: customPropertiesPath
				}),
				showInsights && jsxs(Fragment$1, { children: [
					jsx(Heading$2, {
						as: "h3",
						className: "sr-only",
						children: jsx("span", { children: "Stars" })
					}),
					jsx("div", {
						className: "mt-2",
						children: jsxs(SidebarLink, {
							to: stargazersPath,
							muted: true,
							analyticsLabel: "section:stars",
							children: [
								jsx(StarIcon, { className: "mr-2" }),
								jsx("span", { children: jsx("strong", { children: socialCount(stargazerCount) }) }),
								jsx("span", { children: ` star${stargazerCount === 1 ? "" : "s"}` })
							]
						})
					}),
					jsx(Heading$2, {
						as: "h3",
						className: "sr-only",
						children: jsx("span", { children: "Watchers" })
					}),
					jsx("div", {
						className: "mt-2",
						children: jsxs(SidebarLink, {
							to: watchersPath,
							muted: true,
							analyticsLabel: "section:watchers",
							children: [
								jsx(EyeIcon, { className: "mr-2" }),
								jsx("span", { children: jsx("strong", { children: socialCount(watcherCount) }) }),
								jsx("span", { children: " watching" })
							]
						})
					}),
					jsx(Heading$2, {
						as: "h3",
						className: "sr-only",
						children: jsx("span", { children: "Forks" })
					}),
					jsx("div", {
						className: "mt-2",
						children: jsxs(SidebarLink, {
							to: forkNetworkPath,
							muted: true,
							analyticsLabel: "section:forks",
							children: [
								jsx(RepoForkedIcon, { className: "mr-2" }),
								jsx("span", { children: jsx("strong", { children: socialCount(forksCount) }) }),
								jsx("span", { children: ` fork${forksCount === 1 ? "" : "s"}` })
							]
						})
					})
				] }),
				auditLogPath && jsx(SidebarResourceLink, {
					icon: LogIcon,
					label: "Audit log",
					to: auditLogPath
				}),
				reportPath && jsx("div", {
					className: "mt-2",
					children: jsx(SidebarLink, {
						to: reportPath,
						reloadDocument: true,
						muted: true,
						analyticsLabel: "section:report",
						children: jsx("span", { children: "Report repository" })
					})
				})
			]
		});
		$[0] = activityPath;
		$[1] = auditLogPath;
		$[2] = className;
		$[3] = customPropertiesPath;
		$[4] = description;
		$[5] = forkNetworkPath;
		$[6] = forksCount;
		$[7] = hasCodeOfConduct;
		$[8] = hasContributing;
		$[9] = hasDescription;
		$[10] = hasReadme;
		$[11] = hasSecurityPolicy;
		$[12] = hasWebsite;
		$[13] = license;
		$[14] = reportPath;
		$[15] = sendClickAnalyticsEvent;
		$[16] = showInsights;
		$[17] = stargazerCount;
		$[18] = stargazersPath;
		$[19] = topics;
		$[20] = watcherCount;
		$[21] = watchersPath;
		$[22] = website;
		$[23] = t1;
	} else t1 = $[23];
	return t1;
}
SidebarAbout.displayName = "SidebarAbout";
var CodeViewSidebar_module_default = { borderGrid: "CodeViewSidebar-module_6TmlqG_borderGrid" };
/**
* Layout container for the repository sidebar.
* Renders the grid shell without requiring all section data upfront,
* allowing each child section to be independently wrapped in Suspense.
*/
function CodeViewSidebarLayout({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: CodeViewSidebar_module_default.borderGrid,
		children
	});
}
CodeViewSidebarLayout.displayName = "CodeViewSidebarLayout";
/**
* Extract sidebar-relevant data from overviewFiles.
*
* Reuses tree_payload_helper's proven resolution so we don't need
* duplicate fields in the sidebarAbout endpoint.
*/
function extractOverviewFilesData({ overviewFiles }) {
	return overviewFiles?.reduce((acc, file) => {
		if (file.preferredFileType === PreferredFileTypes.LICENSE) acc.license = { name: file.tabName ?? "License" };
		else if (file.preferredFileType === PreferredFileTypes.README) acc.hasReadme = true;
		else if (file.preferredFileType === PreferredFileTypes.CODE_OF_CONDUCT) acc.hasCodeOfConduct = true;
		else if (file.preferredFileType === PreferredFileTypes.CONTRIBUTING) acc.hasContributing = true;
		else if (file.preferredFileType === PreferredFileTypes.SECURITY) acc.hasSecurityPolicy = true;
		return acc;
	}, {});
}
/**
* Sidebar orchestrator for the repository overview page.
*
* Fetches route-level queries and passes primitives to presentational
* components from `@github-ui/code-view-sidebar`. Each section can be
* independently wrapped in Suspense as more are added.
*
* File-presence fields (readme, license, code of conduct, contributing,
* security policy) come from the main payload's overviewFiles
*/
function OverviewSidebar(t0) {
	const $ = c$1(7);
	const { overview } = t0;
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("react_data_router_code_view_sidebar");
		$[0] = t1;
	} else t1 = $[0];
	const reactSidebarEnabled = t1;
	let t2;
	if ($[1] !== overview) {
		t2 = extractOverviewFilesData(overview);
		$[1] = overview;
		$[2] = t2;
	} else t2 = $[2];
	const overviewFiles = t2;
	let t3;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = { enabled: reactSidebarEnabled };
		$[3] = t3;
	} else t3 = $[3];
	const { data: aboutData } = useRouteQuery(codeViewRepoRoute, "sidebarAbout", t3);
	if (!aboutData || !overviewFiles || !reactSidebarEnabled) return null;
	let t4;
	if ($[4] !== aboutData || $[5] !== overviewFiles) {
		t4 = jsx(CodeViewSidebarLayout, { children: jsx(SidebarAbout, {
			className: "hide-sm hide-md",
			...aboutData,
			...overviewFiles
		}) });
		$[4] = aboutData;
		$[5] = overviewFiles;
		$[6] = t4;
	} else t4 = $[6];
	return t4;
}
OverviewSidebar.displayName = "OverviewSidebar";
function ReposOverviewPage(t0) {
	const $ = c$1(4);
	const { payload, isTree } = t0;
	useUpdateRefInfoAndPath(payload.refInfo, payload.path);
	let t1;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = isFeatureEnabled("react_data_router_code_view_sidebar");
		$[0] = t1;
	} else t1 = $[0];
	const reactSidebarEnabled = t1;
	let t2;
	if ($[1] !== isTree || $[2] !== payload) {
		t2 = jsxs(SplitPageLayout, {
			className: "container-xl",
			children: [
				jsx(SplitPageLayout.Header, {
					padding: "none",
					divider: "none",
					className: "tmp-px-3 tmp-px-lg-5",
					children: isTree ? jsx(RailsPartialHTML, {
						html: payload.overview.partials.header,
						partialName: "codeViewTreeRoute.Header"
					}) : jsx(RailsPartial, {
						route: codeViewRepoRoute,
						partialName: "Header"
					})
				}),
				jsx(SplitPageLayout.Content, {
					as: "div",
					padding: "condensed",
					children: jsx(ReposOverview, {
						payload,
						className: "tmp-pl-lg-3 mt-0",
						tree: payload.tree
					})
				}),
				jsx(SplitPageLayout.Pane, {
					position: "end",
					sticky: false,
					divider: "none",
					width: "large",
					className: "pr-2",
					children: isTree ? jsx(RailsPartialHTML, {
						html: payload.overview.partials.sidebar,
						partialName: "codeViewTreeRoute.Sidebar"
					}) : reactSidebarEnabled ? jsx(OverviewSidebar, { overview: payload.overview }) : jsx(RailsPartial, {
						route: codeViewRepoRoute,
						partialName: "Sidebar"
					})
				})
			]
		});
		$[1] = isTree;
		$[2] = payload;
		$[3] = t2;
	} else t2 = $[3];
	return t2;
}
ReposOverviewPage.displayName = "ReposOverviewPage";
export { DirectoryContent as a, RecentlyTouchedBranchesProvider as c, CommitInfoProvider as i, ReposOverviewPage as l, BranchInfoBar as n, DirectoryRichtextContent as o, BranchInfoBarErrorBanner as r, EditButton as s, BranchAndTagCountProvider as t };
