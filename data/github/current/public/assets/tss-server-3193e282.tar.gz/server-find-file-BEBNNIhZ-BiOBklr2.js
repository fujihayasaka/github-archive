import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { Gt as treeListPath } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { r as score, t as hasMatch } from "./server-fzy.js-7qhjn37q.js";
import memoize from "@github/memoize";
import { createContext, use, useEffect, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
async function fetchJSON(url) {
	const response = await verifiedFetchJSON(url);
	if (response.ok) return await response.json();
	else return;
}
var memoizedFetch = memoize(fetchJSON, { cache: /* @__PURE__ */ new Map() });
function useTreeList(commitOid, load, excludeDirectories) {
	const $ = c(8);
	const repo = useCurrentRepository();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = {
			list: [],
			directories: [],
			loading: true
		};
		$[0] = t0;
	} else t0 = $[0];
	const [state, setState] = useState(t0);
	let t1;
	let t2;
	if ($[1] !== commitOid || $[2] !== excludeDirectories || $[3] !== load || $[4] !== repo.name || $[5] !== repo.ownerLogin) {
		t1 = () => {
			const treeListUrl = treeListPath({
				repo: {
					name: repo.name,
					ownerLogin: repo.ownerLogin
				},
				commitOid,
				includeDirectories: !excludeDirectories
			});
			let cancelled = false;
			const update = async () => {
				setState({
					list: [],
					directories: [],
					loading: true
				});
				const data = await memoizedFetch(treeListUrl);
				if (cancelled) return;
				const files = data?.paths || [];
				const directories = data?.directories || [];
				setState({
					list: files.concat(directories).sort(),
					directories,
					error: !data
				});
			};
			if (load) update();
			return function cancel() {
				cancelled = true;
			};
		};
		t2 = [
			repo.name,
			repo.ownerLogin,
			excludeDirectories,
			commitOid,
			load
		];
		$[1] = commitOid;
		$[2] = excludeDirectories;
		$[3] = load;
		$[4] = repo.name;
		$[5] = repo.ownerLogin;
		$[6] = t1;
		$[7] = t2;
	} else {
		t1 = $[6];
		t2 = $[7];
	}
	useEffect(t1, t2);
	return state;
}
var FileQueryContext = createContext({
	query: "",
	setQuery: () => void 0
});
FileQueryContext.displayName = "FileQueryContext";
function useFileQueryContext() {
	return use(FileQueryContext);
}
function FileQueryProvider(t0) {
	const $ = c(5);
	const { children } = t0;
	const [query, setQuery] = useState("");
	let t1;
	if ($[0] !== query) {
		t1 = {
			query,
			setQuery
		};
		$[0] = query;
		$[1] = t1;
	} else t1 = $[1];
	const value = t1;
	let t2;
	if ($[2] !== children || $[3] !== value) {
		t2 = jsx(FileQueryContext, {
			value,
			children
		});
		$[2] = children;
		$[3] = value;
		$[4] = t2;
	} else t2 = $[4];
	return t2;
}
FileQueryProvider.displayName = "FileQueryProvider";
/**
* WebWorker is an abstraction that exposes similar interface as a Service Worker.
* However, besides the path it also requires a callback, same function as the one run in the worker thread.
* This callback is used as a fallback if worker cannot be created.
*/
var WebWorker = class {
	worker;
	set onmessage(listener) {
		this.worker.onmessage = listener;
	}
	constructor(path, job) {
		try {
			this.worker = new Worker(`${path}?module=true`, { type: "module" });
		} catch {
			console.warn("Web workers are not available. Please enable web workers to benefit from the improved performance.");
			this.worker = new MainThreadWorker(job);
		}
	}
	postMessage(request) {
		this.worker.postMessage(request);
	}
	terminate() {
		this.worker.terminate();
	}
};
var MainThreadWorker = class {
	#terminated = false;
	onmessage;
	#job;
	constructor(job) {
		this.#job = job;
	}
	async postMessage(request) {
		if (this.#terminated) return;
		const response = { data: this.#job({ data: request }) };
		this.onmessage?.(response);
	}
	terminate() {
		this.#terminated = true;
	}
};
var fuzzyScore = memoize(score);
function findFileWorkerJob({ data }) {
	const { query, baseList, startTime } = data;
	const queryWithoutBackslash = query.replaceAll("\\", "");
	return {
		query,
		list: baseList.filter((item) => filterItem(item, queryWithoutBackslash)).sort((itemA, itemB) => fuzzyScore(queryWithoutBackslash, itemB) - fuzzyScore(queryWithoutBackslash, itemA)),
		baseCount: baseList.length,
		startTime
	};
}
function filterItem(item, query) {
	return query === "" || hasMatch(query, item) && fuzzyScore(query, item) > 0;
}
export { useTreeList as a, useFileQueryContext as i, WebWorker as n, findFileWorkerJob as r, FileQueryProvider as t };
