import { o as useId$1 } from "./server-Spinner-BZ8wcT_g-DyRp0Aa2.js";
import { m as useRefObjectAsForwardedRef } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { Fi as getResponsiveAttributes, Gi as useSlots } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as useIsomorphicLayoutEffect } from "./server-useIsomorphicLayoutEffect-CQhQYPHk-DtEZxf1Y.js";
import { t as useOverflow } from "./server-useOverflow-CWkWsgCk-CBzg9WER.js";
import { t as isResponsiveValue } from "./server-useResponsiveValue-DzTNwE8j-CoqY8Y2P.js";
import React, { memo, startTransition, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react-compiler-runtime";
import { clsx } from "clsx";
var classes = {
	"paneMaxWidthDiffBreakpoint": "1280",
	"paneMaxWidthDiffDefault": "511",
	"sidebarMaxWidthDiffDefault": "256",
	"paneMaxWidthDiffWide": "959",
	"PageLayoutRoot": "prc-PageLayout-PageLayoutRoot--KH-d",
	"PageLayoutWrapper": "prc-PageLayout-PageLayoutWrapper-2BhU2",
	"PageLayoutContent": "prc-PageLayout-PageLayoutContent-BneH9",
	"HorizontalDivider": "prc-PageLayout-HorizontalDivider-JLVqp",
	"VerticalDivider": "prc-PageLayout-VerticalDivider-9QRmK",
	"Header": "prc-PageLayout-Header-0of-R",
	"HeaderContent": "prc-PageLayout-HeaderContent-gdFfN",
	"HeaderHorizontalDivider": "prc-PageLayout-HeaderHorizontalDivider-odAHl",
	"ContentWrapper": "prc-PageLayout-ContentWrapper-gR9eG",
	"Content": "prc-PageLayout-Content-xWL-A",
	"PaneWrapper": "prc-PageLayout-PaneWrapper-pHPop",
	"PaneVerticalDivider": "prc-PageLayout-PaneVerticalDivider-le57g",
	"Pane": "prc-PageLayout-Pane-AyzHK",
	"PaneHorizontalDivider": "prc-PageLayout-PaneHorizontalDivider-9tbnE",
	"FooterWrapper": "prc-PageLayout-FooterWrapper-9cB8y",
	"FooterHorizontalDivider": "prc-PageLayout-FooterHorizontalDivider-W-RaS",
	"FooterContent": "prc-PageLayout-FooterContent-HUS0V",
	"DraggableHandle": "prc-PageLayout-DraggableHandle-9s6B4",
	"SidebarWrapper": "prc-PageLayout-SidebarWrapper-kLG4B",
	"Sidebar": "prc-PageLayout-Sidebar-iciWg",
	"SidebarVerticalDivider": "prc-PageLayout-SidebarVerticalDivider-0Rl0V"
};
/**
* Indicate whether current execution environment can access the DOM.
*
* @see https://github.com/facebook/fbjs/blob/4d1751311d3f67af2dcce2e40df8512a23c7b9c6/packages/fbjs/src/core/ExecutionEnvironment.js#L12
*/
var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
/**
* Width value for the pane - defines constraints and defaults only.
* - `PaneWidth`: Preset size ('small' | 'medium' | 'large')
* - `CustomWidthOptions`: Explicit min/default/max constraints
*/
/**
* Default value for --pane-max-width-diff CSS variable.
* Imported from CSS to ensure JS fallback matches the CSS default.
*/
var DEFAULT_MAX_WIDTH_DIFF = Number(classes.paneMaxWidthDiffDefault);
/**
* Default value for --sidebar-max-width-diff CSS variable.
* Unlike --pane-max-width-diff, this is constant across all viewport sizes.
*/
var DEFAULT_SIDEBAR_MAX_WIDTH_DIFF = Number(classes.sidebarMaxWidthDiffDefault);
var WIDE_MAX_WIDTH_DIFF = Number(classes.paneMaxWidthDiffWide);
var DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT = Number(classes.paneMaxWidthDiffBreakpoint);
/** Default widths for preset size options */
var defaultPaneWidth = {
	small: 256,
	medium: 296,
	large: 320
};
var isCustomWidthOptions = (width) => {
	return typeof width === "object" && "min" in width && "default" in width && "max" in width;
};
var isPaneWidth = (width) => {
	return width === "small" || width === "medium" || width === "large";
};
var getDefaultPaneWidth = (w) => {
	if (isPaneWidth(w)) return defaultPaneWidth[w];
	else if (isCustomWidthOptions(w)) return parseInt(w.default, 10);
	return 0;
};
/**
* Derives the --pane-max-width-diff value from viewport width alone.
* Avoids the expensive getComputedStyle call that forces a synchronous layout recalc.
* The CSS only defines two breakpoint-dependent values, so a simple width check is equivalent.
*/
function getMaxWidthDiffFromViewport() {
	if (!canUseDOM) return DEFAULT_MAX_WIDTH_DIFF;
	return window.innerWidth >= DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT ? WIDE_MAX_WIDTH_DIFF : DEFAULT_MAX_WIDTH_DIFF;
}
var updateAriaValues = (handle, values) => {
	if (!handle) return;
	if (values.min !== void 0) handle.setAttribute("aria-valuemin", String(values.min));
	if (values.max !== void 0) handle.setAttribute("aria-valuemax", String(values.max));
	if (values.current !== void 0) {
		handle.setAttribute("aria-valuenow", String(values.current));
		handle.setAttribute("aria-valuetext", `Pane width ${values.current} pixels`);
	}
};
var localStoragePersister = {
	save: (key, width) => {
		try {
			localStorage.setItem(key, width.toString());
		} catch {}
	},
	get: (key) => {
		try {
			const storedWidth = localStorage.getItem(key);
			if (storedWidth !== null) {
				const parsed = Number(storedWidth);
				if (!isNaN(parsed) && parsed > 0) return Math.round(parsed);
			}
		} catch {}
		return null;
	}
};
/**
* Manages pane width state with storage persistence and viewport constraints.
* Handles initialization from storage, clamping on viewport resize, and provides
* functions to save and reset width.
*
* Storage behavior:
* - When `resizable` is `true` and `onResizeEnd` is not provided: Uses localStorage
* - When `onResizeEnd` is provided: Calls the callback instead of localStorage
* - When `resizable` is `false` or `undefined`: Not resizable, no persistence
*/
function usePaneWidth(t0) {
	const $ = c(42);
	const { width, minWidth, resizable, widthStorageKey, paneRef, handleRef, contentWrapperRef, constrainToViewport: t1, onResizeEnd, currentWidth: controlledWidth } = t0;
	const constrainToViewport = t1 === void 0 ? false : t1;
	const isCustomWidth = isCustomWidthOptions(width);
	const minPaneWidth = isCustomWidth ? parseInt(width.min, 10) : minWidth;
	const customMaxWidth = isCustomWidth ? parseInt(width.max, 10) : null;
	const widthStorageKeyRef = React.useRef(widthStorageKey);
	const onResizeEndRef = React.useRef(onResizeEnd);
	let t2;
	if ($[0] !== onResizeEnd || $[1] !== widthStorageKey) {
		t2 = () => {
			widthStorageKeyRef.current = widthStorageKey;
			onResizeEndRef.current = onResizeEnd;
		};
		$[0] = onResizeEnd;
		$[1] = widthStorageKey;
		$[2] = t2;
	} else t2 = $[2];
	useIsomorphicLayoutEffect(t2);
	const maxWidthDiffRef = React.useRef(constrainToViewport ? DEFAULT_SIDEBAR_MAX_WIDTH_DIFF : DEFAULT_MAX_WIDTH_DIFF);
	let t3;
	if ($[3] !== constrainToViewport || $[4] !== customMaxWidth || $[5] !== minPaneWidth) {
		t3 = () => {
			const viewportWidth = window.innerWidth;
			const viewportMax = viewportWidth > 0 ? Math.max(minPaneWidth, viewportWidth - maxWidthDiffRef.current) : minPaneWidth;
			if (customMaxWidth !== null) return constrainToViewport ? Math.min(customMaxWidth, viewportMax) : customMaxWidth;
			return viewportMax;
		};
		$[3] = constrainToViewport;
		$[4] = customMaxWidth;
		$[5] = minPaneWidth;
		$[6] = t3;
	} else t3 = $[6];
	const getMaxPaneWidth = t3;
	let t4;
	if ($[7] !== width) {
		t4 = getDefaultPaneWidth(width);
		$[7] = width;
		$[8] = t4;
	} else t4 = $[8];
	const defaultWidth = t4;
	let t5;
	if ($[9] !== controlledWidth || $[10] !== defaultWidth || $[11] !== onResizeEnd || $[12] !== resizable || $[13] !== widthStorageKey) {
		t5 = () => {
			if (typeof controlledWidth === "number") return controlledWidth;
			if (onResizeEnd === void 0 && resizable === true && widthStorageKey !== void 0) {
				const storedWidth = localStoragePersister.get(widthStorageKey);
				if (storedWidth !== null) return storedWidth;
			}
			return defaultWidth;
		};
		$[9] = controlledWidth;
		$[10] = defaultWidth;
		$[11] = onResizeEnd;
		$[12] = resizable;
		$[13] = widthStorageKey;
		$[14] = t5;
	} else t5 = $[14];
	const [currentWidthState, setCurrentWidthState] = React.useState(t5);
	const [prevDefaultWidth, setPrevDefaultWidth] = React.useState(defaultWidth);
	const [prevControlledWidth, setPrevControlledWidth] = React.useState(controlledWidth);
	const controlledWidthChanged = controlledWidth !== prevControlledWidth;
	const defaultWidthChanged = defaultWidth !== prevDefaultWidth;
	if (controlledWidthChanged) {
		setPrevControlledWidth(controlledWidth);
		if (typeof controlledWidth === "number") setCurrentWidthState(controlledWidth);
		else if (prevControlledWidth !== void 0) setCurrentWidthState(defaultWidth);
	}
	if (defaultWidthChanged) {
		setPrevDefaultWidth(defaultWidth);
		if (controlledWidth === void 0 && !controlledWidthChanged) setCurrentWidthState(defaultWidth);
	}
	const currentWidth = controlledWidth !== null && controlledWidth !== void 0 ? controlledWidth : currentWidthState;
	const currentWidthRef = React.useRef(currentWidth);
	let t6;
	if ($[15] !== customMaxWidth) {
		t6 = () => customMaxWidth !== null && customMaxWidth !== void 0 ? customMaxWidth : 600;
		$[15] = customMaxWidth;
		$[16] = t6;
	} else t6 = $[16];
	const [maxPaneWidth, setMaxPaneWidth] = React.useState(t6);
	let t7;
	let t8;
	if ($[17] !== currentWidth) {
		t7 = () => {
			currentWidthRef.current = currentWidth;
		};
		t8 = [currentWidth];
		$[17] = currentWidth;
		$[18] = t7;
		$[19] = t8;
	} else {
		t7 = $[18];
		t8 = $[19];
	}
	useIsomorphicLayoutEffect(t7, t8);
	let t9;
	if ($[20] !== width) {
		t9 = () => getDefaultPaneWidth(width);
		$[20] = width;
		$[21] = t9;
	} else t9 = $[21];
	const getDefaultWidth = t9;
	let t10;
	if ($[22] !== resizable) {
		t10 = (value) => {
			const rounded = Math.round(value);
			currentWidthRef.current = rounded;
			startTransition(() => {
				setCurrentWidthState(rounded);
			});
			if (onResizeEndRef.current) {
				try {
					onResizeEndRef.current(rounded);
				} catch {}
				return;
			}
			if (resizable && widthStorageKeyRef.current) localStoragePersister.save(widthStorageKeyRef.current, rounded);
		};
		$[22] = resizable;
		$[23] = t10;
	} else t10 = $[23];
	const saveWidth = t10;
	const getMaxPaneWidthRef = React.useRef(getMaxPaneWidth);
	let t11;
	if ($[24] !== getMaxPaneWidth) {
		t11 = () => {
			getMaxPaneWidthRef.current = getMaxPaneWidth;
		};
		$[24] = getMaxPaneWidth;
		$[25] = t11;
	} else t11 = $[25];
	useIsomorphicLayoutEffect(t11);
	let t12;
	let t13;
	if ($[26] !== constrainToViewport || $[27] !== contentWrapperRef || $[28] !== customMaxWidth || $[29] !== handleRef || $[30] !== minPaneWidth || $[31] !== paneRef || $[32] !== resizable) {
		t12 = () => {
			var _paneRef$current3;
			if (!resizable) return;
			let lastViewportWidth = window.innerWidth;
			const syncAll = () => {
				var _paneRef$current;
				const currentViewportWidth = window.innerWidth;
				const crossedBreakpoint = lastViewportWidth < DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT && currentViewportWidth >= DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT || lastViewportWidth >= DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT && currentViewportWidth < DEFAULT_PANE_MAX_WIDTH_DIFF_BREAKPOINT;
				lastViewportWidth = currentViewportWidth;
				if (crossedBreakpoint) maxWidthDiffRef.current = getMaxWidthDiffFromViewport();
				const actualMax = getMaxPaneWidthRef.current();
				(_paneRef$current = paneRef.current) === null || _paneRef$current === void 0 || _paneRef$current.style.setProperty("--pane-max-width", `${actualMax}px`);
				const wasClamped = currentWidthRef.current > actualMax;
				if (wasClamped) {
					var _paneRef$current2;
					currentWidthRef.current = actualMax;
					(_paneRef$current2 = paneRef.current) === null || _paneRef$current2 === void 0 || _paneRef$current2.style.setProperty("--pane-width", `${actualMax}px`);
				}
				updateAriaValues(handleRef.current, {
					max: actualMax,
					current: currentWidthRef.current
				});
				startTransition(() => {
					setMaxPaneWidth(actualMax);
					if (wasClamped) setCurrentWidthState(actualMax);
				});
			};
			maxWidthDiffRef.current = getMaxWidthDiffFromViewport();
			const initialMax = getMaxPaneWidthRef.current();
			setMaxPaneWidth(initialMax);
			(_paneRef$current3 = paneRef.current) === null || _paneRef$current3 === void 0 || _paneRef$current3.style.setProperty("--pane-max-width", `${initialMax}px`);
			updateAriaValues(handleRef.current, {
				min: minPaneWidth,
				max: initialMax,
				current: currentWidthRef.current
			});
			if (customMaxWidth !== null && !constrainToViewport) return;
			let lastUpdateTime = 0;
			let pendingUpdate = false;
			let rafId = null;
			let debounceId = null;
			let isResizing = false;
			const startResizeOptimizations = () => {
				var _paneRef$current4, _contentWrapperRef$cu;
				if (isResizing) return;
				isResizing = true;
				(_paneRef$current4 = paneRef.current) === null || _paneRef$current4 === void 0 || _paneRef$current4.setAttribute("data-dragging", "true");
				(_contentWrapperRef$cu = contentWrapperRef.current) === null || _contentWrapperRef$cu === void 0 || _contentWrapperRef$cu.setAttribute("data-dragging", "true");
			};
			const endResizeOptimizations = () => {
				var _paneRef$current5, _contentWrapperRef$cu2;
				if (!isResizing) return;
				isResizing = false;
				(_paneRef$current5 = paneRef.current) === null || _paneRef$current5 === void 0 || _paneRef$current5.removeAttribute("data-dragging");
				(_contentWrapperRef$cu2 = contentWrapperRef.current) === null || _contentWrapperRef$cu2 === void 0 || _contentWrapperRef$cu2.removeAttribute("data-dragging");
			};
			const handleResize = () => {
				startResizeOptimizations();
				const now = Date.now();
				if (now - lastUpdateTime >= 16) {
					lastUpdateTime = now;
					syncAll();
				} else if (!pendingUpdate) {
					pendingUpdate = true;
					rafId = requestAnimationFrame(() => {
						pendingUpdate = false;
						rafId = null;
						lastUpdateTime = Date.now();
						syncAll();
					});
				}
				if (debounceId !== null) clearTimeout(debounceId);
				debounceId = setTimeout(() => {
					debounceId = null;
					endResizeOptimizations();
				}, 150);
			};
			window.addEventListener("resize", handleResize);
			return () => {
				if (rafId !== null) cancelAnimationFrame(rafId);
				if (debounceId !== null) clearTimeout(debounceId);
				endResizeOptimizations();
				window.removeEventListener("resize", handleResize);
			};
		};
		t13 = [
			resizable,
			customMaxWidth,
			constrainToViewport,
			minPaneWidth,
			paneRef,
			handleRef,
			contentWrapperRef
		];
		$[26] = constrainToViewport;
		$[27] = contentWrapperRef;
		$[28] = customMaxWidth;
		$[29] = handleRef;
		$[30] = minPaneWidth;
		$[31] = paneRef;
		$[32] = resizable;
		$[33] = t12;
		$[34] = t13;
	} else {
		t12 = $[33];
		t13 = $[34];
	}
	useIsomorphicLayoutEffect(t12, t13);
	let t14;
	if ($[35] !== currentWidth || $[36] !== getDefaultWidth || $[37] !== getMaxPaneWidth || $[38] !== maxPaneWidth || $[39] !== minPaneWidth || $[40] !== saveWidth) {
		t14 = {
			currentWidth,
			currentWidthRef,
			minPaneWidth,
			maxPaneWidth,
			getMaxPaneWidth,
			saveWidth,
			getDefaultWidth
		};
		$[35] = currentWidth;
		$[36] = getDefaultWidth;
		$[37] = getMaxPaneWidth;
		$[38] = maxPaneWidth;
		$[39] = minPaneWidth;
		$[40] = saveWidth;
		$[41] = t14;
	} else t14 = $[41];
	return t14;
}
var DATA_DRAGGING_ATTR = "data-dragging";
/** Apply visual feedback and performance optimizations during drag */
function setDraggingStyles({ handle, pane, contentWrapper }) {
	handle === null || handle === void 0 || handle.style.setProperty("--draggable-handle--bg-color", "var(--bgColor-accent-emphasis)");
	handle === null || handle === void 0 || handle.style.setProperty("--draggable-handle--drag-opacity", "1");
	handle === null || handle === void 0 || handle.style.setProperty("--draggable-handle--transition", "none");
	pane === null || pane === void 0 || pane.setAttribute(DATA_DRAGGING_ATTR, "true");
	contentWrapper === null || contentWrapper === void 0 || contentWrapper.setAttribute(DATA_DRAGGING_ATTR, "true");
}
/** Remove drag styles and restore normal state */
function removeDraggingStyles({ handle, pane, contentWrapper }) {
	handle === null || handle === void 0 || handle.style.removeProperty("--draggable-handle--bg-color");
	handle === null || handle === void 0 || handle.style.removeProperty("--draggable-handle--drag-opacity");
	handle === null || handle === void 0 || handle.style.removeProperty("--draggable-handle--transition");
	pane === null || pane === void 0 || pane.removeAttribute(DATA_DRAGGING_ATTR);
	contentWrapper === null || contentWrapper === void 0 || contentWrapper.removeAttribute(DATA_DRAGGING_ATTR);
}
var isArrowKey = (key) => key === "ArrowLeft" || key === "ArrowRight" || key === "ArrowUp" || key === "ArrowDown";
var isShrinkKey = (key) => key === "ArrowLeft" || key === "ArrowDown";
var PageLayoutContext = /* @__PURE__ */ React.createContext({
	padding: "normal",
	rowGap: "normal",
	columnGap: "normal",
	paneRef: { current: null },
	contentWrapperRef: { current: null },
	sidebarRef: { current: null },
	sidebarContentWrapperRef: { current: null }
});
var Root = ({ containerWidth = "xlarge", padding = "normal", rowGap = "normal", columnGap = "normal", children, className, style, _slotsConfig: slotsConfig }) => {
	const paneRef = useRef(null);
	const contentWrapperRef = useRef(null);
	const sidebarRef = useRef(null);
	const sidebarContentWrapperRef = useRef(null);
	const [slots, rest] = useSlots(children, slotsConfig !== null && slotsConfig !== void 0 ? slotsConfig : {
		header: Header,
		footer: Footer,
		sidebar: Sidebar
	});
	const memoizedContextValue = React.useMemo(() => {
		return {
			padding,
			rowGap,
			columnGap,
			paneRef,
			contentWrapperRef,
			sidebarRef,
			sidebarContentWrapperRef
		};
	}, [
		padding,
		rowGap,
		columnGap,
		paneRef,
		contentWrapperRef,
		sidebarRef,
		sidebarContentWrapperRef
	]);
	return /* @__PURE__ */ jsx(PageLayoutContext.Provider, {
		value: memoizedContextValue,
		children: /* @__PURE__ */ jsxs(RootWrapper, {
			style,
			padding,
			className,
			hasSidebar: !!slots.sidebar,
			children: [slots.sidebar, /* @__PURE__ */ jsxs("div", {
				ref: sidebarContentWrapperRef,
				className: classes.PageLayoutWrapper,
				"data-width": containerWidth,
				children: [
					slots.header,
					/* @__PURE__ */ jsx("div", {
						className: clsx(classes.PageLayoutContent),
						children: rest
					}),
					slots.footer
				]
			})]
		})
	});
};
Root.displayName = "Root";
var RootWrapper = /* @__PURE__ */ memo(({ style, padding, children, className, hasSidebar }) => {
	return /* @__PURE__ */ jsx("div", {
		style: {
			"--spacing": `var(--spacing-${padding})`,
			...style
		},
		className: clsx(classes.PageLayoutRoot, className),
		"data-has-sidebar": hasSidebar || void 0,
		children
	});
});
Root.displayName = "PageLayout";
var HorizontalDivider = /* @__PURE__ */ memo(({ variant = "none", className, position, style }) => {
	const { padding } = React.useContext(PageLayoutContext);
	return /* @__PURE__ */ jsx("div", {
		className: clsx(classes.HorizontalDivider, className),
		...getResponsiveAttributes("variant", variant),
		...getResponsiveAttributes("position", position),
		style: {
			"--spacing-divider": `var(--spacing-${padding})`,
			...style
		}
	});
});
HorizontalDivider.displayName = "HorizontalDivider";
var VerticalDivider = /* @__PURE__ */ memo(({ variant = "none", position, className, style, children }) => {
	return /* @__PURE__ */ jsx("div", {
		className: clsx(classes.VerticalDivider, className),
		...getResponsiveAttributes("variant", variant),
		...getResponsiveAttributes("position", position),
		style,
		children
	});
});
VerticalDivider.displayName = "VerticalDivider";
var SidebarDivider = /* @__PURE__ */ memo(function SidebarDivider({ position, divider, resizable, minPaneWidth, maxPaneWidth, currentWidth, currentWidthRef, handleRef, sidebarRef, dragStartClientXRef, dragStartWidthRef, dragMaxWidthRef, getMaxPaneWidth, getDefaultWidth, saveWidth }) {
	const { columnGap } = React.useContext(PageLayoutContext);
	return /* @__PURE__ */ jsx(VerticalDivider, {
		variant: resizable ? "line" : divider,
		position,
		className: classes.SidebarVerticalDivider,
		style: { "--spacing": `var(--spacing-${columnGap})` },
		children: resizable ? /* @__PURE__ */ jsx(DragHandle, {
			handleRef,
			"aria-valuemin": minPaneWidth,
			"aria-valuemax": maxPaneWidth,
			"aria-valuenow": currentWidth,
			onDragStart: (clientX) => {
				var _sidebarRef$current$g, _sidebarRef$current;
				dragStartClientXRef.current = clientX;
				dragStartWidthRef.current = (_sidebarRef$current$g = (_sidebarRef$current = sidebarRef.current) === null || _sidebarRef$current === void 0 ? void 0 : _sidebarRef$current.getBoundingClientRect().width) !== null && _sidebarRef$current$g !== void 0 ? _sidebarRef$current$g : currentWidthRef.current;
				dragMaxWidthRef.current = getMaxPaneWidth();
			},
			onDrag: (value, isKeyboard) => {
				const maxWidth = isKeyboard ? getMaxPaneWidth() : dragMaxWidthRef.current;
				if (isKeyboard) {
					const delta = position === "end" ? -value : value;
					const newWidth = Math.max(minPaneWidth, Math.min(maxWidth, currentWidthRef.current + delta));
					if (newWidth !== currentWidthRef.current) {
						var _sidebarRef$current2;
						currentWidthRef.current = newWidth;
						(_sidebarRef$current2 = sidebarRef.current) === null || _sidebarRef$current2 === void 0 || _sidebarRef$current2.style.setProperty("--pane-width", `${newWidth}px`);
						updateAriaValues(handleRef.current, {
							current: newWidth,
							max: maxWidth
						});
					}
				} else if (sidebarRef.current) {
					const deltaX = value - dragStartClientXRef.current;
					const directedDelta = position === "end" ? -deltaX : deltaX;
					const newWidth = dragStartWidthRef.current + directedDelta;
					const clampedWidth = Math.max(minPaneWidth, Math.min(maxWidth, newWidth));
					if (Math.round(clampedWidth) !== Math.round(currentWidthRef.current)) {
						sidebarRef.current.style.setProperty("--pane-width", `${clampedWidth}px`);
						currentWidthRef.current = clampedWidth;
						updateAriaValues(handleRef.current, {
							current: Math.round(clampedWidth),
							max: maxWidth
						});
					}
				}
			},
			onDragEnd: () => {
				saveWidth(currentWidthRef.current);
			},
			onDoubleClick: () => {
				const resetWidth = getDefaultWidth();
				if (sidebarRef.current) {
					sidebarRef.current.style.setProperty("--pane-width", `${resetWidth}px`);
					currentWidthRef.current = resetWidth;
					updateAriaValues(handleRef.current, { current: resetWidth });
				}
				saveWidth(resetWidth);
			}
		}) : null
	});
});
/**
* DragHandle - handles all pointer and keyboard interactions for resizing
* ARIA values are set in JSX for SSR accessibility,
* then updated via DOM manipulation during drag for performance
*/
var DragHandle = /* @__PURE__ */ memo(function DragHandle({ handleRef, onDragStart, onDrag, onDragEnd, onDoubleClick, "aria-valuemin": ariaValueMin, "aria-valuemax": ariaValueMax, "aria-valuenow": ariaValueNow }) {
	const stableOnDragStart = React.useRef(onDragStart);
	const stableOnDrag = React.useRef(onDrag);
	const stableOnDragEnd = React.useRef(onDragEnd);
	React.useEffect(() => {
		stableOnDragStart.current = onDragStart;
		stableOnDrag.current = onDrag;
		stableOnDragEnd.current = onDragEnd;
	});
	const { paneRef, contentWrapperRef } = React.useContext(PageLayoutContext);
	const isDraggingRef = React.useRef(false);
	const startDragging = React.useCallback(() => {
		if (isDraggingRef.current) return;
		setDraggingStyles({
			handle: handleRef.current,
			pane: paneRef.current,
			contentWrapper: contentWrapperRef.current
		});
		isDraggingRef.current = true;
	}, [
		handleRef,
		contentWrapperRef,
		paneRef
	]);
	const endDragging = React.useCallback(() => {
		if (!isDraggingRef.current) return;
		removeDraggingStyles({
			handle: handleRef.current,
			pane: paneRef.current,
			contentWrapper: contentWrapperRef.current
		});
		isDraggingRef.current = false;
	}, [
		handleRef,
		contentWrapperRef,
		paneRef
	]);
	/**
	* Pointer down starts a drag operation
	* Capture the pointer to continue receiving events outside the handle area
	*/
	const handlePointerDown = React.useCallback((event) => {
		if (event.button !== 0) return;
		event.preventDefault();
		const target = event.currentTarget;
		try {
			target.setPointerCapture(event.pointerId);
		} catch {}
		stableOnDragStart.current(event.clientX);
		startDragging();
	}, [startDragging]);
	const rafIdRef = React.useRef(null);
	const pendingClientXRef = React.useRef(null);
	/**
	* Pointer move during drag
	* Calls onDrag with absolute cursor X position
	* Uses rAF to coalesce updates to one per frame
	*/
	const handlePointerMove = React.useCallback((event) => {
		if (!isDraggingRef.current) return;
		event.preventDefault();
		pendingClientXRef.current = event.clientX;
		if (rafIdRef.current === null) rafIdRef.current = requestAnimationFrame(() => {
			rafIdRef.current = null;
			if (pendingClientXRef.current !== null) {
				stableOnDrag.current(pendingClientXRef.current, false);
				pendingClientXRef.current = null;
			}
		});
	}, []);
	/**
	* Pointer up - cleanup is handled by onLostPointerCapture event
	* which fires when pointer capture is released (including on pointerup)
	*/
	const handlePointerUp = React.useCallback((event) => {
		if (!isDraggingRef.current) return;
		event.preventDefault();
	}, []);
	/**
	* Lost pointer capture ends a drag operation
	* Cleans up dragging state and cancels any pending rAF
	* Calls onDragEnd callback
	*/
	const handleLostPointerCapture = React.useCallback(() => {
		if (!isDraggingRef.current) return;
		if (rafIdRef.current !== null) {
			cancelAnimationFrame(rafIdRef.current);
			rafIdRef.current = null;
			pendingClientXRef.current = null;
		}
		endDragging();
		stableOnDragEnd.current();
	}, [endDragging]);
	/**
	* Keyboard handling for accessibility
	* Arrow keys adjust the pane size in 3px increments
	* Prevents default scrolling behavior
	* Sets and clears dragging state via data attribute
	* Calls onDrag
	*/
	const handleKeyDown = React.useCallback((event) => {
		if (!isArrowKey(event.key)) return;
		event.preventDefault();
		const delta = isShrinkKey(event.key) ? -3 : 3;
		if (!isDraggingRef.current) startDragging();
		stableOnDrag.current(delta, true);
	}, [startDragging]);
	const handleKeyUp = React.useCallback((event) => {
		if (!isArrowKey(event.key)) return;
		event.preventDefault();
		endDragging();
		stableOnDragEnd.current();
	}, [endDragging]);
	React.useEffect(() => {
		return () => {
			if (rafIdRef.current !== null) {
				cancelAnimationFrame(rafIdRef.current);
				rafIdRef.current = null;
			}
		};
	}, []);
	return /* @__PURE__ */ jsx("div", {
		ref: handleRef,
		className: classes.DraggableHandle,
		role: "slider",
		"aria-label": "Draggable pane splitter",
		"aria-valuemin": ariaValueMin,
		"aria-valuemax": ariaValueMax,
		"aria-valuenow": ariaValueNow,
		"aria-valuetext": ariaValueNow !== void 0 ? `Pane width ${ariaValueNow} pixels` : void 0,
		tabIndex: 0,
		onPointerDown: handlePointerDown,
		onPointerMove: handlePointerMove,
		onPointerUp: handlePointerUp,
		onLostPointerCapture: handleLostPointerCapture,
		onKeyDown: handleKeyDown,
		onKeyUp: handleKeyUp,
		onDoubleClick
	});
});
var Header = ({ "aria-label": label, "aria-labelledby": labelledBy, padding = "none", divider = "none", dividerWhenNarrow = "inherit", hidden = false, children, style, className }) => {
	const dividerProp = !isResponsiveValue(divider) && dividerWhenNarrow !== "inherit" ? {
		regular: divider,
		narrow: dividerWhenNarrow
	} : divider;
	const { rowGap } = React.useContext(PageLayoutContext);
	return /* @__PURE__ */ jsxs("header", {
		"aria-label": label,
		"aria-labelledby": labelledBy,
		...getResponsiveAttributes("hidden", hidden),
		className: clsx(classes.Header, className),
		style: {
			"--spacing": `var(--spacing-${rowGap})`,
			...style
		},
		children: [/* @__PURE__ */ jsx("div", {
			className: classes.HeaderContent,
			style: { "--spacing": `var(--spacing-${padding})` },
			children
		}), /* @__PURE__ */ jsx(HorizontalDivider, {
			variant: dividerProp,
			className: classes.HeaderHorizontalDivider,
			style: { "--spacing": `var(--spacing-${rowGap})` }
		})]
	});
};
Header.displayName = "Header";
Header.displayName = "PageLayout.Header";
var Content = ({ as = "main", "aria-label": label, "aria-labelledby": labelledBy, width = "full", padding = "none", hidden = false, children, className, style }) => {
	const Component = as;
	const { contentWrapperRef } = React.useContext(PageLayoutContext);
	return /* @__PURE__ */ jsx(Component, {
		ref: contentWrapperRef,
		"aria-label": label,
		"aria-labelledby": labelledBy,
		style,
		className: clsx(classes.ContentWrapper, className),
		...getResponsiveAttributes("is-hidden", hidden),
		children: /* @__PURE__ */ jsx("div", {
			className: classes.Content,
			"data-width": width,
			style: { "--spacing": `var(--spacing-${padding})` },
			children
		})
	});
};
Content.displayName = "Content";
Content.displayName = "PageLayout.Content";
var overflowProps = {
	tabIndex: 0,
	role: "region"
};
var Pane = /* @__PURE__ */ React.forwardRef(({ "aria-label": label, "aria-labelledby": labelledBy, position: responsivePosition = "end", positionWhenNarrow = "inherit", width = "medium", minWidth = 256, currentWidth: controlledWidth, onResizeEnd, padding = "none", resizable = false, widthStorageKey = "paneWidth", divider: responsiveDivider = "none", dividerWhenNarrow = "inherit", sticky = false, offsetHeader = 0, hidden: responsiveHidden = false, children, id, className, style }, forwardRef) => {
	const positionProp = !isResponsiveValue(responsivePosition) && positionWhenNarrow !== "inherit" ? {
		regular: responsivePosition,
		narrow: positionWhenNarrow
	} : responsivePosition;
	const dividerProp = !isResponsiveValue(responsiveDivider) && dividerWhenNarrow !== "inherit" ? {
		regular: responsiveDivider,
		narrow: dividerWhenNarrow
	} : responsiveDivider;
	const position = isResponsiveValue(positionProp) ? "end" : positionProp;
	const dividerVariant = isResponsiveValue(dividerProp) ? "none" : dividerProp;
	const { rowGap, columnGap, paneRef, contentWrapperRef } = React.useContext(PageLayoutContext);
	const handleRef = React.useRef(null);
	const dragStartClientXRef = React.useRef(0);
	const dragStartWidthRef = React.useRef(0);
	const dragMaxWidthRef = React.useRef(0);
	const { currentWidth, currentWidthRef, minPaneWidth, maxPaneWidth, getMaxPaneWidth, saveWidth, getDefaultWidth } = usePaneWidth({
		width,
		minWidth,
		resizable,
		widthStorageKey,
		paneRef,
		handleRef,
		contentWrapperRef,
		onResizeEnd,
		currentWidth: controlledWidth
	});
	useRefObjectAsForwardedRef(forwardRef, paneRef);
	const hasOverflow = useOverflow(paneRef);
	const paneId = useId$1(id);
	const labelProp = {};
	if (hasOverflow) {
		if (labelledBy) labelProp["aria-labelledby"] = labelledBy;
		else if (label) labelProp["aria-label"] = label;
	}
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(classes.PaneWrapper, className),
		style: {
			"--offset-header": typeof offsetHeader === "number" ? `${offsetHeader}px` : offsetHeader,
			"--spacing-row": `var(--spacing-${rowGap})`,
			"--spacing-column": `var(--spacing-${columnGap})`,
			...style
		},
		...getResponsiveAttributes("is-hidden", responsiveHidden),
		...getResponsiveAttributes("position", positionProp),
		"data-sticky": sticky || void 0,
		children: [
			/* @__PURE__ */ jsx(HorizontalDivider, {
				variant: isResponsiveValue(dividerProp) ? dividerProp : {
					narrow: dividerVariant,
					regular: "none"
				},
				className: classes.PaneHorizontalDivider,
				style: { "--spacing": `var(--spacing-${rowGap})` },
				position: positionProp
			}),
			/* @__PURE__ */ jsx("div", {
				ref: paneRef,
				suppressHydrationWarning: resizable === true && !onResizeEnd,
				...hasOverflow ? overflowProps : {},
				...labelProp,
				...id && { id: paneId },
				className: classes.Pane,
				"data-resizable": resizable || void 0,
				style: {
					"--spacing": `var(--spacing-${padding})`,
					"--pane-min-width": isCustomWidthOptions(width) ? width.min : `${minWidth}px`,
					"--pane-max-width": isCustomWidthOptions(width) ? width.max : `calc(100vw - var(--pane-max-width-diff))`,
					"--pane-width-custom": isCustomWidthOptions(width) ? width.default : void 0,
					"--pane-width-size": `var(--pane-width-${isPaneWidth(width) ? width : "custom"})`,
					"--pane-width": `${currentWidth}px`
				},
				children
			}),
			/* @__PURE__ */ jsx(VerticalDivider, {
				variant: isResponsiveValue(dividerProp) ? {
					narrow: "none",
					regular: resizable ? "line" : dividerProp.regular || "none",
					wide: resizable ? "line" : dividerProp.wide || dividerProp.regular || "none"
				} : {
					narrow: "none",
					regular: resizable ? "line" : dividerVariant
				},
				draggable: resizable,
				position: positionProp,
				className: classes.PaneVerticalDivider,
				style: { "--spacing": `var(--spacing-${columnGap})` },
				children: resizable ? /* @__PURE__ */ jsx(DragHandle, {
					handleRef,
					"aria-valuemin": minPaneWidth,
					"aria-valuemax": maxPaneWidth,
					"aria-valuenow": currentWidth,
					onDragStart: (clientX) => {
						var _paneRef$current$getB, _paneRef$current;
						dragStartClientXRef.current = clientX;
						dragStartWidthRef.current = (_paneRef$current$getB = (_paneRef$current = paneRef.current) === null || _paneRef$current === void 0 ? void 0 : _paneRef$current.getBoundingClientRect().width) !== null && _paneRef$current$getB !== void 0 ? _paneRef$current$getB : currentWidthRef.current;
						dragMaxWidthRef.current = getMaxPaneWidth();
					},
					onDrag: (value, isKeyboard) => {
						const maxWidth = isKeyboard ? getMaxPaneWidth() : dragMaxWidthRef.current;
						if (isKeyboard) {
							const delta = value;
							const newWidth = Math.max(minPaneWidth, Math.min(maxWidth, currentWidthRef.current + delta));
							if (newWidth !== currentWidthRef.current) {
								var _paneRef$current2;
								currentWidthRef.current = newWidth;
								(_paneRef$current2 = paneRef.current) === null || _paneRef$current2 === void 0 || _paneRef$current2.style.setProperty("--pane-width", `${newWidth}px`);
								updateAriaValues(handleRef.current, {
									current: newWidth,
									max: maxWidth
								});
							}
						} else if (paneRef.current) {
							const deltaX = value - dragStartClientXRef.current;
							const directedDelta = position === "end" ? -deltaX : deltaX;
							const newWidth = dragStartWidthRef.current + directedDelta;
							const clampedWidth = Math.max(minPaneWidth, Math.min(maxWidth, newWidth));
							if (Math.round(clampedWidth) !== Math.round(currentWidthRef.current)) {
								paneRef.current.style.setProperty("--pane-width", `${clampedWidth}px`);
								currentWidthRef.current = clampedWidth;
								updateAriaValues(handleRef.current, {
									current: Math.round(clampedWidth),
									max: maxWidth
								});
							}
						}
					},
					onDragEnd: () => {
						saveWidth(currentWidthRef.current);
					},
					onDoubleClick: () => {
						const resetWidth = getDefaultWidth();
						if (paneRef.current) {
							paneRef.current.style.setProperty("--pane-width", `${resetWidth}px`);
							currentWidthRef.current = resetWidth;
							updateAriaValues(handleRef.current, { current: resetWidth });
						}
						saveWidth(resetWidth);
					}
				}) : null
			})
		]
	});
});
Pane.displayName = "PageLayout.Pane";
var Sidebar = /* @__PURE__ */ React.forwardRef(({ "aria-label": label, "aria-labelledby": labelledBy, position = "start", width = "medium", minWidth = 256, padding = "none", resizable = false, widthStorageKey, divider = "none", sticky = false, responsiveVariant = "default", hidden: responsiveHidden = false, children, id, className, style }, forwardRef) => {
	const { columnGap, sidebarRef, sidebarContentWrapperRef } = React.useContext(PageLayoutContext);
	const handleRef = React.useRef(null);
	const dragStartClientXRef = React.useRef(0);
	const dragStartWidthRef = React.useRef(0);
	const dragMaxWidthRef = React.useRef(0);
	const { currentWidth, currentWidthRef, minPaneWidth, maxPaneWidth, getMaxPaneWidth, saveWidth, getDefaultWidth } = usePaneWidth({
		width,
		minWidth,
		resizable,
		widthStorageKey,
		paneRef: sidebarRef,
		handleRef,
		contentWrapperRef: sidebarContentWrapperRef,
		constrainToViewport: true
	});
	useRefObjectAsForwardedRef(forwardRef, sidebarRef);
	const hasOverflow = useOverflow(sidebarRef);
	const sidebarId = useId$1(id);
	const labelProp = {};
	if (hasOverflow) {
		if (labelledBy) labelProp["aria-labelledby"] = labelledBy;
		else if (label) labelProp["aria-label"] = label;
	}
	return /* @__PURE__ */ jsxs("div", {
		className: clsx(classes.SidebarWrapper, className),
		style: {
			"--spacing-column": `var(--spacing-${columnGap})`,
			...style
		},
		...getResponsiveAttributes("is-hidden", responsiveHidden),
		"data-position": position,
		"data-sticky": sticky || void 0,
		"data-responsive-variant": responsiveVariant !== "default" ? responsiveVariant : void 0,
		children: [
			position === "end" && /* @__PURE__ */ jsx(SidebarDivider, {
				position,
				divider,
				resizable,
				minPaneWidth,
				maxPaneWidth,
				currentWidth,
				currentWidthRef,
				handleRef,
				sidebarRef,
				dragStartClientXRef,
				dragStartWidthRef,
				dragMaxWidthRef,
				getMaxPaneWidth,
				getDefaultWidth,
				saveWidth
			}),
			/* @__PURE__ */ jsx("div", {
				ref: sidebarRef,
				suppressHydrationWarning: resizable === true && !!widthStorageKey,
				...hasOverflow ? overflowProps : {},
				...labelProp,
				...id && { id: sidebarId },
				className: classes.Sidebar,
				"data-resizable": resizable || void 0,
				style: {
					"--spacing": `var(--spacing-${padding})`,
					"--pane-min-width": isCustomWidthOptions(width) ? width.min : `${minWidth}px`,
					"--pane-max-width": isCustomWidthOptions(width) ? width.max : `calc(100vw - var(--sidebar-max-width-diff))`,
					"--pane-width-custom": isCustomWidthOptions(width) ? width.default : void 0,
					"--pane-width-size": `var(--pane-width-${isPaneWidth(width) ? width : "custom"})`,
					"--pane-width": `${currentWidth}px`
				},
				children
			}),
			position === "start" && /* @__PURE__ */ jsx(SidebarDivider, {
				position,
				divider,
				resizable,
				minPaneWidth,
				maxPaneWidth,
				currentWidth,
				currentWidthRef,
				handleRef,
				sidebarRef,
				dragStartClientXRef,
				dragStartWidthRef,
				dragMaxWidthRef,
				getMaxPaneWidth,
				getDefaultWidth,
				saveWidth
			})
		]
	});
});
Sidebar.displayName = "PageLayout.Sidebar";
var Footer = ({ "aria-label": label, "aria-labelledby": labelledBy, padding = "none", divider = "none", dividerWhenNarrow = "inherit", hidden = false, children, className, style }) => {
	const dividerProp = !isResponsiveValue(divider) && dividerWhenNarrow !== "inherit" ? {
		regular: divider,
		narrow: dividerWhenNarrow
	} : divider;
	const { rowGap } = React.useContext(PageLayoutContext);
	return /* @__PURE__ */ jsxs("footer", {
		"aria-label": label,
		"aria-labelledby": labelledBy,
		...getResponsiveAttributes("hidden", hidden),
		className: clsx(classes.FooterWrapper, className),
		style: {
			"--spacing": `var(--spacing-${rowGap})`,
			...style
		},
		children: [/* @__PURE__ */ jsx(HorizontalDivider, {
			className: classes.FooterHorizontalDivider,
			style: { "--spacing": `var(--spacing-${rowGap})` },
			variant: dividerProp
		}), /* @__PURE__ */ jsx("div", {
			className: classes.FooterContent,
			style: { "--spacing": `var(--spacing-${padding})` },
			children
		})]
	});
};
Footer.displayName = "Footer";
Footer.displayName = "PageLayout.Footer";
var PageLayout = Object.assign(Root, {
	__SLOT__: Symbol("PageLayout"),
	Header,
	Content,
	Pane,
	Sidebar,
	Footer
});
Header.__SLOT__ = Symbol("PageLayout.Header");
Content.__SLOT__ = Symbol("PageLayout.Content");
Pane.__SLOT__ = Symbol("PageLayout.Pane");
Sidebar.__SLOT__ = Symbol("PageLayout.Sidebar");
Footer.__SLOT__ = Symbol("PageLayout.Footer");
export { PageLayout as t };
