performance.mark("js-parse-end:server-query-client.server-BgYVkGBL-DB1iqVL0.js");
import { i as setServerQueryClientGetter, t as createQueryClient } from "./server-query-client-sXh9HRx3-DFbimX-D.js";
import { AsyncLocalStorage } from "async_hooks";
performance.mark("js-parse-end:query-client.server-BgYVkGBL.js");
/**
* AsyncLocalStorage for the per-request QueryClient context.
* This ensures each request gets its own isolated QueryClient instance
* to prevent data leakage between concurrent requests.
*/
var queryClientAsyncLocalStorage = new AsyncLocalStorage();
/**
* Run a function with a per-request QueryClient context.
* This should be called at the server entry point to set up per-request isolation.
*
* @param fn - The function to run with the QueryClient context
* @returns The result of the function
*/
function runWithQueryClientContext(fn) {
	const queryClient = createQueryClient();
	return queryClientAsyncLocalStorage.run(queryClient, fn);
}
/**
* Get the current QueryClient from the async local storage context.
* This returns the per-request QueryClient instance that was set up
* by runWithQueryClientContext.
*
* @returns The current request's QueryClient
* @throws {Error} If not called within a QueryClient context
*/
function getServerQueryClient() {
	const queryClient = queryClientAsyncLocalStorage.getStore();
	if (!queryClient) throw new Error("getServerQueryClient() must be called within a QueryClient context");
	return queryClient;
}
setServerQueryClientGetter(getServerQueryClient);
export { runWithQueryClientContext };
