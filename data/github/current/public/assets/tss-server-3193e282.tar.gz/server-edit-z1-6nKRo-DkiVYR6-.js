performance.mark("js-parse-end:server-edit-z1-6nKRo-DkiVYR6-.js");
import { c as createServerFn } from "./server-esm-B9fMjEX1-BBlBlJ_n.js";
import { t as createServerRpc } from "./server-createServerRpc-CW2zk0ZX-Tv_xckCo.js";
import { t as queryValidator } from "./server-query-validator-BgVJwrud-CL5PVInh.js";
import { t as fetchDataRouterMainQuery } from "./server-fetch-data-router-main-query-B_AtjOgv-BwXhElvH.js";
performance.mark("js-parse-end:edit-z1-6nKRo.js");
var codeViewEditServerFn_createServerFn_handler = createServerRpc({
	id: "0171e77204682a42c63d8f4aabb2374f77edfad4696d22265c4d82b119aeb6cf",
	name: "codeViewEditServerFn",
	filename: "src/routes/code-view/edit.tsx"
}, (opts) => codeViewEditServerFn.__executeServer(opts));
var codeViewEditServerFn = createServerFn().inputValidator(queryValidator.base).handler(codeViewEditServerFn_createServerFn_handler, async ({ data }) => {
	return fetchDataRouterMainQuery({
		path: data.pathname,
		service: "dotcom"
	}, "codeViewEditRoute");
});
export { codeViewEditServerFn_createServerFn_handler };
