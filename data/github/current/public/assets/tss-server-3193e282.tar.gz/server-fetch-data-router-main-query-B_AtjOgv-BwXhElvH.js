import { n as fetchServiceJSON } from "./server-data-CSCUHXvp-CKCggGaq.js";
/**
* Fetches data from a data router route's main query and returns both meta and payload.
* This function is specifically for main queries, which have the {meta, payload} shape.
*
* @param options - Options for fetching data from the service, passed along to fetchServiceJSON
* @param routeId - The route ID to extract from the data router response
* @returns An object containing both meta and payload data for the specified route
* @throws Error if the response doesn't contain data for the specified route ID
*/
async function fetchDataRouterMainQuery(options, routeId) {
	const data = await fetchServiceJSON({
		metricTag: `dr_${routeId}`,
		...options
	});
	if (data.payload[routeId]) return {
		meta: data.meta,
		payload: data.payload[routeId]
	};
	throw Error("Unexpected data router response");
}
export { fetchDataRouterMainQuery as t };
