import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
async function fetchKeyboardShortcuts(contexts) {
	if (contexts === void 0) return null;
	const resp = await verifiedFetchJSON(`/site/keyboard_shortcuts?${new URLSearchParams({ contexts })}`, { method: "GET" });
	return resp.ok ? resp.json() : null;
}
function getQueryOptions(contexts) {
	const normalizedContexts = contexts?.replace(/-/g, "_");
	return {
		queryKey: ["keyboard-shortcuts", normalizedContexts],
		queryFn: () => fetchKeyboardShortcuts(normalizedContexts),
		staleTime: Infinity
	};
}
var strings_default = {
	keyboardShortcuts: "Keyboard shortcuts",
	siteWideShortcuts: "Site-wide shortcuts",
	loading: "Loading",
	errorTitle: "Something went wrong",
	errorMessage: "Keyboard shortcuts could not be loaded due to an unknown error. If the problem persists, please contact support."
};
export { strings_default as n, getQueryOptions as t };
