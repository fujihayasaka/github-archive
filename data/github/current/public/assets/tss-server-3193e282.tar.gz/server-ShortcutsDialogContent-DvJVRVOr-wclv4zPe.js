performance.mark("js-parse-end:server-ShortcutsDialogContent-DvJVRVOr-wclv4zPe.js");
import { i as ButtonComponent, s as KeybindingHint } from "./server-Button-y2SRwt0u-9Sz2Nx99.js";
import { f as useSuspenseQuery } from "./server-react-query-3hRiSG3i-CelGZRma.js";
import { t as hotkey_exports } from "./server-hotkey-CjmZAe2y-CaimUUmF.js";
import { r as getAllRegisteredCommands } from "./server-commands-registry-PhKKp09d-CINoICbD.js";
import { n as strings_default, t as getQueryOptions } from "./server-strings-BVSa86KS-9Xe7e3BY.js";
import { Fragment, useId, useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
performance.mark("js-parse-end:ShortcutsDialogContent-DvJVRVOr.js");
var ShortcutsGroupList_module_default = {
	KeybindingContainer: "ShortcutsGroupList-module_bfMzna_KeybindingContainer",
	ShortcutItem: "ShortcutsGroupList-module_bfMzna_ShortcutItem",
	ShortcutsGroupContainer: "ShortcutsGroupList-module_bfMzna_ShortcutsGroupContainer",
	ShortcutsGroupHeader: "ShortcutsGroupList-module_bfMzna_ShortcutsGroupHeader",
	ShortcutsList: "ShortcutsGroupList-module_bfMzna_ShortcutsList"
};
function ShortcutsGroupList(t0) {
	const $ = c(4);
	const { group: t1 } = t0;
	const { service: t2, commands } = t1;
	const { name: serviceName } = t2;
	const labelId = useId();
	let t3;
	if ($[0] !== commands || $[1] !== labelId || $[2] !== serviceName) {
		t3 = jsxs("div", {
			className: ShortcutsGroupList_module_default.ShortcutsGroupContainer,
			children: [jsx("h2", {
				id: labelId,
				className: ShortcutsGroupList_module_default.ShortcutsGroupHeader,
				children: serviceName
			}), jsx("ul", {
				role: "list",
				"aria-labelledby": labelId,
				className: ShortcutsGroupList_module_default.ShortcutsList,
				children: commands.map(_temp$1)
			})]
		});
		$[0] = commands;
		$[1] = labelId;
		$[2] = serviceName;
		$[3] = t3;
	} else t3 = $[3];
	return t3;
}
ShortcutsGroupList.displayName = "ShortcutsGroupList";
function _temp$1(command) {
	const { id, name, keybinding } = command;
	const hold = "hold" in command && command.hold;
	return jsxs("li", {
		className: ShortcutsGroupList_module_default.ShortcutItem,
		children: [jsx("div", { children: name }), jsx("div", {
			className: ShortcutsGroupList_module_default.KeybindingContainer,
			children: (Array.isArray(keybinding) ? keybinding : [keybinding]).map((keys, i) => jsxs(Fragment, { children: [
				i > 0 && " or ",
				hold && (i > 0 ? "hold " : "Hold "),
				jsx(KeybindingHint, { keys })
			] }, keys))
		})]
	}, id);
}
var GLOBAL_NAVIGATION_SERVICE_ID = "global-navigation";
/** @file utils and types for normalizing commands from the API and UI to a consistent format */
function normalizeAPICommand(command) {
	const { keybinding } = command;
	if (Array.isArray(keybinding)) return {
		...command,
		keybinding: keybinding.map((kb) => (0, hotkey_exports.normalizeSequence)(kb))
	};
	return {
		...command,
		keybinding: (0, hotkey_exports.normalizeSequence)(keybinding ?? "")
	};
}
function normalizeAPIGroup(group) {
	return {
		service: group.service,
		commands: group.commands.map(normalizeAPICommand)
	};
}
function combineMatchingGroups(groups) {
	const groupMap = /* @__PURE__ */ new Map();
	for (const group of groups) {
		const existing = groupMap.get(group.service.id);
		if (existing) existing.commands = existing.commands.concat(group.commands);
		else groupMap.set(group.service.id, { ...group });
	}
	return Array.from(groupMap.values());
}
function normalizeShortcuts(registeredUiCommandGroups, apiShortcuts) {
	const globalUiCommandsGroup = registeredUiCommandGroups.find((group) => group.service.id === GLOBAL_NAVIGATION_SERVICE_ID);
	const nonGlobalUiCommandsGroups = registeredUiCommandGroups.filter((group) => group.service.id !== "global-navigation" && group.service.id !== "github");
	if (!apiShortcuts) return {
		siteWideShortcuts: {
			service: {
				id: "global",
				name: strings_default.siteWideShortcuts
			},
			commands: globalUiCommandsGroup?.commands ?? []
		},
		shortcutGroups: nonGlobalUiCommandsGroups
	};
	const { global: globalApiGroup, ...nonGlobalApiGroups } = apiShortcuts.commands;
	return {
		siteWideShortcuts: {
			service: {
				id: "global",
				name: strings_default.siteWideShortcuts
			},
			commands: [...globalApiGroup?.commands.map(normalizeAPICommand) ?? [], ...globalUiCommandsGroup?.commands ?? []]
		},
		shortcutGroups: combineMatchingGroups([...Object.values(nonGlobalApiGroups).map(normalizeAPIGroup), ...nonGlobalUiCommandsGroups])
	};
}
function transformShortcuts(apiShortcuts) {
	return normalizeShortcuts(getAllRegisteredCommands(), apiShortcuts);
}
function useKeyboardShortcutsQuery(contexts) {
	const $ = c(4);
	let t0;
	if ($[0] !== contexts) {
		t0 = getQueryOptions(contexts);
		$[0] = contexts;
		$[1] = t0;
	} else t0 = $[1];
	let t1;
	if ($[2] !== t0) {
		t1 = {
			...t0,
			select: transformShortcuts
		};
		$[2] = t0;
		$[3] = t1;
	} else t1 = $[3];
	return useSuspenseQuery(t1);
}
var ShortcutsDialogContent_module_default = {
	Column: "ShortcutsDialogContent-module_3SlWWa_Column",
	ColumnsContainer: "ShortcutsDialogContent-module_3SlWWa_ColumnsContainer",
	FullWidthButton: "ShortcutsDialogContent-module_3SlWWa_FullWidthButton"
};
var Columns = ({ children }) => /* @__PURE__ */ jsx("div", {
	className: ShortcutsDialogContent_module_default.ColumnsContainer,
	children
});
Columns.displayName = "Columns";
var Column = ({ children }) => /* @__PURE__ */ jsx("div", {
	className: ShortcutsDialogContent_module_default.Column,
	children
});
/** Suspends while fetching shortcuts. */
Column.displayName = "Column";
function ShortcutsDialogContent(t0) {
	const $ = c(4);
	const { contexts, docsUrl } = t0;
	const { data } = useKeyboardShortcutsQuery(contexts);
	let t1;
	if ($[0] !== data.shortcutGroups || $[1] !== data.siteWideShortcuts || $[2] !== docsUrl) {
		t1 = jsxs(Columns, { children: [jsx(Column, { children: data.shortcutGroups.map(_temp) }), jsxs(Column, { children: [jsx(ShortcutsGroupList, { group: data.siteWideShortcuts }, data.siteWideShortcuts.service.id), jsx(ButtonComponent, {
			as: "a",
			href: docsUrl,
			className: ShortcutsDialogContent_module_default.FullWidthButton,
			children: "View all keyboard shortcuts"
		})] })] });
		$[0] = data.shortcutGroups;
		$[1] = data.siteWideShortcuts;
		$[2] = docsUrl;
		$[3] = t1;
	} else t1 = $[3];
	return t1;
}
ShortcutsDialogContent.displayName = "ShortcutsDialogContent";
function _temp(group) {
	return jsx(ShortcutsGroupList, { group }, group.service.id);
}
export { ShortcutsDialogContent as default };
