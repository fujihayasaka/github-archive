import { bn as Link, cn as InfoIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { o as verifiedFetch } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { t as Banner } from "./server-Banner-n3VBKO9v-zSs-oamu.js";
import { useEffect, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
var TransactionalMessageBanner_module_default = { squareBanner: "TransactionalMessageBanner-module_Bq9Lza_squareBanner" };
function getVisibleAnalyticsEvent(analytics) {
	return JSON.stringify({
		category: analytics.category,
		action: "visible",
		label: `group:${analytics.group};location:${analytics.location}`
	});
}
function getDismissAnalyticsEvent(analytics) {
	return JSON.stringify({
		category: analytics.category,
		action: "dismiss",
		label: `group:${analytics.group};location:${analytics.location}`
	});
}
function getSegmentKey(segment, index) {
	return `${segment.type}-${index}-${segment.content.slice(0, 20)}`;
}
function TransactionalMessageBanner({ banner, rounded }) {
	const [hidden, setHidden] = useState(false);
	const bannerRef = useRef(null);
	const isRounded = rounded ?? banner.analytics.location !== "global";
	useEffect(() => {
		if (bannerRef.current) bannerRef.current.setAttribute("data-analytics-visible", getVisibleAnalyticsEvent(banner.analytics));
	}, [banner.analytics]);
	const handleDismiss = async () => {
		try {
			await verifiedFetch(banner.dismissPath, { method: "POST" });
		} catch {} finally {
			setHidden(true);
		}
	};
	if (hidden) return null;
	return /* @__PURE__ */ jsx("div", {
		ref: bannerRef,
		"data-hpc": true,
		"data-testid": "transactional-message-banner",
		"data-analytics-event": getDismissAnalyticsEvent(banner.analytics),
		children: /* @__PURE__ */ jsx(Banner, {
			title: "Important update",
			hideTitle: true,
			icon: /* @__PURE__ */ jsx(InfoIcon, {}),
			className: isRounded ? void 0 : TransactionalMessageBanner_module_default.squareBanner,
			description: /* @__PURE__ */ jsx("span", {
				className: "text-normal",
				children: banner.segments.map((segment, index) => segment.type === "link" ? /* @__PURE__ */ jsx(Link, {
					inline: true,
					href: segment.href,
					children: segment.content
				}, getSegmentKey(segment, index)) : /* @__PURE__ */ jsx("span", { children: segment.content }, getSegmentKey(segment, index)))
			}),
			onDismiss: handleDismiss
		})
	});
}
TransactionalMessageBanner.displayName = "TransactionalMessageBanner";
export { TransactionalMessageBanner as t };
