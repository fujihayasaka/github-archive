import { useEffect, useState } from "react";
import { c } from "react/compiler-runtime";
function useFileTreeTooltip(t0) {
	const $ = c(4);
	const { focusRowRef, mouseRowRef } = t0;
	const [showTooltip, setShowTooltip] = useState(false);
	let t1;
	let t2;
	if ($[0] !== focusRowRef || $[1] !== mouseRowRef) {
		t1 = () => {
			const focusEl = focusRowRef.current;
			const mouseEl = mouseRowRef.current;
			if (!focusEl || !mouseEl) return;
			const showIfOverflowing = () => {
				const contentRef = focusEl.querySelector(".PRIVATE_TreeView-item-content-text");
				if (contentRef?.scrollWidth !== contentRef?.offsetWidth) setShowTooltip(true);
			};
			const handleFocus = () => showIfOverflowing();
			const handleBlur = () => setShowTooltip(false);
			const handleMouseEnter = () => showIfOverflowing();
			const handleMouseLeave = () => setShowTooltip(false);
			focusEl.addEventListener("focus", handleFocus);
			focusEl.addEventListener("blur", handleBlur);
			mouseEl.addEventListener("mouseenter", handleMouseEnter);
			mouseEl.addEventListener("mouseleave", handleMouseLeave);
			return () => {
				focusEl.removeEventListener("focus", handleFocus);
				focusEl.removeEventListener("blur", handleBlur);
				mouseEl.removeEventListener("mouseenter", handleMouseEnter);
				mouseEl.removeEventListener("mouseleave", handleMouseLeave);
			};
		};
		t2 = [focusRowRef, mouseRowRef];
		$[0] = focusRowRef;
		$[1] = mouseRowRef;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	return showTooltip;
}
export { useFileTreeTooltip as t };
