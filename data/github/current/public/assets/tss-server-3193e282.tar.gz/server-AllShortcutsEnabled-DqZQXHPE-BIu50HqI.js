import { a as isFeatureEnabled } from "./server-feature-flags-Dyy7Vxty-ChNY28eY.js";
import { s as verifiedFetchJSON } from "./server-verified-fetch-D55zggoK-BK5kPZ4P.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { Ft as repositoryStatsPath, It as repositoryTreePath, U as getRelativeHref } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { t as useAnalytics } from "./server-use-analytics-DhKzkEBW-huBE92Xp.js";
import { t as useRuntimeEnvironment } from "./server-use-runtime-environment-DCpC2o5s-CB7TemO9.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import React, { useCallback, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var CurrentUserContext = React.createContext(void 0);
CurrentUserContext.displayName = "CurrentUserContext";
function CurrentUserProvider({ user, children }) {
	return /* @__PURE__ */ jsxs(CurrentUserContext, {
		value: user,
		children: [
			" ",
			children,
			" "
		]
	});
}
CurrentUserProvider.displayName = "CurrentUserProvider";
function useCurrentUser() {
	return React.use(CurrentUserContext);
}
/**
* Use this hook to send user analytics events to the data warehouse.
* Please note that this hook uses `sendEvent` helper,
* which enriches event context with additional information about the user, repository, and current page.
* See: https://thehub.github.com/epd/engineering/products-and-services/internal/hydro/installation/browser-events/
*
* You can find a list of all included context properties in `app/helpers/octolytics_helper.rb`.
* The majority of the events don't require additional context properties as they are sent by default,
* so check the existing properties in `octolytics_helper` before adding new ones.
*
* "repository.click" represents an umbrella event for all repository clicks.
* "target" is the name of the UI element associated with the event.
*
* @example
* ```tsx
* function Component() {
*   const { sendRepoClickEvent } = useReposAnalytics()
*   return <Button onClick={() => sendRepoClickEvent('FIND_FILE_BUTTON')}>Find file</Button>
* }
* ```
*
*/
function useReposAnalytics() {
	const $ = c(17);
	const { sendAnalyticsEvent } = useAnalytics();
	const sendReposUIEvent = useSendReposUIEvent();
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = isFeatureEnabled("code_nav_ui_events");
		$[0] = t0;
	} else t0 = $[0];
	const shouldUseUIEventTable = t0;
	let t1;
	if ($[1] !== sendAnalyticsEvent || $[2] !== sendReposUIEvent) {
		t1 = (target, t2) => {
			const payload = t2 === void 0 ? {} : t2;
			sendAnalyticsEvent("repository.click", target, payload);
			if (shouldUseUIEventTable) sendReposUIEvent(target, "click", payload);
		};
		$[1] = sendAnalyticsEvent;
		$[2] = sendReposUIEvent;
		$[3] = t1;
	} else t1 = $[3];
	const t2 = t1;
	let t3;
	if ($[4] !== sendAnalyticsEvent || $[5] !== sendReposUIEvent) {
		t3 = (target_0, t4) => {
			const payload_0 = t4 === void 0 ? {} : t4;
			sendAnalyticsEvent("repository.keydown", target_0, payload_0);
			if (shouldUseUIEventTable) sendReposUIEvent(target_0, "keydown", payload_0);
		};
		$[4] = sendAnalyticsEvent;
		$[5] = sendReposUIEvent;
		$[6] = t3;
	} else t3 = $[6];
	const t4 = t3;
	let t5;
	if ($[7] !== sendAnalyticsEvent || $[8] !== sendReposUIEvent) {
		t5 = (type, t6) => {
			const payload_1 = t6 === void 0 ? {} : t6;
			sendAnalyticsEvent(type, "", payload_1);
			if (shouldUseUIEventTable) sendReposUIEvent(type, "stats", payload_1);
		};
		$[7] = sendAnalyticsEvent;
		$[8] = sendReposUIEvent;
		$[9] = t5;
	} else t5 = $[9];
	const t6 = t5;
	let t7;
	if ($[10] !== sendAnalyticsEvent) {
		t7 = (target_1, t8) => {
			sendAnalyticsEvent("marketplace.action.click", target_1, t8 === void 0 ? {} : t8);
		};
		$[10] = sendAnalyticsEvent;
		$[11] = t7;
	} else t7 = $[11];
	const t8 = t7;
	let t9;
	if ($[12] !== t2 || $[13] !== t4 || $[14] !== t6 || $[15] !== t8) {
		t9 = {
			sendRepoClickEvent: t2,
			sendRepoKeyDownEvent: t4,
			sendStats: t6,
			sendMarketplaceActionEvent: t8
		};
		$[12] = t2;
		$[13] = t4;
		$[14] = t6;
		$[15] = t8;
		$[16] = t9;
	} else t9 = $[16];
	return t9;
}
function useSendReposUIEvent() {
	const $ = c(6);
	const repoMetadata = useRepositoryEventMetadata();
	const repo = useCurrentRepository();
	let t0;
	if ($[0] !== repo.name || $[1] !== repo.ownerLogin) {
		t0 = getRelativeHref(repositoryStatsPath, {
			owner: repo.ownerLogin,
			repo: repo.name
		});
		$[0] = repo.name;
		$[1] = repo.ownerLogin;
		$[2] = t0;
	} else t0 = $[2];
	const statsPath = t0;
	let t1;
	if ($[3] !== repoMetadata || $[4] !== statsPath) {
		t1 = (target, interaction, context) => {
			verifiedFetchJSON(statsPath, {
				method: "POST",
				body: {
					target,
					interaction,
					context,
					...repoMetadata,
					...getBrowserEventMetadata()
				}
			});
		};
		$[3] = repoMetadata;
		$[4] = statsPath;
		$[5] = t1;
	} else t1 = $[5];
	return t1;
}
function getBrowserEventMetadata() {
	return {
		url: window.location.href,
		user_agent: window.navigator.userAgent,
		browser_width: document.documentElement.clientWidth,
		browser_languages: window.navigator.languages.join(",")
	};
}
function useRepositoryEventMetadata() {
	const $ = c(7);
	const repo = useCurrentRepository();
	const actor = useCurrentUser();
	const t0 = `${repo.ownerLogin}/${repo.name}`;
	const t1 = actor?.id;
	const t2 = actor?.login;
	let t3;
	if ($[0] !== repo.id || $[1] !== repo.isFork || $[2] !== repo.public || $[3] !== t0 || $[4] !== t1 || $[5] !== t2) {
		t3 = {
			react_app: "code-view",
			repository_id: repo.id,
			repository_nwo: t0,
			repository_public: repo.public,
			repository_is_fork: repo.isFork,
			actor_id: t1,
			actor_login: t2
		};
		$[0] = repo.id;
		$[1] = repo.isFork;
		$[2] = repo.public;
		$[3] = t0;
		$[4] = t1;
		$[5] = t2;
		$[6] = t3;
	} else t3 = $[6];
	return t3;
}
var ActionContext = React.createContext("tree");
ActionContext.displayName = "ActionContext";
function ActionProvider({ children, action }) {
	return /* @__PURE__ */ jsx(ActionContext, {
		value: action,
		children
	});
}
ActionProvider.displayName = "ActionProvider";
function useAction() {
	return React.use(ActionContext);
}
function getTail({ params, hash }, isSSR) {
	const urlParams = params ? `?${params}` : "";
	let hashStr = "";
	if (!isSSR) if (hash === void 0) hashStr = window.location.hash;
	else hashStr = hash ? `#${hash}` : "";
	return urlParams + hashStr;
}
function useUrlCreator() {
	const $ = c(27);
	const { name: repoName, ownerLogin } = useCurrentRepository();
	const currentPath = usePath();
	const action = useAction();
	const refInfo = useRefInfo();
	const { isServer: isSSR } = useRuntimeEnvironment();
	let t0;
	if ($[0] !== ownerLogin || $[1] !== refInfo.name || $[2] !== repoName) {
		t0 = (item) => repositoryTreePath({
			repo: {
				name: repoName,
				ownerLogin
			},
			commitish: refInfo.name,
			action: item.contentType === "directory" ? "tree" : "blob",
			path: item.path
		});
		$[0] = ownerLogin;
		$[1] = refInfo.name;
		$[2] = repoName;
		$[3] = t0;
	} else t0 = $[3];
	const getItemUrl = t0;
	let t1;
	if ($[4] !== action || $[5] !== currentPath || $[6] !== isSSR || $[7] !== ownerLogin || $[8] !== refInfo.name || $[9] !== repoName) {
		t1 = (t2) => {
			const options = t2 === void 0 ? {} : t2;
			const url = repositoryTreePath({
				repo: {
					name: repoName,
					ownerLogin
				},
				commitish: options.commitish || refInfo.name,
				action: options.action || action,
				path: options.path || currentPath
			}) + getTail(options, isSSR);
			if (options.absolute) return new URL(url, window.location.origin).href;
			return url;
		};
		$[4] = action;
		$[5] = currentPath;
		$[6] = isSSR;
		$[7] = ownerLogin;
		$[8] = refInfo.name;
		$[9] = repoName;
		$[10] = t1;
	} else t1 = $[10];
	const getUrl = t1;
	let t2;
	if ($[11] !== action || $[12] !== currentPath || $[13] !== isSSR || $[14] !== ownerLogin || $[15] !== refInfo.currentOid || $[16] !== repoName) {
		t2 = (t3) => {
			const options_0 = t3 === void 0 ? {} : t3;
			const url_0 = repositoryTreePath({
				repo: {
					name: repoName,
					ownerLogin
				},
				commitish: refInfo.currentOid,
				action: options_0.action || action,
				path: options_0.path || currentPath
			}) + getTail(options_0, isSSR);
			if (options_0.absolute) return new URL(url_0, window.location.origin).href;
			return url_0;
		};
		$[11] = action;
		$[12] = currentPath;
		$[13] = isSSR;
		$[14] = ownerLogin;
		$[15] = refInfo.currentOid;
		$[16] = repoName;
		$[17] = t2;
	} else t2 = $[17];
	const createPermalink = t2;
	let t3;
	if ($[18] !== isSSR || $[19] !== refInfo.currentOid || $[20] !== refInfo.name) {
		t3 = () => {
			if (isSSR) return false;
			return refInfo.name === refInfo.currentOid && window.location.pathname.includes(refInfo.currentOid);
		};
		$[18] = isSSR;
		$[19] = refInfo.currentOid;
		$[20] = refInfo.name;
		$[21] = t3;
	} else t3 = $[21];
	const isCurrentPagePermalink = t3;
	let t4;
	if ($[22] !== createPermalink || $[23] !== getItemUrl || $[24] !== getUrl || $[25] !== isCurrentPagePermalink) {
		t4 = {
			getItemUrl,
			getUrl,
			createPermalink,
			isCurrentPagePermalink
		};
		$[22] = createPermalink;
		$[23] = getItemUrl;
		$[24] = getUrl;
		$[25] = isCurrentPagePermalink;
		$[26] = t4;
	} else t4 = $[26];
	return t4;
}
var AllShortcutsEnabledContext = React.createContext(true);
AllShortcutsEnabledContext.displayName = "AllShortcutsEnabledContext";
function AllShortcutsEnabledProvider({ allShortcutsEnabled, children }) {
	return /* @__PURE__ */ jsxs(AllShortcutsEnabledContext, {
		value: allShortcutsEnabled,
		children: [
			" ",
			children,
			" "
		]
	});
}
AllShortcutsEnabledProvider.displayName = "AllShortcutsEnabledProvider";
function useAllShortcutsEnabled() {
	return React.use(AllShortcutsEnabledContext);
}
function AllShortcutsEnabled(t0) {
	const $ = c(3);
	const { children } = t0;
	const allShortcutsEnabled = useAllShortcutsEnabled();
	let t1;
	if ($[0] !== allShortcutsEnabled || $[1] !== children) {
		t1 = allShortcutsEnabled ? jsx(Fragment$1, { children }) : null;
		$[0] = allShortcutsEnabled;
		$[1] = children;
		$[2] = t1;
	} else t1 = $[2];
	return t1;
}
AllShortcutsEnabled.displayName = "AllShortcutsEnabled";
export { useAction as a, useUrlCreator as c, CurrentUserProvider as i, AllShortcutsEnabled as n, useCurrentUser as o, AllShortcutsEnabledProvider as r, useReposAnalytics as s, ActionProvider as t };
