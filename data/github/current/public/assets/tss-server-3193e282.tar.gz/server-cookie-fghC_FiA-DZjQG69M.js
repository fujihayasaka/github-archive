import { n as getCookie, r as setCookie, t as deleteCookie } from "./server-cookies-DndQO37X-vNR87gG9.js";
import { n as COOKIE_NAME } from "./server-constants-xMVBIU7B-COI4NwYP.js";
var DISMISSAL_DURATION_OPTIONS = [
	{
		id: "one-day",
		text: "One day",
		days: 1
	},
	{
		id: "one-week",
		text: "One week",
		days: 7
	},
	{
		id: "one-month",
		text: "One month",
		days: 30
	},
	{
		id: "one-year",
		text: "One year",
		days: 365
	}
];
var getDefaultDurationIndex = () => {
	return DISMISSAL_DURATION_OPTIONS.findIndex((option) => option.days === 30);
};
function storeDismissedOrgIds(ssoOrgs, durationDays) {
	const existingOrgIds = getDismissedOrgIdsFromCookie();
	const allOrgIds = [...new Set([...existingOrgIds, ...ssoOrgs.map((org) => org.id)])].sort();
	deleteCookie(COOKIE_NAME);
	const expirationTime = (durationDays ?? 30) * 24 * 60 * 60 * 1e3;
	const expiration = new Date(Date.now() + expirationTime).toUTCString();
	setCookie(COOKIE_NAME, JSON.stringify(allOrgIds), expiration);
}
/** Gets all the orgs from the last time the banner was dismissed via the stored cookie */
function getDismissedOrgIdsFromCookie() {
	const cookie = getCookie(COOKIE_NAME);
	if (cookie?.value) try {
		const orgIds = JSON.parse(cookie.value);
		return Array.isArray(orgIds) ? orgIds : [];
	} catch (_error) {
		deleteCookie(COOKIE_NAME);
		return [];
	}
	return [];
}
/**
* Check if the SSO banner info stored as a cookie matches what is currently tried to be displayed.
* If it does, the banner will be suppressed.
*/
function shouldCookieSuppressBanner(ssoOrgs) {
	const dismissedOrgIds = getDismissedOrgIdsFromCookie();
	return ssoOrgs.length === dismissedOrgIds.length && ssoOrgs.every((org) => dismissedOrgIds.includes(org.id));
}
export { storeDismissedOrgIds as i, getDefaultDurationIndex as n, shouldCookieSuppressBanner as r, DISMISSAL_DURATION_OPTIONS as t };
