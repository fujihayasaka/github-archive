import { t as Dialog } from "./server-Dialog-CGAAYoqg-Cahr2rwR.js";
import { i as Header_default } from "./server-dist-CYIohkkh-Bv3n8Eqy.js";
import { useCallback, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { c } from "react/compiler-runtime";
var RelationshipsAlertDialog_module_default = {
	body: "RelationshipsAlertDialog-module_TtfCQG_body",
	footer: "RelationshipsAlertDialog-module_TtfCQG_footer",
	header: "RelationshipsAlertDialog-module_TtfCQG_header",
	headerItem: "RelationshipsAlertDialog-module_TtfCQG_headerItem"
};
var SingleConfirmBody = ({ children }) => /* @__PURE__ */ jsx("div", {
	className: RelationshipsAlertDialog_module_default.body,
	children
});
SingleConfirmBody.displayName = "SingleConfirmBody";
var SingleConfirmFooter = ({ footerButtons }) => /* @__PURE__ */ jsx("div", {
	className: RelationshipsAlertDialog_module_default.footer,
	children: /* @__PURE__ */ jsx(Dialog.Buttons, { buttons: footerButtons ?? [] })
});
SingleConfirmFooter.displayName = "SingleConfirmFooter";
var SingleConfirmHeader = ({ title, onClose, dialogLabelId }) => /* @__PURE__ */ jsxs(Header_default, {
	className: RelationshipsAlertDialog_module_default.header,
	children: [/* @__PURE__ */ jsx(Header_default.Item, {
		className: RelationshipsAlertDialog_module_default.headerItem,
		id: dialogLabelId,
		children: title
	}), /* @__PURE__ */ jsx(Dialog.CloseButton, { onClose: useCallback(() => onClose("close-button"), [onClose]) })]
});
SingleConfirmHeader.displayName = "SingleConfirmHeader";
function RelationshipsAlertDialog({ title, children, onClose, width = "medium", ...rest }) {
	return /* @__PURE__ */ jsx(Dialog, {
		title,
		role: "alertdialog",
		width,
		onClose,
		footerButtons: [{
			buttonType: "primary",
			content: "OK",
			onClick: useCallback(() => onClose("confirm"), [onClose])
		}],
		renderBody: SingleConfirmBody,
		renderFooter: SingleConfirmFooter,
		renderHeader: SingleConfirmHeader,
		...rest,
		children
	});
}
RelationshipsAlertDialog.displayName = "RelationshipsAlertDialog";
var MAX_HEIGHT = 7;
function useAlert() {
	const $ = c(10);
	const [alert, setAlert] = useState(null);
	let t0;
	if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = () => setAlert(null);
		$[0] = t0;
	} else t0 = $[0];
	const resetAlert = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = (limit) => setAlert({
			title: "Sub-issue limit reached",
			body: `Parents have a limit of ${limit} sub-issues. To add more, an existing one must be removed.`
		});
		$[1] = t1;
	} else t1 = $[1];
	const showBreadthLimitAlert = t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = () => setAlert({
			title: "Sub-issue limit reached",
			body: `You can’t add more than ${MAX_HEIGHT} layers of sub-issues. To add a sub-issue, remove a parent issue at any level.`
		});
		$[2] = t2;
	} else t2 = $[2];
	const showDepthLimitAlert = t2;
	let t3;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => setAlert({
			title: "Sub-issue circular dependency",
			body: "A parent may not be a sub-issue of itself. To add it as a sub-issue, remove it as a parent in the tree."
		});
		$[3] = t3;
	} else t3 = $[3];
	const showCircularDependencyAlert = t3;
	let t4;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = () => {
			setAlert({
				title: "Duplicate sub-issue",
				body: "A parent may not have duplicate sub-issues."
			});
		};
		$[4] = t4;
	} else t4 = $[4];
	const showDuplicateSubIssueAlert = t4;
	let t5;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = () => {
			setAlert({
				title: "Access denied",
				body: "You do not have permission to take this action for the selected issue. A repository role of 'triage' or higher is required."
			});
		};
		$[5] = t5;
	} else t5 = $[5];
	const showPermissionsAlert = t5;
	let t6;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = () => {
			setAlert({
				title: "Invalid owner",
				body: "A sub-issue must belong to the same organization or user as the parent."
			});
		};
		$[6] = t6;
	} else t6 = $[6];
	const showOwnerAlert = t6;
	let t7;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = (error) => {
			const limitMatch = error.message.match(/Parent cannot have more than (?<limit>\d+) sub-issues/);
			const limit_0 = parseInt(limitMatch?.groups?.limit || "NaN", 10);
			if (!isNaN(limit_0)) {
				showBreadthLimitAlert(limit_0);
				return true;
			}
			if (error.message.includes(`You can’t add more than ${MAX_HEIGHT} layers of sub-issues`)) {
				showDepthLimitAlert();
				return true;
			}
			if (error.message.includes("does not have the correct permissions to execute `AddSubIssue`")) {
				showPermissionsAlert();
				return true;
			}
			if (error.message.includes("Sub issue may not create a circular dependency") || error.message.includes("Sub issue cannot be the same as the parent issue")) {
				showCircularDependencyAlert();
				return true;
			}
			if (error.message.includes("Issue may not contain duplicate sub-issues")) {
				showDuplicateSubIssueAlert();
				return true;
			}
			if (error.message.includes("Sub issue must have the same owner as the parent")) {
				showOwnerAlert();
				return true;
			}
			return false;
		};
		$[7] = t7;
	} else t7 = $[7];
	const showServerAlert = t7;
	let t8;
	if ($[8] !== alert) {
		t8 = {
			alert,
			setAlert,
			resetAlert,
			showBreadthLimitAlert,
			showServerAlert
		};
		$[8] = alert;
		$[9] = t8;
	} else t8 = $[9];
	return t8;
}
export { useAlert as n, RelationshipsAlertDialog as t };
