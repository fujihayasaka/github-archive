import { bn as Link, o as AlertIcon } from "./server-ActionList-Dn-iRaP5-D_-F1a3c.js";
import { t as Octicon } from "./server-Octicon-5tHBLztc-CJUDsGIU.js";
import { i as LinkButton } from "./server-SelectPanel-DDa4f3f9-CoxrUm9C.js";
import { t as BranchName_default } from "./server-BranchName-HKnig0CO-C3hpegKL.js";
import { n as useCurrentRepository } from "./server-CurrentRepository-CdNqxCG--B16cplCr.js";
import { Ot as repoOverviewUrl, Tt as repoDefaultBrachUrl } from "./server-path-B2ovMpzQ-C8Um3nNC.js";
import { n as usePath } from "./server-PathContext-Ds-TOKw_-CeBHD5kA.js";
import { n as useRefInfo } from "./server-RefInfoContext-Dda4E-l4-DLGV72XD.js";
import { t as LinkButton_module_default } from "./server-LinkButton.module-B69Km8g5-o2_Z9fYl.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { clsx } from "clsx";
import { c } from "react/compiler-runtime";
var CodeViewError_module_default = { Box: "CodeViewError-module_otNEQq_Box" };
function CodeViewError(error) {
	const $ = c(5);
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	let t0;
	if ($[0] !== error || $[1] !== path || $[2] !== refInfo || $[3] !== repo) {
		t0 = jsx("div", {
			className: CodeViewError_module_default.Box,
			children: jsxs("div", {
				className: "d-flex flex-column flex-justify-center flex-items-center border rounded-2 tmp-px-6 tmp-py-7",
				children: [
					jsx(Octicon, {
						icon: AlertIcon,
						className: "fgColor-muted mb-2",
						size: 20
					}),
					jsx(ErrorText, { ...error }),
					(path || !refInfo.currentOid) && jsx(LinkButton, {
						type: "button",
						className: clsx("tmp-mt-4", LinkButton_module_default.linkButton),
						variant: "primary",
						"aria-label": refInfo.currentOid ? "go to Overview" : "go to default branch",
						href: refInfo.currentOid ? repoOverviewUrl(repo) : repoDefaultBrachUrl(repo),
						children: refInfo.currentOid ? "Return to the repository overview" : "Go to default branch"
					})
				]
			})
		});
		$[0] = error;
		$[1] = path;
		$[2] = refInfo;
		$[3] = repo;
		$[4] = t0;
	} else t0 = $[4];
	return t0;
}
CodeViewError.displayName = "CodeViewError";
function ErrorText({ httpStatus, type }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "d-flex flex-column flex-items-center gap-1 text-center",
		children: [/* @__PURE__ */ jsx("div", {
			className: "f2 fgColor-default text-bold",
			children: httpStatus === 404 ? "404 - page not found" : "Error loading page"
		}), httpStatus === 404 ? /* @__PURE__ */ jsx(DescriptionText404, {}) : /* @__PURE__ */ jsx(DefaultDescriptionText, {
			httpStatus,
			type
		})]
	});
}
ErrorText.displayName = "ErrorText";
function DescriptionText404() {
	const $ = c(6);
	const repo = useCurrentRepository();
	const path = usePath();
	const refInfo = useRefInfo();
	if (!refInfo.currentOid) {
		let t0;
		if ($[0] !== refInfo.name) {
			t0 = jsxs("div", {
				className: "d-flex flex-wrap flex-justify-center fgColor-muted",
				"data-testid": "error-404-description",
				children: ["Cannot find a valid ref in\xA0", jsx(BranchName_default, {
					as: "p",
					className: "mb-0",
					children: refInfo.name
				})]
			});
			$[0] = refInfo.name;
			$[1] = t0;
		} else t0 = $[1];
		return t0;
	}
	let t0;
	if ($[2] !== path || $[3] !== refInfo.name || $[4] !== repo.name) {
		t0 = jsxs("div", {
			className: "d-flex flex-wrap flex-justify-center fgColor-muted",
			"data-testid": "eror-404-description",
			children: [
				"The\xA0",
				jsx(BranchName_default, {
					as: "p",
					className: "mb-0",
					children: refInfo.name
				}),
				"\xA0branch of\xA0",
				jsx("p", {
					className: "text-bold mb-0",
					children: repo.name
				}),
				"\xA0does not contain the path\xA0",
				jsxs("p", {
					className: "text-bold mb-0",
					children: [path, "."]
				})
			]
		});
		$[2] = path;
		$[3] = refInfo.name;
		$[4] = repo.name;
		$[5] = t0;
	} else t0 = $[5];
	return t0;
}
DescriptionText404.displayName = "DescriptionText404";
function DefaultDescriptionText({ httpStatus, type }) {
	const errorNumberText = httpStatus ? ` ${httpStatus} error` : "error";
	if (type === "fetchError") return /* @__PURE__ */ jsx("div", {
		className: "f5 fgColor-muted",
		"data-testid": "fetch-error-description",
		children: "It looks like your internet connection is down. Please check it."
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "f5 fgColor-muted",
		"data-testid": "default-error-description",
		children: [
			"An unexpected ",
			errorNumberText,
			" occured. Try",
			/* @__PURE__ */ jsx(Link, {
				inline: true,
				onClick: () => window.location.reload(),
				children: "\xA0reloading the page."
			}, "reload-page")
		]
	});
}
DefaultDescriptionText.displayName = "DefaultDescriptionText";
export { CodeViewError as t };
